

# Generated at 2022-06-23 17:27:18.688538
# Unit test for function no_map_instance
def test_no_map_instance():
    from .utils import utils
    from . import config

    test_config = config.TestConfig()
    data = [{'a': 1, 'b': 2, 'c': [1, 2, 3]}, {'a': 3, 'b': 2, 'c': [1, 2, 3]}]
    data_no_map = [no_map_instance(d) for d in data]
    utils.assert_equal(data_no_map[0]['a'], data[0]['a'])
    utils.assert_equal(data_no_map[1]['b'], data[1]['b'])
    utils.assert_equal(data_no_map[0]['c'], data[0]['c'])

# Generated at 2022-06-23 17:27:27.407182
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'a':0,'b':1,'c':2,'d':3,'e':4,\
                  'f':5,'g':6,'h':7,'i':8,'j':9,'k':10,\
                  'l':11,'m':12,'n':13,'o':14,'p':15,'q':16,\
                  'r':17,'s':18,'t':19,'u':20,'v':21,'w':22,\
                  'x':23,'y':24,'z':25}
    id_to_word = reverse_map(word_to_id)
    assert(len(id_to_word)==26)
    assert(len(set(id_to_word))==26)
    assert(id_to_word[0]=='a')

# Generated at 2022-06-23 17:27:28.288828
# Unit test for function register_no_map_class
def test_register_no_map_class():
    pass



# Generated at 2022-06-23 17:27:38.180396
# Unit test for function map_structure
def test_map_structure():

    def test_func(tup):
        return type(tup)(tup[0]-tup[1], tup[1]-tup[0])

    # Namedtuple
    tuple_2 = namedtuple('tuple_2',['a', 'b'])
    assert map_structure(test_func, tuple_2(2, 3)) == tuple_2(-1, 1)
    assert map_structure(test_func, tuple_2(2.0, 3.0)) == tuple_2(-1.0, 1.0)

    # Tuple
    assert map_structure(test_func, (2, 3)) == (-1, 1)
    assert map_structure(test_func, (2.0, 3.0)) == (-1.0, 1.0)

    # List
    assert map_

# Generated at 2022-06-23 17:27:46.610848
# Unit test for function register_no_map_class
def test_register_no_map_class():
    register_no_map_class(list)
    assert len(_NO_MAP_TYPES) == 1
    assert list in _NO_MAP_TYPES
    register_no_map_class(dict)
    assert len(_NO_MAP_TYPES) == 2
    assert dict in _NO_MAP_TYPES
    register_no_map_class(list)
    assert len(_NO_MAP_TYPES) == 2
    register_no_map_class(dict)
    assert len(_NO_MAP_TYPES) == 2
    return

if __name__ == "__main__":
    test_register_no_map_class()

# Generated at 2022-06-23 17:27:51.839087
# Unit test for function map_structure_zip
def test_map_structure_zip():
    for obj in [
        {'a': 1, 'b': 2},
        [1, 2, 3],
        [1, 2, {'a': 1, 'b': 2}],
        [{'a': 1, 'b': 2}, 2, 3, 4],
    ]:
        mapped = map_structure_zip(lambda x, y: x + y, (obj, obj))
        assert mapped == map_structure(lambda x: 2 * x, obj)

# Generated at 2022-06-23 17:27:57.920342
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # Define a subclass of Size
    class MySize(torch.Size):
        def __init__(self, iterable):
            super().__init__(iterable)

    # Register MySize
    register_no_map_class(MySize)

    # Create a list of Size and MySize
    sizes = [torch.Size([2, 3]), MySize([2, 3])]

    # Call function no_map_instance
    new_sizes = map_structure(no_map_instance, sizes)

    # Test result
    assert (new_sizes == sizes)

# Generated at 2022-06-23 17:28:01.476080
# Unit test for function no_map_instance
def test_no_map_instance():
    l = no_map_instance(list(range(5)))
    l2 = no_map_instance(l)
    l3 = no_map_instance([65])
    assert l == l2 == l3
    assert l.__class__ is not list
    assert l2.__class__ is not list
    assert l3.__class__ is not list


# Generated at 2022-06-23 17:28:04.484390
# Unit test for function reverse_map
def test_reverse_map():
    a = {1:0, 2:1, 3:2, 4:3}
    assert(reverse_map(a) == [1, 2, 3, 4])
    b = {1:3, 2:1, 3:2, 4:0}
    assert(reverse_map(b) == [2, 3, 1, 4])

# Generated at 2022-06-23 17:28:14.780858
# Unit test for function map_structure_zip
def test_map_structure_zip():
    fn = lambda *xs: sum(xs)

    result = map_structure_zip(fn, [[1,2], [3,4]])
    assert result == [4,6]
    print(result)

    result = map_structure_zip(fn, [[1,2], [3,4], [5,6]])
    assert result == [9,12]
    print(result)

    result = map_structure_zip(fn, [[1,2], [3,4], [5,6], [7,8]])
    assert result == [16,20]
    print(result)

    # test_dict

# Generated at 2022-06-23 17:28:18.244808
# Unit test for function reverse_map
def test_reverse_map():
    d = {
        "a": 0,
        "b": 1,
        "c": 2,
        "d": 3
    }
    l = ["a", "b", "c", "d"]
    assert reverse_map(d) == l



# Generated at 2022-06-23 17:28:29.344050
# Unit test for function no_map_instance
def test_no_map_instance():
    class A:
        def __init__(self, b):
            self.b = b
    class B:
        def __init__(self, c):
            self.c = c
        def set_c(self, c):
            self.c = c
    def test_func(x):
        print(x, type(x))
        return x * 2
    register_no_map_class(A)
    a = A(B(1))
    assert a.b.c == 1
    a.b.set_c(2)
    assert a.b.c == 2
    a = no_map_instance(a)
    assert a.b.c == 2
    a = map_structure(test_func, a)
    assert a.b.c == 2
    assert isinstance(a, A)

# Generated at 2022-06-23 17:28:34.929164
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class DummyClass(list):
        pass

    register_no_map_class(DummyClass)
    dummy_instance = DummyClass()

    def update_list(list_item):
        list_item.append(5)
        return list_item

    assert map_structure(update_list, dummy_instance) == [5]


# Generated at 2022-06-23 17:28:45.064243
# Unit test for function register_no_map_class
def test_register_no_map_class():

    # Test 1: Use cases
    n_test = 1
    class list_no(list):
        pass
    register_no_map_class(list_no)
    List_no_instance = map_structure(lambda x: x+34, list_no([12,1,3]))
    print("*Test Register no map class (1/{}):".format(n_test))
    print("List_no_instance: ",List_no_instance)  # Output: list_no([12, 1, 3])
    print("Passed" if List_no_instance==List_no_instance else "Failed")

    # Test 2: Use cases
    class list_no(list):
        pass
    register_no_map_class(list_no)

# Generated at 2022-06-23 17:28:56.537491
# Unit test for function map_structure
def test_map_structure():
    sources = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 5, 'b': 6}]
    tt = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 5, 'b': 6}]
    targets = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 5, 'b': 6}]
    def message_func(source, target):
        return target

    outputs = map_structure_zip(message_func, sources, targets, tt)
    print(outputs)
    assert outputs == {'a': 5, 'b': 6}

if __name__ == '__main__':
    test_map_structure()

# Generated at 2022-06-23 17:29:08.975407
# Unit test for function map_structure
def test_map_structure():
    # Test example
    c1 = [0, [1, 2], 3]
    c2 = {4, [5]}
    c3 = (6, (7, 8))
    c4 = [9, {10, [11]}, 12]
    c5 = {15, [16], (17, 18)}
    c6 = [20, {21, [23], (24, 25)}, 26]

    l1 = c1[0]
    l2 = c2[4]
    l3 = c3[0]
    l4 = c4[0]
    l5 = c5[15]
    l6 = c6[20]

    l_actual = map_structure(lambda x: x*2, l1)
    print(l_actual)
    print(l2)

# Generated at 2022-06-23 17:29:21.626416
# Unit test for function reverse_map

# Generated at 2022-06-23 17:29:33.494007
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def add(x: int, y: int) -> int:
        return x + y

    def add_all(nums: List):
        return sum(nums)


    tensor1 = torch.randn(2, 3)
    tensor2 = torch.randn(2, 3)

    dict1 = {'a': 1, 'b': 2}
    dict2 = {'c': 3, 'd': 4}

    list1 = [[1, 2, 3], [4, 5, 6]]
    list2 = [[7, 8, 9], [10, 11, 12]]

    tuple1 = (1, 2, 3)
    tuple2 = (4, 5, 6)

    _no_map_type(int)
    _no_map_type(tuple)

# Generated at 2022-06-23 17:29:41.959433
# Unit test for function reverse_map

# Generated at 2022-06-23 17:29:48.694565
# Unit test for function map_structure
def test_map_structure():
    import numpy as np
    my_list = [1, 2, 3]
    my_dict = {'one': 1, 'two': 2}
    a = {'one': my_list, 'two': my_dict}
    b = {'one': my_list, 'two': (-1, -2)}
    c = {'one': my_dict, 'two': {'one': my_list}}

    list2array = np.array
    converted_a = map_structure(list2array, a)
    converted_b = map_structure(list2array, b)
    converted_c = map_structure(list2array, c)

    # check converted values
    assert np.all(converted_a['one'] == np.array(my_list))

# Generated at 2022-06-23 17:29:59.178557
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from collections import namedtuple
    from collections import OrderedDict

    test_dict = OrderedDict()
    test_dict['A'] = {'a':1,'b':2}
    test_dict['B'] = {'c':2,'d':4}

    test1_dict = OrderedDict()
    test1_dict['A'] = {'a':1.0,'b':2.0}
    test1_dict['B'] = {'c':2.0,'d':4.0}

    test2_dict = OrderedDict()
    test2_dict['A'] = {'a':1.1,'b':2.1}
    test2_dict['B'] = {'c':2.1,'d':4.1}

    # test if the contents are the same
    assert_

# Generated at 2022-06-23 17:30:04.346875
# Unit test for function reverse_map
def test_reverse_map():
    d = { 'a':1,
          'b':2,
          'c':3,
        }
    expected_L = ['a', 'b', 'c']
    assert (reverse_map(d) == expected_L)
    print("Unit test for reverse_map passed")


# Generated at 2022-06-23 17:30:10.443002
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from typing import Dict
    from loguru import logger
    import torch

    a_dict = Dict[str, torch.Size]()
    a_dict["shape"] = torch.Size([3,3,3])
    a_dict["bbox"] = torch.Size([3,3,3])
    logger.info(a_dict)

    register_no_map_class(torch.Size)
    logger.info(map_structure(lambda x: x.tolist(), a_dict))


# Generated at 2022-06-23 17:30:16.962837
# Unit test for function reverse_map
def test_reverse_map():
    item = ['a', 'b', 'c', 'd']
    item_to_idx = {
        'a': 3,
        'b': 0,
        'c': 1,
        'd': 2
    }
    idx_to_item = reverse_map(item_to_idx)
    assert(item == idx_to_item)

if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-23 17:30:26.676931
# Unit test for function no_map_instance
def test_no_map_instance():
    # Test list
    a = [1,2,3]
    a_instance = no_map_instance(a)
    result = (1,2,3)
    assert(a_instance == result)

    # Test Dict
    b = {1:1,2:2,3:3}
    b_instance = no_map_instance(b)
    result = {1:1,2:2,3:3}
    assert(b_instance == result)

    # Test Tuple
    c = (1,2,3)
    c_instance = no_map_instance(c)
    result = (1,2,3)
    assert(c_instance == result)

    # Test Set
    d = {1,2,3}
    d_instance = no_map_instance(d)
    result

# Generated at 2022-06-23 17:30:34.245333
# Unit test for function map_structure
def test_map_structure():
    def f(i):
        return i
    def g(i):
        return i*2

    a = [1,1,1]
    b = map_structure(f,a)
    for i in range(3):
        assert a[i] == b[i]
        assert type(a[i]) == type(b[i])
    b = map_structure(g,a)
    for i in range(3):
        assert a[i]*2 == b[i]
        assert type(a[i]) == type(b[i])

    a = [[1,1],[1,1]]
    b = map_structure(f,a)
    for i in range(2):
        for j in range(2):
            assert a[i][j] == b[i][j]

# Generated at 2022-06-23 17:30:46.953391
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance([1, 2, 3])[0] == 1
    assert no_map_instance(torch.Tensor([1, 2, 3]))[0] == 1
    assert no_map_instance(np.array([1, 2, 3]))[0] == 1
    assert no_map_instance([1, 2, 3]) == no_map_instance([1, 2, 3])
    assert no_map_instance((1, 2, 3)) == no_map_instance((1, 2, 3))
    assert no_map_instance({"a": 1, "b": 2}) == no_map_instance({"a": 1, "b": 2})
    assert no_map_instance({"a": 1, "b": 2}) == no_map_instance({"b": 2, "a": 1})

# Generated at 2022-06-23 17:30:50.250997
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch

    register_no_map_class(torch.Size)
    assert torch.Size([4,5,5]) in _NO_MAP_TYPES

# Generated at 2022-06-23 17:31:03.130752
# Unit test for function map_structure
def test_map_structure():
    a = [1, 2, 3]
    assert map_structure(lambda x: x + 1, a) == [2, 3, 4]

    b = [a, a]
    assert map_structure(lambda x: x + 1, b) == [[2, 3, 4], [2, 3, 4]]

    c = ["abc", "def", "hij"]
    assert map_structure(len, c) == [3, 3, 3]

    d = {"a": "ab", "b": "bc", "c": "cd"}
    assert map_structure(len, d) == {"a": 2, "b": 2, "c": 2}

    e = set(["abc", "def", "hij"])
    assert map_structure(len, e) == {3, 3, 3}

   

# Generated at 2022-06-23 17:31:12.735471
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = {
        'a': {
            1 : 2,
            2 : 4
        },
        'b': {
            1 : 4,
            2 : 3
        }
    }
    b = {
        'a': {
            1 : 2,
            2 : 5
        },
        'b': {
            1 : 4,
            2 : 3
        }
    }

    answer = {
        'a': {
            1 : 4,
            2 : 9
        },
        'b': {
            1 : 8,
            2 : 6
        }
    }

    assert(map_structure_zip(lambda x, y: x + y, [a, b]) == answer)

# Generated at 2022-06-23 17:31:24.971118
# Unit test for function map_structure
def test_map_structure():
    with_label = 'with_label'
    no_label = 'no_label'
    objs = [1, 2, 3, 4]
    objs2 = [(5, 6), (7, 8), (9, 10), (11, 12)]
    def fn(x):
        return x

    assert [[1, 1, 1], [2, 2, 2], [3, 3, 3]] == map_structure(fn, [[1, 1, 1], [2, 2, 2], [3, 3, 3]])
    assert (1, 2, 3, 4) == map_structure(fn, (1, 2, 3, 4))
    assert {1, 2, 3, 4} == map_structure(fn, {1, 2, 3, 4})

# Generated at 2022-06-23 17:31:37.763470
# Unit test for function map_structure_zip
def test_map_structure_zip():
    class Position:
        def __init__(self, x, y):
            self.x = x
            self.y = y
    
    class Size:
        def __init__(self, x, y):
            self.x = x
            self.y = y

    class Box:
        def __init__(self, pos, size):
            self.pos = pos
            self.size = size

    def add(a, b):
        return a + b

    a = 1
    b = 2

    x = Position(a, a)
    y = Position(b, b)
    z = Size(a, a)
    w = Size(b, b)
    m = Box(x, z)
    n = Box(y, w)

    print("Testing with no nested structures.")

# Generated at 2022-06-23 17:31:40.056019
# Unit test for function register_no_map_class
def test_register_no_map_class():

    @dataclass
    class MyClass:
        my_attr: int

    f = lambda x: x.my_attr

    objs = [MyClass(1), MyClass(2)]
    register_no_map_class(MyClass)
    assert map_structure(f, objs) == [1, 2]

# Generated at 2022-06-23 17:31:48.551378
# Unit test for function register_no_map_class
def test_register_no_map_class():
    lst = [1, 2, 3]
    lst_mapped = map_structure(lambda x: x + 1, lst)
    assert lst_mapped == [2, 3, 4]
    lst_no_map = no_map_instance(lst)
    register_no_map_class(type(lst_no_map))
    lst_no_map_mapped = map_structure(lambda x: x + 1, lst_no_map)
    assert lst_no_map_mapped == lst_no_map


# Generated at 2022-06-23 17:31:58.894223
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import OrderedDict

    # Use OrderedDict as the parent class to avoid inconsistent order.
    class A(OrderedDict):
        pass

    # A contains other containers and thus should be traversed.
    a0 = A({"a": {"b": [1, 2, 3]}, "b": {"c": [4, 5, 6]}, "c": {"d": [7, 8, 9]}})
    # An instance of a no_map class should not be traversed.
    a1 = no_map_instance(a0)
    # Modify the contents of a0; a1 should not have the same contents.
    a0["a"]["b"][0] += 1
    # In order to avoid function calls, use asserts.

# Generated at 2022-06-23 17:32:09.712633
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = {
        "a": {
            "aa": [1,2,3],
            "ab": "ab",
            "ac": {
                "aca": {
                    "acaa": "acaa"
                }
            }
        },
        "b": [1,2],
        "c": (1,2)
    }

    b = {
        "a": {
            "aa": [4,5,6],
            "ab": "ab_b",
            "ac": {
                "aca": {
                    "acaa": "acaa_b"
                }
            }
        },
        "b": [7,8],
        "c": (3,4)
    }

# Generated at 2022-06-23 17:32:22.179829
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def g(a, b):
        return a + b

    m = map_structure_zip(g, [1, 2, 3], [10, 20, 30])
    assert m == [11, 22, 33]

    m1 = map_structure_zip(g, {1: 100, 2: 200, 3: 300}, {1: 1000, 2: 2000, 3: 3000})
    assert m1 == {1: 1100, 2: 2200, 3: 3300}

    m2 = map_structure_zip(g, [[1, 2, 3], [10, 20, 30]], [[100, 200, 300], [1000, 2000, 3000]])
    assert m2 == [[101, 202, 303], [1010, 2020, 3030]]



if __name__ == '__main__':
    test_map_

# Generated at 2022-06-23 17:32:34.534153
# Unit test for function map_structure
def test_map_structure():
    # Dicts
    d1 = {'a': 1, 'b': 2}
    d2 = {'b': 2, 'a': 3}

    def twice(x):
        return 2*x

    print(map_structure(twice, d1))
    print(map_structure_zip(lambda x1, x2: 2*x1+x2, [d1, d2]))

    # Lists
    l1 = [1, 2, 3]
    l2 = [2, 3, 4]

    print(map_structure(twice, l1))
    print(map_structure_zip(lambda x1, x2: 2*x1+x2, [l1, l2]))

    # Sets
    s1 = {1, 2, 3}

# Generated at 2022-06-23 17:32:46.839930
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class MyList(list): pass
    my_list = MyList([1, 2, 3])
    
    @register_no_map_class(list)
    def test():
        def test_fn(x):
            return x + 1
        return map_structure(test_fn, my_list)
    
    assert my_list == test()
    
    class MyDict(dict): pass
    my_dict = MyDict({1: 'a', 2: 'b', 3: 'c'})
    
    @register_no_map_class(dict)
    def test2():
        def test_fn(x):
            return x + '1'
        return map_structure(test_fn, my_dict)
    
    assert my_dict == test2()

# Generated at 2022-06-23 17:32:57.699531
# Unit test for function map_structure
def test_map_structure():
    x = {'abc': [1, 2], 'def': [['a', 1], ['b', '2']]}
    y = {'abc': ['a', 'b', 'c'], 'def': [['d', 'e', 'f'], [3, 4, 5]]}
    print(map_structure(lambda x: 2 * x, x))
    # {'abc': [2, 4], 'def': [['a', 2], ['b', '22']]}
    print(map_structure(lambda x: 2 * x, [x, y]))
    # [{'abc': [2, 4], 'def': [['a', 2], ['b', '22']]}, {'abc': ['aa', 'bb', 'cc'], 'def': [['dd', 'ee', 'ff'], [3,

# Generated at 2022-06-23 17:33:04.612252
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import numpy as np
    register_no_map_class(np.ndarray)
    t1 = no_map_instance(np.zeros(5))
    t2 = no_map_instance([1,2,3])
    t3 = no_map_instance((1,2,3))
    print(map_structure(lambda x: x + 2, [t1, t2, t3]))


if __name__ == "__main__":
    test_register_no_map_class()

# Generated at 2022-06-23 17:33:14.466233
# Unit test for function map_structure
def test_map_structure():
    from nltk.tree import Tree as nltkTree

    def f(x):
        if isinstance(x, int):
            return str(x)
        elif isinstance(x, str):
            return x[::-1]
        elif isinstance(x, nltkTree):
            return nltkTree(x.label(), [f(y) for y in x])

    tree1 = nltkTree("ROOT", [
        nltkTree("S", [
            nltkTree("NP", ["Jack"]),
            nltkTree("VP", [
                nltkTree("VP", ["ate"]),
                nltkTree("NP", ["bread"])
            ])
        ])
    ])

# Generated at 2022-06-23 17:33:20.623588
# Unit test for function map_structure
def test_map_structure():
    l1 = [1,2,3]
    l2 = [l1, l1]
    l3 = [l2, l2]
    l4 = [l3, l3]
    l5 = ["hello", "world", "!"]
    l6 = [[l5]]
    l7 = [l6, l6]
    l8 = [l7, l7]

    l9 = [1,2,3]
    l10 = [l9, l9]
    l11 = [l10, l10]

    l12 = [l11, l11]

    l13 = [1,2,3]
    l14 = [l9, l13]
    l15 = [l10, l14]
    l16 = [l11, l15]


# Generated at 2022-06-23 17:33:30.146325
# Unit test for function map_structure
def test_map_structure():
    def my_function(obj):
        return obj + 1

    assert(map_structure(my_function, [1, 2, 3]) == [2, 3, 4])
    assert(map_structure(my_function, (1, 2, 3)) == (2, 3, 4))
    assert(map_structure(my_function, {1: 1, 2: 2, 3: 3}) == {1: 2, 2: 3, 3: 4})
    assert(map_structure(my_function, [1, (2, 3, [4, 5]), 6]) == [2, (3, 4, [5, 6]), 7])


# Generated at 2022-06-23 17:33:36.661112
# Unit test for function register_no_map_class
def test_register_no_map_class():
    try:
        import torch
        from torch import Size
        from torch import Tensor
    except ImportError:
        pass
    else:
        register_no_map_class(Size)
        assert isinstance(map_structure(lambda x: x, Size([1, 2, 3])), Size)
        assert isinstance(map_structure_zip(lambda x, y: x+y, [Tensor([1, 2, 3]), Size([4, 5, 6])]), Size)


# Generated at 2022-06-23 17:33:47.814329
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import OrderedDict
    from copy import deepcopy
    from typing import Callable, Optional, Type
    from functools import partial

    # noinspection PyUnusedLocal
    class A:
        def __init__(self, val: Optional[int] = None) -> None:
            self.val = val

    class B:
        def __init__(self, val: Optional[int] = None) -> None:
            self.val = val

    def assert_no_map(fn: Callable[[int], int], obj: Type[A], no_map_obj: Type[B], val: Optional[int] = None) -> None:
        a = obj(val)
        b = no_map_obj(val)
        a_map = deepcopy(a)
        b_map = deepcopy(b)


# Generated at 2022-06-23 17:33:59.017876
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = [4, 5]
    c = [6, 7, 8]
    d = a + b + c
    d = (d, d)
    def add(x, y, z, w, u, v, p, q, r):
        return x + y + z + w + u + v + p + q + r
    assert map_structure_zip(add, [a, b, c]) == map_structure_zip(add, [[1, 2, 3], [4, 5], [6, 7, 8]])
    assert map_structure_zip(add, d) == map_structure_zip(add, [d, d])
    class MyClass(object):
        def __init__(self, x):
            self.x = x

# Generated at 2022-06-23 17:34:01.608273
# Unit test for function no_map_instance
def test_no_map_instance():
    obj = [{'a': [1, 2], 'b': 1}]
    obj = map_structure(no_map_instance, obj)
    print(obj)


# Generated at 2022-06-23 17:34:12.686053
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # Test class
    class SubList(list):
        pass

    test_list = SubList([1, 2, 3, 4])

    # Test function
    def map_func(x):
        return x * 2

    # If a class is not registered, it will result in a TypeError
    try:
        mapped_list = map_structure(map_func, test_list)
    except TypeError:
        print("Test for map_structure failed")

    # If a class is registered, it should work correctly
    register_no_map_class(list)
    mapped_list = map_structure(map_func, test_list)
    print("mapped_list =", mapped_list)
    assert(mapped_list == [2, 4, 6, 8])

# Generated at 2022-06-23 17:34:20.988271
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from collections import namedtuple
    from typing import Tuple, List

    Address = namedtuple("Address", ["street", "city", "zip_code"])
    Person = namedtuple("Person", ["name", "age", "address"])

    john = Person(name="John", age=27, address=Address(street="Tubman street", city="Washington", zip_code=20011))
    ben = Person(name="Ben", age=26, address=Address(street="Smithfield street", city="New York", zip_code=10590))

    def difference(a1: Address, a2: Address) -> Address:
        street_diff = a1.street != a2.street
        city_diff = a1.city != a2.city
        zip_code_diff = a1.zip_code != a2.zip_code

# Generated at 2022-06-23 17:34:25.711780
# Unit test for function reverse_map
def test_reverse_map():
    a = [1, 2, 3, 3, 3, 4, 5]
    d = {i: idx for idx, i in enumerate(a)}
    assert reverse_map(d) == a



# Generated at 2022-06-23 17:34:34.979268
# Unit test for function no_map_instance
def test_no_map_instance():
    import inspect
    import os
    
    def _test_no_map_instance():
        no_map_instance([1,2])

    test_file = inspect.stack()[0][1]
    test_file_folder = os.path.dirname(test_file)
    test_file_name = os.path.basename(test_file).split('.')[0]
    test_file_name_sub = test_file_name + "_sub"
    test_file_sub = os.path.join(test_file_folder, test_file_name_sub + ".py")

    with open(test_file_sub, 'w') as f:
        f.write("import sys\nsys.path.append('{}')\n".format(test_file_folder))

# Generated at 2022-06-23 17:34:40.049590
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x:x+1, [[1,2],[3,4]]) == [[2,3],[4,5]]
    assert map_structure(lambda x:x+1, (1,2)) == (2,3)
    assert map_structure(lambda x:x+1, {'a':1, 'b':2}) == {'a':2, 'b':3}

# Generated at 2022-06-23 17:34:50.054705
# Unit test for function no_map_instance
def test_no_map_instance():
    l = no_map_instance([1])
    assert(no_map_instance(l) is l)
    assert(map_structure(lambda x: x, l) is l)
    d = no_map_instance({1:1})
    assert(no_map_instance(d) is d)
    assert(map_structure(lambda x: x, d) is d)
    t = no_map_instance((1,))
    assert(no_map_instance(t) is t)
    assert(map_structure(lambda x: x, t) is t)



# Generated at 2022-06-23 17:34:58.083520
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = {"a":{"b":1,"c":2,"dd":(2,3)}}
    b = {"a":{"b":2,"c":3,"dd":(3,4)}}
    c = {"a":{"b":3,"c":4,"dd":(4,5)}}
    d = {"a":{"b":4,"c":5,"dd":(5,6)}}
    objs = (a,b,c,d)
    def add(x,y,z,w):
        return x+y+z+w
    print(map_structure_zip(add,objs))
# test_map_structure_zip()

# Generated at 2022-06-23 17:35:06.744172
# Unit test for function reverse_map

# Generated at 2022-06-23 17:35:15.527827
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from collections import OrderedDict

    @no_type_check
    def fn(*objs):
        return objs

    # obj1 is a nested dictionary
    obj1 = OrderedDict()
    obj1['a'] = OrderedDict()
    obj1['a']['aa'] = 1
    obj1['a']['ab'] = 2
    obj1['b'] = OrderedDict()
    obj1['b']['ba'] = 3
    obj1['b']['bb'] = 4

    # obj2 is a nested dictionary
    obj2 = OrderedDict()
    obj2['a'] = OrderedDict()
    obj2['a']['aa'] = 5
    obj2['a']['ab'] = 6
    obj2['b'] = OrderedDict()
   

# Generated at 2022-06-23 17:35:23.338109
# Unit test for function map_structure
def test_map_structure():
    t1 = ([1, 2, 3], [4, 5, 6])
    tp = [3, 2, 1]
    t2 = [4, 5, 6]
    t3 = [6, 8, 10]
    t1 = map_structure(lambda x: x * 2, t1)
    assert t1 == ([2, 4, 6], [8, 10, 12])
    assert map_structure(lambda x: x, tp) == [3, 2, 1]
    assert map_structure(lambda x, y: x + y, t2, t3) == [10, 13, 16]
    assert map_structure(lambda x, y: x + y, tp, tp) == [6, 4, 2]

# Generated at 2022-06-23 17:35:31.752723
# Unit test for function register_no_map_class
def test_register_no_map_class():
    DictType = Dict[int, int]
    demo_dict: DictType = {1: 1, 2: 2}
    DictType_no_map = _no_map_type(type(demo_dict))
    assert type(no_map_instance(demo_dict)) is DictType_no_map
    assert hasattr(no_map_instance(demo_dict), _NO_MAP_INSTANCE_ATTR)

    ListType = List[int]
    demo_list: ListType = [0, 1, 2, 3]
    ListType_no_map = _no_map_type(type(demo_list))
    assert type(no_map_instance(demo_list)) is ListType_no_map

# Generated at 2022-06-23 17:35:37.168816
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from collections import namedtuple
    from types import SimpleNamespace
    from torch import Size
    from slgnn.utils import register_no_map_class, map_structure

    register_no_map_class(namedtuple)
    register_no_map_class(SimpleNamespace)
    register_no_map_class(Size)

    t = SimpleNamespace(
        a=10,
        b=Size([1, 2]),
        c=namedtuple('foo', 'a b')(10, 20),
        d=SimpleNamespace(
            e=20,
            f=namedtuple('foo', 'a b')(10, 20)
        ),
        g=[
            namedtuple('foo', 'a b')(10, 20)
        ])


# Generated at 2022-06-23 17:35:47.502685
# Unit test for function map_structure
def test_map_structure():
    a = {'b': [{'c': 3, 'd': (1, 2)}, {'e': 1, 'f': 2}]}

    def add_one(x):
        return x + 1

    b = map_structure(add_one, a)
    assert b == {'b': [{'c': 4, 'd': (2, 3)}, {'e': 2, 'f': 3}]}

    a = {'b': [{'c': 3, 'd': (1, 2)}, {'e': 1, 'f': 2}]}

    def sum_list(x):
        return sum(x)

    b = map_structure(sum_list, a)

# Generated at 2022-06-23 17:35:55.010356
# Unit test for function map_structure
def test_map_structure():
    from typing import NamedTuple
    from collections import OrderedDict
    from mltk.utils import flatten_nested_structure

    TestNestedCase = NamedTuple('TestNestedCase', [])
    TestNestedCase.__new__.__defaults__ = (1,)


# Generated at 2022-06-23 17:36:06.698923
# Unit test for function map_structure
def test_map_structure():
    structure1 = {'a': 1, 'b': [2,3]}
    structure2 = {'b': [4,5], 'a': 6}
    structure3 = {'a': 7, 'b': [8,9]}
    structures = [structure1, structure2, structure3]

    def add(x: int, y: int, z: int) -> int:
        return x + y + z
    assert map_structure_zip(add, structures) == {'a': 14, 'b': [14, 17]}

    def add2(x=None, y=None, z=None) -> int:
        return (x or 0) + (y or 0) + (z or 0)
    assert map_structure_zip(add2, structures) == {'a': 14, 'b': [14, 17]}

# Generated at 2022-06-23 17:36:15.443295
# Unit test for function map_structure
def test_map_structure():
    import torch
    a = torch.Tensor([[[1], [0]], [[1], [1]]])
    b = [[1, 2], [3, 4]]
    c = torch.Size([2])
    d = a.size()
    e = [[1, 2, 3], [4, 5]]
    f = [[1], [1]]
    fn = lambda xs: sum(xs)
    ans = map_structure(fn, [a, b, c, d, e, f])
    assert(ans == [[4, 5], [8, 6]])
    return

# Generated at 2022-06-23 17:36:23.618722
# Unit test for function register_no_map_class
def test_register_no_map_class():
    register_no_map_class(list)
    assert list in _NO_MAP_TYPES
    register_no_map_class(dict)
    assert dict in _NO_MAP_TYPES
    register_no_map_class(set)
    assert set in _NO_MAP_TYPES
    register_no_map_class(tuple)
    assert tuple in _NO_MAP_TYPES


# Generated at 2022-06-23 17:36:27.641546
# Unit test for function no_map_instance
def test_no_map_instance():
    assert map_structure(lambda x: x**2, [1, 2, 3]) == [1, 4, 9]
    assert map_structure(lambda x: x**2, no_map_instance([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-23 17:36:37.945224
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = list(range(3))
    b = tuple(range(3))
    c = {'a': list(range(3)), 'b': tuple(range(3))}
    d = OrderedDict({'a': list(range(3)), 'b': tuple(range(3))})
    e = set(range(3))
    f = [c]
    g = (d,)
    h = {'a': f, 'b': g}

    def fn(objs):
        return objs

    def fn_str(objs):
        return str(objs)

    def fn_sum(objs):
        return sum(objs)

    fns = [fn, fn_str, fn_sum]
    objs_list = [a, b, c, d, e]


# Generated at 2022-06-23 17:36:46.803231
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from transformers import PreTrainedTokenizerFast
    from transformers.tokenization_utils import PreTrainedTokenizer

    test_tokenizer = PreTrainedTokenizerFast(
        "bert-base-chinese",
        do_lower_case=True,
        remove_space=True,
        keep_accents=False,
        unk_token="<unk>",
        sep_token="<s>",
        pad_token="<pad>",
        cls_token="<cls>",
        mask_token="<mask>",
        tokenize_chinese_chars=False,
        clean_text=False,
        handle_chinese_chars=True,
        strip_accents=None,
        lowercase=True,
        wordpieces_prefix="##",
    )


# Generated at 2022-06-23 17:36:54.932461
# Unit test for function no_map_instance
def test_no_map_instance():
    named_tuple = collections.namedtuple('named_tuple', ['a', 'b'])
    instance = named_tuple(a=[1, 2, [3, 4]], b='b')
    instance_new = no_map_instance(instance)
    assert instance_new is instance, 'instance_new should be instance'
    with pytest.raises(AttributeError):
        instance_new._fields

    another_instance = named_tuple(a=[5, 6, [7, 8]], b='c')
    another_instance_new = no_map_instance(another_instance)
    assert another_instance_new is another_instance, 'another_instance_new should be another_instance'
    with pytest.raises(AttributeError):
        another_instance_new._fields



# Generated at 2022-06-23 17:37:05.859814
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # Case 1: register a subclass of list
    class MyList(list):
        pass
    # Register MyList as a not-mappable class
    register_no_map_class(MyList)
    # Verify that the returned collection is correct
    assert([[], [1, 2], [3, 4, 5]] == map_structure(lambda x: x, [[], [1, 2], MyList([3, 4, 5])]))
    # Case 2: register a subclass of tuple
    class MyTuple(tuple):
        pass
    # Register MyTuple as a not-mappable class
    register_no_map_class(MyTuple)
    # Verify that the returned collection is correct

# Generated at 2022-06-23 17:37:14.146673
# Unit test for function no_map_instance
def test_no_map_instance():
    input_list = [1, 2, 3]
    mapped_no_map = map_structure(lambda x: x + 1, no_map_instance(input_list))
    assert mapped_no_map == [1, 2, 3], "Mapping over no_map_instance did not give expected result"
    mapped_normal = map_structure(lambda x: x + 1, input_list)
    assert mapped_normal == [2, 3, 4], "Mapping over normal list did not give expected result"