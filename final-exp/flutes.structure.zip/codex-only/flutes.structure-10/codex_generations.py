

# Generated at 2022-06-23 17:27:26.251125
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class CustomList(list):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    register_no_map_class(CustomList)
    # Test single custom container
    custom_list = CustomList([1, 2, 3, 4])
    square = lambda x: x*x
    result = map_structure(square, custom_list)
    expected_result = map_structure(square, [1, 2, 3, 4])
    assert result == expected_result

    # Test nested custom containers
    custom_list_nested = CustomList([custom_list, CustomList([1, 2, 3, 4])])
    result = map_structure(square, custom_list_nested)

# Generated at 2022-06-23 17:27:30.677579
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance(list([2, 3, 4])) == [2, 3, 4]
    assert no_map_instance(dict(name='Bert')) == dict(name='Bert')
    assert no_map_instance(tuple([1, 2])) == (1, 2)
    assert no_map_instance(2) == 2


if __name__ == "__main__":
    for test in list(filter(lambda x: x.startswith('test_'), locals())):
        print(getattr(locals()[test], '__doc__'))
        getattr(locals()[test], '__call__')()

# Generated at 2022-06-23 17:27:38.392732
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from collections import defaultdict
    from copy import copy
    from typing import Any, Generator

    def identity(x: Any) -> Any: return x

    class SubDefaultDict(defaultdict):
        pass

    d = SubDefaultDict({1: [1, 2, 3], 2: [4, 5, 6]})
    # d_copy is an ordinary defaultdict (not an instance of SubDefaultDict)
    d_copy = copy(d)
    assert d == d_copy
    _ = map_structure(identity, d)
    # d_copy should have been updated
    assert d == d_copy

    register_no_map_class(SubDefaultDict)
    d_copy = copy(d)
    assert d == d_copy
    _ = map_structure(identity, d)
    # d_

# Generated at 2022-06-23 17:27:49.544767
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def add1(x, y):
        return x + y

    tup = ((2, 3), (6, 7))
    dic = {'a': (2, 3), 'b': (6, 7)}
    lis = [(2, 3), (6, 7)]

    # test for tuple
    assert map_structure_zip(add1, tup) == (5, 10)
    # test for dict
    assert map_structure_zip(add1, dic) == {'a': 5, 'b': 10}
    # test for list
    assert map_structure_zip(add1, lis) == [5, 10]


# Generated at 2022-06-23 17:27:53.739603
# Unit test for function reverse_map
def test_reverse_map():
    d = {'k1':0, 'k2':1, 'k3':2}
    ret = reverse_map(d)
    print(ret)
    assert(ret == ['k1', 'k2', 'k3'])
    print('reverse_map unit test passed')

if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-23 17:28:02.673558
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'a': 0, 'b': 1, 'c': 2}
    id_to_word = reverse_map(word_to_id)
    print(id_to_word)
    assert id_to_word == ['a', 'b', 'c']


# Generated at 2022-06-23 17:28:04.320927
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    register_no_map_class(torch.Size)


# Generated at 2022-06-23 17:28:12.008770
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance(([1, 2, 3], [4, 5, 6])) == ([1, 2, 3], [4, 5, 6])
    assert no_map_instance(([1, 2, 3], [4, 5, 6])) == no_map_instance(([1, 2, 3], [4, 5, 6]))
    assert no_map_instance([1, 2, 3]) != [1, 2, 3]
    assert no_map_instance([1, 2, 3]) == no_map_instance([1, 2, 3])

# Generated at 2022-06-23 17:28:19.107324
# Unit test for function map_structure
def test_map_structure():
    embedding_size = 7
    hidden_size = 5
    a = torch.rand(hidden_size, hidden_size) * 10 - 5
    b = torch.rand(embedding_size, hidden_size) * 10 - 5
    def foo(x):
        return x + 1
    def bar(x, y):
        return x + y
    l = [a, b]
    print(l)
    l_ = map_structure(foo, l)
    print(l_)
    l__ = map_structure_zip(bar, [l, l_])
    print(l__)


# test_map_structure()

# Generated at 2022-06-23 17:28:24.067939
# Unit test for function reverse_map
def test_reverse_map():

    word_to_id = {'hello':1, 'world':2, 'hi':3}
    id_to_word = reverse_map(word_to_id)

    print(id_to_word)

if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-23 17:28:32.646842
# Unit test for function no_map_instance
def test_no_map_instance():
    test_dict = {1:1}
    test_list = [1,2,3]
    test_set = set([1,2,3])
    test_tuple = (1,2,3)
    assert no_map_instance(test_dict)[1] == test_dict[1]
    assert no_map_instance(test_list)[1] == test_list[1]
    assert no_map_instance(test_set)[1] == test_set[1]
    assert no_map_instance(test_tuple)[1] == test_tuple[1]

# Generated at 2022-06-23 17:28:43.817230
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import math
    import torch

    item = [torch.tensor([0.]), torch.tensor([1.])]

    register_no_map_class(math.sqrt)
    # This should not map over the tensor's elements.
    output = map_structure(math.sqrt, item)
    assert torch.equal(output[0], torch.tensor([0.]))
    assert torch.equal(output[1], torch.tensor([1.]))

    register_no_map_class(torch.Size)
    # This should not map over the tensor's elements.
    output = map_structure(math.sqrt, item)
    assert torch.equal(output[0], torch.tensor([0.]))
    assert torch.equal(output[1], torch.tensor([1.]))

    # The

# Generated at 2022-06-23 17:28:49.781664
# Unit test for function map_structure
def test_map_structure():
    obj = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    import numpy as np
    np.testing.assert_equal(map_structure(np.sum, obj), np.add(obj[0], obj[1]))


if __name__ == '__main__':
    test_map_structure()

# Generated at 2022-06-23 17:29:01.253822
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from typing import NamedTuple
    from collections import OrderedDict
    from torch.size import Size

    d = {'a': 1, 'b': 2}
    size = Size([3, 2])
    namedtuple = NamedTuple('CustomType', [('a', int), ('b', int)])
    custom_tuple = namedtuple(1, 2)
    ol = OrderedDict()
    ol['a'] = 1
    ol['b'] = 2
    register_no_map_class(type(size))
    register_no_map_class(type(namedtuple))
    register_no_map_class(type(ol))
    assert map_structure(len, d) == {'a': 1, 'b': 1}
    assert no_map_instance(size) == size
    assert no

# Generated at 2022-06-23 17:29:06.503254
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def myf(*xs):
        return sum(xs)
    assert map_structure_zip(myf, [[1,2], [3,4]]) == [4,6]

if __name__ == '__main__':
    test_map_structure_zip()

# Generated at 2022-06-23 17:29:08.607620
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = {"a":[1,2,3], "b":[1,2,3]}
    b = {"a":[11,22,33], "b":[11,22,33]}
    c = map_structure_zip(lambda x,y:x+y, [a,b])

    assert c == {"a":[12,24,36], "b":[12,24,36]}


# Generated at 2022-06-23 17:29:15.520729
# Unit test for function reverse_map
def test_reverse_map():
    dict_ = {
        'Neo': 0,
        'Trinity': 1,
        'Morpheus': 2,
        'Cypher': 3,
    }
    result = ['Neo', 'Trinity', 'Morpheus', 'Cypher']
    print(reverse_map(dict_) == result)


# Generated at 2022-06-23 17:29:24.305947
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class SubList(list):
        pass
    list_ = SubList([1, 2, 3])
    list_ = no_map_instance(list_)
    list_ = map_structure(lambda x: x*2, list_)
    assert list_ == [2, 4, 6]

    class SubTuple(tuple):
        pass
    tuple_ = SubTuple([1, 2, 3])
    tuple_ = no_map_instance(tuple_)
    tuple_ = map_structure(lambda x: x*2, tuple_)
    assert tuple_ == (2, 4, 6)

    class SubDict(dict):
        pass
    dict_ = SubDict({0:1, 1:2, 2:3})
    dict_ = no_map_instance(dict_)

# Generated at 2022-06-23 17:29:35.904780
# Unit test for function register_no_map_class
def test_register_no_map_class():
    l1 = [1, 2, 3]
    l2 = [4, 5, 6]
    l3 = [7, 8, 9]
    l1 = no_map_instance(l1)
    assert l1.__class__ != list
    assert l1 == [1, 2, 3]
    l1 = [1, 2, 3]
    l2 = [4, 5, 6]
    l3 = [7, 8, 9]
    l1 = no_map_instance(l1)
    assert l1.__class__ != list
    assert l1 == [1, 2, 3]
    assert (map_structure(lambda x: x[0], [l1, l2, l3]) == [1, 4, 7])

# Generated at 2022-06-23 17:29:43.545456
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert map_structure(lambda x: x + 1, (1, 2, 3)) == (2, 3, 4)
    assert map_structure(lambda x: x + 1, {1: 2, 3: 4}) == {2: 3, 4: 5}
    assert map_structure(lambda x: x + 1, [[1, 2], [3, 4]]) == [[2, 3], [4, 5]]
    assert map_structure(lambda x: x + 1, ((1, 2), (3, 4))) == ((2, 3), (4, 5))

# Generated at 2022-06-23 17:29:52.729751
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Create two lists of same structure
    first = [1,
             {"key_0": 2, "key_1": 3},
             (10, 20, 30),
             torch.Size([10, 20, 30]),
             {"key_0": 5, "key_1": 7},
             [4, 5, 6]]
    second = [4,
              {"key_0": 5, "key_1": 7},
              (10, 20, 30),
              torch.Size([1, 2, 3]),
              {"key_0": 2, "key_1": 3},
              [1, 2, 3]]
    # The test function
    def fn(*args):
        if len(args) == 2:
            return args[0] + args[1]

# Generated at 2022-06-23 17:30:05.251771
# Unit test for function map_structure
def test_map_structure():
    assert list(map_structure(lambda x: x+1, [1, 2, 2.0])) == [2.0, 3.0, 3.0]
    assert list(map_structure(lambda x: x+1, (1, 2, 2.0))) == [2.0, 3.0, 3.0]
    assert list(map_structure(lambda x: x+1, {1, 2, 2.0})) == [2.0, 3.0, 3.0]
    assert list(map_structure(lambda x: x+1, {'a': 1, 'b': 3})) == [2.0, 4.0]

# Generated at 2022-06-23 17:30:10.396273
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x + 1, [[[2]]]) == [[[3]]]
    assert (map_structure(lambda x: x, {"x": [["y"]]}) ==
            {"x": [["y"]]})
    assert (map_structure(lambda x: x + 1, {"x": [["y"]]}) ==
            {"x": [["y1"]]})
    assert map_structure(lambda x: x + 1, [[[2], [3], [4]]]) == [[[3], [4], [5]]]
    assert (map_structure(lambda x: x, {"x": [["y"]],
                                        "z": [["q"]]}) ==
            {"x": [["y"]],
             "z": [["q"]]})

# Generated at 2022-06-23 17:30:14.515118
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Test():
        pass

    x = Test()
    register_no_map_class(Test)
    assert map_structure(lambda x: x, x) == x
    assert map_structure(lambda x: x, [x]) == [x]
    assert map_structure(lambda x: x, (x, x)) == (x, x)
    assert map_structure(lambda x: x, {1:x}) == {1:x}


# Generated at 2022-06-23 17:30:18.701161
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # Case 1:
    test_tuple = tuple([1, 2, 3])
    map_structure(lambda x: x + 10, test_tuple)
    # Case 2:
    register_no_map_class(tuple)
    map_structure(lambda x: x + 10, test_tuple)

# Generated at 2022-06-23 17:30:28.429646
# Unit test for function map_structure
def test_map_structure():
    def map_fn(obj):
        if isinstance(obj, list):
            return 2*obj
        elif isinstance(obj, tuple):
            return obj + tuple([3, 4, 5])
        elif isinstance(obj, dict):
            return obj.get('f', 0)
        return obj
    
    list_obj = [1, 2, 3]
    list_obj2 = [2, 4, 6]
    list_obj3 = [1, 2, 3]
    tuple_obj = (1, 2, 3)
    tuple_obj2 = (2, 4, 6)
    # tuple_obj3 = (1, 2, 3, 4, 5, 6)
    dict_obj = {'a':1, 'b':2}

# Generated at 2022-06-23 17:30:34.777196
# Unit test for function reverse_map

# Generated at 2022-06-23 17:30:40.848272
# Unit test for function register_no_map_class
def test_register_no_map_class():
    d = {'a': 1}
    register_no_map_class(type(d))
    # We cannot directly modify d to get the desired result
    d = no_map_instance(d)
    assert map_structure(lambda x: 2, d) == {'a': 2}

# Generated at 2022-06-23 17:30:52.565777
# Unit test for function map_structure
def test_map_structure():
    list_test = [1, 2, 3]
    str_test = "abc"
    tuple_test = (1, 2, 3)
    namedtuple_test = collections.namedtuple('A',['a','b','c'])
    dict_test = {'a':1, 'b':2, 'c':3}
    math_function_test = lambda x: x*2
    _ = [None] * 3
    test_list = [list_test, str_test, tuple_test, namedtuple_test, dict_test]
    test_function = [math_function_test] * 5
    for i in range(len(test_list)):
        test_in = test_list[i]
        fn = test_function[i]

# Generated at 2022-06-23 17:31:04.225150
# Unit test for function no_map_instance
def test_no_map_instance():
    x = no_map_instance(1)
    assert x == 1
    assert type(x) == int

    x = no_map_instance([1])
    assert x == [1]
    assert type(x) == list
    # assert hasattr(x, _NO_MAP_INSTANCE_ATTR)

    x = no_map_instance((1,))
    assert x == (1,)
    assert type(x) == tuple
    assert hasattr(x, _NO_MAP_INSTANCE_ATTR)

    x = no_map_instance({1: 1})
    assert x == {1: 1}
    assert type(x) == dict
    assert hasattr(x, _NO_MAP_INSTANCE_ATTR)

    x = no_map_instance({1})
    assert x == {1}

# Generated at 2022-06-23 17:31:13.101445
# Unit test for function register_no_map_class
def test_register_no_map_class():
    try:
        class Foo(list):
            pass
        # Trying to map function over type Foo
        register_no_map_class(Foo)
        # Creating foo instance
        foo = Foo([1, 2, 3])
        # Mapping function over foo
        result = map_structure(lambda x: x, [foo])
        # Checking result
        assert isinstance(result[0], Foo)
        assert result[0] == foo
    except Exception as e:
        print("Registration failed for class Foo: ", str(e))
        raise e
    else:
        print("Test passed!")
        return 0

if __name__ == "__main__":
    test_register_no_map_class()

# Generated at 2022-06-23 17:31:17.992015
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class CustomList(list):
        pass

    assert CustomList not in _NO_MAP_TYPES
    register_no_map_class(CustomList)
    assert CustomList in _NO_MAP_TYPES

# Generated at 2022-06-23 17:31:26.808477
# Unit test for function map_structure
def test_map_structure():
    a = {'a':1, 'b':2}
    b = {'b':3, 'c':4}
    c = {'d':5}
    d = map_structure(lambda a, b, c: a+b+c, [a, b, c])
    print(d)
    e = map_structure_zip(lambda a, b, c: a+b+c, [a, b, c])
    print(e)

if __name__ == '__main__':
    test_map_structure()

# Generated at 2022-06-23 17:31:32.268795
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class torch_size(object):
        def __init__(self, size):
            self.size = size
    register_no_map_class(torch_size)
    assert(torch_size in _NO_MAP_TYPES)


# Generated at 2022-06-23 17:31:35.365735
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 1, 'b': 2, 'c': 0}
    reverse_map(d)



# Generated at 2022-06-23 17:31:47.048159
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class A:
        def __init__(self, k):
            self.k = k
    register_no_map_class(A)
    a = A(1)
    b = A(2)

    def a_plus1(instance):
        return instance.k + 1
    def a_plus(instance1, instance2):
        return instance1.k + instance2.k

    a_plus1_a = map_structure(a_plus1, a)
    a_plus1_b = map_structure(a_plus1, b)
    a_plus1_a_b = map_structure_zip(a_plus, a,b)
    assert a_plus1_a.k == 2
    assert a_plus1_b.k == 3

# Generated at 2022-06-23 17:31:55.593913
# Unit test for function map_structure
def test_map_structure():
    a = {
        'a': [1, 2, 3],
        'b': [4, 5, 6],
        'c': {
            'a': 1,
            'b': 2,
            'c': [1, 2, 3, 4, 5]
        }
    }
    b = map_structure(lambda x: x + 2, a)
    print(b)
    assert b == {
        'a': [3, 4, 5],
        'b': [6, 7, 8],
        'c': {
            'a': 3,
            'b': 4,
            'c': [3, 4, 5, 6, 7]
        }
    }



# Generated at 2022-06-23 17:32:07.768634
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Test case with list
    f = lambda x, y: x + y
    x = [1, 2, 3, 4]
    y = [0]*4
    z = [2, 3, 4, 5]
    ans_list = map_structure_zip(f, [x, y, z])
    assert ans_list == [3, 5, 7, 9]

    # Test case with dictionary
    x = {"a": 1, "b": 2}
    y = {"a": [], "b": 0}
    z = {"a": 2, "b": 3}
    ans_dict = map_structure_zip(f, [x, y, z])
    assert ans_dict == {"a": 3, "b": 5}

    # Test case with tuple
    x = (1, 2, 3)
   

# Generated at 2022-06-23 17:32:12.056002
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'a': 0, 'b': 1, 'c': 2, 'd': 3}
    result = reverse_map(word_to_id)
    print (result)


test_reverse_map()

# Generated at 2022-06-23 17:32:23.817011
# Unit test for function reverse_map
def test_reverse_map():
    test_dict1 = {"a":1, "b":2, "c":3, "d":4, "e":5}
    test_dict2 = {"a":1, "b":2, "c":3, "d":4, "e":5, "f":1}
    test_dict3 = {"a":1, "b":2, "c":5, "d":4, "e":5, "f":1}
    res1 = ["a", "b", "c", "d", "e"]
    res2 = ["a", "b", "c", "d", "e", "f"]
    res3 = ["a", "b", "c", "d", "e", "f"]

    assert reverse_map(test_dict1) == res1

# Generated at 2022-06-23 17:32:35.898438
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from collections import defaultdict, namedtuple
    from torch.size import Size
    from torch import is_tensor

    register_no_map_class(Size)
    register_no_map_class(defaultdict)
    register_no_map_class(str)

    a = defaultdict(int, {'a': 1})
    a = map_structure(lambda x: x + 1, a)
    assert(a == defaultdict(int, {'a': 2}))
    a = defaultdict(int)
    a = no_map_instance(a)
    a = map_structure(lambda x: x + 1, a)
    assert(a == defaultdict(int))

    Point = namedtuple('Point', ('x', 'y'))
    p = Point(x=1, y=2)
    p

# Generated at 2022-06-23 17:32:38.619179
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    assert isinstance(a,list)
    assert hasattr(a, _NO_MAP_INSTANCE_ATTR)

if __name__ == "__main__":
    test_no_map_instance()

# Generated at 2022-06-23 17:32:49.151109
# Unit test for function no_map_instance
def test_no_map_instance():
    list_instance = no_map_instance([1, 2, 3])
    dict_instance = no_map_instance({"a": 1, "b": 2})
    import torch
    torch_tensor_instance = no_map_instance(torch.tensor([1]))
    assert hasattr(list_instance, _NO_MAP_INSTANCE_ATTR)
    assert hasattr(dict_instance, _NO_MAP_INSTANCE_ATTR)
    assert hasattr(torch_tensor_instance, _NO_MAP_INSTANCE_ATTR)
    assert isinstance(list_instance, list)
    assert isinstance(dict_instance, dict)
    assert isinstance(torch_tensor_instance, torch.Tensor)
    assert list_instance == [1, 2, 3]

# Generated at 2022-06-23 17:32:55.853779
# Unit test for function map_structure_zip
def test_map_structure_zip():
    xs = [1,2,3,4]
    ys = [5,6,7,8]
    zs = [9,10,11,12]
    def my_fn_1(x, y, z):
        return x + y + z
    sum_of_elements = map_structure_zip(my_fn_1, [xs, ys, zs])
    print(sum_of_elements)


# Generated at 2022-06-23 17:33:02.278861
# Unit test for function map_structure
def test_map_structure():
    a = [1,2,4]
    b = ['a','b','c']
    c = [1,2,3]
    aa = [a,b,c]
    def sum_list(list1, list2, list3):
        return [x+y+z for x,y,z in zip(list1,list2,list3)]
    print(map_structure_zip(sum_list,aa))

# Generated at 2022-06-23 17:33:09.068418
# Unit test for function reverse_map
def test_reverse_map():
    class Map:
        def __init__(self, m):
            self.m = m
        def __str__(self):
            string = ''
            for i in self.m:
                string += '{}: {}\n'.format(i, self.m[i])
            return string

    a = {'a': 6, 'b': 9, 'c': 12}
    b = Map(a)

    assert reverse_map(a) == ['b', 'c', 'a']
    assert reverse_map(b.m) == ['b', 'c', 'a']


# Generated at 2022-06-23 17:33:18.388746
# Unit test for function map_structure
def test_map_structure():
    class Node:
        def __init__(self, data, children=None):
            self.data = data
            self.children = children if children is not None else []

        def __eq__(self, other):
            return self.data == other.data and self.children == other.children

        def __repr__(self):
            return "Node({0.data}, {0.children})".format(self)

    node = Node(1, [Node(2, [Node(3), Node(4)]), Node(5)])
    node_copy = map_structure(lambda x: x, node)
    assert node == node_copy
    multi_node = (node, node, node)

    node_copy2 = map_structure(lambda x: x, multi_node)
    assert node_copy == node_copy2



# Generated at 2022-06-23 17:33:24.714048
# Unit test for function reverse_map
def test_reverse_map():
    d1 = {1:"a", 3:"b", 5:"c"}
    assert reverse_map(d1) == [1,3,5]

    d2 = {2:"a", 4:"b", 6:"c"}
    assert reverse_map(d2) == [2,4,6]


# Generated at 2022-06-23 17:33:33.318698
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # NoMapPyTorch
    class NoMapTensor(torch.Tensor):
        def __init__(self, *args, **kwargs):
            super(NoMapTensor, self).__init__(*args, **kwargs)
            self.__class__ = type(
                'NoMap{}'.format(self.__class__.__name__),
                (NoMapTensor, self.__class__),
                {},  # empty subclass namespace
            )

    register_no_map_class(NoMapTensor)
    t = NoMapTensor([1, 2, 3, 4])
    assert map_structure(lambda x: x.detach().numpy(), t) == t.detach().numpy()

    # NoMapMxNet

# Generated at 2022-06-23 17:33:44.705777
# Unit test for function no_map_instance
def test_no_map_instance():
    # no_map_instance(instance: T) -> T
    # Register a container instance as `non-mappable`, i.e., it will be treated as a singleton object in
    # :func:`map_structure` and :func:`map_structure_zip`, its contents will not be traversed.
    #
    # :param instance: The container instance.
    x = torch.Size([1, 2, 3])
    new_x = no_map_instance(x)
    # Check x and new_x are identical
    assert new_x == x
    # Check x and new_x are different instances
    assert new_x is not x
    # Check type of new_x is same as x
    assert type(new_x) is type(x)



# Generated at 2022-06-23 17:33:54.914153
# Unit test for function map_structure
def test_map_structure():
    dict1 = {'a': 1, 'b': [1, 2, 3], 'c': [1, 2, 3]}
    dict2 = {'a': 2, 'b': [4, 5, 6], 'c': [4, 5, 6]}
    dict3 = {'a': 3, 'b': [7, 8, 9], 'c': [7, 8, 9]}

    dicts = [dict1, dict2, dict3]

    def f1(x):
        return x + 1

    def f2(x, y):
        return x + y

    print(map_structure(f1, dict1))
    print(map_structure(f2, dicts[0], dicts[1]))
    print(map_structure_zip(f2, dicts))

# test_map_

# Generated at 2022-06-23 17:33:57.785826
# Unit test for function map_structure_zip
def test_map_structure_zip():
    t= {'a':1,'b':2}
    t1= {'a':2,'b':4}
    assert map_structure_zip(lambda a,b:a+b, [t,t1]) == {'a':3,'b':6}

# Generated at 2022-06-23 17:34:05.160668
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x + 1, [[1, 2], [3, 4]]) == [[2, 3], [4, 5]]
    assert map_structure(lambda x: x + 1, [[[1, 2], [3, 4]], [[5, 6], [7, 8]]]) == [[[2, 3], [4, 5]], [[6, 7], [8, 9]]]
    assert map_structure(lambda x: x + 1, ((1, 2), (3, 4))) == ((2, 3), (4, 5))
    assert map_structure(lambda x: x + 1, (1, 2)) == (2, 3)
    assert map_structure(lambda x: x + 1, {1: 1, 2: 2}) == {1: 2, 2: 3}


# Generated at 2022-06-23 17:34:15.176439
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def add_(x, y, z):
        return x + y + z
    x = [[1, 2], [3, 4]]
    y = [[5, 6], [7, 8]]
    z = [[9, 10], [11, 12]]
    print(map_structure_zip(add_, [x, y, z]))
    # >>> [[15, 18, 21], [24, 27, 30]]

    x = (1, 2, 3)
    y = (4, 5, 6)
    z = (7, 8, 9)
    print(map_structure_zip(add_, [x, y, z]))
    # >>> (12, 15, 18)

    x = {'a': 1, 'b': 2}
    y = {'a': 3, 'b': 4}
    z

# Generated at 2022-06-23 17:34:21.025126
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import numpy as np
    def sum(a, b):
        return {
            'a': a['a']+b['a'],
            'b': a['b']+b['b'],
            'c': np.stack([a['c'], b['c']]),
        }
    c1 = {'a': 1, 'b': 2, 'c': np.array(1)}
    c2 = {'a': 2, 'b': 3, 'c': np.array(2)}
    c_seq = map_structure_zip(sum, [c1, c2])
    assert isinstance(c_seq, dict)
    assert 'a' in c_seq
    assert 'b' in c_seq
    assert 'c' in c_seq

# Generated at 2022-06-23 17:34:29.890016
# Unit test for function no_map_instance
def test_no_map_instance():
    class Foo():
        def __init__(self):
            pass

    # Check raise exception
    try:
        no_map_instance(Foo())
        raise Exception("no_map_instance should raise exception")
    except:
        pass

    # Check set attribute
    class Foo2():
        def __init__(self):
            pass

        def __setattr__(self, name, value):
            raise Exception("no_map_instance should raise exception")

    no_map_instance(Foo2())

# Generated at 2022-06-23 17:34:40.722425
# Unit test for function no_map_instance
def test_no_map_instance():

    def test(obj):
        obj = no_map_instance(obj)
        assert hasattr(obj, _NO_MAP_INSTANCE_ATTR)

        class SubContainer(type(obj)):
            pass

        sub_obj = SubContainer(obj)
        assert hasattr(sub_obj, _NO_MAP_INSTANCE_ATTR)

        with pytest.raises(AttributeError):
            setattr(obj, _NO_MAP_INSTANCE_ATTR, False)

        sub_obj = no_map_instance(sub_obj)
        assert hasattr(sub_obj, _NO_MAP_INSTANCE_ATTR)

        with pytest.raises(AttributeError):
            setattr(sub_obj, _NO_MAP_INSTANCE_ATTR, False)

    test([])
    test(set())
   

# Generated at 2022-06-23 17:34:53.533517
# Unit test for function map_structure
def test_map_structure():
    a = {
        "a": 1,
        "b": [2, 3, {"c": 4}, ["e", "f", ["g", "h"]]],
        "d": {"e": 5, "f": 6}
    }
    b = {
        "a": 2,
        "b": [3, 4, {"c": 5}, ["g", "h", ["i", "j"]]],
        "d": {"e": 6, "f": 7}
    }

    def test_fn(x):
        return x ** 2

    def test_zip_fn(x, y):
        return x ** y

    c = map_structure(test_fn, a)
    d = map_structure_zip(test_zip_fn, [a, b])


# Generated at 2022-06-23 17:34:57.444412
# Unit test for function no_map_instance
def test_no_map_instance():
    x = no_map_instance(5)
    assert hasattr(x, _NO_MAP_INSTANCE_ATTR)
    assert x == 5

# Generated at 2022-06-23 17:35:06.241609
# Unit test for function reverse_map
def test_reverse_map():
    # When reverse_map() is called with a empty dictionary
    # Then return a empty array
    assert reverse_map({}) == []

    # When reverse_map() is called with a dictionary
    # Then return a array
    assert reverse_map({1: 2}) == [1]
    assert reverse_map({2: 1}) == [2]
    assert reverse_map({1: 1}) == [1]
    assert reverse_map({1: 0}) == [1]
    assert reverse_map({1: 2, 4: 1}) == [1, 4]
    assert reverse_map({1: 0, 4: 1}) == [1, 4]
    assert reverse_map({1: 0, 2: 1, 5: 2, 4: 3}) == [1, 2, 5, 4]

# Generated at 2022-06-23 17:35:15.158008
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Map a function over tuples formed by taking one elements from each (possibly nested) collection. Each collection
    # must have identical structures.
    #
    # .. note::
    #     Although identical structures are required, it is not enforced by assertions. The structure of the first
    #     collection is assumed to be the structure for all collections.

    # Test map_structure_zip
    def fn(a: int, b: int) -> int:
        return a + b

    a = [[1,2], [3,4]]
    b = [[5,6], [7,8]]
    l = map_structure_zip(fn, [a,b])
    # [[6, 8], [10, 12]]
    print("map_structure_zip: ", l)

    # zip()
    # The zip() function takes iterables (can

# Generated at 2022-06-23 17:35:18.928165
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    register_no_map_class(torch.Size)
    pytest.approx(map_structure(lambda x: x + 1, torch.Size((2, 3))), (3, 4))



# Generated at 2022-06-23 17:35:23.560360
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'a': 0, 'b': 1,'c': 2}
    id_to_word = reverse_map(word_to_id)
    print(id_to_word)


# Generated at 2022-06-23 17:35:29.520426
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1,2,3,4]
    b = [5,6,7,8]
    c = [9,10,11,12]
    d = []
    for x in map_structure_zip(lambda x, y, z: x+y+z, [a,b,c]):
        d.append(x)
    assert d == [15,18,21,24]

    a = [1,2,[3,4],5]
    b = [6,7,8,9]
    c = []
    for x in map_structure_zip(lambda x, y: [x,y], [a,b]):
        c.append(x)
    assert c == [[1,6],[2,7],[3,4,8],5,9]


# Generated at 2022-06-23 17:35:35.465829
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 0, 'b': 0, 'c': 0, 'd': 1, 'e': 1, 'f': 1, 'g': 2, 'h': 3}
    output = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
    assert reverse_map(d) == output

test_reverse_map()

# Generated at 2022-06-23 17:35:41.509310
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {
        "the": 0,
        "he": 1,
        "a": 2,
        "had": 3,
        "was": 4,
        "to": 5,
        "in": 6}

    id_to_word = reverse_map(word_to_id)

    for i in range(7):
        assert id_to_word[word_to_id[id_to_word[i]]] == i


# Generated at 2022-06-23 17:35:52.553397
# Unit test for function map_structure
def test_map_structure():
  from collections import OrderedDict
  import torch
  import torch.nn
  import torch.nn.functional as F

  append_a = lambda x: x+'_a'
  append_b = lambda x: x+'_b'
  append_c = lambda x: x+'_c'

  input_dict = OrderedDict([
    ("A", torch.randn(10, 10)),
    ("B", torch.randn(10, 10)),
    ("C", torch.randn(10, 10)),
    ("D", torch.randn(10, 10)),
  ])

  print(input_dict)
  print(dict(map_structure(append_a, input_dict)))
  print(dict(map_structure(append_b, input_dict)))

# Generated at 2022-06-23 17:35:56.400240
# Unit test for function no_map_instance
def test_no_map_instance():
    assert map_structure(lambda x: x, no_map_instance(["a", "b"])) == ["a", "b"]

# Generated at 2022-06-23 17:36:07.588580
# Unit test for function map_structure
def test_map_structure():
    """
    Unit test for function map_structure
    """
    test_tuple = ((("field_0", "field_1"), ("field_2", "field_3")),)
    test_result = ((("field_0", "field_1"), ("field_2", "field_3")),)
    result = map_structure(lambda x: x, test_tuple)
    assert(result == test_result)

    test_tuple = ((("field_0",), ("field_1", "field_2")),)
    test_result = ((("field_0",), ("field_1", "field_2")),)
    result = map_structure(lambda x: x, test_tuple)
    assert(result == test_result)


# Generated at 2022-06-23 17:36:18.450188
# Unit test for function map_structure
def test_map_structure():
    import random

    x = [random.random() for _ in range(100)]
    y = map_structure(lambda x: x + 1, x)
    assert x == [t - 1 for t in y]
    y = map_structure(lambda x: x * 2, x)
    assert x == [t / 2 for t in y]

    x = [random.random() for _ in range(100)]
    y = [random.random() for _ in range(100)]
    z = map_structure_zip(lambda x, y: x * y, [x, y])

    assert len(z) == len(x)
    assert len(z) == len(y)
    for i in range(len(x)):
        assert x[i] * y[i] == z[i]


# Generated at 2022-06-23 17:36:25.625628
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class A(list): pass
    a = A([1, 2])
    b = A([3, 4])

    register_no_map_class(A)
    assert map_structure(lambda x: x + 5, a) == A([6, 7])
    assert map_structure_zip(lambda x, y: x + y, [a, b]) == A([4, 6])

# Generated at 2022-06-23 17:36:32.722705
# Unit test for function map_structure_zip
def test_map_structure_zip():
    test_tuple = ("a", "b", "c", "d", "e", "f")
    test_list = ["g", "h", "i", "j", "k", "l"]
    test_dict = {"1": "m", "2": "n", "3": "o", "4": "p", "5": "q", "6": "r"}
    test_set = {"s", "t", "u", "v", "w", "x"}

    def fn(x, y, z, i, j, k):
        test_list.extend([i, j, k])
        return x + y + z

    test_type_collection = (test_tuple, test_list, test_dict, test_set)

# Generated at 2022-06-23 17:36:43.770078
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import numpy as np
    from collections import OrderedDict

    l1 = [1,2,3]
    l2 = [4,5,6]
    l3 = [7,8,9]

    l4 = [1,2,3]
    l5 = [4,5,6]
    l6 = [7,8,9]

    l7 = [1,2,3]
    l8 = [4,5,6]
    l9 = [7,8,9]

    l10 = [1,2,3]
    l11 = [4,5,6]
    l12 = [7,8,9]

    l13 = [1,2,3]
    l14 = [4,5,6]
    l15 = [7,8,9]

    l16

# Generated at 2022-06-23 17:36:53.535701
# Unit test for function map_structure
def test_map_structure():
    def test_map(fn, obj):
        obj_ = fn(obj)
        obj_map = map_structure(fn, obj)
        assert obj_map == obj_
        print(obj_map)

    print('\npass test only with dict, list, tuple and int:')
    test_map(lambda x: [x] if isinstance(x, int) else [], [1, 2, [3, 4, [5, 6]], 7, 8])
    test_map(lambda x: [x] if isinstance(x, int) else [], {1:0, 2:1})
    test_map(lambda x: [x] if isinstance(x, int) else [], (1, 2, (3, 4, (5, 6)), 7, 8))

# Generated at 2022-06-23 17:36:56.847408
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    assert hasattr(a, _NO_MAP_INSTANCE_ATTR)



# Generated at 2022-06-23 17:37:05.949784
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class MySize(torch.Size):
        def __init__(self, x):
            super(MySize, self).__init__(x)

    a = MySize((1, 2))
    b = MySize((1, 2, 3))
    c = MySize((1, 1))

    register_no_map_class(torch.Size)

    assert map_structure(lambda x: x * 2, a) == a
    assert map_structure(lambda x, y: x + y, a, b) == a + b
    assert map_structure(lambda x, y, z: x + y + z, a, b, c) == a + b + c

# Generated at 2022-06-23 17:37:13.125228
# Unit test for function map_structure
def test_map_structure():
    l = [[1, 2], [3, 4], [5, 6]]
    t = [(1, 2), (3, 4), (5, 6)]
    assert map_structure(lambda x: x + 1, l) == [[2, 3], [4, 5], [6, 7]]
    assert map_structure(lambda x, y: x + y, (l, l)) == [[2, 4], [6, 8], [10, 12]]
    assert map_structure(lambda x: x + 1, t) == [(2, 3), (4, 5), (6, 7)]
    assert map_structure(lambda x, y: x + y, (t, t)) == [(2, 4), (6, 8), (10, 12)]

# Generated at 2022-06-23 17:37:16.721323
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'a': 1, 'b': 2, 'c': 3}
    print(reverse_map(word_to_id))



# Generated at 2022-06-23 17:37:21.164947
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from typeguard import typechecked

    @typechecked
    def adder(a: int, b: int) -> int:
        return a + b

    class A:
        pass

    # A is not a container type
    assert not isinstance(A, type(map))

    register_no_map_class(A)

    assert A in _NO_MAP_TYPES

    structure_A = (1, 2, A(), 3)

    assert map_structure(adder, structure_A) == (3, 5, A(), 7)


if __name__ == "__main__":
    test_register_no_map_class()