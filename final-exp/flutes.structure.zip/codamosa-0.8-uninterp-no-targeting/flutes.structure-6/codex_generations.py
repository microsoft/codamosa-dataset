

# Generated at 2022-06-21 12:07:02.778897
# Unit test for function map_structure_zip
def test_map_structure_zip():
    ############ test map_structure_zip ############
    dict_1 = {'a': 1, 'b':2, 'c': 3}
    dict_2 = {'a': 4, 'c': 5, 'b': 2}
    assert(map_structure_zip(lambda d1, d2: d1+d2, [dict_1, dict_2]) == {'a': 5, 'b': 4, 'c': 8})
    # list
    list_1 = [1, 2, 3]
    list_2 = [4, 5, 6]
    assert(map_structure_zip(lambda l1, l2: l1 + l2, [list_1, list_2]) == [5, 7, 9])
    # tuple
    tuple_1 = (1, 2, 3)
    tuple

# Generated at 2022-06-21 12:07:12.885682
# Unit test for function map_structure
def test_map_structure():
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    a_ = map_structure(sum, [a, b, c])
    assert a_ == [12, 15, 18]

    b = [a, b, c]
    b_ = map_structure(sum, b)
    assert b_ == [[12, 15, 18]]

    c = [a, b]
    c_ = map_structure(map_structure, c)
    assert c_ == [[[1, 2, 3]], [[4, 5, 6], [7, 8, 9]]]

    d = {'1': a, '2': b}
    d_ = map_structure(map_structure, d)

# Generated at 2022-06-21 12:07:22.557774
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Fixture to create an example list of lists
    # Example [[1,2],[3,4],[5,6]]
    def create_list(n, m):
        list_of_list = []
        for i in range(n):
            list_ = []
            for j in range(m):
                list_.append(j+i*m+1)
            list_of_list.append(list_)
        return list_of_list

    # Fixture to create an example list of tuples
    # Example [((1,2),(3,4),(5,6))]
    def create_tuple(n, m):
        list_of_tuple = []
        for i in range(m):
            tuple_ = ()

# Generated at 2022-06-21 12:07:24.774197
# Unit test for function no_map_instance
def test_no_map_instance():
    instance = no_map_instance([1,2,3])
    assert instance == [1,2,3]
    assert hasattr(instance, _NO_MAP_INSTANCE_ATTR)


# Generated at 2022-06-21 12:07:37.049883
# Unit test for function reverse_map

# Generated at 2022-06-21 12:07:41.070572
# Unit test for function reverse_map
def test_reverse_map():
    import numpy as np

# Generated at 2022-06-21 12:07:46.051260
# Unit test for function reverse_map
def test_reverse_map():
    # Test 1
    words = ['a', 'aardvark', 'abandon', 'abandoned']
    d1 = {word: idx for idx, word in enumerate(words)}
    r1 = reverse_map(d1)
    w1 = words == r1
    print('Test 1: ', w1)

    # Test 2
    words = ['a', 'bb', 'ccc', 'dddd']
    d2 = {word: idx for idx, word in enumerate(words)}
    r2 = reverse_map(d2)
    w2 = words == r2
    print('Test 2: ', w2)

    # Test 3

# Generated at 2022-06-21 12:07:56.476577
# Unit test for function no_map_instance
def test_no_map_instance():
    lst = [1, 2, 3]
    nested_lst = [lst, lst]
    no_map_lst = no_map_instance(lst)
    no_map_nested_lst = no_map_instance(nested_lst)

    def fn(lst):
        lst.append(4)
        return lst
    ret1 = map_structure(fn, lst)
    no_map_ret1 = map_structure(fn, no_map_lst)
    assert ret1 == [1, 2, 3, 4]
    assert no_map_ret1 == [1, 2, 3]

    ret2 = map_structure(fn, nested_lst)

# Generated at 2022-06-21 12:08:02.010008
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from .utils import Size
    # Size is not a mappable class.
    assert Size not in _NO_MAP_TYPES
    # Add Size to the mappable class.
    register_no_map_class(Size)
    assert Size in _NO_MAP_TYPES


# Generated at 2022-06-21 12:08:10.640028
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Test 1: map over list
    def fn(x, y):
        return (x, y)

    x = [1, 2, 3]
    y = [4, 5, 6]
    z = [7, 8, 9]
    r = map_structure_zip(fn, [x, y, z])
    assert type(r) == list
    assert r[0] == (1, 4, 7)
    assert r[1] == (2, 5, 8)
    assert r[2] == (3, 6, 9)

    # Test 2: map over dictionary
    def fn(x):
        return x * x

    x = {'a': 1, 'b': 2, 'c': 3}
    y = {'a': 2, 'b': 3, 'c': 4}

# Generated at 2022-06-21 12:08:18.965824
# Unit test for function reverse_map
def test_reverse_map():
    length = 4
    words = ['a', 'aardvark', 'abandon', 'abandoned']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word


# Generated at 2022-06-21 12:08:29.848094
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert map_structure_zip(lambda xs: xs, [['a', 'b', 'c'], [1, 2, 3]]) == [('a', 1), ('b', 2), ('c', 3)]
    assert map_structure_zip(lambda xs: xs, [['a', 'b', 'c'], [1, 2, 3]])[0] == ('a', 1)
    assert map_structure_zip(lambda xs: xs, [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == {'a': (1, 3), 'b': (2, 4)}
    assert map_structure_zip(lambda xs: xs, [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}])['a']

# Generated at 2022-06-21 12:08:39.981110
# Unit test for function no_map_instance
def test_no_map_instance():
    class obj:
        def __init__(self, x):
            self.x = x
    
    def f(x):
        return x
    m = obj(5)
    #test the case of non-basic types
    assert(no_map_instance(m) == m)
    #test case of lists
    a = [1,2,3]
    b = map_structure(f, a)
    assert(a == b)
    a = no_map_instance([1,2,3])
    b = map_structure(f,a)
    assert(a == b)
    #test case of sets
    a = set([1,2,3,4])
    b = map_structure(f, a)
    assert(a == b)

# Generated at 2022-06-21 12:08:47.750917
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Case 1: the structures of input sequences are not the same
    obj = [{2: 3, 5: 6, 7: 8}, {2: 3, 5: 6, 7: 8}]
    objs = [obj, [2, 3, 4, 5]]
    # fn = lambda x, y, z: 2 * x + 3 * y + 4 * z
    with pytest.raises(ValueError):
        map_structure_zip(None, objs)

    # Case 2: input sequences have the same structure
    obj = [{2: 3, 5: 6, 7: 8}, {2: 3, 5: 6, 7: 8}]
    objs = [obj, obj]
    # fn = lambda x, y, z: 2 * x + 3 * y + 4 * z
    # expected_output: [[2,

# Generated at 2022-06-21 12:08:58.967585
# Unit test for function no_map_instance
def test_no_map_instance():
    """
    This unit test first creates a list of tensors, which is then converted into a list of
    no_map_instance()'s, in order to test the mapping features.
    """

    original_list = [torch.tensor([1.0]), torch.tensor([2.0])]
    expected_list = [torch.tensor([1.0]), torch.tensor([2.0])]

    nmi_list = [no_map_instance(t) for t in original_list]

    def test_fn(t):
        return 2.0 * t

    mapped_nmi_list = map_structure(test_fn, nmi_list)

    assert mapped_nmi_list == [torch.tensor([2.0]), torch.tensor([4.0])]
    assert mapped_n

# Generated at 2022-06-21 12:09:11.584226
# Unit test for function map_structure
def test_map_structure():
    a = no_map_instance((torch.tensor([1, 2, 3, 4]), torch.tensor([5, 6, 7, 8])))
    b = [torch.tensor([1, 2, 3, 4]), torch.tensor([5, 6, 7, 8])]
    c = (torch.tensor([1, 2, 3, 4]), torch.tensor([5, 6, 7, 8]))
    for obj in a, b, c:
        for i in range(3):
            obj = no_map_instance(obj)
        obj = map_structure(lambda x: x + x, obj)
        print(obj)
        for i in range(3):
            obj = no_map_instance(obj)

# Generated at 2022-06-21 12:09:16.094045
# Unit test for function reverse_map
def test_reverse_map():
    assert reverse_map({1: 2}) == [None, None]
    assert reverse_map({1: 0, 2: 1}) == [1, 2]
    assert reverse_map({0: 1, 2: 3}) == [None, 0, None, 2]


# Generated at 2022-06-21 12:09:20.490148
# Unit test for function no_map_instance
def test_no_map_instance():
    assert isinstance(no_map_instance([]), list)
    assert isinstance(no_map_instance([1]), list)
    assert isinstance(no_map_instance(OrderedDict()), OrderedDict)
    assert isinstance(no_map_instance(OrderedDict({"a": 2})), OrderedDict)



# Generated at 2022-06-21 12:09:29.446499
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch

    class MySize(torch.Size):
        pass

    my_size = MySize([1, 2])

    register_no_map_class(MySize)
    assert my_size == map_structure(lambda x: x + 1, my_size)

    register_no_map_class(type(my_size))
    assert my_size == map_structure(lambda x: x + 1, my_size)

    structure = ({my_size}, my_size, [my_size], (my_size,))
    assert structure == map_structure(lambda x: x + 1, structure)

# Generated at 2022-06-21 12:09:34.521180
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [[2], 3, {"4": [5, 6]}]
    b = [[7], 8, {"4": [9, 10]}]
    c = map_structure_zip(sum, [a, b])
    assert c == [[9], 11, {"4": [14, 16]}]

# Generated at 2022-06-21 12:09:45.848219
# Unit test for function no_map_instance
def test_no_map_instance():
    arr = numpy.arange(10)
    arr = no_map_instance(arr)

    def func(obj):
        return obj + 1

    result = map_structure(func, arr)

    assert_true(isinstance(arr, no_map_instance(numpy.ndarray)))
    assert_array_equal(result, arr + 1)

# Generated at 2022-06-21 12:09:57.707861
# Unit test for function map_structure
def test_map_structure():
    import numpy as np
    from PIL import Image

    ########## Scalar ##########
    # Built-in scalar
    assert map_structure(lambda x: x+1, 3) == 4
    assert map_structure(lambda x: x+1, np.array(3)) == 4

    # Custom scalar
    class Scalar:
        def __init__(self, x):
            self.x = x

        def __eq__(self, y):
            return self.x == y.x

        def __hash__(self):
            return hash(self.x)

        def __repr__(self):
            return "Scalar({})".format(self.x)
    assert map_structure(lambda x: x+1, Scalar(3)) == Scalar(4)
    assert map_

# Generated at 2022-06-21 12:10:06.850551
# Unit test for function register_no_map_class
def test_register_no_map_class():
    ex_0 = {'a': 1, 'b': 2}
    ex_1 = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]

    def fn_0(x):
        return x + 1

    def fn_1(x):
        return x * 2

    def fn_2(x, y):
        return x + y

    assert no_map_instance(ex_0) == ex_0
    assert no_map_instance(ex_1) == ex_1

    assert map_structure(fn_0, no_map_instance(ex_0)) == ex_0
    assert map_structure(fn_0, no_map_instance(ex_1)) == ex_1

# Generated at 2022-06-21 12:10:15.970938
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    import numpy
    register_no_map_class(torch.Size)
    register_no_map_class(numpy.array)

    class A(torch.Size):
        pass

    class B(numpy.array):
        pass

    a = A((1, 2))
    b = B([1, 2, 3])
    c = {'a': a, 'b': b}
    d = map_structure(lambda x: x, c)
    e = {'a': a, 'b': b}
    assert(d == e)

# Generated at 2022-06-21 12:10:24.899411
# Unit test for function reverse_map
def test_reverse_map():
    assert ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'] == reverse_map({'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5, 'g': 6, 'h': 7, 'i': 8, 'j': 9, 'k': 10, 'l': 11, 'm': 12, 'n': 13, 'o': 14, 'p': 15, 'q': 16, 'r': 17, 's': 18, 't': 19, 'u': 20, 'v': 21, 'w': 22, 'x': 23, 'y': 24, 'z': 25})



# Generated at 2022-06-21 12:10:27.144946
# Unit test for function register_no_map_class
def test_register_no_map_class():
    @register_no_map_class(list)
    def _():
        pass

    assert list in _NO_MAP_TYPES



# Generated at 2022-06-21 12:10:36.205321
# Unit test for function no_map_instance
def test_no_map_instance():
    import numpy as np
    from torch.utils.data import DataLoader
    from numpy import ndarray
    import torch
    class MLP(torch.nn.Module):
        def __init__(self, input_dim=1, hidden_dim=1, output_dim=1):
            super(MLP, self).__init__()
            self.hidden = torch.nn.Linear(input_dim, hidden_dim)
            self.predict = torch.nn.Linear(hidden_dim, output_dim)

        def forward(self, x):
            x = torch.nn.functional.relu(self. hidden(x))
            x = self.predict(x)
            return x


# Generated at 2022-06-21 12:10:41.747049
# Unit test for function reverse_map
def test_reverse_map():
    items = ['a', 'aardvark', 'abandon', 'abandonment', 'abc']
    d = {k: idx for idx, k in enumerate(items)}
    assert (reverse_map(d) == items)
    return


if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-21 12:10:46.352671
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from torch.Size import register_no_map_class
    from torch.Size import Size

    s = Size()
    s[2] = 1
    register_no_map_class(Size)
    assert(s.__class__ in _NO_MAP_TYPES)

# Generated at 2022-06-21 12:10:54.171742
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import namedtuple
    import torch

    tensor = torch.tensor([1, 2, 3])
    some_tensor = no_map_instance(tensor)
    assert torch.equal(tensor, some_tensor), "tensor and some_tensor should be equal"

    Tensor = namedtuple("Tensor", ["tensor"])
    tensor_container = Tensor(tensor)
    no_map_tensor_container = no_map_instance(tensor_container)
    assert torch.equal(tensor, no_map_tensor_container.tensor), \
        "no_map_tensor_container.tensor and tensor should be equal"

    no_map_some_tensor_container = no_map_instance(no_map_tensor_container)

# Generated at 2022-06-21 12:11:06.281716
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class TestClass:
        def __init__(self, x):
            self.x = x

    register_no_map_class(TestClass)
    assert TestClass in _NO_MAP_TYPES
    assert TestClass._no_map_type in _NO_MAP_TYPES


# Generated at 2022-06-21 12:11:16.749756
# Unit test for function map_structure
def test_map_structure():
    from collections import OrderedDict
    from nltk.tree import Tree
    def fn(x): return x + x
    # Both object and the return object are the same type
    assert map_structure(fn, 1) == 2
    assert map_structure(fn, "foo") == "foofoo"
    assert map_structure(fn, [1, 2, 3]) == [2, 4, 6]
    assert map_structure(fn, (1, 2, 3)) == (2, 4, 6)
    assert map_structure(fn, {"a": 1, "b": 2}) == {"a": 2, "b": 4}
    assert map_structure(fn, {"a": 1, "b": 2}.items()) == (("a", 2), ("b", 4))

# Generated at 2022-06-21 12:11:23.337825
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Foo(dict):
        pass

    register_no_map_class(Foo)
    foo = Foo(test=1)
    assert not hasattr(foo, _NO_MAP_INSTANCE_ATTR)
    assert foo.__class__ in _NO_MAP_TYPES
    assert no_map_instance(foo).__class__ not in _NO_MAP_TYPES
    assert hasattr(no_map_instance(foo), _NO_MAP_INSTANCE_ATTR)


# Generated at 2022-06-21 12:11:25.855797
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from torch import Size
    assert Size in _NO_MAP_TYPES, "The register_no_map_class may be not working as expected"


# Generated at 2022-06-21 12:11:29.365510
# Unit test for function map_structure_zip
def test_map_structure_zip():
    one = {"a": 1, "b": 2}
    two = {"a": 3, "b": 4}
    print(map_structure_zip(lambda x,y: x*y, [one, two]))
    return


# Generated at 2022-06-21 12:11:40.758882
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from collections import defaultdict
    from pytorch_transformers.modeling_utils import PreTrainedModel, BertLayerNorm
    # subclass torch.Size is not mappable in pytorch_transformers
    # TODO: fix this issue
    # register no_map class
    register_no_map_class(torch.Size)
    # test torch.Size
    test_input = torch.Size([1, 2])
    test_target = torch.Size([3, 4])
    # test func is an Abstract method, it should raise error
    with pytest.raises(NotImplementedError):
        map_structure(lambda x: x, test_input)
    # test func is an identity
    test_output = map_structure_zip(lambda x, y: x + y, [test_input, test_target])

# Generated at 2022-06-21 12:11:44.818283
# Unit test for function no_map_instance
def test_no_map_instance():
    import copy
    x = torch.randn(2)
    y = no_map_instance(x)
    copied = copy.deepcopy(y)
    assert y.tolist() == copied.tolist()
    assert y.tolist() == x.tolist()

# Generated at 2022-06-21 12:11:49.113018
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'b', 'c']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word


# Generated at 2022-06-21 12:11:57.161661
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # Test case: A dictionary that contains a torch.Size instance inside
    test_input = {
        'a': {
            'b': {
                'c': torch.Size([1, 2, 3])
            }
        }
    }

    # Test if a torch.Size instance is treated as a non-mappable object before registering
    with pytest.raises(AssertionError):
        assert map_structure(lambda x: torch.Size([0, 0]) if isinstance(x, torch.Size) else x, test_input) == {
            'a': {
                'b': {
                    'c': torch.Size([0, 0])
                }
            }
        }

    # Register torch.Size as a non-mappable object.
    register_no_map_class(torch.Size)

   

# Generated at 2022-06-21 12:12:00.327896
# Unit test for function reverse_map
def test_reverse_map():
    correct = ['idx2word']
    result = reverse_map({"idx2word":1})
    assert(correct == result)

# Generated at 2022-06-21 12:12:07.970434
# Unit test for function no_map_instance
def test_no_map_instance():
    assert(no_map_instance(torch.Size([1])).__class__.__name__ == '_no_mapSize')
    assert(no_map_instance(1) == 1)

# Generated at 2022-06-21 12:12:17.624248
# Unit test for function map_structure
def test_map_structure():
    import torch
    size = torch.Size([1,2,3])
    assert(map_structure(lambda a: a*2, size) == torch.Size([2,4,6]))

    tensor = torch.Tensor([1,2,3])
    assert(map_structure(lambda a: a*2, tensor) == torch.Tensor([2,4,6]))
    assert(map_structure(lambda a: len(a), tensor) == 3)

    list = [[1,2], [3,4], [5,6]]
    assert(map_structure(lambda a: a*2, list) == [[2,4], [6,8], [10,12]])

if __name__ == '__main__':
    test_map_structure()

# Generated at 2022-06-21 12:12:29.700066
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = dict(a={1,2,3},b={4,5,6},c={7,8,9})
    b = dict(a=1,b=2,c=3)
    c = dict(a =list([1,2,3]),b =list([4,5,6]),c =list([7,8,9]))
    d = dict(a =1,b =2,c =3)
    e = dict(a=dict(b=1,c=2,d=3),b=dict(b=4,c=5,d=6),c=dict(b=7,c=8,d=9))

# Generated at 2022-06-21 12:12:34.357458
# Unit test for function reverse_map
def test_reverse_map():
    dic = {'a': 1, 'b': 2, 'c': 3}
    l = reverse_map(dic)
    assert l==['a', 'b', 'c']


# Generated at 2022-06-21 12:12:40.498005
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Dict(dict):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    d = Dict()

    register_no_map_class(Dict)
    assert d.__class__ in _NO_MAP_TYPES
    assert not hasattr(d, _NO_MAP_INSTANCE_ATTR)

    registered_d = no_map_instance(d)
    assert registered_d.__class__ in _NO_MAP_TYPES
    assert hasattr(registered_d, _NO_MAP_INSTANCE_ATTR)

# Generated at 2022-06-21 12:12:49.325233
# Unit test for function no_map_instance
def test_no_map_instance():
    # test list
    example_list = no_map_instance([1,2,3])
    assert map_structure(lambda x: x+100, example_list) == example_list
    assert map_structure_zip(lambda x,y: x+y, [example_list, [10,10,10]]) == example_list
    # test tuple
    example_tuple = no_map_instance((1,2,3))
    assert map_structure(lambda x: x+100, example_tuple) == example_tuple
    assert map_structure_zip(lambda x,y: x+y, [example_tuple, [10,10,10]]) == example_tuple
    # test dict
    example_dict = no_map_instance({1:2, 3:4, 5:6})
   

# Generated at 2022-06-21 12:12:58.423449
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # test same input, same output
    def add(x1, x2, x3):
        return x1 + x2 + x3
    l1 = [1, 2, 3, 4]
    l2 = [1, 1, 1, 1]
    l3 = [1, 2, 3, 4]
    res = map_structure_zip(add, [l1, l2, l3])
    assert res == [3, 5, 7, 9]

    # test different input, all elements in different level, same output
    def add2(x, y, z):
        return x + y + z
    l1 = [1, 2, 3]
    l2 = [[1, 1, 1], [1, 1, 1], [1, 1, 1]]

# Generated at 2022-06-21 12:13:06.144992
# Unit test for function map_structure
def test_map_structure():
    a = [[1, 2, 3], [2, 3, 4]]
    result = map_structure(lambda x: x * 2, a)
    assert result == [[2, 4, 6], [4, 6, 8]]

    a = {'a': [1, 2, 3], 'b': [1, 2, 3]}
    fn = lambda x: [2*i for i in x]
    result = map_structure(fn, a)
    assert result == {'a': [2, 4, 6], 'b': [2, 4, 6]}

    a = {'a': [1, 2, 3], 'b': [1, 2, 3]}
    fn = lambda x: [2*i for i in x]
    result = map_structure_zip(fn, a)

# Generated at 2022-06-21 12:13:17.644660
# Unit test for function no_map_instance
def test_no_map_instance():
    instance = {'a': 1, 'b': 2}
    assert no_map_instance(instance) == {'a': 1, 'b': 2}

    lst = [1,2,3,4]
    assert no_map_instance(lst) == [1,2,3,4]

    dct = {'a': [1,2], 'b': {'a': 1}}
    assert no_map_instance(dct) == {'a': [1,2], 'b': {'a': 1}}

    st = {1,2,3}
    assert no_map_instance(st) == {1,2,3}

    tt = (1,2,3)
    assert no_map_instance(tt) == (1,2,3)


# Generated at 2022-06-21 12:13:24.443350
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def example_fn(a, b):
        return a + b
    # Testing with a list
    list_1 = [[1, 2, 3], [4, 5, 6]]
    list_2 = [[1, 2, 3], [4, 5, 6]]
    assert map_structure_zip(example_fn, [list_1, list_2]) == [[2, 4, 6], [8, 10, 12]]
    # Testing with a dict
    dict_1 = {'list': [[1, 2, 3], [4, 5, 6]], 'int': 100}
    dict_2 = {'list': [[1, 2, 3], [4, 5, 6]], 'int': 100}

# Generated at 2022-06-21 12:13:43.781416
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # edge case: only one obj in objs
    map_structure_zip(lambda x: x, [1])
    fn = lambda x, y: x + y
    objs = ([1, 2], [2, 3])
    assert(map_structure_zip(fn, objs) == [3, 5])
    objs = ([1, 2], [2, 3], [3, 4])
    assert(map_structure_zip(fn, objs) == [6, 9])
    objs = ([1, 2], [2, 3], {'a':3, 'b':4})
    assert(map_structure_zip(fn, objs) == {'a':6, 'b':9})
    # edge case: dict in objs

# Generated at 2022-06-21 12:13:50.005010
# Unit test for function map_structure_zip
def test_map_structure_zip():
    """
    Test map_structure_zip by creating and running a simple program.
    """

    arr1 = [1, 2, 3]
    arr2 = [4, 5, 6]
    arr3 = [7, 8, 9]
    c = map_structure_zip(lambda a, b, c: a + b + c, [arr1, arr2, arr3])
    assert(c == [12, 15, 18])

# Generated at 2022-06-21 12:14:01.851015
# Unit test for function map_structure_zip
def test_map_structure_zip():
    input_dict = {'a': {1: {'a': 1, 'b': 2}, 2: {'a': 3, 'b': 4}},
                                     'b': {1: {'a': 5, 'b': 6}, 2: {'a': 7, 'b': 8}}}
    output_dict = {'a': {1: {'a': 1, 'b': 4}, 2: {'a': 9, 'b': 16}},
                                      'b': {1: {'a': 25, 'b': 36}, 2: {'a': 49, 'b': 64}}}

    def test_fn(arg1, arg2):
        if isinstance(arg1, dict):
            assert isinstance(arg2, dict)
            out_dict = {}

# Generated at 2022-06-21 12:14:11.360925
# Unit test for function no_map_instance
def test_no_map_instance():
    from torch import Size, tensor

    A = [1, 2, 3, Size([10, 20, 30])]
    B = [tensor(a) for a in A]
    C = [a - 2 for a in A]
    D = [no_map_instance(a) for a in A]
    E = [tensor(a) for a in Size([10, 20, 30])]

    def _test_fn(a, b):
        return a + b

    def _test_error_fn(a, b):
        return a + int(b)

    expected_output = [tensor(3), tensor(4), tensor(5), Size([10, 20, 30])]
    assert list(map_structure(_test_fn, D, D)) == expected_output

# Generated at 2022-06-21 12:14:19.030868
# Unit test for function reverse_map
def test_reverse_map():
    assert ["a", "b", "c"] == reverse_map({
        "a": 0,
        "b": 1,
        "c": 2
    })
    assert ["a", "b", "c"] == reverse_map({
        "a": 1,
        "b": 2,
        "c": 0
    })
    assert ["a", "b", "c"] == reverse_map({
        "a": 2,
        "b": 0,
        "c": 1
    })
    assert ["aardvark", "a", "abandon"] == reverse_map({
        "aardvark": 0,
        "a": 1,
        "abandon": 2,
    })



# Generated at 2022-06-21 12:14:27.586780
# Unit test for function reverse_map
def test_reverse_map():
    # test reverse_map
    word_to_ix = {'a': 0, 'b': 1, 'apple': 18, 'pear': 19}
    ix_to_word = reverse_map(word_to_ix)
    assert ix_to_word[word_to_ix['a']] == 'a'
    assert ix_to_word[word_to_ix['apple']] == 'apple'
    assert ix_to_word[word_to_ix['pear']] == 'pear'

test_reverse_map()

# Generated at 2022-06-21 12:14:35.546664
# Unit test for function map_structure
def test_map_structure():
    x = [['a', 'b'], [[1, 2],['c', {'d': 1}]]]
    def fn(x):
        if isinstance(x, str):
            return '1'
        elif isinstance(x, int):
            return '2'
        return x
    x_new = map_structure(fn, x)
    print(x_new)
    assert x_new == [['1', '1'], [['2', '2'],['1', {'d': '2'}]]]


# Generated at 2022-06-21 12:14:42.933422
# Unit test for function map_structure_zip
def test_map_structure_zip():
    t1 = (1, 2, 3)
    t2 = (4, 5, 6)
    t3 = (7, 8, 9)
    inputs = (t1, t2, t3)
    def fn(*xs):
        return sum(xs)
    outputs = map_structure_zip(fn, inputs)
    assert outputs == (12, 15, 18)

    t1 = (1, 2, 3)
    t2 = (4, 5, 6)
    t3 = (7, 8, 9)
    inputs = (t1, t2, t3)
    def fn(*xs):
        return xs
    outputs = map_structure_zip(fn, inputs)
    assert outputs == ((1, 4, 7), (2, 5, 8), (3, 6, 9))


# Generated at 2022-06-21 12:14:53.063949
# Unit test for function map_structure
def test_map_structure():
    from itertools import groupby
    from operator import itemgetter
    import numpy as np

    def make_tree():
        return {
            'score': 0.1,
            'children': [
                {
                    'score': 0.2,
                    'children': [],
                    'properties': {'name': 'A'}
                },
                {
                    'score': 0.3,
                    'children': [
                        {
                            'score': 0.4,
                            'children': [],
                            'properties': {'name': 'B'}
                        },
                        {
                            'score': 0.5,
                            'children': [],
                            'properties': {'name': 'C'}
                        }
                    ]
                }
            ]
        }


# Generated at 2022-06-21 12:15:04.691239
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from collections import namedtuple
    from torch.nn import Module

    class Net(Module):
        def __init__(self):
            super(Net, self).__init__()
            self.namedtuple1 = namedtuple('Example_namedtuple1', ['x', 'y'])  # noqa
            self.namedtuple2 = namedtuple('Example_namedtuple2', ['x', 'y'])  # noqa
            self.a = 1
            self.b = [1, [2, [3, [4]]]]
            self.c = self.namedtuple1(0, 1)
            self.d = self.namedtuple2(0, 1)
            self.e = {0: ['e', 1]}
            self.f = (0, 1)

# Generated at 2022-06-21 12:15:21.368864
# Unit test for function map_structure
def test_map_structure():
    def test_func(a):
        return a * 2

    data = [1, 2, 3, "a", "b", {"c": 1, "d": 2}]
    obj = map_structure(test_func, data)
    assert len(obj) == len(data)
    for i in range(len(obj)):
        if isinstance(obj[i], int):
            assert obj[i] == data[i] * 2
        if isinstance(obj[i], str):
            assert obj[i] == data[i]
        if isinstance(obj[i], dict):
            for j in obj[i].keys():
                assert obj[i][j] == data[i][j]


# Generated at 2022-06-21 12:15:28.774591
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # basic test
    assert map_structure_zip(lambda a, b: a + b, [{"a": 1, "b": 3}, {"a": 2, "b": 4}]) == {"a": 3, "b": 7}

    # test for nested structure
    test_input = [
        [["a", {"b": 1}], [1, 2]],
        [["b", {"c": 2}], [3, 4]],
    ]
    test_output = ["a", {"b": 1, "c": 2}, 1, 2, "b", {"b": 1, "c": 2}, 3, 4]
    assert map_structure_zip(lambda *x: x, test_input) == test_output

    # test for sparse structure

# Generated at 2022-06-21 12:15:40.890304
# Unit test for function map_structure
def test_map_structure():
    import pprint

    # input_list and function:
    def func(obj):
        if isinstance(obj, int):
            return obj + 1
        if isinstance(obj, str):
            return obj + ','
        return obj

    input_list = [
        {
            'k1': 1,
            'k2': 'hello',
            'k3': [
                {1, 2, 3}
            ],
        },
        {
            'k1': 2,
            'k2': 'world',
            'k3': [
                set()
            ],
        }
    ]
    pprint.pprint(input_list)

    print(map_structure(func, input_list))
    print(map_structure_zip(lambda x, y: x + y, input_list))
   

# Generated at 2022-06-21 12:15:43.997385
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class test_list(list):
        pass
    register_no_map_class(test_list)
    assert test_list in _NO_MAP_TYPES


# Generated at 2022-06-21 12:15:54.564284
# Unit test for function reverse_map
def test_reverse_map():
    list1 = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    list2 = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    word_to_id = {word: idx for idx, word in enumerate(list1)}
    id_to_word = reverse_map(word_to_id)
    print(id_to_word)
    

# Generated at 2022-06-21 12:16:06.282726
# Unit test for function map_structure_zip

# Generated at 2022-06-21 12:16:12.468828
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class A(list):
        def __init__(self, seq):
            super().__init__(seq)
            self.seq = seq

        def __str__(self):
            return str(self.seq)
    reg = register_no_map_class(A)
    assert reg == None
    assert A in _NO_MAP_TYPES


# Generated at 2022-06-21 12:16:22.268373
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert([1,2,3] ==
    list(map_structure_zip(lambda x,y,z: x+y+z,[1,2,3],[10,20,30],[100,200,300])))

    assert([1,2,3] ==
    list(map_structure_zip(lambda x,y,z: x+y+z,(1,2,3),(10,20,30),(100,200,300))))

    assert((1,2,3) ==
    tuple(map_structure_zip(lambda x,y,z: x+y+z,[1,2,3],(10,20,30),(100,200,300))))


# Generated at 2022-06-21 12:16:32.662643
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert map_structure_zip(lambda *xs: xs, [[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == ((1, 4, 7), (2, 5, 8), (3, 6, 9))
    assert map_structure_zip(lambda *xs: xs, ([1, 2, 3], [4, 5, 6], [7, 8, 9])) == ((1, 4, 7), (2, 5, 8), (3, 6, 9))
    assert map_structure_zip(lambda *xs: xs, ((1, 2, 3), (4, 5, 6), (7, 8, 9))) == ((1, 4, 7), (2, 5, 8), (3, 6, 9))

# Generated at 2022-06-21 12:16:39.102992
# Unit test for function map_structure_zip
def test_map_structure_zip():
    ####################
    # simple use case
    A = namedtuple('A', ['a', 'b'])
    a = A(a=[1,2], b=[3,4])
    b = A(a=['a1', 'a2'], b=['b1', 'b2'])
    print(map_structure_zip(lambda x, y: x+y, (a, b)))
    ####################
    # nested use case
    B = namedtuple('B', ['a', 'b'])
    c = B(a=a, b=b)
    d = B(a=a, b=b)
    print(map_structure_zip(lambda x, y: x+y, (c, d)))
    ####################