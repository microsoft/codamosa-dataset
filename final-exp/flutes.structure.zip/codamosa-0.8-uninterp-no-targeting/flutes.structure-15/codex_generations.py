

# Generated at 2022-06-21 12:07:22.141002
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import OrderedDict
    from copy import deepcopy
    from dataclasses import dataclass
    from torch import Size

    @dataclass
    class NamedTupleLike:
        x: int

    @dataclass
    class Model(NamedTupleLike):
        y: int

    class MyDict(OrderedDict):
        pass
        
    d = dict(a=1, b=2)
    f = lambda x: 2*x

    result = no_map_instance(d)
    assert(result == d)
    assert(not isinstance(result, dict))
    assert(map_structure(f, d) == map_structure(f, result))

    result = no_map_instance([1, 2, 3])
    assert(result == [1, 2, 3])
   

# Generated at 2022-06-21 12:07:25.872182
# Unit test for function register_no_map_class
def test_register_no_map_class():
    tup = tuple()
    assert tup.__class__ in _NO_MAP_TYPES
    register_no_map_class(tuple)
    assert tup.__class__ in _NO_MAP_TYPES


# Generated at 2022-06-21 12:07:30.277717
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'abashed', 'abate', 'abbey', 'abbots', 'abbott', 'abbreviated', 'abbé']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert(words == id_to_word)


# Generated at 2022-06-21 12:07:36.585933
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    assert a == [1, 2, 3]
    b = no_map_instance({'a': 1, 'b': 2})
    assert b == {'a': 1, 'b': 2}
    map_structure(lambda x: x, [a])
    map_structure(lambda x: x, [b])

# Generated at 2022-06-21 12:07:41.832368
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'word1': 1, 'word2': 2, 'word3': 4}
    id_to_word = reverse_map(word_to_id)
    assert(id_to_word == ['word1', 'word2', 'word3'])

if __name__ == "__main__":
    test_reverse_map()

# Generated at 2022-06-21 12:07:46.738902
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class _MySubClassList(list):
        pass

    class _MySubClassDict(dict):
        pass

    def _convert_to_tuple(x):
        return tuple(x)

    register_no_map_class(_MySubClassList)
    register_no_map_class(_MySubClassDict)

    # Test list
    res = map_structure(_convert_to_tuple, [[[1, 2], [3, 4]], [[5, 6], [7, 8]]])
    assert res == ([(1, 3), (2, 4)], [(5, 7), (6, 8)])

    # Test dict
    my_dict = {'a': {'b': [1, 2]}, 'c': {'d': [3, 4]}}
    res = map_structure

# Generated at 2022-06-21 12:07:57.683974
# Unit test for function map_structure
def test_map_structure():
    from collections import namedtuple
    test_obj = ['a', ('b', 'c', ['d', 'e'], {'f':4} ), 3, ('g', 'h') ]
    test_nested_tuple = namedtuple('nested_tuple', ['a', 'b', 'c'])
    test_nested_list = [1, 2, 3, [4, 5, 6], 7, [8, 9, [10, 11]]]
    test_nested_dict = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': [['f', 4], 5]}

    def test_func(x):
        return x + 1
    
    test_obj_output = map_structure(test_func, test_obj) 

# Generated at 2022-06-21 12:08:06.836935
# Unit test for function map_structure_zip
def test_map_structure_zip():
    dict_a = {'c': 1, 'b': 2}
    dict_b = {'c': 4, 'b': 5}
    res = map_structure_zip(sum, [dict_a, dict_b])
    print(f'The result of map_structure_zip on dict_a and dict_b is {res}')

    list_a = [1, 2, 3]
    list_b = [4, 5, 6]
    res = map_structure_zip(sum, [list_a, list_b])
    print(f'The result of map_structure_zip on list_a and list_b is {res}')

if __name__ == '__main__':
    test_map_structure_zip()

# Generated at 2022-06-21 12:08:17.883861
# Unit test for function map_structure
def test_map_structure():
    # Map over a nested tuple
    nested_tuple = (1, (2, 3))
    assert(map_structure(lambda x: x + 1, nested_tuple) == (2, (3, 4)))

    # Map over a nested list
    nested_list = [1, [2, 3]]
    assert(map_structure(lambda x: x + 1, nested_list) == [2, [3, 4]])

    # Map over a nested dictionary
    nested_dictionary = {'a': 1, 'b': {'a': 1, 'b': 2}}
    assert(map_structure(lambda x: x + 1, nested_dictionary) == {'a': 2, 'b': {'a': 2, 'b': 3}})

    # Test that we can't map over a set
    nested_set

# Generated at 2022-06-21 12:08:24.004889
# Unit test for function map_structure
def test_map_structure():
    from collections import namedtuple
    import os
    print("Testing map_structure...")

    Shape = namedtuple("Shape", ["width", "height"])
    def double(x): return 2 * x

    @no_type_check
    class ArrayLike:
        def __init__(self, contents):
            self.contents = contents

    array_like = ArrayLike([3, 4])
    array_like2 = ArrayLike([5, 6, [7, 8], [{9: 10}]])
    assert map_structure(double, array_like) == ArrayLike([3, 4])

    nested_shape_list = [[Shape(2, 4), Shape(1, 2)], [Shape(6, 8)]]

# Generated at 2022-06-21 12:08:35.151626
# Unit test for function no_map_instance
def test_no_map_instance():
    @no_type_check
    def assert_list_equals(l1, l2):
        assert len(l1) == len(l2)
        for i in range(len(l1)):
            assert l1[i] == l2[i]

    def assert_no_map_instance_equals(l1, l2):
        assert_list_equals(l1, l2)
        assert l1 is not l2
        assert no_map_instance(l1) is not no_map_instance(l2)
        register_no_map_class(l1.__class__)
        assert map_structure(lambda x: 2*x, l1) == map_structure(lambda x: 2*x, l2)


# Generated at 2022-06-21 12:08:43.988755
# Unit test for function map_structure_zip
def test_map_structure_zip():
    class Point:
        def __init__(self, x, y):
            self.x = x
            self.y = y

        def __repr__(self):
            return f'Point({self.x}, {self.y})'

    def add_pair(p1: Point, p2: Point) -> Point:
        return Point(p1.x + p2.x, p1.y + p2.y)

    def test(s):
        s = eval(s)
        mapped = map_structure_zip(add_pair, [s, s])
        print(mapped)

    test("Point(1, 2)")
    test("Point(Point(1, 2), Point(3, 4))")
    test("[[1, 2], [3, 4]]")

# Generated at 2022-06-21 12:08:55.722881
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from tqdm.auto import tqdm
    from torch import randn, randint, rand
    a = randn(1, 1, 100, 100)
    b = randint(0, 3, (1, 1, 100, 100))
    c = rand(1)

    result_list = []
    for i, j, k in zip(tqdm(a, desc="a"), tqdm(b, desc="b"), tqdm(c, desc="c")):
        result_list.append((i, j, k))

    iterable_tuple = (tqdm(a, desc="a"), tqdm(b, desc="b"), tqdm(c, desc="c"))
    result_structure_zip = map_structure_zip(lambda *x: tuple(x), iterable_tuple)



# Generated at 2022-06-21 12:09:03.191121
# Unit test for function map_structure_zip
def test_map_structure_zip():
    class Foo:
        def __init__(self, a, b):
            self.a = a
            self.b = b
    
    def test_fn(x, y, z):
        return x + y + z

    x = [0, 1, 2]
    y = Foo(1, 2)
    z = {'a':0, 'b':1}

    result = map_structure_zip(test_fn, [x, y, z])
    assert result == [1, 5, 3]

# Generated at 2022-06-21 12:09:15.641738
# Unit test for function map_structure
def test_map_structure():
    import torch

    a = [torch.randn(5), torch.randn(3, 4)]
    b = [torch.randint(0, 7, (5,)).tolist(), torch.randint(0, 7, (3, 4)).tolist()]

    c = map_structure(lambda _a, _b: _a + _b, [a, b])
    assert c[0] == [_a + _b for _a, _b in zip(a[0], b[0])]
    assert c[1] == [_a + _b for _a, _b in zip(a[1].view(-1).tolist(), b[1].view(-1).tolist())] # flatten, add one by one, reshape



# Generated at 2022-06-21 12:09:23.380426
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = [1.1, 2.2, 3.3]
    c = ["ab", "cd", "ef"]
    d = {'a': 1, 'b': 2, 'c': 3}
    def f(x, y):
        return x + y
    def g(x, y):
        return x * y
    def h(x, y):
        return x + "_" + y
    def i(x, y):
        return x + y
    a_zip = map_structure_zip(f, [a, b])
    print("a_zip", a_zip)
    assert a_zip == [2.1, 4.2, 6.3]
    b_zip = map_structure_zip(g, [a, b])

# Generated at 2022-06-21 12:09:34.806699
# Unit test for function reverse_map

# Generated at 2022-06-21 12:09:37.720870
# Unit test for function no_map_instance
def test_no_map_instance():
    not_mappable_list= no_map_instance([1,2,3])
    assert map_structure(lambda x: x, not_mappable_list) == [1,2,3]

# Generated at 2022-06-21 12:09:41.540747
# Unit test for function reverse_map
def test_reverse_map():
    test_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    result_list = reverse_map(test_dict)
    assert result_list == list('abcd'), "wrong reverse map result"

# Generated at 2022-06-21 12:09:49.437628
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from .typing import Scaling

    register_no_map_class(Scaling)
    try:
        import torch
        assert map_structure(torch.size, [[Scaling.NO, Scaling.NO], [Scaling.NO, Scaling.NO]]) == torch.Size([2, 2])
    except ImportError:
        assert map_structure(list, [[Scaling.NO, Scaling.NO], [Scaling.NO, Scaling.NO]]) == [[2, 2]]

# Generated at 2022-06-21 12:09:55.393584
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch

    register_no_map_class(torch.Size)

    assert map_structure(lambda x: x, torch.Size((1, 2, 3))) == torch.Size((1, 2, 3))

# Generated at 2022-06-21 12:10:05.262381
# Unit test for function map_structure
def test_map_structure():
    import jiant.utils.display as display

    def check_map_structure(unmapped_obj, expected_mapped_obj):
        actual_mapped_obj = map_structure(lambda x: x + x, unmapped_obj)
        display.display_json({
            "unmapped_obj": unmapped_obj,
            "expected_mapped_obj": expected_mapped_obj,
            "actual_mapped_obj": actual_mapped_obj,
        })
        assert actual_mapped_obj == expected_mapped_obj

    # Verify map_structure on value types.
    check_map_structure(None, None)
    check_map_structure(True, True)
    check_map_structure(0, 0)
    check_map_structure(1, 2)


# Generated at 2022-06-21 12:10:12.745742
# Unit test for function register_no_map_class
def test_register_no_map_class():
   import torch
   assert torch.Size in _NO_MAP_TYPES
   assert torch.Size([5,5]) not in _NO_MAP_TYPES
   assert torch.Size([5,5]).__class__ not in _NO_MAP_TYPES
   assert no_map_instance(torch.Size([5,5])) in _NO_MAP_TYPES
   assert no_map_instance(torch.Size([5,5])).__class__ in _NO_MAP_TYPES

# Generated at 2022-06-21 12:10:16.775721
# Unit test for function reverse_map
def test_reverse_map():
    # Function reverse_map
    d = {'a': 2, 'b': 6, 'c': 10, 'd': 1}
    assert reverse_map(d) == ['d', 'a', 'b', 'c']


# Generated at 2022-06-21 12:10:27.584732
# Unit test for function map_structure
def test_map_structure():
    # Function to add 1 to each element in the list
    def plus_1(lst):
        return list(map(lambda x: x+1, lst))

    # Test simple list
    a = [1, 2, 3]
    res = map_structure(plus_1, a)
    assert res == [2, 3, 4]

    # Test nested list
    res = map_structure(plus_1, [[1,2], [3,4]])
    assert res == [[2,3], [4,5]]

    # Test tuple
    res = map_structure(plus_1, (1, 2, 3))
    assert res == (2, 3, 4)

    # Test nested tuple
    res = map_structure(plus_1, (1, (2, 3, 4)))

# Generated at 2022-06-21 12:10:36.488623
# Unit test for function register_no_map_class
def test_register_no_map_class():
    """A test for the function register_no_map_class.
    """
    # 'register_no_map_class' can deal with built-in types
    register_no_map_class(list)
    test_list = no_map_instance([1])
    assert test_list == [1]
    # 'register_no_map_class' can deal with custom types
    class MyList(list):
        pass
    register_no_map_class(MyList)
    test_list = no_map_instance(MyList([1]))
    assert test_list == [1]

    class MyList(list):
        pass
    register_no_map_class(MyList)
    test_list = no_map_instance(MyList([1]))
    assert test_list == [1]
    # 'map

# Generated at 2022-06-21 12:10:47.942174
# Unit test for function map_structure
def test_map_structure():
    from tqdm import tqdm
    import numpy as np
    from scipy.stats import norm

    def f(x):
        return 0.2 * x
    a = np.arange(25)
    b = a.reshape((5, 5))
    c = np.repeat(b, 2).reshape((5, 10))
    d = np.random.randint(0, 5, (5, 10))
    e = np.random.uniform(0, 1, (5, 10))
    f = np.random.normal(0, 1, (5, 10))
    g = np.random.randint(0, 2, (5, 10))

# Generated at 2022-06-21 12:10:57.237953
# Unit test for function map_structure
def test_map_structure():
    # Test basic cases
    assert map_structure(lambda x: x, -1) == -1
    assert map_structure(lambda x: x, 0) == 0
    assert map_structure(lambda x: x, 1) == 1
    assert map_structure(lambda x: x, 0.1) == 0.1
    assert map_structure(lambda x: x, True) == True
    assert map_structure(lambda x: x, False) == False
    assert map_structure(lambda x: x, "string") == "string"
    x = range(0, 10)
    assert map_structure(lambda x: x, x) == list(x)
    assert map_structure(lambda x: x, tuple(x)) == tuple(x)

# Generated at 2022-06-21 12:11:03.565967
# Unit test for function reverse_map
def test_reverse_map():
    d = {'fs':1, 'hf':2, 'th':3}
    l = reverse_map(dict(d))
    assert(l==['fs','hf','th'])
    d = {'fs':3, 'hf':2, 'th':1}
    l = reverse_map(dict(d))
    assert(l==['th','hf','fs'])



# Generated at 2022-06-21 12:11:06.805504
# Unit test for function reverse_map
def test_reverse_map():
    d = {"a": 0, "b": 1}
    print(d)
    r = reverse_map(d)
    print(r)
    assert r[0] == "a" and r[1] == "b"

# Generated at 2022-06-21 12:11:24.693793
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import collections
    import torch

    # Test 1:
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    ans = map_structure_zip(lambda x, y, z: x + y + z, [a, b, c])
    assert ans == [12, 15, 18], "Fail test 1"

    # Test 2:
    a = (1, 2, 3)
    b = (4, 5, 6)
    c = (7, 8, 9)
    ans = map_structure_zip(lambda x, y, z: x + y + z, [a, b, c])
    assert ans == (12, 15, 18), "Fail test 2"

    # Test 3:

# Generated at 2022-06-21 12:11:28.488199
# Unit test for function no_map_instance
def test_no_map_instance():
    no_map_instance([1, 2, 3])
    no_map_instance({"a": 1, "b": 2, "c": 3})
    no_map_instance(1)
    no_map_instance("hello")
    no_map_instance(["a", "b", "c"])
    no_map_instance({"key": "value"})
    no_map_instance([1, 2, {"a": 1, "b": 2, "c": 3}])
    no_map_instance([1, 2, no_map_instance({"a": 1, "b": 2, "c": 3})])
    no_map_instance([1, 2, no_map_instance({"a": 1, "b": 2, "c": 3}), 1])

# Generated at 2022-06-21 12:11:40.109447
# Unit test for function no_map_instance
def test_no_map_instance():
    list1 = [1,2,3]
    list2 = [4, 5, 6]
    list3 = [7, 8, 9]
    tuple1 = (1, 2, 3)
    tuple2 = (4, 5, 6)
    tuple3 = (7, 8, 9)
    dic = {"a": 1, "b": 2}
    # test no_map_instance
    list1 = no_map_instance(list1)
    list2 = no_map_instance(list2)
    list3 = no_map_instance(list3)
    tuple1 = no_map_instance(tuple1)
    tuple2 = no_map_instance(tuple2)
    tuple3 = no_map_instance(tuple3)
    dic = no_map_instance(dic)

    #

# Generated at 2022-06-21 12:11:45.276564
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class MyClass(list):
        def __init__(self, data):
            self.data = data
            super(MyClass, self).__init__(data)

    my_instance = MyClass([1, 2, 3])
    register_no_map_class(MyClass)
    assert my_instance is no_map_instance(my_instance)



# Generated at 2022-06-21 12:11:55.226967
# Unit test for function map_structure
def test_map_structure():
    def add_one(x):
        return x + 1

    def empty(x):
        x.clear()

    # Testing on a nested list
    lst = [[1,2],[3,4]]
    lst_new = map_structure(add_one, lst)
    assert lst_new == [[2,3],[4,5]]
    map_structure(empty, lst)
    assert lst == []

    # Testing on a set
    myset = {-2,-1,0,1,2,3}
    myset_new = map_structure(add_one, myset)
    assert myset_new == {-1,0,1,2,3,4}
    map_structure(empty, myset)
    assert myset == set()

    # Testing on a dictionary


# Generated at 2022-06-21 12:12:07.862252
# Unit test for function no_map_instance
def test_no_map_instance():
    assert(no_map_instance((1,2)) == (1,2))
    assert(no_map_instance((1,2)).__class__ != tuple)
    assert(hasattr(no_map_instance((1,2)), "--no-map--"))
    assert(no_map_instance((1,2)).__class__ != tuple)
    assert(no_map_instance([1,2]) == [1,2])
    assert(no_map_instance([1,2]).__class__ != list)
    assert(hasattr(no_map_instance([1,2]), "--no-map--"))
    assert(no_map_instance((1,2)).__class__ != list)
    assert(no_map_instance({1,2}) == {1,2})

# Generated at 2022-06-21 12:12:12.611008
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'a': 0, 'aardvark': 1, 'abandon': 2}
    id_to_word = reverse_map(word_to_id)
    assert(id_to_word == ['a', 'aardvark', 'abandon'])


# Generated at 2022-06-21 12:12:20.143273
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from typing import NamedTuple
    from collections import defaultdict

    def colors(x):
        if x == 10:
            return "red"
        elif x % 2 == 0:
            return "yellow"
        else:
            return "blue"

    def colors2(x, c):
        return colors(x) + " " + c

    class D(NamedTuple):
        x: int
        y: int

    a = list(range(10))
    assert map_structure_zip(colors2, a) == ['yellow red', 'blue blue', 'yellow yellow', 'blue yellow',
                                             'yellow red', 'blue blue', 'yellow yellow', 'blue yellow',
                                             'yellow red', 'blue blue']

    b = [10, 10, 20]

# Generated at 2022-06-21 12:12:26.560794
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class MyClass(list):
        pass
    c = MyClass([1, 2, 3])
    assert map_structure(lambda x: x * 2, c) == [2, 4, 6]
    register_no_map_class(MyClass)
    assert map_structure(lambda x: x * 2, c) == [1, 2, 3, 1, 2, 3]

# Generated at 2022-06-21 12:12:28.940450
# Unit test for function reverse_map
def test_reverse_map():
    l = ["a", "b", "c"]
    d = {"a": 1, "b": 2, "c": 3}
    assert l == reverse_map(d)

# Generated at 2022-06-21 12:12:45.520472
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance(1) == 1
    assert no_map_instance([1, 2]) == [1, 2]
    assert no_map_instance((1, 2)) == (1, 2)
    assert no_map_instance((1, 2, {"a": 1, "b": 2})) == (1, 2, {"a": 1, "b": 2})
    assert no_map_instance({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert no_map_instance({"a": 1, "b": [2, 3]}) == {"a": 1, "b": [2, 3]}

# Generated at 2022-06-21 12:12:53.537981
# Unit test for function no_map_instance
def test_no_map_instance():
    class MyList(list):
        def __init__(self, *args):
            super().__init__(*args)

    my_list = MyList([1, 2, 3])
    my_list_no_map = no_map_instance(my_list)
    register_no_map_class(MyList)
    assert my_list_no_map == my_list
    assert map_structure(lambda x: None, my_list_no_map) == None

if __name__ == "__main__":
    test_no_map_instance()

# Generated at 2022-06-21 12:13:02.669385
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from dataclasses import dataclass
    from torch import Size
    class NoMapTuple(tuple):
        pass
    @dataclass
    class MyClass:
        d: list
        t: tuple
        c: NoMapTuple
        def __init__(self, d, t, c):
            self.d = d
            self.t = t
            self.c = c
    @dataclass
    class MyDataClass:
        d: list
        t: tuple
        c: NoMapTuple
        s: Size
    register_no_map_class(NoMapTuple)
    register_no_map_class(Size)
    myclass = MyClass([1,2,3],[2, 3, 4], NoMapTuple([1,2,3]))

# Generated at 2022-06-21 12:13:05.161927
# Unit test for function reverse_map
def test_reverse_map():
    test_d = {'a': 1, 'b': 2, 'c': 3}
    expected_result = ['a', 'b', 'c']
    assert reverse_map(test_d) == expected_result


# Generated at 2022-06-21 12:13:17.124139
# Unit test for function reverse_map

# Generated at 2022-06-21 12:13:18.902436
# Unit test for function no_map_instance
def test_no_map_instance():
    obj = no_map_instance([1, 2, 3])
    assert hasattr(obj, _NO_MAP_INSTANCE_ATTR)

# Generated at 2022-06-21 12:13:31.358722
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = list(map(lambda x: 2*x, [1, 2, 3]))
    b = list(map(lambda x: 3*x, [1, 2, 3]))
    c = list(map(lambda x: 4*x, [1, 2, 3]))
    d = list(map(lambda x: 5*x, [1, 2, 3]))
    e = [a, b, c, d]
    f = list(map(lambda x: x[0] + x[1] + x[2] + x[3], zip(a, b, c, d)))
    g = map_structure_zip(lambda x, y, z, w: x + y + z + w, e)
    assert f == g


# Generated at 2022-06-21 12:13:42.222452
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    print(type(a))
    print(a)
    print(hasattr(a, _NO_MAP_INSTANCE_ATTR))
    #
    b = no_map_instance(a)
    print(hasattr(b, _NO_MAP_INSTANCE_ATTR))
    print(b)
    #
    c = no_map_instance(a)
    print(c)
    assert(a is c)
    #
    d = no_map_instance(b)
    print(d)
    assert(d is b)
    #
    register_no_map_class(list)
    e = no_map_instance([1, 2, 3])
    print(type(e))
    print(e)

# Generated at 2022-06-21 12:13:52.504861
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn1(a, b, c):
        return [a, b, c]
    def fn2(a, b, c):
        return [a, b, c]
    def fn3(a, b, c):
        return {'a': a, 'b': b, 'c': c}
    objs1 = [[1, 2, 2], [1, 2, 3], [1, 2, 4]]
    objs2 = [1, 2, 3, 4]
    objs3 = [['a'], ['b'], ['c']]
    objs4 = [1, 2, 3]
    objs5 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    res1 = map_structure_zip(fn1, objs1)

# Generated at 2022-06-21 12:13:59.110394
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # since the function is not used elsewhere, import it here
    from spacy.attrs import ORTH
    from spacy.tokens import Doc

    register_no_map_class(Doc)

    def test(doc):
        return doc.user_hooks

    doc = Doc(None)
    assert map_structure(test, [doc, doc, doc]) == [[], [], []]

# Generated at 2022-06-21 12:14:11.222323
# Unit test for function no_map_instance
def test_no_map_instance():
    tlist = no_map_instance([1, 2, 3, 4])
    assert map_structure(lambda x: x**2, tlist) == [1, 2, 3, 4]

# Generated at 2022-06-21 12:14:17.761810
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # Only valid for testing. So use a more complicated method
    class MyTestClass(list):
        def __init__(self, arg0):
            self.arg0 = arg0

    # Use base class list to test this
    register_no_map_class(list)
    original = (1, 2, 3)
    new_list = map_structure(lambda x: x + 1, original)
    assert original == new_list

    # No error raised.
    new_instance = map_structure(lambda x: x + 1, MyTestClass((1, 2)))

# Generated at 2022-06-21 12:14:21.031375
# Unit test for function register_no_map_class
def test_register_no_map_class():

    class A(dict):
        def __init__():
            super().__init__()

    # A should not be treated as a normal dict.
    register_no_map_class(A)
    assert A in _NO_MAP_TYPES

# Generated at 2022-06-21 12:14:24.414974
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 1, 'b': 4, 'c': 2, 'd': 3}
    res = ['a', 'c', 'd', 'b']
    assert res == reverse_map(d)

# Generated at 2022-06-21 12:14:31.858930
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'abandonment', 'abate', 'abbey', 'abbot', 'abbreviate', 'abdicate']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word



# Generated at 2022-06-21 12:14:40.225895
# Unit test for function map_structure
def test_map_structure():
    def f1(x): return x*2
    def f2(x,y): return x+y
    def f3(x,y,z): return x+y+z

    test1 = [1,2,3,4,5]
    test2 = map_structure(f1, test1)
    assert (test1 != test2)
    assert (test2 == [2,4,6,8,10])

    test1 = (1,2,3,4,5)
    test2 = map_structure(f1, test1)
    assert (test1 != test2)
    assert (test2 == (2,4,6,8,10))

    test1 = {'a':1, 'b':2, 'c':3}

# Generated at 2022-06-21 12:14:51.021652
# Unit test for function no_map_instance
def test_no_map_instance():
    dict_no_map = no_map_instance({1: 2, 3: 4})
    assert dict_no_map == {1: 2, 3: 4}
    # Test type
    assert isinstance(dict_no_map, dict)
    # Test __class__
    assert dict_no_map.__class__ == dict
    # Test hasattr
    assert hasattr(dict_no_map, '__dict__') == False
    assert hasattr(dict_no_map, _NO_MAP_INSTANCE_ATTR) == True
    # Test setattr
    try:
        setattr(dict_no_map, '__dict__', {'a': 3})
    except AttributeError:
        # Test setattr failed
        assert True
    else:
        assert False

    list_no_map = no_map_

# Generated at 2022-06-21 12:14:58.409185
# Unit test for function reverse_map
def test_reverse_map():
    #assert(list(range(100)) == reverse_map(dict(zip(range(100), range(100)))))
    #assert(list(range(100)) == reverse_map(dict(zip(range(100), list(reversed(range(100)))))))
    #assert(list(reversed(range(100))) == reverse_map(dict(zip(range(100), list(reversed(range(100)))))))
    #assert(list(reversed(range(100))) == reverse_map(dict(zip(range(100), range(100)))))
    assert(list(reversed(range(100))) == reverse_map(dict(zip(range(100), list(reversed(range(100)))))))

# Generated at 2022-06-21 12:15:10.278646
# Unit test for function no_map_instance
def test_no_map_instance():
    @register_no_map_class
    class ContainerClass(list):
        def __init__(self, *args, **kwargs):
            super(ContainerClass, self).__init__(*args, **kwargs)

    def test_obj(obj):
        if isinstance(obj, list):
            return [test_obj(x) for x in obj]
        if isinstance(obj, dict):
            return {k: test_obj(v) for k,v in obj.items()}
        return no_map_instance(obj)

    test_obj([1, 2, 3])
    test_obj([ContainerClass([1, 2, 3]), ContainerClass([])])
    test_obj({'a': 1, 'b': {'c': 3}, 'd': [1, 2, 3]})


# Generated at 2022-06-21 12:15:14.612497
# Unit test for function register_no_map_class
def test_register_no_map_class():
    try:
        register_no_map_class(torch.Size)
        tmp_test = {torch.Size: 'torch.Size'}
        assert tmp_test[torch.Size] == 'torch.Size'
    except:
        assert False



# Generated at 2022-06-21 12:15:40.161400
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from collections.abc import Mapping
    from collections import UserDict
    from torch.Size import Size
    from torch.Tensor import Tensor
    from torch.empty import empty
    register_no_map_class(Size)
    register_no_map_class(Mapping)
    register_no_map_class(UserDict)
    register_no_map_class(Tensor)

    def test_mapping(mapping):
        return mapping

    def test_mapping_zip(mapping1, mapping2):
        return mapping1, mapping2

    def test_tuple(x, y):
        return x, y

    def test_list(x):
        return x

    # Test NamedTuple
    from collections import namedtuple
    A = namedtuple('A', '')
    a = A()


# Generated at 2022-06-21 12:15:44.144181
# Unit test for function no_map_instance
def test_no_map_instance():
    numbers = [1, 2, 3, 4, 5]
    fn = lambda x : x * 2
    assert map_structure(fn, no_map_instance(numbers)) == numbers

if __name__ == '__main__':
    test_no_map_instance()

# Generated at 2022-06-21 12:15:51.007415
# Unit test for function map_structure_zip
def test_map_structure_zip():
    A = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    B = {'a': 4, 'b': 5, 'c': 6, 'd': 7}
    key = lambda x: x['a'] + x['b']
    assert list(map_structure_zip(key, [A, B])) == [6, 7, 8, 9]

# Generated at 2022-06-21 12:16:02.731973
# Unit test for function no_map_instance
def test_no_map_instance():
    from pprint import pprint
    from typing import Optional, Callable

    # Define a dummy container.
    class MyContainer(list):
        pass

    # Define a dummy function.
    def dummy_func(xs: Optional[MyContainer]) -> int:
        if isinstance(xs, list):
            return len(xs)
        else:
            return 0

    # Define a dummy container instance.
    mc = MyContainer([1, 2, 3, 4])
    # Define a dummy container instance that is registered as no-map.
    nmc = no_map_instance(mc)

    # Define a dummy function that could handle the no-map container.
    def dummy_func_flex(xs: Optional[MyContainer]) -> int:
        if isinstance(xs, list):
            return len(xs)

# Generated at 2022-06-21 12:16:12.216042
# Unit test for function no_map_instance
def test_no_map_instance():
    test_list = [1, 2, 3]
    test_list_no_map = no_map_instance(test_list)
    assert test_list_no_map == test_list
    assert test_list_no_map is not test_list
    assert test_list_no_map.__class__.__base__ is list
    assert not hasattr(list, _NO_MAP_INSTANCE_ATTR)
    assert hasattr(test_list_no_map, _NO_MAP_INSTANCE_ATTR)
    assert getattr(test_list_no_map, _NO_MAP_INSTANCE_ATTR) is True


# Generated at 2022-06-21 12:16:17.502011
# Unit test for function reverse_map
def test_reverse_map():
    inpDict = {1:1, 2:2, 3:3}
    outList = reverse_map(inpDict)
    assert (outList == [1,2,3])

    inpDict = {4:3, 2:1, 5:4}
    outList = reverse_map(inpDict)
    assert (outList == [2,4,5])

# Generated at 2022-06-21 12:16:25.915098
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import Counter, defaultdict
    from typing import Mapping
    from torch.nn.modules.batchnorm import _BatchNorm

    container_types = [
        list, tuple, Mapping, Counter, defaultdict,
        _BatchNorm,  # subclass `Module`
    ]

    def map_all_items(fn: Callable[[int], int], c: Collection[int]) -> Collection[int]:
        return map_structure(fn, c)

    for c in container_types:
        c_instance = c()
        c_instance_no_map = no_map_instance(c())
        print(c_instance, c_instance_no_map)
        assert map_all_items(lambda x: x + 1, c_instance_no_map) is None

# Generated at 2022-06-21 12:16:30.149818
# Unit test for function map_structure_zip
def test_map_structure_zip():
    x = torch.ones(3)
    y = torch.ones(3)
    def fn(x,y):
        return x+y
    print(map_structure_zip(fn, [x,y]))


# Generated at 2022-06-21 12:16:36.733071
# Unit test for function register_no_map_class
def test_register_no_map_class():
    register_no_map_class(torch.Size)
    a = torch.Size((1,))
    b = torch.Size((2,))
    c = map_structure(lambda x: torch.Size(x), [a, b])
    d = map_structure_zip(lambda x, y: torch.Size(x) + torch.Size(y), [a, b])
    assert c[0].size() == a
    assert c[1].size() == b
    assert d.size() == torch.Size((3,))
    assert d == torch.Size((3,))

test_register_no_map_class()

# Generated at 2022-06-21 12:16:44.062175
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # Test on list
    class testList(list):
        def __init__(self, *args):
            super(testList, self).__init__(args)

    # Test on dict
    class testDict(dict):
        def __init__(self, *args):
            super(testDict, self).__init__(args)

    l = testList([1, 2, 3])
    d = testDict({'l':l})

    # Before customized list and dict are registered
    assert isinstance(map_structure(lambda x: x*2, l), list)
    assert isinstance(map_structure(lambda x: x*2, d), dict)
    assert isinstance(map_structure(lambda x: x*2, d['l']), list)

    # After customized list and dict are registered
