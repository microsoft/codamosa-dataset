

# Generated at 2022-06-21 12:07:01.866310
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [{"a": 1, "b": 2}]
    b = [{"a": 3, "b": 4}]
    def fn(d):
        return sum(d.values())
    result = map_structure_zip(fn, objs=[a, b])
    assert isinstance(result, list)
    assert result[0].keys() == a[0].keys()
    assert result[0]["a"] == 4
    assert result[0]["b"] == 6

    a = [{"a": 1, "b": 2}]
    b = [{"a": 3, "b": 4}]
    def fn(d):
        return sum(d.values())
    result = map_structure_zip(fn, objs=[a, b])
    assert isinstance(result, list)
    assert result

# Generated at 2022-06-21 12:07:12.067114
# Unit test for function no_map_instance
def test_no_map_instance():
    # define classes for testing
    class Container1(list):
        pass

    class Container2(Container1):
        pass

    class Container3(Container1):
        pass

    class Container4(Container2):
        pass

    # test normal container classes
    assert map_structure(len, [[1, 2, 3], [4, 5, 6]]) == [3, 3]
    assert map_structure(len, [{1, 2, 3}, {1}]) == [3, 1]
    assert map_structure(len, [[[1, 2], [3, 4]], [[1, 2], [3, 4, 5]]]) == [2, 3]

    # test subclass of container classes

# Generated at 2022-06-21 12:07:22.216375
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x - 3, [[1, 2], [3, [4, 5], 6, [7, 8, 9]]]) == [[-2, -1], [0, [-1, -2], -3, [-4, -5, -6]]]
    assert map_structure(lambda x: x - 3, (1, 2)) == (-2, -1)
    assert map_structure(lambda x: x - 3, (1, (2, 3))) == (-2, (-1, -2))
    assert map_structure(lambda x: x - 3, (1, (1, (1, 1)))) == (-2, (-2, (-2, -2)))

    with pytest.raises(ValueError, match="Structures cannot contain `set` because it's unordered"):
        map_st

# Generated at 2022-06-21 12:07:34.183860
# Unit test for function map_structure_zip
def test_map_structure_zip():
    ids_to_words_0 = {1: "aardvark"}
    ids_to_words_1 = {2: "abandon"}
    ids_to_words_2 = {3: "about"}
    ids_to_words_3 = {4: "abroad"}
    ids_to_words_4 = {5: "absence"}
    ids_to_words_5 = {6: "absent"}
    ids_to_words_6 = {7: "absolute"}

    #fn = lambda *x: x
    #mapped_list = map_structure_zip(fn, [ids_to_words_0, ids_to_words_1, ids_to_words_2, ids_to_words_3,
    #                                     ids_to_words

# Generated at 2022-06-21 12:07:40.779803
# Unit test for function map_structure_zip
def test_map_structure_zip():
    x = torch.randn(5,5,5,5)
    y = torch.randn(5,5,5,5)
    z = torch.randn(5,5,5,5)
    def fn(a,b,c):
        return a+b+c
    a = map_structure_zip(fn, [x,y,z])
    b = x+y+z
    assert torch.allclose(a,b)

# Generated at 2022-06-21 12:07:49.087240
# Unit test for function map_structure_zip
def test_map_structure_zip():
	a1 = 1
	b1 = 2
	c1 = 3
	a2 = 4
	b2 = 5
	c2 = 6
	a3 = 7
	b3 = 8
	c3 = 9
	
	def func1(a, b, c):
		return a + b + c
	
	d1 = func1(a1, b1, c1)
	d2 = func1(a2, b2, c2)
	d3 = func1(a3, b3, c3)
	d4 = map_structure_zip(func1, [[a1, b1, c1], [a2, b2, c2], [a3, b3, c3]])
	

# Generated at 2022-06-21 12:07:57.071417
# Unit test for function map_structure
def test_map_structure():
    tensor_list = [torch.tensor([1.0]), torch.tensor([2.0]), torch.tensor([3.0])]
    list_list1 = [[1.0,2.0], [3.0,4.0], [6.0, 7.0]]
    list_list2 = [['a', 'b'], ['b','c'], ['c', 'd']]
    assert map_structure(lambda x: x-1.0, tensor_list) == [torch.tensor([0.0]), torch.tensor([1.0]), torch.tensor([2.0])]

# Generated at 2022-06-21 12:08:07.166490
# Unit test for function map_structure
def test_map_structure():
    list1 = [1, 2, 3]
    tuple1 = ("x", "y", "z")
    dict1 = {"x": 1, "y": 2, "z": 3}
    namedtuple1 = namedtuple('point', ['x', 'y'])
    n1 = namedtuple1(x=1, y=2)
    sublist1 = [1, 2, 3]
    subdict1 = {"x": 1, "y": 2, "z": 3}
    subnamedtuple1 = namedtuple('point', ['x', 'y'])
    subn1 = namedtuple1(x=1, y=2)
    list2 = [4, 5, 6]
    tuple2 = ("a", "b", "c")

# Generated at 2022-06-21 12:08:16.144641
# Unit test for function no_map_instance
def test_no_map_instance():
    def test_object():
        x = no_map_instance([1,2,3])
        assert hasattr(x, _NO_MAP_INSTANCE_ATTR)
        x[0] = 2
        assert x == [2,2,3]
        assert hasattr(x[0], _NO_MAP_INSTANCE_ATTR)
        x = list(x)
        assert not hasattr(x[0], _NO_MAP_INSTANCE_ATTR)
        
    def test_class():
        class Test(list): pass
        register_no_map_class(Test)
        x = no_map_instance(Test([1,2,3]))
        assert hasattr(x, _NO_MAP_INSTANCE_ATTR)
        x[0] = 2
        assert x == [2,2,3]

# Generated at 2022-06-21 12:08:22.014345
# Unit test for function no_map_instance
def test_no_map_instance():
    l = [1, 2, 3]
    l_ = no_map_instance(l)
    assert id(l) == id(l_)
    assert map_structure(lambda x: x + 1, l) == [2, 3, 4]
    assert map_structure(lambda x: x + 1, l_) == [1, 2, 3]
    assert type(l_) == list

# Generated at 2022-06-21 12:08:34.063206
# Unit test for function register_no_map_class
def test_register_no_map_class():
    """
    Test `register_no_map_class` function
    """
    class _TestClass(list):
        pass

    assert(issubclass(_TestClass, list))
    assert(not hasattr(_TestClass, _NO_MAP_INSTANCE_ATTR))

    test_obj = _TestClass()
    assert(not hasattr(test_obj, _NO_MAP_INSTANCE_ATTR))

    try:
        map_structure(lambda x: x, test_obj)
    except TypeError:
        print("Pass test_map_structure_no_map_class_error")
    else:
        raise Exception("Expect TypeError when call map_structure")

    register_no_map_class(_TestClass)


# Generated at 2022-06-21 12:08:43.475868
# Unit test for function map_structure_zip
def test_map_structure_zip():
    list1 = [[1, 2, 3], [4, 5, 6]]
    list2 = [[4, 5, 6], [7, 8, 9]]
    list3 = [[7, 8, 9], [10, 11, 12]]
    list4 = [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]]
    assert map_structure_zip(lambda x, y, z: x + y + z, [list1, list2, list3]) == [[12, 15, 18], [21, 24, 27]]
    assert map_structure_zip(lambda x, y: x + y, [list1, list2]) == [[5, 7, 9], [11, 13, 15]]

# Generated at 2022-06-21 12:08:47.820413
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class NewContainer:
        pass
    register_no_map_class(container_type=NewContainer)

    class NewContainer2:
        pass
    assert _NO_MAP_TYPES == {NewContainer}



# Generated at 2022-06-21 12:08:59.062972
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from .config import AttrDict
    from .misc import size_str
    from .path import Path
    from .size import Size, Size2

    register_no_map_class(size_str)
    register_no_map_class(Path)
    register_no_map_class(Size)
    register_no_map_class(Size2)


# Generated at 2022-06-21 12:09:10.375782
# Unit test for function map_structure
def test_map_structure():
    obj_list = {"hello": [9, 10, 11],
                "world": [1, 2, (3, 4), [5, 6], 7],
                "goodbye": 'abc'}

    def increment_if_odd(x):
        if isinstance(x, int) and x % 2 == 1:
            return x + 1
        else:
            return x

    obj_inc = map_structure(increment_if_odd, obj_list)
    assert obj_inc["hello"] == [9, 11, 11]
    assert obj_inc["world"] == [1, 2, (3, 4), [5, 6], 7]
    assert obj_inc["goodbye"] == 'abc'



# Generated at 2022-06-21 12:09:20.623091
# Unit test for function map_structure
def test_map_structure():
    def square(x):
        return x*x

    obj = {"a": 1, "b": [4, 7, 8]}
    obj_out = map_structure(square, obj)
    assert obj_out == {"a": 1, "b": [16, 49, 64]}

    obj_out = map_structure(lambda x: square(2*x), obj)
    assert obj_out == {"a": 4, "b": [32, 98, 128]}

    def square_and_add(x, y):
        return x*x + y

    obj_1 = {"a": 1, "b": [4, 7, 8]}
    obj_2 = {"a": 4, "b": [7, 9, 1]}

# Generated at 2022-06-21 12:09:28.846063
# Unit test for function map_structure
def test_map_structure():
    for a, b in zip([1,2,4], [5,5,5]):
        print(a, b)

    d = {
        "a": [1, 2, 3],
        "b": [4, 5, 6],
        "c": 3
    }

    def sub(a, b):
        return a - b

    dd = map_structure_zip(sub, d.values())
    print(dd)

if __name__ == "__main__":
    test_map_structure()

# Generated at 2022-06-21 12:09:34.249478
# Unit test for function map_structure
def test_map_structure():
    A = [1, 2, 3]
    B = [4, 5, 6]
    C = [7, 8, 9]

    D = map_structure(lambda x: x + 1, [[A, B], [C]])
    assert D == [[[2, 3, 4], [5, 6, 7]], [[8, 9, 10]]]

# Generated at 2022-06-21 12:09:44.078184
# Unit test for function reverse_map
def test_reverse_map():
    # need to work with different types of values
    for t in ('text', 123, 3.4, ('c',), [98.6], {'a':1, 'b':2}):
        # create a dict with unique keys from the value
        testdict = {i: t for i in range(len(t))}
        check = reverse_map(testdict)
        print(testdict)
        print(check)
        assert check == t
        for k, v in testdict.items():
            assert check[k] == t
    # create a dict with multiple values
    testdict = {i: t for t in ('text', 123, 3.4, ('c',), [98.6], {'a':1, 'b':2}) for i in range(len(t))}
    check = reverse_map(testdict)


# Generated at 2022-06-21 12:09:55.394133
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def test_fn(a, b):
        return a + b

    test_list = [[1, 2],
                 [5, 6]]
    test_list_list = [test_list, test_list]

    test_dict = {
        'a': [1, 2],
        'b': [5, 6],
    }
    test_dict_dict = [test_dict, test_dict]

    # test for list
    assert map_structure_zip(test_fn, test_list_list) == [[2, 4], [10, 12]]

    # test for dict
    assert map_structure_zip(test_fn, test_dict_dict) == {
        'a': [2, 4],
        'b': [10, 12],
    }

# Generated at 2022-06-21 12:10:07.762854
# Unit test for function map_structure_zip
def test_map_structure_zip():
    list1 = [1, [1, 2], -1, [[4, 5, 6], [7, 8, 9]]]
    list2 = [1, [1, 2], -1, [[4, 5, 6], [7, 8, 9]]]
    list3 = [1, [1, 2], -1, [[4, 5, 6], [7, 8, 9]]]
    def fn(a, b, c):
        return (a, b, c)

# Generated at 2022-06-21 12:10:19.771314
# Unit test for function register_no_map_class
def test_register_no_map_class():
    register_no_map_class(dict)
    register_no_map_class(list)
    register_no_map_class(tuple)
    register_no_map_class(set)
    assert(dict in _NO_MAP_TYPES)
    assert(list in _NO_MAP_TYPES)
    assert(tuple in _NO_MAP_TYPES)
    assert(set in _NO_MAP_TYPES)
    assert(_NO_MAP_TYPES == {dict, list, tuple, set})

    # check if instantiated class is in _NO_MAP_TYPES
    class NonMapType(list):
        pass
    register_no_map_class(NonMapType)
    assert(NonMapType in _NO_MAP_TYPES)

# Generated at 2022-06-21 12:10:29.724325
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def test_single(arrs, fn):
        for a in arrs:
            print(type(a), a)
            map_structure_zip(fn, a)

    def test_all(*arrs):
        for a in arrs:
            print(type(a), a)
            assert type(map_structure_zip(len, a)) == type(a)
            assert type(map_structure_zip(len, a)) == type(a)

    # Test special cases
    # map_structure_zip(fn, [[1,2], [3,4], [5,6]])
    print('\nTesting map_structure_zip([[1,2], [3,4], [5,6]])')

# Generated at 2022-06-21 12:10:33.681303
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5, 'g': 6, 'h': 7, 'i': 8, 'j': 9}
    result = d
    assert (result == reverse_map(d))


# Generated at 2022-06-21 12:10:36.841572
# Unit test for function reverse_map
def test_reverse_map():
    dict = {'a': 0, 'b': 1, 'c': 2}
    assert(reverse_map(dict) == ['a', 'b', 'c'])

# Generated at 2022-06-21 12:10:41.746604
# Unit test for function no_map_instance
def test_no_map_instance():
    @no_type_check
    def fn(x):
        return x+1
    a = no_map_instance([1, 2, 3, 4])
    b = map_structure(fn, a)
    assert b == [1, 2, 3, 4]

test_no_map_instance()

# Generated at 2022-06-21 12:10:51.396276
# Unit test for function map_structure
def test_map_structure():
    def f(obj):
        print(obj)
        return obj * 2


    x = [1,2,3,4,5]
    expected = [2,4,6,8,10]
    assert(map_structure(f, x) == expected)

    x = {'a': 1, 'b': 2}
    expected = {'a': 2, 'b': 4}
    assert(map_structure(f, x) == expected)

    x = (1,2,3,4,5)
    expected = (2,4,6,8,10)
    assert(map_structure(f, x) == expected)

    x = (1, 2, {'a': 3, 'b': 4}, 5)

# Generated at 2022-06-21 12:10:59.203791
# Unit test for function map_structure
def test_map_structure():
    def f(a):
        return a + 1

    def f_zip(a, b):
        return a + b

    assert map_structure(f, 1) == 2
    assert map_structure(f, [1]) == [2]
    assert map_structure(f, [1, 2, 3]) == [2, 3, 4]
    assert map_structure(f, [[1]]) == [[2]]
    assert map_structure(f, [[1, 2], [3, 4]]) == [[2, 3], [4, 5]]
    assert map_structure(f, [[[1], [2], [3]], [[4], [5], [6]]]) == [[[2], [3], [4]], [[5], [6], [7]]]

# Generated at 2022-06-21 12:11:09.893149
# Unit test for function map_structure_zip
def test_map_structure_zip():
    exp = 1
    def fn(a: int, b: int) -> int:
        nonlocal exp
        assert a == b
        assert a == exp
        exp = exp + 1
        return a

    a = (1, 2, 3)
    b = ("a", "b", "c")
    c = (1, 2, 3)
    map_structure_zip(fn, (a, b, c))
    assert exp == 3

    a = [1, 2, 3]
    b = ["a", "b", "c"]
    c = [1, 2, 3]
    map_structure_zip(fn, (a, b, c))
    assert exp == 5

    a = {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-21 12:11:13.319904
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a':0,'b':1,'c':2}
    r = reverse_map(d)
    assert r[0]=='a'
    assert r[1]=='b'
    assert r[2]=='c'

# Generated at 2022-06-21 12:11:36.897129
# Unit test for function no_map_instance
def test_no_map_instance():
    import numpy as np

    assert no_map_instance([3, 6, 1, 2, 5, 4]) == [3, 6, 1, 2, 5, 4]
    assert no_map_instance((3, 6, 1, 2, 5, 4)) == (3, 6, 1, 2, 5, 4)
    assert no_map_instance({3, 6, 1, 2, 5, 4}) == {3, 6, 1, 2, 5, 4}
    assert no_map_instance({'a': 3, 'b': 6, 'c': 1, 'd': 2, 'e': 5, 'f': 4}) == {'a': 3, 'b': 6, 'c': 1, 'd': 2, 'e': 5, 'f': 4}

# Generated at 2022-06-21 12:11:43.212471
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import torch
    import mkl

    def f(x, y):
        if type(x) is torch.Tensor:
            return x + y
        else:
            return x + ' ' + y
    
    sizes = [torch.Size([3, 2]), torch.Size([3, 2])]
    a1 = torch.rand(sizes[0])
    a2 = torch.rand(sizes[1])
    
    _map = map_structure_zip(f, [a1, a2])

    print("Test map_structure_zip success!")

if __name__ == "__main__":
    test_map_structure_zip()

# Generated at 2022-06-21 12:11:49.714322
# Unit test for function map_structure
def test_map_structure():
    obj = [
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
    ]
    result = map_structure(sum, obj)
    expected = [
        {'a': 4, 'b': 6},
        {'a': 6, 'b': 8},
    ]
    assert result == expected


if __name__ == '__main__':
    test_map_structure()

# Generated at 2022-06-21 12:11:55.185623
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class List(list):
        pass
    register_no_map_class(List)

    @no_type_check
    def test_map_structure(obj: List[int]) -> List[int]:
        for i in range(len(obj)):
            obj[i] += 1
        return obj

    a = List([0, 0, 0])
    a = map_structure(test_map_structure, a)
    assert a == [1, 1, 1]

# Generated at 2022-06-21 12:12:07.812525
# Unit test for function map_structure_zip
def test_map_structure_zip():
    test_obj0 = {
        'int': 1,
        'float': 3.5,
        'list': [1, 2, 3],
        'tuple': (1, 2, 3),
        'dict': {'1': 1, '2': 2},
        'set': {1, 2, 3}
    }
    test_obj1 = {
        'int': 5,
        'float': 7.5,
        'list': [5, 6, 7],
        'tuple': (4, 5, 6),
        'dict': {'4': 4, '5': 5},
        'set': {4, 5, 6}
    }

# Generated at 2022-06-21 12:12:13.278808
# Unit test for function reverse_map
def test_reverse_map():
    word2idx = {'a':0, 'apple':1, 'about':2}
    idx2word = reverse_map(word2idx)
    assert(idx2word[0] == 'a')
    assert(idx2word[1] == 'apple')
    assert(idx2word[2] == 'about')


test_reverse_map()

# Generated at 2022-06-21 12:12:20.326599
# Unit test for function map_structure
def test_map_structure():
    x = {
        "a": 1,
        "b": 2,
        "c": 3
    }

    def func(x):
        if isinstance(x, int):
            return x*x
        return x
    
    def func1(x):
        return x
        
    def func2(x, y):
        return x+y

    res = map_structure(func, x)
    res1 = map_structure(func1, x)
    res2 = map_structure_zip(func2, [x, x])
    print("res: ", res)
    print("res1: ", res1)
    print("res2: ", res2)

if __name__ == '__main__':
    test_map_structure()

# Generated at 2022-06-21 12:12:23.596350
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 1, 'b': 3, 'c': 2}
    assert reverse_map(d) == ['a', 'c', 'b']

# Generated at 2022-06-21 12:12:32.372679
# Unit test for function map_structure
def test_map_structure():
    dict_input = {'a':dict(b=[1, 2, 3]), 'c':dict(d=[4, 5, 6])}
    dict_output = map_structure(lambda x: 2*x, dict_input)
    assert(dict_output == {'a': dict(b=[2, 4, 6]), 'c': dict(d=[8, 10, 12])})


    test_namedtuple = collections.namedtuple('test', ['a', 'b'])
    list_input = [dict(a=1, b=2), dict(a=3, b=4)]

    list_output = map_structure(test_namedtuple, list_input)

# Generated at 2022-06-21 12:12:42.222422
# Unit test for function reverse_map

# Generated at 2022-06-21 12:13:14.051333
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class ListWrapper(list):
        def __init__(self, list):
            super().__init__(list)
    register_no_map_class(list)
    assert(list in _NO_MAP_TYPES)
    assert(ListWrapper in _NO_MAP_TYPES)
    assert(tuple not in _NO_MAP_TYPES)



# Generated at 2022-06-21 12:13:22.667857
# Unit test for function map_structure_zip
def test_map_structure_zip():
    head_labels1 = {'a': 0, 'b': 1, 'c': 2, 'd': 3}
    head_labels2 = {'e': 8, 'b': 9, 'c': 10, 'd': 11}
    head_labels3 = {'b': 16, 'c': 17, 'd': 18, 'f': 19}
    head_labels4 = {'b': 25, 'c': 26, 'd': 27, 'g': 28}

    head_labels_list = [head_labels1, head_labels2, head_labels3, head_labels4]


# Generated at 2022-06-21 12:13:34.163861
# Unit test for function register_no_map_class
def test_register_no_map_class():
    
    #Example 1
    print("*********Example1**********")
    from collections import UserList
    example_type = UserList
    example_type_name = type(example_type)
    print("Example_type:", example_type)
    print("Example_type_name:", example_type_name)
    
    register_no_map_class(example_type)
    assert len(_NO_MAP_TYPES) == 1
    assert example_type in _NO_MAP_TYPES
    print("assert example_type in _NO_MAP_TYPES")
    
    #Example 2
    print("*************Example2***********")
    example_type = list
    example_type_name = type(example_type)
    print("Example_type:", example_type)

# Generated at 2022-06-21 12:13:46.090972
# Unit test for function map_structure
def test_map_structure():
    from torch.tests._internal.common_utils import TestCase
    from torch.testing import assert_allclose

    class TestMapStructure(TestCase):
        def test_tensor_map_structure_tuple(self):
            # test case custom struct input
            a = torch.randn(3, 4) / 10
            b = torch.randn(3, 1) / 10
            c = torch.randn(2, 3, 1, 4) / 10

            def custom_fn(struct_ele):
                return struct_ele + 1

            # custom struct input
            cst_struct_in = ((a,), (b,), (c,), (a + b, b + c))
            mapped_cst_struct_in = map_structure(custom_fn, cst_struct_in)


# Generated at 2022-06-21 12:13:48.964283
# Unit test for function no_map_instance
def test_no_map_instance():
  a = no_map_instance([1, 2])
  a.append(3)
  a.append(4)
  a[1] = 5
  assert a == [1, 5, 3, 4]

# Generated at 2022-06-21 12:14:00.532232
# Unit test for function map_structure
def test_map_structure():
    import numpy as np
    from torch.nn.utils.rnn import PackedSequence


# Generated at 2022-06-21 12:14:08.996857
# Unit test for function map_structure
def test_map_structure():
    obj = {
        "a": [3, 5, 7],
        "b": [9, 11, 13],
        "c": [15, 17],
    }
    obj_mapped = map_structure(lambda x: x + 1, obj)
    assert obj == {
        "a": [3, 5, 7],
        "b": [9, 11, 13],
        "c": [15, 17],
    }
    assert obj_mapped == {
        "a": [4, 6, 8],
        "b": [10, 12, 14],
        "c": [16, 18],
    }



# Generated at 2022-06-21 12:14:13.663982
# Unit test for function register_no_map_class
def test_register_no_map_class():
    structure = [1, [2, 2], torch.Size([1])]
    register_no_map_type = register_no_map_class(torch.Size)
    assert register_no_map_type is None
    simple_function = lambda x: x + 1
    mapped_structure = map_structure(simple_function, structure)
    expected_structure = [2, [3, 3], torch.Size([1])]
    assert mapped_structure == expected_structure


# Generated at 2022-06-21 12:14:17.974323
# Unit test for function no_map_instance
def test_no_map_instance():
    def test_type(a_object):
        assert no_map_instance(a_object) == a_object
        assert isinstance(no_map_instance(a_object), type(a_object))
    test_type({1, 2, 4, 'a', 'b'})
    test_type({'key1':2, 'key2':{1,2,3}, 'key3':'test_string'})
    test_type([1, 'a', 2, 'b'])
    test_type({'key1':2, 'key2':[1,'a',2,'b'], 'key3':'test_string'})
    test_type({})
    test_type([])
    test_type(())
    T = namedtuple('T', ['field1', 'field2'])
    test_type

# Generated at 2022-06-21 12:14:30.045569
# Unit test for function reverse_map
def test_reverse_map():
    # Example 1:
    words = ['a', 'aardvark', 'abandon', 'abandoned', 'ability', 'able', 'about', 'above', 'abroad', 'absolutely', 'absorb', 'abuse', 'abused', 'accept', 'acceptable', 'access', 'accident', 'accompany', 'accomplish']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    if (words == id_to_word):
        print("Example 1: Pass!")
    else:
        print("Example 1: Fail!")
    # Example 2:
    words = ['abroad', 'absolutely', 'absorb', 'abuse', 'abused']

# Generated at 2022-06-21 12:15:00.986409
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class SubList(list):
        pass
    sub_l = SubList([1, 2, 3])
    assert not hasattr(sub_l, _NO_MAP_INSTANCE_ATTR)
    register_no_map_class(SubList)
    assert hasattr(sub_l, _NO_MAP_INSTANCE_ATTR)


if __name__ == '__main__':
    test_register_no_map_class()

# Generated at 2022-06-21 12:15:03.751786
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([[1,2,3],2,3,4])
    print(a)
    print(map_structure(lambda x: x, a))

# Generated at 2022-06-21 12:15:09.483497
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance(list())
    b = no_map_instance(list())
    assert a == b
    assert map_structure(lambda x: x, [a, b]) == [list(), list()]


if __name__ == "__main__":
    test_no_map_instance()

# Generated at 2022-06-21 12:15:13.254034
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([[1, 2, 3], [1, 2, 3]])
    assert map_structure(sum, a) == map_structure(sum, a)



# Generated at 2022-06-21 12:15:18.553356
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance([1,2,3]) == [1,2,3]
    assert no_map_instance([[1,2,3], [4,5]]) != [[no_map_instance(1), no_map_instance(2), no_map_instance(3)], [no_map_instance(4), no_map_instance(5)]]



# Generated at 2022-06-21 12:15:27.608527
# Unit test for function reverse_map

# Generated at 2022-06-21 12:15:39.228966
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class TestClass(list):
        pass
    class TestClass2(dict):
        pass

    register_no_map_class(TestClass)
    register_no_map_class(TestClass2)

    @no_type_check
    def test_function(x) -> str:
        return str(x)

    t = TestClass()
    t.append(1)
    t.append(2)
    ret = map_structure(test_function, t)
    assert ret == str(t)

    t2 = TestClass2()
    t2['a'] = 1
    t2['b'] = 2
    ret = map_structure(test_function, t2)
    assert ret == str(t2)

# Generated at 2022-06-21 12:15:50.914613
# Unit test for function map_structure_zip
def test_map_structure_zip():
    list_x = [1, 2, 3]
    list_y = [4, 5, 6]
    list_z = [7, 8, 9]
    def add(x, y, z):
        return x + y + z
    
    assert map_structure_zip(add, [list_x, list_y, list_z]) == [12, 15, 18]
    
    tuple_x = (1, 2, 3)
    tuple_y = (4, 5, 6)
    tuple_z = (7, 8, 9)
    def multiply(x, y, z):
        return x * y * z
    
    assert map_structure_zip(multiply, [tuple_x, tuple_y, tuple_z]) == (28, 60, 108)

test_map_structure_

# Generated at 2022-06-21 12:16:02.633664
# Unit test for function map_structure
def test_map_structure():
    class A:
        def __init__(self, x, y):
            self.x = x
            self.y = y

        def __repr__(self):
            return "(A %s %s)" % (self.x, self.y)


# Generated at 2022-06-21 12:16:04.538837
# Unit test for function no_map_instance
def test_no_map_instance():
    l = no_map_instance(['a', 1, [2, 3]])
    assert isinstance(l, list)
    assert l == ['a', 1, [2, 3]]
    assert l.__class__.__name__ != 'list'

# Generated at 2022-06-21 12:16:35.955075
# Unit test for function no_map_instance
def test_no_map_instance():
    def test_fn(x):
        return 1

    def test_fn2(x, y, z):
        return x, y, z

    l = [[0, 1, 2], [1, 1, 1]]
    l2 = no_map_instance(l)
    d = {0: "a", 1: "b"}
    d2 = no_map_instance(d)
    t = tuple(range(10))
    t2 = no_map_instance(t)
    assert map_structure(test_fn, l) == [[1, 1, 1], [1, 1, 1]]
    assert map_structure(test_fn, l2) == l2
    assert map_structure(test_fn, d) == {0: 1, 1: 1}

# Generated at 2022-06-21 12:16:38.583731
# Unit test for function reverse_map
def test_reverse_map():
    a = {'a':1,'b':2,'c':3}
    ans = reverse_map(a)
    assert ans == ['a','b','c']
    assert type(ans) == list


# Generated at 2022-06-21 12:16:47.324048
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [[1, 2], [[3, 4], [5, 6]]]
    b = [[0, 1], [[0, 1], [2, 3]]]
    c = [[1, 1], [[0, 2], [3, 6]]]
    assert map_structure_zip(lambda *xs: list(xs), [a, b]) == c
    assert map_structure_zip(lambda x, y: x + y, [a, b]) == c


if __name__ == "__main__":
    test_map_structure_zip()