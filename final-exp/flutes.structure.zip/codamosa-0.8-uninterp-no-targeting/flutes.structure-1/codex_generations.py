

# Generated at 2022-06-21 12:07:01.866255
# Unit test for function no_map_instance
def test_no_map_instance():
    for type in (int, float, str, bool, None):
        assert (no_map_instance(type([])) == [])
    for type in (list, tuple, dict, torch.Size, set):
        assert (no_map_instance(type([])) == no_map_instance([]))

# Generated at 2022-06-21 12:07:06.748474
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Test:
        def __init__(self, a, b):
            self.a = a
            self.b = b
    register_no_map_class(Test)
    test1 = Test(1, "2")
    assert test1.a == 1
    assert test1.b == "2"


# Generated at 2022-06-21 12:07:20.806335
# Unit test for function no_map_instance
def test_no_map_instance():
    # TODO: This test is not very reliable.
    # Create a list, tuple and dict.
    obj = [1, 2, [3, 4]], {'5': 5}, [6, 7], 8, 9
    # The list, tuple and dict should have structure [[1, 2, [3, 4]], {'5': 5}, [6, 7], 8, 9].
    # Register the list and dict as no_map_instance, then map_structure over it.
    # The result should be [[1, 2, 3], 4, 5, 6, 7, 8, 9].
    # First register the list and dict
    no_map_instance(obj[0])
    no_map_instance(obj[1])
    # Then map_structure, the result should be [1, 2, 3, 4, 5, 6, 7

# Generated at 2022-06-21 12:07:27.316611
# Unit test for function reverse_map

# Generated at 2022-06-21 12:07:38.156649
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # input1
    d1 = {'key1': {'key11': [1, 2, 3]}}
    d2 = {'key1': {'key11': [4, 5, 6]}}
    d3 = {'key1': {'key11': [7, 8, 9]}}

    # expected_output
    d_output = {'key1': {'key11': [12, 15, 18]}}

    # output
    d_result = map_structure_zip(lambda t1, t2, t3: list(map(sum, zip(t1, t2, t3))), [d1, d2, d3])

    assert d_result == d_output


# Generated at 2022-06-21 12:07:47.467038
# Unit test for function reverse_map

# Generated at 2022-06-21 12:07:59.169806
# Unit test for function map_structure
def test_map_structure():
    a = dict(b=1,c=2,d=3)
    b = dict(b=1,c=2,d=3)
    x = map_structure(lambda a,b:a+b, a,b)
    assert dict(b=2,c=4,d=6) == x

    c = dict(b=1,c=2,d=3,e=4)
    x = map_structure(lambda a,b,c:a+b+c, a,b,c)
    assert dict(b=3,c=6,d=9,e=4) == x

    a = (1,2,3)
    b = (3,4,5)
    x = map_structure(lambda a,b:a+b, a,b)

# Generated at 2022-06-21 12:08:08.168119
# Unit test for function no_map_instance
def test_no_map_instance():
    # Test function '_no_map_type'
    lst = no_map_instance(['a', 'b', 'c'])
    assert len(lst) == 3
    assert lst == ['a', 'b', 'c']

    tup = no_map_instance(('d', 'e', 'f'))
    assert len(tup) == 3
    assert tup == ('d', 'e', 'f')

    d = no_map_instance({'d': 1, 'e': 2, 'f': 3})
    assert len(d) == 3
    assert d == {'d': 1, 'e': 2, 'f': 3}

    s = no_map_instance({'d', 'e', 'f'})
    assert len(s) == 3

# Generated at 2022-06-21 12:08:18.265733
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [[1, 2, 3], [4, 5, 6]]
    b = [[10, 11, 12], [13, 14, 15]]
    c = [[20, 21, 22], [23, 24, 25]]
    ans =  [[31, 33, 35], [37, 39, 41]]
    res = map_structure_zip(lambda x, y, z: x + y + z, [a, b, c])
    if res != ans:
        print("ERROR! test_map_structure_zip() failed. "
              "map_structure_zip([a, b, c]) returned %s, but %s was expected." % (str(res), str(ans)))


if __name__ == "__main__":
    test_map_structure_zip()

# Generated at 2022-06-21 12:08:24.124409
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [[1, 2], {1: 2, 3: 4}]
    b = [[3, 4], {1: 3, 3: 5}]
    c = [5, 8]
    d = map_structure_zip(lambda x, y, z: x + y + z, [a, b, c])
    assert d == [[9, 14], {1: 13, 3: 17}]

    a = [[1, 2], {1: 2, 3: 4}]
    b = [[3, 4], {1: 3, 3: 5}]
    c = [5, 8]
    d = map_structure_zip(lambda *args: args, [a, b, c])

# Generated at 2022-06-21 12:08:35.850224
# Unit test for function map_structure
def test_map_structure():
    test_list = [[1, 2, 3], [3, 4, 5]]
    def multiply_list(list_):
        return [i * 2 for i in list_]
    multiplied_list = map_structure(multiply_list, test_list)
    expected_output = [[2, 4, 6], [6, 8, 10]]
    assert multiplied_list == expected_output, 'multiply_list failed'
    test_tuple = ([1, 2, 3], [4, 5, 6])
    test_dict = {'one':[1, 2, 3], 'two':[4, 5, 6]}
    test_set = {([1, 2, 3], [4, 5, 6]), ([7, 8, 9], [10, 11, 12])}

# Generated at 2022-06-21 12:08:44.603905
# Unit test for function map_structure
def test_map_structure():
    a = {'a': 1, 'b': [1, 2], 'c': {'a': 1, 'b': 2}}
    b = {'a': 10, 'b': [10, 20], 'c': {'a': 10, 'b': 20}}

    def fn(x):
        return x + 10

    x = map_structure(fn, a)
    y = {'a': 11, 'b': [11, 12], 'c': {'a': 11, 'b': 12}}
    assert (x == y)

    a = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]]
    b = [[[10, 20], [30, 40]], [[50, 60], [70, 80]]]

    def fn(x, y):
        return x + y



# Generated at 2022-06-21 12:08:53.856019
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from copy import copy, deepcopy
    from torch import Size
    register_no_map_class(Size)
    s = Size([1, 2])
    assert s == map_structure(lambda _: 0, s)
    assert s == copy(s)
    assert s == deepcopy(s)
    # Test that a new method is added to built-in list
    s = [Size([1, 2])]
    assert [Size([1, 2])] == map_structure(lambda _: 0, s)
    assert [Size([1, 2])] == copy(s)
    assert [Size([1, 2])] == deepcopy(s)

# Generated at 2022-06-21 12:09:05.246441
# Unit test for function map_structure
def test_map_structure():
    def double(x):
        return x * 2
    def concat(x, y):
        return ''.join([x,y])
    structure = (1, 'hi', [1, 2, 3], {4: '4', 5: '5'})
    structure_doubled = (2, 'hihi', [2, 4, 6], {4: '44', 5: '55'})
    structure_concat = ('hi1hi', [1, 2, 3, 1, 2, 3], {4: '4', 5: '5', 4: '4', 5: '5'})
    assert structure_doubled == map_structure(double, structure)
    assert structure_concat == map_structure_zip(concat, (structure, structure))

# Generated at 2022-06-21 12:09:15.473257
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def test_fn(x: int, y: str) -> int:
        return x+len(y)
    xs: int = [1, 2, 3]
    ys: str = ["one", "two", "three"]
    xs_expected = [4, 5, 6]
    ys_expected = ["one", "two", "three"]
    xs_actual = map_structure_zip(test_fn, (xs, ys))
    assert xs_actual == xs_expected
    ys_actual = map_structure_zip(test_fn, (ys, xs))
    assert ys_actual == ys_expected


# Generated at 2022-06-21 12:09:17.343924
# Unit test for function register_no_map_class
def test_register_no_map_class():
    register_no_map_class(list)
    assert list in _NO_MAP_TYPES


# Generated at 2022-06-21 12:09:29.219454
# Unit test for function no_map_instance
def test_no_map_instance():
    my_list = ['a', 'b', 'c', 'd']
    my_tuple = (1, 2, 4, 6, 8)
    my_dict = {'name': 'abcde', 'age': 12, 'score': 100}
    my_set = {'a', 'b', 'c', 'd', 'e'}
    
    
    def change_num_positive(x : int) -> int:
        return (-1)*x
    
    def change_alpha_upper(x : str) -> str:
        return x.upper()
    
    print(my_list)
    print("No_map_instance")
    print(no_map_instance(my_list))

# Generated at 2022-06-21 12:09:32.662004
# Unit test for function reverse_map
def test_reverse_map():
    assert reverse_map({'a': 0, 'b': 1, 'c': 2}) == ['a', 'b', 'c']

if __name__ == "__main__":
    test_reverse_map()

# Generated at 2022-06-21 12:09:43.134695
# Unit test for function map_structure
def test_map_structure():
    obj1 = [1, 2, 3]
    obj2 = {}
    obj3 = (1, 2, 3)
    obj4 = [[1, 2], [3, 4]]
    obj5 = (1, [2, 3], {'a': 4, 'b': 5})
    obj6 = {'a': 1, 'b':{'c': 2, 'd': 3}}

    def f(n):
        return n+1

    print(map_structure(f, obj1))
    print(map_structure(f, obj2))
    print(map_structure(f, obj3))
    print(map_structure(f, obj4))
    print(map_structure(f, obj5))
    print(map_structure(f, obj6))




# Generated at 2022-06-21 12:09:55.007252
# Unit test for function map_structure
def test_map_structure():
    list_of_list = [[1, 2], [3, 4], [5, 6]]
    dict_of_list = {'one': [1, 2], 'two':[3, 4], 'three':[5, 6]}
    expected_outcome = [[2, 4], [6, 8], [10, 12]]
    def fn(x):
        return x * 2
    list_of_list_mapped = map_structure(fn, list_of_list)
    assert(list_of_list_mapped == expected_outcome)
    dict_of_list_mapped = map_structure(fn, dict_of_list)
    assert(dict_of_list_mapped == expected_outcome)

    m_list = [[1, 2], [3, 4], [5, 6]]
    n_

# Generated at 2022-06-21 12:10:07.499803
# Unit test for function map_structure_zip
def test_map_structure_zip():
    class A:
        def __init__(self, i, j):
            self.i = i
            self.j = j
    class B(A):
        def __init__(self, i, j, k):
            super().__init__(i, j)
            self.k = k
    class C(A):
        def __init__(self, i, j, k, l):
            super().__init__(i, j)
            self.k = k
            self.l = l
    ret = map_structure_zip(lambda a, b, c: a if a.i != -1 else (b if b.i != -1 else c), [[], [], []])
    assert ret is None

# Generated at 2022-06-21 12:10:19.190151
# Unit test for function map_structure
def test_map_structure():
    import torch

    class ListWithMap(list):
        @classmethod
        def from_list(cls, obj):
            return cls(x.cpu() for x in obj)

        def to_list(self):
            return list(x.cpu() for x in self)

        def __eq__(self, other):
            return self.to_list() == other

    class Test1(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.hidden_size = 5
            self.ffn = torch.nn.Linear(10, self.hidden_size)

# Generated at 2022-06-21 12:10:24.189370
# Unit test for function map_structure_zip
def test_map_structure_zip():
    objs = [[1, 2], [3, 4], [5, 6], [7, 8]]
    print(map_structure_zip(list, objs))


if __name__ == '__main__':
    test_map_structure_zip()

# Generated at 2022-06-21 12:10:28.507489
# Unit test for function map_structure
def test_map_structure():
    t = {'hello': [1,2,3], 'w': [1,2]}
    def map_fn(x):
        return x
    mapped = map_structure(map_fn, t)
    assert t['hello'] == mapped['hello']
    assert t['w'] == mapped['w']


# Generated at 2022-06-21 12:10:37.028744
# Unit test for function map_structure
def test_map_structure():
    d = dict(a = dict(b = dict(c = 1, d = 2)), e = 3)
    def test_fn(x):
        return x + 1
    # In this test case, the whole dictionary will be changed
    print(map_structure(test_fn, d))

    d = dict(a = dict(b = dict(c = 1, d = 2)), e = 3)
    def test_fn2(x):
        if isinstance(x, dict):
            return map_structure(test_fn2, x)
        else:
            return x + 1
    # In this test case, only the integer values in the dictionary will be changed
    print(map_structure(test_fn2, d))


# Generated at 2022-06-21 12:10:44.753123
# Unit test for function no_map_instance
def test_no_map_instance():
    a = [[[1, 2], [3, [4]]]]
    b = no_map_instance(a)
    assert type(a) == list
    assert type(a[0]) == list
    assert type(a[1]) == list
    assert type(b) == type
    assert type(b[0]) == list
    assert type(b[1]) == list


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:10:50.298524
# Unit test for function reverse_map
def test_reverse_map():
    """Unit test for function reverse_map"""
    words = ['a', 'aardvark', 'abandon', 'abandoning', 'abandonment', 'abbott', 'abbreviated', 'abbreviation',
             'abdomen', 'abdominal', 'abducted']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word

# Generated at 2022-06-21 12:10:58.667102
# Unit test for function register_no_map_class
def test_register_no_map_class():
    # Torch tensor, torch_size is not a subclass of built-in container types
    torch_tensor = torch.rand(1)
    torch_size = torch.Size([1])
    torch_tensor_to_list = map_structure(list, torch_tensor)
    torch_size_to_list = map_structure(list, torch_size)
    # If torch_size cannot be mapped, it will be mapped to list([torch_size]),
    # so torch_size_to_list should be [1]
    assert(torch_size_to_list == [1])
    # If torch_size can be mapped, torch_size_to_list should be [[1], [[1]]]
    assert(torch_tensor_to_list == [[1], [[1]]])
    # Register torch_size as

# Generated at 2022-06-21 12:11:09.789129
# Unit test for function map_structure_zip
def test_map_structure_zip():
    target_d = {'a': {'1': [1, 2], '2': [2, 3]}, 'b': ['1', '2']}
    target_nested_list = [[[1, 2], [2, 3]], ['1', '2']]
    target_nested_tuple = (((1, 2), (2, 3)), ('1', '2'))
    target_list_d_list = [{'1': [1, 2], '2': [2, 3]}, ['1', '2']]
    target_list_d_tuple = [{'1': (1, 2), '2': (2, 3)}, ('1', '2')]
    target_list_tuple_list = [(1, 2), [1, 2], (2, 3), [2, 3]]

   

# Generated at 2022-06-21 12:11:19.848502
# Unit test for function no_map_instance
def test_no_map_instance():
    # Test that when no_map_instance is called, the instance is not affected if it's not a container type
    # However, if the instance is a container type, the instance has to be changed to a new type with the attribute set
    class TestClass():
        def __init__(self):
            self.name = "TestClass"

        def to_string(self):
            print(self.name)

    # Test that instance of a class will not be changed
    tc = TestClass()
    tc_new = no_map_instance(tc)
    assert tc is tc_new

    # Test that the transformation works
    lst = [1, 2, 3]
    lst_new = no_map_instance(lst)
    assert lst is lst_new

# Generated at 2022-06-21 12:11:31.762766
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from tool.utils.torch_extra import assert_equal

    class TensorList(list):
        pass

    t = TensorList([1, 2, 3])
    register_no_map_class(TensorList)
    t2 = no_map_instance(t)
    t3 = map_structure(lambda x: x + 1, t)
    assert_equal(t2, t)
    assert_equal(t3, [2, 3, 4])


if __name__ == '__main__':
    test_register_no_map_class()
    print('pass')

# Generated at 2022-06-21 12:11:33.984614
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 0, 'b': 1, 'c': 2}
    assert reverse_map(d) == ['a','b','c']


# Generated at 2022-06-21 12:11:37.636934
# Unit test for function map_structure
def test_map_structure():
  d = {'a': [1, 2, 3], 'b': [4, 5, 6]}
  def fn(x):
    return x + 1
  d_new = map_structure(fn, d)
  print(d_new)


# Generated at 2022-06-21 12:11:44.655245
# Unit test for function reverse_map

# Generated at 2022-06-21 12:11:54.762536
# Unit test for function map_structure_zip
def test_map_structure_zip():
    struct1 = [{'a':1,'b':2}, 2, 3]
    struct2 = [{'a':4,'b':5}, 6, 7]
    struct3 = [{'a':1,'b':2}, 2, 3]
    struct4 = [{'a':4,'b':5}, 6, 7]

    print(map_structure_zip(lambda x, y: x + y, struct1))
    print(map_structure_zip(lambda x, y, z, w: x + y + z + w, struct1, struct2, struct3, struct4))
    print(map_structure_zip(lambda x, y, z, w: x + y + z + w, struct1, struct2, struct2, struct4))

if __name__ == '__main__':
    test_map

# Generated at 2022-06-21 12:11:59.117854
# Unit test for function reverse_map
def test_reverse_map():
    test_dict = {"a": 1, "b": 2, "c": 3, "d": 2}
    assert (reverse_map(test_dict).__eq__(["a", "d", "b", "c"])) == True

# Generated at 2022-06-21 12:12:03.993425
# Unit test for function no_map_instance
def test_no_map_instance():
    x = [1,2]
    y = no_map_instance(x)
    assert hasattr(x, _NO_MAP_INSTANCE_ATTR)
    assert hasattr(y, _NO_MAP_INSTANCE_ATTR)
    assert x is y
    assert id(x) == id(y)

# Generated at 2022-06-21 12:12:09.266336
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert all([(words[i] == id_to_word[i]) for i in range(len(words))])

test_reverse_map()

 

# Generated at 2022-06-21 12:12:18.501406
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import numpy as np
    import torch

    def add(x: int, y: int) -> int:
        return x + y
    
    a = map_structure_zip(add, [1,2,3], [4,5,6])
    print(type(a))
    print(a)
    b = map_structure_zip(add, [1,2,3], [4,5,6,7])
    print(b)

    def add2(x: np.array, y: np.array) -> np.array:
        return x + y
    
    a1 = np.array(([1,2],[3,4]))
    b1 = np.array(([5,6],[7,8]))

# Generated at 2022-06-21 12:12:27.252727
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def test_f(a, b):
        return a+b

    obj = [[1.0, 2.0], [100.0, 200.0], [1000.0, 2000.0]]
    objs = (obj, obj, obj)
    res = map_structure_zip(test_f, objs)

    expected_res = [[3.0,6.0],[300.0,600.0],[3000.0,6000.0]]
    assert res == expected_res

# Generated at 2022-06-21 12:12:43.692524
# Unit test for function map_structure
def test_map_structure():
    def add_f(x, y):
        return x + y

    def add_g(x):
        return x + 1

    x = map_structure(add_f, [[[1, 2], [3, 4]], [[5, 6], [7, 8]]])
    assert (x == [[[2, 3], [4, 5]], [[6, 7], [8, 9]]])

    y = map_structure(add_g, [[[1, 2], [3, 4]], [[5, 6], [7, 8]]])
    assert (y == [[[2, 3], [4, 5]], [[6, 7], [8, 9]]])

    z = map_structure_zip(add_f, [[[1, 2], [3, 4]], [[5, 6], [7, 8]]])

# Generated at 2022-06-21 12:12:52.332581
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x+1, [1,2,3]) == [2,3,4]
    assert map_structure(lambda x: x+1, {'a':1, 'b':2, 'c':3}) == {'a':2, 'b':3, 'c':4}
    assert map_structure(lambda x: x+1, {'a':1, 'b':2, 'c':{'d':3, 'e':4}}) == {'a':2, 'b':3, 'c':{'d':4, 'e':5}}
    assert map_structure(lambda x: x+x, [[1,2], [3,{'a':4}]]) == [[2,4], [6, {'a':8}]]


# Generated at 2022-06-21 12:13:01.717226
# Unit test for function reverse_map

# Generated at 2022-06-21 12:13:13.820723
# Unit test for function map_structure
def test_map_structure():
    import numpy as np
    import torch
    from allennlp.data import Token
    from allennlp.common.checks import ConfigurationError
    # test for a nested list
    a = [[[1, 2], [3, 4]]]
    result = map_structure(lambda x: np.array(x), a)
    assert isinstance(result[0], list)
    assert isinstance(result[0][0], np.ndarray)
    assert isinstance(result[0][1], np.ndarray)
    # test for nested dict
    a = {"a": {"b": torch.tensor(1), "c": torch.tensor(2)}}
    result = map_structure(lambda x: x + 1, a)
    assert isinstance(result, dict)
    assert isinstance(result["a"], dict)


# Generated at 2022-06-21 12:13:22.099013
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = ['a', 'b', 'c']
    c = [0, 0, 0]
    print(map_structure_zip(lambda x, y, z: x + y + z, [a, b, c]))

    def test(x, y):
        return x + y
    print(map_structure_zip(test, [a, b]))

    a = [(1, 2), (3, 4), (5, 6)]
    b = ['a', 'b', 'c']
    c = [0, 0, 0]
    print(map_structure_zip(lambda x, y, z: x + (y, z), [a, b, c]))

# Generated at 2022-06-21 12:13:28.635886
# Unit test for function reverse_map
def test_reverse_map():
    ids_to_words = ["a", "aardvark", "abandon"]
    words_to_ids = {word: i for i, word in enumerate(ids_to_words)}
    reversed_map = reverse_map(words_to_ids)
    assert(reversed_map == ids_to_words)

if __name__ == "__main__":
    test_reverse_map()

# Generated at 2022-06-21 12:13:30.651213
# Unit test for function register_no_map_class
def test_register_no_map_class():
    register_no_map_class(list)
    register_no_map_class(dict)


# Generated at 2022-06-21 12:13:39.572804
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def add(a, b, c):
        return a + b + c

    assert map_structure_zip(add, [1, 2, 3], [4, 5, 6], [7, 8, 9]) == [12, 15, 18]
    assert map_structure_zip(add, [[[1, 2]], [[3, 4]]], [[[5, 6]], [[7, 8]]], [[[9, 10]], [[11, 12]]]) == [[[15, 18]], [[21, 24]]]

    def add_one(x):
        return x + 1

    assert map_structure(add_one, {'a': 1}) == {'a': 2}

# Generated at 2022-06-21 12:13:42.861945
# Unit test for function map_structure_zip
def test_map_structure_zip():
    d = map_structure_zip(lambda x, y: x + y, [1, 2, 3], [4, 5, 6])
    print(d)

test_map_structure_zip()

# Generated at 2022-06-21 12:13:52.867363
# Unit test for function reverse_map

# Generated at 2022-06-21 12:14:10.423309
# Unit test for function map_structure_zip
def test_map_structure_zip():
    d1 = {'a':1, 'b':2}
    d2 = {'a':[1, 2, 3], 'b':[4, 5, 6], 'c':[7, 8, 9]}
    d3 = map_structure_zip(lambda x, y, z: x + y + z, (d1, d2))
    assert d3 == {'a':[2, 4, 6], 'b':[6, 8, 10], 'c':[7, 8, 9]}
    d3 = map_structure_zip(lambda x, y, z: x + y + z, (d2, d1))
    assert d3 == {'a':[2, 4, 6], 'b':[6, 8, 10], 'c':[7, 8, 9]}

# Generated at 2022-06-21 12:14:19.286863
# Unit test for function reverse_map

# Generated at 2022-06-21 12:14:32.012094
# Unit test for function reverse_map

# Generated at 2022-06-21 12:14:40.311427
# Unit test for function map_structure
def test_map_structure():
    def fn(obj):
        return obj**2

    # Test 1
    nested_list = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]]
    nested_list_str = [[[str(n), str(n+1)], [str(n+2), str(n+3)]], [[str(n+4), str(n+5)], [str(n+6), str(n+7)]]]
    nested_tuple = (((1, 2, 3), (4, 5, 6)), ((7, 8, 9), (10, 11, 12)))

# Generated at 2022-06-21 12:14:51.107814
# Unit test for function map_structure_zip

# Generated at 2022-06-21 12:15:01.888525
# Unit test for function map_structure
def test_map_structure():
    nested_list = [[1, 2], [[3], 4, [5, [[6, 7]]]]]
    nested_tuple = ([1, 2], ([3], 4, [5, ([6, 7], )]))
    nested_dict = {'a': [1, {'b': 2}], 'c': [3, 4, 5]}
    nested_namedtuple = collections.namedtuple('_', ['a', 'b', 'c'])
    nested_namedtuple.__new__.__defaults__ = (None,) * len(nested_namedtuple._fields)

# Generated at 2022-06-21 12:15:14.110781
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import random
    import torch
    from torch.nn import Module
    from torch.utils.data import DataLoader, random_split
    from transformers import AutoTokenizer, AutoModelForSequenceClassification
    from src.data import BertDataset
    from src.model import BertClassifier
    from src.utils import config
    from src.utils.logger import logger

    # tokenizer
    tokenizer = AutoTokenizer.from_pretrained(config.bert_model)

    # bert data loader
    raw_train_set = BertDataset(tokenizer, config.train_path)
    trainset, validset = random_split(raw_train_set, [config.train_size, config.valid_size])

# Generated at 2022-06-21 12:15:22.888249
# Unit test for function map_structure
def test_map_structure():
    # Empty
    assert map_structure(0, ()) == ()
    # 0 dimension
    assert map_structure(0, ()) == ()
    assert map_structure(0, []) == []
    # 1 dimension
    assert map_structure(0, [0, 1, 2]) == [0, 0, 0]
    assert map_structure(0, (0, 1, 2)) == (0, 0, 0)
    assert map_structure(0, (0, 1, [2, 3, 4])) == (0, 0, [0, 0, 0])
    # 2 dimension
    assert map_structure(0, [[0, 1, 2], [3, 4, 5]]) == [[0, 0, 0], [0, 0, 0]]

# Generated at 2022-06-21 12:15:36.307012
# Unit test for function reverse_map

# Generated at 2022-06-21 12:15:45.713535
# Unit test for function no_map_instance
def test_no_map_instance():
    import numpy as np
    example_list = [np.ones(3), np.ones(3), np.ones(3)]
    example_named_tuple = no_map_instance(example_list)
    assert isinstance(example_named_tuple, list)
    assert hasattr(example_named_tuple, "--no-map--")
    assert list(example_named_tuple) == example_list
    example_set = {1, 2, 3}
    example_named_tuple = no_map_instance(example_set)
    assert isinstance(example_named_tuple, set)
    assert hasattr(example_named_tuple, "--no-map--")
    assert set(example_named_tuple) == example_set

# Generated at 2022-06-21 12:16:09.317532
# Unit test for function no_map_instance
def test_no_map_instance():
    # Test normal case
    a = [1,2,3,4]
    no_map_instance(a)
    assert a == [1,2,3,4]
    # Test subclass of list
    class sub_list(list): pass
    a = sub_list([1,2,3,4])
    no_map_instance(a)
    assert a == [1,2,3,4]

# Generated at 2022-06-21 12:16:14.847446
# Unit test for function reverse_map
def test_reverse_map():
    word_to_id = {'a':1, 'b':2, 'c':3}
    id_to_word = reverse_map(word_to_id)
    print(id_to_word)
    assert id_to_word == ['a', 'b', 'c']

# Unit test to function no_map_instance

# Generated at 2022-06-21 12:16:24.258319
# Unit test for function reverse_map
def test_reverse_map():
    try:
        import pytest
    except ImportError as e:
        raise e


# Generated at 2022-06-21 12:16:34.787420
# Unit test for function no_map_instance
def test_no_map_instance():
    import copy
    from typing import NamedTuple
    from allennlp.common.testing import AllenNlpTestCase

    l = [1, 2, 3, ['a', 'b', 'c']]
    l2 = copy.deepcopy(l)
    l2 = no_map_instance(l2)
    assert l == l2

    t = (l, l)
    t2 = copy.deepcopy(t)
    t2 = no_map_instance(t2)
    assert t == t2

    d = {'a': 1, 'b': [1, 2], 'c': [1, 2, (1, 2, 3)]}
    d2 = copy.deepcopy(d)
    d2 = no_map_instance(d2)
    assert d == d2


# Generated at 2022-06-21 12:16:43.182650
# Unit test for function no_map_instance
def test_no_map_instance():
    a = torch.Size([1, 2])
    b = list(range(10))
    c = {'a': a, 'b': b}
    d = [a, b, c]
    a_ = no_map_instance(a)
    b_ = no_map_instance(b)
    c_ = no_map_instance(c)
    d_ = no_map_instance(d)

    def fn(x):
        return str(x)
        
    assert fn(map_structure(lambda x:x, a_))=='torch.Size([1, 2])'
    assert fn(map_structure(lambda x:x, b_))=='[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'

# Generated at 2022-06-21 12:16:48.083328
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    b = no_map_instance([4, 5, 6])
    c = [a, b]
    d = map_structure(lambda x: x, c)
    e = map_structure(lambda x: x, d)
    assert c == d == e