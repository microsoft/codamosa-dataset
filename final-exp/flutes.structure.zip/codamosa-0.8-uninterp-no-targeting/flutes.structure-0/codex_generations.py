

# Generated at 2022-06-21 12:07:22.742230
# Unit test for function map_structure
def test_map_structure():
    def make_container_instance(container_type: Type[T], *args: Sequence[T]) -> T:
        # This is necessary because the container types in
        # `map_structure` (i.e. `tuple`, `list`, `dict`) do not
        # accept `float` keys or values.
        if container_type is dict:
            return container_type({k: v for k, v in args})
        if container_type is set:
            return container_type(args)
        return container_type(args)

    def test_make_container_instance(container_type: Type[T], obj: T) -> None:
        """Ensure that `make_container_instance` returns something with the same type and structure as the original object."""
        assert isinstance(obj, container_type)

# Generated at 2022-06-21 12:07:25.897891
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class ListLike(list):
        pass
    
    register_no_map_class(ListLike)

    def fn(lst):
        return [i for i in lst]

    assert map_structure(fn, ListLike([[1, 2, 3]])) == [[1, 2, 3]]
    
test_register_no_map_class()

# Generated at 2022-06-21 12:07:37.733838
# Unit test for function map_structure
def test_map_structure():
    print ( "Testing function map_structure...")
    print ("Case 1: Test recursive mapping")
    def ut(x):
        return x

    l1 = [(1, 2), 3, 4]
    l2 = [5, (1, 2)]
    assert map_structure(ut, l1) == l1
    assert map_structure(ut, l2) == l2
    t1 = (1, [2, 3])
    assert map_structure(ut, t1) == t1
    from collections import OrderedDict
    d1 = OrderedDict([('a', 1), ('b', (2, 3))])
    assert map_structure(ut, d1) == d1
    print ("\tPASSED")



# Generated at 2022-06-21 12:07:47.193455
# Unit test for function map_structure_zip
def test_map_structure_zip():
    
    from collections import namedtuple
    
    test_case = namedtuple("test_case", ("fn", "result", "label"))

# Generated at 2022-06-21 12:07:50.549246
# Unit test for function register_no_map_class
def test_register_no_map_class():

    class Foo(list):
        pass

    assert Foo not in _NO_MAP_TYPES
    register_no_map_class(Foo)
    assert Foo in _NO_MAP_TYPES

# Generated at 2022-06-21 12:08:02.099722
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class DummyClass:
        pass
    class DummyClass2(list):
        pass
    obj1 = DummyClass()
    obj2 = DummyClass2()
    obj3 = list()
    register_no_map_class(DummyClass)
    register_no_map_class(DummyClass2)
    assert not hasattr(obj1, _NO_MAP_INSTANCE_ATTR)
    assert not hasattr(obj2, _NO_MAP_INSTANCE_ATTR)
    assert not hasattr(obj3, _NO_MAP_INSTANCE_ATTR)
    register_no_map_class(DummyClass)
    register_no_map_class(DummyClass2)
    assert obj1.__class__ in _NO_MAP_TYPES
    assert obj2.__class__ in _NO

# Generated at 2022-06-21 12:08:10.703531
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import numpy as np
    a = np.array([1,2,3])
    b = np.array([3,3,3])
    out = map_structure_zip(lambda x,y:x+y, [a,b])
    assert(np.array_equal(out, np.array([4,5,6])))

    # Maps a numpy array and a list
    c = [1,2,3]
    d = np.array([3,3,3])
    out = map_structure_zip(lambda x,y: x+y, [c,d])
    assert(np.array_equal(out, np.array([4,5,6])))


    # Map into a list
    e = [1,2,3]
    f = [4,5,6]
    out

# Generated at 2022-06-21 12:08:19.447251
# Unit test for function no_map_instance
def test_no_map_instance():
    # Check that it doesn't affect unpacked lists
    x = [1, 2, 3]
    x_ = no_map_instance(x)
    assert (x == x_) == True
    assert x[0] == 1
    assert x[1] == 2
    assert x[2] == 3

    # Check that it doesn't affect unpacked tuples
    y = (1, 2, 3)
    y_ = no_map_instance(y)
    assert (y == y_) == True
    assert y[0] == 1
    assert y[1] == 2
    assert y[2] == 3

    # Check that it doesn't affect unpacked dicts
    z = {"a" : 1, "b" : 2, "c" : 3}
    z_ = no_map_instance(z)

# Generated at 2022-06-21 12:08:30.357327
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn1(x, y, z):
        return x + y + z
    def fn2(x, y, z):
        return x * y + z
    x = [1, 2, 3]
    x1 = [[1, 2, 3], [1, 2, 3], [1, 2, 3]]
    x2 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    x3 = [[1, 2, 3], [4, 5, 6], [7, 8, 9], [7, 8, 9]]
    x4 = [[1, 2, 3], [4, 5, 6], [7, 8, 9], {'a': 1, 'b':2}]

    print(map_structure_zip(fn1, [x, x, x]))

# Generated at 2022-06-21 12:08:32.501574
# Unit test for function reverse_map
def test_reverse_map():
    assert reverse_map(dict(zip(['a', 'b', 'c', 'd'], range(4)))) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-21 12:08:42.030368
# Unit test for function map_structure
def test_map_structure():
    import torch
    import numpy as np
    a = torch.tensor([1,2])
    b = torch.tensor([3,4])
    c = np.array([1,2])
    d = np.array([3,4])
    assert map_structure(lambda x: x * 2, a) == a * 2
    assert map_structure(lambda x, y: x + y, a, b) == a + b
    assert map_structure(lambda x: x * 2, c) == c *2
    assert map_structure(lambda x, y: x + y, c, d) == c + d

# Generated at 2022-06-21 12:08:45.036084
# Unit test for function no_map_instance
def test_no_map_instance():
    obj = no_map_instance([1,2,3])
    assert hasattr(obj, '__iter__')
    assert hasattr(obj, _NO_MAP_INSTANCE_ATTR)


if __name__ == '__main__':
    test_no_map_instance()

# Generated at 2022-06-21 12:08:51.986159
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y
    objs = [{'id': 1, 'name': 'a'}, {'id': 2, 'name': 'b'}]

    expect_objs = {'id': 3, 'name': 'ab'}
    actual_objs = map_structure_zip(fn, objs)
    assert actual_objs == expect_objs, "Fail to pass map_structure_zip function test"



# Generated at 2022-06-21 12:08:59.824501
# Unit test for function register_no_map_class
def test_register_no_map_class():

    def test_fn(val):
        return 2*val

    class TestType(list):
        pass

    t = TestType([1,2,3])
    print(map_structure(test_fn, t))

    register_no_map_class(TestType)
    print(map_structure(test_fn, t))

    d = {'x': 1}
    print(map_structure(test_fn, d))

    register_no_map_class(dict)
    print(map_structure(test_fn, d))


# Generated at 2022-06-21 12:09:10.535159
# Unit test for function map_structure
def test_map_structure():
    b1 = [1,2,3]
    b2 = [4,5,6]
    b3 = [7,8,9]
    def add(b1, b2):
        return [b1[i]+b2[i] for i in range(len(b1))]
    print(add(b1,b2))
    print(map_structure_zip(add, [b1,b2]))
    print(map_structure_zip(add, [b1,b2,b3]))
    """
    [5, 7, 9]
    [5, 7, 9]
    [12, 15, 18]
    """
    return

# Generated at 2022-06-21 12:09:20.719271
# Unit test for function map_structure
def test_map_structure():
    import numpy as np
    from torch.autograd import Variable
    x = {'a': np.array([1, 2], dtype=float), 'b': Variable(torch.randn(2, 3))}
    y = map_structure(lambda x: x, x)
    assert isinstance(y['a'], np.ndarray)
    assert isinstance(y['b'], Variable)

    x = {'a': np.array([1, 2], dtype=float), 'b': Variable(torch.randn(2, 3))}
    y = map_structure(lambda x: x.data, x)
    assert isinstance(y['a'], np.ndarray)
    assert isinstance(y['b'], torch.Tensor)


# Generated at 2022-06-21 12:09:25.721220
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'abandoned']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word


# Generated at 2022-06-21 12:09:37.024494
# Unit test for function map_structure
def test_map_structure():
    l = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    d = [{1, 2, 3}, {4, 5, 6}, {7, 8, 9, 0}]
    t = ('a', ('b', ('c', ('d', ('e', ('f', ('g', ('h', ('i', ('j',))))))))))
    dd = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 5, 'b': 6}]
    dt = [{'a': '1', 'b': '2'}, {'a': '3', 'b': '4'}, {'a': '5', 'b': '6'}]

# Generated at 2022-06-21 12:09:46.067925
# Unit test for function no_map_instance
def test_no_map_instance():
    l = [1, 2, 3]
    l1 = no_map_instance([1, 2, 3])
    l2 = no_map_instance(l)
    print(l1)
    assert(l1 is not l and l2 is l)

    d = {'a': [1, 2, 3]}
    d1 = no_map_instance({'a': [1, 2, 3]})
    d2 = no_map_instance(d)
    print(d1)
    assert(d1 is not d and d2 is d)

    t = (1, 2, 3)
    t1 = no_map_instance((1, 2, 3))
    t2 = no_map_instance(t)
    print(t1)
    assert(t1 is not t and t2 is t)

   

# Generated at 2022-06-21 12:09:57.909204
# Unit test for function map_structure

# Generated at 2022-06-21 12:10:12.745820
# Unit test for function reverse_map
def test_reverse_map():
    # The number of items in the words file is around 100k
    words = ['a', 'aardvark', 'abandon', 'ability', 'able', 'about', 'above', 'above', 'above', 'above', 'above', 'above', 'above', 'abstain']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word


# https://stackoverflow.com/questions/50728328/how-to-inject-a-python-class-method-with-a-unit-test

# Generated at 2022-06-21 12:10:24.639865
# Unit test for function no_map_instance
def test_no_map_instance():
    import numpy as np
    def test_list(l, r):
        r_list = []
        for i in range(5):
            r_list.append(l * i * r)
        return r_list

    def test_tuple(l, r):
        r_tuple = ()
        for i in range(5):
            r_tuple += (l * i * r,)
        return r_tuple
    def test_dict(l, r):
        r_dict = {}
        for i in range(5):
            r_dict[i] = l * i * r
        return r_dict

    def test_array(l, r):
        r_array = np.array([0] * 5)
        for i in range(5):
            r_array[i] = l * i * r

# Generated at 2022-06-21 12:10:34.458055
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance([1, 1, [1, 2]]) == ([1, 1, [1, 2]],)
    assert no_map_instance([]) == ([],)
    assert no_map_instance(1) == 1
    assert no_map_instance('a') == 'a'
    assert no_map_instance((1, 2)) == ((1, 2),)
    assert no_map_instance((1, [1, 2])) == (1, [1, 2])
    assert no_map_instance(((1, 2),)) == (((1, 2),),)
    assert no_map_instance(((1, (2,)), [1, 2])) == ((1, (2,)), [1, 2])

# Generated at 2022-06-21 12:10:46.397362
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Test cases:
    # 1. A is list of lists, B is list of tuples and C is list of lists
    # 2. A is list of tuples, B is list of lists, C is list of lists
    # 3. A is list of lists, B is list of lists, C is list of tuples
    A = [1,2,3]
    B = [(1,2),(3,4),(5,6)]
    C = [1,2,3,4]
    expected_results = [4,16,62]
    def test(a,b,c):
        return a+b[0]+b[1]+c
    results = map_structure_zip(test, [A,B,C])
    assert results == expected_results

# Generated at 2022-06-21 12:10:50.190565
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = 1
    b = [1, 2, {1: 1}]
    c = (1, 2, [2, 3])

    def func(*args):
        return sum(args)

    result = map_structure_zip(func, [a, b, c])
    # print(result)
    assert result == 4

# Generated at 2022-06-21 12:10:57.024419
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'abandoned']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word

    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word

if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-21 12:11:08.109919
# Unit test for function map_structure
def test_map_structure():
    x1 = namedtuple('x1', 'a b c')
    x2 = namedtuple('x2', 'a b c')
    x3 = namedtuple('x3', 'a b c')
    value = [x1(1, x2(1, x3(1, 1, 1), 2), 3), x1(4, x2(5, x3(6, 7, 8), 9), 10), x1(11, x2(12, x3(13, 14, 15), 16), 17)]
    result = map_structure(lambda x: x, value)
    assert result == value
    result = map_structure(lambda x: x + 1, value)

# Generated at 2022-06-21 12:11:18.227702
# Unit test for function no_map_instance
def test_no_map_instance():
    # Test essential functions of no_map_instance()
    a_list = [1, 2, 3]
    a_list_nm = no_map_instance(a_list)
    assert a_list_nm == a_list
    assert hasattr(a_list_nm, _NO_MAP_INSTANCE_ATTR)

    a_tuple = (1, 2, 3)
    a_tuple_nm = no_map_instance(a_tuple)
    assert a_tuple_nm == a_tuple
    assert hasattr(a_tuple_nm, _NO_MAP_INSTANCE_ATTR)

    a_dict = {'a': 1, 'b': 2, 'c': 3}
    a_dict_nm = no_map_instance(a_dict)

# Generated at 2022-06-21 12:11:22.452310
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(a, b):
        return str(a)+str(b)
    objs = [{'a':'a', 'b':'b'}, {'a':1, 'b':2}]
    print(map_structure_zip(fn, objs))


# Generated at 2022-06-21 12:11:30.732750
# Unit test for function map_structure_zip
def test_map_structure_zip():
    A = [1,2,{'a':1,'b':2},[0,1,2]]
    B = [1,2,{'a':1,'b':2},[0,1,3]]
    C = [1,2,{'a':1,'b':3},[0,1,2]]
    # A and B's structure are the same, 
    # but A and C is different
    result = map_structure_zip(lambda a,b:a==b, [A,B])
    print(result)
    # result = map_structure_zip(lambda a,b:a==b, [A,C])

# Generated at 2022-06-21 12:11:41.345642
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'abandoned', 'abbreviation', 'abdication', 'abdomen', 'abdominal', 'aberration', 'ability']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word, words

if __name__ == '__main__':
    test_reverse_map()

# Generated at 2022-06-21 12:11:43.179316
# Unit test for function register_no_map_class
def test_register_no_map_class():
    register_no_map_class(list)
    assert list in _NO_MAP_TYPES



# Generated at 2022-06-21 12:11:53.722860
# Unit test for function map_structure
def test_map_structure():
    # Test for map_structure
    def fn1(value):
        return value + 2


    def fn2(value):
        return value * 3


    def fn3(value):
        return value / 2


    class TestClass:
        def __init__(self, value):
            self.value = value


        def __call__(self, value):
            return self.value + value


    def test_map_structure_list(list_in, list_out):
        list_in1 = map_structure(fn1, list_in)
        list_in2 = map_structure(fn2, list_in1)
        list_in3 = map_structure(fn3, list_in2)
        assert list_in3 == list_out



# Generated at 2022-06-21 12:11:55.677950
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a':0, 'b':1, 'c':2, 'd':3}
    r = reverse_map(d)
    print(r)


# Generated at 2022-06-21 12:11:59.969515
# Unit test for function reverse_map
def test_reverse_map():
    print("Unit tests for function reverse_map.")
    x = {'a': 1, 'b': 3, 'c': 2}
    print(reverse_map(x))
    print()


# Generated at 2022-06-21 12:12:05.262346
# Unit test for function map_structure_zip
def test_map_structure_zip():

    a = [[1,2,3,4], [1,2,3,4]]

    b = list(map(lambda x: x + 1, a))

    c = list(map_structure_zip(lambda x, y:x + y , a))

    print(b)
    print(c)
    assert b == c



# Generated at 2022-06-21 12:12:11.627712
# Unit test for function reverse_map
def test_reverse_map():
    words = ['a', 'aardvark', 'abandon', 'ability', 'able', 'about', 'about', 'about']
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    print("reverse_map(word_to_id)", id_to_word)


# Generated at 2022-06-21 12:12:18.002861
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = {'name':'a', 'age':'18', 'sex':'female'}
    b = {'name':'b', 'age':'19', 'sex':'male'}
    c = {'name':'c', 'age':'20', 'sex':'male'}
    mp = map_structure_zip(lambda x,y,z:x+y+z, [a,b,c])
    print(mp)
    return mp


if __name__ == '__main__':
    test_map_structure_zip()

# Generated at 2022-06-21 12:12:27.511801
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Test:
        def __init__(self, x):
            self.x = x
        def __str__(self):
            return 'Test{' + str(self.x) + '}'
    @register_no_map_class
    class TestNoMap(Test):
        def __init__(self, x):
            super().__init__(x)

    def double(x):
        return x*2
    t = TestNoMap(3)
    t1 = map_structure(double, t)
    assert t1 == Test(6)

# Generated at 2022-06-21 12:12:36.274078
# Unit test for function no_map_instance
def test_no_map_instance():
    xs = [[1, 2], [3, 4]]
    ys = no_map_instance([[1, 2], [3, 4]])
    ys[0][0] = 5
    assert xs[0][0] == 1
    assert ys[0][0] == 5
    xs = (1, 2)
    ys = no_map_instance((1, 2))
    ys = (5, ys[1])
    assert ys[0] == 5
    assert xs[0] == 1


# Generated at 2022-06-21 12:12:51.905615
# Unit test for function map_structure_zip
def test_map_structure_zip():
    K = 2
    def fn(a, b):
        return a + b
    objs = [{i:list(range(K)) for i in range(K)} for i in range(K)]

    zipped_dict = map_structure_zip(fn, objs)
    for key in range(K):
        for k in range(K):
            assert zipped_dict[key][k] == sum(objs[i][key][k] for i in range(K))


# Generated at 2022-06-21 12:13:00.282630
# Unit test for function map_structure
def test_map_structure():
    def fn(x):
        return x + 1

    x = [1, 2, 3]
    print(map_structure(fn, x))

    x = [1, [2, 3], [[4], 5]]
    print(map_structure(fn, x))

    x = [[1, 2, 3], [4, 5]]
    print(map_structure(fn, x))

    x = (1, [2, 3], [[4], 5])
    print(map_structure(fn, x))

    x = (1, 2, 3)
    print(map_structure(fn, x))

    x = {"foo":1, "bar":(2, 3), "baz":{"a":4, "b":5}}
    print(map_structure(fn, x))


# Generated at 2022-06-21 12:13:04.760956
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x + 1, [1, 2, 3, 4]) == [2, 3, 4, 5]
    assert map_structure(lambda x: x + 2, (1, 2, 3, 4)) == (3, 4, 5, 6)
    assert map_structure(lambda x: x + 3, {"A": 1, "B": 2, "C": 3}) == {"A": 4, "B": 5, "C": 6}



# Generated at 2022-06-21 12:13:17.079094
# Unit test for function no_map_instance
def test_no_map_instance():
    input = {}
    assert not no_map_instance(input)
    assert not isinstance(input, dict)
    assert (no_map_instance(input) == input)

    input = []
    assert not no_map_instance(input)
    assert not isinstance(input, list)
    assert (no_map_instance(input) == input)

    class A:
        def __init__(self, a:str):
            self.a = a
        def __eq__(self, other):
            return self.a == other.a

    input = [1, 2, A('a')]
    assert not no_map_instance(input)
    assert not isinstance(input, list)
    assert (no_map_instance(input) == input)


# Generated at 2022-06-21 12:13:28.866255
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = [4, 5, 6]
    result = [5, 7, 9]
    assert map_structure_zip(lambda x, y: x + y, [a, b]) == result

    # Nested list
    a = [1, 2, [3, 4]]
    b = [4, 5, [6, 7]]
    result = [5, 7, [9, 11]]
    assert map_structure_zip(lambda x, y: x + y, [a, b]) == result

    # Mixed nested list
    a = [1, 2, [3, 4]]
    b = [4, 5, 6]
    result = [5, 7, [9, 10]]

# Generated at 2022-06-21 12:13:39.734525
# Unit test for function map_structure
def test_map_structure():
    import random
    import re
    import torch

    def test_map_structure_fn(d):
        assert(d['a'] == 1)
        assert(d['b'] == 2)
        assert(d['c'] == 3)
        # print(d)

    # test multiple nesting
    test_map_structure_fn(map_structure(lambda x: x, {'a': 1, 'b': 2, 'c': 3}))
    test_map_structure_fn(map_structure(lambda x: x, [{'a': 1, 'b': 2, 'c': 3}]))
    test_map_structure_fn(map_structure(lambda x: x, [[{'a': 1, 'b': 2, 'c': 3}]]))
    test_map_structure_fn

# Generated at 2022-06-21 12:13:46.145358
# Unit test for function reverse_map
def test_reverse_map():
    words = 'I am a big aardvark'.split()
    word_to_id = {word: idx for idx, word in enumerate(words)}
    id_to_word = reverse_map(word_to_id)
    assert words == id_to_word

if __name__ == "__main__":
    test_reverse_map()

# Generated at 2022-06-21 12:13:47.855556
# Unit test for function reverse_map
def test_reverse_map():
    states = ['a', 'b', 'c']
    state_to_id = {state: idx for idx, state in enumerate(states)}
    id_to_state = reverse_map(state_to_id)
    assert states == id_to_state


# Generated at 2022-06-21 12:13:53.358331
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class Container(list):
        def __init__(self, test):
            self.test = test
    class MyContainer(Container):
        pass
    register_no_map_class(Container)
    assert (map_structure(lambda x: x+1, [Container([1, 2, 3]), MyContainer([2, 3, 4])]) == [Container([2, 3, 4]), MyContainer([2, 3, 4])])


# Generated at 2022-06-21 12:13:56.362468
# Unit test for function reverse_map
def test_reverse_map():
    d = {'a': 1, 'b': 0, 'c': 2, 'd': 3}
    assert reverse_map(d) == ['b', 'a', 'c', 'd']

# Generated at 2022-06-21 12:14:06.939242
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance(list())
    b = no_map_instance(list())
    assert a == b
    assert a[0] != b[0]

# Generated at 2022-06-21 12:14:14.457482
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Prepare
    class MyDict(dict):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    def fn(x: int, y: str) -> str:
        return f"{x}:{y}"

    def fn2(x: int, y: str, z: MyDict) -> str:
        return f"{x}:{y}:{str(z)}"

    # Test
    a = [1, 2, 3]
    b = ['a', 'b', 'c']
    assert map_structure_zip(fn, [a, b]) == ['1:a', '2:b', '3:c']

# Generated at 2022-06-21 12:14:17.720196
# Unit test for function reverse_map
def test_reverse_map():
	dict_1 = {1:1, 2:2, 3:3, 4:4}
	assert reverse_map(dict_1) == [1, 2, 3, 4]

if __name__ == '__main__': 
	test_reverse_map()

# Generated at 2022-06-21 12:14:24.154575
# Unit test for function register_no_map_class
def test_register_no_map_class():
    import torch
    a = torch.Size([1,2])
    register_no_map_class(a.__class__)
    assert map_structure(lambda x: x, a) == a
    assert map_structure_zip(lambda x, y: x, [a, a]) == a
    b = torch.Size([1,2])
    assert map_structure_zip(lambda x, y: x, [b, b]) == b
### END ###

# Generated at 2022-06-21 12:14:35.998735
# Unit test for function map_structure
def test_map_structure():
    from torch.nn.utils.rnn import PackedSequence
    n = 2
    input = [1, 2, 3]
    obj = {
        'a': [{'a': input, 'b': input}, {'a': input, 'b': input}],
        'b': PackedSequence(torch.tensor(input),
                            torch.tensor([3, 3, 4])),
        'c': torch.tensor(input),
    }
    output = map_structure(lambda x: x * n, obj)

    assert (output['a'][0]['a'] == [1 * n, 2 * n, 3 * n])
    assert (output['a'][0]['b'] == [1 * n, 2 * n, 3 * n])

# Generated at 2022-06-21 12:14:41.120352
# Unit test for function no_map_instance
def test_no_map_instance():
    # case1: instance of built-in type, e.g. `list`, `dict`
    l1 = [1, 2, 3]
    l2 = no_map_instance(l1)
    assert id(l1) == id(l2), "No_map_instance should return the same instance for built-in container type"

    d1 = {'a': 'b'}
    d2 = no_map_instance(d1)
    assert id(d1) == id(d2), "No_map_instance should return the same instance for built-in container type"

    # case2: instance of object type
    class MyClass:
        def __init__(self, x):
            self.x = x
    c1 = MyClass(100)
    c2 = MyClass(100)

# Generated at 2022-06-21 12:14:51.659006
# Unit test for function reverse_map

# Generated at 2022-06-21 12:14:58.756854
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import namedtuple
    from typing import List, Tuple

    nt1 = namedtuple('nt1', ['no_map', 'field1', 'field2'])
    lst = [nt1(['a', 'b', 'c'], 1, 2), nt1(['a', 'b', 'c'], 2, 3)]

    def func(i: Tuple[List[str], int, int]):
        return i[0][0] + str(i[1])

    assert map_structure(func, lst) == ['a1', 'a2']  # without no_map_instance
    lst = no_map_instance(lst)

# Generated at 2022-06-21 12:15:02.288337
# Unit test for function reverse_map
def test_reverse_map():
    for i in range(10):
        d = {str(i): i for i in range(i)}
        l = [str(i) for i in range(i)]

        assert(reverse_map(d) == l)


# Generated at 2022-06-21 12:15:06.831587
# Unit test for function reverse_map
def test_reverse_map():
    d = {1: 0, 2: 1, 5: 2, 10: 3, 20: 4}
    dd = {0: 1, 1: 2, 2: 5, 3: 10, 4: 20}
    assert dd == reverse_map(d)
    return


# Generated at 2022-06-21 12:15:20.330680
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import numpy as np
    list_input = [[1,2],[3,4],[5,6]]
    tuple_input = ([1,2],[3,4],[5,6])
    numpy_input = np.array(list_input)
    map_structure_zip(sum,list_input)
    map_structure_zip(sum,tuple_input)
    map_structure_zip(sum,numpy_input)

# Generated at 2022-06-21 12:15:28.311626
# Unit test for function map_structure
def test_map_structure():
    from pytorch_transformers import PreTrainedTokenizer, XLNetTokenizer

    tokenizer = XLNetTokenizer.from_pretrained('xlnet-base-cased')
    _map_structure = map_structure
    # Test for function _map_structure_recursive
    def map_structure(fn, obj):
        return _map_structure(fn, obj)

    class Example:
        def __init__(self, tokenizer):
            self.tokenizer = tokenizer

    def getInstance(obj):
        if isinstance(obj, list):
            return [getInstance(x) for x in obj]
        if isinstance(obj, tuple):
            return tuple(getInstance(x) for x in obj)

# Generated at 2022-06-21 12:15:33.825733
# Unit test for function map_structure
def test_map_structure():
    from collections import OrderedDict
    import torch

    namedtuple = torch.utils.data.Enum(
        'NamedTuple', x=0, y=1, z=2
    )
    input_list = [
        [namedtuple(1, 2, 3), namedtuple(4, 5, 6)],
        [namedtuple(7, 8, 9), namedtuple(10, 11, 12)],
        [namedtuple(13, 14, 15), namedtuple(16, 17, 18)],
    ]

# Generated at 2022-06-21 12:15:39.606722
# Unit test for function register_no_map_class
def test_register_no_map_class():
    register_no_map_class(tuple)
    a = (1,2,3)
    b = no_map_instance(a)
    assert (a == b)
    assert (isinstance(b, tuple))
    assert (hasattr(b, '--no-map--'))


# Generated at 2022-06-21 12:15:44.157999
# Unit test for function register_no_map_class
def test_register_no_map_class():
    class TestList(list):
        def __init__(self, l: List[int]) -> None:
            super().__init__(l)
    register_no_map_class(TestList)
    ret = map_structure(lambda x: x + 10, TestList([0, 1, 2]))
    expected = TestList([10, 11, 12])
    assert ret == expected


# Generated at 2022-06-21 12:15:56.000468
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # simple test case
    obj = [1, 2, 3]
    result = map_structure_zip(sum, [[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    assert result == [12, 15, 18]
    assert result.__class__ == obj.__class__
    # test case with nested structure
    obj = {1: {'a': 1, 'b': 2}, 2: {'c': 3, 'd': 4}}
    result = map_structure_zip(sum, [obj, obj])
    assert result == {1: {'a': 2, 'b': 4}, 2: {'c': 6, 'd': 8}}
    assert result.__class__ == obj.__class__
    # test case with namedtuple
    from collections import namedtuple
   

# Generated at 2022-06-21 12:16:08.151928
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # map_structure_zip with function of 1 input
    test_tuple = (1,2,3)
    test_list = [1,2,3]
    test_dict = {'a':1, 'b':2, 'c':3}
    result = map_structure_zip(lambda x: x*2, [test_tuple, test_list])
    assert result == (2,4,6)
    result = map_structure_zip(lambda x: x*2, [test_list, test_dict])
    assert result == {'a': 2, 'b': 4, 'c': 6}

    # map_structure_zip with function of 2 inputs
    result = map_structure_zip(lambda x,y: x-y, [test_tuple, test_list])

# Generated at 2022-06-21 12:16:18.973003
# Unit test for function map_structure
def test_map_structure():
    # List of int
    l_int = [1, 2, 3]
    l_int_res = map_structure(lambda x: x * 2, l_int)
    assert l_int_res == [2, 4, 6]
    # List of list of int
    l_l_int = [[1, 2], [3, 4]]
    l_l_int_res = map_structure(lambda x: x * 2, l_l_int)
    assert l_l_int_res == [[2, 4], [6, 8]]
    # Dict of int
    d_int = {1: 2, 3: 4}
    d_int_res = map_structure(lambda x: x * 2, d_int)
    assert d_int_res == {1: 4, 3: 8}
   

# Generated at 2022-06-21 12:16:26.942546
# Unit test for function map_structure
def test_map_structure():
    from collections import OrderedDict
    from collections import namedtuple
    from itertools import product

    class TestClass(object):
        def __init__(self):
            self.int_col = [1, 2, 3, 4]
            self.int_val = 10
            self.dict_col = {'a': 1, 'b': 2}
            self.dict_val = {'c': 3, 'd': 4}
            self.list_col = [[1, 2], [3, 4]]
            self.list_val = [5, 6]
            self.set_col = {1, 2}
            self.set_val = {3, 4}
            self.tuple_col = ((1, 2), (3, 4))
            self.tuple_val = (5, 6)

# Generated at 2022-06-21 12:16:32.074755
# Unit test for function no_map_instance
def test_no_map_instance():
    #test function of no_map_instance
    # the normal case
    assert no_map_instance([1,2,3]) == [1,2,3]

    # the exception case
    with pytest.raises(TypeError):
        no_map_instance(set([1,2,3]))
        no_map_instance((1,2,3))


# Generated at 2022-06-21 12:16:44.335262
# Unit test for function reverse_map
def test_reverse_map():
    d = {
        'a': 0,
        'b': 1,
        'c': 2,
        'd': 3,
    }
    assert reverse_map(d) == ['a', 'b', 'c', 'd']



# Generated at 2022-06-21 12:16:54.146736
# Unit test for function map_structure_zip
def test_map_structure_zip():
    TestList = []
    TestList.append({'name':'t1', 'tlist':[1,2,3], 'tdict':{'k1':'v1', 'k2':'v2'}, 'tset':set([4,5,6])})
    TestList.append({'name':'t6', 'tlist':[4,5,6], 'tdict':{'k3':'v3', 'k4':'v4'}, 'tset':set([7,8,9])})
    TestList.append({'name':'t11','tlist':[7,8,9],'tdict':{'k5':'v5', 'k6':'v6'},'tset':set([-1,-2,-3])})


# Generated at 2022-06-21 12:17:01.360154
# Unit test for function register_no_map_class
def test_register_no_map_class():
    from torch.Size import register_no_map_class
    register_no_map_class(torch.Size)
    assert isinstance(torch.Size([2, 3]), no_map_instance(torch.Size))
    assert torch.Size([1]) == map_structure(lambda x: x+3, no_map_instance(torch.Size([1])))
    assert map_structure_zip(lambda x,y: x+y, [no_map_instance(torch.Size([1])), no_map_instance(torch.Size([1]))]) == no_map_instance(torch.Size([2]))

# Generated at 2022-06-21 12:17:08.558628
# Unit test for function register_no_map_class