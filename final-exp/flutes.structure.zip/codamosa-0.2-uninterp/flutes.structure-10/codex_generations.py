

# Generated at 2022-06-17 18:40:54.941692
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = [10, 11, 12]
    e = [13, 14, 15]
    f = [16, 17, 18]
    g = [19, 20, 21]
    h = [22, 23, 24]
    i = [25, 26, 27]
    j = [28, 29, 30]
    k = [31, 32, 33]
    l = [34, 35, 36]
    m = [37, 38, 39]
    n = [40, 41, 42]
    o = [43, 44, 45]
    p = [46, 47, 48]
    q = [49, 50, 51]
    r = [52, 53, 54]
   

# Generated at 2022-06-17 18:40:59.946895
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    b = no_map_instance(a)
    assert a == b
    assert a is b
    assert a[0] == 1
    assert a[1] == 2
    assert a[2] == 3
    assert a[0] is 1
    assert a[1] is 2
    assert a[2] is 3
    assert a[0] is b[0]
    assert a[1] is b[1]
    assert a[2] is b[2]

# Generated at 2022-06-17 18:41:07.897202
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(a, b):
        return a + b

    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = map_structure_zip(fn, [a, b, c])
    assert d == [12, 15, 18]

    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = map_structure_zip(fn, [a, b, c])
    assert d == [12, 15, 18]

    a = (1, 2, 3)
    b = (4, 5, 6)
    c = (7, 8, 9)
    d = map_structure_zip(fn, [a, b, c])
   

# Generated at 2022-06-17 18:41:13.053526
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y

    a = {'a': 1, 'b': 2}
    b = {'a': 3, 'b': 4}
    c = {'a': 5, 'b': 6}

    assert map_structure_zip(fn, [a, b, c]) == {'a': 9, 'b': 12}

# Generated at 2022-06-17 18:41:23.999526
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Test for list
    list1 = [1, 2, 3]
    list2 = [4, 5, 6]
    list3 = [7, 8, 9]
    list_result = map_structure_zip(lambda x, y, z: x + y + z, [list1, list2, list3])
    assert list_result == [12, 15, 18]

    # Test for tuple
    tuple1 = (1, 2, 3)
    tuple2 = (4, 5, 6)
    tuple3 = (7, 8, 9)
    tuple_result = map_structure_zip(lambda x, y, z: x + y + z, [tuple1, tuple2, tuple3])
    assert tuple_result == (12, 15, 18)

    # Test for dict

# Generated at 2022-06-17 18:41:30.066038
# Unit test for function no_map_instance
def test_no_map_instance():
    list_instance = no_map_instance([1, 2, 3])
    assert list_instance == [1, 2, 3]
    assert list_instance.__class__.__name__ == "_no_maplist"
    assert hasattr(list_instance, _NO_MAP_INSTANCE_ATTR)

    dict_instance = no_map_instance({"a": 1, "b": 2})
    assert dict_instance == {"a": 1, "b": 2}
    assert dict_instance.__class__.__name__ == "_no_mapdict"
    assert hasattr(dict_instance, _NO_MAP_INSTANCE_ATTR)

    tuple_instance = no_map_instance((1, 2, 3))
    assert tuple_instance == (1, 2, 3)
    assert tuple_instance.__class__.__name

# Generated at 2022-06-17 18:41:40.455632
# Unit test for function map_structure
def test_map_structure():
    from collections import namedtuple
    from typing import NamedTuple
    from collections import OrderedDict
    from collections import defaultdict
    from collections import Counter
    from collections import ChainMap
    from collections import deque
    from collections import UserDict
    from collections import UserList
    from collections import UserString
    from collections import Mapping
    from collections import MutableMapping
    from collections import Sequence
    from collections import MutableSequence
    from collections import Set
    from collections import MutableSet
    from collections import MappingView
    from collections import KeysView
    from collections import ItemsView
    from collections import ValuesView
    from collections import abc
    from collections.abc import Mapping
    from collections.abc import MutableMapping
    from collections.abc import Sequence
    from collections.abc import MutableSequence

# Generated at 2022-06-17 18:41:50.064941
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = [a, b, c]
    e = [a, b, c]
    f = [a, b, c]
    g = [d, e, f]
    h = [d, e, f]
    i = [d, e, f]
    j = [g, h, i]
    k = [g, h, i]
    l = [g, h, i]
    m = [j, k, l]
    n = [j, k, l]
    o = [j, k, l]
    p = [m, n, o]
    q = [m, n, o]
    r = [m, n, o]
   

# Generated at 2022-06-17 18:42:01.685751
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def f(x, y):
        return x + y
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = map_structure_zip(f, [a, b, c])
    assert d == [12, 15, 18]
    a = (1, 2, 3)
    b = (4, 5, 6)
    c = (7, 8, 9)
    d = map_structure_zip(f, [a, b, c])
    assert d == (12, 15, 18)
    a = {'a': 1, 'b': 2, 'c': 3}
    b = {'a': 4, 'b': 5, 'c': 6}

# Generated at 2022-06-17 18:42:07.859217
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    b = no_map_instance(a)
    assert a == b
    assert a is b
    assert a.__class__ is b.__class__
    assert a.__class__.__name__ == "_no_map" + a.__class__.__bases__[0].__name__
    assert hasattr(a, _NO_MAP_INSTANCE_ATTR)
    assert hasattr(b, _NO_MAP_INSTANCE_ATTR)
    assert a.__class__.__dict__[_NO_MAP_INSTANCE_ATTR]
    assert b.__class__.__dict__[_NO_MAP_INSTANCE_ATTR]
    assert a.__class__.__dict__[_NO_MAP_INSTANCE_ATTR] is b.__

# Generated at 2022-06-17 18:42:19.177775
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y

    def fn2(x, y):
        return x * y

    def fn3(x, y):
        return x - y

    def fn4(x, y):
        return x / y

    def fn5(x, y):
        return x ** y

    def fn6(x, y):
        return x % y

    def fn7(x, y):
        return x // y

    def fn8(x, y):
        return x & y

    def fn9(x, y):
        return x | y

    def fn10(x, y):
        return x ^ y

    def fn11(x, y):
        return x << y

    def fn12(x, y):
        return x >> y


# Generated at 2022-06-17 18:42:27.729412
# Unit test for function map_structure
def test_map_structure():
    import numpy as np
    import torch
    from torch.nn import Module
    from torch.nn.utils.rnn import PackedSequence

    class TestModule(Module):
        def __init__(self):
            super().__init__()
            self.param = torch.nn.Parameter(torch.randn(3, 4))

        def forward(self, x):
            return x + self.param

    def test_fn(x):
        return x + 1

    def test_fn_2(x, y):
        return x + y

    def test_fn_3(x, y, z):
        return x + y + z

    def test_fn_4(x, y, z, w):
        return x + y + z + w


# Generated at 2022-06-17 18:42:37.635465
# Unit test for function no_map_instance
def test_no_map_instance():
    import numpy as np
    from collections import namedtuple
    from torch.nn.utils.rnn import PackedSequence
    from torch.nn.utils.rnn import pad_packed_sequence
    from torch.nn.utils.rnn import pack_padded_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pack_padded_sequence
    from torch.nn.utils.rnn import pad_packed_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pack_padded_sequence

# Generated at 2022-06-17 18:42:48.181154
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = [10, 11, 12]
    e = [13, 14, 15]
    f = [16, 17, 18]
    g = [19, 20, 21]
    h = [22, 23, 24]
    i = [25, 26, 27]
    j = [28, 29, 30]
    k = [31, 32, 33]
    l = [34, 35, 36]
    m = [37, 38, 39]
    n = [40, 41, 42]
    o = [43, 44, 45]
    p = [46, 47, 48]
    q = [49, 50, 51]
    r = [52, 53, 54]
   

# Generated at 2022-06-17 18:42:58.700382
# Unit test for function map_structure
def test_map_structure():
    def fn(x):
        return x + 1

    def fn2(x, y):
        return x + y

    assert map_structure(fn, [1, 2, 3]) == [2, 3, 4]
    assert map_structure(fn, (1, 2, 3)) == (2, 3, 4)
    assert map_structure(fn, {1: 2, 3: 4}) == {1: 3, 3: 5}
    assert map_structure(fn, {1, 2, 3}) == {2, 3, 4}
    assert map_structure(fn, 1) == 2
    assert map_structure(fn2, [1, 2, 3], [4, 5, 6]) == [5, 7, 9]

# Generated at 2022-06-17 18:43:07.964374
# Unit test for function no_map_instance
def test_no_map_instance():
    import torch
    from torch.nn.utils.rnn import PackedSequence
    from torch.nn.utils.rnn import pad_packed_sequence
    from torch.nn.utils.rnn import pack_padded_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence

# Generated at 2022-06-17 18:43:14.991784
# Unit test for function map_structure
def test_map_structure():
    def f(x):
        return x + 1

    def g(x, y):
        return x + y

    assert map_structure(f, [1, 2, 3]) == [2, 3, 4]
    assert map_structure(f, (1, 2, 3)) == (2, 3, 4)
    assert map_structure(f, {'a': 1, 'b': 2}) == {'a': 2, 'b': 3}
    assert map_structure(f, {1, 2, 3}) == {2, 3, 4}
    assert map_structure(f, 1) == 2

    assert map_structure_zip(g, [[1, 2, 3], [4, 5, 6]]) == [5, 7, 9]

# Generated at 2022-06-17 18:43:26.793274
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    import torch.optim as optim

    class Net(nn.Module):
        def __init__(self):
            super(Net, self).__init__()
            self.conv1 = nn.Conv2d(1, 6, 5)
            self.conv2 = nn.Conv2d(6, 16, 5)
            self.fc1 = nn.Linear(16 * 5 * 5, 120)
            self.fc2 = nn.Linear(120, 84)
            self.fc3 = nn.Linear(84, 10)

        def forward(self, x):
            x = F.max_pool2d(F.relu(self.conv1(x)), (2, 2))

# Generated at 2022-06-17 18:43:36.418582
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y

    def fn2(x, y):
        return x * y

    def fn3(x, y):
        return x / y

    def fn4(x, y):
        return x - y

    def fn5(x, y):
        return x ** y

    def fn6(x, y):
        return x % y

    def fn7(x, y):
        return x // y

    def fn8(x, y):
        return x & y

    def fn9(x, y):
        return x | y

    def fn10(x, y):
        return x ^ y

    def fn11(x, y):
        return x << y

    def fn12(x, y):
        return x >> y


# Generated at 2022-06-17 18:43:41.761807
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import OrderedDict
    from torch.Size import Size
    from torch.Tensor import Tensor
    from torch.nn.Module import Module
    from torch.nn.Parameter import Parameter
    from torch.nn.ParameterList import ParameterList
    from torch.nn.ParameterDict import ParameterDict
    from torch.nn.ModuleList import ModuleList
    from torch.nn.ModuleDict import ModuleDict
    from torch.nn.Sequential import Sequential
    from torch.nn.Linear import Linear
    from torch.nn.Conv2d import Conv2d
    from torch.nn.BatchNorm2d import BatchNorm2d
    from torch.nn.ReLU import ReLU
    from torch.nn.MaxPool2d import MaxPool2d
    from torch.nn.AvgPool2d import AvgPool

# Generated at 2022-06-17 18:43:52.603680
# Unit test for function no_map_instance
def test_no_map_instance():
    a = [1, 2, 3]
    b = no_map_instance(a)
    assert a == b
    assert a is not b
    assert hasattr(b, _NO_MAP_INSTANCE_ATTR)
    assert not hasattr(a, _NO_MAP_INSTANCE_ATTR)
    c = no_map_instance(a)
    assert c is b
    assert hasattr(c, _NO_MAP_INSTANCE_ATTR)
    assert not hasattr(a, _NO_MAP_INSTANCE_ATTR)
    d = no_map_instance(b)
    assert d is b
    assert hasattr(d, _NO_MAP_INSTANCE_ATTR)
    assert not hasattr(a, _NO_MAP_INSTANCE_ATTR)

# Generated at 2022-06-17 18:43:59.204571
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def test_fn(x, y):
        return x + y
    def test_fn2(x, y):
        return x * y
    def test_fn3(x, y):
        return x - y
    def test_fn4(x, y):
        return x / y
    def test_fn5(x, y):
        return x ** y
    def test_fn6(x, y):
        return x % y
    def test_fn7(x, y):
        return x // y
    def test_fn8(x, y):
        return x & y
    def test_fn9(x, y):
        return x | y
    def test_fn10(x, y):
        return x ^ y
    def test_fn11(x, y):
        return x << y

# Generated at 2022-06-17 18:44:09.554977
# Unit test for function map_structure
def test_map_structure():
    def fn(x):
        return x + 1

    def fn_tuple(x, y):
        return x + y

    def fn_dict(x, y):
        return x + y

    def fn_list(x, y):
        return x + y

    def fn_set(x, y):
        return x + y

    def fn_namedtuple(x, y):
        return x + y

    def fn_no_map_instance(x):
        return x + 1

    def fn_no_map_class(x):
        return x + 1

    def fn_no_map_instance_tuple(x, y):
        return x + y

    def fn_no_map_class_tuple(x, y):
        return x + y


# Generated at 2022-06-17 18:44:16.562765
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    b = no_map_instance([1, 2, 3])
    assert a is b
    assert a == b
    assert a.__class__ == b.__class__
    assert a.__class__ == list
    assert a.__class__ != _no_map_type(list)
    assert a.__class__ != _no_map_type(list)()
    assert a.__class__ != _no_map_type(list)([1, 2, 3])
    assert a.__class__ != _no_map_type(list)([1, 2, 3]).__class__
    assert a.__class__ != _no_map_type(list)([1, 2, 3]).__class__.__class__
    assert a.__class__ != _

# Generated at 2022-06-17 18:44:25.897363
# Unit test for function map_structure
def test_map_structure():
    def add(x):
        return x + 1

    def add_tuple(x, y):
        return x + y

    assert map_structure(add, [1, 2, 3]) == [2, 3, 4]
    assert map_structure(add, (1, 2, 3)) == (2, 3, 4)
    assert map_structure(add, {1: 1, 2: 2, 3: 3}) == {1: 2, 2: 3, 3: 4}
    assert map_structure(add, {1, 2, 3}) == {2, 3, 4}
    assert map_structure(add_tuple, ([1, 2], [3, 4])) == [4, 6]

# Generated at 2022-06-17 18:44:36.268757
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import namedtuple
    from torch.nn import Module
    from torch.nn.utils.rnn import PackedSequence
    from torch.nn.utils.rnn import pad_packed_sequence
    from torch.nn.utils.rnn import pack_padded_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad

# Generated at 2022-06-17 18:44:46.182036
# Unit test for function map_structure
def test_map_structure():
    def fn(x):
        return x + 1

    def fn2(x, y):
        return x + y

    assert map_structure(fn, [1, 2, 3]) == [2, 3, 4]
    assert map_structure(fn, (1, 2, 3)) == (2, 3, 4)
    assert map_structure(fn, {1: 1, 2: 2, 3: 3}) == {1: 2, 2: 3, 3: 4}
    assert map_structure(fn, {1, 2, 3}) == {2, 3, 4}
    assert map_structure(fn, 1) == 2
    assert map_structure(fn2, [1, 2, 3], [1, 2, 3]) == [2, 4, 6]

# Generated at 2022-06-17 18:44:52.549099
# Unit test for function no_map_instance
def test_no_map_instance():
    # Test for list
    l = [1, 2, 3]
    l = no_map_instance(l)
    assert l == [1, 2, 3]
    # Test for tuple
    t = (1, 2, 3)
    t = no_map_instance(t)
    assert t == (1, 2, 3)
    # Test for dict
    d = {'a': 1, 'b': 2, 'c': 3}
    d = no_map_instance(d)
    assert d == {'a': 1, 'b': 2, 'c': 3}
    # Test for set
    s = {1, 2, 3}
    s = no_map_instance(s)
    assert s == {1, 2, 3}


# Generated at 2022-06-17 18:45:02.877473
# Unit test for function no_map_instance
def test_no_map_instance():
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    import torch.optim as optim
    import torch.utils.data as data
    import torchvision
    import torchvision.transforms as transforms
    import torchvision.datasets as datasets
    import torchvision.models as models
    import torchvision.utils as vutils
    import torch.backends.cudnn as cudnn
    import torch.distributed as dist
    import torch.multiprocessing as mp
    import torch.utils.cpp_extension
    import torch.utils.checkpoint
    import torch.utils.data.dataloader
    import torch.utils.data.distributed
    import torch.utils.dlpack
    import torch.utils.hooks
    import torch.utils.model_zoo

# Generated at 2022-06-17 18:45:09.357429
# Unit test for function no_map_instance
def test_no_map_instance():
    import torch
    from torch.nn import Module
    from torch.nn.utils.rnn import PackedSequence
    from torch.nn.utils.rnn import pad_packed_sequence
    from torch.nn.utils.rnn import pack_padded_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pack_padded_sequence
    from torch.nn.utils.rnn import pad_packed_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence

# Generated at 2022-06-17 18:45:23.343917
# Unit test for function no_map_instance
def test_no_map_instance():
    import torch
    from torch.nn import Module
    from torch.nn.utils.rnn import PackedSequence
    from torch.nn.utils.rnn import pad_packed_sequence
    from torch.nn.utils.rnn import pack_padded_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
   

# Generated at 2022-06-17 18:45:32.739808
# Unit test for function map_structure
def test_map_structure():
    def test_fn(x):
        return x + 1

    def test_fn_zip(x, y):
        return x + y

    test_list = [1, 2, 3]
    test_list_result = map_structure(test_fn, test_list)
    assert test_list_result == [2, 3, 4]

    test_tuple = (1, 2, 3)
    test_tuple_result = map_structure(test_fn, test_tuple)
    assert test_tuple_result == (2, 3, 4)

    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_dict_result = map_structure(test_fn, test_dict)

# Generated at 2022-06-17 18:45:43.351892
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y
    objs = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    assert map_structure_zip(fn, objs) == {'a': 4, 'b': 6}
    objs = [{'a': 1, 'b': 2}, {'a': 3, 'c': 4}]
    assert map_structure_zip(fn, objs) == {'a': 4, 'b': 2, 'c': 4}
    objs = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4, 'c': 5}]
    assert map_structure_zip(fn, objs) == {'a': 4, 'b': 6, 'c': 5}
   

# Generated at 2022-06-17 18:45:55.967820
# Unit test for function map_structure
def test_map_structure():
    # Test for list
    list_1 = [1, 2, 3]
    list_2 = [4, 5, 6]
    list_3 = [7, 8, 9]
    list_4 = [10, 11, 12]
    list_5 = [13, 14, 15]
    list_6 = [16, 17, 18]
    list_7 = [19, 20, 21]
    list_8 = [22, 23, 24]
    list_9 = [25, 26, 27]
    list_10 = [28, 29, 30]
    list_11 = [31, 32, 33]
    list_12 = [34, 35, 36]
    list_13 = [37, 38, 39]
    list_14 = [40, 41, 42]

# Generated at 2022-06-17 18:46:05.534421
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    b = no_map_instance([1, 2, 3])
    assert a == b
    assert a is b
    assert a == [1, 2, 3]
    assert a is not [1, 2, 3]
    assert a == no_map_instance([1, 2, 3])
    assert a is no_map_instance([1, 2, 3])

    a = no_map_instance({"a": 1, "b": 2})
    b = no_map_instance({"a": 1, "b": 2})
    assert a == b
    assert a is b
    assert a == {"a": 1, "b": 2}
    assert a is not {"a": 1, "b": 2}

# Generated at 2022-06-17 18:46:16.067215
# Unit test for function map_structure
def test_map_structure():
    def f(x):
        return x + 1

    def g(x):
        return x + 2

    def h(x):
        return x + 3

    def i(x):
        return x + 4

    def j(x):
        return x + 5

    def k(x):
        return x + 6

    def l(x):
        return x + 7

    def m(x):
        return x + 8

    def n(x):
        return x + 9

    def o(x):
        return x + 10

    def p(x):
        return x + 11

    def q(x):
        return x + 12

    def r(x):
        return x + 13

    def s(x):
        return x + 14

    def t(x):
        return x + 15


# Generated at 2022-06-17 18:46:26.951996
# Unit test for function map_structure
def test_map_structure():
    import torch
    from torch.nn import Module
    from torch.nn.utils.rnn import PackedSequence
    from torch.nn.utils.rnn import pad_packed_sequence
    from torch.nn.utils.rnn import pack_padded_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
   

# Generated at 2022-06-17 18:46:36.140504
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance(list([1, 2, 3]))
    b = no_map_instance(list([1, 2, 3]))
    assert a == b
    assert a is b
    assert a[0] == 1
    assert a[1] == 2
    assert a[2] == 3
    assert a[0] is 1
    assert a[1] is 2
    assert a[2] is 3
    a = no_map_instance(dict({1:1, 2:2, 3:3}))
    b = no_map_instance(dict({1:1, 2:2, 3:3}))
    assert a == b
    assert a is b
    assert a[1] == 1
    assert a[2] == 2
    assert a[3] == 3
    assert a[1]

# Generated at 2022-06-17 18:46:46.336419
# Unit test for function map_structure
def test_map_structure():
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = [a, b, c]
    e = [d, d, d]
    f = [e, e, e]
    g = [f, f, f]
    h = [g, g, g]
    i = [h, h, h]
    j = [i, i, i]
    k = [j, j, j]
    l = [k, k, k]
    m = [l, l, l]
    n = [m, m, m]
    o = [n, n, n]
    p = [o, o, o]
    q = [p, p, p]
    r = [q, q, q]
   

# Generated at 2022-06-17 18:46:56.966803
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = [10, 11, 12]
    e = [13, 14, 15]
    f = [16, 17, 18]
    g = [19, 20, 21]
    h = [22, 23, 24]
    i = [25, 26, 27]
    j = [28, 29, 30]
    k = [31, 32, 33]
    l = [34, 35, 36]
    m = [37, 38, 39]
    n = [40, 41, 42]
    o = [43, 44, 45]
    p = [46, 47, 48]
    q = [49, 50, 51]
    r = [52, 53, 54]
   

# Generated at 2022-06-17 18:47:08.168443
# Unit test for function map_structure
def test_map_structure():
    def test_fn(x):
        return x * 2

    # Test list
    l = [1, 2, 3]
    l_out = map_structure(test_fn, l)
    assert l_out == [2, 4, 6]

    # Test tuple
    t = (1, 2, 3)
    t_out = map_structure(test_fn, t)
    assert t_out == (2, 4, 6)

    # Test dict
    d = {'a': 1, 'b': 2, 'c': 3}
    d_out = map_structure(test_fn, d)
    assert d_out == {'a': 2, 'b': 4, 'c': 6}

    # Test nested

# Generated at 2022-06-17 18:47:17.986281
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y

    objs = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ]
    assert map_structure_zip(fn, objs) == [12, 15, 18]

    objs = [
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
        {'a': 5, 'b': 6}
    ]
    assert map_structure_zip(fn, objs) == {'a': 9, 'b': 12}

    objs = [
        (1, 2, 3),
        (4, 5, 6),
        (7, 8, 9)
    ]
    assert map_structure_zip(fn, objs)

# Generated at 2022-06-17 18:47:29.662825
# Unit test for function map_structure
def test_map_structure():
    def fn(x):
        return x + 1

    def fn2(x, y):
        return x + y

    assert map_structure(fn, [1, 2, 3]) == [2, 3, 4]
    assert map_structure(fn, (1, 2, 3)) == (2, 3, 4)
    assert map_structure(fn, {1: 1, 2: 2, 3: 3}) == {1: 2, 2: 3, 3: 4}
    assert map_structure(fn, {1, 2, 3}) == {2, 3, 4}
    assert map_structure(fn, 1) == 2
    assert map_structure(fn2, [1, 2, 3], [4, 5, 6]) == [5, 7, 9]

# Generated at 2022-06-17 18:47:35.781044
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y

    a = [[1, 2], [3, 4]]
    b = [[5, 6], [7, 8]]
    c = [[9, 10], [11, 12]]

    assert map_structure_zip(fn, [a, b, c]) == [[15, 18], [21, 24]]

# Generated at 2022-06-17 18:47:45.887352
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(a, b):
        return a + b

    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = [10, 11, 12]
    e = [13, 14, 15]
    f = [16, 17, 18]
    g = [19, 20, 21]
    h = [22, 23, 24]
    i = [25, 26, 27]
    j = [28, 29, 30]
    k = [31, 32, 33]
    l = [34, 35, 36]
    m = [37, 38, 39]
    n = [40, 41, 42]
    o = [43, 44, 45]
    p = [46, 47, 48]

# Generated at 2022-06-17 18:47:55.783992
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(a, b):
        return a + b

    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = [10, 11, 12]
    e = [13, 14, 15]
    f = [16, 17, 18]
    g = [19, 20, 21]
    h = [22, 23, 24]
    i = [25, 26, 27]
    j = [28, 29, 30]
    k = [31, 32, 33]
    l = [34, 35, 36]
    m = [37, 38, 39]
    n = [40, 41, 42]
    o = [43, 44, 45]
    p = [46, 47, 48]

# Generated at 2022-06-17 18:48:06.293190
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(a, b):
        return a + b

    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = [a, b, c]
    e = [a, b, c]
    f = [a, b, c]
    g = [d, e, f]
    h = [d, e, f]
    i = [d, e, f]
    j = [g, h, i]

    k = map_structure_zip(fn, [a, b, c])
    l = map_structure_zip(fn, [d, e, f])
    m = map_structure_zip(fn, [g, h, i])

# Generated at 2022-06-17 18:48:16.044773
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y

    def fn2(x, y):
        return x * y

    def fn3(x, y):
        return x + y

    def fn4(x, y):
        return x * y

    def fn5(x, y):
        return x + y

    def fn6(x, y):
        return x * y

    def fn7(x, y):
        return x + y

    def fn8(x, y):
        return x * y

    def fn9(x, y):
        return x + y

    def fn10(x, y):
        return x * y

    def fn11(x, y):
        return x + y

    def fn12(x, y):
        return x * y


# Generated at 2022-06-17 18:48:25.209093
# Unit test for function map_structure
def test_map_structure():
    def fn(x):
        return x + 1

    def fn2(x, y):
        return x + y

    def fn3(x, y, z):
        return x + y + z

    def fn4(x, y, z, w):
        return x + y + z + w

    def fn5(x, y, z, w, v):
        return x + y + z + w + v

    def fn6(x, y, z, w, v, u):
        return x + y + z + w + v + u

    def fn7(x, y, z, w, v, u, t):
        return x + y + z + w + v + u + t


# Generated at 2022-06-17 18:48:35.673459
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import OrderedDict
    from torch.nn.utils.rnn import PackedSequence
    from torch.nn.utils.rnn import pad_packed_sequence
    from torch.nn.utils.rnn import pack_padded_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pack_padded_sequence
    from torch.nn.utils.rnn import pad_packed_sequence
    from torch.nn.utils.rnn import pack_sequence
    from torch.nn.utils.rnn import pad_sequence
    from torch.nn.utils.rnn import pack_p

# Generated at 2022-06-17 18:48:44.803836
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    b = no_map_instance(a)
    assert a is b

    a = no_map_instance({"a": 1, "b": 2})
    b = no_map_instance(a)
    assert a is b

    a = no_map_instance((1, 2, 3))
    b = no_map_instance(a)
    assert a is b

    a = no_map_instance(set([1, 2, 3]))
    b = no_map_instance(a)
    assert a is b

    a = no_map_instance(1)
    b = no_map_instance(a)
    assert a is b

    a = no_map_instance(1.0)
    b = no_map_instance(a)


# Generated at 2022-06-17 18:48:56.753998
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y, z):
        return x + y + z

    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = map_structure_zip(fn, [a, b, c])
    assert d == [12, 15, 18]

    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = map_structure_zip(fn, [a, b, c])
    assert d == [12, 15, 18]

    a = (1, 2, 3)
    b = (4, 5, 6)
    c = (7, 8, 9)

# Generated at 2022-06-17 18:49:07.942989
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = [10, 11, 12]
    e = [13, 14, 15]
    f = [16, 17, 18]
    g = [19, 20, 21]
    h = [22, 23, 24]
    i = [25, 26, 27]
    j = [28, 29, 30]
    k = [31, 32, 33]
    l = [34, 35, 36]
    m = [37, 38, 39]
    n = [40, 41, 42]
    o = [43, 44, 45]
    p = [46, 47, 48]

# Generated at 2022-06-17 18:49:16.548949
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y

    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = [10, 11, 12]
    e = [13, 14, 15]
    f = [16, 17, 18]
    g = [19, 20, 21]
    h = [22, 23, 24]
    i = [25, 26, 27]
    j = [28, 29, 30]
    k = [31, 32, 33]
    l = [34, 35, 36]
    m = [37, 38, 39]
    n = [40, 41, 42]
    o = [43, 44, 45]
    p = [46, 47, 48]

# Generated at 2022-06-17 18:49:26.654081
# Unit test for function map_structure
def test_map_structure():
    a = {'a': [1, 2, 3], 'b': [4, 5, 6]}
    b = {'a': [1, 2, 3], 'b': [4, 5, 6]}
    c = {'a': [1, 2, 3], 'b': [4, 5, 6]}
    d = {'a': [1, 2, 3], 'b': [4, 5, 6]}
    e = {'a': [1, 2, 3], 'b': [4, 5, 6]}
    f = {'a': [1, 2, 3], 'b': [4, 5, 6]}
    g = {'a': [1, 2, 3], 'b': [4, 5, 6]}
    h = {'a': [1, 2, 3], 'b': [4, 5, 6]}

# Generated at 2022-06-17 18:49:37.780094
# Unit test for function map_structure
def test_map_structure():
    def test_fn(x):
        return x + 1

    def test_fn_zip(x, y):
        return x + y

    # Test list
    test_list = [1, 2, 3]
    assert map_structure(test_fn, test_list) == [2, 3, 4]
    assert map_structure_zip(test_fn_zip, [test_list, test_list]) == [2, 4, 6]

    # Test tuple
    test_tuple = (1, 2, 3)
    assert map_structure(test_fn, test_tuple) == (2, 3, 4)
    assert map_structure_zip(test_fn_zip, [test_tuple, test_tuple]) == (2, 4, 6)

    # Test dict

# Generated at 2022-06-17 18:49:47.544673
# Unit test for function no_map_instance
def test_no_map_instance():
    # test for list
    l = [1, 2, 3]
    l_no_map = no_map_instance(l)
    assert l_no_map == l
    assert l_no_map.__class__ == list
    assert hasattr(l_no_map, _NO_MAP_INSTANCE_ATTR)

    # test for tuple
    t = (1, 2, 3)
    t_no_map = no_map_instance(t)
    assert t_no_map == t
    assert t_no_map.__class__ == tuple
    assert hasattr(t_no_map, _NO_MAP_INSTANCE_ATTR)

    # test for dict
    d = {1: 2, 3: 4}
    d_no_map = no_map_instance(d)
    assert d_

# Generated at 2022-06-17 18:49:55.906803
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def test_fn(a, b):
        return a + b

    test_list = [1, 2, 3]
    test_tuple = (1, 2, 3)
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_set = {1, 2, 3}
    test_namedtuple = namedtuple('test_namedtuple', ['a', 'b', 'c'])(1, 2, 3)

    test_list_2 = [4, 5, 6]
    test_tuple_2 = (4, 5, 6)
    test_dict_2 = {'a': 4, 'b': 5, 'c': 6}
    test_set_2 = {4, 5, 6}

# Generated at 2022-06-17 18:50:07.931772
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    b = no_map_instance([1, 2, 3])
    assert a == b
    assert a is b
    assert a[0] == 1
    assert a[1] == 2
    assert a[2] == 3
    assert a[0] is 1
    assert a[1] is 2
    assert a[2] is 3
    assert a[0] is b[0]
    assert a[1] is b[1]
    assert a[2] is b[2]
    assert a[0] == b[0]
    assert a[1] == b[1]
    assert a[2] == b[2]
    assert a[0] is not b[1]
    assert a[0] is not b[2]
    assert a

# Generated at 2022-06-17 18:50:19.358748
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y
    x = [1, 2, 3]
    y = [4, 5, 6]
    z = [7, 8, 9]
    assert map_structure_zip(fn, [x, y, z]) == [12, 15, 18]
    x = {'a': 1, 'b': 2, 'c': 3}
    y = {'a': 4, 'b': 5, 'c': 6}
    z = {'a': 7, 'b': 8, 'c': 9}
    assert map_structure_zip(fn, [x, y, z]) == {'a': 12, 'b': 15, 'c': 18}
    x = (1, 2, 3)
    y = (4, 5, 6)

# Generated at 2022-06-17 18:50:31.654011
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Test list
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = map_structure_zip(lambda x, y, z: x + y + z, [a, b, c])
    assert d == [12, 15, 18]

    # Test tuple
    a = (1, 2, 3)
    b = (4, 5, 6)
    c = (7, 8, 9)
    d = map_structure_zip(lambda x, y, z: x + y + z, [a, b, c])
    assert d == (12, 15, 18)

    # Test dict
    a = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 18:50:42.130311
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def test_fn(a, b, c):
        return a + b + c

    # test list
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    assert map_structure_zip(test_fn, [a, b, c]) == [12, 15, 18]

    # test tuple
    a = (1, 2, 3)
    b = (4, 5, 6)
    c = (7, 8, 9)
    assert map_structure_zip(test_fn, [a, b, c]) == (12, 15, 18)

    # test dict
    a = {'a': 1, 'b': 2, 'c': 3}
    b = {'a': 4, 'b': 5, 'c': 6}