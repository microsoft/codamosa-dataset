

# Generated at 2022-06-11 21:49:49.751385
# Unit test for function no_map_instance
def test_no_map_instance():
    instance = [1, 2, 3]
    no_map_instance(instance)
    assert hasattr(instance, _NO_MAP_INSTANCE_ATTR)

    # Make sure multiple calls to no_map_instance with the same instance returns the same object
    assert no_map_instance(instance) is instance


# Generated at 2022-06-11 21:50:01.001017
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import numpy as np
    class Person:
        age: int
        name: str
        pet: List[str]

    person_1 = Person(age=10, name='Alice', pet=['dog'])
    person_2 = Person(age=20, name='Bob', pet=['cat'])
    fn = lambda age_1, age_2: age_1 + age_2
    person = map_structure_zip(fn, [person_1, person_2])
    assert(person.age == 30)
    person = map_structure_zip(np.add, [person_1, person_2])
    assert(person.age == 30)


# Generated at 2022-06-11 21:50:09.341122
# Unit test for function map_structure
def test_map_structure():
    test_list = [[1, 2, 3], [4, 5, 6]]
    out = map_structure(lambda x: x, test_list)
    assert test_list == out
    out = map_structure(lambda x: x + 1, test_list)
    assert out == [[2, 3, 4], [5, 6, 7]]
    test_tuple = ((1, 2), (3, 4))
    out = map_structure(lambda x: x, test_tuple)
    assert out == ((1, 2), (3, 4))
    out = map_structure(lambda x: x + 1, test_tuple)
    assert out == ((2, 3), (4, 5))
    test_set = {1, 2}

# Generated at 2022-06-11 21:50:14.649656
# Unit test for function map_structure_zip
def test_map_structure_zip():
    Tuple = namedtuple("Tuple", ["a", "b"])
    x = Tuple(a={"a": 1}, b={"a": 2})
    y = Tuple(a={"b": 1}, b={"b": 2})
    z = Tuple(a={"c": 1}, b={"c": 2})
    fn = lambda x, y, z: x

    mapping_result = map_structure_zip(fn, [x, y, z])
    assert mapping_result == x

# Generated at 2022-06-11 21:50:26.725354
# Unit test for function no_map_instance
def test_no_map_instance():
    # test list
    a = [1,2,3,4,5]
    x = no_map_instance(a)
    assert x == a
    assert x is a

    # test dict
    a = {'a': 1, 'b': 2, 'c': 3}
    x = no_map_instance(a)
    assert x == a
    assert x is a

    # test tuple
    a = (1,2,3)
    x = no_map_instance(a)
    assert x == a
    assert x is a

    # test namedtuple
    Point = namedtuple('Point', ['x', 'y'])
    a = Point(1,2)
    x = no_map_instance(a)
    assert x == a
    assert x is a

    # test class instance

# Generated at 2022-06-11 21:50:37.769283
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x+2, [2,6,4,4]) == [4,8,6,6]
    assert map_structure(lambda x: x+2, (2,6,4,4)) == (4,8,6,6)
    assert map_structure(lambda x: x+2, (2,6,(4,4))) == (4,8,(6,6))
    assert map_structure(lambda x: x+2, (2,6,(4,4),(4,4))) == (4,8,(6,6),(6,6))
    assert map_structure(lambda x: x+2, {"2":2,"6":6,"4":4}) == {"2":4,"6":8,"4":6}

# Generated at 2022-06-11 21:50:42.084874
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [1,2,3]
    b = [4,5,6]
    c = [7,8,9]
    d = map_structure_zip(lambda *xs: sum(xs), [a,b,c])
    assert d == [12,15,18]



# Generated at 2022-06-11 21:50:51.988306
# Unit test for function map_structure
def test_map_structure():
    import torch

    # Test isinstance and hasattr
    l = [1, 2, 3]
    l_no_map = no_map_instance(l)
    l_no_map_type = _no_map_type(list)
    assert l_no_map.__class__ == l_no_map_type
    assert l_no_map.__class__ in _NO_MAP_TYPES
    assert hasattr(l_no_map, _NO_MAP_INSTANCE_ATTR)

    # Test equality
    assert map_structure(lambda x: x, 1) == 1
    assert map_structure(lambda x: x, [1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-11 21:51:01.921914
# Unit test for function no_map_instance
def test_no_map_instance():
    import copy
    test_list = [1, 2, 3]
    test_no_map_list = no_map_instance(test_list)
    assert hasattr(test_no_map_list, _NO_MAP_INSTANCE_ATTR)
    assert test_no_map_list._NO_MAP_INSTANCE_ATTR
    test_list_copy = copy.deepcopy(test_list)
    assert test_list_copy == test_list
    test_no_map_list_copy = copy.deepcopy(test_no_map_list)
    assert test_no_map_list_copy == test_no_map_list
    assert not hasattr(test_no_map_list_copy, _NO_MAP_INSTANCE_ATTR)
    assert test_no_map_list_copy == test_list

# Generated at 2022-06-11 21:51:12.220573
# Unit test for function no_map_instance
def test_no_map_instance():
    from hypothesis import given, strategies, settings
    from hypothesis.extra import numpy as np_st
    from hypothesis.extra import pandas as pd_st
    from hypothesis.extra import scipy as sp_st
    from hypothesis.extra import torch as th_st
    from hypothesis.extra import scikit_learn as skl_st
    import numpy as np
    import pandas as pd
    import scipy as sp
    import torch as th

    np_types = [np.array, np.matrix, np.memmap, pd.Categorical, pd.Index]

# Generated at 2022-06-11 21:51:20.694114
# Unit test for function no_map_instance
def test_no_map_instance():
    register_no_map_class(list)
    assert(type(no_map_instance([1])) != list)
    assert(no_map_instance([1])[0] == 1)
    assert(no_map_instance([1]) == [1])
    assert(len(no_map_instance([1])) == 1)
    assert(not hasattr(no_map_instance([1]), _NO_MAP_INSTANCE_ATTR))

# Generated at 2022-06-11 21:51:25.990474
# Unit test for function no_map_instance
def test_no_map_instance():
    class A:
        def __init__(self, val):
            self.val = val

    register_no_map_class(A)
    # should not be checked
    a = A(10)
    b = no_map_instance(a)
    assert b.val == 10
    assert b != a

    c = no_map_instance(a)
    assert c.val == 10
    assert c == b
    assert c != a

# Generated at 2022-06-11 21:51:35.748392
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(a,b,c):
        return str(a) + str(b) + str(c)
    a = [1,2]
    b = [3,4,5]
    c = [6,7]
    assert map_structure_zip(fn, [a,b,c]) == ['163', '273', '374']
    d = 'a'
    e = 'b'
    f = 'c'
    assert map_structure_zip(fn, [d,e,f]) == 'abc'
    g = [(1,2), (3,4)]
    h = [(5,6), (7,8), (9,10)]
    i = [(11,12), (13,14)]

# Generated at 2022-06-11 21:51:39.068746
# Unit test for function no_map_instance
def test_no_map_instance():
    list_instance = no_map_instance([1, 2, 3])
    assert (hasattr(list_instance, _NO_MAP_INSTANCE_ATTR))
    print("Test no_map_instance passed!")


# Generated at 2022-06-11 21:51:46.796725
# Unit test for function no_map_instance
def test_no_map_instance():
    obj = no_map_instance([1,2,3])
    assert(map_structure(lambda x: x*2, [obj,obj]) == [[1,2,3],[1,2,3]])
    obj = no_map_instance([[1,2],[3,4],[5,6]])
    assert(map_structure(lambda x: x*2, [obj,obj]) == [[[1,2],[3,4],[5,6]],[[1,2],[3,4],[5,6]]])

# Generated at 2022-06-11 21:51:53.386381
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import copy
    def f1(a, b):
        return a + b

    def f2(a, b):
        return a - b


# Generated at 2022-06-11 21:52:04.010956
# Unit test for function map_structure_zip

# Generated at 2022-06-11 21:52:15.727097
# Unit test for function map_structure_zip

# Generated at 2022-06-11 21:52:25.316923
# Unit test for function map_structure
def test_map_structure():
    a = {'a': [1, 2], 'b': 1}
    b = map_structure(lambda x: x + 1, a)
    assert(a['a'][1] == 2)
    assert(a['b'] == 1)
    assert(b['a'][0] == 2)
    assert(b['a'][1] == 3)
    assert(b['b'] == 2)

    c = (1, 2, 3)
    d = map_structure(lambda x: x + 1, c)
    assert(c[1] == 2)
    assert(d[0] == 2)
    assert(d[1] == 3)
    assert(d[2] == 4)

    e = [1, 2, 3, {'a': 1, 'b': 2}]

# Generated at 2022-06-11 21:52:34.809054
# Unit test for function no_map_instance
def test_no_map_instance():
    # Test whether no_map_instance works
    class A(list):
        def __init__(self):
            super().__init__()
            self.test = True
    a = A()
    b = no_map_instance(a)
    assert set(a) == set(b)
    assert a.test == b.test
    # Test that class inheritance is handled properly
    class B(list):
        def __init__(self):
            super().__init__()
            self.test = True
    c = B()
    d = no_map_instance(c)
    assert set(c) == set(d)
    assert c.test == d.test
    # Test that exceptions are handled properly
    try:
        no_map_instance(list())
    except TypeError:
        pass

# Generated at 2022-06-11 21:52:44.728563
# Unit test for function no_map_instance
def test_no_map_instance():
    mylist = no_map_instance([1,2,3])
    mydict = no_map_instance({'a': 1, 'b': 2})
    mytup = no_map_instance((1,2,3))
    myset = no_map_instance({1,2,3})

    def myprint(obj):
        if hasattr(obj, '__getitem__'):
            return len(obj)
        return 1

    print(map_structure(myprint, mylist))
    print(map_structure(myprint, mydict))
    print(map_structure(myprint, mytup))
    print(map_structure(myprint, myset))



# Generated at 2022-06-11 21:52:47.273095
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance(5)
    b = no_map_instance(5)
    fn = lambda x: x+1
    assert map_structure(fn, a) == b


# Generated at 2022-06-11 21:52:53.769485
# Unit test for function no_map_instance
def test_no_map_instance():
    from tree import Tree
    from grouptree import GroupTree
    from constanttree import ConstTree

    tree = Tree([[1], [2]])
    gtree = GroupTree([[1], [2]], [1, 2, 3])
    ctree = ConstTree([[1, 2, 3], [4, 5, 6]])
    tree = no_map_instance(tree)
    gtree = no_map_instance(gtree)
    ctree = no_map_instance(ctree)
    assert(hasattr(tree, _NO_MAP_INSTANCE_ATTR) == True)
    assert(hasattr(gtree, _NO_MAP_INSTANCE_ATTR) == True)
    assert(hasattr(ctree, _NO_MAP_INSTANCE_ATTR) == True)


# Generated at 2022-06-11 21:52:57.379224
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = dict(a = 1, b = 1)
    b = dict(a = 2, b = 2)
    c = dict(a = 3, b = 3)
    actual = map_structure_zip(lambda x, y: x + y, [a, b, c])
    desired = dict(a = 6, b = 6)
    assert actual == desired
    c = dict(a = 3, b = 1)
    actual = map_structure_zip(lambda x, y: x + y, [a, b, c])
    desired = dict(a = 6, b = 4)
    assert actual == desired

# Generated at 2022-06-11 21:53:09.098176
# Unit test for function map_structure
def test_map_structure():
    structure_list = [0, [1, 2, 3], (4, 5), {"name": "Scott", "age": 25, "job": "Researcher", "hobbies": {"coding": "Python"}}]
    def add_list_2(list):
        return [list[i] + 2 for i in range(len(list))]

    def add_tuple_2(tuple):
        return tuple + (2,)

    def add_dict_2(dict):
        return {key: value + 2 for key, value in dict.items()}

    structure_list = map_structure(add_list_2, structure_list)

# Generated at 2022-06-11 21:53:17.058750
# Unit test for function no_map_instance
def test_no_map_instance():
    # Build a sequence of objects of the same type but have different content
    s = no_map_instance(['a', 'b', 'c'])
    t = no_map_instance(['a', 'b', 'c'])
    u = ['a', 'b', 'c']
    # Check that s and t are not identical but still the same type
    assert s == t, "no_map_instance fails to produce the same object"
    assert s is not t, "no_map_instance fails to produce the same object"
    assert s.__class__ == t.__class__, "no_map_instance produces object of different types"
    # Check that u and s are not the same type
    assert s.__class__ != u.__class__, "no_map_instance fails to produce object with different types"

# Generated at 2022-06-11 21:53:19.669794
# Unit test for function no_map_instance
def test_no_map_instance():
    a = [1,2,3]
    b = no_map_instance(a)
    c = map_structure(lambda x: x+1, b)
    assert a == c

# Generated at 2022-06-11 21:53:27.019712
# Unit test for function map_structure
def test_map_structure():
    fn_test = lambda x: x + 1
    obj_test = [[[[[[[1,2],[3,4],[[1,2]]]]]]]]
    assert map_structure(fn_test, obj_test) == [[[[[[[2,3],[4,5],[[2,3]]]]]]]]
    obj_test = {"1":[1, 2], (1,):[1, 2], "2":{"1":1}}
    assert map_structure(fn_test, obj_test) == {"1":[2, 3], (1,):[2, 3], "2":{"1":2}}

# Generated at 2022-06-11 21:53:33.683770
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(int, (1.0, 2.0)) == (1, 2)
    assert map_structure(int, [1.1, 2.3]) == [1, 2]
    assert map_structure(int, (-1.1, 2.3)) == (-1, 2)
    assert map_structure(int, {'a': 1.1, 'b': 2.3}) == {'a': 1, 'b': 2}
    assert map_structure(int, (1.1,)) == (1,)
    assert map_structure(int, [1.1]) == [1]
    assert map_structure(int, range(0, 10)) == range(0, 10)


if __name__ == "__main__":
    test_map_structure()

# Generated at 2022-06-11 21:53:43.837812
# Unit test for function no_map_instance
def test_no_map_instance():
    from typing import NamedTuple
    from collections import OrderedDict
    # Unit test for function no_map_instance

# Generated at 2022-06-11 21:53:57.250456
# Unit test for function map_structure
def test_map_structure():
    test_list = []
    test_list.append({'a': 1, 'b': ['c', 'd']})
    test_list.append({'a': 2, 'b': ['e', 'f']})
    test_list.append({'a': 3, 'b': ['g', 'h']})
    test_list.append({'a': 4, 'b': ['i', 'j']})

    result = map_structure(lambda l: [i - 1 for i in l], test_list)

    assert result[0]['a'] == 0
    assert result[0]['b'][0] == 'c'
    assert result[0]['b'][1] == 'd'
    assert result[1]['a'] == 1
    assert result[1]['b'][0] == 'e'


# Generated at 2022-06-11 21:54:06.596004
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import namedtuple

    TestNamedTuple = namedtuple('TestNamedTuple', ('foo', 'bar'))
    TestNamedTuple.__module__ = 'test_struct'
    TestList = list
    TestTuple = tuple

    def test_fn(obj):
        return obj

    register_no_map_class(TestList)
    register_no_map_class(TestNamedTuple)
    register_no_map_class(TestTuple)

    fn = no_map_instance(test_fn)

    assert fn(TestNamedTuple(1, 2)) is TestNamedTuple(1, 2)
    assert fn(TestTuple((1, 2),)) is TestTuple((1, 2),)

# Generated at 2022-06-11 21:54:18.506453
# Unit test for function map_structure_zip
def test_map_structure_zip():
  def fn(a, b):
    return a + b
  a = [['aa', 'bb'], ['ac', 'bd']]
  b = [['bb', 'bb'], ['bc', 'bd']]
  c = [['cb', 'bb'], ['cc', 'bd']]
  d = map_structure_zip(fn, [a, b, c])
  d_expected = [['aabb', 'bbbb'], ['acbc', 'bdbd']]
  assert (d == d_expected)

  def fn2(a, b):
    return a + b
  a = [['aa', 'bb'], ['ac', 'bd'], 'af']
  b = [['bb', 'bb'], ['bc', 'bd'], 'bf']

# Generated at 2022-06-11 21:54:28.743567
# Unit test for function no_map_instance
def test_no_map_instance():
    import logging
    import torch
    from collections import namedtuple
    from pieces.data.vocab import Vocab, MultiVocab
    from pieces.data.utils.functional import no_map_instance, map_structure, map_structure_zip

    logging.getLogger().setLevel(logging.INFO)

    # Test no_map_instance
    # Set
    set_obj = {1, 2, 3}
    set_obj_no_map = no_map_instance(set_obj)
    assert not hasattr(set_obj, "--no-map--")
    assert hasattr(set_obj_no_map, "--no-map--")
    set_obj_no_map_1 = no_map_instance(set_obj_no_map)
    assert set_obj_no_map_1

# Generated at 2022-06-11 21:54:39.335313
# Unit test for function no_map_instance
def test_no_map_instance():
    # Create a dict obj
    dict_obj = {'a':['b','c'], 'd':3}
    # Register a dict instance as non-mappable
    dict_obj_nm = no_map_instance(dict_obj)
    # Test dict obj is non-mappable instance
    assert dict.__class__ in _NO_MAP_TYPES
    assert hasattr(dict_obj_nm, '_NO_MAP_INSTANCE_ATTR')

    # Create a subtype of dict
    class subdict(dict):
        pass
    # Create a subdict obj
    subdict_obj = subdict({'a':['b','c'], 'd':3})
    # Register a subdict instance as non-mappable
    subdict_obj_nm = no_map_instance(subdict_obj)


# Generated at 2022-06-11 21:54:48.256329
# Unit test for function map_structure
def test_map_structure():
    objs = {"a" : [1, 2, 3],
            "b" : {"c" : "ccc", "d" : "ddd"}}
    h = {"a" : 4,
         "b" : {"c" : "c4", "d" : "d4"}}
    t = {"a" : 5,
         "b" : {"c" : "c5", "d" : "d5"}}
    objs_ = {"a" : [1, 2, 3],
             "b" : {"c" : "ccc", "d" : "ddd"},
             "h" : h,
             "t" : t}
    def func(objects, key = None):
        if key is None:
            objects['h'] = h
            objects['t'] = t

# Generated at 2022-06-11 21:54:59.021724
# Unit test for function map_structure_zip
def test_map_structure_zip():
    word_to_id = {
        "abandon": 0,
        "abandoned": 1,
        "abandoning": 2,
        "abandonment": 3,
        "abandonments": 4,
        "abandons": 5,
    }

    def mapper(sentences, word):
        return sentences + [word_to_id[word]]

    sentences = [
        ["this", "is", "a", "test", "."],
        ["this", "is", "one", "more", "test", "."]]

    tmp_sentences = map_structure_zip(mapper, sentences)
    print(tmp_sentences)

# Generated at 2022-06-11 21:55:04.323280
# Unit test for function no_map_instance
def test_no_map_instance():
    a = [1, 2, 3]
    b = set([4, 5, 6])
    c = (4, 5, 6)
    d = {'a': 1, 'b': 2}
    list_of_dict = [a, b, c, d]
    def test_fn(obj):
        return obj
    assert map_structure(test_fn, list_of_dict) == \
           map_structure(test_fn, map_structure(no_map_instance, list_of_dict))

if __name__ == '__main__':
    test_no_map_instance()

# Generated at 2022-06-11 21:55:15.133430
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from collections import namedtuple

    # Test builtin collections
    A = namedtuple('A', 'x y') # type: Type[Tuple[int, int]]
    B = namedtuple('B', 'a b') # type: Type[Tuple[int, int]]

    @no_type_check
    def f(x: int, y: int) -> int:
        return x + y

    def test_builtin(a: Tuple[int, int], b: Tuple[int, int], expected: Tuple[int, int]) -> None:
        c = map_structure_zip(f, (a, b))
        assert c == expected

    test_builtin((1, 2), (3, 4), (4, 6))

# Generated at 2022-06-11 21:55:18.314396
# Unit test for function no_map_instance
def test_no_map_instance():
    a = torch.zeros(2)
    b = [a, a]
    c = no_map_instance(b)
    d = map_structure(lambda x: x * 2, c)
    assert c == d

# Generated at 2022-06-11 21:55:28.371968
# Unit test for function no_map_instance
def test_no_map_instance():
    mylist = [0]
    mylist = no_map_instance(mylist)
    assert mylist == [0]
    assert not isinstance(mylist, list)
    assert hasattr(mylist, "_no_maplist")
    assert hasattr(mylist, "--no-map--")

# Generated at 2022-06-11 21:55:36.240114
# Unit test for function map_structure
def test_map_structure():
    obj = {
        "name": "jack",
        "age": 18,
        "friend": {
            "name": "rose",
            "age": 19,
        },
    }

    def fn(obj):
        if isinstance(obj, str):
            return obj.upper()
        else:
            return obj

    assert map_structure(fn, obj) == {
        "name": "JACK",
        "age": 18,
        "friend": {
            "name": "ROSE",
            "age": 19,
        },
    }

    fn = lambda x, y: x + y
    assert map_structure_zip(fn, ["a", "b"], [1, 2]) == ['a1', 'b2']


if __name__ == "__main__":
    test_map_st

# Generated at 2022-06-11 21:55:44.189351
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = {'a': 'a', 'b': 'b'}
    b = {'a': 'aa', 'b': 'bb'}
    a_length = map_structure_zip(lambda x: len(x), [a])
    a_b_length = map_structure_zip(lambda x, y: len(x)+len(y), [a, b])
    assert a_length == {'a': 1, 'b': 1}
    assert a_b_length == {'a': 2, 'b': 2}

# Generated at 2022-06-11 21:55:50.897214
# Unit test for function map_structure_zip
def test_map_structure_zip():
    x = (1,2,3)
    y = (4,5,6)
    z = (7,8,9)
    print(map_structure_zip(lambda a,b,c: a+b+c, objs=[x,y,z]))
    print(map_structure_zip(lambda a,b,c: a+b+c, objs=[x,y,z]))


if __name__ == "__main__":
    test_map_structure_zip()

# Generated at 2022-06-11 21:56:03.316952
# Unit test for function map_structure

# Generated at 2022-06-11 21:56:13.929455
# Unit test for function map_structure
def test_map_structure():
    # Test 1
    list1 = [1,2,3]
    list2 = map_structure(lambda x:x+1, list1)
    print(list2)
    # Test 2
    list3 = [1, [1, 2], [3, 4]]
    list4 = map_structure(lambda x: x+1, list3)
    print(list4)
    # Test 3
    import collections
    T = collections.namedtuple("T", ['a', 'b', 'c'])
    t1 = T(a = 1, b = 2, c = 3)
    t2 = map_structure(lambda x:x+1, t1)
    print(t2)
    # Test 4

# Generated at 2022-06-11 21:56:25.978790
# Unit test for function map_structure
def test_map_structure():
    import pytest

    def f(x):
        return x*x
    a = [1,2,3]
    b = [[1,2],[3,4],[5,6]]
    c = (1,2,[3,4])
    d = {'1':1,'2':2}
    answera = [1,4,9]
    answerb = [[1,4],[9,16],[25,36]]
    answerc = (1,4,[9,16])
    answerd = {'1':1,'2':4}

    assert (map_structure(f,a) == answera)
    assert (map_structure(f,b) == answerb)
    assert (map_structure(f,c) == answerc)
    assert (map_structure(f,d) == answerd)

# Generated at 2022-06-11 21:56:36.281798
# Unit test for function no_map_instance
def test_no_map_instance():
    @register_no_map_class
    class Foo(list): pass
    foo = Foo([1, 2, 3])
    assert not isinstance(foo, tuple)
    assert isinstance(foo, list)
    foo = no_map_instance(foo)
    assert not isinstance(foo, tuple)
    assert not isinstance(foo, list)
    class Bar(tuple): pass
    bar = Bar((1, 2, 3))
    assert isinstance(bar, tuple)
    assert not isinstance(bar, list)
    bar = no_map_instance(bar)
    assert not isinstance(bar, tuple)
    assert not isinstance(bar, list)

# Generated at 2022-06-11 21:56:42.175457
# Unit test for function map_structure_zip
def test_map_structure_zip():
    A = namedtuple('A', 'a b')
    B = namedtuple('B', 'a b')
    c1 = [A(1, 2), A(3, 4)]
    c2 = [B(5, 6), B(7, 8)]
    sum_ = lambda xs: sum(xs)
    res = map_structure_zip(sum_, [c1, c2])
    assert res == [A(6, 8), A(10, 12)]
    print('PASS')

if __name__ == "__main__":
    test_map_structure_zip()

# Generated at 2022-06-11 21:56:52.271264
# Unit test for function map_structure_zip
def test_map_structure_zip():
    objs = [[[1, 2], [3, 4]], [[5, 6], [7, 8]], [[9, 10], [11, 12]]]
    objs2 = [[1, 2], [3, 4]]
    objs3 = [[[1, 2], [3, 4]], [[1, 2], [3, 4]]]
    objs4 = [[[1, 2], [3, 4]], [[1, 2], 5]]
    objs5 = [[[1, 2], [3, 4]], [[1, 2], [3, 4]], 5]
    objs6 = [[[1, 2], [3, 4]], [[1, 2], [3, 4]], [[1, 2], [3, 4]]]


# Generated at 2022-06-11 21:57:06.670970
# Unit test for function no_map_instance
def test_no_map_instance():
    import numpy as np
    import torch
    register_no_map_class(np.ndarray)
    register_no_map_class(torch.Size)

    def fn(x):
        if isinstance(x, np.ndarray):
            return x.shape
        elif isinstance(x, torch.Size):
            return int(np.prod(x))
        else:
            return x

    x = {'a':'1', 'b': [np.array([1,2,3]), np.array([4,5,6])], 'c': torch.Size([1,2,3])}
    y = no_map_instance(x)
    assert map_structure(fn, y) == {'a': '1', 'b': [(3,), (3,)], 'c': 6}

# Generated at 2022-06-11 21:57:15.571338
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import torch
    import numpy as np
    from poutyne.framework.callbacks.metrics import Metric
    from poutyne.framework.callbacks import Callback
    from poutyne import set_seeds
    set_seeds(0)

# Generated at 2022-06-11 21:57:21.316724
# Unit test for function no_map_instance
def test_no_map_instance():

    # Create an empty list
    lst = []

    # Add a single element to the list
    lst.append(1)
    lst.append(2)
    lst.append(3)

    print(lst)

    # Make the list instance nonmappable
    lst = no_map_instance(lst)

    print(lst)

    # Map a function over the list using map_structure
    lst = map_structure(lambda x: x + 1, lst)

    print(lst)


# Generated at 2022-06-11 21:57:25.806884
# Unit test for function no_map_instance
def test_no_map_instance():
    source = {1: 2, 3: [4, 5], 6: 7}
    target = {1: 2, 3: no_map_instance([4, 5]), 6: 7}
    result = map_structure(lambda x: x, target)
    assert source == result

# Generated at 2022-06-11 21:57:36.033476
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def f(a, b):
        return a + b

    a = [4, 5, 6]
    b = [1, 2, 3]
    x = map_structure_zip(f, [a, b])
    assert(x == [5, 7, 9])

    a = [4, 5, 6]
    b = [1, 2, 3]
    c = [9]
    # x = map_structure_zip(f, [a, b, c])
    # assert(x == [5, 7, 9])

# Generated at 2022-06-11 21:57:48.820674
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # test list
    a = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    b = map_structure_zip(lambda *x: sum(x)//len(x), a)
    assert (b == [[1, 2, 3], [4, 5, 6], [7, 8, 9]])

    # test tuple
    c = tuple((1, 2, 3))
    d = tuple((4, 5, 6))
    e = tuple((7, 8, 9))
    f = tuple((a, b, c, d, e))
    g = map_structure_zip(lambda *x: sum(x)//len(x), f)
    assert (g == (4, 5, 6))

    # test dict

# Generated at 2022-06-11 21:57:52.172447
# Unit test for function no_map_instance
def test_no_map_instance():
    x = no_map_instance([1, [2, 3]])
    assert x[1][1] == 3

# Generated at 2022-06-11 21:58:02.670125
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from torch.nn.modules.container import ModuleList
    from .unittest_utils import some_tensor_fn
    list_of_lists = [list(range(5)), [1, 1, 1, 1, 1]]
    result = map_structure_zip(some_tensor_fn, list_of_lists)
    list_of_tensors = [torch.tensor(li) for li in list_of_lists]
    expected_result = map_structure_zip(some_tensor_fn, list_of_tensors)
    assert (result == expected_result)
    list_of_module_lists = [ModuleList(list_of_tensors[i:i+2]) for i in range(len(list_of_tensors) - 1)]
    result = map_structure_

# Generated at 2022-06-11 21:58:07.123973
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a=[1,2,3]
    b=['a','b','c']
    c=['a','c','b']
    def func(a,b,c):
        if b==c:
            return a+1
        else:
            return a
    print(map_structure_zip(func,[a,b,c]))

# Generated at 2022-06-11 21:58:17.443447
# Unit test for function no_map_instance
def test_no_map_instance():
    # Test for list type
    list_object = [1, 2, [3, 4]]
    list_object = no_map_instance(list_object)
    assert hasattr(list_object, _NO_MAP_INSTANCE_ATTR)

    # Test for tuple type
    tuple_object = (1, 2, (3, 4))
    tuple_object = no_map_instance(tuple_object)
    assert hasattr(tuple_object, _NO_MAP_INSTANCE_ATTR)

    # Test for dict type
    dict_object = {1: 2, 2: 3}
    dict_object = no_map_instance(dict_object)
    assert hasattr(dict_object, _NO_MAP_INSTANCE_ATTR)

# Test function map_structure

# Generated at 2022-06-11 21:58:54.016708
# Unit test for function map_structure_zip
def test_map_structure_zip():
    A = namedtuple('A', 'a b')
    B = namedtuple('B', 'a d')
    a = A(a=1, b=2)
    b = B(a=1, d=3)
    C = map_structure_zip(lambda x, y: (x, y), [a, b])
    print(C)

    a = {'a': 1, 'b': 2}
    b = {'a': 1, 'd': 3}
    C = map_structure_zip(lambda x, y: (x, y), [a, b])
    print(C)

    a = {'a': 1, 'b': 2}
    b = {'a': 1, 'd': 3}

# Generated at 2022-06-11 21:59:03.979657
# Unit test for function map_structure
def test_map_structure():
    a = np.array([[1,2],[3,4]])
    b = np.array([1,0,1])
    c = np.array([2,0,2])
    d = np.array([[1,1],[1,1]])
    def f(x,y,z,w):
        if(len(np.shape(x)) == 1):
            x = np.array([[x[0]],[x[1]],[x[2]]])
        if(len(np.shape(y)) == 1):
            y = np.array([[y[0]],[y[1]],[y[2]]])
        if(len(np.shape(z)) == 1):
            z = np.array([[z[0]],[z[1]],[z[2]]])
        return x+y

# Generated at 2022-06-11 21:59:10.094723
# Unit test for function no_map_instance
def test_no_map_instance():
    def func(d):
        return d
    d = [1, 2, 3]
    assert list(map_structure(func, d)) == [1, 2, 3]
    assert list(map_structure(func, no_map_instance(d))) == [no_map_instance([1, 2, 3])]

# Generated at 2022-06-11 21:59:22.641275
# Unit test for function map_structure_zip
def test_map_structure_zip():
    x_tuple = (1, 2, 3)
    x_dict = {'a': (1,), 'b': (2,)}
    x_list = [-1, 0, 1]
    y_dict = {'a': (2,), 'b': (3,)}
    y_list = [-2, 0, 2]
    add_fn = lambda *xs: [x1 + x2 for x1, x2 in zip(*xs) if x1 == x2]
    add_fn2 = lambda *xs: [x1 + x2 for x1, x2 in zip(*xs)]
    add_fn3 = lambda x1, x2: [x11 + x22 for x11, x22 in zip(x1, x2)]

# Generated at 2022-06-11 21:59:34.246993
# Unit test for function map_structure
def test_map_structure():
    import unittest
    
    class TestCase(unittest.TestCase):
        def test_simple_map_structure(self):
            self.assertEqual(map_structure(lambda x: x + 1, [1, 2, 3]), [2, 3, 4])
            self.assertEqual(map_structure(lambda x: x + 1, (1, 2, 3)), (2, 3, 4))
            self.assertEqual(map_structure(lambda x: x + 1, {'a': 1, 'b': 2, 'c': 3}), {'a': 2, 'b': 3, 'c': 4})
            self.assertEqual(map_structure(lambda x: x + 1, {1, 2, 3}), {2, 3, 4})


# Generated at 2022-06-11 21:59:43.769944
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from collections import namedtuple
    Node = namedtuple('Node', ['id', 'children'])

    def _step(node_id, children_ids, nodes):
        children = [nodes[id_] for id_ in children_ids]
        return Node(id=node_id, children=children)
    tree = {'id': 0, 'children': [{'id': 1, 'children': [{'id': 2, 'children': []}]}, {'id': 3, 'children': []}]}
    actual = map_structure_zip(_step, tree.keys(), tree.values(), [[tree]])
    expected = [Node(id=0, children=[Node(id=1, children=[Node(id=2, children=[])])])]
    assert actual == expected
