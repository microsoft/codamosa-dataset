

# Generated at 2022-06-11 21:49:49.682453
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(a, b):
        return a+b
    a = [1,2,3]
    b = [2,2,2]
    c = [3,3,3]
    print('map_structure_zip')
    print(map_structure_zip(fn, [a,b,c]))
    print(list(zip(a,b,c)))

if __name__=='__main__':
    test_map_structure_zip()

# Generated at 2022-06-11 21:50:00.063752
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def sum_two_lists(list1, list2):
        return [l1 + l2 for l1, l2 in map_structure_zip(lambda x, y: x + y,
                                                        [list1, list2])]

    def sum_two_dicts(dict1, dict2):
        return {k: v1 + v2 for k, (v1, v2) in map_structure_zip(lambda x, y: x + y,
                                                                [dict1, dict2]).items()}

    def sum_two_tuples(tuple1, tuple2):
        return tuple(map_structure_zip(lambda x, y: x + y, [tuple1, tuple2]))

    assert sum_two_tuple

# Generated at 2022-06-11 21:50:10.730861
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import torch
    def add_fn(a, b):
        return a + b
    input1 = torch.rand(2, 3, 4)
    input2 = torch.rand(2, 3, 4)
    input3 = torch.rand(2, 3, 4)

    output1 = map_structure_zip(add_fn, (input1, input2))
    assert output1.shape == input1.shape
    assert torch.equal(input1 + input2, output1)

    output2 = map_structure_zip(add_fn, (input1, input2, input3))
    assert output2.shape == input1.shape
    assert torch.equal(input1 + input2 + input3, output2)


# Generated at 2022-06-11 21:50:19.680725
# Unit test for function map_structure
def test_map_structure():
    def fn(x):
        return x[0]

    def fn2(x):
        return x+1

    obj1 = no_map_instance({"a":[3,4], 'b':4})
    obj2 = {"c":[1,2], 'd':{'e':2}}
    obj3 = {"a":[[1,2], [3,4]], 'b':4}
    res = map_structure(fn, obj1)
    assert(res == {'a':3, 'b':4})

    new_obj1 = map_structure(fn2, obj2)
    assert(new_obj1 == {"c":[2,3], 'd':{'e':3}})

    new_obj2 = map_structure(fn, obj3)

# Generated at 2022-06-11 21:50:24.893385
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = [[1, 2], [3, 4]]
    b = [[5, 6], [7, 8]]
    c = [[9, 10], [11, 12]]
    def sum_3(x, y, z):
        return x+y+z
    assert map_structure_zip(sum_3, [a, b, c]) == [[15, 18], [21, 24]]

# Generated at 2022-06-11 21:50:32.079398
# Unit test for function no_map_instance
def test_no_map_instance():
    import numpy as np
    import torch

    class MyList(list):
        pass

    mylist = MyList([1,2,3])
    # assert the new type is created
    assert(type(mylist) != type(no_map_instance(mylist)))
    # assert the new type is not created
    mylist = [1, 2, 3]
    assert(type(mylist) == type(no_map_instance(mylist)))
    # assert the new type is created
    a = [np.array([1]), torch.FloatTensor([1])]
    mylist = MyList(a)
    assert(mylist.__class__ != type(no_map_instance(mylist)))


if __name__ == "__main__":
    test_no_map_instance()

# Generated at 2022-06-11 21:50:36.937439
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(a, b, c):
        return [a, b, c]
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    result = map_structure_zip(fn, (a, b, c))
    assert(result == [[1, 4, 7], [2, 5, 8], [3, 6, 9]])



# Generated at 2022-06-11 21:50:46.758314
# Unit test for function map_structure
def test_map_structure():


    def id_fn(x):
        return x


    def add1_fn(x):
        return x + 1
    
    l1 = [1, 2, 3]
    l2 = [4, 5, 6]
    l3 = [7, 8, 9]
    l4 = [l1, l2, l3]
    l5 = [l4, l4]
    assert map_structure(id_fn, l1) == l1
    assert map_structure(id_fn, l4) == l4
    assert map_structure(id_fn, l5) == l5
    assert map_structure(add1_fn, l1) == [2, 3, 4]

# Generated at 2022-06-11 21:50:52.846702
# Unit test for function map_structure
def test_map_structure():
    test_list = [[1,2,3],[4,5,6],[7,8,9]]
    def test_map_fn(a):
        return a*a
    a = map_structure(test_map_fn, test_list)
    assert a == [[1,4,9],[16,25,36],[49,64,81]]

# Generated at 2022-06-11 21:51:02.130844
# Unit test for function map_structure
def test_map_structure():
    list_in = [[1, 2, 3], [[5, 6, 7], [8, 9, 10]]]
    list_out = [[2, 4, 6], [[10, 12, 14], [16, 18, 20]]]
    list_out_map = map_structure(lambda x: x * 2, list_in)
    assert list_out_map == list_out

    tuple_in = (1, (2, (3, 4)))
    tuple_out = (2, (4, (6, 8)))
    tuple_out_map = map_structure(lambda x: x * 2, tuple_in)
    assert tuple_out_map == tuple_out

    dict_in = {'a': 1, 'b': {'c': 2, 'd': 3}}

# Generated at 2022-06-11 21:51:17.993787
# Unit test for function map_structure_zip
def test_map_structure_zip():
    # Case of identical tuple
    t1 = ((10, 11), (20, 21))
    t2 = ((10, 11), (20, 21))
    assert map_structure_zip(lambda a, b: a + b, [t1, t2]) == ((20, 22), (40, 42))

    # Case of nested tuple
    t3 = (((10, 11), (20, 21)), (30, 31))
    t4 = (((10, 11), (20, 21)), ((30, 31), (40, 41)))
    assert map_structure_zip(lambda a, b: a + b, [t3, t4]) == (((20, 22), (40, 42)), (60, 62))

    # Case of nested list
    l1 = [[10, 11], [20, 21]]

# Generated at 2022-06-11 21:51:24.076922
# Unit test for function map_structure_zip
def test_map_structure_zip():
    obj1 = [{'a': 1, 'b': 2}, 3]
    obj2 = [{'a': 4, 'b': 5}, 6]
    ab = [1, 2, 3, 4, 5, 6]
    test_fn = lambda x, y: x + y
    obj3 = map_structure_zip(test_fn, [obj1, obj2])
    assert(obj3 == ab)



# Generated at 2022-06-11 21:51:35.124843
# Unit test for function map_structure_zip
def test_map_structure_zip():
    test_list1 = [1, 2, 3]
    test_list2 = ['a', 'b', 'c']
    test_list3 = ['2', 'b', 'c']
    test_tuple = (1, 2, 3)
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_list4 = [1, 'b', 'c']

    assert (map_structure_zip(lambda x, y: x * y, [test_list1, test_list2]) == ['a', 'bb', 'ccc'])
    assert (map_structure_zip(lambda x, y: x * y, [test_list1, test_list3]) == ['2', 'bb', 'ccc'])

# Generated at 2022-06-11 21:51:43.216776
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def add(x,y):
        return x + y
    a = [['a','b'],['c','d'],['e','f']]
    b = [['g','h'],['i','j'],['k','l']]
    c = [['m','n'],['o','p'],['r','s']]
    d = map_structure_zip(add, [a,b,c])
    print(d)
    expected = [['agm','bhn'],['cio','djp'],['erk','fls']]
    assert d == expected
    # Test for exceptions when there is wrong number of inputs
    def add3(x,y,z):
        return x + y + z
    a = [['a','b'],['c','d'],['e','f']]

# Generated at 2022-06-11 21:51:47.870467
# Unit test for function map_structure_zip
def test_map_structure_zip():
    objs1 = [2, 3, 4]
    objs2 = [1, 2, 3]
    add = lambda x,y: x+y
    assert map_structure_zip(add, [objs1, objs2]) == [3, 5, 7]

# Generated at 2022-06-11 21:52:00.057607
# Unit test for function map_structure
def test_map_structure():
    obj = {'a': 1, 'b': 2}
    change_structure = lambda obj: {key: value+1 for key, value in obj.items()}
    intended_obj = {'a': 2, 'b': 3}

    assert intended_obj == map_structure(change_structure, obj)

    obj = {'a': [1, 2, 3], 'b': 4, 'c': {'d': 5}}
    change_structure = lambda obj: {key: value+1 for key, value in obj.items()}
    intended_obj = {'a': [2, 3, 4], 'b': 5, 'c': {'d': 6}}

    assert intended_obj == map_structure(change_structure, obj)


# Generated at 2022-06-11 21:52:02.247912
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance([1, 2, 3]) == [1, 2, 3]
    assert hash(no_map_instance([1, 2, 3])) != id([1, 2, 3])


# Generated at 2022-06-11 21:52:13.865765
# Unit test for function map_structure_zip
def test_map_structure_zip():
  nlp = spacy.load("en_core_web_sm")

  def tokenizer(sentence):
    tokens = [token.text for token in nlp(sentence)]
    return tokens
  def add_per(sentence):
    per = 'per'
    return per
  def add_per_manually(list1, list2):
    return [list1[i] + list2[i] for i in range(len(list1))]
  list1 = tokenizer("hello world")
  list2 = tokenizer("hi there")
  list3 = tokenizer("bye now")
  result = map_structure_zip(add_per_manually, [list1, list2, list3])
  print(result)



# Generated at 2022-06-11 21:52:15.384333
# Unit test for function no_map_instance
def test_no_map_instance():
    assert no_map_instance(torch.Size((1, 2, 3))) == torch.Size((1, 2, 3))

# Generated at 2022-06-11 21:52:25.093718
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import torch

    a = [1, 2, 3]
    b = [1.0, 2.0, 3.0]
    c = torch.Tensor([1.0, 2.0, 3.0])
    d = map_structure_zip(lambda x, y, z: x + y + z, a, b, c)
    assert d == [3.0, 7.0, 12.0]

    e = ([1, 2, 3],)
    f = ([1.0, 2.0, 3.0],)
    g = map_structure_zip(lambda x, y: [x, y], a, b)
    assert g == e
    h = map_structure_zip(lambda x, y: [x, y], a, c)
    assert h == f


# Generated at 2022-06-11 21:52:34.608925
# Unit test for function map_structure_zip
def test_map_structure_zip():
    d1 = {'a': 1, 'b': 2}
    d2 = {'a': 1, 'b': 3}
    d3 = {'a': 1, 'b': 4}

    # length 3
    assert map_structure_zip(lambda x, y, z: x + y + z, [d1, d2, d3]) == {'a': 3, 'b': 9}

    # length 1
    assert map_structure_zip(lambda x: x, [d1]) == {'a': 1, 'b': 2}

# Generated at 2022-06-11 21:52:44.705464
# Unit test for function no_map_instance
def test_no_map_instance():
    # Preparing
    from collections import OrderedDict
    ordered_dict1 = OrderedDict([(1, 1), (2, 2)])
    ordered_dict2 = OrderedDict([(1, 3), (2, 4)])
    ordered_dict3 = OrderedDict([(1, 1), (2, 2), (3, 3)])
    ordered_dict4 = OrderedDict([(1, 3), (2, 4), (3, 5)])
    ordered_dict5 = OrderedDict([(1, 1), (2, 2), (3, 3), (4, 4)])
    ordered_dict6 = OrderedDict([(1, 3), (2, 4), (3, 5), (4, 6)])

# Generated at 2022-06-11 21:52:48.930432
# Unit test for function map_structure_zip
def test_map_structure_zip():
    list_a = [[1, 2], [3, 4]]
    list_b = [[1, 1], [1, 1]]

    def f(a, b):
        return a + b

    list_c = map_structure_zip(f, [list_a, list_b])
    print(list_c)



if __name__ == "__main__":
    test_map_structure_zip()

# Generated at 2022-06-11 21:52:51.692940
# Unit test for function no_map_instance
def test_no_map_instance():
    l = [1, 2, 3]
    m = no_map_instance(l)
    assert l == m
    assert id(l) == id(m)
    assert m._NO_MAP_INSTANCE_ATTR == True

# Generated at 2022-06-11 21:52:57.970520
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a = (1, [2, 3], {'c': 4, 'd': 5})
    b = (6, [7, 8], {'c': 9, 'd': 10})
    c = (11, [12, 13], {'c': 14, 'd': 15})
    sum_ab = (7, [9, 11], {'c': 13, 'd': 15})
    sum_abc = (18, [21, 24], {'c': 27, 'd': 30})

    assert sum_ab == map_structure_zip(sum, (a, b))
    assert sum_abc == map_structure_zip(sum, (a, b, c))


# Generated at 2022-06-11 21:53:09.635543
# Unit test for function map_structure
def test_map_structure():
    d = {
        "a": 1,
        "b": [1, 2, 3],
        "c": {
            "d": 2,
            "e": [{
                "f": 3,
                "g": 4
            },
                {
                    "h": 5,
                    "i": "a"
                },
                4]
        }
    }
    d = map_structure(lambda x: x+1, d)
    assert d['a'] == 2
    assert d['b'] == [2, 3, 4]
    assert d['c']['d'] == 3
    assert d['c']['e'][0]['f'] == 4
    assert d['c']['e'][0]['g'] == 5

# Generated at 2022-06-11 21:53:15.338161
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import numpy as np
    # map the function add two elements
    def add(x, y):
        return x + y
    a = np.array([[1,2,3],[4,5,6]])
    b = np.array([[7,8,9],[10,11,12]])
    c = np.array([[13,14,15],[16,17,18]])
    result = map_structure_zip(add, [a, b, c])
    print(result)


# Generated at 2022-06-11 21:53:21.238046
# Unit test for function no_map_instance
def test_no_map_instance():
    class A(list): pass
    class B(A): pass
    a = A([1, 2, 3])
    b = B([1, 2, 3])

    assert(a==map_structure(str, a))
    assert(b==map_structure(str, b))

    def f(x): return no_map_instance(x)
    assert(a==map_structure(f, a))
    assert(b==map_structure(f, b))

    register_no_map_class(A)
    assert(no_map_instance(a)==map_structure(f, a))
    assert(no_map_instance(b)==map_structure(f, b))

    # test for ObjectDict
    from utils.misc_utils import ObjectDict

# Generated at 2022-06-11 21:53:24.025014
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instance([1, 2, 3])
    b = no_map_instance([4, 5, 6])
    c = map_structure(lambda x: x, [a, b])
    assert (c[0] == a) and (c[1] == b)


# Generated at 2022-06-11 21:53:32.369989
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def f1(x):
        return x

    def f2(x, y):
        return x + y

    def f3(x):
        return x['x']

    def f4(x, y):
        return x['x'] + y

    def f5(x, y):
        return x + y['x']

    def f6(x, y, z):
        return x['x'] + y['x'] + z['x']

    def g(x, y, z, w):
        return x + y + z + w

    C1 = [
        [],
        [1],
        [1, 2],
    ]
    C2 = [
        {},
        {'x': 1},
        {'x': 1, 'y': 2}
    ]

# Generated at 2022-06-11 21:53:45.599949
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def f(a, b):
        return a + b

    A = [{'a': 1, 'b': 2}, {'a': 0, 'b': 1}, {'a': 7, 'b': 8}]
    B = [{'a': 1, 'b': 0}, {'a': 2, 'b': 0}, {'a': 9, 'b': 2}]
    C = [{'a': 1, 'b': 0}, {'a': 5, 'b': 3}, {'a': 2, 'b': 5}]

    R = map_structure_zip(f, [A, B, C])
    assert R == [{'a': 3, 'b': 2}, {'a': 7, 'b': 4}, {'a': 18, 'b': 15}]

# Generated at 2022-06-11 21:53:53.882410
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def interact(objs):
        def fn(x, y):
            return x + y
        return map_structure_zip(fn, objs)
    res = interact([[1, 2, 3], [4, 5, 6]])
    print(res)
    assert res == [5, 7, 9]
    res = interact([(1, 2), (3, 4)])
    print(res)
    assert res == (4, 6)

if __name__ == "__main__":
    test_map_structure_zip()

# Generated at 2022-06-11 21:54:04.460253
# Unit test for function map_structure
def test_map_structure():
    a = [[1,2,3],[4,5,6]]
    b = [[1,2,3],[4,5,6],[7,8,9]]
    c = [[1,2,3],[4,5,6]]
    d = [[1,2,3,4],[4,5,6,7],[7,8,9,10]]
    e = [[1,2,3,4],[4,5],[7,8,9,10]]
    containers = [a, b, c, d, e]

    def _add_1(t):
        return [x+1 for x in t]

    for container in containers:
        try:
            _ = map_structure(_add_1, container)
        except Exception as e:
            print(f'Fail to map structure {container}')


# Generated at 2022-06-11 21:54:05.928011
# Unit test for function no_map_instance
def test_no_map_instance():
    a = no_map_instanc

# Generated at 2022-06-11 21:54:13.386497
# Unit test for function no_map_instance
def test_no_map_instance():
    class A:
        def __iter__(self):
            return iter([1, 2, 3])

    a_obj = A()
    for a_elm in a_obj:
        print(a_elm)

    # It's necessary to always say list.
    # If we just say ls, the element of list will still be iter
    # [1, 2, 3]
    ls = [a_obj]
    for a_elm in ls:
        print(a_elm)
    for a_elm in ls[0]:
        print(a_elm)

    # [1, 2, 3]
    ls = [no_map_instance(a_obj)]
    for a_elm in ls:
        print(a_elm)



# Generated at 2022-06-11 21:54:24.052845
# Unit test for function map_structure_zip
def test_map_structure_zip():
    list1 = [1,2,3]
    list2 = [4,5,6]
    tuple1 = (1,2,3)
    tuple2 = (4,5,6)
    dict1 = {'a':1,'b':2,'c':3}
    dict2 = {'a':4,'b':5,'c':6}
    assert map_structure_zip(lambda x,y:x+y, [list1, list2]) == [5,7,9]
    assert map_structure_zip(lambda x,y:x+y, [tuple1, tuple2]) == (5,7,9)
    assert map_structure_zip(lambda x,y:x+y, [dict1, dict2]) == {'a':5,'b':7,'c':9}
    assert map

# Generated at 2022-06-11 21:54:34.013139
# Unit test for function no_map_instance
def test_no_map_instance():
    # For basic test
    instance = [2, 3, 4]

    assert(map_structure(lambda x : x**2, instance) == map_structure(lambda x : x ** 2, no_map_instance(instance)))
    assert(map_structure_zip(lambda x, y : x + y, (instance, instance)) == map_structure_zip(lambda x, y : x + y, (no_map_instance(instance),instance)))

    # For torch.Size test
    from torch.tensor import size as torch_size
    from torch.tensor import tensor as torch_tensor
    instance = torch_size([1, 2, 3, 4])


# Generated at 2022-06-11 21:54:44.495563
# Unit test for function map_structure
def test_map_structure():
    from nose.tools import assert_raises
    from collections import namedtuple

    v1 = (1, 2, 3)
    v2 = [4, 5, 6]
    v3 = {"a": 7, "b": 8, "c": 9}
    v4 = namedtuple("V", "x y z")(10, 11, 12)
    v5 = {13, 14, 15}

    z1 = (1, 4, "a")
    z2 = [2, 5, "b"]
    z3 = {"c": 3, "d": 6, "e": 9}
    z4 = namedtuple("Z", "f g h")(10, 11, 12)
    z5 = {13, 14, 15}

    print("Test map_structure")

    # Test singleton

# Generated at 2022-06-11 21:54:49.704546
# Unit test for function no_map_instance
def test_no_map_instance():
    obj2 = [['a'], 2]
    obj1 = no_map_instance(obj2)
    obj3 = ['a']
    obj3 = no_map_instance(obj3)
    obj1[0] = obj3
    out = map_structure(lambda x: x[0], obj1)
    assert out == ['a']



# Generated at 2022-06-11 21:54:58.874179
# Unit test for function map_structure
def test_map_structure():
    test_collections = [
        [1, 2, 3],
        (1, 2, 3),
        {1, 2, 3},
        {'a': 1, 'b': 2, 'c': 3},
        (1, {'a': {'x': 1, 'y': 2}, 'b': 2}, 3),
    ]

    for col in test_collections:
        result = map_structure(lambda x: x + 1, col)
        assert result == col + 1



# Generated at 2022-06-11 21:55:24.021716
# Unit test for function no_map_instance
def test_no_map_instance():
    test = [[[['a'], [('b', 'c')]], {'d': {'e': 'f'}, 'g': ['h']}]]
    test_no_map = no_map_instance(test)
    assert test_no_map == test
    assert test_no_map.__class__ is type(test)


# Generated at 2022-06-11 21:55:34.339676
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def func_add(x, y):
        return x + y

    def func_multiply(x, y):
        return x * y

    def func_mean(x, y):
        return (x + y) / 2

    a = {"a": 1, "b": 2}
    b = {"a": 3, "b": 4}
    c = {"a": 5, "b": 6}
    d = {"a": 7, "b": 8}
    e = {"a": 9, "b": 10}
    f = {"a": 11, "b": 12}
    vec_a = [a, b, c]
    vec_b = [d, e, f]
    vec_c = [a, b, c]
    vec_d = [d, e, f]


# Generated at 2022-06-11 21:55:45.865455
# Unit test for function no_map_instance
def test_no_map_instance():
    import unittest.mock as mock

    class Foo:
        def __init__(self, x):
            self.x = x

    def check_no_map_instance(instance):
        instance.call_mock = mock.Mock()
        instance.call_mock.side_effect = lambda f: f(instance)

    Foo.check_no_map_instance = check_no_map_instance

    foo1 = Foo(1)
    foo2 = Foo(2)
    foo1.check_no_map_instance(map_structure)
    foo2.check_no_map_instance(map_structure)

    foo1 = no_map_instance(foo1)
    foo2 = no_map_instance(foo2)
    foo1.check_no_map_instance(map_structure)

# Generated at 2022-06-11 21:55:53.608796
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x:x+1, [[2, 3], 4]) == [[3, 4], 5]
    assert map_structure(lambda x:x+1, (2, 3)) == (3, 4)
    assert map_structure(lambda x:x+1, {'x':2, 'y':3}) == {'x':3, 'y':4}
    assert map_structure(lambda x:x+1, {2, 3}) == {3, 4}


# Generated at 2022-06-11 21:56:01.712231
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from pprint import pprint
    def increment(x):
        return x + 1
    list_of_dicts = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 5, 'b': 6}]
    pprint(map_structure_zip(increment, list_of_dicts))
    pprint(map_structure_zip(lambda *xs: sum(xs) / len(xs), list_of_dicts))
    def _zip_and_increment(x):
        return map_structure_zip(increment, x)
    pprint(map_structure(_zip_and_increment, list_of_dicts))

if __name__ == "__main__":
    test_map_structure_zip()

# Generated at 2022-06-11 21:56:13.252663
# Unit test for function map_structure_zip
def test_map_structure_zip():
    assert map_structure_zip(lambda a, b: a + b, [[1, 2, 3], [4, 5, 6]]) == [5, 7, 9]
    assert map_structure_zip(lambda a, b: a + b, ((1, 2, 3), (4, 5, 6))) == (5, 7, 9)
    assert map_structure_zip(lambda a, b: a + b, ({'hi': 1, 'there': 2}, {'hi': 4, 'there': 5})) == {'hi': 5, 'there': 7}
    assert map_structure_zip(lambda a, b: a + b, ({1, 2, 3}, {4, 5, 6})) == {1, 2, 3, 4, 5, 6}

if __name__ == "__main__":
    test

# Generated at 2022-06-11 21:56:25.511763
# Unit test for function map_structure_zip
def test_map_structure_zip():
    c1 = {
        'a': {'a1': 1, 'a2': 2},
        'b': [10, 20],
        'c': {'c1': 'ab', 'c2': 'cd'}
    }
    c2 = {
        'a': {'a1': 5, 'a2': 10},
        'b': [100, 200],
        'c': {'c1': 'ABC', 'c2': 'CD'}
    }
    c3 = {
        'a': {'a1': 50, 'a2': 100},
        'b': [1000, 2000],
        'c': {'c1': 'ABCD', 'c2': 'CDE'}
    }

    f = lambda x, y, z : x + y + z

# Generated at 2022-06-11 21:56:31.938670
# Unit test for function map_structure_zip
def test_map_structure_zip():

    def _f(x, y):
        return x + y
    a = [1, 2, 3]
    b = [2, 3, 4]
    c = [3, 4, 5]
    result = map_structure_zip(_f, [a, b, c])
    assert result == [6, 9, 12]

# Generated at 2022-06-11 21:56:40.926917
# Unit test for function no_map_instance
def test_no_map_instance():
    from collections import OrderedDict
    from typing import Mapping

    class TestDict(Mapping):
        def __init__(self, *args, **kwargs) -> None:
            self.d = OrderedDict(*args, **kwargs)
            self._map_structure_zip_hash = hash(self.d)
            assert hash(self.d) == self._map_structure_zip_hash

        def __len__(self) -> int: return len(self.d)
        def __iter__(self) -> Iterator[T]: return iter(self.d)
        def __getitem__(self, k: str) -> T: return self.d[k]
        def __hash__(self) -> int: return self._map_structure_zip_hash


# Generated at 2022-06-11 21:56:51.541636
# Unit test for function map_structure
def test_map_structure():
    a = [1, 2, [3, 4], (1, 2, 3), {1:2, 2:3}, {1:2, 3:4}]
    # Map fn over the elements in a
    def fn (x):
        return x**2

    b = map_structure(fn, a)
    assert b == [1, 4, [9, 16], (1, 4, 9),
                 {1: 4, 2: 9}, {1: 4, 3: 16}]

    # namedtuple, OrderedDict
    import collections
    Point = collections.namedtuple('Point', ['x', 'y'])
    pt1 = Point(1, 2)
    pt2 = Point(3, 4)
    pt3 = Point(5, 6)

# Generated at 2022-06-11 21:57:14.667319
# Unit test for function map_structure_zip
def test_map_structure_zip():
    import torch

    net = torch.nn.DataParallel(torch.nn.Module())
    # state_dict contains two keys and their values are dicts
    net.state_dict = {'key_dict_0': {'a': '1', 'b': '2'}, 'key_dict_1': {'c': '3', 'd': '4'}}
    # the list of dicts
    nets = [net.state_dict, net.state_dict]

    # a dummy function for testing
    def fn(state_dict, name):
        return name + ' ' + str(state_dict)

    def test():
        passed_args = []

        def fn2(state_dict, name):
            nonlocal passed_args
            passed_args.append((state_dict, name))

# Generated at 2022-06-11 21:57:20.530263
# Unit test for function map_structure
def test_map_structure():
    A = namedtuple('A', ['x', 'y', 'z'])
    B = namedtuple('B', ['p', 'q'])

    obj = A(B(3, 4), {"x", "y"}, [6, 5, 4])
    assert map_structure(lambda x: x - 1, obj) == A(B(2, 3), {"x", "y"}, [5, 4, 3])



# Generated at 2022-06-11 21:57:29.334735
# Unit test for function map_structure
def test_map_structure():
    def add1(x):
        return x + 1

    def add2(x):
        return x[0] + x[1]

    A = [1, 2]
    B = map_structure(add1, A)
    assert B == [2, 3]

    C = [A, A]
    D = map_structure(add1, C)
    assert D == [[2, 3], [2, 3]]

    E = map_structure(add2, D)
    assert E == [4, 6]

    F = map_structure(add2, D)
    assert F == [4, 6]

    G = {'a': [1, 2], 'b': [3, 4]}
    H = map_structure(add1, G)

# Generated at 2022-06-11 21:57:31.761536
# Unit test for function no_map_instance
def test_no_map_instance():
    l = no_map_instance(list(range(5)))
    assert hasattr(l, _NO_MAP_INSTANCE_ATTR)

# Generated at 2022-06-11 21:57:40.034767
# Unit test for function map_structure
def test_map_structure():
    d = {"a": [1, 2, 3], "b": [[4, 5], 6]}
    sq_list_dict = map_structure(lambda x: x ** 2, d)
    assert sq_list_dict['a'] == [1, 4, 9]
    assert sq_list_dict['b'] == [[16, 25], 36]

    d_nested = {"a": [1, 2, 3], "b": {"c": [4, 5], "d": 6}}
    sq_dict_dict = map_structure(lambda x: x ** 2, d_nested)
    assert sq_dict_dict['a'] == [1, 4, 9]
    assert sq_dict_dict['b']['c'] == [16, 25]
    assert sq_dict_dict['b']['d'] == 36



# Generated at 2022-06-11 21:57:50.544483
# Unit test for function map_structure
def test_map_structure():
    from collections import OrderedDict
    from xt_modules.common import namedtuple
    def add1(x):
        return x + 1
    def concat(x1,x2):
        return x1 + x2
    
    print("Testing map_structure with function add1...")
    plain_list = [1,2,3]
    plain_dict = {'a':1,'b':2,'c':3}
    plain_set = set([1,2,3])
    plain_tuple = (1,2,3)
    plain_named_tuple = namedtuple('plain_named_tuple',['a','b','c'])(1,2,3)
    list_of_set = [set([1,2,3]),set([4,5,6])]
    list_of_

# Generated at 2022-06-11 21:58:01.111359
# Unit test for function map_structure
def test_map_structure():
    obj1 = {'a': 1, ('b', 'c'): 2}
    obj2 = {'a': 1, ('b', 'c'): 2}
    obj3 = {'a': 1, ('b', 'd'): 2}
    def f(x):
        return x
    assert map_structure(f, obj1) == obj2
    with pytest.raises(AssertionError):
        assert map_structure(f, obj1) == obj3
    with pytest.raises(KeyError):
        assert map_structure(f, obj1) == obj3

if __name__ == "__main__":
    # Unit test
    test_map_structure()

# Generated at 2022-06-11 21:58:04.763029
# Unit test for function map_structure_zip
def test_map_structure_zip():
    def fn(x, y):
        return x + y

    objs = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    mapped_objects = map_structure_zip(fn, objs)
    assert mapped_objects['a'] == 4
    assert mapped_objects['b'] == 6

# Generated at 2022-06-11 21:58:08.674386
# Unit test for function map_structure
def test_map_structure():
    a=[1,2,3]
    b=[4,5,6]
    c=map_structure(sum,(a,b))
    print(c)

if __name__ == "__main__":
    test_map_structure()

# Generated at 2022-06-11 21:58:11.880721
# Unit test for function no_map_instance
def test_no_map_instance():
    import torch

    size = torch.Size([1,2,3,4])
    no_map_instance(size)
    assert isinstance(size, type(torch.Size))

# Generated at 2022-06-11 21:58:51.209309
# Unit test for function map_structure_zip
def test_map_structure_zip():
    test_list = [(1, 2), [(3, 4), (5, 6)], [{6, 7}, {8, 9}]]

    def test_fn_1(*args):
        # This function is used to test the case of tuple.
        return args

    def test_fn_2(*args):
        # This function is used to test the case of list.
        return [sum(args)]

    def test_fn_3(*args):
        # This function is used to test the case of dict.
        return args[0]

    def test_fn_4(*args):
        # This function is used to test the case of set.
        return args[0].union(args[1])

    # test tuple
    assert map_structure_zip(test_fn_1, test_list) == test_list
    assert map_

# Generated at 2022-06-11 21:59:02.328545
# Unit test for function map_structure_zip
def test_map_structure_zip():
    my_str = "Hello world"
    my_dict = {"a": 100, "b": 200}
    my_int = 100
    my_list = [1, 2, 3]
    my_tuple = (1, 2, 3)

    def fn(a, b, c, d, e):
        return a + b + c + d + e
    res = map_structure_zip(fn, [my_str, my_dict, my_int, my_list, my_tuple])
    assert res == ["Hello worlda100123", my_dict, "Hello worlda100123", my_list, my_tuple]

    def fn2(a, b, c, d, e):
        return a + b + c + d + e, a + b + c + d + e + 1
    res = map_

# Generated at 2022-06-11 21:59:10.713890
# Unit test for function no_map_instance
def test_no_map_instance():
    x_1 = numpy.array([1,2,3])
    x_2 = numpy.array([3,2,1])
    def double(x):
        return x*2
    a = no_map_instance(x_1)
    b = no_map_instance(x_2)
    assert a is b
    a = map_structure_zip(double, [a,b])
    b = map_structure_zip(double, [x_1,x_2])
    assert a is b

# Generated at 2022-06-11 21:59:18.593929
# Unit test for function no_map_instance
def test_no_map_instance():
    x = list()
    y = no_map_instance(x)
    assert(isinstance(no_map_instance(x), list))
    assert(not hasattr(no_map_instance(x), _NO_MAP_INSTANCE_ATTR))
    assert(isinstance(y, list))
    assert(hasattr(y, _NO_MAP_INSTANCE_ATTR))

# Generated at 2022-06-11 21:59:28.779256
# Unit test for function map_structure
def test_map_structure():
    assert map_structure(lambda x: x, [1, 2, 3]) == [1, 2, 3]

    assert map_structure(lambda x: x, no_map_instance([1, 2, 3])) == [1, 2, 3]

    tup = ("a", "b", 3)
    assert type(map_structure(lambda x: x, tup)) == tuple

    a, b, c = map_structure(lambda x: x, tup)
    assert a == "a"
    assert c == 3

    cur_dic = {'a': 1, 'b': 2, 'c': 3}
    assert map_structure(lambda x: x, cur_dic) == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-11 21:59:35.836658
# Unit test for function map_structure_zip
def test_map_structure_zip():
    from typing import NamedTuple, Optional
    Element = NamedTuple('Element', [('a', int),
                                     ('b', Optional[int]),
                                     ('c', str)])
    x = Element(a=0, b=None, c='p')
    y = Element(a=1, b=2, c='q')
    z = Element(a=2, b=None, c='r')
    assert map_structure_zip(lambda a, b, c: c - a - b, [x, y, z]) == Element(a=None, b=None, c='rqp')

# Generated at 2022-06-11 21:59:44.830806
# Unit test for function map_structure_zip
def test_map_structure_zip():
    a0 = {'a': [1, 2, 3], 'b': {'x': 1, 'y': 2}, 'c': [{'x': 1, 'y': 2}, {'x': 3, 'y': 4}]}
    a1 = {'a': [1, 2, 3], 'b': {'x': 1, 'y': 2}, 'c': [{'x': 3, 'y': 4}, {'x': 5, 'y': 6}]}
    a2 = {'a': [1, 2, 3], 'b': {'x': 1, 'y': 2}, 'c': [{'x': 5, 'y': 6}, {'x': 7, 'y': 8}]}