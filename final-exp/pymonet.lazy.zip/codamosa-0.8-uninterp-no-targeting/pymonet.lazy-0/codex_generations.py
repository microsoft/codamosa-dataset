

# Generated at 2022-06-21 19:07:36.513714
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def raise_exception():
        raise Exception('message')

    lazy_with_error = Lazy.of(raise_exception)
    lazy_with_value = Lazy.of(lambda: 5)

    assert Lazy.of(lambda: 'a').to_either() == Right('a')
    assert lazy_with_value.to_either() == Right(5)
    assert lazy_with_error.to_either() == Left(Exception('message'))
    assert lazy_with_error.is_evaluated == True
    assert lazy_with_value.is_evaluated == True



# Generated at 2022-06-21 19:07:41.092917
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn() -> int:
        return 1

    def next_fn(value: int) -> str:
        return str(value)

    lazy = Lazy(fn)
    assert lazy.bind(next_fn).get() == '1'



# Generated at 2022-06-21 19:07:47.989050
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def custom_function():
        return 12

    def error_function():
        raise ValueError

    lazy = Lazy(lambda *args: custom_function())
    from pymonet.monad_try import Try
    assert lazy.to_try() == Try.success(12)

    lazy = Lazy(lambda *args: error_function())
    assert lazy.to_try() == Try.failure(ValueError)



# Generated at 2022-06-21 19:07:50.170198
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.functor import Functor

    assert Lazy.of(1).get() == 1


# Generated at 2022-06-21 19:07:55.460869
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    def test_function():
        return 'Hello World'

    test_lazy = Lazy(test_function)

    result = test_lazy.to_maybe()

    assert isinstance(result, Maybe)
    assert result == Maybe.just('Hello World')



# Generated at 2022-06-21 19:08:04.311433
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def func(*args):
        pass

    lazy = Lazy(func)
    assert str(lazy) == "Lazy[fn=<function test_Lazy___str__.<locals>.func at 0x{}>, value=None, is_evaluated=False]".format(hex(id(func))[2:])

    lazy = Lazy(lambda: True)
    assert str(lazy) == "Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x{}>, value=None, is_evaluated=False]".format(hex(id(lazy.__init__.__locals__['<lambda>']))[2:])



# Generated at 2022-06-21 19:08:14.170792
# Unit test for method __str__ of class Lazy
def test_Lazy___str__(): # type: () -> None
    def fn():
        return 'test'

    assert str(Lazy(fn)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x10b9ea2f0>, value=None, is_evaluated=False]'
    assert str(Lazy(fn).get()) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x10b9ea2f0>, value=\'test\', is_evaluated=True]'



# Generated at 2022-06-21 19:08:17.313503
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_list import List

    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: List.of(x)).get() == List.of(1)



# Generated at 2022-06-21 19:08:22.955252
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # type: () -> None
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert  str(Lazy.of(Box(1)).map(Maybe.just)) == 'Lazy[fn=<built-in function Maybe.just>, value=None, is_evaluated=False]'
    assert  str(Lazy.of(Box(1)).map(Maybe.just).get()) == 'Lazy[fn=<built-in function Maybe.just>, value=Just(1), is_evaluated=True]'

# Generated at 2022-06-21 19:08:25.627023
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(10).to_either() == Right(10)


# Generated at 2022-06-21 19:08:33.656424
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def divide(numerator, denominator):
        return numerator / denominator

    def valid_value(value):
        return Lazy.of(value)

    def invalid_value(value):
        return Lazy.of(value).bind(divide)

    assert Lazy(divide).to_either(1, 2) == invalid_value(1).to_either(2)

# Generated at 2022-06-21 19:08:41.657993
# Unit test for method get of class Lazy
def test_Lazy_get():
    def square(x):
        return x * x

    assert Lazy.of(1).get() == 1
    assert Lazy.of(2).get() == 2
    assert Lazy.of(2).map(square).get() == 4
    assert Lazy.of(5).bind(lambda x: Lazy.of(square(x))).get() == 25
    assert Lazy.of(3).bind(lambda x: Lazy.of(square(x) + 1)).get() == 10
    assert Lazy.of(3).map(square).bind(lambda x: Lazy.of(x + 1)).get() == 10


# Generated at 2022-06-21 19:08:45.058689
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function Lazy.<lambda> at 0x7f79f9b6c158>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:08:55.429065
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def fn(a: int) -> int:
        raise TypeError('Unexpected type')

    assert Lazy(fn).to_try(1) == Try.failure(TypeError('Unexpected type'))
    assert Lazy(fn).to_try(1) != Try.failure(TypeError('Unexpected type 1'))
    assert Lazy(lambda x: x).to_try(1) == Try.success(1)
    assert Lazy(lambda x: x).to_try(1) != Try.success(2)
    assert Lazy(lambda x: x).to_try(1) != Try.failure(TypeError('Unexpected type'))


# Generated at 2022-06-21 19:08:57.689547
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def to_lazy(x):
        return Lazy(lambda: x)

    assert to_lazy(1) != Lazy(lambda: 2)

    lazy1 = Lazy(lambda: 1)
    lazy1._compute_value(1)
    assert to_lazy(1) == lazy1

    lazy2 = Lazy(lambda: 1)
    lazy2._compute_value(2)
    assert to_lazy(1) == lazy2

# Generated at 2022-06-21 19:09:06.104325
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def test_function(*args):
        return "test_function"

    def test_function_with_exc(*args):
        raise Exception('test_function_with_exc')

    lazy1 = Lazy(test_function)
    lazy2 = Lazy(test_function_with_exc)

    assert lazy1.to_either() == lazy1.to_either()
    assert lazy2.to_either() == lazy2.to_either()
    assert lazy1.to_either() == lazy1.to_either(1, 2)
    assert lazy2.to_either() == lazy2.to_either(1, 2)

# Generated at 2022-06-21 19:09:12.461846
# Unit test for method get of class Lazy
def test_Lazy_get():  # type: ignore
    def fn(*args):
        return len(args)

    lazy = Lazy(fn)
    assert lazy.get(1, 2, 3) == 3
    assert lazy.get() == 0

    lazy = Lazy(lambda *args: len(args))
    assert lazy.get(1, 2, 3) == 3
    assert lazy.get() == 0

    lazy = Lazy(lambda x: x)
    assert lazy.get(1, 2, 3) == 1

# Generated at 2022-06-21 19:09:23.900139
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try, Error

    def fn1(*args):
        return 1

    def fn2(*args):
        raise Exception

    def fn3(*args):
        raise Exception
        return 1

    assert Lazy.of(fn1).to_try() == Try.of(fn1)
    assert Lazy.of(fn2).to_try() == Try.of(fn2)
    assert Lazy.of(fn3).to_try() == Try.of(fn3)
    assert Lazy.of(fn1).to_try(2) == Try.of(fn1, 2)
    assert Lazy.of(fn2).to_try(1, 2) == Try.of(fn2, 1, 2)

# Generated at 2022-06-21 19:09:24.946801
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(5).to_box() == Box(5)



# Generated at 2022-06-21 19:09:28.637835
# Unit test for constructor of class Lazy
def test_Lazy():
    value = Lazy.of(5)
    assert value.constructor_fn() == 5
    assert value.is_evaluated == True
    assert value.value == 5

# Generated at 2022-06-21 19:09:35.852895
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    def factory(value):
        return Lazy(lambda: value)

    def test_value(value):
        monad = factory(value)

        assert isinstance(monad.to_validation(), Validation)
        assert monad.to_validation().get_value() == value

# Generated at 2022-06-21 19:09:43.446655
# Unit test for constructor of class Lazy
def test_Lazy(): # pragma: no cover
    from pymonet.validation import Validation
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)
    assert Lazy.of(1).to_validation() == Validation.success(1)

    try:
        Lazy.of(1).get()
    except AttributeError:
        pass
    else:
        assert False



# Generated at 2022-06-21 19:09:48.683026
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    import pymonet.monad_try
    fn = lambda: 10
    lazy = Lazy(fn)
    assert lazy.to_try().get() == 10

    def error_fn():
        raise pymonet.monad_try.MonadTryError("error")

    error_lazy = Lazy(error_fn)
    assert error_lazy.to_try().is_failure()



# Generated at 2022-06-21 19:09:59.376809
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.monad_list import List
    from pymonet.monad_maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.monad_set import Set

    def add_one(num: int) -> int:
        return num + 1

    assert Lazy(add_one).bind(lambda value: Try(value + 10)).get(5) == Try(16)
    assert Lazy(add_one).bind(lambda value: Box(value + 10)).get(5) == Box(16)
    assert Lazy(add_one).bind(lambda value: List([value + 10])).get(5) == List([16])

# Generated at 2022-06-21 19:10:08.333952
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Failure, Try
    from pymonet.validation import Error
    from pymonet.validation import is_error, is_success

    is_success = lambda try_: try_.to_validation().is_success()
    is_error = lambda try_: try_.to_validation().is_error()

    def add(x, y):
        return x + y


    assert is_success(Lazy(add).to_try(1, 1))
    assert is_error(Lazy(add).to_try(1, 'a'))
    assert is_error(Lazy(add).to_try())

    assert is_success(Lazy(lambda: 1).to_try())


# Generated at 2022-06-21 19:10:11.626445
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    assert Lazy.of(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:10:16.978827
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    def mapper(value):
        return Box(value + 1)

    test_func = Lazy.of(1).map(mapper)
    assert test_func.get() == Box(2)
    assert test_func.get() == Box(2)


# Generated at 2022-06-21 19:10:23.482972
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def throws():
        raise ValueError('Ooops!')

    def not_throws():
        return True

    assert Lazy(throws).to_try() == Try.failure(ValueError('Ooops!'))
    assert Lazy(throws).to_try() == Try.failure(ValueError('Ooops!'))
    assert Lazy(not_throws).to_try() == Try.success(True)
    assert Lazy(not_throws).to_try() == Try.success(True)


# Generated at 2022-06-21 19:10:26.347087
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy.of(lambda: 1)) == 'Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x1099e49d8>, value=None, is_evaluated=False]'  # noqa


# Generated at 2022-06-21 19:10:34.270128
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.disjunction import Disjunction
    lazy = Lazy.of(3)
    assert lazy.ap(Lazy.of(lambda x: x + 1)) == 4

    lazy_of_either = Lazy(lambda: Disjunction.left('Error'))
    assert lazy_of_either.ap(Lazy(lambda: Disjunction.right(lambda x: x + 1))) \
           == Disjunction.left('Error')

# Generated at 2022-06-21 19:10:49.799433
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def add(x, y):
        return x + y

    def foo(x):
        return x * 2

    lazy_result = Lazy.of(2)
    assert lazy_result.to_maybe(2) == Maybe.just(2)

    lazy_result = Lazy.of(2)
    assert lazy_result.map(lambda x: x + 1).to_maybe(2) == Maybe.just(3)

    lazy_result = Lazy.of(2)
    assert lazy_result.map(foo).map(lambda x: x + 1).to_maybe(2) == Maybe.just(5)

    lazy_result = Lazy.of(2)

# Generated at 2022-06-21 19:10:57.187385
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x: int) -> 'Lazy[int, int]':
        return Lazy(lambda: x + 1)

    assert Lazy.of(1).bind(fn).get() == Lazy.of(2).get()
    assert Lazy.of(2).bind(fn).get() == Lazy.of(3).get()
    assert Lazy.of(0).bind(fn) != Lazy.of(1).get()
    assert Lazy.of(1).bind(fn) != Lazy.of(2).get()

    def fn2(x: int) -> 'Lazy[int, int]':
        return Lazy(lambda: 2 * x + 3)

    assert Lazy.of(1).bind(fn).bind(fn2).get() == Lazy.of(3).bind(fn2).get

# Generated at 2022-06-21 19:11:01.729436
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return x + 10

    def multiply(x):
        return x * 10

    assert Lazy.of(5).ap(Lazy.of(add)).get() == 15
    assert Lazy.of(5).ap(Lazy.of(multiply)).get() == 50

# Generated at 2022-06-21 19:11:11.572348
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    value = 'Hello'
    assert Lazy.of(value).to_box() == Box(value)
    assert Lazy(lambda: value).to_box() == Box(value)
    assert Lazy(lambda: value).to_box() == Box(value)
    assert Lazy(lambda x: value + x, ' World').to_box(' World') == Box('Hello World')
    assert Lazy(lambda x: value + x, ' World').to_box(' World') == Box('Hello World')
    assert Lazy(lambda x: value + x, ' World').to_box(' World') == Box('Hello World')



# Generated at 2022-06-21 19:11:15.618324
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    f = Lazy.of(lambda x: x + 3)
    assert f.to_box(5) == Box(8), 'test_Lazy_to_box'


# Generated at 2022-06-21 19:11:19.388439
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def constructor_fn(a):
        return a

    assert str(Lazy(constructor_fn)) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(
        constructor_fn, None, False)



# Generated at 2022-06-21 19:11:22.580308
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(200).bind(lambda x: Lazy.of(x / 2 + 100)) == Lazy.of(200)



# Generated at 2022-06-21 19:11:33.026349
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.validation import Validation

    def exception_function():
        raise ValueError()

    def identity_function(arg):
        return arg

    def const(arg):
        return lambda *args: arg

    lazy_ = Lazy(identity_function)

    assert lazy_.to_try(const(5)).get(5) == Box(5).to_try()
    assert lazy_.to_try(exception_function).is_failure()

    assert lazy_.bind(lambda x: Lazy(lambda _: exception_function)).to_try().is_failure()

# Generated at 2022-06-21 19:11:39.573830
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pytest
    from pymonet.maybe import Maybe

    def compute(arg):
        if arg > 0:
            return Maybe.just(arg)
        return Maybe.nothing()

    assert Lazy(lambda: 1).bind(lambda a: Lazy(lambda: a + 1)).get() == 2

    assert Lazy(lambda: 1).bind(lambda a: Lazy(lambda: a + 1)).to_box().get() == 2
    assert Lazy(lambda: 1).bind(lambda a: Lazy(lambda: a + 1)).to_maybe().get() == 2
    assert Lazy(lambda: 1).bind(lambda a: Lazy(lambda: a + 1)).to_either().get() == 2

# Generated at 2022-06-21 19:11:42.779904
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    lazy = Lazy.of(lambda: 1)
    maybe = lazy.to_maybe()
    assert maybe == Maybe(1)



# Generated at 2022-06-21 19:11:53.937648
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    """
    Unit test for method to_maybe of class Lazy
    """
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Lazy(lambda: 'value').to_maybe() == Maybe.just('value')
    assert Lazy(lambda: Box(1)).to_maybe() == Maybe.just(Box(1))
    assert Lazy(lambda: Try.of(lambda: 'value')).to_maybe() == Maybe.just(Try.of(lambda: 'value'))



# Generated at 2022-06-21 19:11:59.951133
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    def add(x: int, y: int) -> int:
        return x + y

    def multiply(x: int, y: int) -> int:
        return x * y

    assert Lazy.of(add).ap(Box(2)).ap(Box(3)) == Box(5)
    assert Lazy.of(add).ap(Lazy.of(2)).ap(Lazy.of(3)) == Lazy.of(5)
    assert Lazy.of(multiply).ap(Try(add, 2, 3)).ap(Try(add, 3, 3)) == Try(add, 5, 6)

# Unit tests for method bind of class Lazy

# Generated at 2022-06-21 19:12:04.456557
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Check if Lazy containing function and Lazy with value return result of function applied with value.
    """
    assert Lazy(lambda b: b + 1).ap(Lazy(lambda _: 2)) == Lazy(lambda _: 3)



# Generated at 2022-06-21 19:12:14.711209
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    import random

    def get_random_int(bound):
        if bound <= 0:
            raise ValueError('bound must be greater than 0')
        return random.randint(0, bound)

    def get_random_int_lazy(bound):
        return Lazy(get_random_int).bind(lambda value: Lazy.of(value))

    random.seed(42)
    lazy = get_random_int_lazy(5)
    result = lazy.to_try()
    assert result == Try.success(lazy.get())

    lazy = get_random_int_lazy(0)
    result = lazy.to_try()
    assert result == Try.failure(ValueError('bound must be greater than 0'))

# Generated at 2022-06-21 19:12:17.753505
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """
    Unit test for method to_either of class Lazy.
    """
    assert Lazy(lambda: 5).to_either() == Lazy(lambda: 5).to_box()



# Generated at 2022-06-21 19:12:24.746181
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def func(arg):
        return 1

    def func_substitute_number(arg):
        return arg + 2

    def func_substitute_string(arg):
        return '2'

    result = Lazy.of(1).bind(func)
    assert result.get() == func(1)

    result = Lazy.of(1).bind(func).bind(func_substitute_number)
    assert result.get() == func_substitute_number(func(1))

    result = Lazy.of(1).bind(func).bind(func_substitute_number).bind(func_substitute_string)
    assert result.get() == func_substitute_string(func_substitute_number(func(1)))


# Generated at 2022-06-21 19:12:31.627393
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left

    assert Lazy.of(1).to_either().equal(Right(1))
    assert Lazy.of(2).to_either(1).equal(Right(2))
    assert Lazy.of(None).to_either().equal(Left(None))
    assert Lazy.of(2).bind(lambda value: Lazy.of(value + 3)).to_either().equal(Right(5))


# Generated at 2022-06-21 19:12:39.539997
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    def div(x, y):
        return x / y

    def part_div(y):
        return div(2, y)

    def double_div(y):
        return div(part_div(y), y)

    def call_with_zero():
        return double_div(0)

    lazy = Lazy(call_with_zero)

    assert lazy.to_maybe() == Maybe.nothing(), 'Should return Nothing'

# Generated at 2022-06-21 19:12:42.669820
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def function_to_call():
        return 'return_value'

    lazy = Lazy(function_to_call)
    assert lazy.to_box().get() == 'return_value'



# Generated at 2022-06-21 19:12:48.367989
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(42).to_validation() == Validation.success(42)
    assert Lazy.of(None).to_validation() == Validation.success(None)
    assert Lazy.of(True).to_validation() == Validation.success(True)


# Generated at 2022-06-21 19:12:52.712621
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(2).get() == 2

# Generated at 2022-06-21 19:12:56.943464
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_fn(value: int) -> Lazy[int, float]:
        return Lazy(lambda *args: float(value))

    assert Lazy(lambda *args: 5).bind(test_fn) == Lazy(lambda *args: 5.0)



# Generated at 2022-06-21 19:13:01.766093
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(1) == Lazy.of(1).map(lambda a: a)
    assert Lazy.of(2) == Lazy.of(2).map(lambda a: a)


# Generated at 2022-06-21 19:13:12.769903
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def double(x):
        return x * 2

    def add_string(x):
        return '{} + {}'.format(x, x)

    lazy_double = Lazy(double)
    lazy_double_add = Lazy(lambda x: x + x)
    lazy_add_string = Lazy(add_string)

    # Test of method of
    assert lazy_double == Lazy.of(4)
    assert Lazy.of('foo') == Lazy.of('foo')

    # Test of method map
    assert lazy_double.map(str) == lazy_double_add.map(str)
    assert lazy_double.map(str) != lazy_add_string.map(str)

# Generated at 2022-06-21 19:13:22.357678
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def func():
        return 1

    lazy = Lazy(func)
    assert lazy.constructor_fn == func
    assert not lazy.is_evaluated
    assert lazy.value is None

    lazy2 = Lazy.of(1)
    assert lazy2.constructor_fn() == 1
    assert not lazy2.is_evaluated
    assert lazy2.value is None

    assert lazy == lazy  # same instance
    assert not (lazy != lazy)  # same instance
    assert lazy2 != lazy  # different instance
    assert not (lazy2 == lazy)  # different instance
    assert lazy2 == lazy2  # same instance
    assert not (lazy2 != lazy2)  # same instance

    lazy3 = lazy.map(lambda x: x * 2)
    assert lazy3.construct

# Generated at 2022-06-21 19:13:24.616715
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x * 3).map(lambda x: x + 42).get(2) == 48



# Generated at 2022-06-21 19:13:33.625957
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    # Given
    def fn1():
        return 1

    def fn2():
        return 1

    lazy1 = Lazy(fn1)
    lazy2 = Lazy(fn1)
    lazy3 = Lazy(fn2)

    # When
    lazy1.get()
    lazy2.get()
    lazy3.get()

    # Then
    assert lazy1 == lazy2
    assert not lazy1 == lazy3

    assert lazy2 == lazy1
    assert not lazy2 == lazy3

    assert lazy3 != lazy1
    assert lazy3 != lazy2



# Generated at 2022-06-21 19:13:38.109775
# Unit test for method get of class Lazy
def test_Lazy_get():
    # given
    class User(object):
        def __init__(self, id):
            self.id = id

    def initializer():
        return User(1)

    lazy = Lazy(initializer)

    # when
    result = lazy.get()

    # then
    assert isinstance(result, User)
    assert result.id == 1



# Generated at 2022-06-21 19:13:43.286292
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def inc(value):
        return value + 1

    assert str(Lazy(inc)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.inc at 0x7f92e010f2f0>, value=None, is_evaluated=False]'
    assert str(Lazy(inc).map(lambda x: x + 1)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x7f92e010f378>, value=None, is_evaluated=False]'
    assert str(Lazy(inc).map(lambda x: x + 1).fold(5)) == '10'



# Generated at 2022-06-21 19:13:54.212286
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover

    expected_lazy = Lazy(lambda: 2)

    class Test:
        def __init__(self, value):
            self.value = value

        def to_lazy(self):
            return Lazy(lambda: self.value)

    assert Lazy.of(2) == expected_lazy
    assert Lazy.of("a") != expected_lazy
    assert Lazy(lambda: "a") != expected_lazy
    assert Lazy(lambda: 2) == expected_lazy
    assert Lazy(lambda: "a") != Lazy(lambda: "a")

    assert expected_lazy == expected_lazy.to_lazy()
    assert Test(2).to_lazy() == expected_lazy.to_lazy()
    assert Test("a").to_lazy()

# Generated at 2022-06-21 19:14:04.429996
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from random import randint

    def random_value_fn(seed: int) -> int:
        return randint(seed, seed * 2)

    my_lazy = Lazy(random_value_fn)
    assert my_lazy == Lazy(random_value_fn)
    assert my_lazy != Lazy(random_value_fn)
    my_lazy.get(1)
    assert my_lazy == Lazy(random_value_fn)
    assert my_lazy != Lazy(random_value_fn)
    my_lazy.get(2)
    assert my_lazy == Lazy(random_value_fn)
    assert my_lazy != Lazy(random_value_fn)



# Generated at 2022-06-21 19:14:06.726490
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.monad_maybe import Just

    result = Lazy.of(1).to_maybe()

    assert isinstance(result, Just)
    assert result.to_list() == [1]



# Generated at 2022-06-21 19:14:09.853086
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    def factorial(n):
        if n < 0:
            raise ValueError('Can\'t compute factorial of negative number')
        if n == 0:
            return 1
        return n * factorial(n - 1)

    lazy = Lazy(lambda: factorial(10))

    assert lazy.to_maybe() == Maybe.just(3628800)



# Generated at 2022-06-21 19:14:18.081767
# Unit test for method map of class Lazy
def test_Lazy_map():
    def f(x):
        return x*3

    def g(x):
        return x+2

    Lazy(f).map(g).get(2) == g(f(2))
    Lazy(f).map(g).get(3) == g(f(3))
    Lazy(f).map(g).map(f).get(2) == f(g(f(2)))
    Lazy(f).map(g).map(f).get(2) == f(g(f(2)))

# Generated at 2022-06-21 19:14:20.116149
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(2).to_box() == Box(2)



# Generated at 2022-06-21 19:14:22.200082
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy(lambda x: x).to_maybe(1) == Maybe.just(1)

# Generated at 2022-06-21 19:14:26.865519
# Unit test for method get of class Lazy
def test_Lazy_get():
    def value_fn(value):
        return value * 2

    lazy_int = Lazy(value_fn).map(lambda x: x.to_float())
    assert lazy_int.get(2) == 4.0
    assert lazy_int.get(2) == 4.0



# Generated at 2022-06-21 19:14:31.417530
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Unit test for method map of class Lazy.
    """
    lazy_A = Lazy(lambda: "test")
    lazy_B = lazy_A.map(lambda x: x + "test")
    assert lazy_B._compute_value() == "testtest"



# Generated at 2022-06-21 19:14:33.884033
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(a, b):
        return a + b

    lazy_1 = Lazy.of(add)

    assert lazy_1.get(2, 3) == 5

# Generated at 2022-06-21 19:14:36.332647
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def f() -> int:
        return 6

    lazy_int = Lazy(f)

    result = lazy_int.to_validation()

    assert Validation.success(6).equals(result)


# Generated at 2022-06-21 19:14:42.669793
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x + 1).map(lambda x: x * 2).get(1) == 4


# Generated at 2022-06-21 19:14:53.043971
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.identity import Identity
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.validation import Validation
    from pymonet.monad import Monad
    from pymonad.either import Left

    def f(x):
        return Lazy(lambda : x + 1)

    def g(x):
        return Lazy(lambda : x + 2)

    assert Lazy(lambda : 2).to_either() == Right(2)

    assert Monad.do(lambda: Lazy(lambda: Identity(1)).bind(f).bind(g).get()) == Identity(4)
    assert Monad.do(lambda: Lazy(lambda: Maybe.just(1)).bind(f).bind(g).get()) == Maybe.just(4)

# Generated at 2022-06-21 19:14:56.699761
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def f(x):
        return x + 1

    def g(x):
        return x

    lazy_1 = Lazy.of(lambda x: x)
    assert Lazy.of(1).ap(lazy_1).get() == 2
    assert Lazy.of(f).ap(Lazy.of(g)).get(2) == 3



# Generated at 2022-06-21 19:15:04.348048
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def _lambda_fn(value): return value ** 2
    def _lambda_fn_with_arg(value, arg): return value ** 2 + arg
    def _lambda_fn_map(value): return _lambda_fn(value) ** 2

    lazy_fn = Lazy.of(_lambda_fn_with_arg)
    lazy_arg = Lazy.of(1)
    lazy_apply = lazy_fn.ap(lazy_arg)

    assert lazy_apply.get() == 2
    assert lazy_apply.get(2) == 6

    lazy_arg = Lazy.of(2)
    lazy_arg2 = Lazy.of(1)
    lazy_apply = lazy_fn.ap(lazy_arg).ap(lazy_arg2)

    assert lazy_apply.get() == 5
    assert lazy_apply

# Generated at 2022-06-21 19:15:15.686014
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.monad_either import Left

    def inc(x):
        return x + 1

    def fn(x):
        return Lazy.of(x)

    assert Lazy.of(0).map(inc).get() == 1
    assert Lazy.of(0).map(inc).to_either().get() == Right(1)
    assert Lazy.of(0).map(inc).to_maybe().get() == Maybe.just(1)
    assert Lazy.of(0).map(inc).to_try().get() == Try.success(1)
    assert Lazy.of(0).map(inc).to_try().get_or_else(0) == 1

# Generated at 2022-06-21 19:15:26.686084
# Unit test for constructor of class Lazy
def test_Lazy():
    import unittest

    class TestLazy(unittest.TestCase):
        def test_of_with(self):
            lazy = Lazy.of("test")
            self.assertEqual(lazy.get(), "test")

        def test_none(self):
            lazy = Lazy(None)
            self.assertEqual(lazy.get(), None)

        def test_mapper(self):
            lazy = Lazy.of("test")
            lazy_mapped = lazy.map(lambda x: x + x)
            self.assertEqual(lazy_mapped.get(), "testtest")

        def test_ap(self):
            lazy = Lazy.of("test")
            lazy_ap = lazy.ap(Lazy.of(lambda x: x + x))

# Generated at 2022-06-21 19:15:34.237626
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.box import Box

    def fn1():
        return 10

    assert Lazy(fn1).to_maybe() == Box(10)

    assert Lazy(lambda: None).to_maybe() == Box(None)

    def fn2(arg):
        return arg

    assert Lazy(fn2).to_maybe(True) == Box(True)

    assert Lazy(fn2).to_maybe(False) == Box(False)

# Generated at 2022-06-21 19:15:36.620071
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 0)



# Generated at 2022-06-21 19:15:40.855292
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test method ap of class Lazy
    """
    from pymonet.maybe import Maybe
    result = Maybe.just(lambda x: x*2)
    lazy = Lazy.of(3).ap(result)
    assert lazy.get() == 6

# Generated at 2022-06-21 19:15:42.665705
# Unit test for method get of class Lazy
def test_Lazy_get():
    x = Lazy.of(2)
    assert x.get() == 2


# Generated at 2022-06-21 19:15:53.488136
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.box import Box

    f = lambda x: x + 5
    x = Lazy(f)
    y = x.map(lambda x: x * 2).map(lambda x: x + 5).to_either()

    assert isinstance(y, Right)
    assert y.value == 20

    assert x.to_maybe().bind(lambda x: Maybe.just(x * 3)).to_either().to_maybe() == Maybe.just(60)

    assert x.map(lambda x: x * 3).to_try().bind(lambda x: Try(x + 5)).to_either().to_try() == Try(30)



# Generated at 2022-06-21 19:15:56.556548
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Lazy.of(1).to_validation()



# Generated at 2022-06-21 19:16:00.244598
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right

    result_value = 'test_value'
    assert Lazy(lambda: result_value).to_either() == Right(result_value)


# Generated at 2022-06-21 19:16:01.353950
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy(lambda x: x).to_box(1).get() == 1



# Generated at 2022-06-21 19:16:12.209902
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert (
        Lazy(lambda: 42)
        .map(lambda x: x + 1)
        .map(lambda x: '%d' % x)
        .bind(lambda x: Lazy(lambda: x + '!'))
        .get()
        == '43!'
    )
    assert (
        Lazy(lambda: 42)
        .map(lambda x: x + 1)
        .map(lambda x: '%d' % x)
        .bind(lambda x: Lazy(lambda: x + '!'))
        .bind(lambda x: Lazy(lambda: x + '!'))
        .get()
        == '43!!'
    )



# Generated at 2022-06-21 19:16:14.996913
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Box(1) == Lazy.of(1).to_box()

    assert Box(1) == Lazy.of(Maybe.just(1)).to_box().get()


# Generated at 2022-06-21 19:16:16.489464
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x + 1) == Lazy(lambda: 1 + 1)



# Generated at 2022-06-21 19:16:20.278416
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def add_two(a):
        return a + 2

    assert Lazy.of(2).map(add_two) == Lazy(lambda: add_two(2))



# Generated at 2022-06-21 19:16:25.723547
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return x + 1

    def incr(x):
        return x * 2

    x = Lazy(lambda: add(1)).map(incr).fold()
    y = Lazy(lambda: add(1)).ap(Lazy(lambda: incr)).fold()
    assert x == y


# Generated at 2022-06-21 19:16:31.661974
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Check Lazy.get with some test data.
    """
    def add_one(value: int) -> int:
        return value + 1

    def multiply_by_two(value: int) -> int:
        return value * 2

    lazy_value = Lazy(add_one)
    assert lazy_value.get(2) == 3

    lazy_value = Lazy(add_one)
    assert lazy_value.map(multiply_by_two).get(1) == 4



# Generated at 2022-06-21 19:16:41.829158
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda x: x+x).get(1) == 2
    assert Lazy(lambda x: x+x).get(1) == 2
    assert Lazy(lambda x: x+x).is_evaluated
    assert Lazy(lambda x: x+x).get(1) == 2
    assert Lazy(lambda x: x+x).is_evaluated
    assert Lazy(lambda x: x+x).get(1) == 2

test_Lazy()

# Generated at 2022-06-21 19:16:46.650342
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right

    # GIVEN
    def func_returning_10():
        return 10

    lazy_instance = Lazy(func_returning_10)

    # WHEN
    either_instance = lazy_instance.to_either()

    # THEN
    assert either_instance == Right(10)



# Generated at 2022-06-21 19:16:50.570921
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right

    assert Lazy.of(5).ap(Box(lambda x: x + 2)).get() == 7
    assert Lazy.of(5).ap(Right(lambda x: x + 2)).get() == 7

# Generated at 2022-06-21 19:16:53.609290
# Unit test for method map of class Lazy
def test_Lazy_map():
    def f1():
        return 5

    def f2(x):
        return x + 10

    assert Lazy(f1).map(f2) == Lazy(lambda: f2(f1()))



# Generated at 2022-06-21 19:16:59.403213
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def mapper_fn(x):
        return x + 1

    def multiplier_fn(a, b):
        return a * b

    def func_mapper_fn(mapper, a):
        return multiplier_fn(mapper(a), 2)

    assert Lazy(lambda: 2).bind(
        lambda x: Lazy(lambda: func_mapper_fn(mapper_fn, x))
    ).get() == 6


# Generated at 2022-06-21 19:17:08.685195
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    test ap method of class Lazy.
    """
    from datetime import datetime
    from pymonet.functor import Functor
    from pymonet.higher_order_functions import pipe

    def add(value):
        def internal_add(x):
            return value + x

        return Functor(internal_add)

    def map_times_two(value):
        return value * 2

    def now():
        return datetime.now()

    lazy_two = Lazy.of(2)

    assert Functor(map_times_two).ap(lazy_two.to_box()).get() == 4
    assert Functor(map_times_two).ap(
        lazy_two.to_either()
    ).get_or_else(0) == 4

# Generated at 2022-06-21 19:17:10.029744
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_two(num):
        return num + 2

    assert Lazy(add_two).map(add_two).get(4) == 8

# Generated at 2022-06-21 19:17:12.383098
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def id_lazy(x: int) -> 'Lazy[U, U]':
        return Lazy(lambda: x)

    assert id_lazy(5).bind(id_lazy) == Lazy(lambda: 5)



# Generated at 2022-06-21 19:17:20.171096
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy = Lazy.of(4).map(lambda x: x + 4).map(lambda x: x / 4)
    assert lazy.get() == 2
    assert lazy.to_box().is_instance_of(Box)
    assert lazy.to_maybe().is_instance_of(Maybe)
    assert lazy.to_either().is_instance_of(Either)
    assert lazy.to_try().is_instance_of(Try)
    assert lazy.to_validation().is_instance_of(Validation)


# Generated at 2022-06-21 19:17:22.514575
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    assert Lazy.of(42).to_try() == Lazy.of(42).to_try(1, 2, 3)
    assert Lazy.of(lambda: 1 / 0).to_try() == Lazy.of(lambda: 1 / 0).to_try(1, 2, 3)
