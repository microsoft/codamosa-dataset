

# Generated at 2022-06-21 19:07:33.629059
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_fn(a):
        return Lazy.of(a + 1)

    f = Lazy.of(1)
    assert f.bind(test_fn).get() == 2


# Generated at 2022-06-21 19:07:35.504829
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    pass  # pragma: no cover



# Generated at 2022-06-21 19:07:41.241189
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy(lambda a: a + 1).to_box(20) == Box(21)
    lazy: Lazy[int, int] = Lazy(lambda a: a + 1)
    assert lazy.get(20) == 21
    assert lazy.to_box(20) == Box(21)



# Generated at 2022-06-21 19:07:43.443903
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    lazy = Lazy(lambda x: x + 1)
    assert isinstance(str(lazy), str)



# Generated at 2022-06-21 19:07:47.896421
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    def fn_to_test() -> int:
        return 1

    assert Lazy.of(fn_to_test()).to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:07:50.401948
# Unit test for method map of class Lazy
def test_Lazy_map():
    value = Lazy(lambda: 1)
    transformed_value = value.map(lambda x: x + 1)
    assert transformed_value.get() == 2


# Generated at 2022-06-21 19:08:01.224902
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.monad import Monad
    from pymonet.monad_try import Try

    def divide(dividend, divisor):
        if divisor == 0:
            raise Exception('Invalid argument')
        return dividend / divisor

    try_1_divide_2_lazy = Lazy(lambda: divide(1, 2))
    assert Monad.is_instance(try_1_divide_2_lazy)

    assert try_1_divide_2_lazy.to_try() == Try.success(0.5)

    try_1_divide_0_lazy = Lazy(lambda: divide(1, 0))

# Generated at 2022-06-21 19:08:08.613785
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    import pymonet.maybe as maybe
    from pymonet.maybe import Maybe

    lazy_just = Lazy.of('foo')
    assert str(lazy_just) == 'Lazy[fn=<function of.<locals>.<lambda> at 0x1070f67b8>, value=None, is_evaluated=False]'

    mapper = lambda arg: arg + 'bar'
    lazy_map = lazy_just.map(mapper)
    assert str(lazy_map) == 'Lazy[fn=<function <lambda> at 0x1070f68c8>, value=None, is_evaluated=False]'

    transformed_lazy = lazy_map.map(lambda arg: arg[0])

# Generated at 2022-06-21 19:08:13.628403
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.instances.function import curry

    assert curry(lambda x: Lazy(lambda: x).to_either(1))(
        Right.of(1)
    ) == curry(lambda x: Right.of(x))(
        1
    )



# Generated at 2022-06-21 19:08:18.832763
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(2).ap(Lazy.of(lambda x: x+1)) == Lazy.of(3)

    assert Lazy.of(3).ap(Lazy.of(lambda x: x+3)) == Lazy.of(6)

    assert Lazy(lambda x: 2).ap(Lazy(lambda x: x+1)) == Lazy(lambda x: 3)

    assert Lazy(lambda x: 2).ap(Lazy(lambda x: x+2)) == Lazy(lambda x: 4)

# Generated at 2022-06-21 19:08:25.790993
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    add_one = Lazy(lambda x: x + 1)
    assert add_one.to_either(1) == Right(2)
    assert add_one.to_either(Left(1)) == Left(1)
    assert Lazy(lambda x: (lambda y: x + y)).ap(add_one).to_either(Left(1)) == Left(1)
    assert Lazy(lambda x: (lambda y: x + y)).ap(add_one).to_either(1) == Right(3)



# Generated at 2022-06-21 19:08:28.607784
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    lazy = Lazy(lambda: 1)
    assert lazy.to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:08:39.533574
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.monoid import Monoid

    def assert_box_is_equal(actual_box, expected_box):
        assert actual_box.to_maybe() == expected_box.to_maybe()
        assert actual_box.to_either() == expected_box.to_either()

    assert_box_is_equal(Lazy.of('x').to_box(), Monoid.of('x'))

    def constructor_fn(x):
        return x

    assert_box_is_equal(Lazy(constructor_fn).to_box('x'), Monoid.of('x'))

    def constructor_fn_map(x):
        return x.upper()


# Generated at 2022-06-21 19:08:41.907490
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    fn = lambda x: x
    m = Lazy(fn)
    assert m.to_validation() == Validation.success(m)



# Generated at 2022-06-21 19:08:46.647916
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.functors.box import Box
    from pymonet.functors.maybe import Maybe

    double = lambda x: x + x
    double_lazy = Lazy(double)
    assert double_lazy.constructor_fn == double
    assert double_lazy.is_evaluated == False
    assert double_lazy.value == None



# Generated at 2022-06-21 19:08:51.804684
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    lazy = Lazy.of(1)

    assert str(lazy) == 'Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x10e8a3d08>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:08:59.652216
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def identity(x: int) -> int:
        return x

    lazy_exception = Lazy(lambda: 1 / 0)
    lazy_identity = Lazy(identity)

    assert(lazy_exception.to_try() == Try.failure(ZeroDivisionError))
    assert(lazy_identity.to_try(3) == Try.of(identity, 3))


# Generated at 2022-06-21 19:09:05.634080
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test method map of class Lazy
    """
    from pymonet.maybe import Maybe

    def add1(x):
        return x + 1

    assert Lazy.of(0).map(add1).get() == 1

    assert Lazy.of(Maybe.just(0)).map(add1).get() == 1

    assert Lazy.of(Maybe.nothing()).map(add1).get() == Maybe.nothing()


# Generated at 2022-06-21 19:09:14.543762
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.applicative import Applicative

    #  apply function from list, not really Lazy
    lazy_list = Lazy(lambda *args: [lambda x: x + 2, lambda x: x + 3])  # type: Applicative[List[int]]
    assert lazy_list.ap(Lazy(lambda *args: 2)) == Lazy([4, 5])

    lazy_list = Lazy(lambda *args: [lambda x: x + 2, lambda x: x + 3, lambda x: x + 4])  # type: Applicative[List[int]]
    lazy_list2 = Lazy(lambda *args: [2, 3])
    assert lazy_list.ap(lazy_list2) == Lazy([4, 5, 6, 5, 6, 7])

# Generated at 2022-06-21 19:09:21.385540
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.monad_try import Try

    def div(*args):
        return Try.of(args[0] / args[1])

    return Lazy(div).__str__() == "Lazy[fn=<function test_Lazy___str__.<locals>.div at 0x7f33f2c2ebf8>, value=None, is_evaluated=False]"



# Generated at 2022-06-21 19:09:29.985859
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # arrange
    lazy_constructor = Lazy(lambda x: x + 1)
    add_one = lambda x: x + 1
    add_two = lambda x: x + 2
    add_three = lambda x: x + 3

    # act
    value = lazy_constructor.map(add_one).ap(lazy_constructor.map(add_two)).ap(lazy_constructor.map(add_three)).get(0)

    # assert
    assert value == 5

# Generated at 2022-06-21 19:09:38.855556
# Unit test for method map of class Lazy
def test_Lazy_map():
    def _map(mapper):
        return Lazy(_map).map(mapper)

    assert Lazy.of(2).map(lambda x: x + 2) == Lazy.of(4)
    assert _map(lambda x: x).constructor_fn(None) == _map
    assert Lazy.of(5).map(lambda x: x + 2).map(lambda x: x - 2) == Lazy.of(5)
    assert Lazy.of(5).map(_map).map(lambda x: x).get(lambda x: x * 2) == (lambda x: x * 2)
    assert _map(lambda x: x).map(_map).get(lambda x: x * 2) == (lambda x: x * 2)


# Generated at 2022-06-21 19:09:44.705522
# Unit test for method get of class Lazy
def test_Lazy_get():
    import pytest

    # GIVEN
    def inc(x):
        return x + 1

    def transform(x):
        return str(x + 1)

    lazy = Lazy(inc).map(transform)

    # WHEN
    result = lazy.get(1)

    # THEN
    assert result == '3'



# Generated at 2022-06-21 19:09:52.412386
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: None)) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: 5)) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: 5).get()) == 'Lazy[fn=<lambda>, value=5, is_evaluated=True]'



# Generated at 2022-06-21 19:09:57.984766
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left

    def fn():
        return 1

    def raise_error():
        raise ValueError('Error')

    assert Lazy(fn).to_either() == Right(1)
    assert Lazy(fn).to_either() == Right(1)
    assert Lazy(raise_error).to_either() == Left('Error')


# Generated at 2022-06-21 19:10:03.485558
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import test_functor
    from pymonet.monad import test_monad
    from pymonet.applicative import test_applicative
    from pymonet.monad_laws import test_monad_law

    test_functor(Lazy, Lazy, Lazy)
    test_applicative(Lazy)
    test_monad(Lazy)
    test_monad_law(Lazy)

# Generated at 2022-06-21 19:10:07.480444
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import (
        Just,
        Nothing
    )

    assert Just(2) == Lazy(lambda: 2).to_maybe()
    assert Nothing() == Lazy(lambda: Box.none()).to_maybe()
    assert Just(2) == Lazy(lambda: Box.of(2)).to_maybe()

# Generated at 2022-06-21 19:10:19.652061
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.functional import compose

    def double(number):
        return number * 2

    def square(number):
        return number * number

    assert Lazy.of(1).map(double).ap(Box(square)) == Box(2)
    assert Lazy.of(1).map(double).ap(Box(square)).unbox() == 2
    assert tuple(Lazy.of(1).map(double).ap(Box(square)).map(square).map(double).to_tuple()) == (8,)
    assert tuple(Lazy.of(1).map(double).ap(Box(square)).map(square).map(double).to_tuple()) == (8,)

# Generated at 2022-06-21 19:10:22.691390
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(1).ap(Lazy.of(lambda x: x + 1)).get() == 2

    assert Lazy.of(1).ap(Lazy.of(None)).get() == 1



# Generated at 2022-06-21 19:10:29.363765
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_fn = lambda x: x * 10
    lazy_fn2 = lambda x: x + 1

    lazy = Lazy.of(10).map(lazy_fn)
    assert lazy.constructor_fn == lazy_fn

    lazy2 = Lazy.of(lazy_fn2)
    assert lazy2.constructor_fn == lazy_fn2

    lazy3 = Lazy.of(lazy_fn2).ap(lazy)
    assert lazy3.constructor_fn(100) == 101 * 10

    lazy4 = Lazy.of(lazy_fn2).ap(lazy)
    assert lazy4.constructor_fn(100) == 101 * 10

    lazy_fn3 = lambda x, y: x * y

# Generated at 2022-06-21 19:10:38.409230
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(None).to_either() == Right(None)
    assert Lazy.of([]).to_either() == Right([])
    assert Lazy.of('').to_either() == Right('')



# Generated at 2022-06-21 19:10:41.662392
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Validation.success('A') == Lazy.of('A').to_validation()


# Generated at 2022-06-21 19:10:47.015179
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try, Success
    from pymonet.either import Left, Right

    assert Lazy(lambda: 1).to_try() == Try.success(1)
    assert Lazy(lambda: 0 / 0).to_try() == Try.failure(ZeroDivisionError('division by zero'))



# Generated at 2022-06-21 19:10:48.495000
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of('test').get() == 'test'


# Generated at 2022-06-21 19:10:56.337575
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    check that Lazy.ap method aplly function inside Lazy to result of other Lazy constructor function.
    """
    from pymonet.functor import Functor
    from pymonet.monad_try import Try

    assert Functor.equals(
        Lazy.of(1).ap(Lazy.of(lambda x: x + 1)),
        Lazy.of(2)
    )

    assert Functor.equals(
        Lazy.of(1)
            .ap(Lazy.of(0))
            .ap(Lazy.of(lambda x, y: x + y)),
        Lazy.of(1)
    )


# Generated at 2022-06-21 19:11:05.952692
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.monad_test import should_have_method
    from pymonet.maybe import Maybe

    def test_method(value):
        lazy = Lazy(lambda: value)
        try:
            value = lazy.get()
            if value is None:
                maybe = lazy.to_maybe()
                assert maybe != Maybe.nothing()
            else:
                maybe = lazy.to_maybe()
                assert maybe == Maybe.just(value)
        except Exception:
            maybe = lazy.to_maybe()
            assert maybe == Maybe.nothing()

    should_have_method(Lazy(lambda: None), test_method)


# Generated at 2022-06-21 19:11:10.908023
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    def fn_for_lazy(x):
        return x

    assert Lazy.of(None).to_maybe(None) == Maybe.nothing()
    assert Lazy.of(10).to_maybe(None) == Maybe.just(10)



# Generated at 2022-06-21 19:11:14.201880
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of(1).to_maybe().is_just() == True
    assert Lazy.of(None).to_maybe().is_nothing() == True

# Generated at 2022-06-21 19:11:15.973959
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of("test").to_either() == Right("test")

# Generated at 2022-06-21 19:11:19.344705
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    result = Lazy(lambda: 42).to_box()

    assert isinstance(result, Box)
    assert result == Box(42)



# Generated at 2022-06-21 19:11:30.549052
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x: x + 1).ap(Lazy.of(3)) == Lazy.of(4)

# Generated at 2022-06-21 19:11:33.341324
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def mapper(x):
        return Lazy(lambda: x*2)

    assert Lazy(lambda: 10).ap(mapper(Lazy(lambda: 10))) == Lazy(lambda: 20)



# Generated at 2022-06-21 19:11:37.001418
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    # given
    lazy_value = Lazy.of(1)

    #when
    box_value = lazy_value.to_box()

    # then
    assert box_value == Box(1)



# Generated at 2022-06-21 19:11:46.724363
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from random import randint

    assert Lazy.of(Box(1)).to_box() == Box(1)
    assert Lazy.of(Box('abc')).to_box() == Box('abc')
    assert Lazy.of(Box([])).to_box() == Box([])
    assert Lazy.of(Box({})).to_box() == Box({})
    assert Lazy.of(Box(None)).to_box() == Box(None)
    assert Lazy.of(Box(randint(1, 100))).to_box() == Lazy.of(Box(randint(1, 100))).to_box()



# Generated at 2022-06-21 19:11:57.229306
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Lazy#ap test.
    """
    a = Lazy.of(1)
    b = Lazy.of(3)
    c = Lazy.of(lambda x, y: x + y)

    assert a.ap(c).get() == c.get(1)
    assert b.ap(c).get() == c.get(3)

    assert a.ap(c).map(lambda x: x * 3).get() == c.get(1) * 3
    assert b.ap(c).map(lambda x: x * 3).get() == c.get(3) * 3

    assert a.ap(b.ap(c.map(lambda z: lambda x, y: z(x, y)))).get() == c.get(1, 3)



# Generated at 2022-06-21 19:12:02.471210
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def f(arg):
        return arg

    assert str(Lazy(f)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.f at 0x7fc9c7b9dd08>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:12:12.500813
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    It's unit test for method map of class Lazy
    """
    import pytest

    list1 = [1, 2, 3, 4, 5]  # type: List[int]

    # Test 1: Lazy of with function multiply on 2
    lazy = Lazy.of(lambda x: x * 2)  # type: Lazy[int, int]

    # Test 2: map function as lambda
    lazy = lazy.map(lambda x: x + 1)
    assert lazy.get(1) == 3

    # Test 3: map function as nested function
    lazy = lazy.map(lambda x: lambda y: x + y)(2)
    assert lazy.get(1) == 5

    # Test 4: map function as lambda but with list argument
    lazy = lazy.map(lambda x: x + list1[1])


# Generated at 2022-06-21 19:12:17.840818
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def raise_exception():
        raise Exception('')

    assert Try.of(lambda: 10) == Lazy(lambda: 10).to_try()
    assert Try.of(raise_exception) == Lazy(raise_exception).to_try()

# Generated at 2022-06-21 19:12:20.378583
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy.
    """
    lazy = Lazy(lambda x: x * 2)
    new_lazy = lazy.bind(lambda x: Lazy(lambda: x + 1))

    assert new_lazy == Lazy(lambda: 3)


# Generated at 2022-06-21 19:12:23.901496
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: 2 * x).ap(Lazy.of(3)) == Lazy.of(6)

# Generated at 2022-06-21 19:12:55.537014
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    >>> test_Lazy_bind()
    True
    """

    def factorial(n):
        if n == 0:
            return 1
        return n * factorial(n - 1)

    def square(n):
        return n ** 2

    def fmap(f, data):
        return data.bind(lambda x: Lazy.of(f(x)))

    assert str(fmap(square, Lazy.of(3))) == 'Lazy[fn=<function <lambda> at 0x000001E0AEDD0510>, value=None, is_evaluated=False]'
    assert fmap(square, Lazy.of(3)).get() == 9
    assert fmap(factorial, Lazy.of(5)).get() == 120

# Generated at 2022-06-21 19:13:05.388740
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def add_one(x):
        return x + 1

    def mult_two(x):
        return x * 2

    def to_str(x):
        return str(x)

    add_one_lazy = Lazy(add_one)
    mult_two_lazy = Lazy(mult_two)
    to_str_lazy = Lazy(to_str)

    assert add_one_lazy.map(add_one) == Lazy(add_one).map(add_one)
    assert add_one_lazy.map(lambda x: x + 1) == Lazy(add_one).map(lambda x: x + 1)


# Generated at 2022-06-21 19:13:13.124139
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    test_value = 'foo'
    assertion_value = test_value * 2
    lazy = Lazy.of(test_value)

    result = lazy.to_validation()
    assert isinstance(result, Validation)
    assert result.is_success()
    assert result.get() == test_value

    result = lazy.map(lambda value: value * 2).to_validation()
    assert isinstance(result, Validation)
    assert result.is_success()
    assert result.get() == assertion_value


# Generated at 2022-06-21 19:13:16.149450
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda x: x)) == "Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f4169c410d0>, value=None, is_evaluated=False]"


# Generated at 2022-06-21 19:13:21.713085
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1, \
        'Should return 1'
    assert Lazy.of(1).map(lambda x: x + 2).get() == 3, \
        'Should return 3'
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 2)).get() == 3, \
        'Should return 3'



# Generated at 2022-06-21 19:13:25.104373
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    def add_two(value):
        return value + 2

    assert Lazy(add_two).to_box(3) == Box(5)


# Generated at 2022-06-21 19:13:31.501867
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.monad_functor import Functor


    def return_three(*args):
        return 3


    assert Functor.of(return_three).lmap(Lazy.of(2)).to_validation(None) == Validation.success(3)


# Generated at 2022-06-21 19:13:40.328558
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    x = Lazy(lambda *args: args)
    one, two, three = 1, '2', 3
    assert x.bind(lambda *args: x.to_box(*args)).get(one, two, three) == Box((one, two, three))
    assert x.bind(lambda *args: x.to_either(*args)).get(one, two, three) == Right((one, two, three))
    assert x.bind(lambda *args: x.to_maybe(*args)).get(one, two, three) == Maybe.just((one, two, three))

# Generated at 2022-06-21 19:13:47.480688
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():

    def throwing_fn(*args):
        raise Exception("raise exception")

    lazy = Lazy(throwing_fn)
    assert lazy.to_try("test").is_success() is False
    assert lazy.to_try("test").is_error() is True
    assert lazy.to_try("test").get_error().value == "raise exception"
    assert lazy.to_try("test").get_error().type == Exception
    assert lazy.to_try("test").get_error().traceback



# Generated at 2022-06-21 19:13:56.678315
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def get_value() -> str:
        return 'value'
    value_as_try = Lazy(get_value).to_try()
    assert Try.success('value') == value_as_try

    def raise_value() -> str:
        raise ValueError('error')
    value_as_try = Lazy(raise_value).to_try()
    assert isinstance(value_as_try, Try)
    assert isinstance(value_as_try.value, ValueError)


# Generated at 2022-06-21 19:14:50.570449
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monoid import Sum

    assert Lazy(lambda *args: Sum(1)).map(lambda x: x.value * 2).get() == Sum(2)
    assert Lazy(lambda *args: Sum(1)).map(lambda x: x.value * 2).get(1, 2) == Sum(2)
    assert Lazy(lambda *args: Sum(1)).map(lambda x: x.value * 2)(1, 2) == Sum(2)
    assert Lazy(lambda x: Sum(x)).map(lambda x: x.value * 2)(1) == Sum(2)
    assert Lazy(lambda x: Sum(x)).map(lambda x: x.value * 2, 1) == Sum(2)


# Generated at 2022-06-21 19:14:54.377052
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def function():
        print('Call function')

    lazy = Lazy(function)

    assert repr(lazy) == 'Lazy[fn=<function test_Lazy___str__.<locals>.function at 0x7f4d4ecb6ae8>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:14:57.681446
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def function():
        return True

    lazy = Lazy.of(function)
    assert lazy.to_validation() == Validation.success(True)

    def function():
        raise AttributeError

    lazy = Lazy.of(function)
    assert lazy.to_validation() == Validation.success(True)

# Generated at 2022-06-21 19:14:59.173591
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(lambda x: x).__eq__(Lazy.of(lambda x: x)) is False

# Generated at 2022-06-21 19:15:01.895391
# Unit test for method map of class Lazy
def test_Lazy_map():
    def construct_fn(x):
        return x + 1

    def mapper_fn(x):
        return x * 2

    assert Lazy(construct_fn).map(mapper_fn).get(2) == 6


# ---------------------------------------------------------------------------

# Generated at 2022-06-21 19:15:05.159294
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def not_called_function(argument):
        raise AssertionError('Function should not be called')

    lazy = Lazy(not_called_function)
    assert lazy.to_either() == Right(None)



# Generated at 2022-06-21 19:15:07.123420
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2


# Generated at 2022-06-21 19:15:15.037960
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    @Lazy
    def fn(a):
        return a ** 2

    @Lazy
    def double(a):
        return a * 2

    @Lazy
    def double_square(a):
        return a ** 2

    def equals(actual, expected):
        assert actual == expected

    equals(Lazy.of(2).ap(fn), Lazy.of(4))
    equals(Lazy.of(2).ap(double), Lazy.of(4))
    equals(double.ap(fn), double_square)



# Generated at 2022-06-21 19:15:18.953413
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    value = 1
    lazy = Lazy.of(value)
    box = lazy.to_box()
    assert box == Box(value)



# Generated at 2022-06-21 19:15:21.149545
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    lazy = Lazy(lambda: 2)
    assert lazy.to_box() == Box(2)


# Generated at 2022-06-21 19:16:10.209514
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    assert Lazy.of(5).to_box() == Box(5)
    assert Lazy.of('a').to_box() == Box('a')
    assert Lazy.of(True).to_box() == Box(True)
    assert Lazy.of(None).to_box() == Box(None)


# Generated at 2022-06-21 19:16:13.510610
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    value = 'TEST'
    validation = Lazy.of(value).to_validation()

    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.value == value


# Generated at 2022-06-21 19:16:18.777839
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def f(x):
        return x + 1

    def g(x):
        return x * 3

    assert Lazy.of(f).ap(Lazy.of(1)).get() == f(1)
    assert Lazy.of(f).ap(Lazy.of(2)).get() == f(2)
    assert Lazy.of(g).ap(Lazy.of(f)).ap(Lazy.of(3)).get() == g(f(3))



# Generated at 2022-06-21 19:16:29.611938
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def const_fn(*args):
        return args

    def throw_fn():
        raise TypeError

    def throw_fn_not_parsed(*args):
        raise TypeError

    from pymonet.monad_try import Try

    assert Lazy(const_fn).to_try() == Try.of(const_fn)
    assert Lazy(const_fn).to_try(1, 2, 3) == Try.of(const_fn, 1, 2, 3)
    assert Lazy(throw_fn).to_try() == Try.of(throw_fn)

    try:
        assert Lazy(throw_fn_not_parsed).to_try(1, 2, 3)
        assert False, 'Shouldn\'t be here'
    except TypeError:
        pass


# Generated at 2022-06-21 19:16:35.250298
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    assert Lazy.of(lambda x: x + 1).map(lambda x: x(10)) == Lazy.of(11)
    l = Lazy.of(lambda x: x + 10)
    l = l.map(lambda x: x(10)).map(lambda x: x + 10)
    assert l == Lazy.of(20)
    l = l.map(lambda x: x + 10).map(lambda x: x + 10)
    assert l == Lazy.of(30)


# Generated at 2022-06-21 19:16:46.594020
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return lambda y: x + y

    def mult(x):
        return lambda y: x * y

    def apply_binary_operation(binary_operation, x):
        return lambda y: binary_operation(x, y)

    assert Lazy(lambda x: apply_binary_operation(add, x)).ap(Lazy(lambda x: apply_binary_operation(mult, x))).get(1, 2) == 3
    assert Lazy(lambda x: apply_binary_operation(mult, x)).ap(Lazy(lambda x: apply_binary_operation(add, x))).get(1, 2) == 5

    assert Lazy(lambda x: apply_binary_operation(mult, x)).ap(Lazy(lambda x: apply_binary_operation(add, x))).to_validation().get_or_

# Generated at 2022-06-21 19:16:53.051193
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Right(10).to_lazy().to_either() == Right(10)
    assert Right(10).to_lazy().map(lambda x: x + 10).to_either() == Right(20)
    assert Right(10).to_lazy().map(lambda x: x + 10).map(lambda x: x ** 2).to_either() == Right(400)
    assert Lazy.of(10).to_either() == Right(10)


# Generated at 2022-06-21 19:16:59.801253
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(0) != Lazy.of(1)
    assert Lazy.of("a") != Lazy.of("b")

    assert Lazy(lambda x: x) == Lazy(lambda x: x)
    assert Lazy(lambda x: x) != Lazy(lambda x, y: x + y)
    assert Lazy(lambda *args: args) != Lazy(lambda *args: reversed(args))



# Generated at 2022-06-21 19:17:01.247796
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy(lambda a: 5).to_maybe() == Maybe.just(5)



# Generated at 2022-06-21 19:17:10.400295
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation
    def add_one(i):
        return i + 1

    lazy_100 = Lazy.of(100)
    assert isinstance(lazy_100.to_validation(), Validation)
    assert lazy_100.to_validation().is_success()
    assert lazy_100.to_validation().get_or_else(lambda: 0) == 100

    lazy_add_one = lazy_100.map(add_one)

    assert lazy_add_one.to_validation().is_success()
    assert lazy_add_one.to_validation().get_or_else(lambda: 0) == 101

    assert lazy_add_one.to_validation().map(add_one).is_success()
    assert lazy_add_one