

# Generated at 2022-06-21 19:07:30.718831
# Unit test for method get of class Lazy
def test_Lazy_get():
    value = 'lazy_value'

    assert Lazy.of(value).get() == value



# Generated at 2022-06-21 19:07:33.532129
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Lazy(lambda x: x).to_maybe(3) == Maybe.just(3)

# Generated at 2022-06-21 19:07:40.156353
# Unit test for method get of class Lazy
def test_Lazy_get():

    def t_fn(*args):
        return args

    def t_mapper(*args):
        return args

    assert Lazy(t_fn).get(1, 2, 3) == (1, 2, 3)
    assert Lazy(t_fn).bind(t_mapper).get(1, 2, 3) == (1, 2, 3)



# Generated at 2022-06-21 19:07:51.369228
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try, Error

    assert Lazy.of(2).to_try() == Try.of(lambda: 2)
    assert Lazy.of(2).to_try(1) == Try.of(lambda x: 2, 1)
    assert Lazy.of(error).to_try(2) == Try.of(error, 2)
    assert Lazy.of(error).to_try(1, 2) == Try.of(error, 1, 2)
    assert Lazy.of(error).to_try(1, 2, 3) == Try.of(error, 1, 2, 3)
    assert Lazy.of(error).to_try(1, 2, 3, 4) == Try.of(error, 1, 2, 3, 4)

# Generated at 2022-06-21 19:07:53.420909
# Unit test for constructor of class Lazy
def test_Lazy():
    assert_that(Lazy.of('test').constructor_fn, equal_to(lambda *args: 'test'))



# Generated at 2022-06-21 19:07:56.992456
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def test_function():
        return 1 / 0

    value_try = Lazy(test_function).to_try()
    assert type(value_try) is Try
    assert not value_try.is_success
    assert value_try.is_failure

# Generated at 2022-06-21 19:08:00.327365
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    assert Lazy.of(4).to_maybe() == Lazy.of(4).map(Maybe.just).get()

# Generated at 2022-06-21 19:08:03.013530
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(lambda: 1).to_either() == Right(1)


# Generated at 2022-06-21 19:08:13.169038
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    # Given
    from pymonet.either import Right, Left

    fn = lambda: 1
    lazy_with_right = Lazy(fn).to_either()
    lazy_with_left = Lazy(fn).ap(Left(2)).to_either()

    # Then
    assert lazy_with_right == lazy_with_left, 'to_either should return Right for Lazy with Right and for both with Left'



# Generated at 2022-06-21 19:08:16.832366
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Lazy(lambda: 'monet').to_box() == Box.of('monet')


# Generated at 2022-06-21 19:08:29.682349
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add2(x: int) -> int:
        return x + 2

    validation = Lazy.of(1).to_validation().ap(Lazy.of(add2))
    assert validation == Validation.success(3)

    try_with_add2 = Try.of(add2, 1)
    validation = Lazy.of(1).to_validation().ap(try_with_add2)
    assert validation == Validation.success(3)

    lazy_with_add2 = Lazy.of(add2)
    validation = Lazy.of(1).to_validation().ap(lazy_with_add2)
    assert validation == Validation.success(3)

# Generated at 2022-06-21 19:08:33.569259
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def lrandom():
        from random import random
        return Lazy(lambda: random())

    assert(lrandom().to_validation() == Validation.success(lrandom().get()))


# Generated at 2022-06-21 19:08:43.807530
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation
    from pymonet.validation import Success
    from pymonet.validation import Failure

    def even(number: int) -> 'Lazy[int, bool]':
        def even_fn(number):
            assert isinstance(number, int)
            return number % 2 == 0

        return Lazy(even_fn)

    assert Validation.success(1).to_lazy().map(even).to_validation(1) == Validation.success(False)
    assert Validation.success(2).to_lazy().map(even).to_validation(2) == Validation.success(True)


# Generated at 2022-06-21 19:08:46.434873
# Unit test for method get of class Lazy
def test_Lazy_get():
    # arrange
    def test_function(value):
        return value

    argument = 5
    # act
    result = Lazy(test_function).get(argument)
    # assert
    assert result == argument


# Generated at 2022-06-21 19:08:50.610077
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 'test').to_maybe() == Maybe.just('test')
    assert Lazy(lambda: None).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:08:55.493855
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert 'Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x7f5e7d5ca378>, value=None, is_evaluated=False]' == \
           str(Lazy.of(1))



# Generated at 2022-06-21 19:09:01.118871
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    lz = Lazy.of(lambda *args: [str(arg) for arg in args])
    assert str(lz) == "Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x{}>, value=None, is_evaluated=False]".format(
        hex(id(lz))
    )



# Generated at 2022-06-21 19:09:05.586646
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    def fn1(n):
        return n + 10

    assert Lazy.of(10).to_either()._value == Right(10)._value
    assert Lazy(fn1).to_either(10)._value == Right(20)._value



# Generated at 2022-06-21 19:09:10.903816
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1))
    assert not Lazy(lambda x: x).__eq__(None)
    assert not Lazy(lambda x: x).__eq__(1)


# Generated at 2022-06-21 19:09:14.551050
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.functor import Functor

    assert Functor.map(lambda _: '')(
        Lazy(lambda *args: '')
    ) == Lazy.of('')



# Generated at 2022-06-21 19:09:27.993084
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.validation import Validation
    from pymonet.either import Either, Left, Right
    from pymonet.maybe import Maybe, Nothing, Just
    from pymonet.box import Box
    from pymonet.monad_try import Try

    def test_function(*args):
        return args[0] + args[1]

    def test_function_raise(arg):
        if arg == 1:
            raise ValueError('error')
        return arg

    def test_function_left(arg):
        if arg == 1:
            raise ValueError('error')
        return arg

    def test_function_nothing(arg):
        if arg == 1:
            raise ValueError('error')
        return arg

    def test_function_just(arg):
        if arg == 1:
            raise ValueError('error')

# Generated at 2022-06-21 19:09:32.848907
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test map method of class Lazy with function returning different values
    """
    def plus_one(number):
        return number + 1

    def square(number):
        return number ** 2

    result = Lazy(lambda: 10).map(plus_one).map(square).get()

    assert result == 121



# Generated at 2022-06-21 19:09:40.880611
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.maybe import Just, Nothing
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def f(x):
        return x + 1

    def g(x):
        return x * 2

    def h(x):
        return x - 1

    def i(x):
        return x / 2

    def j(x):
        return x ** 2


    assert Lazy(f).map(g) == Lazy(f).map(g)
    assert Lazy(f).map(g) == Lazy.of(f).map(g)

# Generated at 2022-06-21 19:09:48.882531
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)
    assert Lazy(lambda: 1).to_box() == Box(1)
    assert Lazy(lambda: 1 / 0).to_box() == Box(1)

    try_lazy = Lazy(lambda: 1 / 0)
    assert isinstance(try_lazy.to_box(), Box)
    assert isinstance(try_lazy.to_box(), Try)
    assert try_lazy.to_box().is_success() == False
    assert try_lazy.to_box().get_error() is not None

    assert Lazy(lambda: None).to_box() == Box(None)


# Generated at 2022-06-21 19:09:56.358773
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """Unit tests for method to_either of class Lazy"""

    from pymonet.either import Right, Left

    def get_value(value):
        def lambda_fn(*args):
            return value
        return Lazy(lambda_fn)

    assert get_value(1).to_either() == Right(1)
    assert get_value(Right(1)).to_either() == Right(Right(1))
    assert get_value(Left(1)).to_either() == Right(Left(1))



# Generated at 2022-06-21 19:09:58.136825
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2


# Generated at 2022-06-21 19:10:00.224587
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    validation = Lazy.of(3).to_validation()

    assert(validation == Validation.success(3))


# Generated at 2022-06-21 19:10:03.876687
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy.of(123).to_try() == Try.of(lambda: 123)
    assert not (Lazy.of(123).map(lambda x: x / 0).to_try() == Try.of(lambda: 123 / 0))
    assert Lazy.of(123).map(lambda x: x / 0).to_try() == Try.of(lambda: 123 / 0)

# Generated at 2022-06-21 19:10:07.867967
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    add = Lazy(lambda a, b: a + b)
    mul = Lazy(lambda a, b: a * b)

    add_mul = add.ap(mul)

    assert add_mul._compute_value(2, 3) == 8

    assert add.ap(Lazy.of(2))._compute_value(2, 5) == 4

# Generated at 2022-06-21 19:10:13.140656
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(1).to_box() == Lazy.of(1).to_box() == Box(1)
    assert Lazy.of(1).to_box(1) == Lazy.of(1).to_box(1) == Box(1)


# Generated at 2022-06-21 19:10:17.829765
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy(lambda: 1).to_box() == Box(1)



# Generated at 2022-06-21 19:10:22.146797
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = lambda x: x**2
    l1 = Lazy(f)
    l2 = Lazy(f)
    l3 = Lazy(f).get()

    assert l1 != l2
    assert l1 == l2.get()
    assert l1 == l3
    assert l2 != l3



# Generated at 2022-06-21 19:10:24.309457
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add(a):
        return a + 10

    lazy = Lazy(lambda a: a * 2)

    assert lazy.map(add).get(10) == 30



# Generated at 2022-06-21 19:10:28.785007
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def xx():
        return 'xx'

    lazy = Lazy(xx)
    assert lazy.is_evaluated is False
    assert lazy.get() == 'xx'
    assert lazy.is_evaluated is True

    def yy(arg):
        return 'yy{}'.format(arg)

    lazy = Lazy(yy)
    assert lazy.is_evaluated is False
    assert lazy.get('y') == 'yyy'
    assert lazy.is_evaluated is True



# Generated at 2022-06-21 19:10:35.360748
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function <lambda> at 0x10a6c8b70>, value=None, is_evaluated=False]'
    assert str(Lazy.of(1)) == 'Lazy[fn=<function <lambda> at 0x10a6c8ea0>, value=None, is_evaluated=False]'

# Generated at 2022-06-21 19:10:41.752451
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure
    from pymonet import Lazy

    def fn_that_raise_exception(a, b):
        raise ValueError('Test error')

    def fn_that_not_raise_exception(a, b):
        return a+b

    lazy_instance_that_raise_exception = Lazy(fn_that_raise_exception)
    lazy_instance_that_not_raise_exception = Lazy(fn_that_not_raise_exception)

    success_try = lazy_instance_that_not_raise_exception.to_try(1, 2)
    assert isinstance(success_try, Try)
    assert success_try.is_success

# Generated at 2022-06-21 19:10:52.027765
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.utils import identity

    def _test_Lazy(
        fn_to_store: Callable[[int], int],
        args: list,
        result: int,
        constructor_fn_str: str,
        args_str: str,
        result_str: str
    ) -> None:
        lazy = Lazy(fn_to_store)
        assert lazy.constructor_fn == fn_to_store
        assert lazy.get(*args) == result
        assert lazy.get(*args) == result
        assert str(lazy) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(
            constructor_fn_str,
            result_str,
            True
        )


# Generated at 2022-06-21 19:10:54.789690
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of('test').to_validation() == Validation.success('test')



# Generated at 2022-06-21 19:10:57.402709
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda: 2)
    result = lazy.get()

    assert result == 2


# Generated at 2022-06-21 19:11:09.556513
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    print('---- test for method __eq__ of class Lazy ----')
    value = 'value'
    def fn(x):
        return x

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy1._compute_value(value)
    lazy2._compute_value(value)
    assert lazy1 == lazy2

    lazy1 = Lazy(fn)
    lazy2 = Lazy(lambda x: x)
    lazy1._compute_value(value)
    lazy2._compute_value(value)
    assert lazy1 != lazy2

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy1._compute_value(value)
    assert lazy1 != lazy2

    print('---- successfully passed ----')



# Generated at 2022-06-21 19:11:21.725756
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    def f(value):
        return Lazy.of(value + 5)

    def g(value):
        return Lazy.of(Box(value * 2))

    def h(value):
        return Lazy.of(Maybe.just(value + 10))

    def i(value):
        return Lazy.of(Right(value * 2))

    assert Lazy.of(5).bind(f).get() == 10
    assert Lazy.of(5).bind(g).get().get() == 10
    assert Lazy.of(5).bind(h).get().get() == 15
    assert Lazy.of(5).bind(i).get().get() == 10

# Generated at 2022-06-21 19:11:28.408285
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def add(x):
        print('Eval add')
        return x + 1

    def mul(y):
        print('Eval mul')
        return y * 2

    lazy = Lazy(lambda x: add(x)).map(lambda x: mul(x))

    assert lazy.get(1) == 4
    assert lazy.is_evaluated

    assert lazy.get(2) == 4
    assert lazy.is_evaluated


# Generated at 2022-06-21 19:11:31.716666
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x + 1)) == 'Lazy[fn=<function Lazy.<lambda> at 0x7faec9a9e620>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:11:37.997348
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from math import sqrt
    from pymonet.utils import id_

    first_lazy = Lazy(sqrt)
    second_lazy = Lazy(sqrt)

    assert first_lazy != second_lazy
    assert first_lazy == Lazy(sqrt)
    assert Lazy(id_).__eq__(Lazy(id_))  # pylint: disable=no-member
    # test of equals of Lazy with evaluated value
    assert Lazy(sqrt).map(sqrt).get(4) == 2
    assert Lazy(sqrt).map(sqrt).__eq__(Lazy(sqrt).map(sqrt))



# Generated at 2022-06-21 19:11:48.751252
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Error

    def throw_exception(flag):
        if flag:
            raise ValueError('exception')
        return flag

    def get_value(flag):
        return Lazy.of(flag)

    assert Lazy(throw_exception).to_try(False).get_value() == Try.of(throw_exception, False).get_value()
    assert Lazy(throw_exception).to_try(True).get_value() == Try.of(throw_exception, True).get_value()

    assert Lazy(get_value).ap(Lazy.of(True)).to_try().get_value() == Try.of(get_value).ap(Try.of(True)).get_value()
    assert Lazy

# Generated at 2022-06-21 19:11:54.406615
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.monad_try import TryError

    assert Lazy.of(1).to_try() == Try.success(1)
    assert Lazy(lambda: 1/0).to_try() == Try.failure(TryError('division by zero'))

# Generated at 2022-06-21 19:11:58.037746
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    def add_two(x):
        return x + 2

    def raise_some_error():
        raise ValueError('Has Error')

    assert Lazy(add_two).to_maybe(1).just().bind(add_two).just().value == 4
    assert Lazy(raise_some_error).to_maybe().is_none()

# Generated at 2022-06-21 19:12:02.174992
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def test_function(*args):
        return 'value'

    expected_result = Validation.success('value')
    assert Lazy(test_function).to_validation() == expected_result

# Generated at 2022-06-21 19:12:05.084843
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(2).to_validation() == Validation.success(2)

# Generated at 2022-06-21 19:12:06.923248
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1))
    assert not Lazy(lambda x: x).__eq__(123)


# Generated at 2022-06-21 19:12:18.956532
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add_2(x):
        return x + 2

    def multiply_by_3(x):
        return x * 3

    lazy: Lazy[int, int] = Lazy.of(multiply_by_3)
    assert lazy.ap(Lazy.of(add_2)).get(2) == 12

    lazy: Lazy[int, int] = Lazy.of(add_2)
    assert lazy.ap(Lazy.of(add_2)).get(2) == 6



# Generated at 2022-06-21 19:12:26.164227
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Maybe

    a_maybe = Maybe.just(5)

    lazy_number = Lazy.of(5)
    lazy_maybe = Lazy.of(a_maybe)

    def add_five(number):
        return number + 5

    def add_ten_in_maybe(maybe):
        return maybe.map(lambda number: number + 10)

    assert lazy_number.map(add_five).get() == 10
    assert lazy_maybe.map(add_ten_in_maybe).fold(lambda x: x, lambda a: a) == 15


# Generated at 2022-06-21 19:12:28.358302
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy(lambda x: x).to_either(1) == Right(1)



# Generated at 2022-06-21 19:12:31.332252
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def func(a):
        return Lazy(lambda b: a + b)

    Lazy(lambda: 4).ap(Lazy(func)).get(5)
    # 9

# Generated at 2022-06-21 19:12:36.234368
# Unit test for method get of class Lazy
def test_Lazy_get():
    add_one = lambda x: x + 1

    lazy_val = Lazy.of(2)
    assert lazy_val.get() == 2

    lazy_val = Lazy(add_one)
    assert lazy_val.get(2) == 3



# Generated at 2022-06-21 19:12:42.337796
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def fn_raising_exception(*args):
        raise Exception(args)

    lazy = Lazy.of(0)
    assert lazy.to_try(1, 2) == Try.success(0)

    lazy = Lazy(fn_raising_exception)
    assert lazy.to_try(1, 2) == Try.failure(Exception((1, 2, )))


# Generated at 2022-06-21 19:12:43.888527
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1



# Generated at 2022-06-21 19:12:55.975886
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right, Left

# Generated at 2022-06-21 19:12:57.621644
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    lazy = Lazy.of(10)

    assert lazy.to_maybe() == Maybe.just(10)

# Generated at 2022-06-21 19:13:00.168388
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    assert Lazy.of(6).to_either() == Right(6)



# Generated at 2022-06-21 19:13:16.298859
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def f(value):
        if value in [0, 1, 2]:
            return 'result'
        raise ValueError()

    assert Lazy.of('result').to_try() == Try.of(f, 0)
    assert Lazy(f).to_try(5) == Try.of(f, 5)
    assert Lazy(f).to_try(0) == Try.of(f, 0)

    assert Lazy(f).to_try(2) == Try.of(f, 2)
    assert Lazy(f).to_try(3).failed() == Try.of(f, 3).failed()


# Generated at 2022-06-21 19:13:24.115607
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    Test of Lazy constructor
    """
    from pymonet.custom_assert import assert_that

    lazy = Lazy.of(1)

    assert_that(Lazy.of(1), lazy).is_equal_to()
    assert_that(lazy.is_evaluated).is_false()
    assert_that(lazy.get()).is_equal_to(1)
    assert_that(lazy.is_evaluated).is_true()
    assert_that(lazy.constructor_fn(1)).is_equal_to(1)
    assert_that(lazy.is_evaluated).is_true()



# Generated at 2022-06-21 19:13:29.662021
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    call method bind of lazy with function returning lazy.
    """
    def fn(value):
        return Lazy(lambda: value + 1)

    result = Lazy(lambda: 1).bind(fn).get()

    assert result == 2
    assert Lazy(lambda: 1).bind(fn) == Lazy(lambda: 2)



# Generated at 2022-06-21 19:13:39.635522
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def multiply_by_two(num: int) -> int:
        return num * 2

    def sum_by_two(num: int) -> int:
        return num + 2

    lazy_multiply = Lazy(multiply_by_two)
    assert lazy_multiply.is_evaluated is False
    assert lazy_multiply.get(3) == 6
    assert lazy_multiply.value == 6
    assert lazy_multiply.is_evaluated is True

    lazy_sum = lazy_multiply.map(sum_by_two)
    assert lazy_sum.is_evaluated is False
    assert lazy_sum.get(3) == 8
    assert lazy_sum.value == 8
    assert lazy_sum.is_evaluated is True

    assert lazy

# Generated at 2022-06-21 19:13:42.432697
# Unit test for constructor of class Lazy
def test_Lazy():
    assert 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'.replace(' ', '') == str(Lazy(lambda: 'Lazy'))



# Generated at 2022-06-21 19:13:49.005000
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import random

    random_number = random.randint(0, 100)

    def multiply_by_two(number):
        return number * 2

    assert Lazy(lambda: random_number).ap(Lazy(multiply_by_two)).get() == multiply_by_two(random_number)
    assert Lazy(lambda: random_number).ap(Lazy(lambda: multiply_by_two(random_number))).get() == multiply_by_two(random_number)


# Generated at 2022-06-21 19:13:56.675133
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.function import identity

    lazy = Lazy(identity)
    assert str(lazy) == 'Lazy[fn=<function identity at 0x7f965da9b158>, value=None, is_evaluated=False]'

    lazy._compute_value(1)
    assert str(lazy) == 'Lazy[fn=<function identity at 0x7f965da9b158>, value=1, is_evaluated=True]'



# Generated at 2022-06-21 19:14:03.932147
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    def f():
        raise RuntimeError('my error')

    def g():
        return 5

    assert Lazy(lambda: 5) == Lazy(lambda: 5)
    assert Lazy(f) != Lazy(g)

    assert Lazy(f) != f
    assert Lazy(f) != Lazy(lambda: 5)

    assert Lazy(g) == Lazy(g)
    assert Lazy(g).map(lambda x: x * 2) == Lazy(g).map(lambda x: x * 2)
    assert Lazy(f).to_try() == Try.failure(RuntimeError('my error'))

# Generated at 2022-06-21 19:14:06.152760
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(2).to_box() == Box(2)


# Generated at 2022-06-21 19:14:10.142133
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Success, Failure

    # fn = lambda d: Lazy(lambda: Success(d))
    fn = lambda d: Lazy.of(d)

    successful_lazy = Lazy.of(1).bind(fn)
    assert successful_lazy.is_evaluated
    assert successful_lazy.get() == 1

    failing_lazy = Lazy(ValueError)
    assert not failing_lazy.is_evaluated
    assert failing_lazy.bind(fn).get() == failure(ValueError)

# Generated at 2022-06-21 19:14:30.582361
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    value = Maybe.just(1)
    lazy = Lazy.of(value)

    assert lazy.get() == lazy.to_maybe()

# Generated at 2022-06-21 19:14:32.785576
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():

    lazy = Lazy.of(1)
    assert Maybe.just(1) == lazy.to_maybe()


# Generated at 2022-06-21 19:14:39.033558
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """
    Test to_either method
    """
    from pymonet.either import Either, Left, Right

    def constructor_fn(*_):
        raise RuntimeError("expected error")

    assert isinstance(Lazy(constructor_fn).to_either(), Either)
    assert isinstance(Lazy(constructor_fn).to_either(), Left)
    assert Lazy(constructor_fn).to_either().get_value() == RuntimeError("expected error")
    assert isinstance(Lazy(lambda: 5).to_either(), Either)
    assert isinstance(Lazy(lambda: 5).to_either(), Right)
    assert Lazy(lambda: 5).to_either().get_value() == '5'



# Generated at 2022-06-21 19:14:41.936543
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Validation.of(4).to_lazy().to_validation() == Validation.success(4)

# Generated at 2022-06-21 19:14:46.603639
# Unit test for method bind of class Lazy
def test_Lazy_bind(): # pragma: no cover
    from pymonet.validation import Validation

    L = Lazy(lambda name: 'Hello, ' + name)
    assert L.bind(lambda x: Lazy.of(Validation.success(x))).get('Daria') == Validation.success('Hello, Daria')

# Generated at 2022-06-21 19:14:55.849580
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # two Lazy are equals where both are evaluated both have the same value and constructor functions
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1).map(lambda x: x + 1) == Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1).to_either() != Right(2)
    assert Lazy.of(1).to_maybe() != None
    assert Lazy.of(1).to_try() != Try.failure('error')
    assert Lazy.of(1).to_validation() != Validation.success(2)

# Generated at 2022-06-21 19:14:58.981874
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for method get of class Lazy
    """
    assert Lazy.of(1).get() == 1
    assert Lazy(mean).get([1, 2, 3]) == 2
    assert Lazy(lambda x: x).get(1) == 1



# Generated at 2022-06-21 19:15:02.220152
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda x: x**2)(16) == 256

    with pytest.raises(Exception):
        Lazy(lambda: 2/0).get()

    def set_to_none():
        global a_global_var
        a_global_var = None

    global a_global_var
    a_global_var = 1
    Lazy(set_to_none).get()

    assert a_global_var is None



# Generated at 2022-06-21 19:15:12.781933
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == Lazy.of(2).get()
    assert Lazy.of(1).bind(lambda _: Lazy.of(2)).get() == Lazy.of(2).get()
    assert Lazy.of(1).bind(lambda _: Lazy.of(2)).get() == 2
    assert Lazy.of(lambda: 1).bind(lambda fn: Lazy.of(fn())).get() == 1
    assert Lazy.of(lambda x: x).bind(lambda fn: Lazy(lambda: fn(Lazy.of(1).get()))).get() == 1


# Generated at 2022-06-21 19:15:16.572318
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy(lambda x: x)
    lazy2 = lazy.bind(lambda x: Lazy.of(x + 1))
    assert lazy.is_evaluated == False
    assert lazy2.is_evaluated == False
    assert lazy2.get(1) == 2



# Generated at 2022-06-21 19:15:51.910441
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda x: x).get(5) == 5
    assert Lazy(lambda x: x).to_try(5).get() == 5
    assert Lazy(lambda: [1, 2]).to_try().get() == [1, 2]


# Generated at 2022-06-21 19:16:02.660985
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_maybe import Maybe, Empty

    fn = Lazy.of(lambda x, y: x * y)
    assert fn.ap(Maybe.just(2)).get(1) == 2
    assert isinstance(fn.ap(Empty()).get(1), Empty)

    add_two = Lazy.of(lambda x, y: x + y)
    multiply_by_three = Lazy.of(lambda x, y: x * y)

    assert (
        add_two.ap(Maybe.just(2))
            .ap(multiply_by_three.map(lambda x: x * 3).to_maybe(1))
            .to_maybe(1)
        == Maybe.just(5)
    )



# Generated at 2022-06-21 19:16:07.602197
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def add(a, b):
        return a + b

    lazy = Lazy(add)

    assert str(lazy) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(add, None, False)


# Generated at 2022-06-21 19:16:15.590170
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    fn = lambda: 5
    result = Lazy(fn).to_maybe()
    assert result == Maybe.just(5) and type(result) == Maybe
    result = Lazy(fn).to_box()
    assert result == Box(5) and type(result) == Box
    result = Lazy(fn).to_validation()
    assert result == Validation.success(5) and type(result) == Validation

# Generated at 2022-06-21 19:16:17.502180
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy(lambda x: x).to_validation(0) == Validation.success(0)


# Generated at 2022-06-21 19:16:29.049290
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Lazy(lambda x: 1).to_validation() == Validation.success(1)

    assert Lazy(lambda: 1 / 0).to_validation() == Validation.failure([ZeroDivisionError.__name__])

    assert Lazy(lambda: 1 / 0).to_validation(lambda exception:
                                             Validation.success(exception.__class__.__name__)) == \
                                             Validation.success(ZeroDivisionError.__name__)


# Generated at 2022-06-21 19:16:32.562586
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.monad_test import TestClass

    test_lazy = Lazy(lambda x: TestClass(x))
    assert test_lazy.constructor_fn
    assert not test_lazy.is_evaluated
    assert test_lazy.value is None


# Generated at 2022-06-21 19:16:35.249499
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_maybe import Maybe

    def map_fn(x):
        return Lazy(lambda *args: x + 1)

    assert Lazy(lambda *args: 1).bind(map_fn).get() == 2



# Generated at 2022-06-21 19:16:38.582402
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    #pylint: disable=invalid-name
    from pymonet.either import Left

    lazy_1 = Lazy.of(1)

    assert lazy_1.bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert lazy_1.bind(lambda _: Lazy.of((Left(ValueError('error'))))) == Lazy.of(Left(ValueError('error')))

# Generated at 2022-06-21 19:16:49.063579
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def success_fn(x, y):
        return x + y

    def failure_fn(x, y):
        return Try.of(lambda: x / y)

    plus_one = lambda x: x + 1
    plus_two = lambda x: x + 2
    plus_three = lambda x: x + 3

    assert Lazy.of(success_fn).ap(Lazy.of(plus_one)).get(5, 5) == 11
    assert Lazy.of(success_fn).ap(Lazy.of(plus_one).ap(Lazy.of(plus_two))).get(5, 5) == 14