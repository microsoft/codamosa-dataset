

# Generated at 2022-06-21 19:07:41.290947
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from test.testing_utils import should_throw
    from pymonet.monad_try import Try

    def fn(x):
        try:
            return int(x)
        except:
            return None

    lazy = Lazy(fn)

    assert isinstance(lazy.to_try('3'), Try)
    assert lazy.to_try('3').get() == 3
    assert lazy.to_try('3').is_success() is True
    assert lazy.to_try('3').is_failure() is False
    assert lazy.to_try('3').value == 3
    assert lazy.to_try('3').fail_value is Try.NOT_SET

    assert isinstance(lazy.to_try('a'), Try)
    assert lazy.to_try('a').get() is None
    assert lazy.to_

# Generated at 2022-06-21 19:07:48.175480
# Unit test for constructor of class Lazy
def test_Lazy():
    l = Lazy(lambda x: x + 1)
    assert l == Lazy(lambda x: x + 1)
    assert l != Lazy(lambda x: x + 2)
    assert l.constructor_fn(2) == 3
    assert str(l) == 'Lazy[fn=<function Lazy.<lambda> at 0x7f3a3b65d950>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:07:49.662339
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(10).to_box() == Box(10)



# Generated at 2022-06-21 19:08:01.053820
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    import unittest

    class TestLazyToTry(unittest.TestCase):
        def test_with_function_that_raise_error(self):
            from pymonet.monad_try import Failure

            def call_function_raise_error(_):
                raise AttributeError('Not expected attribute')

            lazy = Lazy(call_function_raise_error)
            result = lazy.to_try()

            self.assertTrue(isinstance(result, Failure))

        def test_with_function_that_return_value(self):
            from pymonet.monad_try import Success

            lazy = Lazy(lambda _: 10)
            result = lazy.to_try()

            self.assertTrue(isinstance(result, Success))
            self.assertEqual(result.get(), 10)


# Generated at 2022-06-21 19:08:04.274788
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(2) != Lazy(lambda value: value * 2)



# Generated at 2022-06-21 19:08:15.854557
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test_fn(x: int) -> bool:
        return x >= 20

    test_lazy = Lazy.of(1).map(lambda x: x + 10).map(lambda x: x * 2)

    assert test_lazy.get(1) == 22
    assert test_lazy.get(2) == 22
    assert test_lazy.get(3) == 22

    assert test_lazy.to_maybe(1).fold(lambda: False, test_fn) == True
    assert test_lazy.to_maybe(2).fold(lambda: False, test_fn) == True
    assert test_lazy.to_maybe(3).fold(lambda: False, test_fn) == True

# Generated at 2022-06-21 19:08:18.621532
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1) is True
    assert Lazy.of(2) == Lazy.of(1) is False

# Generated at 2022-06-21 19:08:22.527391
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    value = 1
    lazy_value = Lazy.of(value)
    validation = lazy_value.to_validation()

    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.get() == value



# Generated at 2022-06-21 19:08:31.059846
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1)._compute_value() == 1
    assert Lazy.of(1).map(lambda x: x * 2)._compute_value() == 2
    assert Lazy.of(5).get() == 5
    assert Lazy.of(5).map(lambda x: x * 2).get() == 10
    assert Lazy.of(5).map(lambda x: x * 2).map(lambda x: x * 5).get() == 50

# Generated at 2022-06-21 19:08:32.616572
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of("asd").get() == "asd"

# Generated at 2022-06-21 19:08:38.045921
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x: x).get(1) == 1
    assert Lazy(lambda x: x).get(1, 2) == 1
    assert Lazy(lambda x: x).get(1, 1, 1) == 1
    assert Lazy(lambda x: x ** 2).get(2, 2, 1) == 4


# Generated at 2022-06-21 19:08:44.591622
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    def identity(x: int) -> int:
        return x

    def generate_error(x: int) -> int:
        raise ValueError('Invalid value')

    lazy_success = Lazy(identity)
    lazy_fail = Lazy(generate_error)

    assert lazy_success.to_try(2) == Try.of(identity, 2)
    assert lazy_fail.to_try(2) == Try.raise_error(ValueError('Invalid value'))



# Generated at 2022-06-21 19:08:52.205945
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add_three(x):
        return x + 3

    assert Lazy(add_three).get(1) == 4
    assert Lazy(add_three).get(2) == 5
    assert Lazy(add_three).get(3) == 6

    assert Lazy(lambda x: x + 5).get(1) == 6
    assert Lazy(lambda x: x + 5).get(2) == 7
    assert Lazy(lambda x: x + 5).get(3) == 8



# Generated at 2022-06-21 19:08:59.703315
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(5) == Lazy.of(5).to_maybe()
    assert Maybe.just(5) == Lazy.of(5).to_maybe(1)
    assert Maybe.just(5) == Lazy.of(5).to_maybe(*[])
    assert Maybe.just(5) == Lazy.of(5).to_maybe(*["a"])



# Generated at 2022-06-21 19:09:01.567212
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    assert Lazy.of(1).to_either() == Right(1)


# Generated at 2022-06-21 19:09:10.461816
# Unit test for method map of class Lazy
def test_Lazy_map():
    # type: () -> None
    """
    Unit test for method map of class Lazy
    """
    from pymonet.monad_either import Left

    # Setup
    fn = Lazy(lambda: 42).map(lambda v: v**2)

    # Execute
    result = fn._compute_value()

    # Verify
    assert fn.is_evaluated
    assert result == 42**2
    assert fn == Lazy(lambda: 42).map(lambda v: v**2)
    assert fn != Lazy(lambda: 42).map(lambda v: v**2).map(lambda v: v**2)



# Generated at 2022-06-21 19:09:14.176532
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    # Arrange
    from pymonet.either import Right

    # Action
    lazy = Lazy.of(10)

    # Assert
    right = Right(10)
    assert right == lazy.to_either()


# Generated at 2022-06-21 19:09:16.260607
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(10).to_validation() == Validation.success(10)

# Generated at 2022-06-21 19:09:20.899765
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(42) == Lazy.of(42)
    assert not (Lazy.of('Hello') == Lazy.of('world'))
    assert not (Lazy.of('Hello') == 'Hello')

# Generated at 2022-06-21 19:09:24.102217
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.util import identity

    assert Lazy(lambda: 1).to_either() == Right(1)
    assert Lazy(lambda: 1).map(identity).to_either() == Right(1)

# Generated at 2022-06-21 19:09:33.180057
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(3).bind(lambda n: Lazy.of(n + 1)).get() == 4
    assert Lazy.of(3).bind(lambda n: Lazy.of(n + 1)).get() == 4
    assert Lazy.of(3).bind(lambda n: Lazy.of(n + 1)).get() == 4

# Generated at 2022-06-21 19:09:37.704143
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.maybe import Maybe

    # Given
    maybe_value = Maybe.just(None)
    lazy_maybe = Lazy(maybe_value.get)

    # When
    result = lazy_maybe.to_either().to_maybe()

    # Then
    assert maybe_value == result, 'Lazy to_either() should transform Maybe into Lazy'

# Generated at 2022-06-21 19:09:43.116038
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    def fn(a):
        return a + 1

    def zero(a):
        return 0

    assert Right(2) == Lazy(fn).to_either(1)
    assert Right(0) == Lazy(zero).to_either(1)


# Generated at 2022-06-21 19:09:45.514831
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy(lambda: 123).to_maybe() == Maybe(123)
    assert Lazy(lambda: NotImplementedError('not implemented')).to_maybe() == Maybe(NotImplementedError('not implemented'))



# Generated at 2022-06-21 19:09:57.227528
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left
    from functools import partial

    square = lambda value: value * value
    inc = lambda value: value + 1

    assert str(Lazy.of(3).map(square)) == (
        'Lazy[fn=<function test_Lazy_map.<locals>.<lambda> at 0x7f94c0b17e18>, '
        'value=9, is_evaluated=False]'
    )

# Generated at 2022-06-21 19:10:03.613846
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(value):
        return Lazy(lambda *args: value + 1)

    lazy = Lazy(lambda *args: 1)
    assert lazy.bind(fn).get() == 2, 'Bind should return new Lazy with function applying function to previous value'

    lazy = Lazy(lambda *args: 0)
    assert Lazy(lambda *args: 1).bind(lambda x: Lazy(lambda *args: x + 1)).get() == 2, \
        'Bind should return new Lazy with function applying function to previous value'



# Generated at 2022-06-21 19:10:10.535676
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.functor import identity, compose

    fn = lambda x: x * 2
    lazy_fn = Lazy(fn)
    lazy_fn_mapped = lazy_fn.map(lambda x: x * 2)

    assert lazy_fn.map(identity) == Lazy.of(1).map(lambda x: fn(x)).map(identity)
    assert lazy_fn.map(identity) == lazy_fn

    assert lazy_fn.map(compose(identity, fn)) == Lazy.of(1).map(lambda x: fn(fn(x))).map(identity)
    assert lazy_fn.map(compose(identity, fn)) == lazy_fn.map(fn).map(identity)


# Generated at 2022-06-21 19:10:14.309341
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Box(1) == Lazy.of(1).to_box()


# Generated at 2022-06-21 19:10:24.044967
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def constructor_fn():
        try:
            return 10 / 2
        except Exception as e:
            raise e

    assert Lazy.of(constructor_fn).to_try() == Try.of(constructor_fn)

    try:
        assert Lazy.of(constructor_fn).map(lambda x: 10 / x).to_try() == Try.of(lambda: 10 / (10 / 2))
    except ZeroDivisionError as e:
        test_error = e

    assert Lazy.of(constructor_fn).map(lambda x: 10 / x).to_try().get_exception() == test_error

    def name_error():
        raise NameError

    assert Lazy.of(name_error).to_try().get_exception() == NameError

# Generated at 2022-06-21 19:10:35.359867
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Error

    assert type(Lazy.of(1).to_try().get()) is int
    try:
        Lazy.of(1 / 0).to_try().get()
        assert False
    except ZeroDivisionError:
        assert True

    assert Lazy.of(1).to_try().is_success()
    assert Lazy.of(1 / 0).to_try().is_failure()
    assert Try.failure(ZeroDivisionError('division by zero')) == Lazy.of(1 / 0).to_try()

    exception = ZeroDivisionError('division by zero')


# Generated at 2022-06-21 19:10:44.685667
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    def get_value() -> tuple:
        return (1, '2')

    lazy = Lazy(get_value)

    assert lazy.to_maybe() == Maybe.just(lazy.get())
    assert lazy.to_maybe() != Maybe.nothing()


# Generated at 2022-06-21 19:10:50.628850
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    def boo():
        return "foo"

    assert Lazy.of("lazy").to_validation() == Validation.success("lazy")

    assert Lazy(boo).to_validation() == Validation.success("foo")

    def foo():
        raise ValueError("foo")

    assert Lazy(foo).to_validation() == Validation.failure("foo")



# Generated at 2022-06-21 19:10:54.282308
# Unit test for method get of class Lazy
def test_Lazy_get():
    # given
    lazy_true = Lazy.of(True)
    lazy_false = Lazy.of(False)
    lazy_eager = Lazy(lambda: True)
    # when
    result_lazy_true = lazy_true.get()
    result_lazy_false = lazy_false.get()
    result_lazy_eager = lazy_eager.get()
    # then
    assert result_lazy_true is True
    assert result_lazy_false is False
    assert result_lazy_eager is True

# Generated at 2022-06-21 19:10:58.637036
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda: "test")
    assert lazy.get() == "test"
    assert lazy.get() == "test"
    assert lazy.get() == "test"
    assert lazy.is_evaluated
    assert lazy.value == "test"


# Generated at 2022-06-21 19:11:03.082005
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet import Lazy

    def fn():
        return 1

    assert Lazy.of(fn).to_try().is_success

    def fn():
        return 1 / 0

    assert Lazy.of(fn).to_try().is_failure

# Generated at 2022-06-21 19:11:04.718014
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda *args, **kwargs: None) != '('

# Generated at 2022-06-21 19:11:08.325175
# Unit test for method to_box of class Lazy
def test_Lazy_to_box(): # pragma: no cover
    from pymonet.box import Box
    assert Box(5) == Lazy.of(5).to_box()


# Generated at 2022-06-21 19:11:15.372327
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(None).bind(lambda value: Lazy.of('value')) == Lazy.of('value')
    assert Lazy.of(None).bind(lambda value: Lazy.of('value')).bind(lambda value: Lazy.of('newValue')) == Lazy.of('newValue')
    assert Lazy.of(None).bind(lambda value: Lazy.of('value')).bind(lambda value: Lazy.of(None)).bind(lambda value: Lazy.of('newValue')) == Lazy.of(None)
    assert Lazy.of(None).bind(lambda value: Lazy.of(None)).bind(lambda value: Lazy.of('value')).bind(lambda value: Lazy.of('newValue')) == Lazy.of(None)

# Generated at 2022-06-21 19:11:19.509004
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    test_Lazy = Lazy(lambda x: x)
    assert test_Lazy.__str__() == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x0000026FB8172EA0>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:11:26.526158
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma no cover
    from pymonet.monad_tests.lazy_test_helpers import map_lazy_test

    # Test for map with function identity
    map_lazy_test(lambda x: x, lambda x: x)

    # Test for map with function f
    map_lazy_test(lambda x: x + 1, lambda x: x + 1)


# Generated at 2022-06-21 19:11:38.381898
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.functor import Functor

    from pymonet.monad_maybe import Maybe
    from pymonet.monad_validation import Validation
    from pymonet.monad_try import Try
    from pymonet.applicative import Applicative

    def mapper1(value):
        return value + 1
    def monad_mapper(value):
        return Maybe.just(value)

    def ap_mapper(value):
        return Lazy.of(value + 1)

    def valid_mapper(value):
        return Validation.success(value)
    def valid_error_mapper(value):
        return Validation.fail(['ERROR'])

    def try_mapper(value):
        return Try.of(lambda: value)

# Generated at 2022-06-21 19:11:40.074524
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(1) == 2
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(2) == 3


# Generated at 2022-06-21 19:11:44.108549
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    f_one = Lazy.of(1)
    assert f_one.get() == 1

    def f_two():
        return 2

    g_two = Lazy(f_two)
    assert g_two.get() == 2



# Generated at 2022-06-21 19:11:46.234504
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.maybe import Nothing
    assert Maybe.just(1).to_lazy() == Lazy.of(1).to_maybe()
    assert Nothing.instance() == Lazy.of(1).to_maybe().to_nothing()

# Generated at 2022-06-21 19:11:56.931126
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe

    def fn():
        raise Exception('wooooooops')

    assert Lazy.of(7).to_box() == Box(7)
    assert Lazy.of(lambda *args: 7).to_box(1) == Box(7)
    assert Lazy.of(Try.of(lambda: 7)).to_box() == Box(7)
    assert Lazy.of(lambda *args: Try.of(lambda: 7)).to_box() == Box(7)
    assert Lazy.of(lambda *args: Try.of(fn)).to_box() == Box(None)
    assert Lazy.of(Right(7)).to_box

# Generated at 2022-06-21 19:12:08.747637
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Method Lazy.ap apply function inside Lazy to another applicative
    """
    from pymonet.either import Left
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    ## Apply Lazy functions to Box, Either and Validation

    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).get() == 2, \
        'Should apply function from Lazy to argument'
    assert Lazy.of(lambda x: x + 2).ap(Either.right(1)).get() == 3, \
        'Should apply function from Lazy to Either monad'

# Generated at 2022-06-21 19:12:16.566326
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    import pymonet.functor as F

    def fn(box1):
        def inner(x):
            return Lazy.of(box1.get() + x)
        return inner

    def fn_mapper(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).map(fn_mapper).get() == 2
    assert Lazy.of(1).bind(fn(F.Box(1))).get() == 2



# Generated at 2022-06-21 19:12:18.214817
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(1).to_box() == Lazy.of(1).to_box()



# Generated at 2022-06-21 19:12:21.239555
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    lazy = Lazy.of(1)
    assert lazy.__str__() == 'Lazy[fn=<function <lambda> at 0x000001F7F0C0C620>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:12:27.199350
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():

    class TestClass(object):
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return isinstance(other, TestClass) and self.value == other.value

        def __str__(self):
            return "TestClass {}".format(self.value)

    def test_fn(value):
        return TestClass(value + 10)

    lazy = Lazy(test_fn)
    assert str(lazy) == 'Lazy[fn=<function Lazy<lambda> at 0x7f85d2938ae8>, value=None, is_evaluated=False]'
    assert lazy == Lazy(test_fn)
    # another lazy with the same function
    lazy2 = Lazy(test_fn)
    assert lazy == lazy2
    assert lazy.get

# Generated at 2022-06-21 19:12:37.516749
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def add(x, y):
        return x + y

    lazy = Lazy(lambda: add(1, 2))

    assert lazy.to_box() == Box(3)



# Generated at 2022-06-21 19:12:40.961064
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    lazy = Lazy(lambda: 2).map(lambda x: x * 2)
    assert lazy.to_maybe() == Maybe.just(4)



# Generated at 2022-06-21 19:12:52.668296
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(3) == Lazy.of(3)
    assert Lazy.of(3) == Lazy(lambda: 3)
    assert Lazy(lambda *args: 3) == Lazy(lambda *args: 3)
    assert Lazy(lambda *args: 3) == Lazy(lambda *args: 3)
    assert Lazy(lambda *args: 3) == Lazy.of(3)
    assert Lazy.of(3) == Lazy(lambda *args: 3)
    assert Lazy.of(3) != Lazy.of(4)
    assert Lazy.of(3) != Lazy(lambda: 4)
    assert Lazy.of(3) != Lazy(lambda *args: 4)
    assert Lazy(lambda *args: 3) != Lazy.of(4)
    assert L

# Generated at 2022-06-21 19:12:56.896378
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def f():
        return None

    lazy = Lazy(f)

    expected = 'Lazy[fn=' + repr(f) + ', value=None, is_evaluated=False]'
    actual = repr(lazy)
    assert actual == expected


# Generated at 2022-06-21 19:13:00.131334
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet import identity

    assert Lazy.of(None).to_box() == Box(None)
    assert Lazy(identity).to_box(1) == Box(1)



# Generated at 2022-06-21 19:13:04.649301
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import ValidationError

    assert Lazy.of(2).to_validation() == Validation.success(2)
    assert Lazy.of(ValidationError('Error')).to_validation() == Validation.failure(ValidationError('Error'))


# Generated at 2022-06-21 19:13:07.414844
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    assert Lazy(lambda: 1) == Lazy(lambda: 1)

    assert (
        Lazy(lambda: 1) == Lazy(lambda: 1)
        and Lazy(lambda: 1) != Lazy(lambda: 2)
        and Lazy(lambda: 1) != Lazy(lambda: 2) == Lazy(lambda: 2)
        and Lazy(lambda: 1) != Lazy(lambda: 2) != Lazy(lambda: 1)
    )


# Generated at 2022-06-21 19:13:16.857722
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x: x).get(2) == 2
    assert Lazy(lambda: 42).get() == 42
    assert Lazy(id).get(23) == 23
    assert Lazy(lambda x: x).ap(Lazy(lambda x: x)).get(2) == 2
    assert Lazy(lambda x: x * 2).bind(lambda x: Lazy(lambda: x * 2)).get(4) == 16
    assert Lazy(lambda x: x).map(lambda x: x * 2).get(2) == 4
    assert Lazy(lambda x: x).to_box(2).get() == 2
    assert Lazy(lambda x: x).to_either(2).get_or_else(5) == 2
    assert Lazy(lambda x: x).to_try(2).get_or_

# Generated at 2022-06-21 19:13:18.938019
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    >>> lazy = Lazy(lambda: 3)
    >>> assert lazy.get() == 3
    >>> assert lazy.is_evaluated
    >>> lazy._compute_value()
    >>> assert lazy.get() == 3
    >>> assert lazy.is_evaluated
    """

# Generated at 2022-06-21 19:13:26.030566
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    assert Lazy(lambda *args: 'value').get() == 'value'
    assert Lazy(lambda *args: 'value').to_box() == Box('value')
    assert Lazy(lambda *args: 'value').to_either() == Right('value')
    assert Lazy(lambda *args: 'value').to_maybe() == Maybe.just('value')
    assert Lazy(lambda *args: 'value').to_try() == Try.of(lambda *args: 'value')
    assert Lazy(lambda *args: 'value').to_validation() == Validation.success('value')

#

# Generated at 2022-06-21 19:13:40.644363
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.validation import Validation

    a = Lazy(lambda: 2)
    b = a.map(lambda x: x * 4)
    c = a.ap(b)

    assert c.get() == 16

    d = Box(lambda x: x * 8)
    e = a.ap(d)

    assert e.get() == 16
    d = Right(lambda x: x * 8)
    e = a.ap(d)

    assert e.get() == 16

    f = Validation.success(lambda x: x * 8)
    g = a.ap(f)

    assert g.get() == 16

# Generated at 2022-06-21 19:13:46.623315
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    Test for Lazy class constructor.

    :returns: nothing
    :rtype: None
    """
    from pymonet.either import Right

    def f(x):
        return x

    assert (Lazy.of(Right(10)) == Lazy(lambda *args: Right(10)))
    assert (Lazy(f) == Lazy.of(f))


# Generated at 2022-06-21 19:13:56.339866
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x * 2).ap(Lazy.of(3)) == Lazy.of(6)
    assert Lazy.of(lambda x, y: x * y).ap(Lazy.of(3)).ap(Lazy.of(4)) == Lazy.of(12)
    assert Lazy.of(lambda x, y, z: x + y + z).ap(Lazy.of(3)).ap(Lazy.of(4)).ap(Lazy.of(5)) == Lazy.of(12)

    str_concener = Lazy.of(lambda x, y: x + y)
    assert str_concener.ap(Lazy.of('foo')).ap(Lazy.of('bar')) == Lazy.of('foobar')

# Generated at 2022-06-21 19:14:00.138975
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    not_empty_lazy = Lazy.of(42)
    empty_lazy = Lazy(lambda: 1 / 0)

    assert not_empty_lazy.to_try() == Try.of(not_empty_lazy.constructor_fn)
    assert empty_lazy.to_try() == Try.of(empty_lazy.constructor_fn)

# Generated at 2022-06-21 19:14:02.983416
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def mul_one(x: int) -> Lazy[int, int]:
        return Lazy(lambda y: x * y)

    assert Lazy.of(2).bind(mul_one).get(2) == 4



# Generated at 2022-06-21 19:14:04.634004
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(10).bind(lambda x: Lazy.of(x + 2)) == Lazy(lambda: 10 + 2)


# Generated at 2022-06-21 19:14:06.927584
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def operation_to_try():
        return Try(1 / 0)

    lazy_operation = Lazy(operation_to_try)
    try_operation = lazy_operation.to_try()
    assert try_operation.is_failure()

# Generated at 2022-06-21 19:14:09.818200
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.either import Left

    lazy = Lazy.of(5)
    assert lazy.get() == 5
    assert lazy.constructor_fn(None) == 5
    assert lazy.is_evaluated is False

    lazy_evaluated = lazy.get()
    assert lazy.is_evaluated is True
    assert lazy_evaluated == 5


# Generated at 2022-06-21 19:14:21.747594
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    def first_fn():
        return '123'

    def second_fn(first_fn_result):
        return Lazy(lambda: first_fn_result * 2)

    def third_fn(fold_result):
        return fold_result + '456'

    assert Lazy(first_fn).bind(second_fn).bind(lambda x: Lazy(lambda: x + '4')).get() == '12344'
    assert Lazy(first_fn).bind(second_fn).bind(lambda x: Lazy(lambda: x + '4')).bind(third_fn).get() == '123444456'

    Lazy(lambda: '123').bind(lambda x: Lazy(lambda: x + '234')).bind(lambda x: Lazy(lambda: x + '6')).get() == '1232346'
   

# Generated at 2022-06-21 19:14:29.407349
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_fn(first: Lazy[T, U], second: Lazy[U, W]) -> W:
        return second.bind(lambda _: first)
    
    first = Lazy(lambda *args: 'first')
    second = Lazy(lambda *args: 'second')

    assert test_fn(first, second).get() == first
    assert test_fn(first, second).get() == first
    assert test_fn(first, second).get() == first



# Generated at 2022-06-21 19:14:48.754438
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def my_function(*args):
        return 42

    assert Lazy.of(42).to_maybe(1) == Maybe.just(42)
    assert Lazy(my_function).to_maybe(1) == Maybe.just(42)

# Generated at 2022-06-21 19:14:51.448958
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda x: x)
    assert lazy.get(5) == 5
    assert lazy.get(4) == 5



# Generated at 2022-06-21 19:14:52.620951
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def comp():
        return 'foo'
    assert str(Lazy(comp).to_box()) == str(Box('foo'))


# Generated at 2022-06-21 19:14:57.966265
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from collections import namedtuple

    def function(value: Any) -> Any:
        return value

    assert str(Lazy(function)) == 'Lazy[fn=<function Lazy.test_Lazy___str__.<locals>.function at 0x7f1ca9d9e268>, value=None, is_evaluated=False]'
    assert str(Lazy(function).map(function)) == 'Lazy[fn=<function Lazy.test_Lazy___str__.<locals>.function at 0x7f1ca9d9e1e0>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:15:03.368251
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a):
        return Lazy(lambda b: a + b)

    def to_Lazy(a):
        return Lazy(lambda: a)

    result = Lazy(lambda: 5).map(to_Lazy).ap(add(5))
    assert result.get() == 10

    result = Lazy(lambda: 5).ap(add(5))
    assert result.get() == 10

    result = Lazy(lambda: 3).ap(add(2))
    assert result.get() == 5

# Generated at 2022-06-21 19:15:15.167434
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    """
    Unit test for method __str__ of class Lazy
    """
    assert (
        str(Lazy(lambda x: x).map(lambda x: x + 1))
        ==
        'Lazy[fn=<function Lazy.map.<locals>.<lambda> at 0x7fbbc85f53a0>, value=None, is_evaluated=False]'
    )
    assert (
        str(Lazy(lambda x: x).map(lambda x: x + 1).get(2))
        ==
        'Lazy[fn=<function Lazy.map.<locals>.<lambda> at 0x7fbbc85f53a0>, value=3, is_evaluated=True]'
    )



# Generated at 2022-06-21 19:15:25.073213
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)
    assert Lazy.of(2).to_box() == Box(2)
    assert Lazy.of(3).to_box() == Box(3)
    assert Lazy.of(1).map(lambda x: x + 1).to_box() == Box(2)
    assert Lazy.of(2).map(lambda x: x + 1).to_box() == Box(3)
    assert Lazy.of(3).map(lambda x: x + 1).to_box() == Box(4)



# Generated at 2022-06-21 19:15:30.873728
# Unit test for method get of class Lazy
def test_Lazy_get():
    """Test Lazy"""
    assert Lazy.of(1).get() == 1
    assert Lazy.of("New York").get() == "New York"
    assert Lazy.of([1, 2, 3]).get() == [1, 2, 3]
    assert Lazy.of((1, 2, 3)).get() == (1, 2, 3)

# Generated at 2022-06-21 19:15:33.963175
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(5).to_either() == Right(5)
    assert Lazy.of(-5).to_either() == Right(-5)


# Generated at 2022-06-21 19:15:35.939026
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)



# Generated at 2022-06-21 19:16:07.050230
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(5).get() == 5



# Generated at 2022-06-21 19:16:14.427539
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    def add2(a): return a + 2

    lazy = Lazy(add2).map(add2).map(add2)
    box = lazy.to_box(2)

    assert box == Box(10)
    assert isinstance(box, Box)
    assert isinstance(box, Functor)



# Generated at 2022-06-21 19:16:20.232892
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    def no_args_function() -> int:
        return 10

    def one_arg_function(arg: int) -> int:
        return arg * 2

    def complex_function(arg1: int, arg2: str) -> str:
        return "%s %s" % (arg1 * 2, arg2 * 2)

    assert Lazy(no_args_function).to_box() == Box(10)
    assert Lazy(one_arg_function).to_box(2) == Box(4)
    assert Lazy(complex_function).to_box(2, "test") == Box("4 testtest")


# Generated at 2022-06-21 19:16:24.540664
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    """Unit test for method map of class Lazy."""
    assert Lazy(lambda *args: 0).map(lambda x: x + 1).get() == Lazy(lambda *args: 1).get()

# Generated at 2022-06-21 19:16:33.279257
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    lazy = Lazy[int, int](lambda x: x * 2)
    # Lazy[fn=function, value=2, is_evaluated=True] is expected
    assert str(lazy) == 'Lazy[fn=<function Lazy.<lambda> at 0x1054d3b70>, value=None, is_evaluated=False]'
    # None is expected
    assert lazy.value is None
    # True is expected
    assert lazy.is_evaluated is False
    # Lazy[fn=function, value=2, is_evaluated=True] is expected
    assert lazy.get(2) is 4
    # None is expected
    assert lazy.value is 4
    # True is expected
    assert lazy.is_evaluated is True

# Generated at 2022-06-21 19:16:39.298094
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.either import Left

    # given
    l = Lazy(lambda x: x)

    # when
    result = l.to_validation(5)

    # then
    assert result == Validation.success(5)

    # when
    result = l.to_validation('')

    # then
    assert result == Validation.success('')

    # when
    result = l.to_validation(None)

    # then
    assert result == Validation.success(None)

    # when
    result = l.to_validation(Left('error'))

    # then
    assert result == Validation.success(Left('error'))

    # when
    l = Lazy(lambda x: int(x))

    # when
   

# Generated at 2022-06-21 19:16:44.395669
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad import Maybe

    def function_to_call(x):
        return Maybe.just(x)

    lazy = Lazy(function_to_call)
    lazy_result = lazy.bind(lambda x: Maybe.just(x))

    assert Maybe.just(Maybe.just(4)) == lazy_result.to_maybe(4)

# Generated at 2022-06-21 19:16:47.833860
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    lazy = Lazy(lambda: 'test')
    result = lazy.to_either()

    assert isinstance(result, Right)
    assert result.value == 'test'



# Generated at 2022-06-21 19:16:49.098999
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    assert Lazy(lambda: 10).to_try() == Try.of(lambda: 10)

# Generated at 2022-06-21 19:16:56.898866
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.composites import Composite

    def plus(a, b):
        return a + b

    lazy_plus = Lazy(plus)
    lazy_double = lazy_plus.map(lambda a: a * 2)
    lazy_sum = Lazy.of(0)
    # Execute functions only in fold
    lazy_composite = lazy_sum.bind(lambda a: lazy_double.bind(lambda b: Lazy.of(Composite(a, b))))
    assert lazy_composite.fold(lambda: lazy_sum.get(1, 1), lambda a: lazy_double.get(a), lambda c: c.get()) == Composite(0, 2)

    composite_with_decorator = Composite.of(0).ap_l(lazy_double).ap_