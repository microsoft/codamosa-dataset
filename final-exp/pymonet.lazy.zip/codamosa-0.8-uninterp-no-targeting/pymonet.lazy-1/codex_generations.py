

# Generated at 2022-06-21 19:07:40.369607
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    x = Lazy.of(5)
    assert x.to_try() == Try.of(lambda: 5)

    def f(x):
        return x + 1

    y = x.map(f)
    assert y.to_try() == Try.of(lambda: 6)

    def f(x):
        return str(x)

    z = y.map(f)
    assert z.to_try() == Try.of(lambda: '6')

# Generated at 2022-06-21 19:07:46.434970
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.box import Box

    result = Lazy.of(42).get()
    assert result == 42

    result = Lazy.of(42).fold(lambda value: Box(value))
    assert result == Box(42)

    result = Lazy.of(42).fold(lambda value: Box(value + 1))
    assert result == Box(43)



# Generated at 2022-06-21 19:07:50.441368
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    fn = lambda: 1
    lazy = Lazy(fn)

    assert str(lazy) == "Lazy[fn=<function Lazy.<locals>.<lambda> at 0x0000020D8C70E268>, value=None, is_evaluated=False]"


# Generated at 2022-06-21 19:07:55.334820
# Unit test for method __str__ of class Lazy
def test_Lazy___str__(): # pragma: no cover
    lazy = Lazy(lambda: 2)
    assert str(lazy) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f46d8e9f048>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:07:59.188769
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def some_function(value: int) -> int:
        return value + 1

    some_lazy = Lazy(lambda x: x + 1).bind(some_function)

    assert some_lazy.get(5) == 7

# Generated at 2022-06-21 19:08:03.169182
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def add(a):
        return a + 2

    assert str(Lazy(add)) == 'Lazy[fn=<function add at {memory_address}>, value=None, is_evaluated=False]'.format(
        memory_address=hex(id(add))
    )



# Generated at 2022-06-21 19:08:12.034343
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def mapper(value: int, increment: int) -> int:
        return value + increment

    fn = lambda x: x + 2
    lazy = Lazy(fn)
    maybe = lazy.map(mapper).to_maybe(2)

    assert isinstance(maybe, Maybe)
    assert maybe == Maybe.just(6)


# Generated at 2022-06-21 19:08:14.573579
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 'foo')) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x10f738048>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:08:17.434613
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy.of(1)

    assert lazy.get() == 1



# Generated at 2022-06-21 19:08:22.801007
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy(lambda x: 1 / x).to_try(2) == Try.success(0.5)
    assert Lazy(lambda x: 1 / x).to_try(0) == Try.failure(ZeroDivisionError())
    assert Lazy(lambda x: 1 / x)(2) == 0.5
    assert Lazy(lambda x: 1 / x)(0) == ZeroDivisionError()



# Generated at 2022-06-21 19:08:28.883350
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def get_user(user_id: int) -> Lazy[int, str]:
        return Lazy(lambda user_id: 'user')

    assert get_user(0).to_box(0) == Box('user')


# Generated at 2022-06-21 19:08:32.107279
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_value(x):
        return x

    assert Lazy(test_value).get(1) == 1
    assert Lazy.of(1).get() == 1

# Generated at 2022-06-21 19:08:34.082442
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def fn():
        return 2

    assert Lazy(fn).to_box()._value == 2



# Generated at 2022-06-21 19:08:41.028498
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    def get_int_safely(x):
        try:
            return int(x)
        except ValueError:
            return None

    def get_int_safely_with_exception(x):
        return Try(lambda: int(x))

    assert Lazy(get_int_safely).to_either('5') == Box(5)  # Lazy[A] -> Box[A]
    assert Lazy(get_int_safely).to_either('5') == Box(5)  # Lazy[A] -> Either[A]
    assert Lazy(get_int_safely_with_exception).to_either('5') == Box(5)  # Lazy[Try[A]] -> Either[A]


# Generated at 2022-06-21 19:08:42.955903
# Unit test for method get of class Lazy
def test_Lazy_get():
    def function():
        return 5

    assert Lazy.of(1).get() == 1
    assert Lazy(function).get() == 5



# Generated at 2022-06-21 19:08:47.302361
# Unit test for method to_try of class Lazy
def test_Lazy_to_try(): # pragma: no cover
    from pymonet.monad_try import Try

    def should_fail(*args):
        return 1 / 0

    def should_pass(*args):
        return 'success'

    assert Lazy.of(should_fail).to_try() == Try.of(should_fail)
    assert Lazy.of(should_pass).to_try() == Try.of(should_pass)



# Generated at 2022-06-21 19:08:52.107728
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.monotest import assert_str
    assert_str(Lazy(lambda: 1), "Lazy[fn=<function Lazy.<locals>.<lambda> at 0x", ">, value=None, is_evaluated=False]")



# Generated at 2022-06-21 19:09:04.113440
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(*args):
        return args

    lazy_none = Lazy.of(None)
    lazy_value = Lazy.of(5)

    assert lazy_none.map(lambda _: "new value") == Lazy.of("new value")
    assert lazy_value.map(lambda _: "new value") == Lazy.of("new value")

    assert lazy_value.map(Box) == Lazy(lambda args: Box(fn(*args)))
    assert lazy_value.map(Right) == Lazy(lambda args: Right(fn(*args)))

# Generated at 2022-06-21 19:09:09.225085
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def method_with_some_value(*args, **kwargs):
        return Maybe.just(2)

    lazy = Lazy(method_with_some_value)
    result = lazy.to_maybe()
    assert result == Maybe.just(method_with_some_value())



# Generated at 2022-06-21 19:09:11.199986
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(2).to_box() == Box(2)


# Generated at 2022-06-21 19:09:16.130243
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    m = Lazy(lambda x: x + 2).to_maybe(2)

    assert isinstance(m, Maybe)
    assert m == Just(4)



# Generated at 2022-06-21 19:09:24.101589
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def division(x, y):
        return x / y

    def division_with_zero(x, y):
        return division(x, y)

    success_try = Lazy(division_with_zero).to_try(1, 0)
    assert isinstance(success_try, Try)
    assert not success_try.is_success()
    assert success_try.is_failure()
    assert success_try.exception is ZeroDivisionError

# Generated at 2022-06-21 19:09:35.053933
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def lazy_fn(value):
        return Lazy(lambda: value)

    assert Lazy.of(1).bind(lazy_fn).get() == 1
    assert Lazy.of(42).to_box().bind(lazy_fn).get() == 42
    assert Lazy.of(1).to_either().bind(lazy_fn).get() == 1
    assert Lazy.of(42).to_maybe().bind(lazy_fn).get() == 42

# Generated at 2022-06-21 19:09:41.882014
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    import sys
    import traceback
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def divide(x: int, y: int):
        return x / y

    def divide_with_try(x: int, y: int):
        return Try.of(divide, x, y)

    def double_divide(x: int, y: int):
        return Validation.of(divide, x, y).map(lambda result: result * 2)

    def double_divide_with_try(x: int, y: int):
        return Try.of(double_divide, x, y)

    def divide_with_box(x: int, y: int):
        return

# Generated at 2022-06-21 19:09:44.275553
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    function = lambda value: value * 2
    lazy = Lazy(function)
    assert lazy.to_validation(2) == Validation.success(function(2))



# Generated at 2022-06-21 19:09:53.374973
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.box import Box

    def get_value(*args):
        return Box(args[0] * args[1])

    lazy1 = Lazy(get_value)
    assert lazy1.get(3, 5) == 15

    lazy2 = lazy1.map(lambda x: x + 7)
    assert lazy2.get(3, 5) == 22

    lazy3 = lazy2.bind(lambda x: Lazy(lambda a, b: x // a + b))
    assert lazy3.get(2, 3) == 9



# Generated at 2022-06-21 19:10:00.413389
# Unit test for constructor of class Lazy
def test_Lazy():
    assert str(Lazy(lambda x: x + 1)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f5cac295ae8>, value=None, is_evaluated=False]'
    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 2)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 1).get(1)


# Generated at 2022-06-21 19:10:09.157991
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    """
    Unit test for method to_try of class Lazy.
    """
    from pymonet.monad_try import Try

    def fn(val):
        return val

    assert Lazy(lambda: fn(True)).to_try() == Try.success(fn(True))
    assert Lazy(lambda: fn(True)).to_try(1, 2) == Try.success(fn(True))
    assert Lazy(lambda: fn(True)).to_try(a=1);
    assert Lazy(lambda: 1).to_try() == Try.success(1)
    assert Lazy(lambda: 1).to_try(1, 2) == Try.success(1)
    assert Lazy(lambda: 1).to_try(a=1);

# Generated at 2022-06-21 19:10:12.290213
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy(lambda: 1).to_either() == Right(1)


# Generated at 2022-06-21 19:10:19.219264
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    # given
    lazy = Lazy.of(True)

    # when
    actual_result = lazy.to_maybe()

    # then
    assert actual_result == Maybe.just(True)

    # given
    lazy = Lazy.of(None)

    # when
    actual_result = lazy.to_maybe()

    # then
    assert actual_result == Maybe.empty()


# Generated at 2022-06-21 19:10:23.156126
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 2).map(lambda x: x * 2).get() == 4


# Generated at 2022-06-21 19:10:29.609506
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    import pymonet.functions as F
    def add(num: int) -> int:
        return num + 1

    lazy_add_1 = Lazy(add)
    assert lazy_add_1 == eval(str(lazy_add_1))  # but not str(lazy_add_1) == str(eval
                                                # because Lazy define classmethod of
                                                # and call eval twice: Lazy.of(2) ==
                                                # Lazy(lambda : 2))
    assert str(lazy_add_1) == 'Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x7f0a2d6a4268>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:10:39.335315
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.monoid import MList
    from pymonet.validation import Validation

    assert Lazy.of(3).to_validation() == Validation.success(3)
    assert Lazy.of(None).to_validation() == Validation.success(None)
    assert Lazy.of([1, 2, 3]).to_validation() == Validation.success([1, 2, 3])
    assert Lazy.of(()).to_validation() == Validation.success(())
    assert Lazy.of(3).map(lambda i: i + 1).to_validation() == Validation.success(4)
    assert Lazy.of(3).map(lambda i: None).to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:10:44.109825
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    test_add = Lazy(lambda x: x)
    test_lazy = Lazy(lambda x: x + 1)
    assert test_add.ap(test_lazy) == Lazy(lambda x: x + 1).get(2)



# Generated at 2022-06-21 19:10:47.156805
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    lazy = Lazy.of(lambda: 2)
    assert lazy.to_box() == Box(2)



# Generated at 2022-06-21 19:10:51.355986
# Unit test for method get of class Lazy
def test_Lazy_get():
    from nose.tools import assert_equals
    from pymonet.monad_try import Try

    lazy = Lazy(lambda n: n + 1)
    assert_equals(2, lazy.get(1))
    assert_equals(1, lazy.value)
    assert_equals(True, lazy.is_evaluated)



# Generated at 2022-06-21 19:10:58.112572
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn() -> int:
        return 1

    def mapper(i: int) -> float:
        return i / 2

    def mapper_2(i: int) -> Lazy[int, float]:
        return Lazy.of(i / 2)

    lazy = Lazy(fn)
    assert Maybe.just(1).equals(lazy.to_maybe())
    assert Maybe.just(1/2).equals(lazy.map(mapper).to_maybe())

# Generated at 2022-06-21 19:11:01.561948
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def f(x): return x * 2

    lazy_result = Lazy(lambda: 2).map(f)

    assert lazy_result == Lazy(lambda: 4)



# Generated at 2022-06-21 19:11:06.880012
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    def lambda_fn():
        return Maybe.just(1).to_either()

    lazy = Lazy(lambda_fn)
    assert lazy.to_either() == Right(Right(1))


# Generated at 2022-06-21 19:11:14.751767
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    try_ = Lazy(int).to_try(1)
    assert try_ == Try.of(int, 1)

    try_ = Lazy(int).to_try('foo')
    assert isinstance(try_, Try)
    assert isinstance(try_.get_value(), ValueError)

    validation_lazy_to_try_int_with_args = Lazy(lambda x: x + 1).to_try('foo', 1)
    assert isinstance(validation_lazy_to_try_int_with_args, Try)
    assert isinstance(validation_lazy_to_try_int_with_args.get_value(), ValueError)

    validation_lazy_to_try_int_with_

# Generated at 2022-06-21 19:11:23.280216
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    lazy = Lazy(lambda x: x)

    assert lazy.to_validation(1).is_success()
    assert lazy.to_validation(1).get() == 1


# Generated at 2022-06-21 19:11:29.481316
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Given
    def g(x):
        return x.upper()

    def f(x):
        return x.lower()

    # When
    lazy = Lazy(f)
    other_lazy = Lazy(g)
    new_lazy = lazy.ap(other_lazy)

    # Then
    expected_lazy = Lazy(lambda: 'abc')
    assert new_lazy == expected_lazy



# Generated at 2022-06-21 19:11:37.423161
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left

    assert Lazy.of(2) == Lazy.of(2)
    assert str(Lazy.of(2)) == 'Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x10cbf2f28>, value=2, is_evaluated=False]'
    assert Lazy.of(2).to_either() == Right(2)
    assert Lazy.of(2).to_box() == Box(2)
    assert Lazy.of(2).to_maybe() == Maybe.just(2)
    assert Lazy.of(2).to_try() == Try.of(lambda: 2)
    assert Lazy.of(2).to_validation() == Validation.success(2)

# Generated at 2022-06-21 19:11:42.432863
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(2).get() == 2
    assert Lazy.of(2).map(lambda x: x * x).get() == 4
    assert Lazy.of(2).map(lambda x: x * x).map(lambda x: x * x).get() == 16



# Generated at 2022-06-21 19:11:53.788516
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
	assert Lazy(lambda: 1) == Lazy(lambda: 1)
	assert Lazy(lambda: 1) == Lazy(lambda a: 1)
	assert Lazy(lambda: 1) != Lazy(lambda: 2)
	assert Lazy(lambda x: x) != Lazy(lambda a: a)
	assert Lazy(lambda: 1) != Lazy(lambda a: a)
	assert Lazy(lambda x: x) != Lazy(lambda: 1)
	assert Lazy(lambda x, y: x + y) == Lazy(lambda x, y: x + y)
	assert Lazy(lambda x, y: x + y) != Lazy(lambda x, y: x - y)

# Generated at 2022-06-21 19:11:59.108995
# Unit test for constructor of class Lazy
def test_Lazy():
    def fn_1(arg_1):
        return arg_1

    lazy_1 = Lazy(fn_1)

    assert lazy_1.is_evaluated is False
    assert lazy_1.value is None
    assert lazy_1.constructor_fn(5) == 5



# Generated at 2022-06-21 19:12:04.074609
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.functions import identity

    lazy = Lazy(identity)

    assert str(lazy) == 'Lazy[fn=<function identity at 0x7fbf2b2a42f0>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:12:07.832561
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """
    Test of method to_either of class Lazy
    """
    def func(a, b):  # pylint: disable=unused-argument
        return 'test'

    lazy = Lazy(func)
    assert lazy.to_either(2, 3) == Right('test')

# Generated at 2022-06-21 19:12:18.803985
# Unit test for constructor of class Lazy
def test_Lazy():
    def add(x: int, y: int) -> int:
        return x + y

    # Lazy.of
    assert Lazy.of(10) == Lazy(lambda: 10)

    # Lazy.map
    assert Lazy.of(10).map(lambda x: x * x) == Lazy(lambda: 10 * 10)
    assert Lazy.of(10).map(lambda x: x * x).map(lambda x: x / 100) == Lazy(lambda: (10 * 10) / 100)

    # Lazy.bind
    assert Lazy.of(10).bind(lambda x: Lazy.of(x * x)) == Lazy.of(10 * 10)

# Generated at 2022-06-21 19:12:22.025998
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def test_function():
        return "Hello world"
    test_value = Lazy(test_function)
    assert str(test_value) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(test_function, None, False)



# Generated at 2022-06-21 19:12:33.898820
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert Lazy(lambda: "Unit test") == Lazy(lambda: "Unit test")



# Generated at 2022-06-21 19:12:38.314138
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2

    assert Lazy(lambda x: x * 2).map(lambda x: x + 1).get(3) == 7



# Generated at 2022-06-21 19:12:42.241769
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy(lambda: 0).get() == 0
    assert Lazy(lambda: "test").get() == "test"
    assert Lazy(lambda: "test").map(lambda t: t + "2").get() == "test2"



# Generated at 2022-06-21 19:12:48.721314
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert (
        Lazy
        .of(1)
        .to_validation()
        ==
        Validation.success(1)
    )

    assert (
        Lazy
        .of(1)
        .to_validation(1, 2)
        ==
        Validation.success(1)
    )


# Generated at 2022-06-21 19:12:59.431864
# Unit test for constructor of class Lazy
def test_Lazy():
    def make_lazy() -> Lazy[int, int]:
        return Lazy(lambda x: x + 1)

    assert make_lazy() == Lazy(lambda x: x + 1)
    assert make_lazy() != Lazy(lambda x: x + 2)
    assert make_lazy() == Lazy(lambda y: y + 1)
    assert make_lazy() != Lazy(lambda y: y + 2)
    assert make_lazy().is_evaluated == False
    assert make_lazy().get(1) == 2
    assert make_lazy().is_evaluated == True
    assert make_lazy().value == 2
    assert make_lazy().get(1) == 2
    assert make_lazy().value == 2


# Generated at 2022-06-21 19:13:05.429170
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def to_int(x):
        return int(x)

    assert Lazy.of('1').to_maybe().is_just()
    assert Lazy.of(1.1).to_maybe().is_just()
    assert Lazy.of(1).to_maybe().is_just()
    assert Lazy.of('').to_maybe().is_nothing()
    assert Lazy.of(to_int).to_maybe().value()(1) == 1
    assert Lazy.of(to_int).to_maybe().value()('1') == 1
    assert Lazy.of(to_int).to_maybe().value()('1a') == Maybe.nothing()


# Generated at 2022-06-21 19:13:12.815577
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def fn(a):
        raise TypeError("Test error")

    assert Lazy(fn).to_try() == Lazy(fn).to_try(1)
    assert Lazy(fn).to_try() == Lazy(fn).to_try(1, 2)
    assert Lazy(fn).to_try() == Lazy(fn).to_try(1, 2, 3)
    assert Lazy(fn).to_try() == Lazy(fn).to_try(1, 2, 3, 4)


# Generated at 2022-06-21 19:13:16.735964
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    def add(x):
        return x + 2

    def div(x):
        return x / 2

    def add_three(x):
        return x + 3

    lazy_result = Lazy(add).ap(Lazy(div)).bind(lambda x: Lazy(add_three)(x))
    assert lazy_result.to_validation() == Validation.success(4)

# Generated at 2022-06-21 19:13:18.992569
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def lf():
        pass

    assert Lazy(lf) == Lazy(lf)



# Generated at 2022-06-21 19:13:20.997127
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy.of('value').to_validation() == Validation.success('value')


Lazy.to_validation.__test__ = False

# Generated at 2022-06-21 19:13:44.236018
# Unit test for method map of class Lazy
def test_Lazy_map():
    def func(x: int) -> int:
        return x + 1

    lazy = Lazy(func)

    def mapper(x: int) -> int:
        return 2 * x

    mapped = lazy.map(mapper)

    assert mapped == Lazy(lambda *args: mapper(func(*args)))



# Generated at 2022-06-21 19:13:46.843224
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(123).map(lambda x: x + 2) == Lazy(lambda *args: 125)


# Generated at 2022-06-21 19:13:51.820870
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    # given
    value = 5
    lazy = Lazy(lambda: value)

    # when
    actual = lazy.to_validation()

    # then
    assert actual == Validation.success(value)

# Generated at 2022-06-21 19:14:01.616296
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.monad import Maybe

    def sqrt_or_error(value):
        try:
            return Right(value ** 0.5)
        except ValueError:
            return Maybe.nothing()

    value = 1

    try_result = Lazy.of(value).to_try()
    assert try_result == Lazy.of(value ** 0.5).to_try()
    assert try_result == Lazy.of(value).to_try()
    assert try_result.fold(lambda v: v ** 2) == Lazy.of(value).get()

    try_result = Lazy.of(value).to_try()
    assert try_result != sqrt_or_error(value)
    assert try_result != Lazy.of

# Generated at 2022-06-21 19:14:08.620193
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_validation import Validation
    from pymonet.monad_box import Box
    from pymonet.monad_try import Try
    from pymonet.monad_either import Right
    from pymonet.monad_maybe import Maybe

    def double(i):
        return i * 2

    double_lazy = Lazy(double)
    double_validation_lazy = Validation.success(Lazy(double))
    double_box_lazy = Box(Lazy(double))
    double_try_lazy = Try.of(double)
    double_lazy_right = Right(Lazy(double))
    double_lazy_maybe = Maybe.just(Lazy(double))


# Generated at 2022-06-21 19:14:14.422210
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert(Right(1) == Lazy.of(1).to_either())
    assert(Right(2) == Lazy.of(lambda: 1 + 1).to_either())
    assert(Right(2) == Lazy.of(lambda x: x + 1).to_either(1))

# Generated at 2022-06-21 19:14:19.985867
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    # Given
    def successful_function(*args):
        return 3

    lazy_value = Lazy.of(successful_function)

    # When
    lazy_maybe = lazy_value.to_maybe()

    # Then
    assert isinstance(lazy_maybe, Maybe)
    assert lazy_maybe.get() == 3

# Generated at 2022-06-21 19:14:22.034812
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(5).to_box() == Box(5)



# Generated at 2022-06-21 19:14:27.061464
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def fn(*args):
        pass

    assert str(Lazy(fn)) == 'Lazy[fn=<function Lazy.test_Lazy___str__.<locals>.fn at 0x7f7a0caf68c0>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:14:29.901783
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    """
    >>> Lazy(lambda : "a").to_box()
    Box(a)
    """


# Generated at 2022-06-21 19:15:12.437309
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy(lambda: 2).to_either() == Right(2)

# Generated at 2022-06-21 19:15:18.598375
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def identity_fn(x):
        return x

    lazy_2 = Lazy.of(2)

    assert lazy_2.get() == lazy_2.get()
    assert lazy_2 != Lazy.of(4)
    assert lazy_2 != Lazy(identity_fn)
    assert Lazy(identity_fn) != Lazy(identity_fn)
    assert Lazy(identity_fn) == Lazy(identity_fn)
    assert Lazy(lambda v: v).map(identity_fn) != Lazy(lambda v: v)



# Generated at 2022-06-21 19:15:24.656274
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Test for method to_try of class Lazy
    """
    def constructor(*args):
        if args == 'fail':
            raise ValueError()
        return 42

    lazy = Lazy(constructor)
    assert lazy.to_try() == Try.success(42)
    assert lazy.to_try('fail') == Try.failure(ValueError)

# Generated at 2022-06-21 19:15:27.218601
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    right = Lazy(lambda x: x)
    right2 = Lazy(lambda x: x)
    assert right.__eq__(right2)



# Generated at 2022-06-21 19:15:31.576374
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def function():
        return 'hello'

    lazy_hello = Lazy(function)
    maybe_hello = lazy_hello.to_maybe()

    assert maybe_hello.is_just()
    assert maybe_hello.unbox() == 'hello'

# Generated at 2022-06-21 19:15:34.550918
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    lazy = Lazy(lambda x: 3)
    assert lazy.to_either() == Right(3)



# Generated at 2022-06-21 19:15:37.271404
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda a: None)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x10a8b76a8>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:15:41.264103
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert isinstance(Lazy.of(2).to_validation(), Validation)
    assert isinstance(Lazy.of(2).to_validation(), Success)
    assert Lazy.of(2).to_validation().get() == 2

# Generated at 2022-06-21 19:15:42.752812
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(1).to_either() == Right(1)

# Generated at 2022-06-21 19:15:45.417417
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    param = 1
    expected = 2
    actual = Lazy.of(param).bind(lambda x: Lazy.of(x + 1)).get()

    assert expected == actual



# Generated at 2022-06-21 19:16:28.012814
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    # GIVEN
    # Define Lazy with return value
    lazy = Lazy.of('test')

    # WHEN
    # Transform Lazy into Maybe
    maybe = lazy.to_maybe()

    # THEN
    # Lazy was transformed into Maybe with values
    assert maybe == Maybe.just('test')



# Generated at 2022-06-21 19:16:36.221873
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.monad_try import Try as T

    def f(x):
        return x + 1

    def g(x):
        return x * 2

    def h(x):
        return x / 2

    def div(x, y):
        return x // y

    def to_int(x):
        return int(x)

    assert Lazy(lambda: f(1)).get() == Lazy.of(f(1)).get()
    assert Lazy(lambda: 2 * 3).get() == Lazy.of(2 * 3).get()

    assert Lazy(lambda: f(1)).map(g).map(h).get() == T.of(div(f(g(h(1))), 2)).get()

# Generated at 2022-06-21 19:16:40.578718
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: Box(1))
    assert lazy.to_box() == Box(1)

    lazy = Lazy.of(2)
    assert lazy.to_box() == Box(2)


# Generated at 2022-06-21 19:16:47.554002
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def may_raise(*args):
        from copy import copy

        if copy(args) == [2, 3]:
            raise Exception('Error')

        return args[0] * args[1]

    assert Lazy(may_raise).to_try(1, 2) == Try.of(may_raise, 1, 2)
    assert Lazy(may_raise).to_try(2, 3) == Try.of_error(Exception('Error'))



# Generated at 2022-06-21 19:16:50.830233
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda n: n + 1).get() == 2
    assert Lazy.of(3).map(lambda n: n + 1).get() == 4


# Generated at 2022-06-21 19:16:53.386683
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda *_: None)) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:16:55.638061
# Unit test for method get of class Lazy
def test_Lazy_get():
    def function(x):
        return x ** 2

    lazy = Lazy(function)

    assert lazy.get(2) == 4

# Generated at 2022-06-21 19:17:02.598459
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of('foo').to_box() == 'foo'
    assert Lazy.of([1, 2, 3]).to_box() == [1, 2, 3]
    assert Lazy.of({'foo': 'bar'}).to_box() == {'foo': 'bar'}
    assert Lazy.of(1).to_box() == 1
    assert Lazy.of(True).to_box() == True
    assert Lazy.of(1.2).to_box() == 1.2
    assert Lazy.of(None).to_box() is None


# Generated at 2022-06-21 19:17:06.250189
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert 'Lazy[fn=<function Lazy.<locals>.lambda_fn at 0x7f3e95b30e18>, value=1, is_evaluated=True]' == str(Lazy(lambda: 1).fold())



# Generated at 2022-06-21 19:17:11.053635
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.box import Box

    result_box = Lazy(lambda value: value + 3).to_box(23)
    result = Lazy(lambda value: value + 3).get(23)

    assert result_box == Box(26)
    assert result == 26

    result_box = Lazy.of(23).to_box()
    result = Lazy.of(23).get()

    assert result_box == Box(23)
    assert result == 23

