

# Generated at 2022-06-21 19:07:29.785754
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Failure
    from pymonet.monad_try import Success

    def div(argument):
        if (argument == 0):
            raise ValueError('division by zero')
        return 1 / argument

    def is_even(argument):
        return argument % 2 == 0

    def get_three(argument):
        return 3

    assert Lazy(div).to_try(0) == Failure(ValueError('division by zero'))
    assert Lazy(div).to_try(2) == Success(0.5)
    assert Lazy(div).map(is_even).to_try(2) == Success(True)
    assert Lazy(div).bind(lambda x: Lazy(get_three)).to_try(2) == Success(3)

# Generated at 2022-06-21 19:07:34.067973
# Unit test for method get of class Lazy
def test_Lazy_get():
    def f():
        return "Lazy"

    def f1(a):
        return a

    value = Lazy(f)
    value2 = Lazy(f1)

    assert f() == value.get()
    assert f1("Lazy") == value2.get("Lazy")



# Generated at 2022-06-21 19:07:43.345112
# Unit test for constructor of class Lazy
def test_Lazy(): # pragma: no cover
    def plus(a, b):
        return a + b

    lazy = Lazy.of(plus)
    assert isinstance(lazy, Lazy)
    assert callable(lazy.constructor_fn)
    assert lazy.constructor_fn() == plus
    assert lazy == lazy
    assert lazy != lazy.map(lambda x: x)
    assert lazy != lazy.map(lambda x: x).map(lambda x: x)
    assert lazy != lazy.map(lambda x: x)._compute_value()
    assert lazy != lazy._compute_value()


# Generated at 2022-06-21 19:07:50.488086
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    def fn():
        return 345

    assert Lazy(fn).to_either() == Left(fn)

    assert Lazy(lambda x: 123).to_either(1) == Right(123)

    assert Lazy(Maybe.just(123)).to_either() == Right(123)

    assert Lazy(Maybe.nothing()).to_either() == Left(Maybe.nothing)



# Generated at 2022-06-21 19:07:53.671080
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation
    from pymonet.box import Box

    value = 'hello world'

    def fn(v):
        return v

    lazy = Lazy.of(value).box(Box)

    assert isinstance(lazy.to_validation(), Validation)
    assert lazy.to_validation().is_success()
    assert lazy.to_validation().value == value

    assert Lazy(fn).to_validation().is_success()

# Generated at 2022-06-21 19:07:57.573672
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def a1():
        return 1

    def b1():
        return 2

    def c1():
        return 2

    assert Lazy(a1) == Lazy(a1)
    assert not Lazy(a1) == Lazy(b1)
    assert Lazy(c1) == Lazy(b1)
    assert Lazy(c1) == Lazy(c1)



# Generated at 2022-06-21 19:08:00.516111
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of(4).to_maybe() == Maybe.just(4)



# Generated at 2022-06-21 19:08:08.249581
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    def fn(x):
        return x + 5

    assert Lazy.of(fn).ap(Lazy.of(5)).get() == fn(5)
    assert Lazy.of(fn).ap(Lazy.of(7)).get() == fn(7)
    assert Lazy.of(fn).ap(Lazy.of(5)).get() == 10

    assert Lazy.of(fn).ap(Lazy.of(5)).to_validation().get_value() == fn(5)
    assert Lazy.of(fn).ap(Lazy.of(7)).to_validation().get_value() == fn(7)

# Generated at 2022-06-21 19:08:11.792544
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(1).to_either() == Right(1)



# Generated at 2022-06-21 19:08:17.151493
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Either

    assert Lazy(lambda: Either.right(1)).to_either() == Either.right(1)
    assert Lazy(lambda: Either.success(1)).to_either() == Either.right(1)
    assert Lazy(lambda: Either.left(1)).to_either() == Either.left(1)
    assert Lazy(lambda: Either.failure(1)).to_either() == Either.left(1)


# Generated at 2022-06-21 19:08:23.733964
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.monad_maybe import Maybe

    dec_to_hex = Lazy(lambda x: hex(int(x))[2:])
    hex_to_bin = Lazy(lambda x: bin(int(x, 16))[2:])

    assert dec_to_hex.map(hex_to_bin).get('10') == Maybe.just(bin(16)[2:])

# Generated at 2022-06-21 19:08:27.171770
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.identity import Identity

    assert Lazy(lambda x: x * 2).ap(Identity(lambda x: x * 3)).get(3) == 18



# Generated at 2022-06-21 19:08:32.030417
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    lazy = Lazy(lambda: 1)
    assert str(lazy) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(
        lazy.constructor_fn, lazy.value, lazy.is_evaluated
    )


# Generated at 2022-06-21 19:08:34.715476
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    def f(x):
        return x + 1

    assert Right(5) == Lazy(f).to_either(4)


# Generated at 2022-06-21 19:08:44.867337
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(5).get(1, 2, 3) == 5
    assert Lazy.of(False).get(1, 2, 3) is False
    assert Lazy.of(None).get(1, 2, 3) is None
    assert Lazy.of(lambda x, y: x + y).bind(lambda x: Lazy.of(lambda z: x(1, z))).get(2) == 3
    assert Lazy.of(lambda x, y: x + y).map(lambda x: x(1, 2)).get() == 3
    assert Lazy.of(lambda x, y: x + y).ap(Lazy.of(1)).get(2) == 3

# Generated at 2022-06-21 19:08:49.295064
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy.of(10)) == 'Lazy[fn=<function Lazy._lambda_fn.<locals>.<lambda> at 0x000001E3E3FFEEA0>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:08:53.224056
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from collections.abc import Callable
    assert callable(Lazy[Callable, Callable].to_maybe)
    assert Lazy[Callable, Callable].to_maybe == Lazy[Callable, Callable].to_box.to_maybe

# Generated at 2022-06-21 19:08:57.757908
# Unit test for method map of class Lazy
def test_Lazy_map():
    def f1(a):
        return a * a

    def f2(a):
        return -a

    lazy = Lazy(f1)
    assert lazy.map(f2).get(5) == -25

# Generated at 2022-06-21 19:09:03.681728
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    """
    Test for method bind of Lazy class
    :returns: None
    """
    from pymonet.box import Box

    def fn(arg):
        return Box(arg * 2)

    lazy = Lazy((lambda x: x * 2))
    lazy_bound = lazy.bind(fn)

    assert lazy_bound.get(5) == Box(20)



# Generated at 2022-06-21 19:09:10.701130
# Unit test for method get of class Lazy
def test_Lazy_get():
    def run_tests(tests):
        for lzy in tests:
            result = lzy.get()
            assert result == 3

    tests = [
        Lazy(lambda: 3),
        Lazy.of(3)
    ]
    run_tests(tests)
    tests = [
        Lazy(lambda: 3).map(lambda v: v * 2),
        Lazy.of(3).map(lambda v: v * 2)
    ]
    run_tests(tests)



# Generated at 2022-06-21 19:09:19.028958
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """
    Test transforming Lazy into Either.
    """
    from pymonet.either import Left

    def test_to_either(x):
        return Lazy(lambda: str(x)).to_either()

    assert test_to_either(1) == Right('1')
    assert test_to_either(Left('Error')) == Right(Left('Error'))


# Generated at 2022-06-21 19:09:22.627535
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    d = Lazy(lambda x: x*2)
    d2 = Lazy(lambda x: x*2)
    d3 = Lazy(lambda x: x*3)

    assert d == d2
    assert d != d3

# Generated at 2022-06-21 19:09:24.264601
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(1).to_box() == Box(1)



# Generated at 2022-06-21 19:09:26.779401
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)

# Generated at 2022-06-21 19:09:35.100096
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def double(x):
        return x * 2

    def add(x, y):
        return x + y

    Lazy1 = Lazy(lambda x: double(x))
    Lazy1._compute_value(5)
    Lazy2 = Lazy(lambda x: double(x))
    Lazy2._compute_value(5)
    Lazy3 = Lazy(lambda x, y: add(x, y))
    Lazy3._compute_value(5, 5)

    assert Lazy1 == Lazy2
    assert Lazy1 != Lazy3



# Generated at 2022-06-21 19:09:36.696870
# Unit test for method get of class Lazy
def test_Lazy_get():
    result = Lazy.of(2).get()

    assert result == 2



# Generated at 2022-06-21 19:09:44.544305
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Maybe(1)._compute_value() == 1
    assert Maybe(1).get() == 1
    assert Maybe(None)._compute_value() is None
    assert Maybe(None).get() is None
    assert Maybe(lambda: 1).get() == 1
    assert Maybe(lambda: None).get() is None
    assert Maybe(lambda: 1 + 1).get() == 2
    assert Maybe(lambda: 1 + None).get() is None



# Generated at 2022-06-21 19:09:56.120838
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.functor import Functor
    from pymonet.monad_writer import MonadWriter
    from pymonet.monad_state import MonadState

    def calc(x: int) -> int:
        return (x ** 2) * 2 + 1

    def calc_with_applicative(x: int) -> Lazy[int, int]:
        def fn(f: Callable[[int], int]):
            return f(x)

        return Lazy(fn).ap(Lazy(calc))

    # Monadic composition of Lazy
    # Lazy[x -> y] -> Lazy[y -> z] -> Lazy[x -> z]
    # lazy_x_y.bind(x -> lazy_y_z.bind(y -> Lazy.of(f(x, y))))

# Generated at 2022-06-21 19:10:00.105328
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    """Test for __str__ in class Lazy."""
    def test_fn():
        return 'test'

    assert str(Lazy(test_fn)) == 'Lazy[fn=<function test_fn at 0x%x>, value=None, is_evaluated=False]' % id(test_fn)


# Generated at 2022-06-21 19:10:02.266707
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(2).map(lambda current:  current + 2).get() == 4



# Generated at 2022-06-21 19:10:08.836986
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.monad_maybe import Maybe

    l = Lazy.of(Maybe(2))
    assert Lazy.of(1) == Lazy.of(1)
    assert l.map(lambda x: x+1) != l.map(lambda x: x)
    assert l.ap(l) == l
    assert l.bind(lambda x: Lazy.of(x)) == l


# Generated at 2022-06-21 19:10:12.228124
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy(str).to_validation(1).get == "1"



# Generated at 2022-06-21 19:10:22.064489
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) == Lazy.of(lambda: 1)
    assert not Lazy.of(1) == Lazy.of(2)
    assert not Lazy.of(1) == Lazy.of(lambda: 2)

    def fn(a):
        def generator(x):
            for i in range(0, x):
                yield i
        return list(generator(a))

    assert Lazy(fn) == Lazy(fn)
    assert not Lazy(fn) == Lazy(lambda: fn)
    assert not Lazy(fn) == Lazy(lambda x: fn(x))



# Generated at 2022-06-21 19:10:25.449350
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 2).get() == 2
    assert Lazy(lambda: 3).get() == 3
    assert Lazy(lambda: 4).get() == 4
    assert Lazy(lambda: 5).get() == 5


# Generated at 2022-06-21 19:10:36.929144
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from functools import partial

    def mapper(value):
        return value * 2

    def mapper_returning_lazy(value):
        from pymonet.box import Box

        return Lazy.of(Box(value * 2))

    def mapper_returning_box(value):
        from pymonet.box import Box

        return Box(value * 2)

    assert Lazy.of(1).ap(Lazy.of(mapper)) == Lazy.of(mapper_returning_lazy)

    assert Lazy.of(1).ap(Lazy.of(mapper_returning_box)) == Lazy.of(1).map(mapper_returning_box).to_box()


# Generated at 2022-06-21 19:10:48.973688
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    box = Box(1)
    lazy = Lazy.of('hello').map(lambda x: x + ' world!')
    assert lazy.get() == 'hello world!'
    assert lazy.map(len).get() == 12

    lazy = lazy.ap(Lazy.of(lambda x: x[0:5]))
    assert lazy.get() == 'hello'

    lazy = Lazy.of(Try.of(lambda: box.get()))
    resolved_value = lazy.bind(lambda x: Try.of(lambda: len(x)))
    assert resolved_value.get() == 1


# Generated at 2022-06-21 19:10:59.545434
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test for method get of class Lazy.

    we only test method get of Lazy because constructor, bind, map and ap methods works only with get method
    """
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(2, 3) == 1

    def fn(x, y):
        return x + y
    lazy_fn = Lazy(fn)

    assert lazy_fn.get(1, 2) == 3
    assert lazy_fn.get(1) == 1
    assert lazy_fn.get(2, 3) == 5
    assert lazy_fn.get(1, 2) == 3

    def fn_raise_error(x, y):
        raise ValueError


# Generated at 2022-06-21 19:11:05.079013
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(None).to_box() == Lazy.of(None).to_box()
    assert Lazy.of(1).to_box() == Lazy.of(1).to_box()
    assert Lazy.of(1).to_box() != Lazy.of(2).to_box()

# Generated at 2022-06-21 19:11:13.689899
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(5) == Lazy.of(5)
    assert Lazy.of(5) != Lazy.of(6)
    assert Lazy.of(5) != Lazy.of(5.0)
    assert Lazy.of(5.0) == Lazy.of(5.0)
    assert Lazy(lambda: 5) == Lazy(lambda: 5)
    assert Lazy(lambda: 5) != Lazy.of(5)
    assert Lazy.of(lambda: 5) != Lazy.of(lambda: 5)

    lazy = Lazy.of(5)
    lazy._compute_value()
    assert lazy == Lazy.of(5)



# Generated at 2022-06-21 19:11:22.255487
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add_one(val: int) -> int:
        return val + 1

    lazy = Lazy.of(add_one).ap(Lazy.of(1))
    assert lazy.get() == 2

    lazy = Lazy.of(add_one).ap(Lazy.of(None))
    assert lazy.get() is None

    lazy = Lazy.of(add_one).ap(Lazy.of([]))
    assert lazy.get() == []

    lazy = Lazy.of(add_one).ap(Lazy.of(''))
    assert lazy.get() == ''

    lazy = Lazy.of(add_one).ap(Lazy.of(1.1))
    assert lazy.get() == 1.1

# Generated at 2022-06-21 19:11:30.505457
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    def return_something():
        return 'something'

    fnc = Lazy(return_something)
    result = fnc.to_either()

    assert isinstance(result, Right)
    assert result == Right('something')



# Generated at 2022-06-21 19:11:33.301588
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    @Lazy
    def lazy():
        return 5

    assert Maybe.nothing() == Lazy.of(None).to_maybe()
    assert Maybe.just(5) == lazy.to_maybe()

# Generated at 2022-06-21 19:11:39.169909
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from unittest import TestCase

    class LazyTest(TestCase):
        def test_should_return_string_representation_of_Lazy(self):
            def fn(*args):
                return 1

            lazy = Lazy(fn)
            assert str(lazy) == 'Lazy[fn=<function LazyTest.test_should_return_string_representation_of_Lazy.<locals>.fn at 0x7fb0c08d6a60>, value=None, is_evaluated=False]'

    LazyTest('test_should_return_string_representation_of_Lazy').test_should_return_string_representation_of_Lazy()


# Generated at 2022-06-21 19:11:42.363592
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test function for map method of Lazy.
    """
    def f() -> int:
        return 5

    assert Lazy(f).map(lambda x: x * 2).get() == 10



# Generated at 2022-06-21 19:11:45.761654
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of('test') == Lazy.of('test')
    assert not Lazy.of('test') == Lazy.of('test2')
    assert not Lazy.of('test') == 'test'



# Generated at 2022-06-21 19:11:47.765276
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda: 1).to_box() == Box(1)

# Generated at 2022-06-21 19:11:55.856518
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from probably import expect

    x_value = 123

    def __minus(a):
        return a - x_value

    minus_lazy = Lazy(__minus)
    expect(minus_lazy).to_equal(Lazy(__minus))
    expect(minus_lazy.map(lambda x: x * 2).get(10)).to_equal(20)

    expect(minus_lazy.to_box(10)).to_equal(Box(10 - x_value))



# Generated at 2022-06-21 19:12:04.323747
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    """
    Test function for Lazy map function.
    """
    # pylint: disable=C0116
    assert Lazy.of(1).map(lambda x: x+1).get() == 2
    assert Lazy.of(1).map(lambda x: x+2).get() == 3
    assert Lazy.of(42).map(lambda x: x+1).get() == 43


# Generated at 2022-06-21 19:12:06.709335
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy(lambda: 1).to_try() == Try.of(lambda: 1)


# Generated at 2022-06-21 19:12:17.603493
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert str(Lazy(lambda x: x).map(lambda x: x + 1)) == 'Lazy[fn=<function <lambda> at 0x10b7ab840>, value=None, is_evaluated=False]'
    assert Lazy(lambda x: x).map(lambda x: x + 1) == Lazy(lambda x: x).map(lambda x: x + 1)
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(1) == 2
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(1) == 2

# Generated at 2022-06-21 19:12:28.603972
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(2).get() == 2



# Generated at 2022-06-21 19:12:32.518218
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy(lambda: None).to_validation() == Validation.success(None)
    assert Lazy(lambda: 1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:12:44.106342
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    class DivisionByZero(Exception):
        pass

    def try_divide(x, y):
        try:
            return x // y
        except ZeroDivisionError:
            raise DivisionByZero()

    lazy_x = Lazy.of(lambda: 6)
    lazy_y = Lazy.of(lambda: 2)

    multiplies_x_and_y = lambda x: (
        Lazy.of(lambda: x * lazy_x.get())
    )

    multiplies_x_and_y_by_2 = lambda x: (
        Lazy.of(lambda: x * lazy_y.get())
    )

    lazy_divises_x_and_y = lambda x: (
        Lazy.of(lambda: try_divide(x, lazy_y.get()))
    )

    lazy_

# Generated at 2022-06-21 19:12:48.054555
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    lazy = Lazy.of(Box.of(4))
    assert lazy.to_box() == Box.of(Box.of(4))



# Generated at 2022-06-21 19:12:51.191424
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)


# Generated at 2022-06-21 19:13:01.309284
# Unit test for constructor of class Lazy
def test_Lazy():
    def f():
        return 1

    lazy1 = Lazy(f)
    assert not lazy1.is_evaluated
    assert lazy1.get() == 1
    assert lazy1.is_evaluated

    lazy2 = Lazy(f)
    assert lazy1 == lazy2
    assert not lazy2.is_evaluated
    assert lazy2.get() == 1
    assert lazy2.is_evaluated

    lazy3 = Lazy(f)
    assert lazy1 == lazy3
    assert not lazy3.is_evaluated
    assert lazy3.get() == 1
    assert lazy3.is_evaluated

    lazy4 = Lazy(f)
    assert lazy1 == lazy4
    assert not lazy4.is_evaluated
    assert lazy4.get() == 1
    assert lazy4.is_evaluated

    lazy

# Generated at 2022-06-21 19:13:06.602370
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 'test')
    assert str(lazy) == "Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x7f5fe8124598>, value=None, is_evaluated=False]"



# Generated at 2022-06-21 19:13:08.696218
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy(lambda:1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:13:12.635417
# Unit test for method get of class Lazy
def test_Lazy_get():
    def func(value: int) -> str:
        return str(value)

    lazy = Lazy(func)
    assert lazy.get(6) == func(6)
    assert lazy.value == lazy.get(6)
    assert lazy.is_evaluated


# Generated at 2022-06-21 19:13:17.505292
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    def fn1(a):
        return Validation.success(a)

    assert Lazy.of(1).to_validation() == Validation.success(1)
    assert Lazy.of(1).map(fn1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:13:40.861787
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def fn():
        return 2

    assert Lazy(fn).to_validation() == Validation.success(2)

# Generated at 2022-06-21 19:13:52.173050
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right, Left
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    f = Lazy(lambda value: value + 1)
    g = Lazy(lambda value: value + 10)
    assert f.ap(Right(1)).get() == Right(2)
    assert f.ap(Left(1)).get() == Left(1)
    assert f.ap(Box(1)).get() == Box(2)
    assert f.ap(Validation.success(1)).get() == Validation.success(2)
    assert f.ap(Maybe.just(1)).get() == Maybe.just(2)
    assert f.ap(Try.success(1)).get()

# Generated at 2022-06-21 19:13:54.501092
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    assert Lazy.of(3).ap(Lazy.of(lambda x: x+2)).get() == 5

# Generated at 2022-06-21 19:13:58.889710
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    import pymonet.functions as F

    def _divide(x, y):
        return x / y

    lazy = Lazy(_divide)
    assert lazy.map(F.plus(1)).to_validation(5, 5) == Validation.success(6)



# Generated at 2022-06-21 19:14:01.906702
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    test for Lazy.map(Lazy[Function(A) -> B])
    """
    lazy = Lazy(lambda *args: 1)
    assert (
        lazy.map(lambda x: x ** 2)
        == Lazy(lambda *args: 1 ** 2)
    )



# Generated at 2022-06-21 19:14:05.779808
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    def generate_even_number():
        return 42

    lazy = Lazy(generate_even_number)
    assert lazy.to_maybe() == Maybe.just(42)



# Generated at 2022-06-21 19:14:07.533842
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    called = False
    Lazy(lambda *args: called).bind(lambda *args: Lazy(lambda *args: not called)).get()
    assert called



# Generated at 2022-06-21 19:14:08.674683
# Unit test for method to_box of class Lazy
def test_Lazy_to_box(): # pragma: no cover
    assert Lazy.of(1).to_box() == Box(1)


# Generated at 2022-06-21 19:14:12.510811
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert [1, 2, 3, 4] == Lazy(lambda: [1, 2, 3]).bind(lambda x: Lazy(lambda: x + [4])).get()

# Generated at 2022-06-21 19:14:20.759020
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right

    def test_function():
        return "value"

    was_function_called = [False]

    def test_function_that_raise_exception():
        was_function_called[0] = True
        raise Exception("Exception message")

    assert Lazy(test_function).to_either() == Right(test_function())

    assert Lazy(test_function_that_raise_exception).to_either() == Right(None)

    assert was_function_called[0]



# Generated at 2022-06-21 19:15:07.382253
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy(lambda x: x).to_box(5) == 5
    assert Lazy(lambda x: x).to_box(False) is False


# Generated at 2022-06-21 19:15:17.274598
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def test_fn(value):
        return value

    lazy_object_1 = Lazy(test_fn)
    lazy_object_2 = Lazy(test_fn)
    lazy_object_3 = Lazy(test_fn)

    assert lazy_object_1 == lazy_object_1
    assert lazy_object_1 == lazy_object_2
    assert lazy_object_1 == lazy_object_3

    assert not (lazy_object_1 == None)

    assert lazy_object_1.get(1) == 1
    assert lazy_object_1.get(4) == 4

    assert lazy_object_1 == lazy_object_2
    assert lazy_object_1 == lazy_object_3


# Generated at 2022-06-21 19:15:22.278462
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.lazy import Lazy

    fn = lambda: 'some value'
    lazy = Lazy(fn)

    assert lazy.constructor_fn == fn
    assert lazy.is_evaluated == False
    assert lazy.value is None



# Generated at 2022-06-21 19:15:26.090850
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.functors.monad_maybe import Nothing

    assert Lazy(lambda: 5).to_maybe() == Maybe.just(5)
    assert Lazy(lambda: None).to_maybe() == Nothing()

# Generated at 2022-06-21 19:15:35.313406
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda x: x * 2).to_box(2) == Box(4)
    assert Lazy(lambda x, y: x * y).to_box(2, 3) == Box(6)
    assert Lazy(lambda x, y, z: x * y * z).to_box(2, 3, 4) == Box(24)
    assert Lazy(lambda x: x).to_box() == Box(None)

    # force evaluation
    assert Lazy(lambda x: x).to_box() == Box(None)



# Generated at 2022-06-21 19:15:36.452484
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert isinstance(Lazy.of(None).bind(lambda value: Lazy.of(value)), Lazy)

# Generated at 2022-06-21 19:15:42.969031
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def compute_fn(value: int) -> Lazy[int, int]:
        return Lazy(lambda *args: value * 2)

    assert Lazy(lambda *args: 1).bind(compute_fn).get() == 2
    assert Lazy(lambda *args: 1).bind(compute_fn).get() == 2
    assert Lazy(lambda *args: 1).bind(compute_fn).get() == 2


# Generated at 2022-06-21 19:15:44.644838
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    assert Lazy.of(10).ap(Maybe.just(lambda x: x * 2)).get() == 20



# Generated at 2022-06-21 19:15:49.160487
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.monad_try import Try

    print(Lazy.of(5))
    assert Lazy.of(5) == Lazy(lambda *args: 5)

    print(Lazy(Try.of(int, '5').get))
    assert Lazy.of(5) == Lazy(Try.of(int, '5').get)


# Generated at 2022-06-21 19:15:54.513288
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    def triple(x):
        return 3 * x

    def add_one_triple(x):
        return Lazy(lambda x: 3 * (x + 1))

    lazy = Lazy(lambda x: x + 1)
    lazy_triple = lazy.bind(add_one).bind(triple)
    assert lazy_triple.get(5) == 18
    assert lazy_triple.get(5) == 18
    assert lazy_triple == Lazy(lambda x: 3 * (2 * x))
    assert lazy_triple == add_one_triple(5)

