

# Generated at 2022-06-21 19:07:35.606468
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy(lambda: 1).fold() == 1
    assert Lazy(lambda x: x + 2).fold(1) == 3


# Generated at 2022-06-21 19:07:36.750548
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add(value):
        return Lazy(lambda x: x + 1)

    lazy = Lazy(lambda: 1)
    assert lazy.bind(add).get() == 2



# Generated at 2022-06-21 19:07:42.916699
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add1(x): return x + 1
    assert Lazy.of(10).map(add1).get() == 11

    def sum2(x, y): return x + y
    assert Lazy.of(sum2).ap(Lazy.of(add1)).ap(Lazy.of(10)).get() == 11

if __name__ == '__main__':
    test_Lazy_map()

# Generated at 2022-06-21 19:07:47.381627
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: 2*x).__eq__(Lazy(lambda x: 2*x))
    assert not Lazy(lambda x: 2*x).__eq__(Lazy(lambda x: 3*x))



# Generated at 2022-06-21 19:07:58.639030
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    def div(x, y):
        if y == 0:
            raise ValueError()
        return x / y


# Generated at 2022-06-21 19:08:02.425298
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right, Either

    test_cases = [
        (Lazy(lambda *args: 1), Right(1)),
        (Lazy(lambda *args: None), Left(None))
    ]

    for case in test_cases:
        actual = case[0].to_either()
        expected = case[1]
        assert actual == expected, 'Error during processing case {}'.format(case)



# Generated at 2022-06-21 19:08:06.105343
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    import pytest

    Lazy.of(5).bind(Maybe.of).to_maybe() | pytest.raises(Exception)



# Generated at 2022-06-21 19:08:12.284900
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def inc(x):
        return x+1

    assert (
        Lazy.of(inc).ap(Lazy.of(8))
        ==
        Lazy(lambda: inc(8))
    )


# Generated at 2022-06-21 19:08:13.875155
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy(lambda: 'string').to_either() == Right('string')

# Generated at 2022-06-21 19:08:20.627788
# Unit test for constructor of class Lazy
def test_Lazy():
    def test_fn(*args):
        return (1,) + args

    lazy = Lazy(test_fn)

    assert lazy.is_evaluated is False
    assert lazy.value is None

    assert lazy.get(4) == (1, 4)
    assert lazy.is_evaluated is True
    assert lazy.value == (1, 4)

    assert lazy.get(5) == (1, 4)
    assert lazy.is_evaluated is True
    assert lazy.value == (1, 4)

    assert lazy.get(6) == (1, 4)
    assert lazy.is_evaluated is True
    assert lazy.value == (1, 4)

    assert lazy.get(7) == (1, 4)
    assert lazy.is_evaluated is True
    assert lazy.value == (1, 4)


# Generated at 2022-06-21 19:08:25.577766
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    l = Lazy(lambda: 1)
    assert l.to_box().get() == 1



# Generated at 2022-06-21 19:08:28.425935
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of(1).to_maybe() == Just(1)
    assert Lazy.of(None).to_maybe() == Just(None)


# Generated at 2022-06-21 19:08:31.249762
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(5).to_box() == Box(5)



# Generated at 2022-06-21 19:08:34.715967
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    # given
    from pymonet.box import Box

    lazy = Lazy(lambda x: Box(x))
    result = lazy.to_box()
    expected = Box(None)

    assert result == expected



# Generated at 2022-06-21 19:08:36.846364
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def func():
        return 10

    lazy = Lazy(func)
    assert lazy.get() == 10

# Generated at 2022-06-21 19:08:40.670605
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def fn(x):
        return x

    assert Lazy(fn).to_maybe(1) == Maybe.just(1)
    assert Lazy(fn).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:08:43.854195
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add3(x, y, z):
        return x + y + z

    lazy = Lazy(add3)

    assert lazy.get(1, 2, 3) == 6


# Generated at 2022-06-21 19:08:49.553507
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    fn = lambda x: x
    lazy = Lazy(fn)

    assert str(lazy) == 'Lazy[fn=<function <lambda> at ' in str(lazy)

    lazy._compute_value(1)

    assert str(lazy) == 'Lazy[fn=<function <lambda> at ' in str(lazy)



# Generated at 2022-06-21 19:08:52.158520
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1) == Lazy.of(2)



# Generated at 2022-06-21 19:08:55.246398
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)).get() == 3


# Generated at 2022-06-21 19:09:10.697618
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Error

    result = Lazy.of(1).to_try()

    assert isinstance(result, Try)
    assert result.success
    assert result.value == 1

    def raise_error(*args):
        raise RuntimeError('Error')

    result = Lazy(raise_error).to_try()

    assert isinstance(result, Try)
    assert not result.success
    assert isinstance(result.error, Error)
    assert result.error.message == 'Error'

    result = Lazy.of(1).map(lambda x: x/0).to_try()

    assert isinstance(result, Try)
    assert not result.success
    assert isinstance(result.error, Error)

# Generated at 2022-06-21 19:09:16.303279
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy(lambda x: x + 1).to_try(1) == Try.of(lambda x: x + 1, 1)
    assert Lazy(lambda x: len(x)).to_try([1, 2, 3]) == Try.of(lambda x: len(x), [1, 2, 3])

# Generated at 2022-06-21 19:09:20.948478
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def try_fnt(x):
        return x

    assert Lazy(try_fnt).to_try(1) == Try.of(try_fnt, 1)



# Generated at 2022-06-21 19:09:22.178790
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(5).to_box() == Box(5)


# Generated at 2022-06-21 19:09:28.732073
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def add(x, y):
        return x + y

    def div(x, y):
        return x / y

    def is_empty(x):
        return x is None

    def is_empty1(x):
        return x is None

    def is_empty2(x):
        return isinstance(x, int)

    # fold Lazy defined with function returning value
    assert Lazy(lambda: 'Abra').to_maybe() == Maybe.just('Abra')

    # fold Lazy defined with function throwing exception
    try:
        Lazy(lambda: div(1, 0)).to_maybe()
    except ZeroDivisionError:
        assert True
    else:
        assert False

    # fold Lazy defined with function

# Generated at 2022-06-21 19:09:38.500790
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def f(x):
        return x

    lazy1 = Lazy(f)
    assert str(lazy1) == "Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x7f2dcc8f1f28>, " \
                        "value=None, is_evaluated=False]"

    lazy2 = Lazy(f).get()
    assert str(lazy2) == "Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x7f2dcc8f1f28>, " \
                        "value=None, is_evaluated=True]"

    lazy3 = Lazy(f).map(lambda x: 1)

# Generated at 2022-06-21 19:09:39.762911
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(2).to_box() == Box(2)


# Generated at 2022-06-21 19:09:48.536108
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy(lambda x: x * 2)
    lazy1 = lazy.bind(lambda x: Lazy(lambda y: x + y))
    assert lazy1.get(5) == 15

    lazy2 = Lazy(lambda x: x * 2).bind(lambda x: Lazy(lambda y: x + y)).bind(lambda x: Lazy(lambda y: x * y))
    assert lazy2.get(3) == 45

    # example of chained calls for lazy with inversion

# Generated at 2022-06-21 19:09:53.007309
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    # Given
    def stub_function():
        return 3

    lazy = Lazy(stub_function)

    # When
    either = lazy.to_either()

    # Then
    assert either == Right(3)

# Generated at 2022-06-21 19:09:58.841235
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy1 = Lazy(lambda x: x)
    lazy2 = Lazy(lambda x: x)

    lazy1.get('test')
    lazy2.get('test')

    assert lazy1 == lazy2

    lazy1 = Lazy(lambda x: x)
    lazy2 = Lazy(lambda x: x * 2)

    lazy1.get('test')
    lazy2.get('test')

    assert lazy1 != lazy2


# Generated at 2022-06-21 19:10:10.036756
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(5).get() == 5



# Generated at 2022-06-21 19:10:13.416167
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert isinstance(Lazy.of(1).to_try(), Try)



# Generated at 2022-06-21 19:10:23.840560
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: 1).bind(lambda x: Lazy(x * 2)).get() == 2
    assert Lazy(lambda x, y: x + y).bind(lambda x: Lazy(x * 2)).bind(lambda y: Lazy(y * 5)).get(4, 5) == 30
    assert Lazy.of(1).bind(lambda x: Lazy(x * 2)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy(x * 2)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy(x * 2)).bind(lambda y: Lazy(y * 5)).get() == 10
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2

# Generated at 2022-06-21 19:10:28.743052
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    # given
    from pymonet.either import Right

    lazy_right = Lazy.of(Right(2))
    lazy_right2 = Lazy.of(Right(3))

    # when
    result = lazy_right.bind(lambda x: lazy_right2)

    # then
    assert result == Lazy.of(Right(3)), "should be equal"


# Generated at 2022-06-21 19:10:35.651111
# Unit test for method get of class Lazy
def test_Lazy_get():
    # GIVEN
    mock_value = 'MOCK_VALUE'
    mock_function = mock.MagicMock(return_value=mock_value)
    lazy = Lazy(mock_function)

    # WHEN
    result = lazy.get()

    # THEN
    assert result == mock_value
    assert lazy.is_evaluated == True
    mock_function.assert_called_once_with()


# Generated at 2022-06-21 19:10:38.558333
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    def fn(x):
        return x * x

    assert Lazy.of(4).to_either() == Right(4)
    assert Lazy(fn).to_either(3) == Right(9)


# Generated at 2022-06-21 19:10:46.964133
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    """
    Test transform Lazy into try
    """
    # GIVEN function that raise something
    def raise_something():
        raise ValueError('Something happened')

    # AND Lazy with that function
    lazy = Lazy(raise_something)

    # WHEN lazy transform into try
    try_ = lazy.to_try()

    # THEN try should be failure with ValueError
    assert isinstance(try_, Failure)
    assert try_.get_exception() == ValueError('Something happened')


# Generated at 2022-06-21 19:10:55.349622
# Unit test for method map of class Lazy
def test_Lazy_map():
    # test with 0 parameter
    assert Lazy(lambda: 1).map(lambda _: 2).get() == 2

    # test with more parameter
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(1) == 2

    # test with more parameter
    assert Lazy(lambda x, y: x).map(lambda x: x + 1).get(1, 2) == 2

    # test when function was evaluated
    lazy_fn = Lazy(lambda x: x * 2)
    assert lazy_fn.get(2) == 4
    assert lazy_fn.map(lambda x: x + 1).get() == 5

    # Expected:
    # Lazy[fn=<function <lambda> at 0x7f5d9ed5bae8>, value=None, is_evaluated=False]


# Generated at 2022-06-21 19:10:59.982552
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def fun():
        raise ValueError('error')

    assert Lazy(fun).to_try() == Try.failure(ValueError('error'))
    assert Lazy(lambda: 2).to_try() == Try.success(2)


# Generated at 2022-06-21 19:11:07.818611
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy.of(1)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x104f3ea60>, value=1, is_evaluated=True]'
    assert str(Lazy(lambda: [])) == 'Lazy[fn=<function <lambda> at 0x104f3ed90>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:11:35.493177
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def test_constructor():
        assert Lazy(lambda *args: args) == Lazy(lambda *args: args)

        assert Lazy(lambda *args: args) != Lazy(lambda *args: args[0])

    def test_get():
        assert Lazy(lambda *args: args).get(1, 2, 3) == (1, 2, 3)

    def test_of():
        expected = Lazy(lambda *args: 'test')
        actual = Lazy.of('test')

        assert actual == expected

    def test_map():
        assert Lazy(lambda value: value + 1).map(lambda computed_value: computed_value + 1).get(5) == 7

    def test_ap():
        n = Lazy.of(lambda x: x + 3)
        assert n

# Generated at 2022-06-21 19:11:46.098804
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def func(a: int) -> int:
        return a * 2

    def func_mapper(a: int) -> Lazy[int, int]:
        return Lazy(lambda: a)

    assert Lazy.of(2).bind(func_mapper).get() == 2
    assert Lazy.of(2).map(func_mapper).get() == Lazy(lambda: Lazy(lambda: 2))
    assert Lazy.of(2).bind(func_mapper).bind(func_mapper) == Lazy(lambda: Lazy(lambda: 2))
    assert Lazy.of(2).bind(func_mapper).bind(lambda a: Lazy.of(a + 2)).get() == Lazy(lambda: Lazy(lambda: 4))

# Generated at 2022-06-21 19:11:51.593989
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(4)) == Lazy.of(5)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(5)) == Lazy.of(6)


# Generated at 2022-06-21 19:11:57.294628
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def _raise_exception(a):
        raise Exception(a)

    value = Lazy(_raise_exception).to_either(123)

    assert isinstance(value, Either)
    assert value.is_left()

    value = Lazy(lambda x: x + 1).to_either(123)

    assert isinstance(value, Either)
    assert value.is_right()
    assert value.get() == 124

# Generated at 2022-06-21 19:12:02.128773
# Unit test for method __str__ of class Lazy
def test_Lazy___str__(): # pragma: no cover
    assert str(Lazy(lambda x: x + 1)) == 'Lazy[fn=<function <lambda> at 0x109cb3320>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:12:06.749292
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(a):
        return lambda b: Lazy.of((a, b))

    assert (
        Lazy(lambda: 1).bind(f).fold(lambda a, b: a + b) ==
        Lazy(lambda: 2).fold(lambda a, b: a + b)
    )

# Generated at 2022-06-21 19:12:17.644203
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(10).to_box() == Box(10)
    assert Lazy(lambda: 11).to_box() == Box(11)
    assert Lazy(lambda *args: args).to_box(1, 2, 3, 4) == Box([1, 2, 3, 4])
    assert Lazy(lambda: False).to_box() == Box(False)
    assert Lazy(lambda: True).to_box() == Box(True)
    assert Lazy(lambda: []).to_box() == Box([])
    assert Lazy(lambda: [1, 2]).to_box() == Box([1, 2])
    assert Lazy(lambda: (1, 2, 3)).to_box() == Box((1, 2, 3))

# Generated at 2022-06-21 19:12:24.875753
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.try_ import Success, Failure

    def fn(arg):
        return Box(arg)

    result = Lazy.of(5).bind(fn)
    expected = Lazy(lambda: Box(5))

    assert result == expected

    result = Lazy.of(5)
    result.bind(fn)
    expected = Lazy(fn)

    assert result == expected

    def fn(arg):
        return Right(arg)

    result = Lazy.of(5).bind(fn)
    expected = Lazy(lambda: Right(5))

    assert result == expected

    result = Lazy.of(5)
    result.bind(fn)
    expected = Lazy

# Generated at 2022-06-21 19:12:36.449331
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Test to_try method of Lazy class.
    """

    test_data = [
        (lambda: 1, 1),
        (lambda: 1 / 0, ZeroDivisionError),
        (None, TypeError),
        ('a', TypeError),
        ([], TypeError),
        (1, TypeError)
    ]

    for (constructor_fn, expected) in test_data:
        fn = Lazy.of(constructor_fn)
        result = fn.to_try()
        if isinstance(expected, Exception):
            assert result.is_failure()
            assert isinstance(result._failure_value, expected)
        else:
            assert result.is_success()
            assert result._success_value == expected



# Generated at 2022-06-21 19:12:41.683212
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    assert Lazy.of(1).to_either(1) == Right(1)
    assert Lazy(lambda: 1).to_either() == Right(1)
    assert Lazy(lambda: 1).to_either() == Right(1)
    assert Lazy(lambda: Left(1)).to_either() == Left(1)



# Generated at 2022-06-21 19:13:23.922998
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy(lambda: 1)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)


# Generated at 2022-06-21 19:13:33.585677
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """Unit test for mapper method of class Lazy"""
    from pymonet.either import Left

    def fn(a):
        return a * 10

    assert Lazy(lambda: 1).to_either() == Right(1)
    assert Lazy(lambda: 1).to_either() == Right(1)
    assert Lazy(lambda: 1).map(fn).to_either() == Right(10)

    assert isinstance(Lazy(lambda: None).map(fn).to_either(), Left)
    assert Lazy(lambda: None).map(fn).to_either() == Left(None)



# Generated at 2022-06-21 19:13:41.511921
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test for Lazy class method map.
    """
    from pymonet.functor import Functor
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def test_functor(functor: Functor, is_ok: bool):
        """
        Test if functor has value or is an error.

        :param functor: functor to test
        :type functor: Any
        :param is_ok: is functor should be ok (not empty)
        :type is_ok: bool
        :returns: None
        :rtype: None
        """
        if is_ok:
            assert isinstance(functor, functor.__class__)
            assert functor.get() == -1

# Generated at 2022-06-21 19:13:52.689091
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import success
    from pymonet.validation import failure
    from pymonet.functor import Functor

    def test_success(value):
        def ret_fn():
            return str(value)

        lazy = Lazy(ret_fn)
        validation = lazy.to_validation()

        assert isinstance(validation, Validation)
        assert isinstance(validation, Functor)
        assert isinstance(validation, success)
        assert not isinstance(validation, failure)
        assert validation.get() == str(value)

    def test_failure(value):
        def ret_fn():
            raise value

        lazy = Lazy(ret_fn)
        validation = lazy.to_validation()


# Generated at 2022-06-21 19:13:59.381334
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(2).ap(Lazy.of(lambda x: x * 2)) == Lazy.of(4)
    assert Lazy.of(3).ap(Lazy.of(None)) == Lazy.of(3)
    assert Lazy.of(5).ap(Lazy.of(lambda x: x ** x)) == Lazy.of(3125)
    assert Lazy.of(None).ap(Lazy.of(lambda x: x ** x)) == Lazy.of(None)


# Generated at 2022-06-21 19:14:01.575680
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test method __eq__ of class Lazy.
    """
    assert Lazy.of(1) == Lazy.of(1)



# Generated at 2022-06-21 19:14:05.709814
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def f():
        return 1 / 0

    def g():
        return 1

    assert Lazy(f).to_try() == Try.failure(ZeroDivisionError())
    assert Lazy(g).to_try() == Try.success(1)

# Generated at 2022-06-21 19:14:12.955596
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return None

    lazy = Lazy(fn)

    assert lazy != Lazy(fn)
    assert not (lazy == Lazy(fn))

    # noinspection PyUnusedLocal
    def new_fn():
        return None

    assert lazy != new_fn

    # noinspection PyUnusedLocal
    def another_new_fn():
        return not None

    assert lazy != new_fn
    assert lazy != another_new_fn



# Generated at 2022-06-21 19:14:15.720328
# Unit test for method get of class Lazy
def test_Lazy_get():
    def function(*args):
        return 1 + 2

    lazy = Lazy(function)
    assert lazy.get('a') == 3


# Generated at 2022-06-21 19:14:17.662889
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda x: x + 1)
    assert lazy.get(1) == 2


# Generated at 2022-06-21 19:15:49.345208
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pytest

    testdata = [
        ('1', 1),
        ('2', 2),
        ('3', 3),
        ('4', 4),
        ('5', 5),
        ('6', 6),
        ('7', 7),
        ('8', 8),
        ('9', 9),
        ('0', 0),
    ]

    for value, result in testdata:
        lazy = Lazy.of(value)

        def fn(val):
            return Lazy.of(int(val))

        assert lazy.bind(fn).get() == result



# Generated at 2022-06-21 19:15:52.062031
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def add1(x):
        return x + 1

    def add2(x):
        return x + 2

    lazy1 = Lazy.of(1)
    assert lazy1.bind(lambda x: Lazy.of(add1(x))).bind(lambda x: Lazy.of(add2(x))).get() == 4

# Generated at 2022-06-21 19:15:55.833109
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    assert Lazy.of(2).map(Box.of).get() == Box.of(2)


# Generated at 2022-06-21 19:15:58.734873
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    test_Lazy = Lazy.of(10)
    assert test_Lazy.to_box() == Box(10)



# Generated at 2022-06-21 19:16:06.028946
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    value = Lazy.of(lambda x: x+5)
    assert Lazy.of(10).ap(value) == Lazy.of(15)
    assert Lazy.of([]).ap(value) == Lazy.of(5)
    assert Lazy.of([1, 1, 2, 3]).ap(value) == Lazy.of([6, 6, 7, 8])
    value = Lazy.of(lambda x: x.upper())
    assert Lazy.of('a').ap(value) == Lazy.of('A')
    assert Lazy.of(['a']).ap(value) == Lazy.of(['A'])
    assert Lazy.of(['a', 'b']).ap(value) == Lazy.of(['A', 'B'])

# Generated at 2022-06-21 19:16:12.853031
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy.
    """
    from pymonet.either import Right

    def get_adder(a):
        return lambda b: Right(a + b)

    def get_value(a):
        return Right(a)

    def sum_function(a):
        return a.bind(get_adder(5))

    assert Lazy(get_value).bind(sum_function).get() == Right(5)  # noqa

# Generated at 2022-06-21 19:16:14.996176
# Unit test for method map of class Lazy
def test_Lazy_map():
    my_lazy = Lazy(lambda: 'value')
    new_lazy = my_lazy.map(lambda value: value.upper())
    assert new_lazy == Lazy(lambda: 'value'.upper())


# Generated at 2022-06-21 19:16:19.436328
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe(): #pylint: disable=C0111,E0102,W0105
    from pymonet.maybe import Maybe

    def add(x, y):
        return x + y

    # when
    maybe = Lazy(add, 3, 2).to_maybe()

    # then
    assert Maybe.just(5) == maybe

    # when
    maybe = Lazy(add, 3, 2).to_maybe(2)

    # then
    assert Maybe.just(2) == maybe


# Generated at 2022-06-21 19:16:22.053849
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def one_plus_two():
        return 3
    lazy_function = Lazy(one_plus_two)
    lazy_function.to_either() == Either.right(1)

# Generated at 2022-06-21 19:16:25.889339
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_int = (Lazy.of(1)
                .map(lambda v: v + 1)
                .map(lambda v: v + 1))
    assert lazy_int.get() == 3
