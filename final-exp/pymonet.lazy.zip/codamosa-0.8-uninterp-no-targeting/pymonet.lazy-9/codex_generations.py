

# Generated at 2022-06-21 19:07:37.329818
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from hamcrest import *

    assert_that(Lazy.of(134).__eq__(Lazy.of(134)), equal_to(True))
    assert_that(Lazy.of(134).__eq__(Lazy.of(135)), equal_to(False))



# Generated at 2022-06-21 19:07:41.488260
# Unit test for method map of class Lazy
def test_Lazy_map():
    # GIVEN
    def add_one(value):
        return value + 1

    # WHEN
    result = Lazy.of(1).map(add_one).constructor_fn()

    # THEN
    assert 2 == result


# Generated at 2022-06-21 19:07:52.760821
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left
    from pymonet.maybe import Nothing, Just
    from pymonet.validation import Validation

    expected_to_either = Right(10)
    assert Lazy.of(10).to_either() == expected_to_either
    assert Lazy.of(Left(Just(10))).to_either() == Left(Just(10))
    assert Lazy.of(Nothing()).to_either() == Nothing()
    assert Lazy.of(Nothing()).to_either().is_nothing
    assert Lazy.of(Left(Nothing())).to_either() == Nothing()
    assert Lazy.of(Left(Nothing())).to_either().is_just
    assert Lazy.of(Left(Just(10))).to_either().is_just

# Generated at 2022-06-21 19:07:56.185729
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def _map(value):
        return value * 2

    assert Lazy.of(1).map(_map).to_maybe() == Maybe.just(2)


# Generated at 2022-06-21 19:08:00.316801
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    import pytest

    lazy = Lazy(lambda: None)
    assert str(lazy) == 'Lazy[fn=<function Lazy.<lambda> at 0x10a06e1e0>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:08:04.825945
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def divide_by_two(val):
        return val / 2

    # when
    lazy_result = Lazy.of(divide_by_two).to_try(4)

    # then
    assert lazy_result == Try.of(divide_by_two, 4)



# Generated at 2022-06-21 19:08:09.739053
# Unit test for method get of class Lazy
def test_Lazy_get():
    def get_value():
        return 1

    lazy = Lazy(get_value)
    assert lazy.get() == 1
    assert lazy.get() == 1



# Generated at 2022-06-21 19:08:17.952615
# Unit test for constructor of class Lazy
def test_Lazy():
    def function1(value):
        return value * 2
    def function2(value):
        return value * 3

    lazy1 = Lazy(function1)
    assert lazy1.value == None
    assert lazy1.is_evaluated == False
    assert lazy1.constructor_fn == function1
    assert lazy1 == lazy1, "Expected same instance of Lazy"

    lazy2 = Lazy(function2)
    assert lazy1 != lazy2, "Expected different instances of Lazy"
    assert lazy2.value == None
    assert lazy2.is_evaluated == False
    assert lazy2.constructor_fn == function2


# Generated at 2022-06-21 19:08:21.292428
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy.of(1)) == 'Lazy[fn=<function Lazy__init__.<locals>.<lambda> at 0x7f9ba6d9e1e0>, value=1, is_evaluated=True]'


# Generated at 2022-06-21 19:08:26.689397
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Just, Nothing
    from pymonet.monad_error import Try
    from pymonet.monad_try import Failure, Success
    from pymonet.validation import Validation, FailureValidation, SuccessValidation
    def foo(x):
        return x * 2

    assert Lazy(lambda: 1).map(foo).get() == 2
    assert Lazy(lambda: Box(1)).map(lambda x: x.map(foo)).get() == Box(2)
    assert Lazy(lambda: Just(1)).map(lambda x: x.map(foo)).get() == Just(2)
    assert Lazy(lambda: Nothing()).map(lambda x: x.map(foo)).get() == Nothing()
   

# Generated at 2022-06-21 19:08:33.698198
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy = Lazy(lambda x: x)
    assert lazy.__eq__(Lazy(lambda x: x)) is True
    assert lazy.__eq__(Lazy(lambda x: x + 1)) is False
    assert lazy.__eq__(1) is False

# Generated at 2022-06-21 19:08:37.570732
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def ap_inner_fn():
        return Lazy(lambda x: x + 1)

    lazy = Lazy(lambda x: x + 1)
    new_lazy = lazy.ap(ap_inner_fn())

    assert new_lazy.get(1) == 3

# Generated at 2022-06-21 19:08:44.179210
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    try_with_error = Lazy(lambda x: x + 1).to_try(1)
    assert isinstance(try_with_error, Try)
    assert try_with_error == Try.success(2)

    try_with_error = Lazy(lambda x: x + 1).to_try(1)
    assert isinstance(try_with_error, Try)
    assert try_with_error == Try.of(lambda x: x + 1, 1)

# Generated at 2022-06-21 19:08:48.546897
# Unit test for method get of class Lazy
def test_Lazy_get():
    counter = 0

    def counter_fn(*args):
        nonlocal counter
        counter += 1

        return counter

    assert Lazy(counter_fn).get() == 1
    assert Lazy(counter_fn).get() == 2
    assert Lazy(counter_fn).get() == 3



# Generated at 2022-06-21 19:08:52.737515
# Unit test for method map of class Lazy
def test_Lazy_map():
    def mapper(x):
        return x + 'bar'

    res = Lazy.of('foo').map(mapper)

    assert res == Lazy(mapper)
    assert res.get() == mapper('foo')



# Generated at 2022-06-21 19:08:56.799563
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda: 5).to_box().value == 5

    assert Lazy(lambda: 5).to_box(1, 2, 3).value == 5



# Generated at 2022-06-21 19:09:01.163490
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def function():
        return "smth"

    test_lazy = Lazy(function)

    assert test_lazy.to_maybe() == Maybe.just(function())


# Generated at 2022-06-21 19:09:03.633396
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.monad_test import test_to_maybe

    test_to_maybe(Lazy.of)


# Generated at 2022-06-21 19:09:12.784970
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.functions import true

    maybe = Maybe.nothing()
    lazy = Lazy.of(1)
    another_lazy = lazy.map(lambda x: x + 1)

    assert maybe.to_lazy() != lazy
    assert lazy.to_maybe() == Maybe.just(1)
    assert another_lazy.to_maybe() == Maybe.just(2)
    assert lazy.to_maybe().map(true) == Maybe.just(True)
    assert lazy.to_maybe().filter(true) == Maybe.just(1)
    assert lazy.to_maybe().filter(lambda x: x != 1) == Maybe.nothing()



# Generated at 2022-06-21 19:09:23.899297
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def increment(x):
        return x + 1

    def double(x):
        return x * 2

    def error_func():
        raise ValueError("Incorrect value")

    def success_func(x):
        return x + 1

    def success_func2(x):
        return x * 2

    assert Lazy(success_func) == Lazy(success_func)
    assert Lazy(double) != Lazy(increment)

    assert Lazy(success_func).map(double).fold(2) == 6

# Generated at 2022-06-21 19:09:36.860604
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Test method to_try of class Lazy.

    :returns: True when success and False when fails
    :rtype: bool
    """
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def success_fn() -> Try:
        return Try.of(lambda: 1)

    def failure_fn() -> Try:
        return Try.of(lambda: 1 / 0)

    lazy_try = Lazy(success_fn)
    assert lazy_try.to_try() == Try.success(1)
    assert lazy_try.to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:09:42.912582
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def fn(x):  # pragma: no cover
        return x

    lazy = Lazy(fn)
    assert str(lazy) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x7f8dca59f488>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:09:54.051183
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.either import Right, Left
    from pymonet.either import Either
    from pymonet.maybe import Maybe, Just, Nothing

    assert Maybe(True) == Lazy.of(True).to_maybe()
    assert Maybe(None) == Lazy.of(None).to_maybe()
    assert Maybe(1) == Lazy.of(1).to_maybe()
    assert Maybe("hello") == Lazy.of("hello").to_maybe()
    assert Maybe("hello").value() == "hello"
    assert Maybe("hello").value() == "hello"
    assert Maybe("hello").value(None) == "hello"
    assert Maybe("hello").value("bye") == "hello"
    assert Maybe("hello").value("bye", lambda: "hello") == "hello"

# Generated at 2022-06-21 19:10:00.375592
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy(lambda: 5).to_validation() == Validation.success(5)
    assert Lazy(lambda: {'a': 5}).to_validation() == Validation.success({'a': 5})
    assert Lazy(lambda: (1, 5)).to_validation() == Validation.success((1, 5))
    assert Lazy(lambda: None).to_validation() == Validation.success(None)
    assert Lazy(lambda: 'str').to_validation() == Validation.success('str')

# Generated at 2022-06-21 19:10:03.384552
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def fn(x):
        return x

    assert str(Lazy(fn)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x000001C7CF2D9EA0>, value=None, is_evaluated=False]' # noqa


# Generated at 2022-06-21 19:10:07.100201
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert str(Lazy(lambda: Maybe.just(1))) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x1064d5378>, value=Maybe.just(1), is_evaluated=False]'



# Generated at 2022-06-21 19:10:10.735159
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy(lambda: 'value').to_try().get() == 'value'

    raised_exception = Exception('raised exception')
    assert Lazy(lambda: raise_exception(raised_exception)).to_try().is_failure()
    assert Lazy(lambda: raise_exception(raised_exception)).to_try().get_failure() == raised_exception

# Generated at 2022-06-21 19:10:20.571263
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    assert Lazy.of(10).to_validation()._value == 10
    assert Lazy(lambda a: a).to_validation(10)._value == 10
    assert Lazy(lambda a, b: a + b).to_validation(10, 5)._value == 15
    assert Lazy(lambda a, b: a + b).to_validation(10).to_validation(5)._value == 15
    assert Lazy(lambda a, b: a + b).to_validation(10).to_validation(5).to_validation()._value == 15


# Generated at 2022-06-21 19:10:22.816152
# Unit test for method get of class Lazy
def test_Lazy_get():
    def lmd(var):
        msg = 'test'
        return msg

    lazy = Lazy(lmd)
    assert lazy.get() == 'test'



# Generated at 2022-06-21 19:10:28.236084
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def mapper(value):
        return value + 1

    def mapper2(value):
        return Lazy.of(value + 1)

    empty = Lazy(lambda *args: 1)
    assert empty.to_maybe().is_empty()
    assert empty.to_maybe(1).is_empty()

    lazy = Lazy(lambda *args: 1)
    assert lazy.bind(mapper) == Lazy(lambda *args: 2)
    assert Lazy(lambda *args: 2).bind(mapper2) == Lazy(lambda *args: 2).bind(mapper)


# Generated at 2022-06-21 19:10:37.449455
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def function(val):  return val
    def mapper(val):  return val * 2

    new_val = Lazy(lambda *args: 1).ap(Lazy(lambda *args: mapper)).get()
    assert new_val == 2

    original_val = Lazy(lambda *args: function).map(mapper).get()(1)
    assert original_val == new_val

# Generated at 2022-06-21 19:10:43.211710
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def f1(*args):
        return 1

    assert Lazy(f1).to_maybe(None) == Maybe.just(1)
    assert Lazy(f1).map(lambda x: x + 1).to_maybe(None) == Maybe.just(2)



# Generated at 2022-06-21 19:10:47.568286
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy = Lazy(lambda x: x ** 2)
    assert lazy.map(lambda x: x - 1).get(2) == 3

    lazy = Lazy.of(2)
    assert lazy.map(lambda x: x - 1).get() == 1



# Generated at 2022-06-21 19:10:55.690460
# Unit test for constructor of class Lazy
def test_Lazy():
    def uut(x:int) -> str:
        return 'Lazy({})'.format(x)

    assert Lazy(uut).get(10) == 'Lazy(10)'
    assert Lazy(uut).map(str.upper).get('10') == 'LAZY(10)'
    assert Lazy(uut).map(str.upper).get(10) == 'LAZY(10)'

    def uut_throw(x:int) -> str:
        if x == 1:
            raise AssertionError('It should raise AssertionError')
        return 'Lazy({})'.format(x)

    assert Lazy(uut_throw).to_try(1).is_failure()
    assert Lazy(uut_throw).to_try(1).is_failure()

# Generated at 2022-06-21 19:10:59.371511
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def fn():  # pragma: no cover
        return 1
    lazy = Lazy(fn)
    validation = lazy.to_validation()

    assert validation == Validation.success(fn())



# Generated at 2022-06-21 19:11:11.132089
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.either import Left
    from pymonet.either import Right
    from pymonet.box import Box

    def get_maybe():
        return Maybe.empty()

    assert(Lazy(get_maybe).to_maybe() == Maybe.empty())
    assert(Lazy(lambda: 3).to_maybe() == Maybe.just(3))
    assert(Lazy(lambda: None).to_maybe() == Maybe.empty())
    assert(Lazy(lambda: Left(3)).to_maybe() == Maybe.empty())
    assert(Lazy(lambda: Right(3)).to_maybe() == Maybe.just(3))
    assert(Lazy(lambda: Box(3)).to_maybe() == Maybe.just(3))



# Generated at 2022-06-21 19:11:19.301770
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy(lambda: 1).to_try() == Try.success(1)
    assert Lazy(lambda: '2').to_try() == Try.success('2')
    assert Lazy(lambda: []).to_try() == Try.success([])

    assert Lazy(lambda: 1/0).to_try() == Try.failure(ZeroDivisionError('division by zero'))
    assert Lazy(lambda: arr[1]).to_try() == Try.failure(IndexError("'arr' is not defined"))

# Generated at 2022-06-21 19:11:22.086944
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    result = Lazy.of(1) == Lazy(lambda: 1)
    assert result



# Generated at 2022-06-21 19:11:25.901583
# Unit test for constructor of class Lazy
def test_Lazy():
    fn = lambda x: x
    lazy = Lazy(fn)

    assert fn == lazy.constructor_fn
    assert False == lazy.is_evaluated
    assert None == lazy.value



# Generated at 2022-06-21 19:11:28.959719
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    """
    Test for method to_maybe of class Lazy
    """
    from pymonet.maybe import Maybe

    assert Maybe.just(20) == Lazy(lambda: 20).to_maybe()

# Generated at 2022-06-21 19:11:39.466481
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def add(a: int) -> int:
        return a + 1

    lazy = Lazy(add)

    expected_str = 'Lazy[fn=<function add at {}>, value=None, is_evaluated=False]'.format(hex(id(add)))
    assert str(lazy) == expected_str


# Generated at 2022-06-21 19:11:44.255426
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    assert isinstance(Lazy(lambda: 1), Functor)
    assert isinstance(Lazy(lambda: 1), Monad)
    assert isinstance(Lazy(lambda: 1), Applicative)

# Generated at 2022-06-21 19:11:46.342287
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def fn(x):
        return x + x

    lazy = Lazy(fn)
    assert lazy.__str__() == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(fn, None, False)



# Generated at 2022-06-21 19:11:56.999038
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    result = Lazy.of(1).bind(lambda x: Lazy.of(fn(x))).to_validation()

    # Successful result
    assert result.is_success
    assert result.value == [2]
    assert result.errors == []

    # Failed result
    result = Lazy.of(1).bind(lambda x: Lazy.of(fn(x))).to_validation().bind(lambda x: Validation.fail(x)).bind(
        lambda x: Validation.success(fn2(x))
    )

    assert result.is_success
    assert result.value == [2]


# Generated at 2022-06-21 19:11:59.963894
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(1).to_either() == Right(1)

# Generated at 2022-06-21 19:12:10.029341
# Unit test for constructor of class Lazy
def test_Lazy():
    f = lambda x: x + 1
    g = lambda x: x * 10
    h = lambda x: x * 10

    assert Lazy(f).map(g).constructor_fn(1) == 10
    assert Lazy(f).ap(Lazy(g)).constructor_fn(1) == 10
    assert Lazy(f).bind(lambda x: Lazy(g)).constructor_fn(1) == 10
    assert Lazy(f).bind(lambda x: Lazy(g)).map(h).constructor_fn(1) == 100
    assert Lazy(f).map(g).bind(lambda x: Lazy(h)).constructor_fn(1) == 100
    assert Lazy(f).constructor_fn(1) == 2
    assert Lazy(f).constructor_fn(1) == 2
   

# Generated at 2022-06-21 19:12:14.707886
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def test_fn(v):
        return Maybe(2)

    assert Maybe.just(1).bind(test_fn) == Lazy.of(1).to_maybe().bind(test_fn)

# Generated at 2022-06-21 19:12:18.805325
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda x: x + 2)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x7f9237e9d8c8>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:12:28.262803
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    box = Box(10)
    maybe = Maybe.just(10)
    either = Right(10)
    monad_try = Try.success(10)
    validation = Validation.success(10)

    assert Lazy.of(box).to_maybe() == maybe
    assert Lazy.of(maybe).to_maybe() == maybe
    assert Lazy.of(either).to_maybe() == maybe
    assert Lazy.of(monad_try).to_maybe() == maybe
    assert Lazy.of(validation).to_maybe() == maybe

# Generated at 2022-06-21 19:12:34.292960
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Test successful Try calling function inside Lazy
    """
    # given:
    lazy = Lazy(lambda x: x * 2)
    # when:
    try_result = lazy.to_try(2)
    # then:
    assert isinstance(try_result, Try)
    assert try_result.is_success
    assert try_result.get() == 4


# Generated at 2022-06-21 19:12:50.714266
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    def _pure(x: int) -> Lazy[int, int]:
        return Lazy.of(x)

    def _product(a: int, b: int) -> int:
        return a * b

    assert _pure(_product).ap(_pure(2)).ap(_pure(3)).get() == _pure(_product).ap(_pure(2)).ap(_pure(3)).get() == 6
    assert _pure(_product).ap(_pure(2)).ap(_pure(0)).get() == _pure(_product).ap(_pure(2)).ap(_pure(0)).get() == 0
    assert _pure(_product).ap(_pure(0)).ap(_pure(3)).get() == _pure(_product).ap(_pure(0)).ap(_pure(3)).get() == 0

# Generated at 2022-06-21 19:12:53.609145
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    lazy = Lazy.of(42)
    assert lazy.to_either() == Right(42)
    assert lazy.get() == 42


# Generated at 2022-06-21 19:13:03.242822
# Unit test for constructor of class Lazy
def test_Lazy():
    def func(x, y):
        return x, y

    from pymonet.lazy import Lazy
    from pymonet.box import Box

    lazy = Lazy(func)
    assert lazy is not None
    assert lazy == Lazy(func)

    lazy_of = Lazy.of(3)
    assert lazy_of is not None
    assert lazy_of == Lazy(lambda *args: 3)

    assert lazy_of.map(lambda arg: arg + 1).get() == 4

    assert lazy_of.ap(Lazy.of(lambda arg: arg + 1)).get() == 4

    assert lazy.ap(lazy_of).get(1, 2) == (1, 2)

    assert lazy_of.to_box().get() == 3


# Generated at 2022-06-21 19:13:08.396432
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def function():
        return 'foo'

    lazy = Lazy(function)
    assert lazy.to_maybe().to_native() == 'foo'

    lazy.is_evaluated = True
    lazy.value = 'bar'
    assert lazy.to_maybe().to_native() == 'bar'



# Generated at 2022-06-21 19:13:10.638914
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    assert Lazy(lambda: 'a').bind(lambda v: Lazy(lambda: v.upper())).fold() == 'A'

# Generated at 2022-06-21 19:13:14.933088
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    """
    Test method to_validation of class Lazy
    """
    from pymonet.validation import Validation

    lazy = Lazy(lambda x: x + 2)
    validation = lazy.to_validation(2)
    assert isinstance(validation, Validation)
    assert validation == Validation.success(4)



# Generated at 2022-06-21 19:13:20.111987
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # type: () -> None

    def test():
        # type: () -> int
        return 1

    lazy1 = Lazy(test)
    lazy2 = Lazy(test)
    assert lazy1 == lazy2

    lazy2._compute_value()

    assert lazy1 == lazy2
    assert lazy2 == lazy1

# Generated at 2022-06-21 19:13:23.234214
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe

    def fn(a: int) -> Maybe[int]:
        return Maybe.just(a)

    lazy = Lazy.of(4).bind(fn)
    assert lazy.get() == 4

# Generated at 2022-06-21 19:13:28.051551
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy1 = Lazy(lambda x: x * 3)
    lazy2 = Lazy(lambda x: x * x)

    assert lazy1.ap(lazy2).get(5) == 75
    assert lazy2.ap(lazy1).get(5) == 225

# Generated at 2022-06-21 19:13:32.319850
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def fn():
        return Lazy(lambda: 10)

    assert fn().to_either(1, 2) == Right(10)
    assert fn().to_either(1, 2) == Right(10)


# Generated at 2022-06-21 19:13:48.707315
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(20).to_either() == Right(20)
    assert Lazy.of(None).to_either() == Right(None)
    assert Lazy.of('test').to_either() == Right('test')
    assert Lazy.of(True).to_either() == Right(True)
    assert Lazy.of(False).to_either() == Right(False)
    assert Lazy.of(20).to_either() == Right(20)
    assert Lazy.of(20).to_either() != Right(30)
    assert Lazy.of(None).to_either() != Right(30)
    assert Lazy.of('test').to_either() != Right(30)
    assert Lazy.of(True).to_either() != Right(False)

# Generated at 2022-06-21 19:13:51.275001
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    def fn(a):
        return a

    Lazy(fn).to_either() == Left(None)

# Generated at 2022-06-21 19:13:59.073355
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.functor import identity_function
    from pymonet.lazy import Lazy

    assert Lazy(identity_function) != 1
    assert Lazy(identity_function) != None
    assert Lazy(identity_function) == Lazy(identity_function)
    assert Lazy(identity_function) == Lazy.of(identity_function)
    assert Lazy(identity_function).map(identity_function) == Lazy(identity_function).map(identity_function)


# Generated at 2022-06-21 19:14:02.086286
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def fn(x):
        return x * 2

    lazy = Lazy(fn)
    assert str(lazy) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(fn, lazy.value, lazy.is_evaluated)



# Generated at 2022-06-21 19:14:07.740857
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def foo():  # pragma: no cover
        return 123

    assert Lazy.of(100) == Lazy.of(100)
    assert Lazy.of(100) != Lazy.of(200)
    assert Lazy(foo) == Lazy(foo)
    assert Lazy(foo).map(lambda x: x + 1) != Lazy(foo).map(lambda x: x + 2)



# Generated at 2022-06-21 19:14:14.373613
# Unit test for constructor of class Lazy
def test_Lazy():

    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        Lazy()

    assert Lazy(lambda: 'a') == Lazy(lambda: 'a')
    assert Lazy(lambda: 'a') != Lazy(lambda: 'b')

    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        Lazy(1)



# Generated at 2022-06-21 19:14:17.714280
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    fn = lambda: 42
    lazy = Lazy(fn)

    assert Maybe.just(42) == lazy.to_maybe()

# Generated at 2022-06-21 19:14:24.110361
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(10).to_box() == Box(10)
    assert Lazy(lambda: 10).to_box() == Box(10)
    assert Lazy.of(10).to_box() == Box(10)
    assert Lazy(lambda: 10).to_box() == Box(10)
    assert Lazy.of(10).to_box() == Box(10)
    assert Lazy(lambda: 10).to_box() == Box(10)


# Generated at 2022-06-21 19:14:29.161528
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.monad import assert_equal

    def add(a, b):
        return a + b

    assert_equal(Lazy(lambda: add(1, 2)).to_box(), Box(3))


# Generated at 2022-06-21 19:14:32.026306
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    # given
    lazy_value = Lazy.of(10)

    # when
    try_result = lazy_value.to_try()

    # then
    assert try_result.is_success
    assert try_result.get_value() == 10

# Generated at 2022-06-21 19:14:42.023306
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert_that(Lazy.of(10) == Lazy.of(10))
    assert_that(Lazy.of(12) != Lazy.of(10))
    assert_that(Lazy.of(10) != "other")



# Generated at 2022-06-21 19:14:45.225987
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(2).map(lambda e: e + 2).get() == 4
    assert Lazy.of(None).map(lambda e: e + 2).get() == 2



# Generated at 2022-06-21 19:14:48.714668
# Unit test for method ap of class Lazy
def test_Lazy_ap(): # pragma: no cover
    from pymonet.monad import Monad
    def mult(a, b):
        return a * b

    assert Monad.ap(Lazy.of(2), Lazy.of(mult)).get(8) == 16

# Generated at 2022-06-21 19:14:55.219331
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.f_either import Either

    lazy_constructor_1 = Lazy(lambda x: x)
    lazy_constructor_2 = Lazy(lambda x: 2 * x)

    first = lazy_constructor_1.ap(lazy_constructor_2)
    assert isinstance(first, Lazy)
    assert first.get(3) == 6

    second = lazy_constructor_1.ap(Either.right(2 * 3))
    assert isinstance(second, Lazy)
    assert second.get(3) == 6

# Generated at 2022-06-21 19:14:59.014799
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(1).ap(Lazy.of(lambda x: x * 2)).get() == 2
    assert Lazy.of(1).ap(Lazy.of(lambda x: x * 2)).get(1) == 2
    assert Lazy.of(1).ap(Lazy.of(lambda x, y: x * y)).get(2) == 2
    assert Lazy.of(1).ap(Lazy.of(lambda x, y: x + y)).get(1) == 2


# Generated at 2022-06-21 19:15:01.754387
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda: 1).is_evaluated == False
    assert Lazy(lambda: 1).value == None
    assert Lazy(lambda: 1).constructor_fn == Lazy(lambda: 1).constructor_fn

# Generated at 2022-06-21 19:15:05.811119
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy(lambda x: x).map(lambda x: x + 1).to_maybe(2) == Maybe.just(3)
    assert Lazy(lambda x: x).map(lambda x: x + 1).to_maybe(2) == Maybe.just(3)

# Generated at 2022-06-21 19:15:08.239759
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy(lambda: 5).to_either() == Right(5)



# Generated at 2022-06-21 19:15:14.829489
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def multiply_lazy(first, second):
        return Lazy(lambda: first * second)

    def divide_lazy(first, second):
        return Lazy(lambda: first / second)

    def add_fn(first, second):
        return first + second

    assert Lazy.of(add_fn).ap(multiply_lazy(2, 3)).ap(divide_lazy(30, 5)).get() == 36

# Generated at 2022-06-21 19:15:18.587439
# Unit test for constructor of class Lazy
def test_Lazy():
    def res():
        return 7
    lazy = Lazy(res)
    assert lazy
    assert lazy.constructor_fn(1) == res(1)
    assert lazy.get(1) == res(1)
    assert lazy.constructor_fn(1) == lazy.get(1)
    assert lazy.is_evaluated
    assert lazy.get(1) == lazy.get(1)


# Generated at 2022-06-21 19:15:26.753221
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    def constructor_fn(*args):
        return "".join(args)

    lazy = Lazy(constructor_fn)
    maybe = lazy.to_maybe('a', 'b')
    assert isinstance(maybe, Maybe)
    assert maybe == Maybe.just('ab')



# Generated at 2022-06-21 19:15:29.728321
# Unit test for method get of class Lazy
def test_Lazy_get():
    def _get_value():
        return 'value'

    assert Lazy(_get_value).get() == 'value'
    assert Lazy(_get_value).get() == 'value'



# Generated at 2022-06-21 19:15:32.614828
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def add(a, b):
        return a + b

    assert Lazy(add).to_box(1, 2) == Box(3)


# Generated at 2022-06-21 19:15:39.206352
# Unit test for method get of class Lazy
def test_Lazy_get():
    test_type = "Lazy Unit test for method get of class Lazy"
    test_description = "Test for Lazy.get method"

    print("\n\n===== {0} =====\nDescription: {1}".format(test_type, test_description))

    def function(arg):
        return arg

    lazy = Lazy(function)

    result = lazy.get(1)

    print("Result of lazy.get(1): {0}".format(result))
    assert result == 1, "Result should be 1"
    print("Test {0} passed\n".format(test_type))



# Generated at 2022-06-21 19:15:42.981513
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Prepare data
    l1 = Lazy.of(lambda x: x + 1)
    l2 = Lazy.of(5)

    def check():
        assert l1.ap(l2) == Lazy.of(6)

    check()


# Generated at 2022-06-21 19:15:51.207453
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    lazy_a = Lazy(lambda: 'a')
    lazy_b = Lazy(lambda: 'b')
    assert (lazy_a == lazy_b) is False

    lazy_a._compute_value()
    lazy_b._compute_value()
    assert (lazy_a == lazy_b) is False
    lazy_b._compute_value()
    assert (lazy_a == lazy_b) is True

    lazy_a = Lazy(lambda x: x)
    lazy_b = Lazy(lambda x: x)
    assert (lazy_a == lazy_b) is False
    lazy_a._compute_value()
    lazy_b._compute_value()
    assert (lazy_a == lazy_b) is False

    lazy_a = L

# Generated at 2022-06-21 19:15:54.617352
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.either import Right

    assert Right.of(1).to_box() == Lazy(lambda *args: 1).to_box()


# Generated at 2022-06-21 19:16:03.232935
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    def f(*args):
        if len(args) != 2:
            raise ValueError('Exception')
        return args[0]+args[1]

    assert Lazy(f).to_either(1, 2) == Lazy(f).get(1, 2)
    assert Lazy(f).to_either(1) != Lazy(f).get(1, 2)
    assert Lazy(f).to_either(1).left.get_or_raise() == Lazy(f).get(1)
    assert Lazy(f).to_either(1).left.get_or_raise() != Lazy(f).get(1, 2)



# Generated at 2022-06-21 19:16:06.903268
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function <lambda> at 0x7f4652bac710>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:16:17.437543
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.monad import do

    def to_four(one):
        return 4

    def to_five(one):
        return 5

    def to_lazy(one):
        return Lazy.of(one)

    assert do(Lazy.of(1), lambda x: x.map(to_four)) == Lazy.of(4), 'Should return lazy with value 4'

    assert do(Lazy.of(1), lambda x: x.map(to_four).map(to_five)) == Lazy.of(5),\
        'Should return lazy with value 5'

    assert do(Lazy.of(1), lambda x: x.map(to_lazy).map(to_four)) == Lazy.of(4),\
        'Should return lazy with value 4'

# Generated at 2022-06-21 19:16:31.100455
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def add1(x):
        return x + 1

    def add2(x):
        return x + 2

    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) == Lazy.of(1)

    assert Lazy(add1) != Lazy(add2)
    assert Lazy(add1) == Lazy(add1)


# Generated at 2022-06-21 19:16:33.037961
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    f = lambda x: x + 3
    value = Maybe.just(3)
    lazy = Lazy(lambda: value)
    result = lazy.to_maybe()
    expected = Maybe.just(6)
    assert result == expected



# Generated at 2022-06-21 19:16:43.927812
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def multiplicatiom(a):
        return a * 2

    def division(a):
        if a == 0:
            return 0
        return 1 / a

    def substraction(a):
        return a - 1

    def add_one(a):
        return a + 1

    # Lazy.of
    lazy_1 = Lazy.of(2)
    assert lazy_1.map(add_one).map(multiplicatiom).get() == 6
    assert lazy_1.map(add_one).map(multiplicatiom).get() == 6

# Generated at 2022-06-21 19:16:51.200446
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def foo() -> str:
        return 'bar'

    lazy = Lazy(foo)

    assert lazy.is_evaluated is False
    assert lazy.get() == 'bar'
    assert lazy.is_evaluated is True
    assert str(lazy) == 'Lazy[fn=<function test_Lazy.<locals>.foo at 0x7f8a8a1a9730>, value=bar, is_evaluated=True]'
    assert lazy == Lazy(foo)



# Generated at 2022-06-21 19:16:52.310524
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(10) == Lazy(lambda *args: 10)



# Generated at 2022-06-21 19:16:54.967980
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Maybe

    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.none().map(lambda x: x + 1) == Maybe.none()


# Generated at 2022-06-21 19:17:04.737736
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    import pymonet.functor as f

    def test_const():
        assert str(Lazy.of(1)) == 'Lazy[fn=<function Lazy.<lambda> at 0x7fca75eaaa60>, value=None, is_evaluated=False]'
        assert str(Lazy.of(1).map(lambda v: v + 1)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.test_const.<locals>.<lambda> at 0x7fca75eaaae8>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:17:07.991535
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    def constructor_fn():
        return 'foo'

    lazy = Lazy(constructor_fn)
    assert lazy.to_box() == Box(constructor_fn())


# Generated at 2022-06-21 19:17:10.858316
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn).map(lambda x: x + 1) == Lazy(fn).map(lambda x: x + 1)


# Generated at 2022-06-21 19:17:12.825012
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.errors import Errors

    assert Lazy.of(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:17:27.080654
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of('x').to_box() == Box('x')


# Generated at 2022-06-21 19:17:36.599085
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.functor import Functor
    import pytest

    def fn(i: int) -> int:
        return i

    def fn2(i: int) -> int:
        return i

    def fn3(i: str) -> str:
        return i

    def fn4(i: int) -> str:
        return str(i)

    lazy = Lazy(fn)
    lazy2 = Lazy(fn2)
    lazy3 = Lazy(fn3)
    lazy4 = Lazy(fn4)

    assert lazy == lazy2
    assert lazy2 == lazy

    assert lazy != lazy3
    assert lazy != lazy4

    # Both Lazy are evaluated and have the same value but different functions
    assert lazy == Lazy.of(3).get()