

# Generated at 2022-06-21 19:07:43.969063
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    def fn(x: int) -> int:
        return x * 2

    def composed_fn(x: int) -> int:
        return fn(fn(fn(x)))

    lazy = Lazy(lambda x: x)
    assert lazy.get(1) == 1
    assert lazy.get(1) == 1
    assert lazy.get(2) == 2

    lazy = Lazy(lambda x: x * 2)
    assert lazy.get(2) == 4
    assert lazy.is_evaluated
    assert lazy.value == 4

    lazy = Lazy(lambda x: x * 2)
    assert lazy.map(lambda x: x * 2).get(2) == 16

# Generated at 2022-06-21 19:07:54.961782
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def constructor(*args):
        print("constructor called with args: {0}".format(args))
        return "constructor result"

    def mapper(value):
        print("mapper called with args: {0}".format(value))
        return "mapper result"

    def fn(value):
        print("folder called with args: {0}".format(value))
        return Lazy(function)

    def function(*args):
        print("function called with args: {0}".format(args))
        return "function result"

    lazy = Lazy(constructor)
    assert lazy.bind(fn).get('hello') == 'function result'
    assert lazy.map(mapper).bind(mapper).get('hello') == 'mapper result'

# Generated at 2022-06-21 19:07:58.274185
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy.of(2) == Lazy(lambda *args: 2)
    assert Lazy.of(2).to_maybe() == Maybe.just(2)



# Generated at 2022-06-21 19:08:00.812604
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<function Lazy.<lambda> at 0x7f6e4013f378>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:08:05.263423
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def square(x: int) -> int:
        return x**2

    from pymonet.box import Box

    assert Lazy.of(3).to_box() == Box(3)
    assert (
        Lazy.of(3)
            .map(square)
            .to_box() == Box(3**2)
    )


# Generated at 2022-06-21 19:08:13.875194
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    assert Lazy(lambda: Maybe.just(lambda x: x + 2)).ap(Maybe.just(2)) == Maybe.just(4)
    assert Lazy(lambda: Maybe.nothing()).ap(Maybe.just(2)) == Maybe.nothing()
    assert Lazy(lambda: Maybe.just(lambda x: x + 2)).ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-21 19:08:17.388852
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy(lambda: 'test').to_box() == Box('test')
    assert Lazy(lambda: 'test').to_box('test') == Box('test')



# Generated at 2022-06-21 19:08:19.051313
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy(lambda x: x).to_validation('a') == Validation.success('a')



# Generated at 2022-06-21 19:08:22.606673
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x * 2).get() == 2
    assert Lazy.of(1).map(lambda x: x * 2).value is None
    assert Lazy.of(1).map(lambda x: x * 2).is_evaluated is False



# Generated at 2022-06-21 19:08:25.005176
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    lazy = Lazy.of(10)
    box = lazy.to_box()

    assert isinstance(box, Box)
    assert box == Box(10)


# Generated at 2022-06-21 19:08:30.271946
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy(lambda *args: 'foo').to_maybe() == Maybe.just('foo')



# Generated at 2022-06-21 19:08:32.299988
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2



# Generated at 2022-06-21 19:08:36.368811
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def foo():
        return 9

    def bar():
        return 9

    def baz():
        return 10

    foo_lazy = Lazy(foo)
    bar_lazy = Lazy(bar)
    baz_lazy = Lazy(baz)

    assert foo_lazy == bar_lazy
    assert foo_lazy != baz_lazy



# Generated at 2022-06-21 19:08:43.235185
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def constructor(*args):
        assert args == (1, )
        return 5

    lazy = Lazy.of(5)
    assert isinstance(lazy.to_box(1), Box)
    assert lazy.to_box(1).get_or_else(None) == 5

    lazy = Lazy(constructor)
    assert isinstance(lazy.to_box(1), Box)
    assert lazy.to_box(1).get_or_else(None) == 5



# Generated at 2022-06-21 19:08:44.562693
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(5).bind(lambda x: Lazy.of(x + 1)).get() == 6


# Generated at 2022-06-21 19:08:50.434046
# Unit test for method map of class Lazy
def test_Lazy_map():
    inner_fn = lambda *args: [1, *args]
    lazy_instance = Lazy(inner_fn)

    mapper_fn = lambda arr: ''.join([str(item) for item in arr])
    mapped_lazy = lazy_instance.map(mapper_fn)

    assert mapped_lazy.get(3, 4) == '143'



# Generated at 2022-06-21 19:08:53.332073
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def fn():
        return "test"
    lazy = Lazy(fn)
    assert lazy.get() == "test"


# Generated at 2022-06-21 19:08:58.341432
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    import pytest
    from pymonet.validation import Validation

    def addition(a):
        # type: (int) -> int
        return a + 5

    assert Lazy(addition).to_validation(5) == Validation.success(10)

# Generated at 2022-06-21 19:09:03.007712
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    def constructor_fn(first: int, second: int) -> int:
        return first + second

    lazy = Lazy(constructor_fn)
    val = lazy.to_validation(1, 2)

    assert type(val._validation_value) == list
    assert val._validation_value[0] == 3

# Generated at 2022-06-21 19:09:08.610107
# Unit test for method get of class Lazy
def test_Lazy_get():
    def plus_one(value):
        return value + 1

    assert Lazy.of(2).get() == 2
    assert Lazy.of(2).map(plus_one).get() == 3

    assert Lazy(plus_one).get(3) == 4
    assert Lazy(plus_one).map(plus_one).get(3) == 5


# Generated at 2022-06-21 19:09:16.389064
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Lazy.of(2).to_validation() == Validation.success(2)



# Generated at 2022-06-21 19:09:26.512273
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    import pymonet
    import sys

    def lazy_func(x):
        """
        Function to test lazy func
        :param x: element
        :type x: int
        :returns: x
        :rtype: int
        """
        return x

    x = 10
    assert Lazy.of(x).to_try() == pymonet.monad_try.Try.of(lazy_func, x)

    def lazy_error_func(*args):
        """
        Function to test lazy error
        :param x: element
        :type x: int
        :returns: x
        :rtype: int
        """
        raise ValueError('any error')

    try:
        lazy_error_func()
    except ValueError as e:
        error = e

# Generated at 2022-06-21 19:09:31.174359
# Unit test for constructor of class Lazy
def test_Lazy():
    fn_1 = lambda arg: arg
    result_1 = Lazy(fn_1).get(1)
    assert result_1 == 1

    fn_2 = lambda arg: arg * 2
    result_2 = Lazy(fn_2).get(1)
    assert result_2 == 2



# Generated at 2022-06-21 19:09:36.162643
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def dummy_func():
        return 1

    def dummy_func_1(x):
        return x + 1

    assert Lazy(dummy_func) == Lazy(dummy_func)
    assert Lazy(dummy_func) != Lazy(dummy_func_1)
    assert Lazy(dummy_func) != 1


# Generated at 2022-06-21 19:09:39.855605
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_Lazy_bind_inner(lazy):
        def inner_fn(value):
            return Lazy.of(value + 1)

        return lazy.bind(inner_fn)

    lazy = Lazy(lambda: 1)
    result = test_Lazy_bind_inner(lazy)
    assert 2 == result.get()


# Generated at 2022-06-21 19:09:48.559804
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def id(x):
        return x

    def plus_two(x):
        return x + 2

    def plus_three(x):
        return x + 3

    def plus_one(x):
        return x + 1

    assert Lazy.of(plus_two).ap(Lazy.of(plus_three).map(id)) == Lazy.of(plus_two).ap(Lazy.of(plus_three)).get()
    assert Lazy.of(plus_two).ap(Lazy.of(plus_two)) == Lazy(lambda x: plus_two(plus_two(x)))
    assert Lazy.of(plus_two).ap(Lazy.of(plus_three).map(plus_one)) == Lazy(lambda x: plus_two(plus_one(plus_three(x))))


# Unit

# Generated at 2022-06-21 19:09:53.003854
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    """
    Test constructor of class Lazy.
    """
    def test_fn(*args):
        return 1

    assert Lazy(test_fn) is not None


# Generated at 2022-06-21 19:10:01.555457
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.validation import Validation

    assert Lazy.of(1).get() == 1
    assert Lazy.of(lambda: 'test').get()() == 'test'
    assert Lazy.of(1).constructor_fn() == 1
    assert Lazy.of(2).constructor_fn() == 2
    assert Lazy.of(2).map(lambda x: x + 1).get() == 3
    assert Lazy.of(3).bind(lambda x: Lazy.of(x + 1)).get() == 4
    assert Lazy.of(2).to_box().get() == 2
    assert Lazy.of(2).to_either().get_right() == 2
    assert Lazy.of(2).to_maybe().get_just() == 2

# Generated at 2022-06-21 19:10:03.784505
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def throw_exception():
        raise AttributeError

    lazy_throw_exception = Lazy(throw_exception)
    assert lazy_throw_exception.to_try() == Try.failure(AttributeError)

    def return_1():
        return 1

    lazy_return_1 = Lazy(return_1)
    assert lazy_return_1.to_try() == Try.of(return_1)

# Generated at 2022-06-21 19:10:06.833955
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(3).map(lambda x: x + 2) == Lazy.of(5)

    assert Lazy.of(3).map(lambda x: x + 2).map(lambda x: x / 2) == Lazy.of(2.5)



# Generated at 2022-06-21 19:10:15.008447
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda *args: [1, 2, 3]).get() == [1, 2, 3]

# Generated at 2022-06-21 19:10:21.220311
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(42) == Lazy.of(42).to_maybe()

    def divide(a, b):
        return a / b

    assert Lazy.of(42).to_maybe() == Lazy(divide).ap(Maybe.just(42)).to_maybe()
    assert Lazy.of(42).to_maybe() == Maybe.just(divide).ap(Maybe.just(42)).to_maybe()

# Generated at 2022-06-21 19:10:25.866944
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(*args):
        return args[0]

    assert (
        Lazy(fn) == Lazy(fn)
        and Lazy(fn) != Lazy.of(2)
        and Lazy(fn) != Lazy.of('2')
        and Lazy.of(1) == Lazy.of(1)
        and Lazy.of(1) != Lazy.of(2)
    )



# Generated at 2022-06-21 19:10:29.768808
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def fn_to_box(value: str) -> str:
        return value

    assert Lazy.of('test').to_box() == Lazy.of('test').map(fn_to_box).get()


# Generated at 2022-06-21 19:10:35.277120
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def function_to_call(arg):
        return arg * 2
    fn = lambda x: x * 3        # type: (int) -> int
    lazy = Lazy(fn).map(function_to_call)
    assert lazy.get(1) == 6


# Generated at 2022-06-21 19:10:38.528837
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def fn(x_arg: int, y_arg: int) -> int:
        return x_arg * y_arg

    lazy = Lazy(fn)

    assert lazy.to_maybe(123, 321) == Maybe.just(fn(123, 321))

# Generated at 2022-06-21 19:10:47.296291
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add3(a, b, c):
        return a + b + c

    def to_my_type(value):
        return SomeMyType(value)

    lazy_add3 = Lazy(add3)
    lazy_to_my_type = Lazy(to_my_type)

    assert lazy_to_my_type.ap(lazy_add3).get(1,2,3) == SomeMyType(6)
    assert lazy_add3.ap(lazy_to_my_type).get(1,2,3) == 6


# Generated at 2022-06-21 19:10:50.197761
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    value = 'value'
    error = Exception()

    assert Lazy.of(value).to_try() == Try.success(value)
    assert Lazy.of(error).to_try() == Try.failure(error)

    def raise_value():
        raise value

    assert Lazy(raise_value).to_try() == Try.failure(value)



# Generated at 2022-06-21 19:10:56.790497
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    fn_1, fn_2 = lambda x: x, lambda x: x
    lazy_obj = Lazy(fn_1)
    assert str(lazy_obj) == 'Lazy[fn={}, value=None, is_evaluated=False]'.format(fn_1)

    lazy_obj.is_evaluated = True
    lazy_obj.value = 1
    assert str(lazy_obj) == 'Lazy[fn={}, value=1, is_evaluated=True]'.format(fn_1)
    assert str(Lazy(fn_2)) == 'Lazy[fn={}, value=None, is_evaluated=False]'.format(fn_2)



# Generated at 2022-06-21 19:11:08.693647
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def dummy_function(*args):
        return args

    def dummy_mapper(x):
        return x + 1

    def dummy_folder(x):
        return x * 2

    def dummy_computation():
        return 1 / 0  # pylint: disable=pointless-statement

    assert Lazy(dummy_function).to_try(1, 2) == Try.success(dummy_function(1, 2))


# Generated at 2022-06-21 19:11:20.405796
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    # Arrange
    a_fn = lambda: 5
    a_lazy = Lazy(a_fn)
    a_lazy_value = a_lazy._compute_value()

    # Act
    result = a_lazy.__str__()

    # Assert
    expected = 'Lazy[fn={}, value={}, is_evaluated={}]'.format(a_fn, a_lazy_value, True)
    assert result == expected



# Generated at 2022-06-21 19:11:24.104112
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.validation import Validation

    def _func(v):
        return Lazy.of(v * 2)

    assert Lazy.of(1).bind(_func).get() == Validation.success(2).get()

# Generated at 2022-06-21 19:11:29.982376
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(42).get(42) == 42

    lazy_var = Lazy(lambda x: x * 2)
    assert lazy_var.is_evaluated == False
    assert lazy_var.get(21) == 42
    assert lazy_var.is_evaluated == True
    assert lazy_var.get(21) == 42
    assert lazy_var.value == 42

# Generated at 2022-06-21 19:11:37.944018
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Test method to_try of class Lazy

    :returns: None
    :rtype: None
    """
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.box import Box

    assert Lazy(lambda: 1).to_try() == Try.of(lambda: 1)
    assert Lazy(lambda: 1).to_try(1) == Try.of(lambda: 1, 1)
    assert Lazy(lambda: 1).to_try(1, 2) == Try.of(lambda: 1, 1, 2)
    assert Lazy(lambda a: 2).to_try() == Try.of(lambda a: 2)

# Generated at 2022-06-21 19:11:43.002041
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def fn(val):
        return val

    def is_right(val):
        return isinstance(val, Right)

    test_value = 'a'
    assert is_right(Lazy(fn).to_either(test_value))
    assert Lazy(fn).to_either(test_value).get() == test_value



# Generated at 2022-06-21 19:11:50.142813
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Just

    assert Lazy.of(5).ap(Lazy.of(3).map(lambda x: x + 1)) == Lazy.of(5)
    assert Lazy.of(5).ap(Just(7).to_lazy().bind(lambda x: Lazy.of(x + 1))) == Lazy.of(6)
    assert Lazy.of(5).ap(Lazy.of(7).map(lambda x: x + 1)) == Lazy.of(6)


# Generated at 2022-06-21 19:11:59.008719
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # two unevaluated Lazy with the same constructor functions will be equals
    assert Lazy(lambda: 'a') == Lazy(lambda: 'a')

    # two evaluated Lazy with the same constructor functions and value will be equals
    lazy_1 = Lazy(lambda: 'a')
    lazy_1._compute_value()
    lazy_2 = Lazy(lambda: 'a')
    lazy_2._compute_value()

    assert lazy_1 == lazy_2

    # two evaluated Lazy with the different constructor functions and value will be different
    lazy_1 = Lazy(lambda: 'a')
    lazy_1._compute_value()
    lazy_2 = Lazy(lambda: 'b')
    lazy_2._compute_value()

    assert lazy_1 != lazy_2

    # two evaluated Lazy with the

# Generated at 2022-06-21 19:12:01.433525
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():

    def foo():
        return 42

    lazy = Lazy(foo)
    assert lazy.to_maybe() == Maybe(42)


# Generated at 2022-06-21 19:12:11.293142
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.fn import compose
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value: T) -> U:
        return value

    def test_fn_to_box(value: T) -> Box[U]:
        return Box(value)

    def test_fn_to_either(value: T) -> Right[U]:
        return Right(value)

    def test_fn_to_maybe(value: T) -> Maybe[U]:
        return Maybe.just(value)

    def test_fn_to_try(value: T) -> Try[U]:
        return Try.of(lambda: value)


# Generated at 2022-06-21 19:12:15.778275
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lz = Lazy(lambda x: x + 1)
    result = lz.ap(Lazy(lambda x: x(2)))
    assert result.get() == 3


# Generated at 2022-06-21 19:12:25.796898
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def test_fn(test_value):
        def fn():
            return test_value

        lazy = Lazy(fn)
        assert lazy.get() == test_value

    test_fn(2)
    test_fn(None)



# Generated at 2022-06-21 19:12:38.011081
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Success

    try:
        def function_return_string(*args):
            print('calling function_return_string')
            return 'hello'

        lazy = Lazy(function_return_string)
        assert isinstance(lazy.to_try(), Success)
        assert lazy.to_try().get() == 'hello'
        assert lazy.to_try().get() == 'hello'

        def function_raise_exception(*args):
            raise ValueError('exception!!!')

        lazy = Lazy(function_raise_exception)
        assert lazy.to_try().is_failure()
        assert isinstance(lazy.to_try().get_cause(), ValueError)

    except AssertionError as e:
        print(e)
        import sys

# Generated at 2022-06-21 19:12:49.271281
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def throwing_function(error):
        raise error

    def error(value):
        return ZeroDivisionError('{}'.format(value))

    lazy = Lazy(lambda x: throwing_function(ZeroDivisionError('10')))
    assert lazy.to_try() == Try.failure(ZeroDivisionError('10'))

    assert Lazy(lambda x: throwing_function(ZeroDivisionError('10'))).to_try() == Try.failure(ZeroDivisionError('10'))
    assert Lazy(lambda x: throwing_function(KeyError('key'))).to_try() == Try.failure(KeyError('key'))
    assert Lazy(lambda x: throwing_function(KeyError(10))).to_try() == Try.failure(KeyError(10))

# Generated at 2022-06-21 19:12:52.492957
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    def return_string():
        return 'string'

    assert Right('string') == Lazy(return_string).to_either()


# Generated at 2022-06-21 19:12:55.674370
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(10) == Lazy.of(10).to_validation()


# Generated at 2022-06-21 19:12:58.426563
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    fn = lambda: 1
    lazy = Lazy(fn)

    assert isinstance(lazy.to_box(), Box)
    assert lazy.to_box() == Box(1)


# Generated at 2022-06-21 19:13:01.111761
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(3) == Lazy.of(3)
    assert not Lazy.of(2) == Lazy.of(3)



# Generated at 2022-06-21 19:13:04.606023
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    lazy = Lazy.of(lambda x: x + 1)
    assert lazy.map(lambda x: x * 2).map(lambda x: str(x)).get(2) == '6'


# Generated at 2022-06-21 19:13:14.856742
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.monad_try import Try
    import pymonet.either

    # Try to get result of function which raise ValueError
    result = Lazy(lambda: float('A')).to_either()

    result_to_string = result.to_string()
    expected_result_to_string = 'Left[ValueError("could not convert string to float: \'A\'")]'

    # Check if result is Left with ValueError
    assert isinstance(result, pymonet.either.Left)
    assert result_to_string == expected_result_to_string

    # Try to get result of function which raise TypeError
    result = Lazy(lambda: 1 / 'A').to_either()

    result_to_string = result.to_string()
    expected_result_to_

# Generated at 2022-06-21 19:13:18.748531
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def plus(a, b):
        return a + b

    def plus_through_try(a, b):
        return Try.of(plus, a, b)

    assert Lazy(plus_through_try).to_try(1, 1) == Try.success(2)
    assert Lazy(plus_through_try).to_try(1, '1') == Try.failure(TypeError)

# Generated at 2022-06-21 19:13:33.929894
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def test(value):
        return Lazy.of(value).to_validation()

    assert test(10) == Validation.success(10)
    assert test('ala') == Validation.success('ala')


# Generated at 2022-06-21 19:13:37.748576
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(2).bind(lambda x: Lazy.of(x + 1)).map(lambda x: x + 1) == Lazy.of(4).bind(lambda x: Lazy.of(x + 1)).map(lambda x: x + 1)


# Generated at 2022-06-21 19:13:48.782256
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    # pylint: disable=unused-variable,unused-argument
    from pymonet.exceptions import UnsupportedValueError

 
    assert Lazy.of(1).bind(lambda x: Lazy.of(x * 2)) == Lazy(lambda *args: 2)

    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x * 2)) == Lazy(lambda *args: 2)
    assert Lazy(lambda: 1).bind(lambda x: Lazy.of(x * 2)) == Lazy(lambda *args: 2)

    assert Lazy.of(1).bind(lambda x: Lazy(lambda: x * 2)) == Lazy(lambda *args: 2)


# Generated at 2022-06-21 19:13:53.670352
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    lazy = Lazy(lambda: 'Hello World!')

    assert str(lazy) == "Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x7fa3dcf37510>, value=None, is_evaluated=False]"


# Generated at 2022-06-21 19:14:02.676888
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.either import Either

    def fn(*_):
        return Lazy.of(1)

    def fn2(*_):
        return Lazy.of(Try.success(1))

    def fn3(*_):
        return Lazy.of(Try.failure(1))

    def fn4(*_):
        return Lazy.of(Right(1))

    def fn5(*_):
        return Lazy.of(Left(1))

    assert fn().to_either() == Either.right(1)
    assert fn2().to_either() == Either.right(1)
    assert fn3().to_either() == Either.left(1)

# Generated at 2022-06-21 19:14:04.869617
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def fn():
        return 1
    assert Lazy(fn).to_maybe() == Maybe.just(1)
    assert Lazy(fn).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 19:14:06.401378
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda: 5).to_box() == Box(5)


# Generated at 2022-06-21 19:14:08.835550
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def test_f():
        return 'test'

    lazy = Lazy(test_f)

    assert 'Lazy[fn={}, value={}, is_evaluated={}]'.format(test_f, None, False) == str(lazy)


# Generated at 2022-06-21 19:14:13.016861
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of('1').map(int).map(lambda x: x + 1).get() == 2


# Generated at 2022-06-21 19:14:16.978430
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.identity import Identity

    assert Lazy.of(1) == Lazy(lambda: 1)

    def fn(): pass
    assert Lazy.of(fn) != Lazy(lambda: 2)

    assert Lazy.of([]) == Lazy(lambda: [])

    assert Lazy(lambda: Identity(1)) != Identity(1)

    # Lazy can not't be compared with anything except Lazy
    try:
        assert Lazy(lambda: 1) == 1
    except TypeError:
        pass
    else:
        assert False, "Must raise TypeError"



# Generated at 2022-06-21 19:14:31.667274
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1


# Generated at 2022-06-21 19:14:36.695554
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    f = lambda x: Lazy.of(x + 5)
    g = lambda x: Lazy.of(x * 5)
    h = lambda x: x

    src = Lazy.of(Box(5)).bind(f).bind(g).bind(h)
    expected_src = Lazy.of(30)

    assert src == expected_src, 'Expected {}, got {}'.format(expected_src, src)



# Generated at 2022-06-21 19:14:41.544454
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test Lazy.__init__() method.
    """
    from pymonet.functor import mapper

    # map with tuples
    assert Lazy(lambda: (1, 2, 3)).map(mapper(lambda a, b, c: a + b + c)).get() == 6
    assert Lazy(lambda: (1, 2, 3)).map(mapper(lambda a, b, c: (a, b, c))).get() == (1, 2, 3)
    # map with lists
    input_list = [1, 2, 3]
    assert Lazy(lambda: input_list).map(mapper(lambda a, b, c: a + b + c)).get() == 6

# Generated at 2022-06-21 19:14:45.180120
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(3) == Lazy.of(3).to_validation()
    assert Validation.success(3) == Lazy(lambda: 3).to_validation()


# Generated at 2022-06-21 19:14:47.243720
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(7).to_box() == Lazy.of(7).to_box()



# Generated at 2022-06-21 19:14:50.654104
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1).__eq__(Lazy.of(1))
    assert not Lazy.of(2).__eq__(Lazy.of(1))

# Generated at 2022-06-21 19:14:57.991349
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    """
    Test to_validation method for class Lazy
    """
    from pymonet.validation import Validation

    def _test1():  # pylint: disable=missing-docstring
        val = Validation.success('test')

        return Lazy(val.get)

    returned_validation = _test1().to_validation()

    assert isinstance(returned_validation, Validation)
    assert returned_validation.is_success()
    assert returned_validation.get() == Lazy.of('test').get()

    def _test2():  # pylint: disable=missing-docstring
        val = Validation.failure('test')

        return Lazy(val.get)

    returned_validation = _test2().to_validation()


# Generated at 2022-06-21 19:15:05.233232
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # Tests two not empty Lazy instances
    assert Lazy.of(None) == Lazy.of(None)
    assert Lazy.of(123) == Lazy.of(123)
    assert Lazy.of(False) == Lazy.of(False)
    assert Lazy.of('text') == Lazy.of('text')
    assert Lazy.of({'key': 123}) == Lazy.of({'key': 123})
    assert Lazy.of(['value']) == Lazy.of(['value'])

    # Tests two empty Lazy instances
    assert Lazy(lambda _: None) == Lazy(lambda _: None)
    assert Lazy(lambda _: 123) == Lazy(lambda _: 123)
    assert Lazy(lambda _: False) == Lazy(lambda _: False)

# Generated at 2022-06-21 19:15:09.473426
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def foo():
        return 3/0

    lazy = Lazy(lambda: foo())
    lazy_try = lazy.to_try()

    assert lazy_try == Try.failure(ZeroDivisionError)

# Generated at 2022-06-21 19:15:15.452349
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    try_1 = Try(lambda: 1 / 0)
    try_2 = Try(lambda: 1 / 0)
    assert try_1 != try_2

    lazy_1 = Lazy(lambda: 1 / 0)
    lazy_2 = Lazy(lambda: 1 / 0)
    assert lazy_1 != lazy_2



# Generated at 2022-06-21 19:15:48.829212
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1).__eq__(Lazy.of(1))
    assert Lazy.of(1).__eq__(Lazy(lambda arg: arg).get(1))
    assert Lazy.of(1).__eq__(Lazy(lambda arg: arg).get(1).get(1))
    assert not Lazy(lambda arg: arg).__eq__(Lazy(lambda arg: arg * 2).get(1))
    assert not Lazy.of(1).__eq__(None)
    assert not Lazy.of(1).__eq__(2.1)
    assert not Lazy.of(1).__eq__(Lazy(lambda arg: arg).get(1).get(1).map(lambda arg: arg * 2))

# Generated at 2022-06-21 19:15:54.958316
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from hypothesis import given
    from hypothesis.strategies import from_type, recursive, one_of, nothing, sampled_from


# Generated at 2022-06-21 19:16:01.277273
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from collections import namedtuple

    Person = namedtuple('Person', ('name', 'age'))

    def person_constructor(name, age):
        return Person(name, age)

    person = Lazy(person_constructor)

    assert str(person) == 'Lazy[fn=<function Lazy.<locals>.person_constructor at 0x7f8c31128b70>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:16:04.768685
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Success test
    assert Lazy(lambda x: x + 1).map(lambda x: x * 3).get(2) == 9, "Lazy map function was changed"
    # Exception test
    assert Lazy(lambda x: x + 1).map(lambda x: x * 3).get('x') == 9, "Lazy map function was changed"


# Generated at 2022-06-21 19:16:07.652800
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)


# Generated at 2022-06-21 19:16:12.554476
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    test_fn = lambda: 1
    lazy = Lazy(test_fn)

    assert str(lazy) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x{:x}>, value=None, is_evaluated=False]'.format(id(test_fn))

# Generated at 2022-06-21 19:16:15.861120
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.either import Right

    assert Lazy(lambda x: x).map(lambda x: x + 1).get(1) == 2
    assert Lazy(lambda x: x).map(lambda x: x + 1).get('abc') == 'abc1'
    assert Lazy(lambda x: x + 1).map(lambda x: Right(x)).get(1) == Right(2)



# Generated at 2022-06-21 19:16:20.255216
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def fn(x):
        return x + 1

    lazy_0 = Lazy.of(2)

    assert lazy_0 == Lazy.of(2)

    lazy_1 = lazy_0.map(fn)

    assert lazy_1 == lazy_1

    assert lazy_0 != lazy_1

    assert lazy_1 != 1

    lazy_2 = lazy_1.map(lambda x: x + 1)

    assert lazy_1 == lazy_1.map(fn)

    assert lazy_2 == lazy_1.map(lambda x: x + 1)



# Generated at 2022-06-21 19:16:25.681096
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    """
    Unit test for method to_maybe of class Lazy
    """

    def fn():
        return 1

    def fn_with_raise():
        raise "error"

    assert Lazy.of(1).to_maybe() == Lazy.of(1).map(Maybe.just).get()

# Generated at 2022-06-21 19:16:34.510537
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def test_lazy(values):
        return Lazy.of(sum(values))

    # When: Box contains function
    # And: Lazy contains some values
    # Then: result of function obtains from Box is applied to every value in Lazy
    assert Lazy.of((2, 3)).ap(Box(lambda x: x*x)) == Lazy.of((4, 9))

    # When: Validation contains function
    # And: Lazy contains some values
    # Then: result of function obtains from Validation is applied to every value in Lazy