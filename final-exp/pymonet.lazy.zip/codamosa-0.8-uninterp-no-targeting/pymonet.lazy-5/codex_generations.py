

# Generated at 2022-06-21 19:07:39.518977
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Lazy(lambda x: x).to_try() == Try.success(None)
    assert Lazy(lambda x: 10).to_try() == Try.success(10)
    assert Lazy(lambda: 1 / 0).to_try() == Try.failure(ZeroDivisionError())
    assert Lazy(lambda x: x).to_try(None) == Try.success(None)
    assert Lazy(lambda x: 10).to_try(None) == Try.success(10)
    assert Lazy(lambda: 1 / 0).to_try(None) == Try.failure(ZeroDivisionError())


# Generated at 2022-06-21 19:07:40.135897
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(42).get() == 42



# Generated at 2022-06-21 19:07:44.443467
# Unit test for method get of class Lazy
def test_Lazy_get():
    t = Lazy(lambda: 10).map(lambda x: x * 10)
    assert t.get() == 100
    assert t.is_evaluated is True
    assert t.get() == 100
    assert t.is_evaluated is True
    assert t.value == 100



# Generated at 2022-06-21 19:07:47.760695
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy1 = Lazy.of(1)
    lazy2 = lazy1.bind(lambda x: Lazy.of(x + 1))

    assert lazy1.get() == 1
    assert lazy2.get() == 2

# Generated at 2022-06-21 19:07:58.926927
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy.of(123) == Lazy.of(123)
    assert Lazy.of(123) != Lazy.of(0)

    lazy = Lazy.of(123)
    assert lazy._compute_value() == 123
    assert lazy.is_evaluated == True
    assert lazy.value == 123

    lazy = Lazy.of(lambda x: x * 2)
    assert lazy.is_evaluated == False
    assert lazy._compute_value(2) == 4
    assert lazy.value == 4

    lazy = Lazy.of(123)
    assert lazy.is_evaluated == False
    assert lazy._compute_value() == 123
    assert lazy.is_evaluated == True

    lazy = Lazy.of(lambda x: x + 1)

# Generated at 2022-06-21 19:08:02.671537
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    # Test success Try
    assert (
        Lazy.of(True).to_try()
        ==
        Try.of(lambda: True)
    )

    # Test failure Try
    def failing_fn():
        raise RuntimeError('failing call')

    assert (
        Lazy(failing_fn).to_try()
        ==
        Try.of(failing_fn)
    )

# Generated at 2022-06-21 19:08:14.525827
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    lazy1 = Lazy(lambda: 1)
    lazy1.is_evaluated = True
    lazy1.value = 1

    lazy2 = Lazy(lambda: 1)
    lazy2.is_evaluated = True
    lazy2.value = 1

    assert lazy1 == lazy2

    lazy3 = Lazy(lambda: 'a')
    lazy3.is_evaluated = True
    lazy3.value = 'a'

    assert lazy3 == lazy3

    assert lazy1 != lazy3
    assert lazy3 != lazy1



# Generated at 2022-06-21 19:08:18.123451
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    one = Lazy.of(1)
    assert one.to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:08:27.904196
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Failure

    assert str(Lazy.of(1).bind(lambda n: Lazy(lambda: n + 1))) == 'Lazy[fn=<function <lambda> at 0x7f6e419c7378>, value=None, is_evaluated=False]'
    assert str(Lazy.of(1).map(lambda n: n + 1).bind(lambda n: Lazy(lambda: n + 1))) == 'Lazy[fn=<function <lambda> at 0x7f6e419c7378>, value=None, is_evaluated=False]'

    assert Lazy.of(1).bind(lambda n: Lazy(lambda: n + 1)).get() == 2

# Generated at 2022-06-21 19:08:34.490482
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    """
    Unit test for method map of class Lazy
    """
    def mock_function(value):
        return value + 3

    assert Lazy(mock_function).map(lambda x: x - 3).get(2) == 2

    def mock_lazy_function(value):
        return Lazy(mock_function)

    assert Lazy(mock_lazy_function).map(lambda x: x).g

# Generated at 2022-06-21 19:08:41.180072
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    """
    Test for method bind of class Lazy
    """
    lazy = Lazy.of(42)
    result = lazy.bind(lambda value: Lazy.of(value + 1))

    assert result.get() == 43
    assert result.is_evaluated



# Generated at 2022-06-21 19:08:43.192187
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    def function():
        return 1

    assert Lazy(function).to_validation() == Validation.success(function())



# Generated at 2022-06-21 19:08:45.717003
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from ..identity import Identity

    assert Lazy.of(1) == Lazy.of(1)
    assert Identity.of(1) == Identity.of(1)

# Generated at 2022-06-21 19:08:50.985247
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(1) == 1
    assert Lazy(lambda a, b: a + b).get(1, 2) == 3
    assert Lazy(lambda a, b: a + b).get(10, 20) == 30



# Generated at 2022-06-21 19:08:55.926218
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test for method map of class Lazy.
    """
    def fn(x):
        return x + 2

    def mapper(x):
        return x ** 3

    assert Lazy(fn).map(mapper).get(3) == 125



# Generated at 2022-06-21 19:08:59.601168
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def sum_two(x, y):
        return x + y

    assert Lazy(sum_two).ap(Lazy(1)).ap(Lazy(2)).get() == 3


# Generated at 2022-06-21 19:09:02.645112
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Unit test for method ap of class Lazy
    """
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)) == Lazy.of(3)



# Generated at 2022-06-21 19:09:12.350810
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def div(x: int, y: int) -> int:
        return x / y

    assert Lazy(lambda: div(4, 2)).to_try() == Try.of(lambda: div(4, 2))
    assert Lazy(lambda: div(4, 0)).to_try() == Try.of(lambda: div(4, 0))
    assert Lazy(lambda: div(4, None)).to_try(None) == Try.of(lambda: div(4, None), None)
    assert Lazy(lambda: div(4, '2')).to_try('2') == Try.of(lambda: div(4, '2'), '2')


# Generated at 2022-06-21 19:09:16.767461
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    inc = lambda x: x + 1
    lazy = Lazy(inc)

    assert lazy.__str__() == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(
        inc,
        None,
        False
    )


# Generated at 2022-06-21 19:09:21.437054
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda: 'str')) == 'Lazy[fn=<function <lambda> at 0x10cec5d90>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:09:36.697335
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def __eq__(first, second):
        assert first == second

    def __not_eq__(first, second):
        assert first != second

    add_3 = lambda x: x + 3
    const_1 = lambda *args: 1

    __eq__(Lazy(add_3), Lazy(add_3))
    __eq__(Lazy(const_1), Lazy(const_1))

    __not_eq__(Lazy(add_3), Lazy(const_1))
    __not_eq__(Lazy(const_1), Lazy(add_3))

    __not_eq__(Lazy(const_1), Lazy.of(1))

    __eq__(Lazy.of(add_3).get(), add_3)

# Generated at 2022-06-21 19:09:40.830631
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1).constructor_fn() == Lazy(lambda: 1).constructor_fn()
    assert Lazy(lambda: 1).constructor_fn() != Lazy(lambda: 2).constructor_fn()



# Generated at 2022-06-21 19:09:46.469545
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    maybe_A = Maybe.just(Lazy.of('A'))
    assert maybe_A.to_lazy().to_maybe() == Maybe.just('A')

    maybe_B = Maybe.nothing(Lazy.of('B'))
    assert maybe_B.to_lazy().to_maybe() == Maybe.nothing(Lazy.of('B'))



# Generated at 2022-06-21 19:09:52.906589
# Unit test for method map of class Lazy
def test_Lazy_map():
    """Unit test for method map of class Lazy"""
    assert Lazy.of('abcd').map(lambda x: x[1:]).get() == 'bcd'
    assert Lazy.of('abcd').map(lambda x: x[1:]).constructor_fn.__name__ == '<lambda>'



# Generated at 2022-06-21 19:09:58.457743
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def x(*args):
        return 4 / args[0]

    lazy = Lazy(x)

    result = lazy.to_try(4)
    assert isinstance(result, Try)
    assert result.get() == 1.0

    result = lazy.to_try(0)
    assert not result.is_success()
    assert result.get_error() == ZeroDivisionError


# Generated at 2022-06-21 19:10:01.308851
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    fn = lambda x: x * 2

    lazy = Lazy(fn)
    assert lazy.to_maybe(2) == Maybe.just(fn(2))

# Generated at 2022-06-21 19:10:06.243909
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Given
    def f(x):
        return x * 2

    fn = Lazy.of(f)
    one = Lazy.of(1)
    two = Lazy.of(2)

    # When
    result_one = one.ap(fn)
    result_two = two.ap(fn)

    # Then
    assert result_one.get() == 2
    assert result_two.get() == 4

# Generated at 2022-06-21 19:10:16.678460
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 5) == Lazy(lambda: 5)
    assert not Lazy(lambda: 6) == Lazy(lambda: 7)
    assert not Lazy(lambda: 5).map(lambda x: x + 1) == Lazy(lambda: 5)
    assert not Lazy(lambda: 7) == Lazy(lambda: 7).map(lambda x: x + 1)
    assert Lazy(lambda: 8).map(lambda x: x + 1) == Lazy(lambda: 7).map(lambda x: x + 1)

    def side_effect(a):
        print('First function was called')
        return a + 1

    def side_effect2(a):
        print('Second function was called')
        return a + 1

    assert not Lazy(side_effect) == Lazy(side_effect)

# Generated at 2022-06-21 19:10:25.193022
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Tests lazy map with two types of mappers:
    1) mapper which returns value with incremented value
    2) mapper which increments value
    """
    def mapper_with_incremented(arg):
        return arg + 1

    def mapper_which_increments(arg):
        return arg + 2

    def fn():
        return 1
    lazy_result = Lazy(fn)

    result_with_incremented = lazy_result.map(mapper_with_incremented)
    result_which_increments = lazy_result.map(mapper_which_increments)

    assert result_with_incremented._compute_value() == 2
    assert result_which_increments._compute_value() == 3


# Generated at 2022-06-21 19:10:28.169307
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(2).to_either() == Right(2)
    assert Lazy.of(2).to_either() == Lazy.of(2).to_either()

# Generated at 2022-06-21 19:10:47.386844
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """Unit tests for Lazy monad.

    Method bind returns new Lazy with constructor function equals to result of
    calling argument function with value from Lazy.
    Both functions were not called before calling fold method.
    """
    def add_one(number):
        return number + 1

    def check_four(number):
        from pymonet.maybe import Maybe

        if number == 4:
            return Maybe.just('four')

        return Maybe.nothing()

    def sub_one(number):
        return number - 1

    def double(number):
        return number * 2

    # unbox(Lazy(add_one).bind(check_four).bind(sub_one).bind(double)) == 8
    assert Lazy(add_one).bind(check_four).bind(sub_one).bind(double).get() == 8

   

# Generated at 2022-06-21 19:10:48.784721
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    boxLazy = Lazy(lambda: Box(1))
    assert boxLazy.to_box() == Box(Box(1))



# Generated at 2022-06-21 19:10:56.559966
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    lazy_five = Lazy.of(5)
    assert lazy_five.get() == 5
    print(lazy_five)
    assert str(lazy_five) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f8f6c0e1b00>, value=None, is_evaluated=False]'

    lazy_three = Lazy.of(3)
    lazy_three_plus_five = lazy_three.map(lambda x: x + 5)
    assert lazy_three_plus_five.get() == 8

    assert lazy_three_plus_five == lazy_three.map(lambda x: x + 5)


if __name__ == '__main__':  # pragma: no cover
    test_Lazy()

# Generated at 2022-06-21 19:11:07.009921
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def foo(a, b, c):
        if b == 3:
            raise ValueError('Not equal 3!')
        return a + b + c

    try_ok = Lazy(foo).to_try(1, 2, 3)
    assert try_ok.is_success() is True
    assert try_ok.get() == 6

    try_fail = Lazy(foo).to_try(1, 3, 3)
    assert try_fail.is_success() is False
    assert try_fail.get_exception() == 'Not equal 3!'

    try:
        try_fail.get()
    except ValueError as e:
        assert str(e) == 'Not equal 3!'



# Generated at 2022-06-21 19:11:10.410647
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def fn():
        return 'e'

    lazy = Lazy(fn)

    assert lazy.to_validation() == Validation.success('e')



# Generated at 2022-06-21 19:11:17.394525
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet import Lazy
    from pymonet.either import Left, Right

    def add(x, y):
        return x + y

    assert Lazy(add).ap(Lazy(lambda x: x * 10))

    assert Lazy(add).ap(Left("Error")) == Left("Error")

    assert Lazy(add).ap(Right(1)) == Lazy(lambda x: 1 + x)


# Generated at 2022-06-21 19:11:23.362747
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Call method map of class Lazy.
    """
    assert Lazy(lambda x: x * 2).map(lambda x: x / 2).get(5) == 5
    assert Lazy(lambda s: s + 'a').map(lambda s: s + 'b').get('c') == 'cab'
    assert (
        Lazy(lambda s: s + 'a')
            .map(lambda s: s + 'b')
            .map(lambda s: s + 'c')
            .map(lambda s: s + 'd')
            .get('start') == 'startabcd'
    )


# Generated at 2022-06-21 19:11:27.095958
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(5).to_box() == Box(5)
    assert Lazy(lambda: 5).to_box() == Box(5)


# Generated at 2022-06-21 19:11:33.217560
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy(lambda: 1).to_box() == Box(1)

    def fn(x):
        return x + 1

    assert Lazy(lambda: 1).to_box().map(fn) == Box(2)
    assert Lazy(lambda: 1).to_box().get() == 1
    assert Lazy(lambda: 1).to_box().to_try() == Try.success(1)
    assert isinstance(Lazy(lambda: 1).to_box(), Box)


# Generated at 2022-06-21 19:11:41.585615
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy(lambda: 1).to_maybe() == Lazy(lambda: 1).to_box() == Lazy(lambda: 1).to_either() == \
        Lazy(lambda: 1).to_try() == Lazy(lambda: 1).to_validation() == Maybe.just(1)
    assert Lazy(lambda: None).to_maybe() == Maybe.nothing()
    try:
        Lazy(lambda: 1 / 0).to_maybe()
        assert False
    except ZeroDivisionError:
        assert True



# Generated at 2022-06-21 19:11:51.505429
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    def func(*args):
        return 2 ** 2

    lazy: Lazy = Lazy(func)
    assert lazy.to_either() == Right(4)



# Generated at 2022-06-21 19:11:58.144332
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def func(error=False):
        if error:
            raise RuntimeError('Some error')
        return 'Some value'

    assert Try.success(Lazy.of(func()).to_try()) == Lazy.of(func()).to_try()
    assert Try.failure(Lazy.of(func(error=True)).to_try()) == Lazy.of(func(error=True)).to_try()


# Generated at 2022-06-21 19:12:03.584483
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    test_lazy = Lazy.of(42)
    assert str(test_lazy) == 'Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x7f0155f5a048>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:12:14.609432
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test for method get
    """
    class Lazy(Generic[T, U]):
        """
        Data type for storage any type of function.
        This function (and all his mappers) will be called only during calling fold method
        """

        def __init__(self, constructor_fn: Callable[[T], U]) -> None:
            """
            :param constructor_fn: function to call during fold method call
            :type constructor_fn: Function() -> A
            """
            self.constructor_fn = constructor_fn
            self.is_evaluated = False
            self.value = None


# Generated at 2022-06-21 19:12:17.973565
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    # arrange
    fn = lambda x: x + 1
    data = Lazy(fn)

    # act
    result = data.to_maybe(1)

    # assert
    assert result == Maybe.just(fn(1))



# Generated at 2022-06-21 19:12:24.420197
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(value):
        return Lazy(lambda: value * 2)

    def g(value):
        return Lazy(lambda: value + 3)

    lazy_1 = Lazy(lambda: 2).bind(f)
    assert lazy_1 == Lazy(lambda: 2 * 2)
    assert lazy_1.is_evaluated is False

    lazy_2 = lazy_1.bind(g)
    assert lazy_2 == Lazy(lambda: 2 * 2 + 3)
    assert lazy_2.is_evaluated is False

    assert lazy_2.get() == 7

    assert lazy_1.is_evaluated is True
    assert lazy_2.is_evaluated is True



# Generated at 2022-06-21 19:12:25.403840
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function():
        return 1

    assert Lazy(test_function).get() == 1


# Generated at 2022-06-21 19:12:34.210593
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def addToList(x):
        return [x]
    def concatList(x, y):
        return x + y

    assert Lazy.of(1).bind(lambda x: Lazy.of(addToList(x))).ap(Lazy.of(addToList(2))).get() == [1, 2]
    assert Lazy.of(1).bind(lambda x: Lazy.of(concatList(x, [2]))).ap(Lazy.of(addToList(3))).get() == [1, 3, 2]

test_Lazy_ap()

# Generated at 2022-06-21 19:12:40.081574
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.utils import always_false

    # GIVEN
    always_false_lazy = Lazy(always_false)

    # WHEN
    lazy_with_mapper = always_false_lazy.map(lambda x: not x)

    # THEN
    assert lazy_with_mapper.constructor_fn() is True


# Generated at 2022-06-21 19:12:42.528817
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy(lambda x: x).to_validation(1) == Validation.success(1)

# Generated at 2022-06-21 19:12:55.346839
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def divide(x, y):
        if y == 0:
            return None
        return x / y

    assert Lazy(lambda x, y: divide(x, y)).to_maybe(10, 0) == None
    assert Lazy(lambda x, y: divide(x, y)).to_maybe(10, 2) == 5


# Generated at 2022-06-21 19:12:59.432886
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def add(Lazy) -> Lazy:
        return Lazy.map(lambda s: s + 'b')

    lazy = Lazy.of('a')
    bind_lazy = lazy.bind(add)

    assert bind_lazy.get() == 'ab'



# Generated at 2022-06-21 19:13:03.676803
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy([1, 2, 3]).map(lambda x: x + 2) == Lazy([3, 4, 5])
    assert Lazy([1, 2, 3]).map(lambda x: x * 2) == Lazy([2, 4, 6])
    assert Lazy([1, 2, 3]).map(lambda x: x + 2).map(lambda x: x * 2) == Lazy([6, 8, 10])


# Generated at 2022-06-21 19:13:08.445274
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def fn(*args):
        if len(args) > 1:
            raise Exception('Too many arguments')
        return args[0]

    result = Lazy(fn).to_try('a')

    assert result == Try.success('a')

# Generated at 2022-06-21 19:13:16.570248
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from typing import Callable
    from pymonet.functor import Functor

    def fn(_):
        return 1

    assert str(Lazy.of(1)) == 'Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x7f3ddd8bb598>, value=None, is_evaluated=False]'
    msg = 'Lazy[fn={}, value={}, is_evaluated={}]'

    assert str(Lazy(fn)) == msg.format(fn, None, False)

    lazy = Lazy(fn)
    lazy._compute_value()
    assert str(lazy) == msg.format(fn, 1, True)


# Generated at 2022-06-21 19:13:22.197863
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def mul_fn(x: int) -> int:
        return x * 2

    lazy_with_function = Lazy(lambda x: mul_fn(x))

    result_of_to_maybe = lazy_with_function.to_maybe(2)

    assert isinstance(result_of_to_maybe, Maybe)
    assert result_of_to_maybe.get() == 4

# Generated at 2022-06-21 19:13:31.069744
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    """
    Unit test for method to_try of class Lazy
    """
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    value = 'some string'
    def constructor(*args):  # pylint: disable=unused-argument
        return value

    lazy = Lazy(constructor)

    assert Try.of(lambda: value) == lazy.to_try()
    assert Validation.success(value) == lazy.to_validation()



# Generated at 2022-06-21 19:13:33.252727
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(2).bind(lambda number: Lazy.of(number + 1)).get() == 3


# Generated at 2022-06-21 19:13:41.131269
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for method bind
    """
    import pytest

    def func(x):  # pylint: disable=unused-argument
        return Lazy.of(5)

    def func2(*args):  # pylint: disable=unused-argument
        return Lazy.of(7)

    result = Lazy(func).bind(func2).get()
    assert result == 7

    result = Lazy(func).bind(func2).get(1)
    assert result == 7

    # Folder not callable
    with pytest.raises(TypeError):
        Lazy(func).bind(None)

    result = Lazy(func).bind(func2).bind(func2).bind(func2).get()

    assert result == 7


# Generated at 2022-06-21 19:13:44.331610
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.box import Box

    assert Lazy(lambda: Box(1)).to_either() == Right(1)



# Generated at 2022-06-21 19:13:58.770635
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert (Lazy.of(1) == Lazy.of(1)) is True
    assert (Lazy.of(1) == Lazy.of(2)) is False
    assert (Lazy.of(1) == Lazy.of(1).map(lambda v: v + 1)) is False
    assert (Lazy.of(1) == Lazy.of(1).map(lambda v: v + 1).get()) is False
    assert (Lazy.of(1) == Lazy.of(1).map(lambda v: v + 1).map(lambda v: v - 1)) is True


# Generated at 2022-06-21 19:14:01.258560
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def return_value(*args):
        return args

    assert Lazy(return_value).to_try(True) == Try.success(True)



# Generated at 2022-06-21 19:14:05.542674
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for Lazy.bind method.
    """

    def fn(value):
        def mapper(v):
            return v * 2
        return Lazy(lambda *args: mapper(value)).map(lambda v: v * 4)

    a = Lazy(lambda x: x * 2)
    b = Lazy(lambda x: x * 4)
    assert a.bind(fn).get(3) == b.get(3)

# Generated at 2022-06-21 19:14:07.865599
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy(lambda x: x + 2).to_validation(4) == Validation.success(6)

# Generated at 2022-06-21 19:14:18.428054
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    import pytest

    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).to_box().map(lambda x: x + 2).get() == 4
    assert Lazy.of(Box(1)).map(lambda x: x + 1).to_box().map(lambda x: x + 2).get() == 4  # type: ignore

    with pytest.raises(Exception):
        assert Lazy.of(Box(1)).map(lambda x: x + 1).to_box()  # type: ignore



# Generated at 2022-06-21 19:14:26.209480
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    def test_method(message, lz):
        mb = lz.to_maybe()
        assert mb == Maybe.just(1), message

    lz = Lazy.of(1)
    test_method('__init__', lz)

    should_be_true = False

    def const(*args):
        global should_be_true
        assert not should_be_true, 'function should be evaluated only once'
        should_be_true = True
        return 1

    lz = Lazy(const)
    test_method('Lazy test', lz)

    lz = Lazy(lambda: 1)
    test_method('function test', lz)



# Generated at 2022-06-21 19:14:30.279477
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        def add_x(y):
            return x + y

        return add_x

    assert add(1) << Lazy.of(2) == Lazy.of(3)



# Generated at 2022-06-21 19:14:32.834477
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.monad_test_helpers import TestHelpersMixin
    TestHelpersMixin.test_to_either(Lazy)



# Generated at 2022-06-21 19:14:39.443144
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_try import Try

    try_instance = Try.of(int, 's')
    change_to_int_and_multiply = Lazy(lambda *args: int(args[0])).map(lambda number: number * 10)
    change_to_int_and_multiply_composed = compose(Lazy(lambda *args: int(args[0])), lambda number: number * 10)

    assert not try_instance.is_successful()
    assert change_to_int_and_multiply.get('5') == 50
    assert change_to_int_and_multiply.get('foo') == 500
    assert change_to_int_and_multiply_composed.get('5') == 50
    assert change_to_int_and_multiply_composed

# Generated at 2022-06-21 19:14:46.751366
# Unit test for constructor of class Lazy
def test_Lazy(): # pragma: no cover
    def some_fn(name):
        return 'Hello {}'.format(name)

    Lazy(some_fn).get('John') == Lazy(some_fn).to_box('John').get() == Lazy(some_fn).to_maybe('John').get() ==\
        Lazy(some_fn).to_try('John').get() == Lazy(some_fn).to_either('John').get() == Lazy(some_fn).to_validation('John').get()

# Generated at 2022-06-21 19:14:54.569118
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy(lambda: 'test').to_box() == Box('test')



# Generated at 2022-06-21 19:15:03.041090
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def my_add(a, b):
        return a + b

    def my_mul(a, b):
        return a * b

    lazy_adder = Lazy(my_add)
    lazy_multiplier = Lazy(my_mul)

    lazy_sum_multiplier_adder = lazy_adder.bind(lambda a: lazy_multiplier.bind(lambda b: Lazy.of(my_add(a, b))))
    assert lazy_sum_multiplier_adder.get(1, 2) == 5

    lazy_sum_multiplier_adder = lazy_adder.bind(lambda a: lazy_multiplier.bind(lambda b: Lazy.of(my_mul(a, b))))
    assert lazy_sum_multiplier_adder.get(1, 2) == 6

    lazy

# Generated at 2022-06-21 19:15:12.736615
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def function(n: int) -> int:
        return n*n

    def function_raising(n: int) -> int:
        raise ValueError('error')

    assert Lazy.of(1).to_try() is Try.of(Lazy.of(1).constructor_fn)

    assert Lazy(function_raising).to_try(1) is Try.of(function_raising, 1)

    assert Lazy(function).to_try(1) is Try.of(function, 1)


# Generated at 2022-06-21 19:15:16.254918
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test bind of Lazy.
    """
    lazy = Lazy(lambda *args: 'a')

    def fn(arg):
        return Lazy(lambda *args: arg + 'b')

    assert lazy.bind(fn).get() == 'ab'


# Generated at 2022-06-21 19:15:26.836131
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def raise_error():
        raise RuntimeError("Oops")

    assert Lazy(Lazy.of(1234)).to_try().is_success()
    assert Lazy(Lazy.of(1234)).to_try().get() == 1234
    assert Lazy(Lazy.of(1234)).to_try().get_or_else(4321) == 1234
    assert Lazy(raise_error).to_try().is_success() is False
    assert Lazy(raise_error).to_try().get() is None
    assert Lazy(raise_error).to_try().get_or_else(4321) == 4321
    assert Lazy(raise_error).to_try().exception().args == ('Oops',)



# Generated at 2022-06-21 19:15:31.575417
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    def test_function(x: int) -> str:
        return 'test'

    lazy_test = Lazy(test_function)
    assert(lazy_test.to_either(1) == Right('test'))



# Generated at 2022-06-21 19:15:34.893030
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def f(x):
        return x + 1

    lazy = Lazy(f)
    box = lazy.to_box(2)

    assert box.get() == 3


# Generated at 2022-06-21 19:15:37.010809
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:15:47.102402
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Lazy(lambda x: x) == Lazy(lambda x: x)
    assert Lazy(None) != Lazy(lambda x: None)
    assert Lazy(None) != Lazy(lambda x: 1)
    assert Lazy(lambda x: None) != Lazy(lambda x: 1)

    lazy = Lazy(lambda x: x)
    assert lazy.get(1) == 1
    assert lazy.get(None) is None
    assert lazy.get() is None

    lazy = Lazy(lambda x, y: x + y)
    assert lazy.get(1, 2) == 3
    assert lazy.get(None, None) is None
    assert lazy.get(None) is None


# Generated at 2022-06-21 19:15:52.133732
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Either

    is_left_called = False
    is_right_called = False

    def left_function():
        nonlocal is_left_called
        return is_left_called

    def right_function():
        nonlocal is_right_called
        return is_right_called

    assert Lazy(lambda: None).to_either() == Either.left(None)
    assert Lazy(lambda: left_function()).to_either() == Either.left(False)
    assert Lazy(lambda: right_function()).to_either() == Either.right(False)



# Generated at 2022-06-21 19:16:02.426527
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    def fn(arg):
        return True

    lazy = Lazy(fn)

    assert lazy.to_validation() == Validation.success(True)

# Generated at 2022-06-21 19:16:11.614129
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    bind allows us to apply some function to the value, resulting in a new Lazy.
    :return:
    """
    test_lazy = Lazy(lambda: True)
    assert test_lazy.is_evaluated is False, "The test_lazy varaible should not evaluated"

    new_lazy = test_lazy.bind(lambda x: Lazy(lambda: x))
    assert new_lazy.is_evaluated is True, "The new_lazy varaible should be evaluated"



# Generated at 2022-06-21 19:16:17.482206
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def square(number):
        return number * number

    def square_root(number):
        return math.sqrt(number)

    def half_of(number):
        return number / 2

    lazy_square = Lazy(square)
    lazy_square_root = Lazy(square_root)
    lazy_half_of = Lazy(half_of)

    assert lazy_square.get(5) == 25
    assert lazy_square_root.get(25) == 5

    lazy_half_of.bind(lazy_square).bind(lazy_square_root).get(2) == 1
    assert Lazy.of(2).bind(lazy_square).bind(lazy_square_root).get() == 1

# Generated at 2022-06-21 19:16:29.007136
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try

    assert Lazy.of(1).ap(Lazy.of(1)) == Lazy.of(1)
    assert Lazy.of(1).ap(Lazy.of(Lazy.of(1))) == Lazy.of(1)
    assert Lazy.of(Lazy.of(1)).ap(Lazy.of(1)) == Lazy.of(1)
    assert Lazy.of(Lazy.of(1)).ap(Lazy.of(Lazy.of(1))) == Lazy.of(1)
    assert Lazy.of(lambda x: x+1).ap(Lazy.of(1)) == Lazy.of(2)

# Generated at 2022-06-21 19:16:35.606735
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.function import Function
    from pymonet.box import Box

    lazy = Lazy(Function.identity())
    assert isinstance(lazy, Lazy), type(lazy)
    assert str(lazy) == "Lazy[fn=<pymonet.function.Identity object at 0x7f6cca3c6f28>, value=None, is_evaluated=False]"

    assert str(Lazy.of(Box("value"))) == "Lazy[fn=<function Identity.execute at 0x7f6cca0819d8>, value=None, is_evaluated=False]"



# Generated at 2022-06-21 19:16:43.349307
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy.of(1)) == 'Lazy[fn=<function <lambda> at 0x000001C1F3F3EBF8>, value=1, is_evaluated=True]'
    assert str(Lazy.of(1).map(lambda x: x + 1)) == 'Lazy[fn=<function <lambda> at 0x000001C1F9D2ABF8>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:16:47.553410
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def fn(x):
        return x

    lazy = Lazy(fn)
    assert str(lazy) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x7f9a44a02b70>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:16:55.275817
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right

    def fn(x):
        return Box(x + 2)

    def expected_result(x):
        return Right(4)

    # for tests coverage
    Lazy(lambda y: y + 2).bind(lambda x: x + 2) == 5

    assert Lazy(lambda y: y + 2).bind(fn) == expected_result(2)
    assert Lazy(lambda y: y + 2).bind(fn).fold(lambda x: x) == 4
    assert Lazy(lambda y: y + 2).bind(fn).fold(lambda x: x + 2) == 6



# Generated at 2022-06-21 19:17:05.029097
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """Test for class Lazy"""

    # Test for lazy of
    assert Lazy.of(1) == Lazy(lambda: 1)

    # Test for lazy of None
    assert Lazy.of(None) == Lazy(lambda: None)

    # Test for lazy of empty list
    assert Lazy.of([]) == Lazy(lambda: [])

    # Test for lazy of empty string
    assert Lazy.of('') == Lazy(lambda: '')

    # Test for lazy of empty tuple
    assert Lazy.of(()) == Lazy(lambda: ())

    # Test for lazy of empty set
    assert Lazy.of(set()) == Lazy(lambda: set())

    # Test for lazy of empty dict
    assert Lazy.of({}) == Lazy(lambda: {})


# Generated at 2022-06-21 19:17:06.988882
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x: x).get(3) == 3
    assert Lazy.of(3).get() == 3



# Generated at 2022-06-21 19:17:22.141053
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test(expected, actual):
        print(expected, '==', actual, '==>', expected == actual)

    test(Lazy(lambda: 1), Lazy(lambda: 1))
    test(Lazy(lambda: 1), Lazy(lambda _: 1))
    test(Lazy(lambda: 1), Lazy(lambda: 2))
    test(Lazy(lambda: 1), Lazy.of(1))
    test(Lazy(lambda: 1), None)
    test(Lazy(lambda: 1), 1)



# Generated at 2022-06-21 19:17:33.045522
# Unit test for constructor of class Lazy
def test_Lazy():
    class LazyTest:
        def test_get(self):
            assert Lazy(lambda x: x).get(3) == 3
            assert Lazy(lambda x: x)(3) == 3

        def test_map(self):
            assert Lazy(lambda x: x).map(lambda a: 3 * a).get(3) == 9

        def test_ap(self):
            assert Lazy(lambda x: lambda y: x + y).ap(Lazy.of(3)).get(4) == 7
            assert Lazy(lambda z: 3 * z).ap(Lazy(lambda x: x).ap(Lazy.of(3))).get(3) == 9

        def test_bind(self):
            assert Lazy(lambda x: x).bind(lambda x: Lazy.of(x + 3)).get(3)