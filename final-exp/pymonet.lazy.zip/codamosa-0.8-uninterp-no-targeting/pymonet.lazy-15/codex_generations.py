

# Generated at 2022-06-21 19:07:42.159159
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.validation import Validation
    from pymonet.box import Box

    assert Lazy.of(42).ap(Maybe.just(lambda x: x + 1)).get() == Maybe.just(43)
    assert Lazy.of(42).ap(Maybe.nothing()).get() == Maybe.nothing()
    assert Lazy.of(42).ap(Right(lambda x: x + 1)).get() == Right(43)
    assert Lazy.of(42).ap(Validation.success(lambda x: x + 1)).get() == Validation.success(43)
    assert Lazy.of(42).ap(Box(lambda x: x + 1)).get() == Box(43)



# Generated at 2022-06-21 19:07:47.429814
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def function(a):
        return a
    lazy = Lazy(function)
    assert str(lazy) == 'Lazy[fn=<function Lazy_test___str__.<locals>.function at 0x10a4e8a60>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:07:50.214924
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    """
    Checks Lazy.to_validation method of class Lazy.
    """

    from pymonet.validation import Validation

    lazy = Lazy.of(2)

    assert lazy.to_validation() == Validation.success(2)



# Generated at 2022-06-21 19:07:59.118343
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function <lambda> at 0x{:x}>, value=None, is_evaluated=False]'.format(
        id(lambda x: x))  # pragma: no cover
    assert str(Lazy(lambda x: x).map(lambda x: x)) == 'Lazy[fn=<function <lambda>.<locals>.<lambda> at 0x{:x}>, value=None, is_evaluated=False]'.format(
        id(lambda x: x))  # pragma: no cover


# Generated at 2022-06-21 19:08:01.937080
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def fn():
        raise ValueError

    assert Lazy.of(1).to_try().get_() == 1
    try:
        Lazy(fn).to_try()
    except:  # noqa
        pass
    else:
        assert False

# Generated at 2022-06-21 19:08:06.170238
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    # GIVEN
    lazy_string = Lazy.of('string')
    # WHEN
    validation = lazy_string.to_validation()
    # THEN
    assert isinstance(validation, Validation)
    assert validation.to_either().is_right()
    assert validation.to_either().get_or_else(None) == 'string'



# Generated at 2022-06-21 19:08:17.833262
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.maybe import Maybe

    def function_str(arg_str):
        return 'arg ' + arg_str

    lazy = Lazy(function_str)
    assert str(lazy) == "Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x7fabbbae09d8>, value=None, is_evaluated=False]"

    lazy2 = lazy.map(Maybe.just)
    assert str(lazy2) == "Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x7fabbbae0950>, value=None, is_evaluated=False]"

    lazy2.get('test')


# Generated at 2022-06-21 19:08:21.820590
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 2).bind(f).get() == 3
    assert Lazy(lambda: 2).bind(Lazy.of).get() == 2
    assert Lazy(lambda: "test").bind(f).get() == 'test'



# Generated at 2022-06-21 19:08:24.319065
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy(lambda: Left(1)).to_either() == Left(1)

# Generated at 2022-06-21 19:08:35.824379
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(a):
        return a + 1

    empty_lazy = Lazy(add_one)

    assert empty_lazy.bind(Lazy.of) == empty_lazy

    assert 1 == empty_lazy.bind(Lazy.of).get()
    assert 1 == empty_lazy.get()
    assert not empty_lazy.is_evaluated

    empty_lazy = Lazy(add_one)
    assert 1 == empty_lazy.bind(lambda x: Lazy.of(x + 1)).get()

    # lazy_pow = Lazy(lambda x: x ** 2)
    # assert 10 == lazy_pow.bind(lambda x: Lazy.of(add_one(x + 1))).get()
    # assert lazy_pow.value == 4

    lazy_p

# Generated at 2022-06-21 19:08:41.743280
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    # given
    def function(*args):
        return args[0] * args[1]

    # when
    lazy = Lazy(function).to_either()

    # then
    assert lazy.get(5, 1) == Right(5)



# Generated at 2022-06-21 19:08:46.267897
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.instance_helpers import unreachable

    assert Lazy.of(5).to_box() == Box(5)
    assert Lazy.of(Box(5)).to_box() == Box(Box(5))

    assert Lazy.of(unreachable).to_box() == Box(unreachable)


# Generated at 2022-06-21 19:08:48.596093
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(Right(1)).to_either() == Right(1)



# Generated at 2022-06-21 19:08:52.352840
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.validation import Validation

    assert Lazy.of(3).bind(lambda a: Validation.success(a + 2)) == Validation.success(5)



# Generated at 2022-06-21 19:08:56.393227
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    result = Lazy.of(42).to_validation()

    assert isinstance(result, Validation)
    assert result



# Generated at 2022-06-21 19:09:02.546286
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def get_lazy(dummy_input):
        return Lazy.of(dummy_input)

    assert Try.of(get_lazy, 42).get == 42

    def last_func(dummy_input):
        raise NotImplementedError()

    assert Try.of(last_func, 42).get == NotImplementedError


# Generated at 2022-06-21 19:09:09.372675
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Given:
    from pymonet.functor import Functor
    from pymonet.monad_maybe import Maybe

    def mapper(x: int) -> int:
        return x + 1

    functor = Functor.of(mapper)
    lazy = Lazy(lambda: Maybe.just(1))

    # When:
    result = lazy.ap(functor)

    # Then:
    assert result.get() == Maybe.just(2)


# Generated at 2022-06-21 19:09:10.691189
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of('foo').get() == 'foo'



# Generated at 2022-06-21 19:09:13.813199
# Unit test for method get of class Lazy
def test_Lazy_get():
    add_7 = lambda x: x + 7

    assert Lazy(add_7).get(10) == 17
    assert Lazy(add_7).get(11) == 18
    assert Lazy(add_7).get(12) == 19


# Generated at 2022-06-21 19:09:22.256100
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function <lambda> at 0x7f70d79bf950>, value=None, is_evaluated=False]'

    def _constructor_fn(*args):  # pragma: no cover
        return 1

    lazy = Lazy(_constructor_fn)
    lazy._compute_value(1)
    assert str(lazy) == 'Lazy[fn=<function _constructor_fn at 0x7f70d79bf950>, value=1, is_evaluated=True]'



# Generated at 2022-06-21 19:09:35.852507
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import pymonet.either
    import pymonet.validation
    import pymonet.box

    add = lambda x: Lazy.of(lambda y: x + y).to_box()

    assert pymonet.box.Box(1).ap(add(2)).to_either() == pymonet.either.Right(3)
    assert Lazy.of(1).ap(add(2)).get() == 3
    assert Lazy.of(1).ap(add(2)).to_maybe().get() == 3
    assert Lazy.of(1).ap(add(2)).to_validation().get_or_else(0) == 3
    assert Lazy.of(1).ap(add(2)).to_box().get_or_else(0) == 3

# Generated at 2022-06-21 19:09:43.797719
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def _test(fn1, fn2, expected_output):
        assert (Lazy(fn1) == Lazy(fn2)) == expected_output

    _test(lambda: 1, lambda: 1, True)
    _test(lambda: 1, lambda: 2, False)
    _test(lambda x: x, lambda: 3, False)
    _test(lambda: 3, lambda x: x, False)
    _test(lambda x: x, lambda x: x, True)



# Generated at 2022-06-21 19:09:48.472706
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(2).to_either() == Right(2)
    assert Lazy.of(lambda x: x + 1).to_either(1) == Right(2)
    assert Lazy.of(lambda x, y: x + y).to_either(1, 2) == Right(3)



# Generated at 2022-06-21 19:09:55.074412
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    """
    Test for method to_box of class Lazy.
    """
    from pymonet.box import Box

    def f(_str):
        return Lazy.of('foo')

    assert Lazy(f).to_box('foo') == Box('foo')
    assert Lazy(f).map(lambda _str: 'bar').to_box('foo') == Box('bar')


# Generated at 2022-06-21 19:10:01.789831
# Unit test for method get of class Lazy
def test_Lazy_get():

    from nose.tools import assert_equals, assert_true, assert_false

    def test_fn():
        test_fn.counter += 1
        return 1

    test_fn.counter = 0

    assert_equals(Lazy(test_fn).get(), 1)
    assert_equals(test_fn.counter, 1)
    assert_equals(Lazy(test_fn).get(1), 1)
    assert_equals(test_fn.counter, 2)
    assert_equals(Lazy(test_fn).get(), 1)
    assert_equals(test_fn.counter, 3)



# Generated at 2022-06-21 19:10:03.967338
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def test_method(a: int) -> int:
        return a + 5

    assert 'Lazy[fn=<function test_method at 0x10b7f51e0>, value=None, is_evaluated=False]' == str(Lazy(test_method))



# Generated at 2022-06-21 19:10:10.940298
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    lazy = Lazy.of(2)
    assert lazy.ap(Lazy.of(lambda x: x + 5)) == Lazy.of(7)
    assert lazy.ap(Lazy.of(lambda x: x * 5)) == Lazy.of(10)
    assert lazy.ap(Maybe.just(lambda x: x + 5)) == Lazy.of(7)
    assert lazy.ap(Maybe.just(lambda x: x * 5)) == Lazy.of(10)
    assert lazy.ap(Try.of(lambda x: x + 5)) == Lazy.of(7)

# Generated at 2022-06-21 19:10:16.879358
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def add(a):
        def sum(b):
            return a + b

        return Lazy(sum)

    assert add(1).to_maybe(2) == Maybe.just(3)
    assert add(1).to_maybe(None) == Maybe.nothing()



# Generated at 2022-06-21 19:10:22.774969
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from expect import expect

    def fn(a: int) -> int:
        return a * 2

    new_lazy = Lazy.of(8)
    expect(new_lazy.get()).to_equal(8)

    new_lazy = Lazy(fn)
    expect(new_lazy.get(4)).to_equal(8)
    expect(new_lazy.is_evaluated).to_be_true()

# Generated at 2022-06-21 19:10:24.582641
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)



# Generated at 2022-06-21 19:10:29.194256
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2



# Generated at 2022-06-21 19:10:34.711673
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def hello_world(): return 'hello world'

    assert str(Lazy(hello_world)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.hello_world at 0x0000020B5E665268>, value=None, is_evaluated=False]'  # NOQA


# Generated at 2022-06-21 19:10:41.138314
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy.of('abc').to_maybe() == Maybe.just('abc')
    assert Lazy.of((1, 2, 3)).to_maybe() == Maybe.just((1, 2, 3))
    assert Lazy.of('abc').to_maybe(1) == Maybe.just('abc')
    assert Lazy.of((1, 2, 3)).to_maybe(1) == Maybe.just((1, 2, 3))
    assert Lazy.of('abc').to_maybe(1, 2, 3) == Maybe.just('abc')
    assert Lazy.of((1, 2, 3)).to_

# Generated at 2022-06-21 19:10:50.590012
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    """
    Testing Lazy class constructor.
    """
    value = 4
    lazy = Lazy.of(value)

    assert(str(lazy) == 'Lazy[fn=<function Lazy.<lambda>.<locals>.<lambda> at 0x7fd5d5bba6a8>, value=None, is_evaluated=False]')
    assert(lazy.is_evaluated == False)
    assert(lazy.value == None)

    assert(lazy.get() == value)
    assert(lazy.is_evaluated == True)
    assert(lazy.value == value)


# Generated at 2022-06-21 19:10:52.326570
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.functor import Functor

    class LazyFunctor(Lazy[int, str], Functor):
        pass

    LazyFunctor('X').get(1) == 'X'



# Generated at 2022-06-21 19:10:54.077240
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(1) == Lazy(lambda: 1)


# Generated at 2022-06-21 19:10:59.081177
# Unit test for method get of class Lazy
def test_Lazy_get():
    def some_function_to_call_in_future(x, y):
        return x + y

    lazy_result = Lazy.of(some_function_to_call_in_future).bind(lambda fn: Lazy.of(fn(1, 2)))

    assert lazy_result.get() == 3



# Generated at 2022-06-21 19:11:11.151008
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Unit testing method Lazy.to_try

    :return: nothing
    """
    from pymonet.monad_try import Failure

    assert Lazy(lambda: 1).to_try() == Lazy(lambda: 1).get()
    assert Lazy(lambda: None).to_try() == Lazy(lambda: None).get()
    assert Lazy(lambda: ()).to_try() == Lazy(lambda: ()).get()

    assert Lazy(lambda: (1, 2)).to_try() == Lazy(lambda: (1, 2)).get()
    assert Lazy(lambda: [1, 2]).to_try() == Lazy(lambda: [1, 2]).get()

# Generated at 2022-06-21 19:11:21.388682
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert Lazy(lambda *args: 1).__str__() == 'Lazy[fn=<function <lambda> at 0x10c6e47b8>, value=None, is_evaluated=False]'
    assert Lazy(lambda *args: 1).get() == 1
    assert Lazy(lambda *args: 1).__str__() == 'Lazy[fn=<function <lambda> at 0x10c6e47b8>, value=1, is_evaluated=True]'

    def f(x):
        return x

    assert Lazy(f).__str__() == 'Lazy[fn=<function f at 0x10c6e4320>, value=None, is_evaluated=False]'
    assert Lazy(f).get() == f
    assert Lazy(f).__str__

# Generated at 2022-06-21 19:11:28.914077
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<function Lazy.<locals>.<lambda>.<locals>.<lambda> at 0x7f2f202bcbf8>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: 1)._compute_value()) == 'Lazy[fn=<function Lazy.<locals>.<lambda>.<locals>.<lambda> at 0x7f2f202bcbf8>, value=1, is_evaluated=True]'


# Generated at 2022-06-21 19:11:45.273296
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def some_fn_1():
        pass

    def some_fn_2():
        pass

    lazy_1 = Lazy(some_fn_1)
    assert str(lazy_1) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(some_fn_1, None, False)

    lazy_1._compute_value()

    assert str(lazy_1) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(some_fn_1, None, True)

    lazy_2 = Lazy(some_fn_2)
    assert str(lazy_2) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(some_fn_2, None, False)



# Generated at 2022-06-21 19:11:56.206027
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.box import Box

    def get_increment_fn():
        def increment_fn(value):
            return value + 1

        return increment_fn

    def get_sum_fn():
        def sum_fn(first, second):
            return first + second

        return sum_fn

    lazy = Lazy(get_sum_fn())
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    # another way to call function stored in Lazy
    assert lazy.bind(get_increment_fn()).get() == 4
    assert lazy.bind(get_increment_fn()).get() == 4

    # Lazy are immutable
    assert lazy.map(get_increment_fn()) == Lazy(lambda: 4)
   

# Generated at 2022-06-21 19:12:00.241512
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 2).ap(Lazy.of(1)) == Lazy.of(3)

# Generated at 2022-06-21 19:12:08.163752
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(5).map(lambda x: x+1) == Lazy(lambda: 6)
    assert Lazy.of(5).map(lambda x: x+1).get() == 6
    assert Lazy.of(5).map(lambda x: x+1).get(6) == 6
    assert Lazy.of(6).map(lambda x: x+1) != Lazy.of(6).map(lambda x: x)
    assert Lazy.of(5).map(lambda x: x+1) != Lazy.of(6).map(lambda x: x+1)


# Generated at 2022-06-21 19:12:10.802730
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    def constructor_fn(a):
        return a

    lazy = Lazy(constructor_fn)
    assert lazy.to_box(2).get() == 2



# Generated at 2022-06-21 19:12:14.804843
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def create_lazy():
        return Lazy(lambda: 1)

    assert create_lazy().to_box() == Box(1)



# Generated at 2022-06-21 19:12:23.298803
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from copy import copy

    from pymonet.validation import Validation

    # Example how to use bind method
    lazy_numbers = Lazy(lambda: [1, 2, 3])
    lazy_summ = Lazy(lambda nums: sum(nums))

    def bind_sum_lazy_numbers_lazy(lazy_nums: Lazy[None, list]) -> Lazy[None, int]:
        return lazy_nums.bind(lambda nums: lazy_summ.map(lambda s: s * 2)).map(lambda s: 3)

    result = bind_sum_lazy_numbers_lazy(lazy_numbers)
    assert result.get() == 18

    lazy_numbers_copy = copy(lazy_numbers)
    assert result == bind_sum_lazy_numbers

# Generated at 2022-06-21 19:12:31.049631
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    lazy = Lazy(lambda *args: 10)
    assert str(lazy) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x000001B5C7175EA0>, value=None, is_evaluated=False]'

    lazy._compute_value()
    assert str(lazy) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x000001B5C7175EA0>, value=10, is_evaluated=True]'


# Generated at 2022-06-21 19:12:42.625914
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def f1(x: int) -> float:
        return 3.0 / x

    def f2(x: float) -> int:
        return int(x)

    def f3(x: int) -> str:
        return '{} {!r}'.format(x, x)

    def f4(x: str) -> str:
        return x.replace('{', '(').replace('}', ')')

    lazy = Lazy(f1).map(f2).map(f3).map(f4)
    assert lazy.get(3) == '1 \'1\''

    assert Lazy.of(1).get() == 1
    assert Lazy.of(f1).bind(lambda x: Lazy.of(x(5.0))).get() == 1.5



# Generated at 2022-06-21 19:12:49.766158
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left
    from pymonet.either import Right

    def fn():
        raise Exception('exception')

    assert Lazy.of(Right(1)).to_either() == Lazy.of(Right(1)).get()
    assert Lazy.of(Left(1)).to_either() == Lazy.of(Left(1)).get()
    assert Lazy(fn).to_either() == Try.of(fn).to_either()

# Generated at 2022-06-21 19:13:03.087372
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.monad import assert_equal
    from pymonet.utils import identity

    assert_equal(Lazy(lambda i: i ** 2).get(2), 4)
    assert_equal(Lazy(identity).get(2), 2)
    assert_equal(Lazy(identity).bind(Lazy.of).get(2), 2)
    assert_equal(Lazy(identity).map(lambda i: i ** 2).get(2), 4)
    assert_equal(Lazy(identity).ap(Lazy(lambda i: i ** 2)).get(2), 4)
    try:
        Lazy(lambda i: j).get()
    except:
        pass
    else:
        assert False


# Generated at 2022-06-21 19:13:07.251441
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x: x + 2).get(2) == 4
    assert Lazy.of(4).get(2) == 4
    assert Lazy(lambda x, y: x + y).get(3, 2) == 5



# Generated at 2022-06-21 19:13:13.381712
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def test_fn(a: int, b: int) -> int:
        return a + b

    _lazy = Lazy(test_fn)
    _maybe = _lazy.to_maybe(4, 8)

    assert isinstance(_maybe, Maybe)
    assert _maybe.is_present()
    assert _maybe.get_or_else(lambda: None) == 12


# Generated at 2022-06-21 19:13:18.301360
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def function(a):
        if a:
            return a
        raise Exception('Error')

    assert Lazy(function).to_try(1) == Try.of(function, 1)
    assert Lazy(function).to_try(0) == Try.of(function, 0)


# Generated at 2022-06-21 19:13:25.714836
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    import pytest

    def test_function(arg1, arg2, arg3):
        return arg1 + arg2 + arg3

    lazy = Lazy(test_function)

    assert lazy.constructor_fn(1, 2, 3) == 6
    assert lazy.get(1, 2, 3) == 6

    lazy_empty = Lazy.of(1)
    assert lazy_empty.constructor_fn() == 1
    assert lazy_empty.get() == 1

    lazy_empty = Lazy.of(1)
    assert lazy_empty.constructor_fn() == 1
    assert lazy_empty.get() == 1
    assert lazy_empty.get() == 1

    assert Lazy.of(4).to_box().get() == 4
    assert Lazy.of(1).to_

# Generated at 2022-06-21 19:13:33.253001
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    x = Lazy(lambda: 1)
    assert x.bind(lambda x: Box(x)).get() == 1

    assert x.bind(lambda _: Box(2)).get() == 2

    x = Lazy(lambda: None)
    assert x.bind(lambda x: Box(x)).get() is None

    assert x.bind(lambda _: Box(2)).get() == 2



# Generated at 2022-06-21 19:13:41.980471
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.maybe import Maybe

    a = Lazy(lambda: 1).map(lambda v: v + 1)
    b = Lazy(lambda: 1).map(lambda v: v + 1)
    c = Lazy(lambda: 1).map(lambda v: v + 2)
    d = Lazy(lambda: 2).map(lambda v: v + 1)
    e = Lazy(lambda: Maybe.just(1)).map(lambda v: v + 1)
    f = Lazy(lambda: Maybe.just(1)).map(lambda v: v + 1)
    g = Lazy(lambda: Maybe.just(1)).map(lambda v: v + 2)
    h = Lazy(lambda: Maybe.just(2)).map(lambda v: v + 1)

    assert a == b
    assert a != c
   

# Generated at 2022-06-21 19:13:53.222509
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """Test ap method of Lazy class"""
    from pymonet.random import Random
    from pymonet.operators import Lazy as L
    from pymonet.operators import Lazy as LazyOperators

    def generate_number() -> int:
        return Random().number().get()

    def multiply_by_two(number: int) -> int:
        return number * 2

    def subtract(x: int, y: int) -> int:
        return x - y

    lazy_subtrahend = Lazy(lambda : 10)

    lazy_subtract = lazy_subtrahend.map(subtract)
    lazy_subtract = LazyOperators.map2(lazy_subtract, Lazy.of(100))

    lazy_number = Lazy(generate_number)

    lazy_multip

# Generated at 2022-06-21 19:13:58.191427
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def f(*args):
        return args[0]

    value = 'test'
    vl = Lazy(f).to_validation(value)

    assert isinstance(vl, Validation)
    assert vl.is_success()
    assert vl.get_value() == value



# Generated at 2022-06-21 19:13:59.375676
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda x: x + 1).constructor_fn(1) == 2

# Generated at 2022-06-21 19:14:05.837455
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(lambda x: x * 2).bind(lambda x: Lazy(lambda: x(2))).get() == 4


# Generated at 2022-06-21 19:14:09.215629
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.monad_test import _to_maybe as to_maybe
    from pymonet.either import Right
    from pymonet.failure import Failure

    def fn():
        return 10

    def check_fn():
        return Right(10).to_maybe()

    assert Lazy(fn).to_maybe() == check_fn()
    assert Failure(None).to_maybe() == check_fn()

# Generated at 2022-06-21 19:14:13.005165
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def mapper(x):
        return x + 1

    assert Lazy(lambda: 5).map(mapper).get() == 6



# Generated at 2022-06-21 19:14:23.517056
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def add5(x):
        return x + 5

    def cube(x):
        return x ** 3

    assert Lazy.of(2).ap(Lazy.of(add5)).get() == 7
    assert Lazy.of(2).map(add5).ap(Lazy.of(cube)).get() == 125
    assert Lazy.of(2).ap(Box.of(add5)).to_box().get() == 7
    assert Lazy.of(2).map(add5).ap(Box.of(cube)).to_box().get() == 125

# Generated at 2022-06-21 19:14:26.455795
# Unit test for constructor of class Lazy
def test_Lazy():
    def fn(*args):
        return 'fn_result'

    assert Lazy(fn).get() == 'fn_result'

# -----------------------------

# Generated at 2022-06-21 19:14:36.131254
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pylint: disable=missing-function-docstring
    assert Lazy.of(2).map(lambda x: x + 1) == Lazy.of(3).map(lambda x: x - 1)
    assert Lazy.of(2).map(lambda x: x + 1) != Lazy.of(3).map(lambda x: x - 2)
    assert Lazy.of(10).map(lambda x: x + 1) == Lazy.of(10).map(lambda x: x + 1)
    assert Lazy.of(10).map(lambda x: x + 1) != Lazy.of(10).map(lambda x: x + 2)
    assert Lazy.of(10).map(lambda x: x + 1) != Lazy.of(10).get()
    assert Lazy.of(10) == Lazy

# Generated at 2022-06-21 19:14:39.943983
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    assert Lazy(lambda: 1).to_either() == Right(1)
    assert Lazy(lambda: Left(1)).to_either() == Left(1)

# Generated at 2022-06-21 19:14:47.982151
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    class MyLazy(Lazy, Functor[T, U], Monad[U]):
        pass

    my_lazy = MyLazy(lambda n: n * 2)
    assert my_lazy.map(lambda n: n + 2).get(10) == 22

    my_lazy2 = MyLazy(lambda n: n * 2)
    assert my_lazy2.map(lambda n: n + 2).get(10) == 22



# Generated at 2022-06-21 19:14:52.675639
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    import pytest

    from pymonet.either import Right
    from pymonet.validation import Validation

    def fn(a, b):
        return a / b

    with pytest.raises(ZeroDivisionError):
        assert Lazy(fn).to_validation(1, 0) == Validation.success(1 / 0)

# Generated at 2022-06-21 19:14:55.081557
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    assert Lazy(lambda x: 2*x).ap(Lazy(lambda x: x+6)) == Lazy(lambda x: 8+x)


# Generated at 2022-06-21 19:15:06.509686
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # prepare two lazy
    lazy1 = Lazy(lambda x, y: Validation.success(x + y))
    lazy2 = Lazy(lambda x, y: Validation.success(x + y))
    lazy3 = Lazy(lambda x, y: Validation.success(x + y))
    lazy4 = Lazy(lambda x, y: Validation.success(x + y))
    lazy5 = Lazy(lambda x, y: Validation.success(x + y))
    lazy6 = Lazy(lambda x, y: Try.of(lambda x: x, 'a'))

    # test with method of
    assert Lazy.of(2) == Lazy.of(2)

# Generated at 2022-06-21 19:15:14.197550
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    def add_4(number):
        return number + 4

    def multiply_by_3(number):
        return number * 3

    def multiply(x, y):
        return x * y

    lazy = Lazy.of(2)
    lazy_func = Lazy.of(add_4)

    assert Lazy.of(6) == lazy.ap(lazy_func)
    assert Lazy.of(6) == Lazy.of(multiply).ap(lazy).ap(lazy_func)

# Generated at 2022-06-21 19:15:18.806077
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    """
    Simple test for method to_maybe of class Lazy
    """
    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy.of('a').to_maybe() == Maybe.just('a')
    assert (
        Lazy.of(lambda: 1 / 0).to_maybe() == Maybe.nothing()
    )
    assert (
        Lazy.of(lambda: 'abc'[9]).to_maybe() == Maybe.nothing()
    )

# Generated at 2022-06-21 19:15:22.648116
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def func_generator(a):
        return a

    either_of_lazy = Lazy(func_generator).to_either(1)

    assert either_of_lazy == Right(1)


# Generated at 2022-06-21 19:15:30.672845
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def f(a):
        if a == 0:
            raise ValueError('a is 0')
        return a

    def g(e):
        return 'a is 0'

    assert Lazy(lambda: f(0)).to_try() == Try.failure(ValueError('a is 0'))
    assert Lazy(lambda: f(1)).to_try() == Try.success(1)
    assert Lazy(lambda: f(0)).to_try(g).to_maybe() == Maybe.just('a is 0')
    assert Lazy(lambda: f(1)).to_try(g).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 19:15:36.840394
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    result = Lazy.of(lambda: 1).to_try()
    assert result == Try.success(1)
    result = Lazy.of(lambda: 1 / 0).to_try()
    assert isinstance(result, Try)
    assert result.is_failure()
    assert result.get_error() is ZeroDivisionError
    assert result.get_value() is None


# Generated at 2022-06-21 19:15:46.883006
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add1(number):
        return number + 1

    def add2(number):
        return number + 2

    def add3(number):
        return number + 3

    assert Lazy.of(1).map(add1).get() == 2
    assert Lazy.of(1).map(add1).map(add2).get() == 3
    assert Lazy.of(1).map(add1).map(add2).map(add3).get() == 4

    assert Lazy.of(1).map(add1).to_box().get() == 2

# Generated at 2022-06-21 19:15:49.467447
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    assert Lazy(lambda: 1).to_either() == Right(1)
    assert Lazy(lambda: Left(1)).to_either() == Left(1)


# Generated at 2022-06-21 19:15:50.865015
# Unit test for constructor of class Lazy
def test_Lazy():
    foo = lambda: 0
    assert Lazy(foo).constructor_fn == foo



# Generated at 2022-06-21 19:16:00.992027
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try

    LazyTry = Lazy[int, Callable[[int], Try[int]]]

    success_try = LazyTry(lambda x: Try(lambda: x*2)).map(lambda x: Try(lambda: x + 2)).ap(LazyTry(lambda x: Try(lambda: x+2)))
    assert 4 == success_try.constructor_fn(1).get()

    failure_try = LazyTry(lambda x: Try(lambda: x*2)).ap(LazyTry(lambda x: Try(lambda: x/0)))
    assert ZeroDivisionError == failure_try.constructor_fn().get_exception().__class__



# Generated at 2022-06-21 19:16:16.904052
# Unit test for method get of class Lazy
def test_Lazy_get():
    # pylint: disable=invalid-name

    def test_lazy_get_returns_expected_value():
        lazy = Lazy.of(1)
        assert lazy.get() == 1

    def test_lazy_get_returns_expected_value_when_mapper_used():
        lazy = Lazy.of(1).map(lambda value: value * value)
        assert lazy.get() == 1

    def test_lazy_get_returns_expected_value_when_ap_and_mapper_used():
        lazy = Lazy.of(1).map(lambda value: value * value).ap(Lazy.of(2))
        assert lazy.get() == 2


# Generated at 2022-06-21 19:16:21.223515
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(10).to_box() == Box(10)
    assert Lazy.of(None).to_box() == Box(None)
    assert Lazy.of('test').to_box() == Box('test')


# Generated at 2022-06-21 19:16:31.580870
# Unit test for constructor of class Lazy
def test_Lazy():
    import pytest

    def _test_eq():
        with pytest.raises(AttributeError):
            Lazy.of('') == None

        assert Lazy.of('') == Lazy.of('')

        assert not Lazy.of('') == Lazy.of('1')

        assert not Lazy.of('') == Lazy(lambda: '')

        assert not Lazy(lambda: '') == Lazy.of('')

    def _test_get():
        assert Lazy(lambda: 1).get() == 1
        assert Lazy(lambda arg: arg).get(1) == 1
        assert Lazy(lambda arg1, arg2: arg2).get('a', 'b') == 'b'

# Generated at 2022-06-21 19:16:37.503328
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    assert Lazy(lambda: Box.of(1)).ap(Lazy(lambda: lambda x: x * 2)).get() == Lazy(lambda: Box.of(2)).get()
    assert Lazy(lambda: lambda x: x * 2).ap(Lazy(lambda: Box.of(1))).get() == Lazy(lambda: Box.of(2)).get()
    assert Lazy(lambda: Box.of(lambda x: x * 2)).ap(Lazy(lambda: Box.of(1))).get() == Lazy(lambda: Box.of(2)).get()



# Generated at 2022-06-21 19:16:40.301637
# Unit test for method get of class Lazy
def test_Lazy_get():
    def sum(x, y):
        return x + y

    assert Lazy.of(2).get() == 2
    assert Lazy.of(2).map(sum).get(1) == 3



# Generated at 2022-06-21 19:16:46.294453
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def sum(a, b):
        return a + b

    def mul(a, b):
        return a * b

    lazy_sum = Lazy(sum)
    lazy_mul = Lazy(mul)
    assert lazy_sum.get(1, 2) == 3
    assert lazy_mul.get(3, 4) == 12


# Generated at 2022-06-21 19:16:53.728063
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(1).to_box() is Box(1)
    assert Lazy.of(1).map(lambda x: x + 1).to_box() is Box(2)
    assert Lazy.of(1).map(lambda x: x + 1).ap(Lazy.of(lambda x: x * 3)).to_box() is Box(6)
    assert Lazy.of(1).map(lambda x: x + 1).bind(lambda x: Lazy.of(x * 3)).to_box() is Box(6)



# Generated at 2022-06-21 19:17:01.328095
# Unit test for method map of class Lazy
def test_Lazy_map():
    first_lazy = Lazy(lambda x: x + 1).map(lambda x: x + 2)
    assert first_lazy.constructor_fn(2) == 5

    second_lazy = Lazy(lambda x: x + 1)
    other_lazy = second_lazy.map(lambda x: x + 2).map(lambda x: x + 2)
    assert other_lazy.constructor_fn(2) == 7

    third_lazy = Lazy(lambda x, y: x + 1 + y).map(lambda x: x + 2)
    assert third_lazy.constructor_fn(2, 3) == 8


# Generated at 2022-06-21 19:17:04.084482
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(4).to_validation() == Validation.success(4)

# Generated at 2022-06-21 19:17:08.275502
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.identity import Identity

    lazy = Lazy.of(Right(2))

    assert(lazy.to_either() == Right(Right(2)))

    lazy = Lazy.of(Identity(Right(2)))

    assert(lazy.to_either() == Right(Right(2)))

# Generated at 2022-06-21 19:17:21.197474
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left
    from pymonet.either import Right

    assert Left(1).to_either() == Right(1)
    assert Lazy(lambda: 1).to_either() == Right(1)
    assert Lazy(lambda: Left(1)).to_either() == Right(1)
    assert Lazy(lambda: Right(1)).to_either() == Right(1)


# Generated at 2022-06-21 19:17:23.385533
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy.of(2).bind(lambda x: Box(x + 2)).unbox() == 4



# Generated at 2022-06-21 19:17:28.340568
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    # Lazy with only one argument
    def upper(value):
        return (value * 2).upper()

    lazy_upper = Lazy(upper)

    assert lazy_upper.get(1) == '2'.upper()

