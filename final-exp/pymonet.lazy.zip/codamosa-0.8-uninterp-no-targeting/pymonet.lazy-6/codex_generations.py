

# Generated at 2022-06-21 19:07:31.704335
# Unit test for method get of class Lazy
def test_Lazy_get():
    def cons_fn():
        return 5

    lazy = Lazy(cons_fn)
    assert lazy.get() == 5


# Generated at 2022-06-21 19:07:36.747571
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Lazy.of(10).to_maybe() == Maybe.just(10)
    assert Lazy.of(Box(10)).to_maybe() == Maybe.just(10)

# Generated at 2022-06-21 19:07:38.764379
# Unit test for constructor of class Lazy
def test_Lazy():
    l = Lazy.of(10)

    assert l._compute_value(1) == 10


# Generated at 2022-06-21 19:07:43.922862
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.box import Box

    result = Lazy.of(20).ap(Lazy.of(lambda x: x * 2))
    assert result.get() == 40

    result = Lazy.of(lambda x: x * 2).ap(Box(20))
    assert result.get() == 40

# Generated at 2022-06-21 19:07:55.622939
# Unit test for method to_try of class Lazy
def test_Lazy_to_try(): # pragma: no cover
    def constructor_fn(x, y):
        print('constructor_fn called')
        return x + y

    lazy = Lazy(constructor_fn)

    assert lazy.is_evaluated == False
    assert lazy.get(5, 10).is_success() == True
    assert lazy.get(5, 10).get_or('error') == 15

    assert lazy.is_evaluated == True
    assert lazy.get(6, 10).is_success() == True
    assert lazy.get(6, 10).get_or('error') == 16

    assert lazy.get(6, 10).map(lambda x: x * 2).is_success() == True
    assert lazy.get(6, 10).map(lambda x: x * 2).get_or('error') == 32


# Generated at 2022-06-21 19:07:58.723322
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy(lambda: "value").to_validation() == Validation.success("value") # type: ignore

# Generated at 2022-06-21 19:08:07.155580
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    add_2_lazy = Lazy(lambda value: value + 2)
    add_2_lazy_wrong_type = Lazy(lambda value: value + 2)

    try_add_2_lazy = add_2_lazy.to_try(2)

    assert Try.is_success(try_add_2_lazy)

    assert 4 == try_add_2_lazy.get()
    assert 4 == try_add_2_lazy.get_or_else(None)

    try_add_2_lazy_wrong_type = add_2_lazy_wrong_type.to_try('two')

    assert Try.is_failure(try_add_2_lazy_wrong_type)


# Generated at 2022-06-21 19:08:08.087769
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(3).get(None) == 3



# Generated at 2022-06-21 19:08:18.968838
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    import sys

    def _function(*args):
        return 10

    # Empty Lazy -> Success Try
    lazy = Lazy(_function)
    assert lazy.to_try() == Try.success(10)

    def _exception_function(*args):
        raise ZeroDivisionError()

    # Lazy with exception -> Failure Try
    exception_lazy = Lazy(_exception_function)
    assert exception_lazy.to_try() == Try.failure(ZeroDivisionError)

    # Lazy with exception -> Failure Try
    exception_lazy = Lazy(_exception_function)

    try:
        exception_lazy.get()
        assert False
    except ZeroDivisionError:
        assert True
    finally:
        sys.last_type = None

    #

# Generated at 2022-06-21 19:08:24.180288
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Test Lazy.to_try() method.
    """
    from pymonet.monad_try import Try

    to_raise = Lazy(lambda: 1 / 0)
    to_not_raise = Lazy(lambda: 1)

    assert to_raise.to_try() == Try.failure(ZeroDivisionError())
    assert to_not_raise.to_try() == Try.success(1)

assert test_Lazy_to_try() is None

# Generated at 2022-06-21 19:08:37.570480
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def add(x: int, y: int) -> int:
        return x + y

    def raise_exception():
        raise Exception('exception')

    assert Lazy.of(1).map(new_x=lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(new_x=lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(new_x=add, new_y=lambda y: 2).get() == 3

# Generated at 2022-06-21 19:08:38.984007
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda x: x) == Lazy(lambda x: x)

# Generated at 2022-06-21 19:08:46.435170
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    """
    Check if converting Lazy to Validation works as expected
    """
    from pymonet.validation import Validation

    validate_int = Validation.of(lambda x: x if isinstance(x, int) else 'not int')

    assert Lazy.of(5).to_validation() == Validation.success(5)
    assert Lazy(lambda x: 5).ap(validate_int).to_validation() == Validation.success(5)
    assert Lazy(lambda x: 'not int').ap(validate_int).to_validation() == Validation.failure('not int')



# Generated at 2022-06-21 19:08:52.352995
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """
    Tests the method to_either of class Lazy with two arguments
    """
    def lazy_either():
        def func_to_lazy():
            return "Lazy to Either 1"

        return Lazy(func_to_lazy)

    expected = Right("Lazy to Either 1")
    assert lazy_either().to_either() == expected



# Generated at 2022-06-21 19:08:55.979189
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:09:04.215763
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Test Lazy to try method
    """
    from pymonet.monad_try import Try

    def function_raising_exception(*args):  # pragma: no cover
        print("Hello!")
        return 1 / 0

    def function_returning_result(*args):
        print("Hello!")
        return 10

    assert Lazy(function_raising_exception).to_try() == Try.of(function_raising_exception)
    assert Lazy(function_returning_result).to_try() == Try.of(function_returning_result)

# Generated at 2022-06-21 19:09:05.633695
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(5).to_box() == 5


# Generated at 2022-06-21 19:09:13.323694
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.monads import Lazy
    from pymonet.maybe import Maybe
    def to_return_maybe(x):
        return Maybe.just(x)

    assert Lazy.of(2).to_maybe() == Maybe.just(2)
    assert Lazy.of(None).to_maybe() == Maybe.just(None)
    assert Lazy.of(4).map(to_return_maybe).to_maybe() == Maybe.just(4)
    assert Lazy.of(None).map(to_return_maybe).to_maybe() == Maybe.just(None)


# Generated at 2022-06-21 19:09:20.998184
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    """
    Unit test for method __str__ of class Lazy
    """
    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<function <lambda> at 0x0000017EB3C3CD08>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: 1).get()) == 'Lazy[fn=<function <lambda> at 0x0000017EB3C3CD08>, value=1, is_evaluated=True]'


# Generated at 2022-06-21 19:09:23.866573
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def fn():
        return '1'

    lazy = Lazy(fn)
    from pymonet.box import Box
    box = lazy.to_box()

    assert box == Box('1')


# Generated at 2022-06-21 19:09:29.884533
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.monad_try import Try
    def f(num):
        return num + 1
    result = Try.unit("error").to_validation()
    assert result.get_value() == "error"


# Generated at 2022-06-21 19:09:34.868999
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_one = Lazy(lambda x: x + 1)
    lazy_inc = Lazy(lambda x: x + 1)

    assert Lazy.of(100).ap(lazy_one) == lazy_one
    assert lazy_inc.ap(lazy_one) == Lazy.of(2)


# Generated at 2022-06-21 19:09:41.029362
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    import pytest
    from pymonet.monad_try import Try

    try_lazy = Lazy(lambda *args: 1 / args[0])
    success = try_lazy.to_try(0)
    assert isinstance(success, Try)
    assert not success.is_failure

    failure = try_lazy.to_try(1)
    assert isinstance(failure, Try)
    assert failure.is_failure

    assert failure == Lazy(lambda *args: 1 / args[0]).to_try(1)
    assert success == Lazy(lambda *args: 1 / args[0]).to_try(0)



# Generated at 2022-06-21 19:09:44.463849
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy(lambda: 1).to_box() == Box(1)

    assert Lazy(lambda: Box(1)).to_box() == Box(Box(1))


# Generated at 2022-06-21 19:09:49.816959
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from .test_utils import assert_str
    from functools import partial

    assert_str(Lazy(partial(add_one, 13)), "Lazy[fn=functools.partial(<function add_one at 0x7f3898e9d620>, 13), value=None, is_evaluated=False]")



# Generated at 2022-06-21 19:09:52.153927
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def dummy_function():
        return 1

    lazy = Lazy(dummy_function)

    assert lazy.to_maybe() == Maybe.just(1)

# Generated at 2022-06-21 19:09:55.278885
# Unit test for method get of class Lazy
def test_Lazy_get():
    """Test get() method for Lazy class"""
    lazy = Lazy.of(1 + 2)
    assert lazy.get() == 3

    lazy = Lazy(lambda: 1 + 2)
    assert lazy.get() == 3


# Generated at 2022-06-21 19:09:56.810095
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1

# Generated at 2022-06-21 19:09:58.906155
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy(lambda: 10)
    assert lazy.bind(Lazy.of).get() == 10



# Generated at 2022-06-21 19:10:00.337858
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(10).to_box() == Box(10), 'test Lazy to Box'


# Generated at 2022-06-21 19:10:05.196504
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda value: value)) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: 'Hello World').bind(lambda value: Lazy(lambda: value + '!')).map(lambda value: value.upper())) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:10:11.621376
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.box import Box
    from pymonet.validation import Validation

    def add_one(x: int) -> int:
        return x + 1

    def add_two(x: int) -> int:
        return x + 2

    def compose(f, g):
        return lambda x: f(g(x))

    lazy = Lazy.of(1)
    composed_fn = compose(add_one, add_two)

    assert lazy.map(add_one) == Lazy.of(2)
    assert lazy.map(add_two) == Lazy.of(3)
    assert lazy.map(add_two).map(add_one) == Lazy.of(4)
    assert lazy.map(composed_fn) == Lazy.of(4)
    assert Lazy.of

# Generated at 2022-06-21 19:10:20.669713
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation, Success, Failure

    def applicative_fn(value):
        return value + 'test'

    def applicative(value):
        return Validation.success(applicative_fn(value))

    def applicative_failure(value):
        return Validation.fail([Failure(value)])

    assert Lazy(lambda: '1').ap(applicative('2')).get() == Success('2test')
    assert Lazy(lambda: '1').ap(applicative_failure('2')).get() == Failure('2')


# Generated at 2022-06-21 19:10:25.063516
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 2)
    assert Lazy(lambda x: x + 1) != Maybe.nothing()
    assert Lazy(lambda x: x + 1) != Box('test')
    assert Lazy(lambda x: x + 1).to_box() == Box(1)



# Generated at 2022-06-21 19:10:32.643504
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Just, Nothing
    from pymonet.monad import is_just

    def function(*args):
        return 7

    def function_with_error(*args):
        raise Exception('test_exception')

    # When Lazy return just value
    assert is_just(Lazy(function).to_maybe())

    # When Lazy raise error
    assert isinstance(Lazy(function_with_error).to_maybe(), Nothing)


# Generated at 2022-06-21 19:10:34.666992
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of(1).to_maybe() == Lazy.of(1).to_box().to_maybe()

# Generated at 2022-06-21 19:10:37.805649
# Unit test for method map of class Lazy
def test_Lazy_map():
    # GIVEN
    test_lazy = Lazy.of(5)

    # WHEN
    mapped_lazy = test_lazy.map(lambda x: x + 1)

    # THEN
    assert mapped_lazy.get() == 6


# Generated at 2022-06-21 19:10:42.325403
# Unit test for constructor of class Lazy
def test_Lazy():
    def constructor_fn(a):
        return a + 1

    l = Lazy(constructor_fn)
    assert l.constructor_fn
    assert not l.is_evaluated
    assert l.value is None


# Generated at 2022-06-21 19:10:47.955267
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy.of(3).to_maybe() == Maybe.just(3)
    assert Lazy.of(None).to_maybe() == Maybe.nothing()
    assert Lazy(lambda: 4).to_maybe() == Maybe.just(4)
    assert Lazy(lambda: None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:10:55.956175
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(2) != Lazy.of(3)
    assert Lazy.of(2) != Lazy(lambda: 2)

    assert Lazy(lambda: 2) != Lazy.of(3)
    assert Lazy(lambda: 2) != Lazy(lambda: 3)
    assert Lazy(lambda: 2) != Lazy(lambda: 1)
    assert Lazy(lambda: 2) == Lazy(lambda: 2)

    assert Lazy(lambda x: x + 1).map(lambda x: x * 10).get(2) == 30
    assert Lazy(lambda x: x + 1).map(lambda x: x * 10).get(2) == 30

# Generated at 2022-06-21 19:11:03.909787
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(2).ap(Lazy.of(lambda x: x * 2)).get() == 4
    assert Lazy.of(lambda x: x * 2).ap(Lazy.of(2)).get() == 4
    assert Lazy.of(lambda x: x * 2).ap(Lazy.of(3)).get() == 6


# Generated at 2022-06-21 19:11:13.797116
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import operator
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe, Nothing
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def doubling_function(x: int) -> int:
        return 2 * x

    # Lazy of int
    def plus_three_function(x: int) -> int:
        return x + 3

    # Lazy of function(int) -> int
    def function_of_function(double_function: Callable[[int], int]) -> Callable[[int], int]:
        return lambda x: double_function(double_function(x))

    # Lazy of int -> int
    def valid_function(x: int) -> int:
        return x * 3

    # Lazy of int -> int

# Generated at 2022-06-21 19:11:22.070370
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    import unittest

    test1_fn = lambda x: x
    test1 = Lazy(test1_fn)
    test2_fn = lambda x: x
    test2 = Lazy(test1_fn)

    # same functions and evaluated
    test2._compute_value(1)
    assert test1 == test2

    # same functions and not evaluated
    assert test1 == test2

    class TestClass(unittest.TestCase):
        def test_test(self):
            assert test1 == test1

    del test1_fn
    del test2_fn
    test2 = None

    # same functions and not evaluated by one Lazy
    assert test1 == test2



# Generated at 2022-06-21 19:11:26.973053
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    >>> Lazy.of(lambda a: a + 1).ap(Lazy.of(1))
    Lazy[fn=<function Lazy.<locals>.<lambda> at 0x000001D35C3E3CA8>, value=2, is_evaluated=True]
    """


# Generated at 2022-06-21 19:11:31.668586
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test case for method ap of class Lazy
    """

    def add(value):
        return lambda x: value + x

    add_three = Lazy(add(3))
    add_five = Lazy(add(5))
    result_add_five = add_three.ap(add_five)

    assert Lazy.of(8) == result_add_five

# Generated at 2022-06-21 19:11:36.984622
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    """
    Verifies that method __str__ of class Lazy produces expected string.

    :returns: Nothing
    :rtype: None
    """

    # Given
    constructor_fn = lambda *args: str(args)
    lazy = Lazy(constructor_fn)

    # When
    result = str(lazy)

    # Then
    assert result == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(constructor_fn, lazy.value, lazy.is_evaluated)



# Generated at 2022-06-21 19:11:41.163838
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(3) != Lazy.of(2)
    assert Lazy(lambda: 2) != Lazy(lambda: 2)



# Generated at 2022-06-21 19:11:50.328406
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.monad_try import Try

    assert str(Lazy.of(1)) == 'Lazy[fn=<function <lambda> at 0x7faf4e101c80>, value=None, is_evaluated=False]'
    assert str(Lazy.of(1).to_try()) == \
        "Try[value=Lazy[fn=<function <lambda> at 0x7faf4e101c80>, value=None, is_evaluated=False], is_success=True]"
    assert str(Try.of(lambda: int("12a"))) == "Try[value=12, is_success=False]"  # noqa



# Generated at 2022-06-21 19:11:53.504873
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda x: x)
    assert 1 == lazy.get(1)
    assert 1 == lazy.get(2)


# Generated at 2022-06-21 19:11:57.981211
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    def inc(n):
        return n + 1

    def name(n):
        return 'Pyton ' + str(n)

    assert Lazy(lambda: Box(3)).map(inc).value == \
           Lazy(lambda: inc(Box(3))).value

    assert Lazy(lambda: 3).map(name).value == \
           Lazy(lambda: name(3)).value


# Generated at 2022-06-21 19:12:04.593118
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Call Function(A) -> Lazy<B> only when fold method is called.
    """
    a = Lazy(lambda: 1)
    result_a = a.bind(lambda x: Lazy(lambda: x + 10)).get()

    assert result_a == 11

# Generated at 2022-06-21 19:12:09.642632
# Unit test for method get of class Lazy
def test_Lazy_get():
    def method_returning_multiple_arguments(a, b):
        return a, b

    lazy = Lazy(method_returning_multiple_arguments)
    assert lazy is not None
    assert lazy.get(1, 2) == (1, 2)
    assert lazy.get(1, '2') == (1, '2')
    assert lazy.to_box(1, 2) == Box((1, 2))



# Generated at 2022-06-21 19:12:15.877415
# Unit test for method map of class Lazy
def test_Lazy_map():
    x = Lazy.of(1)
    assert x.map(lambda x: x + 1).get() == 2

    x = Lazy.of(2)
    assert x.map(lambda x: x * 2).get() == 4

    x = Lazy.of('a')
    assert x.map(lambda x: x + 'b').get() == 'ab'



# Generated at 2022-06-21 19:12:19.076363
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x).map(lambda x: 3)) == 'Lazy[fn=<function Lazy.<lambda> at 0x10dcaa5f0>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:12:22.830260
# Unit test for method map of class Lazy
def test_Lazy_map():
    def fn(a):
        return a + 1

    assert Lazy(lambda: 3).map(fn).get() == 4
    assert Lazy(lambda: 3).map(fn).map(fn).get() == 5

    # map must not be evaluated
    assert Lazy(lambda: 3).map(lambda x: assert_(False), fn).get() == 3


# Generated at 2022-06-21 19:12:34.249973
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert_equal(
        Lazy.of(1).map(lambda value: value + 1).get(),
        2
    )

    assert_equal(
        Lazy.of(6).map(lambda value: value + 1).map(lambda value: value * 2).get(),
        14
    )

    assert_equal(
        Lazy.of(1).map(lambda value: value + 1).map(lambda value: value * 2).map(lambda value: value ** 2).get(),
        16
    )

    assert_equal(
        Lazy.of(1).map(lambda value: value + 1).map(lambda value: value * 2).map(lambda value: value ** 2).map(
            lambda value: value / 2).get(),
        8
    )


# Generated at 2022-06-21 19:12:43.126358
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.maybe import Maybe

    f = lambda x: x + 1
    g = lambda x: x * 2
    a = Lazy(f)
    b = Lazy(g)
    c = a.map(f).map(g).map(g)

    assert Lazy.of(1) == Lazy.of(1)
    assert c == b.map(g)
    assert c.get(1) == Lazy(lambda x: g(f(x))).get(1)
    print('Test Lazy constructor ok')



# Generated at 2022-06-21 19:12:47.490741
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_divider(value):
        return value / 2

    lazy = Lazy(test_divider)
    assert lazy.get(4) == 2
    assert lazy.is_evaluated
    assert lazy.value is not None


# Generated at 2022-06-21 19:12:58.095860
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    test_empty_lazy = Lazy(lambda *args: None)
    assert Maybe.empty() == test_empty_lazy.to_maybe("arg1", "arg2")

    test_not_empty_lazy = Lazy(lambda *args: "value")
    assert Maybe.just("value") == test_not_empty_lazy.to_maybe("arg")

    test_box = Box(Maybe.just("value"))
    assert Maybe.just("value") == test_box.to_maybe("arg")

    test_box = Box(Maybe.empty())
    assert Maybe.empty() == test_box.to_maybe("arg")



# Generated at 2022-06-21 19:13:08.542946
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1).map(lambda x: x) == Lazy.of(1)
    assert Lazy.of(1).map(lambda x: x) == Lazy.of(1).map(lambda x: x)
    assert Lazy.of(1).map(lambda x: x) == Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1).map(lambda x: x) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1).map(lambda x: x) != Lazy.of(2)


# Unit test

# Generated at 2022-06-21 19:13:15.164253
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    x = Lazy(lambda: Maybe.just(1))
    assert x.to_maybe(1) == Maybe.just(1)



# Generated at 2022-06-21 19:13:19.603750
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right

    assert Lazy.of('value').to_either() == Right('value')
    assert Lazy(lambda: 1 / 0).to_either() == Left(ZeroDivisionError('division by zero'))

# Generated at 2022-06-21 19:13:22.631146
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(5)
    assert Lazy.of('5')
    assert Lazy.of(5).constructor_fn() == 5
    assert Lazy.of('5').constructor_fn() == '5'

# Generated at 2022-06-21 19:13:33.295804
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda: 2).to_box() == Box(2)
    assert Lazy(lambda: 'test').to_box() == Box('test')
    assert Lazy(lambda: Box(2)).to_box() == Box(Box(2))  # can't be
    assert Lazy(lambda: Box('test')).to_box() == Box(Box('test'))  # can't be
    assert Lazy(lambda: None).to_box() == Box(None)  # can't be
    assert Lazy(lambda: True).to_box() == Box(True)
    assert Lazy(lambda: False).to_box() == Box(False)


# Generated at 2022-06-21 19:13:37.788857
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def lazy_map(f):
        return Lazy.of(f).map(lambda a: a + 2)

    def multiply_by_2(a):
        return 2 * a

    def fold(lazy):
        return lazy.get()

    assert fold(lazy_map(10).ap(lazy_map(multiply_by_2))) == 22



# Generated at 2022-06-21 19:13:46.327993
# Unit test for constructor of class Lazy
def test_Lazy():
    from functools import partial

    lazy = Lazy(lambda: 'lazy')
    lazy_of = Lazy.of('lazy')

    assert(lazy == lazy)
    assert(lazy_of == lazy_of)
    assert(lazy == lazy_of)

    assert(
        str(lazy)
        == 'Lazy[fn=<function Lazy.<lambda> at 0x7fc6a7014598>, value={}, is_evaluated={}]'.format(lazy.value, lazy.is_evaluated)
    )



# Generated at 2022-06-21 19:13:49.385542
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy.of(0).get() == 0



# Generated at 2022-06-21 19:13:54.002069
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Tests the bind method
    """
    def f(a):
        def g(b):
            return a + b
        return Lazy(g)

    lazy = Lazy(lambda x: x)
    actual = lazy.bind(f)
    assert actual is not None

# Generated at 2022-06-21 19:13:58.114561
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def fun():
        return 1
    assert str(Lazy(fun)) == 'Lazy[fn=<function Lazy_tests.test_Lazy___str__.<locals>.fun at 0x10b8c8ea0>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:14:00.463544
# Unit test for method to_try of class Lazy
def test_Lazy_to_try(): # type: () -> None
    from pymonet.monad_try import Try
    try_result = Try.of(int, "2")

    assert try_result == Lazy.of(2).to_try()

# Generated at 2022-06-21 19:14:14.517185
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(23).to_validation() == Validation.success(23)
    assert Lazy.of('example string').to_validation() == Validation.success('example string')



# Generated at 2022-06-21 19:14:17.867209
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(3).to_either() == Right(3)
    assert Lazy.of(0).to_either() == Right(0)



# Generated at 2022-06-21 19:14:26.109991
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    def plus_three(x):
        return x + 3

    def plus_seven(x):
        return x + 7

    assert Lazy.of(2).ap(Lazy.of(plus_three)) == Lazy.of(5)
    assert Lazy.of(2).ap(Lazy.of(plus_three)).ap(Lazy.of(plus_seven)) == Lazy.of(12)
    assert Lazy.of(2).ap(Lazy.of(plus_three)).ap(Lazy.of(plus_seven)).ap(Lazy.of(plus_three)) == Lazy.of(15)

# Generated at 2022-06-21 19:14:31.211948
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    empty_lazy = Lazy.of(None)
    assert empty_lazy.to_maybe(None) == Maybe.nothing()

    not_empty_lazy = Lazy.of(1)
    assert not_empty_lazy.to_maybe(None) == Maybe.just(1)



# Generated at 2022-06-21 19:14:37.094773
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 'hi').get() == 'hi'
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: '1').get() == '1'
    assert Lazy(lambda x: x).get('1') == '1'
    assert Lazy(lambda x, y: x + y).get('a', 'b') == 'ab'
    assert Lazy(lambda x, y: x + y).get(x='a', y='b') == 'ab'


# Generated at 2022-06-21 19:14:46.457273
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1).map(lambda x: x + 1) != Lazy.of(2)
    assert Lazy.of(1).map(lambda x: x + 1) == Lazy.of(2).map(lambda x: x - 1)
    assert Lazy.of(1).map(lambda x: x + 1) != Lazy.of(2).map(lambda x: x + 1)



# Generated at 2022-06-21 19:14:48.913070
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def function(value: Any) -> Any:
        return value

    assert Lazy(function).to_box(1) == Box(1)


# Generated at 2022-06-21 19:14:56.672424
# Unit test for method map of class Lazy
def test_Lazy_map():
    def upper(value):
        return value.upper()

    def double(value):
        return value * 2

    def add_constant(value, constant):
        return value + constant

    assert (
        Lazy(lambda: 'test').map(upper).map(double).map(lambda value: add_constant(value, '*'))
        == Lazy(lambda: 'TEST*TEST*')
    )
    assert (
        Lazy(lambda: 'test').map(upper).map(double).map(lambda value: add_constant(value, '*')).map(double)
        == Lazy(lambda: 'TEST*TEST**TEST*TEST*')
    )


# Generated at 2022-06-21 19:15:02.524754
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """Unit test for method to_either of class Lazy"""

    def test(x):
        if x == 3:
            raise Exception("error")
        elif x == 2:
            return "ok"
        else:
            return None

    lazy = Lazy(test)
    assert lazy.to_either(0) == pymonet.either.Left("error")
    assert lazy.to_either(2) == pymonet.either.Right("ok")
    assert lazy.to_either(3) == pymonet.either.Right(None)


# Generated at 2022-06-21 19:15:05.864914
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert not Lazy(lambda: 1) == None



# Generated at 2022-06-21 19:15:32.914290
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    val = Lazy.of(5)

    assert val.to_maybe() == Maybe.just(5)
    assert val.map(lambda x: x + 5).to_maybe() == Maybe.just(10)
    assert val.map(lambda x: x + 7).to_maybe(10) == Maybe.just(12)
    assert val.to_maybe() == Maybe.just(5)



# Generated at 2022-06-21 19:15:40.258536
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_either import Left

    def fn_raise():
        return 1/0

    def fn_not_raise():
        return 1

    assert Lazy.of(fn_raise).to_try() == Try.failure(ZeroDivisionError)
    assert Lazy.of(fn_not_raise).to_try() == Try.of(fn_not_raise)
    assert Lazy.of(fn_raise).bind(lambda x: Try.of(fn_raise)).to_try() == Try.failure(ZeroDivisionError)

    def fn_raise_left():
        raise Exception("Fake exception")

    assert Lazy.of(fn_raise_left).to_try() == Try.failure(Exception)


# Generated at 2022-06-21 19:15:42.925348
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 'test'
    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    assert lazy1 == lazy2



# Generated at 2022-06-21 19:15:51.177613
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try

    some_lazy_function = Lazy(lambda x: x * 2)
    some_lazy_returned_value = Lazy(lambda x: x * 3)
    test_value = 3
    assert test_value == some_lazy_function.ap(some_lazy_returned_value).get(test_value)

    some_lazy_function = Lazy(lambda x: x * 2)
    some_lazy_returned_value = Lazy(lambda x: x * 3)
    test_value = 3
    assert test_value == some_lazy_function.ap(Try.of(lambda x: x * 3, test_value)).get()

    some_lazy_function = Lazy(lambda x: x * 2)
    some_lazy_

# Generated at 2022-06-21 19:15:56.602370
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    import pytest
    from pymonet.either import Right, Left

    def test_fn(value):
        return Lazy.of(value)

    assert(Right('foo') == test_fn('foo').to_either())
    assert(Left('bar') == test_fn(Left('bar')).to_either())


# Generated at 2022-06-21 19:16:01.324805
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    import pymonet.box as box

    assert Lazy.of(1).to_box() == box.Box(1)

    lazy = Lazy.of(1)
    assert lazy.to_box() == box.Box(1)
    assert lazy.is_evaluated is True
    assert lazy.value == 1



# Generated at 2022-06-21 19:16:06.077299
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add(a):
        return a + a

    def mul(a):
        return a * a

    assert Lazy(add).map(mul).get(2) == 16
    assert Lazy(add).map(mul).get(1) == 4



# Generated at 2022-06-21 19:16:16.643064
# Unit test for method get of class Lazy
def test_Lazy_get():

    def test_get_of_evaluated_Lazy():
        lazy = Lazy.of(3).map(lambda x: x + 2)
        lazy.get() == 5

    test_get_of_evaluated_Lazy()

    def test_get_of_not_evaluated_Lazy():
        lazy = Lazy(lambda: 5).map(lambda x: x + 2)
        lazy.get() == 7

    test_get_of_not_evaluated_Lazy()

    def test_get_of_Lazy_with_argument():
        lazy = Lazy(lambda x: x + 2)
        assert lazy.get(2) == 4
        assert lazy.get(3) == 5

    test_get_of_Lazy_with_argument()


# Generated at 2022-06-21 19:16:19.626912
# Unit test for method map of class Lazy
def test_Lazy_map():
    _lazy = Lazy(lambda: 1).map(lambda x: x + 1)
    assert _lazy.get() == 2



# Generated at 2022-06-21 19:16:27.802204
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def my_func():
        return 'hello world'

    lazy1 = Lazy(my_func)
    lazy2 = Lazy(my_func)
    assert lazy1 == lazy2

    # Test different function
    def my_func2():
        return 'hello world2'

    lazy3 = Lazy(my_func2)
    assert lazy1 != lazy3

    # Test that not evaluated Lazy are equals
    lazy1._compute_value()
    assert lazy1 == lazy2

    lazy2._compute_value()
    assert lazy1 == lazy2



# Generated at 2022-06-21 19:17:16.476190
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy(lambda x: x).to_try(123) == Try.of(lambda x: x, 123)

    assert Lazy(lambda x: '{}'.format('x' * x)).to_try(123) == Try.success('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
    assert Lazy(lambda x: '{}'.format('x' * x)).to_try(0) == Try.success('')


# Generated at 2022-06-21 19:17:24.003949
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    class TestException(Exception):
        pass

    def function_to_lazy(value):
        return Lazy(lambda: value)

    def bind_function(value):
        if value < 0:
            return Lazy(lambda: raise_value_error())
        return Lazy(lambda: value)

    def raise_value_error():
        raise ValueError('Lazy bind value error')

    def raise_test_exception():
        raise TestException('Lazy bind test exception')

    assert Lazy(lambda: "test data") >> bind_function \
        >> bind_function \
        >> bind_function \
        >> bind_function \
        >> function_to_lazy \
        == Lazy(lambda: "test data")


# Generated at 2022-06-21 19:17:29.541667
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Lazy should return value from constructor_fn and memoize it
    """

    def fn():
        return 10

    lazy = Lazy(fn)
    assert lazy.get() == 10
    assert lazy.is_evaluated
    assert lazy.get() == 10
    assert lazy.is_evaluated
