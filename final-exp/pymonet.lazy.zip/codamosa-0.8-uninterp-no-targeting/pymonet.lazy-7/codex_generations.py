

# Generated at 2022-06-21 19:07:37.921811
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Left

    lazy_left = Lazy.of(Left('error'))
    lazy_right = Lazy.of(1)
    class_lazy_left = Lazy(lambda: Left('error'))
    class_lazy_right = Lazy(lambda: 2)

    assert lazy_left.bind(lambda a: Lazy.of(a)).get() == Left('error')
    assert lazy_left.bind(lambda a: Lazy(lambda: a)).get() == Left('error')
    assert class_lazy_left.bind(lambda a: Lazy.of(a)).get() == Left('error')
    assert class_lazy_left.bind(lambda a: Lazy.of(a)).get() == Left('error')


# Generated at 2022-06-21 19:07:49.804691
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    import pytest

    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy.of(None).to_maybe() == Maybe.just(None)

    # When constructor_fn return empty Maybe then to_maybe should return empty Maybe
    def func_empty_maybe():
        return Maybe.empty()

    assert Lazy(func_empty_maybe).to_maybe().is_empty()

    # When constructor_fn is not callable then should return empty Maybe
    assert Lazy(1).to_maybe().is_empty()
    assert Lazy(None).to_maybe().is_empty()

    # When constructor_fn raise exception then to_maybe should return empty Maybe
    def func_raise_error():
        raise ValueError()


# Generated at 2022-06-21 19:07:53.500738
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    lazy = Lazy(lambda x: x + 1)
    result = lazy.to_validation(1)
    assert result == Validation.success(2)



# Generated at 2022-06-21 19:07:57.530581
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    assert Lazy.of(Box(1)).to_either() == Right(Box(1))
    assert Lazy.of(Maybe.just(1)).to_either() == Right(Maybe.just(1))
    assert Lazy.of(1).to_either() == Right(1)


# Generated at 2022-06-21 19:08:03.111986
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.try_ import Try
    from pymonet.validation import Validation
    from pymonet.list import List

    print('Lazy.to_box')

    assert Lazy.of(1).to_box() == Box(1)
    assert Lazy.of(1).to_box().__eq__(Box(1)) == True

    print('OK')


# Generated at 2022-06-21 19:08:10.468327
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy.
    """
    assert Lazy(lambda x: x + 1).bind(
        lambda x: Lazy(lambda y: x + y)
    ).get(10) == 21

# Generated at 2022-06-21 19:08:17.224870
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def constructor_fn(*args):
        return "test"

    lazy = Lazy(constructor_fn)

    assert lazy.to_either() == lazy.to_box()
    assert lazy.to_either() == lazy.to_maybe()
    assert lazy.to_either() == lazy.to_try()
    assert lazy.to_either() == lazy.to_validation()



# Generated at 2022-06-21 19:08:20.942743
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def add(x):    # pylint: disable=invalid-name
        return x + 1

    assert str(Lazy(add)) == 'Lazy[fn=<function add at 0x10edb5ea0>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:08:24.452660
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def test():
        return 1

    assert Lazy(test).get() == 1
    assert Lazy(test).value is None
    assert Lazy.of(1).get() == 1
    assert Lazy(test).is_evaluated is True


# Generated at 2022-06-21 19:08:35.953948
# Unit test for method get of class Lazy
def test_Lazy_get():
    """ Unit tests for Lazy.get() method. """
    assert Lazy.of(1).get() == 1
    assert Lazy.of(2).get(3) == 2
    assert Lazy.of(3).get(4, 5) == 3
    assert Lazy.of(4).get(5, 6, 7) == 4

    def func():
        return 5

    assert Lazy(func).get() == 5

    def func_raises():
        raise IOError('Some error')

    assert Lazy(func_raises).get() == None

    def func_with_arg(arg):
        return arg + 1

    assert Lazy(func_with_arg).get(1) == 2
    assert Lazy(func_with_arg).get(2) == 3

# Generated at 2022-06-21 19:08:43.437110
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from random import randint

    fn = lambda: randint(0, 10)
    lazy = Lazy(fn)
    def fold(value):
        return Lazy.of(value)

    # Check is bind not call function before call fold method
    assert lazy.is_evaluated == False
    assert lazy.bind(fold).get() == fn()
    assert lazy.is_evaluated == True

# Generated at 2022-06-21 19:08:47.121351
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy.of(None) == Lazy.of(None)
    assert Lazy.of(1) != Lazy.of(2)

    lazy_with_fn = Lazy(lambda: 'a')
    assert lazy_with_fn != Lazy.of('a')
    assert lazy_with_fn != Lazy(lambda: 'b')

# Generated at 2022-06-21 19:08:51.905826
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    def constructor_fn():
        return '123'

    box = Lazy(constructor_fn).to_box()

    assert isinstance(box, Box)
    assert box.get() == '123'



# Generated at 2022-06-21 19:08:54.856393
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def func():
        return Maybe.empty()

    assert Lazy(func).to_maybe() == Maybe.empty()

# Generated at 2022-06-21 19:08:57.297999
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of('test').to_validation() == Validation.success('test')

# Generated at 2022-06-21 19:09:04.713853
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    not_evaluated_Lazy = Lazy(lambda x: x)
    evaluated_Lazy = Lazy(lambda x: x)
    evaluated_Lazy._compute_value(1)

    assert not_evaluated_Lazy.__eq__(Lazy(lambda x: x))
    assert evaluated_Lazy.__eq__(Lazy(lambda x: x).map(lambda x: x * 2))
    assert not evaluated_Lazy.__eq__(Lazy(lambda x: x * 2))


# Generated at 2022-06-21 19:09:11.199953
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x * x

    first_lazy = Lazy(fn)
    second_lazy = Lazy(fn)
    first_lazy_after_call = Lazy(fn)
    first_lazy_after_call._compute_value(1)

    assert first_lazy == second_lazy
    assert first_lazy != first_lazy_after_call
    assert second_lazy != first_lazy_after_call

# Generated at 2022-06-21 19:09:15.346170
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: True)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x10c7a46a8>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:09:17.819386
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    lazy = Lazy(lambda x: x)
    assert lazy.to_validation("Test").get_value() == "Test"


# Generated at 2022-06-21 19:09:21.242723
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda: 10) == Lazy(lambda: 10)
    assert isinstance(Lazy(lambda x: x), Lazy)


# Generated at 2022-06-21 19:09:36.855170
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def fn(a):
        return a

    lazy = Lazy(fn).map(lambda a: a + 1).map(lambda a: a * 2)
    assert 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x{:x}>, value=None, is_evaluated=False]'.format(
        id(fn)) == str(lazy)

    lazy = Lazy(fn).map(lambda a: a + 1).map(lambda a: a * 2).get(3)
    assert 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x{:x}>, value=8, is_evaluated=True]'.format(id(fn)) == str(lazy)



# Generated at 2022-06-21 19:09:43.329404
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.monad_applicative import MonadApplicative
    import pytest

    assert Functor.is_functor(Lazy.of(lambda x: x))
    assert Monad.is_monad(Lazy.of(lambda x: x))
    assert MonadApplicative.is_monad_applicative(Lazy.of(lambda x: x))

    assert Lazy.of(lambda x: x).constructor_fn(1) == 1
    assert Lazy.of(lambda x: x).is_evaluated is False

    assert Lazy.of(lambda x: 2).get(1) == 2
    assert Lazy.of(lambda x: 2).is_evaluated

# Generated at 2022-06-21 19:09:48.070455
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def divide(x, y):
        return x/y

    assert Lazy(divide).to_try(2, 3) == Try.of(divide, 2, 3)
    assert Lazy(divide).to_try(2, 0) == Try.of(divide, 2, 0)


# Generated at 2022-06-21 19:09:54.443968
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left

    assert Lazy.of(1).to_either() == Right(1)

    try:
        Lazy.of(1/0).to_either()
    except ZeroDivisionError:
        pass

    assert Lazy.of(1/0).to_either() == Left(ZeroDivisionError())



# Generated at 2022-06-21 19:09:57.872761
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    """
    Unit test for method to_maybe of class Lazy.
    """
    result = Lazy.of(3).to_maybe()

    assert isinstance(result, Lazy)
    assert result.get() == 3
    assert result.constructor_fn == result.get

# Generated at 2022-06-21 19:09:59.991127
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def func(x):
        return x * 2

    assert Lazy.of(func).ap(Lazy.of(2)) == Lazy.of(4)

# Generated at 2022-06-21 19:10:02.458535
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    test_map = lambda x: x
    lazy = Lazy.of(1).map(test_map)
    assert lazy.bind(lambda x: Box.of(x+1)).get() == 2

# Generated at 2022-06-21 19:10:04.974629
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy(lambda: 'a').to_either() == Lazy(lambda: 'a').to_either() == Right('a')



# Generated at 2022-06-21 19:10:10.127322
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)

    assert Lazy.of('a') == Lazy.of('a')
    assert Lazy.of('a') != Lazy.of('b')

    assert Lazy.of(None) == Lazy.of(None)
    assert Lazy.of(None) != Lazy.of(1)

    assert Lazy.of(3.14) == Lazy.of(3.14)
    assert Lazy.of(3.14) != Lazy.of(3.15)

    assert Lazy.of(True) == Lazy.of(True)
    assert Lazy.of(True) != Lazy.of(False)

    assert Lazy.of([]) == Lazy

# Generated at 2022-06-21 19:10:12.464217
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 'a').get() == 'a'

# Generated at 2022-06-21 19:10:23.529410
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: None) == Lazy(lambda: None)
    assert Lazy(lambda: None) != Lazy(lambda: 'None')
    assert Lazy(lambda: None) != ['A', 'B']
    assert Lazy(lambda: None) != 'NONE'

    # Ensure that result of method __eq__ concerned from some state
    a = Lazy(lambda: None)
    b = Lazy(lambda: None)

    assert a == b
    a.get()
    b.get()

    assert a == b



# Generated at 2022-06-21 19:10:34.797132
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Lazy.of(1).ap(Box(lambda x: x+1)) == Box(2)
    assert Lazy.of(1).map(lambda x: x+1).ap(Box(lambda x: x+2)) == Box(4)
    assert Lazy.of(1).map(lambda x: x+1).map(lambda x: x+2).ap(Box(lambda x: x+3)) == Box(7)

    assert Lazy.of(1).ap(Right(lambda x: x+1)) == Right(2)

# Generated at 2022-06-21 19:10:45.898844
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    """
    ``Lazy.to_either()`` transforms Lazy into Either Right with Lazy constructor_fn result.
    """
    def test_fn_1():
        return 'hello'

    def test_fn_2(value, value1):
        return value + value1

    assert Lazy(test_fn_1).to_either() == Lazy(test_fn_1).to_box() == Lazy(test_fn_1).to_maybe() == Lazy(test_fn_1).to_try() == Lazy(test_fn_1).to_validation() == 'hello'

# Generated at 2022-06-21 19:10:52.261849
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import ValidationResult

    def fn(arg):
        return arg + 2

    lazy = Lazy(fn)
    result = lazy.to_validation(2)
    assert isinstance(result, Validation)
    assert result.is_success, 'Validation should be success.'
    assert isinstance(result.value, ValidationResult), 'Validation value should be ValidationResult.'
    assert result.value.value == 4, 'Validation result should be 4.'



# Generated at 2022-06-21 19:10:56.563812
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    """ __str__(Lazy[A]) -> str"""
    assert 'Lazy[fn=<function Lazy_test.<locals>.<lambda> at 0x' in str(Lazy(lambda: 'abc'))



# Generated at 2022-06-21 19:11:07.010867
# Unit test for method get of class Lazy
def test_Lazy_get():
    # pylint: disable=unused-variable
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    # assert Box.unit(Lazy.of(5).get()) == Box.unit(5)
    # assert Right.unit(Lazy.of(5).get()) == Right.unit(5)
    # assert Maybe.unit(Lazy.of(5)).get() == Maybe.just(5)
    # assert Lazy.of(5).to_try().get() == 5
    # assert Validation.unit(Lazy.of(5)).get() == Validation.success(5)

# Generated at 2022-06-21 19:11:11.071295
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Either
    from pymonet.monad_maybe import Maybe

    def _fn():
        return Either.right(Maybe.just(5))

    lazy = Lazy(_fn)

    assert lazy.to_either() == Either.right(Maybe.just(5))

# Generated at 2022-06-21 19:11:17.906096
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def raise_exception(*args):
        raise Exception('Exception message')

    lazy = Lazy(raise_exception)
    assert lazy.to_try() == Try.fail(Exception('Exception message'))

    def no_raises(*args):
        pass

    lazy = Lazy(no_raises)
    assert lazy.to_try() == Try.of(no_raises)

# Generated at 2022-06-21 19:11:23.386007
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)

    # Here Lazy is not evaluated and returned Box is empty
    assert Lazy.of(1).to_box() == Box.empty()



# Generated at 2022-06-21 19:11:32.736488
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.either import Left, Right
    import pytest

    def test_function(value):
        if value == 1:
            return Maybe.just(value)
        else:
            return Maybe.empty()

    def test_function_empty(value):
        return Maybe.empty()

    result = Lazy(test_function).to_either()
    assert isinstance(result, Right)
    assert result.get() == 1

    result = Lazy(test_function_empty).to_either()
    assert isinstance(result, Left)
    with pytest.raises(Exception):
        result.get()

# Generated at 2022-06-21 19:11:48.165334
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # pylint: disable=too-many-statements,too-many-locals

    def constructor_fn_1(_=None):
        return None

    def constructor_fn_2(_=None):
        return 'test'

    lazy_first_1 = Lazy(constructor_fn_1)
    lazy_first_2 = Lazy(constructor_fn_1)
    lazy_first_3 = Lazy(constructor_fn_2)

    assert lazy_first_1 == lazy_first_2

    assert lazy_first_1 != lazy_first_3

    lazy_first_1._compute_value()
    lazy_first_2._compute_value()
    lazy_first_3._compute_value()

    assert lazy_first_1 == lazy_first_2

# Generated at 2022-06-21 19:11:57.981189
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    def add_fn1(x):
        return x + 1

    def add_fn2(x):
        return x + 2

    def mult_fn(a, b):
        return a * b

    def to_list(x):
        return [x]

    lazy_add1 = Lazy(lambda x: add_fn1(x))
    lazy_add2 = Lazy(lambda x: add_fn2(x))
    lazy_mult = Lazy(lambda x, y: mult_fn(x, y))
    lazy_list = Lazy(lambda x: to_list(x))

# Generated at 2022-06-21 19:12:01.782438
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 2)

# Generated at 2022-06-21 19:12:04.324375
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(3).to_box() == Box(3)



# Generated at 2022-06-21 19:12:14.949366
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    add = lambda x: lambda y: x + y
    assert Lazy(add).ap(Box(2)) == Lazy(lambda y: 2 + y)
    assert Lazy(lambda x: add(x).ap(Box(2))) == Lazy(lambda x: x + 2)
    assert Lazy(lambda x: x).ap(Box.of(add).ap(Box(2))) == Lazy(lambda x: x + 2)
    assert Lazy(lambda x: add).ap(Box(2)).ap(Box(2)) == Lazy(lambda x: x + 2 + 2)
    assert Lazy(lambda x: x).ap(Box.of(add).ap(Box(2)).ap(Box(2))) == Lazy(lambda x: x + 2 + 2)



# Generated at 2022-06-21 19:12:19.633843
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.functor import Functor

    def f():
        return 3

    lazy = Lazy.of(f).to_box()
    assert isinstance(lazy, Box)
    assert isinstance(lazy, Functor)
    assert lazy.get() == 3


# Generated at 2022-06-21 19:12:24.499782
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation, Invalid

    assert Lazy(lambda x: x).to_validation() == Validation.success(None), 'Lazy with sync function with no arguments'

    def lazy_fn():
        return 1

    def lazy_fn_exception():
        raise Exception('Exception error')

    assert Lazy(lazy_fn).to_validation() == Validation.success(1), 'Lazy with sync function'
    assert Lazy(lambda: Lazy(lambda x: x).to_validation()).to_validation() == Validation.success(Validation.success(None)), 'Lazy with sync function with no arguments'


# Generated at 2022-06-21 19:12:26.972352
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy(lambda: 1).to_try() == Try(lambda: 1)



# Generated at 2022-06-21 19:12:31.188852
# Unit test for method map of class Lazy
def test_Lazy_map():
    def function(a):
        return a+1

    # map with not empty Lazy
    assert Lazy.of(1).map(function).get() == 2

    # map with empty Lazy
    assert Lazy.of(None).map(function).get() is None

# Generated at 2022-06-21 19:12:41.998574
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy.of("test").get() == Lazy.of("test").to_box().get()
    assert Lazy.of("test").get() == Lazy.of("test").to_box().get()
    assert Lazy.of("test").get() == Lazy.of("test").to_box().get()

    assert Box("test") == Lazy.of("test").to_box()
    assert Box("test") == Lazy.of("test").to_box()

    assert Box("test") == Lazy.of("test").to_box()
    assert Box("test") == Lazy.of("test").to_box()



# Generated at 2022-06-21 19:12:54.311478
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn(a):
        return a

    Lazy.of(1).get(1) == Lazy.of('1')
    Lazy.of(1).get(1) == Lazy.of(2).get(2)



# Generated at 2022-06-21 19:12:56.737477
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Right

    assert Lazy(lambda: 1).bind(lambda value: Right(value + 1)).get() == 2

# Generated at 2022-06-21 19:12:57.312962
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    pass

# Generated at 2022-06-21 19:13:07.353266
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def factory_of_lazy_add(x: int) -> Lazy[int, int]:
        def x_plus_y(y: int):
            return x + y
        return Lazy.of(x_plus_y)

    lazy_add: Lazy[int, int] = Lazy.of(lambda x, y: x + y)

    assert lazy_add.ap(Lazy.of(4)).get(2) == 6
    assert lazy_add.ap(Lazy.of(4)).to_box(2) == Box(6)

    lazy_of_fn: Lazy[int, Callable[[int], int]] = factory_of_lazy_add(2)
    assert lazy_of_fn.ap(Lazy.of(6)).get() == 8

# Generated at 2022-06-21 19:13:11.397195
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    # given
    from pymonet.validation import Validation

    validation = Validation.success('foo')
    lazy = validation.to_lazy()

    # when
    new_validation = lazy.to_validation()

    # then
    assert validation == new_validation

# Generated at 2022-06-21 19:13:16.437222
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    def fn1(a):
        return a + 1

    def fn2(a):
        return a - 2

    assert Lazy(fn1).to_validation(1) == Validation.success(2)
    assert Lazy(fn2).to_validation(1) == Validation.success(-1)

# Unit tests for method ap of class Lazy

# Generated at 2022-06-21 19:13:17.823402
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    assert Lazy.of(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:13:20.995836
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import pymonet.box as box_

    lazy_ = Lazy.of(1)
    fn = lambda x: x ** 2
    assert lazy_.ap(box_.pure(fn)) == Lazy.of(fn(1))

# Generated at 2022-06-21 19:13:23.185292
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:13:35.043108
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    def add_it(additional: int):
        def add_lambda(number: int):
            return number + additional

        return Lazy(add_lambda)

    lazy = Lazy(lambda: 3)
    assert lazy.bind(add_it(3)).get() == 6
    assert lazy.value is None
    assert lazy.is_evaluated is False
    lazy_add_4 = lazy.bind(add_it(4))
    assert lazy_add_4.get() == 7
    assert lazy.value == 3
    assert lazy.is_evaluated is True
    assert lazy_add_4.value is None
    assert lazy_add_4.is_evaluated is False
    assert lazy_add_4.get() == 7
    assert lazy_add_

# Generated at 2022-06-21 19:13:53.333340
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy(lambda: 1).to_validation() == Lazy(lambda x: 1).to_validation(None)
    assert Lazy(lambda: 1).to_validation() != Lazy(lambda x: 'a').to_validation()


# Generated at 2022-06-21 19:14:01.817899
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def not_divisible_by_3(n):
        if n % 3 == 0:
            return Lazy.of(n)
        else:
            return Lazy.of(Validation.failure('not_divisible_by_3'))

    assert Validation.success(0) == Lazy.of(0).to_validation()
    assert Validation.success(1) == not_divisible_by_3(1).to_validation()
    assert Validation.failure(['not_divisible_by_3']).contains('not_divisible_by_3') == not_divisible_by_3(2).to_validation()



# Generated at 2022-06-21 19:14:04.938227
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy(lambda x: x).of(1).to_box() == Lazy(lambda x: x).of(1).to_box()
    assert Lazy(lambda x: x).of(2).to_box() != Lazy(lambda x: x).of(1).to_box()


# Generated at 2022-06-21 19:14:06.962021
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function():
        return 42

    lazy = Lazy(test_function)
    assert lazy.get() == 42
    assert lazy.get() == 42
# User test for method fold of class Lazy

# Generated at 2022-06-21 19:14:09.183840
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(2).ap(Lazy.of(lambda x: x * 5)) == Lazy.of(10)



# Generated at 2022-06-21 19:14:21.356884
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Tests for ap method in Lazy class
    """
    from pymonet.functor import Functor
    from pymonet.maybe import Maybe

    def add1(x):
        return x + 1

    # Function with one argument
    functor_with_one_arg = Functor(lambda x: lambda y: x + y)

    # Function with two arguments
    functor_with_two_arg = Functor(lambda x: lambda y: lambda z: x + y + z)

    assert Lazy.of(1).ap(functor_with_one_arg) == 2
    assert Lazy.of(1).ap(functor_with_two_arg) == 4

    # Function with one argument
    functor_with_one_arg_maybe = Maybe.of(lambda x: x + 1)

    # Function

# Generated at 2022-06-21 19:14:25.072545
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    class Mock:
        def __call__(self):
            return 1

    # WHEN
    first_lazy = Lazy(lambda: Mock())
    second_lazy = Lazy(lambda: 1)
    actual_result = first_lazy.ap(second_lazy)

    # THEN
    assert actual_result == Lazy(lambda: 1)



# Generated at 2022-06-21 19:14:29.203975
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def function_returning_5() -> int:
        return 5

    assert Lazy(function_returning_5).to_try() == Try.of(function_returning_5)

# Generated at 2022-06-21 19:14:33.999977
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test_function(a: str) -> int:
        return int(a)

    assert Lazy.of(test_function).map(lambda fn: fn('5')).get() == 5

    assert Lazy.of(test_function) \
        .map(lambda fn: fn('5')) \
        .map(lambda a: a + 1) \
        .get() == 6



# Generated at 2022-06-21 19:14:36.498516
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def foo(a):
        return a

    def bar(a):
        return a

    def baz(a):
        return a

    assert Lazy(foo).map(bar) == Lazy(baz).map(bar)


# Generated at 2022-06-21 19:15:09.585892
# Unit test for method get of class Lazy
def test_Lazy_get():
    def power(base, power):
        return base ** power

    lazy_power = Lazy(power)
    assert lazy_power.get(2, 10) == 1024

# Generated at 2022-06-21 19:15:14.871622
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: '')) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: 'a').map(lambda x: x + 'b')) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:15:26.261771
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for method get of class Lazy
    """
    lazy_empty = Lazy.of('')
    assert lazy_empty.get() == ''

    lazy_not_empty = Lazy.of('test')
    assert lazy_not_empty.get() == 'test'

    def fn(a):
        return a

    lazy_function = Lazy(fn)
    assert lazy_function.get('test') == 'test'

    lazy_function2 = Lazy(fn).map(fn)
    assert lazy_function2.get('test') == 'test'

    lazy_function3 = Lazy(fn).map(fn).map(fn)
    assert lazy_function3.get('test') == 'test'

    def fn2(a):
        def fn3(b):
            return a + b
       

# Generated at 2022-06-21 19:15:32.569481
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.functor import Functor

    def function_stub():
        return 'something'

    lazy_test = Lazy(function_stub)
    assert lazy_test == lazy_test
    assert lazy_test.get() == 'something'
    assert lazy_test == Lazy(function_stub)
    assert lazy_test.map(lambda x: x + '1').get() == 'something1'
    assert lazy_test.to_maybe().get() == 'something'
    assert lazy_test == Lazy.of('something')
    assert lazy_test == Functor.of(Lazy, 'something')



# Generated at 2022-06-21 19:15:40.144995
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def factorial(n):
        if n <= 1:
            return 1
        return n * factorial(n - 1)

    lazy = Lazy.of(2)
    assert lazy == Lazy.of(2)

    lazy = Lazy.of(lambda: 2)
    assert lazy == Lazy.of(lambda: 2)
    assert lazy != Lazy.of(lambda: 3)

    lazy = Lazy(factorial)
    assert lazy == Lazy(factorial)

    # Lazy in Lazy
    inner_lazy_1 = Lazy.of(1)
    inner_lazy_2 = Lazy.of(2)
    assert inner_lazy_1 != inner_lazy_2
    assert Lazy.of(inner_lazy_1) == Lazy.of(inner_lazy_1)

# Generated at 2022-06-21 19:15:44.592366
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(5).map(lambda x: x + 10).get() == 15
    assert Lazy(lambda x: x + 10).map(lambda x: x + 2).get(0) == 12
    assert Lazy(lambda x: x + 10).map(lambda x: x * 2).get(0) == 20


# Generated at 2022-06-21 19:15:51.078483
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def add(x):
        return x + 1

    def times(y):
        return y * 2

    def add_or_times(fn):
        if fn == 'add':
            return add
        elif fn == 'times':
            return times
        else:
            return lambda x: x

    assert Lazy.of(5).ap(Lazy.of('add')).get() == 6
    assert Lazy.of(5).ap(Lazy.of('times')).get() == 10
    assert Lazy.of(5).ap(Lazy.of('other')).get() == 5

# Generated at 2022-06-21 19:15:56.937382
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda: 1).get() == 1

    # Test for memoization
    a = []
    lazy = Lazy(lambda: a.append(1) or a.append(2) or len(a))
    assert lazy.get() == 2
    assert len(a) == 1
    assert lazy.get() == 2
    assert len(a) == 1

# Generated at 2022-06-21 19:16:02.870667
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    import pytest

    success_lazy = Lazy.of(1)

    assert(success_lazy.to_validation() == Validation.success(1))

    with pytest.raises(Exception):
        Lazy(lambda x: x / 0).to_validation()

    with pytest.raises(Exception):
        Lazy(lambda x: x / x).to_validation()



# Generated at 2022-06-21 19:16:06.399770
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def fn(a, b): return a+b

    lazy = Lazy(fn)


    assert lazy.to_try(1, 1) == Try.of(fn, 1, 1)

# Generated at 2022-06-21 19:17:11.157031
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def test():
        return 1

    assert Lazy(test).to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:17:20.356553
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(a, b, c):
        return a + b + c

    lazy_one = Lazy.of(1)
    lazy_two = Lazy.of(2)
    lazy_three = Lazy.of(3)

    sum_lazy = Lazy(lambda: add(lazy_one.get(), lazy_two.get(), lazy_three.get()))
    assert sum_lazy.get() == 6

    def raise_exception():
        raise Exception("Failed")

    lazy_add = Lazy(raise_exception)
    assert lazy_add.get() == lazy_add.get()



# Generated at 2022-06-21 19:17:22.543949
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def fn():
        return 1 / 0

    lazy = Lazy(fn)

    assert lazy.to_try() == Try.failure(ZeroDivisionError("division by zero"))



# Generated at 2022-06-21 19:17:28.881754
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x + 1).map(lambda x: x * 5) == Lazy(lambda x: (x + 1) * 5)
    assert Lazy(lambda x: x + 1).map(lambda x: x * 5).map(lambda x: x + 2) == Lazy(lambda x: (x + 1) * 5 + 2)
