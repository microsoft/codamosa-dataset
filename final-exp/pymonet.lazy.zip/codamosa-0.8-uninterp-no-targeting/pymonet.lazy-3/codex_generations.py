

# Generated at 2022-06-21 19:07:35.607043
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 'abc')) == "Lazy[fn=<function <lambda> at 0x7fc47caa0ea0>, value=None, is_evaluated=False]"



# Generated at 2022-06-21 19:07:36.466987
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is True


# Generated at 2022-06-21 19:07:44.275270
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Failure, Success

    def constructor_fn(*args):
        if args == (1, 2):
            raise ZeroDivisionError('test')
        return args

    def test_factory(*args):
        return Lazy(constructor_fn).to_try(*args)

    assert Failure(ZeroDivisionError('test')) == test_factory(1, 2)
    assert Success((3, 4)) == test_factory(3, 4)


# Generated at 2022-06-21 19:07:50.531562
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn1(x):
        return x + 1

    def fn2(x):
        return x + 2

    lazy1 = Lazy(fn1)
    lazy2 = Lazy(fn2)
    assert lazy1 == lazy1
    assert lazy1 != lazy2
    lazy3 = lazy1.map(lambda a: a + 2)
    assert lazy3 != lazy1



# Generated at 2022-06-21 19:07:52.809477
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda s: s.lower()).map(lambda s: s.upper()).bind(lambda s: Lazy.of(s)).get('Test') == 'TEST'
    assert Lazy(lambda s: s.lower()).bind(lambda x: Lazy(lambda s: s.upper())).get('Test') == 'TEST'

# Generated at 2022-06-21 19:07:57.037886
# Unit test for constructor of class Lazy
def test_Lazy():
    def or_zero(value: int) -> int:
        return value if value > 0 else 0

    value = 4
    lazy = Lazy(or_zero)
    assert lazy.get(value) == 4

    value = -4
    lazy = Lazy(or_zero)
    assert lazy.get(value) == 0



# Generated at 2022-06-21 19:08:04.495304
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test_lazy_map(lazy: Lazy[str, int], function: Callable[[int], str], expected: str):
        assert lazy.map(function).get('x') == expected

    test_lazy_map(Lazy(lambda x: '1' + x), lambda x: str(x + 1), '21')
    test_lazy_map(Lazy(lambda x: '1' + x), lambda x: str(x - 1), '19')



# Generated at 2022-06-21 19:08:09.236870
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = lambda x: x

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(lambda x: str(x))


# Generated at 2022-06-21 19:08:13.376072
# Unit test for method map of class Lazy
def test_Lazy_map():
    # given
    x = Lazy(lambda: 3)

    # then
    assert x.map(lambda x: x * 2) == Lazy(lambda: 6)



# Generated at 2022-06-21 19:08:16.612638
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add_two(arg):
        return arg + 2

    def add_three(arg):
        return arg + 3

    arg = 2
    result = Lazy(add_two).ap(Lazy(add_three)).get()

    assert result == arg + 5


# Generated at 2022-06-21 19:08:30.321169
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(first, second):
        return first + second

    def div(first, second):
        return first / second

    def add1(first):
        return first + 1

    def mult2(first):
        return first * 2

    assert Lazy(lambda: 5).get() == 5
    assert Lazy(add).get(3, 2) == 5
    assert Lazy(add).get(3, 2) == 5
    assert Lazy(div).get(6, 2) == 3
    assert Lazy(div).get(6, 2) == 3
    assert Lazy(div).map(add1).get(6, 2) == 4
    assert Lazy(add).map(div).get(6, 2) == 3
    assert Lazy(add).map(mult2).get(3, 2) == 10
   

# Generated at 2022-06-21 19:08:34.474913
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # GIVEN
    def sum(a, b):
        return a + b

    def multiply(a):
        return a * 2

    fn = Lazy(lambda x: sum(1, x))
    lazy_applicative = Lazy(lambda x: multiply(x))
    expected = Lazy(lambda x: multiply(sum(1, x)))

    # WHEN
    result = fn.ap(lazy_applicative)

    # THEN
    assert expected == result



# Generated at 2022-06-21 19:08:44.672818
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    import pytest
    from pymonet.maybe import Just

    def test_monad_transformer(monad):
        class Person:
            def __init__(self, name: str, age: int):
                self.name = name
                self.age = age

            def __eq__(self, other: object) -> bool:
                if not isinstance(other, Person):
                    return False

                return self.name == other.name and self.age == other.age

        def get_person_name():
            return Person('John', 30)

        person = monad(get_person_name)
        assert person.map(lambda person: person.name).get() == 'John'

    test_monad_transformer(Lazy.of)
    test_monad_transformer(Just)



# Generated at 2022-06-21 19:08:50.085045
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def identity(value):
        return value

    val = Lazy(identity).to_validation(identity)  # type: Validation[Callable[object], [object]]

    assert val.is_success
    assert val.get_value() == identity  # type: ignore



# Generated at 2022-06-21 19:08:55.369721
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def sum_n_times(n, value):
        return n + value

    def compute_sum(n):
        return Lazy.of(sum_n_times(n, 2))

    assert Lazy.of(2).ap(compute_sum(2)).constructor_fn() == 6



# Generated at 2022-06-21 19:09:00.656820
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def returns_nothing():
        return Lazy.of(None)

    def returns_just_something():
        return Lazy.of(42)

    assert returns_nothing().to_maybe() == Maybe.nothing()
    assert returns_just_something().to_maybe() == Maybe.just(42)



# Generated at 2022-06-21 19:09:11.362517
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    from pymonet.monad_try import Try

    from pymonet.validation import Validation

    assert Maybe.just('value') == Maybe.just(Lazy(lambda x: 'value').get('callable_arg'))
    assert Maybe.nothing() == Maybe.just(Lazy(lambda x: ['value'][1]).get('callable_arg'))
    assert Maybe.nothing() == Maybe.just(Lazy(lambda x: {}['value']).get('callable_arg'))
    assert Maybe.just('value') == Maybe.just(Lazy(lambda x: x).get(['value']))

# Generated at 2022-06-21 19:09:22.982633
# Unit test for constructor of class Lazy
def test_Lazy():
    def success(value):
        return Lazy(lambda *args: value)

    def fail(ex):
        return Lazy(lambda *args: raise_(ex))

    def empty(*args):
        return Lazy(lambda *args: None)

    assert lazy_test_suite(success, fail, empty)

    assert Lazy.of(2).get() == 2
    assert Lazy.of(2).to_box().get() == 2
    assert Lazy.of(2).to_maybe().get() == 2
    assert Lazy.of(2).to_either().get() == 2
    assert Lazy.of(2).to_try().get() == 2
    assert Lazy.of(2).to_validation().get() == 2



# Generated at 2022-06-21 19:09:27.268578
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.lazy_funcs import lazy_box

    assert Lazy.of(Box.of(2)).to_box() == Box.of(2)
    assert Lazy.of('foo').to_box() == Box.of('foo')
    assert Lazy.of(Box.of(2)).map(lazy_box).to_box() == Box.of(2)


# Generated at 2022-06-21 19:09:34.768829
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    f = lambda x: x + 1
    f_lazy = Lazy(f)

    assert f_lazy.to_validation(1) == Validation.success(2)
    assert f_lazy.to_validation(1) == Validation.success(2)
    assert f_lazy.to_validation(1) == Validation.success(2)
    assert f_lazy.to_validation(2).value == 3



# Generated at 2022-06-21 19:09:45.807500
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from .box import Box

    def inc(val):
        return Lazy.of(val + 1)

    def to_box(val):
        return Box(val)

    def inc_box(val):
        return Lazy.of(val.map(lambda x: x + 1))

    assert Lazy.of(1).bind(inc).get() == 2
    assert Lazy.of(1).bind(to_box).get() == 1
    assert Lazy.of(Box.of(1)).bind(inc_box).get().is_present() is True
    assert Lazy.of(Box.of(1)).bind(inc_box).get().get_value() == 2

# Generated at 2022-06-21 19:09:49.712299
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for method get of class Lazy
    """
    assert Lazy(lambda value: value + 1).get(1) == 2


# Generated at 2022-06-21 19:09:59.876710
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    lazy = Lazy.of(2)
    assert lazy.to_box() == Box(2)

    lazy = Lazy(lambda : 5)
    assert lazy.to_box() == Box(5)

    lazy = Lazy(lambda x: x + 2)
    assert lazy.to_box(5) == Box(7)

    lazy = Lazy.of(2)
    assert lazy.map(lambda value: value * 2).to_box() == Box(4)

    lazy = Lazy(lambda : 5)
    assert lazy.map(lambda value: value * 2).to_box() == Box(10)

    lazy = Lazy(lambda x: x + 2)
    assert lazy.map(lambda value: value * 2).to_box(5) == Box(14)


# Generated at 2022-06-21 19:10:04.182175
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    a_lazy = Lazy.of(1)

    assert a_lazy.to_box() == Box(1)
    assert a_lazy.to_box(1, 2, 3) == Box(1)


# Generated at 2022-06-21 19:10:09.866248
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet import Lazy, Either
    from pymonet.either import Left, Right

    def try_to_int(value: str) -> Either[Exception, int]:
        try:
            return Right(int(value))
        except ValueError as exception:
            return Left(exception)

    assert Lazy.of(None).to_either(try_to_int('1')) == Right(1)
    assert Lazy.of(None).to_either(try_to_int('a')) == Left(ValueError('invalid literal for int() with base 10: \'a\''))

# Generated at 2022-06-21 19:10:21.938193
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_list import MonadList
    from pymonet.monad_try import Try

    def mapper(x):
        return x + 10

    def ap_mapper(x):
        return x[0] + x[1]

    def err():
        raise ValueError()

    # call with Lazy with function returning error
    assert Lazy.of(mapper).ap(Lazy.of(err)).to_try() == Try.failure(ValueError)

    # call with empty MonadList
    assert Lazy.of(mapper).ap(MonadList([]).bind(lambda _: Lazy.of(err))).to_try() == Try.failure(ValueError)

    # call with Lazy[Function] and Lazy[]

# Generated at 2022-06-21 19:10:28.934263
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def function():
        pass

    def function1():
        pass

    def function_returning(value):
        return value

    def function1_returning(value):
        return value

    assert Lazy(function) == Lazy(function)
    assert Lazy(function).map(function_returning) == Lazy(function).map(function_returning)
    assert Lazy(function).map(function).map(function) == Lazy(function).map(function).map(function)
    assert Lazy(function_returning).map(function).map(function) == \
        Lazy(function_returning).map(function).map(function)
    assert Lazy(function).map(function_returning).map(function) != \
        Lazy(function).map(function_returning).map

# Generated at 2022-06-21 19:10:33.796492
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(10) == Lazy.of(10).to_validation()
    assert Validation.success(10) == Lazy(lambda x: 10).to_validation(10)


# Generated at 2022-06-21 19:10:40.811222
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def get_lazy_with_identity_fn():
        return Lazy(lambda x: x)

    def get_lazy_with_multiply_fn():
        return Lazy(lambda x, y: x * y)

    assert get_lazy_with_identity_fn().bind(get_lazy_with_identity_fn).get(3) == 3
    assert get_lazy_with_identity_fn().bind(get_lazy_with_multiply_fn).get(10, 2) == 20
    assert get_lazy_with_multiply_fn().bind(get_lazy_with_identity_fn).get(10, 5) == 50
    assert get_lazy_with_multiply_fn().bind(get_lazy_with_multiply_fn).get

# Generated at 2022-06-21 19:10:51.949626
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    """
    Unit test for method __eq__
    """
    assert Lazy.of(5) == Lazy.of(5)
    assert Lazy.of(5) != Lazy.of(10)
    assert Lazy.of(5).map(lambda x: x) == Lazy.of(5)
    assert Lazy.of(lambda x: x(5)).map(lambda y: y(10)) == Lazy.of(lambda x: x(10))
    assert Lazy.of(10).ap(Lazy.of(lambda x: x + 9)) == Lazy.of(19)
    assert Lazy.of(9).bind(lambda x: Lazy.of(x + 10)) == Lazy.of(19)

# Generated at 2022-06-21 19:10:56.804242
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)


# Generated at 2022-06-21 19:10:59.592376
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # pylint: disable=E1101
    assert Lazy.of('value').ap(Lazy.of(lambda x: x.upper())) == Lazy.of('VALUE')



# Generated at 2022-06-21 19:11:06.260182
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    """
    Check that to_validation really return Validation monad with wrapped value
    """

    from pymonet.validation import Validation

    lazy = Lazy.of(1)
    validation = lazy.to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.success_value.get() == 1



# Generated at 2022-06-21 19:11:12.646404
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for method bind in Lazy

    bind method is testing in all monads classes.
    I dont repeat all tests here.
    """
    from pymonet.box import Box

    def fn(x):
        return Box(x)

    def fn2(x):
        return Lazy.of(x)

    fn_ = Lazy.of(fn)

    assert(fn_.bind(fn).to_box() == Box(1))

# Generated at 2022-06-21 19:11:21.024198
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_lazy_eq(lazy, other, equals):
        assert (lazy.__eq__(other) == equals)

    test_lazy_eq(Lazy(lambda: 1), Lazy(lambda: 1), True)
    test_lazy_eq(Lazy(lambda: 1), Lazy(lambda: 2), False)
    test_lazy_eq(Lazy(lambda: 1), Lazy(lambda x: 1), False)
    test_lazy_eq(Lazy(lambda x: 1), Lazy(lambda x: 1), False)
    test_lazy_eq(Lazy(lambda: 1), 'a', False)


# Generated at 2022-06-21 19:11:24.197531
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x + 1).map(lambda x: x - 2) == Lazy(lambda x: x + 1).map(lambda x: x - 2)
    assert Lazy(lambda x: x + 1).map(lambda x: x - 2).map(lambda x: x * 3) == Lazy(lambda x: x + 1).map(lambda x: x * 3 - 6)



# Generated at 2022-06-21 19:11:28.633482
# Unit test for method get of class Lazy
def test_Lazy_get():
    def get_lazy():
        return Lazy.of('correct')

    assert get_lazy().get() == 'correct'

    def add(a, b):
        return a + b

    assert Lazy(add).get(1, 2) == 3


# Generated at 2022-06-21 19:11:32.375108
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(x):
        return x + 1

    lazy = Lazy(test_fn)

    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3


# Generated at 2022-06-21 19:11:35.284520
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left
    from pymonet.either import Right

    assert Lazy.of(Right(0)).to_either() == Right(0)
    assert Lazy.of(Left(0)).to_either() == Left(0)


# Generated at 2022-06-21 19:11:42.264925
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(100).to_either() == Right(100)
    assert Lazy.of(True).to_either() == Right(True)
    assert Lazy.of('some value').to_either() == Right('some value')
    assert Lazy.of((1, 2, 3)).to_either() == Right((1, 2, 3))
    assert Lazy.of(None).to_either() == Right(None)

# Generated at 2022-06-21 19:11:48.604854
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(str).__eq__(Lazy(str)) is False
    assert Lazy(str).__eq__(Lazy(str).map(str)) is False
    assert Lazy(str).__eq__(Lazy(str)._compute_value('aa')) is True


# Generated at 2022-06-21 19:11:51.135253
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)


# Generated at 2022-06-21 19:11:54.447679
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Lazy.of(1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-21 19:11:59.055840
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 2).bind(lambda n: Maybe.just(n * 11)).get() == 22
    assert Maybe.just(3).bind(lambda n: Lazy(lambda: n * 11)).get() == 33
    assert Lazy(lambda: 2).bind(lambda n: Box(n * 11)).get() == 22
    assert Box(3).bind(lambda n: Lazy(lambda: n * 11)).get() == 33

# Generated at 2022-06-21 19:12:01.833871
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(0).to_either() == Right(0)
    assert Lazy.of(lambda: 0).to_either() == Right(0)


# Generated at 2022-06-21 19:12:09.943150
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__(): # pragma: no cover
    from pymonet.functor import Functor

    def func():
        return 42

    def func2():
        return 23

    lazy_1 = Lazy(func)
    lazy_2 = Lazy(func2)
    lazy_3 = Lazy(func)

    assert lazy_1 == lazy_1
    assert lazy_1 == lazy_3
    assert lazy_1 != lazy_2
    assert lazy_1 != []
    assert lazy_1 == Functor.of(lazy_1.get())
    assert lazy_1 != Functor.of(lazy_2.get())


# Generated at 2022-06-21 19:12:12.716518
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    lazy = Lazy.of(42)

    assert lazy.to_validation() == Validation.success(42)

# Generated at 2022-06-21 19:12:20.463775
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def add(x, y):
        return x + y

    lazy = Lazy(add)
    assert lazy.constructor_fn == add

    assert lazy.is_evaluated == False
    assert lazy.value == None

    assert lazy.get(1, 2) == 3
    assert lazy.is_evaluated == True
    assert lazy.value == 3

    # second call do nothing
    assert lazy.get(1, 2) == 3
    assert lazy.is_evaluated == True
    assert lazy.value == 3


# Generated at 2022-06-21 19:12:30.848342
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left

    def take_none():
        return None

    def take_my_str():
        return 'test'

    def take_none_and_raise_error():
        raise ValueError

    lazy_none = Lazy(take_none)
    lazy_my_str = Lazy(take_my_str)
    lazy_with_error = Lazy(take_none_and_raise_error)

    assert lazy_none.to_either() == Right(None)
    assert lazy_my_str.to_either() == Right('test')
    assert lazy_with_error.to_either() == Left(ValueError())


# Generated at 2022-06-21 19:12:41.641400
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    class A:
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return 'A[{}]'.format(self.value)

    def test(n):
        return A(n)

    lazy_value = Lazy(test)
    assert str(lazy_value) == 'Lazy[fn=<function test at 0x1014a52a8>, value=None, is_evaluated=False]'

    lazy_value.get(5)

    assert str(lazy_value) == 'Lazy[fn=<function test at 0x1014a52a8>, value=A[5], is_evaluated=True]'



# Generated at 2022-06-21 19:12:48.309080
# Unit test for method map of class Lazy
def test_Lazy_map():
    def method_to_call(value):
        return value + 1

    lazy_instance = Lazy(method_to_call)
    assert lazy_instance.map(lambda x: x + 10).get(1) == 12



# Generated at 2022-06-21 19:12:49.597173
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(5).get() == 5



# Generated at 2022-06-21 19:12:56.463185
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x:x+1).map(lambda x:x-1).get(10) == 10
    assert Lazy(lambda x:x+1).map(lambda x:x+10).get(10) == 21
    assert Lazy(lambda:1).map(lambda x:x+1).get() == 2
    assert Lazy(lambda:1).map(lambda x:x+10).get() == 11



# Generated at 2022-06-21 19:12:59.836489
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy.of(2).to_maybe() == Maybe.just(2)
    assert Lazy(lambda: 2 / 0).to_maybe() == Maybe.just(2)



# Generated at 2022-06-21 19:13:04.529927
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def catcher(a):
        try:
            return a / 0
        except ZeroDivisionError as e:
            return e

    lazy = Lazy.of(2)
    value = lazy.map(catcher).to_either()
    error = lazy.map(catcher)

    assert value.is_right() == True
    assert value.get() == 2
    assert error.to_either().is_left() == True
    assert isinstance(error.to_either().swap().get(), ZeroDivisionError)



# Generated at 2022-06-21 19:13:14.792941
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from types import FunctionType
    from unittest.mock import Mock

    fn = Mock(spec=FunctionType)
    fn.__name__ = 'fn'
    lazy = Lazy(fn)
    assert str(lazy) == 'Lazy[fn=<MagicMock name=\'fn\' id=\'...\'>, value=None, is_evaluated=False]'
    lazy.get()
    assert str(lazy) == 'Lazy[fn=<MagicMock name=\'fn\' id=\'...\'>, value=None, is_evaluated=True]'
    lazy = Lazy(fn)
    lazy.get()
    assert str(lazy) == 'Lazy[fn=<MagicMock name=\'fn\' id=\'...\'>, value=None, is_evaluated=True]'

# Generated at 2022-06-21 19:13:19.227778
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 1).to_maybe() == Maybe.just(1)
    assert Lazy(lambda: None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:13:25.788867
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right

    def test_Lazy_to_either_when_wrap_function():
        assert Lazy(lambda: 1).to_either() == Right(1)

    def test_Lazy_to_either_when_wrap_value():
        assert Lazy.of(1).to_either() == Right(1)

    def test_Lazy_to_either_with_args():
        assert Lazy(lambda a: a).to_either(1) == Right(1)

    test_Lazy_to_either_when_wrap_function()
    test_Lazy_to_either_when_wrap_value()
    test_Lazy_to_either_with_args()



# Generated at 2022-06-21 19:13:29.265952
# Unit test for method map of class Lazy
def test_Lazy_map():
    result = Lazy(lambda: 1).map(lambda x: x + 1)
    assert result.constructor_fn() == 2
    assert result.get() == 2


# Generated at 2022-06-21 19:13:32.362349
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    fn = lambda x: Lazy(lambda x: x)
    lazy = Lazy(fn)

    assert lazy.bind(fn).get(10) == 10

# Generated at 2022-06-21 19:13:39.635976
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # given
    fn = lambda x: x + 1
    lazy = Lazy.of(1)

    # when
    lazy = lazy.bind(lambda x: Lazy.of(fn(x)))

    # then
    assert lazy.get() == fn(1)



# Generated at 2022-06-21 19:13:44.940288
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def mapper(i, j):
        return i + j

    maybe_mapper = Maybe.of(mapper)
    maybe = Maybe.of(1)
    lazy = Lazy.of(2)
    result = maybe_mapper.ap(maybe.ap(lazy))
    assert Maybe.of(3) == result



# Generated at 2022-06-21 19:13:48.430473
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(Box(10)).to_box() == Box(10)
    assert Lazy.of(Box(10)).to_box(5) == Box(10)


# Generated at 2022-06-21 19:13:56.867713
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def divide(x, y):
        if y == 0:
            raise ZeroDivisionError('Division by zero')
        return x / y

    def divide_lazy(x, y) -> Lazy[int, int]:
        return Lazy(lambda: divide(x, y))

    assert divide_lazy(4, 2).to_try().get() == 2
    assert divide_lazy(4, 0).to_try().get() == divide(4, 0)



# Generated at 2022-06-21 19:13:59.415182
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    lazy = Lazy(lambda x: x)
    assert lazy.to_box(1) == Box(1)



# Generated at 2022-06-21 19:14:02.248630
# Unit test for constructor of class Lazy
def test_Lazy():
    def test_fn():
        return "lazy"

    lazy = Lazy(test_fn)

    lazy.get()

    assert lazy.value == "lazy"
    assert lazy.is_evaluated



# Generated at 2022-06-21 19:14:07.865654
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    def test_function(arg):
        return arg

    assert Lazy.of(1).to_validation(1) == Validation.success(1)
    assert Lazy(test_function).to_validation(1) == Validation.success(1)
    assert Lazy(test_function).to_validation(0) == Validation.success(0)


# Generated at 2022-06-21 19:14:12.957021
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left
    assert Lazy.of(23).to_either() == Right(23)
    assert Lazy(lambda: raise_value_error()).to_either() == Left(ValueError('test exception'))


# Generated at 2022-06-21 19:14:16.792840
# Unit test for method to_either of class Lazy

# Generated at 2022-06-21 19:14:18.659612
# Unit test for method get of class Lazy
def test_Lazy_get():
    def stub_func():
        return 1

    assert Lazy(stub_func).get() == 1


# Generated at 2022-06-21 19:14:28.256920
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x000001DA5E9C9598>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:14:32.440371
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    test_lazy = Lazy(lambda: 10)
    assert test_lazy == Lazy(lambda: 10)

    assert not test_lazy == Lazy(lambda: 12)
    assert not test_lazy == None
    assert not test_lazy == (10, 20)
    assert not test_lazy == 'test'


# Generated at 2022-06-21 19:14:35.716916
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    class TestClass(object):
        pass

    test_instance = TestClass()
    call_result = None

    lazy_instance = Lazy(lambda: test_instance)

    def fn(test_instance):
        nonlocal call_result
        call_result = test_instance
        return Lazy(lambda: 44)

    returned_instance = lazy_instance.bind(fn)
    assert call_result is test_instance

    assert 44 == returned_instance.get()


# Generated at 2022-06-21 19:14:38.643199
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(None).get() is None
    assert Lazy(lambda x: x + 1).get(3) == 4


# Generated at 2022-06-21 19:14:49.247052
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe

    assert Lazy.of(1).bind(lambda x: Lazy.of(x)).get() == 1
    assert Lazy.of(1).bind(lambda x: Lazy.of(x)).bind(lambda x: Lazy.of(x)).get() == 1
    assert Lazy.of(1).bind(lambda x: Lazy.of(x)).bind(lambda x: Lazy.of(x)).bind(lambda x: Lazy.of(x)).get() == 1
    assert (
        Lazy.of(1).bind(lambda x: Lazy.of(x)).bind(lambda x: Lazy.of(x)).bind(lambda x: Lazy.of(x))
        .bind(lambda x: Maybe.of(x)).get()
        == 1
    )

# Generated at 2022-06-21 19:14:52.044354
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def func(a: int) -> int:
        return a + 5

    lazy_test = Lazy(func)
    lazy_test = lazy_test.ap(Lazy(lambda x: 5))

    assert lazy_test.get() == 10



# Generated at 2022-06-21 19:14:54.449397
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    lazy_with_value = Lazy.of('value')

    assert lazy_with_value.to_box() == Box('value')



# Generated at 2022-06-21 19:14:57.730333
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    import pytest

    from pymonet.either import Left

    lazy_either = Lazy.of(123).to_either()

    assert isinstance(lazy_either, Left)
    assert lazy_either.value == 123


# Generated at 2022-06-21 19:15:00.845481
# Unit test for method get of class Lazy
def test_Lazy_get():
    def f():
        return 10

    def g():
        return "hello"

    def h():
        return None

    assert Lazy(f).get() == 10
    assert Lazy(g).get() == "hello"
    assert Lazy(h).get() is None

# Generated at 2022-06-21 19:15:06.852493
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet import monad_try
    from pymonet.validation import Validation

    def lmbda_return_a(*args) -> int:
        return 1

    def lmbda_return_b(*args) -> int:
        return 2

    def lmbda_return_string(*args) -> str:
        return 'test_string'

    lazy_test_1 = Lazy.of(1)
    lazy_test_2 = Lazy.of(2)


# Generated at 2022-06-21 19:15:11.844883
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)


# Generated at 2022-06-21 19:15:16.175558
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Either

    def add(a, b):
        return a + b

    lazy_add = Lazy(add)

    assert lazy_add.ap(Lazy.of(5)).get(10) == 15
    assert lazy_add.ap(Either.right(5)).right.get(10) == 15



# Generated at 2022-06-21 19:15:22.406755
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(number):
        return lambda value: value + number

    assert Lazy.of(1).ap(Box(add(2))).get() == 3
    assert Lazy.of(1).ap(Maybe.just(add(2))).to_maybe().get() == 3


# Generated at 2022-06-21 19:15:28.845065
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    :return: None
    :rtype: None
    """
    assert Lazy.of(1).to_try() == Try.of(lambda: 1)
    assert Lazy.of(None).to_try() == Try.of(lambda: None)
    assert Lazy.of(False).to_try() == Try.of(lambda: False)
    assert Lazy.of([None, False]).to_try() == Try.of(lambda: [None, False])



# Generated at 2022-06-21 19:15:30.432344
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(2).ap(Lazy.of(lambda a: a + 1)) == Lazy.of(3)


# Generated at 2022-06-21 19:15:36.664986
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    unit test for method map
    :returns: Nothing
    :rtype: None
    """
    def _(constructor_fn, mapper):
        lazy_1 = _mock_Lazy(constructor_fn)
        lazy_2 = Lazy(mapper)
        lazy_3 = lazy_1.map(mapper)

        assert lazy_2 == lazy_3

    _call_with_all_fns(_)


# Generated at 2022-06-21 19:15:40.963742
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pylint: disable=W0612
    def test_function(value):
        return value + 10

    lazy_result = Lazy.of(10)
    lazy_value = lazy_result.bind(test_function)
    assert lazy_value.get() == 20



# Generated at 2022-06-21 19:15:45.603545
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy.of(1234).to_try() == Try.success(1234)

    try:
        def fn_raise_exception():
            raise ValueError

        assert Lazy(fn_raise_exception).to_try() == Try.error(ValueError)
    except:
        assert False

# Generated at 2022-06-21 19:15:47.852378
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    input = Lazy.of(10)
    assert input.to_validation() == Validation.success(input.get())

# Generated at 2022-06-21 19:15:49.269739
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(5).to_either() == Right(5)



# Generated at 2022-06-21 19:15:56.986571
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return

    assert Lazy.of(fn).__eq__(Lazy.of(fn))
    assert not Lazy.of(fn).__eq__(Lazy(fn))



# Generated at 2022-06-21 19:16:03.129737
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.either import Left

    lazy_of_maybe_3 = Lazy.of(Maybe.just(3))
    assert lazy_of_maybe_3.to_maybe() == Maybe.just(3)
    assert lazy_of_maybe_3.to_maybe() == Maybe.just(3)

    lazy_of_left = Lazy.of(Left(10))
    assert lazy_of_left.to_maybe() == Maybe.empty()

# Generated at 2022-06-21 19:16:07.283377
# Unit test for method map of class Lazy
def test_Lazy_map():
    def return_one():
        return 1

    lazy = Lazy(return_one)

    def add1(value):
        return value + 1

    assert lazy.map(add1).constructor_fn() == 2



# Generated at 2022-06-21 19:16:17.632260
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def simple_function():
        return 2

    def mapper(value):
        return value * 2

    def applicative_function(value):
        return value * 2

    def folder(value):
        return Box(value * 4)

    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(2) == Lazy(simple_function)

    fn = Lazy.of(2)

    assert fn.bind(folder) == Lazy(lambda: Box(8))

    assert fn == fn.map(mapper)


# Generated at 2022-06-21 19:16:19.730054
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(3).to_box() == 3



# Generated at 2022-06-21 19:16:24.454954
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Lazy.of(1).to_maybe()
    assert Maybe.just(Box(1)) == Lazy.of(Box(1)).to_maybe()



# Generated at 2022-06-21 19:16:32.563763
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    def add(x: int, y: int) -> int:
        return x + y

    def read_file(file_name: str) -> str:
        with open(file_name, 'r') as file:
            return file.read()

    def with_error() -> str:
        raise Exception('Error')

    assert Lazy(add).__eq__(Lazy(add)) == True

    assert Lazy(add).__eq__(Lazy(read_file)) == False

    assert Lazy(read_file).__eq__(Lazy(read_file)) == True

    assert Lazy(add).__eq__(Lazy(with_error)) == False

# Generated at 2022-06-21 19:16:38.606039
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Lazy(lambda: 5).to_try() == Try.of(lambda: 5)
    assert Lazy(lambda: 5).to_try(6) == Try.of(lambda: 5)
    assert Lazy(lambda x: x).to_try(6) == Try.of(lambda x: x, 6)

    try:
        Lazy(lambda: 5 / 0).to_try()
    except ZeroDivisionError:
        assert True
    else:
        assert False

    try:
        Lazy(lambda: 5 / 0).to_try(6)
    except ZeroDivisionError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 19:16:42.018962
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(Left(1)).to_either() is Left(1)


# Generated at 2022-06-21 19:16:46.035872
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """Test bind method of Lazy class."""
    lazy_add_1 = Lazy(lambda x: x + 1)
    result = lazy_add_1.bind(lambda x: Lazy.of(x ** 2)).get(2)

    assert result == 9


# Generated at 2022-06-21 19:16:53.650616
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(2) != Lazy.of(2)
    assert Lazy.of(2) == Lazy.of(2)


if __name__ == '__main__':
    test_Lazy___eq__()

# Generated at 2022-06-21 19:16:57.808074
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def some_function():
        return "some value"

    lazy_obj = Lazy(some_function)
    lazy_obj_empty = Lazy(lambda: None)

    assert lazy_obj.to_maybe() == Maybe.just("some value")
    assert lazy_obj_empty.to_maybe() == Maybe.nothing()

# Generated at 2022-06-21 19:17:03.735242
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    first = Lazy.of(2)
    second = Lazy.of(2)

    third = first.map(lambda x: x + 2)
    fourth = second.map(lambda x: x + 2)

    fifth = Lazy.of(1)
    sixth = Lazy.of(3)

    assert first == second
    assert third == fourth
    assert first != third
    assert first != fifth
    assert first != sixth



# Generated at 2022-06-21 19:17:07.958537
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """
    case 1
    """
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)

    """
    case 2
    """

    def foo(a):
        raise Exception()

    from pymonet.either import Left

    assert Lazy(foo).to_either() == Left(Exception)

# Generated at 2022-06-21 19:17:14.654025
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Test to_try method of class Lazy

    :returns: nothing
    :rtype: None
    """
    from pymonet.monad_try import Try
    from pymonet.monad_try import Error

    def fn(*args):
        return args[0] + args[1]

    try_instance = Try.of(fn, 2, 2)
    assert try_instance == Lazy.of(fn).to_try(2, 2)

    def throw_fn(*args):
        raise ValueError('error')

    assert Try.of(throw_fn) == Lazy.of(throw_fn).to_try()

    try_instance = Try.of(throw_fn)
    assert Lazy.of(throw_fn).to_try() == try_instance

# Generated at 2022-06-21 19:17:16.840807
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def fn(value):
        return Lazy(lambda *args: value + ' -> ')

    assert Lazy.of('value').bind(fn).get() == 'value -> '

# Generated at 2022-06-21 19:17:18.151697
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)

# Generated at 2022-06-21 19:17:22.072274
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f1(x):
        return Lazy.of(x)

    def f2(x):
        return Lazy.of(x)

    lazy = Lazy(lambda x: x)
    assert lazy.bind(f1).bind(f2).get(10) == 10



# Generated at 2022-06-21 19:17:24.983372
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(3).ap(Lazy.of(lambda x: x + 1)) == Lazy.of(4)



# Generated at 2022-06-21 19:17:34.517703
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    When you call fold method for lazy value you also call all previous mappers applied for lazy value.
    So, after creating lazy value with some mappers, you can to create Lazy with bind method,
    then call fold method for it and all previous mappers will be called.
    """
    def mapper1(arg):
        return arg * 2

    def mapper2(arg):
        return arg + 10

    def mapper3(arg):
        return arg * 4

    def mapper4(arg):
        return arg - 10

    assert Lazy(mapper1).map(mapper2).map(mapper3).map(mapper4).bind(lambda arg: Lazy(lambda: arg)).get() == 10 * 2 * 4 * 2 * 4 * 2 * 4 - 10

