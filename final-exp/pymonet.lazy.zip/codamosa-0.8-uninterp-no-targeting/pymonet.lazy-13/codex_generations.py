

# Generated at 2022-06-21 19:07:34.259105
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy.of('some string').to_maybe() == Maybe.just('some string')
    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy.of(None).to_maybe() == Maybe.just(None)



# Generated at 2022-06-21 19:07:38.523123
# Unit test for method get of class Lazy
def test_Lazy_get():

    def test():
        return 5

    lazy = Lazy(test)

    assert lazy.get() == 5
    assert lazy.get() == 5
    assert lazy.get() == 5
    assert lazy.get() == 5


# Generated at 2022-06-21 19:07:43.758690
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left
    def f(a: int) -> str:
        return 'a=%i' % a

    assert Lazy(f).to_either(10) == Right('a=10')
    assert Lazy(f).bind(lambda a: Left(a)).to_either(10) == Left('a=10')

# Generated at 2022-06-21 19:07:52.129481
# Unit test for constructor of class Lazy
def test_Lazy():

    def fn_a():
        return 5

    def fn_b(a):
        return a ** 2

    a = Lazy(fn_a)
    a_b = a.map(fn_b)
    assert a_b.get() == 25

    b = Lazy(fn_b)
    a_b = b.ap(a)
    assert a_b.get() == 25

    def fn_c(a):
        return Lazy(lambda: a + 1)

    a_c = a.bind(fn_c)
    assert a_c.get() == 6

# Generated at 2022-06-21 19:07:57.294404
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    increment = Lazy(lambda x: x + 1)
    double = Lazy(lambda x: x * 2)

    assert increment.ap(double).get(2) == 8

# Generated at 2022-06-21 19:08:03.320114
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    import pymonet.monad_try

    get_id = lambda x: Lazy(lambda: x['id'])
    get_name = lambda x: Lazy(lambda: x['name'])

    result = (get_id({'id': 12, 'name': 'John'})
              .bind(lambda x: get_name({'id': x, 'name': 'John'}))
              .bind(lambda name: Lazy(lambda: name.to_upper())))

    assert result.to_try() == pymonet.monad_try.Try.success('JOHN')

# Generated at 2022-06-21 19:08:12.034443
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    result = Lazy(lambda x: x**3).to_validation(2)
    assert isinstance(result, Validation)
    assert result.is_success()
    assert result.get_or_else(9) == 8



# Generated at 2022-06-21 19:08:13.995829
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(0).to_box() == Box(0)



# Generated at 2022-06-21 19:08:16.241768
# Unit test for method get of class Lazy
def test_Lazy_get():
    import pytest

    def constructor_fn():
        return 10

    lazy = Lazy(constructor_fn)
    index = lazy.get()

    assert index == 10



# Generated at 2022-06-21 19:08:21.660547
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy.of(1).to_maybe(1) == Maybe.just(1)
    assert Lazy.of(1).to_maybe(1, 2) == Maybe.just(1)
    assert Lazy.of(1).to_maybe(1, 2, 3) == Maybe.just(1)

# Generated at 2022-06-21 19:08:28.841441
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def f():
        raise Exception('test')

    assert Lazy.of(5).to_try() == Try.of(lambda: 5)
    assert Lazy(f).to_try() == Try.of(f)



# Generated at 2022-06-21 19:08:37.431885
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.box import Box

    # ------------------------------------------------------------------
    # Lazy.of

    lazy = Lazy.of('foo')
    assert lazy.get() == 'foo'

    # ------------------------------------------------------------------
    # Lazy.map

    assert lazy.map(lambda value: "{}!!".format(value)).get() == 'foo!!'

    # ------------------------------------------------------------------
    # Lazy.ap

    number = Box(10)
    assert lazy.ap(number).get() == 'foo'

    # ------------------------------------------------------------------
    # Lazy.ap

    assert lazy.bind(lambda value: lazy).get() == 'foo'

# Generated at 2022-06-21 19:08:40.349814
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    lazy = Lazy.of(1)

    assert isinstance(lazy.to_box(), Box)
    assert lazy.to_box().get() == 1

# Generated at 2022-06-21 19:08:48.355229
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    Unit test for class Lazy

    :return: None
    :rtype: None
    """
    import pymonet.test.test_helpers as test_helpers
    import pymonet.test.test_helpers_more as test_helpers_more
    import pymonet.test.test_helpers_for_lazy as test_helpers_for_lazy

    test_helpers.test_object_not_equals(Lazy(lambda x: x + 1), Lazy(lambda x: x + 2))
    test_helpers.test_object_not_equals(Lazy(lambda x: x + 1), Lazy(lambda x: x + 1), params=(2, ))

# Generated at 2022-06-21 19:08:51.236977
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy(lambda: 1).to_either() == Right(1)



# Generated at 2022-06-21 19:08:59.900872
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    def f(x):
        return x + 5

    def g(x):
        return x * 6

    assert Lazy(f).ap(Lazy(g)).get(5) == 50

    assert Try.of(f).ap(Try.of(g)).get() == 50

    assert Validation.success(f).ap(Validation.success(g)).get() == 50



# Generated at 2022-06-21 19:09:06.448825
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.either import Right

    func_mapper = lambda x: x
    mapper_validation_fn = lambda value: Validation.failure(Maybe(value))

    assert Lazy.of(1) == Lazy(lambda *args: 1)
    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(1).to_either(2) == Right(1)

    assert Lazy(lambda *args: 1).to_either() == Right(1)
    assert Lazy(lambda *args: 1).to_either(2) == Right(1)

    assert Lazy(lambda *args: 1).map(func_mapper).to_either() == Right(1)
   

# Generated at 2022-06-21 19:09:11.601852
# Unit test for method map of class Lazy
def test_Lazy_map():
    result_lazy_fn = Lazy(lambda x: x * x).map(lambda x: x + x).map(lambda x: x - 1)

    assert result_lazy_fn.constructor_fn == (lambda x: (x * x) + (x * x) - 1)
    assert result_lazy_fn._compute_value(2) == 7



# Generated at 2022-06-21 19:09:16.527682
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.either import Left
    from pymonet.lazy import Lazy

    def my_value(*args):
        return 'value'

    def my_error(error):
        return error

    lazy = Lazy(my_value)
    assert lazy.to_either() == Right('value')

    lazy_from_error = Lazy(my_error)
    assert lazy_from_error.to_either(error='error') == Left('error')


if __name__ == '__main__':  # pragma: no cover
    test_Lazy_to_either()

# Generated at 2022-06-21 19:09:26.589426
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def test(obj):
        return 1 / obj

    def test_failed(obj):
        return 1 / obj
        # can't handle this type of exception

    def test_failed_with_global_error(obj):
        raise RuntimeError('lalal')

    result = Lazy(lambda: 1).to_try()
    assert result == Try.success(1), 'Result is not Try.success(1) but {}'.format(result)

    result = Lazy(lambda: test(1)).to_try()
    assert result == Try.success(1), 'Result is not Try.success(1) but {}'.format(result)

    result = Lazy(lambda: test_failed('a')).to_try()
    assert result == Try.failure

# Generated at 2022-06-21 19:09:38.386133
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    assert Lazy(lambda: 1).to_either().equals(Right(1))
    assert Lazy(lambda: 1).map(lambda x: x + 1).to_either().equals(Right(2))
    assert Lazy(lambda: None).to_either().equals(Right(None))
    assert Lazy(lambda: None).map(lambda x: x + 1).to_either().equals(Right(None))
    assert Lazy(lambda: None).map(lambda x: x is None).to_either().equals(Right(None))
    assert Lazy(lambda: None).bind(lambda x: Lazy.of(x + 1)).to_either().equals(Right(None))


# Generated at 2022-06-21 19:09:40.220991
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(x, y):
        return x + y

    assert Lazy(add).get(1, 2) == 3

# Generated at 2022-06-21 19:09:45.019886
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.maybe import Maybe
    from pymonet.either import Left, Right

    assert Lazy(lambda: 'A').to_either() == Right('A')

    assert Lazy(lambda: Maybe.nothing()).to_either('B') == Left('B')

# Generated at 2022-06-21 19:09:54.313565
# Unit test for method get of class Lazy
def test_Lazy_get():
    import pytest

    class Mock:
        def __init__(self):
            self.i = 0

        def m(self):
            self.i += 1

    m = Mock()
    lazy = Lazy(m.m)
    assert m.i == 0
    assert lazy.get() == None
    assert m.i == 1
    assert lazy.get() == None
    assert m.i == 1

    lazy = Lazy(lambda x: x)
    assert lazy.get(5) == 5
    assert lazy.get(5) == 5



# Generated at 2022-06-21 19:10:02.702125
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import empty_validation
    from pymonet.validation import Validation
    from pymonet.validation_errors import ValidationError

    def divide(arg1, arg2):
        if arg2 == 0:
            raise ValidationError('Division by zero')
        return arg1 / arg2

    validation = Lazy(divide)

    assert validation.to_validation(1, 1) == Validation.success(1.0)
    assert validation.to_validation(1, 0) == empty_validation.append_error(ValidationError('Division by zero'))

# Generated at 2022-06-21 19:10:06.073206
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(4).map(lambda i: i ** 2).get() == 16
    assert Lazy.of(4).map(lambda i: i ** 2).get() == 16
    assert Lazy.of(4).map(lambda i: i ** 2).map(lambda i: i + 1).get() == 17
    assert Lazy.of(4).map(lambda i: i ** 2).map(lambda i: i + 1).get() == 17



# Generated at 2022-06-21 19:10:08.122456
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
        from pymonet.validation import Validation

        lazy = Lazy.of(1)
        validation = lazy.to_validation()

        assert validation == Validation.success(1)

# Generated at 2022-06-21 19:10:11.626579
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    assert Lazy.of(2).to_try() == Lazy.of(2).to_try(1, 2, 3, 4)

# Generated at 2022-06-21 19:10:16.978222
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(42).to_box() == Box(42)
    assert Lazy.of(42).map(lambda x: x + 5).to_box() == Box(47)
    assert Lazy.of(lambda x: x + 5).to_box()(47) == Box(52)



# Generated at 2022-06-21 19:10:22.468984
# Unit test for method map of class Lazy
def test_Lazy_map():
    def map1(x: int) -> str:
        return str(x)

    def add1(x: int) -> int:
        return x+1

    lazy = Lazy.of(3)
    lazy_mapped_add1 = lazy.map(map1)
    assert str(lazy_mapped_add1) == 'Lazy[fn=<function test_Lazy_map.<locals>.lambda_fn at 0x7f22c2bf2a60>, value=None, is_evaluated=False]'
    assert lazy_mapped_add1.get() == '3'
    lazy_mapped = lazy.map(add1)

# Generated at 2022-06-21 19:10:27.411503
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.functor import Functor

    from pymonet.lazy import Lazy

    double = Lazy(lambda x: x * 2)
    double_mapper = Lazy(lambda x: x + 2)

    assert Functor(double).ap(double_mapper).get(3) == 8

# Generated at 2022-06-21 19:10:29.589583
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)



# Generated at 2022-06-21 19:10:36.766320
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    import os.path

    lazy_fn = Lazy(os.path.exists)

    assert str(lazy_fn) == 'Lazy[fn=<built-in function exists>, value=None, is_evaluated=False]'

    lazy_fn._compute_value(__file__)

    assert str(lazy_fn) == 'Lazy[fn=<built-in function exists>, value=True, is_evaluated=True]'


# Generated at 2022-06-21 19:10:41.915488
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda a, b: b)



# Generated at 2022-06-21 19:10:44.008623
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x : x + 1).get() == 2


# Generated at 2022-06-21 19:10:51.954136
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def f(x: int) -> str:
        return str(x)

    lazy = Lazy(f)

    assert lazy.__str__() == 'Lazy[fn=<function test_Lazy___str__.<locals>.f at 0x7fd8da8f9d90>, value=None, is_evaluated=False]'
    assert str(lazy) == 'Lazy[fn=<function test_Lazy___str__.<locals>.f at 0x7fd8da8f9d90>, value=None, is_evaluated=False]'


# Generated at 2022-06-21 19:11:03.533336
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    data = [1, 2, 3]

    # ToTry with successful Try
    assert Lazy(lambda: data).to_try() == Try.of(lambda: data)

    # ToTry with failed Try
    # - Function will be called
    # - Expection will be ignored
    # - Result will be Try with exception
    def _exception_function(*args) -> int:
        raise ValueError('Test exception')

    assert Lazy(_exception_function).to_try() == Try.of(_exception_function)

    # ToTry with failed Try and arguments
    # - Function will be called with arguments
    # - Expection will be ignored
    # - Result will be Try with exception
    def _exception_function_with_args(*args) -> int:
        raise ValueError

# Generated at 2022-06-21 19:11:12.197143
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Unit test to test 'map' method of Lazy class

    :returns: Nothing
    :rtype: None
    """
    assert Lazy(
        lambda x: x + 1
    ).map(
        lambda x: x + 1
    ).map(
        lambda x: x + 1
    ) == Lazy(
        lambda x: 3 + x
    )

    assert Lazy(
        lambda x: x + 1
    ).map(
        lambda x: x + 1
    ).map(
        lambda x: x + 1
    ).get(5) == 9


# Generated at 2022-06-21 19:11:13.586004
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 5).get() == 5



# Generated at 2022-06-21 19:11:19.669865
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try, exception

    result = Try.of(lambda: 5 / 2) == Lazy(lambda: 5 / 2).to_try()
    assert result == True

    result = Try.of(lambda: 5 / 0) == Lazy(lambda: 5 / 0).to_try()
    assert isinstance(result, Try)
    assert result.get_or_else() == exception



# Generated at 2022-06-21 19:11:30.378473
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda n: Lazy.of(n + 1)).get() == 2
    assert Lazy.of([1]).bind(lambda n: Lazy.of(n + [2])).get() == [1, 2]
    assert Lazy.of({1: 1}).bind(lambda n: Lazy.of(n.update({2: 2}))).get() == { 1: 1, 2: 2 }


# Generated at 2022-06-21 19:11:38.143169
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.maybe import Maybe

    lazy_function = Lazy(
        lambda: "foo_value"
    )

    assert lazy_function.get() == 'foo_value'
    assert lazy_function.get() == 'foo_value'
    assert lazy_function.get() == 'foo_value'

    assert lazy_function.constructor_fn() == 'foo_value'
    assert lazy_function.constructor_fn() == 'foo_value'
    assert lazy_function.constructor_fn() == 'foo_value'

    assert lazy_function.is_evaluated
    assert lazy_function.value == 'foo_value'

    maybe_lazy_function = Lazy(
        lambda: Maybe.just("foo_value")
    )


# Generated at 2022-06-21 19:11:41.448984
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.box_tests import test_Box_of

    test_Box_of(Lazy(lambda: 'value'))



# Generated at 2022-06-21 19:11:51.726358
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    assert Lazy(lambda x: x + 10).map(lambda x: x * 10).map(lambda x: x - 5).fold(21) == 455
    assert str(Lazy(lambda x: x + 10).map(lambda x: x * 10).map(lambda x: x - 5).map(lambda x: 'test')) == (
        "Lazy[fn=<function %s.test_Lazy_map.<locals>.<lambda>>, value=None, is_evaluated=False]" % __name__
    )
    assert Lazy(lambda x: x + 10).map(lambda x: x * 10).map(lambda x: x - 5).map(lambda x: 'test') == (
        Lazy(lambda x: 'test')
    )


# Generated at 2022-06-21 19:11:59.722861
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # pylint: disable=E0102,R0916
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert (
        Lazy.of(lambda: 2) == Lazy.of(lambda: 2) ==
        Lazy(lambda: 2) == Lazy(lambda: 2) ==
        Lazy.of(lambda: 2).to_try() ==
        Lazy.of(lambda: 2).to_box() ==
        Lazy.of(lambda: 2).to_validation() ==
        Lazy.of(lambda: 2).to_maybe() ==
        Lazy.of(lambda: 2).to_either()
    )


# Generated at 2022-06-21 19:12:09.857040
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe, Some
    from pymonet.either import Either
    from pymonet.validation import Validation
    from pymonet.box import Box

    assert Lazy(lambda: 4).to_try() == Try.of(lambda: 4)
    assert Lazy(lambda: 4).to_try(Maybe.nothing()) == Try.of(lambda: 4)
    assert Lazy(lambda: 4).to_try(Maybe.just(4)) == Try.of(lambda: 4)
    assert Lazy(lambda: 4).to_try(Either.right(4)) == Try.of(lambda: 4)
    assert Lazy(lambda: 4).to_try(Either.left(4)) == Try.of(lambda: 4)

# Generated at 2022-06-21 19:12:20.615909
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(10) != Lazy.of(10)
    assert Lazy.of(10) == Lazy.of(10)
    assert Lazy.of(10) != Lazy.of('10')
    assert Lazy.of(10).map(lambda o: o+1) != Lazy.of(10).map(lambda o: o+1)
    assert Lazy.of(10).map(lambda o: o+1) == Lazy.of(10).map(lambda o: o+1)
    assert Lazy.of(10).bind(lambda v: Lazy.of(v)) == Lazy.of(10).bind(lambda v: Lazy.of(v))

# Generated at 2022-06-21 19:12:29.049164
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda : 2)) == 'Lazy[fn=<function Lazy.<lambda> at 0x000001A4C4D6E730>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda : 2).map(lambda x: x)._compute_value()) == 'Lazy[fn=<function Lazy.<lambda>.<locals>.<lambda>.<locals>.<lambda> at 0x000001AE5A9A9268>, value=2, is_evaluated=True]'


# Generated at 2022-06-21 19:12:32.074190
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda x: 2 * x)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2


# Generated at 2022-06-21 19:12:36.618176
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.box import Box

    box = Box(2)
    lazy = Lazy.of(lambda x: x + 1)
    assert lazy.ap(box) == Lazy.of(3)

# Generated at 2022-06-21 19:12:47.121113
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(2).map(lambda x: x + 1).get() == 3

# Generated at 2022-06-21 19:12:51.473199
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_function(value):
        assert value == 1
        return Lazy(lambda: 50)

    assert Lazy(lambda: 1).bind(test_function).get() == 50
    assert Lazy(lambda: 1).bind(test_function) == Lazy(lambda: 50)

# Generated at 2022-06-21 19:12:56.171747
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    try:
        Lazy(lambda x: x + 1).to_try(0)
        assert True
    except:
        assert False

    try:
        Lazy(lambda x: 1 / 0).to_try(0)
        assert False
    except ZeroDivisionError:
       assert True

# Generated at 2022-06-21 19:13:01.727625
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 'LazyValue') == Lazy.of('LazyValue')
    assert Lazy(lambda: Maybe.just(1)).to_maybe().is_just
    assert Lazy(lambda: Maybe.Nothing).to_maybe().is_nothing
    assert Lazy(lambda: Maybe.just(1)).to_box().is_just
    assert Lazy(lambda: Maybe.Nothing).to_box().is_nothing

# Generated at 2022-06-21 19:13:06.373227
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Unit test for method ap of class Lazy
    """
    from pymonet.function import pipe

    assert pipe(
        Lazy(lambda: 1),
        lambda x: x.ap(Lazy(lambda a: a + 5)),
        lambda x: x.get()
    ) == 6

# Generated at 2022-06-21 19:13:13.633832
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    def _l():
        return Maybe.just(10).to_either()

    assert Lazy.of(10).to_either() == Right(10)
    assert Lazy.of(10).ap(Lazy.of(_l)).to_either() == Right(Right(10))
    assert Lazy.of(10).ap(Lazy.of(lambda x: Left(x))).to_either() == Right(Left(10))


# Generated at 2022-06-21 19:13:18.387396
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    obj = Lazy.of('success')
    assert obj.to_try().get_or_else('error') == 'success'

    @Lazy
    def constructor_fn():
        raise ValueError('Error')

    assert constructor_fn.to_try().is_failure()
    assert isinstance(constructor_fn.to_try().error, ValueError)
    assert constructor_fn.to_try().get_or_else('error') == 'error'


# Generated at 2022-06-21 19:13:20.467596
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy.of(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 19:13:23.040297
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    lazy = Lazy(lambda a: 10 + a).bind(
        lambda x: Lazy(lambda y: x * y)
    )

    assert lazy.get(5) == 60

# Generated at 2022-06-21 19:13:27.805394
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Lazy.of(5).to_try() == Try.success(5)
    assert Lazy(lambda: 5 / 0).to_try() == Try.failure()



# Generated at 2022-06-21 19:13:39.948156
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    """
    Unit test for method __eq__ of class Lazy
    """
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x)



# Generated at 2022-06-21 19:13:43.156925
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad import Identity

    assert Identity.of(4).to_lazy().ap(Identity.of(lambda x: x * 2)).to_identity() == 8

# Generated at 2022-06-21 19:13:48.672438
# Unit test for method map of class Lazy
def test_Lazy_map():
    a1 = Lazy.of(1)
    assert a1.map(lambda v: v + 1).get() == 2
    assert a1.map(lambda v: v + 1).map(lambda v: v + 1).get() == 3
    assert a1.map(lambda v: v + 1).map(lambda v: v + 1).map(lambda v: v + 1).get() == 4



# Generated at 2022-06-21 19:13:51.274726
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def fn():
        return 1

    lazy = Lazy(fn)
    assert lazy.to_box() == Box(1)



# Generated at 2022-06-21 19:14:01.337572
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right, Left

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(1).map(lambda x: x + 1).to_either() == Right(2)
    assert Lazy.of(1).map(lambda x: x + 1).to_either() == Right(2)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).to_either() == Right(3)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).to_either() == Right(3)

# Generated at 2022-06-21 19:14:03.441683
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(Box(1)).to_box() == Box(1)

# Generated at 2022-06-21 19:14:04.545485
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
 

# Generated at 2022-06-21 19:14:06.304655
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<function <lambda> at 0x...>, value=None, is_evaluated=False]'



# Generated at 2022-06-21 19:14:09.366166
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn() -> str:
        return 'test'

    def fn2() -> str:
        return 'test2'

    lazy = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(fn2)

    assert lazy != 1

    assert lazy == lazy2

    assert lazy != lazy3


# Generated at 2022-06-21 19:14:17.219270
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pytest

    lazy_plus_one = Lazy(lambda x: x + 1)
    plus_one_lazy = Lazy(lambda x: x + 1)

    assert lazy_plus_one.bind(lambda x: plus_one_lazy) == Lazy(lambda x: x + 2)

    # test case when Lazy constructror fn is evaluated but Lazy is not
    assert Lazy(lambda x: x + 1).bind(lambda x: x).get(1) == 2

# Generated at 2022-06-21 19:14:29.162154
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1



# Generated at 2022-06-21 19:14:31.089599
# Unit test for method get of class Lazy
def test_Lazy_get(): # pragma: no cover
    def some_function():
        return 1

    assert Lazy(some_function).get() == 1



# Generated at 2022-06-21 19:14:35.408221
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.list import List
    from pymonet.maybe import Maybe

    def some_function(a):
        return a

    lazy = Lazy(some_function)
    lazy_map = lazy.map(lambda x: List(x))

    assert Maybe.just(List(5)).eq(lazy_map.to_maybe(5))



# Generated at 2022-06-21 19:14:38.523475
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation() == Validation.success(1)
    assert Lazy(lambda: 1 / 0).to_validation() == Validation.success(1)
    assert Lazy(lambda: 1 / 's').to_validation() == Validation.failure('s')



# Generated at 2022-06-21 19:14:49.165406
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert (
        str(Lazy(lambda x: x + 1)) ==
        'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x000001D5E5C0E0D0>, value=None, is_evaluated=False]'
    )
    assert (
        str(Lazy(lambda x: x + 1).map(lambda x: x * 2)) ==
        'Lazy[fn=<function Lazy.<locals>.<lambda>.<locals>.<lambda> at 0x000001D5E5C0E158>, value=None, is_evaluated=False]'
    )

# Generated at 2022-06-21 19:14:57.519406
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.either import Right, Left

    # Box
    assert Lazy.of(3).ap(Box.of(lambda x: x + 2)).get() == 5
    assert Lazy.of(3).ap(Box.empty).get() == 3
    assert Lazy.of(lambda x: x + 3).ap(Box.of(4)).get() == 7
    assert Lazy.of(lambda x: x + 3).ap(Box.empty).get()() == 3

    # Either
    assert Lazy.of(3).ap(Right.of(lambda x: x + 2)).get() == 5
    assert Lazy.of(3).ap(Left.of(2)).get() == 3

# Generated at 2022-06-21 19:15:01.239315
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def tested_function(arg: int) -> int:
        return 2 * arg

    maybe = Lazy(tested_function).to_maybe(2)

    assert maybe.is_nothing is False
    assert maybe.is_just is True
    assert maybe.unbox() == 4


# Generated at 2022-06-21 19:15:02.025096
# Unit test for method get of class Lazy
def test_Lazy_get():

    assert Lazy.of(2).get() == 2


# Generated at 2022-06-21 19:15:13.821716
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.either import Right

    def test_fn(a, b, c):
        return a + b + c

    def test_fn_with_exception(a, b, c):
        raise ValueError(b)

    def test_fn_with_exception_and_traceback(a, b, c):
        try:
            1 / 0
        except ZeroDivisionError:
            raise TypeError(b)

    # Test with successful function
    assert Lazy(test_fn).to_try(1, 2, 3) == Try(test_fn, 1, 2, 3)

    # Test with function raise exception

# Generated at 2022-06-21 19:15:16.872347
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def fn_returning_maybe():
        return Maybe.just(42)

    lazy_instance = Lazy(fn_returning_maybe)

    assert lazy_instance.to_maybe() == Maybe.just(42)



# Generated at 2022-06-21 19:15:37.368866
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right
    from random import randint
    from pymonet.box import Box

    def add_one(value):
        return value + 1

    def divide_two(value):
        return value / 2

    def compute_value(value):
        return [x / value for x in range(100)]

    assert Right(10).to_lazy().to_either() == Right(10)
    assert Box(10).to_lazy().to_either() == Right(10)
    assert Lazy(lambda: 10).to_either() == Right(10)

    for x in range(10):
        value = randint(0, 100)
        assert Lazy(lambda: value).map(add_one).to_either() == Right(value + 1)
        assert Lazy

# Generated at 2022-06-21 19:15:40.607521
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    def fn(a):
        return a + 1

    result = Lazy(fn).to_maybe(1)

    assert isinstan

# Generated at 2022-06-21 19:15:43.240589
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(5) == Lazy(lambda *args: 5).to_validation()



# Generated at 2022-06-21 19:15:50.848875
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for method bind of class Lazy
    """
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation, ValidationError

    def fn(a):
        return Maybe.just(a+1)

    assert Lazy.of(Maybe.just(1)).bind(fn).get() == Maybe.just(2)
    assert Lazy.of(Maybe.nothing).bind(fn).get() == Maybe.nothing

    assert Lazy.of(Validation(1)).bind(fn).get() == Validation(Maybe.just(2))

    assert Lazy.of(Validation(ValidationError('error message'))).bind(fn).get() == Validation(ValidationError('error message'))


# Generated at 2022-06-21 19:15:54.829720
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    def f1():
        return 1

    lazy = Lazy(f1)
    assert lazy.to_maybe() == Maybe.just(1)

# Generated at 2022-06-21 19:16:04.101237
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def add_a_to_b(a, b):
        return a+b

    def add_a_to_b_and_c(a, b, c):
        return a+b+c

    add_a_to_b_lazy = Lazy(lambda a, b: add_a_to_b(a, b))
    add_a_to_b_and_c_lazy = add_a_to_b_lazy.map(lambda a_b: add_a_to_b_and_c(a_b, 3))

    assert add_a_to_b_and_c_lazy.get(1, 2) == 6  # Lazy call parameters are not used

# Generated at 2022-06-21 19:16:15.589483
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_list import List
    from operator import add

    assert Lazy(lambda x: x + 5).ap(Lazy(lambda x: x * 2)).get(5) == 20
    assert Lazy(lambda x: [x]).ap(Lazy(lambda x: [x])).get(5) == [5]
    assert Lazy(lambda x: [x]).ap(Lazy(lambda x: List([x]))).get(5) == List([5])
    assert Lazy(lambda x: [x]).ap(Lazy(lambda x: add)).get(5, 5) == 10

# Generated at 2022-06-21 19:16:17.207546
# Unit test for method get of class Lazy
def test_Lazy_get():
    import random

    assert Lazy.of(10).get() == 10

    assert Lazy.of(random.randint(1, 10)).get() != 10

# Generated at 2022-06-21 19:16:22.713361
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
        Unit test for method bind of class Lazy
    """
    def fn():
        return 1

    def bind_result_fn(value):
        return Lazy.of(value + 1)

    lazy = Lazy(fn)
    new_lazy = lazy.bind(bind_result_fn)

    assert new_lazy.constructor_fn() == 2

# Generated at 2022-06-21 19:16:26.180573
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy(lambda: 5).to_validation() == Validation.success(5)



# Generated at 2022-06-21 19:16:38.933280
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    empty = Lazy.of(None)
    lazy_function = Lazy(lambda value: lambda: value)
    lazy_value = Lazy(lambda: 1)

    assert empty == empty.bind(lazy_function)
    assert Lazy(lambda: lazy_value.get()) == lazy_value.bind(lazy_function)
    assert Lazy(lambda: lazy_value.get()) == lazy_value.bind(lambda value: Lazy(lambda: value))
    assert Lazy(lambda: 1) == lazy_value.bind(lambda value: Lazy(lambda: 1))

# Generated at 2022-06-21 19:16:45.161857
# Unit test for constructor of class Lazy
def test_Lazy():
    value_1 = 3
    value_2 = 6
    lazy = Lazy(lambda: value_1)

    assert not lazy.is_evaluated
    assert lazy.get() == value_1
    assert lazy.is_evaluated

    lazy = Lazy(lambda x: value_1 * x)
    assert lazy.get(value_2) == value_1 * value_2

    return



# Generated at 2022-06-21 19:16:47.918923
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    test_lazy = Lazy.of('some value')
    assert test_lazy.to_validation() == Validation.success('some value')

# Generated at 2022-06-21 19:16:50.416685
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda a: a + 1).map(lambda a: a + 3).get(2) == 6


# Generated at 2022-06-21 19:16:56.194896
# Unit test for method get of class Lazy
def test_Lazy_get():
    squared = lambda x: x ** 2
    lazy = Lazy(lambda x: x * 2)
    assert lazy.get(5) == 10
    assert lazy.get(10) == 20
    assert lazy.get(5) == 10
    assert lazy.get(50) == 100
    assert lazy.get(1) == 2

    lazy = Lazy(squared)
    assert lazy.get(5) == 25
    assert lazy.get(10) == 100
    assert lazy.get(5) == 25
    assert lazy.get(50) == 2500
    assert lazy.get(1) == 1


# Generated at 2022-06-21 19:16:59.846547
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """
    >>> assert Lazy(lambda: 'x').to_either() == Right('x')
    >>> try: Lazy(lambda: 1 / 0).to_either()
    ... except ZeroDivisionError: assert True
    ... else: assert False
    """


# Generated at 2022-06-21 19:17:01.289555
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x).map(lambda x: x + 1)[10] == 11



# Generated at 2022-06-21 19:17:07.736467
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.either import Right

    def divide(a, b):
        return a / b

    div_10_2 = Lazy(lambda: divide(10, 2))
    div_10_0 = Lazy(lambda: divide(10, 0))

    assert div_10_2.to_either() == Right(5)
    assert div_10_0.to_either() == Right(ZeroDivisionError)

# Generated at 2022-06-21 19:17:13.376041
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    for i in range(10):
        assert Lazy.of(i).to_validation() == Validation.success(i)

    assert Lazy.of(None).to_validation() == Validation.success(None)

    success_lazy = Lazy(lambda: 1)
    assert success_lazy.to_validation() == Validation.success(1)
    assert success_lazy.is_evaluated

    success_lazy = Lazy(lambda: None)
    assert success_lazy.to_validation() == Validation.success(None)
    assert success_lazy.is_evaluated


# Generated at 2022-06-21 19:17:16.122099
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.validation import Validation

    lazy = Lazy(lambda x: Box.of(x + 1))
    validation = lazy.to_validation(1)

    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.value.get() == 2