

# Generated at 2022-06-21 19:07:35.568718
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    lazy = Lazy.of(2)
    assert lazy.to_box() == Box(2)

    lazy = Lazy(lambda i: i + 9)
    assert lazy.to_box(1) == Box(10)


# Generated at 2022-06-21 19:07:39.471448
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy(lambda: "Hello")
    assert lazy.bind(lambda x: Lazy("World")) == Lazy("World")
    assert lazy.bind(lambda x: Lazy("World")).get() == "World"


# Generated at 2022-06-21 19:07:43.162684
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Lazy.of(None).to_maybe() == Maybe.empty()
    assert Lazy.of(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-21 19:07:52.035473
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def to_lazy(x):
        return Lazy.of(x)

    def identity(x):
        return x

    lazy = Lazy(identity)
    validation = lazy.to_validation(to_lazy)
    assert isinstance(validation, Validation)
    assert validation.fold(identity) == lazy

    lazy = Lazy(identity)
    validation = lazy.to_validation(to_lazy).to_lazy()
    assert isinstance(validation, Lazy)
    assert validation.fold(identity) == lazy

# Generated at 2022-06-21 19:07:56.616119
# Unit test for method get of class Lazy
def test_Lazy_get():
    # GIVEN
    def constructor_fn(*args):
        return 'result'

    lazy = Lazy(constructor_fn)

    # WHEN
    result = lazy.get('args')

    # THEN
    assert result == 'result'



# Generated at 2022-06-21 19:08:03.320246
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def identity_x2(x):
        return x * 2

    def get_n(n):
        return Lazy(lambda: n)

    def get_y(y):
        return Lazy(lambda: y)

    assert Lazy(lambda: 5).bind(get_n).get() == 5
    assert Lazy(lambda: 5).bind(get_n).bind(get_y).get() == 5
    assert Lazy(lambda: 5).bind(lambda x: get_n(identity_x2(x))).get() == 10

# Generated at 2022-06-21 19:08:11.578534
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.list_ import List

    validation_lazy = Lazy.of(1).to_validation()
    assert validation_lazy == Validation.success(1)
    assert isinstance(validation_lazy, Validation)



# Generated at 2022-06-21 19:08:13.667019
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    constructor_fn = lambda: 1
    l = Lazy(constructor_fn)

    assert l == Lazy(constructor_fn)


# Generated at 2022-06-21 19:08:19.655790
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    assert Lazy.of(1).to_either() == Right(1)

    assert Lazy.of(lambda: 1 / 2).to_either() == Right(0.5)

    assert Lazy.of(lambda: 1 / 0).to_either() == Left(ZeroDivisionError('division by zero'))


# Generated at 2022-06-21 19:08:30.076603
# Unit test for constructor of class Lazy
def test_Lazy():
    def add_one(x):
        return x + 1

    def divide_by_two(x):
        return x / 2

    def add_five(x):
        return x + 5

    lazy_0 = Lazy(lambda: 0)
    assert lazy_0.get() == 0
    assert lazy_0.constructor_fn() == 0
    assert lazy_0.is_evaluated

    lazy_1 = Lazy(lambda: 1)
    assert lazy_1.get() == 1
    assert lazy_1.constructor_fn() == 1
    assert lazy_1.is_evaluated

    lazy_add_one = Lazy(add_one)
    assert lazy_add_one.get(1) == 2
    assert lazy_add_one.constructor_fn(1) == 2
    assert lazy_add_

# Generated at 2022-06-21 19:08:38.681928
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet import Lazy

    def fn_with_error(*args):
        return 1 / 0

    def fn_with_error2(*args):
        raise Exception

    def fn_successful(*args):
        return 100

    lazy_with_error = Lazy(fn_with_error)
    assert Try.is_failure(lazy_with_error.to_try())

    lazy_with_error2 = Lazy(fn_with_error2)
    assert Try.is_failure(lazy_with_error2.to_try())

    lazy_succesfull = Lazy(fn_successful)
    assert Try.is_success(lazy_succesfull.to_try())


# Generated at 2022-06-21 19:08:44.792635
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    def fn(x):
        if x < 5:
            return Validation.success(x)
        return Validation.failure(x)

    lazy = Lazy.of(fn)

    assert lazy.to_try(1).get() == Validation.success(1)
    assert lazy.to_try(6) == Try.failure(6)



# Generated at 2022-06-21 19:08:53.332440
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe

    assert Lazy.of('b').bind(lambda x: Lazy.of('a')).get() == 'a'
    assert Lazy.of('b').bind(
        lambda x: Lazy.of('a')
    ).bind(
        lambda x: Lazy.of('c')
    ).get() == 'c'
    assert Lazy.of('b').bind(
        lambda x: Maybe.nothing()
    ).bind(
        lambda x: Lazy.of('c')
    ).get() == 'c'


# Generated at 2022-06-21 19:09:05.265496
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.monad_try import Try

    def constructor(*args):
        return 5

    def constructor_with_error(*args):
        raise ValueError('Error')

    assert str(Lazy(constructor)) == 'Lazy[fn=<function Lazy_test.test_Lazy___str__.<locals>.constructor at 0x10e5d5bf8>, value=None, is_evaluated=False]'
    assert str(Lazy(constructor_with_error)) == 'Lazy[fn=<function Lazy_test.test_Lazy___str__.<locals>.constructor_with_error at 0x10e5d5c80>, value=None, is_evaluated=False]'

# Generated at 2022-06-21 19:09:11.035097
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def empty_lazy_mapper():
        return Maybe.empty()

    def not_empty_lazy_mapper():
        return Maybe.just(5)

    assert Lazy(empty_lazy_mapper).to_maybe() == Maybe.empty()
    assert Lazy(not_empty_lazy_mapper).to_maybe() == Maybe.just(5)

# Generated at 2022-06-21 19:09:14.734353
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right

    def fn(x):
        return x

    # Left
    assert Left(1).to_lazy().to_either() == Left(1)

    # Right
    assert Lazy(lambda _: 1).to_either() == Right(1)
    assert Right(1).to_lazy().to_either() == Right(1)

# Generated at 2022-06-21 19:09:21.975587
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    def create_test_lazy_1() -> Lazy[None, int]:
        return Lazy(lambda *_: 7)

    def test_function() -> Box[int]:
        return create_test_lazy_1().to_box()

    assert create_test_lazy_1().to_box() == Box(7)
    assert test_function() == Box(7)



# Generated at 2022-06-21 19:09:26.940053
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation
    from unittest.mock import patch, MagicMock

    mock1 = MagicMock(return_value=2)
    mock2 = MagicMock(return_value=3)

    with patch('pymonet.lazy.Lazy', return_value=mock1):
        Lazy().ap(mock2)

    mock2.assert_called_once()
    mock1.assert_called_once_with(3)



# Generated at 2022-06-21 19:09:31.856523
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """
    >>> lazy_monad = Lazy(lambda x: x**2)
    >>> either_monad = lazy_monad.to_either(2)
    >>> either_monad
    Right(4)
    >>> either_monad.get_or_else(-1)
    4
    """


# Generated at 2022-06-21 19:09:35.369682
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    # empty Lazy
    assert Lazy(lambda: None).to_maybe() == Maybe.nothing()

    # not empty Lazy
    assert Lazy(lambda: 1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-21 19:09:47.410255
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Fold function is called only during calling fold method
    """

    def mapper(x: int) -> int:
        return x + 1

    def mapper2(x: int) -> int:
        return x + 2

    def mapper3(x: int) -> int:
        return x + 3

    def side_effect_function() -> int:
        raise Exception('This function should not be called!')

    def fold_function(x: int) -> int:
        return x + 5

    lazy = Lazy(lambda: 1).map(mapper).map(mapper2).map(mapper3)
    assert lazy.bind(fn=lambda x: Lazy(side_effect_function)).get() == 9

    assert lazy.map(fold_function).fold(mapper3) == 12

# Generated at 2022-06-21 19:09:58.418019
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.monad_try import Try

    def func_1():
        return 1

    def func_2():
        return 2

    def func_3():
        return 1 / 0

    a = Lazy(lambda *a: 1)
    b = Lazy(func_1)
    c = Lazy(func_2)
    d = Lazy(func_3)
    e = Lazy.of(1)

    assert a.get() == 1
    assert b.get() == 1
    assert c.get() == 2
    assert d.to_try().fold(lambda ex: Try.success(ex), lambda v: Try.failure(v)) == Try.failure(ZeroDivisionError)
    assert e.get() == 1


# Generated at 2022-06-21 19:10:04.863873
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 2)).get() == Lazy.of(1).map(lambda x: x + 2).get()
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).bind(lambda x: Lazy.of(str(x))).get() == '1'
    assert Lazy.of('1').map(lambda x: int(x)).get() == 1
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 2)).bind(lambda x: Lazy.of(x - 1)).get() == 2

    lazy_executed = False

    def dummy_fn():
        nonlocal lazy_executed
        lazy_executed = True
        return 1


# Generated at 2022-06-21 19:10:08.621717
# Unit test for method get of class Lazy
def test_Lazy_get():
    def is_five(value):
        return value == 5

    def is_thirth_arg_five(arg, *args):
        return is_five(args[2])

    test_lazy = Lazy(lambda *args: is_thirth_arg_five(args[0], args))

    assert test_lazy.get(1, 1, 5, 1) is True
    assert test_lazy.get(1, 1, 5, 1) is True



# Generated at 2022-06-21 19:10:12.165352
# Unit test for constructor of class Lazy
def test_Lazy():
    lazy_str = Lazy(lambda: "Test")
    lazy_str.get() == "Test"



# Generated at 2022-06-21 19:10:23.028603
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    """
    Unit test for __eq__ method on class Lazy.
    """
    l1 = Lazy.of(1)
    l2 = Lazy.of(1)
    l3 = Lazy.of(lambda: 1)
    l4 = Lazy.of(lambda: 1)
    l5 = Lazy.of(2)
    l6 = Lazy.of(None)
    l7 = Lazy.of(lambda: None)
    l8 = Lazy.of(lambda: None)

    assert l1 == l2
    assert l3 == l4
    assert l5 != l1
    assert l6 == l7
    assert l1 != l8
    assert l1 != 1
    assert l1 != {'lazy': l2}

# Generated at 2022-06-21 19:10:26.247374
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__(): # pragma: no cover
    assert Lazy.of(1) == Lazy(lambda *args: 1)
    assert not Lazy(lambda *args: 1) != Lazy(lambda *args: 1)
    assert Lazy(lambda *args: 1) != Lazy.of(2)



# Generated at 2022-06-21 19:10:33.003848
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    a = Lazy(lambda: 'A').bind(lambda a: Lazy(lambda: a + 'B'))

    assert a.constructor_fn() == 'AB'

    b = Lazy(lambda: None).bind(lambda a: Lazy(lambda: a + 'B'))

    assert b.constructor_fn() is None



# Generated at 2022-06-21 19:10:37.290952
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Lazy(lambda a: None).to_maybe(5)
    assert Maybe.just(None) == Lazy(lambda a: None).to_maybe(5)
    assert Maybe.just(5) == Lazy(lambda a: a).to_maybe(5)


# Generated at 2022-06-21 19:10:42.666436
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def constructor_function(value):
        return value

    def fold_function(_):
        return Maybe.just(1)

    assert Maybe.just(1) == Lazy(constructor_function).map(fold_function).to_maybe()



# Generated at 2022-06-21 19:10:51.514158
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: 2).bind(lambda x: Lazy(lambda: x ** 2)).get() == 4
    assert Lazy(lambda: 2).bind(lambda x: Lazy(lambda: x ** 2)).bind(
        lambda x: Lazy(lambda: x ** 2)).get() == 16
    assert Lazy(lambda: 3).bind(lambda x: Lazy(lambda: x ** 2)).bind(
        lambda x: Lazy(lambda: x ** 2)).get() == 81


# Generated at 2022-06-21 19:10:53.534613
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import ValidationSuccess

    lazy_success = Lazy(lambda: 10)
    assert lazy_success.to_validation() == ValidationSuccess(10)

# Generated at 2022-06-21 19:10:59.369716
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda: True)) == 'Lazy[fn=<function Lazy.<lambda> at 0x7f9f8bb05488>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: True).map(lambda x: x)) == 'Lazy[fn=<function Lazy.<lambda> at 0x7f9f8bb05488>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: True).get()) == 'Lazy[fn=<function Lazy.<lambda> at 0x7f9f8bb05488>, value=True, is_evaluated=True]'

# Generated at 2022-06-21 19:11:06.415402
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def inc(value):
        return value + 1

    # check result of mapping function
    lazy_inc = Lazy.of(inc)
    validation = lazy_inc.to_validation()
    assert isinstance(validation, Validation)
    assert isinstance(validation.value, Success)
    assert validation.value.value == inc


# Generated at 2022-06-21 19:11:09.910044
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    def fn():
        return 1

    lazy = Lazy(fn)
    value = lazy.to_validation()

    assert value.is_success
    assert value.get_or_else(lambda: 0) == 1

# Generated at 2022-06-21 19:11:13.177696
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def fn(x):
        return x

    assert Lazy(fn).to_box(1) == Box(1)



# Generated at 2022-06-21 19:11:16.675182
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert 'Lazy[fn={}, value={}, is_evaluated={}]'.format(lambda x: x, None, False) == str(Lazy(lambda x: x))


# Generated at 2022-06-21 19:11:20.988788
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda a: a + 1).ap(Lazy.of(3)) == Lazy.of(4)

    # Test with nested HOFs
    assert Lazy.of(lambda a: a + 1).ap(Lazy.of(lambda a, b: b + a)).ap(Lazy.of(4)) == Lazy.of(5)


# Generated at 2022-06-21 19:11:24.275788
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    def half(x: int) -> int:
        return x // 2

    assert Lazy(half).to_box(10) == Box(5)


# Generated at 2022-06-21 19:11:31.763800
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    def to_try(a):
        return a.to_try()

    assert to_try(Lazy(lambda: 1)) == Try.success(1)
    assert to_try(Lazy(lambda: 1/0)) == Failure(ZeroDivisionError('division by zero'))
    assert to_try(Lazy(lambda: [1, 2, 3][3])) == Failure(IndexError('list index out of range'))



# Generated at 2022-06-21 19:11:43.676176
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    def map_to_even(x):
        return x % 2 == 0

    def map_to_odd(x):
        return x % 2 != 0

    added_two_even = Lazy.of(1).bind(add_one).bind(add_one).bind(map_to_even)
    added_two_odd = Lazy.of(1).bind(add_one).bind(add_one).bind(map_to_odd)

    assert added_two_even.get()
    assert not added_two_odd.get()

# Generated at 2022-06-21 19:11:54.275975
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    lazy = Lazy(lambda x: x.lower())
    assert 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x{:x}>, value=None, is_evaluated=False]'.format(
        id(lazy.constructor_fn)) == str(lazy)

    lazy = Lazy(lambda x: x.lower()).map(lambda x: x.upper())
    assert 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x{:x}>, value=None, is_evaluated=False]'.format(
        id(lazy.constructor_fn)) == str(lazy)


# Generated at 2022-06-21 19:11:59.147154
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy.of(10).to_try() == Try.of(lambda: 10)
    assert Lazy.of(10).to_try('custom_message') == Try.of(lambda: 10, 'custom_message')

    def fn():
        raise ValueError('Custom Error')

    assert Lazy.of(fn).to_try() == Try.of(fn)
    assert Lazy.of(fn).to_try('custom_message') == Try.of(fn, 'custom_message')



# Generated at 2022-06-21 19:12:05.670398
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def test_function(*args):
        return True

    lazy_object = Lazy(test_function)

    assert lazy_object.get() is lazy_object.get()
    assert lazy_object.get() is True
    assert str(lazy_object) == 'Lazy[fn=<function test_function at 0x1084c4b90>, value=True, is_evaluated=True]'



# Generated at 2022-06-21 19:12:08.540612
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add(x, y):
        return x + y

    lazy_adder = Lazy(lambda: add)

    assert lazy_adder.bind(lambda adder: Lazy.of(adder(2, 3))).get() == 5


# Generated at 2022-06-21 19:12:11.172194
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(x):
        return x + 1

    lazy = Lazy.of(1)
    new_lazy = lazy.bind(f)
    assert new_lazy.get() == 2

# Generated at 2022-06-21 19:12:16.610252
# Unit test for method map of class Lazy
def test_Lazy_map():
    def function(value: int) -> int:
        return value + 10

    def mapper(value: int) -> int:
        return value + 1

    lazy = Lazy(function)

    assert lazy.map(mapper).get(3) == 14



# Generated at 2022-06-21 19:12:19.410563
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.either import Right

    def unit_test():
        validation = Lazy(lambda x: x).to_validation(1)

        assert isinstance(validation, Validation)
        assert validation == Validation.success(1)

        return Right(True)

    validation = unit_test()

    assert isinstance(validation, Right)
    assert validation.is_equal(Right(True))


# Generated at 2022-06-21 19:12:22.334608
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    value = 'test'

    test_lazy = Lazy(lambda: value)
    is_instance(test_lazy.to_validation(), Validation)
    is_instance(test_lazy.to_validation(), Validation)


# Generated at 2022-06-21 19:12:27.886945
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(3).ap(Lazy.of(lambda x: x * 2)) == Lazy.of(6)
    assert Lazy.of(3).ap(Box(lambda x: x * 2)).get() == 6
    assert Lazy.of(3).ap(Right(lambda x: x * 2)).get() == 6
    assert Lazy.of(3).ap(Maybe(lambda x: x * 2)).get() == 6
    assert Lazy.of(3).ap(Try(lambda x: x * 2)).get() == 6

# Generated at 2022-06-21 19:12:34.204777
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.either import Left

    def fn(x):
        return x + x

    lazy_value = Lazy(fn)

    assert lazy_value.is_evaluated == False
    assert lazy_value.value == None
    assert lazy_value.constructor_fn(1) == 2
    assert lazy_value.value == None

    lazy_value2 = Lazy(lambda *args: Lazy(lambda x: x + x).get(*args))

    assert lazy_value2.is_evaluated == False
    assert lazy_value2.value == None
    assert lazy_value2.constructor_fn(2) == 4
    assert lazy_value2.value == None

    lazy_value3 = Lazy.of(1)

    assert lazy_value3.is_evaluated == False

# Generated at 2022-06-21 19:12:39.042788
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_of_10 = Lazy.of(10)
    result = lazy_of_10.map(lambda x: x + 10)
    assert result.is_evaluated is False
    assert result.value is None
    assert result.get() == 20



# Generated at 2022-06-21 19:12:44.867588
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def fun_raise_exception():
        raise Exception("exception")

    def fun_return_value():
        return 1

    assert Lazy(fun_raise_exception).to_try() == Try.failure(Exception("exception"))
    assert Lazy(fun_return_value).to_try() == Try.success(1)



# Generated at 2022-06-21 19:12:51.140023
# Unit test for method get of class Lazy
def test_Lazy_get():
    #
    # given
    def test_fn(*args):
        print('Got args {}'.format(args))
        return 'Got expected value'

    lazy_fn = Lazy(test_fn)
    #
    # then
    assert lazy_fn.get('test') == 'Got expected value'
    assert lazy_fn.value == 'Got expected value'


# Generated at 2022-06-21 19:12:53.241054
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(3).to_either() == Right(3)



# Generated at 2022-06-21 19:12:57.134540
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    assert Lazy.of(1).to_try() == Try.of(lambda: 1)
    assert Lazy.of(1).to_try(1, 2) == Try.of(lambda: 1, 1, 2)

# Generated at 2022-06-21 19:13:02.626085
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    assert Lazy.of(lambda x: x + 3).ap(Maybe.just(2)) == Lazy.of(5), \
        "Lazy.ap should apply function stored in Lazy to monad value"

    assert Lazy.of(lambda x: x + 3).ap(Maybe.nothing()) == Lazy.of(lambda x: x + 3), \
        "Lazy.ap should return itself when monad is empty"



# Generated at 2022-06-21 19:13:13.338833
# Unit test for method get of class Lazy
def test_Lazy_get():
    def mul_lazy(a):
        return Lazy(lambda b: a*b)

    assert Lazy.of(None).get(0) is None
    assert mul_lazy(None).get(0) is None

    assert Lazy.of(1).get(0) == 1
    assert mul_lazy(1).get(0) == 0

    assert Lazy.of(1).get(1) == 1
    assert mul_lazy(1).get(1) == 1

    assert Lazy.of(1).get(2) == 1
    assert mul_lazy(1).get(2) == 2

    assert Lazy.of(2).get(2) == 2
    assert mul_lazy(2).get(2) == 4


# Generated at 2022-06-21 19:13:16.043388
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert (
        Lazy.of(100)
        .map(lambda x: x * 2)
        .to_maybe()
        .equals(
            from_iterable([Just(200)]),
        )
    )

# Generated at 2022-06-21 19:13:21.281751
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from hypothesis import given
    from hypothesis.strategies import integers, text, lists

    @given(integers(), lists(integers()))
    def test_Lazy___str__(x, ys):
        """
        Case: function and value are immutable.
        """
        fn = lambda x, ys: x + sum(ys)

        lazy = Lazy(fn)

        assert lazy.is_evaluated is False
        assert lazy.value is None

        assert str(lazy) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(fn, None, False)

        lazy.get(x, ys)

        assert lazy.is_evaluated is True
        assert lazy.value == fn(x, ys)


# Generated at 2022-06-21 19:13:32.276941
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def test_Lazy1():
        return 1

    def test_Lazy2():
        return 2

    lazy1 = Lazy(test_Lazy1)
    lazy1.get()

    assert lazy1.__eq__(lazy1)
    assert not lazy1.__eq__(Lazy(test_Lazy1))
    assert not lazy1.__eq__(Lazy(test_Lazy2))
    assert not lazy1.__eq__(1)



# Generated at 2022-06-21 19:13:36.918367
# Unit test for method get of class Lazy
def test_Lazy_get():
    def empty_fn():
        raise Exception('Empty')

    lazy = Lazy(lambda: 'not empty')
    assert lazy.get() == 'not empty'

    lazy = Lazy(empty_fn)
    assert lazy.get() == 'not empty'

    lazy = Lazy(empty_fn)
    with pytest.raises(Exception):
        lazy.get()



# Generated at 2022-06-21 19:13:40.061628
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(x):
        return x + 1

    assert Lazy(test_fn).get(1) == 2

# Generated at 2022-06-21 19:13:51.393162
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test Lazy bind method.
    Check that compute_value is called only once.
    """

    calls_count = 0

    def inc_calls_count():
        nonlocal calls_count
        calls_count += 1

        return calls_count

    def add_to_calls_count(x):
        return x + calls_count

    def map_calls_count(x):
        return x + 2

    lazy_inc_calls_count = Lazy(inc_calls_count)
    lazy_add_to_calls_count = lambda x: Lazy(add_to_calls_count).map(lambda y: x + y)
    lazy_map_calls_count = lambda x: Lazy(map_calls_count).map(lambda y: x + y)


# Generated at 2022-06-21 19:13:53.851691
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(None).to_box() == Box(None)



# Generated at 2022-06-21 19:14:02.826231
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy.of(0) == Lazy(lambda: 0)
    assert Lazy.of(0).get() == 0
    assert Lazy.of(0).map(lambda x: x * 2) == Lazy.of(0).map(lambda x: x * 2)
    assert Lazy.of(0).map(lambda x: x * 2).get() == 0
    assert Lazy(lambda: 0).map(lambda x: x * 2) == Lazy.of(0).map(lambda x: x * 2)
    assert Lazy(lambda: 0).map(lambda x: x * 2).get() == 0

    assert Lazy(lambda x: x * 2).of(1).get() == 2


# Generated at 2022-06-21 19:14:13.921388
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_list import List
    from pymonet.monad_try import Try

    def test_001():
        def f(a):
            return a + 1

        Lazy(f) == Lazy(f)

    def test_002():
        def f(a):
            return a + 1

        Lazy(f) != Lazy(f).map(lambda x: x + 1)

    def test_003():
        def f(a):
            return a + 1

        Lazy(f) != Lazy(f).map(lambda x: x + 1).map(lambda x: x + 1)

    def test_004():
        def f(a):
            raise ValueError()

        Lazy(f) == Lazy(f)

# Generated at 2022-06-21 19:14:17.157053
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda x: x).get(1) == 1


# Generated at 2022-06-21 19:14:22.917669
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test for map method of Lazy class.
    """
    def add_one(value):
        return value + 1

    def another_add_one(value):
        return value + 1

    lazy = Lazy(lambda: 1)
    lazy_add_one = lazy.map(add_one)
    lazy_add_one_two = lazy_add_one.map(another_add_one)

    assert lazy != lazy_add_one
    assert lazy_add_one != lazy_add_one_two
    assert lazy_add_one.map(add_one) == lazy_add_one_two

    assert lazy.get() == 1
    assert lazy.get() == lazy.get()
    assert lazy_add_one.get() == 2
    assert lazy_add_one_two.get() == 3



# Generated at 2022-06-21 19:14:25.832158
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Validation.success(5) == Lazy(lambda: 5).to_validation()

# Generated at 2022-06-21 19:14:31.708462
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    assert (
        Lazy(lambda: 42).to_box() == Box(42)
    ), "Lazy.to_box should transform Lazy into Box with constructor_fn result"


# Generated at 2022-06-21 19:14:35.089375
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 1)) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(
        '<function Lazy.<lambda> at 0x7fd8f1eede60>', None, False
    )



# Generated at 2022-06-21 19:14:39.125996
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__(): # pragma: no cover
    from pymonet.function import Function

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert not Lazy(lambda: 1) == Lazy(lambda: 2)
    assert not Lazy(lambda: 1) == Lazy(lambda x: x)
    assert not Lazy(lambda: 1) == 1
    assert not Lazy(lambda: 1) == Function(lambda x, y: x + y)
    assert not Lazy(lambda: 1) == None



# Generated at 2022-06-21 19:14:45.425761
# Unit test for method map of class Lazy
def test_Lazy_map():
    def multiply_by_two(x):
        return x * 2

    def plus_one(x):
        return x + 1

    assert (Lazy.of(1).map(multiply_by_two).map(plus_one)).constructor_fn(5) == 3
    assert (Lazy.of(1).map(multiply_by_two).map(plus_one)).constructor_fn(5) == 3



# Generated at 2022-06-21 19:14:52.038844
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Nothing

    def function():
        return 5

    lazy = Lazy(function)

    assert lazy.to_maybe() == Maybe.just(5)
    assert lazy.to_maybe(default=Nothing) == Maybe.just(5)
    assert lazy.to_maybe(default=Maybe.nothing()) == Maybe.just(5)
    assert lazy.to_maybe(default=Maybe.just(10)) == Maybe.just(5)



# Generated at 2022-06-21 19:14:59.765537
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    """
    Test for method to_maybe of class Lazy
    """
    from pymonet.maybe import Maybe

    assert Lazy.of(None).to_maybe() == Maybe.nothing()
    assert Lazy.of(None).map(lambda x: "test").to_maybe() == Maybe.nothing()
    assert Lazy.of("sample").map(lambda x: None).to_maybe() == Maybe.nothing()
    assert Lazy.of("sample").to_maybe() == Maybe.just("sample")
    assert Lazy.of("sample").map(lambda x: "test").to_maybe() == Maybe.just("test")
    assert Lazy.of("sample").map(lambda x: x.upper()).to_maybe() == Maybe.just("SAMPLE")


# Generated at 2022-06-21 19:15:01.549493
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert (Lazy.of(lambda x: x + 2).ap(Lazy.of(10))).get() == 12



# Generated at 2022-06-21 19:15:09.371287
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def fn(a):
        return a + 1

    value = 1
    lazy = Lazy.of(value)
    assert lazy.constructor_fn() == value
    assert lazy.value is None
    assert not lazy.is_evaluated

    lazy2 = Lazy(fn)
    assert lazy2.value is None
    assert lazy2.is_evaluated is False
    assert lazy2.constructor_fn == fn

    assert lazy == Lazy.of(1)

    assert lazy != Lazy.of(0)



# Generated at 2022-06-21 19:15:10.435626
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    pass


# Generated at 2022-06-21 19:15:19.083239
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.monad_try import Try

    def square(x: int) -> int:
        return x ** 2

    assert Lazy(square) == Lazy(square)
    assert Lazy(square) == Lazy(square).map(square)

    assert Lazy(lambda x: x ** 2) == Lazy(lambda x: x ** 2)
    assert Lazy(lambda x: x) != Lazy(lambda x: x + 1)

    assert str(Lazy(square)) == 'Lazy[fn=<function square at 0x0000022F9C6F92F0>, value=None, is_evaluated=False]'  # noqa

    assert Lazy.of(2) == Lazy(lambda x: 2)
    assert Lazy(lambda x: x).map(lambda x: x ** 2) == Lazy

# Generated at 2022-06-21 19:15:30.642892
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def function_that_can_raise_errors(*args):
        if len(args) > 0:
            return Maybe.just(5)
        return Maybe.just(2)

    assertion = Lazy.of(5)

    lazy_maybe = assertion.to_maybe()
    assert lazy_maybe == Maybe.just(5)

    lazy_maybe_with_errors = Lazy(function_that_can_raise_errors).to_maybe(1)
    assert lazy_maybe_with_errors == Maybe.just(5)

    lazy_maybe_with_errors = Lazy(function_that_can_raise_errors).to_maybe()
    assert lazy_maybe_with_errors == Maybe.just(2)



# Generated at 2022-06-21 19:15:35.899788
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Lazy(lambda: 1).to_validation() == Validation.success(1)
    assert Lazy(lambda: "2").to_validation() == Validation.success("2")
    assert Lazy(lambda: None).to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:15:37.485324
# Unit test for method get of class Lazy
def test_Lazy_get():
    def func(x):
        return x + 1

    assert Lazy(func).get(1) == 2


# Generated at 2022-06-21 19:15:41.475148
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy.of(2).to_box() == Box(2)
    assert Lazy(lambda: 2).to_box() == Box(2)


# Generated at 2022-06-21 19:15:47.421574
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert str(Lazy.of(1).to_maybe()) == "Maybe[1]", \
        "should return Maybe[1] when Lazy contains integer"

    assert str(Lazy.of({}).to_maybe()) == "Maybe[{}]", \
        "should return Maybe[{}] when Lazy contains dict"

    assert str(Lazy.of([]).to_maybe()) == "Maybe[[]]", \
        "should return Maybe[[]] when Lazy contains list"



# Generated at 2022-06-21 19:15:50.361540
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test for get method of Lazy
    """
    assert Lazy.of(1).get() == 1
    # Test memoization
    obj = Lazy(lambda: 123)
    assert obj.get() == 123
    assert obj.value == 123
    assert obj.is_evaluated



# Generated at 2022-06-21 19:15:56.745269
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe

    def increase(x: int) -> int:
        return x + 1

    def increase_maybe(x: Maybe[int]) -> Maybe[int]:
        return Maybe.just(increase(x.get()))

    assert Lazy.of(Maybe.just(0)).map(increase_maybe).get() == Maybe.just(1)



# Generated at 2022-06-21 19:15:59.554176
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy(lambda: 1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:16:05.511508
# Unit test for method map of class Lazy
def test_Lazy_map():
    def func():
        return 2

    def mapper(a):
        return a + 1

    # check when Lazy is evaluated
    lazy = Lazy(lambda: 1).map(mapper)
    assert lazy.is_evaluated is False
    assert lazy.get() == 2

    assert lazy.is_evaluated is True
    assert lazy.get() == 2

    # check when Lazy is not evaluated
    lazy = Lazy(func).map(mapper)
    assert lazy.is_evaluated is False
    assert lazy.get() == 3

    assert lazy.is_evaluated is True
    assert lazy.get() == 3



# Generated at 2022-06-21 19:16:10.344173
# Unit test for method map of class Lazy
def test_Lazy_map():
    def f(a):
        return a

    def g(a):
        return a

    lazy = Lazy(f).map(g)

    assert lazy.constructor_fn(1) == f(1)



# Generated at 2022-06-21 19:16:15.522504
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.maybe import Nothing

    def division_by_zero(*args):
        return 1 / 0

    assert Try.of(division_by_zero) == Lazy(division_by_zero).to_try()  # NOQA



# Generated at 2022-06-21 19:16:18.411454
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_test_helpers import f1

    assert Lazy(f1) == Lazy(f1)
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(2) != Lazy.of(3)



# Generated at 2022-06-21 19:16:29.574538
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    def get_value(_):
        return 'a'

    def get_value_failing(_):
        raise Exception()

    lazy = Lazy(get_value)
    assert lazy.to_box() == Box('a')
    assert lazy.to_box() == Box('a')

    lazy = Lazy(get_value_failing)
    assert lazy.to_box() == Box(Exception())

    assert Lazy.of(1).to_box() == Box(1)
    assert Lazy.of(Try(Exception())).to_box() == Box(Try(Exception()))
    assert Lazy(lambda: Try.of(get_value)).to_box() == Box(Try.of(get_value))
    assert Lazy

# Generated at 2022-06-21 19:16:34.959898
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is False

    assert Lazy(lambda x: x).__eq__(Lazy(lambda: None)) is False

    assert Lazy(lambda x: x).__eq__(Lazy.of(1)) is False

    assert Lazy.of(1).__eq__(Lazy.of(2)) is False

    assert Lazy.of(1).__eq__(Lazy.of(1)) is True


# Generated at 2022-06-21 19:16:39.524639
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(arg):
        return Lazy(lambda *args: arg + 1)

    def fn2(arg):
        return Lazy(lambda *args: arg * 2)

    lazy = Lazy(lambda *args: 1).bind(fn).bind(fn2)

    assert lazy.get() == 4



# Generated at 2022-06-21 19:16:42.286600
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    lazy = Lazy.of('lazy')
    assert lazy.get() == 'lazy'



# Generated at 2022-06-21 19:16:46.956947
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.lazy import Lazy

    def noop(*args):
        pass

    lazy = Lazy(noop)
    assert str(lazy) == "Lazy[fn=<function noop at 0x{}>, value=None, is_evaluated=False]".format(hex(id(noop)))



# Generated at 2022-06-21 19:16:55.743658
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert isinstance(Lazy.of(1), Lazy)
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy.of(2)
    assert Lazy(lambda: 2) == Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: '1') == Lazy(lambda: '1')
    assert Lazy(lambda: '1') != Lazy(lambda: '2')

    def func1():
        return 2

    def func2():
        return 3

    assert Lazy(func1) == Lazy(func1)
    assert Lazy(func1) != L

# Generated at 2022-06-21 19:17:00.400748
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def raise_error():
        raise ValueError('Error')

    def return_value():
        return 'value'

    assert Lazy(raise_error).to_try() == Try.failure(ValueError('Error'))
    assert Lazy(return_value).to_try() == Try.success('value')

# Generated at 2022-06-21 19:17:09.662304
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(1).to_lazy().to_maybe() == Maybe.just(1)
    assert Maybe.nothing().to_lazy().to_maybe() == Maybe.nothing()

    assert Lazy.of(None).to_maybe() == Maybe.nothing()
    assert Lazy.of(1).to_maybe() == Maybe.just(1)

    assert Lazy(lambda: 1).to_maybe() == Maybe.just(1)
    assert Lazy(lambda: None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:17:20.712037
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def sum_fn(n: int) -> int:  # pragma: no cover
        return n + n

    def sum_fn_2(n: int) -> int:  # pragma: no cover
        return n + n

    lazy = Lazy(lambda n: sum_fn(n))

    assert lazy == Lazy(lambda n: sum_fn(n))
    assert not lazy == Lazy(lambda n: sum_fn_2(n))
    assert not lazy == Lazy(lambda n: sum_fn_2(n)).map(lambda n: n + 2)
    assert not lazy == Lazy.of(2).map(lambda n: n + 2)
    assert not lazy == Lazy(lambda n: sum_fn(n)).map(lambda n: n + 2)

# Generated at 2022-06-21 19:17:24.669041
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: "value") == Lazy(lambda: "value")
    assert Lazy(lambda: "value") == Lazy.of("value")
    assert Lazy(lambda: "value") != Lazy(lambda: "other value")
    assert Lazy(lambda: "value") != "value"



# Generated at 2022-06-21 19:17:30.021736
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a: int, b: int) -> int:
        return a + b

    def add2(a: int) -> int:
        return add(a, 2)

    a = Lazy(lambda: 1)
    b = Lazy(add2)

    actual = b.ap(a).get()
    assert actual == 3, "Should be true"
