

# Generated at 2022-06-12 05:11:06.393485
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(7).get() == Lazy.of(7).get() == 7
    assert Lazy.of(7).get() == Lazy(lambda: 7).get()
    assert Lazy(lambda: 7).get() == Lazy(lambda: 7).get()


# Generated at 2022-06-12 05:11:11.260923
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy.
    """
    def mul2(x):
        return Lazy(lambda: 2 * x)

    def mul3(x):
        return Lazy(lambda: 3 * x)

    def mul5(x):
        return Lazy(lambda: 5 * x)

    result = Lazy(lambda: 10).bind(mul2).bind(mul3).bind(mul5)

    assert result.get() == 150

# Generated at 2022-06-12 05:11:19.462237
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.fn import pipe

    def is_Lazy_2_with_value_2_and_constructor_fn_1_2(lazy):
        return lazy == Lazy(lambda x: 1 + x).map(lambda x: 1 + x)

    assert pipe(
        Lazy(lambda x: 1 + x),
        lambda x: x.map(lambda x: 1 + x),
        is_Lazy_2_with_value_2_and_constructor_fn_1_2
    )


# Generated at 2022-06-12 05:11:27.965656
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x: int) -> int:
        return x + 1

    def list_to_str(x: List[int]) -> str:
        return str(''.join(map(str, x)))

    assert Lazy.of(1).map(add_one).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of([1, 2, 3]).map(list_to_str).get() == '123'



# Generated at 2022-06-12 05:11:36.376761
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functions import bind_lazy
    from pymonet.maybe import Maybe

    def wrap(x):
        return Maybe.just(x)

    assert Maybe.just(1).bind(wrap) == Lazy.of(1).bind(wrap)
    assert Maybe.nothing().bind(wrap) == Lazy.of(None).bind(wrap)
    assert Maybe.just(1).bind(wrap) == bind_lazy(Lazy.of(1), wrap)
    assert Maybe.nothing().bind(wrap) == bind_lazy(Lazy.of(None), wrap)



# Generated at 2022-06-12 05:11:43.358113
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_instance = Lazy(lambda x: x + 1)
    assert lazy_instance.bind(lambda x: Lazy.of(x * 2)).get(1) == 4
    assert lazy_instance.bind(lambda x: Lazy.of(x * 2)).get(1) == 4


# Generated at 2022-06-12 05:11:54.401735
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    assert Lazy.of(lambda x: x + 2).ap(Maybe.just(2)) == Maybe.just(4)
    assert Lazy.of(lambda x: x + 2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Lazy.of(lambda x: x + 2).map(Maybe.just).ap(Maybe.just(2)) == Maybe.just(4)
    assert Lazy.of(lambda x: x + 2).map(Maybe.just).ap(Maybe.nothing()) == Maybe.nothing()
    assert Lazy.of(lambda x: x + 2).map(Maybe.nothing).ap(Maybe.just(2)) == Maybe.nothing()
    assert Lazy.of(lambda x: x + 2).map(Maybe.nothing).ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-12 05:12:01.848762
# Unit test for method get of class Lazy
def test_Lazy_get():
    def get_number():
        return 4

    def get_string():
        return 'str'

    def get_dict():
        return {'key': 'value'}

    assert Lazy.of(4).get() == Lazy(lambda: 4).get() == 4
    assert Lazy.of('str').get() == Lazy(lambda: 'str').get() == 'str'
    assert Lazy.of({'key': 'value'}).get() == Lazy(lambda: {'key': 'value'}).get() == {'key': 'value'}
    assert Lazy(get_number).get() == Lazy(get_number).get() == 4
    assert Lazy(get_string).get() == Lazy(get_string).get() == 'str'

# Generated at 2022-06-12 05:12:06.387057
# Unit test for method get of class Lazy
def test_Lazy_get():
    def some_fn(a, b):
        return a + b

    def mapper_fn(a):
        return a * 2

    lazy = Lazy(lambda: some_fn(1, 2)).map(mapper_fn)

    assert lazy.get() == 6



# Generated at 2022-06-12 05:12:13.290752
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from .either import Left
    from .validation import Invalid

    assert Lazy(lambda x: x).__eq__(Lazy(lambda y: y))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda y: y * y))
    assert not Lazy(lambda x: x * x).__eq__(Lazy(lambda y: y * y))
    assert Lazy(lambda x: x * Lazy(lambda y: y)).__eq__(Lazy(lambda x: x * Lazy(lambda y: y)))
    assert Lazy(lambda x: x * Lazy(lambda y: y * y)).__eq__(Lazy(lambda x: x * Lazy(lambda y: y * y)))
    assert not Lazy(None).__eq__(None)
    assert not Lazy(None).__eq

# Generated at 2022-06-12 05:12:21.305725
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy1 = Lazy.of(1)
    lazy2 = Lazy.of(1)
    assert lazy1 == lazy2
    assert lazy1 == lazy1
    assert lazy2 == lazy2

    lazy3 = Lazy(lambda x: x + 2)
    assert lazy3 != lazy1

# Unit tests for method get of class Lazy

# Generated at 2022-06-12 05:12:27.476959
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Unit test for the __eq__ function from class Lazy
    """
    from pymonet.functor import Functor
    from .lazy import Lazy
    from .monad import Monad

    lazy_one = Lazy(lambda: 2)
    lazy_two = Lazy(lambda: 3)
    lazy_three = Lazy(lambda: 2)
    lazy_four = Lazy(lambda: 2)
    lazy_five = Lazy(lambda: 2)

    assert False == (lazy_one == lazy_two)
    assert False == (lazy_one == lazy_three)
    assert False == (lazy_one == lazy_four)
    assert True == (lazy_one == lazy_five)
    assert True == (lazy_one == lazy_three)

# Generated at 2022-06-12 05:12:37.117767
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a):
        return lambda b: a + b

    assert Lazy(1).ap(Lazy(add(2))).get() == 3
    assert Lazy(1).ap(Lazy(add(2))).to_box().get() == 3
    assert Lazy(1).ap(Lazy(add(2))).to_either().get() == 3
    assert Lazy(1).ap(Lazy(add(2))).to_maybe().get() == 3
    assert Lazy(1).ap(Lazy(add(2))).to_try().get() == 3
    assert Lazy(1).ap(Lazy(add(2))).get() == 3


# Generated at 2022-06-12 05:12:39.578288
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2


# Generated at 2022-06-12 05:12:43.410422
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.list import List

    lazy = Lazy.of(2)
    lazy_list = lazy.bind(lambda a: List([a, a * a]))

    assert lazy_list.get() == List([2, 4])

# Generated at 2022-06-12 05:12:49.473540
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add_two(x):
        return x + 2

    lazy_two = Lazy.of(2)

    assert 2 == lazy_two.get()
    assert 4 == lazy_two.map(add_two).get()
    assert 2 == lazy_two.map(add_two).get()

    assert Lazy.of(2).map(add_two) == Lazy.of(4)


# Generated at 2022-06-12 05:13:00.940120
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_either import Right
    from pymonet.monad_validation import Validation
    from pymonet.monad_maybe import Maybe

    def create_lazy(x):
        return Lazy(lambda: x)

    def lazy_plus(x, y):
        return create_lazy(x + y)


# Generated at 2022-06-12 05:13:07.865312
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x * 2) == Lazy.of(2)
    assert Lazy.of(1).map(lambda x: x * 2).map(lambda x: x * 2) == Lazy.of(4)
    assert Lazy.of(2).map(lambda x: x * 2).map(lambda x: x * 2) == Lazy.of(8)


# Generated at 2022-06-12 05:13:09.372521
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy(lambda: 1).get() == 1



# Generated at 2022-06-12 05:13:17.653025
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_equal_lazy(x):
        assert x == x
        assert x == Lazy.of(x.get())
        assert x == Lazy.of(x.get())
        assert Lazy.of(x.get()) == x
        assert not(x == Lazy.of(x.get() + 1))

    test_equal_lazy(Lazy(lambda: 100))
    assert Lazy(lambda: 100) == Lazy(lambda: 100)
    assert Lazy(lambda: 100) != Lazy(lambda: 101)


# Generated at 2022-06-12 05:13:26.629372
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_maybe import Maybe

    def check_Lazy_map(mapper_fn, lazy_fn, expected_value):
        assert Lazy(lazy_fn).map(mapper_fn).get() == expected_value
        assert Lazy(lazy_fn).map(mapper_fn).to_box() == Box(expected_value)
        assert Lazy(
            lazy_fn
        ).map(
            mapper_fn
        ).to_either() == Right(
            expected_value
        )
        assert Lazy(
            lazy_fn
        ).map(
            mapper_fn
        ).to_maybe() == Maybe.just(
            expected_value
        )

    check_Lazy_map(lambda a: a + 1, lambda: 1, 2)
    check_Lazy_

# Generated at 2022-06-12 05:13:36.574137
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_try import Try

    def add(x: int, y: int) -> int:
        return x + y

    def add_and_raise(x: int, y: int) -> Try:
        return Try.of(add, x, y)

    fn = Lazy(lambda x: x * 2)
    assert fn.map(add_and_raise).get(5) == Try.of(add, 10, 5)

    fn = Lazy.of(5)
    assert fn.map(add_and_raise).get(5) == Try.of(add, 5, 5)

# Generated at 2022-06-12 05:13:46.780908
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    from pymonet.mlist import Node, Nil
    from pymonet.monad import Monad

    number = Lazy.of(23)
    string = Lazy.of('Dima')

    fn = Lazy.of(lambda x: x + 4)
    fn2 = Lazy.of(lambda x: x + ': ')

    assert fn.ap(Lazy.of(2)) == Lazy.of(6)
    assert fn.ap(number) == Lazy.of(27)
    assert string.ap(fn2) == Lazy.of('Dima: ')

    def fn3(x: int) -> Lazy[int, str]:
        return Lazy.of(lambda y: str(x + y))


# Generated at 2022-06-12 05:13:55.930827
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test_map_call_from_not_lazy(first_lazy: Lazy[int, int]) -> bool:
        def initial_func(arg: int) -> int:
            return arg

        # First Lazy was evaluated and memoized value
        assert first_lazy.constructor_fn(1) == 1
        assert first_lazy.value == 1

        # Get mapped lazy from evaluated first lazy
        mapped_lazy = first_lazy.map(initial_func)

        assert mapped_lazy.constructor_fn() == 1

    def test_map_call_from_lazy(first_lazy: Lazy[int, int]) -> bool:
        def initial_func(arg: int) -> int:
            return arg

        # Get mapped lazy from lazy
        mapped_lazy = first_lazy.map

# Generated at 2022-06-12 05:14:05.788732
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_fn = lambda: 'foo'
    lazy = Lazy(lazy_fn)

    class Lazy2(Generic[T, U]):
        def __init__(self, constructor_fn: Callable[[T], U]) -> None:
            self.constructor_fn = constructor_fn

        def map(self, mapper: Callable[[U], W]) -> 'Lazy[T, W]':
            return Lazy(lambda *args: mapper(self.constructor_fn(*args)))

        def get(self):
            return self.constructor_fn()

        def bind(self, fn: 'Callable[[U], Lazy[U, W]]') -> 'Lazy[T, W]':
            return fn(self.constructor_fn())


# Generated at 2022-06-12 05:14:10.035391
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    f = Lazy(lambda x: x + 1)
    g = Lazy(lambda x: x * 2)
    ap_fg = f.ap(g)
    assert isinstance(ap_fg, Lazy)
    assert ap_fg.get(3) == 7

# Generated at 2022-06-12 05:14:18.907560
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.functor import test_functor
    from pymonet.applicative import test_applicative_for_functor

    def f(x: int) -> int:
        return x + 1

    def g(x: int) -> int:
        return x + 2

    def h(x: int) -> int:
        return x + 3

    test_functor(Lazy.of, f, g, h)
    test_applicative_for_functor(Lazy.of, f, g, h)

# Generated at 2022-06-12 05:14:25.309690
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    # given
    a = 0
    b = 1
    c = Lazy.of(a + b)
    # when
    d = c.get()
    # then
    assert d == a + b
    assert c.is_evaluated is True
    assert c.value == d


# Generated at 2022-06-12 05:14:27.790790
# Unit test for method map of class Lazy
def test_Lazy_map():
        assert Lazy.of(123).map(int).get('123') == 123
        assert Lazy.of('123').map(int).get() == 123

# Generated at 2022-06-12 05:14:34.168815
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add_one(value):
        return Lazy.of(value + 1)

    def multiply_by_two(value):
        return Lazy.of(value * 2)

    lazy = Lazy.of(2)

    assert lazy.ap(add_one).get() == 3

    assert lazy.ap(multiply_by_two).get() == 4

    assert lazy.ap(add_one).ap(multiply_by_two).get() == 6



# Generated at 2022-06-12 05:14:44.378756
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda n: n + 1) != '1'
    assert Lazy(lambda n: n + 1) == Lazy(lambda n: n + 1)
    assert Lazy(lambda n: n + 1) != Lazy(lambda n: n + 2)
    assert Lazy(lambda n: n + 2) != Lazy(lambda n: n + 1)



# Generated at 2022-06-12 05:14:48.263813
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy(lambda x: 1)

# Generated at 2022-06-12 05:14:56.545598
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Maybe

    # Should change value
    assert Lazy(lambda x: Maybe.just(x + 1)).map(lambda x: x - 1).get(2) == Maybe.just(2)

    # Should call constructor fn only once
    count = 0
    add = lambda x: Maybe.just(x + count)
    plus_one = lambda x: Maybe.just(x + 1)

    lazy = Lazy(add).map(plus_one)
    assert lazy.get(1) == Maybe.just(2)

    count = 1

    assert lazy.get(1) == Maybe.just(2)


# Generated at 2022-06-12 05:14:58.780308
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def fn():
        return 1

    lazy_instance = Lazy(fn)

    assert lazy_instance.get() == 1

# Generated at 2022-06-12 05:15:02.536701
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn(): pass

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(None)



# Generated at 2022-06-12 05:15:05.027475
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(5).get() == 5
    assert Lazy(lambda a: a + 5).get(5) == 10


# Generated at 2022-06-12 05:15:08.400924
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return x * 2

    lazy = Lazy(lambda: 2)
    assert lazy.bind(lambda x: Lazy.of(fn(x))).get() == 4



# Generated at 2022-06-12 05:15:17.420718
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    result = Lazy(lambda value: value).__eq__(Lazy(lambda value: value))
    assert result is True

    result = Lazy(lambda value: value).__eq__(Lazy(lambda value: 2 * value))
    assert result is False

    result = Lazy(lambda value: 2 * value).__eq__(Lazy(lambda value: value))
    assert result is False

    result = Lazy(lambda value: 2 * value).__eq__(Lazy(lambda value: 2 * value))
    assert result is True



# Generated at 2022-06-12 05:15:20.942087
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def add(value):
        return value + 1

    # Test lazy bind with instant function
    assert Lazy.of(2).bind(lambda x: Lazy.of(add(x))).get() == 3

    # Test lazy bind with lazy function
    def lazy_add(value):
        return Lazy.of(add(value))

    assert Lazy.of(2).bind(lazy_add).get() == 3

# Generated at 2022-06-12 05:15:30.144381
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    >>> Lazy(lambda: 1).get()
    1
    >>> Lazy(lambda: 'str').get()
    'str'
    >>> Lazy(lambda: [1]).get()
    [1]
    >>> Lazy(lambda: {'one': 1}).get()
    {'one': 1}
    >>> Lazy(lambda: None).get()

    # >>> Lazy(lambda: 1 / 0).get()
    Traceback (most recent call last):
    ...
    ZeroDivisionError: division by zero
    """


# Generated at 2022-06-12 05:15:42.966347
# Unit test for method get of class Lazy
def test_Lazy_get():
    import pytest

    lazy = Lazy(lambda memoize: memoize)
    assert lazy.get(5) == 5
    assert lazy.is_evaluated is True
    assert lazy.value == 5

    lazy = Lazy(lambda memoize: memoize)
    assert lazy.get(5) == 5
    assert lazy.get(6) == 5
    assert lazy.get(7) == 5
    assert lazy.is_evaluated is True
    assert lazy.value == 5

    with pytest.raises(TypeError):
        lazy.get()



# Generated at 2022-06-12 05:15:48.565031
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """

    def mapper(value):
        def inner(*args):
            return value + ' ' + ' '.join(args)
        return Lazy(inner)

    lazy = Lazy(lambda: 'Hello')
    lazy = lazy.bind(mapper)
    assert lazy.get('world', '!') == 'Hello world !'

# Generated at 2022-06-12 05:15:59.382013
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def just_if_odd(number):
        if number % 2:
            return Maybe.just(number)
        return Maybe.nothing

    assert Lazy.of(1).ap(Lazy.of(1)) == Lazy.of(1)
    assert Lazy.of(1).ap(Maybe.just(1)) == Lazy.of(1)

    assert Lazy.of(1).ap(Lazy.of(1).bind(just_if_odd)) == Lazy.of(1)
    assert Lazy.of(2).ap(Lazy.of(1).bind(just_if_odd)) == Lazy(lambda *args: Maybe.nothing)
    assert Lazy.of(2).ap(Lazy.of(2).bind(just_if_odd)) == Lazy

# Generated at 2022-06-12 05:16:08.900824
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Lazy[int, int] ap Lazy[int, int]
    add = lambda a, b: a + b
    sum_ = Lazy(lambda a: add(a, 5))
    sum_1 = Lazy(lambda a: a + 5)
    assert sum_.ap(sum_1).get(10) == 20

    # Lazy[str, int] ap Lazy[str, str]
    string_length = lambda a: len(a)
    string_length_ = Lazy(string_length)
    upper = lambda a: a.upper()
    upper_ = Lazy(upper)
    assert string_length_.ap(upper_).get('monad') == 5

    # Lazy[str, int] ap Lazy[str, str]
    sum_str = lambda a: '1 + 1 = 2'


# Generated at 2022-06-12 05:16:18.255125
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Left

    assert Lazy.of(lambda x: x + 1).ap(Lazy.of([1, 2, 3])).get() == [2, 3, 4]

    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(Left(0))).get() == Left(0)
    assert Lazy.of(lambda x: Left(x + 1)).ap(Lazy.of(Left(0))).get() == Left(1)
    assert Lazy.of(lambda x: Left(x + 1)).ap(Lazy.of(0)).get() == Left(1)
    assert Lazy.of(lambda x: 0).ap(Lazy.of(Left(0))).get() == Left(0)



# Generated at 2022-06-12 05:16:26.823149
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def get_data(a: str, b: str, c: str) -> str:
        return ''.join([a, b, c])

    lazy = Lazy(get_data)

    assert lazy.get('a', 'b', 'c') == 'abc'
    assert lazy.to_box('a', 'b', 'c') == Box('abc')
    assert lazy.to_either('a', 'b', 'c') == Try('abc')
    assert lazy.to_maybe('a', 'b', 'c') == Maybe.just('abc')

# Generated at 2022-06-12 05:16:30.762553
# Unit test for method map of class Lazy
def test_Lazy_map():
    def map_fun(value):
        return value * 2

    lazy_instance = Lazy.of(1)
    assert lazy_instance.map(map_fun).get() == 2


# Generated at 2022-06-12 05:16:36.932753
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    try_value = Try.of(lambda: True)
    l1 = Lazy(lambda: lambda v: Try.of(lambda: True if v else False))
    assert l1.ap(try_value).get() == Try.of(lambda: True)

# Generated at 2022-06-12 05:16:41.048820
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Method map of class Lazy should return new Lazy with mapped result of it's constructor function.
    """
    imported_lazy = Lazy(lambda: 1).map(lambda x: 2 * x)
    assert imported_lazy._compute_value() == 2



# Generated at 2022-06-12 05:16:46.626564
# Unit test for method map of class Lazy
def test_Lazy_map():
    # given
    lazy = Lazy(lambda x: x + 10)

    # when
    result = lazy.map(lambda y: y ** 2)

    # then
    assert result == Lazy(lambda x: (x + 10) ** 2)
    assert result.get(3) == 169
    assert lazy == Lazy(lambda x: x + 10)



# Generated at 2022-06-12 05:17:00.823897
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.functor import Functor
    from pymonet.type_constructors.function import Function

    def mapper(x):
        return x

    obj_data = Functor(Function.of(mapper))
    obj_data.map(lambda x: x)



# Generated at 2022-06-12 05:17:07.565049
# Unit test for method map of class Lazy
def test_Lazy_map():
    def foo() -> int:
        return 1

    def foo_3x() -> int:
        return 3

    assert Lazy(foo).map(foo_3x).constructor_fn() == 3
    assert Lazy(foo).map(foo_3x).map(foo_3x).constructor_fn() == 9
    assert Lazy(foo).map(foo_3x).map(foo_3x).map(foo_3x).constructor_fn() == 27


# Generated at 2022-06-12 05:17:15.290745
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    class Packet:
        pass

    p1 = Packet()
    p2 = Packet()

    def fn(x):
        return x

    lazy = Lazy(fn)

    assert lazy != None
    assert lazy != 2
    assert lazy != Lazy(fn)
    assert lazy != Lazy(lambda x: x + 1)
    assert lazy != Lazy(fn)(p1)
    assert lazy != Lazy(fn)(p1)
    assert lazy == Lazy(fn)(p1)
    assert lazy != Lazy(fn)(p2)



# Generated at 2022-06-12 05:17:27.033757
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box
    from pymonet.either import Left

    assert str(Lazy.of(4).get()) == '4'
    assert Lazy.of(4).get() == 4
    assert Lazy.of(lambda x: x + 5).get(1) == 6
    assert Lazy.of(Box.of(5)).get().get() == 5
    assert Lazy.of(Box.of(5)).bind(lambda x: Lazy.of(lambda: x + 1)).get().get() == 6
    assert Lazy.of(Left('error')).bind(lambda x: Lazy.of(lambda: x.get_or_else(x + '!'))).get().get_or_else(None) == 'error!'

# Generated at 2022-06-12 05:17:36.699416
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.functor_class import Functor

    Functor.test_functor(Lazy, False)

    just = lambda x: Lazy.of(x)

    assert Lazy(lambda x: x + 1).get(1) == 2

    assert just(2).get() == 2
    assert just(2).to_box().get() == 2
    assert just(2).to_either().get() == 2
    assert just(2).to_maybe().get() == 2
    assert just(2).to_try().get() == 2
    assert just(2).to_validation().get() == 2

    assert just(2).get() == 2
    assert just(2).to_box().get() == 2
    assert just(2).to_either().get() == 2

# Generated at 2022-06-12 05:17:45.928836
# Unit test for method get of class Lazy
def test_Lazy_get():
    # type: () -> None
    assert Lazy.of(2).get() == 2

    assert Lazy(lambda x: x).get(1) == 1
    assert Lazy(lambda x: x).get(2) == 2

    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 2).get() == 2

    assert Lazy(lambda x: x * x).get(2) == 4
    assert Lazy(lambda x: x * x).get(3) == 9
    assert Lazy(lambda x, y: x * y).get(3, 5) == 15



# Generated at 2022-06-12 05:17:54.479453
# Unit test for method map of class Lazy
def test_Lazy_map():
    # given
    def double(x):
        return x * 2

    def triple(x):
        return x * 3

    def quad(x):
        return x * 4

    fn = Lazy.of(9)

    # then
    assert fn.map(double).map(quad).get(7) == fn.map(lambda x: quad(double(x))).get(7)

    assert fn.map(triple).map(double).get(10) == fn.map(lambda x: double(triple(x))).get(10)


# Generated at 2022-06-12 05:17:56.776088
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda *args: 1).bind(lambda a: Lazy(lambda *args: a + 1)).get() == 2

# Generated at 2022-06-12 05:17:58.684985
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x))



# Generated at 2022-06-12 05:18:02.835335
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    lzy0 = Lazy.of(3)
    lzy1 = Lazy.of(3)
    lzy2 = Lazy.of(5)
    assert lzy0 == lzy1
    assert lzy0 != lzy2



# Generated at 2022-06-12 05:18:28.584621
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def fn(a):
        return a * 3

    def fn_mapper(a):
        return a * 2

    lazy = Lazy(fn)
    lazy_mapper = Lazy(fn_mapper)
    result = Lazy(lambda *_: 2).ap(lazy_mapper)
    assert result.get() == 4
    assert lazy.ap(lazy_mapper).get(2) == 12
    assert Lazy(fn).ap(lazy).get(2) == 12
    assert lazy_mapper.ap(lazy).get(2) == 12

# Generated at 2022-06-12 05:18:30.474284
# Unit test for method get of class Lazy
def test_Lazy_get():
    la = Lazy.of(42)
    assert la.get() == 42



# Generated at 2022-06-12 05:18:37.287577
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add3(a):
        return a + 3

    def mul2(a):
        return a * 2

    def div3(a):
        return a // 3

    to_Lazy = Lazy.of(lambda a: a)

    assert to_Lazy.ap(Lazy(mul2)).ap(Lazy(div3)).ap(Lazy(add3)).get(5) == 7
    assert to_Lazy.ap(Lazy(mul2).ap(Lazy(div3))).ap(Lazy(add3)).get(9) == 7
    assert to_Lazy.ap(Lazy(mul2)).ap(Lazy(div3).ap(Lazy(add3))).get(8) == 7

# Generated at 2022-06-12 05:18:48.989643
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f():
        return 1

    class MyObj:
        def __eq__(self, other):
            return isinstance(other, MyObj)

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(f)
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(0)
    assert Lazy.of(Lazy.of(MyObj())) == Lazy.of(Lazy.of(MyObj()))
    assert Lazy.of('1').ap(Lazy.of(lambda x: int(x))) == Lazy.of(1)

# Generated at 2022-06-12 05:18:57.293140
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """Unit test for method ap of class Lazy"""
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Lazy.of('John').ap(Lazy.of(lambda x: 'Hello, {}!'.format(x))).get('John') == 'Hello, John!'
    assert Lazy.of('John').ap(Maybe.just(lambda x: 'Hello, {}!'.format(x))).get('John') == 'Hello, John!'
    assert Lazy.of('John').ap(Box('John')).get('John') == 'John'
    assert Lazy.of('John').ap(Validation.success('John')).get('John') == 'John'

# Generated at 2022-06-12 05:19:02.187877
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn(x):
        return x * x

    lazy = Lazy(fn)
    assert Lazy.of(1) == Lazy(lambda *args: 1)
    assert lazy == Lazy(fn)
    assert lazy == lazy
    assert Lazy(fn) != Lazy(lambda: 1)



# Generated at 2022-06-12 05:19:14.285866
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    class TestClass(object):
        def __init__(self, val):
            self.val = val

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

    def get_test_class(val):
        return TestClass(val)

    assert Lazy(lambda _: (1, 2)) == Lazy(lambda _: (1, 2))
    assert Lazy(get_test_class) != Lazy(lambda _: (1, 2))
    assert Lazy(lambda _: (1, 2)) != Lazy(get_test_class)
    assert Lazy(get_test_class) != Lazy(get_test_class)
    assert Lazy(lambda _: (1, 2)) != Lazy(lambda _: (1, 2, 3))



# Generated at 2022-06-12 05:19:18.524378
# Unit test for method get of class Lazy
def test_Lazy_get():

    def some_function():
        return 42

    def another_function(x):
        return x * 42

    lazy = Lazy(some_function)

    assert lazy.get() == 42, "Lazy get method is invalid"

    assert lazy.map(another_function).get() == 1764, "Lazy map method is invalid"



# Generated at 2022-06-12 05:19:28.345365
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import pytest

    def long_run_fn():
        return 1

    lazy_fn = Lazy(long_run_fn)
    lazy_fn2 = Lazy(lambda *args: 2)
    lazy_result = lazy_fn.ap(lazy_fn2)

    assert lazy_fn2(None) == lazy_result(None)

    def long_run_fn3(*args):
        return 3

    lazy_fn3 = Lazy(long_run_fn3)
    lazy_result2 = lazy_fn2.ap(lazy_fn3)
    assert 2 == lazy_result2(None)

# Generated at 2022-06-12 05:19:38.368531
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.either import Either
    from pymonet.validation import Validation

    def call_that_raise_error(argument):
        raise TypeError("Test error")

    call_that_raise_error_lazy = Lazy(call_that_raise_error)
    call_that_raise_error_lazy_in_box = call_that_raise_error_lazy.bind(Box.of)
    assert call_that_raise_error_lazy_in_box == Lazy(
        lambda *args: call_that_raise_error_lazy.constructor_fn(*args, caller=Box)
    )

# Generated at 2022-06-12 05:20:01.576391
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def function():
        pass

    def function_with_add_param(a, b):
        pass

    assert Lazy(function) == Lazy(function)
    assert Lazy(function_with_add_param) != Lazy(function)

# Generated at 2022-06-12 05:20:08.409637
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_maybe import Maybe

    def to_maybe_fn(x):
        return Maybe.just(x * 10)

    def to_nothing_fn(x):
        return Maybe.nothing()

    lazy = Lazy.of(10)

    assert lazy.ap(Lazy(to_maybe_fn)) == Lazy.of(100)

    assert lazy.ap(Lazy(to_nothing_fn)) == Lazy.of(10)

# Generated at 2022-06-12 05:20:18.140640
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # type: () -> Callable[[Lazy[int, int]], Lazy[int, int]]

    def test_lazy(l):
        # type: (Lazy[int, int]) -> Lazy[int, int]
        return l.bind(lambda v: Lazy.of(v + 10))

    lazy = Lazy(lambda x: x + 10)

    assert test_lazy(Lazy.of(0)) == Lazy.of(10)
    assert test_lazy(lazy) == lazy
    assert Lazy.of(5).bind(test_lazy) == Lazy.of(25)



# Generated at 2022-06-12 05:20:22.293475
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from doctest import testmod
    from pymonet.maybe import Maybe
    assert testmod(verbose=True)[0] == 0

    assert Maybe.just('alfa') == Maybe.just('alfa')
    assert Maybe.just('alfa') != Maybe.just('beta')
    assert Maybe.nothing() != Maybe.just('alfa')
    assert Maybe.nothing() == Maybe.nothing()

# Generated at 2022-06-12 05:20:34.473055
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def _plus_one(a):
        return a + 1

    def _plus_two(a):
        return a + 2

    def _plus_three(a):
        return a + 3

    lazy1 = Lazy(_plus_one)
    lazy2 = Lazy(_plus_one)
    lazy3 = Lazy(_plus_two)
    lazy4 = Lazy(_plus_two)
    lazy5 = Lazy(_plus_three)
    lazy6 = Lazy(_plus_three)

    assert lazy1 == lazy2
    assert lazy3 == lazy4
    assert lazy5 == lazy6
    assert lazy1 != lazy3
    assert lazy1 != lazy5
    assert lazy3 != lazy5
    assert len({lazy1, lazy3, lazy5}) == 3



# Generated at 2022-06-12 05:20:46.887443
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x) == Lazy(lambda x: x)

    assert not (Lazy(lambda x: x) == Lazy(lambda x: x*2))
    assert not (Lazy(lambda x: x) == Lazy(lambda x: x+2))
    assert not (Lazy(lambda x: x) == Lazy(lambda x: x+2))
    assert not (Lazy(lambda x: x) == Lazy(lambda x: x/2))
    assert not (Lazy(lambda x: x) == Lazy(lambda x: x**2))
    assert not (Lazy(lambda x: x) == Lazy(lambda x: x+5))
    assert not (Lazy(lambda x: x) == Lazy(lambda x: x+6))

# Generated at 2022-06-12 05:20:51.359975
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 5).get() == 5
    assert Lazy(lambda x: x).get(10) == 10
    assert Lazy(lambda: Lazy(lambda: 5).get()).get() == 5
    assert Lazy(lambda x: x).get(Lazy(lambda: 7).get()) == 7
    assert Lazy(lambda x: x).get('abc') == 'abc'
    assert Lazy(lambda x: x).get([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-12 05:20:53.282242
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 'Lazy!').get() == 'Lazy!'


# Generated at 2022-06-12 05:21:01.208906
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(0) == 1
    assert Lazy(lambda x: x).map(lambda x: x + 2).get(0) == 2
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(-1) == 0
    assert Lazy(lambda x: x).map(lambda x: x + 4).get(-1) == 3
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(1) == 2
    assert Lazy(lambda x: x).map(lambda x: x + 5).get(1) == 6
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(3) == 4