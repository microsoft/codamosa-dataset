

# Generated at 2022-06-12 05:11:06.008596
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_fn_return_Lazy_of_sum(value):
        return Lazy.of(lambda x: x + value)

    lazy_with_function = Lazy(lambda: 'I am Lazy')
    assert lazy_with_function.bind(test_fn_return_Lazy_of_sum(1)).get() == 'I am Lazy1'



# Generated at 2022-06-12 05:11:13.402059
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right

    f = Lazy(lambda x: x + 1)
    g = Lazy(lambda x: x * 2)

    assert Lazy.of(lambda x: x).ap(g) == Lazy.of(2)
    assert g.ap(Lazy.of(1)) == g
    assert f.ap(g) == Lazy.of(lambda x: f.get(x).ap(g.get(x)))
    assert f.ap(Lazy.of(Right(10))) == Lazy.of(11)
    assert f.ap(g).ap(Lazy.of(Right(10))) == Lazy.of(22)
    assert f.ap(g.ap(Lazy.of(Right(10)))) == f.ap(Lazy.of(Right(20)))

#

# Generated at 2022-06-12 05:11:19.545062
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x * 2)
    assert Lazy.of(1) == Lazy.of(1).map(lambda x: x * 2).map(lambda x: x / 2)



# Generated at 2022-06-12 05:11:23.405905
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(x): return x + 1

    def g(x): return x + 2

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(g)
    assert Lazy(f) != f


# Generated at 2022-06-12 05:11:36.129155
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.either import Left

    lazy = Lazy(lambda: 'test')
    assert lazy.get() == 'test'
    assert lazy.is_evaluated is True

    lazy = Lazy(lambda x: x)
    assert lazy.get(100) == 100
    assert lazy.is_evaluated is True

    lazy = Lazy(lambda: 'test') \
        .bind(lambda x: Lazy(lambda: x + 'this')) \
        .bind(lambda x: Lazy(lambda: x + 'test'))
    assert lazy.get() == 'testthistest'
    assert lazy.is_evaluated is True

    assert Lazy(lambda: Left('Error')).to_either().get() == Left('Error')
    assert Lazy(lambda: Left('Error')).to_either().is_evaluated

# Generated at 2022-06-12 05:11:48.493134
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def test_function_with_args(a):
        return a * 2

    def test_function():
        return 0

    lazy = Lazy(test_function)
    lazy_with_args_initialization = Lazy(lambda a: 2 * a)

    assert lazy.get() == 0
    assert lazy_with_args_initialization.get(2) == 4

    # Check caching
    assert lazy.get() == 0
    assert lazy_with_args_initialization.get(2) == 4

    assert lazy.get() == 0
    assert lazy_with_args_initialization.get(2) == 4



# Generated at 2022-06-12 05:11:57.555219
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    is_negative = Lazy(lambda x: x < 0)
    is_negative_copy = Lazy(is_negative.constructor_fn)
    is_negative_refactor = Lazy(lambda x: x < 0)
    is_negative_diff = Lazy(lambda x: x >= 0)

    assert is_negative == is_negative_copy
    assert is_negative == is_negative_refactor
    assert is_negative != is_negative_diff
    assert is_negative != object

    assert Lazy(lambda: 1) != object
    assert Lazy(lambda x, y: 0) != object



# Generated at 2022-06-12 05:12:08.942321
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def add(x: int, y: int) -> int:
        return x + y

    def inc(x: int) -> int:
        return x + 1

    lazy_add = Lazy(add)
    assert lazy_add.map(inc) == lazy_add.map(inc)
    assert lazy_add.map(inc).map(inc) == lazy_add.map(inc).map(inc)

    # different constructor functions
    def add_inc(x: int, y: int) -> int:
        return x + y + 1

    lazy_add_inc = Lazy(add_inc)

    assert lazy_add_inc.map(inc) != lazy_add_inc.map(inc)

    # different function after mapping
    def dec(x: int) -> int:
        return x - 1

    assert lazy_

# Generated at 2022-06-12 05:12:20.768449
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy(lambda x: x) != Lazy(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(2)

    assert Lazy(lambda x: x) != Box(1)
    assert Lazy(lambda x: x) != Maybe.just(1)
    assert Lazy(lambda x: x) != Try(lambda: 1)
    assert Lazy(lambda x: x) != Validation.success(1)



# Generated at 2022-06-12 05:12:27.250892
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: None) == Lazy(lambda: None)
    assert Lazy(lambda: 'test') == Lazy(lambda: 'test')
    assert Lazy(lambda: [1, 2, 3]) == Lazy(lambda: [1, 2, 3])
    assert Lazy(lambda: []) == Lazy(lambda: [])
    assert Lazy(lambda: {}) == Lazy(lambda: {})
    assert Lazy(lambda: ()) == Lazy(lambda: ())
    assert Lazy(lambda: NotImplemented) == Lazy(lambda: NotImplemented)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: None)
    assert L

# Generated at 2022-06-12 05:12:33.421305
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def some_function():
        def some_function_inside():
            pass

        return some_function_inside

    lazy1 = Lazy(some_function)
    lazy2 = Lazy(some_function)
    assert lazy1 == lazy2



# Generated at 2022-06-12 05:12:41.420649
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def a():
        return 1

    l = Lazy.of(5)
    l_ref = Lazy.of(5)
    l_ref2 = Lazy(lambda: 5)
    l2 = Lazy.of(10)
    l32 = Lazy(lambda: 10)
    l3 = Lazy(a)

    assert l is not l_ref
    assert not l == l_ref
    assert l == l
    assert not l == l2
    assert l == l_ref2
    assert not l == l32
    assert not l == l3
    assert not l == (1, 2)



# Generated at 2022-06-12 05:12:52.119491
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    class B(Generic[T]):
        def __init__(self, a):
            self.a = a

        def get(self):
            return self.a

    def add1(x):
        return x + 1

    def fn(x):
        return add1(x)

    fn_return_b = lambda x: B(fn(x))

    def fn2(b):
        return b.get()

    def fn2_return_b(b):
        return B(fn2(b))

    x = Lazy(lambda: 1)
    y = x.bind(fn_return_b)
    z = y.bind(fn2_return_b)
    assert z.get() == 2



# Generated at 2022-06-12 05:13:02.185656
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.validation import Validation
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    add1 = lambda x: x + 1
    raise_exception = lambda x: 1 / 0

    assert Lazy.of(1).bind(add1).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1).to_validation()).get() == Validation.success(2)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1).to_maybe()).get() == Maybe.just(2)
    assert L

# Generated at 2022-06-12 05:13:10.444687
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    def add1(x):
        return x + 1

    def add2(y):
        return y + 2

    input_lazy = Lazy.of(1)

    add1_lazy = Lazy.of(add1)
    assert Lazy.of(add2)(input_lazy).get() == add2(1)
    assert add1_lazy.ap(input_lazy).get() == add1(1)
    assert add1_lazy.ap(Lazy.of(1)).get() == add1(1)

# Generated at 2022-06-12 05:13:14.259175
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test for method get of class Lazy
    """
    assert Lazy.of(2).get() == 2
    assert Lazy.of(2).get(1) == 2



# Generated at 2022-06-12 05:13:16.888519
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda x: x**2)
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert not lazy.is_evaluated

# Generated at 2022-06-12 05:13:27.891457
# Unit test for method get of class Lazy
def test_Lazy_get():

    def test_two_times_a():
        a = Lazy(lambda x: x + 2).get(1)
        b = Lazy(lambda x: x + 2).get(1)
        assert a == 3
        assert b == 3

    def test_two_times_b():
        res1 = Lazy(lambda x: x + 2).map(lambda x: x ** 2).get(1)
        res2 = Lazy(lambda x: x + 2).map(lambda x: x ** 2).get(1)
        assert res1 == 9
        assert res2 == 9

    def test_two_times_c():
        res1 = Lazy(lambda x: x + 2).map(lambda x: x ** 2).ap(Lazy.of(3)).get(1)

# Generated at 2022-06-12 05:13:33.846981
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    assert Lazy(lambda x: x) == Lazy(lambda x: x)

    assert Lazy(lambda x: x) != Lazy(lambda x: x * 2)
    assert Lazy(lambda x: x) != Functor.of(2)
    assert Lazy(lambda x: x) != Monad.of(2)
    assert Lazy(lambda x: x) != Applicative.of(2)

    assert Lazy(lambda x: x).bind(lambda x: Lazy(lambda x: x + 1)) != Lazy(lambda x: x).bind(lambda x: Lazy(lambda x: x + 2))

# Generated at 2022-06-12 05:13:39.596153
# Unit test for method map of class Lazy
def test_Lazy_map():
    def assert_map(*args):
        fn = lambda *args_: Lazy.of(args_[0] + 1)
        lazy = Lazy.of(*args).map(fn)
        assert lazy == Lazy(fn)

    assert_map(1)
    assert_map(1, 2)
    assert_map(1, 2, 3)
    assert_map(1, 2, 3, 4)


# Generated at 2022-06-12 05:13:45.751607
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x * 2).ap(Lazy.of(3)) == Lazy.of(6)

    assert Lazy.of(lambda x: x * 2).ap(Lazy.of(None)) == Lazy.of(None)



# Generated at 2022-06-12 05:13:55.453976
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.box import Box
    import pytest

    def method_raises_exception(*args):
        raise Exception("Method raises exception")

    assert Lazy(lambda: 42).bind(lambda x: Lazy(lambda: x + 2)).get() == 44
    assert Lazy(method_raises_exception).bind(lambda x: Lazy(lambda: x + 2)).to_try().is_failure()
    assert Lazy(42).bind(lambda x: Lazy(lambda: x + 2)).to_maybe().is_just()
    assert Lazy(42).bind(lambda x: Lazy(lambda: x + 2)).to

# Generated at 2022-06-12 05:14:05.764434
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Either
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # pylint: disable=unused-variable

    class MyClass:
        def __init__(self, a):
            self.a = a

    class MyCustomError(RuntimeError):
        pass

    # Lazy[int,int] tests
    assert Lazy.of(1).map(lambda a: a + 3).get() == Lazy.of(4).get()
    assert Lazy.of(1).map(lambda a: a + 3).get() == 4

    # Lazy[int,int] as Box tests

# Generated at 2022-06-12 05:14:10.873430
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.either import Right

    def fn(value):
        return Lazy(lambda: value + 1)

    lazy = Lazy(lambda: 1)
    lazy2 = lazy.bind(fn).bind(lambda value: Lazy(lambda: value + 1))

    assert lazy2.get() == 3

# Generated at 2022-06-12 05:14:18.515865
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f1(x):
        return Lazy(lambda: x + 10)
    def f2(x):
        return Lazy(lambda: x * 2)
    assert Lazy(f1).bind(f1).get() == 20
    assert Lazy(f2).bind(f2).get() == 0
    assert Lazy(f1).bind(f2).get() == 30
    assert Lazy(f2).bind(f1).get() == 20

# Generated at 2022-06-12 05:14:30.655626
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    def passed_test_case_1():
        return Lazy(lambda: 1)

    lazy = Lazy(lambda: 0).bind(passed_test_case_1)
    assert lazy.get() == 1

    lazy = Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x))

    assert lazy.get() == 1

    def passed_test_case_2():
        return Lazy(lambda: 2)

    def passed_test_case_3():
        return Lazy(lambda: 3)

    lazy_2 = Lazy(lambda: 1).bind(lambda _: passed_test_case_2())
    lazy_3 = Lazy(lambda: 2).bind(lambda _: passed_test_case_3())

    assert lazy_2.get() == 2
    assert lazy_3.get() == 3

# Generated at 2022-06-12 05:14:33.973278
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def mult(x: int, y: int) -> int:
        return x * y

    lazy = Lazy(mult).map(lambda x: x + 2)
    assert lazy.get(4, 5) == 22



# Generated at 2022-06-12 05:14:41.650971
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def add2(arg):
        return Lazy.of(arg + 2)

    def mult3(arg):
        return Lazy.of(arg * 3)

    def add5(arg):
        return Lazy.of(arg + 5)

    lazy_12 = Lazy.of(10).bind(add2).bind(mult3).bind(add5)

    assert lazy_12.get() == 45



# Generated at 2022-06-12 05:14:52.627929
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe
    from pymonet.monad_list import MonadList
    from pymonet.validation import Validation

    def add_lazy(a):
        return Lazy.of(a + 1)

    def multiply_lazy(a):
        return Lazy.of(a * 2)

    def multiply_and_add_lazy(a):
        return Lazy.of(a * 3 + 1)

    assert Lazy.of(1).bind(add_lazy).get() == Lazy.of(1).bind(add_lazy).get()
    assert Lazy.of(1).bind(add_lazy).bind(multiply_lazy).get() == 3

# Generated at 2022-06-12 05:14:55.629823
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def some_function():
        return 'some value'

    assert Lazy(some_function) == Lazy(some_function)
    assert Lazy(some_function) != Lazy(lambda: 'another value')

    assert Lazy(some_function).get() == 'some value'
    assert Lazy(some_function) != Lazy(some_function).get()



# Generated at 2022-06-12 05:15:05.534945
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 5

    def fn2():
        return 5

    assert Lazy.of(fn).__eq__(Lazy.of(fn2))
    assert not Lazy.of(fn).__eq__(Lazy.of(fn2).map(lambda x: x()))
    assert Lazy.of(fn).__eq__(Lazy.of(fn).map(lambda x: x()))
    assert not Lazy.of(fn) == None
    assert not Lazy.of(fn) == 5

# Generated at 2022-06-12 05:15:08.499785
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x: x + 1).ap(Lazy(lambda x: x + 2)) == Lazy(lambda x: x + 1 + 2)



# Generated at 2022-06-12 05:15:15.457293
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add1(value):
        return Lazy.of(value + 1)

    def multiply3(value):
        return Lazy.of(value * 3)

    def subtract2(value):
        return Lazy.of(value - 2)

    assert Lazy.of(2).bind(add1).bind(multiply3).bind(subtract2).get() == 5


# Generated at 2022-06-12 05:15:21.596798
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_try import Try

    def run_function(x):
        return lambda y: x + y

    def run_function_with_exception(x):
        def lambda_fn(y):
            raise ValueError('Test error')
            return x + y

        return lambda_fn

    assert Lazy(run_function(1)).get(2) == 3
    assert Lazy(run_function(1)).get(2) == 3
    assert Lazy(run_function(1)).to_try().get(2) == Lazy(run_function(1)).get(2)

# Generated at 2022-06-12 05:15:33.109078
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.utils import eq_test

    def lazy_fn(*args):
        return 10

    eq_test(
        Lazy(lazy_fn),
        Lazy(lazy_fn).map(lambda x: x),
        Lazy(lazy_fn).map(lambda x: x + 1),
        Lazy(lazy_fn).map(lambda x: x + 1).get(),
        Lazy(lambda x: x + 1),
        Lazy(lambda x: x + 1).get(10),
    )


# Generated at 2022-06-12 05:15:36.726490
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    def test_function(number):
        return number + 2

    assert Lazy(lambda *args: 2).ap(Box(test_function)) == Lazy.of(4)



# Generated at 2022-06-12 05:15:38.988300
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda x: x)
    assert lazy.get(15) == 15



# Generated at 2022-06-12 05:15:42.912754
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(2).get() == 2
    assert Lazy(lambda x, y: x + y).get(1, 2) == 3
    assert Lazy.of(123).get() == 123


# Generated at 2022-06-12 05:15:49.907187
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test for method get of Lazy class.

    >>> Lazy.of(4).get()
    4
    >>> Lazy(lambda: 4).get()
    4
    >>> Lazy(lambda: 4).map(lambda x: x + 4).get()
    8
    >>> Lazy(lambda: 4).map(lambda x: x + 4).bind(lambda x: Lazy(lambda: x).map(lambda w: w * 2)).get()
    16
    """

# Generated at 2022-06-12 05:16:00.168828
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation

    def add(x):
        def inner(y):
            return x + y
        return Lazy(inner)

    def mul(x):
        def inner(y):
            return x * y
        return Lazy(inner)

    lazy = Lazy.of(2)
    assert lazy.ap(add(2)) == Lazy(lambda: add(2).get(lazy.value))
    assert lazy.ap(mul(10)) == Lazy(lambda: mul(10).get(lazy.value))

    add_lazy = Lazy(lambda: add)

    assert Validation(add_lazy).ap(Validation(3)).get() == Validation(add(3))

# Generated at 2022-06-12 05:16:13.293717
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def f():  # pragma: no cover
        pass

    def ff():  # pragma: no cover
        pass

    lazy_default_fn = Lazy(f)
    assert lazy_default_fn == lazy_default_fn

    lazy_default_fn_copy = Lazy(f)
    assert lazy_default_fn == lazy_default_fn_copy

    lazy_default_fn_with_other_fn = Lazy(ff)
    assert lazy_default_fn != lazy_default_fn_with_other_fn

    lazy_default_fn.constructor_fn(1)
    lazy_default_fn_copy.constructor_fn(1)
    assert lazy_default_fn == lazy_default_fn_copy

    lazy_default_fn_with_other_fn.constructor_fn

# Generated at 2022-06-12 05:16:18.715750
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_maybe import Maybe

    def add_one(value):
        if isinstance(value, int) and value == 1:
            return Maybe.just(2)
        return Maybe.just(1)

    lazy_value = Lazy.of(1)
    assert lazy_value.map(add_one).get() == 2

    lazy_value = Lazy.of(2)
    assert lazy_value.map(add_one).get() == 1



# Generated at 2022-06-12 05:16:25.412596
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for method get of class Lazy
    """
    from pymonet.box import Box

    assert Lazy(lambda x: x + 2).get(3) == 5
    assert str(Lazy(lambda: Box(2)).get()) == 'Box[2]'
    assert str(Lazy(lambda x: lambda y: x + y)(2)(3)) == 'Box[5]'
    assert Lazy(lambda: Box(2)).bind(lambda x: Lazy(lambda: Box(x + 2))).get() == 4



# Generated at 2022-06-12 05:16:31.937814
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.monad_maybe import Maybe

    def fn(x):
        return x + 1

    lazy = Lazy.of(fn).ap(Box(3))
    assert lazy.get() == 4

    lazy = Lazy.of(fn).ap(Maybe.just(3))
    assert lazy.get() == 4



# Generated at 2022-06-12 05:16:38.137332
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_1 = Lazy(lambda x: x)
    lazy_2 = Lazy(lambda x: x)
    lazy_3 = Lazy(lambda x: x + 1)

    assert lazy_1 == lazy_2
    assert lazy_1 != lazy_3


# Generated at 2022-06-12 05:16:47.412970
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functional import compose

    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x - 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x, y: x - y)
    assert Lazy(compose(lambda x: x + 1)) == Lazy(compose(lambda x: x + 1))
    assert Lazy(compose(lambda x: x + 1)) != Lazy(compose(lambda x: x - 1))
    assert Lazy(compose(lambda x: x + 1)) != Lazy(compose(2))



# Generated at 2022-06-12 05:16:52.614631
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    empty_lazy = Lazy(lambda: None)

    assert empty_lazy.map(Maybe.just).get() is None

    assert empty_lazy.map(Validation.success).get() is None

# Generated at 2022-06-12 05:16:55.656551
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    assert Lazy.of(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)



# Generated at 2022-06-12 05:17:00.394569
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.functor_list import FunctorList

    functor = Functor(Lazy.of(1))
    functor_list = FunctorList.of(Lazy.of(1))
    assert functor == functor_list


# Generated at 2022-06-12 05:17:02.627426
# Unit test for method get of class Lazy
def test_Lazy_get():
    def square(x):
        return x*x

    test_Lazy = Lazy(lambda x: square(x))

    assert test_Lazy.get(5) == square(5)

# Generated at 2022-06-12 05:17:16.026803
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 'a').get() == 'a'
    assert Lazy(lambda: Box(1)).get() == Box(1)
    assert Lazy(lambda: Left('a')).get() == Left('a')
    assert Lazy(lambda: Maybe.just(1)).get() == Maybe.just(1)
    assert Lazy(lambda: Try(lambda: 1)).get() == Try(lambda: 1).get()
    assert Lazy(lambda: Validation.success(1)).get() == Validation

# Generated at 2022-06-12 05:17:22.632979
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def get_value():
        return 10

    lazy_with_value = Lazy(fn=get_value)
    folded_value = lazy_with_value.bind(lambda value: Lazy(lambda: Box.of(value * 2)))
    assert folded_value.get() == Box.of(20)


# Generated at 2022-06-12 05:17:28.655129
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try

    def double_add(x: float) -> Try[float]:
        return Try.of(lambda: x + 1).map(lambda z: z + 1)

    assert Lazy(lambda: 1).bind(double_add).get() == 3
    assert Lazy(lambda: 1).bind(lambda x: Lazy.of(x + 1)).get() == 2

# Generated at 2022-06-12 05:17:36.714617
# Unit test for method get of class Lazy
def test_Lazy_get():
    import pymonet

    assert Lazy.of(10).get() == 10
    assert Lazy.of(None).get() is None
    assert Lazy.of([1, 2, 3]).get() == [1, 2, 3]

    test_lazy = Lazy(lambda: pymonet.Left(10))
    assert test_lazy.get() == pymonet.Left(10)

    test_lazy = Lazy(lambda: pymonet.Some(True))
    assert test_lazy.get() == pymonet.Some(True)

    test_lazy = Lazy(lambda: pymonet.Try.of(int, '10').get())
    assert test_lazy.get() == 10


# Generated at 2022-06-12 05:17:40.423479
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test case for method map of Lazy monad

    **Requirements**

    - mapped Lazy should have value depending on result of constructor
    """
    def to_val(value: int) -> int:
        """
        function return increment of argument
        :param value: initial value
        :type value: int
        :returns: increment of initial value
        :rtype: int
        """
        return value + 1

    lazy = Lazy(to_val)
    lazy_mapped = lazy.map(to_val)

    assert lazy_mapped.get(1) == 3



# Generated at 2022-06-12 05:17:46.901673
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.functions import identity

    lazy = Lazy.of(4)
    result = lazy.bind(identity)

    assert isinstance(result, Lazy)
    assert result == lazy
    assert result.get() == 4

    box = lazy.bind(lambda x: Box.of(x + 1))

    assert isinstance(box, Box)
    assert box.get() == 5

# Generated at 2022-06-12 05:17:52.031359
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy1 = Lazy.of(1)
    lazy2 = lazy1.bind(lambda x: Lazy.of(x + 1))

    assert lazy1.is_evaluated is False and \
           lazy1.value is None
    assert lazy2.get() == 2

    assert lazy2.is_evaluated is True and \
           lazy2.value == 2



# Generated at 2022-06-12 05:18:01.201801
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.list import List
    from pymonet.validation import Validation

    def test_func(arg):
        return Lazy(lambda x: x + 1).ap(arg)

    assert 1 == test_func(Lazy.of(0)).get()
    assert 2 == test_func(Lazy.of(1)).get()

    assert List(1, 2, 3) == List(1, 2, 3).ap(List.of(lambda x: x + 1))

    assert Validation.success('test') == Validation.success('test').ap(Validation.of(lambda x: x + '2'))



# Generated at 2022-06-12 05:18:02.614632
# Unit test for method get of class Lazy
def test_Lazy_get():
    f = lambda x: x

    assert Lazy(f).get(1) == 1

# Generated at 2022-06-12 05:18:06.922557
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return 5

    def twice(value):
        return value * 2

    lazy = Lazy(fn)
    assert lazy.get() == 5
    assert lazy.map(twice).get() == 10

    lazy = Lazy(fn)
    assert lazy.get() == 5
    assert lazy.map(twice).get() == 10


# Generated at 2022-06-12 05:18:14.409019
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 'test') != object
    assert Lazy(lambda: 'test') == Lazy(lambda: 'test')
    assert Lazy(lambda: 'test') != Lazy(lambda: 'test_2')
    assert Lazy(lambda: 'test') != Lazy(lambda: 'test').map(lambda x: x + '_')
    assert Lazy(lambda: 'test').map(lambda x: x + '_') != Lazy(lambda: 'test').map(lambda x: x + '__')
    assert Lazy(lambda: 'test').map(lambda x: x + '_') == Lazy(lambda: 'test').map(lambda x: x + '_')



# Generated at 2022-06-12 05:18:16.937197
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.validation import Validation

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of('1')
    assert Lazy.of(1) != Lazy(lambda: 1)
    assert Lazy.of(Validation.success(1)) == Lazy.of(Validation.success(1))



# Generated at 2022-06-12 05:18:23.968420
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1), 'Lazy(1) == Lazy(1)'
    assert Lazy.of(None) == Lazy.of(None), 'Lazy(None) == Lazy(None)'
    assert Lazy.of(1) != Lazy.of(2), 'Lazy(1) != Lazy(2)'
    assert Lazy.of(1) != None, 'Lazy(1) != None'
    assert None != Lazy.of(1), 'None != Lazy(1)'
    assert Lazy.of(1) != 1, 'Lazy(1) != 1'
    assert 1 != Lazy.of(1), '1 != Lazy(1)'



# Generated at 2022-06-12 05:18:26.257752
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    lazy = Lazy(lambda a: a + 1)

    assert lazy.get(2) == 3

# Generated at 2022-06-12 05:18:32.358765
# Unit test for method get of class Lazy
def test_Lazy_get():
    def double(value):
        return value * 2

    a = Lazy(double)
    assert a.get(4) == 8
    assert a.get(4) == 8

    a = Lazy(lambda x: x * 2)
    assert a.get(5) == 10
    assert a.get(5) == 10

    a = Lazy(lambda x: x + 2)
    assert a.get(5) == 7
    assert a.get(5) == 7



# Generated at 2022-06-12 05:18:33.726243
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda : 12).map(lambda x: x + 1).get() == 13



# Generated at 2022-06-12 05:18:36.899470
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f1():
        return 3

    def f2():
        return 3

    def f3():
        return 4

    assert Lazy(f1) == Lazy(f1)
    assert Lazy(f1) == Lazy(f2)
    assert Lazy(f1) != Lazy(f3)



# Generated at 2022-06-12 05:18:48.389516
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    with patch('pymonet.monad.lazy.Lazy.get', return_value=5):
        assert Lazy.of(5) == Lazy(lambda: 5)

    with patch('pymonet.monad.lazy.Lazy.get', return_value=5):
        assert Lazy.of(5) != Lazy(lambda: 6)

    with patch('pymonet.monad.lazy.Lazy.get', return_value=5):
        assert Lazy.of(5) != Lazy(lambda: 5)

    with patch('pymonet.monad.lazy.Lazy.get', return_value=5):
        assert Lazy.of(5) != Lazy(lambda: 5)


# Generated at 2022-06-12 05:18:56.428939
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def lazy_of_box(value):
        return Lazy(lambda *args: Box(value))

    def lazy_of_maybe(value):
        return Lazy(lambda *args: Maybe.just(value))

    def lazy_of_try(value):
        return Lazy(lambda *args: Try.of(lambda: value))

    def lazy_of_validation(value):
        return Lazy(lambda *args: Validation.success(value))

    assert Lazy.of(10).bind(lazy_of_box) == Lazy.of(Box(10))

# Generated at 2022-06-12 05:19:00.418170
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(3).__eq__(Lazy.of(3))
    assert not Lazy.of(3).__eq__(Lazy.of(2))



# Generated at 2022-06-12 05:19:14.547800
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    lazy_1 = Lazy(lambda x: x + 1)
    lazy_2 = Lazy(lambda x: x * 2)
    lazy_3 = Lazy(lambda x: x * 3)

    lazy_list = [lazy_1, lazy_2, lazy_3]

    def check_value(element):
        element.bind(lambda value: Box.of((element, value)))

    result = map(lambda element: element.get(2), map(check_value, lazy_list))
    expected = [(lazy_1, 3), (lazy_2, 4), (lazy_3, 6)]

    assert all(map(lambda result_element, expected_element: result_element == expected_element, result, expected))



# Generated at 2022-06-12 05:19:19.016264
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add10(value):
        def add(x):
            return x + 10

        return Lazy(add)

    def add5(value):
        def add(x):
            return x + 5

        return Lazy(add)

    lazy_value = Lazy(lambda: 10).bind(add10).bind(add5)

    assert lazy_value.get() == 25

# Generated at 2022-06-12 05:19:31.517186
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.validation import Validation

    def id_function(value):
        return value

    def my_function(value):
        return value

    lazy = Lazy(lambda: id_function(42))
    lazy2 = Lazy(lambda: id_function(42))

    assert lazy == lazy2

    lazy = Lazy(lambda: id_function(42))
    lazy2 = Lazy(lambda: id_function(43))

    assert lazy != lazy2

    lazy = Lazy(lambda: my_function(42))
    lazy2 = Lazy(lambda: my_function(42))

    assert lazy == lazy2

    lazy = Lazy(lambda: my_function(42)).map(lambda x: x * 2)

# Generated at 2022-06-12 05:19:34.678744
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    f = lambda x: Lazy.of(x)
    l = Lazy(lambda: 3)
    assert l.bind(f).get() == 3



# Generated at 2022-06-12 05:19:39.731584
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    some_function_to_call_later = lambda x: Box(x).map(lambda y: y + 1).map(lambda z: z + 2)
    some_value = 2
    lazy_with_function = Lazy(some_function_to_call_later)

    lazy_with_function_value = lazy_with_function.bind(lambda x: x).get(some_value)

    assert 5 == lazy_with_function_value

# Generated at 2022-06-12 05:19:46.596523
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of('').get() == ''

    test_lazy = Lazy(lambda: 'test')
    assert test_lazy.get() == 'test'
    assert test_lazy.get() == 'test'

    assert Lazy(lambda: 'test').get('arg') == 'test'
    assert Lazy(lambda arg: arg).get('test') == 'test'
    assert Lazy(lambda arg: arg).get('test') == 'test'
    assert Lazy(lambda arg1, arg2: arg1 + ' ' + arg2).get('value1', 'value2') == 'value1 value2'
    assert Lazy(lambda arg1, arg2: arg1 + ' ' + arg2).get('value1', 'value2') == 'value1 value2'


# Generated at 2022-06-12 05:19:49.996970
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(5).get() == 5
    assert Lazy.of(5).map(lambda x: x + 1).get() == 6



# Generated at 2022-06-12 05:19:57.897965
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    lazy = Lazy.of(2)

    assert lazy.map(add).constructor_fn == add
    assert lazy.map(add).constructor_fn(3) == add(3)

    assert lazy.map(mul).constructor_fn != add
    assert lazy.map(mul).constructor_fn != mul
    assert lazy.map(mul).constructor_fn(3) == mul(3)



# Generated at 2022-06-12 05:20:00.781385
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():                         # pragma: no cover
    def make_lazy_function():
        return Lazy.of(make_element())

    def make_element():
        return 'element'

    lazy1 = make_lazy_function()
    lazy2 = make_lazy_function()
    lazy3 = lazy1.bind(lambda el: Lazy.of(el * 2))

    assert lazy1 == lazy2
    assert lazy1 != lazy3
# Test for method __eq__ of class Lazy



# Generated at 2022-06-12 05:20:01.816029
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of('value').get() == 'value'



# Generated at 2022-06-12 05:20:15.568674
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from nose.tools import assert_equal
    assert_equal(Lazy(lambda x: x*x)._compute_value(2), 4)
    assert_equal(Lazy(lambda x: x*x), Lazy(lambda x: x*x))
    assert_equal(Lazy(lambda x: x*x+1), Lazy(lambda x: x*x+1))
    assert_not_equal(Lazy(lambda x: x*x), Lazy(lambda x: x*x+1))
    assert_not_equal(Lazy(lambda x: x*x), Lazy(lambda x: x*x+1))
    assert_not_equal(Lazy(lambda x: x*x)._compute_value(2), 5)

# Generated at 2022-06-12 05:20:24.664616
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda a: a + 1).__eq__(
        Lazy(lambda a: a + 1)
    )

    assert Lazy(lambda a: a + 1).__eq__(
        Lazy(lambda a: a + 1).map(lambda x: str(x))
    )

    assert Lazy(lambda a: a + 1).map(lambda x: str(x)).__eq__(
        Lazy(lambda a: a + 1).map(lambda x: str(x))
    )

    assert not Lazy(lambda a: a + 1).__eq__(
        Lazy(lambda a: a + 2)
    )

    assert not Lazy(lambda a: str(a + 1)).__eq__(
        Lazy(lambda a: a + 1)
    )

# Generated at 2022-06-12 05:20:30.382665
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_lazy import Lazy as lz
    l1 = lz(lambda x: x)
    l2 = lz(lambda x: x)
    l3 = lz(lambda x: x)

    assert l1 == l2
    assert not(l1 == l3)



# Generated at 2022-06-12 05:20:32.817624
# Unit test for method map of class Lazy
def test_Lazy_map():
    def fn(): return 1
    assert Lazy(fn).map(lambda y: y + 1).get() == 2



# Generated at 2022-06-12 05:20:37.173435
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_maybe import Maybe

    assert Lazy.of(Maybe.of(1)).map(lambda x: x.map(lambda y: y + 1)).get() == Maybe.of(2)
    assert Lazy.of(2).map(lambda x: x + 1).get() == 3


# Generated at 2022-06-12 05:20:47.727451
# Unit test for method get of class Lazy
def test_Lazy_get():
    # type: () -> None
    from pymonet.maybe import Maybe

    def function_to_call(*args):
        # type: (int) -> int
        return args[0] + 10

    lazy = Lazy(function_to_call)

    assert lazy.get(10) == 20
    assert lazy.get(20) == 20

    assert lazy.to_maybe(10) == Maybe.just(20)
    assert lazy.to_maybe(20) == Maybe.just(20)

    assert lazy.to_box(10) == function_to_call(10)
    assert lazy.to_box(20) == function_to_call(20)


# Generated at 2022-06-12 05:20:59.425121
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.validation import Validation, ValidationError

    validation = Lazy(lambda x: Validation.success(x + 1))
    assert validation.bind(lambda x: Lazy.of(x)).get(5) == 6
    assert validation.bind(lambda x: Lazy.of(x)).get(10) == 11

    validation = Lazy(lambda x: Validation.failure([ValidationError('error')]))
    assert validation.bind(lambda x: Lazy.of(x)).get('a') == ['error']

    assert Lazy.of(3).bind(lambda x: Lazy.of(x)).get('a') == 3
    assert Lazy.of(3).bind(lambda x: Lazy.of(x)).get('') == 3
    assert Lazy.of