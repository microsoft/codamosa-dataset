

# Generated at 2022-06-12 05:11:11.603899
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor

    def add(x):
        return x + 1

    fn_const = lambda *args: 2
    fn_add = lambda *args: args[0] + 2

    lazy_const = Lazy(fn_const)

    with TestCase() as testcase:
        testcase.assertTrue(lazy_const == lazy_const)

    lazy_const_folded = lazy_const.get()
    lazy_const_folded_another_call = lazy_const.get()

    with TestCase() as testcase:
        testcase.assertEqual(lazy_const, lazy_const_folded)
        testcase.assertEqual(lazy_const, lazy_const_folded_another_call)


# Generated at 2022-06-12 05:11:22.031184
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test function bind of class Lazy
    """
    def square(x):
        return x * x

    def double(y):
        return y * 2

    def add_one(y):
        return y + 1

    def square_of_double(x):
        return square(double(x))

    def square_of_double_plus_one(x):
        return square_of_double(x) + 1

    assert Lazy.of(1)\
        .bind(lambda y: Lazy.of(double(y)))\
        .bind(lambda y: Lazy.of(square(y)))\
        .bind(lambda y: Lazy.of(add_one(y))).get() == 2

# Generated at 2022-06-12 05:11:31.800021
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__(): # pragma: no cover
    from pymonet.functor import identity

    lazy = Lazy.of('x')
    assert (
        lazy
        ==
        Lazy.of('x')
    )

    assert (
        lazy
        ==
        lazy
    )
    assert (
        lazy
        ==
        Lazy(lambda x: 'x')
    )
    assert (
        lazy
        ==
        Lazy(identity)
    )

    assert (
        lazy
        !=
        Lazy.of('y')
    )
    assert (
        lazy
        !=
        'x'
    )


# Generated at 2022-06-12 05:11:40.761756
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.either import Right, Left

    assert Lazy.of(123) == Lazy.of(123)
    assert Lazy.of(123) != Lazy.of(321)
    assert Lazy.of(Right(1)) != Lazy.of(Right(1))
    assert Lazy.of(Right(1)) == Lazy.of(Right(1))
    assert Lazy.of(Left(1)) != Lazy.of(Left(1))
    assert Lazy.of(Left(1)) == Lazy.of(Left(1))
    assert Lazy.of(Right(1)) != Lazy.of(Left(1))
    assert Lazy.of(Left(1)) != Lazy.of(Right(1))

test_Lazy___eq__()

# Generated at 2022-06-12 05:11:52.764378
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert (Lazy(lambda *args: 4) == Lazy(lambda *args: 4)) is True
    assert (Lazy(lambda *args: 42) == Lazy(lambda *args: 4)) is False
    assert (Lazy(lambda *args: 42) == Lazy(lambda *args: 42)) is True
    assert (Lazy(lambda *args: [1, 2, 3]) == Lazy(lambda *args: [1, 2, 3])) is True
    assert (Lazy(lambda *args: [1, 2, 3]) == Lazy(lambda *args: [3, 2, 1])) is False
    assert (Lazy(lambda *args: [1, 2]) == Lazy(lambda *args: [1, 2, 3])) is False

# Generated at 2022-06-12 05:11:54.997982
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda value: Lazy.of(value * 2)) == Lazy.of(2)



# Generated at 2022-06-12 05:11:58.634684
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn1(*_):
        return 1

    def fn2(*_):
        return 2

    lazy = Lazy(fn1)
    binded = lazy.bind(lambda x: Lazy(fn2))

    assert binded.get() == 2



# Generated at 2022-06-12 05:12:06.438420
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    # GIVEN

    def fn_a_1(a):
        return a + 1

    def fn_a_2(a):
        return a + 2

    a = Lazy.of(1).map(fn_a_1).map(fn_a_2)
    lazy_of_a = Lazy.of(a)

    # WHEN
    result = lazy_of_a.bind(lambda x: x)

    # THEN
    assert isinstance(result, Lazy)



# Generated at 2022-06-12 05:12:11.187579
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    fn = lambda x: x + 1
    lazy1 = Lazy(fn)

    assert lazy1 == lazy1
    assert lazy1 != Lazy(lambda x: x + 2)
    assert lazy1 != Lazy(fn).map(lambda x: x)
    assert lazy1 == Lazy(fn)
    assert lazy1 != lazy1.get(2)


# Generated at 2022-06-12 05:12:23.369040
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_function():
        pass

    def test_function_2():
        pass

    class TestClass:
        def __eq__(self, other):
            if isinstance(other, Lazy):
                return (
                    other.is_evaluated == self.is_evaluated
                    and other.value == self.value
                    and other.constructor_fn == self.constructor_fn
                )
            else:
                return False

        def __init__(self, value, is_evaluated, constructor_fn):
            self.value = value
            self.is_evaluated = is_evaluated
            self.constructor_fn = constructor_fn

    def test_function_3():
        pass

    assert Lazy(test_function) == Lazy(test_function)
    assert Lazy(test_function) != L

# Generated at 2022-06-12 05:12:32.977043
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test for method __eq__ of class Lazy
    """
    from pymonet.maybe import Maybe

    assert Lazy(lambda x: Maybe.just(x)) == Lazy(lambda x: Maybe.just(x))
    assert Lazy(lambda x, y: Maybe.just(x + y)) == Lazy(lambda x, y: Maybe.just(x + y))

    assert Lazy(lambda x: Maybe.just(x)) != Lazy(lambda x: Maybe.just(x + 1))


# Generated at 2022-06-12 05:12:39.193204
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Create Lazy containing lambda returning A and call map method with function Function(A) -> B.

    After calling _compute_value we should get new Lazy with mapped function by mapper.
    """
    fn = lambda x: x
    obj = Lazy(fn)

    mapped_obj = obj.map(lambda x: x)

    assert obj.get() == fn()
    assert mapped_obj.get() == fn()



# Generated at 2022-06-12 05:12:50.727506
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != 1
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()


# Generated at 2022-06-12 05:13:01.397720
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    import unittest

    class TestLazy___eq__(unittest.TestCase):
        def setUp(self):
            self.lazy = Lazy(lambda x: x)

        def test_equals_itself(self):
            self.assertEquals(self.lazy, self.lazy)

        def test_equals_copy_of_itself(self):
            self.assertEquals(self.lazy, Lazy(lambda x: x))

        def test_equals_copy_of_itself_with_arguments(self):
            self.assertEquals(self.lazy, Lazy(lambda x, y: y))


# Generated at 2022-06-12 05:13:11.418951
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    lazy_success = Lazy(lambda: 1)
    lazy_failure = Lazy(lambda: 1/0)
    assert lazy_success.get() == 1
    assert lazy_failure.get() == lazy_failure.get()
    assert lazy_success.get() == lazy_success.get()

    assert Validation.success(lazy_success.get()) == lazy_success.to_validation()
    assert Try.of(lazy_success.get) == lazy_success.to_try()
    assert Try.of(lazy_failure.get) == lazy_failure.to_try()



# Generated at 2022-06-12 05:13:15.077599
# Unit test for method get of class Lazy
def test_Lazy_get():
    def func_to_call(arg):
        return arg + 2

    lazy = Lazy(func_to_call)
    assert lazy.get(2) == 4



# Generated at 2022-06-12 05:13:26.281612
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test for method __eq__ of class Lazy
    """
    # Test for equal
    lazy1 = Lazy(lambda: 'bla')
    lazy2 = Lazy(lambda: 'bla')
    assert lazy1 == lazy2

    # Test for equals with different values
    lazy1 = Lazy(lambda: 'bla')
    lazy2 = Lazy(lambda: 'bla')
    assert lazy1.get() == lazy2.get()
    assert lazy1 == lazy2

    # Test for equals with different constructor functions
    lazy1 = Lazy(lambda: 3)
    lazy2 = Lazy(lambda: 3)
    assert lazy1.get() != lazy2.get()
    assert lazy1 == lazy2

    # Test for not equals
    lazy1 = Lazy(lambda: 'bla')
    lazy2

# Generated at 2022-06-12 05:13:33.009104
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a, b):
        return a + b

    def multiply(a, b):
        return a * b

    def divide(a, b):
        return a / b

    add_lazy = Lazy(lambda x: lambda y: add(x, y))
    multiplied_lazy = Lazy(lambda x: multiply(x, x))
    div_lazy = Lazy(lambda x: divide(x, 7))

    assert add_lazy.ap(multiplied_lazy).get(2).get(2) == 8
    assert add_lazy.ap(div_lazy).get(21).get(21) == 3
    assert add_lazy.ap(div_lazy).get(2).get(2) == 3



# Generated at 2022-06-12 05:13:43.028993
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.maybe import Maybe

    def add_ten(x):
         return x + 10

    def multiply_by_ten(x):
        return x * 10

    lazy1 = Lazy.of(lambda x, y: x + y)
    lazy2 = Lazy.of(lambda x, y: x * y)
    x = Lazy.of(5)
    y = Lazy.of(6)

    assert lazy1.ap(x).map(add_ten).ap(y).get() == 31
    assert lazy2.ap(y).map(multiply_by_ten).ap(x).get() == 350

    assert Maybe.just(7).ap(Lazy.of(add_ten)).get() == 17



# Generated at 2022-06-12 05:13:51.832064
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    called = False
    value = 2
    def double(x):
        nonlocal called
        called = True
        return x * 2

    def always_true():
        return True

    lazy_value = Lazy.of(2)

    result = lazy_value.bind(double)
    assert not called
    assert result.constructor_fn() == value * 2
    assert called

    result = lazy_value.bind(always_true)
    assert not called
    assert result.constructor_fn()
    assert not called


# Generated at 2022-06-12 05:14:02.064865
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def constructor_fn(x):
        return x * 2

    lazy = Lazy(constructor_fn)
    assert lazy.get(2) == 4
    assert lazy.is_evaluated
    assert lazy.value == 4
    assert lazy.get(2) == 4
    assert lazy.is_evaluated
    assert lazy.value == 4



# Generated at 2022-06-12 05:14:04.820595
# Unit test for method get of class Lazy
def test_Lazy_get():
    def testeen(a: int) -> int:
        return a * a
    lazy = Lazy(testeen)
    assert lazy.get(2) == 4
    assert lazy.get(3) == 9



# Generated at 2022-06-12 05:14:16.740253
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box

    def function_to_bind(value):
        def function_to_call(arg1):
            return Box.of(value + arg1)

        return Lazy(function_to_call)

    lazy_with_function_to_bind = Lazy.of(function_to_bind)

    assert lazy_with_function_to_bind.bind(function_to_bind).get(3) == Box.of(3)
    assert lazy_with_function_to_bind.bind(function_to_bind).constructor_fn(3) == Box.of(3)

    assert lazy_with_function_to_bind.bind(function_to_bind).get(10) == Box.of(10)
    assert lazy_with_function_to_bind.bind

# Generated at 2022-06-12 05:14:24.329605
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.validation import Validation

    class Class1:
        pass

    class Class2:
        pass

    class Class3:
        pass

    class Class4:
        pass

    lazy1 = Lazy(lambda *args: 1)
    lazy1_2 = Lazy(lambda *args: 1)
    lazy2 = Lazy(lambda *args: Class1())
    lazy3 = Lazy(lambda *args: [1, 2, 3])
    lazy3_2 = Lazy(lambda *args: [1, 2, 3])
    lazy3_3 = Lazy(lambda *args: [1, 2, 3])
    lazy4 = Lazy(lambda *args: {'a': 2, 'b': 3})

# Generated at 2022-06-12 05:14:34.409428
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x).bind(lambda x: Lazy(lambda: x + 1)).fold(1) == 2
    assert Lazy(lambda x: x).bind(lambda x: Lazy(lambda: x + 1)).get() == 2
    assert Lazy(lambda x: x).bind(lambda x: Lazy(lambda: x + x)).fold(1) == 2
    assert Lazy(lambda x: x).bind(lambda x: Lazy(lambda: x + x)).get() == 2
    assert Lazy(lambda x: x).bind(lambda x: Lazy(lambda: x + x)).bind(lambda x: Lazy(lambda: x + x)).fold(1) == 4

# Generated at 2022-06-12 05:14:44.102925
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test_fn():
        return 'abcdef-1234'

    lazy = Lazy(test_fn)
    assert lazy.constructor_fn == test_fn
    assert lazy.value is None
    assert lazy.is_evaluated is False

    result = lazy.map(lambda val: val[::-1])

    assert result.constructor_fn != test_fn
    assert isinstance(result.constructor_fn, type(lambda: None))  # noqa
    assert result.value is None
    assert result.is_evaluated is False

    result = result.get()
    assert result == '4321-fedcba'


# Generated at 2022-06-12 05:14:45.365296
# Unit test for method get of class Lazy
def test_Lazy_get():

    def fn():
        return 'test'

    result = Lazy(fn).get()

    assert result == 'test'



# Generated at 2022-06-12 05:14:51.180090
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(a, b):
        return a + b

    def fn_exception():
        raise Exception()

    lazy_instance = Lazy(fn)

    assert lazy_instance.get(1, 2) == 3
    assert lazy_instance.get(1, 2) == 3

    assert Lazy(fn_exception).get() is None


# Generated at 2022-06-12 05:14:57.104875
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def func_a(*args):
        return args[0]

    def func_b(*args):
        return args[0] + 1

    assert Lazy.of(0) == Lazy.of(0)
    assert Lazy.of(0) == Lazy(func_a)
    assert Lazy.of(0) != Lazy(func_b)



# Generated at 2022-06-12 05:14:59.355027
# Unit test for method map of class Lazy
def test_Lazy_map():
    d = Lazy(lambda x: x * 2)
    assert d.map(lambda x: x * 5).get(2) == 20


# Generated at 2022-06-12 05:15:15.352504
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def eq_factory():
        class A:
            pass

        a = A()
        return a

    eq_a = Lazy.of(eq_factory())
    eq_b = Lazy.of(eq_factory())
    eq_c = Lazy.of(eq_factory())

    assert eq_a != eq_b
    assert eq_b == eq_c
    assert eq_a != eq_c



# Generated at 2022-06-12 05:15:22.493473
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add1(x):
        return x + 1

    def mul2(x):
        return x * 2


    result = Lazy.of(10).bind(lambda x: Lazy.of(x + 1))
    assert result.get() == 11

    result = Lazy.of(10).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x * 2))
    assert result.get() == 22

    result = Lazy.of(10).bind(lambda x: Lazy.of(x + 1).bind(lambda y: Lazy.of(y * 2)))
    assert result.get() == 22


# Generated at 2022-06-12 05:15:27.922819
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test of method bind of class Lazy

    :raises: AssertionError if test fails
    """
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy.of(1).bind(fn).get() == 2

# Generated at 2022-06-12 05:15:29.895196
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy = Lazy(lambda: 42)
    assert lazy == Lazy.of(42)


# Generated at 2022-06-12 05:15:41.639767
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f():
        pass

    def g():
        pass

    assert Lazy(f).__eq__(Lazy(f))
    assert not Lazy(f).__eq__(Lazy(g))

    assert Lazy(f).map(f).__eq__(Lazy(f).map(f))
    assert not Lazy(f).map(f).__eq__(Lazy(f).map(g))
    assert Lazy(f).map(f).__eq__(Lazy(g).map(f))
    assert not Lazy(f).map(f).__eq__(Lazy(g).map(g))

    assert Lazy(f).bind(f).__eq__(Lazy(f).bind(f))

# Generated at 2022-06-12 05:15:50.734793
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Unit test for method ap of class Lazy
    """
    from pymonet.validation import Validation

    def _fn_with_args(value, length):
        return '{} with length {}'.format(value, len(value))

    def _fn_double(value):
        return '{} - {}'.format(value, value)

    fn = Lazy(lambda x: _fn_with_args(x, len(x)))
    fn_double = Lazy(lambda x: _fn_double(x))

    actual = fn.ap(fn_double).get('hello')

    assert actual == 'hello with length 5 - hello with length 5'



# Generated at 2022-06-12 05:15:53.534096
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = lambda x: x + 1
    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(lambda x: x)



# Generated at 2022-06-12 05:16:04.314950
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    class Lazy(Monad):

        def __init__(self, constructor_fn: Callable[[T], U]) -> None:
            """
            :param constructor_fn: function to call during fold method call
            :type constructor_fn: Function() -> A
            """
            self.constructor_fn = constructor_fn
            self.is_evaluated = False
            self.value = None

        def __str__(self) -> str:  # pragma: no cover
            return 'Lazy[fn={}, value={}, is_evaluated={}]'.format(self.constructor_fn, self.value, self.is_evaluated)

        def __eq__(self, other: object) -> bool:
            """
            Two Lazy are equals where both are evaluated both have the same value and constructor functions.
            """

# Generated at 2022-06-12 05:16:14.713867
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    # --pytest-args --doctest-modules --cov-report=term-missing --cov-report html --cov=monet
    from pymonet.monad_try import Try

    def constructor_fn():
        return 1

    def mapper(x):
        return x + 1

    # Test for equals Lazy
    lazy_one = Lazy(constructor_fn).map(mapper)
    lazy_second = Lazy(constructor_fn).map(mapper)

    Try.of(lazy_one.get)
    Try.of(lazy_second.get)

    assert lazy_one == lazy_second

    # Test for unequals Lazy
    lazy_one = Lazy(constructor_fn)
    lazy_second = Lazy(constructor_fn).map

# Generated at 2022-06-12 05:16:19.381561
# Unit test for method get of class Lazy
def test_Lazy_get():
    def f_x(x):
        return lambda y: x * y

    def f_y(y):
        return lambda x: x * y

    f = Lazy(f_x(2)).map(f_y(5))  # type: Lazy[int, int]
    assert 20 == f.get(2)

    f = Lazy(f_y(5)).map(f_x(2))  # type: Lazy[int, int]
    assert 20 == f.get(2)



# Generated at 2022-06-12 05:16:34.335047
# Unit test for method get of class Lazy
def test_Lazy_get():
    test_value = 1

    class LazyTest(Lazy[{}, int]):
        def __init__(self, value: int) -> None:
            self.value = value
            super().__init__(lambda x: self.value)

    fake_fn = Mock()

    assert Lazy(lambda: test_value).get() == test_value

    lazy_test = LazyTest(test_value)
    assert lazy_test.get() == test_value
    assert lazy_test.is_evaluated is True
    

# Generated at 2022-06-12 05:16:35.109200
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def function():
        pass

    assert Lazy(function) == Lazy(function)



# Generated at 2022-06-12 05:16:45.136011
# Unit test for method map of class Lazy
def test_Lazy_map():
    # should make new Lazy
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2

    # should not evaluate original
    l = Lazy(lambda: 1)
    l.map(lambda x: x + 1)
    assert l.get() == 1

    # should not evaluate twice
    l = Lazy(lambda: 1)
    l2 = l.map(lambda x: x + 1)
    assert l2.get() == 2
    assert l2.get() == 2

    # should keep result after evaluation
    l = Lazy(lambda: 1)
    l2 = l.map(lambda x: x + 1)
    assert l2.get() == 2
    assert l2.get() == 2



# Generated at 2022-06-12 05:16:46.570342
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(2).get() == 2


# Generated at 2022-06-12 05:16:58.552977
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def identity(x):
        return x

    def add_one(x):
        return x + 1

    def mult(x, y):
        return x * y

    assert Lazy.of(0).bind(lambda x: Lazy.of(identity(x))).get() == Lazy.of(identity(0)).get()
    assert Lazy.of(0).bind(lambda x: Lazy.of(identity(x))).get() == Lazy.of(identity).ap(Lazy.of(0)).get()
    assert Lazy.of(mult).bind(Lazy.of(lambda x: x(3, 4))).get() == mult(3, 4)
    assert Lazy.of(mult).bind(Lazy.of(lambda x: x(3, 4))).get() == Lazy.of

# Generated at 2022-06-12 05:17:04.967323
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Function tests if two Lazy equals

    :returns: None
    """
    from pymonet.maybe import Maybe

    def fn(a: int) -> Maybe[str]:
        return Maybe.just(str(a))

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)
    lazy_3 = lazy_1.map(lambda s: s + '!')

    assert lazy_1 == lazy_2
    assert lazy_1 != lazy_3
    assert lazy_2 != lazy_3


# Unit tests for method of of class Lazy

# Generated at 2022-06-12 05:17:11.386343
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn_5() -> int:
        return 5

    lazy = Lazy(fn_5)
    assert lazy.get() == 5

    def fn_1_2(arg_1: int, arg_2: int) -> int:
        return arg_1 + arg_2

    lazy = Lazy(fn_1_2)
    assert lazy.get(1, 2) == 3



# Generated at 2022-06-12 05:17:18.462221
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Left

    def add(x):
        return x + 5

    def add_with_check(x):
        if x > 5:
            return x + 5
        return Left(ValueError('Given value is less than 5'))

    assert Lazy.of(5).ap(Lazy.of(add)).get() == 10
    assert Lazy.of(5).ap(Lazy.of(add_with_check)).get() == Left(ValueError('Given value is less than 5'))
    assert Lazy.of(10).ap(Lazy.of(add_with_check)).get() == 15

# Generated at 2022-06-12 05:17:26.343364
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Unit test for method map of class Lazy
    """
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 5).map(lambda x: x + 5) == Maybe.just(10)
    assert Lazy(lambda: 5).map(lambda x: x + 5).map(lambda x: x ** 2) == Maybe.just(100)
    assert Lazy(lambda: 0).map(lambda x: x + 5) == Maybe.just(5)


# Generated at 2022-06-12 05:17:33.114782
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy(lambda *args: 1) != Lazy(lambda *args: 2)
    assert Lazy(lambda *args: 1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy(lambda *args: 1)
    assert Lazy(lambda *args: 1) != Lazy(lambda *args: 1)
    assert not Lazy.of(1) == 1


# Generated at 2022-06-12 05:17:50.547187
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda value: value + 1).ap(Lazy(lambda: 1)) == Lazy(lambda: 2)
    assert Lazy.of(lambda value: value + 1).ap(Lazy(lambda: 1)) == Lazy(lambda: 2)

    def add2(value):
        return value + 2

    assert Lazy(lambda: add2).ap(Lazy.of(1)) == Lazy(lambda: 3)
    assert Lazy(lambda: add2).ap(Lazy.of(1)) == Lazy(lambda: 3)
    assert Lazy.of(lambda value: value + 1).ap(Lazy.of(1)) == Lazy(lambda: 2)
    assert Lazy.of(lambda value: value + 1).ap(Lazy.of(1)) == Lazy(lambda: 2)
   

# Generated at 2022-06-12 05:17:55.578801
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    # Setup
    value = 'test-val'
    lazy = Lazy.of(value)
    fn = lambda x: Lazy.of(x)

    # Exercise
    result = lazy.bind(fn)

    # Verify
    assert result.get() == value

    # Cleanup - none needed



# Generated at 2022-06-12 05:18:01.052375
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 'value').get() == 'value'

    assert Lazy(lambda x: x + 1).get(1) == 2
    assert Lazy(lambda x, y: x + y).get(1, 2) == 3
    assert Lazy(lambda x, y, z: x + y + z).get(1, 2, 3) == 6


# Generated at 2022-06-12 05:18:09.332185
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Lazy get unit tests
    """

    # Test Lazy of with value
    lazy: Lazy[int, int] = Lazy.of(1)
    assert lazy.get() == 1

    # Test Lazy with function and args
    def double_fn(val):
        return val * 2

    lazy = Lazy(double_fn)
    assert lazy.get(2) == 4

    # Test Lazy with function and multiple args
    def sum_fn(val1, val2):
        return val1 + val2

    lazy = Lazy(sum_fn)
    assert lazy.get(2, 4) == 6

    # Test empty Lazy on get
    lazy = Lazy(lambda: ())
    assert lazy.get() is ()



# Generated at 2022-06-12 05:18:16.968351
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test creation and using of Lazy with bind operator

    :returns: True if test is successfully
    :rtype: bool
    """
    def mapper(arg):
        return arg + 1

    def wrapper(arg):
        def inner(*args):
            return arg

        return Lazy(inner)

    lazy = Lazy(mapper)
    assert lazy.bind(wrapper).get(1) == 2
    assert lazy.bind(wrapper).get() == 1
    assert lazy.bind(wrapper).get(arg=1) == 2

    return True

# Generated at 2022-06-12 05:18:19.564658
# Unit test for method get of class Lazy
def test_Lazy_get(): # pragma: no cover
    lazy = Lazy(lambda x: x)
    assert lazy.get() == lazy.value



# Generated at 2022-06-12 05:18:25.950953
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x * 2)).get() == 2
    assert Lazy.of(2).bind(lambda x: Lazy.of(x * 3)).get() == 6
    assert Lazy.of(3).bind(lambda x: Lazy.of(x * 4)).get() == 12
    assert Lazy.of(4).bind(lambda x: Lazy.of(x * 5)).get() == 20



# Generated at 2022-06-12 05:18:29.488281
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    test_lazy = Lazy(lambda x: x + 1)
    applied_lazy = Lazy(lambda x: x * 2).ap(test_lazy)
    assert Lazy.of(6) == applied_lazy.bind(lambda x: Lazy.of(x))

# Generated at 2022-06-12 05:18:33.557290
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def constructor_fn_1(value):
        return value + 10

    def constructor_fn_2(value):
        return value - 10

    lazy_1 = Lazy(constructor_fn_1)
    lazy_2 = Lazy(constructor_fn_2)

    assert lazy_1.ap(lazy_2).get(3) == 4

# Generated at 2022-06-12 05:18:36.469243
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import operator

    def add(a, b): return a + b
    add_lazy = Lazy.of(add)
    add_lazy_2 = add_lazy.ap(Lazy.of(2))
    add_lazy_2_3 = add_lazy_2.ap(Lazy.of(3))
    assert add_lazy.get() == add
    assert add_lazy_2.get() == operator.add
    assert add_lazy_2_3.get() == 5


# Generated at 2022-06-12 05:18:59.186437
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    # Declare example function
    def fn(value):
        return value * 2

    # Declare example Lazy
    lazy = Lazy(lambda: 3)

    # Call bind method with example Lazy and function
    result = lazy.bind(lambda value: Lazy.of(fn(value)))

    # See result of previous method
    assert result.get() == 6


# Generated at 2022-06-12 05:19:02.323790
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe

    lazy_inc = Lazy(lambda x: x + 1)
    assert lazy_inc.bind(lambda x: Maybe.just(x + 10)).get(1) == 12

    assert lazy_inc.bind(lambda x: Maybe.nothing()).to_maybe(1) == Maybe.nothing()



# Generated at 2022-06-12 05:19:06.465444
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(x: int) -> int:
        return x + 1

    lazy_add = Lazy(lambda x: add(x + 1))

    assert lazy_add.get(2) == 4

# Generated at 2022-06-12 05:19:12.020815
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    fn = lambda x: x
    l1 = Lazy(fn)
    l2 = Lazy(fn)
    l3 = Lazy(lambda x: x)
    l4 = Lazy(lambda x: x)

    assert l1 == l2
    assert not l1 == l3
    assert not l3 == l4



# Generated at 2022-06-12 05:19:20.820209
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Given
    from pymonet.monad import identity_monad
    from pymonet.validation import Validation
    from pymonet.validation import Validation, validation_monad
    from pymonet.validation import Validation, ValidationFailure, ValidationSuccess

    # When
    result1 = Lazy(lambda x: 1)\
        .bind(lambda x: Lazy(lambda _: x + x))\
        .bind(lambda x: Lazy(lambda _: x + x))

    result2 = Lazy(lambda x: 1)\
        .bind(lambda x: Lazy(lambda _: x + x))\
        .bind(validation_monad.of)\
        .bind(lambda x: Validation.of(x + x))

    result3 = Lazy(lambda x: 1)\
        .bind

# Generated at 2022-06-12 05:19:24.833191
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box

    box = Box(1)
    assert Lazy.of('Lazy content').get() == 'Lazy content'
    assert Lazy(lambda x: x.get()).get(box) == 1



# Generated at 2022-06-12 05:19:34.025972
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(_):
        return 'a'

    def g(_):
        return 'b'

    lazy_a = Lazy(f)
    lazy_a.is_evaluated = True
    lazy_a.value = 'b'

    lazy_b = Lazy(f)
    lazy_b.is_evaluated = True
    lazy_b.value = 'b'

    lazy_c = Lazy(g)
    lazy_c.is_evaluated = True
    lazy_c.value = 'b'

    assert lazy_a == lazy_b
    assert lazy_a != lazy_c
    assert lazy_b != lazy_c



# Generated at 2022-06-12 05:19:35.435707
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) != Lazy.of(2)

# Generated at 2022-06-12 05:19:42.980318
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    class Result:
        pass

    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(3)

    def fn(x):  # pragma: no cover
        def plus_one(y):
            return y + 1
        return plus_one(x)

    assert Lazy.of(1).bind(fn) == Lazy.of(2)
    assert Lazy.of(1).bind(fn).bind(fn) == Lazy.of(3)


# Generated at 2022-06-12 05:19:52.146236
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def add1(prev_value):
        return prev_value + 1

    def mul5(prev_value):
        return prev_value * 5

    def square(prev_value):
        return prev_value * prev_value

    lazy = Lazy.of(1)
    assert lazy.bind(add1).bind(add1).bind(square).bind(mul5).get() == 200
    assert lazy.bind(square).bind(square).bind(square).bind(mul5).get() == 12500000000

# Generated at 2022-06-12 05:20:33.095341
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(i):
        return i + 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda i: i + 2)
    assert Lazy(fn) != Lazy(fn).map(lambda i: i + 1)
    assert Lazy(fn) != 1

# Generated at 2022-06-12 05:20:37.535630
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__(): # type: ignore
    assert Lazy.of('first').map(lambda value: 'second') == Lazy.of('second')
    assert not Lazy.of('first') == Lazy.of('second')
    assert Lazy.of('first').map(lambda value: 'second') != Lazy.of('first')
    assert not Lazy.of(None) == Lazy.of(None)

# Generated at 2022-06-12 05:20:43.940150
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f():
        return 'a'

    def g():
        return 'b'

    lazy1 = Lazy(f)
    lazy2 = Lazy(f)
    lazy3 = Lazy(g)

    assert lazy1 == lazy1
    assert lazy1 == lazy2
    assert lazy1 != lazy3



# Generated at 2022-06-12 05:20:48.477621
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    test Lazy bind method.

    :returns: None
    :rtype: None
    """
    def lazy_mapper(value: int) -> int:
        return Lazy(lambda: value * 2)

    assert Lazy.of(6).bind(lazy_mapper).get() == 12



# Generated at 2022-06-12 05:21:00.267240
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.either import Left
    from pymonet.maybe import Maybe

    def fn(*args):
        return Left(args)

    lazy_a = Lazy(fn)
    lazy_b = Lazy(fn)

    assert lazy_a == lazy_b

    lazy_a = Maybe.from_bool(True).to_lazy().map(lambda _: Lazy(fn)).get()
    lazy_b = Maybe.from_bool(True).to_lazy().map(lambda _: Lazy(fn)).get()

    assert lazy_a == lazy_b

    lazy_a = Maybe.from_bool(False).to_lazy().map(lambda _: Lazy(fn)).get()
    lazy_b = Maybe.from_bool(False).to_lazy().map(lambda _: Lazy(fn)).get()