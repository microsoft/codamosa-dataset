

# Generated at 2022-06-12 05:11:09.373622
# Unit test for method map of class Lazy
def test_Lazy_map():
    from . import add

    x = Lazy.of(1).map(add(1)).map(add(2))
    assert x.get() == 4, 'add(1).map(add(2))'

    y = Lazy.of(1).map(lambda _: None).map(add(1))
    assert y.get() is None, 'None.map(add(1))'

    z = Lazy.of(1).map(add(1)).map(lambda _: None)
    assert z.get() is None, 'add(1).map(_ => None)'

    w = Lazy.of(1).map(add(1))
    assert w.get() == 2, 'add(1)'
#___________________________________________________#


# Generated at 2022-06-12 05:11:19.898492
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    test_cases = [
        {
            'input_lazy': Lazy(lambda: 1),
            'input_other': 2,
            'expected': False
        },
        {
            'input_lazy': Lazy(lambda: 2),
            'input_other': Lazy(lambda: 2),
            'expected': True
        },
        {
            'input_lazy': Lazy(lambda: 2),
            'input_other': Lazy(lambda: 3),
            'expected': False
        }
    ]

    for test_case in test_cases:
        result = test_case['input_lazy'] == test_case['input_other']
        assert result is test_case['expected']



# Generated at 2022-06-12 05:11:29.316603
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def func():
        return 10

    assert Lazy(func) == Lazy(func)
    assert Lazy(func) != Lazy(lambda: 20)
    assert Lazy(func) != Lazy(func).map(lambda x: x + 20)
    assert Lazy(func) != Lazy(func).map(lambda x: x + 10)
    assert Lazy(func) != Lazy(func).ap(Lazy(lambda x: x + 20))
    assert Lazy(func) != Lazy(func).ap(Lazy(lambda x: x + 10))



# Generated at 2022-06-12 05:11:34.946195
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # type: ignore
    @Lazy
    def add(x, y):
        return x + y

    @Lazy
    def add2(x, y):
        return x + y

    assert add2 == add

    add3 = add.map(lambda x: x / 2)

    assert add3 != add
    assert add2 != add3



# Generated at 2022-06-12 05:11:39.004925
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1), "Lazy should be equal"
    assert Lazy(lambda: 1) != 1, "Lazy should not be equal"
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 2), "Lazy should be equal"



# Generated at 2022-06-12 05:11:44.219126
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.function import Function

    lazy = Lazy(Function.identity)
    assert lazy == Lazy(Function.identity)
    assert lazy != Lazy(lambda x: x)
    assert lazy != Lazy.of(1)


# Generated at 2022-06-12 05:11:51.931842
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = Lazy(lambda: 1)
    f2 = Lazy(lambda: 1)
    g = f.map(lambda x: x + 1)
    g2 = f2.map(lambda x: x + 1)
    g3 = g.map(lambda x: x + 3)
    g4 = g2.map(lambda x: x + 3)
    assert f == f2
    assert g == g2
    assert g3 == g4


# Generated at 2022-06-12 05:11:55.940578
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    lazy_value = Lazy.of(10)
    lazy_result = lazy_value.bind(Lazy.of)
    assert lazy_result == Lazy.of(10)
    assert lazy_result.is_evaluated == False



# Generated at 2022-06-12 05:11:57.651506
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 10).get() == 10


# Generated at 2022-06-12 05:12:00.275850
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def func():
        return 42

    lazy = Lazy(func)
    other_lazy = Lazy(func)
    assert lazy == other_lazy


# Generated at 2022-06-12 05:12:08.700976
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(42).__eq__(Lazy.of(42)) is True
    assert Lazy.of(42) == Lazy.of(42) is True
    assert Lazy.of(42) == Lazy.of(43) is False
    assert Lazy.of(42).__eq__(Lazy.of(43)) is False


#Unit tests for methods of class Lazy

# Generated at 2022-06-12 05:12:13.309288
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(5) == Lazy(lambda x: 5)
    assert Lazy.of(1) == Lazy(lambda x: 1)
    assert Lazy.of(1).bind(lambda x: Lazy.of(None)) == Lazy(lambda x: None)


# Generated at 2022-06-12 05:12:23.219278
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def function_to_apply_lazy(x):
        return x + 2
    def function_to_apply_empty_lazy():
        return None

    # notempty Lazy
    assert (Lazy.of(2).ap(Lazy.of(function_to_apply_lazy)) == Lazy.of(4))
    # empty Lazy
    assert (Lazy.of(None).ap(Lazy.of(function_to_apply_lazy)) == Lazy.of(None))
    # notempty Lazy with empty Lazy
    assert (Lazy.of(2).ap(Lazy.of(function_to_apply_empty_lazy)) == Lazy.of(2))



# Generated at 2022-06-12 05:12:29.826693
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_maybe import Maybe

    def test_fn(a):
        return a + 1

    lazy = Lazy.of(10)
    maybe = Maybe.just(test_fn)
    result = lazy.ap(maybe)
    assert result.get() == 11

    maybe2 = Maybe.just(lambda x: x + 1)
    result2 = lazy.ap(maybe2)
    assert result2.get() == 11

# Generated at 2022-06-12 05:12:32.774615
# Unit test for method map of class Lazy
def test_Lazy_map():
    increment = lambda x: x + 1
    lazy = Lazy(lambda x: x).map(lambda x: x + 1)
    actual = lazy.get(2)

    assert increment(2) == actual



# Generated at 2022-06-12 05:12:37.070218
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    # Arrange
    def fn(*args):
        return 42
    lazy = Lazy(fn)

    # Act
    result = lazy.get()

    # Assert
    assert 42 == result
    assert lazy.is_evaluated
    assert 42 == lazy.value


# Generated at 2022-06-12 05:12:44.807825
# Unit test for method get of class Lazy
def test_Lazy_get():
    empty_lazy = Lazy(lambda: 5)
    assert empty_lazy.get() == 5
    assert empty_lazy.is_evaluated
    assert empty_lazy.to_maybe().is_something()
    assert empty_lazy.to_maybe().get_or_else(None) == 5

    empty_lazy = Lazy(lambda: 'five')
    assert empty_lazy.get() == 'five'
    assert empty_lazy.to_maybe().is_something()
    assert empty_lazy.to_maybe().get_or_else(None) == 'five'

    empty_lazy = Lazy(lambda: None)
    assert empty_lazy.get() == None
    assert empty_lazy.to_maybe().is_something()
    assert empty_lazy.to_maybe().get

# Generated at 2022-06-12 05:12:49.143065
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    ap :: Applicative f => f (a -> b) -> f a -> f b

    Test of method ap of class Lazy.
    """
    def square(x):
        return x ** 2

    def add(x):
        return x + 10

    lazy_square = Lazy(square)
    lazy_add = Lazy(add)

    added_squared = lazy_square.ap(lazy_add)
    assert added_squared.get(2) == square(add(2))
    assert added_squared.get(2) == 14

    # For this case should be type error but we works with dynamic python


# Generated at 2022-06-12 05:12:52.556228
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda i: Lazy.of(i * 2)).get() == 2
    assert Lazy.of(2).bind(lambda i: Lazy.of(i * 2)).get() == 4


# Generated at 2022-06-12 05:12:56.139727
# Unit test for method get of class Lazy
def test_Lazy_get():
    result = Lazy(lambda x: x + 1).get(1)
    assert result == 2
    result = Lazy(lambda: 1).get()
    assert result == 1


# Generated at 2022-06-12 05:13:03.639685
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_constructor():
        return 5

    lazy_1 = Lazy(test_constructor)
    lazy_2 = Lazy(test_constructor)
    assert lazy_1 == lazy_2
    assert not (lazy_1 == None)
    assert not (lazy_1 == (1, 2))

    assert lazy_1 != None
    assert lazy_1 != (1, 2)


# Generated at 2022-06-12 05:13:11.226938
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    fn = Lazy.of(lambda a: a + 1)

# Generated at 2022-06-12 05:13:19.379401
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from collections.abc import Callable

    Lazy.of(42) == Lazy.of(42)
    Lazy.of(None) == Lazy.of(None)
    Lazy.of(Callable) == Lazy.of(Callable)
    assert not (Lazy.of(42) == Lazy.of(None))
    assert not (Lazy.of(None) == Lazy.of(42))
    assert not (Lazy.of(Callable) == Lazy.of(42))

# Generated at 2022-06-12 05:13:25.635305
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def foo_fn():
        return 1

    lazy_1 = Lazy.of(foo_fn)
    lazy_2 = Lazy.of(foo_fn)

    assert lazy_1 == lazy_2

    lazy_3 = lazy_1.map(lambda fn: fn())
    lazy_4 = lazy_2.map(lambda fn: fn())

    assert lazy_3 == lazy_4



# Generated at 2022-06-12 05:13:30.147840
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1(_: object) -> Lazy[object, object]:
        return Lazy.of(1)

    def fn2(_: object) -> Lazy[object, object]:
        return Lazy.of(2)

    lazy1 = Lazy(fn1)
    lazy2 = Lazy(fn2)

    assert lazy1 != None
    assert lazy1 == Lazy(fn1)
    assert lazy1 != lazy2

# Generated at 2022-06-12 05:13:39.132777
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def a():
        return 10

    def b():
        return 20

    a1 = Lazy.of(1)
    a2 = Lazy.of(2)
    b1 = Lazy(a).map(lambda x: x * 2)
    b2 = Lazy(b).map(lambda x: x * 2)

    assert a1 == a1
    assert a1 != a2
    assert b1 == b1
    assert b1 != b2

    a3 = Lazy(a).map(lambda x: x * 2)
    a3._compute_value()

    assert a3 == b1

# Generated at 2022-06-12 05:13:50.671705
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.fn import F
    from pymonet.functor import Functor

    assert Lazy.of('a').__eq__(Lazy.of('a'))
    assert Lazy.of('a').map(F(lambda x: x + 'b')).__eq__(Lazy.of('a').map(F(lambda x: x + 'b')))
    assert Lazy.of('a').map(F(lambda x: x + 'b')).__eq__(Lazy.of('a').map(F(lambda x: x + 'b')).to_box())
    assert not Lazy.of('a').__eq__(Lazy.of('b'))
    assert not Lazy.of('a').__eq__(Functor.of('a'))
    assert not L

# Generated at 2022-06-12 05:13:56.495065
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.either import Left

    def head(lst):
        return lst[0]

    def to_string(s):
        return str(s)
    f = Lazy(lambda: [1, 2, 3])
    actual = f.map(head).map(to_string).get()
    expected = '1'

    assert actual == expected

    f = Lazy(lambda: Left('error'))
    actual = f.map(head).to_either()
    assert actual.is_left()

    f = Lazy(lambda: [])
    actual = f.map(head).to_either()
    assert actual.is_left()



# Generated at 2022-06-12 05:14:05.830758
# Unit test for method bind of class Lazy
def test_Lazy_bind(): # pragma: no cover
    from pymonet.functions import compose
    from pymonet.box import Box

    add_lazy = Lazy(lambda x: x + 1)
    multiply_by_three = compose(lambda x: x * 3, add_lazy.get)
    multiply_by_five = compose(lambda x: x * 5, add_lazy.get)
    multiply_by_five_lazy = Lazy(multiply_by_five)

    assert multiply_by_five_lazy.bind(lambda x: Lazy(lambda y: x + y)).get(42) == 42 * 3 + 42 * 5 == 210
    assert add_lazy.bind(lambda x: multiply_by_five_lazy).get(42) == 42 * 3 + 43 * 5 == 245
    assert add_lazy.bind

# Generated at 2022-06-12 05:14:17.987723
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def test_case_equal(lazy1: Lazy, lazy2: Lazy):
        assert lazy1 == lazy2

    def test_case_not_equal(lazy1: Lazy, lazy2: Lazy):
        assert lazy1 != lazy2

    first_test_case = (Lazy(lambda: 1), Lazy(lambda: 1))
    second_test_case = (Lazy(lambda: 1), Lazy(lambda: 2))
    third_test_case = (Lazy(lambda: 1), Lazy(lambda: 1 + 1))
    test_cases = [first_test_case, second_test_case, third_test_case]
    test_cases_expecting_true = test_cases[:1]
    test_cases_expecting_false = test_cases[1:]

# Generated at 2022-06-12 05:14:26.615869
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    def fn(x):
        return x[0]

    def fn_1(x):
        return x[1]

    def fn_2(x):
        return x[2]

    lazy = Lazy(fn).ap(Lazy(fn_1)).ap(Lazy(fn_2))
    assert lazy.get([10, 20, 30]) == 30

# Generated at 2022-06-12 05:14:31.220914
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(2).map(str) == Lazy.of(2).map(str)
    assert Lazy.of(2) != Lazy.of("2")
    assert Lazy.of(2).map(str) != Lazy.of("2").map(str)


# Generated at 2022-06-12 05:14:35.247133
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.list import List

    def sum_list(list_of_numbers: List[int]) -> int:
        return list_of_numbers.fold(0, operator.add)

    functor = Lazy(lambda: List([1, 2, 3]))
    result = functor.bind(sum_list)

    assert result.get() == 6

# Generated at 2022-06-12 05:14:44.128938
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Left, Right

    def get_string():
        return 'a string'

    # String value it's not a lazy so we need to wrap it
    wrapped_true = Lazy(get_string)

    def mapper(value):
        return Lazy(lambda: Left(value))

    assert wrapped_true.bind(mapper).get() == Left(get_string())

    def mapper(value):
        return Lazy(lambda: Right(value))

    assert wrapped_true.bind(mapper).get() == Right(get_string())



# Generated at 2022-06-12 05:14:46.855154
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    called_times = 0
    lazy = Lazy(lambda: called_times).map(lambda x: x + 1)
    lazy_2 = Lazy(lambda: called_times).map(lambda x: x + 1)
    lazy_3 = Lazy(lambda: called_times).map(lambda x: x + 2)

    assert lazy == lazy_2
    assert lazy != lazy_3



# Generated at 2022-06-12 05:14:52.447499
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def return_lazy(x): return Lazy(lambda x: x)

    assert Lazy(lambda: 1).bind(return_lazy).fold(lambda x: x) == 1
    assert Lazy(lambda: 1).bind(return_lazy).get() == 1
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2


# Generated at 2022-06-12 05:14:55.097647
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of("value") == Lazy.of("value")



# Generated at 2022-06-12 05:15:06.235886
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x + 2).map(lambda x: x - 1).get(2) == 3
    assert Lazy(lambda x: x + 2).map(lambda x: x - 1).map(lambda x: x * 3).get(2) == 9
    assert Lazy(lambda x: x + 2).map(lambda x: x - 1).map(lambda x: x * 3).map(lambda x: str(x)).get(2) == '9'

    assert Lazy(None).map(lambda x: x - 1).get(2) == None
    assert Lazy(None).map(lambda x: x - 1).map(lambda x: x * 3).get(2) == None

# Generated at 2022-06-12 05:15:18.275557
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """Test case for method __eq__ of class Lazy."""
    from pymonet.box import Box

    lazy = Lazy(lambda x: Box.of(10))
    assert Lazy(lambda x: Box.of(10)) == lazy
    assert Lazy(lambda x: 10) == Lazy(lambda x: 10)
    assert Lazy(lambda x: 10) == Lazy(lambda x: Box.of(10))

    assert Lazy(lambda x: Box.of(10)) != Lazy(lambda x: 10)
    assert Lazy(lambda x: Box.of(10)) != Lazy(lambda x: Box.of(11))
    assert Lazy(lambda x: 10) != Lazy(lambda x: 11)
    assert Lazy(lambda x: 10).get(10) == 10

# Generated at 2022-06-12 05:15:26.778467
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.functor import Functor

    # SUT
    def fn(x):
        return x * 2

    testee = Lazy(lambda x: x * 2)
    result = testee.map(fn)

    # Assert
    assert Functor(result, testee.map).test()
    assert str(result) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x0000000003065EA0>, value=None, is_evaluated=False]'


# Generated at 2022-06-12 05:15:41.793672
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert (
        Lazy.of(2).bind(lambda x: Lazy.of(x + 2)) ==
        Lazy(lambda: Lazy(lambda: 2).bind(lambda x: Lazy.of(x + 2)).get())
    )

    def test_fn(x):
        return Lazy.of(x + 2)

    assert (
        Lazy.of(2).bind(test_fn) == Lazy(lambda: Lazy(lambda: 2).bind(test_fn).get())
    )

    assert (
        Lazy(lambda: 2).bind(lambda x: Lazy(lambda: x + 2)) ==
        Lazy(lambda: Lazy(lambda: 2).bind(lambda x: Lazy(lambda: x + 2)).get())
    )


# Generated at 2022-06-12 05:15:48.603394
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn).map(lambda x: x + 1) == Lazy(fn).map(lambda x: x + 1)

    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn).map(lambda x: x + 1) != Lazy(fn).map(lambda x: x + 2)



# Generated at 2022-06-12 05:15:55.295862
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_fn():
        pass

    assert Lazy(test_fn) != Lazy(test_fn)
    assert Lazy(test_fn) == Lazy(test_fn)
    assert Lazy(test_fn) != test_fn
    assert Lazy(test_fn) != None
    assert Lazy(test_fn) != 1
    assert Lazy(test_fn) != 'test'
    assert Lazy(test_fn) != [1, 2, 3]
    assert Lazy(test_fn) != {'key': 'value'}

    lazy1 = Lazy(test_fn)
    lazy1._compute_value()
    assert Lazy(test_fn) != lazy1
    assert lazy1 == lazy1
    assert lazy1.get() == lazy1.get()


# Generated at 2022-06-12 05:15:58.477989
# Unit test for method get of class Lazy
def test_Lazy_get():  # type: (...) -> None
    def fn(a):
        return a * 2

    monad = Lazy(fn)
    assert monad.get(2) == 4



# Generated at 2022-06-12 05:16:05.864007
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda y: y))
    assert not Lazy(lambda x: 1).__eq__(Lazy(lambda y: y))
    assert not Lazy(lambda x: 1).__eq__(Lazy(lambda y: y))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda y: 1))
    assert not Lazy(lambda x: 1).__eq__(Lazy(lambda y: y))

# Generated at 2022-06-12 05:16:09.944500
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy(lambda _: 1) != Lazy(lambda _: 2)



# Generated at 2022-06-12 05:16:17.239038
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    def add_one(x: int) -> Try[int]:
        return Try.of_lambda(lambda: x + 1)

    def sub_one(x: int) -> Try[int]:
        return Try.of_lambda(lambda: x - 1)

    def inc(x: int) -> int:
        return x + 1

    def dec(x: int) -> int:
        return x - 1

    def return_two(x) -> int:
        return 2

    def return_three(x) -> int:
        return 3

    assert Try.of(1).bind(add_one).bind(sub_one).get() == 1


# Generated at 2022-06-12 05:16:20.629502
# Unit test for method get of class Lazy
def test_Lazy_get(): # pragma: no cover
    from pymonet.compare import compare

    assert compare(Lazy.of(2).get(), 2)



# Generated at 2022-06-12 05:16:23.621250
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy


    assert Lazy.of(1).ap(Box(lambda x : x + 1)).get() == 2

# Generated at 2022-06-12 05:16:34.402985
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation

    first = Lazy.of(1)
    second = Lazy.of(lambda x: x * 2)

    assert first.ap(second) == Lazy.of(2)
    assert first.ap(Lazy.of(lambda x: Validation.success(x + 1))) == Lazy.of(Validation.success(2))
    assert first.ap(Lazy.of(lambda x: Validation.success(x + 1))).to_validation() == Validation.success(2)
    assert first.ap(Lazy.of(lambda x: Validation.fail(x + 1))) == Lazy.of(Validation.fail(2))
    assert first.ap(Lazy.of(lambda x: Validation.fail(x + 1))).to_validation() == Val

# Generated at 2022-06-12 05:16:42.180235
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(a, b):
        return a + b

    def mul(a, b):
        return a * b

    assert Lazy(add).get(1, 2) == add(1, 2)
    assert Lazy(mul).get(1, 2) == mul(1, 2)


# Generated at 2022-06-12 05:16:44.935620
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x: x + 1).get(6) == 7, 'didn\'t return right value'


# Generated at 2022-06-12 05:16:47.507222
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)


# Generated at 2022-06-12 05:16:57.505073
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    test = Try('test')
    test_eq = Try('test')
    test_another = Try('test2')
    test_none = Try(None)
    lazy_test = Lazy(lambda: test)
    lazy_test_eq = Lazy(lambda: test_eq)
    lazy_test_another = Lazy(lambda: test_another)
    lazy_test_none = Lazy(lambda: test_none)
    assert lazy_test == lazy_test_eq
    assert lazy_test != lazy_test_another
    assert lazy_test != lazy_test_none

# Generated at 2022-06-12 05:17:06.011521
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    class ClassTest:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    def test_fn(a: int, b: int) -> ClassTest:
        return ClassTest(a, b)

    computed_lazy = Lazy(lambda *args: 1).bind(lambda *args: Lazy(lambda *args: ClassTest(*args))).get()

    assert (
        computed_lazy == ClassTest(1, 1)
    ), "Error in Lazy.bind method. Expected computed_lazy == ClassTest(1, 1), but computed_lazy == {}".format(computed_lazy)  # noqa


# Generated at 2022-06-12 05:17:16.455604
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.function import Function
    from pymonet.monad_maybe import Maybe
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    func_1 = Function(add)
    func_2 = Function(add)

    add_lazy = Lazy(func_1)
    add_lazy_2 = Lazy(func_1)
    new_lazy = add_lazy.map(lambda a: a + 2)
    new_lazy_2 = add_lazy.map(lambda a: a + 2)
    maybe_add_lazy = Maybe.just(add_lazy)
    maybe_add_lazy2 = Maybe.just(add_lazy_2)
    validation_add_lazy = Val

# Generated at 2022-06-12 05:17:27.503528
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def number_is_even(num):
        return num % 2 == 0

    def number_is_odd(num):
        return num % 2 != 0


    lazy_even = Lazy(lambda num: number_is_even(num))
    lazy_even_other = Lazy(lambda num: number_is_even(num))
    lazy_odd = Lazy(lambda num: number_is_odd(num))
    lazy_odd_other = Lazy(lambda num: number_is_odd(num))
    assert lazy_even == lazy_even_other
    assert lazy_even != lazy_odd
    assert lazy_odd != lazy_odd_other



# Generated at 2022-06-12 05:17:36.005384
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.validation import Validation

    assert Lazy.of(4).ap(Lazy.of(lambda x: x + 2)) == Lazy.of(6)
    assert Lazy.of(4).ap(Lazy.of(None)) == Lazy.of(None)
    assert Lazy.of(5).ap(Lazy.of(6)) == Lazy.of(6)
    assert Lazy.of(None).ap(Lazy.of('a')) == Lazy.of(None)
    assert Lazy.of(None).ap(Lazy.of(None)) == Lazy.of(None)
    assert Lazy.of(None).ap(Lazy.of(5)) == Lazy.of(5)

# Generated at 2022-06-12 05:17:40.102815
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy(lambda: "foo")
    lazy_of_lazy = lazy.bind(Lazy.of)

    assert lazy_of_lazy.get() == Lazy.of("foo").get()

# Generated at 2022-06-12 05:17:44.743388
# Unit test for method map of class Lazy
def test_Lazy_map():
    value = 'test string'
    to_upper_fn = lambda s: s.upper()

    lazy = Lazy.of(value)
    new_lazy = lazy.map(to_upper_fn)

    assert new_lazy.get() == to_upper_fn(value)



# Generated at 2022-06-12 05:17:55.876394
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)



# Generated at 2022-06-12 05:18:06.087981
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pylint: disable=too-many-locals
    """
    Testing bind method for Lazy on multiply, calculate_percent and calculate_diff functions.

    :returns: None
    :rtype: None
    """
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def multiply(value: int, factor: int) -> int:
        return value * factor

    def calculate_percent(part: int, total: int) -> int:
        return part * 100 / total

    def calculate_diff(value1: int, value2: int) -> int:
        return value1 - value2


# Generated at 2022-06-12 05:18:17.054967
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(val):
        return val

    def g(val):
        return val + 1

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(0) != Lazy.of(1)

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(g)

    assert Lazy(f).map(g) == Lazy(f).map(g)
    assert Lazy(f).map(g) != Lazy(f).map(f)
    assert Lazy(f).map(g) != Lazy(g).map(g)

    assert Lazy(f).ap(Lazy(g)) == Lazy(f).ap(Lazy(g))
    assert Lazy(f).ap(Lazy(g)) != Lazy

# Generated at 2022-06-12 05:18:24.278413
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.either import Right

    def fn1():
        return 1

    lazy_fn1 = Lazy.of(fn1)

    lazy_fn1_box = lazy_fn1.bind(Box)
    assert str(lazy_fn1_box) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(lazy_fn1_box.constructor_fn, None, False)
    assert lazy_fn1_box.get() == Box(1)

    lazy_fn1_either = lazy_fn1.bind(Right)

# Generated at 2022-06-12 05:18:28.374751
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f():
        return 'value'

    lazy1 = Lazy(f)
    lazy2 = Lazy(f)
    lazy3 = Lazy(f).map(lambda x: x + '1')

    assert lazy1 == lazy2
    assert lazy1 is not lazy2
    assert lazy1 != lazy3

# Generated at 2022-06-12 05:18:32.277181
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x: x).get(1) == 1
    assert Lazy(lambda x: x ** 2).get(3) == 9
    assert Lazy(lambda x, y: (x, y)).get(1, 2) == (1, 2)
    assert Lazy(lambda x: 3).get() == 3

# Generated at 2022-06-12 05:18:38.614250
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: None)
    assert Lazy(lambda: None) == Lazy(lambda: None)
    assert Lazy(lambda: None) != Lazy(lambda: 1)
    assert Lazy(lambda: {}) == Lazy(lambda: {})
    assert Lazy(lambda: {}) != Lazy(lambda: [])
    assert Lazy(lambda x: x) == Lazy(lambda x: x)
    assert Lazy(lambda x: x) != Lazy(lambda x: 1)
    assert Lazy(lambda x: x) != 2
    assert Lazy(lambda: None) != None

# Generated at 2022-06-12 05:18:45.204863
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.either import Right
    from pymonet.reader import Reader

    assert Lazy.of(5).get() == 5

    fn = lambda x: x + 1

    assert Lazy.of(5).map(fn).map(fn).get() == 7
    assert Lazy.of(5).map(lambda x: Reader.of(x).map(fn).map(fn)).get() == 7



# Generated at 2022-06-12 05:18:54.262157
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) == True
    assert Lazy(lambda x: 5).__eq__(Lazy(lambda x: x)) == False
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: 5)) == False
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1)) == False
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1)) == False
    assert Lazy(lambda x: x).__eq__(5) == False



# Generated at 2022-06-12 05:18:59.186099
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_eq = Lazy.of(1)
    lazy_eq2 = Lazy.of(1)
    lazy_not_eq = Lazy.of(2)

    assert lazy_eq == lazy_eq2
    assert lazy_eq != lazy_not_eq


# Generated at 2022-06-12 05:19:18.259703
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    def test_function(x):
        return x * 2

    assert Lazy.of(2).ap(Lazy.of(test_function)) == Lazy.of(4)
    assert Lazy.of(2).ap(Box.of(test_function)) == Lazy.of(4)


# Generated at 2022-06-12 05:19:25.918831
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert not Lazy(lambda: 1) == 1
    assert not Lazy(lambda: 1) == Lazy(lambda: 2)
    assert not Lazy(lambda: 1) == Lazy(lambda: 1).map(lambda x: x * 2)

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) == Lazy(lambda: 1).map(lambda x: x)



# Generated at 2022-06-12 05:19:29.667272
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 2).map(lambda n: n * n) == Lazy(lambda: 4)
    assert Lazy(lambda: 2).map(lambda n: n * 2).map(lambda n: n + 3) == Lazy(lambda: 8)
    assert Lazy(lambda: 1).map(lambda n: n * 2).map(lambda n: n + 3).map(lambda n: n * n) == Lazy(lambda: 16)


# Generated at 2022-06-12 05:19:37.595257
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    stub = Lazy.of(40)

    def add_one(i: int) -> int:
        return i + 1

    def multiply_by_two(i: int) -> int:
        return i * 2

    def square(i: int) -> int:
        return i ** 2

    assert stub.bind(add_one).get() == 41
    assert stub.bind(multiply_by_two).bind(add_one).get() == 81
    assert stub.bind(multiply_by_two).bind(add_one).bind(square).get() == 6561



# Generated at 2022-06-12 05:19:38.697803
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 'value').get() == 'value'



# Generated at 2022-06-12 05:19:44.085841
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Lazy(lambda x: Box(x).get()) == Lazy(lambda x: Box(x).get())
    assert Lazy(lambda x: Box(x).get()) != Lazy(lambda x: Maybe.nothing())
    assert Lazy(lambda x: Box(x).get()) != Maybe.just(2)
    assert Lazy(lambda x: Box(x).get()) != []

# Generated at 2022-06-12 05:19:54.273358
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.validation import Validation

    assert(
        Lazy.of(5)
        .map(lambda x: x + 3)
        .bind(lambda x: Lazy.of(x - 3))
        .get()
        ==
        5
    )

    assert(
        Lazy.of(5)
        .map(lambda x: Validation.of([x]))
        .bind(lambda x: Lazy.of(x.to_val(4)))
        .get()
        ==
        4
    )


# Generated at 2022-06-12 05:19:57.901084
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of("abc") == Lazy.of("abc")
    assert Lazy.of(10) == Lazy.of(10)
    assert Lazy.of("abc") != Lazy.of("ab")



# Generated at 2022-06-12 05:20:05.833595
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def f1(val):
        return val + 1

    def f2(val):
        return val * 2

    def f3(val):
        if val == 1:
            raise ValueError("1 is not valid value")

    def f4(val):
        return val[0]

    def f5(val):
        return val[1]

    def f6(val):
        return val[2]

    def f7(val):
        return val[3]

    def f8(val):
        return val[4]



# Generated at 2022-06-12 05:20:12.758846
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for method get of class Lazy
    """
    def lazy_add(arg: int) -> int:
        """
        Lazy function of adding 1 to argument.

        :param arg: number to add
        :type arg: int
        :returns: number + 1
        :rtype: int
        """
        return arg + 1

    result = Lazy(lazy_add).get(2)

    assert result == 3

# Generated at 2022-06-12 05:20:48.233047
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_test_utils import add_one_test

    add_one_test('test__Lazy___eq__', 2, [
        ('lazy', Lazy(add_one)),
        ('clone', Lazy(add_one)),
        ('other', Lazy(lambda x: x + 1))
    ])



# Generated at 2022-06-12 05:20:57.140139
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pytest

    def _test_lazy_fn(value):
        return value

    lazy_value = Lazy(_test_lazy_fn).bind(lambda _: Lazy.of(1))
    assert 1 == lazy_value.get()

    def _test_lazy_fn_raise_exception(value):
        raise Exception('Exception')

    lazy_value = Lazy(_test_lazy_fn_raise_exception)
    with pytest.raises(Exception) as exception:
        lazy_value.get()

    assert 'Exception' == str(exception.value)



# Generated at 2022-06-12 05:21:07.048037
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation
    from pymonet.validation import ValidationError

    def fn(x):
        return x + 1

    def vfn(x):
        return Validation.success(x + 1)

    assert (Lazy.of(1).ap(Lazy.of(fn)) == Lazy.of(2))
    assert (Lazy.of(1).ap(Lazy.of(vfn).to_try()) == Lazy.of(2))
    assert (Lazy.of(1).ap(Lazy.of(vfn).to_try()) != Lazy.of(3))
    assert (Lazy.of(1).ap(Lazy.of(vfn).to_try()) == Lazy.of(2))