

# Generated at 2022-06-12 05:11:04.339132
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_1(x):
        return x + 1
    assert Lazy.of(1).map(add_1).get() == 2



# Generated at 2022-06-12 05:11:05.286957
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 'a').get() == 'a'



# Generated at 2022-06-12 05:11:09.552718
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet import Lazy
    from pymonet.box import Box

    def get_value() -> Lazy[T, U]:
        return Lazy(lambda *args: Box(1))

    assert Lazy.of(1).bind(get_value).get() == 1
    assert Lazy.of(2).bind(get_value).get() == 2


# Generated at 2022-06-12 05:11:14.159285
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    class TestLazy(Lazy[int, int]):
        pass

    test_instance = TestLazy(lambda x: x)
    same_as_test_instance = TestLazy.of(0)
    assert test_instance == same_as_test_instance

    assert not (test_instance == TestLazy(lambda x: x + 1))
    assert not (test_instance == TestLazy.of(1))

    assert not (test_instance == Lazy(lambda x: x))
    assert test_instance != Lazy(lambda x: x)


# Generated at 2022-06-12 05:11:23.000791
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add_multiply(x, y):
        return x + y * 5

    lazy_add_multiply = Lazy(lambda: add_multiply)

    # When ap is called with Lazy with function which takes two arguments
    lazy_example = Lazy.of(1).ap(Lazy(lambda num: lambda x, y: num + x + y))

    # Then result Lazy contains function which takes two arguments
    def expected_fn(x, y):
        return 2 + x + y

    assert lazy_example.constructor_fn == expected_fn

    # And when ap is called with Lazy with function with any arguments
    lazy_example = Lazy.of(5).ap(lazy_add_multiply)

    # Then result Lazy contains function with any arguments
    assert lazy_example.constructor_fn

# Generated at 2022-06-12 05:11:28.657143
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box

    # Prepare
    lazy1 = Box(1).to_lazy()

    # Action
    result = lazy1 == lazy1

    # Assert
    assert result is True, 'AssertionError: Lazy(1) == Lazy(1) should be True'



# Generated at 2022-06-12 05:11:31.559176
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe

    def id(value):
        return value

    assert Maybe.just(1).bind(id) == Maybe.just(1)

# Generated at 2022-06-12 05:11:40.134608
# Unit test for method get of class Lazy
def test_Lazy_get():
    def function_passing_arg_to_constractor(x: int) -> int:
        return x

    lazy = Lazy(lambda x: x)
    assert lazy.get(1) == 1

    lazy = Lazy(function_passing_arg_to_constractor)
    assert lazy.get(1) == 1

    assert False == Lazy(lambda *args: False).get()
    assert None is Lazy(lambda *args: None).get()
    assert list() == Lazy(lambda *args: list()).get()
    assert dict() == Lazy(lambda *args: dict()).get()
    assert set() == Lazy(lambda *args: set()).get()


# Generated at 2022-06-12 05:11:41.896321
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1


# Generated at 2022-06-12 05:11:48.111881
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Maybe

    def constructor_fn(*args):
        return Maybe.just(10)

    lazy = Lazy(constructor_fn)

    assert lazy.map(lambda v: v + 10).get() == Maybe.just(20)


# Generated at 2022-06-12 05:11:54.645415
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def func(value):
        return value + 1

    def func2(value):
        return value + 3

    a = Lazy(func)
    b = Lazy(func)
    c = Lazy(func2)

    assert a == b
    assert a != c
    assert b != c



# Generated at 2022-06-12 05:11:59.998505
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x: x + 2).ap(Lazy(lambda x: x + 2)).get(2) \
        == Lazy(lambda x: x + 2).constructor_fn(Lazy(lambda x: x + 2).constructor_fn(2))

    assert Lazy(lambda: 2).ap(Lazy(lambda _: 3)).get() \
        == Lazy(lambda: 2).constructor_fn(Lazy(lambda _: 3).constructor_fn())

# Generated at 2022-06-12 05:12:09.679690
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    id_fn = lambda x: x
    validate_fn = lambda x: Validation.success(x)
    empty_maybe_fn = lambda x: Maybe.empty()
    assert Lazy(lambda: 1).map(id_fn) == Lazy(lambda: 1), 'should be equal'
    assert Lazy(lambda: 1).map(validate_fn) == Lazy(lambda: Validation.success(1)), 'should be equal'
    assert Lazy(lambda: 1).map(empty_maybe_fn) == Lazy(lambda: Maybe.empty()), 'should be equal'



# Generated at 2022-06-12 05:12:14.617261
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)) == Lazy.of(3)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(None)) == Lazy.of(None)


# Generated at 2022-06-12 05:12:22.655018
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def function_1(*args):
        pass

    def function_2(*args):
        pass

    lazy_1 = Lazy(function_1)
    lazy_2 = Lazy(function_1)

    assert lazy_1 == lazy_2
    lazy_2._compute_value('a')
    assert lazy_1 != lazy_2

    lazy_1._compute_value('b')
    assert lazy_1 == lazy_2

    lazy_2 = Lazy(function_2)
    assert lazy_1 != lazy_2

# Generated at 2022-06-12 05:12:33.708271
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy.of(8).get() == 8

    assert Lazy.of(lambda *args: 8).bind(lambda *args: Lazy.of(8)).get() == 8
    assert Lazy.of(lambda *args: 8).bind(lambda *args: Lazy.of(lambda *args: 8)).get() == 8
    assert Lazy.of(lambda *args: 8).bind(lambda *args: Lazy.of(lambda *args: lambda *args: 8)).get() == 8

    assert Lazy.of(lambda *args: list(args)).bind(lambda *args: Lazy.of(8)).get(8) == 8
    assert Lazy.of(lambda *args: list(args)).bind(lambda *args: Lazy.of(lambda *args: 8)).get(8) == 8

# Generated at 2022-06-12 05:12:35.087039
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x).ap(Lazy.of(lambda y: y)).get()(10) == 10

# Generated at 2022-06-12 05:12:39.000659
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(0).get() == 0
    assert Lazy.of(lambda x: x + 1).get(1) == 2
    assert Lazy.of(2).get(1) == 2



# Generated at 2022-06-12 05:12:46.908983
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functions import id
    from pymonet.test.test_box import test_Box___eq__

    test_Box___eq__(Lazy(str), Lazy(str), Lazy(str))
    assert Lazy(str) != Lazy(id)
    assert Lazy(str) != Lazy(str)("TEST")
    assert Lazy(str) != Lazy.of("TEST")
    assert Lazy.of("TEST") == Lazy.of("TEST")


# Generated at 2022-06-12 05:12:50.825026
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != "Lazy"


# Generated at 2022-06-12 05:12:59.987253
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_function(value):
        def second_function(value):
            return value + 10
        return Lazy(lambda: second_function(value))

    lazy = Lazy(lambda: 2)

    assert lazy.bind(test_function).get() == 12
    assert lazy.bind(test_function).is_evaluated is True
    assert lazy.bind(test_function).get() == 12
    assert lazy.bind(test_function).is_evaluated is True

# Generated at 2022-06-12 05:13:10.108086
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy

    :returns: Nothing
    :rtype: NoReturn
    :raises AssertionError: if test failed
    """
    def square(value):
        return Lazy(lambda: value * value)

    lazy = Lazy.of(2)

    assert lazy.bind(square).get() == 4
    assert lazy.bind(square).is_evaluated

    def add(value):
        def add_internal(value_to_add):
            return Lazy(lambda: value + value_to_add)

        return add_internal

    assert lazy.bind(add(3)).get() == 5
    assert lazy.bind(add(3)).is_evaluated


# Generated at 2022-06-12 05:13:17.094259
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.functor import Functor
    from pymonet.box import Box

    assert isinstance(Lazy.of(lambda x: x).ap(Box(len)), Lazy) == True
    assert Lazy.of(lambda x: x).ap(Box(len)).constructor_fn(
        [1, 2, 3]) == 3
    assert Lazy.of(lambda x: x).ap(Box(len)).constructor_fn(
        [1, 2, 3]) == 3

# Generated at 2022-06-12 05:13:20.351498
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)


# Generated at 2022-06-12 05:13:25.998014
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.idea import Idea

    lazy_idea = Lazy(lambda: Idea(10))

    assert lazy_idea.ap(Lazy(lambda: Idea("the value"))).get() == Idea("the value")
    assert lazy_idea.ap(Lazy(lambda: Idea("the value"))).get() == lazy_idea.constructor_fn()


# Generated at 2022-06-12 05:13:33.053223
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.validation import Validation

    maybe = Maybe.just(lambda x: x + 3)
    lazy_maybe = maybe.to_lazy()
    lazy = Lazy(lambda x: x * 2)
    assert lazy.ap(lazy_maybe).get(2) == 10
    assert lazy_maybe.ap(lazy).get(2) == 8

    box = Box(lambda x: x + 3)
    lazy_box = box.to_lazy()
    assert lazy.ap(lazy_box).get(2) == 10
    assert lazy_box.ap(lazy).get(2) == 8


# Generated at 2022-06-12 05:13:36.573116
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x, y: x + y))

# Generated at 2022-06-12 05:13:39.880236
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(x):
        return Lazy(lambda: x + 10)

    def g(y):
        return Lazy(lambda: y * 2)

    assert Lazy.of(10).bind(f).bind(g).get() == 30
    assert Lazy.of(10).bind(lambda x: Lazy.of(x + 10)).bind(lambda y: Lazy.of(y * 2)).get() == 30


# Generated at 2022-06-12 05:13:42.510183
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda x: x + 1)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2



# Generated at 2022-06-12 05:13:53.803252
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor

    test_functor = Functor[Lazy[int, int]]

    lazy_of_0 = Lazy.of(0)
    assert test_functor.__eq__(lazy_of_0, lazy_of_0, lambda x: x)

    lazy_of_1 = Lazy.of(1)
    assert not test_functor.__eq__(lazy_of_0, lazy_of_1, lambda x: x)

    lazy_fn = Lazy(lambda x: x + 1)
    lazy_fn_copy = Lazy(lambda x: x + 1)
    assert test_functor.__eq__(lazy_fn, lazy_fn_copy, lambda x: x)

    lazy_fn_copy.value
    assert test_functor.__

# Generated at 2022-06-12 05:14:05.788308
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.monoid import SumMonoid, MaxMonoid
    from pymonet.box import Box, Some

    lazy = Lazy.of(lambda x, y: x + y)
    assert lazy.map(lambda x: x + 1)(1, 2) == 4

    maybe = Some(3).to_maybe()
    results = lazy.map(lambda x: x + 1).ap(maybe).fold([])
    assert results == [4]

    maybe = Some(10).to_maybe()
    results = lazy.map(lambda x: x + 1).ap(maybe).fold([])
    assert results == [13]

    maybe = Some(40).to_maybe()

# Generated at 2022-06-12 05:14:08.168968
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_result = Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert lazy_result.get() == 2

# Generated at 2022-06-12 05:14:11.488058
# Unit test for method map of class Lazy
def test_Lazy_map():
    fn = lambda x: x * 2
    x = Lazy(lambda: 2)
    assert x.map(fn).get() == fn(2)



# Generated at 2022-06-12 05:14:21.540824
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__(): #pragma: no cover
    from pymonet.monad_try import Try

    def try_fn(value):
        return Try.of(lambda: value)

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: try_fn(1)) == Lazy(lambda: try_fn(1))
    assert Lazy(lambda: try_fn(1)) != Lazy(lambda: try_fn(2))
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != 2
    assert Lazy(lambda: 1) != 1
    assert Lazy(lambda: 1) != object()



# Generated at 2022-06-12 05:14:31.682727
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add_one(x):
        return x + 1

    lazy_add_one = Lazy.of(add_one)
    lazy_number = Lazy.of(3)

    assert lazy_number.bind(lazy_add_one).get() == 4

    def add_one_to_maybe_box(maybe_box):
        return maybe_box.map(add_one)

    lazy_add_one_to_maybe_box = Lazy.of(add_one_to_maybe_box)
    lazy_maybe_box = Lazy.of(Box(Maybe.just(3)))

    assert lazy_maybe_box.bind(lazy_add_one_to_maybe_box).get() == Box(Maybe.just(4))

# Generated at 2022-06-12 05:14:43.820942
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Given
    class LazyStub(Generic[T]):
        def __init__(self, value: T) -> None:
            self.value = value

        def bind(self, fn):
            return fn(self.value)

        def __eq__(self, other):
            return isinstance(other, LazyStub) and self.value == other.value

    class LazyStubEmpty(Generic[T]):
        def bind(self, fn):
            return self

        def __eq__(self, other):
            return isinstance(other, LazyStubEmpty)

    def assert_lazy_stub(value_to_return, result_stub, args):
        assert LazyStub(value_to_return).bind(lambda _: result_stub).get(*args) == result_stub



# Generated at 2022-06-12 05:14:54.401531
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def min(x, y):
        return x if x < y else y

    def max(x, y):
        return x if x < y else y

    def mean(x, y):
        return (x + y) / 2

    def sqrt(x):
        return x ** 2

    def cube(x):
        return x ** 3

    def to_int(x):
        return int(x)

    add1 = Lazy.of(1).map(cube).map(sqrt).map(to_int)
    add2 = Lazy.of(1).map(sqrt).map(cube).map(to_int)

    expected = Lazy.of(2).map(cube).map(sqrt).map(to_int)

    assert Lazy.of(min).ap(add1).ap(add2)

# Generated at 2022-06-12 05:14:58.696514
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 10).ap(Box(lambda x: x + 2)) == Lazy(lambda: 12)
    assert Lazy(lambda: 10).ap(Maybe.just(lambda x: x + 2)) == Lazy(lambda: 12)



# Generated at 2022-06-12 05:15:10.375293
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    class ClassWithoutInit:
        pass

    class ClassWithoutInit2:
        pass

    def constructor_fn1(*args):
        return ClassWithoutInit(*args)

    def constructor_fn2(arg):
        return ClassWithoutInit2(arg)

    def constructor_fn3(arg):
        return ClassWithoutInit2(arg)

    assert (
        Lazy(constructor_fn1).ap(Lazy(constructor_fn2)) == Lazy(lambda: constructor_fn2(constructor_fn1()))
    )

# Generated at 2022-06-12 05:15:20.579874
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    # pylint: disable=unused-variable,unused-argument,expression-not-assigned,pointless-statement
    def add_one(n):
        return n + 1

    def multiply(n, m):
        return n * m

    def caller():
        return Lazy(lambda: 1)

    def caller_with_argument(y):
        return Lazy(lambda x: x + y)

    def input_args(*args):
        return Lazy(lambda: args)

    @classmethod
    def get_computed_value(cls):
        return Lazy(lambda: 1)

    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2

# Generated at 2022-06-12 05:15:28.377200
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy.of(5).get() == 5
    assert Lazy(lambda: 2 + 3).get() == 5
    assert Lazy(lambda: 2 + 3).map(lambda x: x * 4).get() == 20


# Generated at 2022-06-12 05:15:31.731167
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """Unit test for method __eq__ of class Lazy"""
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(2) != Lazy.of(1)



# Generated at 2022-06-12 05:15:37.286552
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    returned_lazy = Lazy(lambda x: x + x).ap(Lazy(lambda x: x * x))
    assert returned_lazy.value == None
    assert returned_lazy.is_evaluated == False
    assert returned_lazy.constructor_fn(4) == 32
    assert returned_lazy.is_evaluated == True
    assert returned_lazy.value == 32


# Generated at 2022-06-12 05:15:49.121012
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.either import Right

    assert Lazy.of(lambda x: x + 1).ap(Maybe.just(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x.get() + 1).ap(Maybe.just(Lazy.of(1))) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Validation.success(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x.get() + 1).ap(Validation.success(Lazy.of(1))) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Right(1)) == Lazy.of

# Generated at 2022-06-12 05:15:52.008493
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.functor import identity

    assert Lazy.of(identity).__eq__(Lazy.of(identity)) is True



# Generated at 2022-06-12 05:15:55.412731
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Given
    lazy_int = Lazy(lambda arg: arg + 1)
    lazy_string = Lazy(lambda arg: arg + '1')
    lazy_dict = Lazy(lambda arg: {'key': arg})

    # When
    # Then
    assert lazy_int.get(1) == 2
    assert lazy_string.get('1') == '11'
    assert lazy_dict.get('value') == {'key': 'value'}



# Generated at 2022-06-12 05:16:01.269944
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(2).ap(Lazy.of(lambda x: x + 1)) == Lazy.of(3)
    assert Lazy(lambda x: x + 1).map(lambda x: x + 2).ap(Lazy.of(3)) == Lazy.of(6)
    assert Lazy.of(2).ap(Lazy(lambda x: x + 1)) == Lazy.of(3)


# Generated at 2022-06-12 05:16:06.982361
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda a: a + 1).bind(lambda a: Lazy.of(a + 1)).get(1) == 3
    assert Lazy(lambda *args: 1).bind(lambda a: Lazy(lambda *args: a + 1)).get(1) == 2
    assert Lazy(lambda *args: 1).bind(lambda a: Lazy.of(a + 1)).get(1) == 2


# Generated at 2022-06-12 05:16:10.073598
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def fn(x):
        return Lazy(lambda: x + 10)

    assert Lazy.of(42).bind(fn).get() == 52

# Generated at 2022-06-12 05:16:17.238940
# Unit test for method map of class Lazy
def test_Lazy_map():
    def fn_a(*args):
        return ''.join(args)

    lazy = Lazy(fn_a)
    assert isinstance(lazy, Lazy)
    assert callable(lazy.constructor_fn)
    assert lazy.constructor_fn == fn_a
    assert lazy.is_evaluated is False
    assert lazy.value is None

    def fn_b(value):
        return value + 'x'

    mapped = lazy.map(fn_b)
    assert isinstance(mapped, Lazy)
    assert callable(mapped.constructor_fn)
    assert lazy.constructor_fn == fn_a
    assert lazy.value == None
    assert lazy.is_evaluated is False
    assert mapped.constructor_fn == fn_b
    assert mapped.value == None

# Generated at 2022-06-12 05:16:24.994284
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy((lambda: 3)).get() == 3
    assert Lazy((lambda x: x)).get(3) == 3
    assert Lazy((lambda x, y: x + y)).get(3, 6) == 9


# Generated at 2022-06-12 05:16:31.446313
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy = Lazy(lambda x: x + 1)
    assert lazy.map(lambda x: x * 2) == Lazy(lambda x: x * 2 + 2)
    assert lazy.map(lambda x: x * 2).get(5) == 12
    assert lazy.map(lambda x: x * 2).is_evaluated is True



# Generated at 2022-06-12 05:16:35.807462
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    x = Lazy(lambda _: 10).bind(lambda _: Lazy(lambda _: 20)).get()
    assert(x == 20)


# Generated at 2022-06-12 05:16:42.349929
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x) == Lazy(lambda x: x)
    assert Lazy(lambda x: x) == Lazy.of(1)
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) == Lazy.of(2)
    assert not Lazy.of(1) == Lazy.of(2)
    assert not Lazy.of(1) != Lazy.of(1)


# Generated at 2022-06-12 05:16:45.912404
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn_to_call(*args):
        return Lazy(lambda *args: args[0])

    assert Lazy(fn_to_call).bind(fn_to_call).get('test') == 'test'

# Generated at 2022-06-12 05:16:50.852062
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def echo(value: str) -> str:
        return value

    lazy_fn = Lazy(lambda *args: echo(args[0]))
    assert Lazy.of(echo) == lazy_fn
    assert Lazy.of(echo) != Lazy(lambda *args: lambda value: value)


# Generated at 2022-06-12 05:16:54.960846
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """ Lazy mapper test """
    def bound_function(input_value):
        return Lazy.of(input_value + 1)

    lazy = Lazy.of(1)
    lazy = lazy.bind(bound_function)

    assert lazy.get() == 2


# Generated at 2022-06-12 05:16:57.504112
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy.of(10)
    assert lazy.get() == 10


# Generated at 2022-06-12 05:17:02.667366
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test_function(value):
        return value + 1

        # creates Lazy with function returning 2

    monad = Lazy.of(1)

    # function will call only during call of monad fold method (or bind method)

    assert monad.map(test_function).get() == 2
    assert monad.map(test_function).map(test_function).get() == 3



# Generated at 2022-06-12 05:17:05.999349
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(2) == 1



# Generated at 2022-06-12 05:17:16.267144
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x + 1).bind(Lazy.of).get(1) == 2

# Generated at 2022-06-12 05:17:21.824684
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def mapper(a):
        return a + 5

    assert Lazy.of(5).ap(Lazy.of(mapper)) == Lazy.of(10)
    assert Lazy.of(5).ap(Lazy.of(mapper)).ap(Lazy.of(mapper)) == Lazy.of(15)


# Generated at 2022-06-12 05:17:32.859561
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    cls = Lazy

    # Two Lazy are equals where both are evaluated both have the same value and constructor functions.
    lz1 = cls.of(1)
    lz2 = cls.of(1)
    assert lz1 == lz2

    lz1 = cls.of(1)
    lz2 = cls.of(2)
    assert lz1 != lz2

    lz1 = cls.of(1)
    lz2 = lz1.map(lambda x: x + 1)
    assert lz1 != lz2

    lz1 = cls.of(2)
    lz2 = lz1.map(lambda x: x + 1)
    assert lz1 != lz2

    lz1 = cls.of(1)
    l

# Generated at 2022-06-12 05:17:34.500376
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)) == 3

# Generated at 2022-06-12 05:17:36.618711
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x, y: x + y).get(1, 2) == 3


# Generated at 2022-06-12 05:17:48.154608
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    from pymonet.box import Box
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try, Success, Failure
    from pymonet.validation import Validation, Success as ValidationSuccess, Failure as ValidationFailure

    def add1(x): return x + 1

    def to_box(x): return Box(x)

    def to_right(x): return Right(x)

    def to_left(x): return Left(x)

    def to_just(x): return Maybe.just(x)

    def to_nothing(x): return Maybe.nothing()

    def to_success(x): return Try.success(x)

    def to_failure(x): return Try.failure(x)


# Generated at 2022-06-12 05:17:52.122673
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for method get of class Lazy.
    """
    expected_value = 1

    def get_value(*args):
        return expected_value

    lazy = Lazy(get_value)

    assert lazy.get() == expected_value



# Generated at 2022-06-12 05:18:03.182061
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def test_function(arg1):
        return arg1 * 2

    # Lazy with same constructed functions and values are equal
    assert Lazy(test_function).map(lambda x: x * 3) == Lazy(test_function).map(lambda x: x * 3)

    # Lazy with different constructed functions are not equal
    def test_function2(arg1):
        return arg1 * 3

    assert Lazy(test_function).map(lambda x: x * 3) != Lazy(test_function2).map(lambda x: x * 3)

    # Lazy with different values are not equal
    assert Lazy(test_function).map(lambda x: x * 2) != Lazy(test_function).map(lambda x: x * 3)

    # Lazy with unevaluated functions are not equal

# Generated at 2022-06-12 05:18:07.119861
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1

    assert Lazy(lambda: 1).get() == 1 # pragma: no cover
    assert Lazy(lambda: 'a').get() == 'a' # pragma: no cover
    assert Lazy(lambda: [1]).get() == [1] # pragma: no cover


# Generated at 2022-06-12 05:18:17.982090
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for bind method
    """

    def lazy_fn_factory() -> Lazy[int, str]:
        """
        Build new Lazy with lambda function, which convert int to str.
        This function is not called during building Lazy.

        :returns: Lazy with lambda function converting int to str.
        :rtype: Lazy[Function(int) -> str]
        """
        return Lazy(lambda number: str(number))


# Generated at 2022-06-12 05:18:42.864978
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def __val():
        pass

    def __val2():
        pass

    def __val3():
        pass

    def __val4():
        pass

    assert Lazy.of(1) == Lazy.of(1)

    lazy = Lazy(__val)
    lazy2 = Lazy(__val2)

    assert lazy != lazy2

    assert Lazy(__val) != Lazy(__val2)
    assert Lazy(__val) == Lazy(__val)
    assert Lazy(__val2) == Lazy(__val2)

    assert Lazy(__val2) != Lazy(__val3)
    lazy.bind(lambda v: Lazy(__val2) if v == 4 else Lazy(__val3))

# Generated at 2022-06-12 05:18:51.138581
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    def function_1():  # pragma: no cover
        return 1

    def function_2():  # pragma: no cover
        return 1

    assert Lazy(function_1) != Lazy(function_2)
    assert Lazy(function_1) == Lazy(function_1)

    assert Try.of(function_1) != Try.of(function_2)
    assert Try.of(function_1) == Try.of(function_1)



# Generated at 2022-06-12 05:18:53.659595
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda: 100)

    assert lazy.get() == 100
    assert lazy.is_evaluated
    assert lazy.value == 100


# Generated at 2022-06-12 05:19:01.592797
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_maybe import Maybe

    def bind_fn(a: object) -> 'Lazy[object, str]':
        def lambda_fn(*args):
            return 'bind_fn: {}'.format(a)

        return Lazy(lambda_fn)

    lazy_a = Lazy(lambda *args: 'a')
    test_maybe = Maybe.just(None).to_lazy().bind(bind_fn)
    assert lazy_a.bind(bind_fn) == test_maybe



# Generated at 2022-06-12 05:19:03.754379
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).get(1) == 2


# Generated at 2022-06-12 05:19:11.766544
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    lazy = Lazy.of(20)
    assert lazy.get() == 20

    lazy = Lazy.of(lambda: 20)
    assert lazy.get() == 20

    lazy = Lazy.of(lambda item: item + 10)
    assert lazy.get(100) == 110
    assert lazy.get(200) == 210

    assert lazy.get(100) == 110
    assert lazy.get(200) == 210


# Generated at 2022-06-12 05:19:17.263826
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = lambda x: x * 2
    g = lambda x: x * 4
    assert Lazy(f).__eq__(Lazy(f)) is True
    assert Lazy(f).__eq__(Lazy(f).map(g)) is False
    assert Lazy(f).__eq__(Lazy(g)) is False
    assert Lazy(f).__eq__(Lazy(g).map(f)) is False



# Generated at 2022-06-12 05:19:22.643770
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def fn1(x):
        def fn2(y):
            return Lazy(lambda: x + y)

        return Lazy.of(fn2)

    assert Lazy(lambda: 2).bind(fn1).get(3) == 5



# Generated at 2022-06-12 05:19:27.746683
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def function(a):
        return a + 10

    lazy = Lazy.of(10).ap(Lazy.of(function))
    assert(lazy.get() == 20)

    lazy = Lazy.of(100).ap(Lazy.of(function))
    assert(lazy.get() == 110)



# Generated at 2022-06-12 05:19:38.067438
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_1 = Lazy(lambda x: x)
    lazy_2 = Lazy(lambda x: x)

    assert not (lazy_1 == lazy_2)
    assert not (lazy_2 == lazy_1)

    assert lazy_1 == lazy_1
    assert lazy_2 == lazy_2

    lazy_1._compute_value(1)
    lazy_2._compute_value(2)
    assert not (lazy_1 == lazy_2)

    lazy_2._compute_value(1)
    assert lazy_1 == lazy_2

    lazy_1.constructor_fn = lambda x: x + 1
    assert not (lazy_1 == lazy_2)

    lazy_2.constructor_fn = lambda x: x + 1
    assert lazy_1 == lazy_2


#

# Generated at 2022-06-12 05:20:24.502924
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_plus_one = Lazy(lambda x: x + 1)
    lazy_plus_two = Lazy(lambda x: x + 2)
    lazy_plus_three = Lazy(lambda x: x + 3)

    assert lazy_plus_one.map(lambda x: x + 10).get(0) == 11
    assert lazy_plus_one.map(lambda x: x + 10) == Lazy(lambda a: a + 11)

    assert lazy_plus_one.map(lambda x: x + 10).map(lambda x: x + 10).get(0) == 21
    assert lazy_plus_one.map(lambda x: x + 10).map(lambda x: x + 10) == Lazy(lambda a: a + 21)


# Generated at 2022-06-12 05:20:35.401734
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 2) == Lazy(lambda: 2)
    assert Lazy(lambda: 2) != Lazy(lambda: 3)
    assert Lazy(lambda: 3) != Lazy(lambda: 2)
    assert Lazy(lambda: [1, 2]) != Lazy(lambda: [2, 1])
    assert Lazy(lambda: [1, 2]) == Lazy(lambda: [1, 2])
    assert Lazy(lambda: {1: 1, 2: 2}) == Lazy(lambda: {1: 1, 2: 2})
    assert Lazy(lambda: {1: 1, 2: 2}) != Lazy(lambda: {2: 2, 1: 1})
    assert Lazy(lambda: {1: 1, 2: 2}) != Lazy(lambda: {1: 1, 2: 3})
   

# Generated at 2022-06-12 05:20:45.752541
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test method get of class Lazy
    """

    # Test with string value
    lazy = Lazy(lambda: 'Test me')
    assert lazy.get() == 'Test me'
    assert lazy.is_evaluated is True

    # Test with int value
    lazy = Lazy(lambda: 666)
    assert lazy.get() == 666
    assert lazy.is_evaluated is True

    # Test with dict value
    lazy = Lazy(lambda: {'key': 'value'})
    assert lazy.get() == {'key': 'value'}
    assert lazy.is_evaluated is True



# Generated at 2022-06-12 05:20:51.554751
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def eval_fn1(x):
        return x

    def eval_fn2(x):
        return x + 1

    lazy1 = Lazy(eval_fn1)
    lazy2 = Lazy(eval_fn2)

    assert lazy1 is not lazy2
    assert lazy1 == Lazy(eval_fn1)
    assert lazy1 != Lazy(eval_fn2)
    assert lazy1 != lazy2

    assert lazy1.bind(lambda x: lazy2) == lazy1.bind(lambda x: lazy2)
    assert lazy1.bind(lambda x: lazy2) != lazy1.bind(lambda x: lazy1)

# Generated at 2022-06-12 05:21:02.157588
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # Given
    class Value(object):
        def __init__(self, value: str) -> None:
            self.value = value

        def __eq__(self, other: object) -> bool:
            return isinstance(other, Value) and self.value == other.value

    def generator(value):
        def fn():
            return value

        return fn

    value = Value('value')
    lazy_1 = Lazy(generator(value))
    lazy_2 = Lazy(generator(value))
    lazy_1.get()

    # When & Then
    assert lazy_1 != lazy_2
    assert lazy_1 == lazy_1

    assert lazy_2 != lazy_1
    assert lazy_2 == lazy_2
