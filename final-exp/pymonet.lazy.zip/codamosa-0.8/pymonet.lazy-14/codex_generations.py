

# Generated at 2022-06-12 05:11:12.183507
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def func(first, second):
        return first + second

    def func_try(first, second):
        return Try.success(first / second)

    def func_validation(first, second):
        return Validation.success(first * second)

    try_item = Try.success(4)
    validation_item = Validation.success(5)
    lazy_item = Lazy(lambda: 6)
    array_item = [7]
    # Lazy and Try
    result = lazy_item.ap(try_item)
    assert isinstance(result, Try)
    assert result.get() == 15
    result = Try.of(func, lazy_item, try_item)

# Generated at 2022-06-12 05:11:22.062257
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.callable.compose import compose

    f = Lazy(lambda x: x)
    g = Lazy(lambda x: x + 1)

    f_and_g = f.ap(g)
    f_and_g2 = g.ap(f)
    compose_f_and_g = compose(g.constructor_fn, f.constructor_fn)
    compose_f_and_g2 = compose(f.constructor_fn, g.constructor_fn)

    assert f_and_g == f_and_g2
    assert f.map(f.constructor_fn) == f
    assert f.map(f_and_g.constructor_fn) != f_and_g
    assert f.map(compose_f_and_g) == f_and_g


# Generated at 2022-06-12 05:11:31.082805
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # test of method ap of class Lazy
    lazy_of_1 = Lazy.of(1)
    lazy_of_2 = Lazy.of(2)
    print("lazy_of_1.ap(lazy_of_2):", lazy_of_1.ap(lazy_of_2))

    lazy_add_function = Lazy.of(lambda x: x + 1)
    print("lazy_of_1.ap(lazy_add_function):", lazy_of_1.ap(lazy_add_function))



# Generated at 2022-06-12 05:11:37.349531
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert False is Lazy.of('value').__eq__(None)
    assert True is Lazy.of('value').__eq__(Lazy.of('value'))
    assert False is Lazy.of('value').__eq__(Lazy.of('other_value'))
    assert True is Lazy.of('value').map(lambda x: x).__eq__(Lazy.of('value').map(lambda x: x))
    assert False is Lazy.of('value').map(lambda x: x).__eq__(Lazy.of('value').map(lambda x: x + 1))



# Generated at 2022-06-12 05:11:50.445357
# Unit test for method get of class Lazy
def test_Lazy_get():

    lazy_to_call = Lazy(lambda a: a)
    assert lazy_to_call.get(3) == 3

    lazy_to_call = Lazy(lambda a: a).map(lambda a: a + 5)
    assert lazy_to_call.get(3) == 8

    lazy_to_call = Lazy(lambda a: a + 5).map(lambda a: a + 5)
    assert lazy_to_call.get(3) == 13

    lazy_to_call = Lazy(lambda a: a + 5).map(lambda a: a + 5).map(lambda a: a + 5)
    assert lazy_to_call.get(3) == 18


# Generated at 2022-06-12 05:11:52.881168
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x + 1).bind(lambda x: Lazy(lambda y: x + y)).get(2, 3) == 6

# Generated at 2022-06-12 05:11:57.670626
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_try import Try

    def pair(x: str) -> 'Try[Tuple[int, str]]':
        return Try.of(lambda x: (x, x), x)

    assert Lazy(pair).get('1') == Try.of(lambda x: (x, x), '1').get()



# Generated at 2022-06-12 05:12:01.062122
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def my_fn():
        pass

    assert (Lazy(my_fn) == Lazy(my_fn)) is True

    assert (Lazy(my_fn) == Lazy(lambda: True)) is False



# Generated at 2022-06-12 05:12:03.199185
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.fn import Fn

    fn_id = Fn.id

    Lazy.of(1) == Lazy.of(1)

# Generated at 2022-06-12 05:12:09.029774
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given
    lazy_value = Lazy.of(10)
    mapper = lambda x: x * 2

    # When
    actual_result = lazy_value.map(mapper)

    # Then
    expected_result = Lazy(lambda *args: 20)
    assert actual_result == expected_result


# Generated at 2022-06-12 05:12:13.727520
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(10).get() == 10


# Generated at 2022-06-12 05:12:24.380599
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def concat_str(str1: str) -> int:
        return int(str1)

    def add_int(i1: int, i2: int) -> int:
        return i1 + i2

    def add_all_int(i1: int, i2: int, i3: int) -> int:
        return i1 + i2 + i3

    lazy1 = Lazy.of(10)
    lazy2 = Lazy.of('10')
    lazy3 = Lazy.of('20')
    lazy4 = Lazy.of('30')
    lazy_fn = Lazy.of(concat_str)
    lazy_fn1 = Lazy.of(add_int)
    lazy_fn2 = Lazy.of(add_all_int)


# Generated at 2022-06-12 05:12:31.862744
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(Lazy.of) == Lazy(lambda: 1)
    assert Lazy(lambda: 1).bind(lambda x: Lazy.of(x)) == Lazy(lambda: 1)
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x)) == Lazy(lambda: 1)
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)) == Lazy(lambda: 2)



# Generated at 2022-06-12 05:12:37.356875
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    y = Lazy(lambda x: x+1)
    assert not y == Lazy(lambda x: x+2)

    assert Lazy.of(10) == Lazy.of(10)

    y = Lazy(lambda *args: [1, 2, 3])
    assert y == Lazy(lambda *args: [1, 2, 3])


# Generated at 2022-06-12 05:12:44.714623
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add1(x: int) -> int:
        return x + 1

    def add2(x: int) -> int:
        return x + 2

    def add3(x: int) -> int:
        return x + 3

    def add4(x: int) -> int:
        return x + 4

    lazy = Lazy.of(1)
    assert lazy.map(add1).map(add2).map(add3).map(add4).get() == 10
    assert lazy.map(add1).map(add2).map(add3).get() == 6
    assert lazy.map(add1).map(add2).get() == 3
    assert lazy.map(add1).get() == 2
    assert lazy.get() == 1



# Generated at 2022-06-12 05:12:48.365288
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(2)



# Generated at 2022-06-12 05:12:53.793327
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    def function(value):
        def function_to_bind(value):
            return Maybe.of(value)

        return Lazy.of(value).bind(function_to_bind)

    assert function(Box(5)) == Maybe.of(Box(5))
    assert function(Box(None)) == Maybe.empty()
    assert function(None) == Maybe.empty()

# Generated at 2022-06-12 05:13:01.150191
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def mapper1(value): return value * 2

    def mapper2(value): return value + 1

    assert Lazy.of(1).ap(Box(mapper1)).get() == 2
    assert Lazy.of(3).ap(Box(mapper2)).get() == 4
    assert Lazy.of(1).ap(Box(mapper1)).map(lambda x: x - 1).get() == 1



# Generated at 2022-06-12 05:13:07.654351
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # pylint: disable=comparison-with-callable
    lazy_func = Lazy(lambda x: x)
    assert lazy_func == lazy_func
    assert not (lazy_func == None)
    assert lazy_func == Lazy(lambda x: x)
    assert lazy_func != Lazy(lambda x: x/2)
    # pylint: enable=comparison-with-callable

# Generated at 2022-06-12 05:13:09.786972
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)

    assert not (Lazy.of(1) == Lazy.of(2))


# Generated at 2022-06-12 05:13:17.548421
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 2) == Lazy(lambda: 2)
    assert Lazy(lambda: 2) != Lazy(lambda: 5)
    assert Lazy(lambda: 2) != Lazy(lambda: 2).map(lambda x: x * 2)
    assert Lazy(lambda: 2) != 5



# Generated at 2022-06-12 05:13:28.406183
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda l: Lazy.of(l + 1)).get() == 2
    assert Lazy.of(1).bind(lambda l: Lazy.of(l + 2)).get() == 3
    assert Lazy.of(1).bind(lambda l: Lazy.of(l + 3)).get() == 4
    assert Lazy.of(1).bind(lambda l: Lazy.of(l + 4)).get() == 5
    assert Lazy.of(1).bind(lambda l: Lazy.of(l + 5)).get() == 6
    assert Lazy.of(1).bind(lambda l: Lazy.of(l + 6)).get() == 7
    assert Lazy.of(1).bind(lambda l: Lazy.of(l + 7)).get() == 8
    assert L

# Generated at 2022-06-12 05:13:40.363724
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    class TestClass(object):
        pass

    test_instance = TestClass()
    test_instance._is_called = False
    test_value_to_return = 1

    class ApClass(Lazy[None, int]):
        def __init__(self):
            super().__init__(lambda *args: test_value_to_return)

        def get(self, *args):
            if not test_instance._is_called:
                test_instance._is_called = True
                return super().get(*args)

    ap_class = ApClass()

    def mapper(value, *args):
        return value + 1

    ap_class_map = ap_class.map(mapper)

    assert test_instance._is_called is False
    assert ap_class.get() == test_value_to_return


# Generated at 2022-06-12 05:13:44.863632
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test(name, mock_value):
        def mock_fn():
            return mock_value

        lazy_value = Lazy(mock_fn)
        assert lazy_value.map(lambda value: value + 2).get() == 4
        print(name)

    test('test_Lazy_map', 2)


# Generated at 2022-06-12 05:13:46.406883
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for method get of class Lazy

    :return: None
    """
    x = Lazy.of(10)
    assert x.get() == 10



# Generated at 2022-06-12 05:13:54.154981
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.either import Left

    def is_even_lazy(value):
        def is_even(value):
            return True if value % 2 == 0 else False

        return Lazy(lambda: is_even(value)).bind(lambda result: Lazy.of(Left('not_even')) if not result else Lazy.of(value))

    assert is_even_lazy(10).get() == 10
    assert is_even_lazy(11).get() == Left('not_even')



# Generated at 2022-06-12 05:14:05.495245
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    add = lambda a, b: a + b
    add_lazy = Lazy.of(add)
    add_two = add_lazy.map(lambda add_func: lambda a: add_func(2, a))
    assert add_two.get(3) == 5

    add_lazy_box = add_lazy.to_box()
    assert add_lazy_box.map(add, Box.of(5)).get() == 7

    add_lazy_right = add_lazy.to_either()

# Generated at 2022-06-12 05:14:08.276508
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(3).get() == 3
    def function(x):
        return x + 2

    assert Lazy(function).get(3) == 5


# Generated at 2022-06-12 05:14:20.049855
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functions import compose
    from pymonet.functions import pipe
    from pymonet.box import Box
    from pymonet.functions import _

    add = lambda x, y: x + y
    lazy_add = Lazy(lambda x, y: x + y)

    composed_add = compose(Lazy.of, add, lambda x: x)
    piped_add = pipe(Lazy.of, add, lambda x: x)
    add_box = Lazy(lambda x: Box(x))

    assert lazy_add.bind(composed_add).get(1, 1) == 2
    assert lazy_add.bind(piped_add).get(1, 1) == 2
    assert lazy_add.bind(add_box).get(1) == 2

# Generated at 2022-06-12 05:14:23.617308
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)

    class TestClass:
        pass

    test_object = TestClass()
    assert Lazy.of(test_object) == Lazy.of(test_object)

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)

    assert Lazy(lambda: test_object) == Lazy(lambda: test_object)
    assert Lazy(lambda: test_object) != Lazy(lambda: TestClass())

    assert Lazy(lambda: 1) != 1
    assert Lazy(lambda: test_object) != test_object

    assert Lazy(lambda: 1) != None
    assert Lazy

# Generated at 2022-06-12 05:14:28.951627
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_double_value(value):
        return Lazy(lambda: value * 2)

    assert Lazy(lambda: 1).bind(test_double_value).get() == 2



# Generated at 2022-06-12 05:14:32.069795
# Unit test for method get of class Lazy
def test_Lazy_get():
    @Lazy
    def value():
        return 42

    assert value.get() == 42
    assert value.get() == 42
    assert value.get() == 42


# Generated at 2022-06-12 05:14:42.742353
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box

    add_one = lambda box: Box(box.get() + 1)

    add_one_lazy = Lazy(lambda x: add_one(x)).bind(lambda x: x)
    add_one_lazy_copy = Lazy(lambda x: add_one(x)).bind(lambda x: x)

    assert add_one_lazy == add_one_lazy_copy
    assert add_one_lazy.get(Box(0)) == 1
    assert add_one_lazy_copy.get(Box(0)) == 1
    assert add_one_lazy is not add_one_lazy_copy


# Generated at 2022-06-12 05:14:47.886446
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(3) == Lazy.of(3)
    assert Lazy.of(3) != Lazy.of(4)
    assert Lazy.of(3) != 3
    assert Lazy.of(3) != Lazy(lambda: 4)


# Generated at 2022-06-12 05:14:53.576280
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.validation import Validation

    data = Lazy(lambda x: x)
    assert not data.is_evaluated

    result = data.ap(Box(1))
    assert result.is_evaluated
    assert result.value == 1

    result = data.ap(Validation.success(1))
    assert result.is_evaluated
    assert result.value == 1

# Generated at 2022-06-12 05:14:57.477382
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # given
    lazy1 = Lazy(len)
    lazy2 = Lazy(len)

    # when
    lazy1.get(['1'])

    # then
    result = lazy1 == lazy2

    # expect
    assert result is False



# Generated at 2022-06-12 05:15:06.136248
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    def add2(x):
        return x + 2

    def multiple_by_3(x):
        return x * 3

    def divide_by_4(x):
        return x / 4

    def function1(x):
        return Lazy.of(Box(x))

    def function2(x):
        return Lazy.of(Box(x)).map(add2).map(multiple_by_3).map(divide_by_4)

    def function3(x):
        return Lazy.of(Box(x)).m

# Generated at 2022-06-12 05:15:10.419406
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    lazy = Lazy(fn)
    assert lazy == lazy
    assert lazy == Lazy(fn)
    lazy2 = Lazy(fn2)
    assert lazy != lazy2


# Generated at 2022-06-12 05:15:12.639476
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(5).map(lambda x: x + 1).get() == 6


# Generated at 2022-06-12 05:15:18.085323
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x: int) -> int:
        """
        x -> x + 2
        """
        return x + 2

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy.of(1)

    assert lazy1 == lazy2
    assert lazy1 != lazy3
    assert lazy2 != lazy3



# Generated at 2022-06-12 05:15:28.028268
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """Unit test for method __eq__ of class Lazy"""

    def mock_constructor_fn(value):
        return value

    mock_value = 'value'

    lazy_A = Lazy(mock_constructor_fn)
    lazy_B = Lazy(mock_constructor_fn)
    lazy_A.get(mock_value)
    lazy_B.get(mock_value)

    assert lazy_A == lazy_B



# Generated at 2022-06-12 05:15:32.873372
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    def add(a):
        def adder(b):
            return a + b

        return adder

    lazy_adder = Lazy.of(add).ap(Lazy.of(10))
    assert lazy_adder == Lazy(lambda *args: add(10))
    assert lazy_adder.get(20) == 30


# Generated at 2022-06-12 05:15:34.317035
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    This method is tested as part of BindableTests.
    """

# Generated at 2022-06-12 05:15:38.720479
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(x):
        pass

    def g(x):
        pass

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1).map(f) != Lazy.of(2).map(f)
    assert Lazy.of(1).map(f) != Lazy.of(1).map(g)
    assert Lazy.of(1).map(f) != Lazy.of(1)



# Generated at 2022-06-12 05:15:46.270362
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(2).get() == 2
    assert Lazy.of(None).get() is None
    assert Lazy.of(lambda x: x * 2).get(2) == 4
    assert Lazy.of(lambda x: x).get('abc') == 'abc'
    assert Lazy.of(lambda x, y, z: x + y + z).get(1, 2, 3) == 6


# Unit tests for method bind of class Lazy

# Generated at 2022-06-12 05:15:51.932908
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Left

    assert Lazy.of(1).bind(lambda x: Lazy.of(2 * x)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(2 * x)).get() == 2
    assert Lazy.of(1).bind(lambda x: Left('err')).get() == 'err'
    assert Lazy.of(1).bind(lambda x: Left('err')).to_maybe().get() == 1

# Generated at 2022-06-12 05:15:57.802287
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn(*args):
        return 1

    def fn1(*args):
        return 2

    def fn2(*args):
        return 2

    lazy = Lazy(fn)

    assert lazy == Lazy(fn)
    assert lazy != Lazy(fn1)
    assert lazy == Lazy(fn2)
    assert lazy == lazy
    assert lazy != 2


# Generated at 2022-06-12 05:15:59.825335
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn():
        return 1

    lazy = Lazy(test_fn)
    assert lazy.get() == 1


# Generated at 2022-06-12 05:16:02.205726
# Unit test for method map of class Lazy
def test_Lazy_map():
    l = Lazy(lambda x: x + 1).map(lambda x: x * 3)
    assert l == Lazy(lambda x: (x + 1) * 3)


# Generated at 2022-06-12 05:16:07.217869
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda v: Lazy.of(v + 1)).get() == 2

    def f1(v):
        return Lazy.of(v + 1)

    def f2(v):
        return Lazy.of(v * 2)

    assert Lazy.of(1).bind(f1).bind(f2).get() == 4

# Generated at 2022-06-12 05:16:19.450272
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box

    f = lambda x: x + 1
    assert Lazy(f) == Lazy(f)

    f = lambda x: x + 1
    assert Lazy(f) == Lazy(f)

    assert Lazy(f).map(lambda x: x - 1) == Lazy(f).map(lambda x: x - 1)

    assert Lazy(f).ap(Lazy(f).map(lambda x: x - 1)) == Lazy(f).ap(Lazy(f).map(lambda x: x - 1))

    assert Lazy(f).bind(Lazy(Box(f))) == Lazy(f).bind(Lazy(Box(f)))

    assert Lazy(f).to_box() == Lazy(f).to_box()

    assert Lazy(f).to_

# Generated at 2022-06-12 05:16:21.687423
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f():
        return 1

    assert Lazy(f) == Lazy(f)
    assert not (Lazy(f) == object())



# Generated at 2022-06-12 05:16:26.973449
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 'abc') != Lazy(lambda: 'abc')
    assert Lazy(lambda: 123) != Lazy(lambda: 123)
    assert Lazy(lambda: [1, 2, 3]) != Lazy(lambda: [1, 2, 3])
    assert Lazy(lambda: 'abc') == Lazy(lambda: 'abc')
    assert Lazy(lambda: 123) == Lazy(lambda: 123)
    assert Lazy(lambda: [1, 2, 3]) == Lazy(lambda: [1, 2, 3])


# Generated at 2022-06-12 05:16:32.402295
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box, BoxEmpty
    from pymonet.boxed_fn import BoxedFn

    assert Lazy(lambda x: x).ap(BoxedFn(lambda x: x)).get(2) == 2
    assert Lazy(lambda x: x).ap(BoxEmpty()).get() == BoxEmpty()

# Generated at 2022-06-12 05:16:44.680990
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_try import Try

    called_function = {}
    class_type = 'class_type'
    class_value = 'class_value'
    class_function_result = 'class_function_result'
    def mapper(value):
        # pylint: disable=missing-function-docstring
        called_function[class_type] = value
        return class_function_result

    result = Lazy(lambda: class_value).map(mapper).get()

    assert result == class_function_result
    assert result != class_value
    assert called_function[class_type] == class_value

    assert (
        Lazy(lambda: Try.success(class_value)).map(mapper).get().get()
        == class_function_result
    )

# Generated at 2022-06-12 05:16:47.268567
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_ = Lazy(lambda number: number + 2).bind(lambda number: Lazy(lambda: number * 5))
    assert lazy_.get(2) == 14



# Generated at 2022-06-12 05:16:59.493616
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    """
    Unit test for method get of class Lazy
    """
    # Check equality of type int(5) with type Lazy(int(5))
    assert 1 == Lazy.of(1).bind(lambda x: Lazy.of(x + 4)).get()

    # Check equality of type Lazy[A, A] with Lazy[A, A]
    assert Lazy.of(1) == Lazy.of(1).bind(lambda x: Lazy.of(x + 4)).get()

    # Check equality of type Lazy[A, A] with Lazy[A, A]
    assert Lazy.of(1) == Lazy.of(1).bind(lambda x: Lazy.of(x + 4)).get()

    # Check equality of type str("some string") with Lazy(

# Generated at 2022-06-12 05:17:02.227425
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_1 = Lazy.of(1)
    lazy_2 = Lazy.of(1)
    assert lazy_1 == lazy_2
    assert lazy_1 == lazy_1



# Generated at 2022-06-12 05:17:10.614241
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn(val):
        return val

    mapped_fn = Lazy(fn).map(lambda val: val)

    assert Lazy(fn) == Lazy(fn)
    assert mapped_fn == mapped_fn
    assert mapped_fn != str(mapped_fn)
    assert mapped_fn != Lazy(fn)
    assert mapped_fn != Lazy(fn).map(lambda val: val + val)
    assert mapped_fn != Lazy(fn).map(lambda val: val).map(lambda val: val)


# Generated at 2022-06-12 05:17:15.750301
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda: 'something')
    assert lazy.get() == 'something'
    assert lazy.get() == 'something'
    assert lazy.get() == 'something'

    lazy = Lazy(lambda x: x).bind(lambda x: Lazy(lambda y: x + y))
    assert lazy.get(1, 2) == 3



# Generated at 2022-06-12 05:17:29.027910
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(arg):
        return arg + 1

    def f1(arg):
        return arg + 1

    assert Lazy(f) == Lazy(f1)

    g = lambda arg: arg + 1
    g1 = lambda arg: arg + 1

    assert Lazy(g) == Lazy(g1)

    assert Lazy(f) == Lazy.of(2)

# Generated at 2022-06-12 05:17:37.116120
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2

    def add_rule(a):
        try:
            return a + 1
        except Exception as e:
            raise ValueError(e)

    assert Lazy.of(1).map(add_rule).get() == 2

    # check if mapper is called
    mapper = spy(lambda x: x + 1)
    Lazy.of(1).map(mapper).get()

    assert mapper.called

    # check if mapper return value is used
    def mapCalled(x):
        mapper()
        return x + 1

    mapper = spy(mapCalled)
    Lazy.of(1).map(mapper).get()

    assert mapper.call_count == 2

    # check if mapper is

# Generated at 2022-06-12 05:17:42.318618
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def function(*args):
        print(args)
        return args

    lazy = Lazy(function)
    lazy.bind(lambda x: Lazy.of(x))
    print(lazy)
    lazy.get(1, 2, 3)
    print(lazy)
    print(lazy.fold(lambda x: str(x)))

# Generated at 2022-06-12 05:17:49.414067
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    add = lambda x, y: x + y
    lazy_add = Lazy(add)
    lazy_add2 = Lazy(add)
    lazy_add2_evaluated = Lazy(add)
    lazy_add2_evaluated.is_evaluated = True
    lazy_add3 = Lazy(add)
    lazy_add3.value = add(5, 5)

    assert lazy_add == lazy_add2
    assert lazy_add != lazy_add2_evaluated
    assert lazy_add != lazy_add3



# Generated at 2022-06-12 05:17:56.385830
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy(lambda: 3)
    assert lazy.bind(lambda x: Lazy.of(x + 1)) == Lazy.of(4)

    lazy = Lazy(lambda x: x + 1)
    assert lazy.bind(lambda x: Lazy(lambda y: x + y + 1))(3) == 8

    def generator():
        """
        Generator function used to not alter native range function
        """

# Generated at 2022-06-12 05:18:01.058466
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 2)
    assert Lazy.of(1) != 1



# Generated at 2022-06-12 05:18:11.792309
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy1 = Lazy.of(1)
    lazy2 = Lazy.of(1)

    assert lazy1 == Lazy.of(1)
    assert lazy2 == Lazy.of(1)
    assert lazy1 != Lazy.of(2)
    assert lazy2 != Lazy.of(2)

    assert lazy1 == lazy1
    assert lazy1 == lazy2
    assert lazy1 != lazy2.map(lambda x: x + 1)
    assert lazy1 != lazy2.map(lambda x: x + 1)

    assert lazy1.fold(lambda x: x) == 1
    assert lazy2.fold(lambda x: x) == 1


# Generated at 2022-06-12 05:18:19.715116
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # given
    some_val = 'test'
    lazy = Lazy(some_val)

    other_val = 'test'
    other_lazy = Lazy(other_val)

    different_val = 'different'
    different_lazy = Lazy(different_val)

    # when
    result_1 = lazy == other_lazy
    result_2 = lazy == different_lazy

    result_3 = different_lazy == lazy
    result_4 = different_lazy == other_lazy

    # then
    assert result_1
    assert not result_2

    assert result_3
    assert not result_4



# Generated at 2022-06-12 05:18:30.043273
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Either
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def divider(a, b):
        if b == 0:
            raise ZeroDivisionError('Division by 0')
        return a / b

    assert Lazy.of(2).ap(Lazy.of(divider)).get(4) == 2

    assert Lazy.of(0).ap(Lazy.of(divider)).to_either(4).is_left()
    assert Lazy.of(0).ap(Lazy.of(divider)).to_either(4).get_left() == ZeroDivisionError('Division by 0')
    assert Lazy.of(0).ap(Lazy.of(divider)).to_

# Generated at 2022-06-12 05:18:37.433146
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Lazy.of(14).bind(lambda x: Lazy.of(x + 1) if x % 2 == 0 else Lazy.of(20)).get() == 15
    assert Lazy.of(14).bind(lambda x: Lazy.of(x + 1) if x % 2 == 0 else Lazy.of(20)).constructor_fn() == 15
    assert Lazy.of(15).bind(lambda x: Lazy.of(x + 1) if x % 2 == 0 else Lazy.of(20)).get() == 20
    assert Lazy.of(15).bind(lambda x: Lazy.of(x + 1) if x % 2 == 0 else Lazy.of(20)).constructor_fn() == 20

# Generated at 2022-06-12 05:19:03.941823
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    lazy_box_fn = Box.of(lambda x: x + 1)  # type: Box[Callable[[int], int]]
    lazy_maybe_fn = Maybe.just(lambda x: x + 1)  # type: Maybe[Callable[[int], int]]
    lazy_validation_fn = Validation.success(lambda x: x + 1)  # type: Validation[Callable[[int], int], []]

    assert Lazy.of(1).ap(lazy_box_fn).get() == 2
    assert Lazy.of(1).ap(lazy_maybe_fn).get() == 2

# Generated at 2022-06-12 05:19:10.324976
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = Lazy(lambda: 42)
    g = Lazy(lambda: 42)
    h = Lazy(lambda: 43)
    assert f == g
    assert g != h
    assert f != h
    assert f != 42
    assert f != Lazy.of(42)
    assert f == Lazy.of(42)

# Generated at 2022-06-12 05:19:14.501318
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def folder_fn(x):
        return Box(x + 1)

    lazy_instance = Lazy(lambda: 1)
    result = lazy_instance.bind(folder_fn)
    assert result.get() == Box(2)


# Generated at 2022-06-12 05:19:22.135762
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of Lazy class
    """
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Either

    def addup(x):
        return Lazy(lambda: x + 1)

    def addtwo(x):
        return Lazy(lambda: x + 2)

    def addthree(x):
        return Lazy(lambda: x + 3)

    lazy_try = Try.of(lambda: '1').to_lazy()
    lazy_maybe = Maybe.just(1).to_lazy()
    # pylint: disable=unnecessary-lambda
    lazy_either = Either.of(lambda: 2, lambda: 3).to_lazy()


# Generated at 2022-06-12 05:19:32.942388
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Unit test for method __eq__ of class Lazy
    """
    def f(x):
        return x

    def g(x):
        return x

    assert Lazy.of(f).__eq__(Lazy.of(f))
    assert Lazy.of(f).__eq__(Lazy.of(g))

    assert not Lazy.of(f).__eq__(Lazy.of(f).map(f))
    assert not Lazy.of(f).__eq__(Lazy.of(g).map(f))

    assert Lazy.of(f).__eq__(Lazy.of(f).map(g))
    assert Lazy.of(f).__eq__(Lazy.of(g).map(g))



# Generated at 2022-06-12 05:19:35.266318
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    __eq__ method of Lazy class
    """
    assert Lazy.of(1) == Lazy.of(1)



# Generated at 2022-06-12 05:19:42.850094
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.either import Left
    from pymonet.maybe import Nothing
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(10).get() == 10
    assert Lazy.of(None).get() is None

    assert Lazy.of(lambda: 10).bind(lambda x: lambda *args: x * 2)(10) == 20
    assert not Lazy.of(lambda: 10).bind(lambda x: lambda *args: x * 2).is_evaluated
    assert Lazy.of(lambda: 10).bind(lambda x: lambda *args: x * 2).get(10) == 20
    assert Lazy.of(lambda: 10).bind(lambda x: lambda *args: x * 2).is_evaluated



# Generated at 2022-06-12 05:19:52.928279
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Set test values
    test_value = 'test_value'
    test_args = [1, 2, 'test_args']

    # Define test function
    test_function = lambda *args: test_value
    test_function_args = lambda *args: (args, test_value)

    # Assert get() method returns expected value
    assert Lazy.of(test_value).get() == test_value
    assert Lazy(test_function).get(*test_args) == test_value
    assert Lazy(test_function_args).get(*test_args) == (test_args, test_value)



# Generated at 2022-06-12 05:19:56.785606
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def increment(value):
        return value + 1

    lazy = Lazy(lambda: 0)

    assert lazy.bind(increment) == Lazy(lambda: 1)

# Generated at 2022-06-12 05:20:01.433113
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def constructor(x):
        return x

    lazy_minimal = Lazy(constructor)
    lazy_with_equal_constructor = Lazy(constructor)
    lazy_with_not_equal_constructor = Lazy(None)

    lazy_without_value = Lazy(constructor)
    lazy_with_value = Lazy(constructor)
    lazy_with_value._compute_value()

    lazy_minimal_value = Lazy.of(1)
    lazy_with_equal_value = Lazy.of(1)
    lazy_with_not_equal_value = Lazy.of(2)

    assert lazy_minimal != lazy_with_equal_constructor
    assert lazy_minimal != lazy_with_not_equal_constructor

    assert lazy_without_value != lazy_with_value

# Generated at 2022-06-12 05:20:47.842681
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def custom_function(a: int, b: int) -> int:
        return a + b

    box_result = Lazy(custom_function).bind(lambda x: Box(x)).get(1, 2)
    either_result = Lazy(custom_function).bind(lambda x: Right(x)).get(1, 2)
    maybe_result = Lazy(custom_function).bind(lambda x: Maybe.just(x)).get(1, 2)
    try_result = Lazy(custom_function).bind(lambda x: Try.of(lambda: x)).get(1, 2)
    validation

# Generated at 2022-06-12 05:20:53.076820
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_fn(constructor_fn):
        def sum_fn(b):
            return constructor_fn + b
        return Lazy(sum_fn)

    assert Lazy(lambda a: a + 1).bind(add_fn).get(4) == 6
    assert Lazy(lambda a: a + 1).map(lambda a: a + 5).get(4) == 10

# Generated at 2022-06-12 05:21:00.883047
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    fn = Lazy(lambda _: lambda x: x * 2)
    another = Lazy(lambda _: 2)

    assert Lazy.of(3).ap(Lazy.of(lambda x: x + 2)) == Lazy(lambda: 3).ap(Lazy(lambda: lambda x: x + 2)).to_box()
    assert fn.ap(another) == fn.bind(lambda g: another.map(g)) == Lazy.of(4).to_box()

