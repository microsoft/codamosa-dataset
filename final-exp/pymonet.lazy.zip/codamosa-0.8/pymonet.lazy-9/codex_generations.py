

# Generated at 2022-06-12 05:11:11.996382
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn():
        return 1

    x = Lazy(fn)
    assert x.get() == 1

    assert x.to_box().unbox() == 1
    assert x.to_either().get_or_else(lambda: None) == 1
    assert x.to_maybe().get_or_else(lambda: None) == 1
    assert x.to_try().get_or_else(lambda: None) == 1
    assert x.to_validation().get_or_else(lambda: None) == 1
    assert x.to_validation().to_seq() == [1]

# Generated at 2022-06-12 05:11:19.159425
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    # GIVEN function to return 2
    def add_2(a):
        return a + 2

    # WHEN create two Lazy both with the same function (add_2)
    lazy_with_add_2 = Lazy(add_2)
    lazy_with_add_2_2 = Lazy(add_2)

    # THEN both lazeys are equal
    assert lazy_with_add_2 == lazy_with_add_2_2



# Generated at 2022-06-12 05:11:27.369169
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def make_lazy(value):
        return Lazy(lambda: value)

    lazy_1 = make_lazy(1)
    lazy_2 = make_lazy(2)

    assert lazy_1 != lazy_2
    assert lazy_1.get() == 1
    assert lazy_1.get() == 1
    assert lazy_2.get() == 2
    assert lazy_2.get() == 2
    assert lazy_1 == lazy_1
    assert lazy_2 == lazy_2

# Generated at 2022-06-12 05:11:30.298774
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add(x):
        return Lazy.of(x + 1)

    lazy = Lazy.of(1).bind(add).bind(add)
    assert lazy.get() == 3

# Generated at 2022-06-12 05:11:37.015758
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    lazy_to_return_args = Lazy.of(lambda *args: args)
    lazy_return_value = lazy_to_return_args.bind(lambda args: Lazy.of(args[0]))
    assert lazy_return_value._compute_value(1) == 1



# Generated at 2022-06-12 05:11:42.233488
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def test_fn(x):
        return x

    assert Lazy(test_fn) == Lazy(test_fn)
    assert Lazy(test_fn) == Lazy(test_fn)

# Generated at 2022-06-12 05:11:54.395980
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def assert_lazy_values_are_equals(lazy_l, lazy_r):
        assert lazy_l == lazy_r
        assert not lazy_l != lazy_r

    def assert_lazy_values_are_not_equals(lazy_l, lazy_r):
        assert not lazy_l == lazy_r
        assert lazy_l != lazy_r

    def assert_lazy_values_are_equals_with_value(lazy_l, lazy_r, value):
        assert lazy_l == lazy_r
        assert not lazy_l != lazy_r
        assert lazy_l.get() == value
        assert lazy_r.get() == value


# Generated at 2022-06-12 05:11:57.905879
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 2).get() == 2
    assert Lazy(lambda x: x).get(2) == 2
    assert Lazy(lambda x, y: x * y + 1).get(2, 3) == 7



# Generated at 2022-06-12 05:12:00.171923
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy = Lazy.of(2)
    assert lazy.map(lambda x: x + 2).constructor_fn() == 4



# Generated at 2022-06-12 05:12:06.208816
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def add_two(x: int) -> int:
        return x + 2

    lazy = Lazy(add_two)
    assert lazy == Lazy(add_two)

    another_lazy = Lazy(add_two)
    another_lazy.get(11)
    assert another_lazy == Lazy(add_two)

    assert lazy != another_lazy



# Generated at 2022-06-12 05:12:19.682552
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test Lazy.bind method.

    It's only way to call function store in Lazy
    :param fn: Function(constructor_fn) -> B
    :returns: result od folder function
    :rtype: B
    """
    import pytest

    from pymonet.validation import Validation
    from pymonet.validation import Invalid

    f = Lazy(lambda x: x + 1)

    def mapper(x):
        return Lazy(lambda: x + 2)

    assert f.bind(mapper) == Lazy(lambda x: x + 3)
    assert f.bind(mapper).get(3) == 6

    def val_mapper(x):
        return Validation.success(x + 1).to_lazy()

    assert f.bind(val_mapper) == L

# Generated at 2022-06-12 05:12:26.834543
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor

    def _assert_equal_lazy_functors(functor: Functor, equal_functor: Functor) -> None:  # pragma: no cover
        assert functor.__eq__(equal_functor)
        assert equal_functor.__eq__(functor)

    def _assert_not_equal_lazy_functors(functor: Functor, not_equal_functor: Functor) -> None:  # pragma: no cover
        assert not functor.__eq__(not_equal_functor)
        assert not not_equal_functor.__eq__(functor)

    # Lazy with computed values
    lazy_computed_value = Lazy(lambda: 1)
    lazy_computed_value.is_evaluated = True
    lazy

# Generated at 2022-06-12 05:12:30.073372
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(2).get() == 2
    assert Lazy.of(3).get() == 3

# Generated at 2022-06-12 05:12:39.003118
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.maybe import Maybe

    # when
    lazy_empty = Lazy.of(1)
    lazy_empty.get()
    lazy_filled = Lazy.of(2)
    lazy_filled.get()

    # then
    assert lazy_empty == lazy_empty
    assert lazy_filled == lazy_filled

    assert lazy_empty != lazy_filled
    assert lazy_filled != lazy_empty

    assert lazy_empty != Maybe.empty()
    assert lazy_filled != Maybe.just(2)

    assert lazy_empty != Maybe.just(1)
    assert lazy_filled != Maybe.just(1)


# Generated at 2022-06-12 05:12:41.637137
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def get_value():
        return 1

    assert Lazy(get_value) == Lazy(get_value)



# Generated at 2022-06-12 05:12:48.577767
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def func(x: int, y: int) -> int:
        return x + y

    def func_1(a: int) -> int:
        return a + 1

    lazy = Lazy(lambda x: x).map(func_1)
    assert Lazy(func).ap(lazy).get(1, 2) == 4

    lazy = Lazy(lambda: None)
    assert lazy.ap(lazy) == lazy

# Generated at 2022-06-12 05:12:49.609030
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(lambda x: x).map(lambda x: x(1)).get() == 1


# Generated at 2022-06-12 05:12:53.449315
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x + 11) != Lazy(lambda x: x + 1)

# Generated at 2022-06-12 05:12:56.987558
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    fn = lambda x: Box(x + 2)
    lazy = Lazy(lambda: 1)
    assert lazy.bind(fn).get() == Box(3)

# Generated at 2022-06-12 05:13:02.632612
# Unit test for method map of class Lazy
def test_Lazy_map():
    sum_of_two_numbers = Lazy(lambda x: lambda y: x + y)

    assert sum_of_two_numbers.map(lambda x: x(3)).map(lambda y: y(5)).get() == 8
    assert sum_of_two_numbers.map(lambda x: x(3)).map(lambda y: y(5)).get() == 8  # check if we execute function only once



# Generated at 2022-06-12 05:13:10.318525
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def transformation_fn(x):
        def transformation_fn_inner(y):
            return x + y

        return Lazy(transformation_fn_inner)

    lazy = Lazy(lambda _: 3)

    lazy2 = lazy.bind(transformation_fn)

    assert lazy2.get(1) == 4

# Generated at 2022-06-12 05:13:22.034722
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def f(x):
        return Lazy(lambda: x + 1)

    def g(x):
        return Lazy(lambda: x * 3)

    def h(x):
        return Lazy(lambda: x - 10)

    assert Lazy(lambda: 4).bind(f).bind(g).bind(h).get() == 9
    assert Lazy(lambda: 4).bind(f).bind(g).bind(h).get() == 9
    assert Lazy(lambda: 4).bind(f).bind(g).bind(h).get() == 9
    assert Lazy(lambda: 4).bind(f).bind(g).bind(h).get() == 9
    assert Lazy(lambda: 4).bind(f).bind(g).bind(h).get() == 9

# Generated at 2022-06-12 05:13:27.325551
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover

    from .lazy import Lazy

    add = Lazy(lambda a: lambda b: a + b)
    assert add.ap(Lazy.of(1)).ap(Lazy.of(2)).get() == 3

    data = Lazy.of(1)
    assert data.ap(Lazy.of(2)).get() == 1

# Generated at 2022-06-12 05:13:39.636616
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test for method __eq__ of class Lazy
    """
    def a_fn():
        return 1

    def b_fn():
        return 2

    # pylint: disable=too-many-function-args
    a_lazy = Lazy(a_fn)
    a_fn.b_fn = Lazy(b_fn)

    def c_fn():
        return 42

    def d_fn():
        return 43

    c_lazy = Lazy(c_fn)
    c_fn.d_fn = Lazy(d_fn)

    # pylint: disable=too-many-function-args
    assert a_lazy == Lazy(a_fn)
    assert a_lazy != Lazy(b_fn)
    assert a_lazy != a_fn.b_

# Generated at 2022-06-12 05:13:51.235905
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def _get_lazy(fn_name, arg=None) -> Lazy[int, str]:
        return Lazy(lambda x: "lazy_" + fn_name + "(" + str(x) + str(arg) + ")")

    assert _get_lazy("a", "=1") == _get_lazy("a", "=1")
    assert _get_lazy("a", "=1") != _get_lazy("a", "=2")
    assert _get_lazy("a", "=1") != _get_lazy("b", "=1")
    assert _get_lazy("a", "=1").is_evaluated is False
    assert _get_lazy("a", "=1").get() == "lazy_a(1=1)"
    assert _get_l

# Generated at 2022-06-12 05:13:57.319940
# Unit test for method get of class Lazy
def test_Lazy_get():
    def side_effect_not_empty_str(string):
        return string

    def side_effect_not_empty_int(string):
        return int(string)

    def side_effect_empty_str(string):
        return ''

    def side_effect_empty_int(string):
        return 0

    lazy_with_side_effect_not_empty_str = Lazy(side_effect_not_empty_str)
    lazy_with_side_effect_not_empty_int = Lazy(side_effect_not_empty_int)
    lazy_with_side_effect_empty_str = Lazy(side_effect_empty_str)
    lazy_with_side_effect_empty_int = Lazy(side_effect_empty_int)

    assert 'data' == lazy_with_side_effect_not_

# Generated at 2022-06-12 05:14:01.635907
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).bind(lambda x: Lazy.of(x + 1)).get() == 3



# Generated at 2022-06-12 05:14:07.588904
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x, y):
        return x + y

    def sub(x, y):
        return x - y

    assert Lazy.of(add).ap(Lazy.of(5)).ap(Lazy.of(2)) == Lazy.of(add).ap(Lazy.of(5)).ap(Lazy.of(2))
    assert Lazy(add).ap(Lazy(5)).ap(Lazy(2)) == Lazy(add).ap(Lazy(5)).ap(Lazy(2))

    assert Lazy(add).ap(Lazy(5)).ap(Lazy(2)).get() == 7

# Generated at 2022-06-12 05:14:12.938412
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def fn(x, y):
        return x + y

    x = Maybe.of(1).bind(lambda x: Lazy.of(2 * x)).ap(Maybe.of(3))
    assert x == Maybe.of(7)


# Generated at 2022-06-12 05:14:18.274646
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x: x + 1).ap(Lazy(lambda x: x + 2)) == Lazy(lambda x: x + 1).bind(lambda x: Lazy(lambda y: x + y)).bind(lambda x: Lazy(lambda y: x + y)), \
        'Lazy.ap failed'



# Generated at 2022-06-12 05:14:32.094643
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(None)

    greater_three = lambda x: x > 3
    greater_two = lambda x: x > 2
    assert Lazy(greater_three) == Lazy(greater_three)
    assert Lazy(greater_three) != Lazy(greater_two)



# Generated at 2022-06-12 05:14:34.535467
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)


# Generated at 2022-06-12 05:14:38.847534
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x: int, y: int) -> int:
        return x + y

    lazy_add = Lazy(add)
    assert lazy_add.ap(Lazy.of(2)).get(1) == 3



# Generated at 2022-06-12 05:14:46.812143
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    result = Lazy.of(10).ap(Box(lambda x: x + 2)).ap(Box(lambda x: x * 2))

    assert result.get() == 24

    result = Lazy.of(10).ap(Box.of(lambda x: x + 2)).ap(Box.of(lambda x: x * 2))

    assert result.get() == 24

    result = Lazy.of(10).ap(Maybe.just(lambda x: x + 2)).ap(Maybe.just(lambda x: x * 2))

    assert result.get() == 24

    result = Lazy.of(10).ap(Right(lambda x: x + 2)).ap(Right(lambda x: x * 2))


# Generated at 2022-06-12 05:14:54.147905
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Tests for method __eq__ in class Lazy

    """
    fn = Lazy(lambda x: x)
    fn_2 = Lazy(lambda x,y: x + y)
    assert fn == fn
    assert not (fn == fn_2)
    assert Lazy.of(1) == Lazy.of(1)
    assert not (Lazy.of(1) == Lazy.of(2))
    assert Lazy.of(None) == Lazy.of(None)
    assert not (Lazy.of(None) == Lazy.of(1))


# Generated at 2022-06-12 05:15:00.123806
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(True) == Lazy.of(True)
    assert Lazy.of(None) == Lazy.of(None)
    assert Lazy.of(2.0) == Lazy.of(2.0)
    assert Lazy.of(1) != Lazy.of(2)

    def func(x):
        return x ** 2

    assert Lazy.of(func) == Lazy.of(func)



# Generated at 2022-06-12 05:15:06.674745
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn_to_bind(x: int) -> Lazy[int, int]:
        return Lazy(lambda _: x + 1)

    lazy = Lazy(lambda _: 1)

    assert lazy.bind(fn_to_bind).get() == 2

    lazy = Lazy(fn_to_bind)
    assert lazy.get() == 2


# Generated at 2022-06-12 05:15:14.194383
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    def fn(arg: str) -> 'Lazy[str, str]':
        return Lazy(lambda x: 'hello ' + x)

    assert Lazy.of('world').bind(fn).get() == 'hello world'
    assert Lazy.of('world').bind(fn).to_box().get() == 'hello world'
    assert Lazy.of('world').bind(fn).to_either().get() == Right('hello world')
    assert Lazy.of('world').bind(fn).to_maybe().get() == Maybe.just('hello world')

# Generated at 2022-06-12 05:15:16.920283
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def fn(v):
        return v + 1

    lazy = Lazy(lambda: 1).map(fn).ap(Lazy(lambda: 2))
    assert lazy.get() == 4

# Generated at 2022-06-12 05:15:19.287947
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def function(value):
        return Lazy.of(value + 1)

    assert Lazy.of(2).bind(function).get() == 3



# Generated at 2022-06-12 05:15:40.639783
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1(*args):  # pylint: disable=unused-argument
        return 1

    def fn2(*args):  # pylint: disable=unused-argument
        return 2

    lazy1 = Lazy(fn1)
    lazy2 = Lazy(fn2)
    assert lazy1 == lazy1
    assert lazy2 == lazy2
    assert (lazy1 == lazy2) is False



# Generated at 2022-06-12 05:15:51.374585
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.functors import Container

    def just(value):
        return Lazy.of(value)

    def add(value_a, value_b):
        return value_a + value_b

    monad_list = [Lazy.of(2), Lazy.of(3), Lazy.of(4), Lazy.of(5)]

    def sum_values(*args):
        return reduce(lambda x, y: x + y, monad_list)

    expected_result = Lazy.of(sum_values)

    sum_monad = reduce(
        lambda x, y: just(add).ap(x).ap(y),
        monad_list,
        just(0)
    )

    container = Lazy.of(sum_monad).map(Container.of)

    assert sum_mon

# Generated at 2022-06-12 05:16:01.775405
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add2_fn(value):
        return value + 2

    def double_fn(value):
        return value * 2

    def triple_fn(value):
        return value * 3

    assert Lazy.of(add2_fn).ap(Lazy.of(10)) == Lazy.of(12)
    assert Lazy.of(add2_fn).ap(Lazy.of(10)).ap(Lazy.of(double_fn)) == Lazy.of(24)
    assert Lazy.of(add2_fn).ap(Lazy.of(10)).ap(Lazy.of(double_fn)).ap(Lazy.of(triple_fn)) == Lazy.of(72)


# Generated at 2022-06-12 05:16:04.234968
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda v: v + 1).get() == 2



# Generated at 2022-06-12 05:16:14.618241
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.data_structures import List

    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(2).bind(lambda x: Lazy.of(x * 2)).get() == 4
    assert Lazy.of(2).bind(lambda x: Lazy.of(x * 2)).bind(lambda x: Lazy.of(x * 2)).get() == 8
    assert Lazy.of(2).bind(lambda x: Lazy.of(x * 2)).bind(lambda x: Lazy.of(x * 2)).bind(lambda x: Lazy.of(x * 2)).get() == 16

# Generated at 2022-06-12 05:16:19.001650
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def not_lazy_fn():
        pass

    def lazy_fn():
        pass

    def lazy_fn_second():
        pass

    lazy = Lazy(lazy_fn)
    lazy_second = Lazy(lazy_fn)
    lazy_third = Lazy(lazy_fn_second)

    assert lazy == lazy_second
    assert lazy_second == lazy
    assert lazy_third != lazy



# Generated at 2022-06-12 05:16:23.283025
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def concat(x, y):
        return str(x) + str(y)

    lazy1 = Lazy(concat)
    lazy2 = Lazy(concat)

    assert lazy1 == lazy2

    lazy2.get(1, 2)

    assert not lazy1 == lazy2



# Generated at 2022-06-12 05:16:33.801787
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def increment(value):
        return value + 10

    def get_data(value_list):
        return value_list[-1]

    assert Lazy(lambda *args: 1).bind(increment).get() == 11
    assert Lazy(lambda *args: 1).bind(lambda_fn=increment).get() == 11
    assert Lazy(lambda *args: 1).bind(lambda_fn=increment, args=(1,)).get() == 1
    assert Lazy(lambda *args: 1).bind(lambda_fn=get_data, args=(1,)).get() == 1
    assert Lazy(lambda *args: 1).bind(lambda_fn=get_data, args=()).get() == 1



# Generated at 2022-06-12 05:16:37.859587
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: '2').get() == '2'


# Generated at 2022-06-12 05:16:48.142967
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    class ExampleClass(object):
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return isinstance(other, ExampleClass) and self.value == other.value

        def __str__(self):
            return 'ExampleClass({})'.format(self.value)

    def example_constructor_fn(value):
        return ExampleClass(value)

    from pymonet.monad import Monad

    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is True
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1)) is False
    assert Lazy(lambda x: x).__eq__(Monad(1)) is False

# Generated at 2022-06-12 05:17:27.031978
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 0) == Lazy(lambda: 0)
    assert Lazy(lambda: 0).map(lambda x: x + 1) == Lazy(lambda: 0).map(lambda x: x + 1)
    assert Lazy(lambda: 0) == Lazy(lambda: 0).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy(lambda: 0) != Lazy(lambda: 1)
    assert Lazy(lambda: 0) != object()



# Generated at 2022-06-12 05:17:34.533892
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def make_Lazy(x, y):
        def bogus(*args):
            return x + y

        return Lazy(bogus)

    make_Lazy_1 = make_Lazy(1, 2)
    make_Lazy_2 = make_Lazy(1, 2)
    make_Lazy_3 = make_Lazy(3, 2)
    make_Lazy_4 = make_Lazy(1, 4)

    assert make_Lazy_1 == make_Lazy_2
    assert make_Lazy_1 != make_Lazy_3
    assert make_Lazy_1 != make_Lazy_4



# Generated at 2022-06-12 05:17:36.054483
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert callable(Lazy(lambda: 1).get)



# Generated at 2022-06-12 05:17:47.779038
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def constructor_fn(*args):
        return args

    def mapper(value):
        return value

    def mapper2(value):
        return value + 1

    def mapper3(value):
        return value + 2

    assert Lazy(constructor_fn).bind(mapper).constructor_fn(1, 2, 3) == (1, 2, 3)
    assert Lazy(constructor_fn).bind(mapper).constructor_fn(2, 3) == (2, 3)
    assert Lazy(constructor_fn).bind(mapper).constructor_fn(3) == (3,)
    assert Lazy(constructor_fn).bind(mapper).constructor_fn() == tuple()


# Generated at 2022-06-12 05:17:52.512693
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy = Lazy.of(lambda x: x * 2)
    assert Lazy.of(2).ap(lazy).get() == 4
    assert Lazy.of(2).ap(Lazy.of(None)).get() == 2
    assert Lazy.of(None).ap(Lazy.of(2)).get() is None


# Generated at 2022-06-12 05:18:03.573693
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.functor_tests.tests_functor import add_two
    from pymonet.monad import Monad
    from pymonet.monad_tests.tests_monad import add_two_using_bind

    assert Lazy(add_two) == Lazy(add_two)
    assert Lazy(add_two) != Lazy(add_two_using_bind)  # different calls to fold
    assert Lazy(add_two) != Lazy(Functor(add_two).map(add_two))  # different calls to fold
    assert Lazy(add_two) != Lazy(Monad(add_two).map(add_two))  # different calls to fold

# Generated at 2022-06-12 05:18:04.872400
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1


# Generated at 2022-06-12 05:18:07.968471
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1).__eq__(Lazy(lambda: 1))
    assert not Lazy(lambda: 1).__eq__(Lazy(lambda: 2))
    assert not Lazy(lambda: 1).__eq__(None)


# Generated at 2022-06-12 05:18:14.441446
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_function(x):
        assert x == 1
        return int(x) * 2

    some_Lazy = Lazy(test_function)
    other_Lazy = Lazy(test_function)
    third_Lazy = Lazy(lambda x: x)

    assert some_Lazy == other_Lazy
    assert some_Lazy != third_Lazy



# Generated at 2022-06-12 05:18:20.884045
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # class for testing method bind
    class TestClass():
        def __init__(self, value) -> None:
            self.value = value

        def method(self, arg_first, arg_second) -> int:
            return self.value * arg_first * arg_second

    # test 1
    instance = TestClass(2)
    lazy_instance = Lazy.of(instance)
    lazy_fn = lazy_instance.bind(lambda instance: Lazy.of(instance.method))

    assert lazy_fn.get(2, 3) == 24
    assert lazy_instance.get() == instance

    # test 2
    lazy_instance = Lazy.of(instance)
    lazy_fn = lazy_instance.bind(lambda instance: Lazy.of(instance.method(1, 2)))


# Generated at 2022-06-12 05:19:23.992922
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn():
        return 'test'

    assert Lazy(test_fn).get() == 'test'


# Generated at 2022-06-12 05:19:29.841569
# Unit test for method get of class Lazy
def test_Lazy_get():
    def lambda_fn(x):
        return x + 'str'

    lazy = Lazy(lambda_fn)

    assert lazy.get('val') == lambda_fn('val')
    assert lazy.value is None
    assert lazy.is_evaluated is False

    lazy.get()

    assert lazy.value == 'valstr'
    assert lazy.is_evaluated is True



# Generated at 2022-06-12 05:19:36.434155
# Unit test for method get of class Lazy
def test_Lazy_get():
    data = 1

    assert Lazy.of(data).get() == data
    assert Lazy.of(data).get(1, 2, 3) == data

    def sum_args(a, b, c):
        return a + b + c

    assert Lazy(sum_args).get(1, 2, 3) == 6
    assert Lazy(sum_args).get(1, 2, 3) == Lazy(sum_args).get(1, 2, 3)



# Generated at 2022-06-12 05:19:41.081162
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    assert Lazy.of(3).map(lambda x: x * 3).get() == 9
    assert Lazy.of(3).map(lambda x: x * 3).get() == 9

    assert Lazy.of(3).map(lambda x: x * 3).is_evaluated is True



# Generated at 2022-06-12 05:19:52.749798
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Validation
    from pymonet.monad_either import Right, Left
    from pymonet.monad_maybe import Maybe

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda x: x)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)

    assert Lazy(lambda: 1).to_box() == Box(1)
    assert Lazy(lambda: 1).to_either() == Right(1)
    assert Lazy(lambda: 1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-12 05:19:55.199288
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert (
        Lazy.of(2).map(lambda x: x * 2)
        != Lazy.of(2).map(lambda x: x * 2).map(lambda x: x + 4)
    ), "Two Lazy which is evaluated and have another values should not be equal"


# Generated at 2022-06-12 05:19:58.346988
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet import Lazy

    def fn():
        return 1

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)

    assert lazy_1 == lazy_2


# Generated at 2022-06-12 05:20:02.492896
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def value_fn(a, b, c):
        return a * b * c

    lazy_val_fn = Lazy(value_fn)

    assert lazy_val_fn.bind(lambda _: Lazy(lambda *args: 'done')).get(3, 4, 5) == 'done'

# Generated at 2022-06-12 05:20:07.929687
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box

    lazy_1 = Lazy.of(1)
    lazy_2 = Lazy.of(2)
    lazy_3 = Lazy.of(1)

    assert lazy_1 != lazy_2
    assert lazy_1 == lazy_3
    assert lazy_3 != lazy_2
    assert lazy_3 != Box.of(3)



# Generated at 2022-06-12 05:20:10.841474
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def fn():
        return 'message'

    assert Lazy(fn).get() == fn()
