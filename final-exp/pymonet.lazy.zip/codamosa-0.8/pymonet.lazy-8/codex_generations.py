

# Generated at 2022-06-12 05:11:11.224226
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def fn(x: Lazy) -> Lazy[bool, bool]:
        return Lazy(lambda: x.get() is True)

    assert Lazy(lambda: True).bind(fn).get() is True
    assert Lazy(lambda: False).bind(fn).get() is False

    assert Lazy(lambda: True).bind(
        lambda x: Lazy(lambda: True)).bind(
        lambda x: Lazy(lambda: True)).get() is True

    assert Lazy(lambda: False).bind(
        lambda x: Lazy(lambda: x)).bind(
        lambda x: Lazy(lambda: False)).get() is False



# Generated at 2022-06-12 05:11:13.919159
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def double(n):
        return n * 2

    def add(n, m):
        return n + m

    lazy_1 = Lazy(double)
    lazy_2 = Lazy(add)
    lazy_3 = Lazy(double)

    assert lazy_1 != lazy_2
    assert lazy_1 == lazy_3

# Generated at 2022-06-12 05:11:19.897864
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from hamcrest import assert_that, is_
    from random import randint

    value = randint(0, 1000)
    lazy_1 = Lazy.of(value)
    lazy_2 = Lazy.of(value)

    assert_that(lazy_1, is_(lazy_2))
    assert_that(lazy_1, is_(not Lazy.of(value + 1)))


# Generated at 2022-06-12 05:11:32.052651
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # pylint: disable=W0612
    global test_Lazy_bind  # pylint: disable=W0603
    test_Lazy_bind = True

    def get_lazy_with_one(value):
        return Lazy.of(value)

    assert Lazy(lambda: True).bind(lambda x: Lazy.of(x)).get()
    assert Lazy(lambda: False).bind(lambda x: Lazy.of(x)).get() is False

    assert Lazy(lambda: 1).bind(get_lazy_with_one).get() == 1
    assert Lazy(lambda: 3).bind(get_lazy_with_one).get() == 3
    assert Lazy(lambda: 'test').bind(get_lazy_with_one).get() == 'test'

# Generated at 2022-06-12 05:11:36.457764
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy.of(3).get(3) == 3
    assert Lazy.of([1, 2]).get(3) == [1, 2]
    assert Lazy.of([1, [2, 3]]).get(3) == [1, [2, 3]]


# Generated at 2022-06-12 05:11:47.188940
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 'a') == Lazy(lambda: 'a')
    assert not Lazy(lambda: 'a') == Lazy(lambda: 'b')

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert not Lazy(lambda: 1) == Lazy(lambda: 2)

    assert not Lazy(lambda: [1, 2]) == Lazy(lambda: [1, 2])
    assert not Lazy(lambda: [1, 2]) == Lazy(lambda: [2, 1])



# Generated at 2022-06-12 05:11:56.433808
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation

    def is_valid_number(number):
        return Validation.of(number > 0)

    def reduce_to_valid(left, right):
        return Validation.of(left * right)

    lazy_validation_of_is_valid_number_5 = Lazy.of(is_valid_number(5))
    lazy_validation_of_is_valid_number_2 = Lazy.of(is_valid_number(2))

    lazy_ap = lazy_validation_of_is_valid_number_5.ap(lazy_validation_of_is_valid_number_2)
    assert lazy_ap.get() == True

    lazy_ap = lazy_ap.map(reduce_to_valid)
    assert lazy_ap.get() == 10

# Generated at 2022-06-12 05:12:08.171911
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a, b, c):
        return a + b + c

    from pymonet.maybe import Maybe

    lazy_maybe_add = Lazy(lambda a, b, c, add_argument: Maybe.just(add(a, b, c) + add_argument))

    assert lazy_maybe_add.ap(Lazy(lambda: 1)).get(1, 2, 3) == 7
    assert lazy_maybe_add.ap(Lazy(lambda: 0)) == Lazy.of(6)

    def add_error(a, b, c):
        raise Exception("Oh no...")

    lazy_maybe_add = Lazy(lambda a, b, c, add_argument: Maybe.just(add_error(a, b, c) + add_argument))


# Generated at 2022-06-12 05:12:19.737867
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f1 = lambda x: x + 10
    f2 = lambda x: x + 20
    f3 = lambda x: x + 30
    lazy = Lazy(f1).map(f2).map(f3)
    lazy_copy = Lazy(f1).map(f2).map(f3)
    lazy_with_other_f1 = Lazy(f2).map(f2).map(f3)
    lazy_with_other_f2 = Lazy(f1).map(f3).map(f3)
    lazy_with_other_f3 = Lazy(f1).map(f2).map(f1)
    assert lazy == lazy_copy
    assert lazy != lazy_with_other_f1
    assert lazy != lazy_with_other_f2
    assert lazy != lazy_with_other

# Generated at 2022-06-12 05:12:30.668897
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Maybe.just(1).ap(Maybe.just(lambda a: a + 1)) == Maybe.just(2)
    assert Maybe.nothing().ap(Maybe.just(lambda a: a + 1)) == Maybe.nothing()
    assert Maybe.just(1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(1).ap(Maybe.just(lambda a: a * 2)).ap(Maybe.just(lambda a: a * 2)) == Maybe.just(4)
    assert Maybe.just(1).ap(Maybe.just(lambda a: a * 2)).ap(Maybe.nothing()) == Maybe.nothing()

    assert Right(1).ap(Right(lambda a: a + 1)) == Right(2)
    assert Right(1).ap

# Generated at 2022-06-12 05:12:34.092106
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1



# Generated at 2022-06-12 05:12:35.201031
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy.of('result')

    assert lazy.get() == 'result'



# Generated at 2022-06-12 05:12:41.897112
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def fn1(arg: str) -> Maybe[int]:
        return Maybe.just(int(arg))

    def fn2(arg: int) -> Maybe[str]:
        return Maybe.just(str(arg))

    def compose(f, g):
        return lambda arg: g(f(arg))

    composed_fn = compose(fn1, fn2)

    assert (Lazy.of('42').ap(Lazy.of(composed_fn))).get() == Maybe.just('42')

# Generated at 2022-06-12 05:12:48.475045
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def inner_test(test_value, test_exception):
        def test_lazy_constant(test_value: object) -> Lazy[None, object]:
            return Lazy.of(test_value)

        def test_lazy_value(test_exception: Exception) -> Lazy[None, Exception]:
            def test_lazy_fn() -> Exception:
                raise test_exception

            return Lazy(test_lazy_fn)

        def test_maybe_with_value(value: object) -> Lazy[object, object]:
            return Maybe.just(value)

        def test_maybe_with_nothing(value: object) -> Lazy[object, object]:
            return Maybe.nothing()


# Generated at 2022-06-12 05:12:51.731439
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 'value').get() == 'value'
    assert Lazy(lambda a, b: a + b).get(1, 'a') == '1a'

# Generated at 2022-06-12 05:13:01.915016
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.monad_try import Try

    assert Lazy(lambda: Try.success('a').to_either()) == Lazy(lambda: Try.success('a').to_either())
    assert Lazy(lambda: Try.success(1)).bind(lambda x: Lazy(lambda: Try.success(x + 1))) == Lazy(lambda: Try.success(2))
    assert Lazy(lambda: Try.failure('error').to_either()).bind(lambda x: Lazy(lambda: Right(x + 1))) == Lazy(
        lambda: Right(1))
    assert Lazy(lambda: Try.failure('error').to_either()).bind(lambda x: Lazy(lambda: Right(x + 1))).is_evaluated == True



# Generated at 2022-06-12 05:13:04.263418
# Unit test for method get of class Lazy
def test_Lazy_get():
    double = lambda x: x * 2
    assert Lazy(double).get(1) == 2


# Generated at 2022-06-12 05:13:09.426217
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 3) == Lazy(lambda: 3)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 2)
    assert Lazy(lambda: 3) != 3

    def twice(x):
        return x * 2
    assert Lazy(twice) != Lazy(lambda x: x * 2)

# Generated at 2022-06-12 05:13:15.173601
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 0) == Lazy(lambda: 0)
    assert not Lazy(lambda: 0) == Lazy(lambda: 1)
    assert not Lazy(lambda: 0) == Lazy(lambda: None)
    assert not Lazy(lambda: 0) == Lazy(lambda: '')
    assert not Lazy(lambda: 0) == ''


# Generated at 2022-06-12 05:13:16.586920
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(10).get() == 10



# Generated at 2022-06-12 05:13:29.352558
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    def f(value):
        return Lazy.of(value)

    def g(value):
        return value

    def h(value):
        return Maybe.just(value)

    def i(value):
        return value + 1

    def l(value):
        return Box(value)

    assert Lazy(lambda value: value).map(g) == Lazy(lambda value: value).map(g)
    assert Lazy(lambda: 10).map(i).get() == 11
    assert Lazy(lambda value: Box(value)).map(lambda box: box.map(i)).get(10).get() == 11

# Generated at 2022-06-12 05:13:37.386221
# Unit test for method map of class Lazy
def test_Lazy_map():
    def lazy_fn(i):  # pylint: disable=unused-argument
        return 1

    def mapper(v):
        return v + 1

    assert Lazy(lazy_fn).map(mapper).get() == 2, 'Lazy map fails'
    assert Lazy.of(1).get() == 1, 'Lazy of method fails'
    assert Lazy(lambda: 1).to_box().get() == 1, 'Lazy to_box method fails'



# Generated at 2022-06-12 05:13:48.141320
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    fn1 = lambda: 'fn1-out'
    fn2 = lambda: 'fn2-out'

    lazy_fn1_true = Lazy(fn1).bind(lambda x: Lazy.of(x)).bind(lambda x: Lazy.of(x))
    lazy_fn1_false = Lazy(fn1).bind(lambda x: Lazy.of(x)).bind(lambda x: Lazy.of(not x))
    lazy_fn2_true = Lazy(fn2).bind(lambda x: Lazy.of(x)).bind(lambda x: Lazy.of(x))
    lazy_fn2_false = Lazy(fn2).bind(lambda x: Lazy.of(x)).bind(lambda x: Lazy.of(not x))
    lazy_fn1_true_not_evaluated = Lazy

# Generated at 2022-06-12 05:13:56.370310
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    class TestLazy(Lazy[T, U], Functor[U, W], Applicative[W]):
        def __init__(self, constructor_fn: Callable[[T], U]) -> None:
            super().__init__(constructor_fn)

        def map(self, mapper: Callable[[U], W]) -> Lazy[T, W]:
            return super().map(mapper)

        def ap(self, applicative):
            return super().ap(applicative)

        def bind(self, fn: 'Callable[[U], Lazy[U, W]]') -> 'Lazy[T, W]':
            return super().bind(fn)

        def get(self, *args):
            return super

# Generated at 2022-06-12 05:14:05.811086
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test function for Lazy class bind function
    """
    lazy = Lazy(lambda: 1)
    increment = lambda x: x + 1

    assert lazy.bind(lambda x: Lazy(lambda: increment(x))).get() == 2
    assert lazy.bind(lambda x: Lazy(lambda: increment(x))).to_box().get() == 2
    assert lazy.bind(lambda x: Lazy(lambda: increment(x))).to_maybe().get() == 2
    assert lazy.bind(lambda x: Lazy(lambda: increment(x))).to_try().get() == 2
    assert lazy.bind(lambda x: Lazy(lambda: increment(x))).to_validation().get() == 2
    assert lazy.bind(lambda x: Lazy(lambda: increment(x))).to_either().get()

# Generated at 2022-06-12 05:14:10.953469
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(arg: str) -> str:
        return 'fn(' + arg + ')'

    lazy = Lazy(fn)

    assert lazy.get('arg') == 'fn(arg)'
    assert lazy.get('random_arg') == 'fn(random_arg)'
    assert lazy.get('arg') == 'fn(arg)'



# Generated at 2022-06-12 05:14:14.594878
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def func(a):
        return a

    assert Lazy(func) == Lazy(func)
    assert Lazy(func) != Lazy(lambda a: a + 1)


# Generated at 2022-06-12 05:14:17.544740
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda x: x)

    assert lazy.get(1) == 1
    assert lazy.get(2) == 1

# Generated at 2022-06-12 05:14:24.579926
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda a: a) == Lazy(lambda a: a)
    assert Lazy(lambda a: a) != Lazy(lambda a: a + 1)

    assert Lazy(lambda a: a).map(lambda x: x) == Lazy(lambda a: a).map(lambda x: x)

    assert Lazy(lambda a: a).map(lambda x: x) == Lazy(lambda a: a).map(lambda x: x + 1).map(lambda x: x - 1)

    assert Lazy(lambda a: a).map(lambda x: x) != Lazy(lambda a: a).map(lambda x: x + 1)


# Generated at 2022-06-12 05:14:31.074870
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def func1(x):
        return x

    def func2(x):
        return x

    def func3(x):
        return x + 1

    assert Lazy(func1) == Lazy(func1)
    assert Lazy(func1).get(1) == 1
    assert Lazy(func1) != Lazy(func2)
    assert Lazy(func1).get(2) != 3
    assert Lazy(func3).get(2) != 4


# Generated at 2022-06-12 05:14:38.686919
# Unit test for method get of class Lazy
def test_Lazy_get():
    def five():
        return 5

    assert Lazy(five).get() == 5
    assert Lazy(five).get(1, 2, 3) == 5



# Generated at 2022-06-12 05:14:42.654420
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != 1



# Generated at 2022-06-12 05:14:48.156757
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of('').get() == Lazy.of('').to_box().get() == Lazy.of('').to_either().get() == Lazy.of('').to_maybe().get() == Lazy.of('').to_try().get() == Lazy.of('').to_validation().get()

# Generated at 2022-06-12 05:14:56.386362
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Call map for Lazy with mapper function. Mapper function will be called only when Lazy is evaluated.
    """
    from pymonet.box import Box

    assert Lazy(lambda: "foo").ap(Box(lambda x: x + 'bar')).get() == 'foobar'
    assert Lazy(lambda: "foo").ap(Box(lambda x: x + 'bar')).to_box().get() == 'foobar'
    assert Lazy(lambda: "foo").ap(Box(lambda x: x + 'bar')).to_either().get() == 'foobar'
    assert Lazy(lambda: "foo").ap(Box(lambda x: x + 'bar')).to_maybe().get() == 'foobar'

# Generated at 2022-06-12 05:15:08.351819
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def function_1a(argument_1a: int) -> int:
        return argument_1a

    def function_1b(argument_1b: int) -> int:
        return argument_1b

    def function_2(argument_2: int) -> str:
        return str(argument_2)

    lazy_1a = Lazy(function_1a)
    lazy_1b = Lazy(function_1a)
    lazy_2 = Lazy(function_2)

    assert lazy_1a == lazy_1a
    assert lazy_1a == lazy_1b
    assert lazy_1a != lazy_2
    assert lazy_2 != lazy_1a
    assert lazy_1a != lazy_1b.map(function_2)

# Generated at 2022-06-12 05:15:12.440536
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(a: int, b: int, c: int) -> int:
        return a + b + c

    assert Lazy(fn).get(1, 2, 3) == 6



# Generated at 2022-06-12 05:15:21.499268
# Unit test for method __eq__ of class Lazy

# Generated at 2022-06-12 05:15:28.177580
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add4(x):
        return x + 4

    assert Lazy.of(10).bind(add4).constructor_fn(None) == 14
    assert Lazy.of(10).bind(lambda x: x).constructor_fn(None) == 10
    assert Lazy.of(10).bind(lambda x: x).get() == 10


# Generated at 2022-06-12 05:15:39.182215
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Left, Right
    from pymonet.box import Box

    assert Lazy.of(2).ap(Lazy.of(lambda x: x * x)) == Lazy.of(4)
    assert Lazy.of(2).ap(Box.of(lambda x: x * x)).get() == 4
    assert Lazy.of(2).ap(Right(lambda x: x * x)).get() == 4
    assert Lazy.of(2).ap(Left(lambda x: x * x)) == Lazy.of(2)
    assert Lazy.of(2).ap(Lazy.of(lambda x: x * x)).ap(Lazy.of(lambda x: x + 3)) == Lazy.of(7)

# Generated at 2022-06-12 05:15:42.713133
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    fn1 = lambda: 1
    fn2 = lambda: 2

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)

# Generated at 2022-06-12 05:15:55.778077
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def cl(x):
        return Lazy(lambda: x + 1)

    a = Lazy(lambda: 1)

    b = a.bind(cl)
    assert b.get() == 2

    b = a.bind(cl).bind(cl)
    assert b.get() == 3



# Generated at 2022-06-12 05:16:03.320845
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def test(func1: Lazy, func2: Lazy, expected: bool):
        actual = func1 == func2

        assert actual is expected, \
            'Expected:{} Actual:{} for args: {}, {}'.format(expected, actual, func1, func2)

    test(Lazy(lambda: 2), Lazy(lambda: 2), True)
    test(Lazy(lambda: 2), Lazy(lambda: 3), False)
    test(Lazy(lambda: 2), Lazy(lambda: 2).get(), False)



# Generated at 2022-06-12 05:16:05.628001
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def function():
        return 1

    def function2():
        return 1

    lazy = Lazy(function)
    lazy2 = Lazy(function2)

    assert lazy == lazy2

# Generated at 2022-06-12 05:16:15.799395
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_list import List

    def sum_list(list_: list):
        return sum(list_)

    def list_to_list(list_: list):
        return List(list_)

    list_lazy = Lazy(list_to_list)
    assert list_lazy.ap(Lazy(sum_list)) == Lazy(list_to_list).map(sum_list)

    user_list_lazy = Lazy(lambda *args: [1, 2, 3])
    assert list_lazy.ap(user_list_lazy) == Lazy(lambda *args: List([1, 2, 3])).map(lambda a_list: sum(a_list))


# Generated at 2022-06-12 05:16:17.519016
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy(lambda: 1)
    assert lazy.bind(lambda x: Lazy(lambda: x + x)).get() == 2


# Generated at 2022-06-12 05:16:21.887189
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    def add(a):
        return lambda b: a + b

    lazy = Lazy(lambda x: x + 1)
    lazy = lazy.ap(Lazy(add(2)))
    assert lazy.get(2) == 5

# Generated at 2022-06-12 05:16:24.051878
# Unit test for method map of class Lazy
def test_Lazy_map():
    value = 1
    lazy = Lazy.of(value)

    assert lazy.map(lambda x: x + 2).get() == 3



# Generated at 2022-06-12 05:16:34.568378
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(lambda: 1) == Lazy.of(lambda: 1)
    assert Lazy.of(lambda: 1) != Lazy.of(lambda: 2)
    assert Lazy.of(lambda: 1) != Lazy.of(lambda: 1).bind(lambda x: Lazy.of(lambda: x + 1))
    assert Lazy.of(lambda: 1).bind(lambda x: Lazy.of(lambda: x + 1)) == Lazy.of(lambda: 2)
    assert Lazy.of(lambda: 1).bind(lambda x: Lazy.of(lambda: x + 1)) != Lazy.of(lambda: 1).bind(lambda x: Lazy.of(lambda: x + 2))

# Generated at 2022-06-12 05:16:39.224880
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """Unit test for method __eq__ of class Lazy"""
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda x: x) == Lazy(lambda y: y)



# Generated at 2022-06-12 05:16:47.702657
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = Lazy(lambda t: t).map(lambda t: 2*t)
    f1 = Lazy(lambda t: t).map(lambda t: 2*t)
    
    assert f == f1
    assert f.get(6) == 12
    assert f.get(5) == 10
    assert f.get(7) == 14
        
    f = Lazy(lambda t: t)
    f1 = Lazy(lambda t: t)
    assert f == f1
    assert f.get(6) == 6
    assert f.get(5) == 5
    assert f.get(7) == 7


# Generated at 2022-06-12 05:17:15.582701
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fun_1(*args):
        return "value"
    def fun_2(*args):
        return "value"
    def fun_3(*args):
        return "value"
    lazy_1 = Lazy(fun_1)
    lazy_2 = Lazy(fun_2)
    lazy_3 = Lazy(fun_3)
    assert lazy_1 != lazy_2
    assert lazy_2 != lazy_3
    assert lazy_1 != lazy_3
    lazy_2.get()
    lazy_3.get()
    assert lazy_1 != lazy_2
    assert lazy_2 != lazy_3
    assert lazy_1 != lazy_3
    lazy_1.get()
    lazy_2.get()
    assert lazy_1 == lazy_2
    assert lazy_2 == lazy_3
    assert lazy

# Generated at 2022-06-12 05:17:20.717981
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    try_lazy = Lazy(lambda *args: Try.of(lambda *args: 10))
    maybe_lazy = Lazy(lambda *args: Maybe.of(9))

    assert Maybe.of(9) == maybe_lazy.ap(try_lazy).to_maybe()



# Generated at 2022-06-12 05:17:30.546653
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(num: int) -> int:
        return num + 1

    def add_two(num: int) -> int:
        return num + 2

    def add_three(num: int) -> int:
        return num + 3

    # Create Lazy object with function
    lazy: Lazy[int, int] = Lazy(add_one)

    # Test if map works properly
    assert Lazy.of(10).get() == Lazy.of(10).map(add_one).map(add_two).map(add_three).get()

    # Test if map returns new Lazy object
    assert Lazy.of(10).map(add_one) != lazy


# Generated at 2022-06-12 05:17:39.960548
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.functor import Functor
    from pymonet.functor import FunctorLaws

    lazy = Lazy(lambda *args: args[0] + 2)

    new_lazy = lazy.map(lambda n: n + 3)

    assert FunctorLaws.identity(lazy)
    assert FunctorLaws.composition(lazy, lambda n: -n, lambda n: n + 3)
    assert new_lazy.is_evaluated is False, "map method mustn't be call constructor_fn"
    assert new_lazy.constructor_fn(1) == 6



# Generated at 2022-06-12 05:17:48.154665
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe
    from pymonet import functors

    add_five = Maybe.just(5)
    seven = Maybe.just(2)

    test_lazy = Lazy.of(functors.add)
    assert test_lazy.ap(add_five).ap(seven).to_maybe() == Maybe.just(7)
    assert test_lazy.ap(Maybe.nothing()).ap(seven).to_maybe() == Maybe.nothing()
    assert test_lazy.ap(add_five).ap(Maybe.nothing()).to_maybe() == Maybe.nothing()



# Generated at 2022-06-12 05:17:59.225838
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def add_1(x):
        return x + 1

    def add_2(x):
        return x + 2

    def add_3(x):
        return x + 3

    assert (
        Lazy(add_1).bind(lambda x: Lazy(add_2).bind(lambda y: Lazy(add_3).map(lambda z: x + y + z))).fold()
        == 7
    )
    assert Lazy(add_1).bind(lambda x: Lazy(add_2).map(lambda y: x + y)).bind(add_3).fold() == 7
    assert Lazy(add_1).bind(lambda x: Lazy(add_2).map(lambda y: x + y)).bind(add_3).fold() == 7

# Generated at 2022-06-12 05:18:03.530051
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def constructor_function(*args):
        return 'value'

    lazy = Lazy(constructor_function)
    assert lazy == lazy
    assert Lazy.of('value') == Lazy.of('value')
    assert Lazy.of('value') != Lazy.of('other_value')



# Generated at 2022-06-12 05:18:05.162555
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(2).bind(lambda x: Lazy.of(x+4)).get() == 6

# Generated at 2022-06-12 05:18:10.979833
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """Unit test for method __eq__ of class Lazy"""
    assert Lazy.of(1) == Lazy.of(1)

    # test for constructor
    not_equal_lazy = Lazy(lambda: 1)
    assert not_equal_lazy != Lazy.of(1)
    assert not_equal_lazy != Lazy.of(2)

    # test for evaluation
    assert not_equal_lazy != not_equal_lazy.map(lambda x: 1)

    # test for value
    assert Lazy.of(1) != Lazy.of(2)



# Generated at 2022-06-12 05:18:12.299754
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    import pytest  # type: ignore

    def fn():
        pass

    assert Lazy(fn) == Lazy(fn) is False



# Generated at 2022-06-12 05:18:54.659460
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_case():
        assert Lazy.of(1) == Lazy.of(1)
        assert Lazy.of(1) != Lazy.of(2)
        assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
        assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) != Lazy.of(1)
        assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) != Lazy.of(2)

    test_case()



# Generated at 2022-06-12 05:18:59.293974
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda x: x + 2) == Lazy(lambda x: x + 2)
    assert Lazy(lambda x: x + 2) != Lazy(lambda x: x + 3)



# Generated at 2022-06-12 05:19:09.203110
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for method get of class Lazy
    """
    def to_test_1():
        """
        Function as argument of Lazy.
        """
        return 1 + 2 + 3

    lazy1 = Lazy(to_test_1)
    assert lazy1.get() == 6

    def to_test_2(a):
        """
        Function as argument of Lazy with argument.
        """
        return a + 2

    lazy2 = Lazy(to_test_2)
    assert lazy2.get(3) == 5

    def to_test_3(a, b):
        """
        Function as argument of Lazy with two arguments.
        """
        return a + b

    lazy3 = Lazy(to_test_3)
    assert lazy3.get(1, 2) == 3



# Generated at 2022-06-12 05:19:19.331485
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def identity(x):
        return x

    def other(x):
        return x * 2

    lazy_of_3 = Lazy.of(3)
    lazy_of_3_same = Lazy.of(3)
    lazy_of_identity = Lazy(identity)
    lazy_of_identity_same = Lazy(identity)

    assert lazy_of_3 != lazy_of_3_same
    assert lazy_of_3 != lazy_of_identity
    assert lazy_of_3 == lazy_of_3
    assert lazy_of_3_same == lazy_of_3_same
    assert lazy_of_identity == lazy_of_identity
    assert lazy_of_identity == lazy_of_identity_same
    assert lazy_of_identity != lazy_of_3

# Generated at 2022-06-12 05:19:22.643833
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def foo():
        return 1

    lazy1 = Lazy(foo)
    lazy2 = Lazy(foo)

    assert lazy1 == lazy2

# Generated at 2022-06-12 05:19:28.711851
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_validation import Validation

    def _test(x: Maybe[int]) -> Validation[int]:
        return Validation.of(x.get)

    lazy_either = Lazy(lambda: Maybe.just(3))

    assert _test(lazy_either.to_maybe()) == Validation.success(3)

# Generated at 2022-06-12 05:19:32.852721
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(0).ap(Lazy.of(lambda x: x * 2)) == Lazy.of(0)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)) == Lazy.of(3)



# Generated at 2022-06-12 05:19:35.963836
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def const_return(x: int) -> Lazy:
        return Lazy(lambda *__: x)

    assert Lazy(lambda *__: 1).bind(const_return) == const_return(1)



# Generated at 2022-06-12 05:19:40.061111
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def f(x):
        return x

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(lambda x: x)
    assert Lazy(f) == Lazy(f).map(lambda x: x)
    assert Lazy(f) != Lazy(f).map(lambda x: x + 1)



# Generated at 2022-06-12 05:19:46.753380
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda a: a + 1).ap(Lazy.of(1)).get() == 2
    assert Lazy.of(lambda a: a + 1).ap(Lazy.of(1).to_box()).get() == 2
    assert Lazy.of(lambda a: a + 1).ap(Lazy.of(1).to_either()).get() == 2
    assert Lazy.of(lambda a: a + 1).ap(Lazy.of(1).to_maybe()).get() == 2
    assert Lazy.of(lambda a: a + 1).ap(Lazy.of(1).to_try()).get() == 2
    assert Lazy.of(lambda a: a + 1).ap(Lazy.of(1).to_validation()).get() == 2



# Generated at 2022-06-12 05:21:06.655574
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # GIVEN set of Lazy with any type of constructor_fn
    lazy1 = Lazy(lambda e: e)
    lazy2 = Lazy(lambda e: e)
    lazy3_1 = Lazy(lambda e: e + 1)
    lazy3_2 = Lazy(lambda e: e + 2)
    lazy4 = Lazy(lambda e: e - e)
    lazy5 = Lazy(lambda e: e * e)
    lazy6 = Lazy(lambda e: e + e)
    lazy7 = Lazy(lambda e: e + e)

    # WHEN check equality where different Lazy are the same and similar are different
    are_equal1 = lazy1 == lazy1
    are_equal2 = lazy2 == lazy2
    are_equal3 = lazy3_1 == lazy3_2
    are_equal4