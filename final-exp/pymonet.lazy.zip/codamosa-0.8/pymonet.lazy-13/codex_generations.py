

# Generated at 2022-06-12 05:11:11.401921
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def function(argument):
        return 42 + argument

    def mapper_function(argument):
        return argument / 2

    test_input_args = ((['argument'], [function]), (['wrapped_lazy'], [Lazy]))
    test_inputs = product(*test_input_args)
    test_outputs = product(['wrapped_lazy'], [Lazy])
    test_data = [(test_input, test_output) for test_input, test_output in zip(test_inputs, test_outputs)]


# Generated at 2022-06-12 05:11:14.196083
# Unit test for method get of class Lazy
def test_Lazy_get():
    a = Lazy.of(10)
    assert a.get() == 10



# Generated at 2022-06-12 05:11:18.273986
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy = Lazy.of(2)
    assert lazy.get() == lazy.map(lambda x: x).get()

    lazy = Lazy.of(2)
    assert lazy.get() * 2 == lazy.map(lambda x: x * 2).get()



# Generated at 2022-06-12 05:11:24.719611
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    result = Lazy(lambda x: x) == Lazy(lambda x: x)
    assert result is False, 'Expected False and got {0}'.format(result)

    result = Lazy(lambda x: x).map(lambda x: x + 1) == Lazy(lambda x: x).map(lambda x: x + 1)
    assert result is False, 'Expected False and got {0}'.format(result)

    result = Lazy(lambda x: x)._compute_value() == 1
    assert result is True, 'Expected True and got {0}'.format(result)

    result = Lazy(lambda x: x).map(lambda x: x + 1)._compute_value() == 2
    assert result is True, 'Expected True and got {0}'.format(result)


# Generated at 2022-06-12 05:11:28.819801
# Unit test for method get of class Lazy
def test_Lazy_get():
    constructor = lambda value: value
    assert Lazy(constructor).get(1) == 1
    assert Lazy(constructor).get(1) == 1

# Unit tests for method map of class Lazy

# Generated at 2022-06-12 05:11:35.666464
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def my_constructor_fn():
        return 10

    constructor_fn = Lazy(my_constructor_fn)
    my_lazy = Lazy(my_constructor_fn)
    empty_lazy = Lazy(lambda: None)

    assert constructor_fn == constructor_fn
    assert constructor_fn == my_lazy
    assert empty_lazy == empty_lazy
    assert constructor_fn != empty_lazy

# Generated at 2022-06-12 05:11:50.405126
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    try1 = Lazy(lambda *args: Try.of(int, *args))
    try2 = Lazy(lambda *args: Try.of(int, *args))
    try3 = Lazy(lambda *args: Try.of(float, *args))
    try4 = Lazy(lambda *args: Try.of(int, *args))
    try4.get(1)

    assert try1 != try2
    assert try1 != try3
    assert try1 != try4
    assert try2 != try3
    assert try2 != try4
    assert try3 != try4

    assert try1 != 1
    assert try1 != 'ala'
    assert try1 != []
    assert try1 != {}
    assert try1 != try1.constructor_fn


#

# Generated at 2022-06-12 05:11:56.234312
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def module():
        return 'module'

    def module2():
        return 'module'

    lazy = Lazy(module)
    lazy2 = Lazy(module)
    lazy3 = Lazy(module2)
    lazy4 = Lazy(module2)

    assert lazy == lazy2
    lazy2._compute_value()
    assert lazy == lazy2
    assert lazy3 == lazy4
    lazy3._compute_value()
    assert lazy3 == lazy4
    assert lazy != lazy3
    assert lazy3 != lazy

# Generated at 2022-06-12 05:12:02.771556
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x).bind(lambda x: x).get(0) == 0
    assert Lazy(lambda x: x).bind(lambda x: Lazy(lambda: x + 2)).bind(lambda x: Lazy(lambda: x * 3)).get(0) == 6
    assert Lazy(lambda x: x).bind(lambda x: Lazy(lambda: x + 2)).bind(lambda x: Lazy(lambda: x * 3)).get(4) == 18


# Generated at 2022-06-12 05:12:12.216708
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_identity import Identity, IdentityMonad
    from pymonet.monad_maybe import Maybe
    from pymonet.validation import Validation

    assert Lazy(lambda: "a").bind(lambda x: Maybe.just(x)).get() == ("a",)
    assert Lazy(lambda: "a").bind(Maybe.just).get() == ("a",)
    assert Lazy(lambda: "b").bind(lambda x: Maybe.just(x)).get() == ("b",)

    assert Lazy(lambda: Maybe.just("b")).bind(lambda x: x).get() == Maybe.just("b")
    assert Lazy(lambda: Maybe.nothing).bind(lambda x: Maybe.just(x)).get() == Maybe.nothing


# Generated at 2022-06-12 05:12:22.453375
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of('foo').bind(lambda s: Lazy.of(s + 'bar')) == Lazy(lambda *_: 'foobar')

    def fn(value):
        if len(value) > 3:
            return Lazy.of("|>")
        return Lazy.of("<|")

    assert Lazy.of("bar").bind(fn) == Lazy.of("|>")
    assert Lazy.of("baz").bind(fn) == Lazy.of("<|")



# Generated at 2022-06-12 05:12:27.426819
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functions import identity

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)

    assert Lazy(identity) != Lazy(identity)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)


# Generated at 2022-06-12 05:12:34.140886
# Unit test for method get of class Lazy
def test_Lazy_get():
    def sum(*args):
        return reduce(lambda x, y: x + y, args, 0)

    assert Lazy(sum).get(1) == 1
    assert Lazy(sum).get(1, 2, 3) == 6
    assert Lazy(sum).get(1, 2, 3) == 6
    assert Lazy(sum).get(1, 2, 3, 4) == 10
    assert Lazy(sum).get(1, 2, 3, 4) == 10

# Generated at 2022-06-12 05:12:37.258004
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(5).map(lambda x: x + 5).get() == 10
    assert Lazy.of(5).map(lambda x: x + 5).map(lambda x: x + 5).get() == 15

# Generated at 2022-06-12 05:12:40.504682
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def foobar() -> object:
        return object()

    assert Lazy(foobar) != Lazy(foobar)
    assert Lazy(foobar) == Lazy(foobar)
    assert Lazy(foobar) != None  # noqa



# Generated at 2022-06-12 05:12:43.211971
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy(lambda: 1).get() == 1



# Generated at 2022-06-12 05:12:50.035364
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right

    val = Lazy(lambda: 3)
    lazy_fn = lambda x: Box(x + 1)
    assert val.bind(lazy_fn).get() == Box(4)

    val = Lazy(lambda: 3)
    lazy_fn = lambda x: Right(x + 1)
    assert val.bind(lazy_fn).get() == Right(4)



# Generated at 2022-06-12 05:13:01.327845
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: 1).bind(lambda a: Lazy(lambda: a * 2)).get() == 2
    assert Lazy(lambda: 1).bind(lambda a: Lazy(lambda: a * 2)).bind(lambda a: Lazy(lambda: a * 2)).get() == 4
    assert Lazy(lambda: 1).bind(lambda a: Lazy(lambda: a * 2)).bind(lambda a: Lazy(lambda: a * 2)).bind(lambda a: Lazy(lambda: a * 2)).get() == 8
    assert Lazy(lambda: 1).bind(lambda a: Lazy(lambda: a * 2)).bind(lambda a: Lazy(lambda: a * 2)).bind(lambda a: Lazy(lambda: a * 2)).bind(lambda a: Lazy(lambda: a * 2)).get() == 16

    assert L

# Generated at 2022-06-12 05:13:03.639275
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)



# Generated at 2022-06-12 05:13:06.023961
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return 1
    assert Lazy(fn).get() == 1


# Generated at 2022-06-12 05:13:15.075968
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def fn(arg1: int, arg2: int = 5) -> int:
        return arg1 * arg2

    assert Lazy(fn).ap(Box(2)) == Lazy(fn).map(fn)(2)
    assert Lazy(fn).ap(Maybe.just(2)) == Lazy(fn).map(fn)(2)
    assert None == Lazy(fn).ap(Maybe.empty()).get()



# Generated at 2022-06-12 05:13:17.399339
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(5).get() == 5
    assert Lazy.of('5').get() == '5'


# Generated at 2022-06-12 05:13:20.687046
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_function = Lazy(lambda x: x * 2)
    lazy_value = Lazy(lambda: 50)
    assert lazy_function.ap(lazy_value).get() == 100



# Generated at 2022-06-12 05:13:27.774495
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for Lazy.bind method with examples.
    """
    basic_number = 10

    # define function and use it in Lazy
    def add_one(x: int) -> int:
        return basic_number + x

    _lazy = Lazy(add_one)

    # map returned value of Lazy to other Lazy
    lazy = _lazy.bind(lambda value: Lazy(lambda: value**2))

    assert lazy.get() == 100



# Generated at 2022-06-12 05:13:31.179709
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x).get() == 1
    assert Lazy.of(1).map(lambda x: x+1).get() == 2
    assert Lazy.of(1).map(lambda x: x+1).map(lambda x: x+2).get() == 3


# Generated at 2022-06-12 05:13:34.574910
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    def test_function(arg1):
        return Lazy(lambda: arg1 + 1)

    assert Lazy(lambda: 1).bind(test_function).constructor_fn() == 2



# Generated at 2022-06-12 05:13:44.819582
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_fn():
        return 'test'

    def bound_fn(a, b):
        return Lazy.of(a + b)

    assert Lazy.of('a').bind(lambda _: Lazy.of('b')) == Lazy.of('b')
    assert Lazy.of('a').bind(lambda _: Lazy.of('b')).get() == 'b'

    assert Lazy(test_fn).bind(lambda _: Lazy.of('b')).get() == 'b'

    assert Lazy.of('a').bind(lambda _: Lazy(test_fn)).get() == 'test'

    assert Lazy(test_fn).bind(lambda c: Lazy(bound_fn).ap(Lazy.of(c))).get() == 'testtest'

# Generated at 2022-06-12 05:13:55.141324
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.either import Left, Right
    from pymonet.functor import Functor

    def minus_one(num): return num - 1

    lazy_one = Lazy.of(1)
    lazy_two = Lazy.of(1)
    lazy_three = Lazy.of(3)
    lazy_minus_one = Lazy.of(minus_one)

    assert lazy_one == lazy_two
    assert lazy_one != lazy_three
    assert lazy_one != lazy_minus_one

    # check for instance of Functor
    assert Functor.is_instance_of(Lazy, Right(1))

    # Check for instance of Functor for type Lazy
    fntype = Callable[[int], int]

# Generated at 2022-06-12 05:14:05.766138
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    add_five = lambda x: x + 5
    lazy_add_five = Lazy(add_five)

    res = Lazy.of(42).ap(lazy_add_five)
    assert res.get() == 47

    apply_fn = lambda x: x + 3
    multiply_fn = lambda x: x * 3
    res = Lazy(apply_fn).ap(Lazy(multiply_fn))
    assert res.get() == 15

    apply_fn = lambda x: x + ' world'
    res = Lazy(apply_fn).ap(Lazy(str))
    assert res.get() == 'hello world'

    res = Lazy(apply_fn).ap(Lazy(lambda: ''))
    assert res.get() == ' world'


# Generated at 2022-06-12 05:14:10.404603
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # given
    lazy_func = Lazy(lambda: 5)

    # when
    lazy_concat = lazy_func.bind(lambda x: Lazy.of(str(x)))

    # then
    assert lazy_func.get() == 5
    assert lazy_concat.get() == '5'

# Generated at 2022-06-12 05:14:16.337565
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def foo(x):
        return x + ' from Lazy'

    assert Lazy.of(foo).map('string from Lazy').get() == 'string from Lazy from Lazy'


# Generated at 2022-06-12 05:14:19.388555
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(): return 1

    assert Lazy(fn) == Lazy(fn)

    assert not Lazy(fn) == 1

    assert not Lazy(fn) == Lazy(lambda: 2)



# Generated at 2022-06-12 05:14:26.248740
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def add(x, y):
        return x + y

    lazy1 = Lazy(partial(add, 2))
    lazy2 = Lazy(partial(add, 2))
    lazy3 = Lazy(partial(add, 3))

    assert lazy1 == lazy1
    assert lazy1 == lazy2
    assert lazy1 != lazy3

# Generated at 2022-06-12 05:14:28.413095
# Unit test for method get of class Lazy
def test_Lazy_get():
    fn = Lazy(lambda: 10)

    assert fn.get() == 10
    assert fn.get() == 10
    assert fn.get() == 10

# Generated at 2022-06-12 05:14:35.905021
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Unit test for method __eq__ of class Lazy.
    """
    assert Lazy.of(1).__eq__(Lazy.of(1))
    assert False is Lazy.of(1).__eq__(Lazy.of(2))
    assert False is Lazy.of(1).__eq__(Lazy.of(1).map(lambda value: value + 1))
    assert Lazy.of(1).__eq__(Lazy.of(1).map(lambda value: value + 1).map(lambda value: value - 1))



# Generated at 2022-06-12 05:14:44.018926
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(12).__eq__(Lazy.of(12))
    assert not Lazy.of(12).__eq__(Lazy.of(13))
    assert not Lazy.of(12).__eq__(Lazy(lambda: 42))
    assert not Lazy.of(12).__eq__(None)
    assert not Lazy.of(12).__eq__(13)
    assert Lazy.of(12).__eq__(Lazy.of(12))



# Generated at 2022-06-12 05:14:46.594538
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def some_function(*args):
        return 'some_function'

    assert Lazy(some_function) == Lazy(some_function)

    def some_function():
        return 'some_function'

    def other_function():
        return 'other_function'

    assert Lazy(some_function) != Lazy(other_function)



# Generated at 2022-06-12 05:14:51.887756
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1).map(lambda x: x + 1) == Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)


# Generated at 2022-06-12 05:14:55.048313
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(10).bind(lambda x: Lazy.of(x + 10)) == Lazy.of(20)


# Generated at 2022-06-12 05:15:06.185391
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Left

    lazy = Lazy.of([1, 2, 3])
    lazy = lazy.bind(lambda xs: Lazy.of(xs[0]))
    assert lazy.get() == 1

    lazy = Lazy.of([1, 2, 3])
    lazy = lazy.bind(lambda xs: Lazy.of(xs[50]))
    assert lazy.get() is None

    lazy = Lazy.of([1, 2, 3])
    lazy = lazy.bind(lambda xs: Lazy.of(xs[0])).to_either()
    assert lazy.get() == 1

    lazy = Lazy.of([1, 2, 3])
    lazy = lazy.bind(lambda xs: Lazy.of(xs[50])).to_either()
    assert lazy.get()

# Generated at 2022-06-12 05:15:19.652346
# Unit test for method ap of class Lazy

# Generated at 2022-06-12 05:15:24.544533
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    import pytest  # type: ignore

    def test_function(value: int) -> str:
        return str(value)

    lazy = Lazy(test_function)
    assert lazy.get(1) == '1'
    assert lazy.get(2) == '2'
    assert lazy.is_evaluated

# Generated at 2022-06-12 05:15:35.037283
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    class TestClass:
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return (
                isinstance(other, TestClass) and
                other.value == self.value
            )

        def __str__(self):
            return 'TestClass[value={}]'.format(self.value)

    tc1 = TestClass('a')

    lazy = Lazy.of(tc1)

    def mapper(value: TestClass) -> Lazy[TestClass]:
        return Lazy.of(TestClass(value.value * 2))

    assert Lazy.of(TestClass('aa')) == lazy.bind(mapper)

# Generated at 2022-06-12 05:15:40.047972
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy.of(2)
    assert Lazy.of(1) == Lazy.of(1)



# Generated at 2022-06-12 05:15:43.517792
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = lambda x: x**2
    g = lambda x: x+2
    x = 2
    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(g)

# Generated at 2022-06-12 05:15:46.953482
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def mapper(x):
        return x + 2

    assert Lazy.of(1).ap(Lazy.of(mapper)).get() == 3


# Generated at 2022-06-12 05:15:50.890165
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    test_value = 2
    lazy = Lazy(lambda: test_value)
    assert lazy.bind(lambda a: Lazy(lambda: a + 1)).get() == 3

# Generated at 2022-06-12 05:15:55.778849
# Unit test for method map of class Lazy
def test_Lazy_map():
    """

    """
    fn = Lazy(lambda x: x + 1)
    assert fn.map(lambda x: x + 1).get(2) == 4
    assert fn.map(lambda x: x + 1).is_evaluated is False
    assert fn.map(lambda x: x + 1).value is None


# Generated at 2022-06-12 05:15:59.370723
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.either import Right
    from nose.tools import assert_true, assert_false

    Lazy.of(1) == Lazy(lambda: 1)
    Lazy.of(lambda: 1).map(lambda x: x()).get() == 1

    assert_true(Lazy.of(1) == Lazy(lambda: 1))
    assert_false(Lazy.of(1) == Lazy(lambda: 2))

    assert_true(Lazy.of(lambda: 1).map(lambda x: x()).get() == 1)

    assert_true(Lazy.of(Right(1)) == Lazy(lambda: Right(1)))

    def f():
        raise Exception()
    assert_true(Lazy.of(lambda: 1) != Lazy(f))


# Generated at 2022-06-12 05:16:08.899125
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor import Functor
    from pymonet.monad_try import Try, Success, Failure

    def failing_function():
        raise Exception('Test failure')

    def successful_function():
        return 'Test result'

    bind_failing_test_instance_1 = Lazy.of(lambda: failing_function()).bind(lambda value: Try.of(value))
    bind_failing_test_instance_2 = Lazy.of(lambda: failing_function()).map(lambda value: Try.of(value))
    bind_successful_test_instance = Lazy.of(lambda: successful_function()).bind(lambda value: Try.of(value))

    assert isinstance(bind_failing_test_instance_1, Lazy)

# Generated at 2022-06-12 05:16:19.381847
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    class TestException(Exception):
        pass

    def divide_by_zero(x):
        return x / 0

    def divide_on_five(x):
        return x / 5

    def divide_on_zero_or_five(x):
        return Lazy(divide_on_five) if x > 0 else Lazy(divide_by_zero)

    def negative_to_zero(x):
        return 0 if x < 0 else x

    def divide_on_zero_or_five_or_negative_to_zero(x):
        return Lazy(negative_to_zero).map(lambda result: divide_on_five(result) if x > 0 else divide_by_zero(result))


# Generated at 2022-06-12 05:16:27.148091
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    assert Functor.laws(Lazy)
    assert Applicative.laws(Lazy)

    # Tests for method bind
    def identity(x: int) -> Lazy[int, int]:
        return Lazy.of(x)

    def f(x: int) -> Lazy[int, int]:
        return Lazy.of(x * 2)

    def g(x: int) -> Lazy[int, int]:
        return Lazy.of(x + 1)

    z = Lazy.of(0)

    assert z.bind(identity).get(1) == 0
    assert z.bind(f).get(1) == 0
    assert z.bind(f).bind(g).get(1) == 1

# Generated at 2022-06-12 05:16:31.495357
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def identity(x):
        return x

    assert Lazy.of(2).bind(identity).is_evaluated is True
    assert Lazy.of(2).bind(identity).get() == 2



# Generated at 2022-06-12 05:16:43.968799
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test __eq__ method.
    """

    def identity(value):
        return value

    def construct(value):
        def fn():
            return value
        return fn

    def const(value):
        return lambda *args: value

    def const_with_arg(value):
        return lambda arg: value

    assert Lazy(identity).__eq__(Lazy(identity)) == False, "Lazy equality is wrong for identity"
    assert Lazy(identity).__eq__(Lazy(identity).get()) == False, "Lazy equality is wrong for identity"
    assert Lazy(identity).__eq__(Lazy(identity).get()) == False, "Lazy equality is wrong for identity"

# Generated at 2022-06-12 05:16:47.702340
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 'str') == Lazy(lambda: 'str')
    assert not (Lazy(lambda: 'str') == Lazy(lambda: 'different'))
    assert not (Lazy(lambda: 'str') == 'different')



# Generated at 2022-06-12 05:16:51.050184
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.option import Option

    assert Option(Lazy(lambda: lambda x: x * 2)).ap(Lazy(lambda: 10)) == Option(20)

# Generated at 2022-06-12 05:16:58.932623
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(5).get() == 5

    def construct_fn_with_one_arg(arg: int) -> int:
        return arg

    assert Lazy(construct_fn_with_one_arg).get(5) == 5

    def construct_fn_with_two_args(arg1: int, arg2: int) -> int:
        return arg1 + arg2

    assert Lazy(construct_fn_with_two_args).get(5, 5) == 10



# Generated at 2022-06-12 05:17:06.552406
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def square(x):
        return x ** 2

    assert Lazy.of(10).__eq__(Lazy.of(10))
    assert Lazy(square).__eq__(Lazy(square))
    assert Lazy.of(10).__eq__(Lazy.of(10)) is not False

    assert Lazy.of(10).__eq__(Lazy.of(11)) is not True
    assert Lazy(square).__eq__(Lazy(lambda x: x)) is not True
    assert Lazy.of(10).__eq__(Lazy.of(11)) is not False

    assert Lazy.of(10).__eq__("string") is not True
    assert Lazy(square).__eq__("string") is not True
    assert Lazy.of(10).__

# Generated at 2022-06-12 05:17:16.835443
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation

    lazy = Lazy(lambda x: x + 1)
    assert lazy.ap(Lazy.of(1)) == Lazy.of(2)

    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)

    validation = Validation.success(lambda x: x + 1)
    assert Lazy.of(1).ap(validation) == Lazy.of(2)

    validation = Validation.failure(lambda x: x + 1)
    assert Lazy.of(1).ap(validation) == Lazy.of(1)

    lazy = Lazy.of(lambda x: x + 1)
    assert lazy.ap(Validation.success(1)) == Lazy.of(2)

    lazy

# Generated at 2022-06-12 05:17:23.129872
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1) == Lazy.of(2)
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(2).map(lambda x: x * 2).map(lambda x: x + 1).get() == 5


# Generated at 2022-06-12 05:17:28.560618
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    fn = lambda x: Lazy(lambda y: x + y)
    def mapper(x):
        return x * 2

    assert Lazy.of(1).ap(fn(2)) == Lazy(lambda x: 3)
    assert Lazy.of(3).ap(Lazy.of(mapper)).ap(fn(2)) == Lazy(lambda x: 7)



# Generated at 2022-06-12 05:17:36.713068
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet import List
    from pymonet.boxes import Box

    Lazy0 = Lazy(lambda: 1)
    Lazy1 = Lazy(lambda: 1)
    Lazy2 = Lazy(lambda: 1).map(lambda x: x * 2)
    Lazy3 = Lazy(lambda: 2)
    Lazy4 = Lazy(lambda: 1).map(lambda x: x * 2)

    assert Lazy0 == Lazy1
    assert Lazy2 == Lazy2
    assert not Lazy2 == Lazy3
    assert Lazy2 == Lazy4

    Lazy5 = Lazy(lambda x: x ** 2)
    Lazy6 = Lazy(lambda x: x ** 2 + 1)

# Generated at 2022-06-12 05:17:41.853623
# Unit test for method get of class Lazy
def test_Lazy_get():
    def f(x: int) -> str:
        return str(x)

    lazy = Lazy(f)
    assert lazy.get(1) == '1'
    assert lazy.is_evaluated
    assert lazy.get(1) == '1'
    assert lazy.is_evaluated


# Generated at 2022-06-12 05:17:47.388255
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda x: x + 1).get(2) == 3
    assert Lazy(lambda x, y: x - y).get(3, 2) == 1
    assert Lazy(lambda x, y, z: x + y - z).get(3, 2, 1) == 4


# Generated at 2022-06-12 05:17:50.967199
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(0) == Lazy(lambda x: x + 1).bind(lambda x: Lazy.of(x - 1)).to_box()



# Generated at 2022-06-12 05:17:54.810305
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(2).map(lambda x: x ** 2) == Lazy.of(2).map(lambda x: x ** 2)

# Generated at 2022-06-12 05:17:57.067845
# Unit test for method get of class Lazy
def test_Lazy_get():

    def fn(*args):
        return 3

    lazy = Lazy(fn)

    assert lazy.get(1) == 3


# Generated at 2022-06-12 05:17:59.062640
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x + 1).map(lambda x: x * 10).construc

# Generated at 2022-06-12 05:18:05.841179
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_fn = lambda x: Lazy(lambda a: a + x)
    lazy = Lazy(lambda x: x)
    Lazy(lambda x: x + 2).ap(lazy_fn(2)).get(19)

    assert Lazy(lambda x: x).ap(lazy_fn(2)).get(19) == 21
    assert Lazy(lambda x: x + 2).ap(lazy_fn(2)).get(19) == 23
    assert Lazy(lambda x: x + 2).ap(lazy).get(19) == 21

# Generated at 2022-06-12 05:18:09.130834
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a):
        return lambda b: a + b

    add_3 = Lazy.of(3).map(add)
    add_5 = Lazy.of(5).map(add)

    assert (add_3.ap(add_5)).get() == 8



# Generated at 2022-06-12 05:18:16.505209
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import FunctorMappable
    from pymonet.applicative import ApplicativeWrap
    from pymonet.monad import MonadWrap

    class MockLazy(Lazy[T, U], Generic[T, U]):
        def __init__(self, constructor_fn: Callable[[T], U]) -> None:
            super(MockLazy, self).__init__(constructor_fn)

    def lazy_eq(x, y):
        return y == x

    class LazyMockTest(FunctorMappable[U, W], ApplicativeWrap[T, U], MonadWrap[U, W]):
        def __init__(self, lazy):
            super(LazyMockTest, self).__init__(lazy)


# Generated at 2022-06-12 05:18:19.324878
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_try import Try
    Try = Try.of

    assert Lazy(lambda: 10).map(lambda x: x + 10).get() == Lazy(lambda: 20).get()



# Generated at 2022-06-12 05:18:27.625956
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Lazy should be equal when
    - both are evaluated and have same values
    - both are not evaluated and have same constructor functions
    """
    def my_fn(number):
        return number

    lazy1 = Lazy.of(1)
    lazy2 = Lazy.of(1)

    assert lazy1 == lazy2

    lazy1.get()
    lazy2.get()

    assert lazy1 == lazy2

    lazy1 = Lazy(my_fn)
    lazy2 = Lazy(my_fn)

    assert lazy1 == lazy2

    lazy2.get(1)

    assert not lazy1 == lazy2



# Generated at 2022-06-12 05:18:32.558263
# Unit test for method get of class Lazy
def test_Lazy_get():
    def function_to_call_with_arguments(x, y, z):
        return x + y + z

    lazy = Lazy(function_to_call_with_arguments)
    assert lazy.is_evaluated == False
    assert lazy.get(4, 5, 6) == 15

    assert lazy.is_evaluated == True
    assert lazy.get(4, 5, 6) == 15


# Generated at 2022-06-12 05:18:41.462644
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.monad_try import Try, Failure

    def is_lazy_eq(l1, l2):
        assert l1 == l2
        assert l2 == l1

    is_lazy_eq(Lazy.of(1), Lazy.of(1))
    is_lazy_eq(Try.of(lambda: 1), Lazy.of(Try.of(lambda: 1).get()))
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != 2
    assert Lazy.of(1) != Lazy.of(lambda x: 1)
    assert Lazy.of(1) != Try.success(1)

# Generated at 2022-06-12 05:18:49.098168
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right
    from pymonet.validation import Validation

    def ap_validation(left):
        return lambda right: Validation.success(left + right)

    right = Right(1)
    lazy_right = Lazy(lambda: right)

    lazy_left = Lazy(lambda: 2)

    assert lazy_left.ap(Lazy(ap_validation)).get() == lazy_right.ap(lazy_left).get()

# Generated at 2022-06-12 05:18:55.125685
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # GIVEN
    value1 = Lazy.of(1)
    value2 = Lazy.of(2)
    value3 = Lazy.of(3)
    def fn(first, second):
        return first + second
    function = Lazy.of(fn)

    # WHEN
    result = value1.ap(function).ap(value2).ap(value3).get()

    # THEN
    assert result == 6



# Generated at 2022-06-12 05:19:04.264353
# Unit test for method get of class Lazy
def test_Lazy_get():
    count = 0
    fn = lambda x: x + 1
    # Lazy with lambda
    lazy = Lazy(fn).map(lambda x: x + 2)
    assert lazy.get(1) == 4
    assert lazy.get(1) == 4
    assert count == 1

    # Lazy with function
    def add(x, y):
        return x + y

    def add_with_count(x, y):
        nonlocal count
        count += 1
        return x + y

    lazy = Lazy(add).map(lambda x: x + 2)
    assert lazy.get(1, 1) == 4
    assert lazy.get(1, 1) == 4
    assert count == 1

# Generated at 2022-06-12 05:19:12.553263
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy(lambda x: x + 1).get(1) == 2
    assert Lazy(lambda x: x + 1).get(2) == 3
    assert Lazy(lambda x, y: x + y).get(1, 2) == 3
    assert Lazy(lambda x, y: x + y).get(1, 2) == 3
    assert Lazy(lambda x, y: x + y).get(2, 2) == 4


# Generated at 2022-06-12 05:19:19.117347
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def to_list(list_string):
        return Lazy(lambda *args: list(list_string))

    def list_to_str(list_string):
        return Lazy(lambda *args: ''.join(list_string))

    assert Lazy.of('abcdef').bind(to_list).bind(list_to_str).get() == 'abcdef'
    assert Lazy.of('abcdef').bind(lambda x: Lazy.of(x).bind(lambda y: Lazy.of(y))).get() == 'abcdef'


# Generated at 2022-06-12 05:19:29.659560
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # type: () -> None
    """
    Test bind method of class Lazy
    """
    assert (lambda arg: arg + arg) | Lazy.of(2).map(lambda arg: arg + arg).bind(lambda arg: Lazy.of(arg) \
        .map(lambda arg: arg + arg)) == 8

    assert Lazy.of(2).map(lambda arg: arg + arg) == Lazy.of(4)

# Generated at 2022-06-12 05:19:37.270978
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(2).map(lambda x: x**2).get() == 4

    # Check that mapped lambda is called only once
    def curried_pow(x):
        calls = [0]

        def call(*args):
            calls[0] += 1
            return pow(x, *args)

        return call

    assert Lazy.of(2).map(curried_pow).map(lambda x: x(2)).get() == 4
    assert curried_pow(2).__defaults__ == (None,)


# Generated at 2022-06-12 05:19:42.527198
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_fn(*args):
        return 'testfn'

    assert Lazy(test_fn) != Lazy(test_fn)
    lazy = Lazy(test_fn)
    assert lazy != Lazy(test_fn)
    assert lazy != lazy._compute_value()
    assert lazy != 'test_fn'
    assert lazy == lazy


# Generated at 2022-06-12 05:19:52.752478
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.functor import starmap
    from pymonet.monad_list import List

    def _maybe_of_list(value) -> Lazy['int', List[int]]:
        return Lazy(lambda *x: List(*value))

    assert Lazy.of(List(1, 2, 3)).bind(_maybe_of_list) == Lazy(lambda *x: List(1, 2, 3))

    assert Lazy.of(List(1, 2, 3)).map(starmap(lambda x: x * x)).bind(_maybe_of_list) == Lazy(lambda *x: List(1, 4, 9))

# Generated at 2022-06-12 05:19:53.710505
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x: x + 1).get(1) == 2

# Generated at 2022-06-12 05:19:58.144250
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn1(value):
        return Lazy(lambda: value + 5)
    lazy_object = Lazy(lambda: 8)
    new_lazy_object = lazy_object.bind(fn1)
    assert new_lazy_object.get() == 13



# Generated at 2022-06-12 05:20:00.505269
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def divide(value):
        try:
            return Lazy.of(value / 10)
        except ZeroDivisionError:
            return Lazy.of('Division by 0')

    assert Lazy.of(10).bind(divide).get() == 1
    assert Lazy.of(0).bind(divide).get() == 'Division by 0'



# Generated at 2022-06-12 05:20:06.900145
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # Method __eq__ of class Lazy should compare arguments passed to constructor
    # Method __eq__ of class Lazy should return True when both are evaluated and have the same value
    # Method __eq__ of class Lazy should return True when both are evaluated and have the same value and constructor_fn
    # Method __eq__ of class Lazy should return True when both are not evaluated and have the same value and constructor_fn
    # Method __eq__ of class Lazy should return False when both are not evaluated and have the same value but different constructor_fn
    # Method __eq__ of class Lazy should return False when both are evaluated and have the same value but different constructor_fn
    assert Lazy(lambda: 10) == Lazy(lambda: 10)
    assert Lazy(lambda: 10).get() == Lazy(lambda: 10).get()

# Generated at 2022-06-12 05:20:09.578031
# Unit test for method map of class Lazy
def test_Lazy_map():
    def square(x):
        return x ** 2

    assert Lazy.of(2).map(square).get() == 4


# Generated at 2022-06-12 05:20:20.491733
# Unit test for method bind of class Lazy
def test_Lazy_bind(): # pragma: no cover
    from pymonet.validation import Validation

    lazy = Lazy.of(1) \
        .bind(lambda x: Lazy.of(x + 1)) \
        .bind(lambda x: Lazy.of(x * 2)) \
        .bind(lambda x: Lazy.of(x / 2))

    assert lazy.get() == 2

    lazy = Lazy.of(1) \
        .map(lambda x: x + 1) \
        .map(lambda x: x * 2) \
        .map(lambda x: x / 2)

    assert lazy.get() == 2


# Generated at 2022-06-12 05:20:34.803277
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(None) == Lazy.of(None)

    def fake_function(x):
        return x

    assert Lazy(fake_function) != Lazy(fake_function)



# Generated at 2022-06-12 05:20:46.474260
# Unit test for method get of class Lazy
def test_Lazy_get():  #pragma: no cover
    from pymonet.monad_try import Try

    def expensive_call():
        return 1

    assert Lazy.of(1).get() == 1
    assert Lazy(lambda x: x + 1).get(1) == 2

    assert Lazy.of(expensive_call()).get() == 1
    assert Lazy(lambda x: x + 1).get(1) == 2

    assert Lazy.of(expensive_call()).get() == 1
    assert Lazy(lambda x: x + 1).get(1) == 2
    assert Lazy.of(expensive_call()).get() == 1
    assert Lazy(lambda x: x + 1).get(1) == 2



# Generated at 2022-06-12 05:20:48.966544
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy = Lazy(lambda: 1)
    lazy2 = Lazy(lambda: 1)
    lazy3 = Lazy(lambda: 2)

    assert lazy == lazy2
    assert lazy != lazy3


# Generated at 2022-06-12 05:20:57.524330
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def foo():
        return 'foo'
    def bar():
        return 'bar'

    assert Lazy(foo) == Lazy(foo)
    assert Lazy(foo).map(bar) == Lazy(foo).map(bar)
    assert Lazy(foo).map(bar) == Lazy(bar).map(foo).map(bar)
    assert Lazy(foo).map(bar) != Lazy.of(bar())
    assert Lazy.of(foo()) == Lazy.of(foo())
    assert Lazy.of(foo()) != Lazy.of(bar())