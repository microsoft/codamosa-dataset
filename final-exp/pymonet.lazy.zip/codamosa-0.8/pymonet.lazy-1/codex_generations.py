

# Generated at 2022-06-12 05:11:09.365038
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f1(x): return x + 1
    def f2(x): return x + 1

    assert Lazy(f1) == Lazy(f1)
    assert Lazy(f1).fold() == Lazy(f1).fold()
    assert Lazy(f1) != Lazy(f2)
    assert Lazy(f1).fold() != Lazy(f2).fold()
    assert Lazy(f1).map(f2) != Lazy(f2).map(f1)


# Generated at 2022-06-12 05:11:15.292527
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    value = 10

    def get_list() -> List[int]:
        return [0, 1, 2]

    def filter_list(list_to_filter) -> List[int]:
        return [x for x in list_to_filter if x > value]

    mock_second_fn = Mock(return_value=filter_list)

    fn = Mock(return_value=get_list)
    lazy = Lazy(fn)
    result = lazy.bind(mock_second_fn)

    fn.assert_called_once_with()
    mock_second_fn.assert_called_once_with(get_list())

    assert isinstance(result, Lazy)
    assert result.constructor_fn() == filter_list(get_list())

    expected_result = [1, 2]

# Generated at 2022-06-12 05:11:19.859121
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_maybe import Maybe

    def function(value):
        return Maybe.just(value)

    def function2(value):
        return Maybe.just(2 * value)

    lazy = Lazy.of(1)
    assert lazy.bind(function).bind(function2) == Maybe.just(2)

# Generated at 2022-06-12 05:11:31.894491
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(5).__eq__(Lazy.of(5)) is True
    assert (Lazy.of(5).__eq__(Lazy.of(5)) == Lazy.of(5).__eq__(Lazy.of(5))) is True
    assert Lazy.of(5).__eq__(Lazy.of(6)) is False
    assert (Lazy.of(5).__eq__(Lazy.of(6)) == Lazy.of(6).__eq__(Lazy.of(5))) is False
    assert Lazy.of(5).__eq__(Lazy.of(5).map(lambda x: x + 1)) is False

# Generated at 2022-06-12 05:11:39.306167
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functions import identity
    from pymonet.functions import compose
    from pymonet.functions import increment
    from pymonet.functions import compose

    assert Lazy(identity) == Lazy(identity)
    assert not (Lazy(identity) == Lazy(compose(identity, increment)))
    assert Lazy(identity) == Lazy(identity).map(identity).map(compose(identity, increment))
    assert Lazy(identity) == Lazy(identity).map(identity).ap(Lazy(identity))



# Generated at 2022-06-12 05:11:43.125035
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def double_it(x):
        return x * 2

    def add_one(x):
        return x + 1

    lazy_of_two = Lazy(lambda x: x)
    # double_it is not called
    result = lazy_of_two.bind(double_it)
    # double_it is not called here too
    result = result.bind(add_one).get(2)

    assert result == 5



# Generated at 2022-06-12 05:11:46.298395
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.box import Box

    # pylint: disable=unused-variable
    @staticmethod
    def add(x):
        return lambda y: x + y

    add_1 = Box(add(1))
    add_3 = Box(add(3))
    assert Lazy.of(3).ap(add_1).get() == 4
    assert Lazy.of(3).ap(add_3).get() == 6


# Generated at 2022-06-12 05:11:52.347331
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def plus_one(value):
        return value + 1

    def plus_two(value):
        return value + 2

    assert Lazy.of(1).map(plus_one) == Lazy.of(1).map(plus_one)
    assert Lazy.of(1).map(plus_one) != Lazy.of(1).map(plus_two)



# Generated at 2022-06-12 05:12:00.123698
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.either import Left

    lazy_value = Lazy.of("value").map(str.upper).map(str.lower).bind(lambda v: Lazy.of(Left(v)))
    assert lazy_value.get() == Left('value')
    assert lazy_value.get() == Left('value')

    lazy_value = Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 2).bind(lambda v: Lazy.of(Left(v)))
    assert lazy_value.get() == Left(4)
    assert lazy_value.get() == Left(4)



# Generated at 2022-06-12 05:12:05.400658
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def add(x, y):
        return x + y

    lazy_x = Lazy.of(1)
    lazy_y = Lazy.of(2)
    assert lazy_x == Lazy.of(1)
    assert lazy_x != lazy_y
    assert lazy_x != Lazy(add)



# Generated at 2022-06-12 05:12:10.077359
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of('test').get() == 'test'
    assert Lazy.of(42).get(1) == 42

    assert Lazy.of(lambda x: x+1).get()(1) == 2


# Generated at 2022-06-12 05:12:18.711552
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.demand import Demand

    assert Demand(lambda: 1).bind(lambda x: Demand(lambda: x + 1)) == Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)) == Lazy(lambda: 2)
    assert Demand(lambda: 1).bind(lambda x: Demand(lambda: x + 1)).get() == Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).get() == 2


# Generated at 2022-06-12 05:12:22.769428
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test bind method of Lazy class.
    """
    from pymonet.maybe import Maybe

    value = 1

    def fn(value):
        return Maybe.just(value + 1)

    lazy = Lazy.of(value)
    result = lazy.bind(fn)
    assert result.get() == 2

# Generated at 2022-06-12 05:12:26.849469
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test method __eq__ of class Lazy
    """
    assert Lazy.of(2) == Lazy(lambda: 2)
    assert Lazy.of(2) != Lazy.of(3)  # pylint: disable=no-member

# Generated at 2022-06-12 05:12:29.201424
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda i: Lazy.of(i + 1)).get() == 2

# Generated at 2022-06-12 05:12:32.676574
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of('value').bind(lambda x: Lazy.of(x)).get() == 'value'
    assert Lazy(lambda: 'value').bind(lambda x: Lazy.of(x)).get() == 'value'



# Generated at 2022-06-12 05:12:36.599398
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    Box.unit = Box

    def fn(number: int) -> Box[int]:
        return Box.unit(number + 1)

    assert Lazy.of(1).bind(fn) == Lazy.of(2)



# Generated at 2022-06-12 05:12:42.581830
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test case:
    1. Create empty lazy
    2. Call get method - returns passed argument
    3. Verify results
    """
    # Arrange
    expected = 'hello'
    sut = Lazy.of(expected)

    # Act
    result = sut.get()

    # Assert
    assert result == expected

    # Verify
    assert sut.is_evaluated == True
    assert sut.constructor_fn == None
    assert sut.value == expected


# Generated at 2022-06-12 05:12:46.696037
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test_mapper(value):
        return value * 2

    assert Lazy.of(1).map(test_mapper).get() == 2
    assert Lazy.of(1).map(lambda value: value ** 2).get() == 1


# Generated at 2022-06-12 05:12:54.102613
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # pylint: disable=unused-argument
    def divide(value):
        def inner_fnc(divisor):
            return Lazy(lambda: value / divisor)

        return inner_fnc

    assert Lazy(lambda: 1).bind(divide(1)).get() == 1
    assert Lazy(lambda: 1).bind(divide(2)).get() == 0.5
    assert Lazy(lambda: 4).bind(divide(2)).get() == 2
    assert Lazy(lambda: 4).bind(divide(0)).get() == float("inf")



# Generated at 2022-06-12 05:13:00.794792
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    def lazy_func(value: int) -> Box[int]:
        return Box(value * 2)

    lazy = Lazy(lazy_func)
    lazy2 = lazy.map(lambda box: box.get() * 2)

    assert lazy2.get(1) == 4



# Generated at 2022-06-12 05:13:11.491053
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from tests.utils import is_equal
    from pymonet.maybe import Maybe

    lazy1 = Lazy(lambda: True)
    lazy2 = Lazy(lambda: True)

    assert is_equal(lazy1, lazy2)

    lazy2 = Lazy.of(Maybe.just(1))
    assert not is_equal(lazy1, lazy2)

    lazy2 = Lazy(lambda: 1)
    assert not is_equal(lazy1, lazy2)

    lazy2 = Lazy.of(1)
    assert not is_equal(lazy1, lazy2)

    lazy1 = Lazy.of(True)
    lazy2 = Lazy(lambda: 1)
    assert not is_equal(lazy1, lazy2)


# Generated at 2022-06-12 05:13:15.141492
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(2) != Lazy.of(3)


# Generated at 2022-06-12 05:13:17.493456
# Unit test for method get of class Lazy
def test_Lazy_get():
    def return_int() -> int:
        return 1

    assert Lazy(return_int).get() == 1



# Generated at 2022-06-12 05:13:27.332923
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.maybe import Maybe

    value_1 = Lazy.of('test_string')
    value_2 = value_1.map(lambda s: s + s)
    value_3 = value_1.bind(lambda x: value_2)

    value_4 = Lazy.of('test_string')
    value_5 = value_4.map(lambda s: s + s)
    value_6 = value_4.bind(lambda x: value_5)

    assert value_1 != value_2
    assert value_1 == value_4
    assert value_2 != value_5
    assert value_6 == value_3


# Generated at 2022-06-12 05:13:39.638330
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.monad_try import Try

    def add_one(value):
        return Try.of(lambda: value + 1)

    def add_two(value):
        return Try.of(lambda: value + 2)

    lazy = Lazy(lambda: 1)

    assert lazy.get() == 1  # Lazy is a function that returns 1
    assert lazy.bind(add_one).get() == 2  # first bind is called after .get
    assert lazy.bind(add_two).get() == 3  # first bind is called after .get
    assert lazy.bind(add_two).bind(add_one).get() == 4  # two bind are called after .get

    assert lazy == Lazy(lambda: 1)
    assert lazy != Lazy(lambda: 2)

# Generated at 2022-06-12 05:13:44.405249
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(5).__eq__(Lazy.of(5))
    assert not Lazy.of(5).__eq__(Lazy.of(4))
    assert not Lazy.of(5).__eq__(None)
    assert not Lazy.of(5).__eq__(5)



# Generated at 2022-06-12 05:13:54.709640
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_eq = Lazy.of(3)
    lazy_eq1 = Lazy.of(3)
    lazy_neq1 = Lazy.of(4)
    lazy_neq2 = Lazy.of(3).map(lambda x: x + 2)
    lazy_neq3 = Lazy.of(3).bind(lambda x: Lazy.of(x))
    lazy_neq4 = Lazy.of(6).bind(lambda x: Lazy.of(x // 2))
    assert lazy_eq == lazy_eq1
    assert lazy_eq != lazy_neq1
    assert lazy_eq != lazy_neq2
    assert lazy_eq != lazy_neq3
    assert lazy_eq == lazy_neq4



# Generated at 2022-06-12 05:13:58.714998
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)) == Lazy.of(3)

# Generated at 2022-06-12 05:14:01.223300
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def add(x, y):
        return x + y

    def ap_test(x):
        return add(5, x)

    x = Lazy(lambda x: x)
    y = Maybe.just(5)

    assert x.ap(y).get(10) == 15

# Generated at 2022-06-12 05:14:13.326686
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test for method __eq__ of class Lazy.
    """
    lazy_fn = lambda x: x + 2

    assert Lazy(lazy_fn) == Lazy(lazy_fn)

    lazy_1 = Lazy(lazy_fn)
    lazy_1.get(2)
    assert lazy_1 == lazy_1

    lazy_1 = Lazy(lazy_fn)
    lazy_2 = Lazy(lazy_fn)
    lazy_1.get(2)
    lazy_2.get(2)
    assert lazy_1 == lazy_2



# Generated at 2022-06-12 05:14:20.048549
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def _test_eq(lazy1, lazy2, expected):
        assert lazy1 == lazy2 == expected

    _test_eq(Lazy(lambda: 1), Lazy(lambda: 1), True)
    _test_eq(Lazy(lambda: 1), Lazy(lambda: 2), False)
    _test_eq(Lazy(lambda: 1), 1, False)
    _test_eq(Lazy(lambda: 1), Lazy.of(1), True)


# Generated at 2022-06-12 05:14:21.640082
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2



# Generated at 2022-06-12 05:14:25.876730
# Unit test for method map of class Lazy
def test_Lazy_map():
    fn = lambda _: None
    assert Lazy(fn).map(lambda x: x) == Lazy(fn).map(lambda x: x)
    assert Lazy(fn).map(None) == Lazy(fn)
    assert Lazy(fn).map(None).map(lambda x: x) == Lazy(fn)

    def mapper(fn):
        def result(x):
            return fn(x + 10)

        return result

    output = Lazy(fn).map(mapper(lambda x: x + 10)).map(lambda x: x + 10)
    assert output.get(0) == 20



# Generated at 2022-06-12 05:14:36.623660
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn_a():
        return 'fn_a'

    def fn_b():
        return 'fn_b'

    lazy_a_1 = Lazy(fn_a)
    lazy_a_2 = Lazy(fn_a)
    lazy_b_1 = Lazy(fn_b)
    lazy_b_2 = Lazy(fn_b)

    assert lazy_a_1 == lazy_a_1
    assert lazy_a_1 == lazy_a_2
    assert lazy_a_1 != lazy_b_1
    assert lazy_a_1 != lazy_b_2
    assert lazy_b_1 == lazy_b_1
    assert lazy_b_1 == lazy_b_2
    assert lazy_b_1 != lazy_a_1
    assert lazy_b_1 != lazy_a

# Generated at 2022-06-12 05:14:41.377660
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(5) == Lazy.of(5)
    assert Lazy.of(5) == Lazy.of(5).map(lambda x: 1 + x)
    assert Lazy.of(5) != Lazy.of(6)



# Generated at 2022-06-12 05:14:46.815437
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    my_lazy = Lazy(lambda x: x + 10)
    lazy_double = Lazy(lambda x: x * 2)
    lazy_triple = Lazy(lambda x: x * 3)

    assert my_lazy.ap(lazy_double).get(1) == 12
    assert my_lazy.ap(lazy_triple).get(1) == 13

# Generated at 2022-06-12 05:14:53.720085
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda a: a).bind(lambda a: Lazy(lambda: a + 1)).get(1) == 2
    assert Lazy(lambda a: a).bind(lambda a: Lazy(lambda: a + 1)).get(3) == 4
    assert Lazy(lambda a: a).bind(lambda a: Lazy(lambda: a + 1)).get(5) == 6
    assert Lazy(lambda a: a).bind(lambda a: Lazy(lambda: a + 1)).get(7) == 8


# Generated at 2022-06-12 05:15:01.350650
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = lambda: 1
    lazy1 = Lazy(f)
    lazy2 = Lazy(f)

    assert lazy1 == lazy2
    assert lazy1.get() == 1
    assert lazy1.is_evaluated
    assert lazy2.get() == 1
    assert lazy2.is_evaluated

    assert lazy1 == lazy2
    assert lazy1.get() == 1
    assert lazy1.is_evaluated
    assert lazy2.get() == 1
    assert lazy2.is_evaluated

    f2 = lambda: 2
    lazy3 = Lazy(f2)

    assert lazy1 != lazy3
    assert lazy3 != lazy1

    assert lazy3.get() == 2
    assert lazy3.is_evaluated
    assert lazy1 != lazy3
    assert lazy3 != lazy1


# Generated at 2022-06-12 05:15:04.135626
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.either import Right

    def fn(x):
        return x + x

    def mapper(x):
        return x + 1

    lazy_result = Lazy(fn).map(mapper).get(1)
    expected_result = 3
    assert lazy_result == expected_result

    right = Right(1).to_lazy().map(fn).map(mapper)
    expected_result = Right(3)
    assert right == expected_result

# Generated at 2022-06-12 05:15:09.572457
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def function_a(a):
        return a

    Lazy(function_a).bind(function_a)


# Generated at 2022-06-12 05:15:19.289799
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    class Test:
        pass

    o1 = Test()
    o2 = Test()
    assert Lazy.of(o1) == Lazy.of(o1)
    assert Lazy.of(o1) != Lazy.of(o2)
    assert Lazy.of(o1) != Lazy.of(o1).map(lambda _: None)
    assert Lazy.of(o1) != Lazy.of(o1).map(lambda _: None).map(lambda _: None)
    assert Lazy.of(o1) != Lazy.of(o1).map(lambda _: None).map(lambda _: None).map(lambda _: None)



# Generated at 2022-06-12 05:15:22.479276
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)



# Generated at 2022-06-12 05:15:34.225510
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Right, Left
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def function(value):
        if isinstance(value, str):
            return Lazy.of(Right(value))
        if isinstance(value, int):
            return Lazy.of(Maybe.of(value))
        if isinstance(value, float):
            return Lazy.of(Box(value))
        return Lazy.of(Left('test'))

    Lazy(lambda: 'a').bind(function).get() == Right('a')
    Lazy(lambda: 1).bind(function).get() == Maybe.of(1)
    Lazy(lambda: 1.3).bind(function).get() == Box(1.3)

# Generated at 2022-06-12 05:15:46.428596
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Catch

    def divide_on_3(x: int) -> Try[int]:
        try:
            return Try(lambda: x / 3)
        except Exception as ex:
            return Try.failure(ex)

    def divide_on_5(x: int) -> Try[int]:
        try:
            return Try(lambda: x / 5)
        except Exception as ex:
            return Try.failure(ex)

    assert Lazy(lambda: 15).bind(divide_on_3).get() == 5
    assert Lazy(lambda: 12).bind(divide_on_3).bind(divide_on_5).get() == 2

# Generated at 2022-06-12 05:15:50.168487
# Unit test for method map of class Lazy
def test_Lazy_map():
    no_lazy_fn = lambda i: i

    assert Lazy.of(5).map(lambda i: i + 1).get() == 6
    assert Lazy.of(5).map(no_lazy_fn).get() == 5


# Generated at 2022-06-12 05:15:54.573809
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x, y: x + y).ap(Lazy.of(2)).get(5) == 7
    assert Lazy(lambda x, y: x + y).map(lambda x: x + 1).ap(Lazy.of(2)).get(5) == 8



# Generated at 2022-06-12 05:15:57.850189
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 2).get() == 3

# Generated at 2022-06-12 05:16:02.515962
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get(1) == 1
    test_factory = UnboundMethodMock(Lazy, '_compute_value')
    Lazy.of(1).get(1)
    assert test_factory.call_count == 1
    Lazy.of(1).get(1)
    assert test_factory.call_count == 1

# Generated at 2022-06-12 05:16:13.448238
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def assert_eq(actual, expected):
        assert actual == expected, 'expected: {} != actual: {}'.format(expected, actual)

    assert_eq(Lazy.of('a'), Lazy(lambda: 'a'))
    assert_eq(Lazy.of('a').map(str.upper), Lazy(lambda: 'A'))
    assert_eq(Lazy.of('a').map(str.upper).map(str.lower), Lazy(lambda: 'a'))
    assert_eq(Lazy.of('a').map(str.upper).map(str.lower).map(str.upper), Lazy(lambda: 'A'))

# Generated at 2022-06-12 05:16:19.551685
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    foo = lambda: 0
    lazy1 = Lazy(foo)
    lazy2 = Lazy(foo)
    assert lazy1 == lazy2

# Generated at 2022-06-12 05:16:22.145844
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn() -> int:
        return 1

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy1 == lazy2

# Generated at 2022-06-12 05:16:33.746309
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f():
        return 1

    def g():
        return 2

    # Lazy[int] == Lazy[int]
    assert(Lazy(f) == Lazy(f))
    assert(Lazy(g) == Lazy(g))
    assert(Lazy.of(1) == Lazy.of(1))
    assert(Lazy.of(2) == Lazy.of(2))
    assert(Lazy.of(3) == Lazy.of(3))

    # Lazy[int] != Lazy[int]
    assert(Lazy(f) != Lazy(g))
    assert(Lazy.of(1) != Lazy.of(2))
    assert(Lazy.of(2) != Lazy.of(3))

# Generated at 2022-06-12 05:16:36.638124
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1



# Generated at 2022-06-12 05:16:45.944171
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is True
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1)) is False
    assert Lazy(lambda x: x + 1).__eq__(Lazy(lambda x: x)) is False
    assert Lazy(lambda x: x + 1).__eq__(Lazy(lambda x: x + 1)) is True
    assert Lazy(lambda x: x + 1).__eq__(Lazy(lambda x: x + 2)) is False
    assert Lazy(lambda x: x).__eq__(lambda x: x) is False
    assert Lazy(lambda x: x).__eq__(1) is False



# Generated at 2022-06-12 05:16:53.525057
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add(val):
        return val + 1

    def multiply(val):
        return val * 10

    assert Lazy(lambda: 2).bind(add).bind(multiply).get() == 30
    assert Lazy(lambda: 2).bind(lambda x: Lazy(lambda: x + 1)).get() == 3
    assert Lazy(lambda: 2).bind(lambda x: Lazy(lambda: x + 1)).bind(lambda x: Lazy(lambda: x + 1)).get() == 4

# Generated at 2022-06-12 05:16:56.835008
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x + 2).bind(lambda x: Lazy(lambda: x + 10).map(lambda x: x * 2)).get(1) == 24

# Generated at 2022-06-12 05:17:05.718435
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Initialize constant values
    T_ZERO = 100
    T_ONE = 200
    T_TWO = 300

    def constant_zero(argument):
        assert argument == T_ONE
        return Lazy.of(T_ZERO)

    def constant_one(argument):
        assert argument == T_TWO
        return Lazy.of(T_ONE)

    def constant_two(argument):
        assert argument == T_ZERO
        return Lazy.of(T_TWO)

    # Test bind with one mapper
    assert Lazy.of(T_ZERO).bind(constant_zero) == Lazy.of(T_ZERO)

    # Test bind with two mapper

# Generated at 2022-06-12 05:17:09.660369
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    # given
    test_function = (lambda: 2)
    value = Lazy(test_function)

    # when
    actual = value.get()

    # then
    assert actual == test_function()
    assert value.is_evaluated



# Generated at 2022-06-12 05:17:17.784852
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.logger import get_logger
    import unittest

    logger = get_logger(__name__)

    class TestLazyClass(unittest.TestCase):
        def setUp(self):
            self.value = 'test'
            self.obj = Lazy.of(self.value)

        def test_Lazy_eq_is_equal(self):
            self.assertEqual(self.obj, Lazy.of(self.value))

        def test_Lazy_eq_is_not_equal(self):
            self.assertNotEqual(self.obj, Lazy.of('another_value'))



# Generated at 2022-06-12 05:17:31.038325
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pymonet.functor as f
    from pymonet.box import Box
    from pymonet.either import Right

    def plus_one(f_val):
        return Lazy.of(f_val + 1)

    def transform_value(fn):
        return lambda value: fn(value)

    def add_to_one(value):
        return value + 1

    assert Lazy.of(10).bind(plus_one).get() == 11
    assert Lazy.of(10).bind(Lazy.of).get() == 10
    assert Lazy.of(10).bind(plus_one) == plus_one(Lazy.of(10)).get()
    assert Lazy.of(10).bind(
        lambda value: Lazy.of(value).map(add_to_one)
    ) == L

# Generated at 2022-06-12 05:17:38.649613
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def test_lazy_1():
        return 2

    def test_lazy_2():
        return 3

    map_fn = lambda x: x + 5
    lazy_1 = Lazy(test_lazy_1)
    lazy_2 = Lazy(test_lazy_2)
    assert lazy_1.ap(lazy_2.map(map_fn)) == Lazy(lambda: test_lazy_1() + map_fn(test_lazy_2()))

# Generated at 2022-06-12 05:17:40.532763
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2



# Generated at 2022-06-12 05:17:47.661810
# Unit test for method map of class Lazy
def test_Lazy_map():
    # pylint: disable=pointless-statement
    assert Lazy.of(3).map(lambda x: x).get() == Lazy.of(3).get()
    assert Lazy.of(3).map(lambda x: x + 2).get() == Lazy.of(5).get()
    assert Lazy.of(Lazy.of(3)).map(lambda x: x).get().get() == Lazy.of(Lazy.of(3)).get().get()

# Generated at 2022-06-12 05:17:53.920126
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(5).map(lambda x: x + 1) != Lazy.of(6)
    assert Lazy.of(5).map(lambda x: x + 1) == Lazy.of(5).map(lambda x: x + 1)
    assert Lazy(lambda: 5).map(lambda x: x + 1) == Lazy(lambda: 5).map(lambda x: x + 1)


# Generated at 2022-06-12 05:18:04.506037
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Method bind of class Lazy
    """
    import pytest

    input_list = [1, 2, 3, 4]
    expected_result = 16

    def mapper_fn(value):
        return Lazy.of(lambda i: i * i)

    def compute_fn(value):
        return value * value

    def folder_fn_1(res, item):
        return Lazy.of(lambda value: compute_fn(value)) \
            .bind(mapper_fn) \
            .get()(item)

    def folder_fn_2(res, item):
        return Lazy.of(compute_fn) \
            .bind(lambda value: mapper_fn(value)) \
            .get()(item)


# Generated at 2022-06-12 05:18:11.919740
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.monad_try import Try

    def fn(): return 'fn'

    def mapper(value): return value


# Generated at 2022-06-12 05:18:17.551138
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(2) == Lazy.of(2)
    assert not Lazy.of(2) == Lazy.of(1)
    assert not Lazy.of(2) == Lazy.of([])
    assert not Lazy.of([]) == Lazy.of(1)
    assert not Lazy.of(2) == None
    assert not Lazy.of(2) == 1



# Generated at 2022-06-12 05:18:24.258413
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda a, b: a + b).map(lambda x: x + 1).get(1, 2) == 4
    assert Lazy(lambda a, b: a + b).map(lambda x: x + 1).get(1, 2) == 4

    assert Lazy(lambda a, b: a + b).get(1, 2) == 3
    assert Lazy(lambda a, b: a + b).get(1, 2) == 3

    assert Lazy.of(1) == Lazy.of(1)

# Generated at 2022-06-12 05:18:31.077994
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f():
        return 'I am lazy'

    f2 = lambda: 'I am lazy'

    lazy1 = Lazy(f)
    lazy2 = Lazy(f)
    lazy3 = Lazy(f2)
    lazy4 = Lazy(lambda: 'I am not lazy')

    assert lazy1 == lazy1
    assert lazy1 == lazy2
    assert lazy1 == lazy3
    assert lazy2 == lazy3

    assert lazy1 != lazy4
    assert lazy2 != lazy4
    assert lazy3 != lazy4



# Generated at 2022-06-12 05:18:38.079789
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test get method of class Lazy
    """
    lazy = Lazy(lambda x: x+1)
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(2) == 3
    assert lazy.is_evaluated



# Generated at 2022-06-12 05:18:43.241635
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    lazy = Lazy(lambda x: x)
    lazy_id = lazy.bind(lambda x: x)

    assert lazy.get(1) == 1
    assert lazy_id.get(1) == 1



# Generated at 2022-06-12 05:18:52.325064
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def function(argument):
        return argument

    lazy_1 = Lazy(function)
    lazy_2 = Lazy(function)

    assert lazy_1 == lazy_2
    assert not lazy_1 == Lazy(function).map(function)
    assert lazy_1 == Lazy(function)

    lazy_1.get(1)

    assert lazy_1 == lazy_2
    assert lazy_1.get(1) == 1
    assert lazy_2.get(1) == 1

    assert not lazy_1 == Lazy(function)

test_Lazy___eq__()


# Generated at 2022-06-12 05:18:56.468259
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_maybe import Maybe

    assert Lazy.of(1).map(lambda x: x + 1) == Lazy(lambda: 2)
    assert Lazy.of(1).map(Maybe.just).map(lambda x: x + 1) == Lazy(lambda: Maybe.just(2))



# Generated at 2022-06-12 05:19:05.155346
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.maybe import Maybe

    def inc(value):
        return value + 1

    def dec(value):
        return value - 1

    def double(value):
        return value * 2

    def double_dec(value):
        return (value * 2) - 1

    lazy_inc = Lazy(inc)
    lazy_dec = Lazy(dec)
    lazy_double = Functor(Lazy(double))
    lazy_double_dec = Lazy(double_dec)

    assert not(lazy_inc == None)
    assert not(None == lazy_inc)
    assert lazy_inc == lazy_inc
    assert lazy_dec == lazy_dec
    assert not(lazy_inc == lazy_dec)
    assert lazy_inc == Lazy(inc)

# Generated at 2022-06-12 05:19:11.916283
# Unit test for method map of class Lazy
def test_Lazy_map():
    to_upper = lambda x: x.upper()
    to_hex = lambda x: hex(x)
    to_int = lambda x: x + 1

    assert Lazy.of(3).map(to_hex).map(to_upper).get() == '0X4'
    assert Lazy.of(3).map(to_hex).map(to_upper).map(to_int).get() == '0X5'



# Generated at 2022-06-12 05:19:20.789158
# Unit test for method get of class Lazy
def test_Lazy_get():
    from itertools import zip_longest

    # Test lazy methods
    def add(x: int, y: int) -> int:
        return x + y

    def multiply(x: int, y: int) -> int:
        return x * y

    def to_string(x: int) -> str:
        return str(x)

    lazy_add = Lazy(add)

    assert lazy_add.get(1, 2) == 3
    assert lazy_add.get(3, 4) == 7
    assert lazy_add.get(5, 6) == 11

    lazy_multiply = Lazy(multiply)
    assert lazy_multiply.get(1, 2) == 2
    assert lazy_multiply.get(3, 4) == 12

# Generated at 2022-06-12 05:19:32.159606
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x + 10) == Lazy(lambda x: x + 10)
    assert Lazy(lambda x: x + 10) != Lazy(lambda x: x - 10)
    assert Lazy(lambda x: x + 10) != Lazy(lambda x, y: x + y)
    assert Lazy(lambda x: x + 10) != Lazy(lambda x: x + 10).map(lambda x: 2 * x)
    assert Lazy(lambda x: x + 10) != Lazy(lambda x: x + 10).ap(Lazy(lambda x: 2 * x))
    assert Lazy(lambda x: x + 10) != Lazy(lambda x: x + 10).bind(lambda x: Lazy(lambda y: 2 * y).of(x))

# Unit tests for method of of class Lazy

# Generated at 2022-06-12 05:19:40.584517
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    class LazyTests(Functor[T, U], Applicative[T, U], Monad[T, U]):
        FUNCTOR_METHOD = staticmethod(Lazy.map)
        APPLICATIVE_METHOD = staticmethod(Lazy.ap)
        MONAD_METHOD = staticmethod(Lazy.bind)

        def __init__(self, value: 'Lazy[T, U]') -> None:
            self.value = value

        def __str__(self) -> str:  # pragma: no cover
            return 'LazyTests[value={}]'.format(self.value)

    # Testing data types

# Generated at 2022-06-12 05:19:46.956625
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from random import random
    from pymonet.type_constructor import TypeConstructor
    from pymonet.monad_error import MonadError

    def construct(param: int) -> str:
        return 'number %s' % param

    def mapper(param: int):
        return param + 1

    def err_construct(param: str) -> TypeConstructor[str, str]:
        return MonadError.raise_error(param)

    def eq_test(test_case):
        test_case_a = test_case.copy()
        test_case_b = test_case.copy()

        assert test_case_a == test_case_b

        test_case_a.is_evaluated = not test_case_a.is_evaluated
        test_case_b.is_evaluated = not test_

# Generated at 2022-06-12 05:20:03.842521
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def identity(x: T) -> T:
        return x

    def identity2(x: T) -> T:
        return x

    assert Lazy(identity)('a').get() == 'a'
    assert Lazy(identity2)().get() == None

    assert Lazy(lambda x: x)('a').get() == 'a'
    assert Lazy(lambda x: x)().get() == None

    assert Lazy.of(None)() is None
    assert Lazy.of(None).get() is None
    assert Lazy.of(None).get() is None
    assert Lazy.of('a')() == 'a'
    assert Lazy.of('a').get() == 'a'
    assert Lazy.of('a').get() == 'a'

# Generated at 2022-06-12 05:20:14.771522
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.function import curry

    multiply = curry(lambda m, n: m * n)

    assert Lazy.of(1).ap(Lazy.of(Box.of(multiply)).get()) == Lazy.of(1)

    assert Lazy.of(1).ap(Lazy.of(Box.of(2)).map(multiply)) == Lazy.of(2)

    assert Lazy.of(Box.of(2)).ap(Lazy.of(Box.of(multiply)).get()) == Lazy.of(2)

    assert Lazy.of(Box.of(2)).ap(Lazy.of(Box.of(multiply).get())) == Lazy.of(2)

# Generated at 2022-06-12 05:20:20.452294
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(1).get() == 1
    assert Lazy(1).to_box().get() == 1
    assert Lazy(1).to_either().get() == 1
    assert Lazy(1).to_maybe().get() == 1
    assert Lazy(1).to_validation().get() == 1
    assert Lazy(1).to_try().get() == 1



# Generated at 2022-06-12 05:20:24.818643
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_func():
        pass

    def test_func_2():
        pass

    lazy = Lazy(test_func)
    lazy_2 = Lazy(test_func)
    lazy_3 = Lazy(test_func_2)

    assert lazy == lazy_2, 'Lazy is equal to himself'
    assert lazy != lazy_3, 'Lazy is not equal to another Lazy with another constructor'



# Generated at 2022-06-12 05:20:33.424153
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    val_2 = Lazy.of(2)
    val_5 = Lazy.of(5)
    val_times_2 = Lazy.of(lambda x: x * 2)
    val_times_3 = Lazy.of(lambda x: x * 3)

    assert Lazy.of(lambda x: x + 10).ap(val_2) == Lazy.of(12)
    assert val_times_2.ap(val_5) == Lazy.of(10)
    assert val_times_3.ap(val_5) == Lazy.of(15)

# Generated at 2022-06-12 05:20:36.159254
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def mapper(value):
        return value * 2

    lazy = Lazy(lambda: 1)

    assert lazy.map(mapper).ap(lazy).get() == 2


# Generated at 2022-06-12 05:20:40.910764
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fun(value):
        return value * 2
    lazy = Lazy(lambda: 2)
    result = lazy.bind(fun)
    assert result == Lazy(lambda: 4)


# Generated at 2022-06-12 05:20:47.077005
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_fn():  # pragma: no cover
        pass

    def test_lambda_fn():  # pragma: no cover
        pass

    assert Lazy(test_fn) == Lazy(test_fn)
    assert Lazy(test_fn) == Lazy(test_lambda_fn)

    lazy = Lazy(test_fn)
    lazy._compute_value()
    assert lazy == Lazy(test_fn)

# Generated at 2022-06-12 05:20:51.561942
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda i: i + 1).map(lambda i: i * 2).get(2) == 6
    assert Lazy.of('Hello').map(lambda i: i + ' ').map(lambda i: i + 'World!').get() == 'Hello World!'

# Generated at 2022-06-12 05:20:54.687378
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    assert Lazy(lambda: 4).bind(lambda x: Lazy(lambda: x + 1)).get() == 5

