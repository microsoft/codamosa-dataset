

# Generated at 2022-06-12 05:11:07.523062
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(param):
        return 'fn'

    def identity(x):
        return x

    assert Lazy(fn).get() == 'fn'
    assert Lazy(fn).map(identity).get() == 'fn'
    assert Lazy(fn).map(identity).map(identity).get() == 'fn'
    assert Lazy(fn).map(identity).map(identity).map(identity).get() == 'fn'
    assert Lazy(fn).map(identity).map(identity).map(identity).map(identity).get() == 'fn'



# Generated at 2022-06-12 05:11:11.424408
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fun(x):
        return x + 1

    lazy = Lazy(lambda x: x).bind(fun)
    assert 2 == lazy.get(1)

    def nested_fun(x):
        return Lazy(lambda x: x + 2)

    lazy = Lazy(lambda x: x).bind(nested_fun)
    assert 3 == lazy.get(1)



# Generated at 2022-06-12 05:11:17.350983
# Unit test for method get of class Lazy
def test_Lazy_get():
    def f(x):
        return x ** 3

    def g(x):
        return x + 5

    x = Lazy(f)
    assert x.get(5) == 125
    assert x.get(5) == 125

    x = Lazy(f).map(g)
    assert x.get(5) == 130



# Generated at 2022-06-12 05:11:24.359488
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Function for test Lazy bind.
    """
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def get_value(i):
        return i

    lazy_1 = Lazy.of(1)
    lazy_2 = Lazy.of(2)

    maybe_1 = Maybe.just(lazy_1)
    maybe_2 = Maybe.just(lazy_2)

    validation_1 = Validation.success(lazy_1)
    validation_2 = Validation.success(lazy_2)

    def is_even(i):
        return i % 2 == 0

    def get_even_or_nothing(maybe_lazy):
        return maybe_lazy.bind(lambda lazy: lazy.to_maybe().filter(is_even))


# Generated at 2022-06-12 05:11:27.021603
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Given
    fold_func = Lazy(lambda x, y, z: x * 2 + y * 2 + z * 2 + 10)

    def fn(args):
        x, y, z = args
        return Lazy(lambda: x * 2 + y * 2 + z * 2 + 10)

    # When
    lazy = fold_func.bind(fn)

    # Then
    assert lazy.get(1, 2, 3) == 20



# Generated at 2022-06-12 05:11:37.809509
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1


# Generated at 2022-06-12 05:11:47.254465
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def assert_property(fn: Callable[[Lazy[int, int]], Lazy[int, int]], value):
        lazy = Lazy(lambda: 5)

        assert fn(lazy).get() == value, (
            '{}(Lazy(lambda: 5)).get() == {}'.format(fn.__name__, value)
        )

    assert_property(lambda lazy: lazy.bind(lambda x: Lazy.of(x + 10)), 15)
    assert_property(lambda lazy: lazy.bind(lambda x: Lazy.of(x * 20)), 100)

# Generated at 2022-06-12 05:11:50.228558
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert not Lazy.of('a').__eq__(Lazy.of('b'))
    assert not Lazy.of('a').__eq__(object)

# Generated at 2022-06-12 05:11:52.624184
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert (Lazy(lambda x: x ** 2) == Lazy(lambda x: x ** 2)) is True

# Generated at 2022-06-12 05:12:00.242729
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test Lazy bind method

    It's impossible to test Lazy bind method without manual calling bind.
    So we test only our implementation of bind.
    """

    def first_fn(n):
        return Lazy(lambda: n + 2)

    def second_fn(n):
        return Lazy(lambda: n + 4)

    def third_fn(n):
        return n + 6

    result = Lazy(lambda: 1).bind(first_fn).bind(second_fn).map(third_fn)

    assert result.is_evaluated is False
    assert result.get() == 13
    assert result.is_evaluated is True
    assert result.get() == 13

# Generated at 2022-06-12 05:12:12.055432
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: 1).bind(lambda a: 3 * a) == Lazy(lambda x: 3)
    assert Lazy(lambda x: 2).bind(lambda a: 3 * a) == Lazy(lambda x: 6)
    assert Lazy(lambda x: 3).bind(lambda a: 3 * a) == Lazy(lambda x: 9)
    assert Lazy(lambda x: 4).bind(lambda a: 3 * a) == Lazy(lambda x: 12)
    assert Lazy(lambda x: 5).bind(lambda a: 3 * a) == Lazy(lambda x: 15)

    # it should work with more than on argument
    assert Lazy(lambda x, y, z: 1).bind(lambda a: 3 * a) == Lazy(lambda x, y, z: 3)

# Generated at 2022-06-12 05:12:20.867806
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def constructor(value: int): return value + 1
    lazy1 = Lazy(constructor)
    lazy2 = Lazy(constructor)
    lazy3 = Lazy(lambda value: value)
    lazy4 = Lazy(constructor)
    lazy4.get(1)
    lazy5 = Lazy(constructor)
    lazy5.get(2)

    assert lazy1 == lazy1
    assert lazy1 == lazy2
    assert lazy1 != lazy3
    assert lazy1 != lazy4
    assert lazy1 != lazy5

# Generated at 2022-06-12 05:12:23.661884
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x + 1).map(lambda x: x * 2).get(1) == 4
    assert Lazy(lambda x: x + 2).map(lambda x: x * 2).get(1) == 6


# Generated at 2022-06-12 05:12:31.069484
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda a: a).__eq__(Lazy(lambda a: a)) is True
    assert Lazy(lambda a: a).__eq__(Lazy(lambda a: a + 1)) is False
    assert Lazy(lambda a: a).__eq__(Lazy.of(1)) is False
    assert Lazy(lambda a: a).__eq__(123) is False
    assert Lazy(lambda a: a).__eq__(None) is False


# Generated at 2022-06-12 05:12:34.191584
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.validation import Validation

    def constructor_fn():
        return 'testValue'

    lazy = Lazy(constructor_fn).map(lambda x: x.upper())
    assert lazy.get() == 'TESTVALUE'
    assert lazy.to_validation().get_value() == 'TESTVALUE'

# Generated at 2022-06-12 05:12:35.442189
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test method map of class Lazy
    """
    result = Lazy.of(lambda x: x + 1).map(lambda x: x(1))

    assert result.get() == 2



# Generated at 2022-06-12 05:12:39.686682
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda x: x) == Lazy(lambda x: x)



# Generated at 2022-06-12 05:12:43.507006
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(2).get() == 2
    assert Lazy.of(1) \
        .map(lambda a: a + 1) \
        .map(lambda a: a + 2) \
        .get() == 4



# Generated at 2022-06-12 05:12:46.795517
# Unit test for method map of class Lazy
def test_Lazy_map():
    def value_fn(v):
        return v

    def inc_fn(v):
        return v+1

    assert Lazy(value_fn).map(inc_fn).get(1) == 2


# Generated at 2022-06-12 05:12:53.391527
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f1():
        return 5

    def f2():
        return 7

    lazy1 = Lazy(f1)
    lazy2 = Lazy(f1)
    lazy3 = Lazy(f2)
    lazy4 = Lazy(f1)
    lazy4.get()
    lazy5 = Lazy(f1)
    lazy5.get()

    assert lazy1 == lazy2
    assert not lazy1 == lazy3
    assert not lazy1 == lazy4
    assert lazy1 == lazy5

# Generated at 2022-06-12 05:13:02.351438
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    def test_fn(*args):
        return '{}, {}'.format(args[0], args[1])

    assert Lazy(test_fn).map(lambda x: x + '.').get('A', 'B') == 'A, B.'
    assert Lazy(test_fn).map(lambda x: x + '.').get('C', 'D') == 'C, D.'

# Generated at 2022-06-12 05:13:08.717678
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def equal(left, right):
        return left == right

    assert equal(Lazy.of(1), Lazy.of(1))
    assert not equal(Lazy.of(1), Lazy.of(2))
    assert not equal(Lazy.of(1), Lazy.of('1'))
    assert not equal(Lazy.of(1), Lazy.of({}))


# Generated at 2022-06-12 05:13:12.781125
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(x: int) -> int:
        return x + 1

    lazy = Lazy(add)
    assert lazy.get(4) == add(4)

    lazy = Lazy.of(4)
    assert lazy.get() == 4



# Generated at 2022-06-12 05:13:18.555489
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def add_one(number):
        return number + 1

    def mul_two(number):
        return number * 2

    # Given
    result_of_mul_two = Lazy(mul_two).map(add_one)

    # When
    value = result_of_mul_two.get(3)

    # Then
    assert value == 7



# Generated at 2022-06-12 05:13:29.171963
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x: int) -> int:
        return x + 1

    def double(x: int) -> int:
        return x * 2

    def double_if_even(x: int) -> Lazy[int, int]:
        if x % 2 == 0:
            return Lazy.of(double(x))

        return Lazy.of(x)

    lazy_double1 = Lazy.of(1).bind(double_if_even)
    lazy_double2 = Lazy.of(2).bind(double_if_even)

    assert lazy_double1.get() == 1
    assert lazy_double2.get() == 4

    lazy_add_one_to_double = lazy_double2.bind(add_one)
    assert lazy_add_one_to_double.get() == 5



# Generated at 2022-06-12 05:13:32.736864
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy.of(1).get() == 1
    lazy = Lazy(lambda: 1)
    assert lazy.get() == 1



# Generated at 2022-06-12 05:13:42.038635
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def mul(value: int) -> int:
        return value * 2

    def add(value: int) -> int:
        return value + 3

    def mul_and_add(value: int) -> int:
        return mul(value) + add(value)

    def is_even(value: int) -> bool:
        return value % 2 == 0

    def lazy_add_and_is_even(value: int) -> Lazy[int, bool]:
        return Lazy.of(is_even(mul_and_add(value)))

    assert lazy_add_and_is_even(2).get() == True
    assert lazy_add_and_is_even(3).get() == False



# Generated at 2022-06-12 05:13:52.737496
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    assert Lazy.of(1) != None
    assert Lazy.of(1) != 1
    assert Lazy.of(1) != '1'
    assert Lazy.of(1) != Lazy(lambda: 2)
    assert Lazy.of(1) != Lazy(lambda: 1)
    lazy_functor = Functor(Lazy.of(1))
    assert Lazy.of(1) != lazy_functor
    lazy_monad = Monad(Lazy.of(1))
    assert Lazy.of(1) != lazy_monad
    assert Lazy(lambda: 1) == Lazy(lambda: 1)



# Generated at 2022-06-12 05:13:56.783392
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)


# Generated at 2022-06-12 05:14:05.932445
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.function import compose

    add = lambda x, y: x + y
    add5 = lambda x: add(x, 5)
    add5_lazy = Lazy(add5)
    lazy_compose_add5 = Lazy(compose(lambda x: add(x, 5), add))
    lazy_compose_add5_same = Lazy(compose(lambda x: add(x, 5), add))

    assert Lazy.of(10) == Lazy.of(10)
    assert not Lazy.of(10) == Lazy.of('string')
    assert add5_lazy == add5_lazy
    assert add5_lazy != lazy_compose_add5
    assert lazy_compose_add5 == lazy_compose_add5_same
    assert lazy_compose

# Generated at 2022-06-12 05:14:18.181741
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(10).map(lambda x: x * 2).get() == 20

    def f(a):
        return a * 2

    def g(a):
        return a + 3

    assert Lazy(f).map(g).get() == 7

    plus = lambda a, b: a + b
    assert Lazy(lambda: plus).map(lambda f: lambda a, b: f(a, b)).get()(3, 5) == 8



# Generated at 2022-06-12 05:14:24.880490
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def multiply_by_2(x):
        return x * 2

    def multiply_by_3(x):
        return x * 3

    multiply_by_2_lazy = Lazy.of(multiply_by_2)

    multiply_by_5_lazy = multiply_by_2_lazy.bind(lambda x: Lazy.of(multiply_by_3)).bind(lambda y: Lazy.of(x(3) * y(2)))
    assert multiply_by_5_lazy.get() == 30

    multiply_by_5_lazy_again = multiply_by_2_lazy.bind(lambda x: Lazy.of(multiply_by_3)).bind(lambda y: Lazy.of(x(4) * y(4)))
    assert multiply_by_5_l

# Generated at 2022-06-12 05:14:28.135255
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 42) == Lazy(lambda: 42)
    assert not Lazy(lambda: 42) == Lazy(lambda: 24)


# Generated at 2022-06-12 05:14:37.197894
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Lazy.of(2).bind(lambda v: Lazy.of(v + 1)).get() == 3
    assert Lazy.of(2).bind(lambda v: Lazy.of(v + 1)).map(lambda v: v * 2).get() == 6
    assert Lazy.of(2).bind(lambda v: Lazy.of(v + 1)).fold(lambda v: v * 2) == 6
    assert Lazy(lambda: Maybe.of(2)).bind(lambda v: Lazy(lambda: Maybe.of(v + 1))).get().getOrElse(0) == 3

# Generated at 2022-06-12 05:14:43.548215
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    :returns: result of bind test
    :rtype: bool
    """

    def add1(v):
        return v + 1

    def add2(v):
        return v + 2

    lazy_value = Lazy.of(0).map(add1).bind(lambda v: Lazy.of(v).map(add2))

    return lazy_value.get() == 3

# Generated at 2022-06-12 05:14:53.803167
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # type: () -> None
    """Unit test for method __eq__ of class Lazy."""

    def test_method(a, b, expected_result):  # type: (Lazy, Lazy, bool) -> None
        assert a.__eq__(b) == expected_result

    test_method(Lazy(lambda: True), Lazy(lambda: True), True)
    test_method(Lazy(lambda: True), Lazy(lambda: False), False)
    test_method(Lazy(lambda: True), Lazy(lambda: True), True)
    test_method(Lazy(lambda: 1), Lazy(lambda: 1), True)
    test_method(Lazy(lambda: 1), Lazy(lambda: 2), False)



# Generated at 2022-06-12 05:14:56.402715
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert not Lazy.of(1) == Lazy.of(2)


# Generated at 2022-06-12 05:15:02.075499
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of('') == Lazy.of('')
    assert Lazy(lambda x: x) == Lazy(lambda x: x)
    assert Lazy.of('') != Lazy.of('1')
    assert Lazy(lambda x: x) != Lazy(lambda x: 1)



# Generated at 2022-06-12 05:15:11.851267
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def function(x):
        return x * 2

    assert Lazy(function).bind(Lazy(function)).get(2) == 8
    assert Lazy(function).bind(Lazy(function)).get(2) == 8
    assert Lazy(function).bind(Lazy(function)).get(2) == 8
    assert Lazy(function).bind(Lazy(function)).get(2) == 8
    assert Lazy(function).bind(Lazy(function)).get(2) == 8
    assert Lazy(function).bind(Lazy(function)).get(2) == 8
    assert Lazy(function).bind(Lazy(function)).get(2) == 8
    assert Lazy(function).bind(Lazy(function)).get(2) == 8
    assert Lazy(function).bind(Lazy(function)).get(2)

# Generated at 2022-06-12 05:15:21.342876
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    test_Lazy_get
    """
    def foo():
        return 'bar'

    assert Lazy(foo).get() == 'bar'
    assert Lazy(foo).get() == 'bar'

    def foo2(arg1, arg2, kwarg1='xyz', kwarg2=7):
        """
        function to test get method from Lazy
        """
        return '{} {} {} {}'.format(arg1, arg2, kwarg1, kwarg2)

    assert Lazy(foo2).get(1, 2, kwarg1='keyword arg') == '1 2 keyword arg 7'
    assert Lazy(foo2).get(1, 2) == '1 2 xyz 7'

# Generated at 2022-06-12 05:15:37.595759
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test ap method of Lazy class.
    """

    from pymonet.validation import Validation

    assert Lazy.of(lambda x: x + 3).ap(Lazy.of(1)) == Lazy.of(4)
    assert Lazy.of(lambda x: x + 3).ap(Validation.success(1)) == Lazy.of(4)
    assert Lazy.of(lambda x: x + 3).ap(Lazy.of(lambda o: o + 2)) == Lazy.of(lambda y: y + 5)

# Generated at 2022-06-12 05:15:43.519469
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(3) == Lazy.of(3)
    assert Lazy.of(3) != Lazy.of(2)
    assert Lazy.of(3) != Lazy(lambda: 3)
    assert Lazy.of(3) != Lazy(lambda: 2)
    assert Lazy(lambda: 3) != Lazy(lambda: 2)


# Generated at 2022-06-12 05:15:53.393767
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__(): # pylint: disable=C0111,C0103,C0116
    import pytest

    class MyLazyClass(Generic[T, U]):
        def __init__(self, constructor_fn: Callable[[T], U]) -> None:
            self.constructor_fn = constructor_fn

    lazy_1 = Lazy(lambda x: x)
    lazy_2 = Lazy(lambda x: x)
    lazy_3 = Lazy(lambda x: x)
    lazy_4 = Lazy(lambda x: x)
    lazy_5 = MyLazyClass(lambda x: x)

    assert lazy_1 == lazy_1
    assert lazy_1 == lazy_2 == lazy_3 == lazy_4
    assert lazy_1 != lazy_5


# Generated at 2022-06-12 05:16:03.396811
# Unit test for method map of class Lazy
def test_Lazy_map():
    # noinspection PyStatementEffect
    """
    >>> from pymonet.functor import Lazy as LazyL

    >>> def sum_five_to_arg(x):
    ...     return x + 5

    >>> def times_two_to_arg(x):
    ...     return x * 2

    >>> def map_fn(x):
    ...     return x + 5

    >>> LazyL.of(1).map(sum_five_to_arg).get()
    6
    >>> LazyL.of(1).map(sum_five_to_arg).map(times_two_to_arg).get()
    12
    >>> LazyL.of(1).map(map_fn).get()
    6
    """



# Generated at 2022-06-12 05:16:13.795408
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert not Lazy(lambda: 1) == Lazy(lambda: 2)
    assert not Lazy(lambda: 1) == 1
    assert not Lazy(lambda: 1).map(lambda x: x + 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1).map(lambda x: x + 1) == Lazy(lambda: 1).map(lambda x: x + 1)
    assert not Lazy(lambda: 1).map(lambda x: x + 1) == Lazy(lambda: 1).map(lambda x: x + 2)

# Generated at 2022-06-12 05:16:17.651400
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(10) == Lazy.of(10)
    assert Lazy.of(10) != Lazy.of(20)

    left = Lazy(lambda x: x).map(lambda x: x + 5)
    right = Lazy(lambda x: x + 5)
    assert left != right

# Generated at 2022-06-12 05:16:20.678010
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda : 2).bind(lambda x: Lazy(lambda _: x + 3)).get() == 5


# Generated at 2022-06-12 05:16:25.897685
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(a):
        return a + 1

    def multiply_by_two(a):
        return a * 2

    def add_one_and_multiply_by_two(a):
        return add_one(a) * 2

    assert Lazy(add_one).bind(multiply_by_two).get(2) == 6
    assert Lazy(add_one_and_multiply_by_two).get(2) == 6


# Generated at 2022-06-12 05:16:33.515407
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def get_lazy_with_constant_function(value):
        def constant_function():
            return value

        return Lazy(constant_function)

    lazy1 = get_lazy_with_constant_function(1)
    lazy2 = get_lazy_with_constant_function(1)
    lazy3 = get_lazy_with_constant_function(2)

    assert lazy1 == lazy2
    assert lazy1 != lazy3
    assert lazy2 != lazy3


# Generated at 2022-06-12 05:16:38.509968
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def function(value):
        return Lazy.of(value ** 2)

    lazy = Lazy.of(2)

    assert lazy.bind(function) == Lazy.of(4)



# Generated at 2022-06-12 05:17:05.286655
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pymonet.syntax
    f = lambda x: x + 1
    g = lambda x: x + 5
    h = lambda x: x + 3

    res = Lazy(f).bind(lambda x: Lazy(g).map(h).bind(lambda y: Lazy(lambda z: x + y + z))).get(5)
    assert res == 15

    res = Lazy(f) >> (lambda x: Lazy(g) >> (lambda y: Lazy(lambda z: x + y + z).map(h))).get(5)
    assert res == 15

    res = pymonet.syntax.do(Lazy(f)) >> (lambda x: Lazy(g) >> (lambda y: Lazy(lambda z: x + y + z).map(h))).get(5)

# Generated at 2022-06-12 05:17:08.843186
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def fn_exception():
        raise Exception()

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(2) != Lazy(fn_exception)

# Generated at 2022-06-12 05:17:14.328819
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def pow2(num):
        return num ** 2

    def to_float(num):
        return float(num)

    lazy = Lazy(pow2).bind(to_float)
    assert lazy.is_evaluated == False

    result = lazy.get(2)
    assert lazy.is_evaluated == True
    assert result == 4.0


# Generated at 2022-06-12 05:17:20.771339
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 'foo') == Lazy(lambda: 'foo')
    assert not Lazy(lambda: 'foo') == Lazy(lambda: 'bar')

    def return_foo():
        return 'foo'

    assert Lazy(return_foo) == Lazy(return_foo)
    assert not Lazy(return_foo) == Lazy(lambda: 'foo')

assert test_Lazy___eq__()



# Generated at 2022-06-12 05:17:25.997127
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe

    def function(_):
        return Maybe.just('some value')

    assert Lazy.of(None).bind(function) == Lazy(function)
    assert Lazy.of(None).bind(function).get() == Maybe.just('some value')

# Generated at 2022-06-12 05:17:35.623607
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    # Test 1: comparing Lazy with None and any type
    assert not Lazy(lambda: None) == None
    assert not Lazy(lambda: None) == 1
    assert not Lazy(lambda: None) == '1'
    assert not Lazy(lambda: None) == []
    assert not Lazy(lambda: None) == ()
    assert not Lazy(lambda: None) == {}
    assert not Lazy(lambda: None) == set()
    assert not Lazy(lambda: None) == {'1': 2}


    # Test 2: comparing Lazy without evaluation
    assert Lazy(lambda: None) == Lazy(lambda: None)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)

# Generated at 2022-06-12 05:17:41.035674
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.either import Left

    f = Lazy(lambda x: Left(x * 2))
    g = Lazy(lambda x: Left(x * 2))
    h = Lazy(lambda x: Left(x * 3))

    assert f == f
    assert f == g
    assert f != h



# Generated at 2022-06-12 05:17:50.308995
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.maybe import Maybe

    b2 = Lazy(lambda num: num + 3).bind(lambda x: Maybe.just(x * 2))
    assert b2 == b2
    assert Lazy(lambda num: num).get(11) == 11
    assert Lazy(lambda num: num).get(3) == 3
    assert Lazy(lambda num: num).get(2) != 3
    assert Lazy(lambda num: num).get(11) != 3
    assert Lazy(lambda num: num).get(2) == 2
    assert Lazy(lambda num: num + 2).get(3) != 5
    assert Lazy(lambda num: num + 2).get(3) == 5

# Generated at 2022-06-12 05:18:01.492350
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    class A:
        pass

    class B:
        pass

    fn_arg_1 = A()
    fn_arg_2 = B()
    fn_arg_3 = A()

    def fn1(arg1: A, arg2: B, arg3: A) -> None:
        pass

    def fn2(arg1: A, arg2: B, arg3: A) -> None:
        pass

    fn1_lazy_1 = Lazy(fn1)
    fn1_lazy_2 = Lazy(fn1)

    fn2_lazy_1 = Lazy(fn2)
    fn2_lazy_2 = Lazy(fn2)
    fn2_lazy_3 = Lazy(fn2)


# Generated at 2022-06-12 05:18:05.965816
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test_mapper(value):
        return value + 1

    fn = lambda x: x + 1

    lazy_1 = Lazy.of(1)
    lazy_2 = Lazy(fn)

    assert lazy_1.map(test_mapper).get() == 2
    assert lazy_2.map(test_mapper).get(2) == 4



# Generated at 2022-06-12 05:18:50.181692
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # Given
    constructor_fn = lambda x: x
    lazy = Lazy(constructor_fn)
    other = Lazy(lambda y: y)

    # When
    result = lazy == other

    # Then
    assert not result

    # Given
    other = Lazy(constructor_fn)

    # When
    result = lazy == other

    # Then
    assert result

    # Given
    other = 'Lazy(constructor_fn)'

    # When
    result = lazy == other

    # Then
    assert not result



# Generated at 2022-06-12 05:18:54.619088
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(2).get() == 2
    assert Lazy.of(2).map(lambda a: a * 2).get() == 4
    assert Lazy.of(2).map(lambda a: a * 2).map(lambda a: a * 2).get() == 8



# Generated at 2022-06-12 05:18:58.396217
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(*args):
        return 'lazy result'

    x = Lazy(fn)
    y = Lazy(fn)

    assert x == y



# Generated at 2022-06-12 05:19:04.306149
# Unit test for method map of class Lazy
def test_Lazy_map():
    def identitiy(value):
        return value

    def double(value):
        return value * 2

    lazy_unary_identity_double = Lazy.of(identitiy).map(double)
    assert lazy_unary_identity_double.constructor_fn == double

    empty_lazy = Lazy.of(identitiy).map(lambda x: x)
    assert empty_lazy.constructor_fn == identitiy

    assert lazy_unary_identity_double.get(100) == 200



# Generated at 2022-06-12 05:19:11.616505
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    """
    Unit test for method __eq__ of class Lazy.
    """
    from pymonet.utils import eq

    assert eq(Lazy(lambda: 1), Lazy(lambda: 1))
    assert eq(Lazy(lambda x: x + 1), Lazy(lambda x: x + 1))
    assert not eq(Lazy(lambda: 1), Lazy(lambda x: x + 1))



# Generated at 2022-06-12 05:19:20.601001
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f1(x):  # pragma: no cover
        pass

    def f2(x):  # pragma: no cover
        pass

    assert (
        Lazy(f1).map(lambda x: x + 1) ==
        Lazy(f1).map(lambda x: x + 1)
    )

    assert not (
        Lazy(f1).map(lambda x: x + 1) ==
        Lazy(f2).map(lambda x: x + 1)
    )

    assert not (
        Lazy(f1).map(lambda x: x + 1) ==
        Lazy(f1).map(lambda x: x + 2)
    )


# Generated at 2022-06-12 05:19:25.815924
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Function to test bind method of class Lazy.

    :return: None
    """
    bound_lazy_value = Lazy.of(lambda x: x + 1).bind(lambda x: Lazy.of(x(1)))
    assert bound_lazy_value.get() == 2, 'assert bound lazy value'

# Generated at 2022-06-12 05:19:32.521201
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_list import List

    def to_list(a: int) -> List[int]:
        return List.monad_list(list(range(1, a + 1)))

    lazy_three = Lazy.of(to_list).ap(Lazy.of(10))
    assert lazy_three.get() == List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)



# Generated at 2022-06-12 05:19:36.006933
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    n = 10
    lazy_number = Lazy.of(n)
    def double_number(n):
        return Lazy.of(n * 2)

    assert lazy_number.bind(double_number).get() == n * 2



# Generated at 2022-06-12 05:19:38.876756
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.logic import id

    my_Lazy = Lazy(id)

    assert my_Lazy.get(3) == 3


# Generated at 2022-06-12 05:20:24.967159
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    """
    Unit test for method get of class Lazy
    """
    lazy = Lazy.of(2)
    assert lazy.get() == 2

    def function():
        print('Function called')
        return 3

    lazy = Lazy(function)
    assert lazy.get() == 3

    def function():
        print('Function called')
        return 3

    lazy = Lazy(function)
    lazy.get()
    assert lazy.get() == 3

    def function():
        print('Function called')
        return 3

    lazy = Lazy(function)
    lazy.get()
    assert lazy.is_evaluated
    assert lazy.value == 3

    def function(arg):
        print('Function called')
        return arg

    lazy = Lazy(function)

# Generated at 2022-06-12 05:20:32.246008
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def get_value(lazy):
        def double(value):
            lazy.bind(lambda _: Lazy.of(value * 2))
        return lazy.fold(double)

    assert get_value(Lazy(lambda: 20)) == 40
    assert get_value(Lazy(lambda: "Hello")) == 'HelloHello'
    assert get_value(Lazy(lambda: False)) is False
    assert get_value(Lazy(lambda: None)) is None

# Generated at 2022-06-12 05:20:34.792213
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy(lambda: 5).get() == 5

# Generated at 2022-06-12 05:20:41.640635
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    assert Lazy.of(2).map(lambda x: x + 1).ap(Lazy.of(lambda x: x * 2)).get() == 6
    assert Lazy.of(1).ap(Lazy.of(None)).get() == None
    assert Lazy.of(1).ap(Lazy.of(2)).get() == 2


# Generated at 2022-06-12 05:20:47.036432
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2
    assert Lazy(lambda: (lambda x: x + 1)).ap(Lazy(lambda: 1)).get() == 2
    assert Lazy(lambda: (lambda x: x + 1)).ap(Lazy(lambda: 1)).ap(Lazy(lambda: 2)).get() == 3

# Generated at 2022-06-12 05:20:51.942914
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(arg: int) -> Lazy[int, str]:
        return Lazy(lambda: str(arg + 1))

    assert Lazy(lambda: 1).bind(fn).fold() == '2'
    assert Lazy(lambda: 1).bind(fn).is_evaluated is False


# Generated at 2022-06-12 05:21:02.392217
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda y: y))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x, y: x))
    assert not Lazy(lambda x, y: x).__eq__(Lazy(lambda x: x))
    assert not Lazy(lambda x: x).__eq__(Lazy.of(1))
    assert not Lazy(lambda x: x).__eq__(1)

