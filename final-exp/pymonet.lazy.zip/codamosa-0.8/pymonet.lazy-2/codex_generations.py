

# Generated at 2022-06-12 05:11:04.476660
# Unit test for method get of class Lazy
def test_Lazy_get():
    def plus_one(argument):
        return argument + 1

    assert Lazy.of(1).get() == 1
    assert Lazy.of(plus_one(1)).get() == 2
    assert Lazy.of(plus_one).get()(1) == 2


# Generated at 2022-06-12 05:11:07.473211
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert(Lazy.of(1) == Lazy.of(1))
    assert(Lazy.of(1) != Lazy.of(2))

# Unit tests for method number_less_than_5

# Generated at 2022-06-12 05:11:13.241883
# Unit test for method map of class Lazy
def test_Lazy_map():
    add1 = lambda x: x + 1
    add2 = lambda x: x + 2
    add3 = lambda x: x + 3

    assert Lazy(add1).map(add2).map(add3).get(0) == 6
    assert Lazy(add1).map(add2).map(add3).get(-1) == 5
    assert Lazy(add1).map(add2).map(add3).constructor_fn == add1
    assert Lazy(add1).map(add2).get(0) == 3
    assert Lazy(add1).map(add2).constructor_fn == add1


# Generated at 2022-06-12 05:11:18.226958
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_a = Lazy.of(lambda: 10)
    lazy_b = Lazy.of(lambda: 10)
    assert lazy_a != lazy_b

    lazy_a = Lazy.of(lambda x: x)
    lazy_b = Lazy.of(lambda x: x)
    assert lazy_a == lazy_b



# Generated at 2022-06-12 05:11:24.090900
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.functor import Functor

    class ApLazy(Functor[Lazy]):
        def __init__(self, value: int) -> None:
            self.value = value

        def map(self, mapper: callable) -> Functor:
            return ApLazy(mapper(self.value))

        def ap(self, applicative):
            return applicative.to_box().map(lambda x: self.value + x)

    lazy = Lazy.of(10)
    assert lazy.ap(Lazy.of(2)).get() == 12
    assert lazy.ap(ApLazy(2)).to_box().get() == 12



# Generated at 2022-06-12 05:11:30.453351
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    """
    Unit test for method __eq__ of class Lazy.

    Call the code to test it.
    """
    def fn(value):
        return value

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn)


# Generated at 2022-06-12 05:11:34.424654
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # GIVEN
    lazy = Lazy.of(1)

    # THEN
    assert lazy == lazy
    assert lazy == Lazy.of(1)
    assert lazy != Lazy.of(2)
    assert lazy == Lazy(lambda: 1)
    assert lazy != Lazy(lambda: 2)


# Generated at 2022-06-12 05:11:36.286434
# Unit test for method map of class Lazy
def test_Lazy_map():
    def fn():
        return 1

    lazy = Lazy(fn)
    lazy_with_mapper = lazy.map(lambda x: x + 2)
    assert lazy_with_mapper.get() == 3


# Generated at 2022-06-12 05:11:41.738338
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != 1



# Generated at 2022-06-12 05:11:50.362074
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy.of(0)

    assert lazy.get('no args') == 0

    lazy = Lazy(lambda x: 3 * x)

    assert lazy.get(int) == 0

    lazy = Lazy(lambda x: 3 * int(x))

    assert lazy.get(3.3) == 9

    lazy = Lazy(lambda x: 3 * int(x))

    assert lazy.get('3') == 9



# Generated at 2022-06-12 05:11:55.546824
# Unit test for method get of class Lazy
def test_Lazy_get():
    def func_that_returns_five(*args):
        return 5

    assert Lazy(func_that_returns_five).get() == 5


# Generated at 2022-06-12 05:12:00.513613
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of('initial').map(lambda v: '{} result'.format(v)) == Lazy.of('initial result')
    assert Lazy.of('initial').map(lambda v: '{} result'.format(v)).map(lambda v: '{} result'.format(v)) == Lazy.of('initial result result')



# Generated at 2022-06-12 05:12:04.501167
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    a = Lazy(lambda: 123)
    b = Lazy(lambda: 123)
    c = Lazy(lambda: 456)
    assert a == b
    assert a == a
    assert a != c



# Generated at 2022-06-12 05:12:07.409688
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(3) == Lazy.of(3)
    assert Lazy.of(3) != Lazy.of(4)



# Generated at 2022-06-12 05:12:11.133030
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    # Given
    first_lazy = Lazy.of(lambda x: x+1)
    second_lazy = Lazy.of(2)

    # When
    result = first_lazy.ap(second_lazy)

    # Then
    assert result.get() == 3

# Generated at 2022-06-12 05:12:16.303152
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(input):
        def get_value():
            return input

        return Lazy(get_value)

    assert Lazy.of(2).bind(fn) == Lazy.of(2)
# End of test_Lazy_bind



# Generated at 2022-06-12 05:12:21.520766
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(a):
        return a

    assert Lazy(test_fn).get(1) == 1
    assert Lazy(test_fn).get(2) == 2
    assert Lazy(test_fn).get(3) == 3
    assert Lazy(test_fn).get(4) == 4

# Generated at 2022-06-12 05:12:25.262250
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(*args):
        return args

    assert Lazy(fn) == Lazy(fn)
    assert not (Lazy(fn) == Lazy(lambda *args: args[0] + args[1]))
    assert not (Lazy(fn) == Lazy(lambda *args: args))
    assert not (Lazy(fn) == None)



# Generated at 2022-06-12 05:12:36.365733
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(8).map(lambda x: x * x).get() == 64
    assert Lazy.of(8).map(Box.of).get().get() == 8
    assert Lazy.of(8).map(Right.of).get().get_or_else(lambda: None) == 8
    assert Lazy.of(8).map(Maybe.just).get().get_or_else(lambda: None) == 8
    assert Lazy.of(8).map(lambda x: x * x).to_box().get() == 64

# Generated at 2022-06-12 05:12:41.419895
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    def increment(n):
        return Lazy.of(n + 1)

    assert Lazy(lambda: 1).bind(lambda x: increment(x)) == Lazy(lambda: 2)

    assert Lazy(lambda: 1).bind(lambda x: Lazy.of("Lazy[value={}]".format(x))) == Lazy(lambda: "Lazy[value=1]")



# Generated at 2022-06-12 05:12:48.577643
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation

    lazy = Lazy.of(1).map(lambda x: x + 1)

    validation = Validation.success(lambda x: x + 1)
    new_lazy = lazy.ap(validation)

    assert new_lazy.get() == 3

# Generated at 2022-06-12 05:12:54.702636
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test(): pass
    def test2(): pass
    def test3(): pass

    lazy = Lazy(test)
    lazy2 = Lazy(test2)
    lazy3 = Lazy(test3)

    assert lazy == lazy
    assert lazy != lazy2
    assert lazy != lazy3
    assert lazy2 != lazy
    assert lazy2 != lazy3
    assert lazy3 != lazy
    assert lazy3 != lazy2



# Generated at 2022-06-12 05:13:03.646245
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert (
        Lazy.of([5])
        .ap(Lazy.of(lambda v: v * 2.0))
        .get()
    ) == [10.0]

    assert (
        Lazy.of('hi')
        .ap(Lazy.of(lambda v: v + ' there'))
        .get()
    ) == 'hi there'

    assert (
        Lazy.of(lambda v, x: v + x)
        .ap(Lazy.of(5))
        .ap(Box('hi'))
        .get()
    ) == 'hi5'


# Generated at 2022-06-12 05:13:07.308806
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != 2



# Generated at 2022-06-12 05:13:10.194767
# Unit test for method ap of class Lazy
def test_Lazy_ap(): # pragma: no cover
    Lazy(lambda x: x ** 2).ap(Lazy(lambda x: x**2)).get(2) == Lazy(lambda x: x ** 2).map(lambda x: x**2).get(2)


# Generated at 2022-06-12 05:13:15.597738
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(3).get() == 3
    assert Lazy.of(3).map(lambda x: x + 1).get() == 4
    assert Lazy.of([1, 2, 3]).map(lambda x: list(map(lambda y: y + 1, x))).get() == [2, 3, 4]

# Generated at 2022-06-12 05:13:26.762708
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(a):
        return a + 1

    def fn_with_wrap(a):
        return Maybe.of(a + 1)

    def fn_with_box(a):
        return Box(a + 1)

    def fn_with_try(a):
        return Try.of(lambda x: x + 1, a)

    def fn_with_validation(a):
        return Validation(a + 1)

    assert Lazy(lambda x: x + 1).map(fn).bind(fn_with_wrap) == Maybe.of(3)

# Generated at 2022-06-12 05:13:37.889596
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Left
    from pymonet.maybe import Maybe

    def _fn(x):
        return Box(x * 2)

    assert Lazy.of(2).bind(_fn) == Lazy(lambda *args: Box(4))

    def _fn(x):
        return Left(x * 2)

    assert Lazy.of(2).bind(_fn) == Lazy(lambda *args: Left(4))

    def _fn(x):
        return Maybe.just(x * 2)

    assert Lazy.of(2).bind(_fn) == Lazy(lambda *args: Maybe.just(4))


# Generated at 2022-06-12 05:13:48.741452
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for Lazy bind method
    """
    LazyOf1 = Lazy.of(1)
    LazyOf2 = Lazy.of(2)
    LazyOf3 = Lazy.of(3)

    LazyOfLazy1 = Lazy.of(LazyOf1)
    LazyOfLazy2 = Lazy.of(LazyOf2)
    LazyOfLazy3 = Lazy.of(LazyOf3)

    assert LazyOf1.bind(Lazy.of) == LazyOf1
    assert LazyOf1.bind(LazyOf2.constructor_fn) == LazyOf2
    assert LazyOfLazy1.bind(Lazy.of) == LazyOfLazy1

# Generated at 2022-06-12 05:13:52.265269
# Unit test for method map of class Lazy
def test_Lazy_map():
    a = Lazy.of(5)
    b = a.map(lambda x: x + 5)

    assert a.get() == 5
    assert b.get() == 10



# Generated at 2022-06-12 05:14:01.477043
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1
    lazy = Lazy(fn)
    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(fn)

    assert lazy == lazy
    assert lazy == lazy1
    assert lazy != lazy2
    assert lazy1 != lazy2
    assert lazy2 != lazy3

# Generated at 2022-06-12 05:14:04.219370
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.applicative import Applicative
    assert Lazy.of('a').ap(Lazy.of(lambda a: 'b')) == Lazy.of('b')



# Generated at 2022-06-12 05:14:11.594940
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(3) == Lazy.of(3)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(3)
    assert Lazy.of(2) != Lazy.of(3)


# Generated at 2022-06-12 05:14:14.960360
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box

    constructor_fn = lambda value: Box(value)
    lazy = Lazy(constructor_fn)

    assert lazy.get(1).get() == 1



# Generated at 2022-06-12 05:14:20.219509
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Create Lazy and call get method with value 'x'.
    Expected result is 'x' because mock_fn returns 'x' without any modification.
    """
    mock_fn = mock.MagicMock(return_value='x')
    lazy = Lazy(mock_fn)
    result = lazy.get('x')  # type: ignore

    mock_fn.assert_called_once_with('x')
    assert result == 'x'



# Generated at 2022-06-12 05:14:31.399193
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def get_a():
        return 1

    def get_b():
        return 2

    instance_a = Lazy(get_a)
    instance_a.get()

    instance_b = Lazy(get_a)
    instance_b.get()

    instance_c = Lazy(get_b)
    instance_c.get()

    # Test symmetry
    assert instance_a == instance_b
    assert instance_b == instance_a

    assert not instance_a == instance_c
    assert not instance_c == instance_a

    assert instance_a != instance_c
    assert instance_c != instance_a

    assert not instance_b == instance_c
    assert not instance_c == instance_b

    assert instance_b != instance_c
    assert instance_c != instance_b



# Generated at 2022-06-12 05:14:35.053552
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert (
        Lazy(lambda: 1)
        .bind(lambda x: Lazy(lambda: x + 1))
        .bind(lambda x: Lazy(lambda: x * 2))
        .get()
        == 4
    )


# Generated at 2022-06-12 05:14:43.077399
# Unit test for method get of class Lazy
def test_Lazy_get():

    assert Lazy(lambda x, y=5: x+y).get(5) == 10
    assert Lazy(lambda: 5).get() == 5
    assert Lazy(lambda: None).get() is None
    assert Lazy(lambda x: x+2).get(2, 3) == 4
    assert Lazy(lambda x, y: x+y).get(5, y=5) == 10

    assert Lazy(lambda x=5: x).get() == 5


# Generated at 2022-06-12 05:14:46.918049
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    a = Lazy(lambda: 2)
    b = Lazy(lambda x: x ** 2)
    assert a.ap(b) == Lazy(lambda: 4)



# Generated at 2022-06-12 05:14:55.562939
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_fn(*args):
        return args

    assert Lazy(lambda *args: args) == Lazy(lambda *args: args)
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of("str") == Lazy.of("str")

    assert not Lazy(test_fn) == Lazy(test_fn)
    assert not Lazy.of("str") == Lazy.of("str2")
    assert not Lazy.of("str1") == Lazy.of("str2")
    assert not Lazy.of("str2") == Lazy.of("str1")
    assert not Lazy.of(1) == Lazy.of(2)
    assert not Lazy.of(1) == Lazy.of("1")

# Generated at 2022-06-12 05:15:02.126249
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    >>> Lazy.of(10) \
    ...     .bind(lambda a: Lazy(lambda: a + 1)) \
    ...     .get()
    11
    """

    pass



# Generated at 2022-06-12 05:15:07.803870
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = lambda x: x + 1
    f_cmp = lambda x: x + 1
    f_not_cmp = lambda x: x + 2

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) == Lazy(f_cmp)
    assert not Lazy(f) == Lazy(f_not_cmp)


# Generated at 2022-06-12 05:15:13.143338
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def method_to_bind(argument):
        return 2 * argument

    lazy = Lazy(lambda *args: 42)
    lazy.bind(method_to_bind)
    assert lazy.get() == 84

    lazy = Lazy(lambda *args: 42)
    lazy.bind(method_to_bind).bind(method_to_bind)
    assert lazy.get() == 168

    lazy = Lazy(lambda x: x + 1)
    lazy.bind(lambda x: Lazy(lambda: x + 2))
    assert lazy.get() == 4



# Generated at 2022-06-12 05:15:19.176429
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Tests the Lazy.bind method
    """
    from pymonet.validation import Validation, Success, Failure

    assert Lazy.of(5).bind(lambda x: Lazy.of(x + 10)).get() == 15
    assert Lazy.of(5).bind(
        lambda x: Failure('fail') if x < 0 else Success(x + 10)
    ).to_validation().get_value() == 15



# Generated at 2022-06-12 05:15:27.113151
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x: int) -> int:
        return x + 1

    def mul_with_x(x: int) -> int:
        return lambda y: y * x

    assert Lazy.of(2).bind(mul_with_x).get(4) == 8

    assert Lazy.of(2).map(add_one).bind(mul_with_x).get(4) == 10


# Generated at 2022-06-12 05:15:29.944642
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # when
    actual = Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))

    # then
    assert 2 == actual.get()



# Generated at 2022-06-12 05:15:34.825594
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    """
    Unit test for method get of class Lazy
    """
    def test_fn():
        return 1

    lazy_fn = Lazy(test_fn)
    assert lazy_fn.get() == 1
    assert lazy_fn.get() == 1


# Generated at 2022-06-12 05:15:39.457123
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test map method for Lazy class.
    """
    is_12_lazy = Lazy(lambda x: x * 2)
    is_12 = lambda x: x == 12

    assert is_12_lazy.map(is_12).get(6)



# Generated at 2022-06-12 05:15:46.952051
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def compute_value():
        return []

    def map_fn(value):
        return value + 1

    def ap_fn(value):
        return value + 1

    def bind_fn(value):
        return Lazy.of(value + 1)

    lazy = Lazy(compute_value)
    value = lazy.bind(bind_fn).map(map_fn).ap(ap_fn).get()
    assert value == 1



# Generated at 2022-06-12 05:15:58.916364
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_function_generator(arg):
        def test_function():
            return 'Value is {}'.format(arg)
        return test_function

    def test_function_mapper(arg):
        def test_function(value):
            return 'Mapped {}'.format(value)
        return test_function

    def test_function_builder(arg):
        def test_function(value):
            return 'Mapped {}'.format(value)
        return Lazy(test_function)

    lazy_fn = Lazy('Test')
    lazy_fn_not_empty

# Generated at 2022-06-12 05:16:04.546950
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def test_function():
        return 42

    lazy = Lazy(test_function)

    assert lazy.get() == 42



# Generated at 2022-06-12 05:16:15.271139
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    succ = lambda x: x + 1
    lazy_succ = Lazy(succ)

    lazy_succ_of_10 = lazy_succ.of(10)
    assert lazy_succ_of_10.ap(lazy_succ).get() == 12
    assert lazy_succ_of_10.ap(lazy_succ).to_maybe().get() == 12
    assert lazy_succ_of_10.ap(Lazy(succ)).to_maybe().get() == 12

    another_lazy_succ_of_10 = lazy_succ.of(10)
    assert lazy_succ_of_10 == another_lazy_succ_of_10
    assert lazy_succ_of_10.ap(lazy_succ) == another_lazy_succ_of_

# Generated at 2022-06-12 05:16:19.546743
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    a = Lazy.of(1)
    b = Lazy.of(1)

    assert a == b
    assert not (a != b)
    assert a.constructor_fn(1) == 1
    assert a.get(1) == 1

    a = Lazy.of(None)
    b = Lazy.of(None)

    assert a == b
    assert not (a != b)
    assert a.constructor_fn() == None
    assert a.get() == None

# Generated at 2022-06-12 05:16:22.998525
# Unit test for method map of class Lazy
def test_Lazy_map():
    def increment(x):
        return x + 2

    def square(x):
        return x ** 2

    lazy = Lazy(lambda: 1).map(increment).map(square)
    assert lazy.get() == 9



# Generated at 2022-06-12 05:16:25.242729
# Unit test for method get of class Lazy
def test_Lazy_get():
    # given
    lazy = Lazy(lambda x: x)

    # when
    result = lazy.get(1)

    # then
    assert result == 1


# Generated at 2022-06-12 05:16:31.210496
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn_1(*args):
        return 1 * args[0]

    def fn_2(*args):
        return 2 * args[0]

    assert Lazy(fn_1) == Lazy(fn_1)
    assert Lazy(fn_2) != Lazy(fn_1)



# Generated at 2022-06-12 05:16:38.138519
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_ = Lazy(lambda x: x + 1)

    assert lazy_.map(lambda x: x * 2).get(2) == 6
    assert lazy_.constructor_fn.__name__ == '<lambda>'
    assert lazy_.map(lambda x: x * 2).constructor_fn.__name__ == '<lambda>'


# Generated at 2022-06-12 05:16:45.034650
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f_constructor(x):
        return x + 2

    lazy1 = Lazy(f_constructor)
    lazy2 = Lazy(f_constructor)
    assert lazy1 != lazy2
    assert lazy1 != f_constructor
    assert lazy1 == lazy1
    assert lazy2 == lazy2

    lazy1.get(2)
    assert lazy1 == lazy1
    assert lazy1 != lazy2

    lazy2.get(2)
    assert lazy1 == lazy2


# Generated at 2022-06-12 05:16:56.946991
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(
        lambda x: Lazy.of(x + 1)
    ) == Lazy.of(2)

    assert Lazy.of(1).bind(
        lambda x: Lazy.of(x + 1)
    ).bind(
        lambda y: Lazy.of(y + 2)
    ) == Lazy.of(4)

    assert Lazy.of(1).bind(
        lambda x: Lazy.of(x + 1)
    ).bind(
        lambda y: Lazy.of(y + 2)
    ).bind(
        lambda z: Lazy.of(z + 3)
    ) == Lazy.of(7)


# Generated at 2022-06-12 05:17:00.962637
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_maybe import Maybe

    def fn(value):
        return Maybe.just(value)

    lazy = Lazy(lambda x: x).bind(fn)
    assert lazy.get(6) == 6
    assert lazy.get(None) is None


# Generated at 2022-06-12 05:17:07.329590
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    # Given
    a = Lazy.of(12)
    # When
    result = a.get()
    # Then
    assert result == 12


# Generated at 2022-06-12 05:17:14.384711
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test method get of class Lazy.

    Call constructor, get value and check if method evaluate constructor only once and next time
    return previously evaluated value.
    """
    def constructor():
        constructor.call_count += 1

        return 10

    constructor.call_count = 0

    lazy = Lazy(constructor)
    assert lazy.get() == 10
    assert constructor.call_count == 1
    assert lazy.get() == 10
    assert constructor.call_count == 1



# Generated at 2022-06-12 05:17:23.129746
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy.of(1)
    assert Lazy.of(1).map(lambda x: x + 1) != Lazy.of(1).map(lambda x: x + 2)
    assert Lazy.of(1).map(lambda x: x + 1) != Lazy.of(2).map(lambda x: x + 1)


# Generated at 2022-06-12 05:17:27.317143
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def func_to_store(a):
        return a

    lazy = Lazy(func_to_store)

    assert lazy.get(1) == 1

    assert lazy.get(None) is None


# Generated at 2022-06-12 05:17:29.737784
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1).__eq__(Lazy.of(1))
    assert not Lazy.of(1).__eq__(Lazy.of(2))



# Generated at 2022-06-12 05:17:33.114043
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_curry import curry

    fn = curry(lambda a, b: a + b)
    a = Lazy(fn(1))

    assert a.bind(lambda x: Lazy(x + 2)).get() == 4

# Generated at 2022-06-12 05:17:44.379728
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 2)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x)
    assert Lazy(lambda x: x + 1) != Lazy(lambda: None)
    assert Lazy(lambda: None) != Lazy(lambda x: x + 1)
    assert Lazy(lambda: None) == Lazy(lambda: None)
    assert Lazy(lambda: None) != Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: None)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)


# Generated at 2022-06-12 05:17:47.855062
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    assert Lazy.of(5).map(lambda x: x + 5).get() == 10
    assert Lazy(lambda x: x + 5).map(lambda x: x + 5).get(5) == 15

# Generated at 2022-06-12 05:17:57.117863
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1(a: int) -> str:
        return str(a + 1)
    def fn2(a: int) -> str:
        return str(a + 2)
    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn2).map(lambda x: x)
    assert Lazy(fn1) != Lazy(fn2).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x).ap(Lazy(fn2))


# Generated at 2022-06-12 05:17:59.932141
# Unit test for method get of class Lazy
def test_Lazy_get():
    def _constructor_fn():
        return 5

    assert Lazy(_constructor_fn).get() == _constructor_fn()


# Unit tests for Lazy.of

# Generated at 2022-06-12 05:18:05.841372
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(1).ap(Lazy.of(lambda x : x + 1)).get() == 2

    assert Lazy.of(1).ap(Lazy.of(lambda x : x + 1)).ap(Lazy.of(lambda x : x + 2)).get() == 3

# Generated at 2022-06-12 05:18:12.800198
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.functor import Functor

    def fn(*args):
        return Maybe(args)

    assert (Lazy(fn) == Lazy(fn)) is True, 'Lazy with same values must be equals'

    fn_1 = lambda: 1
    fn_1.__name__ = 'fn_1'
    fn_2 = lambda: 1
    fn_2.__name__ = 'another_fn'
    assert Lazy(fn_1) != Lazy(fn_2), 'Lazy with different function name must be not equals'

    lazy_fn = Lazy(fn)

# Generated at 2022-06-12 05:18:22.078903
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy.of(4).get() == Lazy(lambda: 4).get() == Lazy(lambda: 4).to_box().get() == 4 == Lazy.of(4).to_box().get()

    assert (
        Lazy.of(4)
        .map(lambda a: a * a)
        .map(lambda a: a * a)
        .map(lambda a: a * a)
        .map(lambda a: a * a)
        .get()
    ) == 4 ** 8 == Lazy(lambda: 4).map(lambda a: a * a).map(lambda a: a * a).map(lambda a: a * a).map(lambda a: a * a).get()


# Generated at 2022-06-12 05:18:25.854544
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def bind_fn(value):
        return Lazy.of(value*2)

    assert (
        Lazy.of(2).bind(bind_fn) == Lazy.of(4)
    ), 'Lazy should be equal when they are evaluated'

# Generated at 2022-06-12 05:18:29.997375
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(lambda: 1)
    assert Lazy.of(1) != 1


# Generated at 2022-06-12 05:18:37.008552
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 2)) == Lazy.of(3)
    assert (
        Lazy.of(1)
        .bind(lambda x: Lazy.of(x + 1))
        .bind(lambda y: Lazy.of(y + 2))
        == Lazy.of(4)
    )
    assert (
        Lazy.of(1)
        .bind(lambda x: Lazy.of(x + 1))
        .bind(lambda y: Lazy.of(y + 2))
        .bind(lambda z: Lazy.of(z + 4))
        == Lazy.of(7)
    )



# Generated at 2022-06-12 05:18:48.548575
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.either import Left

    def get_value():
        return 42

    val = Lazy(get_value).get()
    assert get_value() == val

    val = Lazy(lambda x: x * 2).get(21)
    assert val == 42

    val = Lazy(lambda x: x * 2).get(21, 21)
    assert val == 42

    val = Lazy(lambda x, y: x * 2 + y).get(21, 21)
    assert val == 63

    val = Lazy(lambda x, y: (x, y)).get(21, 21)
    assert val == (21, 21)

    val = Lazy(lambda *args: (args[0], args[1])).get(21, 21)
    assert val == (21, 21)

# Generated at 2022-06-12 05:18:51.441596
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def foo():
        return 1

    def bar():
        return 1

    lazy_foo = Lazy(foo)
    lazy_bar = Lazy(bar)

    assert lazy_foo == lazy_bar
    lazy_bar = Lazy(lambda _: 2)
    assert not lazy_foo == lazy_bar



# Generated at 2022-06-12 05:18:58.051267
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1).map(lambda a: a + 1) == Lazy.of(1).map(lambda a: a + 1)
    assert Lazy.of(1).map(lambda a: a + 1) != Lazy.of(2).map(lambda a: a + 1)
    assert Lazy.of(1).map(lambda a: a + 1) != Lazy.of(1).map(lambda a: a * 2)
    assert Lazy.of(1).map(lambda a: a + 1) != Lazy.of(2).map(lambda a: a * 2)
    assert Lazy.of(1).map(lambda a: a + 1) != Lazy.of(2)


# Generated at 2022-06-12 05:19:04.349769
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.either import Left
    from pymonet.validation import Validation

    def fn(x):
        return x ** 2

    lazy_left = Lazy(fn).map(Left)
    assert lazy_left.get(3) == Left(9)

    lazy_box = Lazy(fn).map(lambda x: x ** 3)
    assert lazy_box.get(2) == 8

    lazy_validation = Lazy(fn).map(Validation.success)
    assert lazy_validation.get(5) == Validation.success(25)



# Generated at 2022-06-12 05:19:15.969420
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.validation import Validation

    assert Lazy(lambda: 1).__eq__(Lazy(lambda: 1))
    assert Lazy(lambda: 1).map(lambda x: x + 1).__eq__(Lazy(lambda: 1).map(lambda x: x + 1))
    assert not Lazy(lambda: 1).__eq__(Lazy(lambda: 3))
    assert Lazy(lambda: Validation.success(1)).__eq__(Lazy(lambda: Validation.success(1)))
    assert not Lazy(lambda: Validation.success(1)).__eq__(Lazy(lambda: Validation.success(3)))



# Generated at 2022-06-12 05:19:22.658182
# Unit test for method bind of class Lazy
def test_Lazy_bind(): # pragma: nocover
    """
    This method check if it's possible to call twice constructor function during calling bind method
    """

    class MockFunctionClass:
        """
        This class increment internal value after every constructor call.
        We will use it to check if constructor called only during fold
        """
        def __init__(self):
            self.value = 0

        def constructor(self):
            self.value = self.value + 1
            return self.value

        def map_fn(self, value):
            self.value = self.value + 1
            return value

    mock_fn = MockFunctionClass()

    # Call bind method on Lazy with mocked constructor and check if it's not calling constructor
    lazy = Lazy(mock_fn.constructor).bind(lambda x: Lazy(x))

# Generated at 2022-06-12 05:19:32.293848
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    monad_1 = Lazy.of(1)
    monad_2 = Lazy.of(1)
    monad_3 = Lazy.of(1).map(lambda x: x + 1)
    monad_4 = Lazy.of(2)

    assert monad_1 == monad_1
    assert monad_2 == monad_2
    assert monad_3 == monad_3
    assert monad_4 == monad_4
    assert monad_1 == monad_2
    assert monad_1 != monad_3
    assert monad_1 != monad_4
    assert monad_3 != monad_4



# Generated at 2022-06-12 05:19:38.699209
# Unit test for method get of class Lazy
def test_Lazy_get():
    # pylint: disable=C0111
    assert Lazy(lambda: 2).get() == 2
    assert Lazy(lambda x, y: x + y).get(3, 6) == 9
    assert Lazy(lambda x: 3 * x).get(3, 6) == 9
    assert Lazy(lambda x: 3 * x + 2).get(3, 6) == 11
    assert Lazy(lambda x: 3 * x + 2).get(3) == 11
    assert Lazy(lambda x: 3 * x + 2).get() == 11

# Generated at 2022-06-12 05:19:42.057756
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3



# Generated at 2022-06-12 05:19:53.521616
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.either import Right
    from pymonet.validation import Validation

    mapper = lambda a: a + 1

    assert Lazy.of(1).map(mapper) == Lazy(lambda *args: Right(2))
    assert Lazy.of(1).map(mapper).map(mapper) == Lazy(lambda *args: Right(3))
    assert Lazy.of(1).map(mapper).map(mapper).map(mapper) == Lazy(lambda *args: Right(4))
    assert Lazy.of(1).map(mapper).map(mapper).map(mapper).map(mapper) == Lazy(lambda *args: Right(5))

# Generated at 2022-06-12 05:19:58.134363
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.either import Right
    from pymonet.validation import Validation

    result = Lazy(lambda: 1).get()

    assert result == 1
    assert isinstance(result, int)

    result = Lazy(lambda: 1).map(lambda x: x + 1).get()

    assert result == 2
    assert isinstance(result, int)

    result = Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).get()

    assert result == 2
    assert isinstance(result, int)

    result = Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).get(1, 2)

    assert result == 2
    assert isinstance(result, int)

    result = Lazy(lambda x: x + 1).get(1)


# Generated at 2022-06-12 05:20:00.648117
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test if mapping function to Lazy works correctly.
    """
    test_value = 1
    mapped_value = 2

    assert Lazy(lambda _: test_value).map(lambda v: mapped_value) == Lazy(lambda _: mapped_value)
    assert Lazy(lambda _: test_value).map(lambda v: v).get() == test_value


# Generated at 2022-06-12 05:20:11.464444
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def bind_implementation(x: int, y: int) -> int:
        return x + y

    assert Lazy(lambda x: x + 2).bind(lambda x: Lazy(lambda y: bind_implementation(x, y))).get(1, 2) == 4
    assert Lazy(lambda x: x + 2).bind(lambda x: Lazy(lambda y: bind_implementation(x, y))).to_box(1, 2).unbox() == 4

# Generated at 2022-06-12 05:20:19.937457
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_instance = Lazy(lambda x: x)
    lazy_mapper = lazy_instance.map(lambda x: x+1)

    assert lazy_mapper.get(1) == 2

    lazy_instance = Lazy(lambda x: x)
    lazy_mapper = lazy_instance.map(lambda x: x+1)

    assert lazy_mapper.get(1) == 2

    lazy_instance = Lazy(lambda x: x)
    lazy_mapper = lazy_instance.map(lambda x: x+1)

    assert lazy_mapper.get(1) == 2


# Generated at 2022-06-12 05:20:29.188914
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.s import S

    fn = Lazy(lambda: 1)
    assert fn.get(S('2')) == 1
    assert fn.get(S('3')) == 1  # unit testing for memoize
    assert fn.get(S('4')) == 1  # unit testing for memoize
    assert fn.is_evaluated



# Generated at 2022-06-12 05:20:34.514868
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functions import add, inc

    lazy1 = Lazy.of(10)
    lazy2 = Lazy.of(10)
    lazy3 = Lazy.of('abc')
    lazy4 = Lazy(add)

    assert lazy1 == lazy2
    assert lazy1 != lazy3
    assert lazy1 != lazy4



# Generated at 2022-06-12 05:20:40.047168
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(*args) -> str:
        return ''.join(args)

    first = Lazy(fn)
    second = Lazy(lambda *args: fn(*args))
    third = Lazy.of('test')
    assert first != second
    assert first == third



# Generated at 2022-06-12 05:20:49.778846
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    lazy_fn = Lazy(lambda x, y: x + y)
    lazy_arg = Lazy(lambda: 7)

    assert lazy_arg.ap(lazy_fn) == Lazy(lambda: 7 + 7)
    assert lazy_fn.ap(lazy_arg) == Lazy(lambda: 7 + 7)

    assert lazy_arg.ap(lazy_arg) == Lazy(lambda: 7)
    assert lazy_fn.ap(lazy_fn) == Lazy(lambda x, y: x + y)

    box_lazy_fn = Box(Lazy(lambda x, y: x + y))
    box_lazy_arg = Box(Lazy(lambda: 7))

    assert box_lazy_arg.ap(box_lazy_fn) == Box

# Generated at 2022-06-12 05:20:55.163687
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    def fn(x):
        return x + 10

    def fn_2(x):
        return x * 10

    lazy = Lazy.of(fn)
    lazy_2 = Lazy.of(fn_2)

    assert lazy.ap(lazy_2).get(10) == fn(fn_2(10))



# Generated at 2022-06-12 05:21:01.958032
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from nose.tools import assert_true

    class TestLazy(Lazy):
        def __init__(self, fn: Callable):
            super().__init__(fn)

    assert_true(TestLazy(lambda x: x * 2) == TestLazy(lambda x: x * 2))
    assert_true(TestLazy(lambda x: x * 2) == TestLazy(lambda x: x * 2 * 2))

