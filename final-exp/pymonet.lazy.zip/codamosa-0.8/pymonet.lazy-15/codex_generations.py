

# Generated at 2022-06-12 05:11:08.225617
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_zero(a):
        return a + 0

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    value = Lazy(lambda: 0).map(add_zero).map(add_one).map(add_two).get()
    assert value == 3



# Generated at 2022-06-12 05:11:13.529485
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def optional(x):
        return Maybe.just(10) if x == 10 else Maybe.empty()

    lazy_square = Lazy(lambda x: x ** x)
    assert lazy_square.ap(Lazy(lambda x: x + x)).get(10) == lazy_square.get(20)
    assert lazy_square.ap(Lazy(lambda x: x * 100)).get(10) == lazy_square.get(1000)
    assert lazy_square.ap(Lazy(optional)).get(10) == Lazy(lambda x: x).get(100)

# Generated at 2022-06-12 05:11:21.101639
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def func_1(value):
        return Lazy.of(value * 100)
    def func_2(value):
        return Lazy.of(value + 100)

    assert (
        Lazy.of(2)
        .bind(func_1)
        .bind(func_2)
        .get() == 300
    )

    assert (
        Lazy.of(2)
        .bind(func_1)
        .bind(func_2)
        .bind(func_1)
        .bind(func_2)
        .get() == 20000
    )


# Generated at 2022-06-12 05:11:32.882618
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    mul_3 = lambda x: x * 3

    def mul_4(x):
        return x * 4

    assert Lazy.of(5).map(mul_3) == Lazy(lambda: mul_3(5))
    assert Lazy.of(5).map(mul_4) == Lazy(lambda: mul_4(5))
    assert Lazy.of(5).map(mul_3).fold() == 5 * 3
    assert Lazy.of(5).map(mul_4).fold() == 5 * 4
    assert Lazy.of(5).map(mul_3).fold() != 5 * 4
    assert Lazy.of(5).map(mul_4).fold() != 5 * 3


# Generated at 2022-06-12 05:11:39.165997
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    class A:
        def __init__(self, x):
            self.x = x

        def __eq__(self, other):
            return isinstance(other, A) and self.x == other.x

    def fn(value):
        return Box(A(value.x + 1))

    lazy = Lazy.of(2)
    result = lazy.map(fn).ap(lazy)

    assert result.get() == A(3)



# Generated at 2022-06-12 05:11:45.963901
# Unit test for method get of class Lazy
def test_Lazy_get():
    def get_str_len(s: str) -> int:
        return len(s)

    _get_str_len = Lazy.of(get_str_len)

    assert _get_str_len.get('hello') == get_str_len('hello')
    assert _get_str_len.get('world') == get_str_len('world')



# Generated at 2022-06-12 05:11:50.734201
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(42) == Lazy.of(42)
    assert Lazy.of(42) != Lazy.of(43)
    assert Lazy.of(42) != 43
    assert Lazy.of(42) != object()
    assert Lazy.of(42) != object()



# Generated at 2022-06-12 05:11:52.327922
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 'a').get() == 'a'



# Generated at 2022-06-12 05:11:54.593225
# Unit test for method get of class Lazy
def test_Lazy_get():
    @Lazy
    def f(val):
        return val

    assert f.get('value') == 'value'



# Generated at 2022-06-12 05:11:57.104037
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1) and Lazy.of(1) != Lazy.of(2)



# Generated at 2022-06-12 05:12:02.333016
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def print_fn(value):
        print(value)
        return value

    Lazy.of(1).ap(Lazy.of(print_fn)).get() == 1


# Generated at 2022-06-12 05:12:12.035364
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: None) == Lazy(lambda: None)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: None) != Lazy(lambda: 2)
    assert Lazy(lambda: None) != Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: None)
    assert Lazy(lambda: None).map(lambda x: x) == Lazy(lambda: None)
    assert Lazy(lambda: 1).map(lambda x: x) == Lazy(lambda: 1)
    assert Lazy(lambda: None) != Lazy(lambda: None).map(lambda x: x)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x)

# Generated at 2022-06-12 05:12:14.303325
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 'no test').get() == 'no test'


# Generated at 2022-06-12 05:12:21.736245
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(3) != Lazy.of(4)
    assert Lazy.of('foo') == Lazy.of('foo')
    assert Lazy.of(6.0) == Lazy.of(6.0)
    assert Lazy.of(False) == Lazy.of(False)

# Generated at 2022-06-12 05:12:25.176521
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe

    expected = Maybe.just(1)

    result = Lazy.of(0) \
        .map(lambda x: x + 1) \
        .bind(lambda x: Lazy.of(Maybe.just(x))) \
        .get()

    assert expected == result



# Generated at 2022-06-12 05:12:29.244711
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def foo(value):  # pragma: no cover
        return value

    assert Lazy(foo) == Lazy(foo)
    assert Lazy(foo) != Lazy(foo)



# Generated at 2022-06-12 05:12:32.344574
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy.of(23).get() == 23
    assert Lazy.of(lambda x, y: x + y).get(2, 3) == 5



# Generated at 2022-06-12 05:12:35.228270
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given
    lazy = Lazy.of(5)

    # When
    maped_lazy = lazy.map(lambda x: x * 2)

    # Then
    assert maped_lazy == Lazy(lambda x: 10)
    assert maped_lazy.constructor_fn(6) == 10



# Generated at 2022-06-12 05:12:39.146032
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 'b'

    def fn2():
        return 'c'

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)



# Generated at 2022-06-12 05:12:44.332612
# Unit test for method map of class Lazy
def test_Lazy_map():
    @lazy
    def get_lazy_integer(value):
        return value

    assert get_lazy_integer(1).map(lambda x: x+1).get() == 2
    assert get_lazy_integer(1).map(lambda x: x+1).map(lambda x: x*2).get() == 4


# Generated at 2022-06-12 05:12:53.660981
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn_to_test(*args):
        call_counter = getattr(fn_to_test, 'call_counter', 0)
        setattr(fn_to_test, 'call_counter', call_counter + 1)

        print('[DEBUG] in Lazy - call_fn called {} times'.format(call_counter))

        return args[0] + args[1] * 2

    lazy_instance = Lazy(fn_to_test)
    assert lazy_instance.get(2, 3) == 8
    assert lazy_instance.get(2, 3) == 8


# Generated at 2022-06-12 05:13:03.264792
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert str(Lazy.of(1).map(lambda x: x * 2)) == 'Lazy[fn=<function <lambda> at 0x7f8884b79398>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda x: x + 1).map(lambda x: x * 2)) == 'Lazy[fn=<function <lambda> at 0x7f8884b79840>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda x: x + 2).map(lambda x: x * 2)) == 'Lazy[fn=<function <lambda> at 0x7f8884b79598>, value=None, is_evaluated=False]'

# Generated at 2022-06-12 05:13:12.909739
# Unit test for method get of class Lazy
def test_Lazy_get():
    l = Lazy(lambda: 12)
    assert l.get() == 12
    l = Lazy(lambda: 34)
    assert l.get() == 34
    l = Lazy(lambda: 12)
    assert l.get() == 12
    l = l.map(lambda a: a + 1)
    assert l.get() == 13
    l = l.ap(Lazy(lambda: 2))
    assert l.get() == 15
    l = l.ap(Lazy(lambda: 2))
    assert l.get() == 17
    l = l.to_box()
    assert l.to_list() == [17]
    assert l.filter(lambda a: a > 16).to_list() == [17]
    assert l.map(lambda a: a + 1).to_list() == [18]


# Generated at 2022-06-12 05:13:18.158694
# Unit test for method get of class Lazy
def test_Lazy_get():
    def multiply_by_2(x):
        return 2 * x

    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).map(multiply_by_2).get() == 2
    assert Lazy(lambda: 1).map(multiply_by_2).ap(Lazy(lambda: 2)).get() == 4

# Generated at 2022-06-12 05:13:28.880818
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # Arrange
    def add(x, y):
        return x + y

    lazy = Lazy(add)
    lazy2 = Lazy(add)
    lazy3 = Lazy(lambda x, y: x + y + 1)

    # Assert
    assert not lazy.__eq__(lazy2)
    assert not lazy2.__eq__(lazy3)
    assert not lazy.__eq__(lazy3)

    # Arrange
    lazy4 = Lazy(add)
    lazy4.get(1, 2)
    lazy5 = Lazy(add)
    lazy5.get(1, 2)

    # Assert
    assert lazy4.__eq__(lazy5)

    # Arrange
    lazy6 = Lazy(lambda x, y: x + y)
    lazy7 = L

# Generated at 2022-06-12 05:13:40.508249
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad_try import Try

    def test_invalid_types():
        one = Lazy(lambda: 1)
        assert one != 1
        assert one != None
        assert one != [2]

    def test_equals_empty():
        empty = Lazy.of(None)
        another_empty = Lazy.of(None)
        assert empty == empty
        assert empty == another_empty

    def test_not_equals_empty():
        one = Lazy.of(1)
        two = Lazy.of(2)
        none_empty = Lazy.of(None)
        assert one != two
        assert one != none_empty

    def test_equals_with_map():
        one = Lazy.of(1)
       

# Generated at 2022-06-12 05:13:45.653963
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_maybe import Maybe

    def fn(x):
        from pymonet.monad_maybe import Maybe

        return Maybe(x)

    assert Lazy.of(5).bind(fn).get() == 5

    assert Lazy.of(5).bind(
        lambda x: Maybe.just(x)
    ).get() == 5


# Generated at 2022-06-12 05:13:54.116428
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(10).bind(lambda x: Lazy.of(x + 10)).get() == 20
    assert Lazy.of(10).bind(lambda x: Lazy.of(x + 10)).bind(lambda x: Lazy.of(x * 2)).get() == 40
    assert Lazy.of(10).bind(lambda x: Lazy.of(x + 10)).map(lambda x: x * 2).get() == 40
    assert Lazy.of(10).bind(lambda x: Lazy.of(x + 10).map(lambda x: x * 2)).get() == 40



# Generated at 2022-06-12 05:14:01.377792
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.functor import Functor

    def add1(x):
        return x + 1

    def sub1(x):
        return x - 1

    def func(x) -> Functor:
        return Lazy.of(sub1(x))

    assert Lazy.of(add1).ap(func(2)).get() == 2

# Generated at 2022-06-12 05:14:07.493473
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # returns value of argument
    cnstr = lambda x: x

    # returns square of argument
    square = lambda a: a * a

    # square of argument
    typed_square = Lazy(lambda a: square(a))

    # returns array of squares of arguments
    typed_cnstr = Lazy(lambda a, b, c: [typed_square.ap(Lazy(lambda _: a)).get(),
                                        typed_square.ap(Lazy(lambda _: b)).get(),
                                        typed_square.ap(Lazy(lambda _: c)).get()])

    # returns array of squares of arguments
    untyped_cnstr = Lazy(lambda a, b, c: [cnstr(a * a),
                                          cnstr(b * b),
                                          cnstr(c * c)])

# Generated at 2022-06-12 05:14:13.031386
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try

    assert Lazy(lambda x: x + 5).bind(lambda x: Try(lambda: x + 1)).get(10) == 16

# Generated at 2022-06-12 05:14:20.721010
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x * 2)

    def double(x):
        return Lazy.of(x * 2)

    def construct(a):
        return a + 2

    lazy = Lazy(construct)
    lazy_mapped = lazy.map(fn).map(fn).map(fn).map(double)
    lazy_mapped_bind = lazy.bind(fn).bind(fn).bind(fn).bind(double)
    assert lazy_mapped_bind.get(1) == lazy_mapped.get(1) == 20

# Generated at 2022-06-12 05:14:31.497264
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def return_value(value):
        return Lazy(lambda: value)

    def return_value_as_maybe(value):
        return Lazy(lambda: Maybe.just(value))

    def return_value_as_try(value):
        return Lazy(lambda: Try.successful(value))

    def return_value_as_validation(value):
        return Lazy(lambda: Validation.success(value))

    def return_value_as_lazy(value):
        return Lazy(lambda: Lazy(lambda: value))

    def fold_function(value):
        return value + 10


# Generated at 2022-06-12 05:14:37.175152
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    fn1 = lambda x: x - 1
    fn2 = lambda x: x + 1

    assert Lazy(fn1).__eq__(Lazy(fn1))
    assert not Lazy(fn1).__eq__(Lazy(fn2))
    assert not Lazy(fn1).__eq__(Lazy.of(1))

# Generated at 2022-06-12 05:14:46.123177
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.functors.functor_helpers import identity
    from tests.monad_try.monad_try_helper import increment, increment_with_error_in_case

    assert Lazy.of(None) == Lazy.of(None)
    assert Lazy.of(1) != Lazy.of(None)
    assert Lazy(identity) != Lazy(lambda x: x * 2)
    assert Lazy(lambda x: x * 2) == Lazy(lambda x: x * 2)
    assert Lazy(increment) != Lazy(increment_with_error_in_case)
    assert Lazy(increment_with_error_in_case) == Lazy(increment_with_error_in_case)


# Generated at 2022-06-12 05:14:53.360868
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # type: ignore
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(2) == Lazy(lambda *args: 2)
    assert not (Lazy.of(2) == Lazy.of(None))
    assert not (Lazy.of(2) == Lazy.of(3))
    assert not (Lazy(lambda *args: 2) == Lazy(lambda *args: 3))
    assert not (Lazy.of(2) == Lazy(lambda *args: 2))



# Generated at 2022-06-12 05:15:01.333909
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Unit test for method ap of class Lazy
    """
    from pymonet.box import Box

    lazy_1 = Lazy.of(1)
    lazy_3 = Lazy.of(3)
    apply_lazy = Lazy(lambda arg: arg + arg)

    assert apply_lazy.ap(lazy_1).get() == Box(2), "Lazy.ap should return box with 2, but returned {}".format(apply_lazy.ap(lazy_1))
    assert apply_lazy.ap(lazy_3).get() == Box(6), "Lazy.ap should return box with 6, but returned {}".format(apply_lazy.ap(lazy_3))

# Generated at 2022-06-12 05:15:05.231801
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given
    fn = lambda val: val ** 2
    lazy = Lazy.of(2).map(fn)

    # When
    val = lazy._compute_value()

    # Then
    assert 4 == val



# Generated at 2022-06-12 05:15:15.045592
# Unit test for method ap of class Lazy
def test_Lazy_ap(): # type: ignore
    from pymonet.validation import Validation

    def safe_div(x, y):
        try:
            return Validation.success(x/y)
        except ZeroDivisionError:
            return Validation.failure(["div by zero"])

    lazy = Lazy(lambda: 10)
    lazy_ap = lazy.map(lambda x: safe_div(6, x))

    assert Lazy(lambda: Validation.success(0.6)) == lazy_ap.ap(Lazy(lambda: 1))
    assert Lazy(lambda: Validation.failure(["div by zero"])) == lazy_ap.ap(Lazy(lambda: 0))


# Generated at 2022-06-12 05:15:22.394427
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.unit_test import UnitTest
    import unittest

    class LazyTestCase(UnitTest, unittest.TestCase):
        def test_when_lazy_are_equals_returns_true(self):
            def fn(*args):
                return *args

            lazy_1 = Lazy.of([1, 2])
            lazy_2 = Lazy.of([1, 2])

            self.assertTrue(lazy_1 == lazy_2)

        def test_when_lazy_contains_different_values_returns_false(self):
            lazy_1 = Lazy.of(1)
            lazy_2 = Lazy.of(2)

            self.assertFalse(lazy_1 == lazy_2)

    LazyTestCase().run()

# Generated at 2022-06-12 05:15:32.101726
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def foo(s):
        return Lazy(lambda *args: s.lower())

    lazy = Lazy(lambda *args: 'Hello world!')
    assert lazy.bind(foo).get() == foo(Lazy.of('Hello world!').get()).get()

    lazy = Lazy(lambda *args: 'Hello world!')
    assert lazy.bind(foo).get() == 'hello world!'

# Generated at 2022-06-12 05:15:36.913266
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def func1(value):
        def func2(value):
            return Box(value + 1)
        return Maybe.just(value + 1).bind(func2)

    assert Lazy(lambda x: x).bind(func1).get(1).get() == 3

# Generated at 2022-06-12 05:15:42.095525
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f1(*args):
        pass

    def f2(*args):
        pass

    assert Lazy(f1) == Lazy(f1)
    assert Lazy(f2) == Lazy(f2)
    assert Lazy(f1) != Lazy(f2)



# Generated at 2022-06-12 05:15:44.343823
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x: x).get(7) == 7
    assert Lazy(lambda x: x).get(42) == 42



# Generated at 2022-06-12 05:15:50.314493
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy = Lazy.of(5)
    result = lazy.map(lambda x: x + 1)

    assert result.is_evaluated is False, "Value should not be evaluated now"
    assert result.get() == 6, "Function is not mapped properly"
    assert result.is_evaluated is True, "Value should be evaluated now"
    assert result.value == 6, "Value should be evaluated now"



# Generated at 2022-06-12 05:15:51.277545
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1

# Generated at 2022-06-12 05:16:01.014351
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of('foo').ap(Lazy.of(lambda x: x.upper())) == Lazy.of('FOO')

    def to_upper_case(x):
        return x.upper()

    assert Lazy.of(to_upper_case).ap(Lazy.of('foo')) == Lazy.of('FOO')

    assert Lazy.of(lambda x: x.upper()).ap(Lazy.of('foo')) == Lazy.of('FOO')

    assert Lazy.of(lambda x: x.upper()).ap(Lazy.of(lambda y: y + '2').map(lambda x: x + '1')) == Lazy.of('FOO2')


# Generated at 2022-06-12 05:16:11.889320
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Given: function taking two arguments and returning first
    def first(x, _):
        return x

    # Given: function returning tuple of two arguments
    def tuple_fn(*args):
        return args

    # Given: two Lazy
    # When: first one contains function taking two arguments and returning first
    # And: second one contains tuple constructor
    # And: first one applies to second
    # Then: result contains function taking two arguments and returning tuple of them
    result = Lazy.of(first).ap(Lazy.of(tuple_fn))

    # Then: result is not empty for all arguments
    assert result.constructor_fn(1, 2) == (1, 2)

    # Then: result is not memoize
    result.get(3, 4)
    assert not result.is_evaluated

    # Then: result is

# Generated at 2022-06-12 05:16:17.187347
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add1(x: int) -> int:
        return x + 1

    def lazy_add1(x: int) -> Lazy[int, int]:
        return Lazy(lambda: x + 1)

    assert Lazy.of(1).map(add1).get() == 2
    assert Lazy.of(1).bind(lazy_add1).get() == 2


# Generated at 2022-06-12 05:16:26.754251
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    box = Box(5)
    either = Right(5)
    maybe = Maybe.just(5)
    try_ = Try.of(lambda: 5)
    validation = Validation.success(5)

    def add(x):
        def internal(y):
            return x + y
        return internal

    assert Lazy.of(10).ap(box) == 20
    assert Lazy.of(10).ap(either) == 20
    assert Lazy.of(10).ap(maybe) == 20
    assert Lazy.of(10).ap(try_) == 20

# Generated at 2022-06-12 05:16:34.211385
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def simple_fn():
        return 10

    lazy = Lazy(simple_fn)
    assert lazy.get() == 10



# Generated at 2022-06-12 05:16:40.716305
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Lazy.of(2).bind(lambda x: Lazy.of(x + 1)).get() == 3
    assert Lazy.of(Maybe.just(Box(2))).bind(lambda x: Lazy.of(x.just())).get() == Box(2)


# Generated at 2022-06-12 05:16:45.224332
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != None
    assert Lazy.of(1) != "Lazy"


# Generated at 2022-06-12 05:16:49.403794
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn1():
        return 'foo'

    value1 = Lazy(fn1).get()
    assert value1 == 'foo'

    def fn2(value):
        return value

    value2 = Lazy(fn2).get('foo')
    assert value2 == 'foo'


# Generated at 2022-06-12 05:16:55.124013
# Unit test for method get of class Lazy
def test_Lazy_get():
    def _f1(a):
        return a + 'a'
    _lazy = Lazy(_f1)
    assert _lazy.get() is None
    assert _lazy.get('b') == 'ba'
    assert _lazy.get('c') == 'ba'
    assert _lazy.is_evaluated is True

# Generated at 2022-06-12 05:17:00.964203
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test for ap method for Lazy.
    """
    from pymonet.validation import Validation

    def lazy_fn(value):
        return Lazy(lambda: value + 1)

    validation = Lazy(lambda: 1).ap(lazy_fn(2)).to_validation()

    assert validation == Validation.success(3)


# Generated at 2022-06-12 05:17:05.906980
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def fn1(arg):
        return arg

    def fn2(arg):
        return arg

    def fn3(arg1, arg2):
        return arg1 + arg2

    lazy = Lazy(fn1).map(fn2).map(fn3)
    assert lazy.constructor_fn(2, 3) == 5
    assert lazy.constructor_fn(2, 3) == 5
    assert lazy.constructor_fn(2, 3) == 5



# Generated at 2022-06-12 05:17:16.067994
# Unit test for method get of class Lazy
def test_Lazy_get():
    counter = 1

    def foo():
        nonlocal counter
        counter += 1
        return counter

    lazy = Lazy(foo)

    assert lazy.get() == 1
    assert lazy.is_evaluated
    assert lazy.get() == 1
    assert counter == 2

    counter = 1

    lazy = Lazy(foo)

    assert lazy.get() == 1
    assert lazy.is_evaluated
    assert lazy.get() == 1
    assert counter == 2

    foo.counter = 0

    def lazy_foo():
        foo.counter += 1
        return foo() 

    lazy = Lazy(lazy_foo)

    assert lazy.get() == 1
    assert lazy.is_evaluated
    assert lazy.get() == 1
    assert counter == 3

# Generated at 2022-06-12 05:17:28.530823
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """Unit test for method bind of class Lazy"""

    def test_method_bind_of_empty_list():
        """Unit test for method bind of class Lazy"""
        lazy = Lazy.of([])

        def fn(value):
            return Lazy.of(len(value))

        new_lazy = lazy.bind(fn)
        result = new_lazy.get()

        assert result == 0

    def test_method_bind_of_nonempty_list():
        """Unit test for method bind of class Lazy"""
        lazy = Lazy.of([1, 2, 3])

        def fn(value):
            return Lazy.of(len(value))

        new_lazy = lazy.bind(fn)
        result = new_lazy.get()

        assert result == 3


# Generated at 2022-06-12 05:17:31.529810
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def mock_fn():
        pass

    lazy1 = Lazy(mock_fn)
    lazy2 = Lazy(mock_fn)

    assert lazy1 == lazy2


# Generated at 2022-06-12 05:17:43.329369
# Unit test for method get of class Lazy
def test_Lazy_get():
    # given
    mock = MagicMock(return_value=10)
    lazy = Lazy(mock)

    # when
    lazy.get()

    # then
    mock.assert_called()



# Generated at 2022-06-12 05:17:49.740781
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    def ap_test(lazy):
        return lazy.ap(Lazy(lambda x: lambda y: x + y))

    assert ap_test(Lazy(lambda x: x + 3)) == Lazy(lambda y: 3 + y)
    assert ap_test(Lazy(lambda x: lambda y: x + y)) == Lazy(lambda y: y + y)
    assert ap_test(Lazy(lambda x: Box(x + 3))) == Lazy(lambda y: Box(y + 3))

# Generated at 2022-06-12 05:17:57.880893
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(10).get() == 10
    assert Lazy(lambda: 'foo').get() == 'foo'
    assert Lazy.of(10).get('foo') == 10
    assert Lazy(lambda x: x).get('foo') == 'foo'
    assert Lazy.of(10).get('foo', 'bar') == 10
    assert Lazy(lambda x, y: x).get('foo', 'bar') == 'foo'
    assert Lazy(lambda x, y: y).get('foo', 'bar') == 'bar'



# Generated at 2022-06-12 05:18:02.531028
# Unit test for method map of class Lazy
def test_Lazy_map():
    number = 10
    number_times_2 = number * 2

    def constructor_fn():
        return number

    lazy = Lazy(constructor_fn)

    def mapper(value):
        return value * 2

    assert lazy.map(mapper).get() == number_times_2


# Generated at 2022-06-12 05:18:06.533666
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(x):
        return x + 1

    def g(x):
        return x + 1

    lazy_1 = Lazy(f)
    lazy_2 = Lazy(f)
    lazy_3 = Lazy(g)

    assert lazy_1 == lazy_2
    assert lazy_1 != lazy_3



# Generated at 2022-06-12 05:18:11.672331
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def double(x: int) -> int:
        """
        Double given argument
        :param x: any int
        """
        return x * 2

    result = Lazy(double).map(lambda x: x + 1).get(1)
    assert result == 3



# Generated at 2022-06-12 05:18:20.847979
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.monad_try import Success

    lazy = Lazy(Box)
    assert Lazy.of(1) == Lazy(lambda x: x)(1)
    assert Lazy.of('') == Lazy(lambda x: x)('')
    assert lazy == lazy
    assert Lazy(id) == Lazy(id)
    assert Lazy.of(lambda x: x + 1) == Lazy(lambda x: x + 1)
    assert lazy == lazy
    assert lazy == Lazy(lambda: Box(1))
    assert Lazy.of(1) == Success(1)
    assert Lazy.of('') == Success('')
    assert Lazy(id) == Success(1)
    assert Lazy.of(lambda x: x + 1) == Success

# Generated at 2022-06-12 05:18:28.161088
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).bind(lambda x: Lazy.of(Maybe.just(x))).get() == Maybe.just(1)
    assert Lazy.of(1).bind(lambda x: Lazy.of(Maybe.nothing())).get() == Maybe.nothing()
    assert Lazy.of(1).bind(lambda x: Lazy.of([x])).get() == [1]


# Generated at 2022-06-12 05:18:36.452381
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.evaluation_wrapper import EvaluationWrapper
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    dummy_value = 1
    dummy_value_1 = 2
    dummy_value_2 = 3

    lazy = Lazy(lambda *args: dummy_value_1)
    lazy_copy = Lazy(lambda *args: dummy_value_1)
    lazy_another = Lazy(lambda *args: dummy_value_2)
    lazy_1 = lazy.map(lambda x: dummy_value_2)
    lazy_2 = lazy.map(lambda x: dummy_value_2)

# Generated at 2022-06-12 05:18:42.579862
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def call_two_times(fn):
        def wrapper(*args):
            fn(*args)
            return fn(*args)
        return wrapper

    def add(a, b):
        return a + b

    def mult(a, b):
        return a * b

    lazy = Lazy(call_two_times(add)).map(call_two_times(mult))
    assert lazy.get(10, 5) == 300



# Generated at 2022-06-12 05:19:07.666583
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.function import identity

    test_value = [1, 2, 3]
    test_lazy = Lazy.of(test_value)

    assert Lazy(identity) != test_lazy

    assert Lazy(lambda x: x).map(identity) == Lazy(lambda x: x).map(identity)
    assert test_lazy.map(identity) != test_lazy.map(lambda x: x)
    assert Lazy(lambda x: x) != Lazy(lambda x: x)
    assert test_lazy != test_lazy.map(identity)



# Generated at 2022-06-12 05:19:12.930207
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Maybe.just(lambda x: x).map(lambda x: x(1)) == Maybe.just(1)
    assert Maybe.just(lambda x: x).map(lambda x: x('foo')) == Maybe.just('foo')


# Generated at 2022-06-12 05:19:17.824621
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    fn = lambda x: x + 1
    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy.of(5)
    lazy4 = Lazy.of(5)
    lazy5 = Lazy(lambda x: x + 1)
    assert lazy1 == lazy2
    assert lazy3 == lazy4
    assert lazy1 != lazy3
    assert lazy5 != lazy1

# Generated at 2022-06-12 05:19:25.400417
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Unit test for map method of class Lazy()
    """
    # pylint: disable=W0612, W0613
    def dummy_function(a):
        return a + 1

    result = Lazy.of(1).map(dummy_function)
    assert isinstance(result, Lazy)
    assert result.is_evaluated is False
    assert result.get(1) == 2


# Generated at 2022-06-12 05:19:36.137128
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(Box.of(10)) == Lazy.of(Box.of(10))
    assert Lazy.of(Try.of(lambda : 10)) == Lazy.of(Try.of(lambda : 10))
    assert Lazy.of(Try.of(lambda : 10)) != Lazy.of(Try.of(lambda : "10"))
    assert Lazy.of(Validation.success(10)) != Lazy.of(Validation.failure(10))
    assert Lazy.of(Validation.success(10)) == Lazy.of(Validation.success(10))


# Generated at 2022-06-12 05:19:39.196879
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def constructor(a):
        return a

    def mapper(a):
        return a

    lazy1 = Lazy(constructor).map(mapper)
    lazy2 = Lazy(constructor).map(mapper)
    assert lazy1 == lazy2



# Generated at 2022-06-12 05:19:44.185851
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from typing import cast

    def fn1(value):
        return value

    def fn2(value):
        return value

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn2) == Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != 1
    assert Lazy(fn1) == cast(object, Lazy(fn1))

# Generated at 2022-06-12 05:19:47.315341
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(3).map(lambda x: x + 5) == Lazy.of(8)



# Generated at 2022-06-12 05:19:55.354571
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f1():
        return 'test'

    def f2():
        return 'test'

    lazy1 = Lazy(f1)
    lazy2 = Lazy(f2)
    lazy3 = Lazy(f1)
    lazy4 = Lazy(f1)
    lazy5 = Lazy(f1)
    lazy6 = Lazy(f2)
    lazy1.value = 'test'
    lazy3.value = 'test'
    lazy4.value = 'test'
    lazy5.value = 'test'
    lazy6.value = 'test'
    assert lazy1 == lazy1

    assert lazy1 == lazy2
    assert lazy2 == lazy1

    assert lazy1 == lazy1
    assert lazy1 == lazy3
    assert lazy1 == lazy4
    assert lazy1 == lazy5
    assert lazy

# Generated at 2022-06-12 05:19:56.837300
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 0) == Lazy(lambda: 0)



# Generated at 2022-06-12 05:20:19.884347
# Unit test for method map of class Lazy
def test_Lazy_map(): # pragma: no cover
    def return_one():
        return 1

    def add_one(value):
        return value + 1

    lazy = Lazy(return_one)
    mapped_lazy = lazy.map(add_one)

    assert mapped_lazy.is_evaluated == False
    assert mapped_lazy.get() == 2



# Generated at 2022-06-12 05:20:26.872859
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(x):
        return 2 * x


    def g(x):
        return x % 2 == 0


    def h(x):
        return x == 2


    def a(x):
        return 'a' * x


    def b(x):
        return 'b' * x


    def c(x):
        return 'c' * x


    def add(x):
        return 'add' * x


    def if_else(x, predicate, if_func, else_func):
        return if_func(x) if predicate(x) else else_func(x)


    assert Lazy(f).bind(lambda x: Lazy(g).map(lambda y: x if y else 0)).get(3) == 0

# Generated at 2022-06-12 05:20:28.927341
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 3).get() == 3
    assert Lazy(lambda: 'str').get() == 'str'

# Generated at 2022-06-12 05:20:37.351737
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.impl.test.test_functions import power_of_two, sum_of_two
    from pymonet.impl.test.test_lazy import test_Lazy_of

    def make_power_of_two_Lazy(*args):
        return Lazy.of(power_of_two(*args))

    def make_sum_of_two_Lazy(*args):
        return Lazy.of(sum_of_two(*args))

    empty_power_of_two_Lazy = Lazy.of(lambda: power_of_two())
    empty_sum_of_two_Lazy = Lazy.of(lambda: sum_of_two())
    notempty_power_of_two_Lazy = Lazy.of(lambda value: power_of_two(value))
    notempty_

# Generated at 2022-06-12 05:20:44.299003
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    # When
    lazy = Lazy(lambda *args: Box(3))
    result = lazy.bind(lambda x: Lazy.of(x.get() + 2))
    computed_result = result.get()

    # Then
    assert computed_result == 5



# Generated at 2022-06-12 05:20:50.568186
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(value):
        return value + 1

    def transform_to_string(value):
        return "test string {}".format(str(value))

    def sum_all_strings(value):
        return "sum string {}".format(value)

    lazy_monad = Lazy.of(2).map(add_one) \
                           .map(transform_to_string) \
                           .bind(lambda val: Lazy.of(val).map(sum_all_strings))

    assert "sum string test string 3" == lazy_monad.get()



# Generated at 2022-06-12 05:20:53.027127
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(5).get() == 5
    assert Lazy(lambda: 2 + 3).get() == 5



# Generated at 2022-06-12 05:21:04.580595
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    test_cases = [
        (Lazy.of(1), Lazy.of(1), True),
        (Lazy.of(1), Lazy.of(2), False),
        (Lazy.of(1), Lazy.of('1'), False),
        (Lazy.of(1), 1, False),
        (Lazy.of(1), Lazy.of([1]), False),
        (Lazy.of(1), Lazy.of(lambda x: x + 1), False),
        (Lazy.of(1), List.of(1), False),
        (Lazy.of(1), '1', False),
        (Lazy.of(1), Set.of(1), False),
    ]

    for (lazy1, lazy2, expected_result) in test_cases:
        result = lazy