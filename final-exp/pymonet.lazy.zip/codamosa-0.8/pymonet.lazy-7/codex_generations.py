

# Generated at 2022-06-12 05:10:59.585551
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.validation import Validation

    _lazy = Lazy(lambda *args: Validation.failure([]))
    assert _lazy == _lazy



# Generated at 2022-06-12 05:11:08.508901
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Bind method returns Lazy with function result of function passed to bind function.

    This function is only one which can be use to call constructor.
    """
    value = 'test'

    # Lazy function returning value
    lazy_ = Lazy.of(value)

    # Function returning another Lazy
    fn = lambda x: Lazy.of(x)

    # Call bind with mapping function
    lazy_ = lazy_.bind(fn)

    # Evaluate lazy and returns value
    assert lazy_.get() == value
    # Check if constructor was called
    assert lazy_.is_evaluated
    # Check if constructor returns result of mapping function from bind
    assert lazy_.value == value


# Generated at 2022-06-12 05:11:13.669484
# Unit test for method map of class Lazy
def test_Lazy_map():
    def square(a):
        return a * a

    def add(a):
        return a + a

    def add_and_square(a):
        return square(add(a))

    lazy = Lazy(add_and_square)
    lazy_square = lazy.map(square)
    assert lazy_square.get(5) == 625



# Generated at 2022-06-12 05:11:17.027798
# Unit test for method get of class Lazy
def test_Lazy_get():
    def double(val: int) -> int:
        return val * 2

    assert Lazy(double).get(2) == 4
    assert Lazy(lambda: 2).get() == 2



# Generated at 2022-06-12 05:11:24.067238
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def function_returning_7():
        return 7

    def function_returning_7_with_argument(a):
        return 7

    def function_returning_8():
        return 8

    def function_returning_9_with_argument(a):
        return 9

    assert Lazy(function_returning_7) == Lazy(function_returning_7)
    assert Lazy(function_returning_7) == Lazy(function_returning_7_with_argument)
    assert Lazy(function_returning_7) != Lazy(function_returning_8)
    assert Lazy(function_returning_7) != Lazy(function_returning_9_with_argument)



# Generated at 2022-06-12 05:11:29.599838
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(x: int) -> int:
        return x / 2

    def fn(x: int) -> Lazy[int, int]:
        return Lazy(lambda: x)

    assert Lazy(f).bind(fn).get(2) == 1



# Generated at 2022-06-12 05:11:37.016110
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f1(a):
        return a

    def f2(a):
        return a

    def f3(a):
        return a

    lazy = Lazy(f1)
    lazy2 = Lazy(f2)
    lazy3 = Lazy(f3)

    assert lazy == lazy
    assert lazy != lazy2
    assert lazy == lazy3

# Generated at 2022-06-12 05:11:44.166269
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test Lazy.ap method
    """

    lazy_value_fn = Lazy(lambda x: x * 2)
    lazy_ap_fn = Lazy(lambda y: lambda x: y + x)
    result = lazy_value_fn.ap(lazy_ap_fn)
    assert result.get(1) == 3



# Generated at 2022-06-12 05:11:48.255237
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add_to_x(x):
        return x + 2

    lazy = Lazy.of(lambda x: x).ap(Lazy.of(add_to_x))
    assert lazy.get(10) == 12


# Generated at 2022-06-12 05:11:59.212185
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def is_odd(number):
        return number % 2 == 1

    def compute_mul(x):
        return x * 2

    def compute_add(x):
        return x + 1

    def compute_odd(x):
        return Lazy(lambda *args: is_odd(x.get(*args)))

    def compute_add_odd(x):
        return Lazy(lambda *args: x.get(*args) + 1)

    def compute_mul_add_odd(x):
        return Lazy(lambda *args: x.get(*args) * 2 + 1)

    assert Lazy(compute_odd).bind(compute_mul_add_odd)(5) == 11
    assert Lazy(compute_odd).bind(compute_add_odd)(5) == 6

# Generated at 2022-06-12 05:12:11.877894
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.validation import Validation

    def plus(a, b):
        return a + b

    def minus(a, b):
        return a - b

    def mult(a, b):
        return a * b

    def eq(a, b):
        return a == b

    assert Lazy(plus).ap(Lazy(lambda a: a)).ap(Lazy(lambda a: a)).get(2, 3) == 5
    assert Lazy(plus).ap(Lazy(lambda a: a).map(lambda a: a + 1)).ap(Lazy(lambda a: a)).get(1, 2) == 4

# Generated at 2022-06-12 05:12:17.881361
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    add3 = Lazy.of(lambda x: x + 3)
    assert add3.ap(Lazy.of(3)) == Lazy.of(6)
    assert add3.ap(Lazy.of(5)) == Lazy.of(8)
    assert add3.ap(Lazy.of(8)) == Lazy.of(11)


# Generated at 2022-06-12 05:12:19.544606
# Unit test for method map of class Lazy
def test_Lazy_map():
    def f(x):
        return 2 * x

    def g(x):
        return x + 1

    lazy_1 = Lazy.of(1)
    lazy_2 = lazy_1.map(f).map(g)

    assert(lazy_2.get() == 3)


# Generated at 2022-06-12 05:12:22.412198
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def f(a):
        return Lazy.of(a + 10)

    l = Lazy.of(1).bind(f)
    assert l.get() == 11

# Generated at 2022-06-12 05:12:33.514795
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left
    from pymonet.monad_set import Set
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.monad_list import List

    monad = Lazy.of(2)
    assert monad.ap(Maybe.nothing()) == monad
    assert monad.ap(Maybe.just(lambda x: x * 2)) == Lazy.of(4)
    assert monad.ap(Box(2)) == Lazy.of(4)
    assert monad.ap(List.of(2)) == Lazy.of(4)

# Generated at 2022-06-12 05:12:37.484912
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def function_for_test():
        return 123

    def mapper(x):
        return x + 1

    first = Lazy.of(123)
    second = Lazy.of(123)
    assert first == second

    first = Lazy(function_for_test)
    second = Lazy(function_for_test)
    assert first == second

    first = Lazy.of(123).map(mapper)
    second = Lazy.of(123).map(mapper)
    assert first == second



# Generated at 2022-06-12 05:12:41.561966
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def concat_to_string(x):
        return '{}'.format(x)

    def add_hello(x):
        return Lazy.of('Hello {}'.format(x))

    assert Lazy.of('World').bind(add_hello).bind(concat_to_string) == Lazy.of('Hello World')


# Generated at 2022-06-12 05:12:47.064149
# Unit test for method get of class Lazy
def test_Lazy_get():
    def sample_fn(value):
        return value

    lazy = Lazy(sample_fn)
    assert lazy.get(5) == 5  # Initial value
    assert lazy.get(2) == 5  # After value evaluation it will return memoized value
    assert lazy.get(7) == 5  # Ditto


# Generated at 2022-06-12 05:12:52.710891
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Method bind of class Lazy should return Lazy with constructor_fn which contains
    fold method call.
    """
    def fn(x):
        def constructor_fn(*args):
            return x()

        return Lazy(constructor_fn)

    lazy = Lazy(lambda : 'Lazy')
    lazy = lazy.bind(fn)

    assert 'Lazy' == lazy.get()


# Generated at 2022-06-12 05:12:57.083894
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_maybe import Maybe

    lazy = Lazy(lambda a, b: a + b)
    lazy_maybe = Maybe.just(lambda a: a * 2)

    assert lazy.ap(lazy_maybe).get(1, 2) == 4



# Generated at 2022-06-12 05:13:10.687088
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def increment(x: int) -> int:
        return x + 1

    def double(x: int) -> int:
        return x * 2

    def multiply_by_number(number: int) -> Callable[[int], int]:
        return lambda number_to_multiply: number * number_to_multiply

    def increment_and_double(x: int) -> Lazy[int, int]:
        return Lazy.of(increment(x)).bind(lambda y: Lazy.of(double(y)))

    assert increment_and_double(2).get() == 6
    assert increment_and_double(2).fold() == 6
    assert increment_and_double(2) == Lazy(lambda *args: increment(2)).bind(lambda y: Lazy.of(double(y)))


# Generated at 2022-06-12 05:13:14.983663
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.utils import is_true

    def simple_function():
        return 3

    lazy = Lazy(simple_function)
    assert is_true('test Lazy.map', lazy.map(lambda x: x + 1))



# Generated at 2022-06-12 05:13:22.741929
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test to check if Lazy store, call and memoize function.
    """
    def test_function():
        """
        Function to memoize.
        """
        test_function.count += 1
        return test_function.count

    test_function.count = 0

    lazy = Lazy(test_function)

    assert lazy.get() == 1, "should return 1"
    assert lazy.get() == 1, "Should return memoized value 1"
    assert test_function.count == 1, "Should not call function"



# Generated at 2022-06-12 05:13:26.810227
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    def add(a):
        return lambda b: a + b

    lazy_add = Lazy(lambda b: add(1))
    assert lazy_add.ap(Box(2)) == Box(3)



# Generated at 2022-06-12 05:13:32.696757
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(lambda x: x + 1).get()(1) == 2

    def fn(a, b):
        return a + b

    assert Lazy.of(fn).get(1, 2) == 3



# Generated at 2022-06-12 05:13:37.751017
# Unit test for method get of class Lazy
def test_Lazy_get():
    def lazy_of(value):
        return Lazy(lambda: value)

    lazy1 = lazy_of(1)
    assert 1 == lazy1.get()
    assert 1 == lazy1.get()

    lazy_fn = lazy_of(lambda x: x)
    assert lazy_fn.get(2) == 2



# Generated at 2022-06-12 05:13:42.457415
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test get method of class Lazy
    """
    from .either import Right
    from .maybe import Maybe

    def add5(value):
        return value + 5

    def is_even(value):
        if value % 2 == 0:
            return Maybe.just(value)
        else:
            return Maybe.nothing()

    def is_even1(value):
        if value % 2 == 0:
            return Right(value)
        else:
            return Right.left("It is not an even number")

    lazy = Lazy.of(5)
    result = lazy.get()

    assert Lazy.of(5).get() == result
    assert lazy.bind(add5).get() == result + 5
    assert lazy.bind(is_even).get() == 5

# Generated at 2022-06-12 05:13:45.404503
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add1(a):
        return a + 1

    assert Lazy(lambda: add1).map(lambda a: a(2)).get() == 3


# Generated at 2022-06-12 05:13:50.202531
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    fn1 = lambda x: x
    lazy_function = Lazy(lambda: fn1(1))
    fold_result = lazy_function.bind(lambda x: Lazy(lambda y: fn1(x * 2))).get()
    assert fold_result == 2

# Generated at 2022-06-12 05:13:54.571478
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover

    def source_function(*args):
        return args[0] + 1

    assert Lazy(source_function) == Lazy(source_function)
    result = Lazy(source_function)
    assert result == result
    assert result != Lazy(source_function)
    assert result != Lazy(lambda x: x)


# Generated at 2022-06-12 05:14:00.655210
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def plus(a):
        return Lazy.of(a + 1)

    result = Lazy.of(5).bind(plus)
    assert result.get() == 6



# Generated at 2022-06-12 05:14:04.383264
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x + 2).bind(lambda x: Lazy(lambda: x + 3)).get(3) == 8
    assert Lazy(lambda x: x + 2).bind(lambda x: Lazy(lambda: x + 3)).get(1) == 6


# Generated at 2022-06-12 05:14:08.547156
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1).__eq__(Lazy(lambda: 1)) == True
    assert Lazy(lambda: 1).__eq__(Lazy(lambda: 2)) == False
    assert Lazy(lambda: 1).__eq__(None) == False


# Generated at 2022-06-12 05:14:20.235693
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.tuple import Tuple2

    def add_two(x):
        return x + 2

    def mult_by_2(x):
        return x * 2

    lazy = Lazy.of(1).map(add_two).map(mult_by_2)

    assert lazy.get() == 4
    assert lazy.get(2) == 4
    assert lazy.get(1, 2, 3) == 4
    assert lazy == Lazy.of(4)

    lazy = Lazy(lambda *args: Tuple2(1, *args))
    lazy2 = lazy.map(lambda x: x * 2)
    assert lazy2.get(1) == (1, 2)

    assert Lazy.of(1).map(add_two).map(mult_by_2).get() == 4



# Generated at 2022-06-12 05:14:29.490657
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(10) == Lazy.of(10)
    assert Lazy.of(10) != Lazy.of(100)

    def fn(value):
        return value * 100

    assert Lazy.of(10).map(fn) == Lazy.of(10).map(fn)
    assert Lazy.of(10).map(fn) != Lazy.of(100).map(fn)

    assert Lazy.of(10).ap(Lazy.of(fn)) != Lazy.of(10).ap(Lazy.of(lambda x: x * 10))


# Generated at 2022-06-12 05:14:34.169342
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def dummy_function() -> int:
        return 10

    lazy_instance = Lazy(dummy_function)
    assert lazy_instance.get() == 10
    assert lazy_instance.is_evaluated is True
    assert lazy_instance.value == 10
    assert lazy_instance.get() == lazy_instance.value == 10


# Generated at 2022-06-12 05:14:42.645269
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__(): # pragma: no cover
    assert Lazy.of(2).map(lambda x: x + 1) == Lazy(lambda: 3)
    assert Lazy.of(2).map(lambda x: x + 2) != Lazy(lambda: 3)
    assert Lazy.of(2).map(lambda x: x + 2) != Lazy(lambda x: x + 1)
    assert Lazy.of(2).map(lambda x: x + 2) != Lazy.of(1)



# Generated at 2022-06-12 05:14:53.361639
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.fn.monoid import Monoid
    from pymonet.fn import Monoid, identity

    assert Lazy.of(identity).ap(Lazy.of(Box(1))).get() == 1
    assert Lazy.of(identity).ap(Lazy.of(Box(''))).get() == ''

    assert (
        Lazy.of(lambda x: Monoid(x)).ap(Lazy.of(Box(1))).get()
        == Monoid(1)
    )
    assert (
        Lazy.of(lambda x: Monoid(x)).ap(Lazy.of(Box(''))).get()
        == Monoid('')
    )



# Generated at 2022-06-12 05:15:01.333857
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    # Test with different evaluated and non evaluated Lazy
    assert Lazy.of(5) != Lazy.of(5)
    assert Lazy.of(5).map(lambda x: x) != Lazy.of(5).map(lambda x: x)

    # Test with different evaluated, but with same values
    assert Lazy.of(5) != Lazy.of(5).map(lambda x: x).get()
    assert Lazy.of(5).map(lambda x: x) != Lazy.of(5).map(lambda x: x).get()

    # Test with different evaluated, but with different values
    assert Lazy.of(5) != Lazy.of(5).map(lambda x: x + 1).get()
    assert Lazy.of(5).map(lambda x: x)

# Generated at 2022-06-12 05:15:02.526469
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(x):
        return x + 10

    lazy = Lazy(f)
    lazy2 = Lazy(f)

    assert lazy == lazy2



# Generated at 2022-06-12 05:15:09.721730
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 'foo') == Lazy(lambda: 'foo')
    assert Lazy(lambda: 'foo') != Lazy(lambda: 'bar')
    assert Lazy(lambda: 'foo') != Lazy(lambda: None)
    assert Lazy(lambda: 'foo') != 'foo'

# Generated at 2022-06-12 05:15:18.461300
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from functools import partial

    def fn1():
        return 'ok'

    def fn2():
        return 'ok'

    def fn3():
        return 'ko'

    lazy1 = Lazy(fn1)
    lazy2 = Lazy(fn2)
    lazy3 = Lazy(fn3)
    lazy4 = Lazy(partial(fn1, 'ko'))

    assert lazy1 == lazy2
    assert lazy2 == lazy1
    assert lazy1 != lazy3
    assert lazy3 != lazy1
    assert lazy1 != lazy4
    assert lazy4 != lazy1



# Generated at 2022-06-12 05:15:22.732140
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add(a, b):
        return a + b
    def add_one(a):
        return a + 1

    assert Lazy(lambda: add(1, 2)).map(add_one) == Lazy(lambda: add_one(add(1, 2)))


# Generated at 2022-06-12 05:15:34.404016
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def _f2():
        return 2

    def _f3(*args):
        return 3

    def _f4(*args):
        return 4

    def _f5(*args):
        return 5

    def _f6(*args):
        return 6

    assert Lazy(lambda: 2) == Lazy(_f2)

    _l1 = Lazy(_f2)
    _l2 = _l1.map(lambda x: x + 1)
    assert _l1 != _l2
    _l3 = _l2.bind(lambda x: Lazy(_f3))
    assert _l2 != _l3
    _l4 = _l3.ap(Lazy(_f4))
    assert _l3 != _l4
    _l5 = _l4.ap(Lazy(_f5))
   

# Generated at 2022-06-12 05:15:37.888880
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor import Functor

    def fn0(a):
        return Lazy(lambda: a + 1)

    def fn1(a):
        return Lazy(lambda: a * 2)

    assert Lazy.of(0).bind(fn0).bind(fn1).get() == 2



# Generated at 2022-06-12 05:15:49.832909
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.functor import test_functor


# Generated at 2022-06-12 05:16:00.092239
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Lazy __eq__ method should returns True only when two objects are equals
    """

    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add_1(value):
        return value + 1

    # Two Lazy are equals where both are evaluated both have the same value and constructor functions.
    assert Lazy(Box(1)).__eq__(Lazy(Box(1)))
    assert Lazy(Maybe.just(1)).__eq__(Lazy(Maybe.just(1)))

    # Uncomputed Lazy are equals only when they have the same constructor functions.
    assert Lazy(add_1).__eq__(Lazy(add_1))
    assert not Lazy(add_1).__eq__(Lazy(lambda x: x - 1))

    # Computed Lazy are equals only

# Generated at 2022-06-12 05:16:04.829720
# Unit test for method get of class Lazy
def test_Lazy_get():
    counter = 0
    def func():
        nonlocal counter
        counter += 1
        return counter + 1
    lazy = Lazy(func)
    assert lazy.get() == 2
    assert lazy.is_evaluated == True
    assert lazy.get() == 2
    assert counter == 1



# Generated at 2022-06-12 05:16:09.849928
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    def get_lazy_int(x):
        return Lazy(lambda: x)

    def add(x):
        def add_one(y):
            return y + 1

        return get_lazy_int(x).map(add_one)

    assert Lazy.of(3).ap(add(1)).get() == 4

# Generated at 2022-06-12 05:16:16.840014
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def plus1(x):
        return x + 1

    def plus3(x):
        return x + 3

    def plus5(x):
        return x + 5

    lazy = Lazy.of(10)
    assert lazy.ap(Lazy.of(plus1)) == Lazy.of(plus1(10))
    assert lazy.ap(Lazy.of(plus3)).ap(Lazy.of(plus5)) == Lazy.of(plus1(plus3(10)))



# Generated at 2022-06-12 05:16:27.299742
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.functor_test import test_functor_identity, test_functor_composition
    from pymonet.monad_test import test_monad_left_identity, test_monad_right_identity
    from pymonet.monad_test import test_monad_associativity
    from pymonet.monad_test import test_monad_left_zero, test_monad_right_zero
    from pymonet.monad_test import test_monad_associativity_left
    from pymonet.monad_test import test_monad_associativity_right
    import unittest

    class TestLazy(unittest.TestCase):
        def setUp(self):
            def twice(x):
                return x * 2


# Generated at 2022-06-12 05:16:31.208678
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add_1(x: int) -> int:
        return x + 1

    lazy_box = Lazy.of(1).map(add_1)
    assert lazy_box.get() == 2



# Generated at 2022-06-12 05:16:32.547992
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1



# Generated at 2022-06-12 05:16:35.812224
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1


# Generated at 2022-06-12 05:16:38.616503
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(1).ap(Lazy.of(lambda x: x + x)) == Lazy.of(2)



# Generated at 2022-06-12 05:16:49.272431
# Unit test for method get of class Lazy
def test_Lazy_get():
    class A:
        def __init__(self, value):
            self.value = value

    class B:
        def __init__(self, value):
            self.value = value

    a = Lazy(lambda: A(1))
    assert a.get() == A(1)

    b = Lazy(lambda: B(2))
    assert b.get() == B(2)

    lazy = Lazy(lambda: a.get().value + 1)
    assert lazy.get() == 2

    lazy = a.map(lambda a: B(a.value + 1))
    assert lazy.get() == B(2)

    lazy = b.map(lambda b: A(b.value + 1))
    assert lazy.get() == A(3)

    lazy = Lazy.of(1)

# Generated at 2022-06-12 05:16:53.269922
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_int = Lazy.of(1)
    lazy_fn = Lazy.of(lambda x: x + 1)

    assert lazy_int.ap(lazy_fn).get() == 2


# Generated at 2022-06-12 05:16:57.919432
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_two(value):
        return Lazy.of(value + 2)

    assert Lazy(lambda: 5).bind(add_two) == Lazy.of(7)
    assert Lazy(lambda: 3).bind(add_two) == Lazy.of(5)

# Generated at 2022-06-12 05:17:06.206678
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fun1():
        return 1

    def fun2():
        return 2

    def fun3():
        return 3

    def mapper1(x):
        return x + 1

    def mapper2(x):
        return x + 2

    def mapper3(x):
        return x + 3

    lazy1 = Lazy.of(fun1)
    lazy2 = Lazy.of(fun2)
    lazy3 = Lazy.of(fun3)

    assert lazy1 == lazy1
    assert lazy1 != lazy2

    assert lazy1.map(mapper1) == lazy1.map(mapper1)
    assert lazy1.map(mapper1) != lazy1.map(mapper2)


# Generated at 2022-06-12 05:17:08.157879
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def fn():
        return 'result'

    assert Lazy(fn) == Lazy(fn)

# Generated at 2022-06-12 05:17:12.781341
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(12).map(lambda x: x + 1).get() == 13


# Generated at 2022-06-12 05:17:19.045052
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.functions import identity

    assert Lazy(lambda x: x).get(1) == 1
    assert Lazy(lambda x: x).map(identity).get(1) == 1
    assert Lazy(lambda x: x).map(identity).map(identity).get(1) == 1
    assert Lazy(lambda x: x).map(identity).map(identity).map(identity).get(1) == 1
    assert Lazy(lambda x: x).map(identity).map(identity).map(identity).map(identity).get(1) == 1

# Generated at 2022-06-12 05:17:30.338502
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Perform unit test for map method of class Lazy.
    """
    from pymonet.box import Box
    from pymonet.monad_try import Try

    class MockedLazy:
        def __init__(self):
            self.is_called = False
            self.value = None

        def compute_value(self, *args):
            self.is_called = True
            self.value = args
            return self.value

    mocked_lazy = MockedLazy()
    lazy = Lazy(lambda fn: Lazy(mocked_lazy.compute_value)).map(lambda lazy: lazy.map(lambda value: value + 10))

# Generated at 2022-06-12 05:17:33.852154
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Testing get method of class Lazy
    """
    # given
    def test_function(value):
        return value

    lazy = Lazy(test_function)

    # when
    result = lazy.get(10)

    # then
    assert result == 10


# Generated at 2022-06-12 05:17:45.835777
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Box(None).ap(Box(lambda x: x + 1)) == Box(None)
    assert Box(None).ap(Box(lambda x: x)) == Box(None)
    assert Box(1).ap(Box(lambda x: x + 1)) != Box(None)

    assert Maybe.just(None).ap(Maybe.just(lambda x: x + 1)) == Maybe.just(None)
    assert Maybe.just(None).ap(Maybe.just(lambda x: x)) == Maybe.just(None)
    assert Maybe.just(1).ap(Maybe.just(lambda x: x + 1)) != Maybe.just(None)


# Generated at 2022-06-12 05:17:48.229202
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(n):
        return Lazy(lambda: n + 1)

    assert Lazy.of(5).bind(add_one).get(5) == 6

# Generated at 2022-06-12 05:17:59.286128
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for method bind of class Lazy
    """
    test_cases = [
        (lambda my_value: Lazy(lambda: my_value), 'abc', 'abc'),
        (lambda my_value: Lazy(lambda: my_value * 2), 11, 22),
        (lambda my_value: Lazy(lambda: my_value), None, None),
        (lambda my_value: Lazy(lambda: my_value * 2), None, None),
        (lambda my_value: Lazy(lambda: my_value), 0, 0),
        (lambda my_value: Lazy(lambda: my_value * 2), 0, 0),
    ]


# Generated at 2022-06-12 05:18:02.881246
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add(x, y):
        return x + y

    result = Lazy.of(4).bind(lambda x: Lazy.of(5)).bind(add)
    assert result.get() == 9



# Generated at 2022-06-12 05:18:09.499160
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def f() -> int:
        return 10

    def g() -> int:
        return 10

    def h() -> int:
        return 20

    def j() -> int:
        return 20

    assert Lazy(f) == Lazy(f)
    assert Lazy(g) == Lazy(g)
    assert Lazy(h) == Lazy(j)
    assert Lazy(f) == Lazy(g)
    assert Lazy(h) == Lazy(h)

    assert Lazy(f) != Lazy(h)
    assert Lazy(g) != Lazy(j)

# Generated at 2022-06-12 05:18:11.665889
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)



# Generated at 2022-06-12 05:18:21.522558
# Unit test for method map of class Lazy
def test_Lazy_map():
    def some_fn_with_argument(x: int) -> int:
        return x + 1

    result = Lazy(lambda: 1).map(some_fn_with_argument)

    assert result.is_evaluated == False
    assert result.value is None
    assert result.constructor_fn(1) == some_fn_with_argument(1)

# Generated at 2022-06-12 05:18:25.559821
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    l1 = Lazy(lambda x: x)
    l2 = Lazy(lambda x: x)
    assert l1 is not l2, \
        'Lazy(lambda x: x) is Lazy(lambda x: x) for two different instances'



# Generated at 2022-06-12 05:18:28.373714
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda: 1)
    assert lazy.get() == 1

    lazy2 = Lazy(lambda: 1).map(lambda x: x + 2)
    assert lazy2.get() == 3



# Generated at 2022-06-12 05:18:32.598076
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def fn(x):
        return x.upper()

    assert Lazy.of('test').ap(Box(fn)) == Lazy.of(fn).ap(Lazy.of('test')) == Lazy.of('TEST')


# Generated at 2022-06-12 05:18:38.765849
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fd(a):
        return a + 1

    fd_lazy = Lazy(fd)
    fd_lazy_copy1 = Lazy(fd)
    fd_lazy_copy2 = Lazy(fd)
    fd_lazy_copy1_computed = Lazy(fd)
    fd_lazy_copy2_computed = Lazy(fd)

    fd_lazy_copy1_computed._compute_value(1)
    fd_lazy_copy2_computed._compute_value(1)

    assert fd_lazy == fd_lazy_copy1
    assert fd_lazy == fd_lazy_copy2
    assert fd_lazy_copy1 == fd_lazy_copy2

# Generated at 2022-06-12 05:18:46.153821
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one_fn(x):
        return x + 1

    def multiply_by_two_fn(x):
        return x * 2

    assert Lazy.of(20).map(add_one_fn) == Lazy.of(21)
    assert Lazy.of(15).map(multiply_by_two_fn) == Lazy.of(30)
    assert Lazy.of('aaa').map(str.lower) == Lazy.of('aaa')



# Generated at 2022-06-12 05:18:56.493528
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    assert Lazy(str) == Lazy(str)
    assert Lazy(str).map(str) == Lazy(str).map(str)
    assert Lazy(str).map(Box) == Lazy(str).map(Box)
    assert Lazy(str).map(Maybe) == Lazy(str).map(Maybe)
    assert Lazy(str).map(Right) == Lazy(str).map(Right)
    assert Lazy(str) != Lazy(int)
    assert Lazy(str).map(str) != Lazy(str).map(int)
    assert Lazy(str).map(Box) != Lazy(str).map(Maybe)

# Generated at 2022-06-12 05:19:05.172034
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    This test illustrates bind method of class Lazy
    """
    import random

    def run_fn_with_args(fn: Callable[[int], int], *args) -> 'Lazy[int, int]':
        return Lazy(lambda: fn(*args))

    lazy_add_2 = run_fn_with_args(lambda x: x + 2, 2)
    lazy_add_10 = run_fn_with_args(lambda x: x + 10, 10)
    lazy_add_random = run_fn_with_args(lambda x: x + random.randint(1, 100), random.randint(1, 100))

    assert lazy_add_2.get() == 4
    assert lazy_add_2.bind(lambda x: lazy_add_10).get() == 14
    assert lazy_add_2

# Generated at 2022-06-12 05:19:10.706752
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    def _fn(x):
        return Lazy(lambda y: x * y)

    a1 = Lazy(lambda: 2)
    a2 = Lazy(lambda: 3)

    assert a1.ap(_fn(a2)).get() == 6
    assert a1.ap(_fn(Lazy.of(3))).get() == 6

# Generated at 2022-06-12 05:19:17.828527
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.functor import Functor
    from pymonet.monad_either import Either, Left, Right
    from pymonet.function import Function
    lazy = Lazy(None)
    fn = Function.compose(lambda x: x * 2, lambda x: x + 10)
    result = Functor.map(lazy, fn)
    assert isinstance(result, Lazy)
    assert result.constructor_fn(10) == 40
    assert result.constructor_fn(20) == 60
    # TODO: Add more test cases


# Generated at 2022-06-12 05:19:34.771766
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.functor import functor_test_suite

    def test_functor_instance(x_value, mapper):
        def test(get_inner_lazy):
            return get_inner_lazy(x_value)

        def inner_lazy(x_value):
            return Lazy(lambda: x_value)

        x = inner_lazy(x_value)
        y = inner_lazy(mapper)
        ap_result = test(y)

        functor_test_suite(test, Lazy, x)

        return ap_result

    assert test_functor_instance(1, lambda x: x + 1) == 2
    assert test_functor_instance(False, lambda x: not x) is True

# Generated at 2022-06-12 05:19:41.867207
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box

    def square(x):
        return x * x

    def add(x, y):
        return x + y

    # bind function return Lazy for add passing Box
    def add_lazy(x):
        return Lazy(lambda: add(x, x))

    lazy = Lazy(lambda: 1)
    assert lazy.bind(add_lazy).get() == 4

    # It's not possible to call bind for second time
    # assert lazy.bind(add_lazy).bind(lambda x: Lazy(lambda: x * 2)).get() == 8

    # but is possible to chain method
    assert lazy.bind(add_lazy).bind(lambda x: Lazy(lambda: x)).get() == 4

# Generated at 2022-06-12 05:19:48.834093
# Unit test for method map of class Lazy
def test_Lazy_map():
    fn = lambda x: x * 2
    mapper = lambda x: x + 3

    x = Lazy(fn).map(mapper)

    assert x.get(10) == 28

    x = Lazy(fn).map(mapper).map(mapper)

    assert x.get(10) == 31



# Generated at 2022-06-12 05:19:55.639155
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.monad_maybe import Maybe

    fn = Lazy.of(1).map(lambda x: x + 1)
    assert isinstance(fn, Lazy)
    assert fn == Lazy(lambda *args: 2)
    assert fn.get() == 2
    assert fn.to_box().unbox() == 2
    assert fn.to_either().is_right()
    assert fn.to_maybe() == Maybe.just(2)
    assert fn.to_validation().is_success()
    assert fn.to_try().is_success()
    assert fn.to_validation().get_or_fail() == 2
    assert fn.to_try().get_or_default() == 2



# Generated at 2022-06-12 05:19:58.979376
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn1(*args):
        return args

    lazy = Lazy(fn1)

    assert lazy.get(1) == (1,)
    assert lazy.get(2) == (1,)

# Generated at 2022-06-12 05:20:01.615375
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    assert Lazy(lambda x: x + 2).map(lambda x: x*2) == Lazy(lambda x: x*2 + 4)


# Generated at 2022-06-12 05:20:04.959010
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) == True
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1)) == False

# Generated at 2022-06-12 05:20:16.595737
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.bool import Bool

    def test_fn(*args):
        return lambda x: x + 1

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 2

    lazy = Lazy.of(10)
    assert lazy.get() == 10

    lazy = Lazy(lambda: 20)
    assert lazy.get() == 20

    lazy = Lazy(lambda: 0 / 0)
    assert lazy.to_box().is_instance(Box) is Bool(True)
    with pytest.raises(ZeroDivisionError):
        lazy.get()

# Generated at 2022-06-12 05:20:19.801315
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_five(a):
        return Lazy(lambda b: a + b)

    lazy = Lazy(lambda: 10)
    assert(lazy.bind(add_five).get(5) == 15)

# Generated at 2022-06-12 05:20:22.216121
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test for get method of Lazy

    :return:
    """
    get_five = Lazy(lambda: 5)
    assert get_five.get() == 5



# Generated at 2022-06-12 05:20:46.236587
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x): return x + 1

    def fm(x): return x * 2

    def fn_validation(x): return Validation.success(x + 1)

    left_lazy = Lazy(fn).to_box().bind(fn_validation).to_either().bind(fn)
    right_lazy = Lazy(fn).to_box().bind(fn_validation).to_either().bind(fn)

    assert left_lazy == right_lazy

    left_lazy = Lazy(fn).map(fm).to_box().bind(fn_validation).to

# Generated at 2022-06-12 05:20:49.588838
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.monad_dict import monad_dict

    assert Lazy.of(1).get(dict()) == 1
    assert Lazy.of({'key': 1}).map(monad_dict.get('key')).get(dict()) == 1



# Generated at 2022-06-12 05:21:01.247253
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.validation import Validation

    def evaluate_in_Lazy(fn, x):
        """
        Wrap function in Lazy and evaluate result.
        """
        return Lazy(fn).bind(lambda _: Lazy(lambda *args: x)).get()

    def evaluate_in_Validation(fn, x, y):
        """
        Wrap function in Validation and evaluate result.
        """
        return Validation.of(fn).bind(lambda _: Validation.success(x)).get()

    def add(x, y):
        """
        Function with two args returning sum of both.
        """
        return x + y

    assert evaluate_in_Lazy(add, 0) == 0
    assert evaluate