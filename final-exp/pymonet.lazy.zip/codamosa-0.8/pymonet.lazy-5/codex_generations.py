

# Generated at 2022-06-12 05:11:10.862594
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def create_person(name, age):
        return {
            'name': name,
            'age': age,
        }

    def get_person_name(person):
        return person['name']

    lazy_person_name = Lazy.of('Lol').bind(lambda name: Lazy.of(create_person(name, 16))).bind(get_person_name)
    assert lazy_person_name.get() == 'Lol'

    def get_person_age(person):
        return '{} aged {} years'.format(person['name'], person['age'])

    lazy_person_description = Lazy.of('Lol').bind(lambda name: Lazy.of(create_person(name, 16))).bind(get_person_age)

# Generated at 2022-06-12 05:11:21.402790
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def fn(lazy):
        def inner_fn(val):
            return Lazy.of(val + 1)

        return lazy.bind(inner_fn)

    def fn2(lazy):
        def inner_fn(val):
            return Validation.success(val + 1)

        return lazy.to_validation().bind(inner_fn)

    computed_value = Lazy.of(10).bind(fn).get()
    assert computed_value == 11, 'Lazy must return result of previous bind function'

    computed_value = Lazy.of(10).bind(fn2).get()
    assert computed_value == 11, 'Lazy must return result of previous bind function'


# Generated at 2022-06-12 05:11:28.442568
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    double = lambda x: Lazy.of(x * 2)
    plus_three = lambda x: Lazy.of(x + 3)

    test_lazy = Lazy.of(1)
    result = test_lazy.bind(double).bind(plus_three)

    assert result.get() == Box(5)



# Generated at 2022-06-12 05:11:32.212644
# Unit test for method map of class Lazy
def test_Lazy_map():
    value = 10
    mapper = lambda x: x + 10
    lazy = Lazy.of(value).map(mapper)

    assert lazy.get() == mapper(value)
    assert lazy.get() == value + 10


# Generated at 2022-06-12 05:11:41.220419
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def x(a):
        return Lazy(lambda: a)

    def x1(a):
        return Lazy(lambda: a * 3)

    assert Lazy(lambda: 1).bind(x).get() == x(1).get()
    assert Lazy(lambda: 1).bind(x1).get() == x1(1).get()
    assert Lazy(lambda: 2).bind(x1).bind(x).get() == x(x1(2).get()).get()
    assert Lazy(lambda: 2).bind(x1).bind(x1).bind(x1).get() == Lazy(lambda: 2).map(x1).map(x1).map(x1).get()

# Generated at 2022-06-12 05:11:47.353169
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert (Lazy.of(1) == Lazy.of(1)) is True
    assert (Lazy.of(1) == Lazy.of(2)) is False
    assert (Lazy.of(1) == Lazy.of(lambda: 1)) is True
    assert (Lazy.of(1) == Lazy.of(lambda: 2)) is False



# Generated at 2022-06-12 05:11:57.076892
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def subtract_four(x):
        return x - 4

    assert Lazy(add_one).ap(Lazy(multiply_by_two)).get() == multiply_by_two(add_one(0))
    assert Lazy(add_one).ap(Lazy(multiply_by_two)).ap(Lazy(subtract_four)).get() == subtract_four(multiply_by_two(add_one(0)))
    assert Lazy(add_one).ap(Lazy(multiply_by_two).ap(Lazy(subtract_four))).get() == add_one(multiply_by_two(subtract_four(0)))



# Generated at 2022-06-12 05:12:00.019792
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != 1


# Generated at 2022-06-12 05:12:04.407947
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy1 = Lazy(lambda x: x + 1)

    lazy2 = lazy1.bind(
        lambda value: Lazy(lambda y: value * y + 2)
    )

    assert lazy2.get(1, 2) == 5



# Generated at 2022-06-12 05:12:09.211185
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given
    def test() -> int:
        return 4

    def mapper(value: int) -> str:
        return str(value)

    # When
    lazy = Lazy(test).map(mapper)

    # Then
    assert lazy.constructor_fn() == '4'


# Generated at 2022-06-12 05:12:20.358513
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(2) == Lazy.of(2)
    another_lazy = Lazy(lambda *_: 2)
    assert Lazy.of(2) == another_lazy
    str_lazy = Lazy(lambda *_: 'a')
    assert str_lazy == str_lazy
    assert not Lazy.of(2) == Lazy.of(3)
    assert Lazy.of(2) != Lazy.of(3)

# Generated at 2022-06-12 05:12:25.807722
# Unit test for method get of class Lazy
def test_Lazy_get():
    def sum(a, b):
        return a + b

    lazy = Lazy(sum(1, 2))

    assert lazy.is_evaluated == False
    assert lazy.get() == 3
    assert lazy.is_evaluated == True
    assert lazy.get() == 3
    assert lazy.is_evaluated == True


# Generated at 2022-06-12 05:12:33.125235
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def func(*args):
        return args[0]

    def func_not_equal(*args):
        return 42

    lazy = Lazy(func)
    lazy_with_func_not_equal = Lazy(func_not_equal)
    lazy_with_func_not_equal_duplicate = Lazy(func_not_equal)

    assert lazy != lazy_with_func_not_equal
    assert lazy_with_func_not_equal == lazy_with_func_not_equal_duplicate

# Generated at 2022-06-12 05:12:37.070218
# Unit test for method get of class Lazy
def test_Lazy_get():
    def get_value(x):
        def _get_value():
            return x ** 2

        return Lazy(_get_value)

    assert Lazy.of(5).get() == 5
    assert get_value(5).get() == 25


# Generated at 2022-06-12 05:12:40.486196
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Unit test for method __eq__ of class Lazy
    """
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1.0)



# Generated at 2022-06-12 05:12:46.644817
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def foo(arg1, arg2):
        return 3

    assert Lazy(foo) == Lazy(foo)
    assert Lazy(foo) != Lazy(lambda: 4)
    assert Lazy(foo) != Lazy(lambda: 3)
    assert Lazy(foo) != 3
    assert Lazy(lambda: 3) != Lazy(lambda: 4)



# Generated at 2022-06-12 05:12:53.560138
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    assert Lazy.of(1).map(Box).get() == Box(1)
    assert Lazy(lambda: 1).map(lambda x: x + 2).get() == 3
    assert Lazy(lambda: 1).map(Box).get() == Box(1)
    assert Lazy(lambda: 1).map(Box).map(lambda box: box.get()).get() == 1

    assert Box(1).map(Lazy).get() == Lazy.of(Box(1)).get()


# Generated at 2022-06-12 05:12:56.746968
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda *args, **kwargs: 1).get(1, 2) == 1


# Generated at 2022-06-12 05:12:59.902816
# Unit test for method map of class Lazy
def test_Lazy_map():
    fn = lambda x: x + 1
    c_fn = lambda x: x
    lazy = Lazy(c_fn)

    assert lazy.map(fn) == Lazy(lambda *args: fn(c_fn(*args)))


# Generated at 2022-06-12 05:13:10.724921
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def f(x):
        return x + 2

    def g(x):
        return x * 3

    def h(x):
        return Maybe(x)

    def to_m(x):
        return Try(int, x)

    def id(x):
        return x

    assert Lazy.of(1).bind(f) == Lazy.of(3)
    assert Lazy.of(1).bind(id) == Lazy.of(1)
    assert Lazy.of(1).bind(f).bind(g) == Lazy.of(9)
    assert Lazy.of(1).bind(f).bind(g).bind(f) == Lazy.of(11)


# Generated at 2022-06-12 05:13:19.522687
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return value + 1

    def fn_raise():
        raise Exception

    def fn_return_value(value):
        return Right(value)

    def fn_return_value_raise(value):
        if value is False:
            raise Exception
        return Right(value)

    def fn_return_value_try(value):
        return Try.of(fn, value)

    def fn_return_value_validation(value):
        if value is False:
            return Validation.failure(["Validation is not successful"])

# Generated at 2022-06-12 05:13:29.834123
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 'c') == Lazy(lambda: 'c')
    assert not Lazy(lambda: 'c') == Lazy(lambda: 'd')
    assert not Lazy(lambda: 'c') == 'Lazy(lambda: c)'
    assert Lazy(lambda: 'c').get() == Lazy(lambda: 'c').get()
    assert Lazy(lambda: 'c').map(lambda x: 'd').get() != Lazy(lambda: 'c').map(lambda x: 'c').get()

    assert Lazy(lambda: 'c').to_box().get() == Lazy(lambda: 'c').to_box().get()

# Generated at 2022-06-12 05:13:34.419983
# Unit test for method get of class Lazy
def test_Lazy_get():
    test_fn = lambda a, b: a + b
    lazy_test_fn = Lazy(test_fn)

    lazy_test_fn_result = lazy_test_fn.get(1, 2)

    assert lazy_test_fn_result == 3

# Generated at 2022-06-12 05:13:43.728995
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy(lambda x: x)

    def f(x):
        return Lazy(lambda: x)

    assert lazy.bind(f).get() == lazy.constructor_fn()
    assert lazy.bind(f).get(123) == lazy.constructor_fn(123)
    assert lazy.bind(f).get(123, 'abc') == lazy.constructor_fn(123, 'abc')
    assert lazy.bind(f).get(123, 'abc', 'def') == lazy.constructor_fn(123, 'abc', 'def')
    assert lazy.bind(f).get(123, 'abc', 'def', 456) == lazy.constructor_fn(123, 'abc', 'def', 456)


# Generated at 2022-06-12 05:13:50.150078
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(4).map(lambda x: x + 1) == Lazy.of(4).map(lambda x: x + 1)
    assert Lazy.of(4).map(lambda x: x + 1) != Lazy.of(5).map(lambda x: x + 1)
    assert Lazy.of(4).map(lambda x: x + 1) != object()

# Generated at 2022-06-12 05:13:54.040343
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box

    Lazy.of(1) == Lazy.of(1)
    Lazy.of(1) == Lazy.of(2)
    Lazy.of(1) == Box(1)
    Lazy.of(1) == list()



# Generated at 2022-06-12 05:14:03.401622
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert (Lazy.of(3).map(lambda x: x + 2) == Lazy.of(5))
    assert (Lazy.of(2).map(lambda x: x * 2).map(lambda x: x ** 2) == Lazy.of(8))
    assert (Lazy(lambda: 2).map(lambda x: x ** 2) == Lazy.of(4))
    assert (Lazy(lambda: 2).map(lambda x: x ** 2).map(lambda x: x * 2) == Lazy.of(8))


# Generated at 2022-06-12 05:14:08.862771
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test that ap passed function to context value and return new Lazy with result.
    """
    test_value = Lazy(lambda x: x + 1)
    test_fn = Lazy(lambda x: x * 2)

    assert (test_value.ap(test_fn)).get(3) == 8



# Generated at 2022-06-12 05:14:17.241361
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Check if map method return new Lazy object with mapped constructor_fn and this constructor_fn will be not evaluated.
    """
    def mapper(x):
        return x * 2

    lazy = Lazy(lambda x: x + 1)
    new_lazy = lazy.map(mapper)

    assert new_lazy == Lazy(lambda x: mapper(lazy.constructor_fn(x)))
    assert new_lazy.is_evaluated is False


# Generated at 2022-06-12 05:14:22.237524
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy(lambda: 1)
    assert Lazy.of(1) != Lazy(lambda: 2)
    assert Lazy.of(1) != Lazy(lambda: 'a')
    assert Lazy.of(1) != Lazy.of('a')
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(None)



# Generated at 2022-06-12 05:14:31.433120
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(10).get() == 10
    assert Lazy.of('foo').get() == 'foo'
    assert Lazy.of(['foo', 30]).get() == ['foo', 30]
    assert Lazy.of(10).get() == 10
    assert Lazy(lambda x: x * 10).get(2) == 20
    assert Lazy(lambda x: x + 10).get(2) == 12
    assert Lazy(lambda x: x).get('hoi') == 'hoi'



# Generated at 2022-06-12 05:14:34.724789
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def create_lazy() -> Lazy[int, int]:
        return Lazy(lambda i: i + 1)

    assert create_lazy().get(2) == 3



# Generated at 2022-06-12 05:14:45.339101
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test contains 3 test functions to bind to Lazy which return the same value as argument after modification.
    :return: True if all tests are successes
    """
    def test_function(value):
        """
        This function just return inner function, which returns value passed as argument
        """
        def inner_function(*args):
            """
            Function returns value
            """
            return value(*args)

        return inner_function

    def test_function_add_one(value):
        """
        This function takes one argument, return one more and returns inner function
        """
        def inner_function(*args):
            """
            Function add one and return value
            """
            return value(*args) + 1

        return inner_function


# Generated at 2022-06-12 05:14:54.645311
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test for method map of class Lazy.

    :returns:
    """
    from pymonet.maybe import Maybe

    def fn():
        return 2

    def mapper(arg):
        return arg + 10

    lazy_fn = Lazy(fn)
    result = lazy_fn.map(mapper)

    assert result.get() == 12
    assert result.to_maybe().get() == 12

    lazy_fn = Lazy.of(Maybe.just(1))
    result = lazy_fn.map(mapper)

    assert result.get() == 11
    assert result.to_maybe().get() == 11

    lazy_fn = Lazy.of(Maybe.nothing())
    result = lazy_fn.map(mapper)

    assert result.get() == Maybe.nothing()
    assert result.to

# Generated at 2022-06-12 05:15:00.340468
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_fn(*args):
        return args

    assert Lazy(test_fn) == Lazy(test_fn)

    lazy = Lazy(test_fn)
    lazy.is_evaluated = True
    lazy.value = 1

    assert Lazy(test_fn) != lazy
    assert Lazy(test_fn).map(lambda x: x + 1) != Lazy(test_fn)
    assert Lazy(test_fn) != Lazy(lambda x: x + 1)


# Unit tests for method of of class Lazy

# Generated at 2022-06-12 05:15:06.284291
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda i: i).__eq__(Lazy(lambda i: i)) is True
    assert Lazy(lambda i: i).__eq__(Lazy(lambda i: i + 1)) is False
    assert Lazy(lambda i: i).__eq__(Lazy(lambda i, j: i + j)) is False



# Generated at 2022-06-12 05:15:11.040312
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(2) != Lazy.of(3)
    assert Lazy.of(2) != Lazy.of(2).map(int)
    assert Lazy.of(2) != (lambda x: x ** 2)
    assert Lazy.of(2) != None


# Generated at 2022-06-12 05:15:14.376935
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def constructor_fn():
        return 'a'

    assert Lazy(constructor_fn) == Lazy(constructor_fn)



# Generated at 2022-06-12 05:15:18.905654
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    list_ = [1, 2, 3]
    lazy = Lazy(lambda _: list_)

    def mapper(list_: list) -> Lazy[list, int]:
        assert isinstance(list_, list)

        return Lazy(lambda: list_[1] + 1)

    assert lazy.bind(mapper).get() == 4

# Generated at 2022-06-12 05:15:21.701765
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(4).bind(lambda x: Lazy(lambda: x * 5)) == Lazy(lambda: 20)



# Generated at 2022-06-12 05:15:28.167958
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_value = Lazy.of(3)
    def fn(val):
        return Lazy.of(val + 4)

    assert lazy_value.bind(fn).get() == 7


# Generated at 2022-06-12 05:15:33.384808
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(2).__eq__(Lazy.of(2))
    assert not Lazy.of(3).__eq__(Lazy.of(2))
    assert not Lazy.of(1).__eq__(None)
    assert not Lazy.of(0).__eq__(1)



# Generated at 2022-06-12 05:15:45.485970
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try, Error

    def sum_two(x):
        return x + 2

    def make_sum_two(y) -> Lazy[int, int]:
        return Lazy(sum_two)

    assert Lazy.of(1).ap(Lazy.of(sum_two)) == Lazy.of(3)
    assert Lazy.of(1).ap(Lazy.of(Lazy.of(2))) == Lazy.of(3)
    assert Lazy.of(1).ap(Lazy.of(make_sum_two(2))) == Lazy.of(1)
    assert Lazy.of(1).ap(Lazy.of(Right(2))) == Lazy.of(3)

# Generated at 2022-06-12 05:15:53.996622
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # pylint: disable=invalid-name
    def double_fn(x):
        return Lazy(lambda *args: x * 2)

    def triple_fn(x):
        return Lazy(lambda *args: x * 3)

    def fold(x):
        return x

    assert Lazy.of(11).bind(double_fn).bind(triple_fn).get(None) == 66
    assert Lazy.of(11).bind(lambda x: double_fn(x).bind(triple_fn)).get(None) == 66
    assert Lazy.of(11).bind(double_fn).bind(lambda x: triple_fn(x).bind(fold)).get(None) == 66

# Generated at 2022-06-12 05:15:56.898291
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def fn(value):
        return value

    assert Lazy(fn).get('NOPE') == 'NOPE'



# Generated at 2022-06-12 05:15:59.380353
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    fn = lambda x: x + 1
    assert fn != Lazy(fn).bind(lambda x: Lazy(lambda y: x + y)).constructor_fn



# Generated at 2022-06-12 05:16:02.792971
# Unit test for method get of class Lazy
def test_Lazy_get():
    def func_with_one_arg(x: int) -> int:
        return x

    lazy = Lazy(func_with_one_arg)
    assert lazy.get(1) == 1
    assert lazy.is_evaluated
    assert lazy.value == 1



# Generated at 2022-06-12 05:16:09.989100
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 2) == Lazy(lambda: 2)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 2) != Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)

    assert Lazy(lambda: 3) != None
    assert Lazy(lambda: 3) != object()
    assert Lazy(lambda: 3) != tuple()
    assert Lazy(lambda: 3) != [1]



# Generated at 2022-06-12 05:16:18.849476
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)

    fn1 = lambda: 1
    fn2 = lambda: 1

    lazy1 = Lazy(fn1)
    lazy2 = Lazy(fn1)
    lazy3 = Lazy(fn2)
    assert lazy1 != lazy2
    assert lazy1 == lazy3

    folded_lazy1 = lazy1.get()
    folded_lazy2 = lazy2.get()
    folded_lazy3 = lazy3.get()
    assert folded_lazy1 == lazy1
    assert folded_lazy1 == folded_lazy2
    assert folded_lazy1 == folded_lazy3



# Generated at 2022-06-12 05:16:23.962277
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for Lazy.bind method.
    """

    def test_function(value):
        def lambda_fn(*args):
            return value
        return Lazy(lambda_fn)

    lazy_function = Lazy(lambda *args: 'test')
    assert lazy_function.bind(test_function) == Lazy(lambda *args: 'test')


# Generated at 2022-06-12 05:16:45.174588
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    def l3(x):
        return Lazy(lambda: x + 3)

    def l6(x):
        return Lazy(lambda: x + 6)

    lazy = Lazy.of(2)
    assert lazy.bind(l3).bind(l6).get() == 11
    assert lazy.bind(l3).bind(l6).to_box().get() == 11
    assert lazy.bind(l3).bind(l6).to_either().get_or_else(0) == 11
    assert lazy.bind(l3).bind(l6).to_maybe().is_nothing() is False
    assert lazy.bind(l3).bind(l6).to_try().get() == 11

# Generated at 2022-06-12 05:16:49.731550
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(lambda: 1).__eq__(Lazy.of(lambda: 1))
    assert Lazy.of(lambda: 1).bind(lambda x: Lazy.of(lambda: x + 1)).__eq__(Lazy.of(lambda: 2))
    assert Lazy.of(None).__eq__(Lazy(None))

# Generated at 2022-06-12 05:16:59.582930
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.tuple import Tuple, fst, snd

    a = Lazy.of(10)
    b = a.bind(lambda x: Lazy.of(x + 1))

    assert a.get() == 10
    assert b.get() == 11

    a = Lazy(lambda: Tuple(Lazy.of(11), Lazy.of(0)))
    b = a.bind(lambda x: Lazy.of(fst(x) + snd(x)))

    assert a.get() == Tuple(11, 0)
    assert b.get() == 11


# Generated at 2022-06-12 05:17:05.553115
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test for method __eq__ of class Lazy
    """
    # pylint: disable=protected-access,invalid-name

    lazy_one = Lazy(lambda x: x + 1)
    lazy_two = Lazy(lambda x: x + 1)
    lazy_three = Lazy(lambda x: x + 2)
    lazy_four = Lazy(1)

    assert lazy_one == lazy_two
    assert lazy_one != lazy_three
    assert lazy_one != lazy_four
    assert lazy_one != 1



# Generated at 2022-06-12 05:17:11.430716
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    This test shows how to use Lazy method ap.
    """
    from pymonet.box import Box

    box_four = Box.of(2).ap(Box.of(lambda x: x * 2))
    lazy_four = Lazy.of(2).ap(Lazy.of(lambda x: x * 2))

    assert box_four == lazy_four


# Generated at 2022-06-12 05:17:19.269063
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right

    square = lambda value: value ** 2
    double = lambda value: value * 2
    square_of_double = lambda value: square(double(value))

    value = Lazy(lambda: square_of_double(4))
    value_of_4 = Lazy(lambda: 4)

    assert value.get() == 64
    assert value.ap(Lazy(square)).get() == 4096
    assert value.ap(Lazy(double)).get() == 256
    assert value.ap(value_of_4).get() == 64
    assert value.ap(Right(square_of_double)).get() == 64
    assert value.ap(Right(square)).get() == 4096
    assert value.ap(Right(double)).get() == 256


# Generated at 2022-06-12 05:17:23.535533
# Unit test for method get of class Lazy
def test_Lazy_get():
    def constructor_fn(x):
        return x + 10

    lazy = Lazy(constructor_fn)
    assert lazy.get(5) == 15
    assert lazy.is_evaluated
    assert lazy.value == 15



# Generated at 2022-06-12 05:17:26.550334
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 42).get() == 42
    assert Lazy(lambda: 42).get() == 42



# Generated at 2022-06-12 05:17:34.609958
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functionn import identity as return_self
    from pymonet.functionn import constant as return_1

    equals_to_self = return_self()
    always_1 = return_1(1)

    lazy1 = Lazy.of(1)
    lazy2 = Lazy.of(2)

    assert lazy1.map(equals_to_self) != lazy1
    assert lazy1.map(return_1(1)) == lazy1
    assert lazy1.map(equals_to_self) == lazy2.map(equals_to_self)

    assert lazy1.map(always_1) != lazy2
    assert lazy1.map(always_1) == lazy2.map(always_1)


# Generated at 2022-06-12 05:17:39.691843
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_one = Lazy.of(1)
    lazy_two = Lazy.of(2)
    lazy_one_copy = Lazy.of(1)

    assert lazy_one == lazy_one_copy
    assert lazy_one != lazy_two


# Generated at 2022-06-12 05:18:05.460160
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.list import List

    assert Lazy(lambda x: x).bind(List.pure) == Lazy(lambda x: List(x))
    assert Lazy(lambda x: x).bind(lambda x: List.pure(x)) == Lazy(lambda x: List(x))
    assert Lazy(lambda x: x).bind(lambda x: List.pure(x)).bind(lambda l: l.to_tuple()) == Lazy(lambda x: (x,))


# Generated at 2022-06-12 05:18:08.486573
# Unit test for method map of class Lazy
def test_Lazy_map():
    # given
    def add_one(num):
        return num + 1

    lazy = Lazy.of(10)

    # when
    lazy_map = lazy.map(add_one)

    # then
    assert lazy_map.get() == 11



# Generated at 2022-06-12 05:18:14.483750
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test returning value after applying function with bind method

    :returns: None
    :rtype: None
    """
    import pytest

    # Example of partial application (but without use of partial function)
    lazy_x = Lazy(lambda x: x)
    lazy_x2 = Lazy(lambda: 3)

    assert lazy_x.bind(lambda x: lazy_x2) == Lazy(lambda: lazy_x2.get())
    assert lazy_x.bind(lambda x: Lazy.of(x + 1)) == Lazy(lambda: lazy_x.get() + 1)

    def _empty_lazy() -> Lazy[int, str]:
        return Lazy(lambda: None)

    assert lazy_x.bind(_empty_lazy) == Lazy(lambda: None)


# Generated at 2022-06-12 05:18:16.004065
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Lazy.of(lambda x: x * 2).ap(Box.of(2)) == Lazy.of(4)



# Generated at 2022-06-12 05:18:25.760030
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(value):
        return Lazy.of(value)

    def throw_error():
        raise RuntimeError('test')

    def fn2(value):
        return Lazy.of(value)

    assert Lazy.of('test').bind(fn).constructor_fn() == 'test'
    assert Lazy.of('test').bind(fn).bind(fn2).constructor_fn() == 'test'
    assert Lazy.of('test').map(lambda v: 'test' + v).map(lambda v: v + 'test').constructor_fn() == 'testtesttest'

    assert Lazy.of('test').bind(throw_error).constructor_fn() == 'test'
    assert Lazy.of('test').bind(fn).map(lambda v: None).constructor_fn() is None


# Run

# Generated at 2022-06-12 05:18:34.744738
# Unit test for method get of class Lazy
def test_Lazy_get():

    def attempt_of_get_value_from_not_lazy_evaluated_instance():
        """
        Evaluate Lazy and memoize her output or return memoized value when function was evaluated.
        :returns: result of function in Lazy
        :rtype: A
        """

        def f(args):
            return args

        lazy = Lazy(f)
        assert lazy.is_evaluated is False
        assert lazy.value is None
        assert lazy.get('Lazy is cool!') == 'Lazy is cool!'

    attempt_of_get_value_from_not_lazy_evaluated_instance()

    def attempt_of_get_value_from_lazy_evaluated_instance():
        """
        Attempt to get value from lazy evaluated instance
        """

        def f(args):
            return args

       

# Generated at 2022-06-12 05:18:36.955731
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 'a').map(lambda i: i + '1').get() == 'a1'
    assert Lazy(lambda: 'b').map(lambda i: i + '2').get() == 'b2'



# Generated at 2022-06-12 05:18:48.439918
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right
    from pymonet.maybe import Just
    from pymonet.validation import Success

    lazy_result = Lazy.of(3)
    assert lazy_result.ap(Lazy.of(lambda x: x + 3)) == Lazy.of(6)

    lazy_result = Lazy.of(4)
    assert lazy_result.ap(Lazy.of(lambda x: x * 3)) == Lazy.of(12)

    lazy_result = Lazy.of(10)
    lazy_result = lazy_result.ap(Right(lambda x: x + 3))
    assert lazy_result.ap(Lazy.of(lambda x: x * 3)) == Lazy.of(39)

    lazy_result = Lazy.of(10)
    lazy_result = lazy_result

# Generated at 2022-06-12 05:18:57.429903
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(100).get() == 100
    assert Lazy.of(100).get(1, 2) == 100
    assert Lazy.of(100).map(lambda x: x + 1).get() == 101
    assert Lazy.of(100).map(lambda x: x + 1).get(1, 2, 3) == 101
    assert Lazy.of(100).map(lambda x: x + 1).map(lambda x: x + 10).get() == 111
    assert Lazy.of(100).map(lambda x: x + 1).map(lambda x: x + 10).get(1, 2, 3) == 111
    assert Lazy.of(100).map(lambda x: x + 1).map(lambda x: x + 10).map(
        lambda x: x + 100
    ).get() == 211


# Generated at 2022-06-12 05:18:59.186503
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)



# Generated at 2022-06-12 05:19:41.930948
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_option import Maybe
    from pymonet.monad_try import Try

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(lambda: 1)
    assert Lazy.of(1) != Maybe.just(1)
    assert Lazy.of(1) != Try.success(1)



# Generated at 2022-06-12 05:19:47.208609
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def func(x):
        return x + 1

    def func_multiply(x):
        return x * 2

    assert Lazy(func).ap(Lazy(func_multiply)).get(10) == 21



# Generated at 2022-06-12 05:19:54.763102
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of([1, 2, 3]).map(lambda x: x == [1, 2, 3]).get() is True
    assert Lazy.of([1, 2, 3]).get() == [1, 2, 3]
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).get() == 4
    assert Lazy.of([1, 2, 3]).ap(Lazy.of(lambda x: [0] + x)).get() == [0, 1, 2, 3]


# Generated at 2022-06-12 05:19:57.454044
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy(lambda: 1)

    assert not Lazy.of(1) == Lazy(lambda: 2)



# Generated at 2022-06-12 05:19:59.919581
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(None).get() is None


# Generated at 2022-06-12 05:20:06.314131
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazyA = Lazy(lambda x: x ** 2)

    assert lazyA.bind(
        lambda x: Lazy(lambda y: -x)
    ).get(5) == -25

    assert lazyA.bind(
        lambda x: Lazy(lambda y: y - x)
    ).get(5, 2) == -3

    assert lazyA.bind(
        lambda x: Lazy(lambda y: y - x)
    ).get(5, 2) == -3

    assert lazyA.bind(
        lambda x: Lazy(lambda: x ** 2)
    ).get() == 625

    assert lazyA.bind(
        lambda x: Lazy(lambda: -x)
    ).get() == -625



# Generated at 2022-06-12 05:20:10.939763
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x * 2).ap(Lazy.of(2)) == Lazy.of(4)
    assert Lazy.of(lambda x: x * 2).ap(Lazy.of(2)) != Lazy.of(2)

# Generated at 2022-06-12 05:20:18.048256
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def function_a(*args) -> int:
        pass

    def function_b(*args) -> str:
        pass

    lazy_a = Lazy(function_a)
    lazy_b = Lazy(function_b)
    lazy_c = Lazy(function_a)

    assert lazy_a != lazy_b
    assert lazy_a == lazy_c

    assert lazy_a != 5
    assert lazy_a != 5.0



# Generated at 2022-06-12 05:20:20.008937
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__(): # pragma: no cover
    assert not Lazy.of(1) == 1
    assert Lazy.of(1) == Lazy.of(1)

# Generated at 2022-06-12 05:20:23.182025
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(3) == Lazy(lambda: 3)
    assert Lazy.of(3) != Lazy(lambda: 4)
    assert Lazy.of(3) != 3
    assert not (Lazy(lambda: 3) == Lazy(lambda: '3'))

