

# Generated at 2022-06-12 05:11:09.673731
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def fn(x: int, y: int) -> int:
        return x + y

    def another_fn(x: int) -> Maybe[int]:
        return Maybe.just(x)

    box_fn = Box.of(fn)
    lazy_2 = Lazy.of(2)
    lazy_3 = Lazy.of(3)

    assert lazy_2.ap(box_fn).ap(lazy_3).get() == 5

# Generated at 2022-06-12 05:11:20.509800
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.validation import Validation

    class Just(Validation[int, str]):
        def __init__(self, value: int) -> None:
            super().__init__(value, [])

    def add_fn(val):  # pylint: disable=unused-argument
        return 1

    def add_fn_generator(value=None):  # pylint: disable=unused-argument
        yield lambda val: 1

    lazy1 = Lazy(lambda val: 1)
    lazy2 = Lazy.of(1)
    lazy3 = Lazy(add_fn)
    lazy4 = Lazy.of(1).bind(lambda val: Lazy(lambda _: 1))

# Generated at 2022-06-12 05:11:25.394574
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    Lazy.of(lambda x: x + 10).ap(Box.of(5)).to_box() == Box.of(15)
    Lazy.of(lambda x: x + 10).ap(Maybe.just(5)).to_maybe() == Maybe.just(15)

# Generated at 2022-06-12 05:11:31.277246
# Unit test for method get of class Lazy
def test_Lazy_get():
    def foo():
        return 1 + 2

    lazy = Lazy(foo)
    assert lazy.get() == 3
    assert lazy.is_evaluated is True
    assert lazy.value == 3
    assert lazy.get() == 3
    assert lazy.get() == 3
    assert lazy.get() == 3



# Generated at 2022-06-12 05:11:37.205193
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    And example of how to use Lazy monad
    """
    def add_2(value):
        return value + 2

    def add_3(value):
        return value + 3

    assert Lazy.of(3) == Lazy.of(3)
    assert Lazy.of(3).map(add_2) == Lazy.of(3).map(add_2)
    assert Lazy.of(3).map(add_2) != Lazy.of(4).map(add_2)
    assert Lazy.of(3).map(add_2) != Lazy.of(3).map(add_3)
    assert Lazy.of(3).map(add_2) != Lazy.of(3)

# Generated at 2022-06-12 05:11:50.362762
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_value(b):
        def lambda_fn(a):
            return add(a, b)
        return lambda_fn

    def square(a):
        return a * a

    def square_value(b):
        def lambda_fn(a):
            return square(a)
        return lambda_fn

    result1 = Lazy.of(2).ap(Lazy.of(add_value(1)))
    assert result1.get() == add(2, 1)

    result2 = Lazy.of(2).ap

# Generated at 2022-06-12 05:11:59.497155
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right

    # Call ap on None
    lazy_1 = Lazy.of(10).map(lambda x: x + 10).ap(None)
    assert lazy_1 == Lazy.of(10)

    # Call ap on Box
    lazy_2 = Lazy.of(10).map(lambda x: x + 10).ap(Box(lambda x: x + 5))
    assert Box(lambda x: x + 10) == lazy_2.to_box()

    # Call ap on Either

    # should evaluate Lazy to get inside value
    lazy_3 = Lazy.of(10).map(lambda x: x + 10).ap(Right(lambda x: x + 5))
    assert lazy_3.get() == Right(15).get()

    # should not

# Generated at 2022-06-12 05:12:02.956206
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = lambda *args: args[0] if args else 1
    assert Lazy(f) == Lazy(f)
    assert Lazy(f) == Lazy(f)
    assert Lazy(f) == Lazy(f)

# Generated at 2022-06-12 05:12:08.071315
# Unit test for method map of class Lazy
def test_Lazy_map():  # type: () -> None
    def get_num():
        return 3

    lazy = Lazy(get_num)
    mapped_lazy = lazy.map(lambda x: 2 * x)
    assert mapped_lazy.get() == 6


# Generated at 2022-06-12 05:12:13.462812
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def _not_empty(x):
        assert isinstance(x, Lazy)

        return x != Lazy(lambda: None)

    def _empty(x):
        assert isinstance(x, Lazy)

        return x == Lazy(lambda: None)

    assert _not_empty(Lazy.of("value"))
    assert _empty(Lazy.of(None))

# Generated at 2022-06-12 05:12:21.085205
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def x():
        return 1

    def y():
        return Box(2)

    lazy = Lazy(x)
    assert lazy.bind(y) == Lazy.of(Box(2))


# Generated at 2022-06-12 05:12:25.206203
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # given
    print("Given method_name: test_Lazy___eq__")
    # when
    actual_result = Lazy(lambda: "Lazy").__eq__(Lazy(lambda: "Lazy"))
    # then
    expected_result = True
    assert expected_result == actual_result, "Expected: {} | Actual: {}".format(expected_result, actual_result)


# Generated at 2022-06-12 05:12:36.318557
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def construct_number(number):
        return Lazy(lambda x: number)
    assert construct_number(1).get(1) == 1
    assert construct_number(2).bind(construct_number).get(1) == 2
    assert construct_number(2).bind(construct_number).bind(construct_number).get(1) == 2
    assert construct_number(2).bind(construct_number).bind(construct_number).bind(construct_number).get(1) == 2
    assert construct_number(2).bind(construct_number).bind(construct_number).bind(construct_number).bind(
        construct_number).get(1) == 2

# Generated at 2022-06-12 05:12:44.420195
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    import pytest

    assert Lazy(lambda: 'a') == Lazy(lambda: 'a')
    assert Lazy(lambda: 'c') != Lazy(lambda: 'a')
    assert Lazy(lambda: 'a') != Lazy(lambda: 'a').ap(Lazy(lambda: lambda x: x))
    assert Lazy(lambda: 'a') != Lazy(lambda: 'a').map(lambda x: x)
    assert Lazy(lambda: 'a') != Lazy(lambda: 'a').bind(lambda x: Lazy(lambda: x))
    assert Lazy(lambda: 'a') != Lazy(lambda: 'a').bind(lambda x: Lazy(lambda: x)).map(lambda x: x)

# Generated at 2022-06-12 05:12:50.873812
# Unit test for method get of class Lazy
def test_Lazy_get():
    def mocked_function(x):
        mocked_function.call_count += 1
        return x

    mocked_function.call_count = 0
    lazy = Lazy(mocked_function)
    assert mocked_function.call_count == 0
    assert lazy.get(4) == 4
    assert lazy.get(4) == lazy.get(4) # Monad property
    assert mocked_function.call_count == 1


# Generated at 2022-06-12 05:12:55.665096
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda x: x).get(1) == 1
    assert Lazy(lambda x, y, z: print('{}-{}-{}'.format(x, y, z))).get(1, 2, 3) is None


# Generated at 2022-06-12 05:13:00.028110
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.box import Box

    assert Box(3) == Lazy.of(3).to_box()
    assert Box('value') == Lazy.of('value').to_box()
    assert Box(None) == Lazy.of(None).to_box()



# Generated at 2022-06-12 05:13:10.803702
# Unit test for method get of class Lazy
def test_Lazy_get():
    # pylint: disable=W0612, W0613
    assert Lazy(lambda x: x * 2).get(2) == 4
    assert Lazy(lambda x: x + 1).get(-1) == 0
    assert Lazy(lambda x: x * 2).map(lambda x: x + 1).get(3) == 7
    assert Lazy(lambda x: x - 2).map(lambda x: x - 3).get(99) == 94
    assert Lazy(lambda x, y: x * y).map(lambda x: x + 1).get(3, 5) == 16
    assert Lazy(lambda x, y: x * y).map(lambda x: x - 3).get(-2, 3) == -1

# Generated at 2022-06-12 05:13:19.230666
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test operator == for Lazy.

    Two Lazy are equals where both are evaluated both have the same value and constructor functions.
    """
    assert Lazy.of(10) != Lazy.of(10)
    assert Lazy.of(10) == Lazy.of(10)
    assert Lazy.of(10)(1) == Lazy.of(10)(1)
    assert Lazy.of(10)(1) != Lazy.of(20)(1)
    assert Lazy.of(10)(1) != Lazy.of(10)(2)



# Generated at 2022-06-12 05:13:23.182787
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add_1(x: int) -> int:
        return x + 1

    lazy = Lazy(add_1)
    assert lazy.get(2) == 3
    assert lazy.get(2) == 3


# Generated at 2022-06-12 05:13:27.277745
# Unit test for method get of class Lazy
def test_Lazy_get():
    expected_value = 1
    lazy = Lazy(lambda: expected_value)

    assert lazy.get() is expected_value

# Generated at 2022-06-12 05:13:39.594975
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def no_op(*args):
        pass

    def first_arg(first):
        return first

    def no_op_function_lazy():
        return Lazy(no_op)

    class NoOpClass:
        pass

    no_op_class = NoOpClass()

    assert Lazy(no_op) == Lazy(no_op)
    assert no_op_function_lazy() == no_op_function_lazy()

    assert Lazy(first_arg) != Lazy(no_op)
    assert Lazy.of(1) != Lazy.of(2)

    assert Lazy.of(1) != no_op_class
    assert Lazy.of(2) != None
    assert Lazy.of(2) != 123
    assert Lazy.of(2) != 'string'


# Generated at 2022-06-12 05:13:45.752317
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.monad import Monad

    def get_one():
        return 1

    lazy = Lazy(get_one)

    assert isinstance(lazy, Monad)
    assert lazy.is_evaluated is False
    assert lazy.value is None

    assert lazy.get() == 1

    assert lazy.is_evaluated is True
    assert lazy.value == 1


# Generated at 2022-06-12 05:13:47.846353
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    x = Lazy(lambda: 5)

    def fn(x):
        return x + 5

    assert x.bind(lambda x: Lazy.of(fn(x))).get() == x.map(fn).get()

# Generated at 2022-06-12 05:13:53.923025
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert (
        Lazy(lambda x: x).bind(lambda x: Lazy(lambda: x + 1))
        == Lazy(lambda x: x + 1)
    )
    assert (
        Lazy(lambda x: x).bind(lambda x: Lazy(lambda: x + 1)).bind(lambda x: Lazy(lambda: x + 1))
        == Lazy(lambda x: x + 2)
    )


# Generated at 2022-06-12 05:14:03.254888
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(0).get() == 0
    assert Lazy.of(0).map(lambda x: x + 1).get() == 1
    assert Lazy.of(0).map(lambda x: x - 1).get() == -1
    assert Lazy.of(0).map(lambda x: x + 1).map(lambda x: x - 3).get() == -2
    assert Lazy.of('a').bind(lambda x: Lazy.of(str(x) + 'b')).get() == 'ab'


# Generated at 2022-06-12 05:14:11.703490
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy(lambda n: n + n).bind(lambda n: Lazy(lambda: n + n))
    assert lazy.get(1) == 4
    assert lazy.is_evaluated is True
    assert lazy.value == 4

    lazy = Lazy(lambda n: n + n).bind(lambda n: Lazy(lambda: n + n)).bind(lambda n: Lazy(lambda: n + n))
    assert lazy.get(1) == 8
    assert lazy.is_evaluated is True
    assert lazy.value == 8



# Generated at 2022-06-12 05:14:21.943236
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    class Tests:
        def test_1(self):
            def fn(x: int) -> int:
                return x + 1

            assert Lazy(fn).bind(lambda x: Lazy(lambda: x + 1)).get() == 2

        def test_2(self):
            def fn(x: int) -> int:
                return x + 1

            assert Lazy(fn).bind(lambda x: Lazy(lambda: x + 1)).bind(lambda x: Lazy(lambda: x + 1)).get() == 3

        def test_3(self):
            def fn(x: int) -> int:
                return x + 1


# Generated at 2022-06-12 05:14:26.928005
# Unit test for method map of class Lazy
def test_Lazy_map():
    def increment(number: int) -> int:
        return number + 1

    def double(number: int) -> int:
        return number * 2

    assert Lazy.of(3).map(increment).get() == 4
    assert Lazy.of(3).map(increment).map(double).get() == 8



# Generated at 2022-06-12 05:14:29.221591
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(3).get(3) == 3


# Generated at 2022-06-12 05:14:34.822076
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy: Lazy[int, int] = Lazy.of(1)
    assert lazy.get(1) == 1
    assert lazy.is_evaluated is True
    assert lazy.value == 1



# Generated at 2022-06-12 05:14:39.171596
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def constructor_fn(value):
        return value + 1

    lazy = Lazy(constructor_fn)
    assert not lazy == Lazy(constructor_fn)
    assert lazy == lazy



# Generated at 2022-06-12 05:14:46.932818
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def lazy_value_fn():
        return 5

    lazy_value_fn_with_mapper = Lazy(lazy_value_fn).map(lambda x: x * 5)

    assert lazy_value_fn_with_mapper.get() == 25
    assert lazy_value_fn_with_mapper.to_box().get() == Box(25).get()
    assert lazy_value_fn_with_mapper.to_maybe().get() == Maybe(25).get()

    lazy_value_fn_with_mapper_and_box = lazy_value_fn_with_mapper.map(Box)

    assert isinstance(lazy_value_fn_with_mapper_and_box.constructor_fn(), Box)




# Generated at 2022-06-12 05:14:52.520561
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for method get of class Lazy
    """
    assert Lazy.of("foo").get() == "foo"
    assert Lazy.of("foo").get("bar") == "foo"

    def fn_a() -> str:
        return "foo"

    assert Lazy(lambda: fn_a()).get() == "foo"


# Generated at 2022-06-12 05:14:57.016826
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(0).bind(lambda value: Lazy.of(value + 2)).get() == 2
    assert Lazy.of(2).bind(lambda value: Lazy.of(value + 2)).get() == 4

# Generated at 2022-06-12 05:14:59.903841
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.functions import identity

    assert Lazy.of(5).get() == 5
    assert Lazy(lambda x: identity(x) + 5).get(5) == 10



# Generated at 2022-06-12 05:15:05.836063
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda e: e).__eq__(Lazy(lambda e: e))
    assert Lazy(lambda e: e).__eq__(Lazy(lambda e: e).get())
    assert not Lazy(lambda e: e).__eq__(Lazy(lambda e: 'b'))


# Generated at 2022-06-12 05:15:10.726636
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    fn = lambda x: x + 5
    fn2 = lambda x: x + 7

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(fn2)

    assert lazy1 == lazy2
    assert lazy1 != lazy3
    assert lazy2 != lazy3



# Generated at 2022-06-12 05:15:20.756904
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x) == Lazy(lambda x: x)
    assert Lazy(lambda x: x) != Lazy(lambda x: '')
    assert Lazy(lambda x: x) != Lazy(lambda x: '1')
    assert Lazy(lambda x: x) != Lazy(lambda x: 1)
    assert Lazy(lambda x: '1') == Lazy(lambda x: 1)
    assert Lazy(lambda x: x) != Lazy(lambda x, y: x)
    assert Lazy(lambda x, y: x) != Lazy(lambda x, y, z: x)
    assert Lazy(lambda x: x).map(lambda x: x) == Lazy(lambda x: x).map(lambda x: x)

# Generated at 2022-06-12 05:15:22.580307
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 5).map(lambda x: x + 1).get() == 6



# Generated at 2022-06-12 05:15:30.575140
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(x):
        return Lazy(lambda: x)

    assert f(1) == f(1)
    assert f(1) != f(2)
    assert f(1) != f(1.1)

# Generated at 2022-06-12 05:15:32.640094
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(4).map(lambda x: x + 3) == Lazy.of(7)



# Generated at 2022-06-12 05:15:34.773516
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda *args: 2).map(lambda x: x ** 2).get() == 4


# Generated at 2022-06-12 05:15:41.435122
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(33).bind(lambda i: Lazy.of(i * 2)).get() == 66
    assert Lazy.of(33).bind(lambda i: Lazy.of(i * 2)).map(lambda i: i / 2).get() == 33
    assert Lazy.of(33).bind(lambda i: Lazy.of(i * 2)).map(lambda i: i / 2).map(lambda i: i * 2).get() == 66

# Generated at 2022-06-12 05:15:46.070528
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def first_function(arg):
        return arg

    def second_function(arg):
        return arg

    assert Lazy(first_function) == Lazy(first_function)
    assert not Lazy(first_function) == Lazy(second_function)



# Generated at 2022-06-12 05:15:52.317705
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    class TestClass:
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return isinstance(other, TestClass) and self.value == other.value

    test_value = TestClass(1)
    lazy_value = Lazy.of(test_value)

    assert lazy_value == lazy_value
    assert lazy_value == Lazy.of(test_value)
    assert lazy_value != Lazy.of(TestClass(2))
    assert lazy_value != 1


# Generated at 2022-06-12 05:15:58.750981
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """Unit test for method bind of class Lazy"""
    import pytest
    from pymonet.monad_try import Try

    def func(x) -> Try:  # pragma: no cover
        return Try.of(lambda: x)

    def func_2(x) -> Try:  # pragma: no cover
        return Try.of(lambda: x + 1)

    assert Lazy.of(1).bind(func).bind(func_2).get() == 2

# Generated at 2022-06-12 05:16:08.501477
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from functools import reduce

    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    def sum_all(xs):
        return reduce(lambda x, y: x + y, xs)

    assert Lazy.of(5) == Lazy.of(5)
    assert Lazy.of(5).map(add) == Lazy.of(5).map(add)
    assert Lazy.of(5).map(add).map(mul) == Lazy.of(5).map(add).map(mul)

# Generated at 2022-06-12 05:16:17.835637
# Unit test for method map of class Lazy
def test_Lazy_map():
    inner_fn_called = False

    def inner_fn(x):
        nonlocal inner_fn_called
        inner_fn_called = True

        return x

    lazy_fn_called = False

    def lazy_fn():
        nonlocal lazy_fn_called
        lazy_fn_called = True
        return inner_fn('test')

    lazy = Lazy(lazy_fn)
    lazy2 = lazy.map(lambda x: x)

    assert lazy_fn_called is False
    assert inner_fn_called is False
    assert lazy2._compute_value() == 'test'
    assert lazy_fn_called is True
    assert inner_fn_called is True
    assert lazy is not lazy2



# Generated at 2022-06-12 05:16:25.575183
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def f():
        return 1

    def g():
        return 2

    lazy_1 = Lazy(f)
    lazy_2 = Lazy(f)
    lazy_3 = Lazy(g)
    lazy_4 = Lazy(f)
    lazy_4._compute_value()

    assert lazy_1 != lazy_2
    assert lazy_2 != lazy_3
    assert lazy_1 != lazy_3
    assert lazy_1 != lazy_4
    assert lazy_2 == lazy_4
    assert lazy_2 != lazy_3



# Generated at 2022-06-12 05:16:42.251736
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Unit test for method map of class Lazy

    :return: nothing
    :rtype: None
    """
    # given
    def fn1(x):
        return x * 2

    lazy = Lazy(fn1)

    # when
    lazy_result = lazy.map(lambda x: x * 3).get(3)

    # then
    assert lazy_result == 18
    assert lazy.is_evaluated is True
    assert lazy.constructor_fn(3) == 6

# Generated at 2022-06-12 05:16:51.346476
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover

    a = Lazy.of(1)
    b = Lazy.of(2)

    assert a != b
    assert Lazy.of(1).map(lambda x: x * 2) != Lazy.of(2).map(lambda x: x * 2)
    assert Lazy.of(1).map(lambda x: x * 2) == Lazy.of(1).map(lambda x: x * 2)
    assert Lazy.of(2).map(lambda x: x * 2) == Lazy.of(2).map(lambda x: x * 2)


# Generated at 2022-06-12 05:16:56.894356
# Unit test for method get of class Lazy
def test_Lazy_get():
    f = lambda x: x ** 2
    lazy = Lazy(f)

    assert lazy.get(2) == f(2)
    assert lazy.get(2) == f(2)
    assert lazy.get(5) == f(5)
    assert lazy.get(5) == f(5)


# Generated at 2022-06-12 05:17:05.746453
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add1(x):
        return x + 1

    def add2(x):
        return x + 2

    def add3(x):
        return x + 3

    def add4(x):
        return x + 4

    assert (Lazy.of(add4)
            .ap(Lazy.of(add1)
                .ap(Lazy.of(add2)
                    .ap(Lazy.of(add3)
                        .ap(Lazy.of(1)))))) == Lazy.of(11)

    assert (Lazy.of(add4)
            .ap(Lazy.of(add1))) == Lazy.of(add1)

    assert (Lazy.of(add4)) == Lazy.of(add4)


# Generated at 2022-06-12 05:17:10.338456
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    fn_called = False

    def fn(x):
        nonlocal fn_called
        fn_called = True
        return x

    lazy = Lazy(lambda: 1)
    lazy = lazy.bind(fn)

    assert lazy.constructor_fn(None) == 1
    assert fn_called

# Generated at 2022-06-12 05:17:17.059083
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try

    fn_pass = lambda: 1
    lazy_1 = Lazy(fn_pass)
    lazy_2 = Lazy(fn_pass)

    def fn_with_lazy_arg(lazy):
        def fn_with_arg(value):
            return Lazy.of(lazy.get() + value)

        return lazy.bind(fn_with_arg)

    assert lazy_1.bind(fn_with_lazy_arg).get(lazy_2) == 2

# Generated at 2022-06-12 05:17:25.203537
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def fn(x):
        return x * 2

    def mapper(x):
        return x * 2

    a = Lazy.of(1)
    assert a.map(fn).map(mapper).get() == fn(mapper(1))

    b = Lazy(fn)
    assert b.map(mapper).get(5) == fn(mapper(5))



# Generated at 2022-06-12 05:17:32.509621
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Maybe

    def add1(x):
        return x + 1

    lazy = Lazy(add1)
    assert lazy.map(add1).constructor_fn(2) == 4
    assert Lazy.of(3).map(add1).constructor_fn(3) == 4
    assert Lazy.of(Maybe.just(3)).map(add1).constructor_fn().get_or_else(None) == 4
    assert Lazy.of(Maybe.nothing()).map(add1).constructor_fn().get_or_else(None) is None
    assert Lazy.of(3).map(lambda x: x + 3).constructor_fn(3) == 6


# Generated at 2022-06-12 05:17:35.461402
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def get_sum(a):
        return Lazy.of(a + 3)

    lazy = Lazy.of(3).bind(get_sum)
    assert lazy.get() == 6



# Generated at 2022-06-12 05:17:47.388311
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    class Value:
        def __init__(self, value):
            self.value = value

    def get_value(value):
        return value.value

    def get_lazy_value(lazy_value):
        return Lazy.of(Value(lazy_value))

    lazy_value = Lazy.of(1)

    assert lazy_value.bind(get_lazy_value) == Lazy.of(Value(1))

    assert lazy_value.bind(get_lazy_value).bind(get_value) == Lazy.of(1)

    assert lazy_value.bind

# Generated at 2022-06-12 05:18:12.824936
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def _test_lazy_ap(fn, expected_value):
        _test_lazy_ap.counter += 1
        print('Test {}: Lazy ap({}) == {}'.format(_test_lazy_ap.counter, fn, expected_value))

        actual_value = Lazy.of(1).ap(fn).get()
        assert actual_value == expected_value

    _test_lazy_ap.counter = 0

    test_lazy_ap = partial(_test_lazy_ap, Lazy.of(lambda x: x + 1))
    test_lazy_ap(2)
    test_lazy_ap(0)
    test_lazy_ap(-10)



# Generated at 2022-06-12 05:18:19.479799
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # pylint: disable-msg=unused-argument
    def f(x: int) -> Lazy[int, int]:
        return Lazy(lambda *args: x * 3)

    assert Lazy(lambda *args: 4).bind(f) == Lazy(lambda *args: 12)

    def g(x: int) -> Lazy[int, str]:
        return Lazy(lambda *args: str(x * 4))

    assert Lazy(lambda *args: 7).bind(f).bind(g) == Lazy(lambda *args: '84')



# Generated at 2022-06-12 05:18:24.591354
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def double(value):
        return value * 2

    def add(value1, value2):
        return value1 + value2

    lazy = Lazy(lambda: 5)
    result = lazy.bind(lambda x: Lazy(lambda: double(x))).bind(lambda x: Lazy(lambda: add(x, x)))

    assert result.get() == 20

# Generated at 2022-06-12 05:18:33.902035
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x) == Lazy(lambda x: x)
    assert Lazy(lambda x: x) != Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x) != 'any'
    assert Lazy(lambda x: x) != Lazy(lambda x: x)._compute_value(1)
    assert Lazy(lambda x: x) == Lazy(lambda x: x)._compute_value(1)
    assert Lazy(lambda x: x)._compute_value(1) == Lazy(lambda x: x)._compute_value(1)
    assert Lazy(lambda x: x) != Lazy(lambda x: x)._compute_value(1)

# Generated at 2022-06-12 05:18:36.096786
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    lazy = Lazy(lambda: 'Hello ').bind(lambda x: Lazy(lambda: x + 'pymonet'))
    assert lazy.get() == 'Hello pymonet'

# Generated at 2022-06-12 05:18:46.782678
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.validation import Validation

    def fn_1(*args):
        return Validation.success(args)

    def fn_2(*args):
        return Validation.success(args)

    def fn_3(*args):
        return Validation.success(args)

    def fn_4(*args):
        return Validation.success(args)

    assert Lazy(fn_1).map(lambda v: v).__eq__(Lazy(fn_2).map(lambda v: v))
    assert not Lazy(fn_1).map(lambda v: v + 1).__eq__(Lazy(fn_3).map(lambda v: v + 2))

# Generated at 2022-06-12 05:18:56.852955
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.utils import make_eq_test_class
    from pymonet.lazy import Lazy
    from pymonet.something import Something
    from nose.tools import assert_false

    class TestClass:
        pass

    test_class1 = TestClass()
    test_class2 = TestClass()

    assert_false(Lazy(lambda: 1) == Lazy(lambda: 2))
    assert_false(Lazy(lambda: 1) == Lazy(lambda: 1.0))
    assert_false(Lazy(lambda: test_class1) == Lazy(lambda: test_class2))
    assert_false(Lazy(lambda: 1) == 1)
    assert_false(Lazy(lambda: 1) == Lazy(lambda: Something.empty()))


# Generated at 2022-06-12 05:19:02.512384
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    print('Unit test for method __eq__ of class Lazy')
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(2) != Lazy.of(1)

    def fn():
        return 'x'

    assert Lazy(fn) == Lazy(fn)
    print('OK')


# Generated at 2022-06-12 05:19:05.493523
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x + 1).map(lambda x: x * 10).get(1) == 20


# Generated at 2022-06-12 05:19:11.012471
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    container = Lazy(lambda: 2)
    def mapper(arg):  # pylint: disable=unused-argument
        """Mapper for Lazy"""
        return Lazy.of(2)

    assert container.bind(mapper).get() == 2


# Generated at 2022-06-12 05:19:54.354995
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    def add_one(a):
        return a + 1

    def multiply_by_two(a):
        return a * 2

    # positive cases
    assert Lazy.of(add_one).ap(Lazy.of(2)) == Lazy.of(3)
    assert Lazy.of(multiply_by_two).ap(Lazy.of(2)) == Lazy.of(4)

    # negative cases



# Generated at 2022-06-12 05:20:01.146231
# Unit test for method get of class Lazy
def test_Lazy_get(): #pragma: no cover

    assert Lazy.of(2).get() == 2
    assert Lazy.of(2).map(lambda x: x + 1).get() == 3
    assert Lazy.of(2).map(lambda x: x + 1).map(lambda x: x * 2).get() == 6
    assert Lazy.of(2).map(lambda x: x + 1).map(lambda x: x * 2).get() == 6


# Generated at 2022-06-12 05:20:07.152606
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add10(v):
        return v + 10

    def multiply10(v):
        return v * 10

    def minus10(v):
        return v - 10

    assert Lazy(lambda: 10).map(add10).get() == add10(10)
    assert Lazy(lambda: 10).map(multiply10).get() == multiply10(10)
    assert Lazy(lambda: 10).map(add10).map(multiply10).get() == multiply10(add10(10))
    assert Lazy(lambda: 10).map(multiply10).map(add10).get() == add10(multiply10(10))

# Generated at 2022-06-12 05:20:10.196333
# Unit test for method get of class Lazy
def test_Lazy_get():
    function = lambda x: x * 2
    arg = 5

    assert Lazy(function).get(arg) == arg * 2



# Generated at 2022-06-12 05:20:13.336351
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    a = Lazy(lambda: 1)
    b = a.bind(lambda x: Lazy(lambda: x + 1))

    assert b == Lazy.of(2)



# Generated at 2022-06-12 05:20:19.014277
# Unit test for method map of class Lazy
def test_Lazy_map():
    result = Lazy.of(3).map(lambda x: x ** 2)
    assert result.get() == 9
    assert result.is_evaluated

    result = Lazy.of(20).map(lambda x: x + 30)
    assert not result.is_evaluated
    assert result.get() == 50
    assert result.is_evaluated



# Generated at 2022-06-12 05:20:26.343762
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.trampoline import Trampoline
    from pymonet.maybe import Maybe

    def test_fn(value):
        return Box(value + 1)

    lazy = Lazy.of(5)
    assert type(lazy.ap(Box(1))).__name__ == 'Lazy'
    assert lazy.ap(Box(1)).get() == 2
    assert lazy.ap(Box(1)).get() == 2
    assert type(lazy.ap(Box(test_fn))) == Lazy
    assert lazy.ap(Box(test_fn)).get() == 6

    assert lazy.ap(Maybe.just(1)).get() == 2
    assert lazy.ap(Maybe.just(test_fn)).get() == 6


# Generated at 2022-06-12 05:20:29.679625
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert(Lazy(lambda *args: 1).bind(fn).get() == 2)

# Generated at 2022-06-12 05:20:37.962012
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    from pymonet.lazy import Lazy

    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(2)

    # fold function returns function as result
    def f(x: int) -> int:
        return x + 1

    result_fn = Lazy.of(f).get()

    assert Lazy.of(f) == Lazy.of(result_fn)

    # fold function returns data type as result
    def f(x: int) -> Validation[int, str]:
        return Validation.success(x + 1)

    result_validation

# Generated at 2022-06-12 05:20:40.804724
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy.of(2 + 2)
    assert lazy.get() == 4
