

# Generated at 2022-06-25 23:40:26.802599
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = '2c&DFhTT3 O\r]F1 '

    def lambda_0(str_1):
        return str_1 + ''.join(str_1.split())

    def lambda_1(str_1):
        return str_1 + ''.join(str_1.split())

    lazy_0 = Lazy(lambda_0)

    lazy_1 = lazy_0.bind(lambda_1)
    assert lazy_1.get(str_0) == str_0 + ''.join(str_0.split())


# Generated at 2022-06-25 23:40:31.581828
# Unit test for method get of class Lazy
def test_Lazy_get():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    assert str_0 == lazy_0.get()
    assert not lazy_0.is_evaluated


# Generated at 2022-06-25 23:40:38.991097
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    def lambda_0(arg_0: str) -> Lazy[str, str]:
        def lambda_1(str_0: str) -> str:
            return str_0
        return Lazy(lambda_1)
    lazy_1 = lazy_0.bind(lambda_0)
    str_1 = 'ччч'
    lazy_2 = Lazy(str_1)
    bool_0 = lazy_1 == lazy_2


# Generated at 2022-06-25 23:40:45.450170
# Unit test for method get of class Lazy
def test_Lazy_get():
    str_0 = '7pOI^=;Vz9XEYt!O'
    lazy_0 = Lazy(str_0)
    lazy_0.is_evaluated = False
    lazy_0.value = 'mFoLj@';
    var_0 = lazy_0.get()
    assert var_0 == '7pOI^=;Vz9XEYt!O'


# Generated at 2022-06-25 23:40:47.743355
# Unit test for method get of class Lazy
def test_Lazy_get():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)

    assert str_0 == lazy_0.get()


# Generated at 2022-06-25 23:40:58.836272
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_Lazy___eq__0():
        str_0 = '2c&DFhTT3 O\r]F1 '
        str_1 = '2c&DFhTT3 O\r]F1 '
        lazy_0 = Lazy(str_0.strip)
        lazy_1 = Lazy(str_1.strip)
        assert lazy_0 == lazy_1

    def test_Lazy___eq__1():
        str_0 = '2c&DFhTT3 O\r]F1 '
        str_1 = '2c&DFhTT3 O\r]F1 '
        lazy_0 = Lazy(str_0.strip)
        lazy_1 = Lazy(str_1.strip)
        lazy_0.get()
        lazy_1.get()
        assert lazy_0

# Generated at 2022-06-25 23:41:03.610925
# Unit test for method get of class Lazy
def test_Lazy_get():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy.of(str_0)

    t = lazy_0.get()

    assert t == str_0

    def my_function(str):
        return str + ' test'

    lazy_1 = lazy_0.bind(my_function)

    assert lazy_1.get() == str_0 + ' test'



# Generated at 2022-06-25 23:41:06.819242
# Unit test for method get of class Lazy
def test_Lazy_get():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy.of(str_0)
    str_1 = lazy_0.get()
    assert str_0 == str_1


# Generated at 2022-06-25 23:41:14.036228
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.either import Right
    def func_0(arg_0):
        return arg_0 + 100
    def func_1(arg_0):
        return func_0(arg_0)
    val_0 = '2c&DFhTT3 O\r]F1 '

# Generated at 2022-06-25 23:41:20.694858
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def str_0(str_1):
        def str_2(str_3):
            return str_1 + str_3
        return str_2

    def str_4(str_5):
        return str_5[1:] + str_5[:1]

    lazy_0 = Lazy.of(str_4)
    lazy_1 = lazy_0.ap(Lazy.of(str_0))
    str_6 = 'AbCdEf'
    assert(lazy_1.get(str_6) == 'bCdEfa')


# Generated at 2022-06-25 23:41:25.837585
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    pass
    # stub


lazy_0 = Lazy(test_case_0)


# Generated at 2022-06-25 23:41:34.567599
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    str_0 = 'AbCdEf'
    str_1 = 'AbCdEf'
    bool_0 = str_0 != str_1
    bool_1 = str_0 == str_1
    bool_2 = str_0 != str_1
    bool_3 = str_0 == str_1
    bool_4 = str_0 != str_1
    bool_5 = str_0 == str_1
    bool_6 = str_0 != str_1
    bool_7 = str_0 == str_1
    bool_8 = str_0 != str_1
    bool_9 = str_0 == str_1
    bool_10 = str_0 != str_1
    bool_11 = str_0 == str_1
    bool_12 = str_0 != str_1
    bool_13

# Generated at 2022-06-25 23:41:36.940398
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    l1 = Lazy(lambda: 'AbCdEf')
    l2 = Lazy(lambda: 'AbCdEf')
    assert l1 == l2


# Generated at 2022-06-25 23:41:43.865130
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Arrange
    def to_lowercase(str_0: str) -> Lazy:
        return Lazy.of(str_0.lower())

    def add_samboosa_to(str_0: str) -> Lazy:
        return Lazy.of(str_0 + 'samboosa')

    str_0 = 'AbCdEf'

    # Act
    actual = Lazy.of(str_0).bind(to_lowercase).bind(add_samboosa_to).get()

    # Assert
    expected = 'abcdefsamboosa'
    assert actual == expected


# Generated at 2022-06-25 23:41:51.821121
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_1 = 'AbCdEf'
    list_1 = ['Ab', 'Cd', 'Ef']
    list_of_str_in_lazy_1 = Lazy(lambda : str_1).map(lambda el: list(el)).bind(lambda el: Lazy(lambda : [el[i:i + 2] for i in range(0, len(el), 2)]))

    if list_of_str_in_lazy_1.get() != list_1:
        raise AssertionError()

    str_2 = 'Abcdefg'

# Generated at 2022-06-25 23:41:57.281318
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = 'AbCdEf'
    fn_0 = lambda x: x.upper()
    fn_1 = lambda x: x[1:3]
    lazy_0 = Lazy(lambda: str_0)
    lazy_1 = lazy_0.bind(lambda x: Lazy(lambda: fn_0(x))).bind(lambda x: Lazy(lambda: fn_1(x)))
    assert lazy_1.get() == 'BC'


# Generated at 2022-06-25 23:42:07.036622
# Unit test for method map of class Lazy
def test_Lazy_map():

    lazy = Lazy(lambda str_0: str_0.upper())
    assert lazy.map(lambda str_1: str_1[::-1]) == Lazy(lambda str_2: str_2.upper()[::-1])
    assert lazy.map(lambda str_3: str_3[0]) == Lazy(lambda str_4: str_4.upper()[0])
    assert lazy.map(lambda str_5: str_5[2:4]) == Lazy(lambda str_6: str_6.upper()[2:4])


# Generated at 2022-06-25 23:42:18.587729
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    class TestCase:
        def __init__(self, value, success, result_type, expected_result):
            self.value = value
            self.success = success
            self.result_type = result_type
            self.expected_result = expected_result

    def capitalize(input_str):
        return input_str[0].upper() + input_str[1:]

    def capitalize_with_lazy_input(lazy_str):
        return Lazy.of(lazy_str.get()).map(capitalize)


# Generated at 2022-06-25 23:42:22.815846
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(5) == Lazy.of(5), 'die'
    assert str(Lazy.of(5)) == 'Lazy[fn=<function <lambda> at 0x000001FFE1A8C288>, value=None, is_evaluated=False]', 'die'


# Generated at 2022-06-25 23:42:26.338343
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != str



# Generated at 2022-06-25 23:42:34.552880
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    str_1 = '2c&DFhTT3 O\r]F1 '
    str_2 = '2c&DFhTT3 O\r]F1 '

    lazy_1 = Lazy(str_1)
    lazy_2 = Lazy(str_2)
    lazy_3 = Lazy(str_2)
    lazy_4 = Lazy(str)

    assert lazy_1 == lazy_2
    assert lazy_2 == lazy_3
    assert lazy_3 == lazy_4



# Generated at 2022-06-25 23:42:38.762161
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    str_0 = 'X'
    str_1 = 'e'
    function_0 = Lazy.of(str_0)
    function_1 = Lazy.of(str_1)
    function_1_ap_function_0_result = function_1.ap(function_0)
    assert function_1_ap_function_0_result.get() == str_0


# Generated at 2022-06-25 23:42:42.798318
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    def the0(str_0):
        return Lazy(str_0)
    str_1 = lazy_0.bind(the0)
    assert(str_1 == Lazy(str_0))


# Generated at 2022-06-25 23:42:52.112635
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_list import List
    from pymonet.monad_string import String
    from pymonet.functor_list import List as ListF
    from pymonet.functor_string import String as StringF

    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)

    list_0 = ListF.of(str_0)
    list_1 = list_0.map(lambda x: list(x))
    list_2 = list_1.map(lambda x: x[0])

    List.of(lazy_0).bind(lambda x: list(x)).bind(lambda x: x[0]).get() == String.of(list_2).get()

# Generated at 2022-06-25 23:42:59.544651
# Unit test for method map of class Lazy
def test_Lazy_map():
    str_0 = '2c&DFhTT3 O\r]F1 '

    def fn_0(arg_1):
        def fn_1(arg_2):
            return arg_2.upper()

        return fn_1(arg_1)

    lazy_1 = Lazy(str_0)
    lazy_2 = Lazy.of(fn_0)
    lazy_3 = lazy_1.map(fn_0)
    assert (lazy_3.get() == '2C&DFHTT3 O\r]F1 ')


# Generated at 2022-06-25 23:43:05.239298
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_function_0(val):
        return Lazy.of(val + 1)

    lazy_init_0 = Lazy.of(2)
    lazy_mapped_0 = lazy_init_0.bind(test_function_0)

    assert lazy_mapped_0.get() == 3


# Generated at 2022-06-25 23:43:07.915471
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)

    assert lazy_0 == lazy_0


# Generated at 2022-06-25 23:43:17.579866
# Unit test for method map of class Lazy
def test_Lazy_map():
    from string import punctuation

    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)

    # Test with lambda
    def mapper_0(source: str) -> str:
        return source.strip(punctuation)

    # Test with function
    def mapper_1(source: str) -> str:
        return source.strip(string.punctuation)

    lazy_1 = lazy_0.map(mapper_0)
    assert lazy_1 == Lazy(mapper_0)

    lazy_2 = lazy_0.map(mapper_1)
    assert lazy_2 == Lazy(mapper_1)


# Generated at 2022-06-25 23:43:20.844681
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy(lambda: '2c&DFhTT3 O\r]F1 ')
    lazy_1 = Lazy(lambda: '2c&DFhTT3 O\r]F1 ')
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:43:32.513902
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(len).ap(Lazy.of('foo')).get() == 3
    assert Lazy.of(len).ap(Lazy.of('str_0')).get() == 5
    assert Lazy.of(len).ap(Lazy.of('dV8S0S2M')).get() == 8
    assert Lazy.of(len).ap(Lazy.of('p-O8c"G1')).get() == 8
    assert Lazy.of(len).ap(Lazy.of('QE=\'M- :')).get() == 8
    assert Lazy.of(len).ap(Lazy.of('G\'1nD\r!')).get() == 7
    assert Lazy.of(len).ap(Lazy.of('my_str')).get() == 6


# Generated at 2022-06-25 23:43:40.041749
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: '5nX9fa"P(3qP4?,_aA' ) == Lazy(lambda: '5nX9fa"P(3qP4?,_aA')


# Generated at 2022-06-25 23:43:42.896121
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    str_0 = 'L/^uG7VgAv!P*!h|'
    lazy_0 = Lazy(str_0)
    bool_0 = lazy_0 == lazy_0
    assert bool_0


# Generated at 2022-06-25 23:43:44.957628
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 2) == Lazy(lambda: 2)  # do not raise exception
    assert Lazy(lambda: 2) != Lazy(lambda: 3)  # do not raise exception


# Generated at 2022-06-25 23:43:47.907812
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    str_0 = 'gkBk_j8W2]3H1V<}1 '
    lazy_0 = Lazy(str_0)
    lazy_1 = Lazy(str_0)
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:43:52.194360
# Unit test for method map of class Lazy
def test_Lazy_map():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy.of(str_0)
    lazy_1 = lazy_0.map(lambda x: len(x))
    assert lazy_1.get() == len(str_0)


# Generated at 2022-06-25 23:44:02.990382
# Unit test for method map of class Lazy
def test_Lazy_map():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    lazy_1 = lazy_0.map(str_0.strip)
    lazy_2 = lazy_1.map(str_0.strip)
    str_1 = '2c&DFhTT3 O\r]F1 '
    lazy_3 = lazy_2.map(str_1.strip)
    str_2 = '2c&DFhTT3 O\r]F1 '
    lazy_4 = lazy_3.map(str_2.strip)
    lazy_5 = lazy_4.map(str_2.strip)

    assert(lazy_5 == Lazy.of(''))


# Generated at 2022-06-25 23:44:06.039574
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    str_1 = 's$Hv~JB{'
    lazy_0 = Lazy.of(str_1)
    lazy_1 = Lazy.of(str_1)
    assert lazy_0 == lazy_1



# Generated at 2022-06-25 23:44:14.509043
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(str).__eq__(Lazy(str)) == True
    assert Lazy(str).__eq__(Lazy(list)) == False
    assert Lazy(str).__eq__(Lazy(dict)) == False
    assert Lazy(str).__eq__(Lazy(set)) == False
    assert Lazy(str).__eq__(Lazy(bool)) == False
    assert Lazy(str).__eq__(Lazy(lambda a: a + 1)) == False
    assert Lazy(lambda a: a + 1).__eq__(Lazy(lambda a: a + 1)) == True
    assert Lazy(lambda a: a + 1).__eq__(Lazy(dict)) == False
    assert Lazy(lambda a: a + 1).__eq__(Lazy(str)) == False
    assert L

# Generated at 2022-06-25 23:44:24.928612
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.validation import ValidationFailure
    from pymonet.box import Box
    box_0 = Box(2)
    lazy_0 = Lazy(lambda arg: arg + 1)
    assert lazy_0.ap(box_0) == lazy_0
    validation_0 = Validation.success(0)
    assert lazy_0.ap(validation_0) == lazy_0
    validation_1 = ValidationFailure([])
    assert lazy_0.ap(validation_1) == lazy_0
    lazy_1 = Lazy(lambda arg: arg[1])
    box_1 = Box([1, 2, 3])
    assert lazy_1.ap(box_1) == lazy_1

# Unit test

# Generated at 2022-06-25 23:44:29.740702
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn_0(arg_0):
        return arg_0

    str_0 = ' 2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    lazy_1 = lazy_0.bind(fn_0)
    value = lazy_1.get()
    assert value == str_0


# Generated at 2022-06-25 23:44:42.871620
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Test of ap to function will return function
    # assert Lazy.of(lambda x: x * x).ap(Lazy.of(2)) == Lazy.of(4)  # TypeError: '<' not supported between instances of 'Lazy' and 'Lazy'
    assert Lazy.of(lambda x: x * x).ap(Lazy.of(2)).get() == 4
    assert Lazy.of(lambda x: x * x).ap(Lazy.of(2)).get() == 4
    assert Lazy.of(lambda x: x * x).ap(Lazy.of(2)).get() == 4

    # Test of ap to string
    assert Lazy.of('abc').ap(Lazy.of(1)).get() == 'abc'

# Generated at 2022-06-25 23:44:52.777630
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Test for a nonempty string
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    lazy_1 = lazy_0.bind(lambda a: Lazy(len(a))).get()
    assert lazy_1 == len(str_0)

    # Test for an empty string
    str_0 = ''
    lazy_0 = Lazy(str_0)
    lazy_1 = lazy_0.bind(lambda a: Lazy(len(a))).get()
    assert lazy_1 == len(str_0)
    assert lazy_0.is_evaluated

    # Test for a string contains only spaces
    str_0 = '   '
    lazy_0 = Lazy(str_0)

# Generated at 2022-06-25 23:44:57.749622
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    lazy_0._compute_value()
    lazy_1 = Lazy(str_0)
    lazy_1._compute_value()
    assert lazy_0 == lazy_1
    lazy_1 = Lazy(str)
    lazy_1._compute_value()
    assert lazy_0 != lazy_1


# Generated at 2022-06-25 23:45:04.587025
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    str_1 = '8XR^#xO%A]'
    lazy_1 = Lazy(str_1)
    float_0 = lazy_1.ap(lazy_0)
    str_2 = '2c&DFhTT3 O\r]F1 '
    float_1 = float_0.get(str_2)
    assert float_1 == 0.211462


# Generated at 2022-06-25 23:45:09.373517
# Unit test for method map of class Lazy
def test_Lazy_map():
    str_0 = 'fepxk-jzfq3q-1mzp8!-yk#*-b\x7fop'
    str_1 = '1'
    lazy_0 = Lazy.of(str_0)
    lazy_1 = lazy_0.map(str.lower)
    assert str_1 == lazy_0.get()


# Generated at 2022-06-25 23:45:17.842323
# Unit test for method map of class Lazy
def test_Lazy_map():
    def str_replace(value):
        return value.replace('foo', 'bar')

    def str_reverse(value):
        return value[::-1]

    # Test case 1
    str_0 = 'foobar'
    lazy_0 = Lazy(str_0)
    lazy_1 = lazy_0.map(str_replace)
    assert lazy_1.get() == 'barbar'
    assert lazy_0.value == None

    # Test case 2
    lazy_1 = lazy_0.map(str_replace).map(str_reverse)
    assert lazy_1.get() == 'rabrab'
    assert lazy_0.value == None



# Generated at 2022-06-25 23:45:23.308470
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_1 = ''
    str_2 = ''
    str_4 = ''
    str_3 = None
    str_5 = '2c&DFhTT3 O\r]F1 '
    str_6 = '2c&DFhTT3 O\r]F1 '
    str_7 = ''
    str_8 = ''
    str_9 = ''
    str_10 = '2c&DFhTT3 O\r]F1 '
    str_11 = ''
    str_12 = ''
    str_13 = ''
    str_14 = ''
    str_15 = '2c&DFhTT3 O\r]F1  '
    str_16 = '2c&DFhTT3 O\r]F1  '
    str_17 = ''
    str_18 = ''
   

# Generated at 2022-06-25 23:45:34.645351
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def _test_case_0():
        def _str_2_str_1_str_0(str_2: str) -> Lazy[str, str]:
            return Lazy(lambda str_1: str_0 + ' ' + str_1 + ' ' + str_2)

        str_0 = '2c&DFhTT3 O\r]F1 '
        str_1 = 'Ti7YJ\x17'
        str_2 = 'zGZ^8'
        lazy_0 = Lazy(_str_2_str_1_str_0)

# Generated at 2022-06-25 23:45:43.132729
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    class Function_0:
        def __call__(self, a0):
            return a0 + 1
    maybe_0 = Lazy.of(4).ap(Lazy.of(Function_0()))
    assert 4 == maybe_0.get()
    maybe_1 = Lazy.of(4).ap(Lazy.of(Function_0()))
    assert 4 == maybe_1.get()
    maybe_2 = Lazy.of(4).ap(Lazy.of(Function_0()))
    assert 4 == maybe_2.get()
    maybe_3 = Lazy.of(4).ap(Lazy.of(Function_0()))
    assert 4 == maybe_3.get()
    maybe_4 = Lazy.of(4).ap(Lazy.of(Function_0()))

# Generated at 2022-06-25 23:45:52.369867
# Unit test for method map of class Lazy
def test_Lazy_map():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)

    def lambda_0(s):
        total = 0
        for i in range(len(s)):
            if (s[i]) == ' ':
                break
            else:
                total += (ord(s[i]))
        return total

    lazy_1 = lazy_0.map(lambda_0)
    lazy_2 = Lazy.of(1475)
    assert lazy_1 == lazy_2


# Generated at 2022-06-25 23:46:02.140645
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # prerequisites
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    # test
    assert lazy_0.bind(str.upper) == Lazy(str.upper(str_0))
    # asserts


# Generated at 2022-06-25 23:46:04.322733
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(2) != Lazy.of(3)


# Generated at 2022-06-25 23:46:07.534292
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    f = lambda a: a + 1
    f_lazy = Lazy(f)
    test_lazy = Lazy(lambda *args: 1).bind(f_lazy.constructor_fn)
    assert test_lazy.get() == Lazy(f).get(1)


# Generated at 2022-06-25 23:46:15.314418
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    lazy_1 = lazy_0.bind(Lazy.of)
    assert lazy_1.is_evaluated == False
    assert lazy_1.value == None
    assert lazy_1.constructor_fn(str_0) == '2c&DFhTT3 O\r]F1 '
    assert Lazy(lambda *args: lazy_0.constructor_fn(*args)).bind(Lazy.of).constructor_fn(str_0) == '2c&DFhTT3 O\r]F1 '


# Generated at 2022-06-25 23:46:24.384443
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    class Text(object):

        def __init__(self, value) -> None:
            self.value = value

        def len(self):
            return len(self.value)

    class LazyTextLength(Lazy[Text, int]):

        def __init__(self, text) -> None:
            def len_text(text):
                return text.len()
            super().__init__(len_text)
            self.text = text

    class EmptyTextLength(Lazy[Text, int]):

        def __init__(self) -> None:
            def len_text(_):
                return 0
            super().__init__(len_text)

    def text_to_lazy_text(text):
        if text.len() == 0:
            return EmptyTextLength()

# Generated at 2022-06-25 23:46:32.198409
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    to_upper = lambda x: x.upper()
    str_0 = '2c&DFhTT3 O\r]F1 '
    str_1 = str_0.upper()
    lazy_0 = Lazy(str_0)
    lazy_1 = Lazy.of(str_1)
    lazy_2 = lazy_0.map(to_upper)

    assert lazy_0 != lazy_2
    assert lazy_2 == lazy_1
    assert lazy_0.get() == str_0
    assert lazy_2.get() == str_1


# Generated at 2022-06-25 23:46:33.030049
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    pass



# Generated at 2022-06-25 23:46:40.939825
# Unit test for method map of class Lazy
def test_Lazy_map():
    str_0 = 'abc'
    expected_0 = ['abc']
    lazy_0 = Lazy(str_0)

    assert lazy_0.map(list) == Lazy(list(lazy_0.constructor_fn))
    assert lazy_0.map(list) == Lazy(expected_0)
    assert lazy_0.map(lambda x: x * 2) == Lazy(lambda: str_0 * 2)
    assert lazy_0.map(lambda x: x * 2) == Lazy(lambda: 'abcabc')


# Generated at 2022-06-25 23:46:50.461274
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    str_0 = 'vK weep, poor hapless maid, to see thy lover die.'
    lazy_0 = Lazy(str_0)
    assert (lazy_0 == lazy_0) is True
    lazy_1 = Lazy(str_0)
    assert (lazy_0 == lazy_1) is True
    lazy_0.value = 'vK weep, poor hapless maid, to see thy lover die.'
    assert (lazy_0 == lazy_1) is False
    lazy_0 = Lazy(str_0)
    lazy_1 = Lazy(str_0)
    lazy_1.value = 'vK weep, poor hapless maid, to see thy lover die.'
    assert (lazy_0 == lazy_1) is False
    lazy_1 = Lazy(str_0)
   

# Generated at 2022-06-25 23:46:59.897481
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Left, Right

    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(lambda *args: str_0)
    lazy_result = lambda_0 = lambda x: Lazy(lambda *args: len(x))
    lazy_1 = lazy_0.bind(lazy_result)

    assert lazy_1.get() == 18
    assert lazy_1.get() == 18

    lazy_result = lambda x: Lazy(lambda *args: Right(len(x))).to_either()
    lazy_1 = lazy_0.bind(lazy_result)

    assert lazy_1.get() == Right(18)



# Generated at 2022-06-25 23:47:18.642336
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    str_0 = 'Lazy[fn=<function make_id_0 at 0x000001F78D7C3730>, value=2c&DFhTT3 O\r]F1 , is_evaluated=True]'
    str_1 = 'Lazy[fn=<function make_id_0 at 0x000001F78D7C3730>, value=2c&DFhTT3 O\r]F1 , is_evaluated=False]'
    lazy_0 = Lazy.of(str_0)
    lazy_1 = Lazy.of(str_1)
    assert(lazy_0 == Lazy.of(str_0))
    assert(lazy_0 != Lazy.of(str_1))
    assert(lazy_1 != lazy_0)


# Generated at 2022-06-25 23:47:29.887343
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    list_0 = ['x&D FhTT3 O\r]F1 ', 'X&D FhTT3 O\r]F1 ']
    list_1 = ['x&D FhTT3 O\r]F1 ', 'X&D FhTT3 O\r]F1 ', 'x&D FhTT3 O\r]F1 ', 'X&D FhTT3 O\r]F1 ']

# Generated at 2022-06-25 23:47:38.857272
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.monad_list import monad_list
    from pymonet.validation import Validation

    def test_case_0():
        def str_0(a): return '2c&DFhTT3 O\r]F1 '
        lazy_0 = Lazy(str_0)
        lazy_1 = lazy_0.bind(lambda str_1: Box(str_1))
        lazy_2 = lazy_1.map(str.__add__('A'))
        lazy_3 = lazy_2.map(str.__add__('B'))
        lazy_4 = lazy_3.map(str.__add__('C'))
        lazy_5 = lazy_4.map(str.__add__('D'))
        lazy_6 = lazy_

# Generated at 2022-06-25 23:47:41.953929
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # create data for the test
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)

    def mapper_func_0(str_):
        def str_len(str_):
            return len(str_)

        return Lazy(str_len)

    lazy_0.bind(mapper_func_0)


# Generated at 2022-06-25 23:47:43.720300
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)


# Generated at 2022-06-25 23:47:53.161629
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def str_box(value):
        return Box(value)

    def str_right(value):
        return Right(value)

    def str_validation(value):
        return Validation.success(value)

    def str_try(value):
        return Try.of(value)

    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)

    assert lazy_0.bind(str_box).get() == Box(str_0)
    assert lazy_0.bind(str_right).get() == Right(str_0)

# Generated at 2022-06-25 23:47:59.050012
# Unit test for method map of class Lazy
def test_Lazy_map():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    expected_str = '2c&DFhTT3 O\r]F1 '
    str_1 = lazy_0.map(lambda str_0: str_0)
    assert expected_str == str_1


# Generated at 2022-06-25 23:48:03.589516
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    str_0 = '2c&DFhTT3 O\r]F1 '
    str_1 = '\x19\x00\x00\x00'
    lazy_0 = Lazy(str_1.isprintable)
    lazy_1 = Lazy(str_0)
    lazy_0.ap(lazy_1)
    str_2 = '\x04\x00\x00\x00\x00\x00\x00\x00'
    lazy_2 = Lazy(str_2.islower)
    lazy_2.ap(lazy_1)


# Generated at 2022-06-25 23:48:12.523553
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.list import List
    from pymonet.box import Box
    # Bind for notempty lists
    list_a = List(1, Lazy.of(3), Lazy.of(5))
    def binder(x):
        if x % 2 == 0:
            return List(x + 1)
        else:
            return List(x - 1)
    ret = list_a.bind(binder)
    assert ret == List(0, 4, 6)

    # Empty list
    list_a = List()
    ret = list_a.bind(None)
    assert ret == List()

    # Bind for box
    box = Box(1)
    def binder(x):
        return Box(x + 1)
    ret = box.bind(binder)
    assert ret == Box(2)

# Generated at 2022-06-25 23:48:22.085807
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.iter import Iter

    def test_fn_0():
        box_0 = Box(1)

        iter_0 = box_0.iter()

        def test_fn_1(value_0):
            lazy_0 = Lazy.of(value_0)
            return lazy_0

        iter_1 = iter_0.map(test_fn_1)
        return iter_1

    lazy_0 = Lazy(test_fn_0)
    iter_0 = lazy_0.bind(test_fn_0)
    # """""""""
    iter_1 = iter_0.map(str)

    def test_fn_2(value_0):
        box_0 = Box(value_0)


# Generated at 2022-06-25 23:48:44.689107
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    str_0 = '2c&DFhTT3 O\r]F1 '
    str_1 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    lazy_1 = Lazy(str_1)
    lazy_2 = Lazy(str_0)

    assert lazy_0 == lazy_1
    assert lazy_1 == lazy_0
    assert lazy_0 == lazy_2

# Generated at 2022-06-25 23:48:48.797619
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy.of(lambda fn: fn(fn))

    lazy_1 = lazy_0.ap(Lazy.of(123))

    assert lazy_1.get() == 123123
    assert lazy_1 is not lazy_0


# Generated at 2022-06-25 23:48:55.313707
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)

    lazy_1 = lazy_0.bind(lambda x : Lazy.of(x))
    assert not lazy_1.is_evaluated
    assert lazy_1.constructor_fn != str_0
    assert lazy_1.get() == str_0

if __name__ == '__main__':  # pragma: no cover
    test_Lazy_bind()

# Generated at 2022-06-25 23:48:59.006561
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy.of(str_0)
    assert lazy_0 == Lazy.of(str_0)
    assert not (lazy_0 == Lazy.of(str_0[::-1]))



# Generated at 2022-06-25 23:49:04.706954
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # TODO: fix for python 3.6
    # str_0 = '2c&DFhTT3 O\r]F1 '
    # str_0_1 = '2c&DFhTT3 O\r]F1 '
    # str_1 = '2c&DFhTT3 O\r]F1 '
    # lazy_0 = Lazy(str_0)
    # lazy_1 = Lazy(str_1)
    # lazy_1_1 = Lazy(lambda x: x)
    # assert lazy_0.ap(lazy_1) == Lazy(lambda: str_0_1.upper())
    # assert lazy_0.ap(lazy_1_1) == Lazy(lambda: str_0_1.upper())
    pass



# Generated at 2022-06-25 23:49:10.220273
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    val_0 = Lazy.of(3)
    val_1 = Lazy(lambda x: x + 2)
    val_0.ap(val_1) #eval(val_0, val_1)
    assert val_0.get() == 3
    assert val_1.get() == 5
    assert val_0.is_evaluated
    assert val_1.is_evaluated


# Generated at 2022-06-25 23:49:19.638277
# Unit test for method map of class Lazy
def test_Lazy_map():
    def __test_fixture__(str_0, str_1, int_0):
        str_2 = str_0
        str_3 = (str_1 + str_2)
        def __test_fixture_fn__(str_3):
            return ((str_3 + str_1) + str_2)
        str_4 = __test_fixture_fn__(str_3)
        str_5 = Lazy.of(str_1)
        str_6 = ((str_2 + str_2) + str_2)
        def __test_fixture_fn__(str_1):
            return ((str_3 + str_1) + str_1)
        str_7 = __test_fixture_fn__(str_1)
        str_8 = (str_4 + str_4)

# Generated at 2022-06-25 23:49:27.638534
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad import Monad
    from pymonet.monad_instance import MonadInstance
    from pymonet.monad_type import MonadType
    import pymonet.function as function

    str_0 = '2c&DFhTT3 O\r]F1 '
    lazy_0 = Lazy(str_0)
    lazy_0_bind_result = lazy_0.bind(function.remove_first)
    lazy_0_bind_result_type = type(lazy_0_bind_result)
    lazy_0_constructor = lazy_0_bind_result.get()
    lazy_0_constructor_type = type(lazy_0_constructor)
    lazy_0_mapper_result = lazy_0_bind_result.map(function.reverse)
    lazy_

# Generated at 2022-06-25 23:49:29.181450
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    prop_Lazy_bind = lambda: True
    assert prop_Lazy_bind() == True


# Generated at 2022-06-25 23:49:37.686993
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    str0 = '2c&DFhTT3'
    lazy0 = Lazy(str0)
    print('test_Lazy_ap', lazy0)
    str1 = ' O\r]F1 '
    lazy1 = Lazy(str1)
    print('test_Lazy_ap', lazy1)
    lazy2 = lambda string1: Lazy(lambda string2: string2 + string1)
    lazy3 = lazy0.ap(lazy1.map(lazy2))
    assert lazy3.value == ' O\r]F1 2c&DFhTT3'



# Generated at 2022-06-25 23:50:24.329129
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    str_0 = '8%v7VU9e6U}R'
    lazy_0 = Lazy.of(str_0)
    str_1 = 'V7k&bY{90H[ZWd'
    lazy_1 = lazy_0.map(str_1)
    lazy_2 = Lazy.of(str_0)
    str_2 = '=Gj@'
    lazy_3 = lazy_2.map(str_2)
    lazy_4 = lazy_3.ap(lazy_1)
    str_3 = '=Gj@8%v7VU9e6U}R'
    assert str_3 == lazy_4.get()
