

# Generated at 2022-06-25 23:40:29.649715
# Unit test for method get of class Lazy
def test_Lazy_get():
    bytes_0 = b'0\xce\xf1\x9a\x95P\x8e\x0f\xbf\x80j\x8f\xfc.\xdf\xc1\x8a\n\xaf'
    lazy_0 = Lazy(bytes_0)

    assert(lazy_0.get() == b'0\xce\xf1\x9a\x95P\x8e\x0f\xbf\x80j\x8f\xfc.\xdf\xc1\x8a\n\xaf')

    bytes_1 = b'6U\xfa\xce\xa4\xa4\xfa\xbf\xbf'
    lazy_1 = Lazy(bytes_1)


# Generated at 2022-06-25 23:40:40.323552
# Unit test for method __eq__ of class Lazy

# Generated at 2022-06-25 23:40:47.455341
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b"\x07"
    int_0 = Lazy(len(bytes_0)).__eq__(Lazy(len(bytes_0)))
    assert int_0 == True
    bytes_1 = b"\x07"
    int_1 = Lazy(len(bytes_1)).__eq__(Lazy(len(bytes_1)))
    assert int_1 == True
    bytes_2 = b"\x07"
    int_2 = Lazy(len(bytes_2)).__eq__(Lazy(len(bytes_2)))
    assert int_2 == True


# Generated at 2022-06-25 23:40:52.100391
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1))


# Generated at 2022-06-25 23:40:55.997336
# Unit test for method get of class Lazy
def test_Lazy_get():
    f = lambda : 3
    l = Lazy(f)
    assert l.get() == 3


# Generated at 2022-06-25 23:41:06.205576
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\xde\x95\xf9\x85\x88\x13\xee0Z\x07\x04\xc4\x8d\x7f\x9f\x7f\xdd\xb3\xf3\xdf\xc7\xbb\x9e'
    lazy_0 = Lazy.of(bytes_0)
    assert lazy_0.get() == bytes_0

    lazy_1 = lazy_0.map(lambda h_00: h_00 + b'\xff')

    assert lazy_1.get() == bytes_0 + b'\xff'

    lazy_2 = lazy_1.map(lambda h_10: h_10 + b'\x11')

    assert lazy_2.get() == bytes_0 + b'\xff' + b

# Generated at 2022-06-25 23:41:13.724777
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\x80t\x85\xbe\x7f\x08\xec\xb4'
    lazy_0 = Lazy(bytes_0)
    bytes_1 = b'\x80t\x85\xbe\x7f\x08\xec\xb4'
    lazy_1 = Lazy(bytes_1)
    # for None
    assert lazy_0.__eq__(None) is False
    # for other type
    assert lazy_0.__eq__('') is False
    # for self
    assert lazy_0.__eq__(lazy_0) is True
    # for Lazy where both are evaluated and have the same value and constructor functions

# Generated at 2022-06-25 23:41:22.694812
# Unit test for method ap of class Lazy

# Generated at 2022-06-25 23:41:32.724174
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    bytes_0 = b'tK\x01\xe1\xc9\x82m'
    lazy_0 = Lazy(bytes_0)
    lazy_0.map()
    assert lazy_0.is_evaluated == False
    assert isinstance(lazy_0.map(lambda arg_1: arg_1), Lazy)
    lazy_1 = lazy_0.map(lambda arg_1: arg_1)
    assert lazy_0.is_evaluated == False
    assert lazy_0.value == None
    assert lazy_0 != lazy_1
    assert lazy_0 == Lazy(bytes_0)
    assert lazy_1 == Lazy(bytes_0)
    lazy_1.get()

# Generated at 2022-06-25 23:41:38.090989
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'tK\x01\xe1\xc9\x82m'
    lazy_0 = Lazy(bytes_0)
    assert lazy_0.is_evaluated == False
    str_0 = lazy_0.bind(bytes.decode)
    assert lazy_0.is_evaluated == True
    assert str_0.value == 'tK\x01\xe1\xc9\x82m'


# Generated at 2022-06-25 23:41:46.920989
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    We equals two Lazy where both are evaluated both have the same value and constructor functions.
    """
    bytes_0 = b'tK\x01\xe1\xc9\x82m'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(bytes_0)

    assert lazy_0 == lazy_0
    assert lazy_0 == lazy_1
    assert lazy_1 == lazy_0



# Generated at 2022-06-25 23:41:57.016702
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor import Functor
    from pymonet.optional import Optional, Maybe
    from pymonet.validation import Validation

    func = Functor(lambda x: x + 1)
    lazy_int_1 = Lazy(func.map)

    lazy_int_2 = lazy_int_1.bind(lambda x: Lazy.of(x(1)))
    assert lazy_int_2.get() == 2

    optional_str_1 = Optional.of('1')
    lazy_str_1 = Lazy(optional_str_1.map, optional_str_1)

    lazy_str_2 = lazy_str_1.bind(lambda x: Lazy.of(x))
    assert lazy_str_2.get() == '1'

    optional_str_2 = Optional.of('1')

# Generated at 2022-06-25 23:42:07.036965
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    bytes_0 = b'E\x81\xea\x0cx\x05'
    bytes_1 = b'\xf2\xf6c\xdc\xa5\x82'
    lazy_1 = Lazy(bytes_0)
    lazy_2 = Lazy(bytes_1)
    lazy_3 = Lazy(bytes_1)
    lazy_4 = Lazy.of(bytes_1)
    lazy_2.value = bytes_1
    res = lazy_1.ap(lazy_4)
    assert res == lazy_3


# Generated at 2022-06-25 23:42:08.928114
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(b'abc').map(lambda x: len(x)).get() == 3



# Generated at 2022-06-25 23:42:13.926059
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'tK\x01\xe1\xc9\x82m'
    lazy_0 = Lazy(bytes_0)

    def fn_0(x):
        return len(x)

    lazy_0 = lazy_0.map(fn_0)
    assert lazy_0._compute_value() == 7


# Generated at 2022-06-25 23:42:22.997040
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'\xd6\xdb\x13\xc8\xba\xe1\x0b\x9d\x1c'
    bytes_1 = b'\x13\x8d\x1d\xf0\x16'
    lazy_1 = Lazy(bytes_0)
    lazy_0 = lazy_1.map(lambda byte_1: byte_1 * byte_1)
    bytes_2 = b'\x13\x8d\x1d\xf0\x16'
    lazy_2 = Lazy(bytes_2)
    assert lazy_2 == lazy_0


# Generated at 2022-06-25 23:42:34.011995
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\xa9\x9f\x9e\x05\xdb\xaa\xea\xe5'
    bytes_1 = b'\x9c\xf5\x95\x8a\x02\x15\x0a\x0e'
    bytes_2 = b'\x85\xc5\x1a\n\xfb\xf5\x01H'
    bytes_3 = b'\xea\xb1\x08\xf2\x06\x86\xcd\xde'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(bytes_1)
    lazy_2 = Lazy(bytes_2)
    lazy_3 = Lazy(bytes_3)


# Generated at 2022-06-25 23:42:39.711529
# Unit test for method map of class Lazy

# Generated at 2022-06-25 23:42:44.383974
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'tK\x01\xe1\xc9\x82m'
    lazy_0 = Lazy(bytes_0)
    def fn_0(arg_0):
        return len(arg_0)
    lazy_1 = lazy_0.map(fn_0)
    assert lazy_1.get() == len(bytes_0)


# Generated at 2022-06-25 23:42:54.001609
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'N'
    bytes_1 = b'\x00\x00\x00\x00\x00\x00'
    bytes_2 = b'\x0e\x00\x00\x00\x00\x00'
    lazy_0 = Lazy(bytes_0)
    def bytes_3(arg_0: bytes):
        return Lazy(bytes_1)
    lazy_1 = lazy_0.bind(bytes_3)
    assert_equals(bytes_1, lazy_1.constructor_fn())

    lazy_1 = Lazy.of(bytes_0)
    def bytes_4(arg_0: bytes):
        return Lazy.of(bytes_2)
    lazy_2 = lazy_1.bind(bytes_4)

# Generated at 2022-06-25 23:43:10.390339
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy(lambda arg_0: arg_0)
    list_0 = [b'\xeb\x06\x16\\\x18\x16\x1e\x1e\x15', 6, b'\x1e\x1e\x1e\x1e\x1e\x1e\x1e\x1e\x1e\x1e\x1e', ()]
    lazy_0.ap(lazy_0)
    lazy_1 = Lazy.of(b'\x07\x06\x03\x02\x01')
    lazy_1.ap(lazy_1)
    lazy_1.ap(lazy_0)
    lazy_1.ap(lazy_0.to_box())

# Generated at 2022-06-25 23:43:16.223122
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'tK\x01\xe1\xc9\x82m'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(bytes_0)
    assert lazy_0 == lazy_1
    bytes_1 = b'0'
    lazy_2 = Lazy(bytes_1)
    assert not (lazy_0 == lazy_2)
    assert not (lazy_0 == bytes_0)


# Generated at 2022-06-25 23:43:23.144296
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def lazy_f(x: Lazy, y: Lazy) -> Lazy:
        return x.ap(y)

    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 2).ap(Lazy.of(1)) == Lazy.of(3)
    assert lazy_f(Lazy.of(lambda x: x + 1), Lazy.of(2)) == Lazy.of(3)
    assert lazy_f(Lazy.of(lambda x: x + 3), Lazy.of(2)) == Lazy.of(5)


# Generated at 2022-06-25 23:43:34.547881
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.either import Right

    lazy_0 = Lazy.of(5)
    lazy_1 = lazy_0.map(lambda x: x * 2)
    assert lazy_1.get() == 10

    lazy_0 = Lazy.of(5)
    lazy_1 = lazy_0.map(lambda x: x * 2).map(lambda x: x + 3)
    assert lazy_1.get() == 13

    lazy_0 = Lazy.of(5)
    lazy_1 = lazy_0.map(lambda x: x * 2)
    lazy_2 = lazy_1.map(lambda x: x * 3)

# Generated at 2022-06-25 23:43:43.568385
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\x0f\x9f\xbd\x1f\xe8\x1f3'
    lazy_0 = Lazy(bytes_0)
    assert lazy_0.bind(bytes_0) == lazy_0
    int_0 = int()
    lazy_1 = Lazy(int_0)
    def mapper_0(arg_0):
        return Lazy(int(arg_0))
    lazy_2 = lazy_1.bind(mapper_0)
    assert lazy_1 == lazy_2
    lazy_3 = Lazy(bytes_0)
    def mapper_1(arg_0):
        return Lazy(bytes(arg_0))
    lazy_4 = lazy_3.bind(mapper_1)
    assert lazy_3 == lazy_4
   

# Generated at 2022-06-25 23:43:45.440409
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda a: a + 2).ap(Lazy.of(7)) == Lazy.of(9)



# Generated at 2022-06-25 23:43:50.466507
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy.of(Lazy.of(bytes_0))
    lazy_1 = lazy_0.ap(lazy_0)
    assert lazy_1.is_evaluated == False
    bytes_0 = b'\x08p\x81\xfb\x9a\x9c\x85\x8c'
    result = lazy_1.get()
    assert result == bytes_0



# Generated at 2022-06-25 23:43:56.028275
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.functional import identity
    from pymonet.maybe import Maybe, Just

    lazy_maybe = Lazy.of(Maybe.just(identity))
    lazy_just = Lazy.of(Just(1))
    ap_result = lazy_maybe.ap(lazy_just)
    assert(ap_result.get() == 1)

# Generated at 2022-06-25 23:44:06.131596
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_try import Try

    class C():
        def __init__(self, a):
            self._a = a

        def m(self):
            return self._a

    def mapper(a):
        return a + 1

    def mapper_fail(a):
        raise Exception('Exception here')

    lazy_0: Lazy[int, int] = Lazy(lambda a: a + 1).map(mapper)
    assert mapper(1) == lazy_0.get(1)

    lazy_1: Lazy[int, int] = Lazy(lambda a: a + 1).map(mapper_fail)
    try:
        assert mapper_fail(1) == lazy_1.get(1)
    except Exception as e:
        assert 'Exception here' == str(e)

# Generated at 2022-06-25 23:44:14.631161
# Unit test for method map of class Lazy
def test_Lazy_map():
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z = 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25
    lazy_0 = Lazy.of((a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z))

# Generated at 2022-06-25 23:44:26.705612
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of Lazy

    Args:
        -
    Returns:
        -
    Raises:
        -
    """
    from pymonet.box import Box

    value_map = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50}

    lazy_of_square = Lazy.of(lambda x: x * x)
    lazy_of_key = Lazy.of(lambda t: t[1])

    def f(x: int) -> Lazy[int, int]:
        return Lazy.of(x)

    assert lazy_of_key.bind(lambda x: Lazy.of(x)).get((1, 2)) == 2
    # Check if value is correctly transform during function call:

# Generated at 2022-06-25 23:44:29.228908
# Unit test for method map of class Lazy
def test_Lazy_map():
    test_value_0 = Lazy.of(int_0)
    assert True == test_value_0.map(lambda value: value == 2)


# Generated at 2022-06-25 23:44:36.406117
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Either

    lazy_int = Lazy.of(int_0)
    lazy_try = Lazy.of(Try.of(int, str_0))
    lazy_validation_failure = Lazy.of(Validation.failure(str_0))
    lazy_validation_success = Lazy.of(Validation.success(int_0))
    lazy_either_left = Lazy.of(Either.left(str_0))
    lazy_either_right = Lazy.of(Either.right(int_0))

    assert lazy_int.ap(lazy_int) == Lazy(lambda: int_0)

# Generated at 2022-06-25 23:44:42.225829
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    Lazy_0 = Lazy(lambda x: x)
    try:
        Lazy_0.bind(lambda x: Lazy(lambda y: x))
        print("Success")
    except:
        print("Fail")

    try:
        Lazy_0.bind(lambda x: Lazy_0)
        print("Success")
    except:
        print("Fail")



# Generated at 2022-06-25 23:44:48.284206
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1
    int_1 = 2

    def is_even(num: int) -> Lazy[int, bool]:
        def delta(num):
            if num % 2 == 0:
                return True
            else:
                return False

        return Lazy(lambda *args: delta(num))

    actual = Lazy.of(1).bind(is_even)
    assert actual == Lazy.of(False)

# Generated at 2022-06-25 23:44:57.001546
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.lazy import Lazy

    assert Lazy.of(2).ap(Lazy.of(lambda x : x + 2)) == Lazy.of(4)
    assert Lazy.of(2).ap(Lazy.of(lambda x : x - 2)) == Lazy.of(0)
    assert Lazy.of(2).ap(Lazy.of(lambda x : x ** 2 )) == Lazy.of(4)
    
    assert Lazy.of(0.0).ap(Lazy.of(lambda x : x ** 2)) == Lazy.of(0)
    assert Lazy.of(0.0).ap(Lazy.of(lambda x : x ** 0.5 )) == Lazy.of(0)

# Generated at 2022-06-25 23:45:00.205469
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        def lambda_fn(y):
            return x + y
        return Lazy(lambda_fn)

    lazy = Lazy(lambda x: x * 2)
    assert lazy.bind(fn)(20) == 42


# Generated at 2022-06-25 23:45:05.304367
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import pymonet.lazy as lazy

    def mapper(value):
        return value + 1

    fn = lambda *args: lambda *args: 0

    lazy_with_fn = lazy.Lazy(fn)
    assert lazy_with_fn.ap(lazy_with_fn) == lazy.Lazy(lambda *args: 0)


# Generated at 2022-06-25 23:45:15.863806
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def add_two(value):
            return value + 2

    def throw_error(value):
        raise ValueError("Int is not bigger than 2")

    lazy_int = Lazy.of(1)
    result = lazy_int.ap(Maybe.just(add_two))

    assert isinstance(result, Lazy)

    assert 3 == result.get()

    result = lazy_int.ap(Maybe.nothing())

    assert isinstance(result, Lazy)
    assert Maybe.nothing() == result.get()

    result = lazy_int.ap(Validation.success(add_two))
    assert isinstance(result, Lazy)
    assert 3 == result.get()


# Generated at 2022-06-25 23:45:17.436383
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_0 = Lazy.of(1)
    res_0 = lazy_0.map(lambda a: a + 2)

    assert res_0.get() == 3


# Generated at 2022-06-25 23:45:29.100798
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = -1

    def add_0(a):
        return a + 0

    def mul_10(a):
        return a * 10

    # (1) -> (2) -> (3)
    number_1 = Lazy.of(1).bind(add_0).bind(mul_10)
    assert (int_0 + number_1.get()) == 10

    # (3) -> (2) -> (1)
    number_2 = number_1.bind(mul_10).bind(add_0)
    assert (int_0 + number_2.get()) == 100

    # (2) -> (1) -> (3)
    number_3 = number_2.bind(add_0).bind(mul_10)
    assert (int_0 + number_3.get()) == 1000

# Generated at 2022-06-25 23:45:39.507601
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    def multiply(a, b):
        return a * b

    def divide(a):
        if a == 0:
            return None
        return 1 / a

    def add(a, b):
        return a + b

    def validate_int(a):
        if not isinstance(a, int):
            return 1
        return 0

    def validate_string(a):
        if not isinstance(a, str):
            return 1
        return 0

    def validate_tuple(a):
        if not isinstance(a, tuple):
            return 1
        return 0


# Generated at 2022-06-25 23:45:50.089871
# Unit test for method map of class Lazy
def test_Lazy_map():
    # given
    def add_one(x: int) -> int:
        return x + 1

    # when
    lazy_of_1 = Lazy(lambda: 1).map(add_one)

    # then
    assert lazy_of_1.is_evaluated == False
    assert lazy_of_1.value == None
    assert lazy_of_1 == Lazy(lambda: 1).map(add_one)
    assert lazy_of_1 != Lazy(lambda: 1).get()
    assert lazy_of_1 != Lazy(lambda: 2).map(add_one)
    assert lazy_of_1 != Lazy(lambda: 2)
    assert lazy_of_1 != 1

    # when
    result = lazy_of_1.get()

    # then
    assert result == 2
    assert lazy_of

# Generated at 2022-06-25 23:45:55.795813
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1
    int_1 = 2

    fn1 = lambda value: Lazy(lambda *args: value + int_1)
    fn2 = lambda value: Lazy(lambda *args: value + int_0)
    lazy = Lazy(lambda *args: int_0).bind(fn1).bind(fn2)

    assert lazy.constructor_fn() == int_0 + int_1 + int_0


# Generated at 2022-06-25 23:45:59.594806
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 2).ap(Lazy.of(5)) == Lazy.of(7)



# Generated at 2022-06-25 23:46:07.859246
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # setup
    int_0 = 1
    int_1 = 2
    int_2 = 3

    Lazy_0 = Lazy.of(int_0)
    Lazy_1 = Lazy.of(int_1)
    Lazy_2 = Lazy.of(int_2)

    Lazy_3 = Lazy_1.ap(Lazy_2)

    Lazy_4 = Lazy_1.map(lambda x: lambda y: x + y)
    Lazy_5 = Lazy_4.ap(Lazy_2)

    # assert
    assert Lazy_5.get() == 4

    # teardown
    int_0 = None
    int_1 = None
    int_2 = None

    Lazy_0 = None
    Lazy_1 = None
    Lazy_2

# Generated at 2022-06-25 23:46:11.336440
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = Lazy.of(1)
    int_1 = int_0.map(lambda x: x + 1)
    int_2 = int_1.map(lambda y: y * y)
    assert int_2.get() == 4, "Error: expected 4"


# Generated at 2022-06-25 23:46:20.976547
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = Lazy.of(1)
    str_0 = None

    # Test for function that takes only one argument
    def test_fn_1_arg(x):
        return "a" + str(x)

    str_0 = int_0.map(test_fn_1_arg)

    # Test for function that takes only two argument
    def test_fn_2_args(x, y):
        return y + str(x)

    str_1 = int_0.map(test_fn_2_args)

    # Test for function that takes only three argument
    def test_fn_3_args(x, y, z):
        return z + str(x) + y

    str_2 = int_0.map(test_fn_3_args)

    # Test for function that takes only one argument

# Generated at 2022-06-25 23:46:23.396001
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    expected = "expected"
    instance = Lazy.of(None)

    actual = instance.bind(lambda _: Lazy.of(expected))

    assert actual == expected



# Generated at 2022-06-25 23:46:26.520481
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    value = Lazy.of(1)
    lambdda_fn = lambda x: Lazy.of(x + 1)
    result = value.bind(lambdda_fn)
    assert result.constructor_fn() == 2


# Generated at 2022-06-25 23:46:32.685197
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    bytes_0 = b'\x93\xb8\xbc\xb9\xbc\x06\xfe8W\x02\x07\x01\xb0'
    lazy_0 = Lazy(bytes_0)
    int_0 = lazy_0.ap(lazy_0)



# Generated at 2022-06-25 23:46:42.078751
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    class Error:
        pass

    class MockLazy:
        def __init__(self, value):
            self._value = value

        def constructor_fn(self, *args):
            return self._value

    def calc(a):
        return MockLazy(a + 1)

    assert Lazy(lambda x: x).bind(calc).constructor_fn(2) == 3
    assert Lazy(lambda x: x).bind(Error).constructor_fn(2) == 2

    try:
        Lazy(lambda x: x + 1).bind(calc).constructor_fn()
        assert False
    except TypeError:
        assert True
    except:
        assert False



# Generated at 2022-06-25 23:46:47.290142
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def Foo(x: str) -> 'Lazy[str, str]':
        return Lazy.of(x)
    result_0_1 = Lazy.of('bar').bind(Foo)
    result_0_2 = Lazy.of('bar').bind(Foo)
    assert result_0_1 == result_0_2



# Generated at 2022-06-25 23:46:54.453040
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box, BoxMonad
    from pymonet.monad_try import Try, TryMonad
    from pymonet.maybe import Maybe, MaybeMonad
    from pymonet.either import Either, EitherMonad
    from pymonet.validation import Validation, ValidationMonad
    from pymonet.monad import Monad
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    def _map_to_box(value):
        return Box(value)

    def _map_to_try(value):
        return Try(value)

    def _map_to_maybe(value):
        return Maybe(value)

    def _map_to_either(value):
        return Either(value)


# Generated at 2022-06-25 23:46:59.779177
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'tK\x01\xe1\xc9\x82m'
    lazy_0 = Lazy(bytes_0)

    def function_binder(argument):
        pass

    lazy_result = lazy_0.bind(function_binder)

    assert lazy_result.value == None
    assert lazy_result.is_evaluated == False
    assert lazy_result.constructor_fn == Lazy(function_binder).constructor_fn


# Generated at 2022-06-25 23:47:05.359251
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy(lambda a: a)
    lazy_1 = Lazy(lambda a: a * 2)
    box = lazy_0.ap(lazy_1)
    assert (box.get(2) == 4)



# Generated at 2022-06-25 23:47:13.070311
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    not_empty_lazy_0 = Lazy.of(42)
    not_empty_lazy_1 = Lazy.of(lambda x: x + x)

    assert not_empty_lazy_0.ap(not_empty_lazy_1).get() == (42 + 42)

    empty_lazy_0 = Lazy(lambda: [])
    empty_lazy_1 = Lazy(lambda: not_empty_lazy_1)
    empty_lazy_2 = Lazy(lambda: empty_lazy_1)

    assert empty_lazy_0.ap(empty_lazy_1).get() == (not_empty_lazy_1.get()(empty_lazy_1.get()))


# Generated at 2022-06-25 23:47:17.106248
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'tK\x01\xe1\xc9\x82m'
    lazy_0 = Lazy(bytes_0)
    def func(x):
        return x
    lazy_0.map(func)
    assert lazy_0.get() == bytes_0


# Generated at 2022-06-25 23:47:24.326617
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\x00\x01\x02\x03\x04'
    lazy_0 = Lazy(bytes_0)
    bytes_1 = b'\x00\x01\x02\x03\x04'
    lazy_1 = Lazy(bytes_1)
    bytes_2 = b'\x00\x01\x02\x03'
    lazy_2 = Lazy(bytes_2)
    assert lazy_0 == lazy_1
    assert lazy_0 != lazy_2


# Generated at 2022-06-25 23:47:29.204503
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    value_0 = "1"
    lazy_0 = Lazy(value_0)
    fn_0 = Lazy.of(lambda x: 1)
    result = lazy_0.ap(fn_0)
    expected = Lazy.of(1)

    assert (result == expected)


# Generated at 2022-06-25 23:47:38.016539
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    expected = b'tK\x01\xe1\xc9\x82m'
    bytes_0 = b'tK\x01\xe1\xc9\x82m'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = lazy_0.bind(lambda *args: Lazy(lambda *args: args[0]))
    assert lazy_1._compute_value() == expected


# Generated at 2022-06-25 23:47:43.115138
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(bytes.fromhex('4444444444444444444444444444444444444444444444444444444444444444')).bind(
        lambda x: Lazy.of(x)
    ) == Lazy(bytes.fromhex('4444444444444444444444444444444444444444444444444444444444444444'))



# Generated at 2022-06-25 23:47:52.401307
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def func(num):
        def lambda_fn(*args):
            if args[0] == num:
                return num
            raise Exception()

        return Lazy(lambda_fn)

    actual = Lazy.of(1).bind(func)
    expected = Lazy.of(1)
    assert actual == expected

    actual = Lazy.of(2).bind(func)
    expected = Lazy.of(2)
    assert actual == expected

    actual = Lazy.of('test').bind(func)
    expected = Lazy.of('test')
    assert actual == expected

    actual = Lazy.of(2).bind(func).bind(func)
    expected = Lazy.of(2)
    assert actual == expected

    actual = Lazy.of(1).bind(func).bind(func)

# Generated at 2022-06-25 23:48:01.914810
# Unit test for method map of class Lazy

# Generated at 2022-06-25 23:48:11.706684
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Just, Nothing
    from pymonet.monad_try import Failure
    from pymonet.validation import Validation, Failure as VFailure, Success as VSuccess
    from pymonet.either import Left, Right
    from pymonet.box import Box

    try:
        import cPickle as pickle
    except ImportError:
        import pickle

    def string_to_bytes(s: str) -> bytes:
        return str.encode(s)

    def bytes_to_string(b: bytes) -> str:
        return bytes.decode(b)

    def pickle_serialize(data) -> bytes:
        return pickle.dumps(data)

    def pickle_deserialize(b: bytes) -> object:
        return pickle.loads(b)


# Generated at 2022-06-25 23:48:21.459847
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Arrange
    bytes_0 = b'\x9f\xac\x1c\x02\x06\x0f\x1a\x07\xf1mW\x1f\x13\xfc\x17P'
    lazy_0 = Lazy(bytes_0)
    bytes_1 = b'\x1c\x02\x06\x0f\x1a\x07\xf1mW\x1f\x13\xfc\x17P'
    lazy_1 = Lazy(bytes_1)
    bytes_2 = b'\x02\x06\x0f\x1a\x07\xf1mW\x1f\x13\xfc\x17P'
    lazy_2 = Lazy(bytes_2)

    # Act
   

# Generated at 2022-06-25 23:48:24.900800
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'tK\x01\xe1\xc9\x82m'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = lazy_0.map(bytes.hex)
    assert lazy_1.get() == '744b01e1c9826d'


# Generated at 2022-06-25 23:48:31.109227
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    lazy = Lazy(lambda *a: 'foo')
    maybe = Maybe.just(3)

    def foo(x: str) -> Maybe[int]:
        return Maybe.just(x)

    lazy2 = lazy.bind(foo)
    assert lazy2.get() == maybe.value

    def foo2(x: str) -> Right[int]:
        return Right(x)

    lazy2 = lazy.bind(foo2)
    assert lazy2.get() == maybe.value


# Generated at 2022-06-25 23:48:38.799544
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe
    from pymonet.try_ import Try

    result = Lazy.of(lambda x: x + 1).ap(Try.success(1))
    assert result == Lazy.of(2)

    result = Lazy.of(lambda x: x + 1).ap(Try.failure(ValueError('er')))
    assert result == Lazy.of(lambda x: x + 1)

    result = Lazy.of(Try.failure(ValueError('er'))).ap(Lazy.of(lambda x: x + 1))
    assert result == Lazy.of(Try.failure(ValueError('er')))


# Generated at 2022-06-25 23:48:42.928392
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'tK\x01\xe1\xc9\x82m'
    lazy_0 = Lazy(bytes_0)
    method_result_0 = lazy_0.bind(lambda x: Lazy(x))
    assert method_result_0 == Lazy(bytes_0), "Incorrect result of method bind"


# Generated at 2022-06-25 23:48:55.940115
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Test case 0
    # Error during ap execution

    # Expected result:
    expected_result_0 = Lazy.of(None)

    # Actual result:
    result = exception = None
    try:
        result = lazy_0.ap(lazy_0)
    except Exception as e:
        exception = e

    if exception:
        assert result == expected_result_0
    else:
        assert False


# Generated at 2022-06-25 23:49:02.710368
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    # Arrange
    bytes_0 = b'12345'
    lazy_0 = Lazy(bytes_0)

    # Act
    result = lazy_0.bind(lambda x: Lazy(lambda: Box(x)))

    # Assert
    assert result.get() == Box(bytes_0)

    # Arrange
    int_0 = 12345
    lazy_0 = Lazy(int_0)

    # Act
    result = lazy_0.bind(lambda x: Lazy(lambda: Box(x)))

    # Assert
    assert result.get() == Box(int_0)

    # Arrange
    int_0 = 12345
    lazy_0 = Lazy(int_0)

    # Act

# Generated at 2022-06-25 23:49:12.780612
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b's'
    bytes_1 = b'\x1f'
    bytes_2 = b'dF\x11'
    bytes_3 = b'\x10\x1e\xe4'
    bytes_4 = b'\x00'
    int_0 = Lazy.of(bytes_0)
    int_1 = Lazy.of(bytes_1)
    int_2 = Lazy.of(bytes_2)
    int_3 = Lazy.of(bytes_3)
    int_4 = Lazy.of(bytes_4)

# Generated at 2022-06-25 23:49:21.569539
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test Lazy.bind method.
    """
    from typing import Callable
    str_0 = 'EQ'
    bytes_0 = b'tK\x01\xe1\xc9\x82m'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(bytes_0)
    lazy_2 = Lazy(str_0)
    assertion_0 = lazy_2.constructor_fn
    assertion_1 = lazy_1.constructor_fn
    assertion_2 = lazy_0.constructor_fn
    fn_0 = lazy_0.bind(lambda arg_0: lazy_1.bind(lambda arg_1: lazy_2))
    assert fn_0.constructor_fn == assertion_0

# Generated at 2022-06-25 23:49:26.021645
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\x0b\x15\x04\x1b\x0c\x1e'
    lazy_0 = Lazy(bytes_0)

    bytes_1 = b'\x0b\x15\x04\x1b\x0c\x1e'
    lazy_1 = Lazy(bytes_1)

    assert lazy_0 == lazy_1



# Generated at 2022-06-25 23:49:28.985757
# Unit test for method map of class Lazy
def test_Lazy_map():
    from random import randint

    func = lambda x: x * 2
    value = randint(0, 20)
    lazy = Lazy(lambda x: x)

    assert lazy.map(func).get(value) == func(value)



# Generated at 2022-06-25 23:49:37.093019
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = lazy_0.map(lambda arg_0: arg_0)

    if bytes_0 != lazy_1.get():
        raise AssertionError()


# Generated at 2022-06-25 23:49:42.107360
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test_case_1():
        def map_fn(value): return 1 + value

        lazy_0 = Lazy.of(2)
        lazy_1 = lazy_0.map(map_fn)

        assert lazy_1.get() == 3

    def test_case_2():
        def map_fn(value): return 1 + value

        lazy_0 = Lazy.of(2)
        lazy_1 = lazy_0.map(map_fn)

        assert lazy_1.get() == 3

# Generated at 2022-06-25 23:49:53.993795
# Unit test for method bind of class Lazy

# Generated at 2022-06-25 23:50:05.768778
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    bytes_0 = b'\x1c\x15\x05\x0c\t'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = lazy_0.to_box()
    box_0 = Box(b'\x0e\x13')
    box_1 = lazy_1.ap(box_0)
    assert isinstance(box_1, Box)
    assert box_1.unbox() == b'\x1c\x15\x05\x0c\x0e\x13'


# Generated at 2022-06-25 23:50:28.513692
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pymonet.monad_try
    import pymonet.monad_validation
    import pymonet.lazy
    import pymonet.box
    import pymonet.either
    import pymonet.maybe
    import sys
    import random
    import string
    def random_string(bits):
        return ''.join(random.choice(string.ascii_lowercase) for _ in range(bits))
    def raise_validation_error(error):
        raise ValueError(error)
    def validation_fail_fn():
        try:
            raise_validation_error('ValidationError')
        except Exception as error:
            return pymonet.monad_validation.fail(str(error))