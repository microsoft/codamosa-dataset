

# Generated at 2022-06-25 23:40:29.102414
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_a = Lazy.of(0)
    assert lazy_a.get() == 0


# Generated at 2022-06-25 23:40:39.068810
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    For not empty Lazy result of applying function from applicative to value from Lazy.
    For empty Lazy the same empty Lazy returned.

    :returns: True
    :rtype: bool
    """
    asserts_0 = Lazy.of(lambda x: x + 1).ap(Lazy.of(2)) == Lazy.of(3)
    asserts_1 = Lazy.of(lambda x: x + 1).ap(Lazy.of(2)).get() == 3
    asserts_2 = Lazy.of(lambda x: x + 1).ap(Lazy.of(2)).is_evaluated is True
    asserts_3 = Lazy.of(lambda x: x + 1).ap(Lazy.of(2)).constructor_fn(2) == 3

# Generated at 2022-06-25 23:40:46.752844
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = "&z\nI'Ow\n"
    lazy_0 = Lazy.of(str_0)

    def fn_1(*args):
        str_0 = args[0]
        str_1 = str_0.encode()
        lazy_1 = Lazy.of(str_1)

        return lazy_1

    lazy_1 = lazy_0.bind(fn_1)
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.constructor_fn("test") == "test".encode()


# Generated at 2022-06-25 23:40:51.796903
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # init value
    str_0 = "&z\nI'Ow\n"
    lazy_0 = Lazy(str_0)
    # init other
    str_1 = "&z\nI'Ow\n"
    lazy_1 = Lazy(str_1)
    # init other
    str_2 = "Ow\n"
    lazy_2 = Lazy(str_2)
    # call __eq__
    eq = lazy_0 == lazy_1
    # validate __eq__ result
    assert eq
    # call __eq__
    eq = lazy_0 == lazy_2
    # validate __eq__ result
    assert not eq


# Generated at 2022-06-25 23:41:01.309085
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Success, Failure
    from pymonet.validation import Validation, Success as ValSuccess, Failure as ValFailure

    assert Lazy(lambda: "box").bind(lambda x: Box(x)).get() == Box("box")
    assert Lazy(lambda: "either").bind(lambda x: Right(x)).get() == Right("either")
    assert Lazy(lambda: "maybe").bind(lambda x: Maybe.just(x)).get() == Maybe.just("maybe")
    assert Lazy(lambda: "success").bind(lambda x: Success(x)).get() == Success("success")

# Generated at 2022-06-25 23:41:07.324929
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = "&z\nI'Ow\n"
    str_1 = str_0.replace('\n', 'M')
    lazy_0 = Lazy(str_0)
    lazy_1 = Lazy(str_1)
    assert(
        lazy_0.bind(lambda str_2: Lazy.of(str_2.replace('\n', 'M'))).get() == \
        lazy_1.get()
    )


# Generated at 2022-06-25 23:41:11.321476
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy.of(None)

    assert lazy_0.__eq__(Lazy.of(None)) == True
    assert lazy_0.__eq__(Lazy.of(None).fold()) == True
    assert lazy_0.__eq__(Lazy.of(None).map(str)) == True
    assert lazy_0.__eq__(Lazy.of(23)) == False
    assert lazy_0.__eq__(str) == False
    assert lazy_0.__eq__(2) == False


# Generated at 2022-06-25 23:41:20.937105
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # when:
    str_0 = "&z\nI'Ow\n"
    lazy_0 = Lazy(str_0)
    lazy_1 = lazy_0.map(lambda arg_1: arg_1[1])
    lazy_2 = lazy_1.map(lambda arg_1: arg_1[1])
    lazy_3 = lazy_2.map(lambda arg_1: arg_1[1])
    lazy_4 = lazy_3.map(lambda arg_1: arg_1[1])
    lazy_5 = lazy_4.map(lambda arg_1: arg_1[1])
    lazy_6 = lazy_5.map(lambda arg_1: arg_1[1])
    lazy_7 = lazy_6.map(lambda arg_1: arg_1[1])
    lazy

# Generated at 2022-06-25 23:41:24.796319
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda *args: 1).map(lambda x, y: x + y(2)).get() == 1
    assert Lazy(lambda *args: 1).map(lambda x, y: x + y(2)).constructor_fn(2) == 1


# Generated at 2022-06-25 23:41:33.881776
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_0 = Lazy(lambda: 0)
    assert lazy_0.get() == 0
    assert lazy_0.get() == 0
    assert lazy_0.get() == 0
    str_0 = "&z\nI'Ow\n"
    lazy_0 = Lazy(str_0)
    assert lazy_0.get() == str_0
    assert lazy_0.get() == str_0
    assert lazy_0.get() == str_0
    assert lazy_0.get() == str_0
    assert lazy_0.get() == str_0
    assert lazy_0.get() == str_0
    assert lazy_0.get() == str_0
    assert lazy_0.get() == str_0
    assert lazy_0.get() == str_0
    assert lazy_0

# Generated at 2022-06-25 23:41:43.456823
# Unit test for method get of class Lazy
def test_Lazy_get():
    # case 0
    def lazy_creator_fn_0():
        return 42
    lazy_0 = Lazy(lazy_creator_fn_0)
    assert lazy_0.get() == 42
    # case 1
    def lazy_creator_fn_1():
        return "John"
    lazy_1 = Lazy(lazy_creator_fn_1)
    assert lazy_1.get() == "John"
    # case 2
    def lazy_creator_fn_2():
        return None
    lazy_2 = Lazy(lazy_creator_fn_2)
    assert lazy_2.get() is None


# Generated at 2022-06-25 23:41:44.818974
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy.of(9)
    assert lazy.get() == 9


# Generated at 2022-06-25 23:41:52.376892
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Just
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def increment(value):
        return value + 1

    def decrement(value):
        return value - 1

    def square(value):
        return value**2

    assert Lazy.of(0).map(increment).get() == increment(0)

    assert Lazy.of(0).map(increment).map(decrement).get() == decrement(increment(0))
    assert Lazy.of(0).map(increment).map(decrement).map(square).get() == square(decrement(increment(0)))


# Generated at 2022-06-25 23:41:55.128275
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    actual_0 = Lazy.of(int_0)
    actual_1 = Lazy.of(int_0)
    expected_0 = actual_0 == actual_1
    assert expected_0



# Generated at 2022-06-25 23:42:01.437692
# Unit test for method map of class Lazy
def test_Lazy_map():
    first_argument = 100
    second_argument = 200

    def add_const(x: int, const: int) -> int:
        return x + const

    def substract_const(x: int, const: int) -> int:
        return x - const

    lazy = Lazy(lambda: add_const(first_argument, second_argument))
    assert first_argument + second_argument != lazy.get()

    lazy = lazy.map(lambda x: substract_const(x, second_argument))
    assert lazy.get() == first_argument

    # Ensure Lazy is immutable
    assert lazy.map(lambda x: x + 1).get() == first_argument + 1
    assert lazy.map(lambda x: x + 1).get() != first_argument
    assert lazy.get() == first_argument


# Generated at 2022-06-25 23:42:06.915182
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given
    fn = lambda x: x
    input_0 = Lazy(fn)

    # When
    input_1 = input_0.map(fn)

    # Then
    assert input_1.is_evaluated == input_0.is_evaluated
    assert input_1.value == input_0.value
    assert input_1.constructor_fn == fn



# Generated at 2022-06-25 23:42:18.431902
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 0
    int_100 = 100

    def f(*args):
        return int_0

    lazy = Lazy(f)

    assert lazy.map(lambda x: x + 1).get() == 1
    assert lazy.map(lambda x: x * 10).get() == 0
    assert lazy.map(lambda x: 'A' * x).get() == ''
    assert lazy.map(lambda x: bool(x)).get() is False
    assert lazy.map(lambda x: x + int_100).get() == int_100
    assert lazy.map(lambda x: [x]).get() == [int_0]
    # second call
    assert lazy.map(lambda x: x + 1).get() == 1
    assert lazy.map(lambda x: x * 10).get() == 0
    assert lazy.map

# Generated at 2022-06-25 23:42:29.850866
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test checks:
        - if Lazy memoized result of constructor_fn
        - if Lazy return memoized value
    """
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4

    def add_one(value):
        return value + 1

    def multiply_by_two(value):
        return value * 2

    def error_generator():
        raise Exception('Exception')

    Lazy.of(int_0).get() == int_0
    Lazy.of(int_0).map(add_one).get() == int_1
    Lazy.of(int_0).map(add_one).map(multiply_by_two).get() == int_2

# Generated at 2022-06-25 23:42:32.951316
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right

    def test_fn_1(a):
        return a + 1

    assert Lazy.of(5).ap(Lazy.of(test_fn_1)).get() == 6


# Generated at 2022-06-25 23:42:36.172035
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_add = Lazy(lambda x, y: x + y)

    lazy_add10 = lazy_add.bind(lambda x: Lazy(lambda: x + 10))
    assert lazy_add10.constructor_fn(1, 2) == 13



# Generated at 2022-06-25 23:42:45.271885
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    function_to_map = lambda x, y: Maybe.just(x + y)
    function_in_lazy = Maybe.just(1)
    lazy_map_to_return = 2
    lazy_of_maybe = Lazy(function_in_lazy)
    lazy_of_mapped_maybe = Lazy.of(lazy_map_to_return).map(function_to_map)

    assert(lazy_of_maybe.map(function_to_map).get(Box(1)) == lazy_of_mapped_maybe.get(Box(1)))


# Generated at 2022-06-25 23:42:48.279532
# Unit test for method map of class Lazy
def test_Lazy_map():

    int_10 = 10

    def double(x: int) -> int:
        return x * 2

    assert(Lazy(lambda: int_10).map(double).get() == int_10 * 2)


# Generated at 2022-06-25 23:42:56.839116
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # mock int_0
    int_0 = 0
    # mock function function_int_0
    def function_int_0(x):
        return x + 1

    # mock Lazy lazy_int_0=0
    lazy_int_0 = Lazy.of(int_0)
    # mock Lazy lazy_function_int_0=function_int_0
    lazy_function_int_0 = Lazy.of(function_int_0)

    # test bind of Lazy lazy_int_0
    assert lazy_int_0.bind(lazy_function_int_0).get() == 1


# Generated at 2022-06-25 23:43:05.537260
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_case_0():
        def f():
            return 1
        l = Lazy(f)
        assert l.get() == 1

    def test_case_1():
        def f():
            return 2
        l = Lazy(f)
        assert l.get() == 2

    test_case_0()
    test_case_1()


# Generated at 2022-06-25 23:43:06.837789
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1


# Generated at 2022-06-25 23:43:10.882664
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    test_val1 = Lazy.of(3)
    test_val2 = Lazy.of(lambda a: a * 3)
    res_val = test_val1.ap(test_val2)
    expected_res_val = 9
    assert res_val.get() == expected_res_val


# Generated at 2022-06-25 23:43:18.453544
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_either_const_success = Lazy.of(Either.success(12))
    lazy_either_const_fail = Lazy.of(Either.fail(12))

    lazy_either_return_success_int = Lazy.of(Either.success(int))
    lazy_either_return_fail_int = Lazy.of(Either.fail(int))

    assert lazy_either_return_success_int.ap(lazy_either_const_success).get() == Either.success(12)
    assert lazy_either_return_fail_int.ap(lazy_either_const_fail).get() == Either.fail(12)


# Generated at 2022-06-25 23:43:24.885516
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from math import sqrt
    from pymonet.box import Box

    lazy_2_fn = lambda: 2
    lazy_sqrt_fn = lambda: sqrt
    lazy_2 = Lazy(lazy_2_fn)
    lazy_sqrt = Lazy(lazy_sqrt_fn)

    assert lazy_2.ap(lazy_sqrt).get() == 1

    lazy_of_sqrt = lazy_sqrt.bind(Box.of)
    assert lazy_2.ap(lazy_of_sqrt).get() == 1


# Generated at 2022-06-25 23:43:32.416429
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    test_cases = [
        (2, 3, Lazy.of(lambda a, b: a + b).ap(Lazy.of(2)), 5),
        (2, 3, Lazy.of(lambda a, b: a + b).ap(Lazy.of(2)).ap(Lazy.of(3)), 5),
    ]
    for args, lazy, expected in test_cases:
        assert lazy.get(*args) == expected


# Generated at 2022-06-25 23:43:36.637654
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_a = Lazy(lambda a: a)
    lazy_b = lazy_a.ap(lazy_a)
    assert isinstance(lazy_b, Lazy)
    assert lazy_b.constructor_fn() == lazy_a.constructor_fn()


# Generated at 2022-06-25 23:43:40.426883
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(5).bind(lambda value: Lazy.of(10)) == Lazy.of(10)



# Generated at 2022-06-25 23:43:43.817579
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def unit_test_case_0():
        def bind_function_0(x):
            assert x is None
            return Lazy(lambda: x)

        Lazy(lambda: None).bind(bind_function_0).get()

    unit_test_case_0()


# Generated at 2022-06-25 23:43:48.378153
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_10 = Lazy(lambda: 10)

    def add_10(x):
        return Lazy(lambda: x + 10)

    def divide_10(x):
        return Lazy(lambda: x / 10)

    result = int_10.bind(add_10).bind(divide_10)

    assert result.get() == 2

    assert int_10.get() == 10


# Generated at 2022-06-25 23:43:59.851397
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.either import Either
    result = Maybe.just(2).map(lambda x: Lazy.of(x + 1)).fold(
        lambda v: v + 1,
        lambda v: v + 1
    )
    assert result == 4
    result = Validation.success(2).map(lambda x: Lazy.of(x + 1)).fold(
        lambda v: v + 1,
        lambda v: v + 1
    )
    assert result == 4

# Generated at 2022-06-25 23:44:03.452591
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = Lazy.of(0)
    int_result = int_0.bind(lambda x: Lazy.of(x + 1))
    assert (str(int_result) == "Lazy[fn=<function Lazy.bind.<locals>.<lambda> at 0x10a0ebea0>, value=None, is_evaluated=False]")
    test_case_0()

    def add(x):
        return Lazy.of(x + 1)


    int_result = int_0.bind(add)
    assert (str(int_result) == "Lazy[fn=<function Lazy.bind.<locals>.<lambda> at 0x10a0ec048>, value=None, is_evaluated=False]")
    test_case_0()


# Generated at 2022-06-25 23:44:11.155784
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = Lazy(lambda : 0)
    str_1 = Lazy(lambda : 1)
    int_2 = Lazy(lambda : 2)

    assert int_0.bind(lambda x: int_1) == int_1

    int_0 = Lazy(lambda : 0)
    str_1 = Lazy(lambda : 1)
    int_2 = Lazy(lambda : 2)

    assert int_0.bind(lambda x: str_1) == str_1

    str_0 = Lazy(lambda : 0)
    str_1 = Lazy(lambda : 1)
    int_2 = Lazy(lambda : 2)

    assert str_0.bind(lambda x: int_1) == int_1

    str_0 = Lazy(lambda : 0)

# Generated at 2022-06-25 23:44:16.041995
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(0).get() == 0
    assert Lazy(lambda x: x).get(0) == 0
    assert Lazy(lambda: 0).get() == 0
    assert Lazy(lambda: test_case_0()).get() is None
    assert Lazy(test_case_0).get() is None


# Generated at 2022-06-25 23:44:20.780165
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_int = Lazy(lambda: int_0 + 1)
    lazy_str1 = lazy_int.bind(lambda i: Lazy(lambda: str(i)))
    lazy_str2 = lazy_str1.bind(lambda s: Lazy(lambda: s + ' hello'))
    if lazy_str2.get() != '1 hello':
        raise Exception('method bind of class Lazy is broken')


# Generated at 2022-06-25 23:44:26.159493
# Unit test for method map of class Lazy
def test_Lazy_map():
    '''
    Test map.

    Test Lazy.map() method.

    :returns: Nothing
    :rtype: None
    '''
    # given
    def fn(a):
        return a + 1

    # when
    result = Lazy(lambda x: x).map(fn)

    # then
    assert result == Lazy.of(1)


# Generated at 2022-06-25 23:44:29.054974
# Unit test for method get of class Lazy
def test_Lazy_get():
    test_case_0()
    #assert Lazy.of(0).get() == 0
    print(Lazy.of(0).get())
    print(Lazy.of(10).get())


# Generated at 2022-06-25 23:44:37.055305
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(0).get() == 0
    assert Lazy.of(1).get() == 1
    assert Lazy.of(2).get() == 2
    assert Lazy.of(3).get() == 3
    assert Lazy.of(4).get() == 4
    assert Lazy.of(5).get() == 5
    assert Lazy.of(6).get() == 6
    assert Lazy.of(7).get() == 7
    assert Lazy.of(8).get() == 8
    assert Lazy.of(9).get() == 9



# Generated at 2022-06-25 23:44:39.719853
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x: x + 0).ap(Lazy(lambda x: x - 3)) == Lazy(lambda x: x + 0).ap(Lazy(lambda x: x - 3))

# Generated at 2022-06-25 23:44:42.593260
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 0
    lazy_0 = Lazy.of(int_0)
    assert lazy_0 == Lazy.of(int_0)

# Generated at 2022-06-25 23:44:46.461095
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Given
    int_0 = Lazy(lambda: 0)

    # When
    result = int_0.bind(lambda x: Lazy(lambda: x + 1))

    # Then
    assert result.get() == 1


# Generated at 2022-06-25 23:44:49.983753
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import math

    my_abs = lambda value: Lazy(abs)
    double = lambda value: Lazy(lambda x: x * 2)

    lazy = Lazy(math.sin).bind(my_abs).bind(double).get(2)

    assert lazy == 2



# Generated at 2022-06-25 23:44:51.907520
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == Lazy(lambda: 1).get() == 1



# Generated at 2022-06-25 23:44:57.069703
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 4

    def f(int_a):
        return Lazy(lambda: int_a + int_0)

    int_b = Lazy.of(1).bind(f).get()

    assert int_b == 5

    int_b = Lazy.of(2).bind(f).get()

    assert int_b == 6

    int_b = Lazy.of(22).bind(f).get()

    assert int_b == 26


# Generated at 2022-06-25 23:45:01.933879
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy(test_case_0)

    eq = lazy_0 == lazy_0
    assert eq is True

    lazy_1 = Lazy(test_case_0)

    eq = lazy_0 == lazy_1
    assert eq is True

    lazy_2 = Lazy(test_case_0)
    lazy_2._compute_value()

    eq = lazy_0 == lazy_2
    assert eq is False

# Generated at 2022-06-25 23:45:12.536433
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Asserting method get of class Lazy
    """
    # Given
    int_0 = Lazy.of(0)
    func = lambda x: x + 1
    int_1 = int_0.map(func)
    int_2 = int_1.map(func)
    int_3 = int_2.map(func)
    int_4 = int_3.map(func)

    # When
    result_0 = int_0.get()
    result_1 = int_1.get()
    result_2 = int_2.get()
    result_3 = int_3.get()
    result_4 = int_4.get()

    # Then
    assert result_0 == 0
    assert result_1 == 1
    assert result_2 == 2
    assert result_3 == 3

# Generated at 2022-06-25 23:45:14.897963
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(int_0) == Lazy.of(int_0)



# Generated at 2022-06-25 23:45:27.641466
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    f = lambda x: x + 1
    lazy = Lazy.of(1)
    assert lazy.map(f).get() == f(lazy.get()) == 2

    box = Box(1)
    assert box.map(f).get() == f(box.get()) == 2

    maybe = Maybe.just(1)
    assert maybe.map(f).get() == f(maybe.get()) == 2

    either = Right(1)
    assert either.map(f).get() == f(either.get()) == 2

    try_ = Try.of(lambda *args: 1)
   

# Generated at 2022-06-25 23:45:38.448321
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # define test data
    input_0 = Lazy(lambda: int_0)
    input_1 = Lazy(lambda: int_1)
    input_2 = Lazy(lambda: int_2)
    input_3 = Lazy(lambda: int_3)
    input_4 = Lazy(lambda: int_4)
    input_5 = Lazy(lambda: int_5)
    input_6 = Lazy(lambda: int_6)
    input_7 = Lazy(lambda: int_7)
    input_8 = Lazy(lambda: int_8)
    input_9 = Lazy(lambda: int_9)

    # define correct result
    correct_result = Lazy(lambda: int(0))

    # call test function
    result = Lazy(lambda int_0: int(0)).bind

# Generated at 2022-06-25 23:45:44.922831
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import random

    # Generate random float number in range from 0 to 10
    float_number = random.uniform(0.00, 10.0)

    # Create Lazy with float number
    lz_float_number = Lazy.of(float_number)

    # Create Lazy with function to convert float to int
    lz_float_to_int = Lazy.of(lambda value: int(value))

    lz_int_number = lz_float_number.ap(lz_float_to_int)
    assert lz_int_number.get() == int(float_number)
    assert lz_int_number.constructor_fn() == int(float_number)

    # Convert Lazy to Box
    box_lz_int_number = lz_int_number.to_box()
   

# Generated at 2022-06-25 23:45:51.874120
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Test case 0
    int_0 = Lazy.of(0)
    int_1 = int_0.bind(lambda x: Lazy.of(x + 1))
    assert int_1.get() == 1
    assert int_1.is_evaluated == True
    assert int_0.is_evaluated == False
    assert int_0.get() == 0
    assert int_0.is_evaluated == True


# Generated at 2022-06-25 23:45:56.013387
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for Lazy constructor
    """
    def fn():
        return int_0

    lazy = Lazy.of(fn)

    result = lazy.bind(lambda x: Lazy.of(x))
    expected = Lazy(lambda: int_0)

    assert result == expected


# Generated at 2022-06-25 23:46:05.208227
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = Lazy.of(0)
    assert int_0.get() == 0

    def method_0(val: int) -> int:
        return val

    int_1 = Lazy.of(method_0)
    assert int_1.get(0) == 0

    int_2 = Lazy.of(method_0).map(lambda val: val + 1)
    assert int_2.get(0) == 1

    int_3 = Lazy.of(method_0).map(lambda val: val + 1).map(lambda val: val + 1)
    assert int_3.get(0) == 2

    msg_0 = 'test 0 error'
    def method_1(val: int) -> None:
        raise ValueError(msg_0)


# Generated at 2022-06-25 23:46:07.306848
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy.of(1)

    def fn(v) -> Lazy[Lazy[int], int]:
        return Lazy.of(v * 2)

    assert lazy.bind(fn).get() == 2



# Generated at 2022-06-25 23:46:10.874020
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = Lazy(lambda: 0)
    assert int_0.get() == 0

    int_0 = Lazy(lambda: 0)
    assert int_0.get() == 0

    int_2 = Lazy(lambda: 1 / 0)
    assert int_2.get() == ZeroDivisionError


# Generated at 2022-06-25 23:46:15.188123
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add(a):
        return a + 1

    lazy_add_one = Lazy(add).map(add)

    assert lazy_add_one.get(0) == 2
    assert lazy_add_one.get(5) == 7
    assert lazy_add_one.get(10) == 12


# Generated at 2022-06-25 23:46:18.149505
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # when:
    lazy = Lazy.of(2)
    lazy_ = Lazy.of(lambda x: x * 2).ap(lazy)
    result = lazy_.get()

    # then:
    assert result == 4



# Generated at 2022-06-25 23:46:23.695247
# Unit test for method get of class Lazy
def test_Lazy_get():
    a = Lazy.of(2)

    assert a.get() == 2
    assert a.get(3) == 2


# Generated at 2022-06-25 23:46:30.489281
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = Lazy.of(0).get()
    assert int_0 == 0
    string_0 = Lazy.of('0').get()
    assert string_0 == '0'
    list_0 = Lazy.of(['0']).get()
    assert list_0 == ['0']
    list_0_0 = Lazy.of(['0']).get()
    assert list_0_0 == ['0']
    list_0_1 = Lazy.of(['0']).get()
    assert list_0_1 == ['0']


# Generated at 2022-06-25 23:46:33.302138
# Unit test for method get of class Lazy
def test_Lazy_get():
    def int_adder(a: int, b: int) -> int:
        return a + b

    lazy = Lazy(int_adder)
    lazy_mapped = lazy.map(int_adder)
    assert (
        lazy_mapped.get(2, 3) == lazy.get(2, 3)
    ), 'Lazy must return same result of get method as mapped Lazy'


# Generated at 2022-06-25 23:46:37.504925
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    constructor_fn = lambda *args: 10
    fn = lambda value: Lazy(lambda *args: value + 5)

    lazy = Lazy(constructor_fn)
    lazy_mapped = lazy.bind(fn)
    assert lazy_mapped.get() == 15


# Generated at 2022-06-25 23:46:41.713625
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def fn_0():
        return None

    def fn_1(value):
        return Box(value)

    lazy = Lazy(fn_0)
    bound = lazy.bind(fn_1)

    assert bound(5) == Box(None)


# Generated at 2022-06-25 23:46:51.107909
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left
    from pymonet.validation import Success, Failure


    # Lazy with int
    int_0 = Lazy.of(0)
    print('test_Lazy_map - int_0: {}'.format(int_0))
    assert int_0
    assert int_0.is_evaluated is False
    assert int_0.get() == 0
    assert int_0.is_evaluated is True

    # Lazy with str
    str_0 = Lazy.of('0')
    print('test_Lazy_map - str_0: {}'.format(str_0))
    assert str_0
    assert str_0.is_evaluated is False
    assert str_0

# Generated at 2022-06-25 23:46:57.393889
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_fn = Lazy(lambda x: x + 1)
    lazy_arg = Lazy.of(1)

    assert lazy_arg.ap(lazy_fn) == Lazy(lambda: 2)
    assert lazy_arg.ap(Lazy.of(3)) != Lazy(lambda: 2)
    assert Lazy.of((lambda x: x + 1)).ap(lazy_arg) == Lazy(lambda: 2)


# Generated at 2022-06-25 23:47:07.908017
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_1_to_integer(arg):
        return Lazy.of(arg + 1)

    lazy_int_0 = Lazy.of(0)
    assert lazy_int_0.bind(add_1_to_integer).get() == 1, "should return 1"

    is_called = False
    lazy_floating_1_0 = Lazy(lambda *args: is_called)

    def function_with_side_effects(*args):
        nonlocal is_called
        is_called = True

    lazy_floating_1_0.bind(function_with_side_effects).get()
    assert is_called, "function with side effects should be called"


# Generated at 2022-06-25 23:47:13.457450
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Given

    @raise_if_odd
    def raise_if_odd(number): return number

    def increment(number): return number + 1

    lazy_inc = Lazy(increment)

    # When
    result = lazy_inc.map(raise_if_odd)

    # Then
    assert result == Lazy(increment).map(raise_if_odd)


# Generated at 2022-06-25 23:47:19.425341
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 0
    double_5 = 5 * 2
    lazy_int = Lazy(lambda: int_0)
    add_5_lazy = lambda x: Lazy(lambda: x + 5)
    multiply_2_lazy = lambda x: Lazy(lambda: x * 2)

    lazy_5 = lazy_int.map(add_5_lazy).map(multiply_2_lazy)
    assert lazy_5.get() == double_5


# Generated at 2022-06-25 23:47:36.027707
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy(lambda x: x + 1)
    lazy_1 = Lazy(lambda x: x * 2)
    lazy_2 = Lazy(lambda x: x + 1)
    lazy_3 = Lazy.of(0)

    assert lazy_0.bind(lambda x: lazy_1).get() == lazy_0.get() * 2
    assert lazy_1.bind(lambda x: lazy_0).get() == lazy_0.get() + 1
    assert lazy_0.bind(lambda x: lazy_2).get() == lazy_0.get() + 1
    assert lazy_1.bind(lambda x: lazy_3).get() == lazy_3.get() * 2

# Generated at 2022-06-25 23:47:44.327864
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = Lazy.of(0)
    int_0_copy = Lazy.of(0)
    int_10 = Lazy.of(10)
    int_10_copy = Lazy.of(10)

    assert int_0 == int_0_copy
    assert int_10 == int_10_copy

    assert int_0 != int_10
    assert int_0 == Lazy(lambda *args: 0)

    float_0 = Lazy.of(0.0)
    float_0_copy = Lazy.of(0.0)
    float_10 = Lazy.of(10.0)
    float_10_copy = Lazy.of(10.0)

    assert float_0 == float_0_copy
    assert float_10 == float_10_copy

    assert float_0

# Generated at 2022-06-25 23:47:48.301119
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = Lazy.of(0)

    assert int_0.get() == 0

    int_1 = Lazy.of(1)

    assert int_1.get() == 1

    int_2 = Lazy.of(2)

    assert int_2.get() == 2



# Generated at 2022-06-25 23:47:49.911418
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert 'x' == Lazy(lambda: 0).map(lambda x: 'x').get()


# Generated at 2022-06-25 23:47:51.164871
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(0).get() == 0


# Generated at 2022-06-25 23:47:57.800651
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    a = Lazy.of(2)
    b = Lazy.of(3)
    c = Lazy.of(5)

    assert Box(a.bind(lambda x: b.bind(lambda y: c.bind(lambda z: Lazy.of(x * y * z)))).get()).equals(Box(30))



# Generated at 2022-06-25 23:48:00.459101
# Unit test for method get of class Lazy
def test_Lazy_get():
    input_data = """
        int_0 = 0
        lazy_0 = Lazy.of(int_0)
        result_0 = lazy_0.get()
    """
    assert int_0 == result_0



# Generated at 2022-06-25 23:48:03.132031
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 0
    assert Lazy.of(int_0).map(lambda x: x + 1).get() == 1


# Generated at 2022-06-25 23:48:12.253751
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Test 0
    int_0 = Lazy.of(0)
    int_1 = int_0.map(lambda x: x + 1)

    assert int_0 != int_1
    assert int_0.get() == 0
    assert int_1.get() == 1

    # Test 1
    int_0 = Lazy.of(0)
    int_5 = int_0.map(lambda x: 5)
    int_1 = int_0.map(lambda x: x + 1)

    assert int_0 != int_1
    assert int_0 != int_5
    assert int_1 != int_5
    assert int_0.get() == 0
    assert int_1.get() == 1
    assert int_5.get() == 5

    # Test 2
    test_case_0()



# Generated at 2022-06-25 23:48:21.883477
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    # Generates Lazy(function) with function returning first argument
    int_0 = Lazy.of(0)

    # Lazy(add_by_0) contains function adding 0 to argument
    add_by_0 = lambda x: x + 0

    # Function to call add_by_0 function with argument 0
    add_by_0_0 = lambda _: Lazy.of(add_by_0(0))

    # Lazy(add_by_0_0) contains function add_by_0_0
    add_by_0_0_ = Lazy(add_by_0_0)

    # ap method call add_by_0 function with argument 0
    result = int_0.ap(add_by_0_0_)

    # Evaluated result must be 0
    assert result.get() == 0




# Generated at 2022-06-25 23:48:36.879349
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    no_expected = '__no_expected__'
    constructor_fn = lambda *args: int_0
    test_lazy = Lazy(constructor_fn)
    val_to_check = test_lazy.ap(Lazy.of(1))
    assert no_expected == val_to_check.value
    assert 1 == val_to_check.constructor_fn()
    assert True == val_to_check.is_evaluated
    assert False == test_lazy.is_evaluated
    assert constructor_fn == test_lazy.constructor_fn
    assert no_expected == test_lazy.value


# Generated at 2022-06-25 23:48:41.622759
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test method Lazy.map
    """
    # call map with function incrementing argument
    assert Lazy.of(0).map(lambda x: x + 1) == Lazy(lambda *args: 0 + 1)
    assert Lazy.of(0).map(lambda x: x + 1).map(lambda x: x + 2) == Lazy(lambda *args: 0 + 1 + 2)



# Generated at 2022-06-25 23:48:50.908980
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    try:
        from pymonet.monad_try import Try
        from pymonet.validation import Validation
    except:
        pass

    def add_one(n):
        def inner_add_one(*args):
            return n + 1
        return Lazy(inner_add_one)

    def divide_by_zero(x):
        def inner_divide_by_zero(*args):
            return arg / arg
        return Lazy(inner_divide_by_zero)

    result_1 = Lazy.of(1).bind(add_one).get(1)
    result_2 = Lazy.of(1).bind(add_one).bind(add_one).get(1)
    result_3 = Lazy.of(3).bind(divide_by_zero).get(4)
   

# Generated at 2022-06-25 23:49:00.190029
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Assert that after two mappers the value of constructor_fn will be 8
    assert Lazy.of(2).map(math.pow).map(lambda x: x * 2).get() == 8
    # Assert that after calling mapper the value of constructor_fn will be 4
    assert Lazy.of(6).map(lambda x: x % 4).get() == 2
    # Assert that after two mappers the value of constructor_fn will be 0
    assert Lazy.of(1).map(math.pow).map(lambda x: x - 1).get() == 0
    # Assert that the value of constructor_fn will be 6
    assert Lazy.of(1).map(lambda x: 6).get() == 6
    # Assert that the value of constructor_fn will be 0

# Generated at 2022-06-25 23:49:05.569843
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    test_cases = [
        {
            'name': 'None',
            'inputs': [
                Lazy.of,
                None
            ],
            'expected': Lazy.of(None)
        },
        {
            'name': 'Empty',
            'inputs': [
                Lazy.of,
                Lazy.of(None)
            ],
            'expected': Lazy.of(None)
        },
        {
            'name': 'Not empty',
            'inputs': [
                Lazy.of,
                Lazy.of(lambda x: x*2)
            ],
            'expected': Lazy.of(2)
        }
    ]
    for test_case in test_cases:
        print(test_case['name'])

# Generated at 2022-06-25 23:49:16.130353
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.functor import Functor

    int_0 = Lazy.of(0)

    assert isinstance(int_0, Lazy)
    assert isinstance(int_0, Functor)
    assert isinstance(int_0, Generic)
    assert isinstance(int_0, Callable)

    assert int_0.is_evaluated is False
    assert int_0.value is None
    assert int_0.constructor_fn(int_0) is 0

    assert int_0.value is None
    assert int_0.is_evaluated is False

    int_1 = int_0.map(lambda x: x + 1)

    # constructor function changes
    assert int_1.constructor_fn(int_1) is 1

    # original value keep same
    assert int_0.constructor_

# Generated at 2022-06-25 23:49:23.541689
# Unit test for method map of class Lazy
def test_Lazy_map():
    def function_0(value):
        return value + 1

    lazy_0 = Lazy.of(0)
    lazy_1 = Lazy.of(0)

    assert lazy_0.get() == lazy_0.to_box().get()
    assert lazy_1.get() == lazy_1.to_box().get()

    assert lazy_0 == lazy_1
    assert lazy_0.is_evaluated == False
    assert lazy_1.is_evaluated == False

    lazy_2 = lazy_0.map(function_0)
    lazy_3 = lazy_1.map(function_0)

    assert lazy_2.get() == lazy_2.to_box().get()
    assert lazy_3.get() == lazy_3.to_box().get()

    assert lazy_2 != lazy_3


# Generated at 2022-06-25 23:49:27.563097
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(Lazy.of).get() == 1
    assert Lazy.of(0).bind(Lazy.of).get() == 0
    assert Lazy.of(None).bind(lambda value: Lazy.of(value)).get() == None

    print("test_Lazy_bind passed")



# Generated at 2022-06-25 23:49:29.142010
# Unit test for method get of class Lazy
def test_Lazy_get():

    int_0 = Lazy.of(0)

    assert int_0.get() == 0


# Generated at 2022-06-25 23:49:34.015448
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 0
    str_0 = '0'

    assert Lazy(lambda: int_0).map(str).get() == str_0
    assert Lazy(lambda: int_0).map(lambda x: str(x)).get() == str_0



# Generated at 2022-06-25 23:49:52.549459
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    import operator

    constructor_fn = operator.add
    assertion_fn = lambda a, b: a == b
    argument = [1, 2]
    expected_result = 3

    lazy_0 = Lazy(constructor_fn)
    lazy_1 = Lazy(constructor_fn)

    lazy_0_folded_value = lazy_0.get(*argument)
    lazy_1_folded_value = lazy_1.get(*argument)

    assert lazy_0 != lazy_1
    assert assertion_fn(lazy_0_folded_value, lazy_1_folded_value)
    assert assertion_fn(lazy_0_folded_value, expected_result)


# Generated at 2022-06-25 23:50:06.352033
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for bind method of Lazy class.
    This method is main method of Lazy
    """
    # With bind return Lazy[U, W] and function should return any type of function
    # fnc_2 have been processing result of fnc_1 and return new function
    fnc_1 = lambda x: x + 1
    fnc_2 = lambda x: lambda y: y + x
    # Function return argument multiplied by 5
    fnc_3 = lambda x: x * 5

    # First bind will executed and function will be stored for further execution
    lazy = Lazy.of(fnc_1).bind(fnc_2).bind(fnc_3)

    # Second bind will be executed and stored

# Generated at 2022-06-25 23:50:09.364842
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def get_int0() -> int:
        return 0

    def get_int1() -> int:
        return 1

    int_0 = Lazy.of(get_int0)
    int_1 = Lazy.of(get_int1)
    int_add_one = int_0.bind(lambda i: int_1)

    assert int_add_one.get() == int_0.get() + int_1.get()


# Generated at 2022-06-25 23:50:16.724944
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    test_case_0()

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) == Lazy(lambda x: 1)
    assert not (Lazy.of(1) == Lazy.of(2))
    assert not (Lazy.of(1) == Lazy(lambda x: 2))

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert not (Lazy(lambda: 1) == Lazy(lambda: 2))



# Generated at 2022-06-25 23:50:20.377435
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(2) != Lazy.of(1)
    assert Lazy.of(1).map(lambda x: x + 2) == Lazy.of(1 + 2)


# Generated at 2022-06-25 23:50:27.045626
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad import Just
    from pymonet.monad_try import Success

    value = Lazy(lambda x: x).ap(Just(3).bind(lambda x: Just(x + 1))).get()

    assert int == type(value)
    assert 4 == value

    value = Lazy(lambda x: x * 2).ap(Just(3)).get()

    assert int == type(value)
    assert 6 == value

    value = Lazy(lambda x: x * 2).ap(Success(3)).get()

    assert int == type(value)
    assert 6 == value
