

# Generated at 2022-06-25 23:40:20.989967
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of({}).__eq__(Lazy.of({})) is True
    assert Lazy.of(set()).__eq__(Lazy.of(set())) is True
    assert Lazy.of([]).__eq__(Lazy.of([])) is True
    assert Lazy.of('').__eq__(Lazy.of('')) is True
    assert Lazy.of(1).__eq__(Lazy.of(1)) is True
    assert Lazy.of({}).__eq__(Lazy.of(set())) is False
    assert Lazy.of({}).__eq__(Lazy.of([])) is False
    assert Lazy.of({}).__eq__(Lazy.of('')) is False
    assert Lazy.of({}).__eq__

# Generated at 2022-06-25 23:40:26.540547
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # CASE 0
    int_0 = True
    lazy_0 = Lazy(int_0)
    fn_0 = lambda x: Lazy(x)
    var_0 = lazy_0.bind(fn_0)
    assert var_0 == lazy_0
    # CASE 1
    int_1 = True
    lazy_1 = Lazy(int_1)
    fn_1 = lambda x: Lazy(x)
    var_1 = lazy_1.bind(fn_1)
    assert var_1 == lazy_1
    # CASE 2
    int_2 = True
    lazy_2 = Lazy(int_2)
    fn_2 = lambda x: Lazy(x)
    var_2 = lazy_2.bind(fn_2)
    assert var_2 == lazy_2
    # CASE 3

# Generated at 2022-06-25 23:40:37.547316
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from nose.tools import assert_equal

    class Test:
        @staticmethod
        def test_bind_0():
            int_0 = 1
            lazy_0 = Lazy(int_0)
            lazy_1 = lazy_0.bind(lambda x: Lazy(x + 1))
            var_0 = lazy_1.get()
            assert_equal(var_0, 2)

        @staticmethod
        def test_bind_1():
            int_0 = 1
            int_1 = 2
            lazy_0 = Lazy(int_0 + int_1)
            lazy_1 = lazy_0.bind(lambda x: Lazy(x + 1))
            var_0 = lazy_1.get()
            assert_equal(var_0, 4)


# Generated at 2022-06-25 23:40:47.601917
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_1 = True
    int_2 = True
    lazy_1 = Lazy(int_1)

    def lambda_1(var_1):
        def lambda_2():
            int_3 = True
            int_4 = True
            lazy_2 = Lazy(int_3)

            def lambda_3(var_2):
                int_5 = True
                lazy_3 = Lazy(int_5)

                def lambda_4(var_3):
                    int_6 = True
                    return Lazy(int_6)

                lazy_4 = lazy_3.bind(lambda_4)
                return lazy_4

            lazy_5 = lazy_2.bind(lambda_3)
            return lazy_5

        lazy_6 = Lazy(lambda_2)
        return lazy_6


# Generated at 2022-06-25 23:40:54.693186
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 2
    lazy_0 = Lazy(int_0)
    int_1 = 3
    lazy_1 = Lazy(int_1)
    lazy_2 = Lazy(int_1)
    lazy_3 = lazy_0.map(lambda int_2: int_2 + 2)
    assert not lazy_0 == lazy_1
    assert lazy_1 == lazy_2
    assert not lazy_1 == lazy_3


# Generated at 2022-06-25 23:41:00.886146
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_1 = Lazy(lambda: 1)
    lazy_2 = Lazy(lambda: 2)
    lazy_3 = Lazy(lambda: 1)
    lazy_4 = Lazy(lambda: 1)
    lazy_3._compute_value()
    lazy_4._compute_value()

    assert lazy_1 == lazy_1
    assert lazy_1 != lazy_2
    assert lazy_1 != lazy_3
    assert lazy_3 == lazy_4



# Generated at 2022-06-25 23:41:04.558987
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Test case 0
    int_0 = False
    lazy_0 = Lazy(int_0)
    try:
        var_0 = lazy_0.get()
    except Exception as e:
        var_0 = e


test_Lazy_get()

# Generated at 2022-06-25 23:41:07.501971
# Unit test for method map of class Lazy
def test_Lazy_map():
    # setup
    int = Lazy(lambda: 10)

    # exercise
    string = int.map(lambda number: str(number))

    # verify
    assert string.get() == '10'



# Generated at 2022-06-25 23:41:10.347746
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = True
    lazy_0 = Lazy(int_0)
    lazy_0 = lazy_0.bind(Lazy.of)
    lazy_0 = lazy_0.bind(Lazy.of)


# Generated at 2022-06-25 23:41:16.243809
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    :returns: result of test unit - if test fail or pass
    :rtype: boolean
    """

    l_0 = Lazy.of(lambda x: x + 1)
    l_1 = Lazy.of(1)
    n_0 = l_0.ap(l_1)

    is_eq_0 = n_0 == Lazy.of(2)
    ret_0 = is_eq_0

    return ret_0


# Generated at 2022-06-25 23:41:22.177492
# Unit test for method map of class Lazy
def test_Lazy_map():
    my_lazy = Lazy(lambda x: x + 1)
    mapped_lazy = my_lazy.map(lambda x: x * 2)

    assert mapped_lazy.get(2) == 6
    assert mapped_lazy.constructor_fn != my_lazy.constructor_fn


# Generated at 2022-06-25 23:41:26.437288
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy(bool)

    def fn_0(param_0):
        return Lazy(param_0)

    lazy_1 = lazy_0.bind(fn_0)
    lazy_2 = lazy_0.bind(fn_0).bind(fn_0)


# Generated at 2022-06-25 23:41:34.927791
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Case 0
    bool_0 = True
    lazy_0 = Lazy.of(bool_0)
    result_0 = lazy_0.get()
    expected_result_0 = True
    result_0 == expected_result_0
    # Case 1
    bool_1 = False
    lazy_1 = Lazy.of(bool_1)
    result_1 = lazy_1.get()
    expected_result_1 = False
    result_1 == expected_result_1
    # Case 2
    int_2 = 5
    lazy_2 = Lazy.of(int_2)
    result_2 = lazy_2.get()
    expected_result_2 = 5
    result_2 == expected_result_2
    # Case 3
    str_3 = 'a'

# Generated at 2022-06-25 23:41:41.131927
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.list import List
    from pymonet.funcs import compose

    lst_0 = List(1, 2, 3)

    def lst_1(elem):
        return List(elem)

    def lst_2(elem):
        return List(elem, elem)

    def sum_lst(lst):
        return lst.foldl(0)(lambda acc, element: acc + element)

    compose(sum_lst)(lst_0.map)(lst_2).get() == 12



# Generated at 2022-06-25 23:41:42.143835
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(True) == Lazy.of(True)


# Generated at 2022-06-25 23:41:50.031571
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    lazy1: Lazy[int, int] = Lazy(lambda x: x + 1)

    assert lazy1.map(lambda x: x * 2).get(4) == 10
    assert lazy1.map(lambda x: x * 2).get(4) == 10

    lazy: Lazy[int, int] = Lazy(lambda x: x + 1)

    assert lazy.map(lambda x: x * 2).get(4) == 10
    assert lazy.map(lambda x: x * 2).get(4) == 10


# Generated at 2022-06-25 23:41:58.726521
# Unit test for method get of class Lazy
def test_Lazy_get():
    # AssertionError: bool_0 != bool_0
    assert_raises(AssertionError, Lazy(bool_0).get, bool_0)

    # AssertionError: bool_1 != bool_1
    assert_raises(AssertionError, Lazy(bool_1).get, bool_1)

    # AssertionError: bool_2 != bool_2
    assert_raises(AssertionError, Lazy(bool_2).get, bool_2)

    # AssertionError: bool_3 != bool_3
    assert_raises(AssertionError, Lazy(bool_3).get, bool_3)

    # AssertionError: bool_4 != bool_4
    assert_raises(AssertionError, Lazy(bool_4).get, bool_4)

# Generated at 2022-06-25 23:42:08.667537
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bool_0 = True
    lazy_0 = Lazy(bool_0)
    bool_1 = True
    lazy_1 = Lazy(bool_1)

    assert lazy_0 == lazy_1
    assert lazy_1 == lazy_0

    bool_2 = False

    assert not (lazy_0 == Lazy(bool_2))
    assert not (lazy_1 == Lazy(bool_2))
    assert not (Lazy(bool_2) == lazy_0)
    assert not (Lazy(bool_2) == lazy_1)


# Generated at 2022-06-25 23:42:10.335933
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda v: Lazy.of(v)).get() == 1



# Generated at 2022-06-25 23:42:17.899240
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy(lambda: True)
    lazy_1 = Lazy(lambda: True)
    lazy_2 = Lazy(lambda: False)
    lazy_3 = Lazy(lambda: False)
    lazy_4 = Lazy(lambda: True)

    assert lazy_0 == lazy_1
    assert not (lazy_0 == lazy_2)
    assert lazy_2 == lazy_3
    assert lazy_1 == lazy_4



# Generated at 2022-06-25 23:42:30.963374
# Unit test for method get of class Lazy
def test_Lazy_get():
    bool_0 = True
    bool_1 = False
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = 0
    int_4 = 0
    int_5 = 0
    int_6 = 0
    int_7 = 0
    Lazy_0 = Lazy.of(int_0)
    Lazy_1 = Lazy.of(int_1)
    Lazy_2 = Lazy.of(int_2)
    Lazy_3 = Lazy.of(int_3)
    Lazy_4 = Lazy.of(int_4)
    Lazy_5 = Lazy.of(int_5)
    Lazy_6 = Lazy.of(int_6)
    Lazy_7 = Lazy.of(int_7)
   

# Generated at 2022-06-25 23:42:33.704233
# Unit test for method get of class Lazy
def test_Lazy_get():
    def bool_0_eq_true():
        return True
    Lazy.of(bool_0_eq_true).get()
    bool_0 = True
    assert bool_0


# Generated at 2022-06-25 23:42:37.441125
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_0 = Lazy(test_case_0)
    # Constructor function is not call at Lazy creation
    assert lazy_0.get() == None
    # Calling get calling constructor function and store result
    assert lazy_0.get() == None
    assert lazy_0.is_evaluated
    assert lazy_0.value != None



# Generated at 2022-06-25 23:42:41.734984
# Unit test for method map of class Lazy
def test_Lazy_map():
    bool_0 = Lazy.of(1).map(lambda x: x + 1)
    bool_1 = Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    bool_2 = isinstance(bool_0, Lazy)
    bool_3 = bool_0 == bool_1

    assert bool_2
    assert bool_3


test_case_0()
test_Lazy_map()

# Generated at 2022-06-25 23:42:42.557713
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    pass


# Generated at 2022-06-25 23:42:47.012271
# Unit test for method map of class Lazy
def test_Lazy_map():
    def plus_one(value):
        return value + 1

    def plus_two(value):
        return value + 2

    assert Lazy.of(1).map(plus_one).get() == 2
    assert Lazy.of(1).map(plus_one).map(plus_two).get() == 3


# Generated at 2022-06-25 23:42:57.378963
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.collections import Map, List
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.monad import empty

    assert(Lazy.of(1).bind(lambda x: Lazy.of(x + 2)).get() == 3)
    assert(Lazy.of(1).bind(lambda x: empty(int)).get() == 0)
    assert(Lazy.of(1).bind(lambda x: Lazy.of(2)).get() == 2)
    assert(Lazy.of(1).bind(lambda x: Map(test="test")).get()["test"] == "test")

# Generated at 2022-06-25 23:43:10.441467
# Unit test for method bind of class Lazy

# Generated at 2022-06-25 23:43:13.158181
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_1 = Lazy.of(lambda x: x)

    assert lazy_1.ap(Lazy.of(2)).get() == lazy_1.map(lambda x: x(2)).get()


# Generated at 2022-06-25 23:43:16.837862
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    result = Lazy.of(False).bind(lambda value: Lazy.of(value))

    assert result.is_evaluated == False
    assert result.value == None
    assert result.constructor_fn(test_case_0) == False



# Generated at 2022-06-25 23:43:23.925116
# Unit test for method map of class Lazy
def test_Lazy_map():
    map_fn_0 = lambda arg_0: arg_0 + arg_0
    int_0 = 0
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy.of(int_0)
    lazy_2 = lazy_0.map(map_fn_0)
    lazy_3 = lazy_1.map(map_fn_0)
    str_0 = 'map_fn_0'
    lazy_4 = lazy_0.map(str_0)
    lazy_5 = lazy_1.map(str_0)


# Generated at 2022-06-25 23:43:30.425250
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x + 1).bind(lambda x: Lazy(x + 2)).get(2) == 5
    assert Lazy(lambda x: x * 1.1).bind(lambda x: Lazy(x * 2)).get(5) == 11
    assert Lazy(lambda x: x + 1).bind(lambda x: Lazy(x + 3)).get(2) == 6



# Generated at 2022-06-25 23:43:40.470397
# Unit test for method map of class Lazy
def test_Lazy_map():
    from .box import Box
    from .either import Right
    from .maybe import Maybe
    from .monad_try import Try
    from .validation import Validation

    def function_0(x0: str, x1: int) -> int:
        return int(x0) + x1

    lazy_0 = Lazy(function_0)

    print(lazy_0)

    lazy_1 = lazy_0.map(str)
    print(lazy_1)

    lazy_2 = lazy_1.ap(Lazy.of('1'))
    print(lazy_2)

    lazy_3 = lazy_2.map(lambda x: x + 1)
    print(lazy_3)

    assert lazy_3.get('1', 0) == 3

# Generated at 2022-06-25 23:43:44.951584
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of('boom').get() == 'boom'
    assert Lazy.of('boom').to_box().get() == 'boom'
    assert Lazy.of('boom').to_either().get() == 'boom'
    assert Lazy.of('boom').to_maybe().get() == 'boom'
    assert Lazy.of('boom').to_try().get() == 'boom'


# Generated at 2022-06-25 23:43:55.123693
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy(True)
    lazy_1 = Lazy(True)
    lazy_2 = Lazy(True)
    lazy_2.is_evaluated = True
    lazy_2.value = True
    lazy_3 = Lazy(True)
    lazy_3.is_evaluated = True
    lazy_3.value = True
    lazy_3.constructor_fn = False
    assert lazy_0 == lazy_1
    assert not (lazy_0 == lazy_2)
    assert not (lazy_0 == lazy_3)
    assert lazy_1 == lazy_0
    assert not (lazy_1 == lazy_2)
    assert not (lazy_1 == lazy_3)
    assert not (lazy_2 == lazy_0)

# Generated at 2022-06-25 23:43:57.798044
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(2).get() == 2
    assert Lazy(lambda: 2).get() == 2



# Generated at 2022-06-25 23:44:02.357795
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1
    lazy_0 = Lazy.of(int_0)
    lazy_1 = lazy_0.bind(lambda arg: lazy_0)
    assert lazy_1 == Lazy.of(int_0)
    assert lazy_1.get() == 1

# Unit test method map of Lazy

# Generated at 2022-06-25 23:44:07.405809
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation
    from pymonet.validation import Success

    validation = Validation.success()

    lazy_0 = Lazy.of(lambda x: x + 1)
    lazy_1 = lazy_0.ap(Lazy.of(0))
    lazy_2 = validation.ap(lazy_0)
    lazy_3 = lazy_0.ap(lazy_2)


# Generated at 2022-06-25 23:44:10.858539
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(1).ap(Lazy.of(lambda x: x + 2)).get() == 3
    assert Lazy.of(0).ap(Lazy.of(lambda x: x / 2)).get() == 0
    assert Lazy.of(3).ap(Lazy.of(lambda x: x ** 2)).get() == 9


# Generated at 2022-06-25 23:44:14.344262
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bool_0 = True
    lazy_0 = Lazy(bool_0)
    def fn(arg_0):
        return arg_0
    lazy_1 = lazy_0.bind(fn)
    assert lazy_0.get() == lazy_1.get()


# Generated at 2022-06-25 23:44:19.317281
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy.of("Lazy")
    lazy_1 = lazy_0.bind(lambda value: Lazy.of("bind"))
    assert lazy_0.get() == "Lazy"
    assert lazy_0.get() == lazy_1.get()


# Generated at 2022-06-25 23:44:21.995034
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    mul_2 = Lazy.of(lambda x: x * 2)
    assert mul_2.ap(Lazy.of(5)) == Lazy(lambda x: 10)



# Generated at 2022-06-25 23:44:25.609360
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.maybe import Maybe

    lazy_0 = Lazy.of(Maybe.just(5))
    assert(lazy_0.get() == Maybe.just(5))


# Generated at 2022-06-25 23:44:34.358022
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Test for correct correct types value
    # Test case 0
    bool_0 = True
    lazy_0 = Lazy(bool_0)
    assert lazy_0.get() == bool_0
    # Test case 1
    bool_1 = False
    lazy_1 = Lazy(bool_1)
    assert lazy_1.get() == bool_1
    # Test case 2
    string_0 = "Lazy"
    lazy_2 = Lazy(string_0)
    assert lazy_2.get() == string_0
    # Test case 3
    string_1 = "is awesome"
    lazy_3 = Lazy(string_1)
    assert lazy_3.get() == string_1
    # Test case 4
    integer_0 = 2
    lazy_4 = Lazy(integer_0)

# Generated at 2022-06-25 23:44:44.453778
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bool_0 = False
    lazy_0 = Lazy(bool_0)
    lazy_1 = lazy_0.bind(lambda v: bool(v))
    assert lazy_1.get() == False

    bool_0 = True
    lazy_0 = Lazy(bool_0)
    lazy_1 = lazy_0.bind(lambda v: bool(v))
    assert lazy_1.get() == True

    bool_0 = False
    lazy_0 = Lazy(bool_0)
    lazy_1 = lazy_0.bind(lambda v: bool(not v))
    assert lazy_1.get() == True

    bool_0 = True
    lazy_0 = Lazy(bool_0)
    lazy_1 = lazy_0.bind(lambda v: bool(not v))
    assert lazy_1.get()

# Generated at 2022-06-25 23:44:49.503426
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def ap_mapper(a):
        return a ** 2

    assert Lazy.of(10).ap(Lazy.of(ap_mapper)).get() == 100, 'Check Lazy ap method'
    assert Lazy.of(10).ap(Lazy.of(ap_mapper)).get() == 100, 'Check Lazy ap method'



# Generated at 2022-06-25 23:44:57.839522
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Test case 0
    bool_0 = True
    lazy_0 = Lazy.of(bool_0)
    assert(lazy_0.get() == bool_0)

    # Test case 1
    bool_1 = False
    lazy_1 = Lazy(bool_1)
    assert(lazy_1.get() == bool_1)

    # Test case 2
    int_2 = 0
    lazy_2 = Lazy.of(int_2)
    assert(lazy_2.get() == int_2)

    # Test case 3
    int_3 = 1
    lazy_3 = Lazy(int_3)
    assert(lazy_3.get() == int_3)

    # Test case 4
    float_4 = 0.1

# Generated at 2022-06-25 23:45:01.810077
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    # Define function for test method bind of class Lazy
    def fn(value):
        return Lazy.of(value)

    # Check result of method bind for some values
    assert Lazy(lambda: 'blabla').bind(fn) == Lazy(fn(Lazy(lambda: 'blabla').constructor_fn()))


# Generated at 2022-06-25 23:45:06.382143
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Check if it's possible to create and call bind method with map Lambda function
    """
    test_function = lambda x: Lazy(greet(x))

    result = Lazy.of("John").bind(test_function)
    assert result.get() == "Hello, John"



# Generated at 2022-06-25 23:45:10.510692
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy.of(42)
    lazy_1 = Lazy.of(42)
    lazy_2 = Lazy.of(3.14)

    assert lazy_0 == lazy_1
    assert lazy_0 != lazy_2
    assert lazy_0 != []


# Generated at 2022-06-25 23:45:14.451053
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: 5).bind(lambda x: Lazy(x + 6)).get() == 11



# Generated at 2022-06-25 23:45:16.700299
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bool_0 = True
    lazy_0 = Lazy(bool_0)
    bool_1 = False
    lazy_1 = Lazy(bool_1)
    func_1 = lambda a: lazy_0.map(lambda b: b)
    if not ((lazy_1.bind(func_1)) != lazy_0):
        raise RuntimeError("test failed")


# Generated at 2022-06-25 23:45:24.915107
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    one = Lazy.of(1)
    two = Lazy.of(2)
    three = Lazy.of(3)

    def add(x):
        return Lazy.of(x + 1)

    def times(x):
        return Lazy.of(x * 2)

    two_plus_1 = two.ap(add)
    assert two_plus_1 == Lazy.of(3)
    two_times_2 = two.ap(times)
    assert two_times_2 == Lazy.of(4)

    three_plus_1 = three.ap(add)
    assert three_plus_1 == Lazy.of(4)
    three_times_2 = three.ap(times)
    assert three_times_2 == Lazy.of(6)


# Generated at 2022-06-25 23:45:35.978012
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    def add1(a):
        return a + 1

    def to_box(a):
        return Box(a)

    def to_maybe(a):
        if a % 2 == 0:
            return Maybe.just(a)
        return Maybe.empty()

    def to_either(a):
        if a % 2 == 0:
            return Right(a)
        return Right.empty()

    bool_0 = bool(1)
    lazy_0 = Lazy(bool_0)
    lazy_1 = lazy_0.bind(to_box)
    assert lazy_1 == Lazy(Box(1))

    bool_1 = bool(0)

# Generated at 2022-06-25 23:45:39.953881
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy.of(lambda lazy_0: lambda lazy1: lazy1)
    lazy_1 = Lazy.of(lambda lazy_1: lambda lazy1: lazy1)

    assert lazy_0.ap(lazy_1) == Lazy.of(lambda lazy_1: lazy_1)



# Generated at 2022-06-25 23:45:43.078723
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    fn_0 = lambda a: a + 1
    fn_1 = lambda a: a - 1
    lazy_1 = Lazy(fn_0)
    lazy_2 = Lazy(fn_1)
    assert (lazy_1.ap(lazy_2).get(2) == 4)


# Generated at 2022-06-25 23:45:45.108362
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy((lambda x: x)).get('test') == 'test'

# Generated at 2022-06-25 23:45:53.354567
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right

    def mult(a):
        return a * 3

    def mult2(a):
        return a * 2

    lazy = Lazy(mult)
    lazy2 = Lazy(mult2)
    lazy3 = Lazy(4)
    assert lazy.ap(lazy2) == Box(12)
    assert lazy.ap(lazy3).get() == 12
    assert lazy.ap(lazy2).get() == 12


# Generated at 2022-06-25 23:45:58.670128
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test correctness of get method
    """
    lazy_0 = Lazy(lambda: True)
    assert lazy_0.get()

    lazy_1 = Lazy(lambda: 'test')
    assert lazy_1.get() == 'test'

    lazy_2 = Lazy(lambda: [1, 2, 3])
    assert lazy_2.get() == [1, 2, 3]



# Generated at 2022-06-25 23:46:05.355699
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_0 = Lazy(lambda: 1)
    assert lazy_0.map(lambda x: x * 2).get() == 2
    lazy_1 = Lazy(lambda: 1)
    assert lazy_1.map(lambda x: x * 2).constructor_fn == Lazy(lambda: 1).constructor_fn
    lazy_2 = Lazy(lambda: 1)
    assert lazy_2.map(lambda x: x * 2).is_evaluated == False
    lazy_3 = Lazy(lambda: 1)
    assert lazy_3.map(lambda x: x * 2).value == None

# Generated at 2022-06-25 23:46:17.807188
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def bool_0(b: bool) -> bool:
        return b

    def int_0(i: int) -> int:
        return i

    lazy_0 = Lazy(bool_0)
    lazy_1 = lazy_0.bind(lambda b: bool_0(not b))
    lazy_2 = lazy_1.bind(lambda b: int_0(int(b)))
    assert lazy_2.get(False) == 0



# Generated at 2022-06-25 23:46:27.310005
# Unit test for method map of class Lazy
def test_Lazy_map():
    bool_0 = False
    bool_1 = True
    lazy_0 = Lazy.of(bool_0)
    lazy_1 = lazy_0.map(lambda arg0: not arg0)
    assert lazy_1.get() == bool_1
    lazy_0 = Lazy.of(bool_1)
    lazy_1 = lazy_0.map(lambda arg0: arg0)
    assert lazy_1.get() == bool_1
    lazy_0 = Lazy.of(bool_0)
    lazy_1 = lazy_0.map(lambda arg0: not arg0)
    assert lazy_1.get() == bool_1
    lazy_1 = Lazy.of(bool_0)
    bool_0 = bool_1
    assert lazy_1.get() == bool_0


# Generated at 2022-06-25 23:46:30.256242
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(True).get() == True
    assert Lazy.of(None).get() == None
    assert Lazy.of(False).get() == False



# Generated at 2022-06-25 23:46:35.091807
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.functions import compose

    lazy_0_get_0 = Lazy(lambda x: 1).get(1)
    assert lazy_0_get_0 == 1, "Failed test_Lazy_get"

    lazy_0_get_1 = Lazy(lambda x: x).get(1)
    assert lazy_0_get_1 == 1, "Failed test_Lazy_get"

    lazy_0_get_1_compose_0 = compose(Lazy(lambda x: x).map(lambda y: y + 1), Lazy(lambda x: x).map(lambda y: y + 2)).get(1)
    assert lazy_0_get_1_compose_0 == 4, "Failed test_Lazy_get"


# Generated at 2022-06-25 23:46:40.349589
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Annotation: Lazy(bool) -> bool
    bool_0 = True
    lazy_0 = Lazy(lambda: bool_0)  # noqa E731
    # Method: get - implementation: fn
    assert_true(lazy_0.get())
    # Method: get - implementation: memoize
    assert_true(lazy_0.get())


# Generated at 2022-06-25 23:46:43.168930
# Unit test for method get of class Lazy
def test_Lazy_get():
    bool_0 = True
    lazy_0 = Lazy(lambda: bool_0)
    assert lazy_0.get() == bool_0


# Generated at 2022-06-25 23:46:46.574230
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_1 = Lazy.of(1)
    lazy_2 = Lazy(lambda: 1)
    assert lazy_1 == lazy_1
    assert lazy_1 != lazy_2
    assert lazy_2 == lazy_2


# Generated at 2022-06-25 23:46:49.080863
# Unit test for method map of class Lazy
def test_Lazy_map():
    bool_0 = True
    lazy_0 = Lazy(bool_0)
    lazy_1 = lazy_0.map(lambda x: not x)
    assert lazy_1.get() is False


# Generated at 2022-06-25 23:46:52.838910
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def func_bool(bool_0):
        return Lazy(bool_0)

    bool_0 = True
    lazy_0 = Lazy(bool_0)
    lazy_0_new = lazy_0.bind(func_bool)
    bool_0_new = lazy_0_new.get()
    assert bool_0 == bool_0_new


# Generated at 2022-06-25 23:47:00.172502
# Unit test for method map of class Lazy
def test_Lazy_map():
    value_0 = Lazy.of(True)
    assert value_0.map(lambda x: not(x)).get() == False
    assert value_0.map(lambda x: not(x)).to_box().get() == False
    assert value_0.map(lambda x: not(x)).to_either().get() == False
    assert value_0.map(lambda x: not(x)).to_maybe().get() == False
    assert value_0.map(lambda x: not(x)).to_try().get() == False
    assert value_0.map(lambda x: not(x)).to_validation().get() == False


# Generated at 2022-06-25 23:47:19.378377
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def wrapped_function():
        return Box(23)

    def wrapped_function_2():
        return 42

    lazy_0 = Lazy(wrapped_function)
    lazy_1 = lazy_0.bind(lambda x: wrapped_function)

    assert lazy_1.get() == 23

    lazy_2 = Lazy(wrapped_function_2)
    lazy_3 = lazy_2.bind(lambda x: wrapped_function_2)

    assert lazy_3.get() == 42


# Generated at 2022-06-25 23:47:22.413410
# Unit test for method get of class Lazy
def test_Lazy_get():
    bool_0 = True
    lazy_0 = Lazy(bool_0)
    assert lazy_0.get() == bool_0


# Generated at 2022-06-25 23:47:27.022773
# Unit test for method get of class Lazy
def test_Lazy_get():
    bool_0 = True

    lazy_0 = Lazy.of(bool_0)

    res = lazy_0.get()

    if res is not bool_0:
        raise ValueError("Value shoud be '{}' but is '{}'".format(bool_0, res))


# Generated at 2022-06-25 23:47:33.393601
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    assert Lazy.of(10).map(lambda x: x * 2).get() == 20
    assert Lazy(lambda: 10).map(lambda x: x * 2).get() == 20
    assert Lazy(lambda x: Box.unit(x)).map(lambda x: x * 2).get(10) == 20
    assert Lazy(lambda x, y: x + y).map(lambda x: x * 2).get(10, 5) == 30



# Generated at 2022-06-25 23:47:36.842069
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Lazy[A].bind(Function(A) -> Lazy[B]) -> Lazy[B]
    box_0 = Lazy.of(True).bind(
        lambda b: Lazy.of(b))
    assert box_0.get() == True



# Generated at 2022-06-25 23:47:41.269671
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Test method get of class Lazy
    bool_0 = True
    lazy_0 = Lazy(lambda: bool_0)
    # Test method get of class Lazy
    lazy_1 = Lazy(lambda: bool_0)

    test_0 = lazy_0.get()
    test_1 = lazy_1.get()

    print("Test Lazy get 0: {}".format(test_0))
    print("Test Lazy get 1: {}".format(test_1))

    # assertion test
    assert test_0 == test_1


# Generated at 2022-06-25 23:47:45.582300
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_0 = Lazy([-96, 43, 4, -75, 26, -5, -73, 93, -19, 11])
    lazy_0 = lazy_0.map(lambda x: x if (x <= -48) else (False))
    assert lazy_0.constructor_fn() == [False, False, False, False, False, False, False, False, False, False]


# Generated at 2022-06-25 23:47:55.524608
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_either import Right
    from pymonet.monad_try import Try

    lazy = Lazy(lambda x: x * 2)
    assert isinstance(lazy.map(lambda x: x + 1), Lazy)
    assert lazy.map(lambda x: x + 1).get(2) == 5
    assert lazy.map(lambda x: x + 1).get(3) == 7

    func = lambda x: x * 2
    right = Right(2)
    assert lazy.map(func).ap(right).get() == 6

    try_1 = Try.of(func, 2)
    assert lazy.map(func).ap(try_1).get() == 6



# Generated at 2022-06-25 23:47:59.500916
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    pass


# Generated at 2022-06-25 23:48:03.917369
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def bool_0(): return (3 <= 2)
    bool_1 = bool_0()
    lazy_0 = Lazy(bool_0)
    assert lazy_0.ap(Lazy(lambda x: x)).get() == bool_1


# Generated at 2022-06-25 23:48:17.909876
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # TODO: write unit test
    pass



# Generated at 2022-06-25 23:48:19.443288
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(True) == Lazy.of(True)


# Generated at 2022-06-25 23:48:27.934425
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad import Monad

    lazy_2_0: Monad[bool] = Lazy(True)
    assert lazy_2_0.get() is True

    lazy_2_1: Monad[bool] = Lazy(False)
    assert lazy_2_1.get() is False

    lazy_2_2: Monad[int] = Lazy(1)
    assert lazy_2_2.get() == 1

    lazy_2_3: Monad[int] = Lazy(10)
    assert lazy_2_3.get() == 10

    lazy_2_4: Monad[None] = Lazy(None)
    assert lazy_2_4.get() is None

    lazy_2_5: Monad[None] = Lazy(None)

# Generated at 2022-06-25 23:48:32.772447
# Unit test for method map of class Lazy
def test_Lazy_map():
    from datetime import date

    lazy_0 = Lazy(lambda: date(2019, 1, 1))
    lazy_1 = lazy_0.map(lambda x: x.year)
    lazy_2 = lazy_1.map(lambda x: str(x))
    lazy_3 = lazy_2.map(lambda x: int(x))
    assert lazy_3.get() == 2019



# Generated at 2022-06-25 23:48:38.598878
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda n: n).ap(Lazy(lambda n: 2 * n)).get(1) == 2
    assert Lazy(lambda n: n).ap(Lazy(lambda n: 2 * n)).get(2) == 4
    assert Lazy(lambda n: n).ap(Lazy(lambda n: 2 * n)).get(3) == 6
    assert Lazy(lambda n: n).ap(Lazy(lambda n: 2 * n)).to_box().get() == 1


# Generated at 2022-06-25 23:48:43.584350
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # given
    expected_bool_0 = True
    bool_0 = expected_bool_0
    lazy_0 = Lazy(bool_0)
    bool_1 = expected_bool_0
    lazy_1 = Lazy(bool_1)

    # when
    actual_bool_0 = lazy_0 == lazy_1

    # then
    assert_that(actual_bool_0, is_(expected_bool_0))



# Generated at 2022-06-25 23:48:47.044598
# Unit test for method get of class Lazy
def test_Lazy_get():
    bool_0 = True
    lazy_0 = Lazy(lambda: bool_0)
    bool_1 = lazy_0.get()
    bool_2 = bool_1 is bool_0
    assert bool_2


# Generated at 2022-06-25 23:48:51.260030
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Test case 0
    bool_0 = True
    lazy_0 = Lazy(bool_0)
    bool_1 = lazy_0.get()

    # Test case 1
    bool_2 = False
    lazy_1 = Lazy(bool_2)
    bool_3 = lazy_1.get()



# Generated at 2022-06-25 23:48:55.900820
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: True) == Lazy(lambda: True)
    assert Lazy(lambda: True) != Lazy(lambda: False)
    assert Lazy(lambda: None) != Lazy(lambda: False)
    assert Lazy(lambda: None) == Lazy(lambda: None)


# Generated at 2022-06-25 23:48:59.606524
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation

    val_0 = Validation.success('abc')
    bool_0 = False
    lazy_0 = Lazy(bool_0)
    lazy_1 = lazy_0.ap(Validation.success(bool))
    bool_1 = lazy_0.ap(val_0).get()


# Generated at 2022-06-25 23:49:14.084757
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(True).get() is True


# Generated at 2022-06-25 23:49:22.364477
# Unit test for method map of class Lazy
def test_Lazy_map():
    # empty test case
    weak_test_case_0 = True
    lazy_0 = Lazy(lambda *args: weak_test_case_0)
    assert lazy_0.map(lambda x: not x).get() == False
    
    # empty test case
    weak_test_case_1 = True
    lazy_1 = Lazy(lambda *args: weak_test_case_1)
    assert lazy_1.map(lambda x: not x).get() == False
    
    # empty test case
    weak_test_case_2 = False
    lazy_2 = Lazy(lambda *args: weak_test_case_2)
    assert lazy_2.map(lambda x: not x).get() == True
    
    # empty test case
    weak_test_case_3 = False

# Generated at 2022-06-25 23:49:27.253967
# Unit test for method map of class Lazy
def test_Lazy_map():
    _true = True
    _false = False
    lazy_true = Lazy(_true)
    lazy_true_mapped = lazy_true.map(lambda b: not b)
    assert lazy_true_mapped == Lazy(_false)

    lazy_false = Lazy(_false)
    lazy_false_mapped = lazy_false.map(lambda b: not b)
    assert lazy_false_mapped == Lazy(_true)


# Generated at 2022-06-25 23:49:37.727200
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy.of(0)
    lazy_1 = Lazy.of((lambda x: x + 5))
    lazy_2 = lazy_1.ap(lazy_0)

    assert lazy_2.get() == 5

    lazy_3 = Lazy.of(1)
    lazy_4 = Lazy.of((lambda x: x + 3))
    lazy_5 = lazy_4.ap(lazy_3)

    assert lazy_5.get() == 4

    lazy_6 = Lazy.of(6)
    lazy_7 = Lazy.of((lambda x: x + 7))
    lazy_8 = lazy_6.ap(lazy_7)

    assert lazy_8.get() == 13

    lazy_9 = Lazy.of(4)
    lazy_10 = Lazy.of

# Generated at 2022-06-25 23:49:47.038986
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    value = 3
    def add(x):
        return x + 1
    def add_2(x):
        return x + 2
    lazy_0 = Lazy.of(value)
    lazy_1 = Lazy.of(add)
    lazy_2 = Lazy.of(add_2)

    assert lazy_0.ap(lazy_1) == Lazy.of(4)
    assert lazy_0.ap(lazy_2) == Lazy.of(5)


# Generated at 2022-06-25 23:49:51.190940
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_get_function():
        bool_0 = True
        lazy_0 = Lazy(bool_0)
        bool_1 = bool_0 or bool_0
        assert lazy_0.get() == bool_1
        assert lazy_0.get() == bool_1

    test_get_function()


# Generated at 2022-06-25 23:49:54.398597
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy.of(1)
    lazy_1 = lazy_0.bind(lambda v: Lazy(v + 2))
    assert lazy_1.get() == 3



# Generated at 2022-06-25 23:50:07.776821
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def test_case_0():
        value = {}
        lazy_0 = Lazy.of(value)
        assert lazy_0.ap(value) is lazy_0

    def test_case_1():
        value = {}
        lazy_0 = Lazy.of(value)
        assert lazy_0.ap(value) is lazy_0

    def test_case_2():
        lazy_0 = Lazy.of(0)
        int_0 = 1
        lazy_1 = Lazy(lambda *args: 4)
        assert lazy_0.ap(lazy_1) is lazy_0

    def test_case_3():
        lazy_0 = Lazy.of(0)
        int_0 = 1
        lazy_1 = Lazy(lambda *args: 4)

# Generated at 2022-06-25 23:50:10.019460
# Unit test for method get of class Lazy
def test_Lazy_get():
    bool_0 = True
    lazy_0 = Lazy.of(bool_0)
    assert(lazy_0.get() == bool_0)


# Generated at 2022-06-25 23:50:15.099766
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Given
    lazy_0 = Lazy(bool)
    lazy_1 = Lazy(False)

    # When
    result = lazy_0.ap(lazy_1)

    # Then
    assert(result == Lazy(False))
