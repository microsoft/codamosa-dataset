

# Generated at 2022-06-25 23:40:27.204281
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from random import choice
    from pymonet.maybe import Maybe

    int_values = [11, 21, 31, 41, 51, 61, 71]
    lazy_values = [Lazy.of(i) for i in int_values]

    for _ in range(50):
        int_value = choice(int_values)
        lazy_value = choice(lazy_values)
        assert Maybe.of(lazy_value == lazy_value).is_just
        assert Maybe.of(lazy_value == Lazy.of(int_value)).is_nothing

# Generated at 2022-06-25 23:40:35.383496
# Unit test for method bind of class Lazy
def test_Lazy_bind():
  bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
  def lambda_fn_0(arg_0):
    return Lazy(lambda : arg_0)
  lazy_0 = Lazy(bytes_0)
  lazy_0.bind(lambda_fn_0)
  assert isinstance(lazy_0, Lazy)
  assert lazy_0.constructor_fn() is bytes_0
  assert lazy_0.is_evaluated is False
  assert lazy_0.value is None


# Generated at 2022-06-25 23:40:45.028337
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    assert not lazy_0.__eq__(None)
    assert not lazy_0.__eq__(1)

    lazy_1 = Lazy(bytes_0)
    assert lazy_0.__eq__(lazy_1)

    lazy_1 = Lazy(bytes_0)
    assert lazy_0.__eq__(lazy_1)
    lazy_1.get()
    assert lazy_0.__eq__(lazy_1)



# Generated at 2022-06-25 23:40:51.598518
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    byte_1 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    byte_2 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(byte_1)
    lazy_1 = Lazy(byte_2)
    assert lazy_0 == lazy_1
    assert not (lazy_0 == lazy_0)



# Generated at 2022-06-25 23:41:01.154131
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Test case 1
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)

    # Test case 2
    lazy_0 = Lazy.of(None)

    # Test case 3
    lazy_0 = Lazy(int)

    # Test case 4
    lazy_0 = Lazy(dict)

    # Test case 5
    lazy_0 = Lazy(float)

    # Test case 6
    lazy_0 = Lazy.of(b'0s0s0s0s0s0s0s0s0s0s0s0s0s0s0s0s0s0s0s')

    # Test case 7
    lazy_0 = L

# Generated at 2022-06-25 23:41:08.638221
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    float_0 = 0.427275470351849
    str_0 = ':D'
    lazy_0 = Lazy(float_0)
    lazy_1 = Lazy(float_0)
    lazy_2 = Lazy(str_0)
    lazy_3 = Lazy(float_0)
    lazy_3._compute_value(True)
    assert lazy_0.__eq__(lazy_1)
    assert not lazy_0.__eq__(lazy_2)
    assert lazy_0.__eq__(lazy_3)


# Generated at 2022-06-25 23:41:14.823627
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def assert_equal(lazy_0, expected_lazy):
        assert lazy_0 == expected_lazy, '\n' + str(lazy_0) + '\n' + str(expected_lazy)

    lazy_0 = Lazy.of(11)
    lazy_1 = Lazy.of(lambda x: x + 1)
    lazy_2 = Lazy.of(lambda x: x + 2)
    assert_equal(lazy_1.ap(lazy_0), Lazy(lambda *args: lazy_1.get()(lazy_0.get())))
    assert_equal(lazy_2.ap(lazy_0), Lazy(lambda *args: lazy_2.get()(lazy_0.get())))

# Generated at 2022-06-25 23:41:18.743998
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(bytes_0)

    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:41:19.581024
# Unit test for method get of class Lazy
def test_Lazy_get():
    pass


# Generated at 2022-06-25 23:41:25.580254
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(bytes_0)
    lazy_2 = Lazy(bytes_0)
    assert lazy_1 == lazy_1
    assert lazy_1 == lazy_2
    assert lazy_0 != lazy_1


# Generated at 2022-06-25 23:41:41.027621
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert (
        Lazy.of(5)
        .map(lambda x: x + 6)
        .get() == 11
    ), 'Map of Lazy must return copy of Lazy with mapped value'

    assert (
        Lazy.of(1)
        .map(lambda x: Box(x + 5))
        .get() == Box(6)
    ), 'Map of Lazy must return copy of Lazy with mapped value'


# Generated at 2022-06-25 23:41:44.311287
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    assert Lazy.of('a').map(lambda a: a + 'b').get() == Box('ab').get()
    assert Lazy.of([1, 2, 3]).map(lambda a: a + [5]).get() == Box([1, 2, 3, 5]).get()



# Generated at 2022-06-25 23:41:52.109729
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # New instance of class Person without parameters
    obj_Person_0 = Person()
    # Value of attribute name of class Person
    str_0 = 'name'
    # Attribute name of class Person will be equal str_0
    obj_Person_0.name = str_0
    # New instance of class Lazy with constructor function get_name of class Person to call
    lazy_0 = Lazy(obj_Person_0.get_name)
    # Call method bind of Lazy with function lambda_fn
    #  Binding function get_name of class Person returns new Lazy with constructor function set_name of class Person
    lazy_1 = lazy_0.bind(lambda_fn)
    # Value of attribute name of class Person
    str_1 = 'name'
    # Method get of class Lazy returns result of calling constructor function
    #  constructor

# Generated at 2022-06-25 23:41:56.895357
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(4).get() == 4
    assert Lazy.of(b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}').get() == b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'


# Generated at 2022-06-25 23:42:08.474089
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Coordinates are in range (1, 8)
    coordinates = (1, 2)
    # Coordinates are not in range (1, 8)
    wrong_coordinates = (9, 10)

    def is_valid_move(x, y):
        """
        Returns true if chess figure can move to selected coordinates.
        """
        return 1 <= x <= 8 and 1 <= y <= 8

    valid_move = Lazy(lambda *args: is_valid_move(*args))
    chess_figure_move = Lazy(lambda x: (coordinates, wrong_coordinates))
    # Checks if chess figure can move to valid coordinates
    result = valid_move.ap(chess_figure_move)
    assert result.get() is True

    chess_figure_move = Lazy(lambda x: (wrong_coordinates, coordinates))
   

# Generated at 2022-06-25 23:42:13.872234
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    assert lazy_0.bind(bytes_0).is_evaluated
    assert lazy_0.bind(bytes_0).value == bytes_0



# Generated at 2022-06-25 23:42:25.436755
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        if value:
            return Lazy.of(None)
        return Try.of(lambda: None)

    assert Lazy.of(None).bind(fn) == Lazy.of(None)
    assert Lazy.of(True).bind(fn) == Lazy.of(None)
    assert Lazy.of(1).bind(fn) == Try.of(lambda: None)
    assert Lazy.of('').bind(fn) == Try.of(lambda: None)
    assert Lazy.of([1, 2]).bind(fn) == Try.of(lambda: None)

    def fn(value):
        if value:
            return Lazy.of(None)
        return Validation

# Generated at 2022-06-25 23:42:31.047707
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(x):
        return x * 2

    lazy_0 = Lazy(lambda x: x + 1)
    ret_0 = lazy_0.bind(lambda x: lazy_0._compute_value(x))
    ret_1 = ret_0.constructor_fn
    ret_2 = ret_1()
    assert ret_2 == 2


# Generated at 2022-06-25 23:42:37.025524
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_1 = Lazy(lambda x: x + 5)
    lazy_2 = Lazy(lambda x: x * 5)
    assert lazy_2.ap(lazy_1).get(10) == lazy_1.get(10) * 5
    assert lazy_2.ap(lazy_1).get(10) == 65
    assert lazy_2.ap(lazy_1).is_evaluated == True
    assert lazy_2.is_evaluated == True
    assert lazy_1.is_evaluated == True


# Generated at 2022-06-25 23:42:38.933042
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert (Lazy(lambda x: x + 1).bind(lambda x: Lazy(lambda x: x))
            == Lazy(lambda x: x + 1))



# Generated at 2022-06-25 23:42:52.885810
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Left
    from pymonet.maybe import Just, Nothing
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    lazy_0 = Lazy.of(None)
    lazy_1 = Lazy.of(None)
    lazy_2 = Lazy.of(None)
    lazy_3 = Lazy.of(None)
    lazy_4 = Lazy.of(None)
    lazy_5 = Lazy.of(None)

    assert lazy_0.ap(lazy_1).to_box() == Box.of(None)
    assert lazy_0.ap(lazy_2).to_either() == Left(None)
    assert lazy_0.ap(lazy_3).to_maybe

# Generated at 2022-06-25 23:43:01.881095
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_try import Try
    from pymonet.either import error_to_string

    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    lazy_0_map_0 = lazy_0.map(lambda x: x)
    assert lazy_0_map_0.get(b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}') == b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'


# Generated at 2022-06-25 23:43:06.752144
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Right

    def some_fn(value):
        def some_fn_r(value):
            return Right(value)

        return some_fn_r(value)

    lazy = Lazy.of(1)
    res = lazy.bind(some_fn).get()
    assert res == Right(1)


# Generated at 2022-06-25 23:43:11.838039
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Preconditions
    # Nothing

    # Postconditions
    # Result of method bind is memoized in property value and is_evaluated is True

    # Test
    integer = Lazy.of(1)
    result = integer.bind(lambda value: Lazy.of(value + 1)).get()
    assert 2 == result
    assert integer.is_evaluated
    assert 1 == integer.value



# Generated at 2022-06-25 23:43:16.260267
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_1 = Lazy(bytes_0)
    lazy_2 = Lazy(bytes_0)
    lazy_2.ap(lazy_1)



# Generated at 2022-06-25 23:43:24.026585
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.validation import Validation

    assert Lazy.of(5).get() == 5
    assert Lazy.of(Right(5)).get().value == 5

    assert Lazy.of(Lazy.of(5)).get().get() == 5
    assert Lazy.of(Lazy.of(Lazy.of(5))).get().get().get() == 5

    assert Lazy.of(Lazy.of(Right(5))).get().get().value == 5
    assert Lazy.of(Lazy.of(Lazy.of(Right(5)))).get().get().get().value == 5

    assert Lazy.of(Box(5)).map(lambda box: box.get()).get() == 5
    assert L

# Generated at 2022-06-25 23:43:33.038814
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    def bytes_0():
        return b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'

    lazy_0 = Lazy(bytes_0)
    lazy_1 = lazy_0.map(Box.of)
    assert lazy_1.constructor_fn() == b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    assert lazy_1.constructor_fn() is not bytes_0()



# Generated at 2022-06-25 23:43:37.613050
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(b'\xff').get() == b'\xff'
    assert (
        Lazy(lambda i: b'\xaa' * i)
        .bind(lambda test_bytes: Lazy(bytes_to_int))
        .get(test_bytes=6)
    ) == 885


# Generated at 2022-06-25 23:43:44.748294
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Try

    lazy_0 = Lazy.of(lambda: Try.of(int, '5'))
    lazy_1 = Lazy.of(5)

    lazy_2 = lazy_0.ap(lazy_1)

    assert isinstance(lazy_2, Lazy)
    assert isinstance(lazy_2.value, Try)
    assert lazy_2.value.failure_value is None

    assert (isinstance(lazy_2.value.success_value, int))
    assert lazy_2.value.success_value == 5



# Generated at 2022-06-25 23:43:54.757071
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Case 0
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    bytes_1 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_1 = Lazy(bytes_1)
    lazy_2 = lazy_0.map((lambda it: len(it)))
    lazy_3 = lazy_1.map((lambda it: len(it)))
    assert lazy_2.is_evaluated is False
    assert lazy_3.is_evaluated is False
    assert lazy_2.get() == 11
    assert lazy_3.get() == 11


#

# Generated at 2022-06-25 23:44:08.281129
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import pymonet.maybe as maybe
    import pymonet.box as box
    import pymonet.either as either
    import pymonet.lazy as lazy
    import pymonet.validation as validation
    import pymonet.monad_try as monad_try

    m0 = maybe.Maybe('maybe.Just(True)')
    b0 = box.Box('box.Box(True)')
    e0 = either.Either(True, None)
    l0 = lazy.Lazy(True)
    v0 = validation.Validation(True, [])
    t0 = monad_try.Try(True)

    assert lazy.Lazy(True).ap(m0) == maybe.Maybe(True)
    assert lazy.Lazy(True).ap(b0) == box.Box(True)

# Generated at 2022-06-25 23:44:16.645485
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Integration test of method ap of class Lazy
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    bytes_1 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_1 = Lazy(bytes_1)
    lazy_2 = lazy_0.ap(lazy_1)
    assert lazy_2.get() == bytes_1


# Generated at 2022-06-25 23:44:26.606964
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    class LazyImpl(Lazy[int, int]):
        def __init__(self, constructor_fn):
            Lazy.__init__(self, constructor_fn)
            self.counter = 0

        def get(self, *args):
            self.counter += 1
            return Lazy.get(self, *args)

    lazy_0 = LazyImpl(lambda x: x * 10)

    assert lazy_0.counter == 0
    assert lazy_0.get(1) == 10
    assert lazy_0.counter == 1
    assert lazy_0.get(1) == 10
    assert lazy_0.counter == 1

    lazy_1 = lazy_0.map(lambda x: x + 5).map(lambda x: x + 5).map(lambda x: x + 5)

# Generated at 2022-06-25 23:44:32.445627
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # Ensure that __eq__ function works correctly
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) == Lazy.of(1.0)
    assert Lazy.of(1) == Lazy.of(True)
    assert Lazy.of(1) == Lazy.of('1')
    assert Lazy.of('a') == Lazy.of('a')
    assert not Lazy.of('a') == Lazy.of('b')



# Generated at 2022-06-25 23:44:34.274474
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x * 2).ap(Lazy.of(3)) == Lazy.of(6)



# Generated at 2022-06-25 23:44:38.338161
# Unit test for method get of class Lazy
def test_Lazy_get():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy.of(bytes_0)

    # Testing return value of get method
    assert lazy_0.get() == bytes_0


# Generated at 2022-06-25 23:44:42.762191
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    def wrapper(x):
        return Lazy(x)

    def test_and_result_0():
        test_0 = Lazy.of(1).bind(wrapper)
        result_0 = Lazy(1)
        assert test_0 == result_0



# Generated at 2022-06-25 23:44:47.392656
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    result = Lazy(lambda: 2).ap(Lazy(lambda: lambda x: x + 3))
    assert result.is_evaluated is False
    assert result == Lazy(lambda: lambda x: x + 3)(2)
    assert result.get() == 5
    assert result.is_evaluated


# Generated at 2022-06-25 23:44:53.241599
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Case 0
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = lazy_0.ap(lazy_0)
    assert lazy_1 == Lazy.of(bytes_0), f"Expected: {Lazy.of(bytes_0)}, actual: {lazy_1}"


# Generated at 2022-06-25 23:44:57.589458
# Unit test for method get of class Lazy
def test_Lazy_get():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    assert lazy_0.get() == b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'


# Generated at 2022-06-25 23:45:12.444150
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.result import Result
    from pymonet.maybe import Maybe
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.monad_try import Try

    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    assert lazy_0.get() == bytes_0

    lazy_1 = Lazy.of(None)
    assert lazy_1.get() is None

    lazy_2 = Lazy.of(Maybe.nothing())
    lazy_2_expected = Maybe.nothing()
    assert lazy_2.get() == lazy_2_expected

    assert lazy_2.get() == lazy_2_expected

# Generated at 2022-06-25 23:45:14.808181
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert_equals(Lazy(lambda: 'data').get(), 'data')


# Generated at 2022-06-25 23:45:21.113155
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    bytes_1 = b'i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5'

    def bytes_decode_fn(value: bytes) -> str:
        return value.decode('utf8')

    lazy_1 = Lazy(bytes_1)
    lazy_2 = Lazy(bytes_decode_fn)

    lazy_3 = lazy_1.ap(lazy_2)

    assert lazy_3 == Lazy(lambda: b'i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5'.decode('utf8'))


# Generated at 2022-06-25 23:45:22.767008
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda: 1)
    assert lazy.get() == 1



# Generated at 2022-06-25 23:45:32.914836
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(bytes_0)
    lazy_2 = Lazy(b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}')
    lazy_3 = Lazy(b'\x00')

    assert lazy_0 == lazy_0
    assert lazy_0 != lazy_1
    assert lazy_0 == lazy_2
    assert lazy_3 != lazy_0



# Generated at 2022-06-25 23:45:41.885605
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy.of(bytes_0)
    # Test case 1:
    assert lazy_0.ap(lazy_0) == Lazy.of(bytes_0)
    # Test case 2:
    assert lazy_0.ap(lazy_1) == Lazy.of(bytes_0)
    # Test case 3:
    assert lazy_1.ap(lazy_0) == Lazy.of(bytes_0)
    # Test case 4:
    assert lazy_1.ap(Lazy.of(bytes_0)) == Lazy.of(bytes_0)

# Unit

# Generated at 2022-06-25 23:45:44.784374
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(a):
        return Lazy(a)
    msg = Lazy(fn)
    assert msg.bind(fn) == Lazy(None)


# Generated at 2022-06-25 23:45:56.062997
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box

    lazy_0 = Lazy.of(b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}')
    assert lazy_0.get() == b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    result_0 = lazy_0.get()
    assert result_0 == b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    result_0 = lazy_0.get()

# Generated at 2022-06-25 23:46:04.638306
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Case 0:
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(lambda: 5)
    lazy_0._compute_value()
    lazy_1._compute_value()
    lazy_2 = lazy_0.bind(lambda val_0: lazy_1)
    assert isinstance(lazy_2, Lazy)
    assert lazy_2.constructor_fn == lazy_1.constructor_fn
    assert lazy_2.is_evaluated is True
    assert lazy_2.value == lazy_1.value


# Generated at 2022-06-25 23:46:11.640862
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    class String(Monad, Functor, Applicative, Generic[U]):
        def __init__(self, value: U) -> None:
            self.value = value

        def __str__(self):  # pragma: no cover
            return 'String({})'.format(self.value)

        def __eq__(self, other):
            return isinstance(other, String) and self.value == other.value

        def bind(self, fn: Callable[[U], 'String[W]']) -> 'String[W]':
            return fn(self.value)

        def apply(self, applicative):
            return self.value(applicative.value)


# Generated at 2022-06-25 23:46:24.166202
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy(str)
    str_0 = 'm#f]7V<:G*Q'
    lazy_1 = lazy_0.bind(lambda arg_0: Lazy(str_0))
    assert lazy_1.get() == 'm#f]7V<:G*Q'



# Generated at 2022-06-25 23:46:25.736872
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    left = Lazy(lambda: 1)
    right = Lazy(lambda: 1)

    assert left == right


# Generated at 2022-06-25 23:46:30.488175
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import random

    int_random = random.randint(0, 1000)
    lazy_0 = Lazy.of(int_random)

    def duplicate(value):
        return Lazy.of(value + value)

    lazy_1 = lazy_0.bind(duplicate)
    assert lazy_1.get() == int_random * 2



# Generated at 2022-06-25 23:46:38.586946
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Test case 0
    # When: mapping Function(x) -> x + 1 to Lazy(0)
    # Then: lazy with function returning 0 + 1
    assert Lazy(lambda x: 0).map(lambda x: x + 1) == Lazy(lambda x: 0 + 1)

    # Test case 1
    # When: mapping Function(x) -> x + 1 to Lazy(4)
    # Then: lazy with function returning 4 + 1
    assert Lazy(lambda x: 4).map(lambda x: x + 1) == Lazy(lambda x: 4 + 1)



# Generated at 2022-06-25 23:46:45.383162
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy.of(lazy_0)
    lazy_2 = lazy_1.bind(lambda x: x)
    lazy_3 = Lazy(bytes_0)
    assert lazy_2 == lazy_3



# Generated at 2022-06-25 23:46:46.662215
# Unit test for method get of class Lazy
def test_Lazy_get():
    print('Testing method get:')
    test_case_0()


# Generated at 2022-06-25 23:46:49.493264
# Unit test for method map of class Lazy
def test_Lazy_map():
    def fn(a):
        return a * 2

    lazy_0 = Lazy(lambda *args: fn)
    lazy_1 = lazy_0.map(fn)
    assert lazy_1.get() == fn(fn)



# Generated at 2022-06-25 23:46:58.110375
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(number):
        return number + 1

    def multiply(number):
        return Maybe.just(number * number)

    lazy_0 = Lazy.of(5)
    assert lazy_0.bind(add).get() == 6

    lazy_1 = Lazy.of(5)
    assert lazy_1.bind(multiply).get() == Box(25)

    lazy_2 = Lazy.of('test')
    assert lazy_2.bind(multiply).get() == Box(None)


# Generated at 2022-06-25 23:47:10.007408
# Unit test for method get of class Lazy
def test_Lazy_get():

    # Test case 0
    #f = (lambda:b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}')
    b = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(b)

    assert lazy_0.get() == b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'

    # Test case 1
    #f = (lambda:3)
    i = 3
    lazy_1 = Lazy(i)

    assert lazy_1.get() == 3

    # Test case 2
    #f = (lambda:"test")

# Generated at 2022-06-25 23:47:15.980411
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = lazy_0.bind(lambda x: Lazy(x * 2))
    # @TODO: lazy_1.fold()
    # @TODO: lazy_1.fold()


# Generated at 2022-06-25 23:47:36.881954
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    str_0 = '6i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(str_0)
    lazy_2 = Lazy(bytes_0)
    lazy_3 = Lazy(str_0)
    lazy_4 = lazy_0.map(bytes.decode)
    lazy_5 = lazy_1.map(bytes.decode)
    lazy_6 = lazy_2.map(bytes.decode)
    lazy_7 = lazy_3.map(bytes.decode)

# Generated at 2022-06-25 23:47:38.189371
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    result = Lazy.of(4).bind(lambda x: Lazy.of(x + 1))
    assert result == Lazy.of(5)



# Generated at 2022-06-25 23:47:44.525569
# Unit test for method map of class Lazy
def test_Lazy_map():
    def map_fn(number):
        return number*2

    # Call function map on object Lazy_0
    Lazy_0 = Lazy.of(0)
    Lazy_1 = Lazy_0.map(map_fn)
    Lazy_2 = Lazy_1.map(map_fn)
    Lazy_3 = Lazy_2.map(map_fn)
    assert Lazy_1.get() == 0
    assert Lazy_2.get() == 0
    assert Lazy_3.get() == 0

    # Test lazy method - when constructor will be called
    Lazy_4 = Lazy_3.map(lambda n: n+1)
    assert Lazy_4.get() == 1

    # Call function map on object Lazy_1

# Generated at 2022-06-25 23:47:55.369552
# Unit test for method get of class Lazy
def test_Lazy_get():
    # test case 0
    unit_test_0 = Lazy.of(2).map(lambda x: x * 2)
    # unit test assertion 0
    assert unit_test_0.get() == 4

    # test case 1
    unit_test_1 = Lazy.of(2).map(lambda x: x * 2).map(lambda x: str(x))
    # unit test assertion 1
    assert unit_test_1.get() == '4'

    # test case 2
    unit_test_2 = Lazy.of(2).map(lambda x: x * 2).map(lambda x: str(x)).map(lambda x: int(x))
    # unit test assertion 2
    assert unit_test_2.get() == 4

    # test case 3

# Generated at 2022-06-25 23:48:08.260069
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    bytes_1 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_1 = Lazy.of(bytes_1)
    bytes_2 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_2 = Lazy.of(bytes_2)
    lazy_3 = lazy_1.ap(lazy_2)
    assert lazy_3.is_evaluated
    assert lazy_3.value == bytes_1


# Generated at 2022-06-25 23:48:17.637097
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    try:
        # Create instance of class Lazy (without calling constructor_fn)
        lazy_0 = Lazy(bytes(b''))
    except:
        return 1
    # Call bind method of class Lazy
    assert isinstance(lazy_0.bind(lambda arg0: lazy_0.bind(lambda arg0: lazy_0)),
        Lazy)
    # Call bind method of class Lazy
    assert isinstance(lazy_0.bind(lambda arg0: lazy_0.bind(lambda arg0: lazy_0)),
        Lazy)
    # Call bind method of class Lazy

# Generated at 2022-06-25 23:48:20.993826
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 2)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(x / 2)).get() == 0.5



# Generated at 2022-06-25 23:48:25.675561
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy.of(bytes_0)
    lazy_1 = Lazy.of(lazy_0.get)
    lazy_2 = lazy_1.ap(lazy_0)
    assert lazy_2 == Lazy.of(bytes_0)


# Generated at 2022-06-25 23:48:32.170092
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    data_0 = Lazy(bytes_0)
    fn_0 = Lazy.map(data_0, lambda x: b'\x00\x00\x00\x00')
    assert Lazy.map(data_0, lambda x: b'\x00\x00\x00\x00') == Lazy.of(b'\x00\x00\x00\x00')


# Generated at 2022-06-25 23:48:35.623672
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    lazy_0 = Lazy.of(Box(0))
    lazy_1 = lazy_0.map(lambda x: x.get())
    assert lazy_1.get() == 0


# Generated at 2022-06-25 23:48:56.029738
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    bytes_0 = b'r\x9b\x9bI\xdc\xec\x86\x02\x07\x00\x94'
    lazy_0 = Lazy.of(bytes_0)
    bytes_1 = b'\x02\x00\x00\x1e\x80\x9f[\xad\xd0\t\xd0'
    lazy_1 = Lazy.of(bytes_1)
    lazy_0.ap(lazy_1)


# Generated at 2022-06-25 23:49:02.924874
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_case_0():
        bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
        lazy_0 = Lazy(bytes_0)
        assert lazy_0.get() == bytes_0

    def test_case_1():
        bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
        lazy_0 = Lazy(bytes_0)
        assert lazy_0.get() == bytes_0
        assert lazy_0.get() == bytes_0

    # TEST CASE
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 23:49:13.054305
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe
    from pymonet.maybe import Just
    def maybe_2_lazy(maybe_a):
        return Lazy.of(maybe_a)
    def list_2_lazy(list_a):
        return Lazy.of(list_a)
    def lazy_2_maybe(lazy_a):
        return maybe_2_lazy(lazy_a.get())
    def lazy_2_list(lazy_a):
        return list_2_lazy(lazy_a.get())
    def append_to_int(x, y):
        return x + y
    def append_to_maybe(mayb, num):
        return mayb.ap(Lazy.of(lambda x: x + num))

# Generated at 2022-06-25 23:49:17.610482
# Unit test for method get of class Lazy
def test_Lazy_get():
    bytes_0 = b'\x136i\x01\x08\xfd\xe0!\x8dk\xce\xce\xf5}'
    lazy_0 = Lazy(bytes_0)
    str_0 = lazy_0.get()
    assert str_0 == bytes_0


# Generated at 2022-06-25 23:49:24.011947
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import random
    import string

    def random_string(length):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(length))

    lazy_0 = Lazy.of(random_string(8))
    lazy_1 = lazy_0.bind(lambda string_0: Lazy.of(string_0 + ' suffix'))

    assert lazy_1 != lazy_0
    assert lazy_1.get() == lazy_0.get() + ' suffix'
    assert lazy_1.get() == lazy_0.get() + ' suffix'
    assert lazy_1.get() == lazy_0.get() + ' suffix'


# Generated at 2022-06-25 23:49:29.375900
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy.of('')
    lazy_1 = lazy_0.bind(
        lambda string_0: Lazy.of(
            string_0.upper()
        )
    )
    lazy_2 = lazy_1.to_box()
    lazy_3 = lazy_1.to_maybe()
    lazy_4 = lazy_3.get_or_else('y')
    assert lazy_4 == 'Y'


# Generated at 2022-06-25 23:49:36.140312
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # :returns: assertion result
    # :rtype: bool
    return\
        (
            Lazy(lambda x: x) == Lazy(lambda x: x)
            and
            (
                not (
                    Lazy(lambda x: x) == Lazy(lambda: None)
                    and
                    Lazy(lambda x: x) == Lazy(lambda x: x + 1)
                )
            )
        )



# Generated at 2022-06-25 23:49:39.608349
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    lazy_0 = Lazy(lambda x: (lambda y: x + y))
    maybe_0 = Maybe.just(3)
    maybe_1 = lazy_0.ap(maybe_0).to_maybe()
    maybe_1.is_just()


# Generated at 2022-06-25 23:49:41.202145
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 23:49:53.297771
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.validation import Success, Failure

    lazy_0 = Lazy(lambda i: i + 1).bind(lambda i: Lazy(lambda j: 10 * i + 1))
    assert lazy_0.get(5) == 51

    lazy_1 = Lazy(lambda i: i + 1).bind(lambda i: Lazy(lambda j: 10 * i + j))
    assert lazy_1.get(5) == 65

    lazy_2 = Lazy(lambda i: i + 1).bind(lambda i: Lazy(lambda j: 10 * 'a' + i))
    assert lazy_2.get(5) == 'aaaaaaaaa6'


# Generated at 2022-06-25 23:50:17.192678
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test that bind method correctly take function and call constructor function passing returned value to fn function.

    :returns: True when all assertions from test were passed
    :rtype: bool
    """
    def add(value): return Lazy(lambda x: x + value)
    lazy_0 = Lazy(lambda: 1).bind(add).get()
    assert lazy_0 == 2

    return True



# Generated at 2022-06-25 23:50:26.470008
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Test with Lazy type
    t_lazy_0 = Lazy.of(0)
    t_lazy_1 = Lazy.of(1)
    t_lazy_2 = Lazy.of(lambda x: x + 1)

    assert t_lazy_2.ap(t_lazy_1).get() == 2
    assert t_lazy_1.ap(t_lazy_2).get() == 2
    assert t_lazy_1.ap(t_lazy_0).get() == 1
    assert t_lazy_0.ap(t_lazy_2).get() == 1

    # Test with Box type
    from pymonet.box import Box

    t_box_0 = Box(0)
    t_box_1 = Box(1)
    t_box_