

# Generated at 2022-06-25 23:40:29.135054
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = -1898

    fn_0 = lambda val: val * 0.099
    fn_1 = lambda val: val - 5
    fn_2 = lambda val: val

    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(fn_0)
    lazy_2 = Lazy(fn_1)
    lazy_3 = Lazy(fn_2)

    assert lazy_0.get() is None
    assert lazy_1.get() is None
    assert lazy_2.get() is None
    assert lazy_3.get() is None

    res_0 = lazy_0.bind(fn_0).bind(fn_1)
    res_1 = lazy_1.bind(fn_0).bind(fn_1)

# Generated at 2022-06-25 23:40:35.253995
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1).__eq__(Lazy.of(1))
    assert not Lazy.of(1).__eq__(Lazy.of(2))
    assert not Lazy.of(1).__eq__(Lazy.of(1.0))
    assert not Lazy.of(1).__eq__(Lazy.of(None))
    assert Lazy.of(None).__eq__(Lazy.of(None))


# Generated at 2022-06-25 23:40:45.880090
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 1498
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(int_0)
    assert lazy_0 == lazy_1
    int_1 = -1898
    lazy_0 = Lazy(int_1)
    lazy_1 = Lazy(int_1)
    assert lazy_0 == lazy_1
    int_2 = -1498
    lazy_0 = Lazy(int_2)
    lazy_1 = Lazy(int_2)
    assert lazy_0 == lazy_1
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(int_1)
    assert lazy_0 != lazy_1
    lazy_0 = Lazy(int_1)
    lazy_1 = Lazy(int_2)
    assert lazy

# Generated at 2022-06-25 23:40:55.030750
# Unit test for method __eq__ of class Lazy

# Generated at 2022-06-25 23:41:02.259908
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    def fn(x: int) -> Lazy[int, int]:
        def func(x_1: int) -> int:
            return x_1
        return Lazy(func)
    res_0 = Lazy(func)
    lazy_1 = lazy_0.bind(fn)
    assert lazy_1 == res_0
    lazy_2 = Lazy(int_0)
    assert lazy_2 == lazy_1.bind(fn)


# Generated at 2022-06-25 23:41:11.160343
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Just, Nothing
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(15).get() == 15
    assert Lazy.of(Box(625)).get().get() == 625
    assert Lazy.of(Right(321)).get().get() == 321
    assert Lazy.of(Just(2)).get().get() == 2
    assert Lazy.of(Nothing).get().get() is None
    assert Lazy.of(Try(lambda: 798)).get().get() == 798
    assert Lazy.of(Validation.success(10)).get().get() == 10

# Generated at 2022-06-25 23:41:15.576293
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = 'test'
    str_1 = 'test-test'

    lazy_0 = Lazy(lambda *args: Lazy.of(str_1))

    assert lazy_0.bind(lambda *args: Lazy.of(str_1)).get() == str_1


# Generated at 2022-06-25 23:41:24.927125
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert(Lazy(lambda: 42) == Lazy(lambda: 42))
    assert(Lazy(lambda: 42) == Lazy(lambda: 42) == Lazy(lambda: 42))
    assert(Lazy(lambda: 42) == Lazy(lambda: 42) == Lazy(lambda: 42) == Lazy(lambda: 42))

    assert(Lazy(lambda: 42) != Lazy(lambda: 43))
    assert(Lazy(lambda: 42) != Lazy(lambda: 43) != Lazy(lambda: 44))
    assert(Lazy(lambda: 42) != Lazy(lambda: 43) != Lazy(lambda: 44) != Lazy(lambda: 45))

    assert(Lazy(lambda: 42) != None)
    assert(Lazy(lambda: 42) != None != None)

# Generated at 2022-06-25 23:41:33.971105
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from operator import add, sub
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy(lambda: add).ap(Box.of(5)).get() == Lazy(lambda: add).get()(5)
    assert Lazy(lambda: sub).ap(Box.of(5)).get() == Lazy(lambda: sub).get()(5)
    assert Lazy(lambda: add).ap(Try.of(lambda: 1)).get() == Lazy(lambda: add).get()(1)
    assert Lazy(lambda: sub).ap(Try.of(lambda: 9)).get() == Lazy(lambda: sub).get()(9)
    assert Lazy(lambda: add).ap(Validation.of(5)).get()

# Generated at 2022-06-25 23:41:42.321976
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    int_0 = -1898
    int_1 = 1898
    int_2 = -1898
    int_3 = 1598
    str_0 = 'str_0'
    str_1 = 'str_1'
    str_2 = 'str_0'
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(int_1)
    lazy_2 = Lazy(int_2)
    lazy_3 = Lazy(int_3)
    lazy_4 = Lazy.of(int_2)
    lazy_5 = Lazy.of(int_3)
    lazy_6 = Lazy(str_0)
    lazy_7 = L

# Generated at 2022-06-25 23:41:46.355789
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1898).get() == 1898



# Generated at 2022-06-25 23:41:54.504911
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_case_0():
        int_0 = -1898
        lazy_0 = Lazy.of(int_0)
        lazy_1 = Lazy.of(1898)
        lazy_2 = Lazy.of(int_0)
        assert lazy_0 == lazy_2
        assert lazy_0 != lazy_1
    test_case_0()

    def test_case_1():
        int_0 = -1898
        lazy_0 = Lazy.of(int_0)
        lazy_1 = Lazy.of(int_0)
        assert lazy_0 == lazy_1
    test_case_1()

    def test_case_2():
        lazy_0 = Lazy.of(1898)
        assert lazy_0 == lazy_0
    test_case_2()


# Generated at 2022-06-25 23:42:05.746475
# Unit test for method map of class Lazy
def test_Lazy_map():
    def string_function(number: int) -> str:
        return str(number)

    def int_function(string: str) -> int:
        return int(string)

    int_0 = -1898
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(string_function)
    assert lazy_0.map(string_function).get() == string_function(int_0)

    lazy_3 = lazy_0.map(string_function).map(string_function).map(int_function)
    assert lazy_3.get() == int_function(string_function(string_function(int_0)))

    lazy_4 = lazy_1.map(string_function).map(string_function).map(int_function)

# Generated at 2022-06-25 23:42:16.998158
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
        Test for method bind of class Lazy
    """
    from pymonet.monad_dict import MonadDict
    from pymonet.monad_list import MonadList
    from pymonet.monad_set import MonadSet
    from pymonet.monad_tuple import MonadTuple
    from pymonet.box import Box

    def f(x):
        def g(y):
            return x / y

        return Lazy(g)

    def h(x):
        def g(y):
            return x / y

        return Box(g)

    monads = (
        MonadList(),
        MonadDict(),
        MonadSet(),
        MonadTuple(),
        Box(),
    )


# Generated at 2022-06-25 23:42:20.184738
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = -1898
    lazy_0 = Lazy.of(int_0)
    int_1 = lazy_0.get()
    assert int_1 == int_0


# Generated at 2022-06-25 23:42:31.444334
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Test 0
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    assert lazy_0.get() == int_0

    # Test 1
    def function_1(argument_1):
        return (argument_1 + 2) * 2
    lazy_1 = Lazy(function_1)
    assert lazy_1.get(1) == 6

    # Test 2
    class Class_2(object):
        def __init__(self):
            self.bool_0 = True
        def method_0(self, argument_1):
            return argument_1 if self.bool_0 else argument_1 + 2
    class_2 = Class_2()
    lazy_2 = Lazy(class_2.method_0)
    assert lazy_2.get(1) == 1

    #

# Generated at 2022-06-25 23:42:39.559861
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    class test_Lazy_bind:
        def test_0(self):
            def fn(a):
                return Lazy(a.split(""))
            assert Lazy("test").bind(fn).get() == ["t", "e", "s", "t"]
        def test_1(self):
            def fn(a):
                return Lazy(a.split(""))
            assert Lazy("another_test").bind(fn).get() == ["a", "n", "o", "t", "h", "e", "r", "_", "t", "e", "s", "t"]
        def test_2(self):
            def fn(a):
                return Lazy(a.split(""))

# Generated at 2022-06-25 23:42:41.773655
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy(3)
    lazy_1 = lazy_0.bind(Lazy.of)
    assert lazy_1 == Lazy(lambda: 3)



# Generated at 2022-06-25 23:42:44.024809
# Unit test for method map of class Lazy
def test_Lazy_map():
    result = Lazy(lambda: 1).map(lambda x: x + 1)
    assert result == Lazy(lambda: 2)



# Generated at 2022-06-25 23:42:53.640208
# Unit test for method __eq__ of class Lazy

# Generated at 2022-06-25 23:43:08.302468
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = -1898
    int_1 = -2102
    int_2 = -2102
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(int_1)
    lazy_2 = Lazy(int_2)
    assert (lazy_0.__eq__(lazy_1) is False)
    assert (lazy_1.__eq__(lazy_0) is False)
    assert (lazy_1.__eq__(lazy_2) is True)
    assert (lazy_2.__eq__(lazy_1) is True)


# Generated at 2022-06-25 23:43:12.351441
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Case 1:
    fn_const = lambda x: x
    lazy_0 = Lazy(fn_const)
    fn_0 = lambda x: fn_const(x)
    lazy_1 = lazy_0.bind(fn_0)
    assert lazy_1.get(1) == 1



# Generated at 2022-06-25 23:43:14.949288
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    assert lazy_0.get() == int_0


# Generated at 2022-06-25 23:43:18.770970
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = -5
    lazy_0 = Lazy(int_0)
    lazy_0_bind_fn = lambda x: Lazy.of(x)
    lazy_1 = lazy_0.bind(lazy_0_bind_fn)

    assert lazy_1 == lazy_0


# Generated at 2022-06-25 23:43:20.800009
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(int_0)
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:43:24.769075
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(2) != Lazy.of(1)
    assert Lazy.of(1) != 1
    assert Lazy.of({}) != Lazy.of({})
    assert Lazy.of([]) != Lazy.of([])
    assert Lazy.of(lambda: 1) != Lazy.of(lambda: 1)
    assert Lazy.of(()) != Lazy.of(())



# Generated at 2022-06-25 23:43:34.772517
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def double(value):
        return 2 * value

    def square(value):
        return value * value

    # check if bind lazy function calls function from constructor
    result = Lazy(lambda: 1).bind(double).get()
    assert result == double(1)

    # check if bind lazy function calls function from constructor twice
    result = Lazy(lambda: 1).bind(double).bind(square).get()
    assert result == square(double(1))

    # check if bind lazy function calls function from constructor and map result of this function
    result = Lazy(lambda: 1).bind(double).map(square).get()
    assert result == square(double(1))



# Generated at 2022-06-25 23:43:38.396416
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(int_0)
    boolean_0 = lazy_0.__eq__(lazy_1)
    assert boolean_0 == True


# Generated at 2022-06-25 23:43:40.318430
# Unit test for method get of class Lazy
def test_Lazy_get():
    test_cases = [
        (1, 1),
        (None, None),
        (lambda: "test", "test")
    ]

    for value, expected in test_cases:
        lazy_value = Lazy(value)
        assert lazy_value.get() == expected


# Generated at 2022-06-25 23:43:47.320597
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_case_0():
        def fn(arg):
            return Lazy(lambda *args: arg + args[0])

        lazy_0 = Lazy.of(0)
        lazy_0_binded = lazy_0.bind(fn)
        assert lazy_0_binded.get(1) == 1

    def test_case_1():
        def fn(arg):
            return Lazy(lambda *args: arg + args[0])

        lazy_0 = Lazy(10)
        lazy_0_binded = lazy_0.bind(fn)
        assert lazy_0_binded.get(1) == 11
        assert lazy_0_binded.get(2) == 11


# Generated at 2022-06-25 23:44:00.786185
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # test ap with Lazy[A, B] -> Lazy[Function(A) -> B]
    def test_case_1():
        lazy_0 = Lazy.of(lambda a, b: a * b)
        lazy_1 = Lazy.of(13)
        lazy_2 = Lazy.of(4)

        assert lazy_0.ap(lazy_1).ap(lazy_2).get() == 52

    def test_case_2():
        def get_lazy_of_int(i: int) -> Lazy[int, int]:
            return Lazy(lambda: i)

        def get_lazy_of_fizzbuzz(i: int) -> Lazy[int, str]:
            return Lazy(lambda: 'Fizz' if i % 3 == 0 else 'Buzz')

        lazy_

# Generated at 2022-06-25 23:44:03.997971
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = -1898
    lazy_0 = Lazy.of(int_0)
    assert lazy_0.get() == int_0, "lazy_0.get() != int_0, test failed"



# Generated at 2022-06-25 23:44:07.876652
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def int_square_function(value):
        return value * value

    int_0 = -1898
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.bind(lambda value: Lazy(int_square_function(value)))
    assert lazy_0.get() == int_0
    assert lazy_1.get() == int_square_function(int_0)
    assert lazy_1 != lazy_0
    assert lazy_0 == lazy_0


# Generated at 2022-06-25 23:44:17.882801
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pymonet.functions as f
    def bind_test(lazy: Lazy[int, int], fn: Callable[[int], Lazy[int, int]]):
        return \
            lazy.bind(fn).get() == fn(lazy.get()).get() and \
            fn(lazy.get()).constructor_fn == lazy.constructor_fn

    def test_0():
        return bind_test(Lazy(f.id), f.square)

    def test_1():
        return bind_test(Lazy(f.square), f.id)

    def test_2():
        return bind_test(Lazy(f.square), f.square)

    def test_3():
        return bind_test(Lazy(f.id), f.id)

    assert test_0()
   

# Generated at 2022-06-25 23:44:28.029417
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    try:
        lazy_0.get()
        assert False
    except TypeError:
        assert True

    int_1 = 902
    lazy_1 = Lazy(int_1)
    try:
        lazy_1.get()
        assert False
    except TypeError:
        assert True

    str_0 = 'Y/qlFv[#'
    lazy_2 = Lazy(str_0)
    assert lazy_2.get() == 'Y/qlFv[#'

    int_2 = -3614
    lazy_3 = Lazy(int_2)
    try:
        lazy_3.get()
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-25 23:44:32.949084
# Unit test for method get of class Lazy
def test_Lazy_get():
    def take_empty_value_fn() -> None:
        lazy = Lazy[None, int](lambda: 1)

        value = lazy.get()

        assert value == 1

    def take_value_fn() -> None:
        lazy = Lazy[None, int](lambda: 1)

        lazy.get()
        value = lazy.get()

        assert value == 1

    take_empty_value_fn()
    take_value_fn()



# Generated at 2022-06-25 23:44:36.883541
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_int_0 = Lazy(lambda : 123)
    assert lazy_int_0.get() == 123
    assert lazy_int_0.get() == 123

    lazy_int_1 = Lazy(lambda : 456)
    assert lazy_int_1.get() == 456
    assert lazy_int_1.get() == 456


# Generated at 2022-06-25 23:44:47.783574
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    str_0 = 'Hello world!'
    str_1 = 'Hello world!'
    str_2 = 'Hello world!'
    str_3 = 'Hello world!'
    str_4 = 'Hello world!'
    str_5 = 'Hello world!'
    str_6 = 'Hello world!'
    str_7 = 'Hello world!'
    str_8 = 'Hello world!'
    str_9 = 'Hello world!'
    str_10 = 'Hello world!'
    str_11 = 'Hello world!'
    str_12 = 'Hello world!'
    str_13 = 'Hello world!'
    str

# Generated at 2022-06-25 23:44:51.244556
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy(lambda x: x * x)
    lazy_1 = Lazy(lambda v: v + 1)

    lazy_2 = lazy_0.ap(lazy_1)

    assert lazy_2.constructor_fn(1) == 4



# Generated at 2022-06-25 23:44:52.483466
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)


# Generated at 2022-06-25 23:44:58.787629
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    assert lazy_0.get() == int_0
    assert lazy_0.is_evaluated
    assert lazy_0.value == int_0


# Generated at 2022-06-25 23:45:08.599072
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(15).get() == 15
    assert Lazy.of(0).get() == 0
    assert Lazy.of(-15).get() == -15
    assert Lazy.of(0.1).get() == 0.1
    assert Lazy.of(-0.1).get() == -0.1
    assert Lazy.of('str').get() == 'str'
    assert Lazy.of(True).get() == True
    assert Lazy.of(False).get() == False
    assert Lazy.of(None).get() == None
    assert Lazy.of([]).get() == []
    assert Lazy.of([1, 2, 3]).get() == [1, 2, 3]

# Generated at 2022-06-25 23:45:11.179904
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = -1898
    lazy_0 = Lazy.of(int_0)
    assert lazy_0.get() == int_0


# Generated at 2022-06-25 23:45:17.171160
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    test_lazy = lambda x: lazy_0.bind(lambda y: Lazy(lambda *args: y * x))
    assert str(test_lazy(1)) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'
    assert test_lazy(0).get() == 0



# Generated at 2022-06-25 23:45:21.391429
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given: lazy value
    int_value = -1898
    lazy_value = Lazy(int_value)

    # And: transformation function
    def mapper(value):
        return value * 2

    # When: I call map on Lazy with argument a function
    lazy_map_result = lazy_value.map(mapper)

    # Then: Lazy with transformed value should be returned
    assert lazy_map_result == Lazy(-3796)


# Generated at 2022-06-25 23:45:32.563196
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    test_cases = (
        (481827,),
        (2,),
        (0,),
        ('a',),
        ('',),
        (True,),
        (None,),
        ([],),
        ({},),
    )
    for test_case in test_cases:
        from pymonet.box import Box
        from pymonet.func import fn
        from pymonet.type_signatures import _0, _1

        string_0 = 'test_Lazy_bind'
        int_0 = test_case[0]
        int_1 = -int_0

        lazy_0 = Lazy(int_0)
        lazy_1 = lazy_0.bind(fn(int, _0))
        box_1 = Box(int_0)
        assert lazy_1.get()

# Generated at 2022-06-25 23:45:41.594959
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Test case 0
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    lazy_function_0 = lambda int_1 : Lazy(int_1)
    lazy_1 = lazy_0.bind(lazy_function_0)
    assert lazy_1.get() == -1898, "Bind method of Lazy class is incorrect"
    # Test case 1
    int_1 = 0
    lazy_2 = Lazy(int_1)
    lazy_function_1 = lambda int_2 : Lazy(int_2)
    lazy_3 = lazy_2.bind(lazy_function_1)
    assert lazy_3.get() == 0, "Bind method of Lazy class is incorrect"
    # Test case 2
    int_2 = -3361
    lazy_4 = L

# Generated at 2022-06-25 23:45:49.155193
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(0) == Lazy.of(0), "Lazy[0] is not equal to Lazy[0]"

    assert Lazy.of(0) != Lazy.of(1), "Lazy[0] is equal to Lazy[1]"
    assert Lazy.of(0) != None, "Lazy[0] is equal to None"
    assert Lazy.of(0) != 0, "Lazy[0] is equal to 0"


# Generated at 2022-06-25 23:45:53.729857
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    print("Test __eq__ of class Lazy")

    int_0 = -1898
    lazy_0 = Lazy(int_0)

    int_1 = -1898
    lazy_1 = Lazy(int_1)

    assert lazy_0 == lazy_1
    assert lazy_0 == lazy_0


# Generated at 2022-06-25 23:46:03.294318
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor import Functor
    from pymonet.box import Box
    from pymonet.monad_try import Try

    lazy_0 = Lazy.of(1)
    lazy_1 = lazy_0.bind(lambda x: Try.of(lambda _: x + 1))
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.get() == 2

    lazy_2 = lazy_0.bind(lambda x: Box(x + 1))
    assert isinstance(lazy_2, Lazy)
    assert lazy_2.get() == 2

    lazy_3 = lazy_0.bind(lambda x: Functor.of(x + 1))
    assert isinstance(lazy_3, Lazy)
    assert lazy_3.get() == 2



# Generated at 2022-06-25 23:46:18.824373
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    int_0 = -1898
    lazy_0 = Lazy(int_0)
    assert lazy_0.is_evaluated == False
    assert lazy_0.value == None

    result = lazy_0.map(lambda x: x * 2)
    assert lazy_0.is_evaluated == False
    assert lazy_0.value == None
    assert result.is_evaluated == False
    assert result.value == None

    assert result.get() == -3796
    assert lazy_0.is_evaluated == True
    assert lazy_0.value == None
    assert result.is_evaluated == True
    assert result.value == -3796


# Generated at 2022-06-25 23:46:25.012258
# Unit test for method map of class Lazy
def test_Lazy_map():
    class DummyMapperClass:
        def __init__(self, map_value):
            self.map_value = map_value

        def __call__(self, value):
            return self.map_value

    map_value = -1943

    map_function = DummyMapperClass(map_value)
    lazy = Lazy(None)
    result = lazy.map(map_function)
    assert isinstance(result, Lazy)
    assert result.constructor_fn(None) == map_value



# Generated at 2022-06-25 23:46:27.745458
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = 4
    lazy_0 = Lazy(int_0)
    result = lazy_0.get()
    assert result == 4


# Generated at 2022-06-25 23:46:38.195536
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(0x100).bind(lambda x: Lazy.of(x)).get() == 0x100
    assert Lazy.of(0x100).bind(lambda x: Lazy.of(x)).get() == 0x100
    assert Lazy.of(0x100).bind(lambda x: Lazy.of(x)).get() == 0x100
    assert Lazy.of(0x100).bind(lambda x: Lazy.of(x)).get() == 0x100
    assert Lazy.of(0x100).bind(lambda x: Lazy.of(x)).get() == 0x100
    assert Lazy.of(0x100).bind(lambda x: Lazy.of(x)).get() == 0x100

# Generated at 2022-06-25 23:46:42.570446
# Unit test for method get of class Lazy
def test_Lazy_get():
    start_time = time.time()
    int_0 = -1911
    lazy_0 = Lazy(int_0)
    assert lazy_0.get() == lazy_0.constructor_fn()
    print("--- %s seconds ---" % (time.time() - start_time))


# Generated at 2022-06-25 23:46:46.919252
# Unit test for method get of class Lazy
def test_Lazy_get():

    # setUp
    int_0 = -1898
    lazy_0 = Lazy(int_0)

    # Test case
    assertEqual(lazy_0.get(), int_0)
    assertEqual(lazy_0.is_evaluated, True)



# Generated at 2022-06-25 23:46:54.256918
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test calling `bind` method of `Lazy` class.

    1. Make sure that when bind is called with function which returns empty Lazy it will return empty Lazy
    2. Make sure that when bind is called with identity function it will return copy of the same Lazy
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try, Error

    # First test case
    try_0: Try[int] = Try.of(lambda x: x, [1, 2, 3])
    lazy_0: Lazy[int, Any] = Lazy.of(lambda x: try_0).bind(lambda x: Lazy.of(lambda *args: None))
    assert lazy_0 == Lazy.of(lambda *args: None)

    # Second test case

# Generated at 2022-06-25 23:46:57.365324
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    lazy_0.get()
    assert lazy_0.is_evaluated
    assert lazy_0.value == int_0


# Generated at 2022-06-25 23:47:05.540801
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Create function and expect result is equal after call result to method bind of class Lazy
    def mul_by_2(x):
        return x * 2

    int_0 = 5
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.bind(mul_by_2)

    print('DEBUG: test_case_0:', lazy_0)
    print('DEBUG: test_case_1:', lazy_0)
    assert lazy_1.get() == 10



# Generated at 2022-06-25 23:47:11.525209
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = -1898
    int_1 = -1898
    int_2 = 1898
    int_3 = 1898
    lazy_0 = Lazy.of(int_0)
    int_4 = lazy_0.map(lambda x: int(x)).get()
    assert int_4 == int_1
    lazy_1 = Lazy.of(int_2)
    int_5 = lazy_1.map(lambda x: int(x)).get()
    assert int_5 == int_3


# Generated at 2022-06-25 23:47:22.460721
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_2(n):
        return n + 2
    lazy_0 = Lazy.of(12)
    assert lazy_0.bind(add_2).get() == 14


# Generated at 2022-06-25 23:47:29.927412
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = -1934
    lazy_0 = Lazy(int_0)
    lazy_0 = Lazy.of(int_0)
    lazy_0 = Lazy(int_0)
    lazy_0 = Lazy(int_0)
    lazy_0 = Lazy(bool)
    lazy_0 = Lazy(str)
    lazy_0 = Lazy(int_0)

    double_lazy_0 = lazy_0.map(lambda value: value * 2)

    return double_lazy_0


# Generated at 2022-06-25 23:47:34.962786
# Unit test for method map of class Lazy
def test_Lazy_map():

    # Test with empty Lazy
    def runTest(test_input):
        result = Lazy.of(test_input)
        mapped_result = result.map(lambda x: x * 2).map(lambda x: x + 1)

        assert mapped_result.get() == (test_input * 2) + 1

    for test_input in range(1, 50):
        runTest(test_input)


# Generated at 2022-06-25 23:47:43.350503
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def plus(a, b): return a + b

    def multiply(a, b): return a * b

    def divide(a, b): return a / b

    int_0 = 5
    int_1 = 3

    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(int_1)

    lazy_plus = lazy_0.ap(Lazy(plus))
    lazy_multiply = lazy_0.ap(Lazy(multiply))
    lazy_divide = lazy_0.ap(Lazy(divide))

    assert lazy_plus.get() == plus(int_0, int_1)
    assert lazy_multiply.get() == multiply(int_0, int_1)
    assert lazy_divide.get() == divide(int_0, int_1)


# Generated at 2022-06-25 23:47:45.211606
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = -1898
    lazy_0 = Lazy.of(int_0)
    assert lazy_0.get() == int_0

# Generated at 2022-06-25 23:47:56.266003
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    assert lazy_0.get() == -1898
    int_1 = -15
    lazy_1 = Lazy(int_1)
    assert lazy_1.get() == -15
    int_2 = -13
    lazy_2 = Lazy(int_2)
    assert lazy_2.get() == -13
    int_3 = -17
    lazy_3 = Lazy(int_3)
    assert lazy_3.get() == -17
    mixed_0 = -13.0100
    lazy_4 = Lazy(mixed_0)
    assert lazy_4.get() == -13.01
    mixed_1 = -0.000
    lazy_5 = Lazy(mixed_1)
    assert lazy

# Generated at 2022-06-25 23:48:01.369518
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.either import Right
    from pymonet.validation import Validation

    def test_fn(x):
        return Right(x)
    lazy_fn = Lazy(test_fn)
    lazy_fn_eq = Lazy(test_fn)
    lazy_fn_not_eq = Lazy(lambda x: Validation.success(x))

    assert lazy_fn == lazy_fn_eq
    assert lazy_fn != lazy_fn_not_eq



# Generated at 2022-06-25 23:48:08.672220
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for method bind.
    """
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    def fn_0(*args):
        from pymonet.list import Cons
        from pymonet.list import Nil
        return Cons(3.1718, Nil())
    lazy_1 = lazy_0.bind(fn_0)
    assert lazy_1._compute_value() == Cons(3.1718, Nil())


# Generated at 2022-06-25 23:48:13.504381
# Unit test for method get of class Lazy
def test_Lazy_get():
    def get_lazy_0():
        int_0 = -1898
        lazy_0 = Lazy.of(int_0)
        int_1 = lazy_0.get()
        assert int_1 == int_0, 'lazy_0.get() returned: ' + str(int_1)
        return int_1

    get_lazy_0()


# Generated at 2022-06-25 23:48:22.975551
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_2 = 3
    lazy_2 = Lazy(int_2)


    def test_fn_2(x):
        int_3 = x
        int_4 = int_3 * int_3
        return int_4
    lazy_3 = Lazy(test_fn_2)


    def test_fn_4(y):
        int_5 = y
        int_6 = int_5 + int_5
        return int_6
    lazy_4 = Lazy(test_fn_4)

    def test_fn_6(x):
        return x
    lazy_6 = Lazy(test_fn_6)

    def test_fn_7(y):
        int_7 = y
        int_8 = int_7 * int_7
        return int_8
    lazy_7 = L

# Generated at 2022-06-25 23:48:47.979435
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.utils import curry
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    int_0 = -1898
    str_0 = 'test'
    list_0 = [1, 2, 3, 4]

    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(str_0)
    lazy_2 = Lazy(list_0)

    function = lambda x : x * 2

    assert(lazy_0.ap(Lazy(function)) == Lazy(function(int_0)))
    assert(lazy_0.ap(Lazy(function)).ap(lazy_0) == Lazy(function(int_0)).ap(lazy_0))

# Generated at 2022-06-25 23:48:57.480923
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = -1898
    lazy_0 = Lazy(lambda: int_0)
    def fn_0(arg_0):
        return Lazy(lambda: arg_0)
    assert lazy_0.bind(fn_0) == Lazy(lambda: int_0)
    def fn_0(arg_0):
        return Lazy(lambda: arg_0 + 1)
    assert lazy_0.bind(fn_0) == Lazy(lambda: int_0 + 1)
    int_0 = 2023
    lazy_0 = Lazy(lambda: int_1)
    def fn_0(arg_0):
        return Lazy(lambda: arg_0)
    assert lazy_0.bind(fn_0) == Lazy(lambda: int_1)

# Generated at 2022-06-25 23:49:00.646400
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_1 = 233
    lazy_1 = Lazy.of(int_1)

    def fn(x):
        return Lazy.of(x)

    lazy_2 = lazy_1.bind(fn)

    def test_case_0():
        assert lazy_2.get() == int_1



# Generated at 2022-06-25 23:49:02.964008
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    int_1 = lazy_0.get()
    assert int_0 == int_1


# Generated at 2022-06-25 23:49:11.765236
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # GIVEN
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    int_0 = -231
    lazy_0 = Lazy.of(int_0)
    maybe_int_0 = Maybe.just(int_0)
    validation_int_0 = Validation.success(int_0)

    # WHEN
    lazy_1 = lazy_0.ap(maybe_int_0)
    lazy_2 = lazy_0.ap(validation_int_0)

    # THEN
    assert lazy_1.get() == int_0
    assert lazy_2.get() == int_0


# Generated at 2022-06-25 23:49:17.981187
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = 18;
    int_1 = -139;

    lazy_0 = Lazy.of(int_0)
    lazy_1 = Lazy.of(int_1)
    result = lazy_0.get()
    assert result == lazy_0.constructor_fn()
    assert result == int_0
    assert result == lazy_0.value

    result = lazy_1.get()
    assert result == lazy_1.value
    assert result == int_1



# Generated at 2022-06-25 23:49:24.620828
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy.of(456)
    lazy_1 = Lazy.of(123)
    lazy_2 = Lazy.of(0)
    lazy_3 = Lazy.of(False)
    lazy_4 = Lazy.of(0.5)
    lazy_5 = Lazy.of('f')
    lazy_6 = Lazy.of(4.0)

    lazy_7 = Lazy.of('')
    lazy_8 = Lazy.of(0)
    lazy_9 = Lazy.of(False)
    lazy_10 = Lazy.of(None)

    lazy_11 = Lazy.of(None)
    lazy_12 = Lazy.of(0)
    lazy_13 = Lazy.of(0)
    lazy_14 = Lazy.of(0)



# Generated at 2022-06-25 23:49:34.985299
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_0 = Lazy.of(123)
    assert 123 == lazy_0.get()

    lazy_0 = Lazy.of(123)
    assert 123 == lazy_0.get(1, 2, 3)

    lazy_0 = Lazy.of(123)
    assert 123 == lazy_0.get(1, 2, [3])

    # Test with one argument
    lazy_0 = Lazy.of(lambda x: x)
    assert 4 == lazy_0.get(4)

    # Test with two argument
    lazy_0 = Lazy.of(lambda x, y: x + y)
    assert 7 == lazy_0.get(4, 3)

    # Test with three argument
    lazy_0 = Lazy.of(lambda x, y, z: x + y + z)
    assert 10 == lazy

# Generated at 2022-06-25 23:49:42.941773
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_list import List

    int_0 = -1898
    lazy_0 = Lazy[int](int_0)

    # Lazy[int] -> Lazy[bool]
    lazy_1 = lazy_0.map(lambda arg_0: arg_0 < 0)
    # Lazy[bool] -> Lazy[str]
    lazy_2 = lazy_1.map(lambda arg_0: str(arg_0))

    # Lazy[str] -> Lazy[List[str]]
    lazy_3 = lazy_2.ap(Lazy(lambda arg_0: List(arg_0)))


# Generated at 2022-06-25 23:49:54.983015
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    int_0 = -1898
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.bind(lambda int_0: Lazy(lambda: int_0))
    lazy_1.get()
    assert (lazy_1.get(int, int) == lazy_0.get(int, int))

    my_datetime = datetime.datetime
    lazy_0 = Lazy(my_datetime)
    lazy_1 = lazy_0.bind(lambda my_datetime: Lazy(lambda: my_datetime))
    assert(lazy_1.get(datetime, datetime) == lazy_0.get(datetime, datetime))

    my_str = "Hello"
    lazy_0 = Lazy(my_str)

# Generated at 2022-06-25 23:50:19.241613
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation

    # Test for method ap of class Lazy
    int_0 = -1898
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.ap(lazy_0)
    assert lazy_1 == Lazy.of(int_0 ** int_0)

    # Test for method ap of class Lazy
    lazy_0 = Lazy(int_0)
    lazy_1 = Validation.of(int_0).ap(lazy_0)
    assert lazy_1 == Lazy.of(int_0 ** int_0)

    # Test for method ap of class Lazy
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(lambda: int_0).ap(lazy_0)
    assert lazy_1

# Generated at 2022-06-25 23:50:22.005732
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
