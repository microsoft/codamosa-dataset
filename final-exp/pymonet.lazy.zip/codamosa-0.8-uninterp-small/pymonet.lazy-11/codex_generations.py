

# Generated at 2022-06-25 23:40:32.599441
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def mapper_0(parameter_0):
        return parameter_0 + 1
    float_0 = 1541.7829
    lazy_0 = Lazy(float_0)
    lazy_1 = Lazy(lambda : mapper_0(lazy_0.constructor_fn()))
    lazy_2 = lazy_0.bind(mapper_0)
    assert lazy_1 == lazy_2


# Generated at 2022-06-25 23:40:38.937730
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(None).__eq__(Lazy.of(None))
    assert not Lazy.of(None).__eq__(Lazy.of(1))
    assert not Lazy.of(1).__eq__(Lazy.of(None))
    assert Lazy.of(1).__eq__(Lazy.of(1))
    assert not Lazy.of(1).__eq__(Lazy.of(2))

# Assert if methods map, ap, bind and fold return correct value

# Generated at 2022-06-25 23:40:43.935242
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    func1 = lambda x: x + 1
    lazy_0 = Lazy.of(func1)
    lazy_1 = Lazy.of(5)
    lazy_2 = lazy_0.ap(lazy_1)

    assert lazy_2.get() == lazy_1.get() + 1


# Generated at 2022-06-25 23:40:46.826151
# Unit test for method get of class Lazy
def test_Lazy_get():
    my_float = 1541.7829
    lazy_0 = Lazy(my_float)

    assert isinstance(lazy_0.get(), float)
    assert lazy_0.get() == my_float



# Generated at 2022-06-25 23:40:56.174232
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(16) == Lazy(16)
    assert Lazy(10).get() == 10
    assert Lazy('16').get() == '16'

# Generated at 2022-06-25 23:40:58.710080
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda a: a).ap(Lazy.of(5)) == Lazy.of(5)



# Generated at 2022-06-25 23:41:05.680392
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    float_0 = 64.923809523809526
    lazy_0 = Lazy.of(float_0)
    float_1 = 75.0
    lazy_1 = Lazy.of(float_1)
    str_0 = str(lazy_0)
    str_1 = str(lazy_1)
    float_2 = float_1 + float_0
    lazy_2 = lazy_0.map(str)
    lazy_3 = lazy_1.map(str)
    # Assert statements
    assert float_2 == float_0 + float_1
    assert str_1 == str(lazy_1)
    assert str_0 == str(lazy_0)
    assert lazy_2 == lazy_3
    assert lazy_1 == lazy_1
    assert lazy_0 != lazy_1

# Generated at 2022-06-25 23:41:10.090466
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # Create instance for class Lazy
    float_0 = 1541.7829
    box_0 = Lazy(float_0)
    box_1 = Lazy(float_0)

    # Merge x and y for testing
    x = (box_0, box_1)

    # Call __eq__ method of class Lazy
    assert box_0 == box_1


# Generated at 2022-06-25 23:41:12.468138
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    fn_0 = lambda x: x + 1
    lazy_0 = Lazy(fn_0)
    lazy_1 = lazy_0.bind(fn_0)
    equal(lazy_0, lazy_1)


# Generated at 2022-06-25 23:41:18.513128
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    float_0 = 1541.7829
    lazy_0 = Lazy(float_0)

    float_1 = 1753.1364
    lazy_1 = Lazy(float_1)

    def lambda_fn(x):
        try:
            return float(x)
        except TypeError:
            return 0

    lazy_2 = lazy_0.ap(lazy_1).map(lambda_fn)
    assert float(lazy_2.get()) == float_0 + float_1



# Generated at 2022-06-25 23:41:26.226926
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    try:
        lazy_0 = Lazy.of(5)
        assert(5 == lazy_0.get())
        lazy_1 = Lazy.of(5)
        assert(5 == lazy_1.get())
        lazy_2 = lazy_0.ap(lazy_1)
        assert(25 == lazy_2.get())
    except AssertionError:
        print("Lazy_ap test failed")


# Generated at 2022-06-25 23:41:34.369239
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    test_lazy_a = Lazy(lambda: 1)
    test_lazy_b = Lazy(lambda: 2)
    test_lazy_c = Lazy(lambda: 2)
    test_lazy_d = Lazy(lambda: 1)
    test_lazy_e = Lazy(lambda: 2)
    test_lazy_f = Lazy(lambda: 1)
    assert test_lazy_a == test_lazy_d
    assert test_lazy_b == test_lazy_c
    assert test_lazy_e == test_lazy_b
    assert test_lazy_a == test_lazy_f
    assert test_lazy_a != test_lazy_b



# Generated at 2022-06-25 23:41:42.644020
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    float_0 = 1541.7829
    lazy_0 = Lazy(float_0)
    lazy_1 = lazy_0.map(lambda f: f / 4)
    assert lazy_1.get() == float_0 / 4
    assert lazy_1 is not lazy_0
    assert lazy_1.constructor_fn is not lazy_0.constructor_fn

    list_0 = list(range(0, 3))
    lazy_2 = Lazy(list_0)
    lazy_3 = lazy_2.map(lambda l: list(map(lambda x: 2**x, l)))
    assert lazy_3.get() == [2**x for x in list_0]


# Generated at 2022-06-25 23:41:45.012191
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    float_0 = 1541.7829
    def fn(x):
        return x * x

    lazy_0 = Lazy(float_0)

    assert lazy_0.bind(fn) == Lazy(fn(float_0))


# Generated at 2022-06-25 23:41:47.662840
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_0 = Lazy(lambda name: "Hi " + name)
    assert lazy_0.get("Python") == "Hi Python"



# Generated at 2022-06-25 23:41:57.505142
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try

    # Case 0: regular
    def extract_name_from_maybe_filled_box(box):
        return box.bind(lambda filled_box: filled_box.name)

    def extract_name_from_maybe_filled_box_and_get_first_char(box):
        return box.bind(lambda filled_box: filled_box.name).bind(lambda name: name[0])

    class FilledBox:
        def __init__(self, name):
            self.name = name

    assert extract_name_from_maybe_filled_box(Lazy(lambda: Try.of(FilledBox, 'my name'))) == Lazy(lambda: Try.of('my name'))
    assert extract_name_from_maybe_filled_box_and_get_first_

# Generated at 2022-06-25 23:42:09.378678
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    float_0 = 1283.57
    float_1 = float_0

    def test_fn(obj):
        return Lazy(obj)

    lazy_0 = Lazy(float_0)
    lazy_1 = lazy_0.bind(test_fn)
    assert lazy_0 is lazy_1

    lazy_1 = lazy_0.bind(test_fn)
    float_1 = float_0
    if lazy_0 is not lazy_1:
        float_1 = float_0
    else:
        float_1 += float_0

    assert float_1 == float_0 + float_0


# Generated at 2022-06-25 23:42:11.765187
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = 1541.7829

    lazy_0 = Lazy(float_0)
    assert lazy_0.get() == float_0


# Generated at 2022-06-25 23:42:14.648847
# Unit test for method get of class Lazy
def test_Lazy_get():
    res = Lazy(lambda: 1).get()

    assert res == 1


# Generated at 2022-06-25 23:42:19.683715
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy(float)
    lazy_1 = Lazy(float)
    assert lazy_0 == lazy_1
    assert not lazy_0.is_evaluated
    assert not lazy_1.is_evaluated

    assert Lazy.of(True) == Lazy.of(True)


# Generated at 2022-06-25 23:42:29.142143
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1).__eq__(Lazy.of(1))
    assert Lazy.of(1).__eq__(Lazy.of(1).map(lambda x: x))
    assert not Lazy.of(1).__eq__(Lazy.of(2))
    assert not Lazy.of(1).__eq__(Lazy.of(1).map(lambda x: 2 * x))


# Generated at 2022-06-25 23:42:37.815200
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    class SomeClass:
        pass

    assert Lazy.of(int_0).__eq__(Lazy.of(int_0)) == True
    assert Lazy.of(int_0).__eq__(Lazy.of(int_1)) == False
    assert Lazy.of(int_0).__eq__(Lazy.of(Lazy.of(int_0).get())) == True
    assert Lazy.of(int_0).__eq__(None) == False
    assert Lazy.of(int_0).__eq__(str_0) == False
    assert Lazy.of(int_0).__eq__(SomeClass()) == False

# Generated at 2022-06-25 23:42:42.600195
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    x = Lazy.of(5)

    assert x == Lazy(lambda *args: 5)
    assert not x == Lazy(lambda *args: "5")
    assert not x == Lazy(lambda *args: 5.0)
    assert not x == 5
    assert x != 5
    assert x != Lazy(lambda *args: "5")
    assert x != Lazy(lambda *args: 5.0)
    assert x != "5"


# Generated at 2022-06-25 23:42:47.748956
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = 5
    def square_int_function(value):
        return value * value

    square_int_5_lazy = Lazy(lambda *args: square_int_function(int_0))
    square_int_lazy = Lazy(square_int_function)

    result = square_int_5_lazy.ap(square_int_lazy)
    assert result.get() == 25

# Generated at 2022-06-25 23:42:48.997152
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(5).get() == 5


# Generated at 2022-06-25 23:42:58.683040
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 5
    int_1 = 5
    int_2 = 6

    test_case_0()

    assert int_0 == int_1
    assert not int_0 == int_2

    fn_0 = lambda: 5
    fn_1 = lambda: 5
    fn_2 = lambda: 6

    test_case_0()

    assert Lazy(fn_0) == Lazy(fn_1)
    assert not Lazy(fn_0) == Lazy(fn_2)

    test_case_0()

    assert Lazy(fn_0) == Lazy(fn_1).get()
    assert not Lazy(fn_0) == Lazy(fn_2).get()



# Generated at 2022-06-25 23:43:03.314690
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = Lazy(lambda x: 5)

    float_0 = int_0.map(lambda x: float(x))

    assert float_0 == Lazy(lambda: 5.0)


# Generated at 2022-06-25 23:43:05.386866
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(int_0).__eq__(Lazy.of(int_0))



# Generated at 2022-06-25 23:43:07.704580
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    number = Lazy.of(1)
    result = number.ap(Lazy(lambda x: x + 1))
    assert result.get() == 2



# Generated at 2022-06-25 23:43:16.304377
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test_case_1():
        int_0 = 0
        assert int_0 * 2 == 0

        lazy_0 = Lazy.of(int_0)
        lazy_1 = lazy_0.map(lambda arg_0: arg_0 * 2)
        assert lazy_1.get() == 0

    test_case_1()

    def test_case_2():
        int_0 = 6
        assert int_0 * 2 == 12

        lazy_0 = Lazy.of(int_0)
        lazy_1 = lazy_0.map(lambda arg_0: arg_0 * 2)
        assert lazy_1.get() == 12

    test_case_2()


# Generated at 2022-06-25 23:43:20.959226
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 5
    Lazy_0 = Lazy.of(int_0)
    assert Lazy_0.bind(lambda x: Lazy.of(x + 1)).get() == 6


# Generated at 2022-06-25 23:43:32.513523
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    lazy = Lazy.of(10)
    lazy2 = Lazy.of(4)
    lazy3 = Lazy.of(None)

    mapped = lazy.map(lambda x: x + 1)
    mapped2 = lazy.map(lambda x: lazy2.get() + x)
    mapped3 = lazy.map(lambda x: Maybe.some(x))
    mapped4 = lazy.map(lambda x: Try.of(lambda x: x + 1, x))

    assert Lazy.of(11) == mapped
    assert Lazy.of(14) == mapped2
    assert Lazy.of(Maybe.some(10)) == mapped3
    assert Lazy.of(Try.success(11)) == mapped4

   

# Generated at 2022-06-25 23:43:38.248067
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def _():
        # Given
        def function_0():
            return 1

        lazy_0 = Lazy(function_0)
        lazy_1 = Lazy(function_0)

        # When
        result_0 = lazy_0 == lazy_1

        # Then
        assert result_0 == True, "[FAIL]: Expected True got {}".format(result_0)
        return 1

    assert _() == 1


# Generated at 2022-06-25 23:43:45.172970
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    list_0 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] #type: list
    int_0 = 0 #type: int


    def lambda_fn_Python_Lazy_0(list_0):
        return Lazy.of(list_0)
    def lambda_fn_Python_0(int_0, item):
        return (int_0 + item)
    int_0 = Lazy.of(list_0).bind(lambda_fn_Python_Lazy_0).bind(lambda_fn_Python_0).get(0)
    print(int_0)

    assert int_0 == 55


# Generated at 2022-06-25 23:43:48.294515
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = Lazy(lambda: int_0)
    str_0 = int_0.bind(lambda y: Lazy(lambda: str(y)))
    str_0.get()
    assert int_0.value == 5 == str_0.value



# Generated at 2022-06-25 23:43:59.753150
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    class Fn(Generic[T]):
        def __init__(self):
            self.value: T = None

        def __call__(self, value: T):
            self.value = value
            return self

        def get(self) -> T:
            return self.value

    maybe_empty = Maybe.empty()
    maybe_some = Maybe.some(5)
    box_some = Box(5)
    box_none = Box(None)
    either_left = Left(5)
    either_right = Right(5)
    either_right_none = Right(None)


# Generated at 2022-06-25 23:44:01.150206
# Unit test for method get of class Lazy
def test_Lazy_get():
    import pytest

    __test__ = {
    }



# Generated at 2022-06-25 23:44:03.953265
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    mapper = lambda x: x + 1
    int_0 = Lazy.of(5)
    assert int_0.ap(int_1).get() == int_0.get() + 1


# Generated at 2022-06-25 23:44:08.140476
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 5
    int_1 = int_0 + 1
    lazy_0 = Lazy.of(int_0)
    def identity(value: int) -> Lazy[int, int]:
        return Lazy.of(value)

    lazy_1 = lazy_0.bind(identity)
    assert lazy_1.get() == int_0


# Generated at 2022-06-25 23:44:13.108124
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add(x: int) -> int:
        return x + 1

    def ref(x: int) -> Lazy[int, int]:
        return Lazy.of(x)

    lazy_int_0 = Lazy.of(0)
    lazy_int_1 = lazy_int_0.bind(ref).bind(add)

    assert lazy_int_1.get() == 1


# Generated at 2022-06-25 23:44:25.255604
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def lazy_4():
        return 4

    def lazy_8():
        return 8

    def lazy_16():
        return 16

    def lazy_32():
        return 32

    def add(val: int) -> Lazy:
        return Lazy(lambda x: val + x)

    # Calling bind is the way to call constructor function in Lazy
    assert Lazy(lambda x: x + 5).bind(add).bind(add).bind(add).get(2) == 17

    assert Lazy(lambda x: x + 5).bind(lambda x: Lazy(lambda y: x + y)).bind(lambda x: Lazy(lambda y: x + y)).get(2) == 14


# Generated at 2022-06-25 23:44:29.658781
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    f = lambda x: x + 1
    g = lambda x: x ** 2
    h = lambda x: x ** 3

    assert Lazy.of(5).map(f).map(g).map(h).get() == f(g(h(Box(5).get())))


# Generated at 2022-06-25 23:44:36.621783
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # given
    int_0 = 12
    int_1 = 13
    int_2 = 15
    int_3 = 15
    lazy_0 = Lazy(lambda: int_0)
    lazy_1 = Lazy(lambda: int_1)
    lazy_2 = Lazy(lambda: int_2)
    lazy_3 = Lazy(lambda: int_3)

    # when

    # then
    assert lazy_0 != lazy_1
    assert lazy_0 != lazy_2
    assert lazy_0 != lazy_3

    assert lazy_1 != lazy_0
    assert lazy_1 != lazy_2
    assert lazy_1 != lazy_3

    assert lazy_2 != lazy_0
    assert lazy_2 != lazy_1
    assert lazy_2 != lazy_3

    assert lazy_3 != lazy_0

# Generated at 2022-06-25 23:44:39.240589
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    result = None
    expected = Lazy(lambda *args: result)

    result = Lazy(lambda *args: 1).ap(Lazy(lambda *args: result))

    assert result == expected


# Generated at 2022-06-25 23:44:44.821924
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = 5
    int_1 = 6
    function_0 = lambda var_0: int_0 + var_0
    lazy_0 = Lazy.of(function_0)
    lazy_1 = Lazy.of(int_1)
    lazy_2 = lazy_0.ap(lazy_1)
    assert lazy_2.get() == 11


# Generated at 2022-06-25 23:44:47.616418
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = Lazy.of(5)
    int_1 = int_0.get()
    assert int_1 == 5


# Generated at 2022-06-25 23:44:53.458411
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 5
    lazy_int_0 = Lazy.of(int_0)

    def int_adder(int_0):
        return Lazy.of(lambda int_1: int_0 + int_1)

    lazy_adder_0 = lazy_int_0.bind(int_adder)

    int_1 = 6
    int_2 = lazy_adder_0.get(int_1)

    assert int_2 == (int_0 + int_1)



# Generated at 2022-06-25 23:45:00.185899
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor_test import test_functor

    def check_step_0(value, result):
        assert result == value

    def check_step_1(value, result):
        assert result == value

    def check_step_2(value, result):
        assert result == value + 1

    def check_step_3(value, result):
        assert result == value + 2

    def check_step_4(value, result):
        assert result == value + 3

    def check_step_5(value, result):
        assert result == value + 4


    test_functor(check_step_1, Lazy, Lazy.of, test_case_0, lambda x: x)

# Generated at 2022-06-25 23:45:01.727110
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = Lazy.of(5)
    assert int_0.get() == 5


# Generated at 2022-06-25 23:45:02.824939
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    test_case_0()

# Generated at 2022-06-25 23:45:11.132648
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 5
    int_1 = 6
    int_2 = 7
    int_3 = 8
    int_4 = 9

    lazy_1 = Lazy(lambda arg0: int_1 if arg0 == int_0 else int_2).map(lambda res: res + int_3)
    assert lazy_1.get(int_0) == int_1 + int_3
    assert lazy_1.get(int_4) == int_2 + int_3



# Generated at 2022-06-25 23:45:15.577894
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return x + 1
    laz = Lazy
    z = Lazy(lambda *args: 3)
    z_ap = z.ap(laz.of(add))
    assert z_ap.get() == 4


# Generated at 2022-06-25 23:45:18.505322
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy = Lazy.of(lambda x: x * 2)
    lazy_1 = Lazy.of(lambda x: x + 1)

    assert lazy.ap(lazy_1) == Lazy(lambda x: (lambda x: x + 1)(x) * 2)


# Generated at 2022-06-25 23:45:22.442617
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    for n in range(0, 100):
        int_0 = n

        lazy_int = Lazy.of(int_0)

        assert lazy_int.bind(lambda x: Lazy.of(x + 1)).get() == int_0 + 1
        assert lazy_int.bind(lambda x: Lazy.of(x * 10)).get() == int_0 * 10


# Generated at 2022-06-25 23:45:31.726068
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    # case 0
    # AssertionError: object of type 'Lazy' has no len()
    # assert len(Lazy.of(1).ap(Lazy.of(1))) == 1

    # case 1
    assert Lazy.of(1).ap(Lazy.of(1)) == Lazy.of(1)

    # case 2
    assert Lazy.of(1).ap(Lazy.of(lambda p: p + 1)) == Lazy.of(2)

    # case 3
    assert Lazy.of(5).ap(Lazy.of(100)) == Lazy.of(100)


# Generated at 2022-06-25 23:45:40.638143
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    def fn(x: int) -> int:
        return x + 5

    lazy = Lazy(lambda x: 5)
    lazy_box = lazy.to_box()
    assert isinstance(lazy_box, Box)
    assert lazy_box.get() == 5
    lazy_box_mapped = lazy_box.map(fn).map(str)

    assert isinstance(lazy_box_mapped, Box)
    assert lazy_box_mapped.get() == '10'

    lazy_ap_result = lazy.ap(lazy_box_mapped)

    assert isinstance(lazy_ap_result, Lazy)
    assert lazy_ap_result.get() == '15'



# Generated at 2022-06-25 23:45:46.380412
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 5
    int_1 = 5
    int_2 = 3
    fn_0 = lambda: int_0
    fn_1 = lambda: int_1
    fn_2 = lambda: int_2
    lazy_0 = Lazy(fn_0)
    lazy_1 = Lazy(fn_1)
    lazy_2 = Lazy(fn_2)

    assert lazy_0 == lazy_1
    assert lazy_0 != lazy_2


# Generated at 2022-06-25 23:45:57.698767
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def int_plus_3(value):
        return value + 3

    def str_upper(value):
        return value.upper()

    int_0 = 5
    int_lazy = Lazy.of(int_0)
    lazy_to_map = int_lazy.map(int_plus_3)
    first_map_call_result = lazy_to_map.get()
    second_map_call_result = lazy_to_map.get()
    assert first_map_call_result == 8, "Wrong result"
    assert second_map_call_result == 8, "Wrong result"
    assert lazy_to_map.is_evaluated
    assert int_lazy.is_evaluated == False, "Wrong evaluation status"

# Generated at 2022-06-25 23:45:59.467861
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(5).__eq__(Lazy.of(5)) == True


# Generated at 2022-06-25 23:46:03.574663
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 5
    int_1 = 3

    object_0 = Lazy.of(int_0)
    function_0 = lambda x: Lazy.of(x + int_1)
    object_1 = object_0.bind(function_0)
    assert object_1.get() == 8


# Generated at 2022-06-25 23:46:10.235271
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # given

    def f():
        return 1

    def f1():
        return 1

    def f2():
        return 2

    # when
    Lazy_0 = Lazy(f)
    Lazy_1 = Lazy(f)
    Lazy_2 = Lazy(f2)
    Lazy_3 = Lazy(f1)

    # then
    assert Lazy_0 == Lazy_1
    assert Lazy_1 == Lazy_0
    assert not Lazy_0 == Lazy_2
    assert not Lazy_0 == None
    assert Lazy_1 == Lazy_3


# Generated at 2022-06-25 23:46:19.701419
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.validation import Validation

    def add_1(x):
        return x + 1
    def add_2(x):
        return x + 2
    def add_3(x):
        return x + 3
    def add_4(x):
        return x + 4

    int_5 = Lazy.of(5)
    int_10 = Lazy.of(10)

    assert int_5.bind(lambda x: Lazy.of(add_1(x))).get() == 6
    assert int_10.bind(lambda x: Lazy.of(add_2(x))).get() == 12
    assert int_5.bind(lambda x: Lazy.of(add_3(x))).get() == 8
    assert int_10.bind

# Generated at 2022-06-25 23:46:29.132539
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 5
    int_1 = 4
    int_2 = 3
    int_3 = 2
    int_4 = 1
    int_5 = 0
    sum_0 = lambda x, y: x + y
    sum_1 = lambda x, y: x + y
    sum_2 = lambda x, y: x + y
    sum_3 = lambda x, y: x + y
    sum_4 = lambda x, y: x + y
    sum_5 = lambda x, y: x + y
    final_sum = lambda x, y, z, t, u, v: x + y + z + t + u + v
    lazy_0 = Lazy(sum_0, int_0, int_1)
    lazy_1 = Lazy(sum_1, int_1, int_2)
   

# Generated at 2022-06-25 23:46:30.816974
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def subtract(x):
        return Lazy(lambda y: y - x)

    result = Lazy.of(20) \
        .bind(lambda x: subtract(x)) \
        .get(5)

    # result is equal 15
    assert result == 15


# Generated at 2022-06-25 23:46:38.291612
# Unit test for method get of class Lazy
def test_Lazy_get():
    class TestClass:
        pass

    int_0 = 5

    def test_0():
        return int_0

    class_0 = TestClass()
    lazy_0 = Lazy.of(int_0)
    assert lazy_0.get() == int_0

    lazy_1 = Lazy.of(class_0)
    assert lazy_1.get() == class_0

    lazy_2 = Lazy.of(test_0)
    assert lazy_2.get() == test_0



# Generated at 2022-06-25 23:46:48.485235
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def _add1(x: int) -> Lazy[int, int]:
        return Lazy.of(x + 1)

    def _is_even(x: int) -> Lazy[int, bool]:
        return Lazy.of(x % 2 == 0)

    add1_is_even = Lazy.of(1).bind(_add1).bind(_is_even)
    assert add1_is_even.get() is False

    add1_is_even2 = Lazy.of(2).bind(_add1).bind(_is_even)
    assert add1_is_even2.get() is True

    add1_is_even3 = Lazy.of(0).bind(_add1).bind(_is_even)
    assert add1_is_even3.get() is True



# Generated at 2022-06-25 23:46:50.614607
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = Lazy.of(5)

    assert int_0.bind(lambda x: Lazy.of(x + 8)) == Lazy.of(13)



# Generated at 2022-06-25 23:46:55.675451
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 5

    def double_val(val: int) -> int:
        return int_0 * 2

    lazy_0 = Lazy.of(int_0)
    lazy_1 = lazy_0.map(double_val)
    assert 10 == lazy_1.fold(lambda *args: args[0])

# Generated at 2022-06-25 23:47:07.532930
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    def inc(x):
        return x + 1

    def div(x):
        return x / 5

    def eq(x, y):
        return x == y

    def sub(x, y):
        return x - y

    def raise_exc(x):
        raise Exception('error')

    # test get

    assert Lazy(inc).get(5) == 6

    # test map

    assert Lazy(inc).map(div).get(5) == 1.2
    assert Lazy(inc).map(div).map(eq).get(5, 1.2) is True
    assert Lazy(inc).map(div).map

# Generated at 2022-06-25 23:47:12.191092
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    u = Lazy.of(5)
    v = Lazy(lambda : 5)

    assert u == v
    assert not u == 7
    assert not u == Lazy(lambda : 7)
    assert not u == Lazy(lambda : '7')



# Generated at 2022-06-25 23:47:21.213112
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def __map(value):
        return "STRING_" + str(value)

    def __ap_map(value):
        return "str_" + str(value)

    float_0 = 1541.7829
    lazy_0 = Lazy(float_0)

    lazy_1 = lazy_0.map(__map)

    lazy_2 = Lazy(__ap_map).ap(lazy_1)
    result = lazy_2.get()

    assert result == __ap_map("STRING_" + str(float_0))


# Generated at 2022-06-25 23:47:24.545398
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = 2.389267770692265
    lazy_0 = Lazy.of(float_0)
    assert lazy_0.get() == float_0


# Generated at 2022-06-25 23:47:31.022630
# Unit test for method map of class Lazy
def test_Lazy_map():
    float_0 = 1541.7829
    lazy_0 = Lazy(float_0)
    lazy_1 = lazy_0.map(lambda v_0: not len(str(v_0)))
    assert lazy_1.constructor_fn(None)
    assert lazy_1.constructor_fn(False)
    assert not lazy_1.constructor_fn(True)
    assert lazy_1.constructor_fn(10)


# Generated at 2022-06-25 23:47:33.964628
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    lazy_0 = Lazy.of("abc")
    lazy_1 = lazy_0.bind(lambda v: Lazy.of("abc"))
    assert lazy_1.get() == "abc"


# Generated at 2022-06-25 23:47:39.194099
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    input_0 = Lazy(lambda: "")
    def function_fn_0(value: str):
        return Lazy((lambda: value.upper()))

    result = input_0.bind(function_fn_0)
    assert isinstance(result, Lazy)
    assert result == Lazy(lambda: "")
    assert result.is_evaluated == False
    assert result.value == None
    assert result.constructor_fn == (lambda: "")


# Generated at 2022-06-25 23:47:44.031010
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def double(x):
        return x + x

    def increment(x):
        return x + 1

    lazy_0 = Lazy.of(5)
    lazy_1 = lazy_0.bind(double).bind(increment)
    rv_0 = lazy_1.get()
    assert rv_0 == 11
    assert lazy_0.is_evaluated == False
    assert lazy_1.is_evaluated == True


# Generated at 2022-06-25 23:47:49.382912
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    # Initialization
    float_0 = 1541.7829
    float_1 = 1628.7911
    lazy_0 = Lazy(float_0)
    lazy_1 = Lazy(float_0)
    lazy_2 = Lazy(float_1)

    # Test
    assert lazy_0 == lazy_0
    assert lazy_0 != lazy_1
    assert lazy_2 != lazy_1



# Generated at 2022-06-25 23:47:51.927114
# Unit test for method get of class Lazy
def test_Lazy_get():
    def double(x): return x * 2
    assert Lazy.of(6).get() == 6
    assert Lazy(double).get(3) == 6


# Generated at 2022-06-25 23:47:58.975608
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return x + 2

    def minus(y):
        return y - 3

    lazy_0 = Lazy.of(add)
    lazy_1 = lazy_0.ap(Lazy.of(2))
    assert lazy_1.get() == 4

    lazy_2 = Lazy.of(minus)
    lazy_3 = lazy_2.ap(Lazy.of(2))
    assert lazy_3.get() == -1


# Generated at 2022-06-25 23:48:01.714458
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = 1541.7829
    assert float_0 == Lazy(float_0).get()


# Generated at 2022-06-25 23:48:07.667748
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_1 = Lazy.of(lambda x: x + 1)
    assert lazy_1.ap(Lazy.of(2)) == Lazy.of(lambda x: x + 1)(2)



# Generated at 2022-06-25 23:48:09.817621
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = 1541.7829
    lazy_0 = Lazy(float_0)
    if lazy_0.get() != float_0:
        assert False


# Generated at 2022-06-25 23:48:14.181165
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy.of('')
    assert lazy.bind(lambda arg: Lazy.of(arg + 'c')).get() == 'c'
    assert lazy.bind(lambda arg: Lazy.of(arg + 'c')).get() == 'c'



# Generated at 2022-06-25 23:48:19.018554
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    float_0 = 1541.7829
    lazy_0 = Lazy(float_0)

    def lambda_fn_0(float_0: float) -> Lazy[float, float]:
        return lazy_0

    lazy_1 = lazy_0.bind(lambda_fn_0)
    assert lazy_1.get() == 1541.7829


# Generated at 2022-06-25 23:48:22.281815
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    float_0 = 1541.7829
    lazy_0 = Lazy(float_0)
    lazy_1 = lazy_0.bind(lambda x: Lazy.of(x))
    assert lazy_1.get() == float_0


# Generated at 2022-06-25 23:48:27.149414
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Function to test ``get`` method of class Lazy.

    It tests if ``get`` method returns expected value.
    """
    float_0 = 1541.7829
    float_result = float_0 ** float_0 ** float_0
    lazy_0 = Lazy(float_0)
    lazy_float = lazy_0.map(lambda f: f ** f ** f)
    assert lazy_float.get() == float_result


# Generated at 2022-06-25 23:48:29.302437
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda x: x)
    assert lazy.get(1541.7829) == 1541.7829


# Generated at 2022-06-25 23:48:38.459755
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    float_0 = 1541.7829
    lazy_0 = Lazy(float_0)
    lazy_1 = Lazy(float_0)
    assert lazy_0 == lazy_1, "Test 0"
    float_1 = 1541.7829
    lazy_2 = Lazy(float_1)
    assert lazy_0 == lazy_2, "Test 1"
    lazy_3 = Lazy(float_1)
    assert lazy_0 == lazy_3, "Test 2"
    def fn_0(arg):
        return arg + 5
    lazy_4 = Lazy(fn_0)
    lazy_5 = Lazy(fn_0)
    assert lazy_4 == lazy_5, "Test 3"
    def fn_1(arg):
        return arg + 5

# Generated at 2022-06-25 23:48:42.274798
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    We create lazy object with string.
    We create mapper to integer.
    We test if mapped value is equal to expected type.
    """

    expected = Lazy(int('1'))
    actual = Lazy(str(1)).map(int)
    assert actual == expected



# Generated at 2022-06-25 23:48:45.629555
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy(lambda: [1])
    assert lazy_0.ap(Lazy(lambda: 2)) == Lazy(lambda: 2)
    assert lazy_0.ap(Lazy(lambda: 3)) == Lazy(lambda: 3)

# Generated at 2022-06-25 23:48:55.941889
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    float_0 = 1737.52172
    lazy_0 = Lazy.of(float_0)
    float_1 = -1.64601125989
    lazy_1 = Lazy.of(float_1)
    float_2 = -36.7759192544
    lazy_2 = Lazy.of(float_2)

    assert lazy_0.ap(lazy_1) == lazy_1
    assert lazy_0.ap(lazy_2) == lazy_2



# Generated at 2022-06-25 23:48:59.612982
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # When notempty Lazy is applied to Lazy with function A -> B
    # Then the result of passing the value contained inside the monad to that function is contained inside another Lazy.
    def double(num):
        return num * 2

    lazy_of_2 = Lazy(2)
    lazy_of_double = Lazy(double)
    result = lazy_of_2.ap(lazy_of_double)
    assert result == Lazy.of(4)



# Generated at 2022-06-25 23:49:08.341259
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    float_1 = 1541.7829
    lazy_1 = Lazy.of(float_1)
    # Check bind on Lazy of float
    float_2 = float_1 * (-2.0)

    def _test_case_1(float_2):
        lazy_2 = Lazy.of(float_2)
        return lazy_2

    lazy_3 = lazy_1.bind(_test_case_1)
    result_0 = lazy_3.get()
    assert(result_0 == float_2)

    # Check bind on empty Lazy of string
    string_1 = ""
    lazy_4 = Lazy.of(string_1)

    def _test_case_2(string_2):
        lazy_5 = Lazy.of(string_2)
        return lazy_5

    lazy_

# Generated at 2022-06-25 23:49:16.723755
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    float_0 = 1541.7829
    lazy_0 = Lazy.of(float_0)
    float_1 = float_0 - 945.04874
    lazy_1 = lazy_0.bind(lambda x: Lazy.of(float_1))
    float_2 = float_1 - float_1
    lazy_2 = lazy_1.bind(lambda x: Lazy.of(float_2))
    # AssertionError: assert -696.73464000000001 == -945.04874
    assert float_2 == lazy_2.get()


# Generated at 2022-06-25 23:49:18.358742
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_0 = Lazy.of(1)
    assert lazy_0.get() == 1
    assert lazy_0.is_evaluated

    lazy_1 = Lazy(lambda: 1)
    assert lazy_1.get() == 1
    assert lazy_1.is_evaluated



# Generated at 2022-06-25 23:49:21.003768
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: None)
    assert Lazy(lambda: None) != Lazy(lambda: (1, 2))


# Generated at 2022-06-25 23:49:29.295987
# Unit test for method map of class Lazy
def test_Lazy_map():
    float_0 = 1541.7829
    float_1 = float(float_0)
    float_2 = float(float_1)
    float_3 = float(float_2)
    float_4 = float(float_3)
    float_5 = float(float_4)
    float_6 = float(float_5)
    float_7 = float(float_6)
    float_8 = float(float_7)
    float_9 = float(float_8)
    float_10 = float(float_9)
    float_11 = float(float_10)
    float_12 = float(float_11)
    float_13 = float(float_12)
    float_14 = float(float_13)
    float_15 = float(float_14)

# Generated at 2022-06-25 23:49:34.512956
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    float_0 = 1541.7829
    lazy_0 = Lazy.of(float_0)
    lazy_1 = lazy_0.bind(lambda t: Lazy.of(t + float_0))
    assert (lazy_1.get() == float_0 + float_0)


# Generated at 2022-06-25 23:49:40.130025
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy(41)
    lazy_1 = Lazy(42)
    lazy_2 = Lazy(lambda x: x + 1)
    lazy_3 = Lazy(44)

    assert (lazy_0.bind(lambda x: lazy_1) == Lazy(lambda: 42))

    lazy_2.bind(lambda x: lazy_3)
    assert (lazy_2.bind(lambda x: lazy_3) == Lazy(lambda: 45))


# Generated at 2022-06-25 23:49:52.305422
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    float_0 = 1541.7829
    lazy_0 = Lazy(float_0)
    float_1 = float_0
    lazy_1 = Lazy(float_1)
    float_2 = float_0
    lazy_2 = Lazy(float_2)
    float_3 = float_0
    lazy_3 = Lazy(float_3)
    float_4 = float_0
    lazy_4 = Lazy(float_4)
    float_5 = float_0
    lazy_5 = Lazy(float_5)
    float_6 = float_0
    lazy_6 = Lazy(float_6)
    float_7 = float_0
    lazy_7 = Lazy(float_7)
    float_8 = float_0
    lazy_8 = Lazy(float_8)

# Generated at 2022-06-25 23:50:02.666206
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1541.7829).map(lambda x: x + 1.7829) == Lazy.of(1543.5655)


# Generated at 2022-06-25 23:50:09.381133
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # We have function which multiply argument by 2
    def multiply_by_2(x):
        return x * 2

    lazy_0 = Lazy(lambda arg: arg)
    lazy_1 = lazy_0.bind(multiply_by_2)
    assert lazy_1.constructor_fn(2) == 4
    assert not lazy_1.is_evaluated
    lazy_2 = lazy_1.bind(multiply_by_2)
    assert lazy_2.constructor_fn(2) == 8
    assert not lazy_2.is_evaluated



# Generated at 2022-06-25 23:50:18.441208
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def plus_10(value):
        return value + 10

    def minus_10(value):
        return value - 10

    def minus_90(value):
        return value - 90

    lazy_0 = Lazy(10)
    lazy_1 = Lazy(minus_10)
    lazy_2 = Lazy(plus_10)
    lazy_3 = Lazy(minus_90)

    assert lazy_0.ap(lazy_1) == Lazy(20)
    assert lazy_0.ap(lazy_2) == Lazy(0)
    assert lazy_0.ap(lazy_3) == Lazy(-80)
    assert lazy_0 == Lazy(10)



# Generated at 2022-06-25 23:50:20.934241
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy(lambda x: x + 1.0)
    lazy_1 = Lazy(lambda x: x)
    assert lazy_0 != lazy_1


# Generated at 2022-06-25 23:50:29.058547
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet import Maybe
    from pymonet import Validation
    # Method __init__
    float_0 = 1541.7829
    lazy_0 = Lazy(float_0)
    float_1 = 8476.8991
    maybe_0 = Maybe.just(float_1)
    validation_0 = Validation.success(float_1)
    # Method bind
    def lambda_0(value):
        return value
    def lambda_1(value):
        return value
    def lambda_2(value):
        return value
    lazy_0.bind(lambda_0)
    # Method bind
    def lambda_3(value):
        return maybe_0
    def lambda_4(value):
        return validation_0
    def lambda_5(value):
        return lazy_0