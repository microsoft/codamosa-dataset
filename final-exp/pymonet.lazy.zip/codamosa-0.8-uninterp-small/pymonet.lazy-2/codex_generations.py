

# Generated at 2022-06-25 23:40:25.934939
# Unit test for method map of class Lazy
def test_Lazy_map():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    lazy_0 = Lazy(dict_0)

    lazy_1 = lazy_0.map(dict_1)
    assert lazy_1 == Lazy(lambda: dict_1)

    lazy_2 = lazy_1.map(dict_2)
    assert lazy_2 == Lazy(lambda: dict_2)



# Generated at 2022-06-25 23:40:31.361372
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = 'ABC'
    lazy_0 = Lazy(str_0)
    lazy_1 = lazy_0
    lazy_2 = lazy_1.bind(str)
    res_0 = lazy_2.get()
    assert res_0 == str_0


# Generated at 2022-06-25 23:40:34.946921
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    dict_0 = {'a': 'b'}
    lazy_0 = Lazy(dict_0)
    assert lazy_0.bind(lambda v: Lazy(v.get('a'))) == Lazy(lambda v: v.get('a'))


# Generated at 2022-06-25 23:40:37.590953
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy(lambda: None)
    lazy_1 = Lazy(lambda: None)

    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:40:47.601303
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    lazy_0 = Lazy.of(1)
    lazy_1 = Lazy.of(1)
    lazy_2 = Lazy.of(3)
    lazy_3 = Lazy.of(1)
    lazy_0.get()
    lazy_3.get()

    assert lazy_0 == lazy_1
    assert lazy_1 == lazy_0
    assert lazy_0 == lazy_3
    assert lazy_1 == lazy_3
    assert lazy_3 == lazy_0
    assert lazy_3 == lazy_1
    assert not lazy_0 == lazy_2
    assert not lazy_2 == lazy_0
    assert not lazy_1 == lazy_2
    assert not lazy_2 == lazy_1
    assert not lazy_3 == lazy_2
    assert not lazy_2 == lazy_3


# Generated at 2022-06-25 23:40:53.647198
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(True) == Lazy(lambda: True)
    assert Lazy.of(False) == Lazy(lambda: False)
    assert Lazy.of({}) == Lazy(lambda: {})
    assert Lazy.of(str) == Lazy(lambda: str)



# Generated at 2022-06-25 23:41:03.030478
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Create Lazy with function returing argument.
    Compare two Lazy (created by Lazy.of(0) and Lazy.of(0)) if they are the same
    """
    # assert Lazy.of(0) == Lazy.of(0)

    assert Lazy(lambda_0) == Lazy.of(0)
    assert Lazy(lambda_0) == Lazy(lambda_0)
    assert Lazy(lambda_0) == Lazy(lambda_1)
    assert Lazy(lambda_2) == Lazy(lambda_2)
    assert Lazy(lambda_0) != Lazy(lambda_3)



# Generated at 2022-06-25 23:41:11.743924
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    dict_0 = {}
    assert Lazy(dict_0).ap(Lazy.of(3)) == Lazy.of({})
    assert Lazy.of(dict_0).ap(Lazy.of(3)) == Lazy.of({})
    dict_1 = {}
    dict_1["t"] = 2
    dict_1["u"] = 4
    dict_2 = {}
    dict_2["w"] = 3
    dict_2["v"] = 6
    dict_3 = {}
    dict_3["x"] = 4
    dict_3["y"] = 8

# Generated at 2022-06-25 23:41:21.436835
# Unit test for method get of class Lazy
def test_Lazy_get():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_27 = {}
    dict_

# Generated at 2022-06-25 23:41:29.641617
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pymonet.optic
    from typing import List

    def get_length(l: List[int]):
        return len(l)

    def double_length(l: List[int]) -> int:
        return get_length(l) * 2


# Generated at 2022-06-25 23:41:41.255103
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy(lambda: 4)
    lazy_1 = Lazy(lambda: 5)
    lazy_2 = Lazy(lambda: 3)
    lazy_3 = Lazy(lambda: 4)
    lazy_4 = Lazy(lambda: 5)
    lazy_5 = Lazy(lambda: 3)
    assert lazy_0 != lazy_1
    assert lazy_0 != lazy_2
    assert lazy_0 != lazy_3
    assert lazy_0 != lazy_4
    assert lazy_0 != lazy_5
    assert lazy_1 != lazy_2
    assert lazy_1 != lazy_3
    assert lazy_1 != lazy_4
    assert lazy_1 != lazy_5
    assert lazy_2 != lazy_3
    assert lazy_2 != lazy_4
    assert lazy_2 != lazy_5
   

# Generated at 2022-06-25 23:41:45.012246
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(2) != Lazy.of(1)
    assert Lazy.of(1) != 1
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x)


# Generated at 2022-06-25 23:41:48.737191
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    lazy_1 = Lazy(dict)
    lazy_2 = lazy_0.ap(lazy_1)
    assert lazy_2


# Generated at 2022-06-25 23:41:50.653426
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 5).map(lambda x: x + 7).get() == 12



# Generated at 2022-06-25 23:41:52.689493
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x).bind(lambda x: Lazy(x)).get() == Lazy(lambda x: x).get()



# Generated at 2022-06-25 23:41:59.973463
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Case 0
    Lazy_1 = lambda x: Lazy(lambda: x)
    Lazy_2 = Lazy(lambda: 1)
    result_Lazy_ap_0 = Lazy_1(1)
    # assert result_Lazy_ap_0 == Lazy_2
    print(result_Lazy_ap_0)
    # Case 1
    Lazy_1 = Lazy(lambda: lambda x: Lazy(lambda: x))
    Lazy_2 = Lazy(lambda: 1)
    result_Lazy_ap_1 = Lazy_1.ap(Lazy_2)
    # assert result_Lazy_ap_1 == Lazy(lambda: 1)
    print(result_Lazy_ap_1)


# Generated at 2022-06-25 23:42:01.640252
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    chosen_value = 'value'

    # When
    real_value = Lazy.of(chosen_value).bind(lambda x: Lazy.of(x)).get()

    # Then
    assert chosen_value == real_value


# Generated at 2022-06-25 23:42:05.234530
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy.of(lambda x: x)
    lazy_1 = Lazy.of(1)
    lazy_2 = lazy_0.ap(lazy_1)
    assert lazy_2.get() == 1


# Generated at 2022-06-25 23:42:16.022994
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_0 = Lazy.of(1)
    lazy_1 = lazy_0.map(lambda x: x + 1)
    assert lazy_1.constructor_fn(None) == 2

    lazy_2 = lazy_1.map(lambda x: x + 3)
    assert lazy_2.constructor_fn(None) == 5

    lazy_3 = lazy_2.map(lambda x: x * 2)
    assert lazy_3.constructor_fn(None) == 10

    lazy_4 = Lazy.of(9).map(lambda x: x + 1)
    assert lazy_4.constructor_fn(None) == 10

    lazy_5 = Lazy.of(0).map(lambda x: x + 3)
    assert lazy_5.constructor_fn(None) == 3


# Generated at 2022-06-25 23:42:27.358345
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    lazy_0 = Lazy(dict_0)
    lazy_1 = Lazy(dict_1)
    lazy_2 = Lazy(dict_2)
    dict_0['name'] = 'Pedro'
    dict_1['name'] = 'Pedro'
    dict_2['name'] = 'Pedro'
    lazy_0.is_evaluated = True
    lazy_0.value = dict_0
    lazy_1.is_evaluated = True
    lazy_1.value = dict_1
    lazy_2.is_evaluated = True
    lazy_2.value = dict_2
    dict_0['name'] = 'Pedro'
    dict_1['name'] = 'Pedro'

# Generated at 2022-06-25 23:42:37.440405
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Case 0:
    dict_0 = {'test': 'test'}
    lazy_0 = Lazy(dict_0)
    lazy_0_mapped = lazy_0.map(lambda d: d['test'] + '_INVOKE')

    assert lazy_0_mapped.value is None
    assert lazy_0_mapped.constructor_fn({'test': 'test'}) == 'test_INVOKE'
    assert lazy_0_mapped.is_evaluated == False


# Generated at 2022-06-25 23:42:39.998277
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    dict_0 = {}
    dict_0[0] = 1

    lazy_0 = Lazy(dict_0)

    lazy_1 = lazy_0.bind(lambda value: Lazy(lambda: value[0]))

    assert lazy_1.get() == 1


# Generated at 2022-06-25 23:42:41.354182
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(5) == Lazy.of(5)



# Generated at 2022-06-25 23:42:44.963133
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    lazy_1 = Lazy(dict_0)
    assert lazy_0 == lazy_1
    assert lazy_0 != {}
    assert not (lazy_0 == {})


# Generated at 2022-06-25 23:42:54.580705
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.try_ import Try
    from pymonet.validation import Validation

    def test_lazy_ap(fn):
        dict_0 = {'key_0': 'value_0'}
        dict_1 = {'key_1': 'value_1'}
        lazy_0 = Lazy(dict_0)
        lazy_1 = Lazy(dict_1)
        lazy_2 = lazy_0.ap(lazy_1)
        assert(dict_0 == lazy_2.get())
        assert(lazy_0 == lazy_2.bind(fn))
        assert(Box(dict_0) == lazy_2.to_box())

# Generated at 2022-06-25 23:43:01.103476
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)

    box_0 = lazy_0.bind(lambda arg0: Box(arg0))
    assert box_0.is_equal_to(Box(dict_0))

    def fn0(arg0):
        def fn1(arg1):
            return Box(arg1)

        return Lazy(fn1)

    box_1 = lazy_0.bind(fn0)
    assert box_1.is_equal_to(Box(dict_0))



# Generated at 2022-06-25 23:43:08.388322
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test method Lazy.__eq__
    """

    value = "test_value"
    lazy_0 = Lazy(lambda: value)

    assert lazy_0.__eq__(lazy_0) == True
    assert lazy_0.__eq__(Lazy(lambda: value)) == True
    assert lazy_0.__eq__(Lazy(lambda: "test_value")) == True
    assert lazy_0.__eq__(Lazy(lambda: "Wrong_value")) == False


# Generated at 2022-06-25 23:43:12.434632
# Unit test for method get of class Lazy
def test_Lazy_get():
    dict_0 = {'a': 1, 'b': 2}
    dict_1 = {'a': 1, 'b': 2}
    lazy_0 = Lazy(dict_1)
    value_0 = lazy_0.get()
    assert value_0 == dict_0


# Generated at 2022-06-25 23:43:16.878977
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def get_dict_with_value(a):
        return Lazy(dict({'a': a}))

    lazy_0 = Lazy(lambda: 3)
    lazy_1 = lazy_0.bind(get_dict_with_value)
    assert lazy_1.get() == {'a': 3}



# Generated at 2022-06-25 23:43:19.889748
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(val):
        return Lazy(lambda *args: val * 2)

    val = Lazy(lambda: 2)
    val = val.bind(f)
    assert val.get() == 4


# Generated at 2022-06-25 23:43:35.907696
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Test ap with function that returns Lazy
    assert Lazy.of(0).ap(Lazy.of(lambda x: x + 1)).get() == 1

    # Test ap with function that calls method get on Lazy
    assert Lazy.of(0).ap(Lazy.of(lambda x: x.get())).get() == 0

    # Test ap with function that calls mapped method get on Lazy
    assert Lazy.of(0).map(lambda x: x.get()).ap(Lazy.of(lambda x: x + 1)).get() == 1

    # Test ap with function that calls method ap on Lazy
    assert Lazy.of(0).ap(Lazy.of(lambda x: x.ap(Lazy.of(lambda x: x + 1)))).get() == 1

    # Test ap with function that calls mapped

# Generated at 2022-06-25 23:43:44.581161
# Unit test for method map of class Lazy
def test_Lazy_map():
    def demo_func():
        return 'demo_string'

    def mapper_func(x):
        return 'mapped'

    lazy_0 = Lazy.of('demo_string')
    lazy_1 = Lazy(demo_func)  # stored function, not called yet
    lazy_2 = Lazy.of(demo_func)  # stored function and called
    assert lazy_0 == Lazy(lambda: 'demo_string')
    assert lazy_1 == Lazy(demo_func)
    assert lazy_2 == Lazy(demo_func)
    assert lazy_0.map(mapper_func) == Lazy(lambda: mapper_func('demo_string'))

# Generated at 2022-06-25 23:43:52.643714
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    dict_0 = {1: 1, 2: 4, 3: 9, 4: 16, 5: 25}
    lazy_0 = Lazy(dict_0)
    lazy_1 = Lazy(dict_0)
    assert lazy_0 == lazy_1
    dict_1 = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5}
    lazy_2 = Lazy(dict_1)
    assert lazy_0 != lazy_2
    lazy_3 = Lazy(dict_1)
    assert lazy_2 == lazy_3
    assert lazy_1 != lazy_2
    assert lazy_2 != lazy_0


# Generated at 2022-06-25 23:44:03.821095
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    print('Unit test for method bind of class Lazy')

    assert Lazy.of(1).bind(lambda x: Lazy.of(x * x)).get() == 1
    assert Lazy.of(2).bind(lambda x: Lazy.of(x * x)).get() == 4
    assert Lazy.of(3).bind(lambda x: Lazy.of(x * x)).get() == 9
    assert Lazy.of(4).bind(lambda x: Lazy.of(x * x)).get() == 16

    assert Lazy.of(1).bind(lambda x: Lazy.of(x * x)).bind(lambda x: Lazy.of(x * x)).get() == 1

# Generated at 2022-06-25 23:44:06.785869
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    dict_1 = {}
    lazy_1 = Lazy(dict_1)

    dict_1_ = {}
    lazy_1_ = Lazy(dict_1_).bind(lambda x: Lazy.of(x))



# Generated at 2022-06-25 23:44:14.303212
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_lazy import Lazy

    def test_case_0():
        assert Lazy(None) == Lazy(None)

    def test_case_1():
        assert not (Lazy(None) == None)

    def test_case_2():
        assert not (Lazy(None) == Lazy(None).to_maybe())

    def test_case_3():
        assert not (Lazy(None) == Lazy(1))

    def test_case_4():
        assert not (Lazy(None).map(lambda x: x + 1) == Lazy(None).map(lambda x: x - 1))


# Generated at 2022-06-25 23:44:24.666429
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_case_1():
        lazy_0 = Lazy.of(4.2)
        def fn_0(a: float) -> Lazy[float, float]:
            return Lazy.of(a / 2.0)

        lazy_1 = lazy_0.bind(fn_0)
        assert lazy_1.constructor_fn(5) == 2.1

    def test_case_2():
        # it's impossible to check Lazy after execution
        lazy_0 = Lazy.of(4.2)
        def fn_0(a: float) -> Lazy[float, float]:
            return Lazy.of(a / 2.0)

        lazy_1 = lazy_0.bind(fn_0)
        lazy_1 = lazy_1.map(lambda a: a * 2)
        assert lazy_

# Generated at 2022-06-25 23:44:28.450169
# Unit test for method map of class Lazy
def test_Lazy_map():
    def create_dictionary(*args):
        return {'key': 'value'}

    lazy = Lazy(create_dictionary)
    get_string = lambda x: str(x)  # noqa

    assert isinstance(lazy.map(get_string), Lazy)



# Generated at 2022-06-25 23:44:35.973334
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    dict_0 = {'a': 'b'}
    lazy_0 = Lazy(dict_0)
    def fn_0(dict_0):
        return Lazy(dict_0.get('a'))
    v_0 = lazy_0.bind(fn_0)
    assert isinstance(v_0, Lazy)
    assert v_0._is_evaluated == False
    assert type(v_0._value) is None
    assert v_0._constructor_fn == fn_0(dict_0._constructor_fn)
    dict_1 = {'a': 'b'}
    lazy_1 = Lazy(dict_1)
    def fn_1(dict_1):
        return Lazy(dict_1.get('a'))

# Generated at 2022-06-25 23:44:47.079279
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    def store(value):
        try:
            return Validation.success(value)
        except Exception as error:
            return Validation.failure(error.args)

    def multiply_by_two(value: int):
        return value * 2

    def convert_to_int(value: str):
        return int(value)

    def multiply_by_three(value: int):
        return value * 3

    def divide_by_two(value: int):
        return value / 2

    def to_upper(value: str):
        return value.upper()
    
    def convert_to_str(value: int):
        return str(value)


# Generated at 2022-06-25 23:44:54.604765
# Unit test for method get of class Lazy
def test_Lazy_get():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)

    assert lazy_0.get() == dict_0, 'expected {} but got {}'.format(dict_0, lazy_0.get())



# Generated at 2022-06-25 23:44:59.111998
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lst_0 = [1, 2, 3]
    lazy_0 = Lazy(lst_0)
    assert lazy_0.bind(lambda lst: Lazy(lst[0])) == Lazy(lambda: 1)
    assert lazy_0.bind(lambda lst: Lazy(lst[1])) == Lazy(lambda: 2)
    assert lazy_0.bind(lambda lst: Lazy(lst[2])) == Lazy(lambda: 3)



# Generated at 2022-06-25 23:45:02.480832
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda a: a * a).ap(Lazy(lambda b: b * b * b)).get(2) == 8
    assert Lazy(lambda a: a + a).ap(Lazy(lambda b: b + b + b)).get(2) == 12


# Generated at 2022-06-25 23:45:13.066244
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # c0 -> {a: 0}
    def c0() -> dict:
        return {'a': 0}

    # mapper = {key: {value: value * 2 } for key, value in dict.items}
    # dict_0 = lazy_0.bind(mapper)
    dict_0 = Lazy(c0).bind(lambda key_value_dict: {key: {value: value * 2} for key, value in key_value_dict.items()})

    # Test
    assert dict_0.is_evaluated is False
    assert dict_0.value is None
    assert dict_0.get() == {'a': {0: 0}}
    assert dict_0.is_evaluated is True
    assert dict_0.value == {'a': {0: 0}}


# Generated at 2022-06-25 23:45:16.417259
# Unit test for method get of class Lazy
def test_Lazy_get():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    got_0 = lazy_0.get()
    assert got_0 == lazy_0.constructor_fn()


# Generated at 2022-06-25 23:45:24.293454
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Tests case for test_Lazy_bind method.
    """
    def lambda_23(arg0: int) -> int:
        return (arg0 + 1)

    lazy_23 = Lazy(lambda_23)
    first_value = lazy_23.bind(lambda arg0: Lazy(lambda arg1: arg0 + arg1))
    second_value = first_value.bind(lambda arg0: Lazy(lambda arg1: arg0 + arg1))
    third_value = second_value.bind(lambda arg0: Lazy(lambda arg1: arg0 + arg1))
    fourth_value = third_value.bind(lambda arg0: Lazy(lambda arg1: arg0 + arg1))

# Generated at 2022-06-25 23:45:26.247480
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of("").bind(lambda x: Lazy.of("s")) == Lazy("s")

# Generated at 2022-06-25 23:45:31.738239
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Given
    lazy_0 = Lazy.of({})
    lazy_1 = Lazy.of(lambda x: x)

    # When
    lazy_2 = lazy_1.ap(lazy_0)

    # Then
    assert lazy_2 == lazy_0
    # And
    assert lazy_2.get() == {}


# Generated at 2022-06-25 23:45:38.715625
# Unit test for method get of class Lazy
def test_Lazy_get():
    class TestLazyGet(object):
        def __init__(self):
            self.get_call_count = 0
        def get(self, *args):
            self.get_call_count += 1
            return 5

    test_lazy_get = TestLazyGet()
    expected_lazy = Lazy(test_lazy_get.get)

    assert expected_lazy.get(1) == 5
    assert expected_lazy.get(2) == 5
    assert expected_lazy.get_call_count == 1


# Generated at 2022-06-25 23:45:41.069281
# Unit test for method map of class Lazy
def test_Lazy_map():
    dict_0 = {}
    dict_1 = dict_0.copy()
    lazy_0 = Lazy(dict_0)
    lazy_1 = lazy_0.map(dict_1)


# Generated at 2022-06-25 23:45:47.227741
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 23:45:51.240260
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Arrange
    obj = Lazy(lambda: 40)
    expected_result = 40

    # Act
    result = obj.get()

    # Assert
    assert expected_result == result



# Generated at 2022-06-25 23:45:55.839756
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    empty_lazy_0 = Lazy(None)
    empty_lazy_1 = Lazy(None)
    empty_lazy_2 = Lazy(lambda: 1)

    assert empty_lazy_0 == empty_lazy_1
    assert not empty_lazy_0 == empty_lazy_2



# Generated at 2022-06-25 23:46:05.057143
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def test_data_0():
        dict_0 = dict(key_0=1)
        return dict_0

    def test_data_1():
        dict_0 = dict(key_0=1, key_1=1)
        return dict_0

    def test_data_2():
        dict_0 = dict()
        return dict_0

    lazy_0 = Lazy(test_data_0)
    lazy_1 = Lazy(test_data_1)
    lazy_2 = Lazy(test_data_2)

    def test_fn_0(*args):
        return lazy_1.constructor_fn(*args)

    def test_fn_1(*args):
        return lazy_0.constructor_fn(*args)


# Generated at 2022-06-25 23:46:11.692246
# Unit test for method map of class Lazy
def test_Lazy_map():
    func_0 = lambda: {'key': 'value'}
    lazy_0 = Lazy(func_0)

    func_1 = lambda: {'the_key': 'the_value'}
    lazy_1 = Lazy(func_1)

    # Create mapper function
    func_2 = lambda data: '{key} => {value}'.format(key=data['key'], value=data['value'])
    lazy_2 = Lazy(func_2)

    assert (
        lazy_1.map(lambda data: '{key} => {value}'.format(key=data['key'], value=data['value'])).fold() ==
        lazy_2.fold()
    )


# Generated at 2022-06-25 23:46:21.326081
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Tests for bind method Lazy class.

    1. Lazy with string "Hello" return "Hello H".
    2. Lazy with string "Hello" returns "Hello" after bind to Lazy of string "H".
    3. Lazy of list [1, 2] returns [3, 4] after bind to Lazy of list [2, 3].
    4. Lazy of list [1, 2] and Lazy of list [2, 3] return [3, 4] after bind to Lazy of list [2, 3].
    """
    lazy_0 = None
    lazy_1 = None
    lazy_2 = None
    lazy_3 = None
    lazy_4 = None
    lazy_5 = None
    def fn_0(arg_0):
        return arg_0 + " H"

# Generated at 2022-06-25 23:46:30.602772
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_two_to_0(x) -> Lazy[int, int]:
        return Lazy(lambda: x + 2)

    def add_two_to_1(x) -> Lazy[int, int]:
        return Lazy(lambda: x + 2)

    def add_two_to_2(x) -> Lazy[int, int]:
        return Lazy(lambda: x + 2)

    assert Lazy(lambda: 1)\
        .bind(add_two_to_0)\
        .bind(add_two_to_1)\
        .bind(add_two_to_2)\
        .get() == 7


# Generated at 2022-06-25 23:46:35.486406
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)

    # Test case 0
    if not lazy_0.bind(lambda: Lazy(8)).get():
        raise Exception("Should fail")

    # Test case 1
    if not lazy_0.bind(lambda: Lazy(8)).get():
        raise Exception("Should fail")

    # Test case 2
    lazy_0 = Lazy({'a': 2, 'b': None})

    def inner_fn_0(x, dct):
        if x not in dct:
            raise Exception('KeyError')
        if dct[x] is None:
            raise Exception('ValueError')
        return dct[x]


# Generated at 2022-06-25 23:46:39.142153
# Unit test for method get of class Lazy
def test_Lazy_get():
    # 1. empty lazy
    result = Lazy(lambda: tuple()).get()
    assert tuple() == result

    # 2. not empty lazy
    result = Lazy(lambda: (2, 3, 4)).get()
    assert (2, 3, 4) == result



# Generated at 2022-06-25 23:46:42.261790
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(val):
        return Lazy(lambda a: a + val)

    assert Lazy(lambda x: x + 1).bind(fn).get(1) == 3



# Generated at 2022-06-25 23:46:57.130616
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Init data
    dict_0 = {}

    # start Lazy test
    lazy_0 = Lazy(dict_0)
    lazy_0 = lazy_0.map(lambda x: dict_0)
    lazy_0 = lazy_0.bind(lambda x: Lazy.of(x))

    # check result
    assert lazy_0 == Lazy.of(dict_0)



# Generated at 2022-06-25 23:47:09.082856
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy(object())
    test_0 = lazy_0.bind(lambda arg0: Lazy(arg0))
    assert isinstance(test_0, Lazy)
    assert lazy_0 == test_0
    test_1 = Lazy.of(object()).bind(lambda arg0: Lazy(arg0))
    assert isinstance(test_1, Lazy)
    assert lazy_0 != test_1
    test_2 = lazy_0.bind(lambda arg0: Lazy.of(arg0))
    assert isinstance(test_2, Lazy)
    assert lazy_0 == test_2
    test_3 = Lazy.of(object()).bind(lambda arg0: Lazy.of(arg0))
    assert isinstance(test_3, Lazy)

# Generated at 2022-06-25 23:47:19.001782
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    dict_0 = {'a': 1}
    lazy_0 = Lazy(dict_0)

    dict_1 = {'b': 2}
    lazy_1 = Lazy(dict_1)

    dict_2 = {'c': 3, 'd': 4}
    lazy_2 = Lazy(dict_2)

    dict_3 = {'e': 5, 'f': 6}
    lazy_3 = Lazy(dict_3)

    def fn(dict):
        return dict

    lazy_4 = Lazy(fn)

    assert lazy_4.ap(lazy_0) == lazy_0

    assert lazy_4.ap(lazy_1).get() == {'b': 2}


# Generated at 2022-06-25 23:47:27.785474
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Test data
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    lazy_1 = Lazy(dict_0)
    lazy_1_value = lazy_0.bind(lambda x: lazy_1)

    # Test code
    assert lazy_1_value.is_evaluated == True
    assert lazy_1_value.value == lazy_1.constructor_fn
    assert lazy_1_value.constructor_fn == lazy_1.constructor_fn
    assert lazy_1_value.constructor_fn == lazy_1.constructor_fn



# Generated at 2022-06-25 23:47:37.288844
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.nothing import Nothing
    from pymonet.validation import Validation

    dict_0 = {}
    lazy_0 = Lazy(dict_0)

    def f0(a, b):
        return a + b

    lazy_1 = Lazy(f0)

    lazy_2 = Lazy(f0)

    assert lazy_2.is_evaluated == False
    assert lazy_2 == lazy_1

    assert lazy_1.is_evaluated == False
    lazy_1.get(1, 2)
    assert lazy_1.is_evaluated == True
    assert lazy_1 == lazy_1


# Generated at 2022-06-25 23:47:39.430257
# Unit test for method get of class Lazy
def test_Lazy_get():
    for _ in range(1000000):
        get_0 = Lazy.of('str_0').get('str_0')
    assert get_0 == 'str_0'



# Generated at 2022-06-25 23:47:41.425868
# Unit test for method get of class Lazy
def test_Lazy_get():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    assert lazy_0.get() == {}


# Generated at 2022-06-25 23:47:44.399345
# Unit test for method map of class Lazy
def test_Lazy_map():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    lazy_0 = lazy_0.map(int)

    assert lazy_0 == Lazy(dict_0).map(int)
# End of Unit test for method map of class Lazy


# Generated at 2022-06-25 23:47:55.267324
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_case_1():
        def function_0():
            def function_1(value_0):
                return Lazy(function_2)

            def function_2():
                return value_0

            return function_1

        return function_0

    def test_case_2():
        def function_3():
            def function_4(value_1):
                return Lazy(function_5)

            def function_5():
                return value_1

            return function_4

        return function_3


# Generated at 2022-06-25 23:48:09.856436
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Case 0
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    lazy_0_result = lazy_0.map(dict_0)
    assert lazy_0_result.is_evaluated is False
    assert lazy_0_result.value is None
    assert lazy_0_result.constructor_fn == dict_0
    # Case 1
    list_0 = []
    lazy_1 = Lazy(list_0)
    str_0 = '1'
    lazy_1_result = lazy_1.map(str_0)
    assert lazy_1_result.is_evaluated is False
    assert lazy_1_result.value is None
    assert lazy_1_result.constructor_fn == str_0
    # Case 2
    str_0 = '2'
    lazy

# Generated at 2022-06-25 23:48:22.933547
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test method ap of class Lazy.
    """
    # Initialize arguments
    value_0 = None
    # Call tested method
    result_0 = Lazy.of(value_0).ap(Lazy.of())
    # Check result
    assert (result_0 == Lazy.of(value_0))



# Generated at 2022-06-25 23:48:31.461749
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.validation import Validation

    def test_case_0():
        dict_0 = {}
        lazy_0 = Lazy(dict_0)

    def test_case_1():
        list_0 = [1, 2, 3, 4]
        lazy_0 = Lazy(list_0)

        assert lazy_0.get() == list_0

    def test_case_2():
        dict_0 = {'a': 1}
        lazy_0 = Lazy(dict_0)

        assert lazy_0.get() == dict_0

    def test_case_3():
        list_0 = [1, 2, 3, 4]
        lazy_0 = Lazy(list_0)

        assert lazy_0.get() == list_0


# Generated at 2022-06-25 23:48:39.110063
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    lazy_0.constructor_fn = (lambda x: Lazy(lambda y: x))
    lazy_0.is_evaluated = True
    lazy_0.value = dict_0
    lazy_0_bind_0 = lazy_0.bind((lambda var_0: Lazy(lambda var_1: {})))
    assert isinstance(lazy_0_bind_0, Lazy)
    lazy_0_bind_0_0 = lazy_0_bind_0.constructor_fn
    assert lazy_0_bind_0_0(None) == dict_0


# Generated at 2022-06-25 23:48:41.245961
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy.of(0)
    lazy_1 = lazy_0.bind(lambda v: Lazy.of(v + 1))
    assert lazy_1.get() == 1


# Generated at 2022-06-25 23:48:50.516221
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    lazy_0 = Lazy(dict_0)
    lazy_1 = Lazy(dict_0)
    lazy_2 = Lazy(dict_2)
    lazy_3 = Lazy(dict_4)
    lazy_4 = Lazy(dict_1)
    lazy_5 = Lazy(dict_5)
    lazy_6 = Lazy(dict_2)
    lazy_7 = Lazy(dict_4)
    lazy_8 = Lazy(dict_1)
    lazy_9 = Lazy(dict_3)
    lazy_10 = Lazy(dict_5)
    lazy_11 = Lazy(dict_0)
   

# Generated at 2022-06-25 23:48:55.141093
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    fn_0 = lambda value: Lazy.of(value)
    lazy_0 = Lazy(fn_0)
    value_0 = 'test_Lazy_bind'
    value_1 = lazy_0.bind(fn_0).get()
    assert value_1 == value_0


# Generated at 2022-06-25 23:48:57.934126
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Maybe

    lazy_0 = Maybe.just(2).to_lazy()
    lazy_1 = lazy_0.map(lambda x: x + 2)
    assert lazy_1.get() == 4



# Generated at 2022-06-25 23:49:03.759853
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_key_and_value_to_dict(dict_0):
        def add_key_and_value(key, value, dict_1):
            dict_1[key] = value
            return dict_1

        return Lazy(lambda: add_key_and_value('key_0', 'value_0', dict_0))

    dict_0 = {}
    lazy_0 = Lazy(dict_0)

    lazy_1 = lazy_0.bind(add_key_and_value_to_dict)

    assert isinstance(lazy_1, Lazy)
    assert lazy_1.constructor_fn() == {'key_0': 'value_0'}


# Generated at 2022-06-25 23:49:06.768115
# Unit test for method get of class Lazy
def test_Lazy_get():
    # test_case_0: get method works
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    assert lazy_0.get() == dict_0
    assert lazy_0.is_evaluated


# Generated at 2022-06-25 23:49:12.700910
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 2).get() == 2
    assert Lazy(lambda: "abc").get() == "abc"
    assert Lazy(lambda: [1, 2, 3]).get() == [1, 2, 3]

    assert Lazy(lambda a: a).get(1) == 1
    assert Lazy(lambda a: a + 1).get(1) == 2


# Generated at 2022-06-25 23:49:35.770071
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    dict_0 = {"a": 1}
    lazy_0 = Lazy(dict_0)
    lazy_1 = Lazy(dict_0)

    assert lazy_0 == lazy_0
    assert lazy_0 != lazy_1
    assert lazy_1 != lazy_0



# Generated at 2022-06-25 23:49:39.561328
# Unit test for method map of class Lazy
def test_Lazy_map():
    dict_0 = {'a': 1, 'b': 2}
    dict_1 = {'a': 2, 'b': 4}
    lazy_0 = Lazy(dict_0)
    lazy_1 = lazy_0.map(lambda a: a*2)
    assert lazy_1 == Lazy(dict_1)


# Generated at 2022-06-25 23:49:51.431929
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.validation import Validation
    from pymonet.immutability import ImmutableList as List

    values = [
        Lazy.of(1),
        Lazy.of('a'),
        Lazy.of(True),
        Lazy.of(Box(1)),
        Lazy.of(Right(1)),
        Lazy.of(Maybe.just(1)),
        Lazy.of(Try.of(lambda: 1)),
        Lazy.of(Validation.success(1)),
        Lazy.of(List()),
    ]

# Generated at 2022-06-25 23:49:58.800500
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.box import Box

    lazy_0 = Lazy.of(8)
    lazy_1 = Lazy(lambda x: x + 9)
    lazy_2 = lazy_0.ap(lazy_1)
    assert lazy_2.get(5) == 8 + 9

    right_0 = Right(9)
    right_1 = lazy_0.ap(right_0)
    assert right_1 == Right(8 + 9)

    left_0 = Left(8)
    left_1 = lazy_0.ap(left_0)
    assert left_1 == Left(8)

    lazy_3 = Lazy.of(5)

# Generated at 2022-06-25 23:50:03.064140
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    dict_1 = {}
    lazy_1 = Lazy(dict_1)
    lazy_2 = lazy_0.ap(lazy_1)

# Generated at 2022-06-25 23:50:08.486691
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    dict_0 = {}
    dict_1 = {}
    lazy_0 = Lazy(dict_0)
    lazy_1 = Lazy(dict_1)

    lazy_1.ap(lazy_0)

    assert lazy_1.is_evaluated == False
    assert lazy_1.value == None

    assert lazy_0.is_evaluated == False
    assert lazy_0.value == None


# Generated at 2022-06-25 23:50:18.463186
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    dict_1 = {}
    lazy_1 = Lazy(dict_1)
    assert lazy_0 == lazy_1
    dict_2 = {}
    lazy_2 = Lazy(dict_2)
    dict_3 = {}
    lazy_3 = Lazy(dict_3)
    assert lazy_2 == lazy_3
    dict_4 = {}
    lazy_4 = Lazy(dict_4)
    dict_5 = {}
    lazy_5 = Lazy(dict_5)
    assert lazy_4 == lazy_5
    dict_6 = {}
    lazy_6 = Lazy(dict_6)
    dict_7 = {}
    lazy_7 = Lazy(dict_7)
    assert lazy_6 == lazy_7

# Generated at 2022-06-25 23:50:27.268642
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Test for case when Lazy is not empty
    dict_0 = {'a': 2}
    lazy_0 = Lazy(dict_0)
    lazy_3 = lazy_0.map(lambda value: value.values())
    list_0 = list(lazy_3.get().values())
    assert list_0 == [2]
    # Test for case when Lazy is empty
    lazy_4 = Lazy(dict()).map(lambda value: value['b'])
    assert lazy_4.get() is None
    # Test for case when Lazy is not empty
    dict_1 = {'a': 0}
    lazy_5 = Lazy(dict_1)
    lazy_6 = lazy_5.map(lambda value: value.values())
    list_1 = list(lazy_6.get().values())