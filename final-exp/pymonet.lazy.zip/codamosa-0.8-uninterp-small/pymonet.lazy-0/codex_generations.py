

# Generated at 2022-06-25 23:40:36.681015
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_case_0():  # test_Lazy___eq___0
        int_0 = 13
        lazy_0 = Lazy.of(int_0)
        lazy_1 = Lazy.of(int_0)
        bool_0 = lazy_0.__eq__(lazy_1)
    def test_case_1():  # test_Lazy___eq___1
        int_0 = 0
        lazy_0 = Lazy.of(int_0)
        lazy_1 = Lazy(int)
        bool_0 = lazy_0.__eq__(lazy_1)
    def test_case_2():  # test_Lazy___eq___2
        int_0 = 20
        lazy_0 = Lazy.of(int_0)
        lazy_1 = Lazy.of

# Generated at 2022-06-25 23:40:45.491820
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def lambda_fn(a, b):
        return a + b

    lazy_0 = Lazy.of(0)
    lazy_x = Lazy.of(lambda_fn)
    lazy_5 = lazy_x.ap(lazy_0).ap(lazy_0)
    lazy_10 = lazy_5.ap(lazy_5)
    maybe_10 = lazy_10.to_maybe()
    maybe_none = lazy_10.to_maybe(1, 2)

    assert maybe_10 == Maybe.just(10)
    assert maybe_none == Maybe.none()


# Generated at 2022-06-25 23:40:49.807917
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 1716
    lazy_0 = Lazy.of(int_0)
    int_1 = 8291
    lazy_1 = Lazy.of(int_1)
    lazy_0_copy = Lazy.of(int_0)

    assert lazy_0 == lazy_0_copy
    assert lazy_0 != lazy_1


# Generated at 2022-06-25 23:40:55.704334
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = 1716
    str_0 = '1716'
    str_1 = 'Test 1716'
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(str_0)
    lazy_2 = lazy_0.ap(lazy_1)
    lazy_3 = lazy_1.map(str_1.__contains__)
    str_2 = lazy_2.get()
    bool_0 = lazy_3.get()


# Generated at 2022-06-25 23:41:05.885899
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of('a').get() == 'a'
    assert Lazy.of(True).get() is True
    assert Lazy.of(['a']).get() == ['a']
    assert Lazy.of(lambda x: x).get()
    assert Lazy.of(lambda x: x).get(Lazy.of('a')) == Lazy.of('a')
    assert Lazy.of(Lazy.of('a')).get() == Lazy.of('a')
    assert Lazy.of(Lazy.of('a')).get().get() == 'a'
    assert Lazy.of(Lazy.of(['a'])).get() == Lazy.of(['a'])

# Generated at 2022-06-25 23:41:13.559997
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lst_0 = []
    lst_1 = [1, 1, 1]
    lst_2 = [2, 2, 2]
    lst_3 = [3, 3, 3]
    lst_4 = [4, 4, 4]
    lst_5 = [5, 5, 5]
    lst_6 = [6, 6, 6]

    lazy_0 = Lazy(lambda: lst_0)
    lazy_1 = Lazy(lambda: lst_1)
    lazy_2 = Lazy(lambda: lst_2)
    lazy_3 = Lazy(lambda: lst_3)
    lazy_4 = Lazy(lambda: lst_4)
    lazy_5 = Lazy(lambda: lst_5)

# Generated at 2022-06-25 23:41:17.110670
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    int_1 = 46859
    lazy_1 = Lazy(int_1)
    lazy_2 = lazy_0.__eq__(lazy_1)



# Generated at 2022-06-25 23:41:26.437146
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Test for bind method for storing function for making int from string
    def fn_1(int_0):
        return Lazy(int_0)

    # Test for bind method for storing function for making string from another string as double string
    def fn_2(str_0):
        return Lazy(str_0 + str_0)

    # Test for bind method for storing function for making string from int as string
    def fn_3(int_0):
        return Lazy(str(int_0))

    # Test for bind method for storing function for making int from two ints as sum
    def fn_4(int_0, int_1):
        return Lazy(int_0 + int_1)

    # Test for bind method for storing function for making int from another int as double int

# Generated at 2022-06-25 23:41:33.276928
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    _string = 'foo'
    _int = 42
    Lazy_A = Lazy(lambda: _string)
    Lazy_B = Lazy(lambda: _int)
    Lazy_C = Lazy(lambda: _string)
    Lazy_D = Lazy(lambda: _string)
    assert Lazy_A.__eq__(Lazy_B) == False
    assert Lazy_A.__eq__(Lazy_C) == False
    assert Lazy_A.__eq__(Lazy_D) == False


# Generated at 2022-06-25 23:41:38.471171
# Unit test for method get of class Lazy
def test_Lazy_get():
    # test for case 0
    lazy_0 = Lazy.of(1716)
    lazy_0_result = lazy_0.get()
    assert lazy_0_result == 1716
    # test for case 1
    xs = [0]
    lazy_0 = Lazy(lambda: xs.pop())
    lazy_0_result = lazy_0.get()
    assert lazy_0_result == 0


# Generated at 2022-06-25 23:41:42.519375
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x: x + 1).ap(Lazy(lambda x: x + 2)).get() == 5


# Generated at 2022-06-25 23:41:47.894445
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    lazy_0 = Lazy.of(True)
    # test returns Lazy
    lazy_1 = lazy_0.ap(Maybe.just(False))
    assert type(lazy_1) == Lazy
    # test contains function
    assert lazy_1.constructor_fn is not None
    # test result of constructor
    assert lazy_1.get() is False


# Generated at 2022-06-25 23:41:53.845729
# Unit test for method get of class Lazy
def test_Lazy_get():
    class CustomInt(int):
        pass

    int_0 = 1716
    int_1 = 1716
    custom_int_0 = CustomInt()
    custom_int_0.__int__ = lambda: int_1
    lazy_0 = Lazy(int_0)
    lazy_0.get()
    lazy_1 = Lazy(custom_int_0)
    lazy_1.get()


# Generated at 2022-06-25 23:41:56.568954
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    lazy_0.bind(
        fn=lambda r: Lazy(r)
    )


# Generated at 2022-06-25 23:42:05.883549
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_int_0 = Lazy.of(1716)
    lazy_int_0_bind_0 = lazy_int_0.bind(lambda arg_0: Lazy.of(arg_0))
    int_0 = lazy_int_0_bind_0.get()
    assert int_0 == 1716


# Generated at 2022-06-25 23:42:09.607945
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = 1716
    lazy_0 = Lazy.of(int_0)
    int_1 = lazy_0.get()
    assert int_0 == int_1, "Lazy.get() != Lazy.of(I)"


# Generated at 2022-06-25 23:42:21.040840
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test for method Lazy.map
    :returns: pass if function is correct
    :rtype: bool
    """
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def map_fn(a: int) -> str:
        return '{}'.format(a)

    def ap_fn(a: int) -> str:
        return '{}'.format(a)

    def bind_fn(a: int) -> Lazy[int, str]:
        def constructor_fn(a: int) -> str:
            return '{}'.format(a)

        return Lazy(constructor_fn)

    int_0 = 17

# Generated at 2022-06-25 23:42:25.502426
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(int_0)
    boolean_0 = lazy_0.__eq__(lazy_1)
    assert boolean_0 == True


# Generated at 2022-06-25 23:42:30.414272
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 1716
    lazy_0 = Lazy(int_0)

    def add_one(a):
        return a + 1

    lazy_1 = lazy_0.map(add_one)

    assert int_0 + 1 == lazy_1.get()



# Generated at 2022-06-25 23:42:34.547396
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1716
    lazy_0 = Lazy.of(int_0)

    def fn_0() -> Lazy[int, int]:
        return Lazy.of(int_0)

    lazy_1 = lazy_0.bind(fn_0)
    str_0 = lazy_1.__str__()


# Generated at 2022-06-25 23:42:39.851329
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Test for correct bind for notempty Lazy
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.bind(lambda int_0: Lazy(1716 if int_0 else 1715))
    bool_0 = isinstance(lazy_1, Lazy)
    assert bool_0


# Generated at 2022-06-25 23:42:49.041142
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test bind(self, fn) method of class Lazy.
    """
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    str_0 = '0'
    str_1 = '1'
    str_2 = '2'
    str_3 = '3'
    lazy_0 = Lazy.of(int_0)
    lazy_1 = lazy_0.map(str)
    lazy_2 = lazy_1.bind(Lazy.of)
    bool_0 = lazy_2 == lazy_1
    bool_1 = lazy_2.get() == str_0
    bool_2 = lazy_1.get() == str_0
    bool_3 = lazy_2.is_evaluated
    lazy_3 = Lazy.of

# Generated at 2022-06-25 23:42:59.387719
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Init test objects
    method_Lazy_bind_argument0 = Lazy.of(None)
    method_Lazy_bind_argument1 = Lazy.of(None)
    method_Lazy_bind_argument2 = Lazy.of(None)
    method_Lazy_bind_argument3 = Lazy.of(None)
    method_Lazy_bind_argument4 = Lazy.of(None)
    # Method call and assertions
    assert (Lazy.of('foo').bind(lambda v: Lazy.of(v)) == Lazy.of('foo'))
    assert (Lazy.of('foo').bind(lambda v: Lazy.of(v)).bind(lambda v: Lazy.of(v)) == Lazy.of('foo'))

# Generated at 2022-06-25 23:43:01.528496
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = 1716
    lazy_0 = Lazy.of(int_0)
    int_2 = lazy_0.get()
    assert int_2 == int_0


# Generated at 2022-06-25 23:43:08.346159
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 1716
    int_1 = 1814
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.map(lambda i: i + 1)
    lazy_2 = lazy_1.map(lambda i: i - 2)
    assert lazy_2.get() == int_1
    try:
        assert (lazy_1.get() == int_1)
        assert False
    except Exception as ex:
        assert True



# Generated at 2022-06-25 23:43:18.012721
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.either import Right

    # Box
    box_0 = Box(lambda x: x + 1)
    box_1 = Box(3)
    box_2 = box_0.ap(box_1)

    # Try
    try_0 = Try.of(lambda x: x + 1)
    try_1 = Try.of(3)
    try_2 = try_0.ap(try_1)

    # Maybe
    maybe_0 = Maybe.just(lambda x: x + 3)
    maybe_1 = Maybe.just(4)
    maybe_2 = maybe_0.ap(maybe_1)

   

# Generated at 2022-06-25 23:43:19.975040
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_a = 22
    lazy = Lazy(int_a)
    test_assert_equal(int_a, lazy.get())


# Generated at 2022-06-25 23:43:23.319884
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    inner_fn = lambda x: Lazy(lambda *args: x)
    lazy_0 = Lazy.of(lambda x: x * 2)
    lazy_1 = lazy_0.map(lambda x: x * 2)
    lazy_2 = lazy_1.bind(inner_fn)
    assert lazy_2.get(2) == 8

# Generated at 2022-06-25 23:43:34.724134
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box

    int_1 = 1716
    lazy_0 = Lazy(int_1)
    int_0 = lazy_0.get()
    assert int_0 == int_1
    int_2 = 1719
    lazy_1 = Lazy(int_2)
    int_0 = lazy_1.get()
    assert int_0 == int_2
    str_0 = 'monet'
    lazy_2 = Lazy(str_0)
    str_1 = lazy_2.get()
    assert str_1 == str_0
    lazy_3 = Lazy(str_0)
    str_1 = lazy_3.get()
    assert str_1 == str_0
    box_0 = Box(str_0)

# Generated at 2022-06-25 23:43:36.115446
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1


# Generated at 2022-06-25 23:43:43.568003
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def f(x):
        return Box(10)

    x = Lazy(lambda: 5).ap(Box(f))
    assert x.get() == Maybe.just(50)

    def f(x):
        return Maybe.just(10)

    x = Lazy(lambda: 5).ap(Maybe.just(f)).get()
    assert x == Maybe.just(50)


# Generated at 2022-06-25 23:43:52.771173
# Unit test for method __eq__ of class Lazy

# Generated at 2022-06-25 23:43:55.978675
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 1716
    lazy_0 = Lazy.of(int_0)
    success_0 = lazy_0.map(int_0)


# Generated at 2022-06-25 23:44:01.016259
# Unit test for method get of class Lazy
def test_Lazy_get():
    string = 'x'
    lazy_1 = Lazy(string)
    result_1 = lazy_1.get()
    assert(result_1 == string)

    empty_lazy = Lazy(lambda: None)
    result_2 = empty_lazy.get()
    assert(result_2 == None)



# Generated at 2022-06-25 23:44:09.641500
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    # Test case 0
    lazy_0: Lazy[int, int] = Lazy(lambda *args: 1716)
    lazy_1: Lazy[int, Lazy[int, int]] = Lazy.of(Lazy.of(1716))
    lazy_2: Lazy[int, int] = lazy_1.ap(lazy_0)
    assert isinstance(lazy_2, Lazy)

    # Test case 1
    lazy_3: Lazy[int, float] = Lazy(lambda *args: 1716.0)
    lazy_4: Lazy[int, float] = lazy_3.ap(lazy_0)
    assert isinstance(lazy_4, Lazy)
    assert lazy_4 == Lazy(lambda *args: 1716.0)

    # Test case 2
    lazy

# Generated at 2022-06-25 23:44:20.074558
# Unit test for method map of class Lazy
def test_Lazy_map():
    str_0 = 'hello'
    str_1 = 'hello'
    str_2 = 'olleh'
    str_3 = 'olleh'
    str_4 = 'olleh'
    str_5 = 'hel lo'
    str_6 = 'hel lo'
    str_7 = 'olleh'
    str_8 = 'olleh'
    fn_0 = lambda input_str : input_str[::-1]
    lazy_0 = Lazy(str_0)
    lazy_1 = Lazy.of(str_1)
    fn_1 = lambda input_str : input_str + ' '
    fn_2 = lambda input_str : input_str.replace('e', 'a')
    fn_3 = lambda input_str : input_str[3:6]
   

# Generated at 2022-06-25 23:44:26.967947
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Tests/assertions
    assert Lazy.of(42).map(lambda x: x*2).get() == 84
    assert Lazy.of(42).map(lambda x: x*2).map(lambda x: x/2).get() == 42
    assert Lazy.of(42).map(lambda x: x*2).map(lambda x: x/2).get() == 21

if __name__ == '__main__':
    test_case_0()
    test_Lazy_map()

# Generated at 2022-06-25 23:44:32.093288
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    string_0 = 'result of Lazy_ap'
    result_of_lazy_ap = Lazy(lambda value: string_0)
    fn_of_ap = Lazy(lambda value: value)

    test_lazy_ap = Lazy(lambda: fn_of_ap).ap(result_of_lazy_ap)

    assert test_lazy_ap.get()() == string_0


# Generated at 2022-06-25 23:44:34.953965
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Tests method ap of class Lazy
    """
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.ap(lazy_0)
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:44:38.385532
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x - 2).ap(Lazy.of(6)) == Lazy.of(4)
    assert Lazy.of(lambda x: x - 2).ap(Lazy.of(-6)) == Lazy.of(-8)

# Generated at 2022-06-25 23:44:46.360477
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = 1716
    lazy_0 = Lazy.of(int_0)
    int_1 = lazy_0.get()
    assert int_1 == 1716


# Generated at 2022-06-25 23:44:48.004482
# Unit test for method get of class Lazy
def test_Lazy_get():
    data = random.random()
    result = Lazy(data).get()
    assert result == data


# Generated at 2022-06-25 23:44:56.786512
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    lazy_0 = Lazy.of(lambda x : x * 2)
    lazy_1 = Lazy.of(lambda x : x + 2)
    lazy_2 = lazy_0.ap(lazy_1)
    assert lazy_2.get(2) == 6

    lazy_0 = Lazy.of(lambda x, y : x * y)
    lazy_1 = Lazy.of(lambda x, y : (x, y))
    lazy_2 = lazy_0.ap(lazy_1)
    assert lazy_2.get(2, 3) == 6

    lazy_0 = Lazy.of(lambda x, y, z : x * y * z)
    lazy_1 = Lazy.of(lambda x, y, z : (x, y, z))

# Generated at 2022-06-25 23:45:06.294100
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.utils.test_utils import assert_true, assert_false, assert_equals, assert_raise

    int_0 = 1716
    lazy_0 = Lazy.of(int_0)
    def function_0(lazy_1, lazy_2):
        return lazy_1.map(function_1)
    def function_1(int_1):
        return int_1.__mod__(int_0)
    lazy_1 = function_0(lazy_0, lazy_0)
    boolean_0 = lazy_1.__eq__(lazy_1)
    assert_true(boolean_0)

    int_1 = 0

    def function_0(lazy_1):
        return lazy_1.map(function_1)


# Generated at 2022-06-25 23:45:08.456660
# Unit test for method map of class Lazy
def test_Lazy_map():
    result = Lazy.of("first").map(lambda x: x + " - second").get()
    assert result == "first - second"


# Generated at 2022-06-25 23:45:18.369391
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    num_0 = 25
    num_1 = 8
    lazy_0 = Lazy(lambda x, y: x + y)
    lazy_1 = Lazy(lambda x, y: x / y)
    lazy_2 = lazy_0.bind(lambda x: lazy_1.bind(lambda y: Lazy(lambda x, y: x / y)))
    lazy_3 = lazy_2.bind(lambda x: lazy_1.bind(lambda y: Lazy(lambda x, y: x / y)))

    assert lazy_2.get(num_0, num_1) == lazy_1.get(num_0, num_1)
    assert lazy_3.get(num_0, num_1) == lazy_1.get(num_0, num_1)

# Generated at 2022-06-25 23:45:27.555072
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def mapper(x):
        return Lazy.of(x * x * x)

    def accumulator(x, y):
        return x + y

    lazy = Lazy.of(3)
    lazy_mapped = lazy.bind(mapper)
    assert lazy_mapped.__str__() == 'Lazy[fn=<function <lambda> at 0x7f45eba5a378>, value=None, is_evaluated=False]', \
        'Lazy.bind() broken'
    assert lazy_mapped.get() == 27, 'Lazy.bind() broken'
    assert lazy_mapped.get() == 27, 'Lazy.bind() broken'

    def wtf(x):
        return Lazy.of(x + 1)


# Generated at 2022-06-25 23:45:31.615902
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    lazy_0_0 = lazy_0.get()
    assert lazy_0_0 == int_0


# Generated at 2022-06-25 23:45:40.916815
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    # Unit test of function get
    """

# Generated at 2022-06-25 23:45:45.294551
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.point import Point
    from pymonet.box import Box

    lazy_0 = Lazy(Point(1, 2))
    lazy_1 = Lazy(Point(1, 2))
    assert lazy_0 == lazy_1

    assert lazy_0 != Box(lazy_0.get())


# Generated at 2022-06-25 23:46:03.389030
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1716
    int_1 = 2
    int_2 = 3
    lazy_0 = Lazy(int_0)
    fn_0 = lambda arg_0: Lazy(int_1 + arg_0)
    assert (lazy_0.bind(fn_0).get() == int_1 + int_0)
    int_3 = -1
    int_4 = -1
    int_5 = -1
    int_6 = -1
    int_7 = -1
    int_8 = -1
    int_9 = -1
    lazy_1 = Lazy(int_3)

# Generated at 2022-06-25 23:46:09.270751
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.either import Either
    from pymonet.try_ import Try
    from pymonet.maybe import Maybe
    excepted_int_0 = 1716
    excepted_bool_0 = True
    excepted_int_1 = 1716
    excepted_bool_1 = True
    excepted_int_2 = 1716
    excepted_bool_2 = True
    excepted_int_3 = 1716
    excepted_bool_3 = True
    excepted_int_4 = 1716
    excepted_bool_4 = True
    excepted_int_5 = 1716
    excepted_bool_5 = True
    excepted_int_6 = 1716
    excepted_bool_6 = True

# Generated at 2022-06-25 23:46:18.782600
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Either
    from pymonet.box import Box
    from pymonet.maybe import Maybe


# Generated at 2022-06-25 23:46:24.000331
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def func_0(int_0):
        return Lazy(lambda *args: int_0 * int_0)

    int_0 = 1716
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.bind(func_0)
    lazy_1.fold(lambda: None)
    int_1 = lazy_1.get()
    assert int_1 == 2920756


# Generated at 2022-06-25 23:46:34.370555
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(x,y):
        return x + y

    assert Lazy(lambda : 10).get() == 10
    assert Lazy(lambda x: x).get(14) == 14
    assert Lazy(lambda x: x*x).get(2) == 4
    assert Lazy(lambda *args: add(*args)).get(1, 2) == 3
    assert Lazy(lambda x, y: x * y).get(2, 3) == 6
    assert Lazy(lambda x: x if x%2 == 0 else None).get(2) == 2
    assert Lazy(lambda x: x if x%2 == 0 else None).get(3) is None
    assert Lazy(lambda x: x if x%2 == 1 else None).get(2) is None

# Generated at 2022-06-25 23:46:45.086028
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Test case 0
    int_1 = 1716
    lazy_1 = Lazy(int_1)
    result_lazy_1 = lazy_1.bind(lambda x: Lazy(x))
    int_2 = result_lazy_1.get()
    assert int_2 == int_1
    # Test case 1
    int_1 = 1717
    lazy_1 = Lazy(int_1)
    result_lazy_1 = lazy_1.bind(lambda x: Lazy(x))
    int_2 = result_lazy_1.get()
    assert int_2 == int_1
    # Test case 2
    int_1 = 1718
    lazy_1 = Lazy(int_1)
    result_lazy_1 = lazy_1.bind(lambda x: Lazy(x))

# Generated at 2022-06-25 23:46:53.116879
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(None).bind(lambda value: Lazy.of(value)).get() == None
    assert Lazy.of(False).bind(lambda value: Lazy.of(value)).get() == False
    assert Lazy.of(True).bind(lambda value: Lazy.of(value)).get() == True
    assert Lazy.of(0).bind(lambda value: Lazy.of(value)).get() == 0
    assert Lazy.of(1).bind(lambda value: Lazy.of(value)).get() == 1
    assert Lazy.of(1716).bind(lambda value: Lazy.of(value)).get() == 1716
    assert Lazy.of("").bind(lambda value: Lazy.of(value)).get() == ""

# Generated at 2022-06-25 23:46:57.477803
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given
    int_0 = 1716
    str_0 = 'tralala'
    lazy_0 = Lazy.of(int_0)
    lazy_1 = lazy_0.map(str)
    # When
    str_1 = lazy_1.get()
    # Then
    assert str_0 == str_1



# Generated at 2022-06-25 23:47:09.420330
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_list import List
    from pymonet.monad_set import Set

    list_1 = List(1, 2, 3)
    set_1 = Set(1, 2, 3)
    set_2 = Set(1, 1, 2, 3)
    list_2 = Set((1, 1), (1, 1), (2, 2), (3, 3))

    assert list_1.ap(list_2) == list_2.ap(list_1)
    assert list_1.ap(list_2) == List((1, 1), (1, 1), (2, 2), (3, 3), (2, 2), (3, 3), (3, 3), (3, 3))

# Generated at 2022-06-25 23:47:12.428166
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    lazy_0_get_0 = lazy_0.get(int_0)


# Generated at 2022-06-25 23:47:31.868680
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    lazy_0.get()


# Generated at 2022-06-25 23:47:40.532394
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(5).map(lambda x: x * 5) == Lazy.of(25)
    assert Lazy.of(5).map(lambda x: x * 5).map(lambda x: x / 5) == Lazy.of(5)
    assert Lazy.of(5).map(lambda x: x * 5).map(lambda x: x / 5).map(lambda x: x * 5) == Lazy.of(25)
    assert Lazy.of(5).map(lambda x: x * 5).map(lambda x: x / 5).map(lambda x: x * 5) == Lazy.of(25)
    assert Lazy.of(5).map(lambda x: x * 5).get() == 25
    assert Lazy.of(5).map(lambda x: x * 5).get() == 25


# Generated at 2022-06-25 23:47:44.840545
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def mapping_function(value):
        return value + 1

    lazy_0 = Lazy(mapping_function)
    value = 1
    lazy_1 = Lazy(value)
    lazy_2 = lazy_0.ap(lazy_1)
    result_0: bool = lazy_2.get() == 2
    assert result_0



# Generated at 2022-06-25 23:47:52.991341
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 1716
    str_0 = '1716'
    lazy_0 = Lazy.of(int_0)
    lazy_1 = lazy_0.map(lambda x: str(x))
    str_1 = lazy_1.__str__()
    assert str_1 == 'Lazy[fn=<function test_Lazy_map.<locals>.<lambda> at 0x7f4fa7dcfc80>, value=None, is_evaluated=False]'
    result_0 = lazy_1.get()
    assert result_0 == str_0
    assert lazy_1 == Lazy.of(str_0)


# Generated at 2022-06-25 23:48:01.352781
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_prefix_to_string(string):
        def fn(lazy_string):
            return string + lazy_string

        return Lazy(fn)

    def subtract_from_packed_number(number):
        def fn(lazy_number):
            return lazy_number - number

        return Lazy(fn)

    lazy_int = Lazy(lambda: 73)
    lazy_int_to_str = lazy_int.bind(add_prefix_to_string("x"))
    lazy_str_to_int = lazy_int_to_str.bind(subtract_from_packed_number(2))

    assert lazy_str_to_int.get() == 71

# Generated at 2022-06-25 23:48:08.342286
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 556
    lazy_0 = Lazy(int_0)
    bool_0 = lazy_0.__eq__(int_0)
    int_1 = lazy_0.constructor_fn
    bool_1 = bool_0
    str_0 = lazy_0.__str__()
    bool_3 = lazy_0.__eq__(int_0)
    bool_4 = bool_0


# Generated at 2022-06-25 23:48:10.714497
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.bind(Lazy.of)
    assert lazy_1 == Lazy(1716)


# Generated at 2022-06-25 23:48:16.876964
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    int_1 = lazy_0.get()
    assert int_1 is int_0, 'invalid get'
    int_2 = lazy_0.get()
    assert int_2 is int_0, 'invalid get'
    int_3 = lazy_0.get()
    assert int_3 is int_0, 'invalid get'


# Generated at 2022-06-25 23:48:25.874110
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor import Fn
    from pymonet.monad import bind

    # Case 0
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    fn_0 = Fn(lambda a: a)
    monad_0 = bind(fn_0, lazy_0)
    int_1 = monad_0.get()
    assert int_1 == int_0
    int_1 = monad_0.get(1)
    assert int_1 == int_0

    # Case 1
    str_0 = 'string'
    lazy_1 = Lazy(str_0)
    dct_0 = {
        'a': 1,
        'b': 2
    }
    fn_1 = Fn(lambda a: dct_0)

# Generated at 2022-06-25 23:48:29.152414
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    int_0 = 1716
    str_0 = 'str'
    lazy_0 = Lazy(int_0)
    assert isinstance(lazy_0.bind(lambda _: Box(str_0)), Box)
    assert isinstance(lazy_0.bind(lambda _: Maybe.just(str_0)), Maybe)


# Generated at 2022-06-25 23:49:15.127366
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.validation import Validation

    list_0 = [4, 5, 6, 7, 8]
    list_1 = []

    def add_one(val: int) -> int:
        return val + 1

    def validate_even(val: int) -> Validation[int, [str]]:
        if val % 2 == 0:
            return Validation.success(val)
        return Validation.failure(str(val) + " is not even")

    list_2 = Lazy.of(list_0).bind(lambda x: Lazy(list(map(add_one, x)))).get()
    list_3 = Lazy.of(list_0).bind(lambda x: Lazy(list(map(lambda y: y + 1, x)))).get()
    list_4 = Lazy.of

# Generated at 2022-06-25 23:49:17.492425
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    int_1 = lazy_0.get()
    assert int_1 == 1716


# Generated at 2022-06-25 23:49:22.395431
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_x(x):
        def add_x_y(y):
            return x + y
        return add_x_y
    add_five = add_x(5)
    lazy_add_five = Lazy(add_five)
    add_five_mapped = lazy_add_five.map(add_x(10))
    res = add_five_mapped.constructor_fn(10)
    if res != 25:
        raise Exception("Lazy map method not working properly")


# Generated at 2022-06-25 23:49:26.176165
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy1 = Lazy(lambda: "a")
    lazy2 = Lazy(lambda: "b")
    lazy3 = Lazy(lambda: "c")
    lazy_res = lazy1.bind(lambda x: lazy2.bind(lambda y: lazy3))
    result = lazy_res.get()
    assert result == "c"


# Generated at 2022-06-25 23:49:29.498432
# Unit test for method get of class Lazy
def test_Lazy_get():
    string_0 = 'test_Lazy_get_0'
    test_0 = Lazy(string_0)
    result_0 = test_0.get()

    assert result_0 == string_0
    assert result_0 == string_0


# Generated at 2022-06-25 23:49:39.820489
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 1716
    lazy_0 = Lazy.of(int_0)
    str_0 = lazy_0.__str__()
    assert str_0 == 'Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x7f8fdfa41d08>, value=None, is_evaluated=False]'

    int_1 = 2

    def multiply(arg: int) -> int:
        return arg * int_1

    lazy_1 = lazy_0.map(multiply)
    str_1 = lazy_1.__str__()
    assert str_1 == 'Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x7f8fdfa41e18>, value=None, is_evaluated=False]'

    int_

# Generated at 2022-06-25 23:49:52.311058
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_maybe import Maybe
    int_0 = 1716
    lazy_0 = Lazy(int_0)

    assert lazy_0.get() == int_0, 'Failed get return int_0'

    def count_side_effects():
        assert side_effect_count == 1, 'Failed get is lazy'

    lazy_0 = Lazy(Maybe.maybe)
    side_effect_count = 0
    def counter():
        nonlocal side_effect_count
        side_effect_count += 1

    lazy_0 = Lazy.of(counter())
    lazy_0.get()
    count_side_effects()
    lazy_0.get()
    count_side_effects()

    lazy_0 = Lazy(Maybe.maybe)
    assert lazy_0.get(5) == Maybe

# Generated at 2022-06-25 23:50:06.178403
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 519
    lazy_0 = Lazy.of(int_0)
    int_1 = 519
    lazy_1 = Lazy.of(int_1)
    int_2 = 227
    lazy_2 = Lazy.of(int_2)
    int_3 = 227
    lazy_3 = Lazy.of(int_3)
    int_4 = 16
    lazy_4 = Lazy.of(int_4)
    int_5 = 16
    lazy_5 = Lazy.of(int_5)
    int_6 = 7
    lazy_6 = Lazy.of(int_6)
    int_7 = 7
    lazy_7 = Lazy.of(int_7)
    int_8 = 6
    lazy_8 = Lazy.of(int_8)

# Generated at 2022-06-25 23:50:08.410562
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = Lazy.of(42)
    int_1 = Lazy.of(lambda x: x + 1)
    int_2 = int_0.ap(int_1)
    res_0 = int_2.get()
    assert res_0 == 43


# Generated at 2022-06-25 23:50:18.397388
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1716
    lazy_0 = Lazy(int_0)
    str_0 = lazy_0.__str__()
    lazy_1 = lazy_0.bind(lambda value: Lazy(lambda *args: (value + 3)))
    str_1 = lazy_1.__str__()
    int_1 = lazy_1.get()
    lazy_2 = lazy_1.bind(lambda value: Lazy(lambda *args: (value + 6)))
    str_2 = lazy_2.__str__()
    int_2 = lazy_2.get()
    lazy_3 = lazy_2.bind(lambda value: Lazy(lambda *args: (value + 9)))
    str_3 = lazy_3.__str__()
    int_3 = lazy_3.get()