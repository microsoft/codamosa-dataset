

# Generated at 2022-06-25 23:40:33.286917
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x)).get() == 1
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 2)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 3)).get() == 4


# Generated at 2022-06-25 23:40:40.807608
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def testable_fn_0(arg_0):
        return Lazy(lambda *args: arg_0 + 1)

    def testable_fn_1(arg_0):
        return Lazy(lambda *args: 2 * arg_0)

    lazy_0 = Lazy.of(5)

    assert lazy_0.bind(testable_fn_0).constructor_fn(tuple(), {}) == 6
    assert lazy_0.bind(testable_fn_1).constructor_fn(tuple(), {}) == 10



# Generated at 2022-06-25 23:40:46.297928
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    bytes_1 = b'a\x02\xff\xc0\x8a\x08\x14\x03'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(bytes_1)
    assert str(lazy_0 == lazy_1) is 'False'



# Generated at 2022-06-25 23:40:52.004382
# Unit test for method map of class Lazy
def test_Lazy_map():
    def twice(x):
        return 2 * x

    def plus(x):
        return x + 1

    lazy_0 = Lazy(lambda: 4)
    assert lazy_0.map(lambda x: x).constructor_fn() == 4
    assert lazy_0.map(twice).constructor_fn() == 8
    assert lazy_0.map(plus).constructor_fn() == 5
    assert Lazy(lambda: 4).map(plus).constructor_fn() == 5
    assert Lazy(lambda: [1, 2, 3]).map(lambda x: x[2]).constructor_fn() == 3
    assert Lazy(lambda: [1, 2, 3]).map(lambda x: x[2]).map(lambda x: x - 1).constructor_fn() == 2
    assert Lazy(lambda: 4).construct

# Generated at 2022-06-25 23:40:59.338620
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def bytes_0(arg):
        return b'\xa0Q\x89F\xc9\xd3eD'
    def fn_0(arg):
        return Lazy(bytes_0(arg))

    assert Lazy(bytes_0).bind(fn_0) == Lazy(bytes_0)


# Generated at 2022-06-25 23:41:09.901653
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    bytes_1 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(bytes_1)
    lazy_2 = Lazy(bytes_0)
    lazy_3 = Lazy(bytes_1)
    # checking if are the same objects
    assert (lazy_0 == lazy_0)
    assert (not lazy_0 == lazy_1)
    assert (not lazy_0 == lazy_2)
    assert (not lazy_0 == lazy_3)
    assert (not lazy_0 == None)
    assert (not lazy_1 == lazy_0)
    assert (lazy_1 == lazy_1)

# Generated at 2022-06-25 23:41:14.941749
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = lazy_0
    lazy_2 = Lazy.of(bytes_0)
    assert lazy_0.__eq__(lazy_1)
    assert lazy_0.__eq__(lazy_2) == False



# Generated at 2022-06-25 23:41:18.229999
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: b'\xa0Q\x89F\xc9\xd3eD').bind(lambda x: Lazy(lambda: x)) == Lazy(lambda: b'\xa0Q\x89F\xc9\xd3eD')


# Generated at 2022-06-25 23:41:25.881201
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def to_bytes_lazy(data: int) -> Lazy[int, bytes]:
        return Lazy(lambda: bytes(data))

    bytes_lazy = Lazy(lambda: bytes(100))
    bytes_lazy_2 = bytes_lazy.bind(to_bytes_lazy)
    assert bytes_lazy_2.constructor_fn() == bytes(100)
    assert bytes_lazy_2.get() == bytes(100) == bytes_lazy.get()
    assert bytes(200) == bytes_lazy.bind(lambda data: to_bytes_lazy(data * 2)).get()


# Generated at 2022-06-25 23:41:34.592007
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    assert Lazy(bytes_0) == Lazy(bytes_0)
    assert Lazy(bytes_0) != Lazy.of(bytes_0)
    assert Lazy(bytes_0) != Lazy(bytes_0 + bytes_0)
    assert Lazy(bytes_0) != Lazy.of(bytes_0 + bytes_0)
    assert Lazy.of(bytes_0) == Lazy.of(bytes_0)
    assert Lazy.of(bytes_0) != Lazy(bytes_0)
    assert Lazy.of(bytes_0) != Lazy(bytes_0 + bytes_0)

# Generated at 2022-06-25 23:41:44.105857
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.lazy import _test_Lazy_map as _test
    from pymonet.lazy import test_Lazy_map as test
    from pymonet.imports import get_imports
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def _mapper(a: int) -> int:
        return a * 3

    def _mapper_box(a: int) -> Box[int]:
        return Box(a * 5)

    def _mapper_none(a: int) -> Maybe[None]:
        return Maybe.none()


# Generated at 2022-06-25 23:41:48.411967
# Unit test for method get of class Lazy
def test_Lazy_get():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    bytes_0_0 = lazy_0.get()
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 23:41:53.466947
# Unit test for method get of class Lazy
def test_Lazy_get():
    bytes_0_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy.of(bytes_0_0)
    bytes_0_1 = b'\xa0Q\x89F\xc9\xd3eD'
    assert bytes_0_1 == lazy_0.get()


# Generated at 2022-06-25 23:42:00.605861
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 2)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 3)).get() == 4
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 4)).get() == 5
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 5)).get() == 6
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 6)).get() == 7
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 7)).get() == 8
    assert L

# Generated at 2022-06-25 23:42:06.674063
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(bytes_0)

    def f(b_val): return Lazy(lambda: bytes([b_val - 1]))

    lazy_2 = lazy_1.bind(f)
    assert lazy_2 == Lazy(bytes([255]))
    assert lazy_1 == Lazy(bytes_0)


# Generated at 2022-06-25 23:42:18.109345
# Unit test for method map of class Lazy

# Generated at 2022-06-25 23:42:25.188364
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Testing map method of class Lazy
    """
    float_map_fn = lambda x: float(x)
    double_map_fn = lambda x: float_map_fn(x) * 2
    int_10 = 10
    lazy_0 = Lazy(int_10)
    lazy_1 = lazy_0.map(float_map_fn)
    lazy_2 = lazy_1.map(double_map_fn)
    assert lazy_2.get() == 20.0


# Generated at 2022-06-25 23:42:26.933425
# Unit test for method get of class Lazy
def test_Lazy_get():
    x = Lazy(lambda: 9)
    assert x.get() == 9



# Generated at 2022-06-25 23:42:33.534074
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def function_0(value: str) -> Lazy[str, str]:
        return Lazy(lambda *args: value)

    def function_1(value: str) -> Lazy[str, str]:
        return Lazy(lambda *args: value)

    assert Lazy.of('test').bind(function_0).get() == ('test')
    assert Lazy.of('test').bind(function_0).bind(function_1).get() == ('test')



# Generated at 2022-06-25 23:42:40.736813
# Unit test for method get of class Lazy
def test_Lazy_get():
    expected_0 = '\xa0Q\x89F\xc9\xd3eD'
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    actual_0 = lazy_0.get()
    assert actual_0 == expected_0

# Generated at 2022-06-25 23:42:51.783816
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    bytearray_0 = bytearray(bytes_0)
    assert Lazy(bytearray_0).bind(lambda a: Lazy.of(str(a, "utf-8"))).get() == 'éQ\x89FÉÓeD'
    assert Lazy(bytearray_0).bind(lambda a: Lazy.of(int.from_bytes(a, "little"))).get() == 14722455269162088
    assert Lazy(bytearray_0).bind(lambda a: Lazy.of(int.from_bytes(a, "big"))).get() == 2297867149175046


# Generated at 2022-06-25 23:42:53.640132
# Unit test for method map of class Lazy
def test_Lazy_map():
    # TODO: Implement test if not implemented
    raise NotImplementedError()


# Generated at 2022-06-25 23:42:56.257666
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Test with parameters out of range
    # Test with parameters in range
    # Test with parameters in multiple ranges
    pass


# Generated at 2022-06-25 23:43:06.228615
# Unit test for method get of class Lazy
def test_Lazy_get():
    bytes_0 = b'\xaa\x15\xf7\x1f\xd4'
    lazy_0 = Lazy.of(bytes_0)
    result_0 = lazy_0.get()
    try:
        assert result_0 == bytes_0
    except AssertionError as e:
        print('AssertionError: {}'.format(e))
    else:
        print('Test pass')



# Generated at 2022-06-25 23:43:10.126298
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(val_0):
        def fn_0(val_1):
            return Lazy.of(val_0 * val_1)

        return Lazy.of(fn_0)

    assert Lazy.of(5).bind(fn).get(5) == 25


# Generated at 2022-06-25 23:43:19.510175
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    bytes_1 = b'\xaa\x9a[\xb3\xa2\x99\x8d\x1f\xad'
    lazy_1 = Lazy(bytes_1)
    lazy_2 = lazy_0.map((lambda lazy_value: lazy_value + lazy_1.get()))
    bytes_2 = b'\x0a\x9a[\xb3\xa2\x99\x8d\x1f\xad'
    lazy_3 = Lazy(bytes_2)

# Generated at 2022-06-25 23:43:22.726297
# Unit test for method get of class Lazy
def test_Lazy_get():
    value_0 = b'\r\x14\xbd\x0b\xf3\xea\xc0\x1f\x08\xa1'
    lazy_0 = Lazy(value_0)
    assert(lazy_0.get() == value_0)


# Generated at 2022-06-25 23:43:34.463852
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    code = 'curr_month = Lazy.of(lambda: datetime.datetime.now().month)\n'
    code += 'if curr_month.bind(lambda month: Lazy.of(month <= 2)):\n'
    code += '    return Lazy.of("Winter")\n'
    code += 'elif curr_month.bind(lambda month: Lazy.of(month <= 5)):\n'
    code += '    return Lazy.of("Spring")\n'
    code += 'elif curr_month.bind(lambda month: Lazy.of(month <= 8)):\n'
    code += '    return Lazy.of("Summer")\n'
    code += 'elif curr_month.bind(lambda month: Lazy.of(month <= 11)):\n'


# Generated at 2022-06-25 23:43:43.495124
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 'foo').map(lambda x: x.upper()).get() == 'FOO'
    assert Lazy(lambda: 'foo').map(lambda x: map(lambda c: c * 2, x)).get() == ['ff', 'oo', 'oo']
    assert Lazy(lambda: ['foo', 'bar']).map(lambda x: map(lambda c: c * 2, x)).get() == ['foofoo', 'barbar']
    assert Lazy(lambda: 'foo').map(lambda x: iter(x)).get() == 'foo'
    assert Lazy(lambda: ['foo', 'bar']).map(lambda x: iter(x)).get() == ['foo', 'bar']
    assert Lazy(lambda: []).map(lambda x: x + [1]).get() == [1]
    assert Lazy

# Generated at 2022-06-25 23:43:45.363039
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(5).get() == 5
    assert Lazy.of(5).to_maybe().get() == 5



# Generated at 2022-06-25 23:43:58.332897
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Two Lazy are equals where both are evaluated both have the same value and constructor functions.

    :return: void
    """
    int_0 = 0
    int_1 = 1
    int_2 = 2
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(int_1)
    lazy_2 = Lazy(int_2)
    lazy_3 = Lazy(int_0)
    lazy_4 = Lazy(int_1)
    lazy_5 = Lazy(int_2)
    lazy_6 = Lazy(int_0)
    bool_1 = lazy_1 == lazy_2
    bool_2 = lazy_1 == lazy_3
    bool_3 = lazy_1 == lazy_4
    bool_4 = lazy_1 == lazy_5
    bool_

# Generated at 2022-06-25 23:44:03.590046
# Unit test for method get of class Lazy
def test_Lazy_get():
    from random import randrange
    from pymonet.box import Box

    lazy_0 = Lazy(lambda *_: randrange(5))
    assert lazy_0.get() == lazy_0.get()
    assert lazy_0.to_box().get() == lazy_0.to_box().get()
    assert Box(lazy_0.get()) != Box(lazy_0.get())


# Generated at 2022-06-25 23:44:05.890823
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of('Monet').ap(Lazy.of(lambda x: x.lower())) == Lazy.of('monet')


# Generated at 2022-06-25 23:44:12.304546
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_validation import Validation, failures
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Right, Left

    def fn(a):
        return a + " world"

    lazy_0 = Lazy(fn)

    result = lazy_0.ap(Box(fn)).get()
    assert result == "hello world world"

    result = lazy_0.ap(Maybe(fn)).get()
    assert result == "hello world world"

    result = lazy_0.ap(Right(fn)).get()
    assert result == "hello world world"

    result = lazy_0.ap(Left(fn)).get()
    assert result == "hello world world"

   

# Generated at 2022-06-25 23:44:17.923204
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\xa1\r\xeb\xcd\xdf\xff\xe2'
    lazy_0 = Lazy(bytes_0)
    assert lazy_0.bind(lambda x: Lazy(x) if len(x) == 7 else Lazy(x)).get() == b'\xa1\r\xeb\xcd\xdf\xff\xe2'


# Generated at 2022-06-25 23:44:28.075147
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'\xf5\x81\xd1\x94S\xbe\x8dK\x89'
    bytes_1 = b'\x98'
    bytes_2 = b'\x03'
    bytes_3 = b'\xdb\x84\x10\x91\xd6\x0c\xdc'
    u_bytes_0 = [bytes_2, bytes_0, bytes_3]
    empty_list_0 = []
    lazy_0 = Lazy.of(u_bytes_0)
    str_0 = str(u_bytes_0)
    assert_equal(lazy_0.map(lambda arg: str(arg)).get(), str_0)
    lazy_1 = Lazy.of(bytes_1)

# Generated at 2022-06-25 23:44:32.674673
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(value: str) -> Lazy[str, bytes]:
        def lambda_fn(*args):
            return value.encode()

        return Lazy(lambda_fn)

    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy = Lazy.of('bytes').bind(fn)
    assert lazy.get() == bytes_0



# Generated at 2022-06-25 23:44:42.444224
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 'a').__eq__('a') == False
    assert Lazy(lambda: ('a', 'b')).__eq__('a') == False
    assert Lazy(lambda: 'a').__eq__(('a', 'b')) == False
    assert Lazy(lambda: 'a').__eq__('b') == False
    assert Lazy(lambda: 'a').__eq__(None) == False
    assert Lazy(lambda: None).__eq__(('a', 'b')) == False
    assert Lazy(lambda: 'a').__eq__('a') == False
    assert Lazy(lambda: (1, 'b', 1)).__eq__(('a', 'b')) == False
    assert Lazy(lambda: 1).__eq__(1) == False

# Generated at 2022-06-25 23:44:50.357714
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    lazy_0 = Lazy.of(7)

    def fn_0(x):
        return Lazy.of(x + 8)

    def fn_1(value):
        return Lazy.of(value)

    def fn_2(a):
        return Lazy.of(a)

    assert lazy_0.bind(fn_0).get() == 15

    lazy_1 = Lazy.of(0)
    assert lazy_1.bind(fn_1).get() == 0

    lazy_2 = Lazy.of(0)
    assert lazy_2.bind(fn_2).get() == 0

# Generated at 2022-06-25 23:44:56.306479
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test case for testing method get of class Lazy.

    """
    assert Lazy.of(8).get() == 8
    assert Lazy.of(8).map(lambda x: x + 2).get() == 10
    assert Lazy.of(8).to_box().get() == 8
    assert Lazy.of(8).to_maybe().get() == 8
    assert Lazy.of(8).to_either().get() == 8
    assert Lazy.of(8).get() == 8


# Generated at 2022-06-25 23:45:07.928582
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)

    def lambda_fn_0(*args):
        return Lazy(lambda *args: bytearray(5))

    lazy_1 = lazy_0.bind(lambda_fn_0)

    assert isinstance(lazy_1, Lazy) is True
    assert lazy_1.is_evaluated is False
    assert lazy_1.value is None
    assert lazy_1.constructor_fn is not None
    assert lazy_1.constructor_fn(*()) is not None
    assert lazy_1.constructor_fn(*()).__class__ is bytearray
    assert lazy_1.constructor_fn(*()) == bytearray(5)
    assert lazy

# Generated at 2022-06-25 23:45:11.635069
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    assert Lazy.of(lambda x: x * x).ap(Maybe.just(2)) == Maybe.just(4)
    assert Lazy.of(lambda x: x + x).ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-25 23:45:20.660422
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    byte_array_0 = []
    byte_array_1 = []
    byte_array_0 = bytearray(bytes_0)
    byte_array_1 = bytearray(bytes_0)
    map_0 = map(byte_array_0, byte_array_1)
    lazy_0 = Lazy.of(map_0)
    long_0 = long()
    long_0 = long(lazy_0.get())
    assert long_0 != 6
    lazy_0 = lazy_0.map(str)
    str_0 = str()
    str_0 = str(lazy_0.get())

# Generated at 2022-06-25 23:45:31.674431
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(bytes_0)
    bytes_1 = b'\x00\x00\x00\x00'
    lazy_2 = Lazy(bytes_1)
    lazy_3 = Lazy(bytes_1)
    lazy_4 = Lazy(bytes_1)
    assert lazy_0 == lazy_0
    assert lazy_0 != lazy_2
    assert lazy_0 == lazy_1
    assert lazy_3 != lazy_4
    assert lazy_3 == lazy_3
    assert lazy_2 != lazy_3
    assert not lazy_0 == lazy_2
    assert lazy_2 == lazy_2
    assert lazy_2 == lazy

# Generated at 2022-06-25 23:45:35.272196
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00'
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    bytes_2 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bytes_3 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

    bytes_4 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 23:45:43.356089
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    byte_0 = b'\xa0Q\x89F\xc9\xd3eD'
    byte_1 = b'\x88\xf1,\xc1\xab\x8e\xb5\xbf'
    lazy_0 = Lazy.of(byte_0)
    lazy_1 = Lazy(lambda *args: byte_1)
    lazy_2 = lazy_0.bind(lambda byte_2: lazy_1)
    assert(str(lazy_2).__eq__('Lazy[fn=<function Lazy.<lambda>.<locals>.<lambda> at 0x7f3824084158>, value=None, is_evaluated=False]'))

# Generated at 2022-06-25 23:45:55.226085
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)

    def mapper_0(arg_0: bytes) -> bytes:
        return arg_0[::-1]

    def mapper_1(arg_0: bytes) -> bytes:
        return arg_0[::-1]

    lazy_1 = lazy_0.map(mapper_0)
    assert isinstance(lazy_1, Lazy)
    assert lazy_1 == Lazy(mapper_0(bytes_0))
    assert lazy_1.get() == mapper_0(bytes_0)

    lazy_2 = lazy_1.map(mapper_1)
    assert isinstance(lazy_2, Lazy)
    assert lazy_2

# Generated at 2022-06-25 23:46:01.917713
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)

    def func_0(b):
        return Lazy(len(b))

    lazy_0 = lazy_0.bind(func_0)

    assert lazy_0.is_evaluated == False
    assert lazy_0.constructor_fn(lazy_0.value) == 6
    assert lazy_0.is_evaluated == True
    assert lazy_0.value == 6

# Generated at 2022-06-25 23:46:02.810457
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    test_case_0()



# Generated at 2022-06-25 23:46:07.355094
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    str_0 = str(bytes_0)
    lazy_1 = lazy_0.bind(lambda byte_0: Lazy(str_0))

    assert (isinstance(lazy_1, Lazy) and lazy_1.get() == str_0)


# Generated at 2022-06-25 23:46:13.277146
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(b'\xa0Q\x89F\xc9\xd3eD').get() == b'\xa0Q\x89F\xc9\xd3eD'


# Generated at 2022-06-25 23:46:16.858101
# Unit test for method get of class Lazy
def test_Lazy_get():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    # Test case of Method with args
    assert lazy_0.get() == bytes_0

# Generated at 2022-06-25 23:46:25.611222
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.lazy import Lazy
    # Define function fn
    def fn(value1, value2):
        return Lazy(value1 * value2)
    lazy_0 = Lazy(fn)
    # Define function fn2
    def fn2(value1):
        return value1
    lazy_1 = lazy_0.bind(fn2)
    # Define function fn3
    def fn3(*args):
        return
    lazy_2 = lazy_0.bind(fn3)
    assert lazy_2.constructor_fn(1, 2) == None
    assert lazy_0.constructor_fn('foo', 2) == 'foofoo'
    assert lazy_1.constructor_fn('foo', 2) == 'foofoo'


# Generated at 2022-06-25 23:46:30.676914
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy.of(bytes_0)
    assert not (lazy_0 == lazy_1)
    lazy_0._compute_value()
    lazy_1._compute_value()
    assert lazy_0 == lazy_1



# Generated at 2022-06-25 23:46:35.288466
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = lazy_0.bind(lambda lazy_0: None)
    assert lazy_1 is not None

# Generated at 2022-06-25 23:46:45.970774
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\xaa\xf6\xdb\xfd\x06\xaa\xaa\x98\x9a\x9d\x14\x01\x08\xab\xf0G\x12\x7f\x90\x0b\xe6&'
    lazy_0 = Lazy.of(bytes_0)

    assert lazy_0.bind(lambda x: Lazy(b'\xde\x94\xde6\x8c\xcc\xd0z\x9c2\xb2')).get() == b'\xde\x94\xde6\x8c\xcc\xd0z\x9c2\xb2'


# Generated at 2022-06-25 23:46:47.503832
# Unit test for method get of class Lazy
def test_Lazy_get():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)

    str_0 = lazy_0.get()

    assert bytes_0 == str_0


# Generated at 2022-06-25 23:46:48.998968
# Unit test for method map of class Lazy
def test_Lazy_map():
    test_case_0()


if __name__ == '__main__':
    test_Lazy_map()

# Generated at 2022-06-25 23:46:54.323276
# Unit test for method map of class Lazy
def test_Lazy_map():
    def mapper_0(bytes_1):
        return bytes_1.decode('utf-8')

    lazy_0 = Lazy.of(b'\xc4\xa8\xd4\xa6\xb1\x9b\xa4\x0c\x7f')
    lazy_1 = lazy_0.map(mapper_0)
    assert_equal(lazy_1.value, '\xc4\xa8\xd4\xa6\xb1\x9b\xa4\x0c\x7f'.decode('utf-8'))


# Generated at 2022-06-25 23:46:55.675401
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1



# Generated at 2022-06-25 23:47:10.233787
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Local variables
    result = None
    a = None
    b = None
    lazy_0 = None
    lazy_1 = None

    # Setup
    a = Lazy.of(1)
    b = Lazy.of((lambda x: 2 + x))

    # Test
    lazy_0 = a.ap(b)
    result = lazy_0.get()

    # Assertions
    assert(result == 3)

    # Setup
    a = Lazy.of(None)
    b = Lazy((lambda: 1))

    # Test
    lazy_1 = a.ap(b)
    result = lazy_1.get()

    # Assertions
    assert(result == 1)



# Generated at 2022-06-25 23:47:18.139723
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn_0(x0):

        def fn_1(x1):
            return Lazy.of(x1)
        return Lazy.of(x0).bind(fn_1)
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    lazy_0_ = lazy_0.bind(fn_0)
    bytes_1 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_1 = Lazy(bytes_1)
    assert lazy_0_ == lazy_1



# Generated at 2022-06-25 23:47:24.736546
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    lazy_0.bind()

    from pymonet.monad_try import Try

    def function(element):
        return Try.of(lambda *args: bytes_0)
    lazy_0 = Lazy(function)
    lazy_0.bind()
    lazy_0._compute_value()



# Generated at 2022-06-25 23:47:35.050432
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import pymonet.maybe
    import pymonet.monad_try
    import pymonet.either
    import pymonet.validation
    from pymonet.monad_state import State

    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    byte_0 = bytes_0[0]
    byte_1 = bytes_1[1]

    function_0 = Lazy.of(byte_1.__sub__)
    function_1 = function_0.ap(Lazy.of(byte_0))

    Maybe_0 = pymonet.maybe.of(byte_0)
    Maybe_1 = pymonet.maybe.just(byte_1)
    Maybe_2 = Maybe_1.ap(Maybe_0)


# Generated at 2022-06-25 23:47:39.157259
# Unit test for method map of class Lazy
def test_Lazy_map():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    assert len(bytes_0) == bytes_0.__len__()
    lazy_0 = Lazy(bytes_0)
    lazy_1 = lazy_0.map(len)
    assert len(bytes_0) == lazy_1.get()


# Generated at 2022-06-25 23:47:41.819730
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(None) == 1
    assert Lazy.of(2).get(None, None) == 2


# Generated at 2022-06-25 23:47:45.628713
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    bytes_0 = b'\x9aS\x1eg\xbdw\x94\xc3'
    bytes_2 = b'\xa0Q\x89F\xc9\xd3eD'
    str_0 = 'h'

    assert Lazy(lambda *args: bytes_0).ap(Lazy(lambda *args: bytes_2)) == Lazy.of(bytes_0)
    assert Lazy(lambda *args: str_0).ap(Lazy(lambda *args: str_0)) == Lazy.of(str_0)


# Generated at 2022-06-25 23:47:51.036105
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # orig_fn = lambda x: [1, 2, 3]
    # mapper = lambda y: [3, 2, 1]
    # lazy = Lazy([1, 2, 3])

    orig_fn = lambda x: [1, 3, 3]
    mapper = lambda y: x + y
    lazy = Lazy([1, 2, 3])

    assert lazy.bind(mapper) == Lazy(mapper)

# Generated at 2022-06-25 23:48:01.197280
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    test_cases = [
        (lambda value: Lazy(lambda: value), lambda value: Lazy(lambda: value), True),
        (lambda value: Validation.success(value), lambda value: Validation.success(value), True),
        (lambda value: Box(value), lambda value: Box(value), True),
        (lambda value: Maybe.of(value), lambda value: Maybe.of(value), False),
    ]

    for fn_0, fn_1, equal in test_cases:
        input_0 = fn_0()
        input_1 = fn_1()

        lazy_0 = Lazy(lambda: input_0)

# Generated at 2022-06-25 23:48:11.398711
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'

# Generated at 2022-06-25 23:48:25.486967
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy(lambda: 0)
    lazy_1 = lazy_0.map(lambda x: x * 2)
    assert lazy_1.get() == 0
    assert lazy_0.get() == 0
    assert lazy_1.get() == lazy_0.get()
    lazy_2 = lazy_0.map(lambda x: x + 5)
    assert lazy_2.get() == 5
    assert lazy_0.get() == 0
    assert lazy_2.get() == lazy_0.get() + 5
    try:
        lazy_3 = lazy_0.bind(lambda x: x / 0)
        assert False
    except ZeroDivisionError:
        assert True



# Generated at 2022-06-25 23:48:30.090965
# Unit test for method map of class Lazy
def test_Lazy_map():
    import unittest

    class LazyMap(unittest.TestCase):
        def test_map_0(self):
            result_0 = Lazy(bytes)
            result_1 = result_0.map(type)
            expected_result = Lazy(type)
            self.assertEqual(result_1, expected_result)

    LazyMap().test_map_0()


# Generated at 2022-06-25 23:48:36.099673
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(10).get() == 10
    assert Lazy.of('test').get() == 'test'
    assert Lazy.of(tuple([1, 2, 3])).get() == (1, 2, 3)
    assert Lazy.of(set([1, 2, 3])).get() == {1, 2, 3}
    assert Lazy.of(list([1, 2, 3])).get() == [1, 2, 3]



# Generated at 2022-06-25 23:48:44.786128
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    assert lazy_0 == lazy_0
    assert not (lazy_0 != lazy_0)
    lazy_1 = Lazy(bytes_0)
    assert lazy_0 == lazy_1
    assert not (lazy_0 != lazy_1)
    lazy_1._compute_value()
    assert lazy_0 == lazy_1
    assert not (lazy_0 != lazy_1)
    lazy_1.value = 0
    assert not (lazy_0 == lazy_1)
    assert lazy_0 != lazy_1
    lazy_1 = Lazy(bytes)
    assert not (lazy_0 == lazy_1)
    assert lazy_0 != lazy

# Generated at 2022-06-25 23:48:50.102332
# Unit test for method get of class Lazy
def test_Lazy_get():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    assert lazy_0.get() == b'\xa0Q\x89F\xc9\xd3eD'
    assert lazy_0.get() == b'\xa0Q\x89F\xc9\xd3eD'


# Generated at 2022-06-25 23:48:59.453362
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_case_0():
        def lambda_fn_4(arg_1: bytes) -> Lazy[int, str]:
            return Lazy(lambda: arg_1[0])

        bytes_0 = b'\xfa\x07\x9b\xbc\xd4\x18\x1fq\xce\xda\xb1\xdf\x18\x9f\xe5\x1a\xe6\xa5\x8b\xde\xa5\x1c\x9a\x1e\xef\xac\x81\x8b\x9e\xfc\xc6\xaa\xe9\n\xd7\xfd\xe6\x83?'
        lazy_0 = Lazy(bytes_0)

        lazy_1 = lazy_0.bind

# Generated at 2022-06-25 23:49:01.454576
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    bytes0 = b'\x00U6\xb0\x1b\x1b'
    lazy0 = Lazy(bytes0)


# Generated at 2022-06-25 23:49:11.530280
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    str_0 = '\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)
    lazy_1 = Lazy(str_0)

    assert(lazy_0 == lazy_0)

    lazy_1.is_evaluated = True
    lazy_1.value = '\xa0Q\x89F\xc9\xd3eD'

    assert(lazy_0 == lazy_1)

    assert(lazy_0 != bytes_0)
    assert(lazy_0 != str_0)
    assert(lazy_0 != lazy_0.constructor_fn)
    assert(lazy_0 != None)


# Generated at 2022-06-25 23:49:16.376644
# Unit test for method map of class Lazy
def test_Lazy_map():
    """Lazy.map"""
    def add3(x: int) -> int:
        return x + 3

    def add5(x: int) -> int:
        return x + 5

    assert Lazy.of(1).map(add3).value == 4
    assert Lazy.of(1).map(add3).map(add5).value == 9



# Generated at 2022-06-25 23:49:21.209468
# Unit test for method get of class Lazy
def test_Lazy_get():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    long_0 = 11387051806175350000
    lazy_0 = Lazy(bytes_0)
    str_0 = lazy_0.get()
    lazy_1 = Lazy(long_0)
    long_1 = lazy_1.get()
    assert bytes_0 == str_0
    assert long_0 == long_1



# Generated at 2022-06-25 23:49:42.431588
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.except_ import Error
    from pymonet.either import Right
    from pymonet.monad_try import Try

    def test_fn(value: int) -> Lazy:
        return Lazy.of(value * 2)

    assert test_fn(2).get() == 4

    box = Lazy(Box).bind(lambda box: Lazy.of(box(5)))

    assert box.get() == Box(5)

    validation = Lazy(Validation.success).bind(
        lambda v: Lazy.of(v(5))
    )

    assert validation.get() == Validation.success(5)


# Generated at 2022-06-25 23:49:54.398262
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    bytes_1 = b' \x0e\x06\x13\x01\x19\x03\x07'
    bytes_2 = b'F\x1b\x00\x0b\x07\x12\x03\x10'
    lazy_0 = Lazy.of(bytes_0)
    lazy_1 = Lazy.of(bytes_1)
    lazy_2 = Lazy.of(bytes_0)
    lazy_3 = Lazy.of(bytes_2)
    assert(lazy_0 != lazy_1)
    assert(lazy_0 == lazy_2)
    assert(lazy_0 != lazy_3)



# Generated at 2022-06-25 23:50:02.362392
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add(x):
        return x + 1

    def multiply(x):
        return 2 * x

    lazy = Lazy.of(1).bind(lambda x: Lazy.of(multiply(add(multiply(x)))))

    assert lazy.get() == 4



# Generated at 2022-06-25 23:50:03.328916
# Unit test for method map of class Lazy
def test_Lazy_map():
    pass


# Generated at 2022-06-25 23:50:13.715982
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """ Tests for method ap of class Lazy """
    # Test without parameters
    lazy_0 = Lazy(list)
    assert lazy_0.ap(Lazy.of(1)).get() == [1]

    # Test with parameters
    lazy_1 = Lazy(lambda x, y: x + y)
    assert lazy_1.ap(Lazy.of(1)).get(2) == 3

    # Test for Lazy.of(None)
    assert lazy_1.ap(Lazy.of(None)).get(2) == 2

    # Test for boxed function
    lazy_2 = Lazy(lambda x, y: x - y)
    assert lazy_2.ap(Lazy.of(lambda x: x + 1)).ap(Lazy.of(1)).get(1) == 0


# Generated at 2022-06-25 23:50:20.501694
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    bytes_0 = b'\xa0Q\x89F\xc9\xd3eD'
    lazy_0 = Lazy(bytes_0)

    assert(type(lazy_0.get()) == bytes)
    assert(lazy_0.get() == bytes_0)
    assert(type(lazy_0.to_box().unbox()) == bytes)
    assert(lazy_0.to_box().unbox() == bytes_0)
    assert(type(lazy_0.to_either().get()) == bytes)

# Generated at 2022-06-25 23:50:28.821079
# Unit test for method bind of class Lazy
def test_Lazy_bind():
	def mapper(t: bytes) -> Lazy[bytes, list]:
		return Lazy(list(t))

	def mapper_static(t: bytes, *args) -> Lazy[bytes, list]:
		return Lazy(list(t))

	def mapper_static_factory(t: bytes, *args) -> Lazy[bytes, list]:
		return Lazy.of(list(t))

	def mapper_factory(t: bytes, *args) -> Lazy[bytes, list]:
		return Lazy.of(list(t))
