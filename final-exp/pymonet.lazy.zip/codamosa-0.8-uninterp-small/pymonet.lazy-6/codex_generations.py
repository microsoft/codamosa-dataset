

# Generated at 2022-06-25 23:40:36.681010
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import SycamoreError, Try
    from pymonet.validation import Failure, Success, Validation

    int_0 = 1133
    lazy_0 = Lazy(int_0)
    assert lazy_0 == lazy_0, 'Error in method eq'

    lazy_0 = Lazy.of(int_0)
    lazy_1 = Lazy.of(int_0)
    assert lazy_0 == lazy_1, 'Error in method eq'

    lazy_0 = Lazy.of(int_0)
    lazy_1 = Lazy.of(int_0 + 1)
    assert lazy_0 != lazy_1, 'Error in method eq'

   

# Generated at 2022-06-25 23:40:45.491188
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.validation import Validation

    int_0 = 1133
    lazy_0 = Lazy(int_0)

    # True
    expected = True
    result = lazy_0 == lazy_0
    assert result == expected

    # False
    expected = False
    result = lazy_0 == Box(int_0)
    assert result == expected

    # False
    expected = False
    result = lazy_0 == Validation.success(int_0)
    assert result == expected

    # False
    expected = False
    result = lazy_0 == 5
    assert result == expected



# Generated at 2022-06-25 23:40:53.761763
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_case_1():
        int_0 = 1133
        lazy_0 = Lazy(int_0)
        lazy_1 = Lazy(lambda *args: int_0)

        assert lazy_0 == lazy_1

    def test_case_2():
        int_0 = 1133
        lazy_0 = Lazy(int_0)
        lazy_1 = Lazy(lambda *args: int_0)

        assert lazy_0 == lazy_1

    def test_case_3():
        int_0 = 1133
        lazy_0 = Lazy(int_0)
        lazy_1 = Lazy(lambda *args: int_0)

        assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:41:02.690039
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_value_0 = 123
    lazy_0 = Lazy.of(int_value_0)

    assert lazy_0.get() == int_value_0
    assert lazy_0.is_evaluated

    def fn():
        return int_value_0

    lazy_1 = Lazy(fn)

    assert lazy_1.get() == int_value_0
    assert lazy_1.is_evaluated

    int_value_1 = 321

    def fn_1():
        return int_value_1

    lazy_2 = Lazy(fn_1)

    assert lazy_2.get() != int_value_0



# Generated at 2022-06-25 23:41:11.466279
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1133
    float_0 = 1133.1133
    to_int_fn = lambda float_var: int(float_var)
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.bind(lambda int_0: Lazy(float_0))
    lazy_2 = lazy_1.bind(lambda float_0: Lazy(to_int_fn(float_0)))
    lazy_3 = lazy_1.bind(lambda float_0: Lazy(float_0))
    assert lazy_2.get() == lazy_1.get()
    assert lazy_2.get() == lazy_0.get()
    assert lazy_3.get() == lazy_1.get()
    assert lazy_2 == Lazy(lambda: 1133)
    assert lazy_3 == L

# Generated at 2022-06-25 23:41:20.457488
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Test case 1:
    # ap to Lazy with function mapped to over constructor function
    # input:
    #   - Lazy with function int_0 = 1133.
    #   - Lazy with function lambda x: int(x) / 2.
    # expected:
    #   - Lazy with function = lambda x: int(int(x) / 2)
    int_0 = 1133
    lazy_0 = Lazy.of(int_0)
    func_0 = lambda x: int(x) / 2
    lazy_1 = Lazy.of(func_0)
    assert lazy_0.ap(lazy_1) == Lazy(lambda x: int(int(x) / 2))



# Generated at 2022-06-25 23:41:27.727788
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1
    lazy_0 = Lazy(int_0)

    def fn_0(arg_0):
        assert arg_0 == int_0, 'Wrong lazy value'

        return Lazy(arg_0 * 2)

    lazy_0.bind(fn_0)

    def fn_1(arg_1):
        int_1 = arg_1 + 1
        return Lazy(int_1)

    lazy_1 = lazy_0.bind(fn_1)

    assert lazy_1.get() == 2, 'Error in chaining bind'


# Generated at 2022-06-25 23:41:35.599710
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = 1133
    lazy_0 = Lazy(lambda *args: int_0)
    lazy_1 = Lazy(lambda x, y: x * y)
    lazy_2 = Lazy(lambda x, y: x + y)
    lazy_3 = lazy_1.ap(lazy_2)
    lazy_3.constructor_fn('a', 'b')
    # assert lazy_0.get() == lazy_3.get()
    lazy_0 = Lazy(lambda x: x)
    lazy_1 = Lazy(lambda x: x)
    lazy_2 = Lazy(lambda x: x)
    lazy_3 = lazy_1.ap(lazy_2)
    # assert lazy_0.get() == lazy_3.get()

# Generated at 2022-06-25 23:41:39.946281
# Unit test for method get of class Lazy
def test_Lazy_get():
    import unittest

    class TestLazyGet(unittest.TestCase):
        def test_Lazy_get_0(self):
            def add(a, b):
                return a+b

            lazy = Lazy(add)
            self.assertEqual(lazy.get(3,3), 6)

    unittest.main()


# Generated at 2022-06-25 23:41:49.335361
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    lazy_0 = Lazy(lambda x: x)
    assert lazy_0 == lazy_0

    lazy_1 = Lazy(lambda x: x)
    assert lazy_0 == lazy_1

    lazy_0._compute_value(5)
    assert lazy_0 == lazy_0
    lazy_1._compute_value(5)
    assert lazy_0 == lazy_1

    lazy_0 = Lazy(Try.of(lambda x: x))
    lazy_1 = Lazy(Try.of(lambda x: x))
    assert lazy_0 == lazy_1
    lazy_0._compute_value(5)
    lazy_1._compute_value(5)
    assert lazy_0 == lazy_1



# Generated at 2022-06-25 23:41:54.997074
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet import Lazy

    lazy_0 = Lazy(12)
    lazy_1 = Lazy(12)
    lazy_2 = Lazy(lambda: 12)

    assert lazy_0 == lazy_1
    assert lazy_1 != lazy_2
    assert lazy_1.__eq__(15) is False


# Generated at 2022-06-25 23:41:59.463624
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    assert Lazy.of(0).bind(lambda _: Lazy.of(1)).get() == 1

    assert Lazy.of(0).bind(lambda _: Lazy.of(0)).bind(lambda i: Lazy.of(i + 1)).get() == 1

    lazy_0 = Lazy.of(0)
    lazy_1 = Lazy.of(1)
    assert lazy_0.bind(lambda _: lazy_1).get() == 1



# Generated at 2022-06-25 23:42:05.278124
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1133
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.bind(lambda lazy_0: Lazy(lazy_0 + 1000))

    assert(lazy_1.get() == 2133)



# Generated at 2022-06-25 23:42:09.333845
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 1133
    lazy_0 = Lazy.of(int_0)

    def f_0(v):
        return v * 2

    lazy_1 = lazy_0.map(f_0)
    assert lazy_1.get() == int_0 * 2



# Generated at 2022-06-25 23:42:14.893578
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1133
    lazy_0 = Lazy.of(int_0)
    lazy_1 = lazy_0.bind(lambda t: Lazy.of(str(t)))
    assert lazy_0.is_evaluated == False
    assert lazy_1.is_evaluated == False
    assert lazy_1.get() == str(1133)



# Generated at 2022-06-25 23:42:18.272328
# Unit test for method get of class Lazy
def test_Lazy_get():
    def int_0():
        return 1133

    lazy_0 = Lazy(int_0)

    assert lazy_0.get() == 1133



# Generated at 2022-06-25 23:42:29.722920
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # test case with function returning int
    int_0 = 1133
    lazy_0 = Lazy(int_0)

    lazy_1 = lazy_0.bind(lambda param_0: Lazy(param_0 + 2))

    assert lazy_1.get() == 1135

    # test case with function returning Lazy
    lazy_2 = lazy_0.bind(lambda param_0: Lazy(lambda : param_0 + 2))

    assert lazy_2.get() == 1135

    # test case with function returning Lazy with method call
    def get_lazy(param_0):
        def get_value():
            return param_0.get() + 2

        return Lazy(get_value)

    lazy_3 = lazy_0.bind(get_lazy)
    assert lazy_3.get() == 1135

# Generated at 2022-06-25 23:42:36.487816
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    # Test 0: Try to use ap method when Lazy contains empty Option
    lazy_0 = Lazy.of(Maybe.empty())
    lazy_1 = lazy_0.ap(Maybe.just(lambda x: Maybe.just(x ** 2)))
    exhaust(lazy_1)

    # Test 1: Try to use ap method when Lazy contains Option with present value
    lazy_0 = Lazy.of(Maybe.just(23))
    lazy_1 = lazy_0.ap(Maybe.just(lambda x: Maybe.just(x ** 2)))
    exhaust(lazy_1)


# Generated at 2022-06-25 23:42:40.352634
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # test case 0:
    int_0 = 1133
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(int_0)
    lazy_2 = Lazy(1134)
    lazy_3 = Lazy(1133)

    assert lazy_0 == lazy_0
    assert lazy_0 == lazy_1
    assert lazy_0 != lazy_2
    assert lazy_0 == lazy_3


# Generated at 2022-06-25 23:42:47.793085
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    def double(i):
        return Lazy(i * 2)

    def add(i, j, k):
        return Lazy(i + j + k)

    # int_0 = 1133
    lazy_0 = Lazy(1133)
    lazy_1 = lazy_0.bind(double)
    lazy_2 = lazy_1.bind(lambda i: double(i))
    lazy_3 = lazy_2.bind(lambda i: add(i, i, i))
    assert lazy_3.get() == (1133 * 2 ** 3) + (1133 * 2 ** 3) + (1133 * 2 ** 3)


# Generated at 2022-06-25 23:42:57.855230
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 1133
    is_constructor_called = False

    def constructor():
        nonlocal is_constructor_called
        is_constructor_called = True
        return int_0
    lazy_0 = Lazy(constructor)
    lazy_1 = lazy_0.map(lambda x: x + 1)
    assert not is_constructor_called
    assert lazy_0.get() == int_0
    assert is_constructor_called
    assert not lazy_0.is_evaluated
    assert lazy_1.get() == int_0 + 1
    assert lazy_1.is_evaluated



# Generated at 2022-06-25 23:43:01.409596
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = 1133
    # Constructor function x -> x*x
    square_fn = lambda x: x*x

    # Lazy with constructor function x -> x*x
    lazy_0 = Lazy(square_fn)

    assert lazy_0.get(int_0) == square_fn(int_0)


# Generated at 2022-06-25 23:43:05.824060
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def fn(a):
        return a + 1

    lazy = Lazy.of(fn).ap(Lazy.of(12))
    assert isinstance(lazy, Lazy)
    assert lazy.constructor_fn(None) == 13


# Generated at 2022-06-25 23:43:14.470401
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    int_0 = 1133
    maybe_0 = Maybe(int_0)
    maybe_1 = Maybe(lambda x: x * 2)
    maybe_2 = maybe_1.ap(maybe_0)

    box_0 = Box(int_0)
    box_1 = Box(lambda x: x * 2)
    box_2 = box_1.ap(box_0)

    lazy_0 = Lazy.of(int_0)
    lazy_1 = Lazy.of(lambda x: x * 2)
    lazy_2 = lazy_1.ap(lazy_0)

    assert lazy_2 == box_2 == maybe_2

# Generated at 2022-06-25 23:43:23.026474
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 1133
    int_1 = 1222
    lazy_int_0 = Lazy(lambda: int_0)
    lazy_int_1 = Lazy(lambda: int_1)
    lazy_int_2 = lazy_int_0.map(lambda x: x+1)
    assert lazy_int_2.get() == int_0 + 1

    lazy_int_3 = lazy_int_1.map(lambda x: x+1)
    assert lazy_int_3.get() == int_1 + 1

    assert lazy_int_0.map(lambda x: x+1) == lazy_int_0.map(lambda x: x+1)

    lazy_int_4 = Lazy(lambda: int_0).map(lambda x: int_1)
    assert lazy_int_4.get

# Generated at 2022-06-25 23:43:34.473153
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    assert Lazy.of(2).map(lambda x: x + 3).get() == 5
    assert Lazy.of(xrange(10)).map(lambda x: x[3]).get() == 3
    assert Lazy.of('Hello, world!').map(lambda x: len(x)).get() == 13
    assert Lazy.of(lambda *args: args[0] + 13).map(lambda x: x(17)).get() == 30
    assert Lazy.of(2).map(lambda x: x + 3).map(lambda x: x * 2).get() == 10
    assert Lazy.of(2).map(lambda x: Maybe.just(x + 3)).get().get() == 5

# Generated at 2022-06-25 23:43:39.609062
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test for method get of class Lazy.

    For example:
        >>> int_0 = 1133
        >>>
        >>> lazy_0 = Lazy.of(int_0)
        >>> lazy_0.get()
        1133

    """

    int_0 = 1133

    lazy_0 = Lazy.of(int_0)
    print(lazy_0.get())


# Generated at 2022-06-25 23:43:41.886577
# Unit test for method get of class Lazy
def test_Lazy_get():
    test_case_0()

    assert (Lazy.of(9).get()) == 9
    assert (Lazy.of(43).get()) == 43



# Generated at 2022-06-25 23:43:44.985979
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_a = 53
    int_b = 78

    add = Lazy.of(int_a).bind(lambda x: Lazy.of(x + int_b))
    assert add == Lazy(lambda *args: 53).bind(lambda x: Lazy.of(x + 78))


# Generated at 2022-06-25 23:43:55.123724
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # check equality of Lazy with constructor_fn returning non-type-specific value

    int_0 = 1133
    def constructor_fn_0(argument_0):
        return int_0
    lazy_0 = Lazy(constructor_fn_0)
    assert lazy_0 == lazy_0
    assert lazy_0.is_evaluated == False
    assert lazy_0.constructor_fn == constructor_fn_0
    assert lazy_0.value == None
    assert lazy_0.get() == int_0
    assert lazy_0.is_evaluated == True
    assert lazy_0.value == int_0
    assert lazy_0.constructor_fn == constructor_fn_0
    lazy_1 = Lazy(constructor_fn_0)
    assert lazy_1 == lazy_1

# Generated at 2022-06-25 23:43:58.684206
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    pass

# Generated at 2022-06-25 23:44:02.079043
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    f = lambda x: Lazy.of(str(x))
    x = Lazy.of(int_0).bind(f)

    assert x.get() == str(int_0) and isinstance(x, Lazy)


# Generated at 2022-06-25 23:44:03.775355
# Unit test for method get of class Lazy
def test_Lazy_get():
    expected = 1133
    lazy = Lazy.of(expected)
    assert lazy.get() == expected


# Generated at 2022-06-25 23:44:07.367919
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def fn(x):
        return x + 1

    lazy_1 = Lazy.of(fn)
    lazy_2 = Lazy.of(1133)

    lazy_3 = lazy_1.ap(lazy_2)

    assert lazy_3.get() == 1134



# Generated at 2022-06-25 23:44:10.829792
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Arrange
    def mapping_fn(x):
        return x * x

    actual_lazy = Lazy.of(3)
    expected_lazy = Lazy.of(9)

    # Act
    actual_result = actual_lazy.map(mapping_fn)

    # Assert
    assert expected_lazy == actual_result


# Generated at 2022-06-25 23:44:17.409074
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Scenario:
    # Given:
    # Lazy with function
    fn = lambda x: x + 5
    L = Lazy(fn)

    # When:
    # calling bind method with function returning Lazy(x -> x + 10)
    L2 = L.bind(lambda x: Lazy(lambda *args: x + 10))

    # Then:
    # result of calling bind method should be Lazy instance with constructor_fn returning x + 10 + 5
    assert L2.get() == 20



# Generated at 2022-06-25 23:44:27.485862
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.validation import Validation, Failure
    from pymonet.monad_try import Try
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.monad_list import List
    from pymonet.monad_dict import Dict

    def always_success_fn(value):
        return Lazy(lambda: value)

    def always_fail_fn(value):
        return Lazy(lambda: Failure(value))

    def always_throw_fn(value):
        raise Exception('Exception...')

    def add_one(value):
        return Lazy(lambda: value + 1)

    def sub_one(value):
        return Lazy(lambda: value - 1)


# Generated at 2022-06-25 23:44:33.980695
# Unit test for method bind of class Lazy

# Generated at 2022-06-25 23:44:37.314472
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def get_number():
        return 1133

    def fn(int_0):
        return Lazy.of(int_0 * 100)

    lazy = Lazy.of(get_number).bind(fn)

    assert lazy.get() == 113300



# Generated at 2022-06-25 23:44:42.764145
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def add_1_to_int(x: int) -> int:
        return x + 1

    test_Lazy_0 = Lazy(lambda: add_1_to_int(1))
    test_Lazy_1 = Lazy(lambda: add_1_to_int(1))

    assert test_Lazy_0 == test_Lazy_1


# Generated at 2022-06-25 23:44:55.129209
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor_base import base_functor_test
    from pymonet.monad_maybe import Maybe

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()

    maybe_1 = Maybe.just(1)
    base_functor_test(Lazy.of(1133), Lazy.of(1), Lazy.of(1133), 1133)

    lazy = Lazy(lambda x: x + 1).bind(lambda x: Lazy(lambda: x))
    assert lazy == Lazy(lambda x: x)

    lazy_0 = Lazy(lambda x: x + 1).bind(lambda x: Lazy(lambda: x))

# Generated at 2022-06-25 23:45:03.436780
# Unit test for method map of class Lazy
def test_Lazy_map():

    #
    # Test of map method
    #
    lazy_of_int_0 = Lazy.of(11)

    lazy_of_float_0 = lazy_of_int_0.map(lambda item_0: float(item_0))
    assert lazy_of_float_0.get() == float(lazy_of_int_0.get())

    lazy_of_string_0 = lazy_of_int_0.map(lambda item_0: str(item_0))
    assert lazy_of_string_0.get() == str(lazy_of_int_0.get())

    #
    # Test of map method with monad as input
    #
    def return_maybe_0(item_0: int) -> Maybe[int]:
        from pymonet.maybe import Maybe

        return Maybe.just

# Generated at 2022-06-25 23:45:13.473392
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_case_0():
        int_0 = 1133
        lazy_0 = Lazy(lambda *args: int_0)
        def fn_0(arg_0):
            return Lazy(lambda *args: arg_0)
        lazy_1 = lazy_0.bind(fn_0)
        lazy_2 = lazy_1.bind(fn_0)
        assert lazy_0 == lazy_1
        assert lazy_1 == lazy_2
        assert lazy_0.get() == lazy_1.get()
        assert lazy_1.get() == lazy_2.get()

    def test_case_1():
        int_0 = 1133
        int_1 = -5
        lazy_0 = Lazy(lambda *args: int_0)
        def fn_0(arg_0):
            return L

# Generated at 2022-06-25 23:45:15.725703
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1133
    lazy_0 = Lazy.of(int_0)
    lazy_1 = lazy_0.bind(lambda element_0: Lazy.of(element_0))
    lazy_2 = lazy_1.bind(lambda element_1: Lazy.of(element_1))
    int_1 = lazy_2.get()
    assert int_0 == int_1


# Generated at 2022-06-25 23:45:16.879912
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_0 = Lazy.of(10)
    assert lazy_0.get() == 10

test_Lazy_get()


# Generated at 2022-06-25 23:45:19.997395
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy(10)
    def fn(x):
        def constructor_fn(y):
            return x + y
        return Lazy(lambda: constructor_fn(x))
    lazy_1 = lazy_0.bind(fn)
    assert lazy_1.get() == 20



# Generated at 2022-06-25 23:45:29.964994
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Lazy[int]
    lazy_0 = Lazy(lambda: 1133)
    # Lazy[Function(int) -> str]
    lazy_1 = Lazy(lambda: lambda value: "str " + str(value))
    result = lazy_0.ap(lazy_1)
    assert isinstance(result, Lazy)
    assert result.get() == 'str 1133'

    # Lazy[int]
    lazy_0 = Lazy(lambda: 1133)
    # Lazy[Function(int) -> str]
    lazy_1 = Lazy(None)
    result = lazy_0.ap(lazy_1)
    assert isinstance(result, Lazy)
    assert result.get() == 1133

    # Lazy[int]
    lazy_0 = Lazy(None)
    #

# Generated at 2022-06-25 23:45:39.174612
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 1133
    lazy_0 = Lazy(int_0)
    assert lazy_0.map(lambda x: x).get() == int_0
    assert lazy_0.map(lambda x: x).to_box().unwrap() == int_0
    assert lazy_0.map(lambda x: x).to_either().unwrap() == int_0
    assert lazy_0.map(lambda x: x).to_maybe().unwrap() == int_0
    assert lazy_0.map(lambda x: x).to_try().unwrap() == int_0
    assert lazy_0.map(lambda x: x).to_validation().unwrap() == int_0


# Generated at 2022-06-25 23:45:46.370343
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Lazy[A].bind(fn) #=> Lazy[B]

    Takes a function and evaluates the Lazy, applying the function to the
    result of the constructor function.

    >>> Lazy(lambda: 'foo').bind(lambda x: Lazy(lambda: x + 'bar')).get()
    'foobar'

    """

    fn = lambda x: Lazy(lambda: x + 'bar')
    expected = 'foobar'
    actual = Lazy(lambda: 'foo').bind(fn).get()

    assert expected == actual, 'Expected {} != Actual {}'.format(expected, actual)



# Generated at 2022-06-25 23:45:50.222439
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    assert Lazy.of(1).bind(add_one) == Lazy(add_one)



# Generated at 2022-06-25 23:46:01.750519
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy.of(1133)
    lazy_1 = Lazy.of(1133)

    def assert_lazy(lazy):
        return Lazy.of(lazy)

    assert lazy_0.bind(assert_lazy) == lazy_1

    def bind_add(value):
        return Lazy.of(value + 1)

    assert lazy_0.bind(bind_add).get() == 1134


# Generated at 2022-06-25 23:46:03.335355
# Unit test for method get of class Lazy
def test_Lazy_get():
    representation = Lazy.of(1)
    assert representation.get() == 1



# Generated at 2022-06-25 23:46:06.706351
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) == Lazy(lambda: 1)
    assert Lazy.of(1) == Lazy.of(11)
    assert Lazy.of(1) == Lazy.of(1)


# Generated at 2022-06-25 23:46:11.547976
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1133
    lazy_0 = Lazy.of(int_0)
    lazy_1 = lazy_0.bind(lambda function_result: Lazy.of(function_result))
    int_1 = lazy_1.get()
    assert int_0 == int_1

    int_0 = 1133
    lazy_0 = Lazy(lambda *args: int_0)
    lazy_1 = lazy_0.bind(lambda function_result: Lazy.of(function_result))
    int_1 = lazy_1.get()
    assert int_0 == int_1

    int_0 = 1133
    lazy_0 = Lazy.of(int_0)
    lazy_1 = lazy_0.bind(lambda function_result: Lazy(lambda *args: function_result))
    int_1

# Generated at 2022-06-25 23:46:15.581744
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 1133
    lazy_0 = Lazy(int_0)
    assert lazy_0 == lazy_0
    int_1 = 4123
    lazy_1 = Lazy(int_1)
    assert lazy_0 != lazy_1


# Generated at 2022-06-25 23:46:23.565089
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1234
    lazy_0 = Lazy(int_0)
    assert lazy_0.get() == 1234
    lazy_1 = lazy_0.bind(lambda x: Lazy(x + 1))
    assert lazy_1.get() == 1235
    lazy_const_0 = Lazy(lambda x: x + 1)
    lazy_const_1 = Lazy(lambda y: y + 1)
    lazy_2 = lazy_1.bind(lambda x: lazy_const_1)
    assert lazy_2.get() == 1236
    lazy_3 = lazy_2.bind(lambda x: lazy_const_0)
    assert lazy_3.get() == 1237


# Generated at 2022-06-25 23:46:28.698375
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(1).ap(Lazy.of(lambda x: x + 1)) == Lazy.of(2)
    assert Lazy.of(2).ap(Lazy.of(lambda x: x * x)) == Lazy.of(4)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)) == Lazy.of(3)


# Generated at 2022-06-25 23:46:34.141061
# Unit test for method map of class Lazy
def test_Lazy_map():
    list_0  = [1, 2, 3, 4, 5]
    list_1  = [2, 3, 4, 5, 6]
    lazy_0  = Lazy(list_0)
    lazy_1  = lazy_0.map(lambda x: x + 1)

    assert list_1 == lazy_1.get()


# Generated at 2022-06-25 23:46:40.903034
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # preparyng data
    int_0 = 1133
    int_1 = 2233
    arg_0 = Lazy(int_0)
    arg_1 = Lazy(lambda int_0_value: int_0_value * int_1)
    expected = Lazy(lambda int_0_value: int_0_value * int_1)

    # calling function
    actual = arg_0.ap(arg_1)

    # asserting
    assert expected == actual


# Generated at 2022-06-25 23:46:43.368335
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = 1133
    lazy_0 = Lazy(int_0)
    assert lazy_0.get() == 1133

# Generated at 2022-06-25 23:46:50.614078
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_0 = Lazy.of(1133)
    assert lazy_0.get() == 1133



# Generated at 2022-06-25 23:46:57.393894
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1133
    lazy_0 = Lazy(int_0)
    def fn_0(value_0):
        def method_0(value_1):
            return value_0 + value_1
        lazy_1 = Lazy(method_0)
        return lazy_1
    lazy_2 = lazy_0.bind(fn_0)
    assert lazy_2 == Lazy(lambda : int_0 + int_0)


# Generated at 2022-06-25 23:47:00.704088
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 7

    lazy_0 = Lazy(fn)

    assert lazy_0.get(0) == 7
    assert lazy_0.get(1) == 8
    assert lazy_0.get(6479) == 6486


# Generated at 2022-06-25 23:47:05.499811
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 1133
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0

    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:47:13.115754
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1133
    lazy_0 = Lazy(int_0)
    assert lazy_0.bind(lambda x: Lazy(x + 1)).get() == 1134
    assert lazy_0.bind(lambda x: Lazy(x + 1)).get() == 1134
    assert lazy_0.bind(lambda x: Lazy(x + 1)).get() == 1134
    assert lazy_0.bind(lambda x: Lazy(x + 1)).get() == 1134
    assert lazy_0.bind(lambda x: Lazy(x + 1)).get() == 1134
    assert lazy_0.bind(lambda x: Lazy(x + 1)).get() == 1134
    assert lazy_0.bind(lambda x: Lazy(x + 1)).get() == 1134

# Generated at 2022-06-25 23:47:16.473155
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1133
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.bind(lambda value: Lazy(value + 1))
    assert lazy_1.get() == 1134


# Generated at 2022-06-25 23:47:20.733571
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1133
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.bind(lambda int_1: Lazy(int_1 + 1))
    expected_lazy = lazy_0.map(lambda int_2: int_2 + 1)
    assert lazy_1 == expected_lazy


# Generated at 2022-06-25 23:47:22.574970
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1


# Generated at 2022-06-25 23:47:26.818226
# Unit test for method get of class Lazy
def test_Lazy_get():
    string_0 = 'Lazy[fn=1133, value=None, is_evaluated=False]'
    lazy_0 = Lazy.of(1133)
    string_1 = str(lazy_0)
    assert string_1 == string_0


# Generated at 2022-06-25 23:47:36.479043
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = 1133
    lazy_0 = Lazy(int_0)

    lazy_1 = Lazy.of(lambda n: n + 1)
    lazy_2 = Lazy.of(lambda n: n + 2)

    lazy_3 = lazy_1.ap(lazy_0)
    lazy_4 = lazy_2.ap(lazy_0)

    assert lazy_3.get() == lazy_1.constructor_fn(lazy_0.constructor_fn())
    assert lazy_4.get() == lazy_2.constructor_fn(lazy_0.constructor_fn())

    lazy_5 = lazy_1.ap(lazy_2)
    assert lazy_5.get() == lazy_1.constructor_fn(lazy_2.constructor_fn())

    lazy_6

# Generated at 2022-06-25 23:47:58.026624
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = 1133
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy.of(2)
    assert(lazy_0.ap(lazy_1).get() == 2 * int_0)
    int_0 = 5
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy.of(5)
    assert(lazy_0.ap(lazy_1).get() == 5 * int_0)
    str_0 = '1133'
    lazy_0 = Lazy(str_0)
    lazy_1 = Lazy.of(5)
    assert(lazy_0.ap(lazy_1).get() == 5 * str_0)


# Generated at 2022-06-25 23:48:03.524460
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1133
    lazy_0 = Lazy.of(int_0)
    lazy_1 = lazy_0.bind(lambda x: Lazy.of(x))
    assert lazy_1.get() == lazy_0.get()
    assert lazy_1.is_evaluated



# Generated at 2022-06-25 23:48:09.584781
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy(lambda x: x)
    assert lazy_0 == lazy_0
    assert lazy_0 != Lazy(lambda x: x)
    assert lazy_0 != Lazy(lambda x: x).bind(lambda x: Lazy(x))
    assert lazy_0 != Lazy(lambda x: x + 1)
    assert lazy_0 != Lazy(lambda x: x * 2)



# Generated at 2022-06-25 23:48:19.914606
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    #  test_case_0
    int_0 = 1133
    function_0 = lambda int_0: Lazy(int_0)
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.bind(function_0)
    assert 1133 == lazy_1.get()
    #  test_case_1
    int_1 = 15
    float_0 = float(int_1)
    function_1 = lambda float_0: Lazy(float_0)
    lazy_2 = Lazy(float_0)
    lazy_3 = lazy_2.bind(function_1)
    assert 15.0 == lazy_3.get()
    #  test_case_2
    str_0 = '0'
    int_2 = int(str_0)

# Generated at 2022-06-25 23:48:28.343591
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_exception import Exception, ExceptionMonad
    from pymonet.monad_maybe import Maybe, MaybeMonad
    from pymonet.monad_try import Try, TryMonad

    # Test Lazy[Int] -> Lazy[Str]
    test_value = 333
    test_value_str = "test_Lazy_map-" + str(test_value)
    lazy = Lazy(test_value)
    lazy_str = Lazy(test_value_str)

    def mapper(test_value):
        return test_value_str

    def mapper_multi(test_value):
        return (test_value_str, test_value_str)

    assert lazy.map(mapper) == lazy_str
    assert lazy.map(mapper).map(lambda _: 1)

# Generated at 2022-06-25 23:48:37.579747
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    func_a = lambda: 's'

    lazy_1 = Lazy(func_a)  # contructed but not evaluated
    lazy_2 = Lazy(func_a)  # contructed but not evaluated
    lazy_3 = Lazy(func_a)  # contructed but not evaluated
    lazy_4 = Lazy(func_a)  # contructed but not evaluated

    assert lazy_1 == lazy_2
    assert lazy_1 == lazy_3
    assert lazy_1 == lazy_4

    str_a = lazy_1.get()  # evaluated __call__

    lazy_1 = Lazy(func_a)  # contructed and evaluated
    lazy_2 = Lazy(func_a)  # contructed and evaluated
    lazy_3 = Lazy(func_a)  # contruct

# Generated at 2022-06-25 23:48:46.730875
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """

    :return:
    """
    def fn_a(x):
        return x

    def fn_b(x):
        return Lazy(x + 2)

    returned_value_0 = Lazy.of(2).bind(fn_a).get()
    is_returned_value_0_ok = returned_value_0 == 2

    returned_value_1 = Lazy.of(7).bind(fn_b).get()
    is_returned_value_1_ok = returned_value_1 == 9

    is_test_Lazy_bind_ok = is_returned_value_0_ok and is_returned_value_1_ok

    if not is_test_Lazy_bind_ok:
        raise AssertionError("TEST FAILED: Lazy.bind")

#

# Generated at 2022-06-25 23:48:49.987316
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(5).ap(Lazy.of(lambda x: 2*x)).get() == 10
    assert Lazy.of(5).ap(Lazy.of(None)).get() == None


# Generated at 2022-06-25 23:48:59.344082
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 6234

    string_0 = "Cześć"
    list_0 = [1, 2, 3, 4]
    map_0 = {0: "A", 1: "B", 2: "C"}

    def fn_0(arg_0):
        return arg_0 + 1

    def fn_1(arg_0):
        return lazy_0.map(fn_0)

    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(string_0)
    lazy_2 = Lazy(list_0)
    lazy_3 = Lazy(map_0)

    lazy_int_0 = Lazy.of(67)
    lazy_string_0 = Lazy.of("Test")
    lazy_float_0 = Lazy.of(0.1)

# Generated at 2022-06-25 23:49:02.646539
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 1133
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.map(lambda x: x + int_0)

# Generated at 2022-06-25 23:49:34.971719
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    def add_int(a): return Lazy(a + 1)

    # Setup
    lazy_0 = Lazy(0)
    lazy_1 = Lazy(1)

    # Assertion
    assert lazy_0.ap(lazy_1) == Lazy(1)
    assert lazy_0.ap(Lazy.of(5)) == Lazy(5)
    assert lazy_1.ap(Lazy.of(5)) == Lazy(6)
    assert lazy_0.ap(add_int(1)).get() == 1
    assert lazy_0.ap(add_int(5)).get() == 5
    assert Lazy.of(5).ap(add_int(5)).get() == 10



# Generated at 2022-06-25 23:49:42.904658
# Unit test for method map of class Lazy
def test_Lazy_map():
    class Lazy_map_0(Generic[T, U]):
        def method(self, _input: Lazy[T, U]) -> Lazy[T, U]:
            int_0 = 1133
            lazy_0 = Lazy(int_0)
            int_1 = 924
            lazy_1 = Lazy(int_1)
            bool_0 = True
            lazy_2 = Lazy(bool_0)

            return lazy_0.map(lambda int_2: int_2 + int_1).map(lambda int_3: int_3 + int_2) \
                   .map(lambda int_4: int_4 + int_3).map(lambda bool_1: bool_1 or bool_0)



# Generated at 2022-06-25 23:49:48.615702
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_2(x):
        return x + 2

    lazy_0 = Lazy(1)
    lazy_1 = lazy_0.map(add_2)

    assert lazy_1 == Lazy(lambda: 3)


# Generated at 2022-06-25 23:49:56.442190
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = 1133
    lazy_0 = Lazy(int_0)

    int_1 = 2
    lazy_1 = Lazy.of(int_1)

    lazy_2 = lazy_0.ap(lazy_1)

    assert lazy_2.get() == int_1

    def lazy_3_constructor_fn(*_):
        return  lambda param_1: Lazy.of(param_1)

    lazy_3 = Lazy(lazy_3_constructor_fn)

    lazy_4 = lazy_0.ap(lazy_3)

    assert lazy_4.is_evaluated is False
    assert lazy_4.get() == int_0


# Generated at 2022-06-25 23:50:03.279949
# Unit test for method get of class Lazy
def test_Lazy_get():
    # function () -> int
    int_0 = Lazy(lambda: 1)
    # function () -> int
    int_1 = Lazy(lambda: 2)

    # int
    assert int_0.get() == 1
    # int
    assert int_1.get() == 2


# Generated at 2022-06-25 23:50:05.848061
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Given
    int_0 = 1133

    # When
    lazy_0 = Lazy(int_0)

    # Then
    assert lazy_0.get() == 1133



# Generated at 2022-06-25 23:50:08.744364
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 1133
    int_1 = 1133
    lazy_0 = Lazy(int_0)
    lazy_1 = Lazy(int_1)
    lazy_2 = Lazy(int_0)
    assert (lazy_0.__eq__(lazy_1) is False)
    assert (lazy_0.__eq__(lazy_2) is True)


# Generated at 2022-06-25 23:50:18.630691
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.validation import Validation

    def fn_0(some_value: int) -> Box[int]:
        return Box(some_value + 41)

    lazy_0 = Lazy(fn_0)
    box_0 = lazy_0.bind(fn_0)
    if box_0 != Box(82):
        raise Exception('method bind of class Lazy does not work properly')

    def fn_1(some_value: int) -> Maybe[int]:
        return Maybe.just(some_value + 41)

    lazy_1 = Lazy(fn_1)
    maybe_0 = lazy_1.bind(fn_1)

# Generated at 2022-06-25 23:50:24.426334
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Prepare
    int_0 = 1133
    lazy_0 = Lazy(lambda: int_0)
    int_1 = 33
    lazy_1 = Lazy(lambda: int_1)
    int_2 = int_0 + int_1

    # Execute
    lazy_3 = lazy_0.ap(lazy_1)

    # Assert
    assert lazy_3.get() == int_2

