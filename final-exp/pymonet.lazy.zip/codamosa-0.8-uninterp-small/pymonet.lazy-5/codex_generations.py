

# Generated at 2022-06-25 23:40:29.031803
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right

    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_box().get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_maybe().get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_either().get() == 2

    # assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_try(Exception("I'm Exception")).get() == 2
    # assert Lazy.of(1).bind(lambda x:

# Generated at 2022-06-25 23:40:29.743064
# Unit test for method get of class Lazy
def test_Lazy_get():
    pass

# Generated at 2022-06-25 23:40:40.417148
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test case for method __eq__ of class Lazy. Tests it on the following cases:
     - Both Lazy are evaluates and contain the same value and constructor functions
     - One of Lazy is evaluated, but another is not and contains the same value and constructor functions
     - Both Lazy are unevaluated and contains the same value and constructor functions
     - Lazy contains not the same value or constructor function
     - Lazy is compared with another object
     - Compare Lazy with None
     - Compare Lazy with the same object
     - Compare Lazy to itself
    """
    from pymonet.lazy import Lazy
    import builtins as module_0
    module_0.object()
    def object_1():
        return module_0.object()
    def object_2():
        return module_0.object()
    lazy_0 = L

# Generated at 2022-06-25 23:40:44.724057
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    
    # object_0 is an instance of Lazy
    object_0 = Lazy(object)
    # object_1 is an instance of Lazy
    object_1 = Lazy(object)

    # object_0 is equal to object_1
    assert object_0 == object_1


# Generated at 2022-06-25 23:40:51.550854
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.lazy import Lazy as Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    # Test with function returning random value
    def random_value(arg_0):
        object_0 = module_0.object()
        object_1 = module_0.object()
        object_2 = module_0.object()
        object_3 = module_0.object()
        object_4 = module_0.object()
        object_5 = module_0.object()
        object_6 = module_0.object()
        object_7 = module_0.object()
        object_8 = module_0.object()
       

# Generated at 2022-06-25 23:40:55.449700
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    try:
        object_0 = module_0.object()
        lazy_0 = Lazy(object_0)
        lazy_1 = Lazy(object_0)
        var_0 = lazy_0 == lazy_1
    except Exception:
        var_0 = False
        return var_0
    else:
        return True


# Generated at 2022-06-25 23:40:59.338505
# Unit test for method map of class Lazy
def test_Lazy_map():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    func_0 = module_0.function()
    var_0 = lazy_0.map(func_0)


# Generated at 2022-06-25 23:41:08.935071
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    var_0 = module_0.bool()

    object_1 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy(object_0)
    var_1 = object_1.__eq__(lazy_0)
    var_2 = lazy_1.__eq__(object_1)
    var_3 = lazy_0.__eq__(lazy_1)
    var_4 = Lazy(module_0.id).__eq__(lazy_0)
    var_5 = lazy_0.__eq__(Lazy(module_0.id))


# Generated at 2022-06-25 23:41:10.162573
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    assert lazy_0 == lazy_0


# Generated at 2022-06-25 23:41:19.382813
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()

    lazy_0 = Lazy(object_0)

    object_1 = module_0.object()
    lazy_1 = Lazy(object_1)

    object_2 = module_0.object()
    lazy_2 = Lazy(object_2)
    lazy_2._compute_value()

    object_3 = module_0.object()
    assert not lazy_0 == object_3

    lazy_3 = Lazy(object_3)
    assert not lazy_0 == lazy_3

    lazy_4 = Lazy(object_1)
    assert not lazy_0 == lazy_4

    lazy_4._compute_value()
    lazy_4.value = lazy_0.constructor_fn()
    assert not lazy_0 == lazy_4


# Generated at 2022-06-25 23:41:22.528677
# Unit test for method get of class Lazy
def test_Lazy_get():
    # TODO
    assert True, "TODO"


# Generated at 2022-06-25 23:41:29.350975
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    list_0 = module_0.list([1, 2, 3])
    lazy_0 = Lazy(list_0)
    def lambda_0(arg_0):
        return module_0.set(arg_0)

    lazy_1 = lazy_0.bind(lambda_0)
    var_0 = lazy_1.get()
    var_1 = isinstance(var_0, module_0.set)
    assert var_1 == True


# Generated at 2022-06-25 23:41:41.131887
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Right
    from pymonet.either import Left
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.validation import ValidationFailure
    from pymonet.box import Box

    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()
    object_5 = object()
    object_6 = object()
    object_7 = object()
    object_8 = object()
    object_9 = object()
    object_10 = object()
    object_11 = object()
    object_12 = object()
    object_13 = object()
    object_14 = object()
   

# Generated at 2022-06-25 23:41:43.037510
# Unit test for method get of class Lazy
def test_Lazy_get():
    arg_0 = module_0.object()
    lazy_0 = Lazy(arg_0)
    var_0 = lazy_0.get()


# Generated at 2022-06-25 23:41:44.713311
# Unit test for method get of class Lazy
def test_Lazy_get():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    test_case_0()


# Generated at 2022-06-25 23:41:48.027871
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    bool_0 = lazy_0.__eq__(lazy_0)
    assert bool_0


# Generated at 2022-06-25 23:41:57.648419
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    result = Lazy.of(1).bind(lambda x: Lazy.of(x + 2))
    assert result == Lazy.of(3)

    result2 = Lazy.of(1).bind(lambda x: Lazy.of(x + 2)).bind(lambda x: Lazy.of(x + 3))
    assert result2 == Lazy.of(6)

    try:
        result3 = Lazy.of(1).bind(lambda x: Lazy.of(x + 2)).bind(lambda x: Lazy.of(x + 3)).get()
        assert result3 == 6
    except:
        raise Exception('Lazy.bind fail')

    result4 = Lazy.of(1).map(lambda x: x + 2).bind(lambda x: Lazy.of(x + 3))

# Generated at 2022-06-25 23:42:08.476012
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pymonet.box
    import pymonet.either
    import pymonet.maybe
    import pymonet.option
    import pymonet.validation

    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()
    object_5 = object()
    object_6 = object()
    object_7 = object()
    object_8 = object()
    object_9 = object()
    object_10 = object()
    object_11 = object()
    object_12 = object()
    object_13 = object()
    object_14 = object()
    object_15 = object()
    object_16 = object()
    object_17 = object()
    object_18 = object()
    object_19 = object

# Generated at 2022-06-25 23:42:12.480417
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy(object)
    lazy_0._compute_value()
    lazy_1 = Lazy(object)
    lazy_1._compute_value()
    var_0 = lazy_0.__eq__(lazy_1)


# Generated at 2022-06-25 23:42:17.214343
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy.of(1)
    lazy_1 = Lazy.of(1)

    def fn_0(value):
        return Lazy.of(value)

    lazy_2 = lazy_0.bind(fn_0)
    assert lazy_1 == lazy_2

# Generated at 2022-06-25 23:42:28.659265
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pymonet.monad_try as monad_try
    class TestClass:
        def test_method(self):
            return 1

        def test_method_with_args(self, x, y):
            return x + y

    lazy_0 = Lazy(TestClass().test_method)
    var_0 = lazy_0.bind(lambda x: Lazy(TestClass().test_method_with_args))
    monad_try_0 = monad_try.Try.of(var_0.constructor_fn, 1, 2)
    assert (monad_try_0.get() == 3)



# Generated at 2022-06-25 23:42:34.913672
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # object
    object_0 = module_0.object()
    # Lazy
    lazy_0 = Lazy(object_0)
    # Lazy[A, B]
    lazy_1 = lazy_0.bind(lazy_0.constructor_fn)

    # object
    object_1 = module_0.object()
    # Lazy
    lazy_2 = Lazy(object_1)
    # Lazy[A, B]
    lazy_3 = lazy_0.bind(lazy_2.constructor_fn)


# Generated at 2022-06-25 23:42:37.025809
# Unit test for method get of class Lazy
def test_Lazy_get():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    var_0 = lazy_0.get()



# Generated at 2022-06-25 23:42:38.612486
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_0 = lazy_0.bind(object_0)


# Generated at 2022-06-25 23:42:44.025127
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy(object_0)
    lazy_1.is_evaluated = True
    lazy_1.value = lazy_0.is_evaluated
    lazy_1.constructor_fn = lazy_0.constructor_fn
    var_0 = lazy_0.__eq__(lazy_1)
    assert var_0 == True

# Generated at 2022-06-25 23:42:46.711639
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    var_0 = lazy_0.__eq__(lazy_0)


# Generated at 2022-06-25 23:42:49.345309
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    var_0 = lazy_0 == lazy_0
    assert var_0 == True


# Generated at 2022-06-25 23:42:51.968751
# Unit test for method get of class Lazy
def test_Lazy_get():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    var_0 = lazy_0.get()


# Generated at 2022-06-25 23:42:54.534480
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Unit test for method map of class Lazy
    lazy_0 = Lazy(object)
    lazy_1 = lazy_0.map()


# Generated at 2022-06-25 23:42:57.229571
# Unit test for method get of class Lazy
def test_Lazy_get():
    print('Testing get')

    test_case_0()
    print('Test case 0 OK')
test_case_1_value_0 = int()

# Generated at 2022-06-25 23:43:04.947262
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy(object_0)
    var_0 = lazy_0 == lazy_1


# Generated at 2022-06-25 23:43:10.797259
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy(object_0)
    var_0 = lazy_0 == lazy_1
    assert var_0 == False
    lazy_1.value = lazy_0.value
    lazy_1.is_evaluated = lazy_0.is_evaluated
    var_1 = lazy_0 == lazy_1
    assert var_1 == True


# Generated at 2022-06-25 23:43:20.106006
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Lazy of (lambda x: x)
    # Lazy of (lambda x: x + 1)
    # Lazy of (lambda x: x + 1)
    # Lazy of (lambda x: x + 2)
    # Lazy of (lambda x: x + 3)
    def method_0(arg_0):
        var_0 = Lazy(lambda arg_1: arg_1)
        return var_0

    def method_1(arg_0):
        var_0 = Lazy(lambda arg_1: arg_1).bind(lambda arg_1: Lazy(lambda arg_2: arg_2 + 1))
        return var_0


# Generated at 2022-06-25 23:43:22.936352
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    object_0 = 'b'
    lazy_0 = Lazy(object_0)
    object_1 = lambda a: 'a'
    lazy_1 = Lazy(object_1)

    lazy_2 = lazy_0.ap(lazy_1)


# Generated at 2022-06-25 23:43:26.915294
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    object_1 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy(object_1)
    var_0 = lazy_0.__eq__(lazy_1)

# Generated at 2022-06-25 23:43:38.054721
# Unit test for method map of class Lazy
def test_Lazy_map():
    object_0 = module_0.object()
    callable_0 = module_0.getattr(object_0, "getattr")
    int_0 = module_0.int()
    var_0 = module_0.list()
    lazy_0 = Lazy(object_0)
    lazy_1 = lazy_0.map(callable_0)
    var_1 = module_0.isinstance(lazy_1, Lazy)
    lazy_2 = lazy_0.map(int_0)
    var_2 = module_0.isinstance(lazy_2, Lazy)
    var_3 = module_0.isinstance(lazy_0, Lazy)
    lazy_3 = lazy_0.map(var_0)

# Generated at 2022-06-25 23:43:40.481896
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    var_0 = lazy_0.ap(lazy_0)


# Generated at 2022-06-25 23:43:41.582490
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    var_0 = lazy_0.bind(Box)


# Generated at 2022-06-25 23:43:48.709065
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Case 1:

    Lazy.map()
    """
    # ---Lazy---
    # str
    # eq

    # ---Lazy.map---
    # str
    # eq

    # ---Lazy---
    # str
    # eq

    # ---Lazy.map---
    # str
    # eq

    # ---Lazy---
    # str
    # eq

    # ---Lazy.map---
    # str
    # eq

    # ---Lazy---
    # str
    # eq

    # ---Lazy.map---
    # str
    # eq

    # ---Lazy---
    # str
    # eq

    # ---Lazy.map---
    # str
    # eq

    # ---Lazy---
    # str
    # eq

    # ---Lazy.

# Generated at 2022-06-25 23:44:00.102655
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad
    from pymonet.monad_maybe import Maybe

    class A(object):
        pass

    class B(object):
        pass

    class C(object):
        pass

    class FnAtoB(Applicative, Monad):
        def __init__(self, fn):
            self.fn = fn

        def __str__(self):
            return 'FnAtoB(fn={})'.format(self.fn)

        @classmethod
        def of(cls, value):
            return FnAtoB(lambda *a: value)

        def bind(self, fn):
            def binded(*a):
                return fn(self.fn(*a))

            return FnAtoB(binded)

    l

# Generated at 2022-06-25 23:44:17.586581
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    validation_0 = Validation.success(3)
    maybe_0 = Maybe.just(2)
    try_0 = Try.of((lambda x, y: x + y), 1, 2)
    either_0 = Right(4)
    box_0 = Box(5)
    lazy_0 = Lazy((lambda x: x + 1))
    lazy_1 = Lazy((lambda x: x + 2))
    lazy_2 = Lazy((lambda x: x + 3))

# Generated at 2022-06-25 23:44:21.282308
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def function_0(arg_0):
        return Lazy(arg_0)
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = lazy_0.bind(function_0)
    var_0 = lazy_1.get()


# Generated at 2022-06-25 23:44:26.753716
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy(object_0)
    assert lazy_0 == lazy_1
    object_1 = module_0.object()
    lazy_2 = Lazy(object_1)
    assert lazy_0 != lazy_2


# Generated at 2022-06-25 23:44:28.124747
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = lazy_0.bind(object_0)


# Generated at 2022-06-25 23:44:29.099344
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    pass



# Generated at 2022-06-25 23:44:33.512529
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy(object_0)
    assert lazy_0 == lazy_1
    var_0 = lazy_0.get()
    assert lazy_0 == lazy_1
    lazy_2 = Lazy(object_0)
    assert lazy_0 == lazy_2


# Generated at 2022-06-25 23:44:43.315205
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # setup
    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()

    lazy_0 = Lazy.of(object_0)

    def fn(param_0):
        return Lazy.of(object_1)

    def fn_1(param_0):
        return Lazy.of(object_2)

    def fn_2(param_0):
        return Lazy.of(param_0)

    # action / assert
    assert lazy_0.bind(fn).get() == object_1
    assert lazy_0.bind(fn_1).get() == object_2
    assert lazy_0.bind(fn_2).get() == object_0

# Generated at 2022-06-25 23:44:46.850211
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(4).map(lambda a: a + 1).get() == 5
    assert Lazy.of(4).map(lambda a: a * 2).get() == 8



# Generated at 2022-06-25 23:44:49.332070
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    var_0 = lazy_0.bind(object_0)


# Generated at 2022-06-25 23:44:51.244523
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy({})
    lazy_1 = Lazy({})
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:44:59.510149
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    pass


# Generated at 2022-06-25 23:45:05.259441
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import unittest

    class TestCase(unittest.TestCase):
        def test_bind(self):
            def fn(value):
                def new_fn():
                    return value

                return Lazy(new_fn)

            lazy = Lazy(lambda: 1)
            assert lazy.bind(fn) == Lazy(lambda: 1)

    test_case = TestCase()
    test_case.test_bind()


# Generated at 2022-06-25 23:45:07.833305
# Unit test for method get of class Lazy
def test_Lazy_get():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    var_0 = lazy_0.get()

# Generated at 2022-06-25 23:45:10.746012
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert not Lazy.of(1) == Lazy.of(2)
    assert not Lazy.of(1) == None


# Generated at 2022-06-25 23:45:20.033448
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import pymonet.box as module_0
    import pymonet.either as module_1
    import pymonet.maybe as module_2
    import pymonet.monad_try as module_3
    import pymonet.validation as module_4

    class class_0(object):
        def __init__(self, object_0, object_1):
            self.object_0 = object_0
            self.object_1 = object_1
        def __eq__(self, other):
            return (
                isinstance(other, class_0)
                and self.object_0 == other.object_0
                and self.object_1 == other.object_1
            )

    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object

# Generated at 2022-06-25 23:45:23.198807
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    result_0 = lazy_0.bind(lambda arg_0: arg_0)
    assert result_0.get() == object_0


# Generated at 2022-06-25 23:45:25.846475
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(10).bind(lambda x: Lazy.of(x*2)).get() == 20


# Generated at 2022-06-25 23:45:36.701302
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Maybe, Nothing
    from pymonet.validation import Validation, Failure
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.either import Right, Left
    from pymonet.lazy import Lazy

    # Testing lazy.Lazy.map(lambda x : x)
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = lazy_0.map(lambda x : x)
    assert lazy_1 == Lazy(object_0)
    lazy_0 = Lazy(lambda : module_0.int(0))
    lazy_1 = lazy_0.map(lambda x : x)

# Generated at 2022-06-25 23:45:40.637777
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy.of(20)
    lazy_1 = Lazy.of(lazy_0)
    lazy_2 = Lazy.of(lambda a: a + 1)
    lazy_3 = lazy_1.ap(lazy_2)
    lazy_4 = lazy_3.get()


# Generated at 2022-06-25 23:45:43.070958
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_0 = Lazy(module_0.str)
    var_0 = lazy_0.map(module_0.str)
    var_1 = lazy_0.map(module_0.str)


# Generated at 2022-06-25 23:45:54.008806
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from mono_test_class import TestClass

    lazy_test_class = Lazy(TestClass)
    assert lazy_test_class.bind(lambda value: Lazy(lambda: value.value)).get() == 'test'



# Generated at 2022-06-25 23:46:03.534094
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # setup
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy(object_0)
    lazy_2 = Lazy(object_0)
    lazy_3 = lazy_1
    # action
    var_0 = lazy_0.__eq__(lazy_1)
    var_1 = lazy_1.__eq__(lazy_0)
    var_2 = lazy_1.__eq__(lazy_2)
    var_3 = lazy_1.__eq__(lazy_3)
    var_4 = lazy_1.__eq__(lazy_0.constructor_fn)
    # assertion
    assert var_0 == False
    assert var_1 == False
    assert var_2 == False
    assert var

# Generated at 2022-06-25 23:46:04.362003
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    pass


# Generated at 2022-06-25 23:46:10.409880
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pymonet
    import pymonet.validation as func_0
    import pymonet.maybe as func_1
    import pymonet.either as func_2
    import pymonet.monad_try as func_3
    import pymonet.monad_state as func_4
    import pymonet.monad_state as func_5
    import pymonet.box as func_6
    import pymonet.lazy as func_7
    var_0 = func_0.Validation.of(([], 2))
    var_1 = func_1.Maybe.of(1)
    var_2 = func_2.Either.of(1)
    var_3 = func_3.Try.of(1)
    var_4 = func_4.State.of(func_5.get)

# Generated at 2022-06-25 23:46:19.864387
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object
    function_0 = module_0.function
    var_0 = Lazy(function_0)
    var_1 = Lazy(function_0)
    var_2 = Lazy(function_0)
    var_3 = Lazy(function_0)
    var_4 = Lazy(function_0)
    var_5 = Lazy(function_0)
    var_6 = Lazy(function_0)
    var_7 = Lazy(function_0)
    var_8 = Lazy(function_0)
    var_9 = Lazy(function_0)
    var_10 = Lazy(function_0)
    var_11 = Lazy(function_0)
    var_12 = Lazy(function_0)

# Generated at 2022-06-25 23:46:29.295964
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def fn(x):
        return fn2(x)

    def fn2(x):
        return fn3(x)

    def fn3(x):
        return fn4(x)

    def fn4(x):
        return fn5(x)

    def fn5(x):
        return fn6(x)

    def fn6(x):
        return Box(x)

    def fn7(x):
        return Maybe.just(x)

    def fn8(x):
        return Maybe.nothing()

    def fn9(x):
        return Right(x)


# Generated at 2022-06-25 23:46:36.364913
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def func_0(self_0, other_0):
        return Lazy.__eq__(self_0, other_0)
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy(object_0)
    lazy_2 = Lazy.of(object_0)
    func_0(lazy_0, lazy_1)
    var_0 = func_0(lazy_0, lazy_2)


# Generated at 2022-06-25 23:46:43.841758
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Test 1
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = lazy_0.bind(module_0.id)
    assert lazy_1.constructor_fn == object_0
    # Test 2
    object_1 = module_0.object()
    lazy_2 = Lazy(object_1)
    lazy_3 = lazy_2.bind(module_0.id)
    assert lazy_3.constructor_fn == object_1


# Generated at 2022-06-25 23:46:46.358814
# Unit test for method get of class Lazy
def test_Lazy_get():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    var_0 = lazy_0.get()


# Generated at 2022-06-25 23:46:51.657479
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # input
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy.of(lazy_0.get())
    # expected output
    expected = lazy_0.get()
    # actual output
    actual = lazy_0.ap(lazy_1)
    # Unit test
    assert actual == expected, "expect: " + str(expected) + ", but got: " + str(actual)


# Generated at 2022-06-25 23:47:01.769709
# Unit test for method get of class Lazy
def test_Lazy_get():
    classes = [
        test_case_0
    ]

    for cls in classes:
        cls()

import builtins as module_0


# Generated at 2022-06-25 23:47:08.298130
# Unit test for method map of class Lazy
def test_Lazy_map():
    def mapper_fn(x):
        return x + 1

    lazy_0 = Lazy.of(0)
    lazy_1 = lazy_0.map(mapper_fn)
    assert lazy_1.constructor_fn == mapper_fn


# Generated at 2022-06-25 23:47:14.247321
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    lazy1 = Lazy(lambda: 1)
    lazy1_clone = Lazy(lambda: 1)
    lazy2 = Lazy(lambda: 2)
    assert lazy1 == lazy1_clone
    assert lazy1 != lazy2


# Generated at 2022-06-25 23:47:17.691997
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy = Lazy(lambda x: x * 2)

    assert lazy.map(lambda x: x + 2) == Lazy(lambda x: (x * 2) + 2)
    assert lazy.map(lambda x: x / 2) == Lazy(lambda x: x)


# Generated at 2022-06-25 23:47:20.559798
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy(object_0)
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:47:31.376194
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Right
    from pymonet.either import Left

    assert Lazy.of(1).__eq__(Lazy.of(1)) == True

    assert Lazy.of(1).__eq__(Lazy.of(2)) == False

    assert Lazy.of(1).__eq__(Lazy.of(1).bind(lambda arg_0: Maybe.just(arg_0))) == False

    assert Lazy.of(1).__eq__(Lazy.of(1).bind(lambda arg_0: Try.success(arg_0))) == False

    assert Lazy.of(1).__eq__

# Generated at 2022-06-25 23:47:35.049968
# Unit test for method get of class Lazy
def test_Lazy_get():
    object_0 = module_0.object()
    lazy_1 = Lazy(object_0)
    assert lazy_1.is_evaluated == False
    lazy_1.get()
    assert lazy_1.is_evaluated == True


# Generated at 2022-06-25 23:47:36.464549
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = lazy_0.bind(module_0.object())
    assert isinstance(lazy_1, Lazy)


# Generated at 2022-06-25 23:47:38.255255
# Unit test for method get of class Lazy
def test_Lazy_get():
    def object_0():

        return
    lazy_0 = Lazy(object_0)
    var_0 = lazy_0.get()


# Generated at 2022-06-25 23:47:41.449918
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    arg_0 = Lazy(lambda arg: arg + 1)
    arg_1 = Box(lambda arg, arg2: arg + arg2)
    lazy_0 = arg_0.ap(arg_1)
    var_0 = lazy_0.get()
    assert var_0 == Box(3)


# Generated at 2022-06-25 23:47:58.818316
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_0.bind(object_0)


# Generated at 2022-06-25 23:48:03.813304
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_1 = Lazy(list)
    lazy_2 = Lazy(list)
    assert lazy_1 == lazy_2
    lazy_3 = Lazy(list)
    lazy_3._compute_value()
    assert lazy_1 == lazy_3
    assert lazy_2 == lazy_3


# Generated at 2022-06-25 23:48:12.426145
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Just

    def box_add(a, b): return Box(a+b)

    def just_add(a, b): return Just(a+b)

    def just_mul(a, b): return Just(a*b)

    lazy_add = Lazy(just_add)

    lazy_add_mul = lazy_add.map(just_mul)

    assert lazy_add_mul.get(1, 0) == Just(1)

    assert lazy_add.ap(lazy_add_mul).get(2, 3) == Just(5)

    assert lazy_add.ap(Box(box_add)).get(2, 3) == Box(5)



# Generated at 2022-06-25 23:48:16.062965
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    object_0 = module_0.object()
    lazy_0 = Lazy.of(object_0)
    lazy_1 = lazy_0.bind(lambda x: Lazy.of(x))
    lazy_2 = lazy_1.get()


# Generated at 2022-06-25 23:48:25.054423
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation

    validation_1 = Validation.fail(0)
    object_0 = module_0.object()
    object_0_1 = module_0.object()
    object_0_2 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_0_1 = lazy_0.ap(object_0_1)
    var_0 = lazy_0_1.to_validation()
    validation_0 = Validation.of(lambda: object_0_2)
    lazy_0_2 = lazy_0.ap(validation_0)
    var_1 = lazy_0_2.to_validation()
    var_2 = lazy_0_2.to_validation()


# Generated at 2022-06-25 23:48:27.970789
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()


# Generated at 2022-06-25 23:48:31.698193
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    fn_0 = lambda *args: lazy_0
    param_0 = lazy_0.bind(fn_0)
    param_1 = lazy_0.to_validation()


# Generated at 2022-06-25 23:48:37.130129
# Unit test for method get of class Lazy
def test_Lazy_get():
    module_0 = module_0
    object_0 = module_0.object
    lazy_0 = Lazy(object_0)
    var_0 = lazy_0.get()
    assert var_0 is object_0
    lazy_1 = Lazy.of(object_0)
    var_1 = lazy_1.get()
    assert var_1 is object_0

import pymonet.list
list = pymonet.list


# Generated at 2022-06-25 23:48:46.290823
# Unit test for method __eq__ of class Lazy

# Generated at 2022-06-25 23:48:49.564368
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    lazy_0 = Lazy(object)
    lazy_0 = lazy_0.bind(lambda x: Box.of(x))
    assert(lazy_0.is_evaluated == False)


# Generated at 2022-06-25 23:49:08.213121
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy(object_0)
    var_0 = lazy_0.__eq__(lazy_1)


# Generated at 2022-06-25 23:49:17.258979
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = Lazy(object_0)
    lazy_1.is_evaluated = lazy_0.is_evaluated
    lazy_1.value = lazy_0.value
    var_0 = lazy_1 is not lazy_0
    var_1 = lazy_0.__eq__(lazy_1)
    var_2 = lazy_1.__eq__(lazy_0)
    var_3 = lazy_0.__eq__(lazy_0)
    var_4 = lazy_0.__eq__(module_0.object())


# Generated at 2022-06-25 23:49:19.336397
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of("hi").bind(lambda v: Lazy.of("{}!").format(v)) == Lazy.of("hi!")



# Generated at 2022-06-25 23:49:21.321910
# Unit test for method get of class Lazy
def test_Lazy_get():
    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    module_0.assertEqual(type(lazy_0.get(1)),type(object()))

# Generated at 2022-06-25 23:49:27.751897
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    two_lazy = Lazy(lambda : 1)
    two_value = Lazy(lambda: 1).get()
    zero = Lazy(lambda: 0)
    five = Lazy(lambda: 5).get()

    assert two_lazy == Lazy(lambda : 1)
    assert not two_lazy == Lazy(lambda : 2)
    assert not zero == Lazy(lambda : 1)
    assert not five == Lazy(lambda : 1)
    assert not Lazy(lambda : 1) == zero
    assert not Lazy(lambda : 1) == five
    assert not five == zero
    assert not zero == five

# Generated at 2022-06-25 23:49:34.932115
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test of method ap of class Lazy.

    1)
    Create Lazy with constructor function returning 1.
    Call ap method with Lazy with lambda i -> i + 1.
    Check result of get method (it should be equal to 2).

    :return: None
    """
    lazy_0 = Lazy(lambda _: 1)
    lazy_1 = lazy_0.ap(Lazy(lambda i: i + 1))
    assert lazy_1.get() == 2


# Generated at 2022-06-25 23:49:38.452464
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    object_0 = module_0.object()
    lazy_0_0 = Lazy(object_0)
    lazy_0_0_0 = lazy_0_0.bind(object_0)
    assert isinstance(lazy_0_0_0, Lazy)


# Generated at 2022-06-25 23:49:42.734476
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_try import Try

    object_0 = module_0.object()
    lazy_0 = Lazy(object_0)
    lazy_1 = lazy_0.map(Try.of)
    var_0 = lazy_1.get()



# Generated at 2022-06-25 23:49:54.753899
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    object_0 = module_0.object()
    object_1 = module_0.object()
    object_2 = module_0.object()
    object_3 = module_0.object()
    object_4 = module_0.object()
    object_5 = module_0.object()
    object_6 = module_0.object()

    lazy_0 = Lazy(object_5)
    var_0 = lazy_0.bind(object_6)

    def function_0(object_7 = None):
        var_0 = object_7
        var_1 = lazy_0.bind(function_0)
        var_2 = lazy_0.get()
        var_3 = lazy_0.bind(object_6)
        var_4 = lazy_0.map(function_0)
        return var_

# Generated at 2022-06-25 23:50:02.708510
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Test data
    lazy_0 = Lazy.of("Hello")
    lazy_1 = Lazy.of("World")
    lazy_2 = lazy_0.ap(lazy_1)
    string_0 = lazy_2.get()

    assert(string_0 == "Helloo")
