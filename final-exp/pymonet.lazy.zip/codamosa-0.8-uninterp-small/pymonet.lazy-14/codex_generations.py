

# Generated at 2022-06-25 23:40:34.507090
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    result = Lazy.of(lambda x: x * 2).ap(Lazy.of(3))
    assert result.is_evaluated == True
    assert result.value == 6

    result = Lazy.of(lambda x: x * 2).ap(Lazy.of(3))
    assert result.is_evaluated == True
    assert result.value == 6

    result = Lazy.of(lambda x: x * 2).ap(Lazy.of(3))
    assert result.is_evaluated == True
    assert result.value == 6


# Generated at 2022-06-25 23:40:37.948616
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    value = 20
    lazy_0 = Lazy(lambda *args: value)
    assert lazy_0 == Lazy.of(value)

    assert not (lazy_0 == Lazy.of(value + 1))



# Generated at 2022-06-25 23:40:44.458637
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 3
    lazy_0 = Lazy.of(int_0)

    fn_0 = lambda x: x + 1
    lazy_1 = lazy_0.map(fn_0)

    assert isinstance(lazy_1, Lazy)
    assert lazy_1.is_evaluated is False
    assert lazy_1.value is None
    assert lazy_1.get() == int_0 + 1



# Generated at 2022-06-25 23:40:47.777528
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    int_0 = 3054
    lazy_0 = Lazy(int_0)
    lazy_1 = lazy_0.bind(lambda int_1: Lazy(int_0 + int_1))
    int_2 = lazy_1.get()
    assert int_2 == 2 * int_0



# Generated at 2022-06-25 23:40:52.762705
# Unit test for method map of class Lazy
def test_Lazy_map():
    """Assert Lazy.map(mapper).get() == mapper(value)"""
    def mapper(value):
        return value * 2

    def value():
        return 3

    assert Lazy(value).map(mapper).get() == 6



# Generated at 2022-06-25 23:41:02.340995
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Define lazy_0
    int_0 = 3054
    lazy_0 = Lazy(int_0)
    # Define lazy_1
    def lambda_fn_0(arg_0):
        # Define tmp_fn_0
        tmp_fn_0 = lambda arg_1: arg_1
        # Evaluate tmp_fn_0
        return Lazy(tmp_fn_0)
    lazy_1 = lazy_0.bind(lambda_fn_0)
    # Check if lazy_1 returned valid value
    assert lazy_1 == Lazy(lambda: 3054)


# Generated at 2022-06-25 23:41:05.532849
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(None).bind(lambda _: Lazy.of(1)).get() == 1


# Generated at 2022-06-25 23:41:10.458218
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Ensure that method __eq__ returns correct value.
    """
    int_0 = 3054
    lazy_0 = Lazy(int_0)
    int_1 = 3054
    lazy_1 = Lazy(int_1)
    int_2 = 3154
    lazy_2 = Lazy(int_2)
    int_3 = 3054
    lazy_3 = Lazy(int_3)
    int_4 = 3055
    lazy_4 = Lazy(int_4)

    assert lazy_0.is_evaluated is False
    assert lazy_0.value is None
    assert lazy_0.get() == 3054
    assert lazy_0.is_evaluated is True
    assert lazy_0.value == 3054
    assert lazy_0.get() == 3054
    assert lazy_0

# Generated at 2022-06-25 23:41:16.030601
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 3054
    lazy_0 = Lazy.of(int_0)
    lazy_1 = Lazy.of(int_0)
    lazy_2 = lazy_1.map(lambda v: v)
    assert lazy_0 == lazy_2
    assert lazy_1 == lazy_2
    assert not lazy_0 == None
    assert not lazy_1 == None
    assert not lazy_1 == 345
    

# Generated at 2022-06-25 23:41:18.321444
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 3054
    assert Lazy.of(int_0).bind(lambda a: Lazy.of(a)).get() == 3054


# Generated at 2022-06-25 23:41:31.314339
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1).__eq__(Lazy(lambda: 1)), \
        'Lazy(lambda: 1).__eq__(Lazy(lambda: 1)) should be True'

    assert not Lazy(lambda: 1).__eq__(Lazy(lambda: 2)), \
        'Lazy(lambda: 1).__eq__(Lazy(lambda: 2)) should be False'

    assert not Lazy(lambda: 1).__eq__(Lazy(lambda: 1).map(lambda x: x * 2)), \
        'Lazy(lambda: 1).__eq__(Lazy(lambda: 1).map(lambda x: x * 2)) should be False'


# Generated at 2022-06-25 23:41:36.682775
# Unit test for method get of class Lazy
def test_Lazy_get():

    def assert_value(expected_value, actual_value):
        assert actual_value == expected_value

    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    assert Functor.identity_law(Lazy(lambda: 'a'), lambda x: assert_value('a', x))
    assert Functor.composition_law(Lazy(lambda: 'a'), lambda x: 'b', lambda x: assert_value('b', x))

    assert Applicative.identity_law(Lazy(lambda: 'a'), lambda x: assert_value('a', x))
    assert Applicative.homomorphism_law(Lazy(lambda: 'a'), lambda x: 'b', lambda x: assert_value('b', x))
    assert Applicative

# Generated at 2022-06-25 23:41:44.442657
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    assert Lazy.of(10) == Lazy.of(10)
    assert Lazy.of(20) != Lazy.of(10)

    # Assert Lazy.__eq__ for containers
    assert Lazy.of(Box(10)) == Lazy.of(Box(10))
    assert Lazy.of(Box(20)) != Lazy.of(Box(10))
    assert Lazy.of(Maybe.just(10)) == Lazy.of(Maybe.just(10))

# Generated at 2022-06-25 23:41:52.173467
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from nose.tools import ok_

    from pymonet.validation import Validation

    lazy_0 = Lazy.of(5)
    lazy_1 = Lazy.of(5)

    lazy_2 = Lazy.of(1)
    lazy_3 = Lazy.of(2)

    lazy_4 = Lazy.of(5)
    lazy_5 = Lazy.of(1)

    lazy_6 = Lazy.of(5)
    lazy_7 = Lazy.of(2).map(lambda x: x + 2)
    lazy_8 = Lazy.of(7)

    lazy_9 = Lazy.of(5)
    lazy_10 = Lazy.of(2).bind(lambda v: Lazy.of(v + 2))
    lazy_11 = Lazy.of(7)

# Generated at 2022-06-25 23:41:59.901999
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    #
    # Test happy path
    #
    lazy_0 = Lazy.of(0)
    lazy_1 = Lazy.of(1)
    lazy_2 = Lazy.of(2)

    print(str(lazy_0) == str(lazy_0))

    print(lazy_0 == lazy_0)
    print(lazy_0 == Lazy.of(0))

    print(lazy_1 == lazy_1)
    print(lazy_1 == Lazy.of(1))

    print(lazy_1 == lazy_2)

    #
    # Test commutativity
    #
    print(lazy_0 == lazy_1)

    #
    # Test symmetry
    #
    print(lazy_0 == Lazy(lambda: 0))


# Generated at 2022-06-25 23:42:03.967490
# Unit test for method map of class Lazy
def test_Lazy_map():
    import random

    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    values_list = [
        Lazy.of(1),
        Lazy.of('a'),
        Lazy.of(True),
        Lazy.of(False),
        Lazy.of({'a': 'a'}),
        Lazy.of(['a']),
        Lazy.of(None),
    ]

    for value in values_list:
        result = value.map(lambda v: v + 1).get()
        assert value.to_box().map(lambda v: v + 1).get() == result, str_0

# Generated at 2022-06-25 23:42:13.813770
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    str_0 = 'Assert Lazy(func).__eq__(Lazy(func)) == True'
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) == True, str_0

    str_0 = 'Assert Lazy(func).__eq__(Lazy(lambda x: x + 1)) == False'
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1)) == False, str_0

    str_0 = 'Assert Lazy(func).__eq__(Lazy(lambda x: x).get()) == False'
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x).get()) == False, str_0



# Generated at 2022-06-25 23:42:22.542613
# Unit test for method get of class Lazy
def test_Lazy_get():
    _str_0 = 'Assert Lazy.get() == Lazy.get()'
    assert (Lazy(lambda x: x + 1).get(3) == 4
            ), _str_0
    assert (Lazy(lambda x, y: x + y).get(3, 4) == 7
            ), _str_0

    _str_1 = 'Assert Lazy.map(mapper).get() == mapper(value) for not empty Lazy'
    assert (Lazy(lambda x: x + 1).map(lambda x: x * 2).get(3) == 10
            ), _str_1

# Generated at 2022-06-25 23:42:33.577151
# Unit test for method get of class Lazy
def test_Lazy_get():

    # Test case 0: Lazy with function
    def test_case_0():
        function_0 = lambda _: 'value_0'
        lazy_0 = Lazy(function_0)
        output = lazy_0.get('arg_0')

        assert output == 'value_0'

    test_case_0()

    # Test case 1: Lazy with simple constant
    def test_case_1():
        lazy_0 = Lazy('value_0')
        output = lazy_0.get('arg_0')

        assert output == 'value_0'

    test_case_1()

    # Test case 2: memoization
    def test_case_2():
        function_0 = lambda _: 'value_0'
        lazy_0 = Lazy(function_0)

# Generated at 2022-06-25 23:42:37.376515
# Unit test for method map of class Lazy
def test_Lazy_map():
    Lazy_of_0 = Lazy.of(1)
    mapper_0 = lambda value: value + 1
    Lazy_map_0 = Lazy_of_0.map(mapper_0)

    def Lazy_map_0_fn(*args):
        return Lazy_of_0.get(*args) + 1

    assert Lazy_map_0.get() == 2
    assert Lazy_map_0.constructor_fn == Lazy_map_0_fn
    assert Lazy_map_0.is_evaluated is False
    assert Lazy_map_0.value is None


# Generated at 2022-06-25 23:42:47.359412
# Unit test for method map of class Lazy
def test_Lazy_map():
    def plus_one(x):
        return x + 1

    lazy = Lazy.of(1)
    assert lazy.map(plus_one).get() == 2

    lazy = Lazy.of(1)
    assert lazy.map(lambda x: x + 1).get() == 2

    lazy = Lazy.of(1)
    assert lazy.map(lambda x: x + 1).map(lambda x: x * 3).get() == 6

    lazy = Lazy.of(1)
    assert lazy.map(plus_one).map(lambda x: x * 3).get() == 6



# Generated at 2022-06-25 23:42:57.727305
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Test case 0
    # Test assertion :
    # Expression:
    # Lazy[fn=identity, value=None, is_evaluated=False]
    #     .map(lambda x: x ** 2)
    #     .get(1)
    # == 1 ** 2
    # == 1
    assert Lazy(lambda x: x).map(lambda x: x ** 2).get(1) == 1

    # Test case 1
    # Test assertion :
    # Expression:
    # Lazy[fn=identity, value=None, is_evaluated=False]
    #     .map(lambda x: x ** 2)
    #     .map(lambda x: x + 1)
    #     .get(1)
    # == (lambda x: x ** 2)(1) + 1
    # == 1 + 1


# Generated at 2022-06-25 23:43:01.557513
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Assert empty monad has the same value and constructor function
    assert Lazy.of(lambda: 0).bind(lambda x: Lazy.of(x + 1)).get() == 1

    # Assert result of mapper function and returned value is equal
    assert Lazy.of(lambda: 5).bind(lambda x: Lazy.of(x - 1)).get() == 4


# Generated at 2022-06-25 23:43:11.880797
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation, Success

    result = Lazy.of('Lazy').ap(Lazy.of(lambda x: x + ' is fun!'))

    assert result.get() == 'Lazy is fun!'

    result_fail= Lazy.of('Lazy').ap(Lazy.of(lambda x: 1/0))

    assert result_fail.get() == 'Lazy is fun!'

    result_validation = Lazy.of(Validation.success('Lazy')).ap(Lazy.of(lambda x: Validation.success(x + ' is fun!')))
    assert result_validation.get() == Success('Lazy is fun!')


# Generated at 2022-06-25 23:43:20.133013
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy(lambda x: x)
    assert lazy_0 == lazy_0
    assert lazy_0 != None
    lazy_1 = Lazy(lambda x: Lazy.of(x))
    assert lazy_0 == lazy_1
    assert lazy_1 != None
    lazy_2 = Lazy(lambda x: lazy_0)
    lazy_3 = Lazy(lambda x: lazy_1)
    assert lazy_2 == lazy_3
    assert lazy_2 != None
    assert lazy_2 == lazy_2
    assert lazy_3 == lazy_3
    assert lazy_2 != None
    assert lazy_3 != None
    assert lazy_2 == lazy_3


# Generated at 2022-06-25 23:43:24.929125
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.functions import idenity, square

    # Given
    identity_mapper = idenity()

    # When
    lazy_value = Lazy(idenity())
    lazy_value = lazy_value.map(lambda x: square(x))
    value = lazy_value.get(3)

    assert value == 9



# Generated at 2022-06-25 23:43:31.096270
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.functions import add

    lazy_5 = Lazy.of(5)

    assert lazy_5.get() == 5

    assert lazy_5.map(add(5)).get() == 10

    assert lazy_5.map(lambda value: [value] + [value, value]).get() == [5, 5, 5]



# Generated at 2022-06-25 23:43:34.416616
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Arrange
    value = 'Laziness is my job'
    expected = value

    # Act
    actual = Lazy.of(value).get()

    # Assert
    assert actual == expected



# Generated at 2022-06-25 23:43:39.157296
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Lazy[Function(A) -> B].ap(Lazy[A]) == Lazy[B]
    """
    str_0 = 'Lazy[Function(A) -> B].ap(Lazy[A]) == Lazy[B]'
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)).get() == 3


# Generated at 2022-06-25 23:43:41.802654
# Unit test for method map of class Lazy
def test_Lazy_map():
    def str_case(i: int) -> str:
        return str(i)

    assert Lazy.of(1).bind(lambda i: Lazy.of(i)).get() == 1


# Generated at 2022-06-25 23:43:56.879931
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert ''.join(Lazy.of('hello').bind(lambda str_0: Lazy.of(str_0)).constructor_fn()) == 'hello'



# Generated at 2022-06-25 23:44:06.471413
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Case 0:
    str_0 = 'Test case 0: Assert Lazy.bind(fn).get() == fn(value) for some (fn(value))'
    fn_0 = lambda x: Lazy.of('Lazy_0_value')
    lazy_0 = Lazy.of(0)
    assert lazy_0.bind(fn_0).get(0) == 'Lazy_0_value', str_0

    # Case 1:
    str_1 = 'Test case 1: Assert Lazy.bind(fn).get() == fn(value) for some (fn(value))'
    fn_1 = lambda x: Lazy.of('Lazy_1_value')
    lazy_1 = Lazy.of(1)

# Generated at 2022-06-25 23:44:12.523852
# Unit test for method map of class Lazy
def test_Lazy_map():
    str_0 = Lazy(lambda: 'a').map(lambda value: value.upper()).get()
    assert str_0 == 'A'

    str_1 = Lazy(lambda: 'B').map(lambda value: value.lower()).get()
    assert str_1 == 'b'

    int_0 = Lazy(lambda: 12).map(lambda value: value + 1).get()
    assert int_0 == 13

    int_1 = Lazy(lambda: 10).map(lambda value: value - 1).get()
    assert int_1 == 9


# Generated at 2022-06-25 23:44:14.385265
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x + 1).bind(Lazy.of).get(1) == 2


# Generated at 2022-06-25 23:44:24.766543
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_list import List
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_identity import Identity

    def fn_0():
        return Lazy.of(['a', 'b', 'c'])

    def mapper_0(value: str):
        return Maybe.just(value)

    result_0 = fn_0().bind(lambda x: x.to_list().bind(lambda x: x.bind(mapper_0).to_list().bind(lambda x: Lazy.of(x.get()))))

    assert result_0.get() == ['a', 'b', 'c']

    def fn_1():
        return Lazy.of(['a', 'b', 'c'])


# Generated at 2022-06-25 23:44:33.769979
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for method bind of class Lazy

    """

    instance_of_lazy = Lazy(lambda a: a + 1)
    fn_for_test_0 = lambda a: Lazy(lambda i: a + i)
    result = instance_of_lazy.bind(fn_for_test_0)
    assert result.constructor_fn(0) == 2

    instance_of_lazy = Lazy(lambda a: a + 1)
    fn_for_test_1 = lambda a: Lazy(lambda i: a * i)
    result = instance_of_lazy.bind(fn_for_test_1)
    assert result.constructor_fn(0) == 1

    instance_of_lazy = Lazy(lambda a: a + 1)

# Generated at 2022-06-25 23:44:39.452210
# Unit test for method map of class Lazy
def test_Lazy_map():
    # method Lazy.map(mapper)
    # call Lazy.map(mapper).get()
    # assert result == mapper(value)

    # function x: int -> x * 2
    mapper_fn = lambda x: x * 2
    # value - 1
    value = 1
    # result - mapper_fn(value) = 1 * 2 = 2
    result = mapper_fn(value)

    assert Lazy(lambda: value).map(mapper_fn).get() == result


# Generated at 2022-06-25 23:44:42.491699
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    str(Lazy.of(1).ap(Lazy.of(lambda x: x + 1))) == str(Lazy.of(2))

# Generated at 2022-06-25 23:44:52.094738
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Assert Lazy.ap(applicative) == applicative.constructor_fn(value)
    """
    str_0 = 'Assert Lazy.ap(applicative) == applicative.constructor_fn(value)'
    test_case_0.__doc__ = str_0

    def test_case_inner_0():
        def inner_0(value):
            return 1 + value

        def inner_1(value):
            return 2 + value

        assert Lazy.of(2).ap(Lazy.of(inner_0)).get() == inner_0(2)
        assert Lazy.of(2).ap(Lazy.of(inner_1)).get() == inner_1(2)

    test_case_inner_0()


# Generated at 2022-06-25 23:44:59.470698
# Unit test for method map of class Lazy
def test_Lazy_map():
    """Test Lazy.map"""
    from pymonet.simmap import HashMap
    from pymonet.box import Box

    map_0 = HashMap()
    map_0.put(10, 'a')
    map_0.put(20, 'b')
    map_0.put(30, 'c')
    map_0.put(40, 'd')
    map_0.put(50, 'e')

    def constructor_fn(*args):  # pylint: disable=unused-variable
        """Function that returns HashMap"""
        return map_0

    lazy_0 = Lazy(constructor_fn)

    map_1 = lazy_0.map(lambda x: Box(x))


# Generated at 2022-06-25 23:45:09.768149
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def mapper(value):
        return value + 1

    def mapper_2(value):
        return value + 2

    lazy = Lazy(lambda: 1)

    assert lazy.bind(lambda value: Lazy(lambda: value + 1)).get() == mapper(1)
    assert lazy.bind(lambda value: Lazy(lambda: value + 1)).map(mapper_2).get() == mapper_2(mapper(1))


# Generated at 2022-06-25 23:45:15.749657
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # str_0 = 'Assert Lazy.map(mapper).get() == mapper(value)'

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of('a') == Lazy.of('a')
    assert Lazy.of('a') != Lazy.of('b')


# Generated at 2022-06-25 23:45:21.269284
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test method map of class Lazy
    """
    assert Lazy(lambda: 2).bind(lambda a: Lazy(lambda: a + 3)).get() == 5

    assert Lazy(lambda: 2).bind(Lazy.of).get() == 2

    assert (
        Lazy(lambda: 2).bind(Lazy.of).bind(lambda a: Lazy(lambda: a + 3)).get()
        == 2
    )

    assert (
        Lazy(lambda: 2).bind(lambda a: Lazy(lambda: a + 3)).bind(lambda a: Lazy(lambda: a * 2)).get()
        == 10
    )


# Generated at 2022-06-25 23:45:28.768056
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn_0(value):
        from pymonet.box import Box

        return Box(value + '1')

    def fn_1(value):
        from pymonet.box import Box

        return Box(value + '2')

    lazy = Lazy.of('')
    result_0 = lazy.bind(fn_0)
    result_1 = result_0.bind(fn_1)
    assert result_1.get(None) == fn_0('').get(None) + fn_1('').get(None)


# Generated at 2022-06-25 23:45:38.273383
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x).bind(lambda x: Lazy.of(x)) == Lazy.of(1)
    assert Lazy(lambda x: x).bind(lambda x: Lazy(lambda y: x + y))._compute_value(1) == 2
    assert Lazy(1).bind(lambda x: Lazy(x + 1)) == Lazy(2)
    assert Lazy(1).bind(lambda x: Lazy(x + 1)).bind(lambda x: Lazy(x + 1)) == Lazy(3)
    assert Lazy(1).bind(lambda x: Lazy(x + 1)).bind(lambda x: Lazy(x + 1)).get() == 3



# Generated at 2022-06-25 23:45:41.107303
# Unit test for method map of class Lazy
def test_Lazy_map():
    for i in range(10):
        x = Lazy.of(i)
        mapper = lambda x: x + 1
        assert x.map(mapper).get() == mapper(i), str_0


# Generated at 2022-06-25 23:45:47.311954
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_list import ListMonad

    lazy = Lazy.of(1)
    bind_lazy = lazy.bind(lambda x: Lazy.of(x + 1))
    bind_lazy_list = bind_lazy.bind(ListMonad.of)
    assert bind_lazy_list == ListMonad([2])
    assert bind_lazy_list.fold(lambda x, y: x + y) == 2


# Generated at 2022-06-25 23:45:58.347436
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = 'Assert Lazy.map(mapper).get() == mapper(value)'
    value_0 = Lazy(lambda: 1).bind(lambda v: Lazy(lambda: v * 2)).get()
    assert value_0 == 2, str_0
    value_1 = Lazy(lambda: 1).bind(lambda v: Lazy(lambda: v * 10)).get()
    assert value_1 == 10, str_0
    value_2 = Lazy(lambda: 1).bind(lambda v: Lazy(lambda: v * 100)).get()
    assert value_2 == 100, str_0
    value_3 = Lazy(lambda: 1).bind(lambda v: Lazy(lambda: v * 1000)).get()
    assert value_3 == 1000, str_0

# Generated at 2022-06-25 23:46:02.899026
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # assert Lazy.of(4).ap(Lazy.of((lambda x: x * 2))) == Lazy.of(8)
    Lazy.of(lambda x: x * 2).ap(Lazy.of(4))
    str_0 = '\n=== test_Lazy_ap: OK ==='
    print(str_0)


# Generated at 2022-06-25 23:46:06.312265
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = 'Assert Lazy.get() == value'
    str_1 = 'Assert Lazy.map(mapper).get() == mapper(value)'
    str_2 = 'Assert Lazy.bind(mapper).get() == mapper(value).get()'


# Generated at 2022-06-25 23:46:22.506586
# Unit test for method map of class Lazy
def test_Lazy_map():
    value = 'string'
    value_2 = Lazy.of("tuple")
    mapper = str.upper

    assert Lazy.of(value).map(mapper).get() == mapper(value)
    assert Lazy.of(value).map(mapper).is_evaluated == True
    assert Lazy.of(value).map(mapper).to_either().get() == Lazy.of(value).map(mapper).get()
    assert Lazy.of(value).map(mapper).to_maybe().get() == Lazy.of(value).map(mapper).get()
    assert Lazy.of(value).map(mapper).to_try().get() == Lazy.of(value).map(mapper).get()
    assert Lazy.of(value).map(mapper).to_validation

# Generated at 2022-06-25 23:46:32.361175
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = Lazy.of('str_0')
    def str_0_to_str_1(str_0): return Lazy.of('str_1')
    str_1 = str_0.bind(str_0_to_str_1)
    str_1_expected = 'str_1'
    assert str_1.get() == str_1_expected, str_1_expected + ' was expected instead ' + str_1.get()

    str_0 = Lazy.of('str_0')
    def str_0_to_str_1(str_0): return Lazy.of('str_1')
    def str_1_to_str_2(str_1): return Lazy.of('str_2')

# Generated at 2022-06-25 23:46:43.219187
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    str_mapper = lambda x: str(x)
    # Input: Lazy(lambda: 123).map(mapper).bind(lambda x: Lazy(lambda: x + 1))
    # Expected output: Lazy(lambda: 124)
    assert Lazy(lambda: 123).map(str_mapper).bind(lambda x: Lazy(lambda: x + 1)).get() == '124'
    # Input: Lazy(lambda: [1, 2, 3]).map(mapper).bind(lambda x: Lazy(lambda: x + 1))
    # Expected output: Lazy(lambda: '1,2,31')

# Generated at 2022-06-25 23:46:47.249642
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x).get() == 1
    assert Lazy.of(-2).map(lambda x: x * x).get() == 4
    assert Lazy.of(3).map(lambda x: x * x * x).get() == 27


# Generated at 2022-06-25 23:46:54.063166
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_obj = Lazy.of('test')
    mapper_fn = lambda x: '{} mapped'.format(x)
    mapped_lazy = lazy_obj.map(mapper_fn)

    assert str(mapped_lazy) == "Lazy[fn=<function Lazy_map.<locals>.<lambda> at 0x7f1a270a2d08>, value=None, is_evaluated=False]"
    assert mapped_lazy.get() == 'test mapped'
    assert str(mapped_lazy) == "Lazy[fn=<function Lazy_map.<locals>.<lambda> at 0x7f1a270a2d08>, value='test mapped', is_evaluated=True]"


# Generated at 2022-06-25 23:46:57.205958
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(42).bind(lambda foo: Lazy.of(foo)).get() == 42
    assert Lazy.of(21).bind(lambda foo: Lazy.of(foo * 2)).get() == 42


# Generated at 2022-06-25 23:47:09.149845
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.either import Right, Left

    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy.of(1).to_try() == Try(1)
    assert Lazy.of(1).to_box() == Box(1)
    assert Lazy.of(1).to_validation() == Validation(1)
    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(1).to_maybe().to_either() == Right(1)

# Generated at 2022-06-25 23:47:13.632995
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = 'Assert Lazy.map(mapper).get() == mapper(value)'
    str_1 = 'Assert Lazy().map(lambda x: x + 1).get() == 1'
    str_2 = 'Assert Lazy.map(None).get() == None'

# Generated at 2022-06-25 23:47:16.262766
# Unit test for method map of class Lazy
def test_Lazy_map():
    value = 'value'
    def double(value):
        return value * 2

    assert Lazy.of(value).map(double).get() == double(value)

# Generated at 2022-06-25 23:47:26.939683
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    l0 = Lazy.of(lambda x: x + 1)
    l1 = Lazy.of(5)
    l2 = l0.ap(l1)
    assert l2.get() == 6

    l0 = Lazy.of(lambda x: x + 1)
    l1 = Lazy.of(5)
    l2 = l1.ap(l0)
    assert l2.get() == 6

    l0 = Lazy.of("lazy")
    l1 = Lazy.of("lazy")
    l2 = l0.ap(l1)
    assert l2.get() == "lazy"

    l0 = Lazy.of("lazy")
    l1 = Lazy.of("lazy")
    l2 = l1.ap(l0)
    assert l2

# Generated at 2022-06-25 23:47:35.534083
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x).bind(lambda x: x + 10).get(5) == 15


# Generated at 2022-06-25 23:47:40.192298
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x).map(lambda x: x + 'a').get('b') == 'ba'
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(1) == 2
    assert Lazy(lambda x: x).map(lambda x: x + 1).get('2') == 3
    assert Lazy(lambda x: x).map(lambda x: '5').get([]) == '5'


# Generated at 2022-06-25 23:47:43.126296
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    str_0 = 'Assert Lazy(fn).ap(Lazy(fn)).get() == fn(fn())'
    assert Lazy(lambda : 4).ap(Lazy(lambda : 4)).get() == 4



# Generated at 2022-06-25 23:47:46.467451
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # 1. Preparation
    value_0 = 0
    lazy_0 = Lazy.of(value_0)

    # 2. Execution
    # 3. Verification
    value_1 = 1
    assert lazy_0.get() == value_1



# Generated at 2022-06-25 23:47:57.458140
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    print('Test Lazy.bind()')
    str_0 = 'Assert Lazy(fn).bind(fn).get() == fn(fn())'
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 2)).get() == 3, str_0
    str_1 = 'Assert Lazy(fn).bind(fn).get() == fn(fn())'
    assert Lazy(lambda: 1).map(lambda x: x + 1).bind(lambda x: Lazy(lambda: x + 2)).get() == 4, str_1
    str_2 = 'Assert Lazy(fn).get() == fn(None)'
    assert Lazy(lambda x: x).get(1) == 1, str_2

# Generated at 2022-06-25 23:47:59.613555
# Unit test for method map of class Lazy
def test_Lazy_map():
    fn = lambda x: x * 2
    val = 2
    assert fn(val) == Lazy(lambda x: x).map(fn).get(val)



# Generated at 2022-06-25 23:48:07.072237
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(value: int) -> int:
        return value + 1

    assert Lazy(lambda: 1).map(add_one).get() == add_one(1)
    assert Lazy(lambda x: x + 1).map(add_one).get(1) == add_one(add_one(1))
    assert Lazy(lambda x: x).map(add_one).get(1) == add_one(1)



# Generated at 2022-06-25 23:48:08.006118
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    raise NotImplementedError()


# Generated at 2022-06-25 23:48:16.608409
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of('a') == Lazy.of('a')
    assert Lazy.of(Lazy.of(1)) == Lazy.of(Lazy.of(1))
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of('a') != Lazy.of('b')
    assert Lazy.of(Lazy.of(1)) != Lazy.of(Lazy.of(2))
    assert Lazy.of(1) != Lazy.of(Lazy.of(1))
    assert Lazy.of(1) != 'a'
    assert Lazy.of(1) != 1


# Generated at 2022-06-25 23:48:25.600994
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.monad import bind

    def assert_bind_monad_functor(value: object, mapper: Callable[[object], object], bind_fn: Callable[[object], Lazy[object, object]]):
        result_monad = bind(Lazy(lambda *args: value), bind_fn)
        result_functor = Lazy.of(value).map(mapper)

        assert result_monad == result_functor

    assert_bind_monad_functor(True, lambda value: value, lambda value: Lazy.of(lambda *args: value))
    assert_bind_monad_functor(False, lambda value: value, lambda value: Lazy.of(lambda *args: value))
   

# Generated at 2022-06-25 23:48:41.772111
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    class TestFunctor(Functor):
        def _app(self):  # pragma: no cover
            return self.value

    class TestApplicative(Applicative):
        def _app(self, other: object) -> object:
            return self.value + other

    class TestMonad(Monad):
        def _app(self, other: object) -> object:
            return self.value + other

    test_value_0 = 1
    test_value_1 = 2

    assert test_value_0 == Lazy(lambda: test_value_0).get()
    assert test_value_1 == Lazy(lambda: test_value_1).get()
    assert test

# Generated at 2022-06-25 23:48:44.610533
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of('value').map(lambda x: 'TEST CASE 0').get() == 'TEST CASE 0'
    print(Lazy.of('value').map(lambda x: 'TEST CASE 0').get())


# Generated at 2022-06-25 23:48:51.855337
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of('value').map(lambda x: len(x)).get() == len('value')
    assert Lazy.of([1, 2, 3]).map(lambda x: x[2]).get() == 3
    assert Lazy.of({'a', 'b'}).map(lambda x: list(x)[1]).get() == 'b'
    assert Lazy.of({'a': 1, 'b': 2}).map(lambda x: x['b']).get() == 2
    assert Lazy.of([1, 2, 3]).map(lambda x: x[4]).get() == None


# Generated at 2022-06-25 23:48:57.818915
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    mapper = lambda value: value + 1
    binded_mapper = lambda value: Lazy.of(mapper(value))
    value = 5

    lazy_2 = Lazy.of(value).bind(binded_mapper)
    assert lazy_2.get() == mapper(value)

    str_0 = 'Assert Lazy.bind(binded_mapper).get() == mapper(value)'



# Generated at 2022-06-25 23:49:05.940632
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    # Assert Lazy.map(mapper).get() == mapper(value)
    fn = lambda n: n * 2
    mapper = lambda n: n * 4
    value = 2
    assert Lazy(fn).map(mapper).get() == mapper(fn(value))

    # Assert Lazy.bind(fn).get() == fn(value)
    fn = lambda n: n * 2
    value = 2
    assert Lazy(fn).bind(lambda n: Lazy(lambda: n)).get() == fn(value)

    # Assert Lazy.bind(fn).get() == fn(value)
    fn = lambda n: n * 2
    value = 2
    assert Lazy(fn).bind(lambda n: Lazy(lambda: n * 2)).get() == fn(value) * 2

# Unit

# Generated at 2022-06-25 23:49:08.984834
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    f = lambda x: x * 10
    g = Lazy(f)
    x = Lazy.of(10)
    assert g.ap(x).get() == g.get(f(x.get()))


# Generated at 2022-06-25 23:49:12.700340
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    str_0 = 'lazy(fn) -> A\nlazy.bind(fn) -> B\nfn(A) -> C\nassert lazy(fn).bind(fn) == C'


# Generated at 2022-06-25 23:49:21.499427
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Bind tests for Lazy
    """
    from operator import add
    from pymonet.maybe import Maybe, MaybeType

    def test_case_1():
        """
        Test in case:
        *   mapper is function Function(A) -> B
        *   self is Lazy[Function() -> A]
        *   self constructor_fn return A
        *   fn is Function(A) -> Lazy[A, W]

        :returns: None
        """
        str_0 = 'Binding Lazy of int with fn returning Lazy with mapped value should return Lazy with mapped value'

        def fn_1(a):  # type: (int) -> Lazy[int, str]
            return Lazy(lambda *args: str(a))


# Generated at 2022-06-25 23:49:23.283917
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    result = Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert result.get() == 2


# Generated at 2022-06-25 23:49:32.819493
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Test case 0
    value_0 = 42
    mapper_0 = lambda value: value * 2

    lazy_0 = Lazy.of(value_0)
    lazy_1 = lazy_0.map(mapper_0)
    assert lazy_1.get() == mapper_0(value_0)

    # Test case 1
    value_1 = [1, 2, 3, 4, 5]
    mapper_1 = len

    lazy_0 = Lazy.of(value_1)
    lazy_1 = lazy_0.map(mapper_1)
    assert lazy_1.get() == mapper_1(value_1)

    # Test case 2
    value_2 = 'ciao'
    mapper_2 = lambda value: value.upper()


# Generated at 2022-06-25 23:49:42.539067
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    for i in range(1, 10):
        assert Lazy(lambda: i).bind(lambda x: Lazy(lambda: x + 1)).get() == i + 1


# Generated at 2022-06-25 23:49:49.186367
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(value):
        return Lazy(lambda: value)

    lazy_1_value = 5
    lazy_1 = Lazy.of(lazy_1_value)
    result_1 = lazy_1.bind(fn)
    assert result_1.get() == fn(lazy_1_value).get()



# Generated at 2022-06-25 23:49:57.471307
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import pymonet.box as box
    import pymonet.either as either
    import pymonet.monad_try as monad_try
    import pymonet.validation as validation
    import pymonet.maybe as maybe

    str_0 = 'Assert Lazy.map(mapper).get() == mapper(value)'

    assert Lazy.of(3).ap(Lazy.of(lambda x: x + 1)).get() == (4)

    assert Lazy.of(3).ap(Lazy.of(lambda x: x * 2)).get() == (6)

    assert Lazy.of(Lazy.of(7)).ap(Lazy.of(lambda x: x + 1)).get().get() == (8)


# Generated at 2022-06-25 23:50:03.981438
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    expected_value = True
    lazy_instance = Lazy.of(5)
    lazy_instance_eq = Lazy.of(5)
    result = lazy_instance.__eq__(lazy_instance_eq)
    assert result == expected_value,\
        f'{str_0} : expected_value={expected_value}, result={result}'


# Generated at 2022-06-25 23:50:13.138892
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert_func = lambda str_0, str_1, str_2: Lazy.of(str_1).bind(lambda x: Lazy.of(str_2)).get() == str_2

    assert_func('Assert Lazy.map(mapper).get() == mapper(value)', '', 'a')
    assert_func('Assert Lazy.map(mapper).get() == mapper(value)', 'a', 'a')
    assert_func('Assert Lazy.map(mapper).get() == mapper(value)', 'a', '')
    assert_func('Assert Lazy.map(mapper).get() == mapper(value)', '', '')


# Generated at 2022-06-25 23:50:20.040736
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Describe test name
    str_0 = 'Assert Lazy.ap(function).get(a) == function(constructor_fn).get(a)'
    # Define test's arguments
    a = 1
    def mapper(result: int) -> int:
        return result * 2

    def constructor_fn(a: int) -> int:
        return a + 1

    def function(result: int) -> Lazy[int, int]:
        return Lazy.of(result * 2)

    # Create testee
    lazy_0 = Lazy(constructor_fn)
    # Test
    assert lazy_0.ap(function).get(a) == function(constructor_fn(a)).get(a)



# Generated at 2022-06-25 23:50:21.569354
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda v: Lazy.of(v)).get() == 1


# Generated at 2022-06-25 23:50:26.263492
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given
    value = 'value'
    lazy_value = Lazy.of(value)

    def mapper(args):  # type: ignore
        return args + args

    # When
    mapped_lazy_value = lazy_value.map(mapper)

    # Then
    assert mapped_lazy_value.get() == mapper(value)

