

# Generated at 2022-06-25 23:40:22.040292
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda : ()) == Lazy(lambda : ())


# Generated at 2022-06-25 23:40:25.624552
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test_func_1(arg_0, arg_1):
        return arg_0 + arg_1

    def test_func_2(arg_0):
        return arg_0 * arg_0

    lazy_0 = Lazy(lambda arg_1, arg_2: test_func_1(arg_1, arg_2))
    assert lazy_0.map(test_func_2).get(1, 2) == 9



# Generated at 2022-06-25 23:40:36.681176
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Test two Same Lazy instances
    fn_0 = lambda _: Lazy(lambda value: value)

    lazy_0 = Lazy(fn_0)

    lazy_1 = Lazy.of(lambda x: x.upper())

    ap_0 = lazy_0.ap(lazy_1)
    assert lazy_0 == ap_0
    assert ap_0.get(True) == True

    # Test same Lazy instance
    fn_1 = lambda value: value
    fn_2 = lambda fn: fn(True).upper()

    lazy_2 = Lazy(fn_2)
    lazy_3 = Lazy.of(lambda x: x.upper())

    ap_1 = lazy_2.ap(lazy_3)
    assert lazy_3 == ap_1

# Generated at 2022-06-25 23:40:42.173014
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def constructor_fn_0(*args):
        return 1

    def constructor_fn_1(*args):
        return 1

    def fn_0(*args):
        return constructor_fn_1(*args)
    assert Lazy(constructor_fn_0).bind(fn_0).get() == constructor_fn_1()



# Generated at 2022-06-25 23:40:49.929380
# Unit test for method get of class Lazy
def test_Lazy_get():
    # test creation of class Lazy
    test_case_0()

    # test get value from Lazy
    lazy_1 = Lazy.of(True)
    assert lazy_1.get() == True

    # test get value from Lazy
    lazy_2 = Lazy.of(add)
    assert lazy_2.get()(1, 1) == 2

    # test get value from Lazy
    lazy_3 = Lazy.of(add)
    assert lazy_3.get(1, 1) == 2

    # test get value from Lazy, test indirected call
    lazy_4 = Lazy.of(add)
    assert lazy_4.map(lambda value: value(1, 1)).get() == 2

    # test get value from Lazy, test indirected call

# Generated at 2022-06-25 23:40:54.352905
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Left, Right
    left = Left(1)
    right = Right(1)

    assert Lazy.of(left).bind(lambda left: Lazy.of(left)) == Lazy.of(left)
    assert Lazy.of(right).bind(lambda right: Lazy.of(right)) == Lazy.of(right)


# Generated at 2022-06-25 23:41:00.617882
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure

    def add_fn(val: int) -> Try[int]:
        return Try.of(lambda: val + val)

    lazy_ = Lazy(lambda: 9)
    lazy_.bind(add_fn).get()

    assert lazy_.bind(add_fn) == Lazy(lambda: Success(18))



# Generated at 2022-06-25 23:41:04.686506
# Unit test for method map of class Lazy
def test_Lazy_map():
    def fn_integer_to_string(value: int) -> str:
        return str(value)

    tuple_0 = (1, 2, 3)
    lazy_0 = Lazy(tuple_0)
    lazy_0.map(fn_integer_to_string)


# Generated at 2022-06-25 23:41:08.684289
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_0 = Lazy(tuple).get()
    lazy_1 = Lazy.of(tuple).get()
    assert lazy_0 == ()
    assert lazy_1 == ()
    lazy_2 = Lazy(list).map(list).get()
    assert lazy_2 == []


# Generated at 2022-06-25 23:41:13.726113
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    true_fn = lambda: True
    lazy_0 = Lazy(true_fn)
    lazy_1 = Lazy(true_fn)
    lazy_2 = Lazy(true_fn)

    assert lazy_0 == lazy_1
    assert lazy_0.constructor_fn == lazy_1.constructor_fn
    assert not lazy_0 == lazy_2
    assert not isinstance(None, Lazy)
    assert lazy_0 != None
    assert not lazy_0 == None


# Generated at 2022-06-25 23:41:25.234326
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # Test 1.1:
    # Function with return value
    def function_with_return_value(value):
        return value

    # Test 1.2:
    # Testing Lazy constructor
    lazy_1_2 = Lazy.of(2)

    # Test 1.3:
    # Testing if returned value is of type Lazy
    lazy_1_3 = lazy_1_2.bind(function_with_return_value)
    assert (
        isinstance(lazy_1_3, Lazy)
    ), "bind() function did not return Lazy type in the case of function with return value"

    # Test 1.4:
    # Testing if returned value is equal to the parameter 'value'
    # that the

# Generated at 2022-06-25 23:41:26.476260
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)


# Generated at 2022-06-25 23:41:27.686001
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 23:41:31.197710
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(12) == Lazy(12)
    assert Lazy(12) != Lazy(13)
    assert Lazy(12) != Lazy(lambda x: 12)


# Generated at 2022-06-25 23:41:34.872558
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy = Lazy.of(lambda x: x + 5)
    val = Lazy.of(5).ap(lazy).get()
    assert val == 10



# Generated at 2022-06-25 23:41:43.035374
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    tuple_0 = (1)
    tuple_1 = (1, 2)
    tuple_2 = (1, 2, 3)
    tuple_3 = (1, 2, 3, 4)
    tuple_4 = (1, 2, 3, 4, 5)
    tuple_5 = (1, 2, 3, 4, 5, 6)
    tuple_6 = (1, 2, 3, 4, 5, 6, 7)
    tuple_7 = (1, 2, 3, 4, 5, 6, 7, 8)
    tuple_8 = (1, 2, 3, 4, 5, 6, 7, 8, 9)
    tuple_9 = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-25 23:41:53.805574
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 0).get() == 0
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 2).get() == 2
    assert Lazy(lambda: 3).get() == 3
    assert Lazy(lambda: 4).get() == 4
    assert Lazy(lambda: 5).get() == 5
    assert Lazy(lambda: 6).get() == 6
    assert Lazy(lambda: 7).get() == 7
    assert Lazy(lambda: 8).get() == 8
    assert Lazy(lambda: 9).get() == 9
    assert Lazy(lambda: 10).get() == 10
    assert Lazy(lambda: 11).get() == 11
    assert Lazy(lambda: 12).get() == 12
    assert Lazy(lambda: 13).get() == 13
    assert L

# Generated at 2022-06-25 23:41:55.852582
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2



# Generated at 2022-06-25 23:41:58.456680
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    tuple_0 = (1, 4, '7')
    lazy_0 = Lazy(tuple_0)
    lazy_1 = Lazy(tuple_0)
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:42:06.393721
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    tuple_0 = ()
    list_0 = []
    lazy_0 = Lazy(lambda: tuple_0)
    lazy_1 = Lazy(lambda: tuple_0)
    lazy_2 = Lazy(lambda: list_0)
    assert lazy_0 == lazy_1
    assert not (lazy_0 == lazy_2)


# Generated at 2022-06-25 23:42:18.376866
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = Lazy.of(1)
    int_1 = Lazy.of(1)
    int_2 = Lazy.of(1)
    int_3 = Lazy.of(2)

    # Condition: int_0 == int_1
    # Assert: int_0 == int_1
    assert int_0 == int_1

    # Condition: int_0 == int_2
    # Assert: int_0 == int_2
    assert int_0 == int_2

    # Condition: int_0 == int_3
    # Assert: int_0 != int_3
    assert int_0 != int_3


# Generated at 2022-06-25 23:42:22.948007
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 1
    int_1 = 2
    lazy_0 = Lazy.of(int_0)
    lazy_1 = Lazy.of(int_0)
    lazy_2 = Lazy.of(int_1)
    assert lazy_0 == lazy_1
    assert lazy_0 != lazy_2


# Generated at 2022-06-25 23:42:27.446576
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    mk_int_0 = Lazy(lambda: 1)

    result = mk_int_0.bind(lambda x: Lazy(lambda: x + 1))

    assert result == Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))


# Generated at 2022-06-25 23:42:30.862529
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(2).__eq__(Lazy.of(2)) == True
    assert Lazy.of(2).__eq__(Lazy.of(3)) == False


# Generated at 2022-06-25 23:42:39.170811
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet import lazy

    def check_ap(old_lazy, applicative, expected_value, expected_is_evaluated):
        new_lazy = old_lazy.ap(applicative)

        lazy.assert_lazy(new_lazy, expected_value, expected_is_evaluated)

    test_cases = [
        (lambda x: x * 2, Box(lambda x: x + 2), 6, False),
        (lambda x: x * 2, lazy.Lazy.of(lambda x: x + 2), 6, False),
        (lambda x: x * 2, lazy.Lazy(lambda x: x + 2), 6, False),
    ]

# Generated at 2022-06-25 23:42:41.967356
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(int_0) == Lazy.of(int_0)
    assert not Lazy.of(int_0) == None
    assert not Lazy.of(int_0) == Lazy.of('str')


# Generated at 2022-06-25 23:42:44.599560
# Unit test for method get of class Lazy
def test_Lazy_get():
    fn = lambda x: x + 3
    lazy = Lazy(fn)
    assert fn(int_0) == lazy.get(int_0)


# Generated at 2022-06-25 23:42:53.116091
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test case 0
    """
    int_0 = 1

    class TestLazyClass(Lazy[int, int]):
        def __init__(self, constructor_fn):
            super().__init__(constructor_fn)
            self.constructor_call_count = 0

        def _compute_value(self, *args):
            self.constructor_call_count += 1
            return self.constructor_fn(*args)

    test_lazy = TestLazyClass.of(int_0)

    int_1 = test_lazy.get()

    assert int_1 == int_0
    assert test_lazy.constructor_call_count == 1


# Generated at 2022-06-25 23:43:00.552999
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = Lazy.of(1)
    str_0 = Lazy.of("ciao")
    assert int_0.get() == 1 == str_0.get()

    class CallableClass:
        def __call__(self):
            return "ciao"
    func_0 = Lazy(CallableClass())
    assert func_0.get() == "ciao"

    def func_1(arg_0):
        return arg_0 + 1
    func_2 = Lazy(func_1)
    assert func_2.get(3) == 4


# Generated at 2022-06-25 23:43:07.366159
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 0).map(lambda x: x).constructor_fn() == 0
    assert Lazy(lambda: 1).map(lambda x: x + 1).constructor_fn() == 2
    assert Lazy(lambda: 2).map(lambda x: x * x * x).constructor_fn() == 8
    assert Lazy(lambda: 5).map(lambda x: 'i am {}'.format(x)).constructor_fn() == 'i am 5'


# Generated at 2022-06-25 23:43:15.635382
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(int_0) == Lazy.of(int_0), "Lazy.__eq__: test 0 - failed"
    assert Lazy.of(int_0) != Lazy.of(1), "Lazy.__eq__: test 1 - failed"


# Generated at 2022-06-25 23:43:20.382000
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 1
    def function(value):
        return Lazy(lambda *args: value + 1)

    lazy_value = Lazy(function)

    # Bind always return new Lazy, self is not changed
    assert id(lazy_value) != id(lazy_value.bind(function))

    # Check binded function
    assert lazy_value.bind(function).get() == 2


# Generated at 2022-06-25 23:43:24.371741
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 1
    f_0 = Lazy
    f_1 = f_0.of(int_0)
    f_2 = f_0.of(int_0)

    assert(f_1 == f_2)


# Generated at 2022-06-25 23:43:28.491870
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add_5(a):
        return a + 5

    lazy_add_5 = Lazy(add_5)
    assert lazy_add_5.get(10) == 15


# Generated at 2022-06-25 23:43:38.735031
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 1
    int_1 = 2
    int_2 = 3
    int_3 = 4

    int_0_box = Lazy.of(int_0)
    int_1_box = Lazy.of(int_1)
    int_2_box = Lazy.of(int_2)
    int_3_box = Lazy.of(int_3)

    def sum_two_args(a: int, b: int) -> int:
        return a + b

    sum_two_args_lz = Lazy(sum_two_args)

    sum_result = sum_two_args_lz.map(lambda x: x).get(int_1, int_2)
    int_add_to_self = int_0_box.map(lambda x: x + x).get

# Generated at 2022-06-25 23:43:40.739982
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(10).bind(lambda x: Lazy.of(x * 2)).get() == 20



# Generated at 2022-06-25 23:43:47.531969
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    fn = lambda x: Lazy(lambda: x + 1)
    lazy_int = Lazy.of(1)
    lazy_int.bind(fn) == Lazy.of(2)

    error_message = TestError.Error("test")
    fn = lambda x: Lazy.of(x)
    lazy_error = Lazy.of(error_message)
    lazy_error.bind(fn) == Lazy.of(error_message)

    lazy_box = Lazy.of(Box.of(1))

# Generated at 2022-06-25 23:43:53.888873
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = Lazy.of(5).get()
    assert int_0 == 5, '\'Lazy.of(5).get()\' should evaluate to 5'
    
    str_0 = Lazy.of("Hello!").get()
    assert str_0 == "Hello!", '\'Lazy.of("Hello!").get()\' should evaluate to \"Hello!\"'
    
    #test_case_0()


# Generated at 2022-06-25 23:44:04.516280
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Test case 0
    # Constructor function return 0 and mapper will return 1.
    # Hence the result should also be 1.
    # This example test that ap function returns proper result.
    int_0 = Lazy.of(0)
    add_1_function = lambda x: x + 1
    int_1 = int_0.ap(Lazy.of(add_1_function))
    assert int_1.get() == 1

    # Test case 1
    # Constructor function return 0 and mapper will return 1.
    # Hence the result should also be 1.
    # This example test that ap function is lazily evaluated.
    int_0 = Lazy.of(0)
    add_1_function = lambda x: x + 1

# Generated at 2022-06-25 23:44:08.940790
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: int_0).bind(lambda x: Lazy.of(x)).get() == 1
    assert Lazy(lambda: 2).map(lambda x: x + 2).bind(lambda x: Lazy(lambda: x)).get() == 4
    assert Lazy(lambda x: x + 2).bind(lambda x: Lazy(lambda: x + 2)).get(10) == 14

# Generated at 2022-06-25 23:44:17.323605
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from test.test_monad import ensure_equals

    ensure_equals(Lazy(lambda: '') == Lazy(lambda: ''), False)
    ensure_equals(Lazy(lambda: '').get() == Lazy(lambda: '').get(), True)


# Generated at 2022-06-25 23:44:18.892808
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_0 = Lazy.of(1)
    assert(int_0.get() == 1)


# Generated at 2022-06-25 23:44:22.938654
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Arrange
    test_Lazy_int_0 = Lazy(int)

    # Act
    computated_lazy = test_Lazy_int_0.bind(lambda x: Lazy(lambda: x + 1))

    # Assert
    assert computated_lazy.get('1') == 2


# Generated at 2022-06-25 23:44:25.092816
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x: 2*x).get(3) == 6


# Generated at 2022-06-25 23:44:28.498380
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy(lambda: int_0)
    int_1 = 2
    lazy.bind(lambda x: Lazy(lambda: x + int_1))
    assert lazy.get() == int_1 + int_0



# Generated at 2022-06-25 23:44:35.999057
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    import unittest
    from pymonet.test_utils import TestUtils

    class TestLazy(unittest.TestCase, TestUtils):
        def __init__(self, methodName='runTest'):
            super().__init__(methodName)
            self.method_name = methodName

        def method_a(self):
            Lazy(lambda x: x)._compute_value(1)
            return Lazy(lambda x: x)

        def method_b(self):
            Lazy(lambda x: x)._compute_value(1)
            return Lazy(lambda x: x)

        def method_c(self):
            Lazy(lambda x: x)._compute_value(2)
            return Lazy(lambda x: x)


# Generated at 2022-06-25 23:44:47.123638
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    add_lazy = Lazy(add)
    add_lazy_mapped = add_lazy.map(lambda arg: arg * 2)

    assert add_lazy.get(1, 2) == 3
    assert add_lazy_mapped.get(1, 2) == 2 * add_lazy.get(1, 2)

    assert add_lazy.to_maybe(1, 2) == Maybe.just(add_lazy.get(1, 2))
    assert add_lazy.to_validation(1, 2) == Validation.success(add_lazy.get(1, 2))

# Generated at 2022-06-25 23:44:51.287638
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: 2 * x).ap(Lazy.of(10)) == Lazy.of(20)
    assert Lazy.of(lambda x: 2 * x).ap(Lazy.of(10)) == Lazy(lambda *x: 20).get()

'''
Test for method bind of Lazy
'''

# Generated at 2022-06-25 23:44:54.610138
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert (
        Lazy.of(int_0)
        .map(lambda n: n + 1)
        .map(lambda n: n * 3)
        .map(lambda n: n - 1)
        .get() == 6
    )


# Generated at 2022-06-25 23:44:56.242234
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(int_0) == Lazy.of(int_0)
    assert Lazy.of(int_0) != Lazy.of(1)



# Generated at 2022-06-25 23:45:10.461633
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    tuple_0 = (1, 1, 1, 1, 1)
    tuple_1 = (2, 2, 2, 2, 2)
    tuple_2 = (3, 3, 3, 3, 3)
    tuple_3 = (4, 4, 4, 4, 4)
    tuple_4 = (5, 5, 5, 5, 5)
    tuple_5 = (6, 6, 6, 6, 6)
    tuple_6 = (7, 7, 7, 7, 7)
    tuple_7 = (8, 8, 8, 8, 8)
    tuple_8 = (9, 9, 9, 9, 9)
    tuple_9 = (10, 10, 10, 10, 10)
    lazy_0 = Lazy(tuple_0)
    lazy_1 = Lazy(tuple_1)
   

# Generated at 2022-06-25 23:45:17.805370
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_number(val):
        return val + 10

    lazy_0 = Lazy(lambda val: val).bind(add_number)
    assert lazy_0.get(2) == 12

    def raise_exception(val):
        raise Exception('test')

    lazy_1 = Lazy(lambda val: val).bind(raise_exception)
    exception = False
    try:
        lazy_1.get(2)
    except Exception as e:
        assert e.args[0] == 'test'
        exception = True

    assert exception


# Generated at 2022-06-25 23:45:20.032620
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn_0():
        return ()
    lazy_0 = Lazy(fn_0)
    value_0 = lazy_0.get()
    assert value_0 == ()


# Generated at 2022-06-25 23:45:30.018174
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Case 0:
    # Nothing to do here
    tuple_0 = (1, 2, 3, 4)
    lazy_0 = Lazy(tuple_0)
    lazy_0 = lazy_0.bind(lambda value: lazy_0)
    tuple_1 = lazy_0.get()
    assert tuple_0 == tuple_1

    # Case 1:
    # Nothing to do here
    tuple_0 = (1, 2, 3, 4)
    lazy_0 = Lazy(lambda *args: tuple_0)
    lazy_0 = lazy_0.bind(lambda value: lazy_0)
    tuple_1 = lazy_0.get()
    assert tuple_0 == tuple_1

    # Case 2:
    # Nothing to do here
    def function_0(arg_0):
        return arg_0


# Generated at 2022-06-25 23:45:40.196377
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor import Functor
    from pymonet.maybe import Maybe
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad
    from pymonet.monad_list import List
    from pymonet.monad_error import MonadError
    from pymonet.error import Error

    # Testing Functor class
    f_0 = Lazy(lambda: 1)
    assert isinstance(f_0, Functor)
    assert f_0.map(lambda x: x + 1).get() == 2

    # Testing Applicative class
    assert isinstance(f_0, Applicative)
    f_1 = Lazy(lambda: lambda x: x+1)
    f_2 = f_0.ap(f_1)
    assert f_2.get

# Generated at 2022-06-25 23:45:50.870217
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0_0 = Lazy.of(0)
    assert isinstance(lazy_0_0.bind(lambda x: Lazy.of(x)), Lazy)

    lazy_1_0 = lazy_0_0.bind(lambda x: Lazy.of(x))
    assert lazy_1_0.get() == 0

    lazy_1_1 = lazy_0_0.bind(lambda x: Lazy.of(x))
    assert lazy_1_1.is_evaluated == True

    lazy_2_0 = lazy_1_0.bind(lambda x: Lazy.of(x))
    assert lazy_2_0.get() == 0

    lazy_2_1 = lazy_1_0.bind(lambda x: Lazy.of(x))
    assert lazy_2_1.is_eval

# Generated at 2022-06-25 23:45:57.826047
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    # Test case 0: constructor_fn is a tuple
    tuple_0 = ()
    lazy_0 = Lazy(tuple_0)
    lazy_1 = lazy_0.bind(lambda value: Lazy(value))
    assert lazy_0 == lazy_1

    # Test case 1: constructor_fn is a single value
    num_1 = 100
    lazy_2 = Lazy(num_1)
    lazy_3 = lazy_2.bind(lambda value: Lazy(value))
    assert lazy_2 == lazy_3

# Generated at 2022-06-25 23:46:06.636496
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right
    from pymonet.maybe import Just, Nothing
    from pymonet.box import Box
    from pymonet.validation import Success
    from pymonet.monad_try import Try

    assert Lazy(lambda x: x + 1).ap(Right(8)) == Right(9)
    assert Lazy(lambda x: x + 1).ap(Just(3)) == Just(4)
    assert Lazy(lambda x: x + 1).ap(Nothing()) == Nothing()
    assert Lazy(lambda x: x + 1).ap(Box(3)) == Box(4)
    assert Lazy(lambda x: x + 1).ap(Success(8)) == Success(9)

# Generated at 2022-06-25 23:46:08.708642
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(5).bind(lambda x: Lazy.of(x + 1)).get() == 6
    assert Lazy.of(5).bind(lambda x: Lazy.of(x + 1)).is_evaluated is True


# Generated at 2022-06-25 23:46:13.729931
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Lazy value should return same value after mapping.

    :returns: pass or fail string
    :rtype: str
    """
    num_0 = 1
    lazy_0 = Lazy(num_0)
    bool_0 = bool(num_0)
    lazy_1 = lazy_0.map(bool_0)

    return 'passed' if lazy_0 == lazy_1 else 'failed'



# Generated at 2022-06-25 23:46:27.191259
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # given
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    import operator

    maybe_0 = Maybe(0)
    maybe_1 = Maybe(1)
    maybe_2 = Maybe(2)
    maybe_int = Maybe(int)

    lazy_0 = Lazy.of(0)
    lazy_1 = Lazy.of(1)
    lazy_2 = Lazy.of(2)
    lazy_int = Lazy.of(int)

    lazy_add = Lazy.of(operator.add)

    # when
    actual_maybe_0_result = maybe_int.ap(maybe_0).map(lazy_add.get)
    actual_maybe_1_result = maybe_int.ap(maybe_1).map(lazy_add.get)
    actual

# Generated at 2022-06-25 23:46:37.635282
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test case for Lazy class bind method.
    It's covers fold method, map and ap methods.
    """
    def add_two_to_arg(value: int) -> int:
        return value + 2

    lazy_instance_0 = Lazy(lambda x: x)
    lazy_instance_1 = lazy_instance_0.bind(lambda x: Lazy(add_two_to_arg(x))).bind(lambda x: Lazy(lambda z: z + 20))
    assert lazy_instance_0.get(10) == 10
    assert lazy_instance_1.get(20) == 42

    lazy_instance_2 = Lazy(lambda x: x).map(lambda x: x + 10)
    assert lazy_instance_2.get(10) == 20


# Generated at 2022-06-25 23:46:38.886222
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy('').__eq__(Lazy(''))



# Generated at 2022-06-25 23:46:43.735080
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    tuple_0 = ()
    lazy_0 = Lazy(tuple_0)
    tuple_1 = ()
    lazy_1 = Lazy(tuple_1)

    lazy_2 = lazy_0.ap(lazy_1)
    assert lazy_2 is not None


# Generated at 2022-06-25 23:46:52.220429
# Unit test for method get of class Lazy
def test_Lazy_get():
    iterator_0 = iter([0, 1, 2])
    tuple_0 = ()
    tuple_1 = (1,)
    tuple_2 = (2, 3)
    tuple_3 = (4,)
    tuple_4 = (5, 6)
    tuple_5 = (7,)
    tuple_6 = (8, 9)
    str_0 = next(iterator_0, None)
    str_1 = next(iterator_0, None)
    str_2 = next(iterator_0, None)
    str_3 = next(iterator_0, None)
    str_4 = next(iterator_0, None)
    str_5 = next(iterator_0, None)
    int_0 = 1
    int_1 = 2
    int_2 = 3
    int_3 = 4
    int_4 = 5

# Generated at 2022-06-25 23:46:55.719127
# Unit test for method get of class Lazy
def test_Lazy_get():
    tuple_0 = (5, 1)
    lazy_0 = Lazy(tuple_0)
    lazy_1 = lazy_0.get()
    assert lazy_1 == (5, 1)


# Generated at 2022-06-25 23:47:05.242914
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda *args: None).bind(lambda *args: Lazy(lambda *args: None)).get() is None
    assert Lazy(lambda *args: 2).bind(lambda *args: Lazy(lambda *args: 4)).get() == 4
    assert Lazy(lambda *args: 2).bind(lambda *args: Lazy(lambda *args: 4)).get() == 4
    assert Lazy(lambda *args: 2).bind(lambda _: Lazy(lambda *args: 4)).get() == 4
    assert Lazy(lambda *args: 2).bind(lambda _: Lazy(lambda _: 4)).get() == 4



# Generated at 2022-06-25 23:47:13.021716
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation

    value_0 = 1
    value_1 = 2
    
    lazy_0 = Lazy.of(value_0)
    lazy_1 = Lazy.of(value_1)

    lazy_2 = lazy_0.ap(Validation.success(lambda i: i * 2))
    assert lazy_2.get() == 2, 'lazy_2: {}, {}, {}'.format(lazy_2, lazy_0, lazy_1)

    lazy_3 = lazy_1.ap(Validation.failure([lambda i: i / 2]))
    assert lazy_3.get() == value_1, 'lazy_3: {}, {}, {}'.format(lazy_3, lazy_0, lazy_1)


# Generated at 2022-06-25 23:47:20.794726
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fct_0(*args):
        return *args

    def mapper_0(value: int) -> int:
        if value == 0:
            return 0
        return value * 2

    lazy_0 = Lazy(fct_0)

    assertion_0 = lazy_0.get(1, 2) == (1, 2)
    assertion_1 = lazy_0.get(1, 2, 3) == (1, 2, 3)
    assertion_2 = lazy_0.get(1, 2, 3, 4) == (1, 2, 3, 4)

    assert assertion_0 and assertion_1 and assertion_2


# Generated at 2022-06-25 23:47:27.369058
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def is_even(number):
        return number % 2 == 0

    def square(number):
        return number ** 2

    assert Lazy.of(1).ap(Lazy.of(is_even)).get() == False
    assert Lazy.of(2).ap(Lazy.of(is_even)).get() == True

    assert Lazy.of(5).ap(Lazy.of(square)).get() == 25


# Generated at 2022-06-25 23:47:40.117797
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Test case 0
    tuple_0 = ()
    lazy_0 = Lazy(tuple_0)
    lazy_1 = lazy_0.bind(lambda lazy_0: lazy_0)
    assert lazy_1 == lazy_0

    # Test case 1
    empty_tuple_0 = ()
    lazy_1 = Lazy(empty_tuple_0)
    lazy_2 = lazy_1.bind(lambda lazy_1: lazy_1)
    assert lazy_2 == lazy_1

    # Test case 2
    tuple_0 = ()
    lazy_2 = Lazy(tuple_0)
    lazy_3 = lazy_2.bind(lambda lazy_2: lazy_2)
    assert lazy_3 == lazy_2

    # Test case 3
    none_0 = None
    lazy_3 = Lazy

# Generated at 2022-06-25 23:47:44.026465
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    tuple_0 = ()
    tuple_1 = ()
    lazy_0 = Lazy(tuple_0)
    lazy_1 = Lazy(tuple_1)
    lazy_2 = Lazy(tuple_1)
    assert not lazy_0 == lazy_1
    assert lazy_1 == lazy_2


# Generated at 2022-06-25 23:47:53.810397
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    tuple_0 = ()
    tuple_1 = (1, 2)
    tuple_2 = (0,)
    lazy_0 = Lazy(tuple_0)
    lazy_1 = Lazy(tuple_0)
    lazy_2 = Lazy(tuple_1)
    assert lazy_0 == lazy_0
    assert lazy_1 == lazy_1
    assert lazy_2 == lazy_2
    assert lazy_0 == lazy_1
    assert lazy_0 != lazy_2
    assert lazy_1 != lazy_2
    assert Lazy(tuple_0).map(len) == Lazy(tuple_0).map(len)
    assert Lazy(tuple_0).map(len) == Lazy(tuple_0).map(len).map(len)

# Generated at 2022-06-25 23:47:57.329793
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 2).get() == 2
    assert Lazy(lambda: 3).get() == 3


# Generated at 2022-06-25 23:48:09.942772
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    mapped_value = 'value_0'
    function_0 = (lambda value_0: mapped_value)
    function_1 = (lambda value_0: function_0)
    # Test with empty Lazy
    lazy_0 = Lazy((lambda: None))
    lazy_1 = lazy_0.ap(lazy_0)
    assert lazy_0 == lazy_1, 'AssertionError: {} != {}'.format(lazy_0, lazy_1)

    # Test with Lazy without value
    lazy_2 = Lazy(function_0)
    lazy_3 = Lazy(lambda: lazy_2)
    lazy_4 = lazy_3.ap(Lazy.of('value_0'))
    assert lazy_4.get() == mapped_value, 'AssertionError: {} != {}'
    assert lazy

# Generated at 2022-06-25 23:48:14.389138
# Unit test for method get of class Lazy
def test_Lazy_get():
    tuple_0 = ()
    tuple_1 = (1,)
    lazy_0 = Lazy(tuple_0)

    assert lazy_0.get() == tuple_0

    assert Lazy(lambda x: x).get(tuple_1) == tuple_1


# Generated at 2022-06-25 23:48:20.209214
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Init some value
    value_0 = 'a'
    value_1 = 'b'
    value_2 = 'c'

    lazy_0 = Lazy.of(value_0 + value_1)
    lazy_1 = Lazy.of(value_2)

    # Call ap method
    lazy_2 = lazy_0.ap(lazy_1)

    assert lazy_2.get() == (value_0 + value_1) + value_2


# Generated at 2022-06-25 23:48:28.729381
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test(expected, f, x):
        res = Lazy(x).bind(f)
        assert res.get() == expected
        assert res.is_evaluated
        def lambda_fn(*args):
            return f(x()).constructor_fn(*args)
        assert res.constructor_fn == lambda_fn

    test(0, lambda x: Lazy.of(x + 3), lambda: 0)
    test(3, lambda x: Lazy.of(x + 3), lambda: 0)
    test(6, lambda x: Lazy.of(x * 3), lambda: 2)
    test(11, lambda x: Lazy.of(x + 10), lambda: 1)
    test(0, lambda x: Lazy.of(x[0] + 3), lambda: (0,))

# Generated at 2022-06-25 23:48:32.862940
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    tuple_0 = ()
    lazy_0 = Lazy(tuple_0)
    assert lazy_0.ap(Lazy.of(lambda x: x)) == Lazy.of(tuple_0)
    assert lazy_0.ap(Lazy.of(1)) == Lazy.of(tuple_0)


# Generated at 2022-06-25 23:48:33.934118
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    pass



# Generated at 2022-06-25 23:48:46.334333
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add_10(x):
        return x + 10

    def throw_error():
        raise ValueError('Bad Error')

    assert Lazy(add_10).get(12) == 22
    assert Lazy(add_10).get(10000) == 10010
    assert Lazy(throw_error).get() == Lazy(throw_error).get()



# Generated at 2022-06-25 23:48:47.977728
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 0).get() == 0



# Generated at 2022-06-25 23:48:52.003941
# Unit test for method map of class Lazy
def test_Lazy_map():
    tuple_0 = (1, 2, 3)
    lazy_0 = Lazy(tuple_0)

    def mapper(value):
        return list(value)
    list_0 = [1, 2, 3]
    lazy_1 = lazy_0.map(mapper)
    assert lazy_1.get() == list_0


# Generated at 2022-06-25 23:48:55.034807
# Unit test for method map of class Lazy
def test_Lazy_map():
    result = Lazy.of('string').map(str.upper)
    assert result.get() == 'STRING'



# Generated at 2022-06-25 23:49:00.222160
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    lazy_0 = Lazy.of(1)
    lazy_1 = Lazy.of(2)
    lazy_2 = Lazy.of(3)
    lazy_3 = Lazy.of(4)
    assert not lazy_0 == lazy_1
    assert not lazy_0 == lazy_2
    assert not lazy_0 == lazy_3
    assert not lazy_1 == lazy_2
    assert not lazy_1 == lazy_3
    assert not lazy_2 == lazy_3


# Generated at 2022-06-25 23:49:09.131606
# Unit test for method get of class Lazy
def test_Lazy_get():
    def case_0():
        def fn_0():
            return 'Test lazy_0'

        lazy_0 = Lazy(fn_0)
        result_0 = lazy_0.get()

        assert result_0 == 'Test lazy_0'

    def case_1():
        def fn_0():
            raise Exception('Test exception')

        lazy_0 = Lazy(fn_0)
        result_0 = lazy_0.get()
        lazy_1 = Lazy(fn_0)
        result_1 = lazy_1.get()

        assert result_0 == result_1

    def case_2():
        def fn_0():
            return "Test lazy_0"

        lazy_0 = Lazy(fn_0)
        result_0 = lazy_0.get()
        result_1 = lazy_0

# Generated at 2022-06-25 23:49:16.211747
# Unit test for method get of class Lazy
def test_Lazy_get():
    def side_effect(*args):
        side_effect.num_call += 1
        return 1

    side_effect.num_call = 0
    lazy_0 = Lazy(side_effect)
    lazy_0.get()
    assert(side_effect.num_call == 1)
    assert(lazy_0.is_evaluated)
    assert(lazy_0.value == 1)
    assert(side_effect.num_call == 1)



# Generated at 2022-06-25 23:49:18.069874
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(10).get() == 10
    assert Lazy(lambda: 10).get() == 10



# Generated at 2022-06-25 23:49:24.682536
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    tuple_0 = ()
    lazy_0 = Lazy(tuple_0)
    maybe_0 = Maybe.just(True)
    maybe_1 = Maybe.empty()
    validation_0 = Validation.success(True)
    validation_1 = Validation.failure([])
    def foo_0(*args):
        def foo_1(*args):
            return args[0]
        return foo_1
    tuple_1 = (lazy_0, maybe_0, maybe_1, validation_0, validation_1, foo_0)
    lazy_1 = Lazy(tuple_1)
    maybe_2 = Maybe.just(lazy_1)
    lazy_2 = maybe_2.ap(lazy_0)
    lazy_3 = lazy_2.bind(foo_0)
    assert lazy_3

# Generated at 2022-06-25 23:49:35.051797
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy(lambda: 10)
    list_0 = list()
    fn_0 = lambda x: Lazy(lambda: list_0.append(x))

    ret_0 = lazy_0.bind(fn_0).get()

    assert ret_0 is None
    assert list_0 == [10]


    lazy_1 = Lazy(lambda: 20)
    list_1 = list()
    fn_1 = lambda x: Lazy(lambda: list_1.append(x))

    ret_1 = lazy_1.bind(fn_1).get()

    assert ret_1 is None
    assert list_1 == [20]


    lazy_2 = Lazy(lambda: 30)
    list_2 = list()

# Generated at 2022-06-25 23:49:54.359900
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert (Lazy.of(False).get() == False)
    assert (Lazy.of("TEST").get() == "TEST")
    assert (Lazy.of("TEST").get("TEST2") == "TEST")



# Generated at 2022-06-25 23:50:07.484308
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__(): # pragma: no cover
    from pymonet.box import Box

    value_0 = 'foo'
    value_1 = 'bar'

    lazy_0 = Lazy.of(value_0)
    lazy_1 = Lazy.of(value_1)
    lazy_2 = Lazy.of(value_0)

    assert lazy_0 == lazy_2
    assert lazy_0 != lazy_1

    assert lazy_0.map(lambda v: Box(v)) == lazy_2.map(lambda v: Box(v))
    assert lazy_0.map(lambda v: Box(v)) != lazy_1.map(lambda v: Box(v))

    assert lazy_0 == Lazy.of(lazy_0)
    assert lazy_0 != Lazy.of(lazy_1)


# Generated at 2022-06-25 23:50:17.893357
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.validation import Validation
    from functools import partial
    import uuid

    # generate unique strings
    unique_string = str(uuid.uuid1())
    unique_string_2 = str(uuid.uuid1())

    # simpler way to construct lazy
    lazy_instance = Lazy.of(unique_string)

    # check that get method returns unique string
    assert unique_string == lazy_instance.get()

    # get method should be called only once and then return a memoized value
    assert unique_string == lazy_instance.get()

    # validate that get method can be curried on argument
    lazy_instance_2 = Lazy.of(unique_string_2)
    partial_fn = partial(lazy_instance_2.get)
    assert partial_fn() == unique_string_

# Generated at 2022-06-25 23:50:24.379234
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy(10)
    fn_0 = lambda x: Lazy(str(x))
    a_0 = lazy_0.bind(fn_0)
    assert a_0 == Lazy(fn_0(10))
    lazy_1 = Lazy(20)
    fn_1 = lambda x: Lazy(str(x))
    a_1 = lazy_1.bind(fn_1)
    assert a_1 == Lazy(fn_1(20))

