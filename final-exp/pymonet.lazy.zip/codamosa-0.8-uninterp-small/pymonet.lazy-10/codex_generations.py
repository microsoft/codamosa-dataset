

# Generated at 2022-06-25 23:40:34.031915
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    lazy_0 = Lazy(dict_0)
    lazy_1 = Lazy(dict_1)
    lazy_2 = Lazy(dict_2)
    lazy_3 = Lazy(dict_2)
    assert lazy_0 == lazy_1
    assert lazy_1 == lazy_0
    assert lazy_2 == lazy_3
    assert lazy_3 == lazy_2



# Generated at 2022-06-25 23:40:38.266629
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 42).get() == 42
    assert Lazy(lambda: 40 + 2).get() == 42
    assert Lazy(lambda: 40 - 2).get() == 38
    assert Lazy(lambda: 40 + 2).map(lambda x: x - 10).get() == 32


# Generated at 2022-06-25 23:40:45.766104
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def func_0(a0: int) -> Lazy[int, int]:
        return Lazy.of(a0)

    dict_0 = {}
    lazy_0 = Lazy.of(dict_0)
    lazy_1 = Lazy(func_0)
    lazy_2 = lazy_1.bind(lazy_0)
    lazy_3 = lazy_2.bind(lambda a0:Lazy.of(func_0(a0)))
    assert lazy_3.get() == dict_0



# Generated at 2022-06-25 23:40:46.861999
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    check_eq_function(Lazy, Lazy, 2)


# Generated at 2022-06-25 23:40:50.465712
# Unit test for method map of class Lazy
def test_Lazy_map():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    lazy_0.map(lambda arg_0: {})
    lazy_1 = Lazy(dict_0)
    lazy_1.map(lambda arg_0: {})



# Generated at 2022-06-25 23:41:00.272233
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    lazy_0 = Lazy(dict_0)
    lazy_1 = Lazy(dict_1)
    lazy_2 = Lazy(dict_2)
    lazy_3 = Lazy(dict_3)

    lazy_1.is_evaluated = True
    lazy_1.value = dict_1

    lazy_2.is_evaluated = True
    lazy_2.value = dict_2

    assert lazy_0 == lazy_1
    assert lazy_1 == lazy_2
    assert lazy_2 == lazy_3

    lazy_0.is_evaluated = True
    lazy_0.value = dict_0

    assert lazy_0 == lazy_1
    assert lazy_1 == lazy_2


# Generated at 2022-06-25 23:41:02.235973
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    dict_0 = {}
    lazy_0 = Lazy(dict_0)
    lazy_1 = Lazy(dict_0)
    assert lazy_1 == lazy_0, "'assert' failed"


# Generated at 2022-06-25 23:41:05.354854
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_1 = Lazy(lambda: None)
    lazy_2 = Lazy(lambda: 1)
    assert lazy_1 == lazy_1
    assert lazy_2 == lazy_2
    assert lazy_1 != lazy_2


# Generated at 2022-06-25 23:41:13.255009
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != 1
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1).bind(lambda x: Lazy.of(x + 1)) == Lazy(lambda: 1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy(lambda: 1).bind(lambda x: Lazy.of(x + 1)) != Lazy(lambda: 2).bind(lambda x: Lazy.of(x + 1))
    assert Lazy(lambda: 1).bind(lambda x: Lazy.of(x + 1)) != Lazy(lambda: 1).bind(lambda x: Lazy.of(x + 2))

# Generated at 2022-06-25 23:41:16.073802
# Unit test for method get of class Lazy
def test_Lazy_get():
    dict_0 = {'otas': 'o', 'otas_': 'd'}
    lazy_0 = Lazy.of(dict_0)

    assert lazy_0.get() == dict_0



# Generated at 2022-06-25 23:41:26.974753
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    
    int_0 = Lazy(lambda *args: 2)
    add_int_0 = lambda x: Lazy(lambda *args: x + 2)
    def add_int(x, y):
        return Lazy(lambda *args: x + y)

    assert int_0.bind(add_int_0).get() == 4
    assert int_0.bind(lambda x: add_int(x, 2)).get() == 4
    assert int_0.bind(lambda x: Lazy(lambda *args: Box(x + 2))).get().get() == 4
    assert int_0.bind(lambda x: Box(x + 2)).get().get() == 4

# Generated at 2022-06-25 23:41:35.235925
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # test bind function
    int_0 = 2
    int_2 = 3

    def mapper(x): return x + 2

    def case_Lazy_0():
        lazy_0 = Lazy.of(int_0)
        fn_0 = lambda x: Lazy.of(x + 2)
        lazy_2 = lazy_0.bind(fn_0)

        assert lazy_2.get() == mapper(int_0)

    def test_case_0():
        lazy_0 = Lazy.of(int_0)

# Generated at 2022-06-25 23:41:40.813191
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 2
    int_1 = 3
    Lazy_0 = Lazy.of(int_0)
    Lazy_1 = Lazy.of(int_1)
    def lambda_0(int_0):
        return Lazy_1
    Lazy_2 = Lazy_0.bind(lambda_0)
    int_2 = Lazy_2.get()

    assert int_2 == int_1, "Expected int_2 == int_1"


# Generated at 2022-06-25 23:41:42.555406
# Unit test for method get of class Lazy
def test_Lazy_get():
    int_5 = 5
    lazy = Lazy.of(int_5)
    
    assert lazy.get() == int_5



# Generated at 2022-06-25 23:41:52.140061
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn_0(constructor_fn, is_evaluated, value):
        return Lazy(constructor_fn).__eq__(Lazy(constructor_fn)) and Lazy(constructor_fn).is_evaluated == is_evaluated and Lazy(constructor_fn).value == value
    assert (
        fn_0(lambda *args: None, True, None)
        and fn_0(lambda *args: args[0], True, [1, 2, 3])
        and fn_0(lambda *args: args[1], True, [4, 5, 6])
        and fn_0(lambda *args: args[2], True, [7, 8, 9])
    )


# Generated at 2022-06-25 23:41:55.260709
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_a = Lazy.of("Hello")
    lazy_b = Lazy.of("World")
    lazy_c = Lazy.of("Hello")

    assert lazy_a != lazy_b
    assert lazy_a == lazy_c

# Generated at 2022-06-25 23:41:58.258343
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = Lazy.of(0)
    int_1 = Lazy.of(1)
    assert int_0 == Lazy.of(0)
    assert int_0 != int_1
    assert int_0 != Lazy(lambda v: v)


# Generated at 2022-06-25 23:42:05.543015
# Unit test for method map of class Lazy
def test_Lazy_map():
    def f(x):
        return x*2

    def f2(x):
        return x*3

    lazy_f = Lazy(f)
    lazy_f2 = lazy_f.map(f2)

    assert(lazy_f2.get(2) == 12)


# Generated at 2022-06-25 23:42:07.195786
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2



# Generated at 2022-06-25 23:42:18.792873
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_int(int_a):
        return Lazy(lambda: int_a + 1)

    def add_two_ints(int_a, int_b):
        return Lazy(lambda: int_a + int_b)

    int_0 = 0
    int_1 = 1
    int_2 = 2

    assert Lazy.of(int_0).bind(add_int).get() == int_1
    assert Lazy.of(int_0).bind(add_int).bind(add_int).get() == int_2
    assert Lazy.of(int_0).bind(lambda int_a: Lazy(lambda: int_a)).get() == int_0
    assert Lazy.of(int_0).bind(lambda int_a: Lazy(lambda: int_a)) == Lazy.of

# Generated at 2022-06-25 23:42:23.790693
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2


# Generated at 2022-06-25 23:42:25.646432
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(7).__eq__(Lazy.of(7)) == True

# Generated at 2022-06-25 23:42:31.909066
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x:x).__eq__(Lazy(lambda x:x)) == True
    assert Lazy(lambda x:x).__eq__(Lazy(lambda x:x+1)) == False
    assert Lazy(lambda x:x+1).__eq__(Lazy(lambda x:x+2)) == False
    assert Lazy(lambda x:x).__eq__(Lazy(lambda x:x)) == True


# Generated at 2022-06-25 23:42:35.598148
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = 2

    def lambda_fn_0(int_0=2):
        return int_0

    lazy_0 = Lazy.of(int_0)
    lazy_1 = Lazy(lambda_fn_0)
    assert (lazy_0 == lazy_1)



# Generated at 2022-06-25 23:42:41.817292
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy.of(lambda x: lambda y: x + y)
    assert lazy_0.ap(Lazy.of(lambda x: x)).get()(1) == 2
    assert lazy_0.ap(Lazy.of(lambda x: x)).get()(2) == 3
    assert lazy_0.ap(Lazy.of(lambda x: x)).get()(3) == 4
    lazy_1 = Lazy.of(lambda x: lambda x: x + x)
    assert lazy_1.ap(Lazy.of(lambda x: x)).get()(1) == 2
    assert lazy_1.ap(Lazy.of(lambda x: x)).get()(2) == 4
    assert lazy_1.ap(Lazy.of(lambda x: x)).get()(3) == 6
   

# Generated at 2022-06-25 23:42:45.885750
# Unit test for method map of class Lazy
def test_Lazy_map():
    def sum(x, y):
        return x + y

    assert (Lazy(sum).map(lambda x: x + 5).get(2, 3) == 10)
    assert (Lazy(sum).map(lambda x: x + 0).get(2, 3) == 5)


# Generated at 2022-06-25 23:42:47.833643
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy.of(int_0)
    assert(lazy_0 == lazy_0)


# Generated at 2022-06-25 23:42:50.155859
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 2).ap(Lazy.of(1)) == Lazy.of(3)


# Generated at 2022-06-25 23:43:00.039420
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    assert Functor.will_be_functor(Lazy, 'bind')
    assert Applicative.will_be_applicative(Lazy, 'bind')
    assert Monad.will_be_monad(Lazy, 'bind')

    x = Lazy(lambda: 5)
    assert x.bind(lambda x: Lazy.of(x)).get() == 5
    lazy_value = Lazy.of(5)
    assert lazy_value.bind(lambda x: Lazy.of(x * 3)).get() == 15
    assert lazy_value.bind(Lazy.of).to_box().get() == 5


# Generated at 2022-06-25 23:43:10.840075
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_validation import Validation

    int_result = 42
    dummy_mapper = lambda int_param: int(int_param) + 1
    lazy_instance = Lazy(lambda int_param: int(int_param) + 1)
    validation_box_d_result = Validation.of(lazy_instance, 42)
    lazy_instance_d_result = Lazy(lambda int_param: int(int_param) + 1)
    lazy_instance_d_result.constructor_fn = dummy_mapper
    lazy_instance_d_result.value = int_result
    lazy_instance_d_result.is_evaluated = False

    assert lazy_instance.ap(validation_box_d_result) == lazy_instance_d_result


# Generated at 2022-06-25 23:43:18.910606
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: '2').map(lambda v: int(v)) == Lazy(lambda: int('2'))



# Generated at 2022-06-25 23:43:22.795004
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = 2
    int_1 = 3
    fn_0 = lambda int_1: int_1 * 3
    lazy_0 = Lazy.of(int_0)
    lazy_1 = Lazy.of(int_1)
    lazy_2 = lazy_0.ap(lazy_1)
    assert lazy_2.get() == 6


# Generated at 2022-06-25 23:43:34.464582
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # data for test
    int_0 = 2
    bool_0 = True
    string_0 = 'string_0'
    list_0 = [int_0, bool_0]
    list__0 = [string_0, list_0, Lazy.of(int_0), Lazy.of(bool_0)]
    tuple_0 = (int_0, bool_0)
    tuple_1 = (string_0, list_0, Lazy.of(int_0), Lazy.of(bool_0))
    tuple_2 = (tuple_1, tuple_0, list_0, Lazy.of(tuple_0))

    # testing methods of class Lazy
    assert Lazy.of(int_0).bind(lambda x: Lazy.of(x)).constructor_fn() == int_0

# Generated at 2022-06-25 23:43:43.496426
# Unit test for method map of class Lazy
def test_Lazy_map():
    import operator

    assert Lazy.of(1).map(lambda x: x+1).get() == 2
    assert Lazy.of(1).map(lambda x: x+2).get() == 3
    assert Lazy.of(1).map(lambda x: x+3).get() == 4
    assert Lazy.of('a').map(lambda x: x+'b').get() == 'ab'
    assert Lazy.of('a').map(lambda x: x+'c').get() == 'ac'
    assert Lazy.of('a').map(lambda x: x+'d').get() == 'ad'
    assert Lazy.of(1).map(lambda x: x+1).map(operator.mul(2, 2)).get() == 4

# Generated at 2022-06-25 23:43:50.807385
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 2
    int_1 = 3
    int_2 = 10
    def fn_0(x):
        def fn_1(y):
            def fn_2(z):
                return x + y + z
            return fn_2
        return Lazy(fn_1)
    lazy_0 = Lazy(lambda: int_0)
    lazy_1 = lazy_0.bind(fn_0)
    assert isinstance(lazy_1, Lazy)
    assert lazy_0.get() == 2
    assert lazy_1.get(int_1) == 5
    assert lazy_1.get(int_2) == 12


# Generated at 2022-06-25 23:43:57.598349
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test case for bind method.
    """
    int_0 = 2
    fn_0 = lambda x: x * x
    int_1 = fn_0(int_0)

    lazy_0 = Lazy(fn_0)

    assert lazy_0.bind(lambda x: Lazy.of(x + 1)).get(int_0) == int_1 + 1



# Generated at 2022-06-25 23:44:04.305719
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1).__eq__(Lazy.of(1))
    assert not (Lazy.of(1).__eq__(Lazy.of(2)))
    assert not (Lazy.of(1).__eq__(None))
    assert Lazy.of(1).__eq__(Lazy.of(1))
    assert not (Lazy.of(1).__eq__(Lazy.of(2)))
    assert not (Lazy.of(1).__eq__(None))


# Generated at 2022-06-25 23:44:08.140452
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    test case #1
    """
    int_0 = 2

    lazy_0 = Lazy.of(int_0)

    lazy_1 = lazy_0.bind(lambda arg_0: Lazy.of(arg_0 * int_0))

    assert lazy_1.get() == 4


# Generated at 2022-06-25 23:44:10.049583
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)

    assert not Lazy.of(1) == Lazy.of(2)



# Generated at 2022-06-25 23:44:12.609926
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x).map(lambda x: x + 2) == Lazy(lambda x: x + 2)



# Generated at 2022-06-25 23:44:27.338103
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 2
    int_2 = 3

    # Scenario 0
    lazy_0 = Lazy(lambda *args: int_0)
    lazy_1 = lazy_0.map(lambda value: int_2 + value)
    assert lazy_1.get() == int_2 + int_0

    # Scenario 1
    lazy_0 = Lazy(lambda *args: int_0).map(lambda value: int_2 + value)
    assert lazy_0.get() == int_2 + int_0

    # Scenario 2
    lazy_0 = Lazy(lambda *args: int_0).map(lambda value: int_2 + value).map(lambda value: int_2 + value)
    assert lazy_0.get() == int_2 + int_2 + int_0


# Generated at 2022-06-25 23:44:29.740632
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(1).ap(Lazy.of(lambda x: x + 1)).get() == 2, "Lazy ap method failed"
    

# Generated at 2022-06-25 23:44:34.053837
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Input:
    arg_0 = Lazy.of(lambda x: x + 3)
    arg_1 = Lazy.of(5)

    # Call method:
    result = arg_0.ap(arg_1)

    # Test:
    assert type(result) == Lazy
    assert result.constructor_fn(None) == 8
    assert not result.is_evaluated


# Generated at 2022-06-25 23:44:44.097837
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0: int = 1
    int_1: int = 2
    int_2: int = 3

    fn_0: Callable[[int], int] = lambda x: x + int_0
    fn_1: Callable[[int], int] = fn_0 if int_2 == int_1 else lambda x: x + int_2
    
    test_Lazy_0 = Lazy(lambda x: x + int_0)
    test_Lazy_1 = Lazy(lambda x: x + int_1)
    test_Lazy_2 = Lazy(lambda x: x + int_2)
    test_Lazy_3 = test_Lazy_1.map(fn_0)
    test_Lazy_4 = test_Lazy_1.map(fn_1)
    test_Lazy_5

# Generated at 2022-06-25 23:44:53.980249
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    _lazy_of_int_0 = Lazy.of(2)
    _lazy_of_int_1 = Lazy.of(3)
    _lazy_of_int_2 = Lazy.of(7)

    _lazy_1 = _lazy_of_int_0.bind(lambda int_0:
                                  _lazy_of_int_1.bind(lambda int_1:
                                                      _lazy_of_int_2.bind(lambda int_2:
                                                                          Lazy.of(int_0 + int_1 + int_2))))
    print('_lazy_1: {}'.format(_lazy_1))

# Generated at 2022-06-25 23:44:56.492759
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy(lambda: int_0)
    lazy_1 = Lazy(lambda: int_0)
    result_0 = lazy_0 == lazy_1
    assert result_0


# Generated at 2022-06-25 23:44:58.915773
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    value = 2
    string = "2"
    lazy = Lazy.of(value)
    fn = lambda a: Lazy.of(string)
    assert lazy.bind(fn) == Lazy.of(string)

# Generated at 2022-06-25 23:45:05.303574
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test class method ap - function applies a function to an applicative value.
    """
    assert Lazy.of(lambda x: x).ap(Lazy.of(2)).get() == 2
    assert Lazy.of(lambda x: x).ap(Lazy.of(2).map(lambda x: x + 2)).get() == 4
    assert Lazy.of(lambda x: x).ap(Lazy.of(2).map(lambda x: x + 1)).get() == 3


# Generated at 2022-06-25 23:45:09.386005
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    test_case_0()
    int_0 = Lazy(lambda *args: 2)
    int_1 = Lazy(lambda *args: 3)
    int_2 = Lazy(lambda *args: 2)
    assert int_0 != int_1
    assert int_0 == int_2



# Generated at 2022-06-25 23:45:13.055551
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_fn = Lazy(lambda x: lambda y: x * y)
    lazy_value = Lazy(lambda: 2)
    assert lazy_value.ap(lazy_fn).get() == 4


# Generated at 2022-06-25 23:45:22.599904
# Unit test for method map of class Lazy
def test_Lazy_map():
    u = Lazy.of(2)

    result = u.map(lambda x: x + 2)
    assert (result == Lazy(lambda: 4))


# Generated at 2022-06-25 23:45:33.880711
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.validation import Validation

    def fn_0(a):
        return a

    def fn_1(a):
        return a

    arg_0 = Lazy.of(1)
    arg_1 = Lazy.of(1)
    arg_2 = Lazy.of(1)
    arg_3 = Lazy.of(Box.of(1))
    arg_4 = Lazy.of(Validation.success(1))
    arg_5 = Lazy.of(1)
    arg_6 = Lazy.of(1)
    arg_7 = Lazy.of(2)

    assert arg_0.__eq__(arg_1)
    assert arg_0.__eq__(arg_2)
    assert arg_0.__eq

# Generated at 2022-06-25 23:45:38.184776
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_maybe import Maybe

    int_0 = 2
    fn_0 = Maybe.just(Lazy.of(2).bind(Maybe.just)).get()
    int_1 = Maybe.just(Maybe.just(int_0)).bind(Maybe.just).get()
    assert fn_0 == int_1



# Generated at 2022-06-25 23:45:44.810126
# Unit test for method map of class Lazy
def test_Lazy_map():
    val_int_0 = Lazy.of(2)
    assert val_int_0.map(lambda x: x * 2).get() == 4
    assert val_int_0.map(lambda x: x * 2).value is None
    assert val_int_0.map(lambda x: x * 2).is_evaluated is False
    assert val_int_0.map(lambda x: x * 2).constructor_fn is not None
    assert callable(val_int_0.map(lambda x: x * 2).constructor_fn)
    assert val_int_0.map(lambda x: x * 2).constructor_fn(test_case_0) == 4
    assert val_int_0.map(lambda x: x * 2).is_evaluated is False
    assert val_int_0.value is None

# Generated at 2022-06-25 23:45:51.729364
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = 2
    int_1 = 3

    fn_0 = lambda int_0: int_0 + 1
    fn_1 = lambda int_0: int_0 * 2

    lazy_0 = Lazy.of(fn_0)
    lazy_1 = Lazy.of(int_1)

    assert lazy_0.ap(lazy_1).get(int_0) == fn_0(int_1)

# Generated at 2022-06-25 23:45:57.068326
# Unit test for method map of class Lazy
def test_Lazy_map():

    int_0 = 0
    int_1 = 1
    def func_0(int_p: int) -> int:
        return int_p + int_0

    class_0 = Lazy(func_0)
    class_1 = class_0.map(func_0)
    class_2 = class_1.map(func_0)

    return class_2.get(int_1)



# Generated at 2022-06-25 23:46:01.792467
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Tests the bind method of Lazy monad class.
    """

    int_0 = 0
    int_2 = 2

    assert_that(
        Lazy(lambda: int_0).bind(lambda int_1: Lazy(lambda: int_2)).get()
    ) \
        .is_equal_to(int_2)


# Generated at 2022-06-25 23:46:05.997660
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from random import random

    # Given
    final_value = Box(random())
    lazy_object = Lazy(lambda: final_value)

    # When
    result = lazy_object.bind(lambda value: Lazy.of(value))

    # Then
    assert result == Lazy(lambda: final_value.get())



# Generated at 2022-06-25 23:46:13.728402
# Unit test for method map of class Lazy
def test_Lazy_map():
    def double_fn(a):
        return a * 2

    Lazy_double = Lazy.of(2).map(double_fn)
    assert Lazy_double.get() == 4

    # Test of map in map
    Lazy_double_double = Lazy_double.map(double_fn)
    assert Lazy_double_double.get() == 8

    # Test of map in map in map
    Lazy_double_double_double = Lazy_double_double.map(double_fn)
    assert Lazy_double_double_double.get() == 16

    # Test of map in map in map in map
    Lazy_double_double_double_double = Lazy_double_double_double.map(double_fn)
    assert Lazy_double_double_double_double.get() == 32

#

# Generated at 2022-06-25 23:46:23.442201
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 2
    int_1 = 3
    int_2 = 4
    int_5 = 5
    string_0 = "sample string"

    def sum_function(int_0, int_1):
        return int_0 + int_1

    def multiply_function(int_0, int_1):
        return int_0 * int_1

    def compare_function(int_0):
        return int_0 < int_2

    def divide_function(int_0, int_1):
        return int_0 / int_1
    if True:
        Lazy_0 = Lazy.of(int_0)
        Lazy_1 = Lazy.of(int_1)
        Lazy_2 = Lazy.of(int_2)

# Generated at 2022-06-25 23:46:35.451791
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # Lazy[Int]
    int_lazy = Lazy.of(2)

    # Lazy[Int -> Int]
    multiply_1_lazy = Lazy.of(lambda x: x * 1)
    multiply_2_lazy = Lazy.of(lambda x: x * 2)
    # Lazy[Int -> Maybe[Int]]
    multiply_3_maybe_lazy = Lazy.of(lambda x: Maybe.just(x * 3))
    # Lazy[Int -> Try[Int]]
    multiply_4_try_lazy = Lazy.of(lambda x: Try.of(lambda x: x * 4))
    # Lazy[Int -> Validation

# Generated at 2022-06-25 23:46:46.105904
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Either
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn1(x):
        return x + 2

    def test_fn2(x):
        return x * 2

    def test_fn3(x):
        return Maybe.just(x)

    def test_fn4(x):
        return Try.of(lambda: x)

    lazy = Lazy(lambda: 1)
    result = lazy.bind(lambda x: Lazy(lambda: x + 2))
    assert result.get() == 3

    result = lazy.bind(test_fn1)
    assert result.get() == 3


# Generated at 2022-06-25 23:46:53.775126
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover

    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.pair import Pair
    from pymonet.validation import Validation

    # testing method bind for empty lazy

    lazy_0 = Lazy(lambda: None)
    assert lazy_0.bind(lambda x: Lazy.of(1)) == Lazy.of(None)

    # testing method bind with 1 argument of class Lazy
    lazy_0 = Lazy.of(None)
    assert lazy_0.bind(lambda x: Lazy.of(1)) == Lazy.of(1)

    # testing method bind with many arguments of class Lazy
    lazy_0 = Lazy.of(None)

# Generated at 2022-06-25 23:46:56.207878
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy1 = Lazy(lambda: int_0)
    lazy2 = Lazy(lambda: int_0 + 1)
    assert lazy1.bind(lambda x: lazy2) == lazy2

# Generated at 2022-06-25 23:47:02.112692
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given
    def is_positive(num):
        return num > 0

    def abs_value(num):
        return abs(num)

    def to_box(bool_value):
        from pymonet.box import Box
        return Box(bool_value)

    lazy = Lazy.of(-2).map(abs_value).map(is_positive).map(to_box)

    # When
    result = lazy.get()

    # Then
    assert isinstance(result, Box)
    assert result.get() is True


# Generated at 2022-06-25 23:47:09.110856
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = Lazy.of(2).ap(Lazy.of(lambda x: x + 2))
    int_1 = Lazy(lambda _: 2).ap(Lazy(lambda _: lambda x: x + 2))
    assert int_0.get() == int_1.get() == 4


# Generated at 2022-06-25 23:47:19.050087
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    def is_even(value):
        return value % 2 == 0

    assert Lazy.of(5).ap(Lazy.of(is_even)) == Lazy.of(False)
    assert Lazy.of(4).ap(Lazy.of(is_even)) == Lazy.of(True)

    assert Lazy.of(5).ap(Lazy.of(Box(is_even))) == Lazy.of(Box(False))
    assert Lazy.of(4).ap(Lazy.of(Box(is_even))) == Lazy.of(Box(True))


# Generated at 2022-06-25 23:47:22.692021
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = Lazy(lambda : 2)

    int_1 = Lazy(lambda x: x + 3)

    assert int_0.ap(int_1).get() == 5



# Generated at 2022-06-25 23:47:26.201166
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(2).map(lambda x: x * 2).get() == 4
    assert Lazy.of(3).map(lambda x: x * 2).get() == 6


# Generated at 2022-06-25 23:47:28.745917
# Unit test for method map of class Lazy
def test_Lazy_map():
    import pymonet.lazy as lazy
    assert lazy.Lazy(lambda x: x * 2).map(lambda x: x + 1).get(3) == 7

# Generated at 2022-06-25 23:47:38.782357
# Unit test for method map of class Lazy
def test_Lazy_map():
    def _map(x):
        return x * 2

    lazy = Lazy.of(1)
    expected = Lazy(_map(1))
    actual = lazy.map(_map)
    assert expected == actual



# Generated at 2022-06-25 23:47:40.190983
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = Lazy.of(90).map(lambda x: x + 1)
    return int_0


# Generated at 2022-06-25 23:47:49.172201
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = 2
    int_1 = 1
    int_5 = 5

    def add_five(x: int) -> int:
        return x + 5

    def add_four(x: int) -> int:
        return x + 4

    add_five_to_four = Lazy.of(add_five).ap(Lazy.of(add_four))
    assert add_five_to_four.get() == 9


# Generated at 2022-06-25 23:47:59.796562
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    int_0 = 2
    int_1 = 4
    int_2 = 6
    int_3 = 8
    int_4 = 10
    int_5 = 12

    int_fn_0 = Lazy.of(lambda x: x + 1).ap(Lazy.of(int_0))
    res_0 = int_fn_0.get()

    assert res_0 == int_1, 'result of ap method of Lazy was "{}", but we expect "{}"'.format(res_0, int_1)

    int_fn_1 = Lazy.of(lambda x: x + 1).ap(Lazy.of(int_1))
    res_1 = int_fn_1.get()


# Generated at 2022-06-25 23:48:10.684448
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.utils import is_even, is_positive

    def composed(x):
        return is_even(x) and is_positive(x)

    box_0 = Box(42)
    box_1 = Lazy.of(42)
    box_2 = Lazy.of(composed)
    box_3 = box_1.ap(box_2)

    test_case_0()
    assert box_0.ap(box_2).get() == composed(42)
    assert box_1.ap(box_0).get() == composed(42)
    assert box_1.ap(box_2).get() == composed(42)
    assert box_1.ap(box_2).get() == box_3.get()



# Generated at 2022-06-25 23:48:18.076801
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    int_0 = Lazy.of(2)
    int_1 = Lazy.of(3)
    int_2 = Lazy.of(4)

    int_0.get()
    int_1.get()
    int_2.get()

    assert int_0 == int_0
    assert int_1 == int_1
    assert int_2 == int_2

    assert not int_0 == int_1
    assert not int_0 == int_2
    assert not int_0 == None



# Generated at 2022-06-25 23:48:22.741541
# Unit test for method map of class Lazy
def test_Lazy_map():
    int_0 = 2
    inc_fn = lambda n: n + 1
    multiply_fn = lambda n: n * 2
    lazy_0 = Lazy(inc_fn)
    lazy_1 = lazy_0.map(multiply_fn)
    assert(lazy_1.get(int_0) == (int_0 + 1) * 2)


# Generated at 2022-06-25 23:48:28.879909
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Case:
    # Creates a Lazy(3 + _) and applies it to Lazy(5)
    #
    # Expected result:
    # Lazy(8)

    int_0 = 2

    lazy_0 = Lazy.of(2)
    lazy_1 = Lazy.of(1)

    lazy_2 = lazy_0.bind(
        lambda value_0: lazy_1.map(
            lambda value_1: value_0 + value_1
        )
    )

    assert lazy_2.get() == int_0



# Generated at 2022-06-25 23:48:38.052601
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    #Given
    from pymonet.monad_maybe import Maybe

    int_0 = Lazy.of(2)
    int_1 = Lazy.of(2)
    int_2 = Lazy.of(3)
    int_3 = Lazy.of(3)
    int_4 = Lazy.of(5)

    #When
    actual_value_0 = int_0.bind(lambda x: int_1.bind(lambda y: int_2.bind(lambda z: Lazy.of(x + y + z))))
    #Then
    expected_value_0 = Lazy.of(7)
    assert (expected_value_0 == actual_value_0)

    #When

# Generated at 2022-06-25 23:48:47.581953
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    int_0 = 2
    int_1 = 3

    def sum_int(*args) -> int:
        return sum(*args)

    def identity_int(value: int) -> Lazy[int, int]:
        return Lazy(lambda: value)

    assert (Lazy(lambda: int_0).bind(identity_int).get() == int_0)
    assert (Lazy(lambda: int_0).bind(lambda x: Lazy(lambda: x + int_1)).get() == int_0 + int_1)
    assert (Lazy(lambda: int_0).bind(identity_int).bind(identity_int).get() == int_0)

# Generated at 2022-06-25 23:48:57.509110
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    with pytest.raises(AssertionError):
        # Calling function bind without argument
        Lazy.of(int_0).bind()

    # Binding empty Lazy with constructor_fn(A) -> B should return Lazy with constructor_fn(A) -> B
    assert Lazy.of(int_0).bind(lambda x: Lazy(lambda: x * int_0)).get() == 4



# Generated at 2022-06-25 23:49:05.580482
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def l_plus1(n):
        print("l_plus1")
        return n + 1

    def l_plus2(n):
        print("l_plus2")
        return n + 2

    def l_plus3(n):
        print("l_plus3")
        return n + 3

    def l_plus4(n):
        print("l_plus4")
        return n + 4

    assert Lazy(lambda _: 0).bind(lambda a: Lazy(lambda _: a + 1)).get() == 1
    assert Lazy(lambda _: 0).bind(lambda a: Lazy(lambda _: a + 1)).bind(lambda a: Lazy(lambda _: a + 1)).get() == 2

# Generated at 2022-06-25 23:49:15.004426
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def increment(a):
        return a + 1

    def double(a):
        return a * 2

    def to_lazy(a):
        from pymonet.maybe import Maybe
        return Lazy.of(Maybe.just(a))

    lazy_value = Lazy.of(2)
    assert lazy_value.bind(to_lazy).bind(lambda maybe_value: maybe_value.map(increment)).bind(lambda maybe_value: maybe_value.map(double)).get() == 6

    assert lazy_value.bind(lambda a: Lazy.of(increment(a))).bind(lambda a: Lazy.of(double(a))).get() == 6


# Generated at 2022-06-25 23:49:22.869571
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_0 = Lazy.of(int_0)
    lazy_1 = Lazy.of(int_0)

    assert(lazy_0 is not lazy_1)

    lazy_2 = lazy_1.bind(lambda x: Lazy.of(x))

    assert(lazy_2 is not lazy_1)
    assert(lazy_2 is not lazy_0)

    lazy_3 = lazy_2.bind(lambda x: Lazy.of(x))

    assert(lazy_3 is not lazy_2)
    assert(lazy_3 is not lazy_1)
    assert(lazy_3 is not lazy_0)

    lazy_4 = lazy_1.bind(lambda x: Lazy.of(x))

    assert(lazy_4 is not lazy_1)

# Generated at 2022-06-25 23:49:28.478452
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Maybe

    lazy = Lazy(lambda x: int(x * 10))
    mapped_lazy = lazy.map(lambda x: str(x))

    assert mapped_lazy.get(2) == '20'

    lazy = Lazy.of(10)
    mapped_lazy = lazy.map(lambda x: Maybe.just(x))
    assert mapped_lazy.get() == Maybe.just(10)
    assert mapped_lazy is not lazy



# Generated at 2022-06-25 23:49:38.874601
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    def add_2_fn(value):
        return Right(value + 2)

    def maybe_fn(value):
        if value >= 0:
            return Maybe(value)
        return Maybe(None)

    def add_2_then_maybe(value):
        add_2_bound_value = Lazy(value).bind(add_2_fn).get()
        return maybe_fn(add_2_bound_value)

    # Test add_2_then_maybe with negative value and ensure that returned value will be None
    assert add_2_then_maybe(-100) == None, 'Must return None'

    # Test add_2_then_maybe with positive value and ensure that returned value will be equal to add value + 2
    assert add_2_

# Generated at 2022-06-25 23:49:51.148711
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: int_0) == Lazy(lambda: int_0)
    assert Lazy(lambda: int_0) != Lazy(lambda: int_1)
    assert Lazy(lambda: int_0) != Lazy(lambda: int_0)()
    assert Lazy() != Lazy(lambda: int_0)()
    assert Lazy() != Lazy(lambda: None)
    assert Lazy(lambda: str_0) != Lazy(lambda: str_1)
    assert Lazy(lambda: str_0) != Lazy(lambda: None)
    assert Lazy(lambda: str_0) != None
    assert Lazy(lambda: float_0) != Lazy(lambda: float_1)
    assert Lazy(lambda: float_0) != Lazy(lambda: None)
    assert L

# Generated at 2022-06-25 23:49:56.814429
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_fn = Lazy.of(lambda x: x * 2)

    double_lazy_fn = lazy_fn.bind(lambda double: Lazy.of(lambda x: double + x))
    multiply_by_10_fn = double_lazy_fn.bind(lambda double_plus: Lazy.of(lambda x: double_plus * x))

    assert multiply_by_10_fn.get(3) == 60
    assert multiply_by_10_fn.get(5) == 100



# Generated at 2022-06-25 23:50:08.789872
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Lazy(lambda x: x * 2).ap(Box.of(lambda x: x + 2)) == Lazy(lambda x: (x + 2) * 2)
    assert Lazy(lambda x: x * 2).ap(Maybe.just(lambda x: x + 2)) == Lazy(lambda x: (x + 2) * 2)
    assert Lazy(lambda x: x * 2).ap(Validation.success(lambda x: x + 2)) == Lazy(lambda x: (x + 2) * 2)
    assert Lazy(lambda x: x * 2).ap(Lazy(lambda x: x + 2)).get(3) == 10


# Generated at 2022-06-25 23:50:18.685037
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.applicative_functor import ApplicativeFunctor
    from pymonet.monad import Monad

    def test_Lazy_as_Functor(value):
        assert isinstance(value, Lazy)
        assert isinstance(value, Functor)

    def test_Lazy_as_ApplicativeFunctor(value):
        assert isinstance(value, Lazy)
        assert isinstance(value, ApplicativeFunctor)

    def test_Lazy_as_Monad(value):
        assert isinstance(value, Lazy)
        assert isinstance(value, Monad)

    def test_method_map(value, mapper):
        value.map(mapper)
