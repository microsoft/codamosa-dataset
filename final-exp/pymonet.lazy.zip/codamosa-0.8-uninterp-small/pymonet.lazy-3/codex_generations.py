

# Generated at 2022-06-25 23:40:32.076540
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    lazy_0_value = lazy_0.get()
    if lazy_0_value != float_0:
        raise Exception('test exception "%s" != "%s"' % (lazy_0_value, float_0))


# Generated at 2022-06-25 23:40:33.328903
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(float) == Lazy(float)


# Generated at 2022-06-25 23:40:43.760704
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_float_0 = Lazy(float(0))
    assert (lazy_float_0.get() == float(0))
    assert (lazy_float_0.get() == float(0))
    assert (lazy_float_0.get() == float(0))
    assert (lazy_float_0.get() == float(0))

    lazy_float_1 = Lazy(lambda: float(0))  # lambda
    assert (lazy_float_1.get() == float(0))
    assert (lazy_float_1.get() == float(0))
    assert (lazy_float_1.get() == float(0))
    assert (lazy_float_1.get() == float(0))


# Generated at 2022-06-25 23:40:50.805855
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right

    string_0 = 'HEY THERE!'
    string_1 = 'HEY THERE!'
    integer_0 = 430
    float_0 = -479.0
    float_1 = -597.0
    float_2 = -818.0
    float_3 = -613.0
    float_4 = -83.0
    float_5 = -433.0
    lazy_0 = Lazy.of(Right(string_1))
    float_6 = lazy_0.get(float_0, float_3)
    list_0 = []
    float_7 = float_1
    float_8 = float_6
    float_9 = float_2
    float_10 = float_8
    float_11 = float_5
    float_12 = float_9
   

# Generated at 2022-06-25 23:41:00.479827
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    maybe_float_0 = Maybe.of(float())
    maybe_float_1 = Maybe.of(float(1))
    maybe_float_2 = Maybe.of(float(2))
    maybe_float_3 = Maybe.of(float(3))

    # Maybe<float> -> Lazy<float>
    lazy_float_0 = maybe_float_0.to_lazy()
    # Maybe<float> -> Lazy<float> -> Lazy<float>
    lazy_lazy_float_0 = lazy_float_0.map(lambda __1: lazy_float_0)
    #

# Generated at 2022-06-25 23:41:04.200690
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add(a, b):
        return a + b

    lazy_1 = Lazy.of(1)
    lazy_1_mapped = lazy_1.map(add)

    assert Lazy.of(2) == lazy_1_mapped(1)



# Generated at 2022-06-25 23:41:10.163561
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    lazy_1 = Lazy(float_0)
    lazy_2 = Lazy(float_0)
    assert lazy_0 == lazy_1
    assert lazy_0.constructor_fn == lazy_1.constructor_fn
    assert lazy_0 is not lazy_1
    assert not lazy_0 == lazy_2
    assert lazy_0 is not lazy_2
# End unit test for method __eq__


# Generated at 2022-06-25 23:41:19.383739
# Unit test for method get of class Lazy
def test_Lazy_get():

    # Test case 0
    assert Lazy(lambda: 'test0').get() == 'test0'
    # Test case 1
    assert Lazy(lambda: -253.0).get() == -253.0
    # Test case 2
    assert Lazy(lambda: 0).get() == 0
    # Test case 3
    assert Lazy(lambda: '').get() == ''
    # Test case 4
    assert Lazy(lambda: -1).get() == -1
    # Test case 5
    assert Lazy(lambda: 0.0).get() == 0.0
    # Test case 6
    assert Lazy(lambda: 'nonempty string').get() == 'nonempty string'
    # Test case 7
    assert Lazy(lambda: False).get() == False
    # Test case 8

# Generated at 2022-06-25 23:41:29.735004
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(1).__eq__(Lazy(1)), "Lazy(1) == Lazy(1)"
    assert not Lazy(2).__eq__(Lazy(1)), "not Lazy(2) == Lazy(1)"
    assert not Lazy(1).__eq__(Lazy(2)), "not Lazy(1) == Lazy(2)"
    assert not Lazy(1).__eq__(Lazy(2).map(lambda x: x)), "not Lazy(1) == Lazy(2).map(lambda x: x)"
    assert not Lazy(2).__eq__(Lazy(1).map(lambda x: x)), "not Lazy(2) == Lazy(1).map(lambda x: x)"

# Generated at 2022-06-25 23:41:36.651171
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    float_0 = -253.0
    float_1 = 6665.0
    float_2 = float_0 / float_1
    lazy_0 = Lazy.of(float_2).bind(Lazy.of, float_0)
    assert lazy_0.is_evaluated
    assert lazy_0.value == float_0


# Generated at 2022-06-25 23:41:46.766254
# Unit test for method get of class Lazy
def test_Lazy_get():
    class ConstantFloat(float):

        def __new__(cls, value):
            return super(ConstantFloat, cls).__new__(cls, value)

        def __add__(self, other):
            return super().__add__(other)

    float_0 = ConstantFloat(1.1)
    float_1 = float_0
    float_0 = float_1
    float_1 = float_0
    float_0 = -1.1
    lazy_0 = Lazy.of(float_0)
    float_1 = lazy_0.get()

    assert float_1 == float(-1.1)


# Generated at 2022-06-25 23:41:54.871779
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()


# Generated at 2022-06-25 23:42:01.357021
# Unit test for method get of class Lazy
def test_Lazy_get():
    # test for case: (float_0 == (Lazy(float_0).get()))
    float_0 = -253.0
    assert (float_0 == (Lazy(float_0).get()))

    # test for case: (float_0 == (Lazy(float_0).get(1)))
    float_0 = -253.0
    assert (float_0 == (Lazy(float_0).get(1)))

    # test for case: (float_0 == (Lazy(float_0).get(1, 2)))
    float_0 = -253.0
    assert (float_0 == (Lazy(float_0).get(1, 2)))

    # test for case: (str_0 == (Lazy(str_0).get()))
    str_0 = 'Hello World!'

# Generated at 2022-06-25 23:42:11.409771
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    assert lazy_0.get() == -253.0

    long_0 = long(9223372036854775807)
    lazy_1 = Lazy.of(long_0)
    assert lazy_1.get() == 9223372036854775807

    int_0 = int(-2147483648)
    lazy_2 = Lazy.of(int_0)
    assert lazy_2.get() == -2147483648

    float_1 = float(649.1188)
    lazy_3 = Lazy.of(float_1)
    assert lazy_3.get() == 649.1188

    str_0 = 'FpWxD23{yK'

# Generated at 2022-06-25 23:42:15.240226
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    lazy_1 = lazy_0.bind(Lazy.of)
    assert lazy_0 == lazy_1



# Generated at 2022-06-25 23:42:20.873968
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(273.0) == Lazy.of(273.0)
    assert Lazy.of(273.0) != Lazy.of(273)
    assert Lazy.of(273.0) != Lazy.of(273.1)
    assert Lazy.of(273.0) == Lazy.of(273.0+0.0)


# Generated at 2022-06-25 23:42:32.128021
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # Basic data for testing
    float_0 = -253.0
    lazy_0 = Lazy(float_0)

    # Testing with True
    assert (lazy_0 == Lazy(float_0))

    # Testing with False
    assert (lazy_0 != float_0)

    float_1 = float_0
    lazy_1 = Lazy(float_1)

    # Testing with True
    assert (lazy_0 == lazy_1)

    # Testing with False
    assert (lazy_0 != float_1)

    float_2 = float_0
    lazy_2 = Lazy(float_2)

    # Testing with True
    assert (lazy_0 == lazy_2)

    # Testing with False
    assert (lazy_0 != float_2)

    float_3 = float_0

# Generated at 2022-06-25 23:42:35.481103
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_0 = Lazy.of(lambda x: x  + 4)
    lazy_1 = Lazy.of(lambda y: y  + 5)
    lazy_3 = lazy_0.ap(lazy_1)
    assert lazy_3.get() == 9

# Generated at 2022-06-25 23:42:39.702635
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    float_0 = -253.0
    lazy_0 = Lazy(float_0)

    int_0 = 313
    lazy_1 = Lazy(int_0)

    lazy_2 = lazy_1.bind(lambda *args: lazy_0)
    assert lazy_2.get() == lazy_0.get()
    assert lazy_0.is_evaluated
    assert not lazy_1.is_evaluated


# Generated at 2022-06-25 23:42:41.658491
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(5).bind(lambda a: Lazy.of(a + 7)).get() == 12


# Generated at 2022-06-25 23:42:48.997965
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Create data for test
    float_0 = -253.0
    lazy_0 = Lazy.of(float_0)

    # Create function for test
    def lambda_0(x):
        return float(x)

    # Call method
    lazy_1 = lazy_0.map(lambda_0)

    # Check result of call method
    assert lazy_1.constructor_fn() == float(float_0)


# Generated at 2022-06-25 23:42:59.347537
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    float_0 = -253.0
    lazy_0 = Lazy(float_0)

    float_1 = 805.0
    lazy_1 = Lazy(float_1)

    float_2 = 0.0
    lazy_2 = Lazy(float_2)

    float_3 = -407.0
    lazy_3 = Lazy(float_3)

    def f_4(arg_0: float) -> Lazy[float, float]:
        return Lazy(arg_0)

    lazy_4 = lazy_0.ap(lazy_1).ap(lazy_2).ap(lazy_3).bind(f_4)

    assert lazy_4.is_evaluated == False
    assert lazy_4.value == None
    assert lazy_4.constructor_fn == float_0


#

# Generated at 2022-06-25 23:43:03.714028
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    def mapper_0(arg_0):
        return arg_0

    def mapper_1(arg_0: float):
        return int(arg_0)

    def mapper_2(arg_0: int):
        return float(arg_0)

    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    result_0 = lazy_0.bind(mapper_0)
    result_1 = result_0.bind(mapper_1)
    result_2 = result_1.bind(mapper_2)
    assert result_2 == Lazy(float)

# Generated at 2022-06-25 23:43:06.315673
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    assert lazy_0.get() == -253.0


# Generated at 2022-06-25 23:43:15.946695
# Unit test for method ap of class Lazy

# Generated at 2022-06-25 23:43:19.340111
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(1) == Lazy(1)
    assert Lazy(1) != Lazy(2)
    assert Lazy(1) != Lazy.of(1)
    assert Lazy(1) != Lazy.of(2)


# Generated at 2022-06-25 23:43:21.152204
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_0 = Lazy(lambda: 10)
    r0 = lazy_0.get()
    assert r0 == 10


# Generated at 2022-06-25 23:43:24.626248
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    float_1 = lazy_0.get()
    assert abs(float_1 - (-253.0)) <= 0.0001


# Generated at 2022-06-25 23:43:32.513743
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Test 0
    float_0 = -71.853029
    float_1 = float_0
    lazy_0 = Lazy.of(float_0)
    float_2 = float_0
    float_3 = float_0

    def fn_0(arg_0):
        return - arg_0
    lazy_1 = lazy_0.map(fn_0)

    assert lazy_1.get() == float_1 * -1 and lazy_0.get() == float_1

# Generated at 2022-06-25 23:43:42.142808
# Unit test for method map of class Lazy
def test_Lazy_map():
    float_0 = -253.0
    float_1 = float_0
    fn0 = lambda value_0, value_1: value_0 + value_1
    float_2 = float_1
    float_3 = float_2
    float_4 = float_3
    float_5 = float_4
    float_6 = float_5
    str_0 = '-253'
    fn1 = str_0.split
    str_1 = str_0
    str_2 = str_1
    str_3 = str_2
    str_4 = str_3
    str_5 = str_4
    str_6 = str_5
    str_7 = str_6
    fn4 = str_7.split
    str_8 = str_7
    str_9 = str_8
    str_

# Generated at 2022-06-25 23:43:46.470697
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    assert lazy_0.get() == float_0


# Generated at 2022-06-25 23:43:54.592151
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    float_0 = -253.0
    float_1 = -253.0
    float_2 = float_0
    float_3 = -253.0
    float_4 = float_2
    float_5 = float_4
    int_0 = 0
    lazy_0 = Lazy(float_0)
    lazy_1 = Lazy(float_5)
    lazy_2 = Lazy(int_0)
    lazy_3 = lazy_1.bind(lazy_2)
    bool_0 = isinstance(lazy_3, Lazy)
    assert(not bool_0)


# Generated at 2022-06-25 23:44:03.998787
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Variables
    float_0 = -253.0
    float_1 = -251.0
    float_2 = 254.0
    bool_0 = bool
    lazy_0 = Lazy(float_0)
    lazy_1 = Lazy(float_1)
    lazy_2 = Lazy(float_2)
    fn_0 = lambda x : lazy_1.__mul__(x)
    fn_1 = lambda x : lazy_2.__add__(x)
    # Function under test
    lazy_0.bind(fn_0).bind(fn_1).get()
    # Check results
    assert(lazy_0.get() != float_0)


# Generated at 2022-06-25 23:44:08.798209
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = -9.394681630641102e+37
    assert_equal(Lazy.of(0.0).get(), 0.0)
    assert_equal(Lazy.of(0.0).get(), 0.0)
    assert_equal(Lazy.of(float_0).get(), float_0)
    assert_equal(Lazy.of(float_0).get(), float_0)


# Generated at 2022-06-25 23:44:13.226428
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    float_0 = -1.0
    float_1 = -1.0
    lazy_0 = Lazy(float_0)
    lazy_1 = Lazy(float_1)
    lazy_2 = Lazy(float_0)
    assert(lazy_0 == lazy_1 == lazy_2)


# Generated at 2022-06-25 23:44:17.797062
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    lazy_0_get = lazy_0.get()
    assert float_0 == lazy_0_get
    # Verify that Lazy value is memoized
    assert float_0 == lazy_0.get()


# Generated at 2022-06-25 23:44:24.716125
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test if bind method of Lazy class works correctly.

    """
    # Test if bind method bind correctly two classes: Lazy and Box.
    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    lazy_1 = lazy_0.map(lambda float_arg_0: float_arg_0 * float_arg_0)
    float_1 = float_0 * float_0
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.get() == float_1


# Generated at 2022-06-25 23:44:27.733600
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Arrange
    float_0 = -253.0
    lazy_0 = Lazy(float_0)

    # Act
    # Assert
    assert lazy_0.get() == float_0


# Generated at 2022-06-25 23:44:29.784249
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    lazy_1 = Lazy(float_0)

    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:44:34.099238
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda : False).map(lambda x: x).get() == False
    assert Lazy(lambda : 10).map(lambda x: x + 10).get() == 20
    assert Lazy(lambda : [False]).map(lambda x: x).get() == [False]
    assert Lazy(lambda : [4]).map(lambda x: x + 6).get() == [10]


# Generated at 2022-06-25 23:44:47.393785
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    def function_lazy_0(arg_0: float) -> Maybe[float]:
        return Maybe.just(arg_0)
    lazy_1 = lazy_0.bind(function_lazy_0)

    float_1 = -253.0
    lazy_2 = Lazy(float_1)
    def function_lazy_1(arg_0: float) -> Maybe[float]:
        return Maybe.nothing()
    lazy_3 = lazy_2.bind(function_lazy_1)

    int_0 = -13
    lazy_4 = Lazy(int_0)

# Generated at 2022-06-25 23:44:50.446737
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Given
    def f_square(x):
        return x ** 2

    float_a = 2.0
    lazy_a = Lazy(float_a)
    
    # When
    lazy_ab = lazy_a.bind(f_square)
    
    # Result
    float_b = lazy_a.get() ** 2
    assert float_b is lazy_ab.get()


# Generated at 2022-06-25 23:44:58.462800
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    # case: empty Lazy
    def divide_by_2(x):
        return Try(lambda _: x // 2)
    def multiply_by_2(x):
        return Box(x * 2)
    lazy_1 = Lazy(0)
    assert lazy_1.bind(divide_by_2) == Lazy.of(Try(lambda _: 0 // 2))
    assert lazy_1.bind(divide_by_2).bind(multiply_by_2) == Lazy.of(Box(0))

    # case: non empty Lazy
    def divide_by(a, b):
        return Try(lambda _: a // b)

# Generated at 2022-06-25 23:45:01.270370
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def inc(x: float) -> Lazy[float, float]:
        return Lazy(lambda _: x + 1)

    double_inc = inc(2.1).bind(inc).get()

    assert double_inc == 4.1


# Generated at 2022-06-25 23:45:04.321663
# Unit test for method map of class Lazy
def test_Lazy_map():
    value_0 = Lazy(23)
    value_1 = value_0.map(lambda x: x * 4)

    assert value_1.get() == 92

# Generated at 2022-06-25 23:45:06.382511
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = -253.0
    assert Lazy(float_0).get() == -253.0


# Generated at 2022-06-25 23:45:16.749465
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def sum_five_and_two(x):
        return x + 2
    
    def fn_return_5(int_):
        return 5
    
    lazy_ap = Lazy(fn_return_5).ap(Lazy(fn_return_5))
    assert lazy_ap.get() == 10
    
    #Another example
    five_lazy = Lazy(5)
    two_lazy = Lazy(2)
    
    add_two_lazy = Lazy(sum_five_and_two)
    result_lazy = add_two_lazy.ap(five_lazy)
    assert result_lazy.get() == 7
    
    # Another example naive implementation
    add_five_lazy = Lazy(lambda x: x + 5)

# Generated at 2022-06-25 23:45:22.815240
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    float_0 = -253.0
    float_1 = float_0
    lazy_0 = Lazy(float_0)
    lazy_1 = Lazy(float_1)
    # AssertionError: assert <__main__.Lazy object at 0x7fb2aa0f7908> == <__main__.Lazy object at 0x7fb2aa0f7898>
    assert lazy_0 == lazy_1
    str_0 = '<instance of `Lazy`, Wrapping: <function Lazy.__init__.<locals>.<lambda> at 0x7fb2aa0f7400> at 0x7fb2aa2ec268>'
    # str_1 = '<instance of `Lazy`, Wrapping: <function Lazy.__init__.<locals>.<lambda> at 0x7fb2

# Generated at 2022-06-25 23:45:32.966533
# Unit test for method map of class Lazy
def test_Lazy_map():
    float_0 = -253.0
    float_1 = float_0 / float_0
    lazy_0 = Lazy(float_0)
    lazy_0._compute_value()
    assert lazy_0.value == float_0
    lazy_1 = Lazy.of(float_0)
    assert lazy_1.get == float_0
    lazy_2 = lazy_1.map(lambda arg: arg / arg)
    assert lazy_2.get() == float_1
    lazy_3 = Lazy.of(float_0)
    lazy_4 = lazy_3.map(lambda arg: arg / arg)
    assert lazy_4.get() == float_1


# Generated at 2022-06-25 23:45:35.618364
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    float_0 = -253.0
    lazy_0 = Lazy(float_0)
    assert(lazy_0 == Lazy(float_0))



# Generated at 2022-06-25 23:45:41.594781
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    test_value = Lazy.of(float_0)
    float_1 = float_0 * float_0 * float_0 * float_0 * float_0 * float_0 * float_0 * float_0 * float_0 * float_0

    return test_value.ap(Lazy.of(float_1))


# Generated at 2022-06-25 23:45:53.140828
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    float_0 = 2.1
    float_1 = 2.2
    float_2 = 2.3
    lazy_0 = Lazy.of(float_0)
    lazy_1 = Lazy.of(float_0)
    lazy_2 = Lazy.of(float_1)
    lazy_3 = Lazy.of(float_2)

    assert lazy_0 == lazy_0
    assert lazy_0 == lazy_1
    assert lazy_0 != lazy_2
    assert lazy_0 != lazy_3
    lazy_0.get()
    lazy_1.get()
    assert lazy_0 == lazy_0
    assert lazy_0 == lazy_1
    assert lazy_0 != lazy_2
    assert lazy_0 != lazy_3
    lazy_2.get()
    assert lazy_0 != lazy_

# Generated at 2022-06-25 23:45:56.014451
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    


# Generated at 2022-06-25 23:46:00.109019
# Unit test for method get of class Lazy
def test_Lazy_get():
    result_float = Lazy.of(2.1).get()
    assert float_0 == result_float
    result_int = Lazy.of(1).get()
    assert 1 == result_int
    result_none = Lazy.of(None).get()
    assert None == result_none


# Generated at 2022-06-25 23:46:08.187376
# Unit test for method map of class Lazy
def test_Lazy_map():
    # given
    float_0 = 2.1
    float_1 = 5.1
    float_2 = 10.1
    float_2_string = '10.1'
    float_2_string_empty = ''
    float_2_string_empty_number = 0

    def create_lazy_lazy(lazy):
        def inner(*args):
            return lazy
        return Lazy(inner)

    def create_string_from_float(float_to_convert):
        return str(float_to_convert)

    # when
    instance_float_0 = Lazy.of(float_0)
    instance_float_1 = Lazy.of(float_1)
    instance_float_2 = Lazy.of(float_2)
    instance_float_2_string = Lazy.of

# Generated at 2022-06-25 23:46:15.825638
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    # Asserts on Lazy vith constructor_fn returning float
    float_2 = Lazy(lambda: float(2))

    test_case_0()

    float_2_bind = float_2.bind(lambda x: Lazy.of(x))
    assert float_2 == float_2_bind

    float_2_1 = float_2.bind(lambda x: Lazy.of(x + 0.1))
    assert float_2_1 != float_2

    float_2_1_bind = float_2_1.bind(lambda x: Lazy.of(x))
    assert float_2_1 == float_2_1_bind

# Generated at 2022-06-25 23:46:24.847133
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def function_a(a):
        return a * 2

    def function_b(a):
        return Lazy.of(a * 3)

    def function_c(a):
        return a * 4

    def function_d(a):
        return a * 5

    def test_case_0():
        test_a = Lazy.of(2).bind(function_a).bind(function_b).bind(function_c)
        assert test_a.get() == 24

    def test_case_1():
        test_b = Lazy.of(2.1).bind(function_a).bind(function_b).bind(function_c)
        assert test_b.get() == 25.2

    test_case_0()
    test_case_1()


# Generated at 2022-06-25 23:46:29.963305
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    def half(x):
        return x / 2

    def add_three(x):
        return x + 3

    def add_0_5(x):
        return x + 0.5

    result = Lazy.of(float_0).bind(half).bind(add_three).bind(add_0_5)

    assert result.get() == (float_0 / 2 + 3 + 0.5)

# Generated at 2022-06-25 23:46:40.940018
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = 2.1
    lazy_tuple = Lazy(lambda x: (1, x))
    assert lazy_tuple.get(float_0) == (1, float_0)
    lazy_tuple = Lazy(lambda x: (x, 1))
    assert lazy_tuple.get(float_0) == (float_0, 1)
    lazy_tuple = Lazy(lambda x: (1, x))
    assert lazy_tuple.get(float_0) == (1, float_0)
    lazy_tuple = Lazy(lambda x: (x, 1))
    assert lazy_tuple.get(float_0) == (float_0, 1)
    lazy_tuple = Lazy(lambda x: (1, x))

# Generated at 2022-06-25 23:46:43.417416
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_0 = Lazy.of(float_0)
    assert lazy_0 == lazy_0
    assert lazy_0 != None


# Generated at 2022-06-25 23:46:48.527710
# Unit test for method map of class Lazy
def test_Lazy_map():
    def int_to_float(x: int) -> float:
        return float(x)

    lazy = Lazy.of(1)

    assert(lazy.map(int_to_float) == Lazy.of(float(1)))


# Generated at 2022-06-25 23:46:52.928168
# Unit test for method ap of class Lazy
def test_Lazy_ap(): #pragma: no cover
    def add_1(x):
        return x + 1
    float_0 = 2.1
    input_0 = Lazy(lambda : float_0) 
    applicative = Lazy(add_1)
    expected_0 = Lazy(lambda: add_1(float_0))
    actual_0 = input_0.ap(applicative)
    assert actual_0 == expected_0


# Generated at 2022-06-25 23:47:02.000262
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_case_0():
        float_0 = 2.1
        Lazy_0 = Lazy.of(float_0)
        float_1 = Lazy_0.get()
        assert float_1 == float_0
        float_2 = Lazy_0.get()
        assert float_2 == float_1
        assert float_2 == float_0
    def test_case_1():
        float_0 = 2.1
        Lazy_0 = Lazy(lambda: float_0)
        float_1 = Lazy_0.get()
        assert float_1 == float_0
        float_2 = Lazy_0.get()
        assert float_2 == float_1
        assert float_2 == float_0
    test_case_0()
    test_case_1()
# Unit test

# Generated at 2022-06-25 23:47:09.890835
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Given
    float_0 = 2.1
    def f_builder():
        def f(x):
            return Lazy.of(float_0 * x)
        return f
    f = f_builder()
    # When
    computed_lazy = Lazy.of(2).bind(f)
    # Then
    assert computed_lazy == Lazy.of(float_0 * 2)



# Generated at 2022-06-25 23:47:11.988111
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of("").map(lambda x: x + " world").get() == " world"



# Generated at 2022-06-25 23:47:21.953373
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
        float_0: float = 2.1
        float_1: float = 3.1
        float_2: float = float_0 + float_1

        lazy_0: Lazy[float, float] = Lazy.of(float_0)
        lazy_1: Lazy[float, float] = Lazy.of(float_1)

        lazy_2: Lazy[float, float] = lazy_0.bind(lambda val_0:
                                         lazy_1.bind(lambda val_1: Lazy.of(float_2)))
    """
    float_0 = 2.1
    float_1 = 3.1
    float_2 = float_0 + float_1

    lazy_0 = Lazy.of(float_0)
    lazy_1 = Lazy.of(float_1)
   

# Generated at 2022-06-25 23:47:26.670867
# Unit test for method get of class Lazy
def test_Lazy_get():
    # given:
    float_0 = 2.1

    # when:
    float_1 = Lazy.of(float_0).get()

    # then:
    assert float_1 == float_0
    assert Lazy.of(float_0).is_evaluated


# Generated at 2022-06-25 23:47:30.740715
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe

    def double_or_zero(val):
        return Maybe.just(val * 2) if val % 2 == 0 else Maybe.nothing(0)

    lazy = Lazy.of(2).bind(double_or_zero)

    assert lazy.get() == 4



# Generated at 2022-06-25 23:47:38.094922
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    >>> test_case_0()
    >>> float_0 = 2.1
    >>> Lazy.of("Hello").map(lambda x: float(x)).map(lambda x: x > 2).get()
    False
    >>> Lazy.of("Hello").map(lambda x: float(x)).map(lambda x: x > 2).map(lambda x: not x).get()
    True
    >>> Lazy.of("Hello").map(lambda x: float(x)).map(lambda x: x > 2).map(lambda x: "a" if x else "b").get()
    'b'
    """



# Generated at 2022-06-25 23:47:42.372510
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    map method creates new Lazy monad with mapper function and constructor function
    """
    def double(x: float) -> float:
        return x * 2

    # GIVEN
    lazy_0 = Lazy.of(2.1)

    # WHEN
    lazy_1 = lazy_0.map(double)

    # THEN
    assert lazy_0 != lazy_1
    assert lazy_1.constructor_fn is not None
    assert lazy_1.constructor_fn() == 4.2


# Generated at 2022-06-25 23:47:48.787404
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = 0.0
    float_1 = Lazy.of(float_0).get()
    float_2 = float_1
    assert float_1 == float_2
    float_3 = Lazy.of(float_0).get()
    float_4 = float_3
    assert float_3 == float_4


# Generated at 2022-06-25 23:47:58.536506
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # Arrange
    float_0 = 2.1
    test_obj_0 = Lazy.of(float_0)
    test_obj_1 = Lazy.of(float_0)
    test_obj_2 = Lazy.of(float_0)

    # Act
    result_0 = test_obj_0.__eq__(test_obj_1)
    result_1 = test_obj_2.__eq__(test_obj_0)
    result_2 = test_obj_1.__eq__(test_obj_0)

    # Assert
    assert result_0 is True
    assert result_1 is True
    assert result_2 is True


# Generated at 2022-06-25 23:48:10.042447
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.maybe import Just
    #Get result of Lazy with function returning abc value
    assert Lazy.of("abc").get() == 'abc'

    # Get result of Lazy with lambda returning abc value
    assert Lazy(lambda: "abc").get() == 'abc'

    # Get result of Lazy with constructor returning abc value
    assert Lazy(lambda: "abc").get() == 'abc'

    # Get result of Lazy with lambda returning abc value
    assert Lazy(lambda: "abc").get() == 'abc'

    # Get result of Lazy with lambda returning lambda returning abc value
    assert Lazy(lambda: lambda: "abc").get()() == 'abc'

    # Get result of Lazy with lambda returning def value
    assert Lazy(lambda: "def").get() == 'def'



# Generated at 2022-06-25 23:48:16.556476
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    float_0 = Lazy(lambda: 2.1)
    float_1 = Lazy(lambda: float_0.get() + 2.1)
    fn_0 = lambda x: x * 2
    float_2 = Lazy(fn_0)
    float_3 = float_2.ap(float_1)
    float_4 = float_3.get()
    float_5 = 8.4
    assert bool(float_4 == float_5)


# Generated at 2022-06-25 23:48:20.356197
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = 2.1
    def function_0(float_1=float_0):
        return float_1
    lazy_0 = Lazy(function_0)
    float_2 = lazy_0.get()
    assert(float_2 == float_0)


# Generated at 2022-06-25 23:48:26.339758
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Test constant and id functions
    assert Lazy.of(2.1).bind(lambda x: Lazy.of(x)) == Lazy.of(2.1)

    # Test bind with some operations
    test_Lazy = Lazy.of(3)
    test_Lazy = test_Lazy.bind(lambda x: Lazy.of(x + x))
    test_Lazy = test_Lazy.bind(lambda x: Lazy.of(x + 1))
    assert test_Lazy == Lazy.of(7)



# Generated at 2022-06-25 23:48:35.822954
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # When Lazy is evaluated and have another value then instance of class Lazy
    lazy = Lazy(lambda: float_0)
    lazy_clone = Lazy(lambda: float_0)
    assert lazy is not lazy_clone
    assert lazy != lazy_clone

    # When Lazy is not evaluated then must be equal
    lazy = Lazy(lambda: float_0)
    lazy_clone = Lazy(lambda: float_0)
    assert lazy is not lazy_clone
    assert lazy == lazy_clone

    # When Lazy is evaluated and have same value and constructor function then must be equal
    lazy = Lazy(lambda: float_0)
    lazy.get()
    lazy_clone = Lazy(lambda: float_0)
    lazy_clone.get()
    assert lazy is not lazy_clone
    assert lazy == lazy_clone



# Generated at 2022-06-25 23:48:41.847939
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Test case #0
    float_0 = Lazy.of(2.1)
    assert float_0.get() == 2.1

    # Test case #1
    def fn():
        return 2.1
    float_0 = Lazy(fn)
    assert float_0.get() == 2.1

    # Test case #2
    def fn(x):
        return 2.1
    float_0 = Lazy(fn)
    assert float_0.get(2) == 2.1


# Generated at 2022-06-25 23:48:51.089839
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def check_case(lazy_func: Lazy, value: float) -> bool:
        lazy_target = Lazy.of(value)
        result = lazy_target.ap(lazy_func)
        return value == result.get()

    def square(x: float) -> float:
        return x * x

    lazy_mapper = Lazy.of(square)

    # case 0 - check square function
    assert check_case(lazy_mapper, 0)
    assert check_case(lazy_mapper, 1.0)
    assert check_case(lazy_mapper, 4.5)
    assert check_case(lazy_mapper, 1.2234)
    assert check_case(lazy_mapper, 23.34)

# Generated at 2022-06-25 23:48:54.757263
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def double(value):
        return Lazy.of(value * 2)

    lazy = Lazy(lambda: 8)

    assert lazy.bind(double).get() == 16


# Generated at 2022-06-25 23:49:03.796593
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def test_case_1():
        float_0 = 2.1
        func_0 = lambda: float_0
        lazy_0 = Lazy(func_0)
        lazy_1 = Lazy(func_0)
        assert lazy_0 == lazy_1
        float_0 = 4.2
        assert lazy_0 != lazy_1

    def test_case_2():
        float_0 = 2.1
        func_0 = lambda: float_0
        lazy_0 = Lazy(func_0)
        lazy_1 = Lazy(func_0)
        assert lazy_0 == lazy_1
        float_0 = 4.2
        assert lazy_0 != lazy_1

    def test_case_3():
        float_0 = 2.1
        func_0 = lambda: float_0
        lazy

# Generated at 2022-06-25 23:49:05.924208
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: 2).bind(lambda x: Lazy(lambda: x*x)) == Lazy(lambda: 4)



# Generated at 2022-06-25 23:49:12.172077
# Unit test for method map of class Lazy
def test_Lazy_map():
    def double(value: float) -> float:
        return value * 2

    def square(value: float) -> float:
        return value * value

    double_result = Lazy(double).map(square)

    assert double_result.is_evaluated is False
    assert double_result.get() == 16

    double_result = Lazy(double).map(square).map(square)
    assert double_result.get() == 256


# Generated at 2022-06-25 23:49:13.995827
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(float_0) == Lazy.of(float_0)


# Generated at 2022-06-25 23:49:19.758498
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Mocks
    def fn_mock(a):
        return a + 1

    # Arrange
    lazy_lazy = Lazy(fn_mock)
    wrapped_fn = Lazy(fn_mock)

    # Act
    result = lazy_lazy.ap(wrapped_fn)

    # Assert
    assert result.get(0) == 1 # fn_mock(0) + 1
    assert result.get(1) == 2 # fn_mock(1) + 1


# Generated at 2022-06-25 23:49:21.984498
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(3).get() == 3
    assert Lazy.of(float_0).get() == float_0
    assert Lazy.of(None).get() == None


# Generated at 2022-06-25 23:49:24.499355
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Arrange
    float_0 = Lazy.of(2.1)
    # Act
    output = 2.1
    # Assert
    assert float_0.get() == output



# Generated at 2022-06-25 23:49:25.799553
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(0).map(lambda val: val + 2).get() == 2

# Generated at 2022-06-25 23:49:28.788317
# Unit test for method get of class Lazy
def test_Lazy_get():
    # GIVEN
    float_0 = 2.1
    lazy = Lazy(lambda: float_0)

    # WHEN
    result = lazy.get()

    # THEN
    assert result == float_0



# Generated at 2022-06-25 23:49:38.366502
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try

    def add(x):  # pragma: no cover
        return Lazy.of(x + 1)

    def sub(x):  # pragma: no cover
        return Lazy.of(x - 1)

    def mul(x):  # pragma: no cover
        return Lazy.of(x * 2)

    def div(x):  # pragma: no cover
        return Lazy.of(x / 2)

    def err(x):  # pragma: no cover
        return Lazy.of(Try.fail(KeyError('errror')))

    a = Lazy.of(1).ap(add(10))
    asser

# Generated at 2022-06-25 23:49:51.224834
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def get_float(i: int) -> float:
        return float(i)

    def get_negative_float(i: int) -> float:
        return -float(i)

    lazy_float = Lazy(get_float)
    lazy_negative_float = Lazy(get_negative_float)
    another_lazy_float = Lazy(get_float)

    assert not lazy_float == lazy_negative_float
    assert lazy_float == another_lazy_float



# Generated at 2022-06-25 23:49:58.730368
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert (
        Lazy.of(0)
            .bind(lambda x: Lazy.of(x * 2))
            .get() == 0
    )

    assert (
        Lazy.of(1)
            .bind(lambda x: Lazy.of(x * 2))
            .get() == 2
    )

    assert (
        Lazy.of(2)
            .bind(lambda x: Lazy.of(x * 2))
            .get() == 4
    )

    assert (
        Lazy.of(3)
            .bind(lambda x: Lazy.of(x * 2))
            .get() == 6
    )

    assert (
        Lazy.of(4)
            .bind(lambda x: Lazy.of(x * 2))
            .get() == 8
    )

# Generated at 2022-06-25 23:50:09.154345
# Unit test for method map of class Lazy
def test_Lazy_map():
    x = Lazy(lambda x: x + 2)
    assert Lazy.of(4) == x.map(lambda x: x + 2)
    assert Lazy.of(4.4) == x.map(lambda x: x + 2.3)
    assert Lazy.of(6) == x.map(lambda x: x * 3)
    assert Lazy.of(3.0) == x.map(lambda x: x * 1.5)
    assert Lazy.of("2.1") == x.map(lambda x: str(x))
    assert Lazy.of([1, 2]) == x.map(lambda x: [1, x])
    assert Lazy.of(['ab', 'cd', 'ef']) == x.map(lambda x: ['ab', 'cd', 'ef'])
    assert Lazy

# Generated at 2022-06-25 23:50:18.908593
# Unit test for method get of class Lazy
def test_Lazy_get():
    float_0 = 2.1
    def func_0():
        return float_0
    lazy_0 = Lazy(func_0)
    str_1 = str(lazy_0)
    float_1 = lazy_0.get(None)
    assert(float_1 == float_0)

    lazy_0._compute_value(None)
    str_2 = str(lazy_0)
    float_2 = lazy_0.get(None)
    assert(float_2 == float_0)

    float_0 = 2.2
    str_3 = str(lazy_0)
    float_3 = lazy_0.get(None)
    assert(float_3 == float_0)

    lazy_0._compute_value(None)
    str_4 = str(lazy_0)

# Generated at 2022-06-25 23:50:27.525799
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(_):
        return 1

    def g(_):
        return 2

    lazy = Lazy.of(0)
    lazy2 = lazy.bind(f)
    lazy3 = lazy2.bind(g)
    assert lazy.is_evaluated == False
    assert lazy.value is None
    assert lazy2.is_evaluated == False
    assert lazy2.value is None
    assert lazy3.is_evaluated == False
    assert lazy3.value is None
    assert lazy3.bind(lambda x: x + 1).get() == 3
    assert lazy.is_evaluated == True
    assert lazy.value == 0
    assert lazy2.is_evaluated == True
    assert lazy2.value == 1
    assert lazy3.is_evaluated == True
    assert lazy3.value == 2


# Unit test