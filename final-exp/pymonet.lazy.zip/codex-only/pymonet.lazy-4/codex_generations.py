

# Generated at 2022-06-24 00:06:53.447142
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    assert Lazy.of(3).ap(Lazy.of(lambda x: x + 3)) == Box.of(6)
    assert Lazy.of(6).ap(Lazy.of(lambda x: x / 2)) == Box.of(3)



# Generated at 2022-06-24 00:06:57.107511
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    to_box_result = Lazy.of(1).to_box()

    assert to_box_result == Box(1)


# Generated at 2022-06-24 00:07:00.040457
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    function = lambda x: x + 1
    assert Lazy.of(1).to_validation() == Lazy.of(1).to_box().to_validation()

# Generated at 2022-06-24 00:07:09.632845
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    def fn(value: int) -> Lazy[int, int]:
        return Lazy(lambda *args: value * 3)

    def fn_fail(value: int) -> Lazy[int, int]:
        raise ValueError

    assert Lazy.of(2).bind(fn).get() == 6
    assert Lazy.of(2).bind(fn).bind(fn).get() == 18
    assert Lazy.of(2).bind(fn).bind(fn).bind(fn).get() == 54
    assert Lazy.of(2).bind(fn).bind(fn).bind(fn).bind(fn).get() == 162


# Generated at 2022-06-24 00:07:16.304660
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    from pymonet.functors.functor import Functor
    from pymonet.monad_transformers.monad_transformer import MonadTransformer
    from pymonet.monad_transformers.monad_transformer_result import MonadTransformerResult
    from pymonet.monad_transformers.monad_transformer_result_box import MonadTransformerResultBox

    class TestFunctor(Functor, MonadTransformer):

        def __init__(self, value: int) -> None:
            self.value = value

        def __eq__(self, other: object) -> bool:
            """
            Two TestFunctor are equals where both have the same value.
            """
            return isinstance(other, TestFunctor) and self.value == other.value


# Generated at 2022-06-24 00:07:27.081978
# Unit test for method map of class Lazy
def test_Lazy_map():
    call_count = [0]

    def add_one(value: int) -> int:
        call_count[0] += 1
        return value + 1

    def multiply_on_two(value: int) -> int:
        call_count[0] += 1
        return value * 2

    def divide_on_three(value: int) -> int:
        call_count[0] += 1
        return value / 3

    # Check calls with None mapper
    def test_Lazy_map_with_none_mapper(mapper):
        assert call_count[0] == 0
        lazy = Lazy.of(10).map(mapper).map(multiply_on_two).map(divide_on_three)
        assert call_count[0] == 0
        assert lazy.get() == 10
       

# Generated at 2022-06-24 00:07:29.913170
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def test(value_):
        def method_returning_value():
            return value_
        return Validation.success(value_) == Lazy(method_returning_value).to_validation()

    assert test(1)
    assert test("1")

# Generated at 2022-06-24 00:07:42.158241
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.functor import Functor
    def ten() -> int:
        return 10

    assert Lazy(ten).get() == 10

    def add_lazy_one(x: int) -> int:
        return x + 1

    assert Lazy(add_lazy_one).map(lambda e: e * e).get(10) == (11 * 11)
    assert Lazy(add_lazy_one).ap(Lazy(lambda e: e * e)).get(10) == (10 * 10) + 1

    def f(x: int) -> Lazy[int, int]:
        return Lazy(lambda *_: x + 1)

    def g(x: int) -> int:
        return x + 2


# Generated at 2022-06-24 00:07:48.205817
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(value):
        return value + 1

    lazy = Lazy.of(5).bind(Lazy.of)
    assert 5 == lazy.get()

    lazy = Lazy.of(5).bind(lambda value: Lazy.of(value + 1))
    assert 6 == lazy.get()

    lazy = Lazy.of(5).bind(lambda value: Lazy.of(fn(value)))
    assert 6 == lazy.get()



# Generated at 2022-06-24 00:07:52.880562
# Unit test for method get of class Lazy
def test_Lazy_get():
    # GIVEN
    inc = lambda x: x + 1
    test_lazy_value = 5
    lazy = Lazy(lambda: test_lazy_value)

    # WHEN
    value = lazy.get()

    # THEN
    assert value == test_lazy_value
    assert lazy.is_evaluated == True
    assert lazy.value == test_lazy_value


# Generated at 2022-06-24 00:07:54.650805
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy(lambda x: x).get(1) == 1

# Generated at 2022-06-24 00:07:55.943508
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 5).get() == 5



# Generated at 2022-06-24 00:07:58.754550
# Unit test for constructor of class Lazy
def test_Lazy():
    x = Lazy.of(1)
    assert str(x) == 'Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x10b6af0e0>, value=None, is_evaluated=False]'

# Generated at 2022-06-24 00:08:03.989751
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """
    Test transform Lazy into Either.Lazy will be transformed into right.
    """
    from pymonet.either import Right

    assert Lazy.of('value').to_either() == Right('value')



# Generated at 2022-06-24 00:08:13.103403
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.either import Left
    from pymonet.validation import Validation
    from pymonet.monad_list import MonadList

    def _raise_exception():
        raise ValueError('Ooops')
    assert Lazy.of(1).to_try() == Try.of(1)
    assert Lazy(_raise_exception).to_try() == Try.of(_raise_exception).to_try()

    assert Lazy.of(1).to_try().to_box() == Try.of(1).to_box()
    assert Lazy.of(1).to_try().to_either() == Try.of(1).to_either()
    assert Lazy.of(1).to_try().to_maybe

# Generated at 2022-06-24 00:08:15.477670
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1


# Generated at 2022-06-24 00:08:20.390913
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1(value):
        return value

    def fn2(value):
        return value

    lazy1 = Lazy(fn1)
    lazy2 = Lazy(fn1)
    lazy3 = Lazy(fn2)

    assert lazy1 == lazy2
    assert lazy1 != lazy3



# Generated at 2022-06-24 00:08:24.234836
# Unit test for constructor of class Lazy
def test_Lazy():
    def generator(*args):
        return 1 + args

    lazy = Lazy(generator)

    assert lazy.get() == 1
    assert lazy.get(2, 3) == 3
    assert lazy.get(1, 1) == 2
    assert lazy.is_evaluated == True


# Generated at 2022-06-24 00:08:32.907042
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add2(val):
        return Lazy.of(val+2)

    def add3(val):
        return Lazy.of(val+3)

    def add4(val):
        return Lazy.of(val+4)

    assert Lazy.of(5).bind(add2).bind(add3).get(6) == 16
    assert Lazy.of(5).bind(add2).bind(add3).bind(add4).get(6) == 20
    assert Lazy.of(5).bind(lambda x: Lazy.of(x+3)).get(6) == 8
    assert Lazy.of(5).bind(lambda x: Lazy.of(x+3)).get(6) == 8


# Generated at 2022-06-24 00:08:38.697940
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Should return Lazy with mapped constructor_fn.
    """
    from pymonet.validation import Validation

    assert Lazy(lambda: True).map(lambda x: True) == Lazy(lambda: True)
    assert Lazy(lambda: False).map(lambda x: True).get() is False
    assert Lazy(lambda: True).map(lambda x: False).get() is False
    assert Lazy(lambda: True).map(lambda x: True).get() is True
    assert Lazy(lambda: Validation.success(True)).map(lambda x: x.get()).get() is True
    assert Lazy(lambda: Validation.success(True)).map(lambda x: x.map(lambda y: not y)).get().get() is False


# Generated at 2022-06-24 00:08:41.312787
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    lazy = Lazy.of(1)

    assert lazy.to_maybe() == Maybe.just(1)

# Generated at 2022-06-24 00:08:43.079191
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1



# Generated at 2022-06-24 00:08:47.296673
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def foo(p1, p2):
        return True

    assert Lazy(foo).to_maybe() == Maybe.just(True)

    def bar(p1, p2):
        return None

    assert Lazy(bar).to_maybe() == Maybe.empty()


# Generated at 2022-06-24 00:08:58.873830
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    # Given
    from pymonet.either import Left, Right
    from pymonet.monad import m_return

    val = 5
    lazy = Lazy.of(val)
    try:
        value = lazy.to_either()
    except Exception as e:
        value = Left(e)

    # When
    result1 = Lazy.of(5).to_either()
    result2 = m_return(5).to_either()
    result3 = Lazy.of(Left(2)).to_either()
    result4 = Lazy.of(Right(2)).to_either()

    # Then
    assert isinstance(result1, Right)
    assert result1.get() == val

    assert isinstance(result2, Right)
    assert result2.get() == val


# Generated at 2022-06-24 00:09:03.760817
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def test_fn(a):
        return a + 1

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 2



# Generated at 2022-06-24 00:09:05.490785
# Unit test for method map of class Lazy
def test_Lazy_map():
    def fun(x: int) -> int:
        return x

    assert Lazy(fun).map(fun) == Lazy(fun).map(fun)
    assert Lazy(fun).map(lambda x: x + 1) != Lazy(fun).map(fun)

# Generated at 2022-06-24 00:09:11.510277
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) == Lazy.of(1)
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of('a') == Lazy.of('a')
    assert Lazy.of('a') != Lazy.of('b')
    assert Lazy(fn) != Lazy(None)
    assert Lazy(fn) != None
    assert Lazy(fn) != 1



# Generated at 2022-06-24 00:09:14.617725
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1

    assert Lazy(lambda *args: 3).get() == 3

    assert Lazy(lambda *args: args[0] * args[1]).get(2, 3) == 6



# Generated at 2022-06-24 00:09:22.393210
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    import pytest

    assert str(Lazy(lambda: 42)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f2e5d40c3a0>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: 42).map(lambda x: x * 2)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f2e5d40c570>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:09:28.871321
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    # failure test
    def fail_function():
        raise ValueError()
    try_fail = Lazy(fail_function).to_try()
    assert isinstance(try_fail, Try)
    assert isinstance(try_fail, Failure)
    assert try_fail.get_error().__class__ == ValueError

    # success test
    try_success = Lazy(lambda: 1).to_try()
    assert isinstance(try_success, Try)
    assert not isinstance(try_success, Failure)
    assert try_success.get() == 1



# Generated at 2022-06-24 00:09:31.954857
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    # given
    from pymonet.box import Box
    lazy = Lazy.of(1)

    # when
    result = lazy.to_box()

    # then
    assert isinstance(result, Box)
    assert result.is_empty() is False
    assert result.get_or_else(0) == 1


# Generated at 2022-06-24 00:09:37.824559
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    foo_fn = lambda: 1
    bar_fn = lambda: 2
    baz_fn = lambda: 3

    foo_a = Lazy(foo_fn)
    bar_a = Lazy(bar_fn)
    baz_a = Lazy(baz_fn)
    baz_b = Lazy(baz_fn)

    assert foo_a == foo_a
    assert foo_a != bar_a

    assert baz_a == baz_b


# Generated at 2022-06-24 00:09:47.181522
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def non_empty(value):
        return Maybe.just(value)

    def empty():
        return Maybe.empty()

    def non_empty_raise():
        return Maybe.just(1)

    def empty_raise():
        return Maybe.empty()

    assert Lazy(non_empty).to_maybe('not empty') == Lazy(non_empty).map(lambda _: _.to_maybe('not empty')).get()
    assert Lazy(empty).to_maybe('not empty') is Lazy(empty).map(lambda _: _.to_maybe('not empty')).get()

# Generated at 2022-06-24 00:09:48.846787
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x: x + 1).ap(Lazy(lambda x: x + 1)) == Lazy.of(2)

# Generated at 2022-06-24 00:09:56.731714
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Unit test for method to_try of class Lazy
    """
    from pymonet.monad_try import Try

    def fn():
        return 10

    lazy_1 = Lazy(fn)
    assert lazy_1.to_try() == Try(fn)

    def fn2():
        a = 1 / 0

    lazy_2 = Lazy(fn2)
    assert lazy_2.to_try() == Try.failure(ZeroDivisionError())


# Generated at 2022-06-24 00:10:03.781582
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    def f1() -> int:
        return 1

    def f2() -> int:
        return 2

    lazy1 = Lazy(f1)
    lazy2 = Lazy(f2)

    success_lazy1 = lazy1.to_validation()
    success_lazy2 = lazy2.to_validation()

    assert success_lazy1.is_success()
    assert success_lazy2.is_success()
    assert success_lazy1.get() == 1
    assert success_lazy2.get() == 2

# Generated at 2022-06-24 00:10:13.376625
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    import pytest
    from pymonet.either import Right
    from pymonet.monad_try import Try

    def success_fn(*args):
        return str(args)

    def fail_fn():
        raise ValueError()

    def fail_mapper(value):
        raise ValueError()

    assert Lazy(success_fn).to_try(True, 1, 'a') == Try.success('(True, 1, a)')
    assert Lazy(fail_fn).to_try() == Try.failure(ValueError)
    assert Lazy(success_fn).map(fail_mapper).to_try(True, 1, 'a') == Try.failure(ValueError)

    assert Lazy(success_fn).bind(lambda x: Lazy(lambda *args: x)).to_

# Generated at 2022-06-24 00:10:16.005249
# Unit test for method get of class Lazy
def test_Lazy_get():

    def lazy_value_increased():
        return Lazy(lambda x: x + 1)

    assert lazy_value_increased().get(1) == 2


# Generated at 2022-06-24 00:10:17.418928
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy(lambda: 5).to_either().is_right()


# Generated at 2022-06-24 00:10:20.871259
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Try.of(lambda: 1) == Lazy(lambda: 1).to_try()
    assert Try.failure(RuntimeError('error')) == Lazy(lambda: 1 / 0).to_try()

# Generated at 2022-06-24 00:10:25.363542
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    lazy = Lazy(lambda x: 'x')

    assert lazy.get() == 'x'

    lazy = Lazy(lambda x: x).bind(lambda x: Lazy(lambda y: y + x)).bind(lambda z: Lazy(lambda a: z + a))

    assert lazy.get(2, 1) == 3

# Generated at 2022-06-24 00:10:28.717221
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.box import Box

    def box_fn(a):
        return Box(a)

    assert Lazy.of(1).ap(Lazy.of(box_fn)) == Lazy(lambda: Box(1))



# Generated at 2022-06-24 00:10:31.713960
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import I

    assert Lazy(lambda: I('a')) == Lazy(lambda: I('a'))
    assert Lazy(lambda: I('a')) != Lazy(lambda: I('b'))



# Generated at 2022-06-24 00:10:37.944275
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    """
    Test for method __str__ of class Lazy
    """
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function <lambda> at 0x10b8d7b70>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:10:40.598967
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    result = Lazy(lambda x: x + 1).to_box(5)

    assert result == Box(6)


# Generated at 2022-06-24 00:10:48.872656
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Fail, Success

    assert Lazy.of(1).to_try() == Success(1)
    assert Lazy(lambda: raise_runtime_exception()).to_try() == Fail(RuntimeError('runtime exception'))
    assert Lazy(lambda: raise_type_error()).to_try() == Fail(TypeError('type exception'))
    assert Lazy(lambda: raise_value_error()).to_try() == Fail(ValueError('value exception'))
    assert Lazy(lambda: raise_import_error()).to_try() == Fail(ImportError('import exception'))



# Generated at 2022-06-24 00:10:53.365098
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    assert Lazy(lambda x: x * 2).to_either(2) == Left(2)
    assert Lazy(lambda x: x * 2).to_either(-1) == Left(-1)
    assert Lazy(lambda x: x * 2).to_either(None) == Left(None)



# Generated at 2022-06-24 00:10:59.985272
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_try import Try

    lazy_with_param = Lazy(Try.of)
    result = lazy_with_param.get('message')
    assert result == Try.of('message')

    lazy_without_param = Lazy(Try.of())
    result = lazy_without_param.get()
    assert result == Try.of()



# Generated at 2022-06-24 00:11:07.107253
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.box import Box
    from pymonet.either import Left
    from pymonet.lazy import Lazy
    # Empty Lazy with no fn
    lazy = Lazy(lambda *args: None)

    assert lazy.to_either().is_left() is True
    assert lazy.to_either().fold_left(lambda *args: NotImplementedError('Should not be here')) is None

    # Lazy of Box
    lazy = Lazy.of(Box(NotImplementedError('Should not be here')))

    assert lazy.to_either().is_left() is True
    assert lazy.to_either().fold_left(lambda *args: NotImplementedError('Should not be here')) is None

    # Lazy of Left

# Generated at 2022-06-24 00:11:13.652457
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Lazy.of(None).to_maybe()
    assert Maybe.nothing() == Maybe.of(None)
    assert Maybe.just(1) == Lazy.of(1).to_maybe()
    assert Maybe.just(1) == Maybe.of(1)

# Generated at 2022-06-24 00:11:17.508343
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    assert Lazy.of(0).to_either() == Lazy.of(0).to_maybe().to_either()



# Generated at 2022-06-24 00:11:24.448910
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import pytest

    def fn(x):
        return x * 2

    def fn_to_fn(x):
        def inner_fn(y):
            return x * y

        return Lazy.of(inner_fn)

    assert Lazy.of(1).ap(Lazy.of(fn_to_fn)).get()(10) == 2

    with pytest.raises(TypeError):
        Lazy.of(fn).ap(1)

# Generated at 2022-06-24 00:11:28.105105
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)

    def lambda_1(*args):
        return 1

    def lambda_2(*args):
        return 2

    assert Lazy(lambda_1) == Lazy(lambda_1)
    assert Lazy(lambda_1) != Lazy(lambda_2)

# Generated at 2022-06-24 00:11:30.578856
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def fn():
        raise Exception("Blam")

    assert Lazy(fn).to_try().get_or_else("Empty") == "Empty"

# Generated at 2022-06-24 00:11:40.334409
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x + 1)) == 'Lazy[fn={0.__name__}, value=None, is_evaluated=False]'.format(
        Lazy.__init__.__code__.co_consts[0])
    assert str(Lazy(lambda x: x + 1).get()) == 'Lazy[fn={0.__name__}, value=None, is_evaluated=False]'.format(
        Lazy.__init__.__code__.co_consts[0])
    assert str(Lazy(lambda x: x + 1).map(lambda x: x + 1)) == 'Lazy[fn={0.__name__}, value=None, is_evaluated=False]'.format(
        Lazy.map.__code__.co_varnames[0])


# Generated at 2022-06-24 00:11:44.636957
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy.of(10).to_try() == Try.of(10)
    assert Lazy(lambda: int('test')).to_try() == Try.failure(ValueError('invalid literal for int() with base 10: \'test\''))



# Generated at 2022-06-24 00:11:49.913385
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    # Make empty Maybe
    maybe_empty_lazy = Lazy(lambda: Maybe.empty()).to_maybe()
    assert isinstance(maybe_empty_lazy, Maybe)
    assert maybe_empty_lazy.is_empty

    # Make not empty Maybe
    maybe_not_empty_lazy = Lazy(lambda: Maybe.just('HELLO!')).to_maybe()
    assert isinstance(maybe_not_empty_lazy, Maybe)
    assert not maybe_not_empty_lazy.is_empty
    assert maybe_not_empty_lazy == Maybe.just('HELLO!')



# Generated at 2022-06-24 00:11:52.436372
# Unit test for constructor of class Lazy
def test_Lazy():

    assert Lazy(lambda: None).constructor_fn() == None
    assert Lazy(lambda: 2).constructor_fn() == 2



# Generated at 2022-06-24 00:12:01.285263
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    first_name = Lazy(lambda: 'alexander')
    last_name = Lazy(lambda: 'petrosian')
    full_name = first_name.bind(lambda x: last_name.map(lambda y: '{first_name} {last_name}'.format(first_name=x, last_name=y)))
    assert full_name.get() == 'alexander petrosian'
    assert full_name.to_box().get() == 'alexander petrosian'
    assert full_name.to_maybe().get() == 'alexander petrosian'

    age = Lazy(lambda: 22)


# Generated at 2022-06-24 00:12:03.757001
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right
    assert Lazy.of(10).to_either() == Right(10)
    assert Lazy(lambda *args: Left(10)).to_either() == Left(10)



# Generated at 2022-06-24 00:12:06.471591
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def _f():
        return 1

    lazy = Lazy(_f)
    assert lazy.to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:12:10.018625
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test Lazy.map
    """
    assert Lazy(lambda x: x + 1).map(lambda x: x + 2).get(1) == 4



# Generated at 2022-06-24 00:12:15.606478
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    test_value = "OK"
    test_function = lambda: test_value

    lazy = Lazy(test_function)
    assert lazy.to_maybe() == Maybe.just(test_value)
    assert lazy.to_maybe() == Maybe.just(test_value)


# Generated at 2022-06-24 00:12:23.260369
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    @Lazy
    def lazy_a():
        return 'lazy_a'

    @Lazy
    def lazy_b():
        return 'lazy_b'

    @Lazy
    def lazy_c():
        return 'lazy_c'

    lazy_c.is_evaluated = True
    lazy_c.value = 'lazy_c'

    assert lazy_a != lazy_b
    assert lazy_a == lazy_a
    assert lazy_c != lazy_b
    assert lazy_c == lazy_c

# Generated at 2022-06-24 00:12:27.408006
# Unit test for method get of class Lazy
def test_Lazy_get():
    # given
    stub_fn = lambda x: x
    test_lazy = Lazy(stub_fn)

    # when
    lazy = test_lazy.get(1)

    # then
    assert 1 == lazy

# Generated at 2022-06-24 00:12:32.599249
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def do():
        raise Exception('Mock exception.')

    assert Lazy(lambda: 2).to_try() == Try.success(2)
    assert Lazy(do).to_try() == Try.failure(Exception('Mock exception.'))

# Generated at 2022-06-24 00:12:34.453130
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x + 2).map(lambda x: x * 2).get(2) == 6



# Generated at 2022-06-24 00:12:37.782985
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    assert Lazy.of(1).to_box() == Lazy.of(1).to_box()
    assert Lazy.of(2).to_box() != Lazy.of(1).to_box()


# Generated at 2022-06-24 00:12:38.988644
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of('foo').to_either() == Right('foo')


# Generated at 2022-06-24 00:12:48.497254
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    def identity_fn(x):
        return x

    def double_identity_fn(x):
        return x

    lazy_fn = Lazy.of(None)
    lazy_fn_with_map = lazy_fn.map(identity_fn)
    lazy_fn_with_ap = lazy_fn.ap(Lazy.of(identity_fn))

    assert lazy_fn.to_either() == Right(None)
    assert lazy_fn_with_map.to_either() == Right(None)
    assert lazy_fn_with_ap.to_either() == Right(None)

    lazy_fn_with_map_and_ap = lazy_fn.map(double_identity_fn).ap(Lazy.of(identity_fn))
    assert lazy_fn

# Generated at 2022-06-24 00:12:53.929624
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def fn(arg):  # pragma: no cover
        pass
    assert str(Lazy(fn)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x10d9b4e60>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:12:58.347699
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy(lambda: 1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)



# Generated at 2022-06-24 00:13:01.219190
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_value = Lazy(lambda x: x - 1).map(lambda x: x + 1).get(2)

    assert lazy_value == 2



# Generated at 2022-06-24 00:13:04.695567
# Unit test for constructor of class Lazy
def test_Lazy():
    def f(*args):
        return 42

    lazy = Lazy(f)

    assert f == lazy.constructor_fn
    assert False == lazy.is_evaluated
    assert None == lazy.value



# Generated at 2022-06-24 00:13:13.466857
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(3) != Lazy.of(1)
    assert Lazy.of(3).fold(lambda x: x) == 3
    assert Lazy.of(3) == Lazy.of(3).map(lambda x: x).fold(lambda x: x)
    assert Lazy(lambda x: x).bind(lambda x: Lazy.of(x)).fold(lambda x: x) == Lazy(lambda x: x).get()



# Generated at 2022-06-24 00:13:16.801155
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left

    value = Right(5)
    lazy_instance = Lazy.of(value)

    assert lazy_instance.to_either() == value
    assert lazy_instance.to_either() != Left(5)



# Generated at 2022-06-24 00:13:20.677021
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    maybe_value = Maybe.just(5)
    lazy_value = Lazy.of(maybe_value)

    assert Maybe.just(5) == lazy_value.to_maybe()

# Generated at 2022-06-24 00:13:29.956905
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet import identity, compose
    from pymonet.functor import Functor

    def test_1():
        val = Lazy.of(123)

        assert val.constructor_fn is None
        assert val.is_evaluated is False
        assert val.value is None
        assert val is Lazy.of(123)
        assert val == Lazy.of(123)

        val._compute_value()
        assert val.constructor_fn is None
        assert val.value == 123
        assert val.is_evaluated

    def test_2():
        def constructor_with_argument(arg):
            return arg + 321

        val = Lazy(constructor_with_argument)
        assert val.constructor_fn(321) == 642
        assert val.get(321) == 642
        assert val

# Generated at 2022-06-24 00:13:31.796551
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of(2).to_maybe() == Maybe.just(2)

# Generated at 2022-06-24 00:13:38.773775
# Unit test for constructor of class Lazy
def test_Lazy():
    # Wrap lambda_function to Lazy
    lazy_function = Lazy(lambda val: val + 1)
    assert lazy_function.is_evaluated is False

    # Wrap function with args to Lazy
    lazy_function_with_args = Lazy(lambda val, inc: val + inc)
    assert lazy_function_with_args.is_evaluated is False

    # Wrap function with multiple args to Lazy
    lazy_function_with_multiple_args = Lazy(lambda val, inc, foo: val + inc + foo)
    assert lazy_function_with_multiple_args.is_evaluated is False


# Generated at 2022-06-24 00:13:43.686233
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == Lazy.of(2).get() == 1
    assert Lazy.of(1).get() == Lazy.of(1).get()
    assert Lazy.of(3).get(2, 3, 4) == 3


# Generated at 2022-06-24 00:13:49.098519
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: Lazy.of(x + 1)).get().get() == 2
    assert Lazy.of(2).map(lambda x: Lazy.of(x + 1).map(lambda x: x + 2)).get().get() == 5


# Generated at 2022-06-24 00:13:53.358336
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.monad import Lazy

    test = Lazy(lambda: 1)

    assert 'Lazy[fn={}, value={}, is_evaluated={}]'.format(test.constructor_fn, test.value, test.is_evaluated) == str(test)



# Generated at 2022-06-24 00:13:55.819864
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Lazy.of(4).to_maybe() == Maybe.just(4)
    assert type(Lazy.of(4).to_maybe()) == Maybe
    assert Lazy.of(4).to_maybe().is_just
    assert not Lazy.of(4).to_maybe().is_nothing


# Generated at 2022-06-24 00:14:07.245261
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda: 'a') == Lazy(lambda: 'a')
    assert Lazy(lambda: 'a') != Lazy(lambda: 'b')
    assert Lazy(lambda: '') != 'a'
    assert Lazy(lambda: '').constructor_fn == Lazy(lambda: '').constructor_fn
    assert Lazy(lambda: '').constructor_fn != Lazy(lambda: 'a').constructor_fn
    assert Lazy(lambda a: a).constructor_fn(1) == Lazy(lambda a: a).constructor_fn(1)
    assert Lazy(lambda a: a).constructor_fn(1) != Lazy(lambda a: a).constructor_fn(2)



# Generated at 2022-06-24 00:14:12.244220
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: None)) == "Lazy[fn=<built-in function <lambda> at {}>, value=None, is_evaluated=False]" \
        .format(hex(id(Lazy.__init__)))

# Unit tests for method of of class Lazy

# Generated at 2022-06-24 00:14:16.237624
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f2a7d2d2f28>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:14:20.334539
# Unit test for method __str__ of class Lazy
def test_Lazy___str__(): # pragma: no cover
    assert str(Lazy(lambda: 'foo')) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f8b4ab83d08>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:14:26.257266
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy.of(1)) == 'Lazy[fn=<function <lambda> at 0x7f29f0f63c80>, value=1, is_evaluated=False]'
    assert Lazy.of(1)._compute_value() == 1
    assert str(Lazy.of(1)) == 'Lazy[fn=<function <lambda> at 0x7f29f0f63c80>, value=1, is_evaluated=True]'



# Generated at 2022-06-24 00:14:35.242793
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """Ensure function to_either works correctly"""
    from pymonet.either import Left, Right

    def plus_one(value: int) -> int:
        return value + 1

    def to_int(value: str) -> int:
        return int(value)

    assert Lazy(lambda: '1').to_either().equals(Right('1'))
    assert Lazy(lambda: '1').map(to_int).to_either().equals(Right(1))
    assert Lazy(lambda: 'foo').map(to_int).to_either().equals(Left(ValueError('invalid literal for int() with base 10: \'foo\'')))
    assert Lazy(lambda: '1').map(to_int).map(plus_one).to_either().equals(Right(2))

# Generated at 2022-06-24 00:14:37.516550
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add_two(x: int) -> int:
        return x + 2

    assert Lazy.of(add_two).ap(Lazy.of(2)).get() == 4



# Generated at 2022-06-24 00:14:41.677691
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy(lambda: 1).to_validation().value == 1

# Generated at 2022-06-24 00:14:45.975618
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(10).map(lambda x: x + 10).get() == Lazy.of(10).get() + 10

    assert Lazy.of(10).map(lambda x: x).get() == Lazy.of(10).get()



# Generated at 2022-06-24 00:14:52.050514
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.either import Right

    assert Lazy.of(lambda x: x + 1).ap(Box(2)) == Lazy.of(3)
    assert Lazy.of(lambda x: x + 1).ap(Try.of(lambda x: x + 1, 1)) == Lazy.of(3)
    assert Lazy.of(lambda x: x + 1).ap(Right(2)) == Lazy.of(3)



# Generated at 2022-06-24 00:14:54.511123
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda x: x + 1).to_box(2).get_value() == Box(3).get_value()



# Generated at 2022-06-24 00:14:58.714397
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    # given
    lazy: Lazy[int, int] = Lazy(lambda x: x)

    # when
    result: Box[int] = lazy.to_box(3)

    # then
    assert result.contains(3)


# Generated at 2022-06-24 00:15:03.817265
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Box('hello') == Lazy.of('hello').to_box()


# Generated at 2022-06-24 00:15:06.294326
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Lazy(lambda: 1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:15:14.301437
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from . import monad
    from .monad import Lazy

    def fn1():
        return 1

    assert str(Lazy(fn1)) == 'Lazy[fn=<function test_LAzy___str__.<locals>.fn1 at 0x7f868d6e02f0>, value=None, is_evaluated=False]'

    def fn2():
        return 2

    assert str(Lazy(fn2)) == 'Lazy[fn=<function test_LAzy___str__.<locals>.fn2 at 0x7f868d6e0320>, value=None, is_evaluated=False]'

    assert monad.Lazy(lambda: 2) == monad.Lazy(lambda: 2)
    assert monad.Lazy(lambda: 2) != monad.L

# Generated at 2022-06-24 00:15:17.054654
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    function = lambda x: x
    constructor_fn_1 = lambda x: function(x)
    constructor_fn_2 = lambda x: function(x)
    lazy_1 = Lazy(constructor_fn_1)
    lazy_2 = Lazy(constructor_fn_2)
    assert lazy_1 == lazy_2

# Generated at 2022-06-24 00:15:24.608352
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    from pymonet.functor import Functor

    # when
    lazy = Lazy(lambda x: x * 2).bind(lambda x: Lazy(lambda y: x + y))
    functor = Functor.of(lazy)

    # then
    assert functor.fold(lambda x: 5, lambda y: y + 1) == 9
    assert functor.fold(lambda x: 5, lambda y: y + 1) == 9


# Generated at 2022-06-24 00:15:32.320930
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.try_ import Try

    success_lazy = Lazy.of(5)
    assert success_lazy.to_try() == Try.of(lambda: 5)
    assert Try.of(lambda: 5) == Lazy.of(5).to_try()

    exception_lazy = Lazy(lambda: 5/0)
    assert isinstance(exception_lazy.to_try(), Try)
    assert exception_lazy.to_try() != Try.of(lambda: 5)


# Generated at 2022-06-24 00:15:34.761197
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is True



# Generated at 2022-06-24 00:15:36.647638
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy.of(1)
    assert lazy.get() == 1



# Generated at 2022-06-24 00:15:48.013762
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.functor import Functor
    from typing import Callable

    class TestLazy(Lazy, Functor):
        def __init__(self, constructor_fn: Callable):
            super().__init__(constructor_fn)

        def map(self, fn):
            return TestLazy(lambda: fn(self.constructor_fn()))

    def test_fn_1():
        return '1'

    assert str(TestLazy(test_fn_1)) == "Lazy[fn=<function test_fn_1 at 0x7f0a8a8e7d08>, value=None, is_evaluated=False]"

# Generated at 2022-06-24 00:15:49.148049
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(1).to_box() == Box(1)


# Generated at 2022-06-24 00:15:55.375827
# Unit test for method map of class Lazy
def test_Lazy_map():
    def lazy_constructor() -> Lazy[int, int]:
        return Lazy(lambda: 2 + 2)

    lazy = lazy_constructor()
    mapp_lazy = lazy.map(lambda x: x * 2)

    assert mapp_lazy.get() == 8
    assert mapp_lazy.is_evaluated



# Generated at 2022-06-24 00:16:00.508442
# Unit test for method bind of class Lazy
def test_Lazy_bind(): # pragma: no cover
    assert Lazy.of(lambda x: x + 1).bind(lambda x: Lazy.of(x(3))) == Lazy.of(4)
    assert Lazy.of(lambda x: x + 3).bind(lambda x: Lazy.of(lambda y: x(y + 3))).bind(lambda x: Lazy.of(x(3))) == Lazy.of(9)


# Generated at 2022-06-24 00:16:02.444920
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1) == Lazy.of(2)



# Generated at 2022-06-24 00:16:12.313306
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.function import compose
    from pymonet.box import Box

    add = lambda x: x + 1
    add_two = lambda x: x + 2

    assert Lazy.of(3) == Lazy.of(3)
    assert Lazy.of(3) == Lazy(lambda: 3)

    assert Lazy.of(3).map(add) == Lazy.of(4)
    assert Lazy.of(3).map(add).map(add) == Lazy.of(5)

    assert Lazy.of(2).ap(Lazy.of(add)).get() == 3
    assert Lazy.of(2).ap(Lazy.of(add_two)).get() == 4

# Generated at 2022-06-24 00:16:16.511052
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def constructor_fn(x):
        return x * x

    lazy = Lazy(constructor_fn)

    assert str(lazy) == 'Lazy[fn={0}, value={1}, is_evaluated={2}]'.format(constructor_fn, None, False)



# Generated at 2022-06-24 00:16:20.057667
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Just
    from pymonet.monad_try import Success

    result = Lazy.of(10).ap(Just(lambda x: x * 2))
    assert Just(20) == result.to_maybe()

    assert Success(20) == result.to_try()



# Generated at 2022-06-24 00:16:27.873208
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    # when
    val = Lazy(lambda a: a + 1).to_try(10)

    # then
    assert val == Try.success(11)

    # when
    val = Lazy(lambda a: a + a).to_try(None)

    # then
    assert isinstance(val, Try)
    assert val != Try.success(1)



# Generated at 2022-06-24 00:16:31.821517
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def test_fn(x):
        return x

    lazy = Lazy(test_fn)

    assert lazy == Lazy(test_fn)
    assert lazy != Lazy(lambda x: x)


# Generated at 2022-06-24 00:16:38.382591
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    def f(x):
        return x + 1

    def fail_f(x):
        raise Exception('f')

    lazy_f = Lazy.of(f)
    lazy_fail_f = Lazy.of(fail_f)

    assert lazy_f.to_try(1) == Try.of(f, 1)
    assert lazy_fail_f.to_try(1) == Try.failure(Exception('f'))

# Generated at 2022-06-24 00:16:43.189584
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy = Lazy(add_one).map(multiply_three).map(add_one)

    assert lazy.get(123) == (123 + 1) * 3 + 1



# Generated at 2022-06-24 00:16:45.459865
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1).to_box() == Box(1)


# Generated at 2022-06-24 00:16:51.001399
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a, b):
        return a + b

    assert Lazy.of(add).ap(Lazy.of(12)).ap(Lazy.of(13)).get() == 25
    assert Lazy.of(add).ap(Lazy.of(12)).ap(Lazy.of(13)).is_evaluated is False
    assert Lazy.of(add).ap(Lazy.of(12)).ap(Lazy.of(13)).get() == 25
    assert Lazy.of(add).ap(Lazy.of(12)).ap(Lazy.of(13)).is_evaluated is True
