

# Generated at 2022-06-24 00:06:56.245227
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(10).to_either() == Right(10)

# Generated at 2022-06-24 00:07:02.341467
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.converter import Converter
    import unittest

    class LazyTest(unittest.TestCase):
        def test_to_maybe(self):
            converter = Converter.instance
            self.assertEqual(converter.to_maybe(Lazy(lambda x: x).to_maybe(1)), converter.to_maybe(1))

    unittest.main()



# Generated at 2022-06-24 00:07:07.613775
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1  # Lazy is not evaluated
    assert Lazy.of(1).get() == 1  # Lazy is already evaluated
    assert Lazy(lambda a: a).get(1) == 1
    assert Lazy(lambda a: a).get(2) == 2

# Generated at 2022-06-24 00:07:10.709077
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def f():
        return Maybe.empty()

    lazy = Lazy(f)

    assert lazy.to_maybe() is Maybe.empty()



# Generated at 2022-06-24 00:07:13.577014
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of("a").__eq__(Lazy.of("a"))

# Generated at 2022-06-24 00:07:15.003582
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(True) == Lazy.of(True)



# Generated at 2022-06-24 00:07:17.526481
# Unit test for method get of class Lazy
def test_Lazy_get():

    def add(a, b):
        return a + b

    assert Lazy(lambda: add(1, 2)).get() == 3



# Generated at 2022-06-24 00:07:27.857151
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.validation import Validation

    assert Lazy.of("hello").map(str.upper).get() == "HELLO"
    assert Lazy.of("hello").map(str.upper).is_evaluated == False
    assert Lazy.of("hello").map(str.upper)._compute_value() == "HELLO"
    assert Lazy.of("hello").map(str.upper).is_evaluated == True
    assert Lazy.of("hello").map(str.upper).map(str.lower).get() == "hello"
    assert Lazy.of("hello").map(str.upper).map(str.lower).get() == "hello"
    assert Lazy.of("hello").map(str.upper).map(str.lower).get() == "hello"

# Generated at 2022-06-24 00:07:34.821439
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet import ValidationError

    def constructor_fn(a: int, b: int) -> int:
         return a + b

    assert Lazy(constructor_fn).to_validation(1, 2) == Validation.success(3)
    assert Lazy(constructor_fn).to_validation(1, '2') == Validation.fail([ValidationError(None, 'a')])

# Generated at 2022-06-24 00:07:37.677715
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 1).to_maybe() == Maybe.just(1)
    assert Lazy(lambda: None).to_maybe() == Maybe.empty()

# Generated at 2022-06-24 00:07:41.312391
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    def _f():
        return 'ok'

    assert Lazy(_f).to_validation() == Validation.success('ok')

# Generated at 2022-06-24 00:07:46.258152
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.functor import Functor

    # Arrange
    # Act
    lazy = Lazy.of(1)
    result = lazy.get()

    # Assert
    assert result == 1 and isinstance(lazy, Functor)



# Generated at 2022-06-24 00:07:47.775950
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x * x

    lazy = Lazy(fn)
    assert lazy.get(3) == 9
    assert lazy.map(str).get(3) == '9'

# Generated at 2022-06-24 00:07:55.498190
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    value = Lazy(lambda: 1)
    assert value.to_try() == Try.of(lambda: 1)

    def divide_with_exception(a, b):
        return a / b

    value_with_exception = Lazy(lambda: divide_with_exception(1, 0))
    value_with_exception.to_try() == Try.of(divide_with_exception, 1, 0)

    # unit test for nested Lazy
    value_with_exception = Lazy(lambda: Lazy(lambda: divide_with_exception(1, 0)).get()).to_try()
    value_with_exception.to_try() == Try.failure(ZeroDivisionError)

# Generated at 2022-06-24 00:07:59.523433
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def raise_exception(*args):
        raise Exception()

    def not_raise_exception(*args):
        return 1

    assert Lazy(raise_exception).to_try() == Try.raise_exception(Exception())
    assert Lazy(not_raise_exception).to_try() == Try.success(1)

# Generated at 2022-06-24 00:08:10.982160
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: Try(lambda: 1 / 0)).get() == Try(lambda: 1 / 0)
    assert Lazy(lambda: Try(lambda: 1 / 0)).to_try() == Try(lambda: 1 / 0)
    assert Lazy(lambda: Try(lambda: 1)).get() == Try(lambda: 1)
    assert Lazy(lambda: Try(lambda: 1)).to_try() == Try(lambda: 1)
    assert L

# Generated at 2022-06-24 00:08:20.229692
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    # Given
    lazy_box = Lazy(Box[str].of('abc'))

    # When
    mapped = lazy_box.map(lambda value: value.upper())

    # Then
    assert mapped.constructor_fn() == 'ABC'

    # Given
    lazy_box = Lazy(Box[str].of('abc'))

    # When
    mapped = lazy_box.map(lambda value: Box[str].of(value.upper()))

    # Then
    assert mapped.constructor_fn() == 'ABC'



# Generated at 2022-06-24 00:08:26.486813
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left

    empty_lazy = Lazy.of(5)
    lazy_5 = Lazy(lambda: 5)

    assert Right(5) == empty_lazy.to_either()
    assert Right(5) == lazy_5.to_either()

    empty_lazy = Lazy.of(None)
    lazy_error = Lazy(lambda: None)

    assert Left(None) == empty_lazy.to_either()
    assert Left(None) == lazy_error.to_either()

# Generated at 2022-06-24 00:08:28.604305
# Unit test for method get of class Lazy
def test_Lazy_get():
    def f(x):
        return x

    lazy = Lazy(lambda: f)
    assert lazy.get()(1) == 1



# Generated at 2022-06-24 00:08:31.973249
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def fn(a, b):
        return a + b

    def mapper(x):
        return x * 2

    lazy_result = Lazy(fn).map(mapper)
    assert lazy_result.get(2, 3) == 10



# Generated at 2022-06-24 00:08:35.102323
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def print_str(string):
        print(string)

    lazy_str = Lazy(lambda: 'hello')

    print_str(lazy_str)



# Generated at 2022-06-24 00:08:38.052559
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    times_two_fn = lambda x: x * 2

    lazy_value = Lazy.of(1)
    lazy_times_two = lazy_value.bind(times_two_fn)

    assert 2 == lazy_times_two.get()

# Generated at 2022-06-24 00:08:39.230161
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of('test').get() == 'test'

# Generated at 2022-06-24 00:08:44.103505
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def get_value():
        return 'something'

    assert isinstance(Lazy(get_value).to_validation(), Validation)
    assert Lazy(get_value).to_validation() == Validation.success('something')

# Generated at 2022-06-24 00:08:50.133201
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda x: x + 1).to_box(1) == Box(2)
    assert Lazy(lambda x: x).to_box(1) == Box(1)
    assert Lazy(lambda: 1).to_box() == Box(1)
    assert Lazy(lambda x, y: x + y).to_box(1, 2) == Box(3)
    assert Lazy(lambda: 1 + 2).to_box() == Box(3)


# Generated at 2022-06-24 00:08:58.670335
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from nose.tools import assert_equal, assert_not_equal

    value = 1
    lazy = Lazy.of(value)
    assert_equal(lazy, Lazy.of(value))
    assert_equal(lazy, Lazy(lambda: value))
    assert_equal(str(lazy), "Lazy[fn=<lambda>, value=None, is_evaluated=False]")
    assert_equal(value, lazy.get())
    assert_equal(value, lazy.get())
    assert_equal(value, lazy.get())

# Generated at 2022-06-24 00:09:02.875587
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)


# Generated at 2022-06-24 00:09:12.645945
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    T = TypeVar('T')
    U = TypeVar('U')

    assert Lazy[T, U](lambda: 1).to_either() == Right(1), 'Should return Either Right with value from Lazy'
    assert Lazy[T, U](lambda: 'test').to_either() == Right('test'), 'Should return Either Right with value from Lazy'
    assert Lazy[T, U](lambda: (1, 2, 3)).to_either() == Right((1, 2, 3)), 'Should return Either Right with value from Lazy'
    assert Lazy[T, U](lambda: {1: 2, 3: 4}).to

# Generated at 2022-06-24 00:09:13.401878
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Mayb

# Generated at 2022-06-24 00:09:23.737162
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    def function(input_value):
        return input_value + 10

    def mapper(input_value):
        return input_value + 10

    def maybe_mapper(input_value):
        return Maybe.just(input_value + 10)

    assert Maybe.just(10) == Lazy.of(10).to_maybe()
    assert Maybe.just(20) == Lazy(function).to_maybe(10)
    assert Maybe.just(20) == Lazy(function).map(mapper).to_maybe()
    assert Maybe.just(20) == Lazy(function).map(mapper).to_maybe(10)

    assert Maybe.just(20) == Lazy(function).map(maybe_mapper).to_maybe()

# Generated at 2022-06-24 00:09:25.818143
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Unit test for method to_try of class Lazy
    """
    assert (
        str(Lazy(lambda x: x + 1).to_try(2)) ==
        'Success(3)'
    )
    assert (
        str(Lazy(lambda x, y: x / y).to_try(2, 0)) ==
        'Failure(ZeroDivisionError("division by zero",))'
    )

# Generated at 2022-06-24 00:09:28.210706
# Unit test for method get of class Lazy
def test_Lazy_get():
    def first(a, b):
        return a

    def second(a, b):
        return b

    assert Lazy(first).get(1, 2) == 1
    assert Lazy(second).get(1, 2) == 2



# Generated at 2022-06-24 00:09:31.735696
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def fn(arg):
        return arg * 3

    lazy = Lazy(fn)
    assert lazy.constructor_fn(2) == 6
    assert lazy.to_box(2) == Box(6)



# Generated at 2022-06-24 00:09:40.228424
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.maybe import Just

    assert Lazy.of(4).get() == 4
    assert Lazy.of(maybe_one()).get().is_just()
    assert Lazy.of(maybe_one()).get().get_or_else(3) == 1
    assert Lazy.of(maybe_one()).get().get_or_else(3) == 1
    assert Lazy.of(maybe_two()).get().get_or_else(3) == 2
    assert Lazy.of(maybe_two()).get().get_or_else(3) == 2

    assert Lazy.of(Just(1)).get().get_or_else(3) == 1
    assert Lazy.of(Just(1)).get().get_or_else(3) == 1
   

# Generated at 2022-06-24 00:09:52.142271
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.istring import IString

    def plus2(a):
        return a + 2

    def times3(a):
        return a * 3

    def f_plus2_times3(a):
        return (a + 2) * 3

    def f_plus2_times3_istring(a):
        return IString(str((a + 2) * 3))

    assert Lazy.of(2).ap(Lazy.of(plus2)) == Lazy.of(f_plus2_times3(2))

    assert Lazy.of(3).ap(Lazy.of(plus2)).ap(Lazy.of(times3)) == Lazy.of(f_plus2_times3(3))


# Generated at 2022-06-24 00:09:54.255419
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    def fn():
        return 123

    assert Lazy(fn).to_validation() == Validation.success(fn())


# Generated at 2022-06-24 00:09:58.631289
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    expected_value = 2
    lazy = Lazy.of(lambda x: x + 1)
    maybe = Maybe.just(1)
    result = lazy.ap(maybe)

    assert result.get() == expected_value



# Generated at 2022-06-24 00:10:01.675502
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(5) == Lazy.of(5)
    assert Lazy.of(5) != Lazy.of('5')
    assert Lazy.of(5) != object()

# Generated at 2022-06-24 00:10:05.143058
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.utils import _eq

    assert _eq(
        Lazy(lambda x: 2 * x).map(lambda x: x + 1).get(2),
        5
    )
    assert _eq(
        Lazy(lambda x, y: x * y).map(lambda x: x + 1).get(2, 2),
        6
    )



# Generated at 2022-06-24 00:10:08.452069
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    # given
    lazy = Lazy.of(lambda x, y: x + y)

    # when
    try_ = lazy.to_try(1, 2)

    # then
    assert try_.get() == 3

# Generated at 2022-06-24 00:10:11.559878
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    l = Lazy.of(lambda x: x)
    assert l.ap(Box(lambda x: x)) == Lazy.of(lambda x: x)



# Generated at 2022-06-24 00:10:21.494087
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.applicative import Applicative
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Either
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(lambda x: x * 3).ap(Box(2)) == Box(6)
    assert Lazy.of(lambda x: x * 3).ap(Maybe.just(2)) == Maybe.just(6)
    assert Lazy.of(lambda x: x * 3).ap(Either.right(2)) == Either.right(6)
    assert Lazy.of(lambda x: x * 3).ap(Try.success(2)) == Try.success(6)
    assert Lazy.of(lambda x: x * 3).ap

# Generated at 2022-06-24 00:10:24.865159
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert(Lazy.of(2).get() == 2)

    assert(Lazy(lambda: 2).get() == 2)

    assert(Lazy(lambda x, y: x + y).get(2, 3) == 5)



# Generated at 2022-06-24 00:10:29.241655
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def some_fn(a):
        if a:
            raise ValueError('Error')
        return a

    assert Lazy(some_fn).to_try(False) == Try.success(False)

    assert Lazy(some_fn).to_try(True) == Try.failure(ValueError('Error'))


# Generated at 2022-06-24 00:10:40.864530
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    import unittest

    class TestLazy(unittest.TestCase):

        def test_of(self):
            self.assertEqual(Lazy.of("123").constructor_fn(), "123")
            self.assertEqual(Lazy.of({"key": "value"}).constructor_fn(), {"key": "value"})
            self.assertEqual(Lazy.of(123).constructor_fn(), 123)

        def test_map(self):
            self.assertEqual(Lazy.of(123).map(lambda x: x + 1).constructor_fn(), 124)

        def test_ap(self):
            self.assertEqual(Lazy.of(lambda x: x + 1).ap(Lazy.of(123)).constructor_fn(), 124)

       

# Generated at 2022-06-24 00:10:50.316776
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy(lambda: Maybe.just(1)).to_maybe() == Maybe.just(1)
    assert Lazy(lambda: 1).to_maybe() == Maybe.just(1)
    assert Lazy(lambda: None).to_maybe() == Maybe.nothing()
    assert Lazy(lambda: Maybe.nothing()).to_maybe() == Maybe.nothing()
    assert Lazy(lambda: Maybe.just(Maybe.nothing())).to_maybe() == Maybe.just(Maybe.nothing())


# Generated at 2022-06-24 00:10:52.243537
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x: x+1).get(1) == 2



# Generated at 2022-06-24 00:10:59.032406
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def success_fn():
        return 'Value'

    def error_fn():
        raise ValueError('Error')

    assert Lazy(success_fn).to_try() == Try.of(success_fn)
    assert Lazy(error_fn).to_try() == Try.of(error_fn)



# Generated at 2022-06-24 00:11:03.786043
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy = Lazy(lambda x: x)
    lazy1 = Lazy(lambda x: x)
    lazy.get(1)
    lazy1.get(1)
    assert lazy == lazy1
    lazy1.get(2)
    assert lazy != lazy1
    lazy2 = Lazy.of(2)
    assert lazy1 != lazy2

# Generated at 2022-06-24 00:11:12.991324
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # GIVEN
    lazy_data = Lazy(lambda *args: args[0] + args[1])
    folder = lambda value: Lazy.of(value + 1)
    # WHEN
    result = lazy_data.bind(folder)
    # THEN
    assert result.get(1, 2) == 4
    assert result.get(3, 4) == 8
    assert result.get(1, 2) == 4
    assert result.get(3, 4) == 8


# Generated at 2022-06-24 00:11:16.242676
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def id_(x):
        return x

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(id_) != Lazy.of(1)



# Generated at 2022-06-24 00:11:20.377737
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    lazy = Lazy.of(1)

    assert Box(1) == lazy.to_box()



# Generated at 2022-06-24 00:11:26.569501
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1

    lazy = Lazy(lambda: 2)
    assert lazy.get() == 2
    assert lazy.get() == 2

    count_calls = 0

    def mapper(value: int) -> int:
        nonlocal count_calls
        count_calls += 1

        return value + 1

    lazy = Lazy(lambda: 2).map(mapper)
    assert lazy.get() == 3
    assert count_calls == 1



# Generated at 2022-06-24 00:11:32.206100
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy(lambda: 1).to_try() == Try.of(lambda: 1)
    assert Lazy(lambda: 1 / 0).to_try() == Try.of(lambda: 1 / 0)


# Test for method of of class Lazy

# Generated at 2022-06-24 00:11:43.668036
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    # Should be True where both are evaluated both have the same value and constructor functions.
    assert Lazy.of(1) == Lazy.of(1)

    def function():
        return 1

    assert Lazy(function) != Lazy(function)
    assert Lazy(function) != Lazy.of(1)
    assert Lazy.of(1) != Lazy(function)
    assert Lazy(function).get() != Lazy.of(1).get()
    assert Lazy(function).get() == Lazy(function).get()
    assert Lazy.of(1).get() == Lazy.of(1).get()
    assert Lazy(function) != 1


# Generated at 2022-06-24 00:11:55.328720
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try, Error

    def not_raises_exception(*args):
        return 1

    assert (Lazy(not_raises_exception).to_try() == Try.of(not_raises_exception))
    assert (Lazy(not_raises_exception).to_try(1, 2, 3) == Try.of(not_raises_exception, 1, 2, 3))

    def raises_exception(*args):
        raise RuntimeError()

    assert (Lazy(raises_exception).to_try() == Try.of(raises_exception))
    assert (Lazy(raises_exception).to_try(1, 2, 3) == Try.of(raises_exception, 1, 2, 3))



# Generated at 2022-06-24 00:11:58.685809
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    def divide(a, b):
        return a / b

    divideLazy = Lazy(lambda x, y: divide(x, y))

    assert divideLazy.to_box(2, 4) == Box(0.5)


# Generated at 2022-06-24 00:12:05.623396
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.monoid import Sum
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    lazy_add = Lazy(add)
    result1 = lazy_add.map(lambda x: x + 1).to_validation(Sum(3), Sum(4))
    assert Validation.success(8) == result1

    result2 = lazy_add.to_validation(Sum(3), Sum(4))
    assert Validation.success(7) == result2

    def concat(a, b):
        return a + b

    lazy_concat = Lazy(concat)
    result1 = lazy_concat.map(lambda x: x + '!').to_validation('Hi', 'Bob')

# Generated at 2022-06-24 00:12:13.419180
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_a = Lazy.of(2)
    lazy_b = Lazy.of(3)

    result_a = lazy_a.map(lambda x: x + 1)
    result_b = lazy_b.map(lambda x: x + 1)

    assert result_a != result_b
    assert result_a.get() == 3
    assert result_b.get() == 4


# Generated at 2022-06-24 00:12:22.071517
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def _test_Lazy_ap_inner(fn1, fn2):
        error_msg = '\nFailed when call \nfn1: {} \nfn2: {} \n'

        lazy1 = Lazy.of(fn1)
        lazy2 = Lazy.of(fn2)

        func = lambda x, y: x + y

        lazy_res = lazy1.ap(lazy2)
        res = func(fn1, fn2)
        assert lazy_res.get() == res, '{}'.format(error_msg.format(fn1, fn2))

        lazy_res = lazy2.ap(lazy1)
        res = func(fn2, fn1)
        assert lazy_res.get() == res, '{}'.format(error_msg.format(fn1, fn2))



# Generated at 2022-06-24 00:12:26.692624
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    val = Lazy(lambda: 1).to_maybe()

    assert isinstance(val, Maybe)
    assert val.get_or_else(lambda: None) == 1
    assert str(val) == 'Just(1)'



# Generated at 2022-06-24 00:12:31.158025
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def my_function(x: int):
        return Lazy.of(x ** 2)

    result = Lazy.of(2).bind(my_function)

    assert result == Lazy.of(4)

# Generated at 2022-06-24 00:12:36.177049
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right, Left

    assert Lazy.of(None).to_either() == Right(None)

    assert Lazy(lambda: 1 / 0).to_either() == \
        Left(ZeroDivisionError('division by zero'))


# Generated at 2022-06-24 00:12:39.427846
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    try:
        Lazy.of(1).to_validation()
    except ValueError:
        assert False, 'Unit test should not raise ValueError'
    else:
        assert True, 'Unit test returned expected result'



# Generated at 2022-06-24 00:12:48.010652
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def _f():
        return 'result'

    assert str(Lazy(_f)) == 'Lazy[fn=<function _f at 0x7fcd5f547d90>, value=None, is_evaluated=False]'
    assert str(Lazy(_f).get()) == 'Lazy[fn=<function _f at 0x7fcd5f547d90>, value=result, is_evaluated=True]'
    assert str(Lazy(_f).map(lambda x: x).get()) == 'Lazy[fn=<function _f at 0x7fcd5f547d90>, value=result, is_evaluated=True]'



# Generated at 2022-06-24 00:12:50.780192
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    assert Lazy.of(3).map(lambda x: x + 1).get() == 4
    assert Lazy.of(3).map(lambda x: x + 1).map(lambda x: x * 2).get() == 8



# Generated at 2022-06-24 00:13:00.868385
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    def f(x):
        return x + 1
    def f_lazy(x):
        return Lazy.of(x + 2)
    def identity(x):
        return x
    f1 = Lazy(f)
    f2 = f1.map(f_lazy).ap(Lazy.of(f)).bind(Lazy.of)
    assert f2.to_box(2) == Box(5)
    assert f2.bind(identity).to_box(2) == Box(5)
    assert Lazy.of(4).to_box() == Box(4)
    assert Lazy(f).to_box(2) == Box(3)


# Generated at 2022-06-24 00:13:03.940186
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def return_1(*param):
        return 1

    lazy = Lazy(return_1)
    assert lazy.get() == 1

# Generated at 2022-06-24 00:13:07.309084
# Unit test for method map of class Lazy
def test_Lazy_map():
    def sum(a):
        return a + 1

    lazy = Lazy(sum)

    assert lazy.map(lambda a: a + 2).get(1) == 4



# Generated at 2022-06-24 00:13:11.206130
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy.of(1).map(lambda x: x+1).to_maybe() == Maybe.just(2)


# Generated at 2022-06-24 00:13:18.826611
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    # pylint: disable=unused-variable
    import pytest
    from pymonet.box import Box

    def f1(*args):
        return 'foo'

    def f2(*args):
        return 'bar'

    lazy1 = Lazy.of(f1)
    assert isinstance(lazy1.to_box(), Box)
    assert lazy1.to_box().get() == 'foo'

    lazy2 = Lazy.of(f2)
    assert isinstance(lazy2.to_box(), Box)
    assert lazy2.to_box().get() == 'bar'



# Generated at 2022-06-24 00:13:26.605166
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def side_effect():
        # this function change Lazy value from 'value' to 'new value'
        lazy.value = 'new value'

    lazy = Lazy.of('value')
    assert lazy.to_validation() == Validation.success('value')
    assert lazy.get() == 'value'

    side_effect()
    assert lazy.to_validation() == Validation.success('new value')
    assert lazy.get() == 'new value'


# Generated at 2022-06-24 00:13:28.654978
# Unit test for method map of class Lazy
def test_Lazy_map():
    def func(x):
        return x

    lazy = Lazy(func).map(lambda x: x + 1)
    assert lazy.get(2) == 3



# Generated at 2022-06-24 00:13:38.560750
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    # given
    import pymonet.monad
    import operator

    lazy = pymonet.monad.Lazy.of(1)
    # then
    assert str(lazy) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x{:x}>, value=None, is_evaluated=False]'.format(lazy_lambda_fn_address())
    # and
    lazy = lazy.map(operator.add)
    assert str(lazy) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x{:x}>, value=None, is_evaluated=False]'.format(lazy_map_lambda_fn_address())
    # and
    lazy.value = 1

# Generated at 2022-06-24 00:13:42.171406
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    test_value = 1
    assert Lazy.of(test_value).to_box() == Box(test_value)


# Generated at 2022-06-24 00:13:44.815047
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    lazy = Lazy.of('value')
    either_value = lazy.to_either()
    assert either_value.get() == 'value'



# Generated at 2022-06-24 00:13:54.412550
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(1.0).to_either() == Right(1.0)
    assert Lazy.of('c').to_either() == Right('c')
    assert Lazy.of([1, 2]).to_either() == Right([1, 2])
    assert Lazy.of({'a': 1, 'b': 2}).to_either() == Right({'a': 1, 'b': 2})
    assert Lazy.of({}).to_either() == Right({})
    assert Lazy.of(True).to_either() == Right(True)
    assert Lazy.of(None).to_either() == Right(None)

   

# Generated at 2022-06-24 00:14:01.634900
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.validation import ValidationFailure, ValidationSuccess

    lazy = Lazy.of(1)
    assert lazy.bind(lambda x: Box(x)).get() == 1
    assert lazy.bind(lambda x: Validation.success(x)).get() == 1
    assert lazy.bind(lambda x: Validation.failure(ValidationFailure(x))).is_failure()
    assert lazy.bind(lambda x: Try(int, x)).get() == 1

    lazy = Lazy.of('1')
    assert lazy.bind(lambda x: Box(int(x))).get() == 1

# Generated at 2022-06-24 00:14:04.312177
# Unit test for constructor of class Lazy
def test_Lazy():
    lazy = Lazy.of(1)
    assert lazy == Lazy.of(1)
    assert lazy != Lazy.of(2)
    assert lazy != None


# Generated at 2022-06-24 00:14:09.480486
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation
    from pymonet.validation_exception import ValidationException

    assert Lazy(lambda: 5).to_validation() == Validation.success(5)
    assert Lazy(lambda: ValidationException([1, 2, 3])).to_validation() == Validation.failure([1, 2, 3])

# Generated at 2022-06-24 00:14:14.004975
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7faf8ea6e840>, value=None, is_evaluated=False]', '__str__ for Lazy'


# Generated at 2022-06-24 00:14:16.238036
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test():
        return 1

    assert Lazy(test).get() == 1


# Generated at 2022-06-24 00:14:22.946001
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def add_three(x):
        return x + 3

    assert Lazy(add_three).to_validation(3) == Validation.success(6)
    assert Lazy(add_three).to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:14:26.774384
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda value: value + 1).get() == 2
    assert Lazy(lambda: 2).map(lambda value: value + 1).get() == 3


# Generated at 2022-06-24 00:14:29.809194
# Unit test for method get of class Lazy
def test_Lazy_get():
    def sum(x, y):
        return x + y

    lazy = Lazy(lambda: sum(1, 1))

    assert lazy.get() == 2



# Generated at 2022-06-24 00:14:34.742726
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert str(Lazy(Box)) == 'Lazy[fn=<function Box at 0x10be4b0e0>, value=None, is_evaluated=False]'
    assert str(Lazy(Maybe)) == 'Lazy[fn=<function Maybe at 0x10be4b378>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:14:37.226956
# Unit test for method to_either of class Lazy
def test_Lazy_to_either(): # pragma: no cover
    from pymonet.either import Right, Left

    assert Right(1) == Lazy(lambda: 1).to_either()
    assert Left(None) == Lazy(lambda: None).to_either()



# Generated at 2022-06-24 00:14:40.979921
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x + 10).map(lambda x: x + 10).get(10) == 30



# Generated at 2022-06-24 00:14:46.253375
# Unit test for constructor of class Lazy
def test_Lazy():
    def f(x):
        return x + 1

    def g(x):
        return x * 2

    x = Lazy(f)

    assert x.get(1) == f(1)
    assert x.map(g).get(1) == g(x.get(1))
    assert x.get(1) == f(1)



# Generated at 2022-06-24 00:14:52.079569
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(x: int) -> int:
        return x * 2

    def g(x: int) -> int:
        return x * 3

    lazy = Lazy(f)
    assert lazy == Lazy(f)
    assert Lazy.of(5) == Lazy(lambda *args: 5)
    assert lazy.bind(g) == Lazy(lambda *args: g(f(*args)))
    assert not lazy.bind(g).is_evaluated
    assert lazy.bind(g).get(1) == 6
    assert lazy.bind(g).get(2) == 12



# Generated at 2022-06-24 00:14:54.212792
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    val = Right(1).join().to_either().get()
    assert val == 1


# Generated at 2022-06-24 00:15:04.336344
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def fn1(val: int) -> int:
        return val + 10

    def fn2(val: int) -> int:
        return val + 20

    # test map
    assert Lazy.of(1).map(fn1) == Lazy.of(11)
    assert Lazy.of(1).map(fn1).map(fn2) == Lazy.of(31)
    assert Lazy.of(1).map(lambda x: Box(x)).map(lambda x: x.map(fn1)) == Lazy.of(Box(11))
    assert Lazy.of(1).bind(lambda x: Lazy.of(Maybe.just(2))).map(lambda x: x.map(lambda y: y + 1)) == L

# Generated at 2022-06-24 00:15:07.527924
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy.of('').to_maybe() == Maybe.empty()
    assert Lazy.of('result').to_maybe() == Maybe.just('result') == Maybe.of('result')



# Generated at 2022-06-24 00:15:13.396801
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    result1 = Lazy(lambda: 1).to_try()
    print(result1)
    assert isinstance(result1, Try)
    assert result1.is_success
    assert result1.get() == 1

    result2 = Lazy(lambda: 1 / 0).to_try()
    print(result2)
    assert isinstance(result2, Try)
    assert not result2.is_success
    assert isinstance(result2.error, ZeroDivisionError)



# Generated at 2022-06-24 00:15:15.053080
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    fn = lambda x: x + x
    assert Lazy(fn).to_either(1) == Right(fn(1))

# Generated at 2022-06-24 00:15:19.189459
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_try import Try

    def constructor_fn(x):
        return x * x

    lazy = Lazy(constructor_fn)
    assert lazy.get(8) == 64
    assert lazy.is_evaluated == True
    assert lazy.value == 64

    def raise_value_error(x):
        raise ValueError()

    lazy = Lazy(raise_value_error)
    assert isinstance(lazy.to_try(8), Try)
    assert lazy.is_evaluated == False
    assert lazy.value is None

# Generated at 2022-06-24 00:15:24.440965
# Unit test for constructor of class Lazy
def test_Lazy():
    def function():
        raise ValueError()

    assert Lazy.of(1)
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    try:
        Lazy(function)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-24 00:15:29.264508
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def raise_exception(*args):
        raise Exception('Exception message')

    assert Lazy(lambda: 5).to_try() == Try.success(5)
    assert Lazy(raise_exception).to_try() == Try.failure(Exception('Exception message'))



# Generated at 2022-06-24 00:15:39.673046
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    # Test without arguments
    try_success = Lazy.of(10).to_try()
    try_failure = Lazy.of(10 / 0).to_try()

    assert isinstance(try_success, Try)
    assert try_success.is_success
    assert not try_success.is_failure
    assert try_success.get() == 10

    assert isinstance(try_failure, Try)
    assert try_failure.is_failure
    assert not try_failure.is_success
    with pytest.raises(ZeroDivisionError):
        try_failure.get()

    # Test with arguments
    try_success = Lazy(lambda x, y, z: x + y + z).to_try(1, 2, 3)

# Generated at 2022-06-24 00:15:48.775533
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda x: x + 1).get(5) == 6
    assert Lazy.of(5).get() == 5
    assert Lazy.of(5).bind(lambda x: Lazy(lambda y: x + y)).get(5) == 10
    assert Lazy.of(5).map(lambda x: x + 2).get() == 7
    assert Lazy.of(5).to_box().get() == 5
    assert Lazy.of(5).to_maybe().get() == 5
    assert Lazy.of(Lazy.of(5)).bind(lambda x: x).to_maybe().get() == 5
    assert Lazy.of(4).ap(Lazy.of(lambda x: x + 2)).get() == 6
    assert Lazy.of(6).to_try().get() == 6


# Generated at 2022-06-24 00:15:52.973406
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy(lambda: 5).to_try() == Try.success(5)


# Generated at 2022-06-24 00:15:55.726577
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function <lambda> at 0x7fafb89d0620>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:16:03.526534
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.functors.functor import Functor
    from pymonet.applicative import Applicative

    def f(x):
        return x + 1

    def g(x):
        return x * 2

    def h(x):
        return x * 3

    def i(x):
        return x * 4

    assert Functor.test(Lazy.of, f, 1)
    assert Applicative.test(Lazy.of, f, 2)

    assert Lazy(f).map(g).get(2) == g(f(2))
    assert Lazy(f).ap(Lazy(g)).get(2) == f(g(2))
    assert Lazy(f).bind(lambda v: Lazy.of(g(v))).get(2) == g(f(2))


# Generated at 2022-06-24 00:16:09.493350
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 'a').__eq__(Lazy(lambda: 'a'))
    assert Lazy(lambda: 'a').__eq__(Lazy(lambda: 'a')) is False
    assert Lazy(lambda: 'a').__eq__(None) is False
    assert Lazy(lambda: 'a').__eq__(object) is False
    assert Lazy(lambda: 'a').__eq__(1) is False


# Generated at 2022-06-24 00:16:14.392999
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """Unit test for method bind of class Lazy."""
    assert Lazy(lambda x: x + 3).bind(lambda x: Lazy(lambda: x * x)).get(5) == 64
    assert Lazy(lambda x: x + 3).bind(lambda x: Lazy(lambda: x * x)).get(3) == 36

# Generated at 2022-06-24 00:16:17.529625
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda: 2).to_box().value == 2
    assert Lazy(lambda x: x + 2).to_box(3).value == 5
    assert Lazy(lambda: Box(2)).to_box().value.value == 2



# Generated at 2022-06-24 00:16:21.559869
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.monad_applicative import MonadApplicative

    class MockLazy(Lazy, Monad, MonadApplicative, Functor):
        pass

    assert Lazy.of(10) == MockLazy.of(10)



# Generated at 2022-06-24 00:16:25.529625
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy().to_validation() == Validation.success(1)  # type: ignore



# Generated at 2022-06-24 00:16:35.956158
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_maybe().get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_box().get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_either().get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_validation().get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_try().get() == 2


# Generated at 2022-06-24 00:16:41.420136
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(value):
        def fn(x):
            return x + value
        return Lazy(fn)

    lazy = Lazy(lambda: 1)
    assert lazy.bind(f(1)).get() == 2



# Generated at 2022-06-24 00:16:48.977534
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    class TestError(Exception):
        pass

    def raise_test_error():
        raise TestError()

    def value_1():
        return 1

    def value_2():
        return 2

    def value_1_string():
        return '1'

    def value_1_list():
        return [1]

    def value_2_list():
        return [2]

    def value_1_error():
        return TestError()

    def value_2_error():
        return TestError()

    def value_1_error():
        raise TestError()

    def value_2_error():
        raise TestError()

    def value_both_error():
        raise TestError()

    def value_both_error_2():
        raise TestError()

    def value_both_error_2():
        raise Test

# Generated at 2022-06-24 00:16:54.464434
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.box import Box

    def fn(a: str) -> str:
        return str(a)

    def fn_to_bind(a: str) -> Lazy:
        return lazy(lambda: a)

    a = lazy(lambda: 'a')
    b = a.ap(Box(fn)).ap(Box(fn_to_bind))
    print(b.get())

