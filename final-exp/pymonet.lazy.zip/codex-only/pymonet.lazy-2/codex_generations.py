

# Generated at 2022-06-24 00:07:07.033565
# Unit test for method map of class Lazy
def test_Lazy_map():
    def func(value): return value

    lazy = Lazy.of(lambda x: x + 1)
    assert lazy.map(lambda x: x + 2) == Lazy(lambda x: x + 3)
    assert lazy.map(lambda x: x ** 2) == Lazy(lambda x: (x + 1) ** 2)
    assert lazy.map(func) == Lazy(lambda x: x + 1)
    assert lazy.map(lambda x: x + 1).map(lambda x: x + 2) == Lazy(lambda x: x + 3)


# Generated at 2022-06-24 00:07:11.271696
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def fn(*args):
        return 'value of fn'

    value = Lazy(fn).to_validation()

    assert isinstance(value, Validation)
    assert value.is_success()
    assert value.get() == 'value of fn'


# Generated at 2022-06-24 00:07:15.881946
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try

    def my_lazy_test_fn(*args):
        return Lazy(lambda *_: "A")

    try_my_lazy_test_fn = Try.of(my_lazy_test_fn, "test", "arguments")

    assert try_my_lazy_test_fn == Try.of(lambda: Lazy.of("A"), "test", "arguments")

# Generated at 2022-06-24 00:07:26.215397
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor

    fn_one = lambda: 1

    lazy_one = Lazy(fn_one)
    lazy_one_observed = Lazy.of(1)

    assert lazy_one_observed == lazy_one

    lazy_one_observed_map = lazy_one_observed.map(lambda num: num + 1)
    assert lazy_one_observed_map != lazy_one_observed

    lazy_two = Lazy.of(2)
    assert lazy_one_observed_map != lazy_two

    assert lazy_one_observed.ap(lazy_one_observed_map).get() == lazy_one_observed_map.get()


# Generated at 2022-06-24 00:07:28.330594
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    assert(Lazy(lambda: 1).map(lambda x: 2 * x).get() == 2)



# Generated at 2022-06-24 00:07:39.409950
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.either import Left
    from pymonet.monad_try import Failure
    from pymonet.maybe import Just, Nothing

    assert Lazy(lambda: 1).to_try() == Try.of(lambda: 1)
    assert Lazy(lambda: Just(1)).to_try() == Try.of(lambda: Just(1))
    assert Lazy(lambda: 1 / 0).to_try() == Failure(ZeroDivisionError)
    assert Lazy(lambda: Just(1 / 0)).to_try() == Failure(ZeroDivisionError)
    assert Lazy(lambda: 1 / 0).map(lambda x: x + 1).to_try() == Failure(ZeroDivisionError)
    assert Lazy(lambda: 1).map(lambda x: x / 0).to_try() == Failure(ZeroDivisionError)


# Generated at 2022-06-24 00:07:48.134230
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def two_args_add(x, y):
        return x + y

    def two_args_sub(x, y):
        return x - y

    case = Lazy.of(1)
    # not empty Lazy with function return 1
    assert case.constructor_fn() == 1

    lazy_value = case.ap(Lazy.of(add))
    # lazy_value should be Lazy[int] with value 2
    assert lazy_value.constructor_fn() == 2

    new_lazy_value = lazy_value.ap(Lazy.of(add))
    # new_lazy_value should be Lazy[int] with value 3
    assert new_lazy_value.constructor_fn

# Generated at 2022-06-24 00:07:55.735370
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for Lazy.get method.
    """
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    # Given
    @Functor
    class TestFunctor1(object):
        def map(self, mapper: Callable[[U], W]) -> Lazy[U, W]:
            def lambda_mapper(*args):
                return 'new value'

            return Lazy(lambda_mapper)

    test_functor1 = TestFunctor1()
    test_functor2 = TestFunctor1()
    test_functor3 = TestFunctor1()

    @Monad
    class TestMonad1(object):
        def map(self, mapper: Callable[[U], W]) -> Lazy[U, W]:
            return test_functor1

# Generated at 2022-06-24 00:07:58.901078
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda: 'test')) == 'Lazy[fn=<function Lazy.<lambda> at 0x103863ea0>, value=None, is_evaluated=False]'

# Unit tests for method __eq__ of class Lazy

# Generated at 2022-06-24 00:08:04.413028
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left
    from pymonet.either import Right

    # given
    lazy_value = Lazy.of(1)

    # when
    result = lazy_value.to_either()

    # then
    assert Right(1) == result

# Generated at 2022-06-24 00:08:13.404860
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of("a").get() == "a"
    assert Lazy.of("a").get("a", "b") == "a"
    assert Lazy.of("a").get("b", "c") == "a"
    assert Lazy.of("a").get("a", "b", "c") == "a"
    assert Lazy.of("a").get("a", "b", "c", "d") == "a"
    assert Lazy.of("a").get("a", "b", "c", "d", "e") == "a"
    assert Lazy.of("a").get("a", "b", "c", "d", "e", "f") == "a"

# Generated at 2022-06-24 00:08:20.737475
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left

    x = Lazy(lambda: 1)
    y = Right(1)
    assert (x.to_either() == y)

    x = Lazy(lambda: 1/0)
    y = Left(ZeroDivisionError('division by zero'))
    assert (x.to_either() == y)

    x = Lazy(lambda: '1')
    y = Right('1')
    assert (x.to_either() == y)



# Generated at 2022-06-24 00:08:30.211682
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.functions import identity

    test_obj_1 = Lazy(lambda *args: 0)
    test_obj_2 = Lazy(identity)
    test_obj_3 = Lazy(lambda *args: 'test')

    assert str(test_obj_1) == 'Lazy[fn=<function LazyTestCase.<locals>.test_func at 0x10e664400>, value=0, is_evaluated=False]'
    assert str(test_obj_2) == 'Lazy[fn=<function identity at 0x10ea3e400>, value=None, is_evaluated=False]'

# Generated at 2022-06-24 00:08:32.632143
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda: 1).to_box() == Box(1)



# Generated at 2022-06-24 00:08:37.167322
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet import Box
    from pymonet.utils import id

    value = Lazy(id)

    assert str(value) == 'Lazy[fn=<function id at 0x7f946b5a5a60>, value=None, is_evaluated=False]'

    value = Lazy(id).map(Box.of)

    assert str(value) == 'Lazy[fn=<function <lambda> at 0x7f946acf8f28>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:08:42.097216
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    # Arrange
    from pymonet.either import Right

    lazy = Lazy.of('lazy')

    # Act
    actual = lazy.to_either()

    # Assert
    assert actual == Right('lazy')

# Generated at 2022-06-24 00:08:48.433709
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x{:x}>, value=None, is_evaluated=False]'.format(id(lambda: 1))
    assert str(Lazy(lambda: 1).get()) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x{:x}>, value=1, is_evaluated=True]'.format(id(lambda: 1))



# Generated at 2022-06-24 00:08:59.567213
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_if_both_not_evaluated():
        lazy1 = Lazy(lambda x: x + 1)
        lazy2 = Lazy(lambda x: x + 1)
        assert lazy1 == lazy2

    def test_if_any_evaluated():
        lazy1 = Lazy(lambda x: x + 1)
        lazy2 = Lazy(lambda x: x - 1)
        lazy3 = Lazy(lambda x: x - 1)
        lazy4 = lazy1.bind(lambda x: lazy2)
        lazy5 = lazy3.bind(lambda x: lazy2)
        assert lazy4 != lazy1
        assert lazy4 != lazy2
        assert lazy4 == lazy5

    test_if_both_not_evaluated()
    test_if_any_evaluated()



# Generated at 2022-06-24 00:09:09.812056
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_set import Set
    from pymonet.monad_list import List

    def division(x):
        return x / 2

    def division_of_set(x: Set[int]):
        return Set.unit(x).bind(division)

    assert Lazy.of(5).get() == 5
    assert Lazy.of(List.unit(5)).get() == list(List.unit(5))
    assert Lazy.of(Set.unit(5)).get() == set(Set.unit(5))

    assert Lazy(division_of_set).get(Set.unit(5)) == division_of_set(Set.unit(5))
    assert Lazy(division_of_set).get(Set.unit(10)) == division_of_set(Set.unit(10))

   

# Generated at 2022-06-24 00:09:20.848732
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def id_fn(a):
        return a

    def bomb(a):
        raise Exception('Boom!')

    def mapper(a):
        return a + 1

    assert Lazy(id_fn) == Lazy(id_fn)
    assert Lazy(id_fn) != Lazy(bomb)
    assert Lazy(id_fn) == Lazy(id_fn).map(mapper)
    assert Lazy(id_fn).map(mapper) == Lazy(id_fn).map(mapper)
    assert Lazy(lambda a: (a, a)).map(lambda a: (a[1], a[0])) != Lazy(lambda a: (a, a))

# Generated at 2022-06-24 00:09:26.499522
# Unit test for method bind of class Lazy
def test_Lazy_bind(): # pragma: no cover
    def fn(value: int) -> Lazy[int, int]:
        return Lazy(lambda: value + 1)

    lazy = Lazy(lambda: 1)
    assert lazy.bind(fn) == Lazy(fn(1).get).get == Lazy(lambda: 2)

    lazy = Lazy(lambda: 1)
    assert lazy.bind(lambda value: Lazy.of(value + 1)) == Lazy(fn(1).get).get == Lazy(lambda: 2)

# Generated at 2022-06-24 00:09:28.596314
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy(lambda: 'value').to_either() == Right('value')



# Generated at 2022-06-24 00:09:35.563593
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert Lazy(lambda: 'ok').__str__() == "Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x7f26d1852c80>, value=None, is_evaluated=False]"
    assert Lazy(lambda: 'ok').fold(lambda: 'ok').__str__() == "Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x7f26d1852c80>, value='ok', is_evaluated=True]"


# Generated at 2022-06-24 00:09:38.358896
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(2).map(lambda x: x * 3) == Lazy.of(6)
    assert Lazy.of(2).map(lambda x: x * 3) != Lazy.of(3)


# Generated at 2022-06-24 00:09:40.531587
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def fn():
        return 2

    lazy_fn = Lazy(fn)
    assert lazy_fn.to_maybe() == Maybe.just(2)


# Generated at 2022-06-24 00:09:44.627236
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy(lambda: 1).to_box().get() == 1
    assert Lazy(lambda: lambda a, b, c=3: a + b + c).to_box()(1, 2, c=3) == Box(6)



# Generated at 2022-06-24 00:09:51.576782
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    def _check_lazy_to_either(lazy):
        assert lazy.to_either(None) == Right(2)

    _check_lazy_to_either(Lazy.of(1).map(lambda x: x + 1))
    _check_lazy_to_either(Lazy(lambda x: x + 1))



# Generated at 2022-06-24 00:09:58.801017
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left

    def to_either(value: Maybe[int]) -> Either[int, str]:
        """
        Returns Right if Maybe is not empty and Left if Maybe is empty

        :param value: Maybe contains some value
        :type value: Maybe[int]
        :returns: either monad
        :rtype: Either[int, str]
        """
        return value.to_either('value is empty')

    lazy = Lazy(lambda: Maybe.just(1))
    assert lazy.to_either() == Right(1)

    lazy = Lazy(lambda: Maybe.none())
    assert lazy.to_either() == Left('value is empty')

    lazy = Lazy(lambda: Maybe.just(1)).bind(to_either)
    assert lazy

# Generated at 2022-06-24 00:10:06.502721
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    # Given
    class FakeException(Exception):
        pass

    def func_raise_exception(*args, **kwargs):
        raise FakeException('something is wrong!')

    def func_return_value(*args, **kwargs):
        return args, kwargs

    lazy = Lazy.of(1)

    # When
    try:
        str(Lazy(func_raise_exception))
    except FakeException:
        pass

    # Then
    assert str(Lazy(func_raise_exception)) == 'Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x10f7fea60>, value=None, is_evaluated=False]'

# Generated at 2022-06-24 00:10:12.668716
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    assert Lazy.of(2).map(lambda num: num * 100) == Lazy(lambda: 200)

    assert Lazy(lambda: 2).map(None) == Lazy(lambda: 2)

    assert Lazy(lambda: 2).map(lambda num: num * 100).map(lambda num: num + 100) == Lazy(lambda: 300)

    assert Lazy.of(2).map(lambda num: num * 100).map(lambda num: num / 100) == Lazy(lambda: 2)



# Generated at 2022-06-24 00:10:20.911895
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    my_lazy = Lazy.of(4)
    assert my_lazy.to_maybe() == Maybe.just(4)

    my_lazy = Lazy.of(Box(4))
    assert my_lazy.to_maybe() == Maybe.just(Box(4))

    my_lazy = Lazy.of(None)
    assert my_lazy.to_maybe() == Maybe.nothing

    my_lazy = Lazy.of(Box(None))
    assert my_lazy.to_maybe() == Maybe.nothing



# Generated at 2022-06-24 00:10:23.723572
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from tests.helpers import assert_box_equals

    assert_box_equals(Box(2), Lazy.of(2).to_box())



# Generated at 2022-06-24 00:10:26.699271
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def func(*args):
        x = args[0]
        return x + 1

    assert Lazy(func).to_try() == Try(func)

# Generated at 2022-06-24 00:10:34.086763
# Unit test for constructor of class Lazy
def test_Lazy():
    import pytest
    from pymonet.box import Box

    def f(x):
        return x + 1

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(f).map(lambda x: x + 1)
    assert Lazy(f) != Lazy(f).map(lambda x: x + 1).get()
    assert Lazy(Box(5)).bind(lambda x: Lazy(Box(x + 1))).constructor_fn() == Lazy(Box(6))
    assert Lazy(Box(5)).bind(lambda x: Lazy(Box(x + 1))).get() == Lazy(Box(6)).get()
    with pytest.raises(AssertionError):
        assert Lazy(f) == Lazy(f).get()

# Generated at 2022-06-24 00:10:40.019832
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    """
    Test that method to_validation of class Lazy returns Validation with value returned by constructor_fn.
    """
    from pymonet.validation import Validation

    lazy = Lazy(lambda x: x + 1)

    assert lazy.to_validation(1) == Validation.success(2)

# Generated at 2022-06-24 00:10:41.857513
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)


# Generated at 2022-06-24 00:10:46.232723
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(3).map(lambda x: x + 2) == Lazy.of(3).map(lambda x: x + 2)
    assert Lazy(lambda x: x + 2) == Lazy(lambda x: x + 2)



# Generated at 2022-06-24 00:10:51.148603
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    assert str(Lazy.of(2).map(lambda x: x * 2)) == 'Lazy[fn=<function Lazy_map.<locals>.<lambda> at 0x7fa48d38b048>, value=4, is_evaluated=False]'



# Generated at 2022-06-24 00:11:02.781944
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def divide(n, d):
        return n / d

    def divide_check(n, d):
        if d == 0:
            raise Exception("can't divide by zero")
        return n / d

    try_divide_0 = Lazy(lambda d: divide(1, d)).to_try(0)
    try_divide_2 = Lazy(lambda d: divide(1, d)).to_try(2)
    try_divide_check_0 = Lazy(lambda d: divide_check(1, d)).to_try(0)
    try_divide_check_2 = Lazy(lambda d: divide_check(1, d)).to_try(2)


# Generated at 2022-06-24 00:11:07.474685
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from unittest.mock import Mock

    a = Lazy(Mock())
    b = Lazy(Mock())
    b._compute_value()

    assert str(a) == 'Lazy[fn=<Mock id="4173954176">, value=None, is_evaluated=False]'
    assert str(b) == 'Lazy[fn=<Mock id="4173954176">, value=None, is_evaluated=True]'


# Generated at 2022-06-24 00:11:15.686008
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def function_1(args):
        return args
    def function_2(args):
        return args
    def function_3(args):
        return 1

    lazy_1 = Lazy(function_1)
    lazy_2 = Lazy(function_2)
    lazy_3 = Lazy(function_3)

    assert lazy_1._compute_value(1) == lazy_1.get(1)
    assert lazy_1 == lazy_2
    assert lazy_1 != lazy_3
    assert lazy_1 != 1

# Generated at 2022-06-24 00:11:19.543321
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(1).to_box() == Box(1)


# Generated at 2022-06-24 00:11:29.351095
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Lazy.of(None).map(lambda x: x).get() == None
    assert Lazy.of(33).map(lambda x: x).get() == 33
    assert Lazy.of(33).map(lambda x: x + 3).get() == 36
    assert Lazy.of(33).map(lambda x: Box(x)).get() == Box(33)

    def mapper(x):
        return Maybe.just(x)

    assert Lazy.of(33).map(mapper).get() == Maybe.just(33)

    def mapper(x):
        return lambda y: y + x

    assert Lazy.of(1).map(lambda x: lambda y: y + x).get()(2) == 3
   

# Generated at 2022-06-24 00:11:34.736635
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    def test_func(x: int) -> int:
        return x + 33

    result = Lazy(test_func).to_either(2)

    assert result == Right(35)



# Generated at 2022-06-24 00:11:45.982640
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """

    from .monad import Monad
    from pymonet.either import Right

    def add_one_and_pass(x):
        return Right(x + 1)

    def add_one(x):
        return Lazy.of(x + 1)

    def add_two_to_one(x):
        return Lazy.of(x + 2)

    Monad.test_monad(Lazy.of(4), add_one, add_two_to_one)
    Monad.test_monad(Lazy.of(4).bind(add_one_and_pass), add_one, add_two_to_one)


# Generated at 2022-06-24 00:11:52.308582
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def mapper1(value):
        return value + 1

    def mapper2(value):
        return value * 2

    def mapper3(value):
        return value

    def mapper4(value):
        return value

    assert Lazy(mapper1).ap(Lazy(mapper3).ap(Lazy(mapper4))) == Lazy(mapper1).ap(Lazy(mapper3))

# Generated at 2022-06-24 00:11:55.830329
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy().to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:11:59.425256
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def one_add(something):
        return something + 1

    def five_add(something):
        return something + 5

    a = Lazy.of(1).map(one_add)
    b = Lazy.of(5).map(five_add)

    assert a.ap(b).get() == 7

# Generated at 2022-06-24 00:12:04.565504
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from tests.test_monad_class import TestMonad
    from tests.test_box_class import TestBox
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    test_box = TestBox()
    test_monad = TestMonad()
    lazy = Lazy.of('test_value')

    test_box.test_box(lazy.to_box())
    test_monad.test_monad(lazy.to_box())

    assert lazy.to_box() == Box('test_value')



# Generated at 2022-06-24 00:12:07.346066
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    # given
    lazy = Lazy.of(1)

    # when
    actual = str(lazy)

    # then
    expected = 'Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x7f01983b6598>, value=1, is_evaluated=True]'
    assert actual == expected



# Generated at 2022-06-24 00:12:08.567626
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    def f():
        return 2

    lazy = Lazy(f)
    assert lazy.to_either() == 2

# Generated at 2022-06-24 00:12:18.064187
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy.of('foo').constructor_fn() == 'foo'
    assert Lazy.of('foo').constructor_fn(1) == 'foo'
    assert Lazy.of('foo').constructor_fn(1, 2, 3) == 'foo'
    assert Lazy.of('foo').constructor_fn(1, 2, 3, 4, 5) == 'foo'
    assert Lazy.of('foo').map(lambda x: x * 2).constructor_fn() == 'foofoo'

    assert Lazy(lambda x: Box(x)).map(lambda x: x * 2).constructor_fn(1) == Box(2)



# Generated at 2022-06-24 00:12:29.965219
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.monad_maybe import Maybe

    assert Lazy.of('').to_maybe() == Maybe.nothing()
    assert Lazy.of('').to_maybe('') == Maybe.nothing()
    assert Lazy.of(None).to_maybe() == Maybe.nothing()
    assert Lazy.of(None).to_maybe(None) == Maybe.nothing()

    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy.of(1).to_maybe(1) == Maybe.just(1)
    assert Lazy.of(1).to_maybe(2) == Maybe.just(1)
    assert Lazy.of(1).to_maybe('') == Maybe.just(1)

# Generated at 2022-06-24 00:12:38.820393
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.either import Right

    def function_one():
        return 'test'

    def function_two():
        return 'test'

    lazy_one = Lazy(function_one)

    test_Lazy___eq__.__annotations__['bool']

    assert (lazy_one == Lazy(function_one)) is False
    assert (lazy_one == Lazy(function_two)) is False
    assert (lazy_one == Lazy(lambda: 'test')) is False

    lazy_one.get()
    lazy_two = Lazy(function_one)

    assert (lazy_one == lazy_two) is True
    assert (lazy_one == Right(lazy_one)) is False

# Generated at 2022-06-24 00:12:41.698760
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Lazy(lambda: 2).to_either() == Right(2)
    assert Lazy(lambda: 2).to_either().value == 2



# Generated at 2022-06-24 00:12:46.937767
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def function(x: int) -> int:
        return x + 1

    lazy = Lazy(function).map(lambda x: x * 2)
    assert lazy.to_maybe(0) == Maybe.just(2)


# Generated at 2022-06-24 00:12:49.105542
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    lazy1 = Lazy(lambda x: x + 1)

    assert lazy1.map(lambda x: x * 10).get(1) == 20



# Generated at 2022-06-24 00:12:51.821655
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda a: lambda b: a + b).ap(Lazy(lambda: 2)).get(2) == 4


# Generated at 2022-06-24 00:13:01.720137
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    """Unit test for method to_try of class Lazy"""

    def thrower_function(a: int, b: int) -> int:
        """
        Function for testing Try monad.
        This function raise TypeError if invalid type of args is provided.
        """
        if not isinstance(a, int) or not isinstance(b, int):
            raise TypeError('both arguments must be of integer type')

        return a + b

    lazy_try = Lazy(thrower_function).to_try(1, '2')
    assert lazy_try.is_failure()
    assert isinstance(lazy_try.get_exception(), TypeError)

    lazy_try = Lazy(thrower_function).to_try(1, 2)
    assert lazy_try.is_success()
   

# Generated at 2022-06-24 00:13:05.529517
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Lazy(lambda: 27).to_either() == Right(27)


# Generated at 2022-06-24 00:13:11.595105
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda *args: 42).to_box() == Box(42)
    assert Lazy(lambda *args: 42).to_box(1, 2, 3, 4, 5) == Box(42)
    assert Lazy(lambda *args: 1).to_box(1) == Box(1)
    assert Lazy(lambda *args: (1, 2, 3, 4)).to_box() == Box((1, 2, 3, 4))


# Generated at 2022-06-24 00:13:15.810914
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    lazy = Lazy(lambda arg: arg)
    assert lazy.to_either(5) == Right(5)

    lazy = Lazy(lambda arg: arg + 1)
    assert lazy.to_either(5) == Right(6)

    lazy = Lazy(lambda arg: arg / 0)
    assert lazy.to_either(5) == Left("division by zero")



# Generated at 2022-06-24 00:13:22.676520
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    def f(x):
        return x**2

    assert Lazy.of(1).to_validation() == Validation.success(1)
    assert Lazy(f).to_validation(2) == Validation.success(4)
    assert Lazy(f).to_validation('2') == Validation.success(4)
    assert Lazy(f).to_validation('a') == Validation.failure(['a'])


# Generated at 2022-06-24 00:13:25.517955
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_get(a):
        return a

    lazy = Lazy(lambda: test_get(3))
    assert lazy.get() == test_get(3)



# Generated at 2022-06-24 00:13:31.707101
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    # Type: () -> Lazy[int, int]
    def div(x, y):
        return y / x

    # Type: () -> Lazy[int, int]
    def substraction(x):
        return 10 - x

    # Type: () -> Lazy[int, Try[int]]
    def lazy_to_try():
        return Lazy(div).\
            bind(lambda y: Lazy(substraction).ap(Lazy.of(y))).\
            to_try()

    assert lazy_to_try().get(5, 4) == Try.success(4)
    assert lazy_to_try().get(5, 0) == Try.failure("division by zero")


# Generated at 2022-06-24 00:13:38.530392
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def double(value):
        return value * 2

    validation = Lazy(lambda: 1).to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success()
    assert validation.get_or_else(lambda: 0) == 1

    validation = Lazy(lambda: 1).map(double).to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success()
    assert validation.get_or_else(lambda: 0) == 2

# Generated at 2022-06-24 00:13:44.196253
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.selector import is_failure_validation

    validation = Lazy(lambda: Validation.success(42)).to_validation()

    assert not is_failure_validation(validation)
    assert validation.get_or_else(None) == 42



# Generated at 2022-06-24 00:13:48.025820
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn(x): return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy.of(1)


# Generated at 2022-06-24 00:13:56.844622
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.functions import identity
    from pymonet.identity import Identity
    from pymonet.validation import Validation

    lazy = Lazy(identity)

    assert lazy.get('a') == 'a'
    assert lazy.get(2) == 2
    assert lazy.get(True)

    id1 = Identity('1')
    id2 = Identity('2')
    lazy_id1 = Lazy(lambda: id1)
    lazy_id2 = Lazy(lambda: id2)
    assert lazy_id1.get() == id1
    assert lazy_id2.get() == id2

    validation = Validation.success('success')
    lazy_validation = Lazy(lambda: validation)
    assert lazy_validation.get() == validation



# Generated at 2022-06-24 00:14:03.455143
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.function import pipeable

    def test_fn(*args):
        return args

    lazy = Lazy(test_fn)

    assert str(lazy) in 'Lazy[fn={}, value={}, is_evaluated={}]'.format(lazy.constructor_fn, lazy.value,
                                                                        lazy.is_evaluated)



# Generated at 2022-06-24 00:14:06.076737
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    def fn(*args):
        return args[0] + 10

    assert Lazy(fn).to_maybe(10) == Maybe.just(20)



# Generated at 2022-06-24 00:14:08.770722
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda: 'name')) == "Lazy[fn=<function Lazy.<lambda>.<locals>.<lambda> at 0x7f2d5e17c7b8>, value=None, is_evaluated=False]"


# Generated at 2022-06-24 00:14:11.501958
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    lazy = Lazy(lambda *_: 5)
    assert lazy.to_maybe() == Maybe.just(5)

# Generated at 2022-06-24 00:14:16.410261
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add_one(value: int) -> int:
        return value + 1

    assert add_one(1) == 2
    assert Lazy(add_one).get(1) == 2
    assert Lazy(add_one).get(1) == 2  # check that function was memoized


# Generated at 2022-06-24 00:14:22.650024
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def constructor(x):
        return x

    def fn(x):
        return Lazy(lambda: x)

    lazy = Lazy(constructor)
    lazy2 = lazy.ap(lazy.map(fn))

    assert lazy2.get(1) == 1



# Generated at 2022-06-24 00:14:27.532154
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma nocover
    def add1(a):
        return a + 1

    def add2(a): return a + 2

    def add3(a): return a + 3

    assert Lazy(add1) == Lazy(add1)
    assert Lazy(add1) != Lazy(add2)



# Generated at 2022-06-24 00:14:29.708956
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)



# Generated at 2022-06-24 00:14:33.052045
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    assert Lazy(lambda: 1) == Lazy(lambda: 1)

    assert Lazy(lambda: 1).get() == 1

    assert Lazy(lambda: 1) != Lazy(lambda: 2)

    assert Lazy(lambda: 1) != 1


# Generated at 2022-06-24 00:14:37.749078
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Special unit test for method bind of class Lazy
    """
    def f(x):
        return Lazy(lambda: x + ' world')

    def g(y):
        return Lazy(lambda: y + '!')

    lazy = Lazy(lambda: 'Hello')
    assert (lazy.bind(f).bind(g).get() == 'Hello world!')


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 00:14:46.130592
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Success, Failure

    def fn1(a):
        raise ValueError('error in fn1')

    def fn2(a):
        return a

    assert Lazy(fn1).to_try() == Failure(ValueError('error in fn1'))
    assert Lazy(fn2).to_try('value') == Success('value')



# Generated at 2022-06-24 00:14:48.720565
# Unit test for method get of class Lazy
def test_Lazy_get():
    # given
    def function():
        return 'a'
    lazy = Lazy(function)
    # when
    result = lazy.get()
    # then
    assert 'a' == result


# Generated at 2022-06-24 00:14:52.592624
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    def get_number() -> int:
        return 10

    lazy_number = Lazy(get_number).to_box()
    assert isinstance(lazy_number, Box)
    assert lazy_number.get() == 10


# Generated at 2022-06-24 00:14:56.833403
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    import pytest

    from pymonet.box import Box

    value = 'test_value'
    foo_box = Lazy.of(value).to_box()

    assert isinstance(foo_box, Box)
    assert foo_box.get() == 'test_value'



# Generated at 2022-06-24 00:15:03.887037
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def test_fn(a):
        return a

    def test_mapper(a):
        return a

    assert Lazy(test_fn) == Lazy(test_fn)
    assert Lazy(test_fn).map(test_mapper) == Lazy(test_fn).map(test_mapper)
    assert Lazy(test_fn).bind(lambda a: Lazy(test_fn)) == Lazy(test_fn).bind(lambda a: Lazy(test_fn))



# Generated at 2022-06-24 00:15:05.980733
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda: 1).to_box() == Box(1)



# Generated at 2022-06-24 00:15:11.559198
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def func(*args):
        return args

    lazyA = Lazy(func)
    lazyB = Lazy(func)
    lazyC = Lazy(func)

    assert lazyA == lazyB
    assert lazyA != lazyC

    lazyA._compute_value(1, 2, 3)
    lazyB._compute_value(1, 2, 3)
    lazyC._compute_value(1, 2, 4)

    assert lazyA == lazyB
    assert lazyA != lazyC

# Generated at 2022-06-24 00:15:13.757015
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    assert Lazy(lambda x: x).to_try(1) == Try(1)
    assert Lazy(lambda x: 1/0).to_try(1).get_or_raise() == ValueError



# Generated at 2022-06-24 00:15:25.521488
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe, Nothing
    from pymonet.monad_try import Try
    from pymonet.validation import Validation, Success, Failure

    def nothing(value):
        return Nothing()

    assert Lazy(lambda: 1).to_maybe() == Maybe.just(1)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda x: x).map(lambda a: Lazy(lambda: a + 1)).get(1) == 2
    assert Maybe.just(1).bind(lambda x: Lazy(lambda: x + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(nothing) == Maybe.nothing()

# Generated at 2022-06-24 00:15:35.404752
# Unit test for method get of class Lazy
def test_Lazy_get():
    """Unit Test for method get of class Lazy."""

    class Some:
        @staticmethod
        def function_a(*args):  # pylint: disable=unused-argument
            """Static method of Some class."""
            return args

        def class_function(self, a):
            """Instance method of Some class."""
            return a

        def class_function_with_args(self, *args):
            """Instance method of Some class."""
            return args

    # pylint: disable=invalid-name
    a = Some()
    lazy_of_static_function = Lazy.of(Some.function_a)
    lazy_of_instance_function = Lazy.of(a.class_function)

# Generated at 2022-06-24 00:15:38.911039
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left

    def fn(arg):
        return arg

    assert Lazy.of(3).to_either() == Right(3)
    assert Lazy.of(fn).to_either(3) == Right(3)
    assert Lazy.of(fn).to_either(Left(3)) == Left(3)


# Generated at 2022-06-24 00:15:42.369585
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Either

    example_fn = lambda x: x * 2
    example_value = 2

    assert Lazy(example_fn).to_either(example_value).is_right()



# Generated at 2022-06-24 00:15:50.024284
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def sum(a, b):
        return a + b

    def sum_with_exception(a, b):
        raise ValueError('Very bad exception should be catched by Try!')

    def valid_case(_):
        return 'yes'

    def invalid_case(_):
        return Validation.failure(['Something is wrong!'])

    def sum_with_side_effect(a, b):
        print('Sum of {} + {} = {}'.format(a, b, sum(a, b)))
        return a + b

    lazy = Lazy(sum_with_side_effect)

# Generated at 2022-06-24 00:16:00.813133
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x * 2).get() == 2
    assert Lazy.of(1).map(lambda x: x * 2).map(lambda x: x * 4).get() == 8
    assert Lazy.of([1, 2, 3]).map(len).get() == 3
    assert Lazy.of([1, 2, 3]).map(lambda x: x[1]).get() == 2

    assert Lazy(lambda x: 2 * x).map(lambda x: x + 5).get(7) == 19
    assert Lazy(lambda x: 2 * x).map(lambda x: x - 5).map(lambda x: x * 4).get(3) == 4

# Generated at 2022-06-24 00:16:02.397485
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2



# Generated at 2022-06-24 00:16:07.152643
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    """
    Test for method to_box of class Lazy
    """
    from pymonet.box import Box

    test_to_box = Lazy(lambda val: val).to_box(1)
    assert isinstance(test_to_box, Box)
    assert test_to_box.get() == 1


# Generated at 2022-06-24 00:16:14.062844
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # type: ignore
    """
    Test for method __eq__ checking if instances of Lazy are equal when they are evaluated,
    both have the same value and constructor functions.
    Test for method __eq__ checking if instances of Lazy are equal when they are not evaluated and
    both have the same constructor functions.
    """

    fn = lambda *args: 5  # type: ignore
    assert Lazy(fn) == Lazy(fn)
    fn1 = lambda *args: 2  # type: ignore
    assert Lazy(fn1) == Lazy(fn1)

    lazy1 = Lazy(lambda *args: 2)  # type: ignore
    lazy1.get()
    lazy2 = Lazy(lambda *args: 2)  # type: ignore
    lazy2.get()
    assert lazy1 == lazy2


# Unit tests for methods

# Generated at 2022-06-24 00:16:23.106012
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    test Lazy constructor.
    """

    # Function to call in Lazy later
    def get_number():
        """
        :returns: 5
        :rtype: int
        """
        return 5

    # Constructor Lazy with function
    lazy_only_function = Lazy(get_number)

    # Constructor Lazy with function and memoize function argument
    lazy_function_with_arg = Lazy(lambda a: a)

    assert lazy_only_function.constructor_fn == lazy_function_with_arg.constructor_fn
    assert not lazy_only_function.is_evaluated
    assert not lazy_function_with_arg.is_evaluated
    assert lazy_only_function.value is None
    assert lazy_function_with_arg.value is None
    assert lazy_only_function

# Generated at 2022-06-24 00:16:27.372670
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_fn(value: int) -> Lazy[int, T]:
        def constructor_fn(*args) -> int:
            return value + 1

        return Lazy(constructor_fn)

    assert Lazy.of(1).bind(test_fn).get() == 2

# Generated at 2022-06-24 00:16:32.791737
# Unit test for constructor of class Lazy
def test_Lazy(): # pragma: no cover
    def dummy_fn(value):
        return value

    lazy = Lazy(dummy_fn)
    assert lazy.constructor_fn == dummy_fn
    dummy_fn_1 = lambda *args: dummy_fn(1)
    lazy_1 = Lazy.of(1)
    assert lazy_1 == Lazy(dummy_fn_1)
    assert lazy_1.map(lambda x: x + 1) == Lazy(lambda *args: 2)
    assert lazy_1.ap(lazy_1) == lazy_1.map(lazy_1.get())

    def dummy_fn_2(value):
        return Lazy.of(value + 1)

    assert lazy_1.bind(dummy_fn_2) == Lazy(lambda *args: 2)
    assert lazy_

# Generated at 2022-06-24 00:16:35.416467
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2
    assert Lazy(lambda: 1).map(Box.of).get().value == 1


# Generated at 2022-06-24 00:16:37.447838
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda: 1).to_box() == Box(1)

# Generated at 2022-06-24 00:16:40.048248
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(3).to_either() == Right(3)

# Generated at 2022-06-24 00:16:46.307814
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def _eq(fn_1, fn_2):
        return Lazy(fn_1) == Lazy(fn_2)
    assert _eq(lambda: None, lambda: None)
    assert not _eq(lambda: None, lambda: 1)
    assert Lazy(lambda x: x).map(lambda x: x + 1) == Lazy(lambda x: x).map(lambda x: x + 1)



# Generated at 2022-06-24 00:16:54.709237
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.either import Right

    lazy = Lazy(lambda x: x)

    assert lazy.get(1) == 1
    assert lazy.get('a') == 'a'
    assert lazy.get([]) == []
    assert lazy.get(Right(1)) == Right(1)
    assert lazy.get(None) == None
    assert lazy.get(True) == True
    assert lazy.get(False) == False


# Generated at 2022-06-24 00:16:58.331958
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def plus(a, b):
        return a + b

    lazy_value = Lazy.of(2).map(plus)
    assert Validation.success(4) == lazy_value.to_validation(2)

