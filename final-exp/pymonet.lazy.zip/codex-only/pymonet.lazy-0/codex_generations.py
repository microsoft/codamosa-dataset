

# Generated at 2022-06-24 00:06:54.816888
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    import pytest

    assert Lazy.of(5).to_maybe() == Maybe.just(5)

    try:
        Lazy.of(0).bind(lambda value: Try(value / 0)).to_maybe()
        pytest.fail('ZeroDivisionError was not raise')
    except ZeroDivisionError:
        pass

    assert Lazy.of(0).bind(lambda value: Try(value / 0)).to_maybe(None) == Maybe.just(None)

# Generated at 2022-06-24 00:07:01.707243
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    """
    >>> Lazy(lambda x: x + 2).get(1)
    3
    >>> Lazy(lambda x: x + 2).map(lambda x: x * 3).get(1)
    9
    >>> Lazy(lambda x: x + 2).bind(lambda x: Lazy(lambda: x * 3)).get(1)
    9
    """
    pass



# Generated at 2022-06-24 00:07:09.721073
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def return_lazy(x):
        return Lazy.of(x)

    assert str(Lazy.of(1)) == "Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x7fb0e41f5f28>, value=None, is_evaluated=False]"
    assert str(Lazy.of(1).bind(return_lazy)) == "Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x7fb0e4200598>, value=None, is_evaluated=False]"
    assert Lazy.of(1).bind(return_lazy).get() == 1
    assert Lazy.of(1).bind(return_lazy).bind(return_lazy).get() == 1

# Generated at 2022-06-24 00:07:13.697529
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def square(a):
        return a ** 2

    assert str(Lazy(square)) == 'Lazy[fn=<function square at {}>, value=None, is_evaluated=False]'.format(hex(id(square)))

# Unit tests for method __eq__ of class Lazy

# Generated at 2022-06-24 00:07:17.424814
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7fe071b4d2f0>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:07:22.020756
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Lazy(lambda x: x + 5).to_try(3) == Try.of(lambda x: x + 5, 3)
    assert Lazy(lambda x: x / 0).to_try(3) == Try.failure('division by zero')

# Generated at 2022-06-24 00:07:25.506525
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    lazy_maybe = Lazy.of(1).to_maybe()

    assert Lazy.of(lambda x : x + 1).ap(lazy_maybe) == Maybe.just(2)



# Generated at 2022-06-24 00:07:27.291308
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x).ap(Lazy.of(10)) == Lazy.of(10)

# Generated at 2022-06-24 00:07:35.965993
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(3).to_box() == Lazy.of(3).to_box().to_box().to_box().to_box()
    assert Lazy.of(3).to_box() == Lazy.of(3).to_box().to_box().to_box().to_box().get()
    assert Lazy.of(3).to_box().to_box().to_box().to_box().to_box().to_box().to_box().to_box() == Box(Box(Box(Box(Box(3)))))


# Generated at 2022-06-24 00:07:39.591929
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    assert Lazy(lambda x: x + 1).map(Box.of).get(3) == Box.of(4)
    assert Lazy(lambda x: x * 100).map(lambda x: x / 2).get(10) == 500

# Generated at 2022-06-24 00:07:44.361882
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def test_fn(x, y):
        return x+y
    test_lazy = Lazy(test_fn)
    assert str(test_lazy) == 'Lazy[fn=<function test_fn at {}>, value=None, is_evaluated=False]'.format(hex(id(test_fn)))  # pragma: no cover


# Generated at 2022-06-24 00:07:46.781142
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(*args):
        return args[0] + 1

    lazy = Lazy(fn)

    assert 1 == lazy.get(0)



# Generated at 2022-06-24 00:07:50.328072
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda x: x).to_box(None) == Box(None)


# Generated at 2022-06-24 00:07:53.530076
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def create_lazy(): return Maybe.just(10)

    lazy = Lazy(create_lazy)

    assert lazy.to_maybe() == Maybe.just(10)



# Generated at 2022-06-24 00:07:55.674954
# Unit test for method get of class Lazy
def test_Lazy_get():
    def func():
        return 'result'

    lazy = Lazy(func)

    assert lazy.get() == 'result'



# Generated at 2022-06-24 00:08:02.020887
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert Lazy(lambda: 3).__str__() == 'Lazy[fn=<function <lambda> at 0x7fd306c0b840>, value=None, is_evaluated=False]'
    assert Lazy(lambda: 3).map(lambda x: x * 2).__str__() == 'Lazy[fn=<function <lambda> at 0x7fd306c0b488>, value=None, is_evaluated=False]'
    assert Lazy(lambda: 3).ap(Lazy(lambda x: x * 2)).__str__() == 'Lazy[fn=<function <lambda> at 0x7fd306c0b378>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:08:05.169160
# Unit test for constructor of class Lazy
def test_Lazy():
    def fn(value):
        return value

    lazy = Lazy(fn)

    assert lazy.constructor_fn == fn
    assert lazy.is_evaluated == False
    assert lazy.value is None

# Generated at 2022-06-24 00:08:10.121020
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 2) != Lazy(lambda: 1)

    def test_function(x, y):
        return x + y

    assert Lazy(test_function) == Lazy(test_function)
    assert Lazy(test_function) != Lazy(lambda: 1)



# Generated at 2022-06-24 00:08:13.709789
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    lazy = Lazy.of(10)
    either = lazy.to_either()
    assert isinstance(either, Either)
    assert either == Either.right(10)



# Generated at 2022-06-24 00:08:18.660806
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Lazy.of(0) == Lazy.of(0)
    assert Lazy.of(0) != Lazy.of(Maybe.just(0))
    assert Lazy.of(Maybe.nothing) != Lazy.of(Maybe.just(0))



# Generated at 2022-06-24 00:08:24.033435
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    >>> from pymonet.lazy import Lazy
    >>> def div(x):
    ...     return x / 0
    >>> Lazy(div).to_try(10).fold(error=lambda x: 'Error', success=lambda x: x).value
    'Error'
    >>> Lazy(div).to_try(0).fold(error=lambda x: 'Error', success=lambda x: x).value
    0
    """
    pass

# Generated at 2022-06-24 00:08:26.195097
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of('a').map(lambda v: v + 'b') == \
           Lazy(lambda *args: 'ab')



# Generated at 2022-06-24 00:08:28.979625
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def testing_function(x):
        return x * x

    test_object = Lazy(testing_function)
    test_result = test_object.to_try(2)

    assert test_result == Try.of(testing_function, 2)

# Generated at 2022-06-24 00:08:31.720653
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def transform_to_int(value) -> Box[int]:
        return Box(int(value))

    assert Lazy.of("2").bind(transform_to_int) == Lazy(lambda *args: 2)

# Generated at 2022-06-24 00:08:34.485652
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert (Lazy(lambda: True) == Lazy(lambda: True))
    assert (Lazy(lambda: 'foo') != Lazy(lambda: 'bar'))



# Generated at 2022-06-24 00:08:35.623442
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(1) == Lazy(lambda _: 1)



# Generated at 2022-06-24 00:08:46.846664
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy(lambda: 2).get() == 2
    assert Lazy(lambda x: x**2).map(lambda x: x * 2).get(4) == 32
    assert Lazy(lambda x: x**x).ap(Lazy(lambda x: x + 1)).get(2) == 16
    assert Lazy(lambda x: x**x).bind(lambda x: Lazy(lambda: x * 2)).get(2) == 64

    assert Lazy(lambda x: x**x).to_box(2) == Lazy(lambda x: x**x).to_either(2)
    assert Lazy(lambda x: x**x).to_maybe(2) == Maybe.just(Lazy(lambda x: x**x).get(2))

# Generated at 2022-06-24 00:08:49.859788
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    def some_func(value):
        return value

    assert Lazy(some_func).to_box('test') == Box('test')


# Generated at 2022-06-24 00:08:52.296657
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(10).get() == 10
    assert Lazy.of(10).map(lambda x: x * 2).get() == 20

# Generated at 2022-06-24 00:08:57.634048
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy = Lazy(lambda x: x * 2).map(lambda x: x ** 2)

    assert lazy.get(10) == 400
    assert lazy.get(50) == 2500
    assert lazy.get(100) == 10000
    assert lazy.get(500) == 250000


# Generated at 2022-06-24 00:09:01.893366
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy(lambda x: 1).to_maybe(1) == Lazy(lambda x: 1).to_maybe(2)



# Generated at 2022-06-24 00:09:05.697180
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    def add_one(x):
        return x + 1

    add_one_lazy = Lazy(add_one)
    assert add_one_lazy.ap(Box(4)) == Lazy.of(5)


# Generated at 2022-06-24 00:09:07.042194
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.either import Right

    assert Lazy.of(Right(1)).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:09:17.414124
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # pylint:disable=unused-variable, expression-not-assigned, unused-argument

    def get_my_name(name: str) -> 'Lazy[str, str]':
        return Lazy.of(name)

    def get_my_age(age: int) -> 'Lazy[int, int]':
        return Lazy.of(age)

    def get_my_phone(phone: str) -> 'Lazy[str, str]':
        return Lazy.of(phone)

    def get_my_first_name_and_age(full_name: str) -> 'Lazy[str, str]':
        first_name, _ = full_name.split()
        age = get_my_name(full_name).bind(get_my_age).get()


# Generated at 2022-06-24 00:09:24.150009
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 1).to_either() == Right(1)
    assert Lazy(lambda: Maybe.just(1)).to_either() == Right(Maybe.just(1))
    assert Lazy(lambda: Maybe.nothing()).to_either() == Right(Maybe.nothing())
    assert Lazy(lambda x: x, 1).to_either() == Right(1)

# Generated at 2022-06-24 00:09:32.364061
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    """
    Unit test for method _to_try of class Lazy
    """
    from pymonet.monad_try import Success, Failure

    def add(x: int, y: int) -> int:
        return x + y

    def multiply(x: int, y: int) -> int:
        return x * y

    def divide_by_zero(x: int, y: int) -> int:
        x, y = 1, 0
        return x / y

    assert Lazy(add).to_try(1, 2) == Success(3)
    assert Lazy(multiply).to_try(4, 2) == Success(8)
    assert Lazy(divide_by_zero).to_try(4, 2) == Failure(ZeroDivisionError('division by zero'))

# Generated at 2022-06-24 00:09:40.586801
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left
    from pymonet.core import MonadError
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    def fail(x: object) -> U:
        raise ValueError('Failed')

    assert Lazy(lambda x: x).to_either(1) == Right(1)
    assert Lazy(lambda x: x + 1).to_either(1) == Right(2)
    assert Lazy(fail).to_either(1) == Right(1)
    assert Lazy(lambda x: x).to_either('') == Right('')
    assert Lazy(lambda x: x).to_either(None) == Right(None)

# Generated at 2022-06-24 00:09:42.408697
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    result = Lazy.of(42).to_box()
    assert result == Box(42)


# Generated at 2022-06-24 00:09:48.395165
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def f(a):
        return a

    lazy = Lazy(f)

    validation = lazy.to_validation(1)
    assert(validation == Validation.success(1))


# Generated at 2022-06-24 00:09:58.300757
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.functors import compose

    value = 'value'
    triple_function = compose(lambda x: x * 3)
    triple_function_curry = lambda x: triple_function(x)
    double_function = compose(lambda x: x * 2)

    # create new Lazy with function returning value
    lazy = Lazy(lambda *args: value)

    # noinspection PyTypeChecker
    assert lazy == Lazy(lambda *args: value)
    assert 'fn={}, value={}, is_evaluated={}'.format(lazy.constructor_fn, lazy.value, lazy.is_evaluated) == str(lazy)

    # call function and check result
    assert value == lazy.get()

    # create new Lazy with mapped function

# Generated at 2022-06-24 00:10:06.301204
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Tests for method to_try of class Lazy
    """
    from pymonet.monad_try import Success, Failure
    from pymonet.either import Right, Left

    def throw_1():
        raise ValueError("1")

    def throw_2(value):
        raise ValueError("2")

    def throw_3(name):
        raise NameError(name)

    def throw_4(value):
        raise IndexError("4")

    assert Lazy(lambda: 1).to_try() == Success(1)
    assert Lazy(lambda: throw_1()).to_try() == Failure(ValueError("1"))
    assert Lazy(lambda: throw_2(1)).to_try() == Failure(ValueError("2"))

# Generated at 2022-06-24 00:10:08.160800
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda arg: arg).get(10) == 10



# Generated at 2022-06-24 00:10:11.924151
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: '{}'.format(x)).get() == '1'



# Generated at 2022-06-24 00:10:19.346364
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def f(a):
        return a * 2

    def g(a):
        return a + 2

    def h(a):
        return a + 4

    def i(a):
        return a + 6

    fn = Lazy(f).map(g).map(h)

    assert fn.to_box(100) == Box(110)
    assert fn.to_box(200).map(i) == Box(216)

    fn2 = Lazy(f)
    assert fn2.to_box(100).map(g) == Box(204)



# Generated at 2022-06-24 00:10:21.949692
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x + 1)) == 'Lazy[fn=<function <lambda> at 0x10a5d5b70>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:10:27.897390
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    TestCase = namedtuple('TestCase', 'value result')
    test_cases = [
        TestCase(
            value=Lazy(lambda x: x),
            result='Lazy[fn=<function Lazy.<lambda> at 0x7f73c01aa950>, value=None, is_evaluated=False]'
        )
    ]

    for test_case in test_cases:
        assert str(test_case.value) == test_case.result


# Generated at 2022-06-24 00:10:34.789037
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def value_fn(*args):
        return args[0]

    lazy = Lazy(value_fn)
    maybe = lazy.to_maybe(1)
    assert isinstance(maybe, Maybe)
    assert maybe.is_just
    assert maybe.get_or_else(0) == 1

    lazy = Lazy(value_fn)
    maybe = lazy.to_maybe(Box(1))
    assert maybe.is_just
    assert maybe.get_or_else(0) == 1

    maybe = Lazy.of(1).to_maybe()
    assert maybe.is_just
    assert maybe.get_or_else(0) == 1

    maybe = Lazy.of(Box(1)).to_maybe()

# Generated at 2022-06-24 00:10:39.517935
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert (
        Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 11)
        == Lazy.of(1).map(lambda x: x * x).map(lambda x: x + 1)
    )
    assert (
        Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 11)
        == Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 11)
    )
    assert (
        Lazy.of(1).ap(Lazy.of(lambda x: x + 1)).map(lambda x: x * 11)
        == Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 11)
    )

# Generated at 2022-06-24 00:10:45.406270
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    @Lazy.of
    def _lazy_one():
        return 1

    assert _lazy_one == Lazy(lambda: 1)
    assert _lazy_one.get() == 1

# Generated at 2022-06-24 00:10:47.593098
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def foo_func():
        return 1

    assert Lazy(foo_func) == Lazy(foo_func)
    assert Lazy(foo_func) != Lazy(foo_func).map(lambda x: x + 1)


# Generated at 2022-06-24 00:10:53.558042
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda x: x).to_box('xyz') == Lazy(lambda x: x).to_box(123) == Box('xyz')
    assert Lazy(lambda: 10).to_box() == Box(10)



# Generated at 2022-06-24 00:11:04.806971
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    @behave.given("Lazy with value A and B")
    def step_impl1(context):
        context.lazy_a = Lazy(lambda: 'A')
        context.lazy_b = Lazy(lambda: 'B')

    @behave.when("lazy A equals lazy B")
    def step_impl(context):
        context.result = context.lazy_a.__eq__(context.lazy_b)

    @behave.then("lazy A and B are equals")
    def step_impl(context):
        assert context.result

    @behave.given("Lazy with value A")
    def step_impl1(context):
        context.lazy_a = Lazy(lambda: 'A')


# Generated at 2022-06-24 00:11:15.915417
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn_a():
        return 1

    def fn_b():
        return 2

    lazy_monad = Lazy(fn_a)
    box_monad = Box(fn_a)
    maybe_monad = Maybe.just(fn_a)
    try_monad = Try.of(fn_a)
    validation_monad = Validation.success(fn_a)

    assert lazy_monad == lazy_monad
    assert lazy_monad != box_monad
    assert lazy_monad != maybe_monad
    assert lazy_monad != try_monad
    assert lazy_monad != validation_monad

# Generated at 2022-06-24 00:11:19.955312
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)


# Generated at 2022-06-24 00:11:25.077357
# Unit test for method get of class Lazy
def test_Lazy_get():
    # GIVEN
    not_evaluated_lazy = Lazy.of(1)
    evaluated_lazy = Lazy.of(1).get()

    # THEN
    assert not_evaluated_lazy.is_evaluated is False
    assert evaluated_lazy.is_evaluated is True
    assert evaluated_lazy.get() == 1
    assert evaluated_lazy.value == 1


# Generated at 2022-06-24 00:11:27.485410
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda a: "a")) == "Lazy[fn=<function test_Lazy___str__.<lambda> at 0x7f7a8d6abf28>, value=None, is_evaluated=False]"


# Generated at 2022-06-24 00:11:34.772498
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def sum_slow(arg1, arg2):
        time.sleep(0.5)
        return arg1 + arg2

    lazy_sum = Lazy(sum_slow)
    assert isinstance(lazy_sum.to_box(1, 2), Box)
    assert lazy_sum.to_box(1, 2) == Box(3)
    # Check memoized value
    assert lazy_sum.to_box(1, 2) == Box(3)



# Generated at 2022-06-24 00:11:46.024221
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def add_3(x: int) -> int:
        return x + 3

    def add_5(x: int) -> int:
        return x + 5

    lazy_add_3 = Lazy.of(add_3)

    assert lazy_add_3.is_evaluated is False
    assert lazy_add_3.value is None
    assert lazy_add_3.get() == add_3
    assert lazy_add_3.is_evaluated is True

    lazy_add_3_and_add_5 = lazy_add_3.map(add_5)

    assert lazy_add_3_and_add_5.is_evaluated is False
    assert lazy_add_3_and_add_5.value is None
    assert lazy_add_3_and_add_5

# Generated at 2022-06-24 00:11:51.638044
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    # Arrange
    def some_func():
        return 'some_value'

    def some_other_func():
        raise ValueError

    lazy = Lazy(some_func)

    # Act
    lazy_value = lazy.get()

    # Assert
    assert 'some_value' == lazy_value



# Generated at 2022-06-24 00:11:55.486896
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)

# Generated at 2022-06-24 00:11:57.355187
# Unit test for method get of class Lazy
def test_Lazy_get():
    def function_one(*args):
        return 1

    lazy_one = Lazy(function_one)
    assert lazy_one.get() == 1

# Generated at 2022-06-24 00:11:59.586822
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_instance = Lazy.of(10).map(lambda x: x * 2)
    assert lazy_instance == Lazy.of(20)



# Generated at 2022-06-24 00:12:02.400274
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet import Lazy
    from pymonet.maybe import Maybe

    assert Lazy(lambda: None).to_maybe() == Maybe.nothing()
    assert Lazy(lambda: 1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:12:05.068867
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy_instance = Lazy(lambda x: x + 1).bind(lambda x: Lazy(lambda y: x + y))
    assert lazy_instance(1)(2) == 4


# Generated at 2022-06-24 00:12:17.686930
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right

    def positive(x: int) -> str:
        return 'Positive number: {}'.format(x)

    def negative(x: int) -> str:
        return 'Negative number: {}'.format(x)

    assert Lazy(lambda x: x).bind(lambda x: Lazy.of(positive(x)) if x > 0 else Lazy.of(negative(x))).to_either(0) == Right('Positive number: 0')
    assert Lazy(lambda x: x).bind(lambda x: Lazy.of(positive(x)) if x > 0 else Lazy.of(negative(x))).to_either(-1) == Right('Negative number: -1')

# Generated at 2022-06-24 00:12:23.001478
# Unit test for method get of class Lazy
def test_Lazy_get():
    '''
    Lazy.get method should return value passed to class constructor
    '''
    def add_one(x: int) -> int:
        return x + 1

    assert Lazy(add_one).get(3) == add_one(3)


# Generated at 2022-06-24 00:12:32.081842
# Unit test for constructor of class Lazy
def test_Lazy():
    # pylint: disable=too-many-locals
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def generator_fn() -> int:
        return 10

    generator = Lazy(generator_fn)
    generator.get()
    generator.get()

    lazy_box = generator.to_box()
    assert type(lazy_box) == Box
    assert lazy_box.unbox() == generator_fn()

    lazy_try = generator.to_try()
    assert type(lazy_try) == Try
    assert lazy_try.get() == generator_fn()

    lazy_either = generator.to_either()
    assert type(lazy_either) == Either


# Generated at 2022-06-24 00:12:38.140265
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    value = Lazy.of(1).to_box()
    assert isinstance(value, Box)
    assert value == Box(1)
    value = Lazy(lambda: 1).to_box()
    assert isinstance(value, Box)
    assert value == Box(1)
    value = Lazy(lambda x: x + 3, 4).to_box()
    assert isinstance(value, Box)
    assert value == Box(7)


# Generated at 2022-06-24 00:12:47.591449
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def add(a, b):
        return a + b

    lazy = Lazy(lambda: add(1, 2))

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)

    assert Lazy(lambda: add(1, 2)) == Lazy(lambda: add(1, 2))
    assert Lazy(lambda: add(1, 2)) != Lazy(lambda: add(2, 1))
    assert Lazy(lambda: add(1, 2)) != Lazy(lambda: None)

    assert lazy.map(lambda x: x * 3).get() == (1 + 2) * 3
    assert lazy.map(lambda x: Lazy(lambda: x * 3)).get() == (1 + 2) * 3

# Generated at 2022-06-24 00:12:59.666014
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    # given
    test_val_int = 2
    test_val_float = 2.0
    test_val_str = '2'
    test_val_list = [2]

    test_lazy = Lazy(lambda *args: test_val_int)

    # when
    test_result_int = test_lazy.to_box()
    test_result_float = Lazy(lambda *args: test_val_float).to_box()
    test_result_str = Lazy(lambda *args: test_val_str).to_box()
    test_result_list = Lazy(lambda *args: test_val_list).to_box()

    # then
    assert test_result_int.get() == test_val_int
    assert test_result_float.get

# Generated at 2022-06-24 00:13:11.845483
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    def div(x, y):
        if y == 0:
            return None
        return x / y

    def test_fn():
        return 1 / 0

    def test_fn_1():
        return 1

    assert Maybe.none().to_lazy().to_maybe() == Maybe.none()
    assert Maybe.just(21).to_lazy().to_maybe() == Maybe.just(21)
    assert Maybe.just(21).to_lazy().map(lambda x: x/2).to_maybe() == Maybe.just(10.5)
    assert Maybe.just(21).to_lazy().bind(lambda x: Maybe.just(x/2)).to_maybe() == Maybe.just(10.5)

# Generated at 2022-06-24 00:13:16.110558
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Lazy.of(Box.unit(1)).to_maybe() == Maybe.just(Box.unit(1))

# Generated at 2022-06-24 00:13:21.043750
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    def fn(x):
        return x + 1

    def func(x):
        return fn(x)

    lazy_result = Lazy.of(fn).ap(Lazy(func))
    assert lazy_result.get(1) == 3



# Generated at 2022-06-24 00:13:22.574796
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    print(Lazy.of('value').to_box())

# Generated at 2022-06-24 00:13:28.443158
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of('1').map(lambda x: int(x)).__eq__(Lazy.of(1)) is True
    assert Lazy.of('1').map(lambda x: int(x)).__eq__(Lazy.of('1').map(lambda x: int(x))) is True
    assert Lazy.of('1').map(lambda x: int(x)).__eq__(Lazy(lambda x: int(x))) is False



# Generated at 2022-06-24 00:13:35.990214
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.maybe import Maybe

    lazy_int = Lazy.of(5)
    lazy_Maybe_int = Lazy.of(Maybe.just(5))
    lazy_lazy_Maybe_int = Lazy.of(lazy_Maybe_int)

    assert lazy_int.get() == 5
    assert lazy_Maybe_int.get() == Maybe.just(5)
    assert lazy_lazy_Maybe_int.get() == lazy_Maybe_int



# Generated at 2022-06-24 00:13:36.895151
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.monad_list import Mona

# Generated at 2022-06-24 00:13:41.729689
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    def return_lazy_value():
        return 'lazy value'

    lazy_value = Lazy(return_lazy_value)
    assert lazy_value.to_validation() == Validation.success(lazy_value.get())

# Generated at 2022-06-24 00:13:47.528760
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def caller():
        return 1/0

    lazy = Lazy.of(1/0)
    assert isinstance(lazy.to_try().get_exception(), ZeroDivisionError)

    lazy = Lazy(caller)
    assert isinstance(lazy.to_try().get_exception(), ZeroDivisionError)



# Generated at 2022-06-24 00:13:53.925070
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.monad_try import Try

    def fn(x: int) -> Try[int]:
        return Try.of(lambda: x + 1)

    lazy = Lazy(fn)

    assert lazy.get(1).get() == 2
    assert lazy.get(2).get() == 3

    # assert Lazy(lambda: x + 1).get(1) == Lazy(lambda: x + 1).get(1)
    # assert x == 1  # test that lazy is lazy


# Generated at 2022-06-24 00:13:59.413327
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.list import List

    assert Lazy.of(5).bind(lambda v: Lazy.of(v * 2)).get() == 10
    assert Lazy.of(5).bind(lambda v: Lazy.of(v * 2)).bind(lambda v: Lazy.of(v * 2)).get() == 20
    assert Lazy.of(5).bind(lambda v: Lazy.of(Box(v * 2))).bind(lambda v: Lazy.of(List(v, v))).get().get(1).get() == 20


# Generated at 2022-06-24 00:14:04.514335
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).get() == 4
    assert Lazy.of([1, 2, 3]).map(lambda x: [x]).get() == [[1, 2, 3]]


# Generated at 2022-06-24 00:14:07.905943
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f1(i):
        return Lazy(lambda: i+1)

    f = Lazy(lambda: 10).bind(f1).bind(f1)
    result = f.get()
    assert result == 12

# Generated at 2022-06-24 00:14:11.161214
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x + 1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 2)).get(100) == 103

# Generated at 2022-06-24 00:14:18.325925
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def succ(value):
        return Lazy(lambda *args: value)

    def fail():
        raise Exception('Lazy failed')

    assert Try.of(lambda *args: succ).unwrap_or_else(fail) == succ(1)
    assert Try.of(lambda *args: fail).unwrap_or_else(fail).equals(Try.failure(Exception('Lazy failed')))



# Generated at 2022-06-24 00:14:22.185525
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    def function_to_call():
        raise Exception('Exception in function_to_call')

    lazy = Lazy(function_to_call)
    assert lazy.to_try() == Try.failure(Exception('Exception in function_to_call'))

# Generated at 2022-06-24 00:14:26.891038
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # given
    f = lambda x: x + 1

    # when
    lazy = Lazy(f)
    lazy2 = Lazy(f)

    # then
    assert lazy == lazy
    assert lazy == lazy2
    assert lazy != Lazy(lambda x: x)


# Generated at 2022-06-24 00:14:30.604029
# Unit test for method to_try of class Lazy
def test_Lazy_to_try(): # pragma: no cover
    def function(value):
        return int(value)

    lazy = Lazy.of(function)

    assert lazy.to_try('2') == Try(function, '2')
    assert lazy.to_try('a') == Try(function, 'a')

# Generated at 2022-06-24 00:14:38.413706
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """Unit test for method ap of class Lazy"""

    # TEST_CONSTRUCTOR_FN_STRING_CONCAT
    def test_constructor_fn_string_concat():
        return 'test'

    # TEST_CONSTRUCTOR_FN_NUMBER_ADDITION
    def test_constructor_fn_number_addition(number):
        return number + 1

    # TEST_CONSTRUCTOR_FN_LIST_CONCAT
    def test_constructor_fn_list_concat(list_one, list_two):
        return list_one + list_two

    # TEST_CONSTRUCTOR_FN_TUPLE_CONCAT
    def test_constructor_fn_tuple_concat(tuple_one, tuple_two):
        return tuple_one + tuple_two

    # LAZY_STR

# Generated at 2022-06-24 00:14:45.851964
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.maybe import Maybe

    fn = lambda x: x + 1
    lazy = Lazy.of(10).map(fn)
    assert lazy.get() == fn(10)

    lazy = lazy.bind(Maybe.to_lazy)
    assert lazy.get() == (Maybe.just(10).map(fn)).get()

# Generated at 2022-06-24 00:14:48.480905
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_lazy().to_box() == Box(1)



# Generated at 2022-06-24 00:14:52.636697
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def test_function(*args):  # pragma: no cover
        pass

    assert str(Lazy(test_function)) == 'Lazy[fn=<function test_function at 0x7f2abec74d08>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:14:56.624452
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    Lazy(lambda n: n + n).to_try(2) == Try.success(4)
    Lazy(lambda n: 1 / 0).to_try(2) == Try.failure(ZeroDivisionError())


# Generated at 2022-06-24 00:15:06.721398
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from decimal import Decimal
    from pymonet.monad_try import Try

    def fn(value: float) -> Decimal:
        return Decimal(value)

    with_value = Lazy.of(Decimal(5))
    assert with_value.get(1, 2, 3, 4) == Decimal(5)
    assert str(with_value) == 'Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x7f8e10673f28>, value=5, is_evaluated=True]'

    with_function = Lazy(fn)
    assert with_function.get(5) == Decimal(5)
    assert with_function.get(5.0) == Decimal(5)

# Generated at 2022-06-24 00:15:08.325186
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Either.right(1) == Lazy.of(1).to_either()



# Generated at 2022-06-24 00:15:10.881947
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(5).to_box() == Box(5)
    assert Lazy.of(lambda: 5).to_box() == Box(5)
    assert Lazy.of(lambda: lambda: 5).to_box() == Box(5)


# Generated at 2022-06-24 00:15:12.518869
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x: x + 2).ap(Lazy(lambda x: x * 2)) == Lazy(lambda x: (x * 2) + 2)


# Generated at 2022-06-24 00:15:19.083989
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.tools import eq

    l1 = Lazy.of(1)
    l2 = Lazy(lambda: 1)
    l3 = Lazy(lambda: l2.get())

    eq(l1.get(), 1)
    eq(l2.get(), 1)
    eq(l3.get(), 1)



# Generated at 2022-06-24 00:15:21.831969
# Unit test for method map of class Lazy
def test_Lazy_map():
    """Unit test for method map of class Lazy"""
    assert Lazy.of(10).map(lambda x: x + 1) == Lazy.of(11)


# Generated at 2022-06-24 00:15:33.090888
# Unit test for constructor of class Lazy
def test_Lazy():
    def make_lazy(value: int) -> Lazy:
        return Lazy(lambda x: 2 * value)
    assert Lazy(lambda x: 2 * x).get(10) == 20
    assert Lazy(lambda x: 2 * x).to_box(10) == Box(20)
    assert Lazy(lambda x: 2 * x).to_either(10) == Right(20)
    assert Lazy(lambda x: 2 * x).to_maybe(10) == Maybe.just(20)
    assert Lazy(lambda x: 2 * x).to_try(10) == Success(20)
    assert Lazy(lambda x: 2 * x).to_validation(10) == Success(20)
    assert make_lazy(10).get() == 20

# Generated at 2022-06-24 00:15:34.364159
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    result = Lazy.of(2).bind(lambda x: Lazy.of(x * 2)).get()
    assert result == 4



# Generated at 2022-06-24 00:15:42.361461
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    # Given
    value = 1
    lazy = Lazy.of(value)
    func = lambda x: x + 1

    # When
    maybe = lazy.to_maybe()

    # Then
    assert isinstance(maybe, Maybe)
    assert maybe.is_just()
    assert maybe.get() == value

    # When
    maybe2 = lazy.map(func).to_maybe()

    # Then
    assert isinstance(maybe2, Maybe)
    assert maybe2.is_just()
    assert maybe2.get() == func(value)



# Generated at 2022-06-24 00:15:50.023854
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a):
        return a + 1

    assert Lazy.of(10).ap(Lazy.of(add)) == Lazy(lambda: 11)

    def add2(a, b):
        return a + b

    assert Lazy.of(add2).ap(Lazy.of(10)).ap(Lazy.of(1)) == Lazy(lambda: 11)

    assert Lazy.of(add2).ap(Lazy.of(10)).ap(Lazy.of(Lazy.of(1))) == Lazy(lambda: 11)

    assert Lazy.of(add2).ap(Lazy.of(Lazy.of(10))).ap(Lazy.of(1)) == Lazy(lambda: 11)


# Generated at 2022-06-24 00:15:55.954108
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    """
    Unit test for method get of class Lazy
    """
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(add_2).get() == 3
    assert Lazy.of(1).map(add_2).map(sub_3).get() == 0

# Generated at 2022-06-24 00:16:02.105137
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    fn_returning_error = lambda: 1 / 0
    fn_returning_1 = lambda: 1

    lazy_error = Lazy.of(fn_returning_error)
    lazy_1 = Lazy.of(fn_returning_1)

    assert isinstance(lazy_error.to_maybe(), Maybe)
    assert isinstance(lazy_1.to_maybe(), Maybe)
    assert lazy_1.to_maybe() == Maybe(1)
    assert lazy_error.to_maybe() == Maybe.empty()



# Generated at 2022-06-24 00:16:08.685485
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    assert Lazy.of(5).to_try() == Lazy.of(5).to_try()
    lazy_of_5 = Lazy.of(5)
    assert lazy_of_5.to_try(1, 2, 3) == Lazy.of(5).to_try(1, 2, 3)

    assert lazy_of_5.to_try(1, 2, 3) != Lazy.of(6).to_try(1, 2, 3)



# Generated at 2022-06-24 00:16:16.820831
# Unit test for method get of class Lazy
def test_Lazy_get():
    class TestClass:
        def __init__(self, value):
            self.value = value

    def fn_mapper(value: TestClass) -> int:
        return value.value

    def fn_constructor(value: int) -> TestClass:
        return TestClass(value)

    assert Lazy(fn_constructor).get(4) == fn_constructor(4)
    assert Lazy(fn_constructor).map(fn_mapper).get(4) == fn_constructor(4).value
    assert Lazy(fn_constructor).bind(lambda x: Lazy(lambda y: TestClass(x.value + y))).get(4) == 8

# Generated at 2022-06-24 00:16:18.532778
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    assert Lazy(lambda: 6).bind(lambda x: Box(x * 7)).get() == 42

# Generated at 2022-06-24 00:16:21.240285
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Should return value for Lazy with already evaluated function.
    """
    value = Lazy(lambda x: x + 1).map(lambda x: x * 3).get(2)
    assert value == 9



# Generated at 2022-06-24 00:16:26.847511
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(10).get() == 10
    assert Lazy.of(10).get(10) == 10
    assert Lazy.of(10).get('a', 'b') == 10
    assert Lazy(_return_10).get() == 10



# Generated at 2022-06-24 00:16:33.737813
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy.of(1)) == "Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x7f2e276b5048>, value=1, is_evaluated=True]"
    assert str(Lazy(lambda _: 1)) == "Lazy[fn=<function <lambda> at 0x7f2e276b1c80>, value=None, is_evaluated=False]"


# Generated at 2022-06-24 00:16:45.162766
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy.of(3).to_validation() == Validation.success(3)
    assert Lazy.of('alakazam').to_validation() == Validation.success('alakazam')
    assert Lazy.of(True).to_validation() == Validation.success(True)
    assert Lazy.of(False).to_validation() == Validation.success(False)
    assert Lazy.of(13).map(lambda x: x+1).to_validation() == Validation.success(14)
    assert Lazy.of(13).bind(lambda x: Lazy.of(x+1)).to_validation() == Validation.success(14)

# Generated at 2022-06-24 00:16:56.380234
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    assert Lazy.of(1).to_try() == Try.of(lambda: 1)
    assert Lazy(lambda x: x + 1).to_try(1) == Try.of(lambda x: x + 1, 1)
    assert Lazy(lambda x: x + 'a').to_try(1) == Try.of(lambda x: x + 'a', 1)
    assert Lazy(lambda x: [x] + 'a').to_try(1) == Try.of(lambda x: [x] + 'a', 1)
    assert Lazy(lambda x: [x] + 'a').to_try(1) == Try.of(lambda x: [x] + 'a', 1)