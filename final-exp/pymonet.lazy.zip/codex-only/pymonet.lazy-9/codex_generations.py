

# Generated at 2022-06-24 00:07:05.175619
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x, y):
        return x + y

    def divide(x, y):
        return x / y

    def divide_safe(x, y):
        try:
            return x / y
        except ZeroDivisionError:
            return 0

    assert Try.of(add, 1, 2) == Lazy(add).to_try(1, 2)
    assert Try.from_error(ZeroDivisionError('division by zero')) == Lazy(lambda: divide(1, 0)).to_try()
    assert Try.of(divide_safe, 1, 2) == Lazy(divide_safe).to_try(1, 2)

# Generated at 2022-06-24 00:07:12.170727
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def foo(*args):
        return args[0] + '!'

    def constructor_fn1(*args):
        return args[0] + '!'

    def constructor_fn2(*args):
        return args[0] + '!!'

    f1 = Lazy(constructor_fn1)
    f2 = Lazy(constructor_fn2)
    f3 = Lazy(foo)

    assert f1 == f1
    assert f1 != f2
    assert f1 != f3



# Generated at 2022-06-24 00:07:22.477427
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def always_true():
        return True

    def always_false():
        return False

    assert Lazy(always_true) == Lazy(always_true)
    assert Lazy(always_false) == Lazy(always_false)

    assert Lazy(always_true).get() is True
    assert Lazy(always_false).get() is False

    assert Lazy(always_true) != Lazy(always_false)
    assert Lazy(always_true) != Lazy(always_false).get()
    assert Lazy(always_true).get() != Lazy(always_false).get()
    assert Lazy(always_true) != Lazy(always_false).get()
    assert Lazy(always_true).get() != Lazy(always_false)
    assert Lazy(always_true).get() != L

# Generated at 2022-06-24 00:07:29.775854
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    Unit test for constructor of class Lazy
    """
    assert Lazy.of(5).get() == 5
    assert Lazy.of(5).to_box().get() == 5
    assert Lazy.of(5).to_either().get_or_else(lambda: 10) == 5
    assert Lazy.of(5).to_maybe().get_or_else(lambda: 10) == 5
    assert Lazy.of(5).to_try().get_or_else(lambda: 10) == 5
    assert Lazy.of(5).to_validation().get_or_else(lambda: 10) == 5



# Generated at 2022-06-24 00:07:33.137438
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(m: int, n: int) -> int:
        return m + n

    assert Lazy(lambda: add(1, 1)).get() == 2

    def divide(m: int, n: int) -> float:
        return m / n

    assert Lazy(lambda: divide(1, 1)).get() == 1.0



# Generated at 2022-06-24 00:07:37.011957
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    # GIVEN
    lazy_fn = lambda arg: arg

    # WHEN
    lazy = Lazy(lazy_fn)

    # THEN
    assert lazy.to_maybe('test').get_or_else('') == 'test'



# Generated at 2022-06-24 00:07:43.589522
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def plus(a, b):
        return a + b

    double = Lazy(lambda a: a * 2)
    double_plus = Lazy(plus)
    double_plus_3 = Lazy(lambda a: plus(a, 3))
    assert double.ap(double_plus).get(2) == 6
    assert double.ap(double_plus_3).get(2) == 8



# Generated at 2022-06-24 00:07:44.994456
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x) == Lazy(lambda x: x)



# Generated at 2022-06-24 00:07:50.709202
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 42).get() == 42
    assert Lazy(lambda: 43).map(lambda a: a + 1).get() == 44
    assert Lazy(lambda: 44).map(lambda a: a + 1).get() == 45

    assert Lazy(lambda: 42).bind(lambda a: Lazy(lambda: a + 1)).get() == 43
    assert Lazy(lambda: 43).map(lambda a: a + 1).get() == 44
    assert Lazy(lambda: 44).map(lambda a: a + 1).get() == 45

# Generated at 2022-06-24 00:07:53.223977
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Maybe.of(1) == Lazy.of(1).to_maybe()


# Generated at 2022-06-24 00:07:55.368503
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(5).to_either() == Right(5)



# Generated at 2022-06-24 00:08:01.801054
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    # Given
    def thow_error_fn(_):
        raise ValueError('Error')

    def correct_fn(_):
        return 'OK'

    lazy_with_error = Lazy(thow_error_fn)
    lazy_correct = Lazy(correct_fn)

    # When
    result_with_error = lazy_with_error.to_try()
    result_correct = lazy_correct.to_try()

    # Then
    assert isinstance(result_with_error, Try)
    assert isinstance(result_correct, Try)
    assert isinstance(result_with_error.get_cause(), ValueError)
    assert result_correct._value == 'OK'


# Generated at 2022-06-24 00:08:04.277903
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    assert Validation.success(True) == Lazy(lambda *args: True).to_validation()

# Generated at 2022-06-24 00:08:12.106106
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def func(x):
        return x

    def func2(x):
        return x

    assert Lazy.of(1) == Lazy.of(1)
    assert not Lazy.of(1) == Lazy.of(2)
    assert not Lazy.of(1) == 1
    assert not Lazy.of(1) == Lazy(func)
    assert Lazy.of(1) == Lazy.of(1)
    assert not Lazy.of(1) == Lazy.of(2)
    assert Lazy(func) == Lazy(func)
    assert Lazy(func) == Lazy(func)== Lazy(func2)

# Generated at 2022-06-24 00:08:16.358381
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: 'python'
                ).bind(lambda x: Lazy(lambda: ' is awesome')) \
                   .bind(lambda x: Lazy(lambda: ''.join([x, '!']))) == Lazy(lambda: 'python is awesome!')

# Generated at 2022-06-24 00:08:19.344564
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Lazy(lambda: 1).to_either() == Right(1)



# Generated at 2022-06-24 00:08:26.274838
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    # Given
    def mapper(value):
        if value < 3:
            return Maybe.just(Box(value))
        else:
            return Maybe.nothing()

    lazy1 = Lazy(mapper)
    lazy2 = Lazy(lambda *args: 1)
    lazy3 = Lazy(lambda *args: 9)

    # Assert
    assert lazy1.ap(lazy2).get() == Box(1)
    assert lazy1.ap(lazy3).get() == Maybe.nothing()



# Generated at 2022-06-24 00:08:29.727384
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    lazy = Lazy(lambda x: x)
    assert str(lazy) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x10a7f4ea0>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:08:33.139436
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def fn_to_box(*args, **kwargs):
        return 'initial value'

    # When: calling incapsulated function
    result = Lazy(fn_to_box).to_box()

    # Then: result is Box monad with correct value
    expected = 'initial value'
    assert result == expected



# Generated at 2022-06-24 00:08:44.802541
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import _failures

    def to_camel_case(text: str) -> str:
        return text.title().replace('_', '')

    def parse_json(json_text: str) -> Lazy[str, dict]:
        import json

        def parse():
            return json.loads(json_text)
        return Lazy(parse)

    def to_camel_json(json_text: str) -> Lazy[str, dict]:
        return Lazy(parse_json(json_text).get).bind(lambda parsed: Lazy(to_camel_dict(parsed)))


# Generated at 2022-06-24 00:08:46.463673
# Unit test for method get of class Lazy
def test_Lazy_get():
    def construct():
        return 2

    lazy = Lazy(construct)

    assert lazy.get() == 2

# Generated at 2022-06-24 00:08:48.842551
# Unit test for method map of class Lazy
def test_Lazy_map(): # pragma: no cover
    constructor_fn = lambda data: data * 2
    lazy = Lazy.of(1)

    assert lazy.map(constructor_fn).get() == 2



# Generated at 2022-06-24 00:08:52.538005
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def some_function():
        raise Exception('Some Exception')

    lazy = Lazy(some_function)
    lazy_try = lazy.to_try()
    assert lazy_try.is_error() == True



# Generated at 2022-06-24 00:08:57.486063
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.maybe import Maybe

    assert Lazy(lambda a: a).bind(lambda x: Maybe.just(x)).get(2) == 2
    assert Lazy(lambda a: a).bind(lambda x: Maybe.just(x)).get('bla') == 'bla'

# Generated at 2022-06-24 00:09:06.195474
# Unit test for method get of class Lazy
def test_Lazy_get():
    fn = lambda x: x + 2

    assert Lazy(fn).get(2) == fn(2)
    assert Lazy(fn).get(2) == fn(2) # second call should return memoized value
    assert Lazy(fn).bind(lambda x: Lazy.of(x + 2)).get(2) == Lazy(fn).get(2) + 2
    assert Lazy.of(2).get() == 2
    assert Lazy.of(Lazy.of(2)).get().get() == 2
    assert Lazy.of(Lazy.of(Lazy.of(2))).get().get().get() == 2
    assert Lazy.of(Lazy.of(Lazy.of(2))).get().get().get() == 2
    assert Lazy(lambda: 2).get() == 2


#

# Generated at 2022-06-24 00:09:15.117065
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def square(x):
        return x ** 2

    lazy: Lazy = Lazy(lambda: Maybe.just(5))
    assert lazy.get() == Box(5)

    lazy: Lazy = Lazy(lambda: Maybe.empty())
    assert lazy.get() == Box(None)

    lazy: Lazy = Lazy(lambda: Maybe.just(5))
    assert lazy.to_box() == Box(5)

    lazy: Lazy = Lazy(lambda: Maybe.empty())
    assert lazy.to_box() == Box(None)

    lazy: Lazy = Lazy(lambda: Maybe.just(5))
    assert lazy.map(square).get() == Box(25)

    lazy: Lazy

# Generated at 2022-06-24 00:09:21.052457
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    Lazy(lambda x: x).to_either(1)
    Lazy(lambda x: x).to_either(None)
    Lazy(lambda x: 1 / x).to_either(0)
    Lazy(lambda x: 1 / x).to_either(1)


# Generated at 2022-06-24 00:09:24.187950
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert Lazy(lambda x: x + 1).__str__() == "Lazy[fn=<function <lambda> at 0x7f18ccd1a9d8>, value=None, is_evaluated=False]"


# Generated at 2022-06-24 00:09:26.751631
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    lazy = Lazy.of(1)
    assert lazy.to_box() == Box(1)


# Generated at 2022-06-24 00:09:28.742437
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(2).bind(lambda x: Lazy.of(3 + x)) == Lazy.of(5)



# Generated at 2022-06-24 00:09:30.178355
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(2).get() == 2


# Generated at 2022-06-24 00:09:36.908991
# Unit test for constructor of class Lazy
def test_Lazy():
    def add(x, y): return x + y
    lazy_add = Lazy(partial(add, y=10))

    assert str(lazy_add) == 'Lazy[fn=partial(<built-in function add>, y=10), value=None, is_evaluated=False]'
    assert lazy_add.get(5) == 15
    assert str(lazy_add) == 'Lazy[fn=partial(<built-in function add>, y=10), value=15, is_evaluated=True]'
    assert lazy_add.get(5) == 15


# Generated at 2022-06-24 00:09:41.035473
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    import pytest

    def function():
        return "value"

    lazy = Lazy(function)
    assert lazy.__str__() == "Lazy[fn=<function Lazy.test_Lazy___str__.<locals>.function at 0x104f48c80>, value=None, is_evaluated=False]"



# Generated at 2022-06-24 00:09:52.899729
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover 
    def constructor_fn_a():
        return 1

    def constructor_fn_b():
        return 2

    lazy_a = Lazy(constructor_fn_a)
    lazy_a_a = Lazy(constructor_fn_a)
    lazy_b = Lazy(constructor_fn_b)
    lazy_b_a = Lazy(constructor_fn_b)

    assert lazy_a == lazy_a
    assert lazy_b == lazy_b
    assert lazy_a != lazy_b
    assert lazy_b != lazy_a

    assert lazy_a == lazy_a_a
    assert lazy_b == lazy_b_a
    assert lazy_a_a == lazy_a
    assert lazy_b_a == lazy_b

    lazy_a_a.get()

# Generated at 2022-06-24 00:10:03.934735
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def raise_fn(*args, **kwargs):
        raise ValueError("fn")

    laz1 = Lazy(lambda x: x).map(lambda x: x + 1)
    laz2 = Lazy(lambda x: x).map(lambda x: x + 1)

    # Both lazies not evaluated
    assert laz1 == laz2

    # One of lazies evaluated
    laz2.get(1)
    assert laz1 != laz2

    # Both of lazies evaluated
    laz1.get(1)
    assert laz1 == laz2

    # Both of lazies evaluated and evaluated with different values
    laz1.get(2)
    laz2.get(1)
    assert laz1 != laz2

    # Both of lazies evaluated and evaluated with different functions
    laz1 = Lazy(lambda x: x)
    laz2

# Generated at 2022-06-24 00:10:10.464186
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Lazy(lambda value: value + 1).ap(Right(1)) == Right(2)
    assert Lazy(lambda value: value + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Lazy(lambda value: value + 1).ap(Lazy.of(1)) == Lazy(lambda value: value + 2)

# Generated at 2022-06-24 00:10:15.717300
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def constructor_fn(x, y):
        return x + y

    lazy = Lazy(constructor_fn)
    assert str(lazy) == "Lazy[fn=<function Lazy_constructor_fn at 0x{:x}>, value=None, is_evaluated=False]".format(
        id(constructor_fn))


# Generated at 2022-06-24 00:10:23.681957
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    def computation(*args):
        return args[0] * 2

    def maybe_computation(*args):
        return Maybe.of(args[0] * 2)

    def either_computation(*args):
        return Right(args[0] * 2)

    assert Lazy.of(1).ap(Lazy.of(computation)).get() == 2
    assert Lazy.of(1).ap(Lazy.of(maybe_computation)).get() == 2
    assert Lazy.of(1).ap(Lazy.of(either_computation)).get() == 2

# Generated at 2022-06-24 00:10:32.344670
# Unit test for constructor of class Lazy
def test_Lazy():
    from typed_ast import ast3

    assert Lazy(lambda x: x + 10).get(10) == 20
    assert Lazy(lambda x: x + 10).map(lambda x: x * 10).get(10) == 200
    assert Lazy(lambda x: x + 10).map(lambda x: x * 10).get(10) == 200
    assert Lazy(lambda x: x + 10).map(lambda x: x * 10).map(lambda x: x / 10).get(10) == 20
    assert Lazy(lambda x: x + 10).bind(lambda x: Lazy(lambda y: x + y)).get(10) == 20
    assert Lazy(lambda x: x + 10).bind(lambda x: Lazy(lambda y: x + y)).get(10) == 20

# Generated at 2022-06-24 00:10:43.674011
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.functors import Functor
    from pymonet.monad import Monad
    import math

    assert Functor.laws_check(Lazy, lambda x: x * 5, lambda x: math.sqrt(x), x=5)
    assert Monad.laws_check(Lazy, lambda x: x * 5, lambda x: math.sqrt(x), x=5)

    assert Lazy.of(5).get() == 5
    assert Lazy.of("Test").get() == "Test"
    assert Lazy.of(5).map(lambda x: x * 3).get() == 15
    assert Lazy.of("Test").map(lambda x: x + "123").get() == "Test123"

# Generated at 2022-06-24 00:10:47.322884
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert (  # pragma: no cover
        Lazy(lambda: 1).get() == 1
        and Lazy(lambda: [1, 2, 3]).get() == [1, 2, 3]
        and Lazy(lambda: 'a').get() == 'a'
        and Lazy(lambda: 'a').get() == Lazy(lambda: 'a').get()
        and Lazy(lambda: 'a').get() != Lazy(lambda: 'b').get()
    )

# Generated at 2022-06-24 00:10:51.572997
# Unit test for method map of class Lazy
def test_Lazy_map():
    def fn(n):
        return n + 1

    def mapper(n):
        return n * 2

    assert Lazy.of(1).map(mapper).get() == 2
    assert Lazy.of(2).map(mapper).get() == 4
    assert Lazy.of(1).map(fn).map(mapper).get() == 4

# Generated at 2022-06-24 00:11:03.786347
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.monad_validation_error import ValidationError

    foo = Try(lambda: 10)

    # check that we got value
    assert Lazy(foo).get() == 10

    # should not raise 
    Lazy(foo).get()

    # should raise
    result = Lazy(
        Try(lambda: foo / 0)
    )
    with pytest.raises(ZeroDivisionError):
        result.get()

    validation = Validation.of('foo')
    Lazy(validation).get()

    # should raise
    validation = Validation.of(ValidationError('bar'))
    with pytest.raises(ValidationError):
        Lazy(validation).get()



# Generated at 2022-06-24 00:11:13.960155
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def fn(x, y):
        return x + y

    lz = Lazy(fn)

    assert lz.constructor_fn(2, 3) == 5

    lz2 = lz.map(lambda x: x * 2)
    assert lz2.constructor_fn(2, 3) == 10

    assert lz.get(2, 3) == 5
    assert lz.is_evaluated is True

    assert lz2.get(2, 3) == 10
    assert lz2.is_evaluated is True


# Generated at 2022-06-24 00:11:16.711687
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:11:20.087260
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of('foo').to_either() == Right('foo')



# Generated at 2022-06-24 00:11:25.309782
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    fn_raising_exception = lambda: 1 / 0
    lazy_with_exception = Lazy(fn_raising_exception)
    lazy_with_value = Lazy(lambda: 123)

    assert lazy_with_value.to_try() == Try(123)
    assert lazy_with_exception.to_try() == Try.exception(ZeroDivisionError)



# Generated at 2022-06-24 00:11:35.782940
# Unit test for constructor of class Lazy
def test_Lazy():
    def test_fn():
        return 10

    assert str(Lazy(test_fn)) == 'Lazy[fn=<function test_fn at 0x7f609c2fb150>, value=None, is_evaluated=False]'
    assert Lazy.of(10) == Lazy(lambda: 10)
    assert Lazy.of(10) != Lazy(lambda: 20)
    assert Lazy.of(20).map(lambda x: x * 2) == Lazy(lambda: 10 * 2)
    assert Lazy.of(20).ap(Lazy(lambda: 10 * 2)) == Lazy(lambda: 10 * 2 * 2)
    assert Lazy.of(20).ap(Lazy.of(10)) == Lazy.of(20)

# Generated at 2022-06-24 00:11:41.311404
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    # GIVEN
    def func(*_):
        return 123

    lazy = Lazy(func)
    # WHEN
    maybe = lazy.to_maybe()
    # THEN
    assert maybe == Maybe.just(123)



# Generated at 2022-06-24 00:11:45.681612
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 0) == Lazy(lambda: 0)
    assert not Lazy(lambda: 0) == Lazy(lambda: 1)
    assert not Lazy(lambda: 0) == Lazy(lambda: 0 + 1)
    assert not Lazy(lambda: 0) == None



# Generated at 2022-06-24 00:11:51.637144
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def constructor_fn(*args):
        return 10 / args[0]

    def tester_fn(lazy_instance, expected):
        assert lazy_instance.to_try(0) == expected

    tester_fn(Lazy(constructor_fn), Try.raise_error(ZeroDivisionError))


# Generated at 2022-06-24 00:11:56.090834
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    """
    It should return not empty Validation with value of Lazy without calling constructor_fn.
    """
    assert Lazy.to_validation(Lazy.of(1)) == Validation.success(1)

# Generated at 2022-06-24 00:11:57.671420
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Lazy.of(None).to_maybe()

# Generated at 2022-06-24 00:12:01.740244
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def squared(a):
        return a * a

    fn = Lazy(squared)
    assert fn.is_evaluated == False
    assert fn.constructor_fn(3) == 9
    assert fn.get(3) == 9
    assert fn.is_evaluated == True
    assert fn.value == 9


# Generated at 2022-06-24 00:12:04.778070
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    constructor_fn = lambda x: x

    assert Lazy(constructor_fn).bind(lambda x: Lazy(lambda: x)) == Lazy(constructor_fn)
    assert Lazy(constructor_fn).bind(lambda x: Lazy(lambda: x + 1)) == Lazy(lambda: 1)


# Generated at 2022-06-24 00:12:14.538865
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f1(x):
        return x

    def g1(*args):
        return f1(*args)

    def f2(x):
        return x

    def g2(*args):
        return f2(*args)

    def f3(x):
        return x + 5

    def g3(*args):
        return f3(*args)

    assert Lazy(f1) == Lazy(g1)
    assert Lazy(f1) == Lazy(f2)
    assert Lazy(f1) == Lazy.of(1)
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) == Lazy.of('1')

    assert Lazy(f1) != Lazy(f3)
    assert Lazy.of(1) != Lazy

# Generated at 2022-06-24 00:12:15.969798
# Unit test for method get of class Lazy
def test_Lazy_get():
    value = Lazy(lambda: 123).get()
    ArithmeticError('123 is not equal to 456').expect(value).to_equal(456)


# Generated at 2022-06-24 00:12:23.350041
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad import Monad
    from pymonet.monad_try import Try

    def test_case(a, b):
        return a * b

    lazy1 = Lazy(test_case)

    monad = lazy1.to_try(3, 2)
    assert isinstance(monad, Monad) and isinstance(monad, Try)
    assert monad.safe_get() == 6

    def test_case2():
        raise Exception('Wrong case')

    lazy2 = Lazy(test_case2)

    monad = lazy2.to_try()
    assert isinstance(monad, Monad) and isinstance(monad, Try)
    assert monad.is_failure()
    exception = monad.exception
    assert exception is not None

# Generated at 2022-06-24 00:12:30.234963
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # given
    fn = sum

    # when
    l = Lazy(fn).bind(lambda x: Lazy(str(x)))

    # then
    assert str(l) == "Lazy[fn=<function <lambda> at 0x7f959d8f8510>, value=None, is_evaluated=False]"
    assert l.is_evaluated is False
    assert l.get(3, 1) == '4'
    assert l.is_evaluated is True
    assert l.value == '4'



# Generated at 2022-06-24 00:12:37.167742
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Define function for Lazy initialization
    def lazy_fn():
        return 42
    # Create Lazy
    lazy = Lazy(lazy_fn)
    # Calls bind method
    lazy_bind_result = lazy.bind(lambda x: Lazy(lambda: x * 2))
    # Function from lazy_bind_result should be called and returned 84
    assert lazy_bind_result.get() == 84
    # Function from lazy_bind_result should be called and returned 84
    assert lazy_bind_result.get() == 84
    # Function from lazy_bind_result should not be called and returned 84
    assert lazy_bind_result.get() == 84



# Generated at 2022-06-24 00:12:46.543850
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.monad_try import Try
    from pymonet.either import Right

    def _test_to_either_for_value(value, expected_value):
        assert Lazy(lambda: value).to_either() == expected_value

    def _test_to_either_for_error(expected_value):
        assert Lazy(lambda: error_fn()).to_either() == expected_value

    def _test_to_either_for_monad(monad, expected_value):
        assert Lazy(lambda: monad).to_either() == expected_value

    def _test_to_either_for_composition(monad, expected_value):
        assert Lazy(lambda: monad).to_either().map(lambda x: x).to_either() == expected_value

    _test_to_

# Generated at 2022-06-24 00:12:53.306109
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    a = Maybe('a')
    b = Maybe('b')
    c = Maybe('c')
    d = Maybe('d')

    def bind_fn(v):
        def _bind_fn():
            return Maybe(v)

        return Lazy(_bind_fn)

    e = a.bind(bind_fn).bind(bind_fn).to_maybe()
    assert e.is_value()
    assert e.unbox_or_else(None) == 'a'

    f = Maybe.nothing().bind(bind_fn).bind(bind_fn).to_maybe()
    assert f.is_nothing()

    g = a.bind(bind_fn).bind(bind_fn).bind(bind_fn).to_maybe()
    assert g.is_value()

# Generated at 2022-06-24 00:13:00.571980
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # Setup
    def make_bulk() -> Lazy[T, List[T]]:
        return Lazy(lambda *args: list(args))

    def add_elem(bulk: List[T]) -> Lazy[T, List[T]]:
        return Lazy(lambda elem: bulk + [elem])

    # test
    lazy = make_bulk().bind(add_elem)
    assert lazy.get(1, 2, 3, 4) == [1, 2, 3, 4]

# Generated at 2022-06-24 00:13:12.675849
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def both_should_return_success(fn, args):
        result = Lazy(fn).to_try(*args)
        assert isinstance(result, Try)
        assert result.is_success() and result.get() == 2
        assert result.map(lambda i: i ** 2).get() == 4

    def both_should_return_failure(fn, args):
        result = Lazy(fn).to_try(*args)
        assert isinstance(result, Try)
        assert result.is_failure() and result.get_error() == ValueError
        result = result.map(lambda i: i ** 2)
        assert result.is_failure()

    both_should_return_success(lambda: 2, [])

# Generated at 2022-06-24 00:13:15.545210
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    obj1 = Lazy(lambda: 1)
    obj2 = Lazy(lambda: 2)

    assert obj1.to_either(1) == Right(1)
    assert obj2.to_either(1) == Right(2)



# Generated at 2022-06-24 00:13:18.257948
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:13:22.632293
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of('a').to_maybe() == Maybe.just('a')

# Generated at 2022-06-24 00:13:30.505635
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test(t):
        return t

    # Test without raise
    assert Lazy(test).to_try(True) == Try.success(True)
    assert Lazy(test).to_try() == Try.success(None)

    # Test with rais
    assert Lazy(1/0).to_try() == Try.failure(ZeroDivisionError('division by zero'))

    # Test with rais in Validation
    assert Lazy(Validation.failure('failure')).to_try() == Try.failure(ValueError('Validation is Failure'))


# Generated at 2022-06-24 00:13:35.033832
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    def add(a):
        return a + 1

    lazy = Lazy(add)
    assert lazy.to_box(4) == Box(5)
    assert lazy.to_box(-1) == Box(0)


# Generated at 2022-06-24 00:13:39.606684
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1

    assert Lazy(lambda: 1).get(2) == 1

    assert Lazy(lambda x: x).get(1) == 1

    assert Lazy(lambda: 1).get() == 1

    assert Lazy(lambda: 1).get() == 1

    assert Lazy(lambda: 1).get() == 1



# Generated at 2022-06-24 00:13:45.538083
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 5

    def fn2():
        return 6

    lazy = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(fn2)

    assert lazy == lazy2
    assert lazy != lazy3
    assert lazy != fn


# Generated at 2022-06-24 00:13:48.914548
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left

    assert Lazy.of(2).to_either() == Right(2)
    assert Lazy(lambda: 1 / 0).to_either() == Left(ZeroDivisionError(0))

# Generated at 2022-06-24 00:13:54.784638
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.other_monad import instance_check

    lazy = Lazy.of(123)
    assert lazy.to_either() is Right(123)
    assert instance_check.is_of_type_either(lazy.to_either())



# Generated at 2022-06-24 00:13:56.573818
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)


# Generated at 2022-06-24 00:14:08.121138
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test Lazy.get method.
    """
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    def module(p1: str) -> str:
        return 'module {}'.format(p1)

    def component(p1: str) -> str:
        return 'component {}'.format(p1)

    def component_identifier(p1: str, p2: str) -> str:
        return '{}.{}'.format(p1, p2)

    def component_specification_constructor(p1: str, p2: str, p3: str) -> str:
        return 'new {}({}, {})'.format(p1, p2, p3)

    lazy_module = Lazy(module)

# Generated at 2022-06-24 00:14:19.977955
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.validation import Validation

    def test_function():
        return 5

    def test_mapper(value):
        return value*5

    lazy = Lazy(test_function)

    assert lazy.to_either() == Right(5)
    assert lazy.map(test_mapper).to_either() == Right(25)

    validation = lazy.to_validation()
    assert validation == Validation.success(5)
    assert validation.map(test_mapper) == Validation.success(25)

    box = lazy.to_box()
    assert box == Box(5)

# Generated at 2022-06-24 00:14:22.575181
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    fn = lambda x: x + 1

    assert Lazy(fn).to_box() == Box(1)


# Generated at 2022-06-24 00:14:28.771624
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def test_fn():
        pass

    value = 123
    lazy = Lazy(test_fn)
    assert str(lazy) == 'Lazy[fn=<function test_fn at {}>, value=None, is_evaluated=False]'.format(id(test_fn))
    lazy = Lazy(lambda: value)
    assert str(lazy) == 'Lazy[fn=<function <lambda> at {}>, value=None, is_evaluated=False]'.format(id(lazy))



# Generated at 2022-06-24 00:14:37.206322
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Unit test for method __eq__ of class Lazy.
    """
    from pymonet.maybe import Maybe

    def contra_variant_test():
        def fn():
            return Maybe.just(None)

        lazy_1 = Lazy.of(None).map(fn)
        lazy_2 = Lazy.of(None).map(fn)

        assert lazy_1 == lazy_2

        lazy_2 = Lazy.of(None).map(fn).bind(lambda x: x.map(lambda y: y.to_list()))

        assert lazy_1 != lazy_2

    def variat_test():
        def fn(value):
            return Maybe.just(value)

        lazy_1 = Lazy.of(1).map(fn)

# Generated at 2022-06-24 00:14:40.697984
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(1).to_box() == Box(1)


# Generated at 2022-06-24 00:14:49.762219
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.utils import curried

    assert Lazy(curried((lambda a: a + 1))).map(curried((lambda a: a + 1))).bind(curried((lambda a: a + 1))).__eq__(
        Lazy(curried((lambda a: a + 1))).map(curried((lambda a: a + 1))).bind(curried((lambda a: a + 1))),
    )
    assert not Lazy(curried((lambda a: a + 1))).__eq__(Lazy(curried((lambda a: a))))
    assert not Lazy(curried((lambda a: a + 1))).map(curried((lambda a: a + 1))).__eq__(Lazy(curried((lambda a: a))))

# Generated at 2022-06-24 00:14:53.259483
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    assert Lazy.of(1).bind(lambda val: Lazy(lambda: val + 1)).get() == 2



# Generated at 2022-06-24 00:14:55.705226
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(number):
        return Lazy.of(number)

    assert Lazy.of(123).bind(fn).get() == 123



# Generated at 2022-06-24 00:15:03.625708
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of([])
    assert Lazy.of([]) != Lazy.of({})
    assert Lazy.of(None) == Lazy.of(None)
    assert Lazy.of(None) == Lazy.of(lambda: None)
    assert Lazy.of(None) != Lazy.of(lambda: 1)


# Generated at 2022-06-24 00:15:11.200987
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    """
    Unit test for method ap of class Lazy
    """

    def add(x: int) -> int:
        return x + 1

    def multi(x: int) -> int:
        return x * 2

    lazy = Lazy(add)
    lazy_add = lazy.map(add)
    assert lazy_add.ap(lazy_add).get(1) == 5
    assert lazy.ap(lazy_add).get(1) == 3

    assert lazy.ap(lazy.map(multi)).get(1) == 3
    assert lazy.ap(lazy).get(1) == 2



# Generated at 2022-06-24 00:15:17.879509
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy_value = Lazy.of(1).map(lambda x: x + 1)
    assert lazy_value.get() == 2

    lazy_value = Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert lazy_value.get() == 3



# Generated at 2022-06-24 00:15:29.901530
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.maybe import Just

    lazy_1 = Lazy(lambda: 'b')
    lazy_2 = Lazy(lambda a: a, 'b')

    assert str(lazy_1) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f12b5a8f488>, value=None, is_evaluated=False]'
    assert str(lazy_2) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f12b5a8f510>, value=b, is_evaluated=True]'


# Generated at 2022-06-24 00:15:31.911025
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    value = 5
    assert Right(value) == Lazy.of(value).to_either()



# Generated at 2022-06-24 00:15:37.506897
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for method get of class Lazy
    """
    # Given
    def func(*args):
        return args

    lazy = Lazy(func)
    args = [1, 2, 3]

    # When
    result = lazy.get(*args)

    # Then
    assert args == result
    assert lazy.is_evaluated is True
    assert lazy.value == result


# Generated at 2022-06-24 00:15:44.940105
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given
    test_value_a, test_value_b = 'test_value', 'test_value_b'

    # When
    lazy_fn = lambda: test_value_a
    lazy = Lazy(lazy_fn)
    lazy_mapped = lazy.map(lambda a: a + test_value_b)

    # Then
    assert lazy_mapped.get() == test_value_a + test_value_b


# Generated at 2022-06-24 00:15:46.894144
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation, is_success

    validation = Lazy(lambda: 5).to_validation()

    assert is_success(validation)
    assert validation == Validation.success(5)

# Generated at 2022-06-24 00:15:57.959746
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    def lambda_fn():
        return 10

    def lambda_fn_raise():
        raise RuntimeError  # pragma: no cover

    def lambda_fn_maybe():
        return Maybe.just(10)

    def lambda_fn_raise_maybe():
        return Maybe.nothing

    def lambda_fn_raise_maybe_two():
        raise RuntimeError  # pragma: no cover

    lazy_zero = Lazy(lambda_fn)
    lazy_one = Lazy(lambda_fn_maybe)

    lazy_raise_zero = Lazy(lambda_fn_raise)
    lazy_raise_one = Lazy(lambda_fn_raise_maybe)


# Generated at 2022-06-24 00:16:01.527388
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda: 1) == Lazy<int, int>(lambda x: 1)



# Generated at 2022-06-24 00:16:09.749666
# Unit test for constructor of class Lazy
def test_Lazy():
    fn = lambda x: x + 100

    lazy = Lazy(fn)

    assert lazy.constructor_fn == fn
    assert str(lazy) == 'Lazy[fn=' + str(fn) + ', value=None, is_evaluated=False]'
    assert lazy.is_evaluated == False
    assert lazy.value == None

# Generated at 2022-06-24 00:16:18.983982
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<function Lazy.<lambda> at 0x102f8e400>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x * 2)) == 'Lazy[fn=<function Lazy.<lambda>.<locals>.<lambda> at 0x102f8e728>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x * 2).get()) == 'Lazy[fn=<function Lazy.<lambda>.<locals>.<lambda> at 0x102f8e728>, value=4, is_evaluated=True]'

#

# Generated at 2022-06-24 00:16:25.409961
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(lambda x: x) \
        .map(lambda f: lambda x: x + 10) \
        .get(2) == 12

    assert Lazy.of(lambda x: x) \
        .map(lambda f: lambda y: f(y) + 10) \
        .get(2) == 12
		

# Generated at 2022-06-24 00:16:35.279759
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    # lambda x: 2 / x
    f = lambda x: 2 / x
    # Lazy[fn=<function <lambda> at 0x7f3b8766a9d8>, value=None, is_evaluated=False]
    actual = Lazy(f)
    # Try[Value=2.0, Error=None]
    expected = Try.of(f, 1)
    assert actual.to_try(1) == expected

    # lambda x: 1 / (x - 1)
    f = lambda x: 1 / (x - 1)
    # Lazy[fn=<function <lambda> at 0x7f3b8766a9d8>, value=None, is_evaluated=False]
    actual = Lazy(f)
    # Try[Value=None, Error=[division by zero]]
    expected = Try

# Generated at 2022-06-24 00:16:46.639475
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.box import box_of
    from pymonet.box import BoxBool
    from pymonet.box import BoxFloat
    from pymonet.box import BoxInt
    from pymonet.box import BoxStr

    assert Lazy(lambda x: x).to_box(1) == box_of(1)
    assert Lazy(lambda x: x).to_box('Hello!') == BoxStr('Hello!')
    assert Lazy(lambda x: x).to_box(1.9) == BoxFloat(1.9)
    assert Lazy(lambda x: x).to_box(True) == BoxBool(True)
    assert Lazy(lambda x: x).to_box(False) == BoxBool(False)
   

# Generated at 2022-06-24 00:16:50.766315
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy.of("test").to_validation() == Validation("test")

# Generated at 2022-06-24 00:16:54.503800
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    def fn():
        return 'value'

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy(fn).to_either() == Right('value')



# Generated at 2022-06-24 00:16:56.308051
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.box import Box
    assert str(Lazy.of(Box(4))) == "Lazy[fn=<function <lambda> at 0x7f532d1b6620>, value=None, is_evaluated=False]"
