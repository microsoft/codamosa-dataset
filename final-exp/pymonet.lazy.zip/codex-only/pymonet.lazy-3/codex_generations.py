

# Generated at 2022-06-24 00:06:58.530521
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    f = lambda x: Lazy.of(x)
    s = Lazy.of(0).bind(f)
    assert id(s.constructor_fn) != id(f)



# Generated at 2022-06-24 00:07:02.123003
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def fn():
        return 100

    result = Lazy(fn).to_validation()
    assert isinstance(result, Validation)
    assert result.is_success()
    assert result.value == 100



# Generated at 2022-06-24 00:07:05.765267
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def f():
        return 1

    lazy = Lazy(f)

    result = lazy.to_maybe()

    expected = Maybe.just(1)

    assert result == expected



# Generated at 2022-06-24 00:07:09.632642
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return 'test'

    lazy = Lazy(fn)

    assert lazy.is_evaluated == False
    assert lazy.get() == 'test'
    assert lazy.is_evaluated == True
    assert lazy.value == 'test'


# Generated at 2022-06-24 00:07:10.997174
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    val = Lazy.of(1)
    box = Box(lambda x: x * 2)

    assert val.ap(box).get() == 2

# Generated at 2022-06-24 00:07:17.998552
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def add1(x):
        return x + 1


    def divide(x, y):
        return x / y


    def divide_as_lazy(x, y):
        return Lazy(lambda _: divide(x, y))

    def broken():
        raise TypeError('broken')

    assert Lazy(lambda: 2).to_maybe() == Maybe.just(2)
    assert Lazy(lambda: None).to_maybe() == Maybe.just(None)
    assert Lazy(broken).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:07:22.066252
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    # given
    def add_one(value: int) -> int:
        return value + 1

    lazy = Lazy(add_one)

    # when
    result = str(lazy)

    # then
    # it have a str method
    assert isinstance(result, str)


# Generated at 2022-06-24 00:07:30.379025
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a, b):
        return a + b

    def multiply(a, b):
        return a * b

    def apply_function(function, a, b):
        return function(a, b)

    lazy_add = Lazy.of(add)
    lazy_multiply = Lazy.of(multiply)
    lazy_apply = Lazy.of(apply_function)

    assert lazy_apply.ap(lazy_add).ap(Lazy.of(2)).ap(Lazy.of(2)) == Lazy(add(2, 2))
    assert lazy_apply.ap(lazy_multiply).ap(Lazy.of(2)).ap(Lazy.of(2)) == Lazy(multiply(2, 2))

# Generated at 2022-06-24 00:07:35.483435
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def div(x, y):
        return x / y

    def div_null(x, y):
        return x / y if y != 0 else 'division by zero'

    result = Lazy.of(div).to_try(1, 0)
    assert isinstance(result, Try)
    assert result.is_failure()
    assert result.failed().value == 'division by zero'

    result = Lazy.of(div).to_try(10, 2)
    assert isinstance(result, Try)
    assert result.is_success()
    assert result.value == 5

    result = Lazy.of(div_null).to_try(10, 0)
    assert isinstance(result, Try)
    assert result.is_failure()
    assert result.failed().value == 'division by zero'


# Generated at 2022-06-24 00:07:37.924050
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.monad import curry

    lazy = Lazy.of(12)
    assert lazy.to_either() == lazy.to_maybe()



# Generated at 2022-06-24 00:07:48.149160
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_maybe import Maybe

    assert Lazy(lambda x: Maybe.just(x) + 1).map(lambda x: x * 2).get(4) == 10
    assert Lazy(lambda x: Maybe.just(x) + 1).map(lambda x: x - 2).get(4) == 3
    assert Lazy(lambda x: Maybe.nothing() + 1).map(lambda x: x * 2).get(4) == None
    assert str(Lazy(lambda x: Maybe.just(x) + 1).map(lambda x: x * 2)) == 'Lazy[fn=<function Lazy.<lambda> at 0x7fa8405b3d08>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:07:51.617727
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    f = lambda x: x + 1
    a = Lazy(f)
    b = Box(1)

    assert a.to_box() == Box(2)

    assert a.bind(lambda x: b).to_box() == Box(2)

# Generated at 2022-06-24 00:07:54.914804
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda a: a)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7fcde0e601e0>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:07:56.606385
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x * 2).get() == 2



# Generated at 2022-06-24 00:08:03.614833
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.monad_maybe import Maybe

    test_value = 123
    lazy_value = Lazy.of(test_value)

    assert Maybe.just(test_value) == lazy_value.to_maybe()
    assert lazy_value.get() == test_value



# Generated at 2022-06-24 00:08:06.425919
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    """
    Test to_box method of class Lazy
    """
    assert Lazy(lambda: 'A').to_box() == Lazy(lambda: 'A').to_box()



# Generated at 2022-06-24 00:08:16.357954
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy.of(1)) == 'Lazy[fn=<function Lazy.__init__.<locals>.<lambda>>, value=1, is_evaluated=True]'
    assert str(Lazy.of(1).map(lambda x: x + 5)) == 'Lazy[fn=<function Lazy.__init__.<locals>.<lambda>>, value=6, is_evaluated=True]'
    assert str(Lazy.of(lambda x: x + 1).get()) == 'Lazy[fn=<function Lazy.__init__.<locals>.<lambda>>, value=2, is_evaluated=True]'

# Generated at 2022-06-24 00:08:19.808044
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy.of(1).to_validation().is_success()
    assert Lazy.of(1).to_validation().value == 1
    assert Lazy.of(1).to_validation().errors == []

# Generated at 2022-06-24 00:08:22.046104
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of('something').to_either() == Right('something')

# Generated at 2022-06-24 00:08:27.875335
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation() == Validation.success(1)
    assert Lazy.of(1).map(lambda x: x + 1).to_validation() == Validation.success(2)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).to_validation() == Validation.success(3)


# Generated at 2022-06-24 00:08:29.770856
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of('foo').get() == 'foo'



# Generated at 2022-06-24 00:08:32.662133
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy(lambda: 2).to_try() == Try.of(lambda: 2)
    assert Lazy(lambda: 2 / 0).to_try() == Try.of(lambda: 2 / 0)



# Generated at 2022-06-24 00:08:36.721054
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def uppercased(s):
        return s.upper()

    def t_upper_fn(s):
        return Lazy(lambda: uppercased(s))

    identity = Lazy(lambda: 'test')
    assert identity.bind(t_upper_fn).get() == 'TEST'


# Generated at 2022-06-24 00:08:46.632718
# Unit test for constructor of class Lazy
def test_Lazy():
    test_value = 'test_value'

    def test_function():  # pragma: no cover
        return test_value

    def test_function_with_argument(arg):  # pragma: no cover
        return arg + test_value

    result_of_Lazy = Lazy(test_function).get()
    assert result_of_Lazy == test_value, 'Lazy should return constructor function'

    result_of_Lazy2 = Lazy(test_function_with_argument, test_value).get()
    assert result_of_Lazy2 == result_of_Lazy + test_value, 'Lazy should pass arguments to constructor function'



# Generated at 2022-06-24 00:08:55.415891
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for method get of class Lazy.

    test_Lazy_get is a unit.
    """
    from pymonet.either import Right

    def add_one(x: int) -> int:
        return x + 1

    def bind_function(x: int) -> Right[int]:
        return Right(x)

    assert Lazy.of(10).get() == 10
    assert Lazy.of(10).bind(bind_function).get() == Right(10)
    assert Lazy.of(10).map(add_one).get() == 11

# Generated at 2022-06-24 00:08:57.587800
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    # given
    lazy = Lazy.of(1)

    # expect
    assert lazy.to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:09:01.526052
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    lazy_fn = lambda x: x
    assert Lazy(lazy_fn) != 1
    assert Lazy(lazy_fn)._compute_value(2) == Lazy(lazy_fn)._compute_value(2)
    assert Lazy(lazy_fn)._compute_value(2) != Lazy(lazy_fn)._compute_value(3)



# Generated at 2022-06-24 00:09:10.898606
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Error
    from pymonet.monad_try import Success

    # Test with successfull function
    to_try_result = Lazy(lambda: 1).to_try()
    assert isinstance(to_try_result, Try)
    assert to_try_result.fold(lambda x: None, lambda x: x) == 1

    def raising_fn():
        raise ValueError()

    # Test with Raising function
    to_try_result = Lazy(raising_fn).to_try()
    assert isinstance(to_try_result, Try)
    assert isinstance(to_try_result._result, Error)

    # Test with function returning Try

# Generated at 2022-06-24 00:09:20.139306
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    f = lambda x: x * 2
    g = lambda x: x + 3

    assert Lazy.of(2).map(f).map(g).get() == 8
    assert Lazy.of(2).map(f).map(g).to_box().get() == 8
    assert Lazy.of(2).map(f).map(g).to_either().get() == 8
    assert Lazy.of(2).map(f).map(g).to_maybe().get() == 8


# Generated at 2022-06-24 00:09:27.228701
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """Unit test for method to_try of class Lazy"""

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    from pymonet.monad_try import Try

    class TestLazyToTry(unittest.TestCase):
        def test_to_try(self):
            self.assertEqual(
                Lazy(lambda x: x + 2).to_try(2),
                Try.of(lambda x: x + 2, 2),
            )

            self.assertEqual(
                Lazy(lambda: len([]) / 0).to_try(),
                Try.failure(ZeroDivisionError),
            )

    unittest.main()

# Generated at 2022-06-24 00:09:36.292774
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(3) == Lazy.of(3)
    assert Lazy.of(lambda x, y: x + y) == Lazy.of(lambda x, y: x + y)

    assert Lazy.of(3).map(lambda x: x + 1) == Lazy.of(3).map(lambda x: x + 1)
    assert Lazy.of(lambda x, y: x + y).map(lambda x: x(1, 2)) == Lazy.of(lambda x, y: x + y).map(lambda x: x(1, 2))
    assert Lazy.of(lambda x, y: x + y).map(lambda x: x(1, 2)) != Lazy.of(lambda x, y: x + y).map(lambda x: x(1, 3))



# Generated at 2022-06-24 00:09:45.382128
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(str).map(int).map(str) == Lazy.of(1).map(str).map(int).map(str)
    assert Lazy.of(1).map(str).map(int) != Lazy.of(1).map(str).map(str)
    assert Lazy.of(1).map(str).map(int).map(str).map(int) == Lazy.of(1).map(str).map(int).map(str).map(int)
    assert Lazy.of(1).map(str).map(int).map(str).map(int).constructor_fn(1) == 1
    assert Lazy.of(1).map(str).map(int).map(str).map(int).get(1) == 1
    assert Lazy.of

# Generated at 2022-06-24 00:09:51.476653
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.either import Left, Right

    def test():
        return Right(3)

    assert str(Lazy(test)) == 'Lazy[fn=<function test at 0x109f2b7b8>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:10:01.473451
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Lazy method map test function.
    """
    def add_two(n: int) -> int:
        return n + 2

    def add_four(n: int) -> int:
        return n + 4

    lazy_add_two = Lazy(add_two)
    assert lazy_add_two.map(add_four).constructor_fn(2) == 8

    lazy_add_two = Lazy(add_two)
    assert lazy_add_two.map(lambda x: x).constructor_fn(2) == 4

    lazy_empty = Lazy(lambda x: None)
    assert lazy_empty.map(lambda x: x).constructor_fn(2) is None


# Generated at 2022-06-24 00:10:07.121666
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy.of(Maybe.just(1)).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:10:10.425995
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.functors.monoid import Sum

    assert str(Lazy(Sum.zero)) == 'Lazy[fn=<bound method Sum.zero of Sum(item=0)>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:10:14.466936
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def func_to_call_later(value1, value2):  # pragma: no cover
        return value1 + value2

    lazy = Lazy(func_to_call_later)
    assert lazy.to_either(4, 5) == Right(9)



# Generated at 2022-06-24 00:10:18.513998
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    def fn():
        return 1

    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy(fn).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:10:21.201703
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def fn(val):
        return Lazy(lambda *args: val * 2)

    assert Lazy.of(5).ap(fn(5)) == (Lazy.of(10))


# Generated at 2022-06-24 00:10:24.964616
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.utils import identity

    f = Lazy.of(5)
    g = lambda x: x + 1

    assert f.map(g).get() == 6

    assert f.map(identity).get() == 5



# Generated at 2022-06-24 00:10:31.238449
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda a: a) == Lazy(lambda a: a)

    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda a: a) != Lazy(lambda a: a + 1)
    assert Lazy(lambda a: a) != Lazy(lambda b: b)



# Generated at 2022-06-24 00:10:34.691358
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    def box_to_lazy(b):
        return Lazy(lambda: b.get())

    assert box_to_lazy(Box(2)).to_box().unwrap() == 2
    assert box_to_lazy(Box('a')).to_box().unwrap() == 'a'
    assert box_to_lazy(Box(None)).to_box().unwrap() is None


# Generated at 2022-06-24 00:10:38.381626
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert str(Lazy.of(1).map(lambda x: x * 2)) == 'Lazy[fn=Function, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:10:41.343555
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x1111111111111>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:10:45.932063
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy(lambda x: x + 2).to_validation(2) == Validation.success(4)

# Generated at 2022-06-24 00:10:51.793873
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    """Unit test for method __str__ of class Lazy."""
    # Given
    some_lazy = Lazy(lambda: 'some value')

    # When
    result = str(some_lazy)

    # Then
    assert result == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x10e5b5ae8>, value=None, is_evaluated=False]', result



# Generated at 2022-06-24 00:11:02.023869
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.box import Box

    def func_to_call(x):
        return x

    lazy_value = Lazy(func_to_call)
    assert lazy_value.to_either() == Right(None)
    assert lazy_value.to_maybe() == Maybe.just(None)
    assert lazy_value.to_validation() == Validation.success(None)
    assert lazy_value.to_box() == Box(None)
    assert lazy_value.to_try() == Maybe.just(None)



# Generated at 2022-06-24 00:11:06.402535
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: None).get() is None
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 'Foo').get() == 'Foo'
    assert Lazy(lambda: [1, 2]).get() == [1, 2]
    assert Lazy(lambda: {'foo': 'bar'}).get() == {'foo': 'bar'}

# Generated at 2022-06-24 00:11:13.534580
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fold_function(value):
        return Lazy.of(value + 1)

    data = Lazy.of(1)
    assert data.bind(fold_function).get() == 2

    data = Lazy.of('1')
    assert data.bind(fold_function).get() == 2

    assert data.bind(fold_function).bind(fold_function).get() == 3

# Generated at 2022-06-24 00:11:22.926980
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def throwing_function(*args):
        raise Exception('test_Lazy_to_try')

    maybe_lazy_result = Lazy(throwing_function).to_try()

    assert isinstance(maybe_lazy_result, Try)
    assert maybe_lazy_result.is_failure()
    assert isinstance(maybe_lazy_result.get_error(), Exception)
    assert maybe_lazy_result.get_error().args[0] == 'test_Lazy_to_try'



# Generated at 2022-06-24 00:11:27.097897
# Unit test for constructor of class Lazy
def test_Lazy():
    def const_10(*args):
        return 10

    assert Lazy(lambda: 10).to_box() == Box(10)
    assert Lazy(lambda: '').to_box() == Box('')
    assert Lazy(lambda: None).to_box() == Box(None)
    assert Lazy(const_10).to_box() == Box(10)
    assert Lazy(const_10).to_box(1, 2) == Box(10)



# Generated at 2022-06-24 00:11:30.041611
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of('pymonet').to_validation() == Validation.success(Lazy.of('pymonet').get())

# Generated at 2022-06-24 00:11:33.012935
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(10).to_box() == Box(10)



# Generated at 2022-06-24 00:11:35.170377
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of('test').to_maybe() == Maybe('test')


# Generated at 2022-06-24 00:11:42.866833
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.compat import identity

    lazy = Lazy(lambda: 1)
    assert Maybe.just(1) == lazy.to_maybe()

    lazy = Lazy(lambda: None)
    assert Maybe.nothing() == lazy.to_maybe()

    assert Maybe.just(1) == Maybe.just(1) == Maybe.of(identity).ap(Maybe.of(1))

# Generated at 2022-06-24 00:11:47.808355
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Box('test') == Lazy.of(1).map(lambda x: 'test').to_box()


# Generated at 2022-06-24 00:11:50.392101
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(42).to_box() == Box(42)


# Generated at 2022-06-24 00:11:58.512234
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.test_utils import TestUtils

    assert TestUtils.is_box(Lazy(lambda: None).to_box(), Box(None))
    assert TestUtils.is_box(Lazy(lambda: 1).to_box(), Box(1))
    assert TestUtils.is_box(Lazy(lambda: [1, 2, 3]).to_box(), Box([1, 2, 3]))
    assert TestUtils.is_box(Lazy(lambda: {'a': True, 'b': False}).to_box(), Box({'a': True, 'b': False}))



# Generated at 2022-06-24 00:12:05.533148
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    # Arrange
    not_evaluated_lazy = Lazy(lambda *args: Functor.of('test'))
    evaluated_lazy = Lazy(lambda *args: Functor.of('test'))
    evaluated_lazy.get()
    wrong_value_lazy = Lazy(lambda *args: Functor.of('wrong_value'))
    wrong_value_lazy.get()

    # Act & Assert
    assert evaluated_lazy == evaluated_lazy
    assert not_evaluated_lazy == not_evaluated_lazy
    assert wrong_value_lazy == wrong_value_lazy

    assert evaluated_lazy != not_evaluated_lazy
    assert evaluated_lazy != wrong

# Generated at 2022-06-24 00:12:14.414765
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def inc(x: int) -> int:
        return x + 1

    def int_dec(x: int) -> int:
        return x - 1

    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: inc(x))).get() == 2
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: int_dec(x))).get() == 0
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x)).get() == 1
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x)).bind(lambda x: Lazy(lambda: inc(x))).get() == 2


# Generated at 2022-06-24 00:12:17.286141
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x) == Lazy(lambda x: x) == Lazy(lambda y: y)
    assert Lazy(lambda x: x) != Lazy(lambda y: y + 1)
    assert Lazy(lambda x: x).map(lambda y: y * y * y) != Lazy(lambda y: y * y)
    assert Lazy(lambda x: x).map(lambda y: y * y * y) == Lazy(lambda y: y * y * y)



# Generated at 2022-06-24 00:12:20.733648
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.box import Box
    assert Lazy(lambda: Box('string')).to_validation() == Box('string')
    assert Lazy(lambda: Box('string')).to_validation().value == 'string'



# Generated at 2022-06-24 00:12:28.599530
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    import pytest

    def fn_to_call(arg: int) -> int:
        return arg + 1

    lazy_value = Lazy.of(2)

    assert lazy_value.get() == 2

    def fn_parent(arg: int) -> Lazy[int, int]:
        return Lazy.of(fn_to_call(arg))

    assert lazy_value.bind(fn_parent).get() == 3

    with pytest.raises(TypeError):
        lazy_value.bind('function_that_not_exists')

# Generated at 2022-06-24 00:12:35.793422
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def _add(val: int) -> Lazy[int, int]:
        return Lazy.of(lambda x: val + x)

    lazy = Lazy.of(3)
    result1 = lazy.bind(_add(1))
    result2 = lazy.bind(_add(2))
    result3 = lazy.bind(_add(3))

    assert result1.get() == 4
    assert result2.get() == 5
    assert result3.get() == 6

# Generated at 2022-06-24 00:12:39.078418
# Unit test for method get of class Lazy
def test_Lazy_get():
    fn = lambda x: x + 1
    lazy = Lazy(fn)
    lazy_evaluated = Lazy(fn)
    lazy._compute_value(1)

    assert lazy.get(1) == 2
    assert lazy_evaluated.get() == 2

# Generated at 2022-06-24 00:12:43.755429
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    """
    Unit test for method to_maybe of class Lazy
    """
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    # GIVEN
    lazy = Lazy(Box(5).map(lambda x: x + 10))

    # WHEN
    result = lazy.to_maybe()

    # THEN
    assert Maybe.just(15) == result

# Generated at 2022-06-24 00:12:48.817504
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.monad_lazy import Lazy

    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda n: n + 1).get() == 2
    assert Lazy.of((1, 2, 3, 4)).ap(Lazy.of(lambda n: n[2] + 1))



# Generated at 2022-06-24 00:12:52.066607
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy(lambda x: x + x).to_either(1) == Right(2)
    assert Lazy(lambda x: x + x).to_either() == Right(2)
    assert Lazy(lambda x: x + x).to_either(1, 2, 3) == Right(2)


# Generated at 2022-06-24 00:12:54.177948
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy(lambda *args: 1)


# Generated at 2022-06-24 00:12:59.813603
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def stupid_fn(*args):
        import time
        import random

        time.sleep(random.choice([0.2, 0.5, 0.8]))

        return 'Yeeh'

    assert Maybe.just('Yeeh') == Lazy(stupid_fn).to_maybe()

# Generated at 2022-06-24 00:13:02.566386
# Unit test for method get of class Lazy
def test_Lazy_get():
    Test = Lazy(lambda x: x + 'test')
    assert Test.get() is Test.get()



# Generated at 2022-06-24 00:13:08.834676
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x + 5).map(lambda x: x * 2).get(2) == 14
    assert Lazy(lambda x: x + 1).map(lambda x: x * 2).get(2) == 6


# Generated at 2022-06-24 00:13:13.571153
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add_1_and_add_2(a):
        return a + 3

    lazy_1 = Lazy.of(1)
    lazy_mapped = lazy_1.map(add_1_and_add_2)
    assert lazy_1.ap(lazy_mapped).get() == 4

# Generated at 2022-06-24 00:13:24.323921
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.monad_maybe import Maybe

    def fn(a, b):
        return a + b

    lazy = Lazy(lambda: fn(4, 2))
    assert lazy.get() == 6

    lazy = Lazy(lambda: fn(4, 2))
    assert lazy.map(lambda x: x + 4).get() == 10

    def fn_maybe(a):
        return Maybe.just(a * 10)

    lazy = Lazy(lambda: fn_maybe(4))
    assert lazy.to_maybe().get() == Maybe.just(40)

    lazy = Lazy(lambda: fn_maybe(4))
    assert lazy.bind(lambda x: Lazy.of(x + 4)).get() == Maybe.just(44)


# Generated at 2022-06-24 00:13:31.466039
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x).ap(Lazy.of(1)) == Lazy.of(1)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)) == Lazy.of(3)
    assert Lazy.of(lambda x, y: x + y).ap(Lazy.of(1)) == Lazy.of(lambda x: x + 1)
    assert Lazy.of(lambda x, y: x * y).ap(Lazy.of(2)) == Lazy.of(lambda x: x * 2)
    assert Lazy.of(lambda x, y: x * y).ap(Lazy.of(2)) == Lazy.of(lambda x: x * 2)



# Generated at 2022-06-24 00:13:37.874180
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    Lazy.of('1').ap(Lazy.of(lambda x: int(x))) == Lazy.of(1)
    Lazy.of('1').to_maybe().ap(Lazy.of(lambda x: int(x))) == Lazy.of(1).to_maybe()
    val = Lazy.of('1').ap(Maybe.of(lambda x: int(x)))
    assert type(val) is Maybe
    val.get() == 1



# Generated at 2022-06-24 00:13:49.146714
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<function <lambda> at 0x10bd9b400>, value=None, is_evaluated=False]'

    def fn():  # pragma: no cover
        pass
    assert str(Lazy(fn)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x10bd9b840>, value=None, is_evaluated=False]'

    def fn():  # pragma: no cover
        pass
    assert str(Lazy(fn).map(lambda x: x)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x10bd9b840>, value=None, is_evaluated=False]'

    lazy = Lazy(fn)


# Generated at 2022-06-24 00:13:52.737684
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function Lazy.<lambda> at 0x000001A0B8F74E18>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:14:01.557879
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet import Monad
    from pymonet.iterable import Iterable
    from pymonet.maybe import Maybe
    import pymonet.monad_try as monad_try

    def add_one(x):
        return x + 1

    def multiply_two(x):
        return x * 2

    def divide_two(x):
        if x % 2 == 0:
            return x / 2
        else:
            return x

    def add_one_to_maybe(maybe):
        return Maybe.just(add_one(maybe.get()))

    def multiply_two_to_try(try_):
        return monad_try.Try.of(multiply_two, try_.get())

    lazy1 = Lazy(add_one)
    lazy2 = Lazy(multiply_two)

# Generated at 2022-06-24 00:14:05.151177
# Unit test for constructor of class Lazy
def test_Lazy():
    def _example_function(x, y):
        return x + y

    l = Lazy(_example_function)
    assert l._compute_value(1, 2) == 3

    l = Lazy(_example_function)
    assert l.get(2, 3) == 5



# Generated at 2022-06-24 00:14:15.858648
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.utils import identity, square

    assert Maybe.just(10) == Lazy.of(10).to_maybe()
    assert Maybe.just(10) == Lazy(lambda x: x).map(square).map(square).to_maybe(5)
    assert Maybe.just(10) == Lazy(lambda x: x).bind(lambda y: Lazy.of(y * y)).bind(lambda z: Lazy.of(z * z)).to_maybe(5)
    assert Maybe.nothing() == Lazy(lambda x: x).bind(lambda y: Lazy.of(y * y)).bind(lambda z: Lazy.of(z * z)).to_maybe(None)
    assert Lazy.of(10).to_maybe() == L

# Generated at 2022-06-24 00:14:25.839804
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.unittest_utils import assert_methods_equals
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.either import Right
    from pymonet.box import Box

    args_to_test = [[1, 2, 3], ('string',), ([1, 2, 3],)]
    method_to_test = Lazy.of(1).map(lambda x: x * 2).ap

    def to_test(arg_to_test):
        return method_to_test(Lazy.of(lambda x: x + arg_to_test))


# Generated at 2022-06-24 00:14:27.840795
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).is_evaluated is True
    assert Lazy(lambda: 2).is_evaluated is False


# Generated at 2022-06-24 00:14:29.171303
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy(lambda: 1).to_either() == Right(1)

# Generated at 2022-06-24 00:14:31.629211
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe(): #pragma: no cover
    from pymonet.maybe import Maybe

    assert Maybe.just('test').to_lazy().to_maybe().is_just()



# Generated at 2022-06-24 00:14:41.938786
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert 'Lazy[fn=<function f at 0x7f10a06a3d90>, value=None, is_evaluated=False]' == '{}'.format(Lazy(f))  # noqa:E731
    assert 'Lazy[fn=<...>, value=1, is_evaluated=True]' == '{}'.format(Lazy(f).get())  # noqa:E731
    assert 'Lazy[fn=<...>, value=1, is_evaluated=True]' == '{}'.format(Lazy(f).to_box().get())  # noqa:E731

# Generated at 2022-06-24 00:14:45.269174
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy(lambda x: x + 1)
    assert lazy.bind(lambda x: Lazy(lambda _: x + 1)).get(1) == 3

# Generated at 2022-06-24 00:14:53.670456
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def not_empty_fn():
        print('not_empty_fn called')
        return 'value'

    def empty_fn():
        print('empty_fn called')
        return None

    lazy_not_empty = Lazy(not_empty_fn)
    assert lazy_not_empty.to_maybe() == Maybe.just('value')

    lazy_empty = Lazy(empty_fn)
    assert lazy_empty.to_maybe() == Maybe.empty()

    lazy_none = Lazy.of(None)
    assert lazy_none.to_maybe() == Maybe.empty()

    lazy_empty = Lazy(lambda: '')
    assert lazy_empty.to_maybe() == Maybe.empty()



# Generated at 2022-06-24 00:15:03.749532
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad import Monad, Functor
    from pymonet.monad_lazy import Lazy

    def to_str(data):
        return str(data)

    assert isinstance(Lazy(lambda: 1).map(to_str), Lazy)
    assert isinstance(Lazy(lambda: 1).map(to_str), Monad)
    assert isinstance(Lazy(lambda: 1).map(to_str), Functor)

    assert isinstance(Lazy(lambda: {}).map(to_str), Lazy)
    assert isinstance(Lazy(lambda: {}).map(to_str), Monad)
    assert isinstance(Lazy(lambda: {}).map(to_str), Functor)

    assert isinstance(Lazy(lambda: []).map(to_str), Lazy)

# Generated at 2022-06-24 00:15:06.248953
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def construct(value):
        return value

    lazy = Lazy(construct)

    maybe = lazy.to_maybe(5)

    assert maybe == Maybe.of(5)

# Generated at 2022-06-24 00:15:08.765167
# Unit test for method map of class Lazy
def test_Lazy_map():
    from operator import add

    assert Lazy(lambda x: x + 1).map(add(1)).get(1) == 3  # Lazy with lambda -> 2 map -> add 1 -> get -> 3
    assert Lazy(lambda x: x + 1).map(add(1)).get(1) == 3  # Lazy with lambda -> 2 map -> add 1 -> get -> 3


# Generated at 2022-06-24 00:15:11.237927
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    import pymonet.validation as V

    assert Lazy.of(10).to_validation() == V.Validation.success(10)

# Generated at 2022-06-24 00:15:17.879200
# Unit test for method map of class Lazy
def test_Lazy_map():
    def id(x):
        return x

    def f(x):
        return x * 2

    def g(x):
        return x + 10

    assert Lazy(id).map(f).map(g).get(2) == 14
    assert Lazy(id).map(f).get(2) == 4


# Generated at 2022-06-24 00:15:19.742887
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(2).map(lambda x: x + 1).get() == 3


# Generated at 2022-06-24 00:15:25.573756
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    # given
    def some_function(a, b):
        return a + b

    lazy = Lazy(some_function)

    # when
    result = str(lazy)

    # then
    assert result == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(some_function, lazy.get(), lazy.is_evaluated)



# Generated at 2022-06-24 00:15:35.437791
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.maybe import Just, Nothing

    assert Just(2).fold(lambda value: value) == 2

    assert Just(2).size() == 1

    assert Just(2) == Just(2)
    assert Just(1) != Just(2)
    assert Just(1) != Nothing()

    assert str(Just(2)) == 'Just[value=2]'

    assert Just(1).map(lambda value: value + 1) == Just(2)
    assert Just(2).map(lambda value: value / 2) == Just(1)
    assert Just(2).map(lambda value: value * 2) == Just(4)
    assert Just(2).map(lambda value: value - 1) == Just(1)

    assert Just(1).ap(Just(lambda value: value + 1)) == Just(2)

# Generated at 2022-06-24 00:15:37.474985
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    assert Either.of(4).to_lazy().to_either() == Either.of(4)

# Generated at 2022-06-24 00:15:43.010544
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def add_two(x):
        return x + 1

    assert add_two(2) == 3
    assert Lazy(lambda x: add_two(x)).to_box(2).get_value() == 3
    assert Lazy.of(2).to_box(2).get_value() == 2

# Generated at 2022-06-24 00:15:45.832035
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)
    assert Lazy(lambda *args: 1).to_box() == Box(1)


# Generated at 2022-06-24 00:15:50.689256
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_five(x):
        return x + 5


    def greatest_common_divisor(x, y):
        if x % y == 0:
            return y
        else:
            return greatest_common_divisor(y, x % y)


    lazy_gcd = Lazy(lambda: greatest_common_divisor(1000, 100))
    assert type(lazy_gcd.map(add_five)) == Lazy
    assert type(lazy_gcd.map(add_five).get()) == int
    assert lazy_gcd.map(add_five).get() == 105


# Generated at 2022-06-24 00:15:55.496411
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert Lazy.of('some_value').__str__() == "Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f66d4b4c7b8>, value=None, is_evaluated=False]"



# Generated at 2022-06-24 00:15:58.368143
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_value = Lazy.of(lambda x: x + 2)
    lazy_fn = Lazy.of(lambda f: f(2))

    assert lazy_fn.ap(lazy_value).get() == 4

# Generated at 2022-06-24 00:16:02.205034
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x * 2)) == 'Lazy[fn=<function Lazy.<lambda>>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:16:08.405727
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 'test').get() == 'test'
    assert Lazy(lambda: 2).get() == 2
    assert Lazy(lambda: None).get() == None
    assert Lazy(lambda: [1, 2, 3]).get() == [1, 2, 3]
    assert Lazy(lambda: {'a': 1, 'b': 2, 'c': 3}).get() == {'a': 1, 'b': 2, 'c': 3}



# Generated at 2022-06-24 00:16:10.638280
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    result = Lazy.of(1).to_maybe()
    expected = Maybe.just(1)

    assert result == expected


# Generated at 2022-06-24 00:16:18.872417
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(5).to_box() == Box(5)
    assert Lazy.of(5).map(lambda x: x + 5).to_box() == Box(10)
    assert Lazy.of(5).bind(lambda x: Lazy.of(x + 5)).to_box() == Box(10)
    assert Lazy.of(Box(5)).to_box() == Box(5)
    assert Lazy.of(Box(5)).map(lambda x: x + 5).to_box() == Box(10)
    assert Lazy.of(Box(5)).bind(lambda x: Lazy.of(x + 5)).to_box() == Box(10)



# Generated at 2022-06-24 00:16:21.268856
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    def func():
        return 1

    lazy = Lazy(func)

    assert lazy.to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:16:28.104180
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given
    def add_2(number: int) -> int:
        return number + 2

    lazy = Lazy(add_2)

    # When
    result = lazy.map(lambda number: number * 2)

    # Then
    assert result.get(10) == 24



# Generated at 2022-06-24 00:16:37.458340
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    f1 = lambda *args: 'x'
    f2 = lambda *args: 'x'
    g1 = lambda *args: 'y'
    g2 = lambda *args: 'y'

    assert Lazy(f1) == Lazy(f1)
    assert Lazy(f1) != Lazy(f2)
    assert Lazy(f1).map(g1) == Lazy(f1).map(g1)
    assert Lazy(f1).map(g1) == Lazy(f1).map(g2)
    assert Lazy(f1).map(g1) != Lazy(f2).map(g1)
    assert Lazy(f1).map(g1) != Lazy(f1)
    assert Lazy(f1).map(g1)

# Generated at 2022-06-24 00:16:44.537745
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(lambda: 1).to_either() == Right(1)
    assert Lazy.of(lambda: 0 / 0).to_either() == Left(ZeroDivisionError('float division by zero'))



# Generated at 2022-06-24 00:16:47.560202
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x110e0dd08>, value=None, ' +\
        'is_evaluated=False]', 'str method of Lazy is not work properly'



# Generated at 2022-06-24 00:16:52.614219
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_fn():
        return 'value'
    lazy_fn_1 = Lazy(test_fn)
    lazy_fn_2 = Lazy(test_fn)

    assert lazy_fn_1 == lazy_fn_2


# Generated at 2022-06-24 00:17:01.557380
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def to_try_test_return_success_when_no_exception():
        def function_with_exception():
            raise Exception('No error')

        lazy = Lazy(function_with_exception).to_try()
        assert isinstance(lazy, Try)
        assert lazy.is_success()

        return lazy

    def to_try_test_return_fail_when_exception():
        def function_with_exception():
            raise Exception('Error')

        lazy = Lazy(function_with_exception).to_try()
        assert isinstance(lazy, Try)
        assert lazy.is_fail()

        return lazy

    to_try_test_return_success_when_no_exception()
    to_