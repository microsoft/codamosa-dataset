

# Generated at 2022-06-24 00:06:51.605369
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)



# Generated at 2022-06-24 00:06:54.149394
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():

    @Lazy
    def two():
        return 2

    assert two.to_either() == Right(2)



# Generated at 2022-06-24 00:07:00.172935
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    """
    Test for method to_box of class Lazy
    """
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    result = Lazy(lambda: 5).to_box()

    assert isinstance(result, Box)
    assert result.get_or_else(Maybe.nothing()) == 5


# Generated at 2022-06-24 00:07:05.145916
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function <lambda> at 0x7fbefd2f8c80>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:07:14.822906
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure

    assert Lazy.of(4).to_try() == Success(4)
    assert Lazy.of(4).to_try(1, 2, 3) == Success(4)
    assert Lazy.of(lambda: 3 / 0).to_try() == Failure(ZeroDivisionError)
    assert Lazy(lambda: 3 / 0).to_try() == Failure(ZeroDivisionError)
    assert Lazy.of(lambda x: x + 4).to_try(4) == Success(8)
    assert Lazy.of((lambda: 6 / 0)).to_try() == Failure(ZeroDivisionError)

# Generated at 2022-06-24 00:07:21.754196
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.maybe import Maybe

    # Pycharm usually has difficulties with type inference in this case
    def fn(x: int) -> Lazy[int, Maybe[int]]:
        return Lazy.of(Maybe.just(x))

    # @typecheck false
    assert Lazy(lambda: 1).bind(fn).get(1) == Maybe.just(1)

    # @typecheck false
    assert Lazy(lambda: 2).bind(fn).get(2) == Maybe.just(2)

# Generated at 2022-06-24 00:07:24.415638
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return "Lazy"

    lazy = Lazy(fn)
    result = lazy.get()
    assert result == "Lazy"



# Generated at 2022-06-24 00:07:36.790638
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    def get_value1() -> int:
        return 1

    def get_value2() -> int:
        return 2

    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<function test_Lazy.<locals>.<lambda> at 0x7f624af19d90>, value=None, is_evaluated=False]'

    assert Lazy(get_value1) == Lazy(get_value1)

    assert Lazy.of(1) == Lazy(lambda: 1)

    assert Lazy(get_value1).map(lambda x: x + 1).get()

# Generated at 2022-06-24 00:07:47.375606
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 100).to_maybe() == Maybe.just(100)
    assert Lazy(lambda: None).to_maybe() == Maybe.nothing()
    assert Lazy(lambda: "foo").to_maybe() == Maybe.just("foo")
    assert Lazy(lambda: 0).to_maybe() == Maybe.just(0)
    assert Lazy(lambda: []).to_maybe() == Maybe.nothing()
    assert Lazy(lambda: [1]).to_maybe() == Maybe.just([1])
    assert Lazy(lambda: [1, 2, 3]).to_maybe() == Maybe.just([1, 2, 3])

# Generated at 2022-06-24 00:07:51.015882
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def test_function():
        return Maybe.just(1)

    assert Lazy(test_function).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:07:55.052595
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    assert Lazy(lambda a: a + 1).to_try(1) == Try.of(lambda a: a + 1, 1)

    assert Lazy(lambda a: a + 1).to_try('a') == Try.of(lambda a: a + 1, 'a')



# Generated at 2022-06-24 00:07:59.185242
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try

    def function(a):
        return Lazy.of(lambda x: x * 2).bind(lambda x: Lazy.of(x * a))

    assert Lazy.of(2.0) \
        .ap(Lazy.of(function)) \
        .to_try() == Try.of(lambda: 4.0)

# Generated at 2022-06-24 00:08:05.804023
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    assert Lazy.of(1).to_try() == Try.of(lambda arg: arg, 1)
    assert Lazy.of(None).to_try('argument') == Try.of(lambda arg: arg, 'argument')
    assert Lazy.of(Exception('error message')).to_try() == Try.of(lambda arg: arg, Exception('error message'))


# Generated at 2022-06-24 00:08:08.958610
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x) == Lazy(lambda x: x)
    assert Lazy(lambda x: x) != Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x) != None

# Generated at 2022-06-24 00:08:17.756701
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    closure1 = lambda x: x * 2
    closure2 = lambda x: x * 3

    lazy1 = Lazy(lambda x: x * 2)
    lazy1_copy = Lazy(lambda x: x * 2)
    lazy1_equal = Lazy(lambda x: x * 2)
    lazy2 = Lazy(lambda x: x * 3)

    assert lazy1 == lazy1
    assert lazy1 == lazy1_copy
    assert lazy1 == lazy1_equal
    assert lazy1 != lazy2
    assert lazy1 != closure1
    assert lazy2 != closure2

# Generated at 2022-06-24 00:08:25.420489
# Unit test for constructor of class Lazy
def test_Lazy():
    # Given
    value = 2
    lazy = Lazy.of(value)

    # When
    result = lazy.get()

    # Then
    assert value == result
    assert lazy.constructor_fn is not None
    assert lazy.is_evaluated is True
    assert lazy.value is not None

    # Given
    value = 'some string'
    lazy = Lazy(lambda: value)

    # When
    result = lazy.get()

    # Then
    assert value == result
    assert lazy.constructor_fn is not None
    assert lazy.is_evaluated is True
    assert lazy.value is not None



# Generated at 2022-06-24 00:08:29.066860
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 10) == Lazy(lambda: 20)
    assert Lazy(lambda: 10).get() == Lazy(lambda: 10).get()
    assert Lazy(lambda: 10).get() != Lazy(lambda: 20).get()


# Generated at 2022-06-24 00:08:33.042202
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def fn(): pass

    assert str(Lazy(fn)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x7f5bbd2abb90>, value=None, is_evaluated=False]'  # noqa



# Generated at 2022-06-24 00:08:40.067380
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def demo(a):
        return a + 5

    assert Lazy(demo).to_maybe(5).to_box() == Maybe.just(10)

    assert Lazy(demo).map(lambda x: x + 5).to_maybe(5).to_box() == Maybe.just(15)

    assert Lazy(lambda x: x + 5).to_maybe(None).to_box() == Maybe.nothing()



# Generated at 2022-06-24 00:08:47.609236
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.function import identity
    from pymonet import Lazy
    lazy = Lazy.of(3)

    assert str(lazy) == 'Lazy[fn=<function <lambda> at 0x7f03b70c4950>, value=None, is_evaluated=False]'

    lazy.bind(identity)

    assert str(lazy) == 'Lazy[fn=<function <lambda> at 0x7f03b70c4950>, value=3, is_evaluated=True]'


# Generated at 2022-06-24 00:08:50.281009
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    """
    Property based test for method __str__ of class Lazy.
    """
    from hypothesis import given
    from hypothesis.strategies import just, f

# Generated at 2022-06-24 00:08:55.423878
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy(lambda x: x).to_maybe('val') == Maybe.just('val')
    assert Lazy(lambda: None).to_maybe() == Maybe.just(None)
    assert Lazy(lambda: '').to_maybe() == Maybe.just('')


# Generated at 2022-06-24 00:09:02.890270
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.monad_try import MonadTry
    from pymonet.traversable import Traversable
    from pymonet.type_class import TypeClass, Size

    def is_monad(obj):
        return isinstance(obj, Monad) and all(isinstance(obj, type) for type in Monad.__mro__)

    def is_functor(obj):
        return isinstance(obj, Functor) and all(isinstance(obj, type) for type in Functor.__mro__)

    def is_monad_try(obj):
        return isinstance(obj, MonadTry) and all(isinstance(obj, type) for type in MonadTry.__mro__)

   

# Generated at 2022-06-24 00:09:12.664534
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.monad_exception import raise_NumberTooSmallException
    import pymonet.monad_exception as monad_exception

    value = 5
    monad_exception.OK_MINIMUM = 10
    assert Right(value) == Lazy.of(value).to_either()

    value = 15
    monad_exception.OK_MINIMUM = 10
    assert Right(value) == Lazy.of(value).to_either()

    value = 5
    monad_exception.OK_MINIMUM = 10
    assert Right(value).to_either() != Lazy.of(value).to_either()

    monad_exception.OK_MINIMUM = 10

# Generated at 2022-06-24 00:09:17.879305
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(5) == Lazy.of(5)
    assert Lazy.of(5) != Lazy.of(10)
    assert Lazy.of(5) != Lazy.of(lambda: 5)



# Generated at 2022-06-24 00:09:24.790895
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def succ(x):
        return x + 1

    def double(x):
        return x * 2

    lazy_double = Lazy(lambda arg: arg * 2)
    lazy_succ = Lazy(lambda arg: arg + 1)
    assert lazy_succ.ap(lazy_double).get(10) == succ(double(10))

    lazy_succ = Lazy(lambda arg: arg + 1)
    assert lazy_succ.ap(Lazy.of(10)).get() == succ(10)



# Generated at 2022-06-24 00:09:27.836654
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    lazy = Lazy.of(Box(1))
    def to_string(box):
        return box.map(lambda v: str(v))

    assert lazy.ap(to_string) == Lazy.of(Box("1"))



# Generated at 2022-06-24 00:09:29.856969
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Lazy.of(1).to_maybe()


# Generated at 2022-06-24 00:09:38.769174
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover

    def fn(x):
        return 3

    assert str(Lazy(fn)) == 'Lazy[fn=<function test_Lazy.<locals>.fn at 0x7f3f3d4a4e18>, value=None, is_evaluated=False]'
    assert str(Lazy(fn).map(lambda x: x + 1)) == 'Lazy[fn=<function test_Lazy.<locals>.<lambda> at 0x7f3f3d4a4ea0>, value=None, is_evaluated=False]'
    assert str(Lazy.of(1)) == 'Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x7f3f3d4a4f28>, value=None, is_evaluated=False]'
    assert Lazy

# Generated at 2022-06-24 00:09:43.379405
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    # pylint: disable=C0103
    from pymonet.maybe import Maybe

    def fn():
        return 'c,d'

    lazy = Lazy(fn)
    lazy_result = lazy.to_maybe()

    assert isinstance(lazy_result, Maybe)
    assert lazy_result.is_just()
    assert lazy_result.get() == 'c,d'

# Generated at 2022-06-24 00:09:46.028213
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy(lambda: 1).to_box() == Box(1)



# Generated at 2022-06-24 00:09:51.658068
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    t = Validation.success(1)
    assert Lazy.of(1).to_validation() == t
    assert Lazy.of(1).to_validation(2) == t


# Generated at 2022-06-24 00:09:57.501074
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    lazy_result = Lazy.of(3)
    assert lazy_result.to_either() == Right(3)
    assert Lazy.of(7).to_either() == Right(7)
    assert Lazy.of(3).map(lambda x: x + 5).to_either() == Right(8)
    assert Lazy.of(Lazy.of(6)).ap(Lazy.of(lambda x: x + 3)).to_either() == Right(9)


# Generated at 2022-06-24 00:10:03.097428
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation

    def add1(n):
        def add(x):
            return n + x

        return Lazy(add)

    n = Lazy(lambda: 10)
    result = n.ap(add1(2))
    assert result == 12
    assert result.to_validation().get() == Validation.success(12)

# Generated at 2022-06-24 00:10:12.959892
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Lazy.of(5).bind(
        lambda arg1: Lazy.of(arg1 + 1)
    ).bind(
        lambda arg2: Lazy.of(arg2 * 2)
    ) == Lazy.of(12)

    assert Lazy.of([1, 2, 3]).bind(
        lambda list_: Lazy.of([Box(value) for value in list_])
    ).bind(
        lambda list_: Lazy.of([Maybe.just(value.get()) for value in list_])
    ) == Lazy.of([Maybe.just(1), Maybe.just(2), Maybe.just(3)])


# Generated at 2022-06-24 00:10:16.053014
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = Lazy(lambda x: x)
    f2 = Lazy(lambda x: x)
    f3 = Lazy(lambda x: x + 1)

    assert f == f2
    assert f != f3

# Generated at 2022-06-24 00:10:17.255921
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    lazy = Lazy(lambda x: x).to_maybe(1)
    assert isinstance(lazy, Maybe)
    assert lazy.value == 1

# Generated at 2022-06-24 00:10:24.798630
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    # arrange
    lazy = Lazy.of(1)

    # act
    maybe = lazy.to_maybe()

    # assert
    assert maybe.is_just()
    assert maybe.get() == 1


# Generated at 2022-06-24 00:10:27.808022
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    fn = lambda x: x + 5
    lazy = Lazy(fn)

    actual = lazy.to_validation('abc')

    assert isinstance(actual, Validation)
    assert actual.is_success()
    assert actual.value == fn('abc')



# Generated at 2022-06-24 00:10:32.053130
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right

    def return_value(value):
        return value

    my_lazy = Lazy(return_value)

    assert my_lazy.to_either("test") == Right("test")
    assert my_lazy.to_either(0) == Right(0)
    assert my_lazy.to_either(1) == Right(1)

# Generated at 2022-06-24 00:10:38.296982
# Unit test for constructor of class Lazy
def test_Lazy():
    def func(x):
        return x

    x = Lazy(func)

    assert isinstance(x, Lazy)

    assert not x.is_evaluated
    assert x.constructor_fn == func
    assert x.value is None



# Generated at 2022-06-24 00:10:41.857923
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.monad_try import Try

    def fn1():
        raise ValueError("O_o")

    lazy = Lazy(fn1).to_try()
    assert lazy.get() == Try.failure(ValueError("O_o"))

# Generated at 2022-06-24 00:10:52.314657
# Unit test for method bind of class Lazy

# Generated at 2022-06-24 00:11:00.261968
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    """
    Validate maybe result of Lazy
    """
    assert Maybe.just(1) == Lazy.of(1).to_maybe()
    assert Maybe.nothing() == Lazy.of(None).to_maybe()
    assert Maybe.just(1) == Lazy.of(1).to_maybe()
    assert Maybe.just(1) == Lazy.of(1).map(lambda value: value).to_maybe()



# Generated at 2022-06-24 00:11:03.387622
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    assert Maybe.nothing() == Lazy.of(None).to_maybe()
    assert Maybe.just(1) == Lazy.of(1).to_maybe()



# Generated at 2022-06-24 00:11:09.647172
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy(lambda: 1).to_maybe() == Maybe.just(1)
    assert Lazy(lambda: 2).to_maybe() == Maybe.just(2)
    assert Lazy(lambda: None).to_maybe() == Maybe.just(None)
    assert Lazy(lambda: 0).to_maybe() == Maybe.just(0)


# Generated at 2022-06-24 00:11:15.281254
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def divide(x, y):
        return x / y

    assert Lazy(lambda: divide('1', '1')).to_validation() == Validation.success('1')
    assert Lazy(lambda: divide(1, 0)).to_validation() == Validation(False, ['division by zero'])

# Generated at 2022-06-24 00:11:22.071203
# Unit test for method to_try of class Lazy
def test_Lazy_to_try(): # pragma: no cover

    lazy_with_success = Lazy(lambda: "some_value")
    assert lazy_with_success.to_try() == Try.of(lambda: "some_value")

    lazy_with_error = Lazy(lambda: 1 / 0)
    assert lazy_with_error.to_try() == Try.of(lambda: 1 / 0)



# Generated at 2022-06-24 00:11:33.343520
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy(lambda x: x).to_box() == Box(None)
    assert Lazy(lambda x: x + 1).to_box(1) == Box(2)
    assert Lazy(lambda x: x * 2).to_box(10) == Box(20)
    assert Lazy(lambda: 'a').to_box() == Box('a')
    assert Lazy(lambda x: x.upper()).to_box('a') == Box('A')
    assert Lazy(lambda x, y: x + y).to_box(1, 2) == Box(3)
    assert Lazy(lambda x, y, z: x * y * z).to_box(1, 2, 3) == Box(6)

# Generated at 2022-06-24 00:11:36.331823
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Maybe.just(27) == Lazy.of(27).to_maybe()
    assert Maybe.nothing() == Lazy(lambda: 27 / 0).to_maybe()



# Generated at 2022-06-24 00:11:41.784475
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def get_string(string: str) -> Maybe[str]:
        if string is None:
            return Maybe.empty()
        return Maybe.just(string)

    assert Lazy(lambda: get_string('abc')).to_maybe() == Maybe.just('abc')



# Generated at 2022-06-24 00:11:48.154847
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def compute_something_value():
        pass  # pragma: no cover

    assert Lazy(compute_something_value).to_maybe().is_nothing()
    assert Lazy(lambda: 123).to_maybe() == Maybe.just(123)
    assert Lazy(lambda: '123').to_maybe() == Maybe.just('123')
    assert Lazy(lambda: 0).to_maybe() == Maybe.just(0)
    assert Lazy(lambda: False).to_maybe() == Maybe.just(False)
    assert Lazy(lambda: True).to_maybe() == Maybe.just(True)



# Generated at 2022-06-24 00:11:58.307026
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Test for Lazy.to_try method
    """
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def raising_fn(res):
        raise ValueError('Error')
        return res

    def not_raising_fn(res):
        return res

    lazy_empty = Lazy(raising_fn)
    lazy_not_empty = Lazy(not_raising_fn)

    def are_equals(left, right):
        assert isinstance(left, Try) and isinstance(right, Try)
        return left.is_success == right.is_success and left.value == right.value

    assert are_equals(lazy_empty.to_try(), Try.failure(ValueError('Error')))

# Generated at 2022-06-24 00:12:03.174912
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add1(a):
        return add(a, 1)

    def add_validation(a):
        return Validation.success(a).map(add1)

    lazy_result = Lazy.of(1).bind(add_validation)

    assert lazy_result.get() == Validation.success(2)



# Generated at 2022-06-24 00:12:07.829132
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(4).__eq__(Lazy.of(4))
    assert not Lazy.of(4).__eq__(Lazy.of(6))
    assert not Lazy.of(4).__eq__(5)
    assert not Lazy.of(4).__eq__(4)
    assert not Lazy.of(4).__eq__(None)



# Generated at 2022-06-24 00:12:17.952375
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of(1).to_maybe() == Lazy.of(1).to_box()
    assert Lazy.of(2).to_maybe() == Lazy.of(2).to_either()
    assert Lazy.of(3).to_maybe() == Lazy.of(3).to_try()
    assert Lazy.of(4).to_maybe() == Lazy.of(4).to_validation()
    assert Lazy.of(5).to_maybe() == Lazy.of(5).to_maybe()

    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy.of(2).to_maybe() == Maybe.just(2)
    assert Lazy.of(3).to_maybe() == Maybe.just(3)

# Generated at 2022-06-24 00:12:27.363415
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    fn = lambda x: 6 * 7 * x

    lazy_1 = Lazy.of(fn)
    lazy_2 = Lazy.of(fn)
    lazy_3 = Lazy.of(lambda x: 6 * 7 * x + 1)

    assert lazy_1 == lazy_2
    assert lazy_1 != lazy_3
    assert lazy_1 != None

    lazy_1._compute_value(4)
    lazy_2._compute_value(4)

    assert lazy_1 == lazy_2



# Generated at 2022-06-24 00:12:32.373282
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    lazy = Lazy(lambda: 1)
    assert str(lazy) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7ffb6072f620>, value=None, is_evaluated=False]'

# Generated at 2022-06-24 00:12:37.982596
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x + 2)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x7f27a677c0f0>, value=None, is_evaluated=False]'
    assert str(Lazy.of(1)) == 'Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x7f27a677c158>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:12:41.100594
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from ..identity import Identity

    fn = lambda a, b, c: a * b * c
    lazy = Lazy(lambda a, b, c: fn(a, b, c))
    lazy_2 = Lazy(Identity(fn))
    value_a, value_b, value_c = 1, 2, 3

    assert lazy.to_validation(value_a, value_b, value_c) == Validation.success(6)
    assert lazy_2.to_validation(value_a, value_b, value_c) == Validation.success(6)

# Generated at 2022-06-24 00:12:48.566942
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def f():
        return 1

    def g():
        return 2

    assert str(Lazy(f)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.f at 0x104727488>, value=None, is_evaluated=False]'
    assert str(Lazy(g)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.g at 0x104727a60>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:12:54.594778
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def to_list(x):
        if x == 0:
            return Lazy.of([])
        return Lazy.of([x])

    assert Lazy(lambda x: [x]).bind(to_list).get(0) == []
    assert Lazy(lambda x: [x]).bind(to_list).get(1) == [1]



# Generated at 2022-06-24 00:12:59.167549
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    maybe = Lazy.of(2).to_maybe()

    assert maybe == Maybe.just(2)
    assert maybe.get() == 2
    assert maybe.is_just() is True


# Generated at 2022-06-24 00:13:11.317228
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def just(value) -> Lazy[int, int]:
        return Lazy.of(value)

    def inc(value):
        return value + 1

    def add(left, right):
        return left + right

    assert just(1).ap(inc) == just(2)
    assert just(1).ap(just(1)) == just(1)
    assert just(1).ap(just(add)).ap(just(2)).ap(just(3)) == just(6)

    # Apply to box
    assert just(1).ap(Box(inc)) == Box(2)
    assert just

# Generated at 2022-06-24 00:13:15.705317
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def constructor(*args):
        value = args[0]
        return Lazy.of(value)

    def mapper(value):
        return Box(value)

    assert Lazy(constructor).bind(mapper).constructor_fn(1) == Box(1)



# Generated at 2022-06-24 00:13:26.694307
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 2)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 3)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 1.0)
    assert Lazy(lambda x: x + 1) != Lazy(lambda y: y + 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda y, z: y + z + 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda y, z: y + z)
   

# Generated at 2022-06-24 00:13:37.193733
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def fn_a(_):
        return 'a'

    fn_b = lambda: 'b'

    assert Lazy(fn_a) == Lazy(fn_a)
    assert Lazy(fn_a) != Lazy(fn_b)
    assert Lazy(fn_a) != Right('')  # type: ignore
    assert Lazy(fn_a) != Box('')  # type: ignore
    assert Lazy(fn_a) != Maybe('')  # type: ignore
    assert Lazy(fn_a) != fn_a
    assert Lazy(fn_a) != None


# Generated at 2022-06-24 00:13:42.281522
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.maybe import Maybe

    def f(i):
        raise ValueError()

    def g(i):
        return i

    assert Maybe.none() == Lazy(f).to_maybe()
    assert Maybe.just(4) == Lazy(g).to_maybe(4)

# Generated at 2022-06-24 00:13:52.361841
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.monad_maybe import Maybe
    from pymonet.either import Right

    def either_value(value: int) -> Right[int]:
        return Right(value)

    def maybe_value(value: int) -> Maybe[int]:
        return Maybe.just(value)

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(1).map(either_value).to_either() == Right(Right(1))
    assert Lazy.of(1).bind(lambda _: Lazy.of(Right(1))).to_either() == Right(Right(1))
    assert Lazy.of(1).map(maybe_value).to_either() == Right(Right(1))

# Generated at 2022-06-24 00:13:59.278173
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    def func():
        raise Exception('test_Lazy_to_either')

    lazy = Lazy(func)
    either = lazy.to_either()

    assert isinstance(either, Right)
    assert isinstance(either.get_left(), Exception)
    assert either.get_left().args == ('test_Lazy_to_either',)


# Generated at 2022-06-24 00:14:01.176946
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    assert Lazy(lambda: 1).to_either() == Right(1)

# Generated at 2022-06-24 00:14:03.214290
# Unit test for method map of class Lazy
def test_Lazy_map():
    mul = lambda x, y: x * y
    add = lambda x, y: x + y

    lazy_fn = Lazy(add).map(mul)
    assert lazy_fn._compute_value(10, 2) == 20


# Generated at 2022-06-24 00:14:06.232711
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy_zero = Lazy(lambda: 0)
    assert lazy_zero.get() == 0

    lazy_1000 = Lazy(lambda: 1000)
    assert lazy_1000.get() == 1000

    lazy_5 = Lazy(lambda: 5)
    assert lazy_5.get() == 5

    lazy_11 = Lazy(lambda: 5 + 6)
    assert lazy_11.get() == 11



# Generated at 2022-06-24 00:14:17.107333
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    :returns: Nothing
    :rtype: None
    """
    # pylint: disable-msg=W0612
    lazy = Lazy(lambda x: 2 * x)
    lazy2 = Lazy(lambda x: x > 5)
    res = lazy.ap(lazy2)
    assert res.get(3) == False
    assert res.get(6) == True
    lazy = Lazy(lambda x: 2 * x)
    lazy2 = Lazy(lambda x: [x] * x)
    res = lazy.ap(lazy2)
    assert res.get(6) == [6, 6, 6, 6, 6, 6]
    # pylint: enable-msg=W0612


# Generated at 2022-06-24 00:14:28.066582
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(first: int, second: int) -> int:
        return first + second

    first, second = 1, 2

    assert Lazy.of(add).ap(Lazy.of(first)).ap(Lazy.of(second)).get() == 4, 'Lazy.ap(Lazy) should return correct value'
    assert Lazy.of(add).ap(Lazy.of(first)).ap(Lazy.of(second)).is_evaluated == True, 'Lazy.ap(Lazy) should be evaluated'
    assert Lazy.of(add).ap(Lazy.of(first)).ap(Lazy.of(second)) != Lazy.of(add), 'Lazy.ap(Lazy) should not be equal'


# Generated at 2022-06-24 00:14:32.276225
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    @Lazy
    def test(i):
        print("Test:")
        return i*2

    assert test.get(2) == 4
    assert test.get(3) == 6
    assert test.get(4) == 8
    assert test.get(5) == 10



# Generated at 2022-06-24 00:14:34.125398
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Box(10) == Lazy(lambda: 10).to_box()


# Generated at 2022-06-24 00:14:37.274953
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def dummy_fn(value):
        return value

    assert Lazy(dummy_fn).to_maybe(1) == Maybe.just(1)
    assert type(Lazy(dummy_fn).to_maybe(1)) == Maybe



# Generated at 2022-06-24 00:14:42.282818
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def mapper(x):
        return Lazy(lambda: x + 1)

    def folder(x):
        return x + 1

    l = Lazy(lambda: 1).bind(mapper).bind(folder)
    assert l.get() == 3



# Generated at 2022-06-24 00:14:51.545458
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of('1') == Lazy.of('1')
    assert Lazy.of(None) == Lazy.of(None)
    assert Lazy.of(1) != Lazy.of('1')

    assert Lazy(lambda x: x) == Lazy(lambda x: x)
    assert Lazy(lambda x: x) != Lazy(lambda x: 'A')
    assert Lazy(lambda x: x) != Lazy(lambda x: 1)
    assert Lazy(lambda x: x) != Lazy(lambda: x)

    # some examples to ensure that equality is not evaluated https://github.com/slamdata/purescript-lazy/blob/master/test/Test/Lazy.purs#L16
   

# Generated at 2022-06-24 00:14:52.986363
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(1).to_box() == 1


# Generated at 2022-06-24 00:15:03.073001
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def function(x):
        return x + 1

    lazy_maybe = Lazy(lambda x: Maybe.just(function(x)))
    assert lazy_maybe.get(1).get() == 2

    lazy_try = Lazy(lambda x: Try.of(function, x))
    assert lazy_try.get(2).get() == 3

    lazy_either = Lazy(lambda x: Either.right(function(x)))
    assert lazy_either.get(3).get() == 4

    lazy_box = Lazy(lambda x: Box(function(x)))
    assert lazy_box.get(4).get() == 5

    lazy_validation = Lazy(lambda x: Validation.success(function(x)))
    assert lazy_validation.get(5).get() == 6


# Generated at 2022-06-24 00:15:11.939946
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def double(x):
        return x * 2

    def triple(x):
        return x * 3

    lazy_fn = Lazy(lambda: 5)
    assert lazy_fn.get() == 5

    assert lazy_fn.map(double).get() == 10
    assert lazy_fn.map(double).map(triple).get() == 30

    assert lazy_fn.to_box().map(triple).get() == 15
    assert lazy_fn.to_box().map(triple).map(double).get() == 30

    assert lazy_fn.to_either().map(triple).get() == 15
    assert lazy_fn.to_either().map(triple).map(double).get() == 30

    assert lazy_fn.to_maybe().map(triple).get() == 15

# Generated at 2022-06-24 00:15:20.413311
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.utils import identity

    lazy = Lazy(identity)
    assert str(lazy) == 'Lazy[fn=<function identity at 0x7f41a8293c80>, value=None, is_evaluated=False]'

    lazy._compute_value('test')
    assert str(lazy) == 'Lazy[fn=<function identity at 0x7f41a8293c80>, value="test", is_evaluated=True]'



# Generated at 2022-06-24 00:15:22.371862
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(1).to_either() == Right(1)



# Generated at 2022-06-24 00:15:26.057195
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    def test_fn(value):
        return Lazy(lambda *args: value)

    assert test_fn(5).to_box().unbox() == 5


# Generated at 2022-06-24 00:15:32.444582
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Failure
    from pymonet.monad_try import Success

    def throwing_constructor_fn():
        raise ValueError("Throwing value error")

    assert Lazy.of(42).to_try() == Success(42)  # type: ignore
    assert Lazy(throwing_constructor_fn).to_try() == Failure(ValueError("Throwing value error"))  # type: ignore



# Generated at 2022-06-24 00:15:37.522524
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    """
    :rtype: None
    """
    def create_lazy(value):
        return lambda: value

    assert Lazy(create_lazy(True)).to_validation() == Validation.success(True)
    assert Lazy(create_lazy(False)).to_validation() == Validation.success(False)
    assert Lazy(create_lazy({'a': 'b'})).to_validation() == Validation.success({'a': 'b'})
    assert Lazy(create_lazy(10)).to_validation() == Validation.success(10)


# Generated at 2022-06-24 00:15:48.083441
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.functors import lift_maybe
    from pymonet.maybe import Maybe
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) == Lazy(lambda x: 1).to_maybe()
    assert Maybe.just(100) == Lazy(lambda x: x).map(lambda x: x + 1).to_maybe(99)

    def positive_number(number):
        return Maybe.just(number) if number >= 0 else Maybe.nothing()

    assert Maybe.nothing() == Lazy(lambda x: x).map(lift_maybe(positive_number)).to_maybe(-1)
    assert Maybe.nothing() == Lazy(lambda x: x).bind

# Generated at 2022-06-24 00:15:58.183316
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right

    assert Lazy.of(1).to_either(None) == Right(1)
    assert Lazy.of('ABC').to_either(None) == Right('ABC')

    def test_function(*args):
        return 'ABC'

    assert Lazy(test_function).to_either(None) == Right('ABC')
    assert Lazy.of(1).to_either(None, 1) == Right(1)

    def test_function_raise(*args):
        raise IOError("Test")

    assert Lazy(test_function_raise).to_either(None, 1) == Left(1)



# Generated at 2022-06-24 00:16:04.592691
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Lazy.of(7).ap(Box(lambda x: x + 2)) == Lazy.of(9)
    assert Lazy.of(3).ap(Box(lambda x, y: x - 1 if y > 2 else x)) == Lazy.of(2)



# Generated at 2022-06-24 00:16:06.362910
# Unit test for method get of class Lazy
def test_Lazy_get():
    # given
    test_result = 42
    lazy = Lazy.of(test_result)

    # when
    result = lazy.get()

    # then
    assert test_result == result



# Generated at 2022-06-24 00:16:16.203022
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.validation import Validation
    from pymonet.either import Right

    def function(argument: int) -> Lazy[int, str]:
        return Lazy(lambda: str(argument) + '_string')

    lazy_value: Lazy[int, int] = Lazy(lambda: 2)

    assert lazy_value.bind(function).get() == '2_string'

    # Test partial application
    func_lazy = partial(Lazy, lambda: 'success')
    value = lazy_value.bind(func_lazy)
    assert value.get() == 'success'

    @curried
    def function_either(argument: int) -> Lazy[int, Either[str, int]]:
        return Lazy(lambda: Right(argument))

    assert lazy_value.bind(function_either).get

# Generated at 2022-06-24 00:16:23.131128
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.either import Right

    # Check is Lazy work as placeholder for function with argument
    assert Lazy(lambda arg: arg) == Lazy(lambda arg: arg)
    assert Lazy(lambda arg: arg) != Lazy(lambda arg2: arg2)
    assert Lazy(lambda arg: arg).get(1) == 1

    # Check is Lazy work as placeholder for function with multiple arguments
    assert Lazy(lambda arg1, arg2: arg1 + arg2) == Lazy(lambda arg1, arg2: arg1 + arg2)

# Generated at 2022-06-24 00:16:27.131994
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda: 'test')) == "Lazy[fn=<function <lambda> at 0x000001EA88833A60>, value=None, is_evaluated=False]"


# Generated at 2022-06-24 00:16:36.062995
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Validation.success(42) == Lazy(lambda: 42).to_validation()
    assert Validation.success('foo') == Lazy(lambda: 'foo').to_validation()
    assert Validation.success([42, 'foo']) == Lazy(lambda: [42, 'foo']).to_validation()
    assert Validation.success(['foo', 42]) == Lazy(lambda: ['foo', 42]).to_validation()
    assert Validation.success((42, 'foo')) == Lazy(lambda: (42, 'foo')).to_validation()
    assert Validation.success(('foo', 42)) == Lazy(lambda: ('foo', 42)).to_validation()

# Generated at 2022-06-24 00:16:40.048791
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    def lazy_fn(value: str) -> str:
        return value

    assert Lazy(lazy_fn).to_box('test') == Box('test')



# Generated at 2022-06-24 00:16:45.235639
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda x: x + 5)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x7f976a2f42f0>, ' \
        'value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:16:50.819990
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    try:
        # noinspection PyTypeChecker
        Lazy(lambda: 1 / 0).to_try()
        assert False
    except ZeroDivisionError:
        assert True

    assert Lazy(lambda: 1 / 1).to_try() == Try.of_success(1)

