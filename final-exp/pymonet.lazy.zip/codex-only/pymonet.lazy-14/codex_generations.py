

# Generated at 2022-06-24 00:07:07.911509
# Unit test for method map of class Lazy
def test_Lazy_map():  # type: ignore
    """Unit test for method map of class Lazy"""
    assert Lazy(lambda *args: args).map(lambda *args: ','.join([str(arg) for arg in args])) == Lazy(lambda *args: ','.join([str(arg) for arg in args]))
    assert Lazy(lambda *args: args).map(lambda *args: ','.join([str(arg) for arg in args])).get(1, 2, 3) == '1,2,3'
    assert Lazy(lambda *args: ','.join([str(arg) for arg in args])).map(lambda *args: len(args)).get(1, 2, 3) == 3


# Generated at 2022-06-24 00:07:12.472689
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    """Test for Lazy.bind method."""
    from pymonet.box import Box

    lazy_with_10 = Lazy(lambda: 10)
    squared = lambda number: Lazy(lambda: number * number)
    squared(lazy_with_10).get() == Box(100)



# Generated at 2022-06-24 00:07:18.218105
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Setup
    lazy1 = Lazy.of(lambda x: x * 2)
    lazy2 = Lazy.of(lambda x: x / 2)
    result = Lazy.of(5)

    # Exercise
    lazy3 = lazy1.ap(lazy2)
    computed_result = lazy3.get()

    # Verify
    assert result.get() == computed_result


# Generated at 2022-06-24 00:07:28.227936
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.functor import Functor
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Functor.of(Lazy(lambda a: a).to_try(1)).fmap(lambda a: a + 2).get() == 3

    assert Try.of_error(ValueError).fmap(lambda a: a + 1) == Try.of_error(ValueError)
    assert Try.of_error(AttributeError).fmap(lambda a: a + 1) == Try.of_error(AttributeError)
    assert Try.of(1).fmap(lambda a: a + 2).get() == 3

    assert Validation.success(1).fmap(lambda a: a + 2).get() == 3

# Generated at 2022-06-24 00:07:36.310182
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    add_1 = Lazy(lambda x: x + 1)
    add_2 = Lazy(lambda x: x + 2)
    add_1_copy = Lazy(lambda x: x + 1)
    add_1_try = Try.of(add_1.constructor_fn)

    assert add_1 == add_1
    assert add_1 != add_2
    assert add_1 == add_1_copy
    assert add_1 != add_1_try



# Generated at 2022-06-24 00:07:41.589061
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy.of(1).to_try() == Try.success(1)
    assert Lazy(lambda: 1 / 0).to_try() == Try.failure(ZeroDivisionError())
    assert Lazy(lambda: None).to_try() == Try.success(None)



# Generated at 2022-06-24 00:07:49.855420
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.monad_try import Error

    assert Lazy(lambda _: 5).to_try(Box(Error('error 1'))) == Try.error(Error('error 1'))
    assert Lazy(lambda _: 5).to_try(Box(None)) == Try.of(lambda _: 5, Box(None))
    assert Lazy(lambda _: 6).to_try(Box(5)) == Try.success(6)

    assert Lazy(lambda _: 5).to_try(Box(Error('error 1'))) != Try.error(None)

# Generated at 2022-06-24 00:07:57.384243
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    @Lazy.of
    def add(x):
        return x + 1

    @Lazy.of
    def add_to_value(x):
        return lambda y: y + x

    assert add_to_value.ap(add).get(1) == 3

    @Lazy.of
    def add_to_value_and_divide(x):
        def add_and_divide(y):
            return (x + y) / 2
        return add_and_divide

    assert add_to_value_and_divide.ap(add).get(1) == 2


# Generated at 2022-06-24 00:08:03.214144
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f():
        pass

    def g():
        pass

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(g)
    assert Lazy(None).__eq__(None) is False



# Generated at 2022-06-24 00:08:07.176204
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_int = Lazy.of(2)
    lazy_multiply_two = Lazy.of(lambda x: x * 2)
    result_lazy = lazy_int.ap(lazy_multiply_two)

    assert result_lazy.get() == 4



# Generated at 2022-06-24 00:08:13.038688
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def any_to_maybe_just(value: int) -> 'Maybe[int]':
        from pymonet.maybe import Maybe

        return Maybe.just(value)

    assert Lazy.of(23).to_maybe() == any_to_maybe_just(23)
    assert Lazy.of(0).to_maybe() == any_to_maybe_just(0)
    assert Lazy.of(-13).to_maybe() == any_to_maybe_just(-13)


# Generated at 2022-06-24 00:08:17.341319
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    assert Lazy.of(10).to_either() == Right(10)
    assert Lazy(lambda: 10).to_either() == Right(10)
    assert Lazy(lambda: 10 / 0).to_either() == Left(ZeroDivisionError())
    assert Lazy(lambda: 10 + 'test').to_either() == Left(TypeError())

    def fail_function():
        raise Exception('Exception message')

    assert Lazy(fail_function).to_either() == Left(Exception('Exception message'))


# Generated at 2022-06-24 00:08:23.823072
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def add(a: int, b: int) -> int:
        return a + b

    assert Lazy.of(1).to_maybe(2, 3) == Maybe.just(1)
    assert Lazy.of(add).to_maybe(2, 3) == Maybe.just(add)
    assert Lazy.of(add)(2, 3).to_maybe() == Maybe.just(5)



# Generated at 2022-06-24 00:08:31.533376
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def raise_error():
        raise ValueError(':c')

    def divide(value):
        return 1 / value

    try_divide = Try.of(divide, 0)

    try_raise_error = Try.of(raise_error)

    assert Lazy.of(1).to_try() == Try.of(lambda: 1)
    assert Lazy.of(try_divide).to_try() == Try.of(lambda: try_divide)
    assert Lazy.of(try_raise_error).to_try() == Try.of(lambda: try_raise_error)



# Generated at 2022-06-24 00:08:35.060775
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given
    def test_fn(x):
        return x + 10
    # When
    lazy = Lazy(lambda: 5).map(test_fn)
    # Then
    assert lazy.get() == 15



# Generated at 2022-06-24 00:08:39.502653
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Lazy(lambda: 'value').to_either(None) == Right('value')
    assert Lazy(lambda: 'value').to_either() == Right('value')


# Generated at 2022-06-24 00:08:48.395900
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add2(val):
        return val + 2
    def add3(val):
        return val + 3

    assert Lazy(lambda x: x).ap(Lazy(add2)).constructor_fn(1) == 3
    assert Lazy(add2).ap(Lazy(add3)).constructor_fn(1) == 6
    assert Lazy(add2).ap(Lazy(lambda x: x)).constructor_fn(1) == 3
    assert Lazy(lambda x: x).ap(Lazy(add3)).constructor_fn(1) == 4
    assert Lazy(lambda x: x).ap(Lazy(lambda x: x)).constructor_fn(1) == 1


# Generated at 2022-06-24 00:08:51.230486
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Unit test for method get of class Lazy
    lazy = Lazy(lambda x: x + 1)
    assert lazy.get(2) == 3


# Generated at 2022-06-24 00:08:54.522715
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy(lambda: 1).to_maybe() == 1
    assert Lazy.of(1).to_maybe() == 1


# Generated at 2022-06-24 00:09:01.072367
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Failure

    lazy = Lazy(lambda: 'hello')

    assert lazy.to_try() == Try.of(lambda: 'hello')

    try_ = Try.of(lambda: 1 / 0)

    error = lazy.to_try(try_).get()

    assert isinstance(error, Failure)

    assert error.value.__class__.__name__ == 'ZeroDivisionError'

    assert lazy.to_try(
        Try(lambda: 1 / 0)
    ).get_or_else('empty') == 'empty'



# Generated at 2022-06-24 00:09:04.682425
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert 'Lazy[fn=<lambda>, value=None, is_evaluated=False]' == str(Lazy(lambda: 1))



# Generated at 2022-06-24 00:09:07.160392
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    # Given
    from pymonet.validation import Validation

    def fn() -> Validation:
        return Validation.success('i am a result')

    lazy = Lazy(fn)

    # When
    lazy_string = str(lazy)

    # Then
    assert lazy_string == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x000001E08A31E840>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:09:14.229150
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Try.of(lambda: 'value') == Lazy.of('value').to_try()
    assert Try.failure(Exception("Can't get lazy value")) == Lazy(lambda: 1 / 0).to_try()



# Generated at 2022-06-24 00:09:24.541813
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from functools import partial

    call_id = id
    called_on_obj = 'called_on_obj'

    lazy1 = Lazy(call_id)
    assert str(lazy1) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(call_id, None, False)

    lazy1_evaluated = Lazy(call_id).bind(lambda arg: arg)
    assert str(lazy1_evaluated) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(type(call_id), id(call_id), True)

    lazy2 = Lazy(partial(call_id, called_on_obj))

# Generated at 2022-06-24 00:09:30.565602
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    def mapper(value):
        return Left(value)

    assert Lazy.of(0).ap(Lazy.of(mapper)).get(1) == Right(1)
    assert Lazy.of(mapper).ap(Lazy.of(0)).get(1) == Left(1)
    assert Lazy.of(mapper).ap(Lazy.of(Try.of)).get(2) == Left(2)



# Generated at 2022-06-24 00:09:34.612156
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover

    def f(x):
        return Lazy.of(x+1)

    assert Lazy(lambda x: 2).bind(f).get() == 3
    assert Lazy(lambda x: 2).bind(lambda x: Lazy.of(x+1)).get() == 3



# Generated at 2022-06-24 00:09:38.353230
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)

    from pymonet.functor import Functor

    f1 = Functor(lambda x: x + 1)
    f2 = Functor(lambda x: x + 2)

    assert f1 != f2
    assert f1 != object()



# Generated at 2022-06-24 00:09:41.237207
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    l = Lazy(lambda: 23)
    assert l.__str__() == 'Lazy[fn=<function Lazy.<lambda> at 0x7f3f3b6aa9d8>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:09:47.731778
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.func import compose

    def fn_return_lazy(arg):
        def return_lazy(value):
            return Lazy.of(lambda *args: value)

        def return_lazy_called(value):
            return Lazy.of(lambda *args: value(arg))

        return Lazy.of(return_lazy).ap(Lazy.of(return_lazy_called))

    assert fn_return_lazy(42).get()(10) == 42



# Generated at 2022-06-24 00:09:52.672306
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def upper_fn(x: str) -> str:
        return x.upper()

    lazy = Lazy(upper_fn)
    assert lazy.to_box('1') == Box('1'.upper())



# Generated at 2022-06-24 00:09:53.272499
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    pass

# Generated at 2022-06-24 00:09:57.430540
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy.of(lambda x: x * 2)) == "Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x7f9f47ee5950>, value=None, is_evaluated=False]"

# Generated at 2022-06-24 00:10:05.881466
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def add(x):
        return x + 10

    def multiply(x):
        return x * 10

    assert Maybe(5).to_lazy().ap(Maybe(add)) == Maybe(15)
    assert Maybe(5).to_lazy().ap(Box(add)) == Maybe(15)
    assert Maybe(5).to_lazy().ap(Maybe(multiply)) == Maybe(50)
    assert Maybe(5).to_lazy().ap(Box(multiply)) == Maybe(50)

    assert Maybe.nothing().to_lazy().ap(Maybe(add)) == Maybe.nothing()
    assert Maybe.nothing().to_lazy().ap(Box(add)) == Maybe.nothing()

# Generated at 2022-06-24 00:10:07.211278
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 3).get() == 3



# Generated at 2022-06-24 00:10:18.286468
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def fn(n: int) -> int:
        return n + 1

    assert Lazy(lambda *args: 'a') == Lazy(lambda *args: 'a')
    assert not (Lazy(lambda *args: 'a') != Lazy(lambda *args: 'a'))

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(100) == 101
    assert lazy.get(100) == 101

    assert Lazy.of('a').get() == 'a'

    assert Lazy(lambda *args: 'a').get() == 'a'
    assert Lazy(lambda *args: 'a').map(lambda a: a + 'b').get() == 'ab'


# Generated at 2022-06-24 00:10:21.856732
# Unit test for method map of class Lazy
def test_Lazy_map():
    """Simple test for method map of class Lazy."""

    assert Lazy(lambda x: x).map(lambda x: x + 1).map(lambda x: x + 1).get(1) == 3


# Generated at 2022-06-24 00:10:29.764050
# Unit test for constructor of class Lazy
def test_Lazy():
    @Lazy
    def lazy_fn():
        raise ValueError()

    try:
        lazy_fn.get()
        raise AssertionError()
    except ValueError:
        pass

    assert lazy_fn.is_evaluated

    assert lazy_fn.map(lambda x: x + 10).get() == 20
    assert lazy_fn.is_evaluated

    assert lazy_fn.ap(Lazy.of(lambda x: x + 2)).get() == 22
    assert lazy_fn.is_evaluated

    assert lazy_fn.bind(lambda x: Lazy.of(x + 10)).get() == 20
    assert lazy_fn.is_evaluated

# Generated at 2022-06-24 00:10:39.137309
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x + x).map(lambda x: x + x).__eq__(Lazy(lambda x: x + x).map(lambda x: x + x))
    assert Lazy(lambda x: x + x).map(lambda x: x + x) != Lazy(lambda x: x + x).map(lambda x: x * x)
    assert Lazy(lambda x: x + x) != Lazy(lambda x: x * x)
    assert Lazy(lambda x: x + x) != Lazy(lambda x: x + x).map(lambda x: x + x)



# Generated at 2022-06-24 00:10:44.413243
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(x): return x

    def f_mapper_double(x): return x * 2

    def f_mapper_triple(x): return x * 3

    f_double = Lazy(f_mapper_double)
    f_triple = Lazy(f_mapper_triple)

    assert Lazy(f).map(f_mapper_double) == f_double
    assert Lazy(f).map(f_mapper_triple) == f_triple
    assert Lazy(f).map(f_mapper_double) != f_triple

# Generated at 2022-06-24 00:10:47.065787
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """
    Unit test for method to_either of class Lazy
    """
    from pymonet.either import Left, Right

    assert Lazy(lambda: 123).to_either() == Right(123)
    assert Lazy(lambda : 0/0).to_either() == Left(ZeroDivisionError())


# Generated at 2022-06-24 00:10:54.485150
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f1 = lambda: 1
    f2 = lambda: 2

    l1 = Lazy(f1)
    l2 = Lazy(f1)
    l3 = Lazy(f2)

    assert l1 == l1
    assert l1 == l2
    assert l1 != l3

    l1._compute_value()
    l2._compute_value()
    l3._compute_value()

    assert l1 == l1
    assert l1 == l2
    assert l1 != l3



# Generated at 2022-06-24 00:11:05.297701
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def gen_fn(n):
        return Lazy(lambda *args: n * 2)

    def div_fn(n):
        return Lazy(lambda *args: n/2)

    assert Lazy.of(2).ap(Lazy.of(lambda x: x * 2)) == Lazy.of(2).bind(gen_fn) == Lazy.of(4)
    assert Lazy.of(4).ap(Lazy.of(lambda x: x/2)) == Lazy.of(4).bind(div_fn) == Lazy.of(2)
    assert Lazy.of(4).ap(Lazy.of(lambda x: x/0)) == Lazy.of(4).bind(div_fn) is Lazy.of(4).bind(div_fn)

# Generated at 2022-06-24 00:11:07.144290
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    Lazy.of(23) == Lazy(lambda: 23)


# Generated at 2022-06-24 00:11:17.414486
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return lambda y: x + y

    def mul(x):
        return lambda y: x * y

    f = Lazy(lambda x: x * 2)
    g = Lazy(lambda x: x * 3)

    assert f.ap(g).get(5) == 30

    assert f.map(add(1)).ap(g).get(2) == 8

    assert g.ap(f).ap(Lazy(lambda x: x * 4)).get(1) == 24

    assert f.map(add).ap(Lazy.of(1)).ap(Lazy.of(2)) == Lazy.of(3)



# Generated at 2022-06-24 00:11:21.352989
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    lazy = Lazy(lambda x: x + 1)
    fn = lambda x: Lazy(lambda: x + 1)

    result = lazy.bind(fn)
    assert result._compute_value(2) == 4



# Generated at 2022-06-24 00:11:28.039413
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy.of(1)) == 'Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x7f6b1dc01598>, value=1, is_evaluated=True]'
    assert str(Lazy(lambda x: x).map(lambda x: x + 1)) == 'Lazy[fn=<function Lazy.map.<locals>.<lambda> at 0x7f6b1dc06ae8>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:11:35.812372
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is True
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1)) is False
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x).to_either()) is False
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x).fold()) is True
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1).fold()) is False


# Generated at 2022-06-24 00:11:44.483991
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(constructor_fn):
        return Lazy(lambda: constructor_fn + constructor_fn)

    def do_nothing(x):
        return x

    lazy_1 = Lazy.of(1)
    lazy_2 = Lazy.of(2)
    mapping_lazy = Lazy(lambda: lambda x: x + 1)

    assert lazy_1.bind(fn) == Lazy(lambda: 2)
    assert lazy_1.get() == 1
    assert lazy_1.bind(do_nothing) == lazy_1


# Generated at 2022-06-24 00:11:48.113701
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    test_data = [0, None, 'any string']

    for data in test_data:
        context_data = data

        def constructor_fn():
            return context_data

        result = Lazy(constructor_fn).to_either()

        assert isinstance(result, Right)
        assert result.get_value() == data



# Generated at 2022-06-24 00:11:52.834842
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left

    assert Lazy(lambda: 'hello').to_either() == Right('hello')
    assert Lazy(lambda: 1).to_either() == Right(1)
    assert Lazy(lambda: Exception()).to_either() == Left(Exception)


# Generated at 2022-06-24 00:11:56.092574
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    lazy_t = Lazy.of(True)
    assert (
        lazy_t.to_validation() ==
        Validation.success(True)
    )


# Generated at 2022-06-24 00:12:03.370260
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.Either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    lazy = Lazy(lambda: 'test')

    assert lazy.to_maybe() == Maybe.just('test')
    assert lazy.to_box() == Box('test')
    assert lazy.to_either() == Right('test')
    assert lazy.to_try() == Try.of(lazy.constructor_fn)
    assert lazy.to_validation() == Validation.success('test')


# Generated at 2022-06-24 00:12:07.089706
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    """
    Test for method to_maybe of class Lazy.
    """
    from pymonet.maybe import Maybe

    lazy = Lazy(lambda a: a*2)
    lazy = lazy.to_maybe(3)

    assert lazy == Maybe.just(6), 'Test for method to_maybe of class Lazy failed.'

# Generated at 2022-06-24 00:12:08.792491
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def constructor(x):
        return x

    lazy = Lazy(constructor)

    assert lazy.is_evaluated is False
    assert lazy.value is None

    assert lazy.get(2) == 2
    assert lazy.is_evaluated is True
    assert lazy.value == 2

# Generated at 2022-06-24 00:12:17.337498
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.maybe import Maybe

    def eq(value_1, value_2):
        return Lazy(lambda: value_1) == Lazy(lambda: value_2)

    assert eq(10, 10) == True
    assert eq(10, 20) == False
    assert eq("abc", "abc") == True
    assert eq("abc", "abcd") == False

    assert eq(Maybe.of("abc"), Maybe.of("abc")) == True
    assert eq(Maybe.of("abc"), Maybe.of("abcd")) == False
    assert eq(Maybe.of("abc"), Maybe.of(None)) == False


# Generated at 2022-06-24 00:12:20.976256
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Lazy(lambda: Maybe.just(4)).to_maybe() == Maybe.just(4)
    assert Lazy(lambda: Maybe.empty()).to_maybe() == Maybe.empty()

# Generated at 2022-06-24 00:12:25.510262
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    assert Lazy.of(4).to_either() == Right(4)
    assert Lazy.of(4).to_either() != Left("something")

    assert Lazy(lambda *args: 4).to_either() == Right(4)
    assert Lazy(lambda *args: 4).to_either() != Left("something")



# Generated at 2022-06-24 00:12:29.076600
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    # with constructor_fn
    lazy = Lazy(lambda: 7)
    assert lazy.get() == 7

    # with value
    lazy = Lazy.of(7)
    assert lazy.get() == 7



# Generated at 2022-06-24 00:12:37.417493
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    def add(x):
        return x + 10

    def sub(x):
        return x - 10

    def div(x):
        return x / 10

    def mul(x):
        return x * 10

    b = Lazy(lambda: 10).ap(Lazy(lambda x: add(x))).map(lambda x: mul(x)).get()
    assert (b == 200), 'Lazy ap method test failed'

    b = Lazy(lambda: 10).ap(Lazy(lambda x: sub(x))).map(lambda x: div(x)).get()
    assert (b == 0), 'Lazy ap method test failed'



# Generated at 2022-06-24 00:12:46.260685
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.either import Right
    from pymonet.validation import Validation

    def foo():
        return 'foo'

    def bar():
        return 'bar'

    test_lazy = Lazy(lambda: foo())
    test_lazy.get()

    assert test_lazy == Lazy(lambda: foo())

    test_lazy = Lazy(lambda: foo())
    assert test_lazy != Lazy(lambda: bar())
    assert test_lazy != Right(foo())
    assert test_lazy != Validation('error', 'foo')  # pragma: no cover

# Generated at 2022-06-24 00:12:49.741235
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(None).to_either() == Right(None)


# Generated at 2022-06-24 00:12:52.504638
# Unit test for constructor of class Lazy
def test_Lazy():
    def double(n: int) -> int:
        return n * 2

    lazy = Lazy(double)
    expected = Lazy(double)
    assert lazy == expected



# Generated at 2022-06-24 00:12:59.088335
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def func_to_validation():
        return 1

    lazy = Lazy(func_to_validation)

    validation = lazy.to_validation()

    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.success == 1
    assert not validation.is_failure


# Generated at 2022-06-24 00:13:04.048287
# Unit test for constructor of class Lazy
def test_Lazy():
    fn = lambda *args: 9
    assert str(Lazy(fn)) == 'Lazy[fn=<function test_Lazy.<locals>.<lambda> at 0x1110c8d90>, value=None, is_evaluated=False]'
    assert Lazy(fn).constructor_fn == fn



# Generated at 2022-06-24 00:13:11.528710
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add(x, y):
        return x + y

    assert Lazy.of(3).map(lambda x: x * x) == Lazy.of(9)
    assert Lazy.of(3).map(add).map(lambda x: x * x) == Lazy.of(9)
    assert Lazy.of(3).map(add).map(add).map(lambda x: x * x) == Lazy.of(9 + 3 + 3)

# Generated at 2022-06-24 00:13:19.347959
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda *args: 'lazy') == Lazy(lambda *args: 'lazy')
    assert Lazy(lambda *args: 'lazy') != Lazy.of('lazy')
    assert Lazy(lambda *args: 'lazy') != Lazy(lambda *args: 1)
    assert Lazy(lambda *args: 1) != Lazy(lambda *args: '1')
    assert Lazy(lambda *args: ' ') == Lazy(lambda *args: ' ')
    assert Lazy(lambda *args: ' ') == Lazy(lambda *args: ' ')



# Generated at 2022-06-24 00:13:23.826573
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    lazy = Lazy(lambda: 'foo')

    assert lazy.__str__() == 'Lazy[fn=<function <lambda> at 0x7fe91706f9d8>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:13:29.163179
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    import pymonet.monad_try as mt

    try_value = Lazy.of(1).to_try()
    assert isinstance(try_value, mt.Try)
    assert try_value.get() == 1

    def raise_exception():
        raise RuntimeError('kyky')

    try_value = Lazy(raise_exception).to_try()
    assert isinstance(try_value, mt.Try)
    assert isinstance(try_value.get(), RuntimeError)



# Generated at 2022-06-24 00:13:34.503164
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn_to_test(*args):
        return args[0] * args[1]

    lazy = Lazy(fn_to_test)
    assert lazy.get(4, 5) == 20

    lazy = Lazy(fn_to_test)
    assert lazy.get(0, 0) == 0



# Generated at 2022-06-24 00:13:45.949359
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.monad_try import Try

    str_function = lambda x: "yay!"
    str_function_Lazy = Lazy(str_function)

    assert str(str_function_Lazy) == "Lazy[fn={}, value=None, is_evaluated=False]".format(
        str_function
    )

    str_function_Lazy.get()
    assert str(str_function_Lazy) == "Lazy[fn={}, value=yay!, is_evaluated=True]".format(
        str_function
    )

    str_function_Lazy.to_box()

# Generated at 2022-06-24 00:13:51.055252
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.utils import identity

    lazy = Lazy(identity)
    assert str(lazy) == 'Lazy[fn=<function identity at 0x7f0b532f6268>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:14:01.146079
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    def plus_one(i):
        return i + 1

    def plus_two(i):
        return i + 2

    assert Lazy.of(Right(1)).map(plus_one).to_either() == Right(2)
    assert Lazy.of(Right(1)).map(plus_two).to_either() == Right(3)
    assert Lazy.of(Right(1)).map(plus_one).to_either() == Lazy.of(Right(1)).map(plus_two).to_either().map(plus_one)
    assert Lazy.of(Right(1)).map(plus_one).to_either() == Lazy.of(Right(1)).map(plus_two).to_either().map(plus_two)


# Generated at 2022-06-24 00:14:12.131148
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    constructor = lambda: 'hello'
    other_constructor = lambda arg: arg + ' world'
    expected = 'hello world'

    lazy_instance = Lazy(constructor)
    arg_lazy = Lazy(other_constructor)

    assert lazy_instance.ap(arg_lazy).get() == expected
    assert lazy_instance.ap(Lazy.of(other_constructor)).get() == expected
    assert lazy_instance.ap(arg_lazy).map(lambda x: x + '!').get() == expected + '!'
    assert Lazy.of(constructor).ap(Lazy.of(other_constructor)).get() == expected
    assert Lazy.of(constructor).ap(Lazy.of(other_constructor)).map(lambda x: x + '!').get() == expected + '!'



# Generated at 2022-06-24 00:14:16.581226
# Unit test for constructor of class Lazy
def test_Lazy():
    def fn(n):
        return n * n

    lazy = Lazy(fn)
    assert str(lazy) == 'Lazy[fn=<function test_Lazy.<locals>.fn at 0x000002501E211EA0>, value=None, is_evaluated=False]'

# Generated at 2022-06-24 00:14:26.337031
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert 'Lazy[fn=<lambda>, value=None, is_evaluated=False]' == str(Lazy(lambda: 0))
    assert 'Lazy[fn=<lambda>, value=None, is_evaluated=False]' == str(Lazy(lambda: 'a'))
    assert 'Lazy[fn=<lambda>, value=None, is_evaluated=False]' == str(Lazy(lambda: {}))
    assert 'Lazy[fn=<lambda>, value=None, is_evaluated=False]' == str(Lazy(lambda: []))
    assert 'Lazy[fn=<lambda>, value=None, is_evaluated=False]' == str(Lazy(lambda: True))
    assert 'Lazy[fn=<lambda>, value=None, is_evaluated=False]' == str(Lazy(lambda: False))

# Generated at 2022-06-24 00:14:29.350445
# Unit test for method map of class Lazy
def test_Lazy_map():
    def get_one():
        return 1

    def get_two():
        return 2

    def get_three():
        return 3

    assert Lazy(get_one).map(lambda x: x + 2).map(lambda x: x + 3).get() == 6
    assert Lazy(get_two).map(lambda x: x * 2).get() == 4
    assert Lazy(get_three).map(lambda x: x * 3).get() == 9

# Generated at 2022-06-24 00:14:31.715528
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():

    assert Lazy(lambda : 1).to_box().get() == 1
    assert Lazy(lambda name: "Hello " + name).to_box("Tom").get() == "Hello Tom"

# Generated at 2022-06-24 00:14:36.099210
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    # GIVEN: Lazy with mapper
    lazy = Lazy(lambda x: x).map(lambda x: x + 1)

    # WHEN: call to_validation
    validation = lazy.to_validation(**{'x': 5})

    # THEN: validation will be success and contains mapped value
    assert validation == Validation.success(6)



# Generated at 2022-06-24 00:14:40.019496
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 5)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f055e13db70>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:14:46.091748
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.function import compose
    from pymonet.box import Box
    from pymonet.either import Right

    assert Lazy(lambda x: x * 2).ap(Lazy.of(2)) == Lazy.of(4)
    assert Lazy(lambda x: x * 2).ap(Box(2)) == Box(4)
    assert Lazy(lambda x: x * 2).ap(Right(2)) == Right(4)
    assert Lazy(compose(lambda x: x * 2, abs)).ap(Right(-2)) == Right(4)
    assert Lazy(compose(lambda x: x * 2, abs)).ap(Box(-2)) == Box(4)


# Generated at 2022-06-24 00:14:52.349250
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    value = Lazy.of(5).to_maybe()
    assert value == Maybe.just(5)

    value = Lazy.of(5).to_try().to_maybe()
    assert value == Maybe.just(5)

    value = Lazy.of(5).to_box().to_maybe()
    assert value == Maybe.just(5)

    value = Lazy.of(5).to_validation().to_maybe()
    assert value == Maybe.just(5)



# Generated at 2022-06-24 00:15:02.474974
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    class LazyClass(Lazy, Functor, Applicative):
        """
        Class for test multiple inheritance
        """
        pass

    assert Lazy(lambda: None) == Lazy(lambda: None)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: (1, 2)) == Lazy(lambda: (1, 2))
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: (1, 2)) != Lazy(lambda: (2, 1))

    def test_fn(*args):
        return args[0] + 1

    assert Lazy(lambda: 1) != Lazy(test_fn)
    assert Lazy

# Generated at 2022-06-24 00:15:07.572854
# Unit test for constructor of class Lazy
def test_Lazy():
    def f1() -> str:
        return 'hello world'

    def f2() -> int:
        return 2

    assert Lazy.of(f1) == Lazy.of(f1)  # both are empty
    assert Lazy.of(f1) != Lazy.of(f2)  # empty and not empty
    assert Lazy.of(f1).get() == 'hello world'

# Generated at 2022-06-24 00:15:10.973714
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():

    def function_1():  # type: () -> Try[int]
        raise ValueError('function_1')

    def function_2():  # type: () -> int
        return 2

    assert Lazy(function_1).to_try() == Try.failure(ValueError('function_1'))

    assert Lazy(function_2).to_try() == Try.success(2)

# Generated at 2022-06-24 00:15:20.831293
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def construct_lazy(*args):
        """
        Get args and return them. If one of args is empty return None.

        :param args: any arguments
        :type args: Any
        :return: argv or None if one of args is empty
        :rtype: Any
        """
        for arg in args:
            if arg == '':
                return None
        return args

    # Lazy with function which return not empty Maybe
    lazy_not_empty = Lazy(construct_lazy)
    # Lazy with function which return empty Maybe
    lazy_empty = Lazy(construct_lazy)

    # Call method to_maybe with not empty value
    # and lazy_not_empty shouldn't return empty Maybe
    assert lazy_not_empty.to_maybe('test') == Maybe.just(('test',))

    # Call method

# Generated at 2022-06-24 00:15:25.344335
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def f():
        return 1

    lazy = Lazy(f)

    assert lazy.to_validation() == Validation.success(1)
    assert lazy.to_validation() == Validation.success(1)


# Generated at 2022-06-24 00:15:30.131823
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    from ex_3_2 import make_f_to_c

    assert Lazy.of(make_f_to_c).to_validation() == Validation.success(make_f_to_c)



# Generated at 2022-06-24 00:15:32.770362
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    # Given
    lazy = Lazy(lambda x: x + 1)

    # When
    box = lazy.to_box(1)

    # Then
    assert 2 == box.get()


# Generated at 2022-06-24 00:15:38.780616
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    assert Lazy.of(2).to_box() == Lazy.of(2).to_box()
    assert Lazy.of(2).to_box().get() == Lazy.of(2).to_box().get()
    assert Lazy.of(2).to_box() == Lazy.of(2).to_box().get()
    assert Lazy.of(2).to_box().map(lambda x: x*2).get() == Lazy.of(2).to_box().map(lambda x: x*2).get()
    assert Lazy.of(2).to_box().map(lambda x: x*2) == Lazy.of(2).to_box().map(lambda x: x*2).get()

# Generated at 2022-06-24 00:15:43.195980
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x + 2).constructor_fn() == 3
    assert Lazy(lambda: 1).map(lambda x: x + 2).is_evaluated is False
    assert Lazy(lambda: 1).is_evaluated is False



# Generated at 2022-06-24 00:15:46.321434
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    """
    >>> from pymonet.lazy import Lazy
    >>> from pymonet.maybe import Maybe
    >>> Lazy.of(5).to_maybe()
    Maybe[5]
    """

    return 0


# Generated at 2022-06-24 00:15:48.020588
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Lazy(lambda _: 1).to_validation()



# Generated at 2022-06-24 00:15:54.392775
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # type: ignore
    def f():
        return 5

    def g():
        return 6

    assert Lazy(f) != object()
    assert Lazy(f) != Lazy(g)
    assert Lazy(f) == Lazy(f)
    assert Lazy(g) == Lazy(g)



# Generated at 2022-06-24 00:15:58.314463
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def _fn(x: str) -> Lazy[str, int]:
        return Lazy(lambda *args: len(x))

    assert Lazy.of(1).bind(_fn).get() == 1
    assert Lazy.of('test').bind(_fn).get() == 4



# Generated at 2022-06-24 00:16:02.854075
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def some_function():
        return 5

    assert Lazy(some_function).to_try() == Try.of(some_function)
    assert Lazy(some_function).to_try().get() == 5



# Generated at 2022-06-24 00:16:06.869967
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    # pylint: disable=W0612
    def foo(*args):
        return 1

    assert str(Lazy(foo)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.foo at 0x1014cd950>, value=None, is_evaluated=False]'
    assert str(Lazy.of(2)) == 'Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x1014d1440>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:16:16.550721
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.either import Right, Left
    from pymonet.validation import Validation

    def constructor_fn(value: int) -> int:
        return value

    assert Lazy(constructor_fn).to_maybe(1) == Maybe.just(1)

    assert Lazy(constructor_fn).to_maybe(Box(1)) == Maybe.just(1)
    assert Lazy(constructor_fn).to_maybe(Box(None)) == Maybe.nothing()

    assert Lazy(constructor_fn).to_maybe(Right(1)) == Maybe.just(1)
    assert Lazy(constructor_fn).to_maybe(Left(1)) == Maybe.nothing()

    assert Lazy(constructor_fn).to_maybe(Validation.success(1)) == Maybe

# Generated at 2022-06-24 00:16:20.091808
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    global __test_counter
    __test_counter += 1

    assert str(Lazy(lambda: 0)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x10d3e0ea0>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:16:24.207206
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    assert Lazy.of(3).to_validation() == Validation.success(3)

# Generated at 2022-06-24 00:16:29.308694
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def test_fn():
        from pymonet.box import Box
        return Box(15)

    lazy = Lazy(test_fn)

    assert lazy.get() == 15

    assert lazy.get() == 15

    assert lazy.is_evaluated is True


# Generated at 2022-06-24 00:16:32.055856
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 42)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x7ff3d499bbf8>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:16:34.546755
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.either import Right

    assert Lazy.of(Right('')) == Lazy.of(Right(''))



# Generated at 2022-06-24 00:16:46.007819
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test if Lazy.map(function) returns correct Lazy with result of function(Lazy.constructor_fn()) mapped
    """
    def add_two(n):
        return n + 2

    def multiply_by_two(n):
        return n * 2

    lazy_add_two = Lazy(add_two)
    lazy_add_two_mapped = lazy_add_two.map(add_two)

    assert lazy_add_two_mapped.get(3) == 8

    assert lazy_add_two.get(3) == 5
    assert lazy_add_two.get(3) == 5
    assert not lazy_add_two.is_evaluated

    assert lazy_add_two_mapped.get(3) == 8

# Generated at 2022-06-24 00:16:56.764571
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def get_two():
        return 2

    assert Lazy(lambda: 3).bind(lambda x: Lazy(lambda: x * get_two())).get() == 6
    assert Lazy(lambda: 3).bind(lambda x: Lazy(lambda: x * get_two())).to_box().get() == 6
    assert Lazy(lambda: 3).bind(lambda x: Lazy(lambda: x * get_two())).to_either().get_right() == 6
    assert Lazy(lambda: 3).bind(lambda x: Lazy(lambda: x * get_two())).to_maybe().get() == 6
    assert Lazy(lambda: 3).bind(lambda x: Lazy(lambda: x * get_two())).to_try().get() == 6

# Generated at 2022-06-24 00:17:04.549905
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    import pymonet.box
    import pymonet.either
    import pymonet.maybe
    import pymonet.monad_try
    import pymonet.validation

    def add2(x):
        return x + 2

    def add1(x):
        return x + 1

    # prepare test data