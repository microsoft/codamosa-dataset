

# Generated at 2022-06-24 00:06:58.219730
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right

    assert Lazy(lambda: 1).to_either() == Right(1)
    assert (
        Lazy(lambda: raise_error()).to_either() == Left(ValueError('an error'))
    )


# Generated at 2022-06-24 00:07:01.859912
# Unit test for method map of class Lazy
def test_Lazy_map():
    def double(x):
        return x * 2

    def string(x):
        return '{}'.format(x)

    lazy = Lazy(double).map(string)

    assert lazy.constructor_fn(10) == '20'



# Generated at 2022-06-24 00:07:10.127349
# Unit test for method map of class Lazy

# Generated at 2022-06-24 00:07:12.644284
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)



# Generated at 2022-06-24 00:07:14.469563
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda x: x + 2) == Lazy(lambda y: y + 2)

# Generated at 2022-06-24 00:07:16.298216
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)



# Generated at 2022-06-24 00:07:19.680412
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    lazy = Lazy(lambda: '123')
    value = lazy.to_either()

    assert value.is_right()
    assert value.get_value() == '123'



# Generated at 2022-06-24 00:07:24.622635
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy.of(1)) == 'Lazy[fn=<function <lambda> at 0x7f65f768cf28>, value=1, is_evaluated=True]'
    assert str(Lazy(lambda *args: 1)) == 'Lazy[fn=<function <lambda> at 0x7f65f768cf28>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda *args: [])) == 'Lazy[fn=<function <lambda> at 0x7f65f768cf28>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:07:27.435574
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x * 2).get() == 2



# Generated at 2022-06-24 00:07:32.357630
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def plus_one(v):
        return v + 1


    lazy = Lazy(plus_one)

    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2

# Generated at 2022-06-24 00:07:35.036870
# Unit test for method map of class Lazy
def test_Lazy_map():
    lz = Lazy.of(1)
    assert lz.map(lambda x: x + 1) == Lazy(lambda x: x + 1)



# Generated at 2022-06-24 00:07:37.516366
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation(2) == Validation.success(1)

# Generated at 2022-06-24 00:07:40.276913
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(10).to_box() == Box(10)


# Generated at 2022-06-24 00:07:43.772037
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    assert Lazy(lambda: 'hello').to_try() == Try.of(lambda: 'hello')
    assert Lazy(lambda: 1 / 0).to_try() == Try.of(lambda: 1 / 0)


# Generated at 2022-06-24 00:07:47.580150
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def tmp(a):
        return a + 1

    a = Lazy(lambda: 1)
    b = Lazy(lambda: 2)
    assert Lazy.of(tmp).ap(a).get() == 2
    assert Lazy.of(tmp).ap(b).get() == 3

# Generated at 2022-06-24 00:07:55.710255
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Invalid

    def fn1(*args):
        return 2

    def fn2(*args):
        raise Exception()

    assert Lazy(fn1).to_either() == Lazy(fn1).to_box().to_either()
    assert Lazy(fn1).to_either() == Lazy(fn1).to_maybe().to_either()
    assert Lazy(fn1).to_either() == Lazy(fn1).to_try().to_either()
    assert Lazy(fn1).to_either() == Lazy(fn1).to_validation().to_either()

    assert Invalid(Exception()) == Lazy(fn2).to_either()
    assert Invalid(Exception()) == Lazy(fn2).to_box().to_either()

# Generated at 2022-06-24 00:07:58.304164
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    lazy = Lazy.of(1)
    assert lazy.to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:08:04.413376
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation() == Validation.success(1)

    assert Lazy.of(2).ap(Lazy.of(lambda x: x + 2)).to_validation() == Validation.success(4)


# Generated at 2022-06-24 00:08:07.504159
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def fn(a, b):
        if b != 0:
            return a / b
        return ZeroDivisionError('Oh no!')

    lazy_value = Lazy(fn)

    assert lazy_value.to_try(1, 2) == Try.of(lazy_value.constructor_fn, 1, 2)
    assert lazy_value.to_try(1, 0) == Try.of(lazy_value.constructor_fn, 1, 0)

# Generated at 2022-06-24 00:08:14.350765
# Unit test for method get of class Lazy
def test_Lazy_get():
    def x(value):
        return 2 * value

    def y(value):
        return value + 1

    lazy = Lazy(lambda value: x(value))

    assert lazy.get(2) == 4
    assert lazy.get(2) == 4

    lazy = lazy.map(y)
    assert lazy.get(2) == 5
    assert lazy.get(3) == 7

    def cycle(value):
        return cycle(2 * value)

    lazy = Lazy(lambda value: cycle(value))
    with pytest.raises(RuntimeError):
        print(lazy.get(2))


# Generated at 2022-06-24 00:08:16.730898
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    check.equal(Lazy(lambda x: x).to_validation(1), Validation.success(1))



# Generated at 2022-06-24 00:08:22.664592
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    fn = lambda: 1 / 0
    lazy = Lazy(fn)
    lazy.__str__() == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(fn, None, False)
    lazy.to_try().__str__() == 'Failure[Error[type=ZeroDivisionError, msg=division by zero]]'


# Generated at 2022-06-24 00:08:30.810802
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    Unit test for constructor of class Lazy.
    """
    assert Lazy.of(2) == Lazy(lambda x: 2)
    assert Lazy.of(2).get() == 2
    assert Lazy.of(2).fold(lambda x: x + 1) == 3
    assert Lazy.of(2).map(lambda x: x + 1) == Lazy(lambda x: 3)
    assert Lazy.of(2).ap(Lazy.of(lambda x: x + 1)) == Lazy(lambda x: 3)
    assert Lazy.of(2).bind(lambda x: Lazy.of(x + 1)) == Lazy(lambda x: 3)
    assert Lazy.of(2).to_box() == Lazy.of(2).fold(lambda x: x)

# Generated at 2022-06-24 00:08:34.770100
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 10)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7fe01170f7b8>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:08:39.612616
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def value() -> int:
        return 1

    lazy = Lazy(value)

    assert lazy.to_either() == Right(1)

    def value() -> int:
        return 2

    lazy = Lazy(value)

    assert lazy.to_either() == Right(2)


# Generated at 2022-06-24 00:08:44.050207
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    """
    Test transforming Lazy of string to a Box.

    It should return Box with value same as Lazy constructor_fn output
    """
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)



# Generated at 2022-06-24 00:08:46.081101
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    value = 'value'

    assert Lazy(lambda: value).to_box() == Lazy(lambda: value).to_box()



# Generated at 2022-06-24 00:08:50.621217
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert not Lazy(fn) == Lazy(lambda y: fn(y))
    assert not Lazy(fn) == Lazy(lambda y: y)
    assert not Lazy(fn) == Lazy(None)
    assert not Lazy(fn) == Lazy("foo")
    assert not Lazy(fn) == Lazy(5)
    assert not Lazy(fn) == fn


# Generated at 2022-06-24 00:08:53.934340
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)



# Generated at 2022-06-24 00:09:01.815160
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Either

    def func():
        x = getattr(None, "name")

    lazy = Lazy(func)

    assert lazy.to_either() == Either.left("'NoneType' object has no attribute 'name'")
    assert lazy.to_either() != Either.right("'NoneType' object has no attribute 'name'")


# Generated at 2022-06-24 00:09:06.609436
# Unit test for method __str__ of class Lazy
def test_Lazy___str__(): # pragma: no cover
    def my_function(value):
        return value * 2

    lazy = Lazy(my_function)

    assert str(lazy) == 'Lazy[fn=<function test_Lazy___str__.<locals>.my_function at 0x7f5e5d5d5ae8>, value=None, is_evaluated=False]'

# Generated at 2022-06-24 00:09:12.798681
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.either import Right, Left
    from pymonet.monad import curry

    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).get() == 2
    assert Lazy(lambda: Right(1)).bind(lambda _: Lazy(lambda: Left('error'))).get() == Left('error')
    assert Lazy(lambda: Right(1)).bind(lambda r: Lazy(lambda: Right(r + 1))).get() == Right(2)
    assert Lazy(lambda: Left('error')).bind(lambda r: Lazy(lambda: Right(r + 1))).get() == Left('error')

# Generated at 2022-06-24 00:09:23.241304
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Simple tests for Lazy class.
    """
    def add(x):
        return x + 1

    def double(x):
        return x * 2

    def add_three_and_double(x):
        return double(add(add(add(x))))

    assert str(Lazy.of(5).map(add)) == "Lazy[fn=<function Lazy.<lambda>.<locals>.<lambda> at 0x7f71dc20bae8>, value=None, is_evaluated=False]"
    assert str(Lazy.of(5).map(add).map(double)) == "Lazy[fn=<function Lazy.<lambda>.<locals>.<lambda>.<locals>.<lambda> at 0x7f71dc20ba60>, value=None, is_evaluated=False]"

# Generated at 2022-06-24 00:09:31.419288
# Unit test for constructor of class Lazy
def test_Lazy():
    import unittest

    def add_func(*args) -> int:
        return sum(args)

    def mul_func(*args) -> int:
        res = 1
        for i in args:
            res *= i
        return res

    class LazyTest(unittest.TestCase):
        def test_constructor(self):
            lazy = Lazy(add_func)
            self.assertIsNotNone(lazy)
            self.assertIsInstance(lazy, Lazy)
            self.assertIs(lazy.constructor_fn, add_func)
            self.assertFalse(lazy.is_evaluated)
            self.assertIsNone(lazy.value)
            self.assertEqual(lazy, Lazy(add_func))

# Generated at 2022-06-24 00:09:36.788059
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    lazy_int = Lazy(lambda: 7)
    lazy_fn = lambda x: Lazy.of(x * 3)

    assert lazy_int.bind(lazy_fn).get() == lazy_fn(lazy_int.get()).get() == 21

    # Check immutability
    assert lazy_int.get() == 7
    assert lazy_int.is_evaluated is True



# Generated at 2022-06-24 00:09:39.128397
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def lazy_string_function():
        return Lazy.of("Hello")

    assert Lazy(lazy_string_function).bind(lambda x: Lazy.of("World")).get() == "World"

# Generated at 2022-06-24 00:09:46.176578
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda: 0)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7fe6dcceb6a8>, value=None, is_evaluated=False]'

    lazy = Lazy(lambda: 0)
    lazy._compute_value()
    assert str(lazy) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7fe6dcceb6a8>, value=0, is_evaluated=True]'


# Generated at 2022-06-24 00:09:48.693915
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2


# Generated at 2022-06-24 00:09:56.503456
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).get() == 2
    assert Lazy(lambda: 2).bind(lambda x: Lazy(lambda: x + 1)).get() == 3
    assert Lazy(lambda: 3).bind(lambda x: Lazy(lambda: x + 1)).get() == 4
    assert Lazy(lambda: 4).bind(lambda x: Lazy(lambda: x + 1)).get() == 5


# Generated at 2022-06-24 00:10:00.285428
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of("abc").to_box() == Box("abc")


# Generated at 2022-06-24 00:10:02.412836
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def func():
        return 4

    assert Validation.success(4) == Lazy(func).to_validation()

# Generated at 2022-06-24 00:10:09.096543
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy.of(None).to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:10:19.107183
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    def generate_error():
        raise IndexError('Ups!')

    assert Lazy(lambda: []).to_maybe() == Lazy(lambda: []).to_box().to_maybe()
    assert Lazy(lambda: []).to_maybe() == Lazy(lambda: []).to_either().to_maybe()
    assert Lazy(lambda: []).to_maybe() == Lazy(lambda: []).to_try().to_maybe()
    assert Lazy(lambda: []).to_maybe() == Lazy(lambda: []).to_validation().to_maybe()
    assert Lazy(generate_error).to_maybe() == Lazy(generate_error).to_box().to_maybe()

# Generated at 2022-06-24 00:10:25.584808
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    @Lazy
    def maybe_in_lazy_in_box(x):
        return Box(Maybe.just(x + 3))

    assert maybe_in_lazy_in_box.bind(lambda x: x).get(1) == Maybe.just(4)



# Generated at 2022-06-24 00:10:32.319919
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Arrange
    def plus_one(value: int) -> int:
        return value + 1

    lazy_value = Lazy.of(2)

    # Act
    mapped_lazy_value = lazy_value.map(plus_one)

    # Assert
    assert mapped_lazy_value.get() == 3



# Generated at 2022-06-24 00:10:42.728168
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy(lambda: None).to_box() == Box(None)
    assert Lazy(lambda: None).to_either() == Right(None)
    assert Lazy(lambda: None).to_maybe() == Maybe.just(None)
    assert Lazy(lambda: None).to_try() == Try.success(None)
    assert Lazy(lambda: None).to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:10:49.222359
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy.of(1).to_try().is_success
    assert Lazy.of(1).map(lambda x: x + 1).to_try().is_success
    assert Lazy.of(1).map(lambda x: x / 0).to_try().is_failure
    assert Lazy.of(1).to_try().get() == 1

# Generated at 2022-06-24 00:10:52.785371
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy(lambda x: x).to_validation(True) == Validation.success(True)
    assert Lazy(lambda x: x).to_validation() == Validation.success(None)
    assert Lazy(lambda x: x).to_validation(None) == Validation.success(None)
    assert Lazy(lambda x: x).to_validation(False) == Validation.success(False)


# Generated at 2022-06-24 00:11:04.391706
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    try:
        assert Lazy(lambda: 'foo').to_try() == Try(lambda: 'foo') == Try.success('foo')

        assert Lazy(lambda: 1 / 0).to_try().get_exception() == ZeroDivisionError
        assert Lazy(ZeroDivisionError).to_try().get_exception().__name__ == 'ZeroDivisionError'
        assert Lazy(1 / 0).to_try().get_exception() == ZeroDivisionError
        assert Lazy(1 / 0).to_try().get_exception() == ZeroDivisionError
    except Exception as e:
        print('test_Lazy_to_try() => ' + str(e))
        raise e
    else:
        print('test_Lazy_to_try() => ok . . . ')


# Generated at 2022-06-24 00:11:08.948735
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation

    val_func = Validation.success(lambda x: x + 1)
    val_value = Validation.success(2)
    val = val_func.ap(val_value)
    assert val == Validation.success(3)


# Generated at 2022-06-24 00:11:15.354286
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    Unit test for constructor of class Lazy
    """
    ident_fn = lambda x: x

    assert Lazy(ident_fn) == Lazy(ident_fn)
    assert str(Lazy(ident_fn)) == "Lazy[fn=<function test_Lazy.<locals>.<lambda> at 0x10e57b950>, value=None, is_evaluated=False]"


# Generated at 2022-06-24 00:11:23.898263
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe(): # pragma: no cover
    def add(x, y):
        return x + y

    lazy_add = Lazy(add)
    assert lazy_add.map(lambda x: x + 10).to_maybe(1, 2) == Maybe.just(13)
    assert lazy_add.map(lambda x: x + 10).to_maybe(1, 2, 3) == Maybe.just(13)
    assert lazy_add.map(lambda x: x + 10).to_maybe(1) == Maybe.nothing()

# Generated at 2022-06-24 00:11:26.457649
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe, Nothing

    assert Lazy.of(2).to_maybe() == Maybe.just(2)
    assert Lazy.of(None).to_maybe() == Nothing

# Generated at 2022-06-24 00:11:31.748146
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Lazy.of('Hello World').to_maybe() == Maybe.just('Hello World')
    assert Lazy.of('Hello World').map(lambda x: x + ' !').to_maybe() == Maybe.just('Hello World !')

# Generated at 2022-06-24 00:11:35.718119
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x: x + 10).ap(Lazy(10)) == Lazy(lambda x: x + 10).constructor_fn(10)

# Generated at 2022-06-24 00:11:41.934766
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    assert Lazy.of(lambda x, y: x + y).ap(Lazy.of(2)).ap(Lazy.of(3)).get() == 5
    assert Lazy.of(lambda x, y: x + y).ap(Box(2)).ap(Box(3)).get() == 5


# Generated at 2022-06-24 00:11:45.124172
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != 1


# Generated at 2022-06-24 00:11:55.743864
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover

    def failed_sum(x: int) -> int:
        assert False, 'Failed sum'

    def nested_sum(x: int) -> int:
        def sum(a: int, b: int) -> int:
            return a + b

        return Lazy(lambda: nested_sum(1) + nested_sum(2)).fold(sum)

    def sum(a: int, b: int) -> int:
        return a + b

    assert Lazy.of(0) == Lazy.of(0)
    assert Lazy.of(0) != Lazy.of(1)
    assert Lazy.of(0) != Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)

# Generated at 2022-06-24 00:12:03.051800
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from unittest import TestCase
    from pymonet.monad_list import List

    class TestLazy(TestCase):
        def test_bind_lazy(self):
            def fn(argument):
                return Lazy(lambda: argument + '2')

            assert Lazy.of(1).bind(fn).get() == '12'

        def test_bind_lazy_to_monad(self):
            def fn(argument):
                return Lazy(lambda: List([argument]))

            assert Lazy.of('1').bind(fn).get() == ['1']

    from pymonet.test_utils import run_test_class

    run_test_class(TestLazy)

# Generated at 2022-06-24 00:12:08.036124
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 1).to_maybe() == Maybe.just(1)
    assert Lazy(lambda: 1).map(lambda x: x + 1).to_maybe() == Maybe.just(2)
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x * 2).to_maybe() == Maybe.just(4)



# Generated at 2022-06-24 00:12:15.001062
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add2(x): return x + 2

    def add3(x): return x + 3

    assert (Lazy.of(add2).ap(Lazy.of(1)) == Lazy.of(3))
    assert (Lazy.of(add2).map(add3).ap(Lazy.of(1)) == Lazy.of(6))
    assert (Lazy.of(add2).ap(Lazy.of(1).map(add3)) == Lazy.of(6))


# Generated at 2022-06-24 00:12:20.669754
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Lazy.of(1).to_try() == Try.of_result(1)
    assert Lazy.of(None).to_try() == Try.of_result(None)
    assert Lazy(lambda x: x / 0).to_try(6) == Try.of_error(ZeroDivisionError('division by zero'))


# Generated at 2022-06-24 00:12:25.317775
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def fn(arg):
        return arg + 1

    lazy = Lazy.of(1)
    maybe = lazy.to_maybe()

    assert maybe == Maybe.just(1)
    maybe_add = maybe.fmap(fn)
    assert maybe_add == Maybe.just(2)


# Generated at 2022-06-24 00:12:28.639570
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x: x * 2).get(2) == 4
    assert Lazy.of(0).get() == 0
    assert Lazy(lambda x: x / 0).get(4) == 0


# Generated at 2022-06-24 00:12:31.308419
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation() == Validation.success(1)


# Generated at 2022-06-24 00:12:36.533968
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)


# Generated at 2022-06-24 00:12:39.467225
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    empty_lazy = Lazy.of(lambda x : x + 10)
    lazy = Lazy.of(lambda x: x + 10)
    assert lazy == empty_lazy.ap(Lazy.of(10))



# Generated at 2022-06-24 00:12:49.000743
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn():
        return True

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(fn)

    assert lazy1 == lazy2
    assert lazy2 == lazy1
    assert lazy1.__eq__(lazy2)
    assert lazy2.__eq__(lazy1)

    lazy1._compute_value()
    assert lazy1 == lazy2
    assert lazy2 == lazy1
    assert lazy1.__eq__(lazy2)
    assert lazy2.__eq__(lazy1)

    lazy2._compute_value()
    assert lazy1 == lazy2
    assert lazy2 == lazy1
    assert lazy1.__eq__(lazy2)
    assert lazy2.__eq__(lazy1)

   

# Generated at 2022-06-24 00:13:00.637729
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.function import compose
    from pymonet.monad_reader import Reader

    def increment(x: int) -> int:
        return x + 1

    assert str(Lazy(str)) == 'Lazy[fn=<built-in function str>, value=None, is_evaluated=False]'
    assert str(Lazy(increment).map(str)) == 'Lazy[fn=<function Lazy.map.<locals>.<lambda> at 0x000001AE7A5A5F78>, value=None, is_evaluated=False]'

# Generated at 2022-06-24 00:13:05.442137
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    # when
    result = str(Lazy(lambda: 'test'))

    # then
    assert result == 'Lazy[fn=<function Lazy.<lambda> at 0x10dff7b70>, value=None, is_evaluated=False]'  # pragma: no cover


# Generated at 2022-06-24 00:13:10.716394
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def fn():
        pass

    assert (str(Lazy(fn))) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x7fedb1c21730>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:13:20.159575
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left
    from pymonet.validation import Validation

    assert Lazy(lambda: 1).to_box() == Box(1)
    assert Lazy(lambda val: val + 1).to_box(1) == Box(2)

    assert Lazy(lambda: Try(lambda: 1)).to_box().get() == Box(1)
    assert Lazy(lambda: Maybe.just(1)).to_box() == Box(1)
    assert Lazy(lambda x: Maybe.just(x + 1)).to_box(1) == Box(2)


# Generated at 2022-06-24 00:13:24.929020
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    def function_returning_helo_word(*args):
        return 'helo'

    lazy_wrapper = Lazy(function_returning_helo_word)

    assert lazy_wrapper.to_box('argument') == Box('helo')


# Generated at 2022-06-24 00:13:31.957365
# Unit test for method ap of class Lazy
def test_Lazy_ap(): # pylint: disable=missing-docstring
    def add3(value):
        """
        Function for unit test for method ap of class Lazy
        """
        return value + 3

    def mult3(value):
        """
        Function for unit test for method ap of class Lazy
        """
        return value * 3

    value = 10
    fn1 = Lazy.of(add3)
    fn2 = Lazy.of(mult3)

    assert fn1.ap(fn2).get(value) == 33

    fn1 = Lazy.of(value)

    assert fn1.ap(fn2).get() == 30

    fn3 = Lazy.of(lambda x: x + 3)
    assert fn3.ap(fn1).get() == 13


# Generated at 2022-06-24 00:13:39.284313
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(True).map(lambda value: value == True) == Lazy.of(True)
    assert Lazy.of(1).map(lambda value: value + 1) == Lazy.of(2)
    assert Lazy.of(1).map(lambda value: value * 2) == Lazy.of(2)
    assert Lazy.of((1, 2)).map(lambda value: value[0] + value[1]) == Lazy.of(3)
    test_fn = lambda value: value + 1
    assert Lazy(test_fn).map(lambda value: value + 1) == Lazy(lambda x: test_fn(x) + 1)



# Generated at 2022-06-24 00:13:43.034050
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)


# Generated at 2022-06-24 00:13:47.386010
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def f():
        return 1
    assert str(Lazy(f)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.f at 0x0000023ABBFCDEA0>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:13:52.151783
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda x: x).get(10) == 10
    assert Lazy(lambda x: x).get('hello') == 'hello'
    assert Lazy(lambda x, y: x + y).get(10, 20) == 30
    assert Lazy(lambda x, y: x + y).get('hello', 'world') == 'helloworld'



# Generated at 2022-06-24 00:13:59.583446
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.immutable_list import ImmutableList

    def sum(left: int, right: int) -> int:
        return left + right

    def print_args(*args):
        print('args={}'.format(args))

    assert str(Lazy(print_args)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.print_args at 0x7f5f3eb269d8>, value=None, is_evaluated=False]'
    assert str(Lazy(sum).map(lambda x: x + 1).map(lambda x: x * 2)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda>.<locals>.<lambda> at 0x7f5f3eb26a60>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:14:01.822475
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(10).to_box() == Box(10)


# Generated at 2022-06-24 00:14:05.765462
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy(lambda: 42).to_validation() == Lazy(lambda: 42).to_validation(None) == Validation.success(42)
    assert Lazy(lambda x: x).to_validation(42) == Validation.success(42)
    assert Lazy(lambda: 42).to_validation(None) == Validation.success(42)



# Generated at 2022-06-24 00:14:10.208143
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left

    # Try with None
    result = Lazy.of(None).to_either()
    assert result == Left(None)

    # Try with value:
    result = Lazy.of(1).to_either()
    assert result == Left(1)


# Generated at 2022-06-24 00:14:18.477916
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    get_try = Lazy.of(1).to_try()
    assert isinstance(get_try, Try)
    assert get_try.get() == 1
    assert get_try.is_successful() is True
    assert get_try.is_exception() is False

    get_exception = Lazy(lambda: 1 / 0).to_try()
    assert isinstance(get_exception, Try)
    assert get_exception.is_exception() is True
    assert get_exception.is_successful() is False



# Generated at 2022-06-24 00:14:26.459181
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # Given
    constructor_fn_01 = lambda args: args
    constructor_fn_02 = lambda args: args
    evaluee_01 = Lazy(constructor_fn_01)
    evaluee_02 = Lazy(constructor_fn_01)
    evaluee_03 = Lazy(constructor_fn_02)

    # Then
    assert evaluee_01 == evaluee_01
    assert evaluee_01 == evaluee_02
    assert evaluee_02 == evaluee_01
    assert evaluee_01 != evaluee_03
    assert evaluee_03 != evaluee_01



# Generated at 2022-06-24 00:14:31.887919
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    def to_maybe_test(value: bool) -> Maybe[str]:
        def fn():
            if value:
                return 'False'
            return None

        return Lazy(fn).to_maybe()

    assert(Maybe.just('False') == to_maybe_test(True))
    assert(Maybe.just('False') == to_maybe_test(False))

# Generated at 2022-06-24 00:14:39.195330
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.monad_list import MonadList
    from pymonet.monad_try import Success

    assert Lazy(lambda x: x) == Lazy(lambda x: x)
    assert Lazy(lambda x: x).constructor_fn == Lazy(lambda x: x).constructor_fn

    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(2).constructor_fn == Lazy.of(2).constructor_fn
    assert Lazy.of(1).constructor_fn() == 1
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).bind(lambda x: Lazy.of(x)).get() == 1

# Generated at 2022-06-24 00:14:44.921003
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Unit test for Lazy map method.
    """
    def id_function(value: object) -> object:
        return value

    lazy = Lazy(lambda: 'a')
    assert lazy.map(id_function) == Lazy(lambda: 'a')



# Generated at 2022-06-24 00:14:50.568155
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Lazy.of('Monad').to_validation() == Validation.of('Monad')
    assert Lazy.of('Monad').map(str.upper).to_validation() == Validation.of('MONAD')
    assert Lazy.of('Monad').ap(Lazy((lambda n: n.upper()))).to_validation() == Validation.of('MONAD')
    assert Lazy.of('Monad').bind(lambda n: Lazy(str.upper)).to_validation() == Validation.of('MONAD')


# Generated at 2022-06-24 00:14:56.830772
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def f1(x):
        return x + 1

    def f2(x):
        return x + 2

    assert Lazy(f1) == Lazy(f1)
    assert Lazy(f1) != Lazy(f2)
    assert Lazy(f1) != f1
    assert Lazy(f1) != 'x'


# Generated at 2022-06-24 00:15:06.518237
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    assert Lazy.of(1).to_either() == Lazy.of(1).to_box().to_either() == Lazy.of(1).to_try().to_either() == Lazy.of(1).to_validation().to_either()
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_either() == Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_box().to_either() == Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_try().to_either() == Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).to_validation().to_either()

# Generated at 2022-06-24 00:15:10.785370
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def greeting_fn(name: str) -> str:
        return "Hello " + name + "!"

    lzy = Lazy.of('Tom').map(greeting_fn)

    lzy_result = lzy.bind(lambda msg: Lazy.of(msg))

    assert lzy_result.get() == "Hello Tom!"

# Generated at 2022-06-24 00:15:12.403228
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    lazy = Lazy.of(20)
    assert lazy.to_box() == Box(20)



# Generated at 2022-06-24 00:15:21.043022
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.box import Box

    double = Lazy.of(lambda x: x * 2)
    assert double.get(2) == 4
    assert double.to_box(2) == Box(4)
    assert double.to_either(2) == double.to_box(2).to_either()
    assert double.to_maybe(2) == double.to_box(2).to_maybe()
    assert double.to_try(2) == double.to_box(2).to_try()
    assert double.to_validation(2) == double.to_box(2).to_validation()


# Generated at 2022-06-24 00:15:24.329625
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Lazy.of('abc').to_validation() == Validation.success('abc')



# Generated at 2022-06-24 00:15:30.743561
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def lazy_function(*args):
        print('call to lazy_function')
        return Try.of(normal_function, *args)

    def normal_function(*args):
        print('call to normal_function')
        return 'Foo'

    assert str(Lazy(lazy_function).to_try()) == 'Success[Foo]'

# Generated at 2022-06-24 00:15:40.898394
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.validation import Validation

    def test_with_mapper(mapper):
        def test_with(expected, given):
            assert expected == given, 'Excepted: {}, given: {}'.format(expected, given)

        def test_it():
            a = Lazy.of(5)
            a2 = Lazy.of(5)
            assert a == a2, 'Two Lazy with equal value are expected to be equal'

            test_with(Lazy.of(10), a.map(lambda x: x * 2))

            test_with(Lazy.of('5'), a.map(lambda x: str(x)))

            test_with(Lazy.of(Validation.success(5)), a.map(Validation.success))


# Generated at 2022-06-24 00:15:43.239828
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    assert Lazy(lambda: 10).to_validation() == Validation.success(10)


# Generated at 2022-06-24 00:15:50.348865
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def test_fn(value):
        return value

    assert Maybe.just(10).to_lazy().to_maybe() == Lazy(lambda: 10).to_maybe()
    assert Maybe.nothing().to_lazy().to_maybe() == Lazy(lambda: None).to_maybe()
    assert Maybe.just(10).map(test_fn).to_lazy().to_maybe() == Lazy(lambda: 10).map(test_fn).to_maybe()
    assert Maybe.just(10).bind(lambda val: Maybe.just(val)).to_lazy().to_maybe() == Lazy(lambda: 10).bind(lambda val: Lazy.of(val)).to_maybe()
    assert Maybe.nothing().bind(lambda val: Maybe.just(val)).to_lazy().to

# Generated at 2022-06-24 00:15:57.991481
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box

    def fn_a(a):
        return Lazy(lambda *args: a + 1)

    def fn_b(a):
        return Lazy(lambda *args: a + 1)

    a = Lazy(lambda *args: 5).bind(fn_a).bind(fn_b)
    b = Lazy(lambda *args: 5).to_box().bind(lambda a: Box(a + 1)).bind(lambda a: Box(a + 1)).get()
    assert a.get() == b
    assert a.is_evaluated == True
    assert a.value == 7


# Generated at 2022-06-24 00:16:02.166738
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy = Lazy(lambda x: x * 2)
    result = lazy.ap(Lazy(lambda x: x * 3))

    assert result.get(2) == 12

# Generated at 2022-06-24 00:16:04.960124
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def fn():
        return 1

    assert Validation.success(1) == Lazy(fn).to_validation()



# Generated at 2022-06-24 00:16:10.245991
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 'a').get() == 'a'



# Generated at 2022-06-24 00:16:13.811522
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe, Just, Empty

    assert Lazy.of(2).to_maybe() == Just(2)



# Generated at 2022-06-24 00:16:19.272292
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    """
    Test for method __str__ of Lazy class
    """
    res = Lazy(lambda: None)
    assert str(res) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f7f99c2b268>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:16:26.078664
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x: int) -> int:
        return x

    def fn2(x: int) -> int:
        return x + 2

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) == Lazy(fn).map(fn)
    assert not (Lazy(fn) == Lazy(fn2))


# Generated at 2022-06-24 00:16:32.858984
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    lazy = Lazy.of(2)
    assert lazy.is_evaluated is False
    assert lazy.value is None
    assert lazy.constructor_fn is not None
    assert lazy.to_either(1, 2, 3) == Right(2)
    assert lazy.is_evaluated is True
    assert lazy.value == 2


# Generated at 2022-06-24 00:16:35.153459
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Box(1) == Lazy.of(1).to_box()
    assert Box('value') == Lazy.of('value').to_box()

# Generated at 2022-06-24 00:16:43.281155
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1) == Lazy.of(2)
    assert Lazy.of(2).map(lambda x: x * 2) == Lazy.of(4)
    assert Lazy.of(4).map(lambda x: x) == Lazy.of(4)
    assert Lazy.of({1: 1}).map(lambda x: x) == Lazy.of({1: 1})



# Generated at 2022-06-24 00:16:54.302163
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    # given
    def mapper(x):
        return x + 3

    def mapper2(x):
        return x * 2

    def constructor(x):
        return x + 1

    lazy = Lazy(constructor)
    lazy.is_evaluated = True
    lazy.value = 3

    lazy2 = Lazy(constructor)
    lazy2.is_evaluated = True
    lazy2.value = 3

    lazy3 = Lazy(constructor)
    lazy3.is_evaluated = False
    lazy3.value = 3

    lazy4 = Lazy(constructor)
    lazy4.is_evaluated = True
    lazy4.value = 4

    lazy5 = Lazy(mapper)
    lazy5.is_evaluated = True
    lazy5.value = 3

    # then