

# Generated at 2022-06-24 00:07:05.053829
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(1).to_box().unbox() == 1, 'Lazy of 1 should be Box of 1.'
    assert Lazy(lambda: 1).to_box().unbox() == 1, 'Lazy of 1 should be Box of 1.'
    assert Lazy.of(Box(1)).to_box() == Box(1), 'Lazy of Box(1) should be Box(1).'


# Generated at 2022-06-24 00:07:06.798328
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(123).to_either() == Right(123)



# Generated at 2022-06-24 00:07:16.817962
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.monad_maybe import Maybe

    def fn(x):
        return x

    assert not Lazy(fn) == Functor.of(fn)
    assert not Lazy(fn) == Monad.of(1)
    assert not Lazy(fn) == Maybe.just(fn)
    assert not Lazy(fn) == None
    assert Lazy(fn) == Lazy(fn)
    assert not Lazy(fn) == Lazy(lambda x: x)
    assert not Lazy(fn) == Lazy(lambda x: x ** 2)
    assert not Lazy(fn) == Lazy(lambda x, y: x + y)



# Generated at 2022-06-24 00:07:20.320588
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    f = Lazy.of(lambda x: x+1)
    g = Lazy.of(42)

    result = f.ap(g).get()

    assert result == 43, "Result of ap must be 43"


# Generated at 2022-06-24 00:07:22.431373
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    @Lazy
    def x():
        raise ValueError("Oops!")
    assert x.to_either(1) == Right(1)

# Generated at 2022-06-24 00:07:24.765638
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    box = Lazy.of(1).to_box()
    assert box == Box(1)


# Generated at 2022-06-24 00:07:33.106097
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(11).get() == 11
    assert Lazy.of(11).constructor_fn() == 11
    assert Lazy.of(11).to_box().get() == 11
    assert Lazy.of(11).to_maybe().get() == 11
    assert Lazy.of(11).to_either().get() == 11
    assert Lazy.of(11).to_try().get() == 11
    assert Lazy.of(11).to_validation().get() == 11


# Generated at 2022-06-24 00:07:45.020181
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Either

    # Test for Lazy[A] => Lazy[A -> B]
    lazy = Lazy(lambda n: n)
    assert lazy.ap(Lazy(lambda v: lambda n: n + 1)).get(1) == 2
    assert lazy.ap(Lazy.of(lambda n: n + 1)).get(1) == 2
    # Test for Lazy[A] => Lazy[Box[A -> B]]
    assert lazy.ap(Lazy(lambda v: Box(lambda n: n + 1))).get(1) == 2

    # Test for Lazy[A] => Lazy[Either[A -> B]]

# Generated at 2022-06-24 00:07:48.078028
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def _constructor(*args):
        return 'some_value'

    lazy = Lazy(_constructor)

    assert lazy.to_validation(0, 1) == Validation.success('some_value')


# Generated at 2022-06-24 00:07:51.093971
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def fn(a):
        return a + 1

    maybe = Maybe.just(fn)
    assert Lazy.of(1).ap(maybe).get() == 2

# Generated at 2022-06-24 00:07:54.782566
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)

    assert Lazy.of(1) != Lazy.of(2)

    assert Lazy.of(1) != Lazy(lambda: 1)

    assert Lazy.of(1) != 1


# Generated at 2022-06-24 00:07:59.762485
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet import Lazy
    from pymonet.either import Left

    def fn(x):
        return x + 1

    lazy_fn = Lazy(lambda *args: fn)
    lazy_value = Lazy(lambda *args: 1)

    result = lazy_fn.ap(lazy_value)
    assert result.get() == 2

    result = lazy_value.ap(lazy_fn)
    assert result.get() == Left('Function is missing')

# Generated at 2022-06-24 00:08:06.959812
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x - 1).__eq__(Lazy(lambda x: x - 1)) and Lazy(lambda x: x - 1).__eq__(Lazy(lambda x: x - 1))
    assert Lazy(lambda x: x - 1).__eq__(Lazy(lambda x: x + 1)) is False
    assert Lazy(lambda x: x - 1) == Lazy(lambda x: x - 1)



# Generated at 2022-06-24 00:08:10.077907
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    def stub_fn(*args):
        return 'test'

    assert Lazy(stub_fn).to_either() == Right('test')



# Generated at 2022-06-24 00:08:13.256693
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x + 1).bind(lambda x: Lazy.of(x + 2)).get(1) == 4

# Generated at 2022-06-24 00:08:18.139082
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    f = lambda x: x + 1
    lazy = Lazy(f)
    either = lazy.to_either(1)

    assert isinstance(either, Right)
    assert either.get() == f(1)


# Generated at 2022-06-24 00:08:25.849429
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def function_one():
        return 1

    # implementation bind
    assert Lazy(function_one).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(2).bind(lambda x: Lazy.of(x + 1)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(2)).bind(lambda x: Lazy.of(x + 1)).get() == 3

    # implementation ap
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)).get() == 3



# Generated at 2022-06-24 00:08:27.752834
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy(lambda: 4).to_either() == Right(4)

# Generated at 2022-06-24 00:08:34.707940
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def add(a: int, b: int) -> int:
        return a + b

    assert Lazy(add).to_try(1, 2) == Try(add, 1, 2)
    assert Lazy(add).to_try(1, 'b') == Try(add, 1, 'b')
    assert Lazy(add).to_try(1, None) == Try(add, 1, None)
    assert Lazy(add).to_try(None, 1) == Try(add, None, 1)
    assert Lazy(add).to_try(1, 2) == Try.of(add, 1, 2)


# Generated at 2022-06-24 00:08:36.978479
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(4).map(lambda value: value * 2).get() == 8
    assert Lazy(lambda: 2).map(lambda value: value * 2).get() == 4

# Generated at 2022-06-24 00:08:40.165354
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Lazy.of(1).to_maybe()


# Generated at 2022-06-24 00:08:46.040013
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_value = Lazy.of(1)
    lazy_function = Lazy.of(lambda x: x + 1)
    assert lazy_value.ap(lazy_function).get() == 2

    lazy_value = Lazy.of(None)
    lazy_function = Lazy.of(lambda x: x + 1)
    assert lazy_value.ap(lazy_function).get() is None


# Generated at 2022-06-24 00:08:48.760283
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    # given
    lazy_with_13 = Lazy.of(13)

    # when
    maybe = lazy_with_13.to_maybe()

    # then
    assert(maybe == Maybe.just(13))



# Generated at 2022-06-24 00:08:52.050357
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def fn():
        return 'value'

    lazy = Lazy(fn)

    assert lazy.to_validation() == Validation.success('value')

# Generated at 2022-06-24 00:08:55.415606
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: '1').bind(lambda x: Lazy(lambda: str(int(x) + 3))).get() == '4'

# Generated at 2022-06-24 00:09:01.622764
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Error
    from pymonet.validation import is_success

    assert is_success({}, Validation.success('a').to_lazy().to_validation())
    assert is_success({}, Validation.failure([Error('err1'), Error('err2')]).to_lazy().to_validation())

# Generated at 2022-06-24 00:09:06.492088
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    lazy = Lazy.of(1)
    assert lazy.to_either() == Right(1)

    def failure(x):  # pylint: disable=unused-argument
        raise ValueError('failure')

    lazy2 = Lazy(failure)
    assert lazy2.to_either() == Right(None)



# Generated at 2022-06-24 00:09:08.728807
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation
    assert Lazy.of(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:09:14.565074
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def func_to_test(): return 10

    lazy = Lazy(func_to_test)
    assert lazy.to_box() == Box(10)



# Generated at 2022-06-24 00:09:21.793836
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add(a, b):
        return a + b

    def lazy_add(a):
        def add_a(b):
            return add(a, b)

        return Lazy(add_a)

    assert 'Lazy' == Lazy(lambda a: a).bind(lazy_add).get(1).value
    assert 2 == Lazy(lambda a: a + 1).bind(lazy_add).get(1)

test_Lazy_bind()

# Generated at 2022-06-24 00:09:24.865554
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x + 1).map(lambda x: x + 1).get(2) == 4
    assert Lazy(lambda x: 'p').map(lambda x: x + 'ymonet').get() == 'pymonet'


# Generated at 2022-06-24 00:09:33.389194
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    def fn(a, b):  # pragma: no cover
        return a + b

    notempty_box = Box(2)

    # Function stored in Lazy will be called only at the moment of calling fold method
    lazy = Lazy(lambda _: Box(1))

    assert(
        lazy.map(fn)
        .to_maybe()
        .fold(lambda _: Maybe.nothing(), lambda _: Maybe.just(2))
        == Maybe.just(3)
    )


# Generated at 2022-06-24 00:09:36.420390
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """
    >>> assert Lazy.of(3).to_either() == Right(3)
    >>> assert Lazy(lambda x: x + 3).to_either(5) == Right(8)
    """
    pass


# Generated at 2022-06-24 00:09:45.570775
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda: 3).get() == 3
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2
    assert Lazy(lambda: 1).map(lambda x: x + 1).ap(Lazy(lambda: 1)).get() == 2
    assert Lazy(lambda: 1).map(lambda x: x + 1).bind(lambda x: Lazy(lambda: 1)).get() == 1
    assert Lazy(lambda: 3).to_box().get_box_value() == 3
    assert Lazy(lambda: 1).to_either().get() == 1
    assert Lazy(lambda: 1).to_maybe().get_maybe_value() == 1
    assert Lazy(lambda: 1).to_try().get() == 1
    assert Lazy(lambda: 1).to_validation().get

# Generated at 2022-06-24 00:09:52.975253
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    """
    Test method to_maybe of class Lazy
    """
    from pymonet.maybe import Maybe

    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy.of(1).map(lambda x: x + 1).to_maybe() == Maybe.just(2)
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2


# Generated at 2022-06-24 00:09:57.225803
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    def add(a, b):
        return a + b

    lazy = Lazy(lambda: add(5, 6))

    assert lazy.to_box() == Box(11)


# Generated at 2022-06-24 00:10:06.145374
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.exchange_rate import ExchangeRateApi

    exchange_rate_api = ExchangeRateApi()

    res = Lazy(lambda: exchange_rate_api.get_exchange_rate('USD'))
    assert isinstance(res.to_box(), Box)
    assert res.to_box().get() == exchange_rate_api.get_exchange_rate('USD')

    assert res.map(lambda x: x.get('USD')).to_box().get() == exchange_rate_api.get_exchange_rate('USD').get('USD')


# Generated at 2022-06-24 00:10:09.647330
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    constructor_fn = lambda: lambda: 'test'
    test_result = Lazy(constructor_fn).bind(lambda f: Lazy(f)).constructor_fn()
    assert 'test' == test_result


# Generated at 2022-06-24 00:10:13.649096
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(x, y):
        return x + y

    lazy = Lazy(test_fn)
    assert lazy.get(2, 3) == 5

    lazy = Lazy(lambda: x)
    assert lazy.get() == lazy.get()



# Generated at 2022-06-24 00:10:18.204772
# Unit test for method map of class Lazy
def test_Lazy_map():
    evaled_value = 'evaled value'
    lazy_value = Lazy(lambda *args: evaled_value)
    mapped_lazy = lazy_value.map(lambda evaled_value: evaled_value + 'mapped')

    assert mapped_lazy.get() == evaled_value + 'mapped'



# Generated at 2022-06-24 00:10:24.798688
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def test_fn(x):
        return x * 2

    lazy_value = Lazy(lambda x: test_fn(x))

    assert lazy_value.to_either(2) == Right(4)



# Generated at 2022-06-24 00:10:26.528239
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(42).to_either() == Lazy.of(42)



# Generated at 2022-06-24 00:10:29.762750
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def function_to_test(x):
        return x + 3

    lazy1 = Lazy.of(3)
    lazy2 = Lazy.of(function_to_test)

    assert lazy1.ap(lazy2) == Lazy.of(6)



# Generated at 2022-06-24 00:10:37.174425
# Unit test for constructor of class Lazy
def test_Lazy():
    def test_lazy():
        return 'test'

    lazy = Lazy(test_lazy)

    assert lazy.get() == 'test'
    assert lazy.get() == 'test'
    assert lazy.get() == 'test'
    assert lazy.map(lambda v: v + '2').get() == 'test2'
    assert lazy.map(lambda v: v + '3').get() == 'test3'


# Generated at 2022-06-24 00:10:40.238860
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != 1


# Generated at 2022-06-24 00:10:46.115945
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.stream import Stream
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.monoid import Sum

    def increment(a):
        return a + 1

    def pow_2(a):
        return a ** 2

    def pow_3(a):
        return a ** 3

    def multiply_by_3(a):
        return a * 3

    def divide(a, b):
        return a / b

    assert Lazy.of(1).ap(Lazy.of(increment)) == Lazy.of(2)

# Generated at 2022-06-24 00:10:49.569189
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(2).bind(lambda x: Lazy.of(x + 3)).get() == 5



# Generated at 2022-06-24 00:10:54.430730
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation


    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).to_maybe().get() == 1
    assert Lazy.of(1).to_maybe().get(1, 2) == 1
    assert Lazy.of(1).to_validation().get() == 1
    assert Lazy.of(1).to_validation().get(1, 2) == 1
    assert Lazy.of(1).to_validation(1, 2, 3).get() == 1
    assert Lazy.of(1).to_validation(1, 2, 3).get(1, 2) == 1

# Generated at 2022-06-24 00:10:59.514929
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def simple_function():
        return 5

    lazy = Lazy(simple_function)
    maybe_result = lazy.to_maybe()

    assert maybe_result == Maybe.just(5)

# Generated at 2022-06-24 00:11:01.135926
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2



# Generated at 2022-06-24 00:11:01.998782
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    _test_Lazy_bind()



# Generated at 2022-06-24 00:11:05.370151
# Unit test for method map of class Lazy
def test_Lazy_map():
    def foo(x):
        return x * 2

    assert Lazy(lambda: 1).map(foo) == Lazy(lambda: 2)
    assert Lazy(lambda: 1).map(foo).map(lambda x: x * 2) == Lazy(lambda: 4)


# Generated at 2022-06-24 00:11:08.234760
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def my_fun(param):
        return param

    lazy = Lazy(my_fun)

    assert lazy.to_maybe(10) == Maybe.just(10)



# Generated at 2022-06-24 00:11:13.045786
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 2)) == 'Lazy[fn=<function <lambda> at 0x10e3ed9d8>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:11:24.863267
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add1(a: int) -> int:
        return a + 1

    def add2(a: int) -> int:
        return a + 2

    def add3(a: int) -> int:
        return a + 3

    def f(a: int) -> int:
        return a * 3

    lazy_instance = Lazy(f)
    lazy_instance_add1 = lazy_instance.map(add1)
    assert lazy_instance_add1.get(3) == 12
    assert lazy_instance_add1.is_evaluated
    assert not lazy_instance.is_evaluated

    lazy_instance_add2 = lazy_instance_add1.map(add2)
    assert lazy_instance_add2.get(3) == 14
    assert lazy_instance_add2.is_evaluated

# Generated at 2022-06-24 00:11:28.690859
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test for method get of class Lazy.
    """
    import pytest

    lazy_fn = lambda x: x * 2
    lazy_result = Lazy(lazy_fn).get(2)
    assert lazy_result == 4

    lazy_exception_function = lambda x: int('a')
    with pytest.raises(Exception):
        Lazy(lazy_exception_function).get(2)


# Generated at 2022-06-24 00:11:32.206419
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(5).to_box() == Box(5)


# Generated at 2022-06-24 00:11:44.600096
# Unit test for method get of class Lazy
def test_Lazy_get():
    def noerror(*args):
        return args

    def witherror(*args):
        raise RuntimeError('It is OK - we know that Lazy is lazy')

    lazy_noerror = Lazy(noerror)
    assert lazy_noerror.get(1, 2, 3) == (1, 2, 3)
    assert lazy_noerror.get(1, 2, 3) == (1, 2, 3)
    assert lazy_noerror.get(1, 2, 3) == (1, 2, 3)

    lazy_witherror = Lazy(witherror)

    try:
        assert lazy_witherror.get(1, 2, 3) == (1, 2, 3)
    except RuntimeError as e:
        assert str(e) == 'It is OK - we know that Lazy is lazy'



# Generated at 2022-06-24 00:11:47.757883
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def lazy_fn():
        return 2 + 2

    assert 'Lazy[fn={}, value={}, is_evaluated={}]'.format(lazy_fn, None, False) == str(Lazy(lazy_fn))


# Generated at 2022-06-24 00:11:50.329870
# Unit test for method get of class Lazy
def test_Lazy_get():
    def two():
        return 2

    assert Lazy(two).get() == 2
    assert Lazy(two).get() == 2


# Generated at 2022-06-24 00:11:59.035609
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn1(arg1):
        return Lazy(lambda: arg1 + 1)

    def fn2(arg1):
        return Lazy(lambda: arg1 + 1)

    value = Lazy(lambda x: x).bind(fn1).bind(fn2)

    assert value.get(1) == 3

    value = Lazy(lambda x: x).bind(fn1).bind(fn2).bind(lambda x: x + 1)

    assert value.get(1) == 4

    value = Lazy(lambda x: x).bind(lambda x: x + 1).bind(lambda x: x + 1)

    assert value.get(1) == 3



# Generated at 2022-06-24 00:12:03.661716
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: -1)
    assert Lazy(lambda: 1).map(lambda x: x + 1) != Lazy(lambda: 1).map(lambda x: x + 2)
    assert Lazy(lambda: 1).map(lambda x: x + 1) == Lazy(lambda: 1).map(lambda x: x + 1)



# Generated at 2022-06-24 00:12:10.285249
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from datetime import date
    from pymonet.functor import Functor

    def my_constructor(*args, **kwargs):  # pragma: no cover
        return date(2014, 1, 1)

    lazy = Lazy(my_constructor)
    assert str(lazy) == 'Lazy[fn=<function test_Lazy___str__.<locals>.my_constructor at 0x000002399AB566A8>, value=None, is_evaluated=False]'  # pragma: no cover

    lazy = Lazy.of('abc')
    assert str(lazy) == 'Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x0000023998F71598>, value=None, is_evaluated=False]'  # pragma: no cover


# Generated at 2022-06-24 00:12:14.270790
# Unit test for constructor of class Lazy
def test_Lazy():
    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<function test_Lazy.<locals>.<lambda> at 0x7f820a37ac80>, value=None, is_evaluated=False]'


# Tests for method of

# Generated at 2022-06-24 00:12:16.730860
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:12:23.681418
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    from pymonet.validation import Validation

    add_two = lambda x: x + 2
    divide_by_two = lambda x: x / 2

    # Call methods
    assert Lazy.of(10).to_maybe() == Maybe.just(10)
    assert Lazy.of(0).to_maybe() == Maybe.just(0)
    assert Lazy.of(-1).to_maybe() == Maybe.just(-1)

    assert Lazy.of(10).map(add_two).to_maybe() == Maybe.just(12)
    assert Lazy.of(0).map(add_two).to_maybe() == Maybe.just

# Generated at 2022-06-24 00:12:31.492520
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_Lazy___eq__for_evaluated_lazy():
        l1 = Lazy.of(1)
        l2 = Lazy.of(1)

        l1.get()

        assert l1 == l2

    def test_Lazy___eq__for_not_evaluated_lazy():
        l1 = Lazy.of(1)
        l2 = Lazy.of(1)

        assert l1 == l2

    test_Lazy___eq__for_evaluated_lazy()
    test_Lazy___eq__for_not_evaluated_lazy()

# Unit tests for method get of class Lazy and constructor

# Generated at 2022-06-24 00:12:39.334870
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(value):
        return value + 1

    lazy = Lazy(lambda: 10).map(add_one)

    # lazy is not evaluated
    assert lazy.is_evaluated is False
    assert lazy.value is None

    # lazy is evaluated and result is memoized
    assert lazy.get() == 11
    assert lazy.is_evaluated is True
    assert lazy.value == 11

    # Lazy is memoized and not evaluated when we call get() again
    assert lazy.get() == 11
    assert lazy.is_evaluated is True
    assert lazy.value == 11

    # is equal
    assert Lazy(lambda: 10).map(add_one) == lazy

    # not equal when constructed by different functions
    assert Lazy(lambda: 10).map(add_one) != Lazy(lambda: 20).map

# Generated at 2022-06-24 00:12:44.737457
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def function(number):
        return number * 2

    assert Lazy(lambda x: x) == Lazy(lambda x: x)
    assert Lazy(lambda x: x).ap(Lazy(function)) == Lazy(lambda x: 2 * x)
    assert Lazy(lambda x: x).ap(Lazy(function)).get(1) == 2
    assert Lazy(lambda x: x).ap(Lazy(function)).is_evaluated == True


# Generated at 2022-06-24 00:12:47.758973
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x: x + 1).ap(Lazy(lambda y: y + 2)) == Lazy(lambda x: x + 1).get(1) + 2


# Generated at 2022-06-24 00:12:49.813943
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.either import Left

    assert Left.of('foo') == Left.of('foo')
    assert Left.of('foo') != Left.of('bar')

# Generated at 2022-06-24 00:12:58.302943
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def test_fn():
        return 5
    lazy = Lazy(test_fn)
    assert lazy.__str__() == 'Lazy[fn=<function test_fn at 0x7f10a81a5158>, value=None, is_evaluated=False]'

    lazy.get()
    assert lazy.__str__() == 'Lazy[fn=<function test_fn at 0x7f10a81a5158>, value=5, is_evaluated=True]'



# Generated at 2022-06-24 00:13:05.948615
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of('a').get() == 'a'
    assert Lazy.of(1).map(lambda x: x * 10).get() == 10
    assert Lazy.of(1).map(lambda x: 'str' + str(x)).get() == 'str1'
    assert Lazy.of(1).map(lambda x: 'str' + str(x)) == Lazy(lambda x: 'str1')


# Generated at 2022-06-24 00:13:17.115629
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def positive(x: int) -> Lazy[int, int]:
        def fn(x: int) -> int:
            if x >= 0:
                return x
            raise ValueError('x is not positive')

        return Lazy(fn)

    assert Validation.success(5) == Lazy.of(5).bind(positive).to_validation()
    assert Validation.success(0) == Lazy.of(0).bind(positive).to_validation()
    assert Validation.failure(['x is not positive']) == Lazy.of(-1).bind(positive).to_validation()
    assert Validation.failure(['x is not positive']) == Lazy.of(-2).bind(positive).to_validation()


# Generated at 2022-06-24 00:13:23.493444
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x1134a0598>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:13:26.842390
# Unit test for method map of class Lazy
def test_Lazy_map():
    def map_to_2(value):
        return value * 2

    def map_to_10(value):
        return value * 10

    l = Lazy(lambda: 2)

    assert l.map(map_to_2).get() == 4
    assert l.map(map_to_10).get() == 20
    assert l.map(map_to_2).map(map_to_10).get() == 40



# Generated at 2022-06-24 00:13:36.377623
# Unit test for method __str__ of class Lazy
def test_Lazy___str__(): # pragma: no cover
    def func(a):
        raise Exception('It should not be called')
    lazy = Lazy(func)
    assert str(lazy) == 'Lazy[fn=<function test_Lazy___str__.<locals>.func at 0x7f1f18d3f730>, value=None, is_evaluated=False]'
    lazy._compute_value(8)
    assert str(lazy) == 'Lazy[fn=<function test_Lazy___str__.<locals>.func at 0x7f1f18d3f730>, value=None, is_evaluated=True]'


# Generated at 2022-06-24 00:13:41.165577
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    # Given
    lazy_unit_test = Lazy(lambda x: x * 2)

    # When
    either_unit_test = lazy_unit_test.to_either()

    # Then
    assert either_unit_test.value == lazy_unit_test.get()



# Generated at 2022-06-24 00:13:49.563441
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn1(a):
        if a == 1:
            return Lazy.of(2)
        return Lazy.of(1)

    def fn2(a):
        if a == 1:
            return Lazy.of(2)
        return Lazy.of(3)

    def test_fn(a):
        if a == 1:
            return 2
        return 3

    lazy_a = Lazy(fn1)
    lazy_b = lazy_a.bind(fn2)
    assert lazy_a == Lazy(fn1)
    assert lazy_b.get() == test_fn(test_fn(1))



# Generated at 2022-06-24 00:13:55.982746
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def func(x):
        return x + 1

    assert Lazy.of(2).to_try() == Try.just(2)
    assert Lazy.of(2).map(func).to_try() == Try.just(3)

    assert Lazy.of(2).map(lambda x: 1 / x).to_try() == Try.failure(ZeroDivisionError)
    assert Lazy(lambda x: 1 / x).of(2).to_try() == Try.failure(ZeroDivisionError)


# Generated at 2022-06-24 00:14:07.398866
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from functools import partial
    from pymonet.monad_maybe import Maybe

    def test_fn(test_val):
        def inner_fn(inner_val):
            return inner_val * test_val

        return inner_fn

    test_function = partial(test_fn, 5)

    test_lazy = Lazy(test_function)

    assert str(test_lazy) == 'Lazy[fn=<function Lazy.<locals>.test_fn.<locals>.inner_fn at 0x7faf40d21d08>, value=None, is_evaluated=False]'

    def test_fn_2(test_val):
        return test_val

    test_lazy = Lazy(test_fn_2)
    test_lazy.get(5)

   

# Generated at 2022-06-24 00:14:16.861051
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__(): # pragma: no cover
    from functools import partial

    def my_sum(x, y):
        return x + y

    def my_mul(x, y):
        return x * y

    f = partial(my_sum, 1)

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(partial(my_mul, 1))
    assert Lazy(f).map(lambda x: x + 1) == Lazy(f).map(lambda x: x + 1)
    assert Lazy(f).map(lambda x: x + 1) != Lazy(f).map(lambda x: x + 2)
    assert Lazy(f).map(lambda x: x + 1) != Lazy(partial(my_mul, 1))



# Generated at 2022-06-24 00:14:26.323923
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for Lazy.bind method.

    :returns: Nothing
    :rtype: NoReturn
    """
    class StringArray:
        def __init__(self, string_array):
            self.string_array = string_array


    def is_empty(string_array):
        return Lazy(lambda : len(string_array.string_array) == 0)


    def length(string_array):
        return Lazy(lambda : len(string_array.string_array))


    def string_array_to_string(string_array):
        return Lazy(lambda : string_array.string_array)


    def string_array_contain_q(string_array):
        return Lazy(lambda : 'q' in string_array.string_array)



# Generated at 2022-06-24 00:14:30.694628
# Unit test for method map of class Lazy
def test_Lazy_map():
    l = Lazy(lambda x: x * 2).map(lambda x: x + 1)
    assert l.get(20) == 41

    l = Lazy(lambda x: x * 2).map(lambda x: x + 1).map(lambda x: x - 2)
    assert l.get(20) == 39


# Generated at 2022-06-24 00:14:34.278648
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    lazy = Lazy(lambda x, y: x + y)

    assert lazy.map(Box).map(lambda x: x + 10).get(2, 3) == Box(5).map(lambda x: x + 10).get_value()



# Generated at 2022-06-24 00:14:40.499393
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.either import Either
    from pymonet.monad import bind
    from pymonet.monad_validation import bind_validation

    def div(a, b):  # type: ignore
        if b == 0:
            raise ZeroDivisionError()
        return a / b

    lazy = Lazy(lambda: div(4, 2))

    result = Try.of(div, 4, 2)
    assert result == Lazy.to_try(lazy)

    result = Try.of(lambda: div(4, 0))
    assert result == Lazy.to_try(Lazy(lambda: div(4, 0)))


# Generated at 2022-06-24 00:14:47.503964
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def get_value(value):
        return value

    def error_function(value):
        raise ValueError('Error {}'.format(value))

    assert Lazy.to_try(Lazy.of(get_value(1)), 1) == Try.success(1)
    assert Lazy.to_try(Lazy.of(error_function(1)), 1) == Try.failure(ValueError('Error 1'))



# Generated at 2022-06-24 00:14:48.949542
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of('test').bind(lambda x: Lazy.of(x + 'ing')).get() == 'testing'



# Generated at 2022-06-24 00:14:52.983533
# Unit test for constructor of class Lazy
def test_Lazy():
    import pytest

    def add(value):
        return value + 5

    assert Lazy.of(10).get() == 10
    assert Lazy(add).map(lambda value: value / 2).get(5) == 3.0


# Module level function for storage any type of function

# Generated at 2022-06-24 00:15:03.074965
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.either import Left, Right

    assert Lazy.of(lambda x: x + 2).ap(Lazy.of(2)).get() == 4
    assert Lazy.of(lambda x: x + 2).ap(Lazy.of(2)).to_maybe().get() == 4
    assert Lazy.of(lambda x: x + 2).ap(Lazy.of(2)).to_either().get() == 4
    assert Lazy.of(lambda x: x + 2).ap(Lazy.of(2)).to_box().get() == 4

# Generated at 2022-06-24 00:15:11.939705
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.either import Right

    def raise_error():
        raise Exception('error')

    assert Lazy(lambda: 1).to_try() == Try.of(lambda: 1)
    assert Lazy.of(1).to_try() == Try.of(lambda: 1)
    assert Lazy(lambda: 1).to_try().get() == 1
    assert Lazy(lambda: raise_error()).to_try().is_failed()
    assert Lazy(lambda: raise_error()).to_try().get_or_else(2) == 2
    assert Lazy(lambda: 1).to_try().map(lambda x: x + 1).get() == 2
    assert Lazy(lambda: 2).to_try().flatmap(Lazy.of).get()

# Generated at 2022-06-24 00:15:18.367060
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    success = Lazy.of(Validation.success(1))
    fail = Lazy.of(Validation.fail(2))
    assert success.to_validation() == Validation.success(1)
    assert fail.to_validation() == Validation.fail(2)


# Generated at 2022-06-24 00:15:25.886760
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    def f1():
        return 1

    def f2():
        return 2

    def f3():
        return 3

    lazy1 = Lazy(f1)
    lazy2 = Lazy(f2)
    lazy3 = Lazy(f3)

    assert lazy1.to_validation() == Validation.success(1)
    assert lazy2.to_validation() == Validation.success(2)
    assert lazy3.to_validation() == Validation.success(3)

# Generated at 2022-06-24 00:15:29.471961
# Unit test for method to_either of class Lazy
def test_Lazy_to_either(): # pragma: no cover
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)


# Generated at 2022-06-24 00:15:32.893477
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy.of(None).bind(lambda x: Lazy.of(1)) == Lazy.of(1)



# Generated at 2022-06-24 00:15:37.782216
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """Unit test for method bind of class Lazy"""

    from pymonet.validation import Validation

    constructor_fn = lambda x: x + 1
    lazy = Lazy(function=constructor_fn)

    def mapper_fn(value):
        return Lazy(lambda x: x * value)

    binded = lazy.bind(mapper_fn)
    assert binded.constructor_fn(2) == 6

    binded = lazy.bind(lambda x: Validation.success(x + 1))
    assert binded.constructor_fn(2) == Validation.success(3)



# Generated at 2022-06-24 00:15:42.247727
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy(lambda: 7).is_evaluated is False
    assert Lazy(lambda: 7).get() == 7
    assert Lazy(lambda: 7).is_evaluated is True



# Generated at 2022-06-24 00:15:46.200984
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def function(x):
        return 1 / x

    assert Lazy(function).to_try(1) == Try.of(function, 1)
    assert Lazy(function).to_try(0) == Try.of(function, 0)


# Generated at 2022-06-24 00:15:49.546469
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    """
    Unit test for method to_box of class Lazy
    """
    from pymonet.maybe import Maybe

    assert Lazy.of(5).to_box() == Maybe.just(5).to_box()
    assert Lazy(lambda: lambda x, y: x + y).to_box(1, 2) == Maybe.just(lambda x, y: x + y).to_box()


# Generated at 2022-06-24 00:15:55.023945
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def get_value():
        return Box('value')

    assert Lazy(get_value).to_maybe() == Maybe.just('value')



# Generated at 2022-06-24 00:16:01.692539
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    """
    >>> Lazy.of(5).to_maybe()
    Maybe.just(5):Maybe[A]
    >>> Lazy(lambda: 5).to_maybe()
    Maybe.just(5):Maybe[A]
    >>> Lazy(lambda x: x).to_maybe(5)
    Maybe.just(5):Maybe[A]
    >>> Lazy(lambda: 5).to_maybe(10)
    Maybe.just(5):Maybe[A]
    >>> Lazy(lambda x: x + 1).to_maybe(5)
    Maybe.just(5):Maybe[A]
    """


# Generated at 2022-06-24 00:16:04.230594
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # type: () -> None
    from pymonet.either import Right

    assert Lazy.of(123).to_either() == Right(123)



# Generated at 2022-06-24 00:16:06.918071
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    Lazy.of(lambda x: x * x).ap(Lazy.of(lambda x: x * 2)).ap(Lazy.of(8))



# Generated at 2022-06-24 00:16:16.587401
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_try import TryError

    def lazy_constructor(a):
        return a

    # Lazy(Function)
    lazy_expect = Lazy(lazy_constructor)
    assert type(lazy_expect) == Lazy
    assert lazy_expect.constructor_fn == lazy_constructor
    assert lazy_expect.is_evaluated is False
    assert lazy_expect.value is None

    # map(Function) -> Lazy
    lazy_mapped = lazy_expect.map(lambda v: v + '1')
    assert type(lazy_mapped) == Lazy
    assert lazy_mapped.constructor_fn == lazy_constructor
    assert lazy_mapped.is_evaluated is False
   

# Generated at 2022-06-24 00:16:18.560838
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(3) == Lazy.of(3)
    assert Lazy(lambda: 3) == Lazy(lambda: 3)

    assert Lazy.of(3) != Lazy(lambda: 3)
    assert Lazy.of(4) != Lazy.of(3)


# Generated at 2022-06-24 00:16:23.198760
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    def add(value: int) -> int:
        return value + 10

    def mult(value: int) -> int:
        return value * 10

    assert Maybe.just(10).ap(Maybe.just(mult)).bind(lambda x: Maybe.just(x / 10)) == Maybe.just(10)

    assert Lazy(lambda: Maybe.just(10)).ap(Lazy(lambda: Maybe.just(mult))).bind(lambda x: Maybe.just(x / 10)) == Maybe.just(10)

    assert Box.pure(10).ap(Box.pure(add)).bind(lambda x: Box.pure(x / 10)) == Box.pure(10)


# Generated at 2022-06-24 00:16:27.164206
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x).bind(lambda x: x).get(1) == 1
    assert Lazy(lambda x: x).bind(
        lambda x: Lazy(lambda y: x + y)
    ).get(1, 1) == 2

# Generated at 2022-06-24 00:16:30.406219
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    def f():
        return 10

    lazy = Lazy(f)
    value = lazy.to_validation()
    assert isinstance(value, Validation)
    assert value == Validation.success(10)


# Generated at 2022-06-24 00:16:36.215456
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    def multiply_2(num):
        return 2 * num

    def is_zero(num):
        return num == 0

    assert multiply_2(2) == 4

    lazy = Lazy.of(2)
    lazy = lazy.bind(lambda x: Lazy.of(multiply_2(x)))
    assert lazy.to_either() == Right(4)

    lazy = Lazy.of(2)
    lazy = lazy.bind(lambda x: Lazy.of(multiply_2(x)))
    assert lazy.to_either().map(is_zero).get_or_else(False) is False

# Generated at 2022-06-24 00:16:38.641126
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box

    assert Lazy.of('test').to_maybe() == Box('test').to_maybe()

# Generated at 2022-06-24 00:16:47.357552
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def decorator(fn):
        def decorated(*args):
            print('call decorated function')
            return fn(*args)
        return decorated

    def decorator_wrap(fn: Callable[[str], int]) -> Callable[[str], int]:
        print('call decoratoe_wrap')
        return decorator(fn)

    lazy_fn = Lazy(lambda *args: 2 * args[0])
    lazy_fn_decorated = lazy_fn.map(decorator_wrap)
    lazy_apply = lazy_fn_decorated.ap(lazy_fn)

    assert lazy_apply.get(2) == 8

# Generated at 2022-06-24 00:16:51.589856
# Unit test for constructor of class Lazy
def test_Lazy():
    def f(x):
        return x

    assert Lazy(f).constructor_fn(1) == 1



# Generated at 2022-06-24 00:17:00.765152
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    assert str(Lazy(lambda: 'fake')) == 'Lazy[fn=<function <lambda> at {}>, value=None, is_evaluated=False]'.format(
        hex(id(lambda: 'fake')))
    assert str(Lazy(lambda: None)) == 'Lazy[fn=<function <lambda> at {}>, value=None, is_evaluated=False]'.format(
        hex(id(lambda: None)))
    assert str(Lazy(lambda: Functor.of(''))) == 'Lazy[fn=<function <lambda> at {}>, value=None, is_evaluated=False]'.format(
        hex(id(lambda: Functor.of(''))))
   