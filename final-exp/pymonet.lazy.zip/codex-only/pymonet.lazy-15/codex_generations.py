

# Generated at 2022-06-24 00:06:57.733408
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Given
    lazy = Lazy(lambda: 'END')

    # When
    value = lazy.get()

    # Then
    assert value == 'END'



# Generated at 2022-06-24 00:07:07.197780
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe

    lazy_none = Lazy(lambda x: Maybe(None))
    assert Right(None) == lazy_none.to_either(5)

    lazy_zero = Lazy(lambda x: Maybe(0))
    assert Right(0) == lazy_zero.to_either(5)

    def raise_exception(value):
        raise ValueError('Error')

    lazy_exception = Lazy(raise_exception)
    assert isinstance(lazy_exception.to_either(5), Left)


# Generated at 2022-06-24 00:07:17.526593
# Unit test for constructor of class Lazy
def test_Lazy():
    from unittest import TestCase, main

    class LazyTest(TestCase):
        def test_Lazy_of_return_Lazy_with_function_returning_argument(self):
            lazy = Lazy.of(5)
            self.assertTrue(isinstance(lazy, Lazy))
            self.assertEqual(lazy._compute_value(), 5)

        def test_Lazy_map_returns_Lazy_with_mapped_constructor_function(self):
            lazy = Lazy.of(5).map(lambda v: v + 5)
            self.assertEqual(lazy._compute_value(), 10)

        def test_Lazy_bind_returns_function_result_for_call_of_Lazy(self):
            def plus_5(v):
                return Lazy

# Generated at 2022-06-24 00:07:19.518998
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)

# Generated at 2022-06-24 00:07:26.821925
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.monoid import Sum

    lazy = Lazy(lambda: Try(lambda: Sum(5)).get)
    assert lazy.to_box() == Box(Sum(5))
    lazy_empty = Lazy(lambda: Try(lambda: None).get)
    assert lazy_empty.to_box() == Box(None)



# Generated at 2022-06-24 00:07:30.978802
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    assert Functor.test_functor_laws(Lazy, lambda *args: 1, lambda *args: 2)
    assert Applicative.test_applicative_laws(Lazy, lambda *args: 1, lambda *args: 2)
    assert Monad.test_monad_laws(Lazy, lambda *args: 1, lambda *args: 2)



# Generated at 2022-06-24 00:07:32.911202
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2



# Generated at 2022-06-24 00:07:35.656982
# Unit test for constructor of class Lazy
def test_Lazy():
    fn = lambda x: x

    lazy = Lazy(fn)

    assert lazy.constructor_fn == fn
    assert lazy.is_evaluated is False



# Generated at 2022-06-24 00:07:41.351242
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    a_lazy = Lazy(lambda x: x)
    b_lazy = Lazy(lambda x: x + 1)
    assert a_lazy != b_lazy

    a_lazy = Lazy(lambda x: 'test')
    b_lazy = Lazy(lambda x: 'test')
    assert a_lazy == b_lazy



# Generated at 2022-06-24 00:07:49.753193
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    result = Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1)).get()
    assert result == 2

    result = Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1)).ap(Lazy(lambda: 2)).get()
    assert result == 3

    result = Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1)).ap(Lazy(lambda: 2)).ap(Lazy(lambda : 3)).get()
    assert result == 4

    result = Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1)).ap(Lazy(lambda: 2)).ap(Lazy(lambda : 3)).ap(Lazy(lambda : 4)).get()
    assert result == 5


# Generated at 2022-06-24 00:07:55.502189
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(5).ap(Lazy.of(lambda x, y: x + y)).get(1, 2) == 8
    assert Lazy.of(5).ap(Lazy.of(lambda x, y: x + y)).get(1, 2) == 8
    assert Lazy.of(5).ap(Lazy.of(lambda x, y: x + y)).get(1, 2) == 8

# Generated at 2022-06-24 00:07:56.420707
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:08:00.534246
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    """
    Test method to_box of class Lazy.
    """
    from pymonet.box import Box

    lazy_value = Lazy.of(Box.of(1)).to_box()
    assert isinstance(lazy_value, Box), 'Lazy.to_box() should return Box'
    assert lazy_value == Box.of(1), 'Lazy.to_box() should return Box with lazy function result.'


# Generated at 2022-06-24 00:08:03.110568
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    lazy = Lazy(lambda *args: 'value')

    assert str(lazy) == 'Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x7fbb42b0f488>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:08:08.288277
# Unit test for constructor of class Lazy
def test_Lazy(): # pragma: no cover
    from pymonet.monad_try import Try

    def test_fn(*args):
        return args[0] if len(args) > 0 and args[0] < 10 else 0

    def test_mapper(value):
        return value * 10

    lazy = Lazy(test_fn)
    assert lazy.get(1, 2, 3) == 1
    assert lazy.get(20) == 0
    assert lazy.map(test_mapper).get(1, 2, 3) == 10
    assert lazy.map(test_mapper).get(20) == 0
    assert lazy.bind(lambda x: Try.of(lambda y: x + y, 10)).get(1, 2, 3) == 11

# Generated at 2022-06-24 00:08:13.416049
# Unit test for constructor of class Lazy
def test_Lazy():
    def constructor_fn(*args):
        return args[0] * 2

    lazy = Lazy(constructor_fn)

    assert lazy.value is None
    assert lazy.is_evaluated is False
    assert lazy.constructor_fn(2) == 4
    assert lazy.value is None
    assert lazy.is_evaluated is False
    assert lazy.get(2) == 4
    assert lazy.value == 4
    assert lazy.is_evaluated



# Generated at 2022-06-24 00:08:15.940257
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    def constructor_fn():
        return Box("test")
    lazy = Lazy(constructor_fn)
    assert lazy.to_box() == Box("test")
    assert lazy.to_box() == lazy.to_box()


# Generated at 2022-06-24 00:08:25.606461
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right
    from pymonet.box import Box

    plus = lambda a, b: a + b
    minus = lambda a, b: a - b
    multiply = lambda a, b: a * b
    divide = lambda a, b: a / b
    power = lambda a, b: pow(a, b)

    plus_lazy = Lazy(lambda: plus)
    minus_lazy = Lazy(lambda: minus)
    multiply_lazy = Lazy(lambda: multiply)
    divide_lazy = Lazy(lambda: divide)
    power_lazy = Lazy(lambda: power)

    assert plus_lazy.ap(Box(1)) == Lazy(lambda: plus(1, None))

# Generated at 2022-06-24 00:08:32.605069
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    lazy_with_exception = Lazy.of(1/0)
    assert isinstance(lazy_with_exception.to_try(), Try)
    assert lazy_with_exception.to_try().is_failure()
    assert lazy_with_exception.to_try().get_exception() is not None

    lazy_successful = Lazy.of(1)
    assert isinstance(lazy_successful.to_try(), Try)
    assert lazy_successful.to_try().is_success()
    assert lazy_successful.to_try().get() == 1


# Generated at 2022-06-24 00:08:34.102193
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda: 1).to_box() == Box(1)


# Generated at 2022-06-24 00:08:36.489665
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(1).to_box() == Box(1)
    assert Lazy.of(2).map(lambda x: x * 2).to_box() == Box(4)

# Generated at 2022-06-24 00:08:41.110873
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda x: x + x).to_box(2) == Box(4)
    assert Lazy(lambda x: x + 1).to_box(None) == Box(None)


# Generated at 2022-06-24 00:08:43.997443
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x, y: x + y).ap(Lazy.of(1)).ap(Lazy.of(2)).get() == 3


# Generated at 2022-06-24 00:08:49.808746
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Lazy.of(2).to_maybe() == Maybe.just(2)
    assert Lazy.of(2).map(lambda a: a * 2).to_maybe() == Maybe.just(4)
    assert Lazy.of(2).ap(Lazy.of(lambda a: a * 2)) == Maybe.just(4)
    assert Lazy.of(2).bind(lambda a: Lazy.of(a * 2)).to_maybe() == Maybe.just(4)


# Generated at 2022-06-24 00:08:58.124578
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.validation import Validation

    def func(a):
        return a + 10

    lazy = Lazy.of(2).map(func)

    assert lazy.get() == 12

    lazy = Lazy.of(2).map(lambda a: a).to_box()

    assert lazy == Box(2)

    lazy = Lazy.of(2).map(lambda a: a).to_validation()

    assert lazy == Validation.success(2)


# Generated at 2022-06-24 00:09:03.446831
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def value() -> Either[str, int]:
        return Maybe.just(5).to_either()
    a_value = Lazy(value)

    assert a_value.to_either() == Right(5)



# Generated at 2022-06-24 00:09:12.398335
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 2).map(lambda x: x + 1) == Lazy(lambda: 3)
    assert Lazy(lambda: 2).map(lambda x: x + 1).fold(lambda x: x) == 3
    assert Lazy(lambda: 2).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy(lambda: 4)
    assert Lazy(lambda: 1).map(lambda x: x + 2).bind(lambda x: Lazy(lambda: x + 1)).fold(lambda x: x) == 4
    assert Lazy(lambda x: x + 2).map(lambda x: x + 2).bind(lambda x: Lazy(lambda: x + 1)) == Lazy(lambda x: x + 5)
    assert Lazy(lambda: 2).map(lambda x: x + 1).map

# Generated at 2022-06-24 00:09:15.347167
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    to_str = lambda x: str(x)
    add_str = lambda x: Lazy.of(x + 'str')

    assert Lazy.of(3).bind(add_str).bind(to_str) == Lazy.of('3str')

# Generated at 2022-06-24 00:09:20.704621
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f():
        return 'Hello'

    lazy1 = Lazy(f)

    def g():
        pass

    lazy2 = Lazy(g)

    assert lazy1 == lazy1
    assert not lazy1 != lazy1

    assert lazy1 != lazy2


# Generated at 2022-06-24 00:09:28.425441
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.box import Box
    from pymonet.util.test_utils import assert_test_case

    factory = lambda x: Lazy(lambda *args: x)


    assert_test_case(expected='Lazy[fn=<function <lambda> at 0x7f35561526a8>, value=None, is_evaluated=False]',
                     actual=factory(1).__str__())
    assert_test_case(expected='Lazy[fn=<function <lambda> at 0x7f3556152840>, value=2, is_evaluated=True]',
                     actual=factory(2).get().__str__())

# Generated at 2022-06-24 00:09:31.211667
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Given
    value = 5
    lazy_computation = Lazy.of(value)

    # When
    result = lazy_computation.get()

    # Then
    assert result == value



# Generated at 2022-06-24 00:09:34.567567
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def fn():
        pass

    lazy = Lazy(fn)
    expected = 'Lazy[fn={}, value={}, is_evaluated={}]'.format(fn, None, False)

    assert lazy.__str__() == expected



# Generated at 2022-06-24 00:09:38.092362
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def fn(*args):
        return args

    lazy = Lazy(fn)

    assert str(lazy) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x7ffb2c2b3840>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:09:41.964459
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def maybe_add(value):
        return Maybe(value + 10)

    lazy = Lazy(lambda x: maybe_add(x)).bind(lambda x: Lazy(lambda *args: x))
    assert lazy.to_maybe(10) == Maybe(20)
    assert lazy.to_maybe(None) == Maybe(None)


# Generated at 2022-06-24 00:09:46.900490
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    """
    Unit test for method to_maybe of class Lazy
    """
    from pymonet.maybe import Maybe

    class A:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    def fn(a):
        return A(1, a)

    assert Lazy(fn).to_maybe(3) == Maybe.just(A(1, 3))



# Generated at 2022-06-24 00:09:57.670107
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.error import Error
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(1).to_either(2) == Right(1)
    assert Lazy.of(1).map(lambda x: str(x)).to_either() == Right('1')
    assert Lazy.of(1).map(lambda x: str(x)).to_either(2) == Right('1')

    lazy_mapper = Lazy(lambda x: Maybe.just(x))
    assert lazy_mapper.ap(Lazy(lambda x: x))

# Generated at 2022-06-24 00:10:06.009900
# Unit test for method get of class Lazy
def test_Lazy_get():
    sample_list = [1, 2, 3, 4]
    sample_fn = lambda: sample_list[0]
    sample_lazy = Lazy(sample_fn)
    assert sample_lazy.get() == 1
    assert sample_lazy.is_evaluated is True
    assert sample_lazy.value == 1
    sample_fn = lambda: sample_list[1]
    sample_lazy = Lazy(sample_fn)
    assert sample_lazy.get() == 2
    assert sample_lazy.is_evaluated is True
    assert sample_lazy.value == 2
    sample_fn = lambda: sample_list[2]
    sample_lazy = Lazy(sample_fn)
    assert sample_lazy.get() == 3
    assert sample_lazy.is_evaluated is True


# Generated at 2022-06-24 00:10:08.897905
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(10).get() == 10
    assert Lazy.of(None).get() is None
    assert Lazy.of('a').get() == 'a'



# Generated at 2022-06-24 00:10:10.448127
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(1).to_box() == Box(1)


# Generated at 2022-06-24 00:10:20.551379
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    import unittest
    from pymonet.maybe import Maybe

    class TestLazy(unittest.TestCase):
        def test_when_Lazy_not_evaluated_then_return_value_of_Lazy_constructor_function(self):
            def test_fn(*args):
                test_fn.called += 1
                return 1

            test_fn.called = 0
            lazy = Lazy(test_fn)
            self.assertEqual(lazy.get(), 1)
            self.assertEqual(test_fn.called, 1)
            self.assertEqual(lazy.get(), 1)
            self.assertEqual(test_fn.called, 1)


# Generated at 2022-06-24 00:10:22.158066
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy(lambda: 1).to_box() == Box(1)


# Generated at 2022-06-24 00:10:27.366627
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def func():
        return 'value'

    assert str(Lazy(func)) == 'Lazy[fn={}, value=None, is_evaluated=False]'.format(func)
    assert str(Lazy(func).map(lambda x: x)) == 'Lazy[fn={}, value=None, is_evaluated=False]'.format(func)


# Generated at 2022-06-24 00:10:30.465770
# Unit test for method map of class Lazy
def test_Lazy_map():
    def sum(a, b):
        return a + b

    lazy = Lazy(sum)
    mapped_lazy = lazy.map(lambda a: a * 2)
    result = mapped_lazy.get(2, 3)
    assert result == 10



# Generated at 2022-06-24 00:10:39.502340
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.collections import Seq

    assert Lazy(lambda x: x + 2).ap(Box(2)) == Box(4)
    assert Lazy(lambda x: x + 2).ap(Box(None)) == Box(None)
    assert Lazy(lambda x: x + 2).ap(Seq(2)) == Seq(4)
    assert Lazy(lambda x: x + 2).ap(Seq(2, 20)) == Seq(4, 22)



# Generated at 2022-06-24 00:10:45.800264
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    def test_either(result: bool):
        return Right(result)

    assert Lazy.of(True).to_either() == test_either(True)

    assert Lazy(lambda: True).to_either() == test_either(True)

    def test_either_with_args(result: bool, arg):
        return Right(result)

    assert Lazy(test_either_with_args).to_either(True, 2) == test_either_with_args(True, 2)

    assert Lazy(lambda: test_either_with_args).to_either(True, 2) == test_either_with_args(True, 2)


# Generated at 2022-06-24 00:10:51.767351
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Testing modul lazy
    """
    from pymonet.monad_maybe import Maybe

    def five_times_two(*_):
        return 10

    result = Lazy(five_times_two).get()
    assert result == 10

    def ten_times_two(*_):
        return 20

    result = Lazy(ten_times_two) == Lazy(five_times_two)
    assert not result

    result = Lazy(ten_times_two).map(lambda x: x / 2.0).get()
    assert result == 10.0

    result = Lazy(ten_times_two).bind(lambda x: Lazy(lambda *_: x * x)).get()
    print(result)
    assert result == 400


# Generated at 2022-06-24 00:10:57.862043
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def my_func():
        return 1

    lazy = Lazy(my_func)
    assert str(lazy) == 'Lazy[fn=<function test_Lazy___str__.<locals>.my_func at 0x10b348668>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:11:07.237878
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation() == Validation.success(1)
    assert Lazy.of([1]).to_validation() == Validation.success([1])
    assert Lazy.of(Box(1)).to_validation() == Validation.success(Box(1))
    assert Lazy.of(Right(1)).to_validation() == Validation.success(Right(1))
    assert Lazy.of(Maybe.just(1)).to_validation() == Validation.success(Maybe.just(1))

# Generated at 2022-06-24 00:11:09.787937
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(5).to_box() == Box(5)


# Generated at 2022-06-24 00:11:13.296455
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda n: n).constructor_fn(1) == 1



# Generated at 2022-06-24 00:11:15.079165
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy.of('A').to_validation() == Validation.success('A')



# Generated at 2022-06-24 00:11:24.304757
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = lambda: 1
    g = lambda: 1
    lazy_1 = Lazy(f)
    lazy_2 = Lazy(f)
    lazy_3 = Lazy(g)
    lazy_4 = Lazy(g)

    assert lazy_1 == lazy_2
    assert lazy_2 == lazy_1
    assert lazy_3 == lazy_4
    assert lazy_4 == lazy_3
    assert lazy_1 != lazy_3
    assert lazy_3 != lazy_1
    assert lazy_1 != lazy_4
    assert lazy_4 != lazy_1



# Generated at 2022-06-24 00:11:26.853022
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(42).get() == 42
    assert Lazy.of(42).get(1, 2) == 42
    assert Lazy.of(42).get(1, 2, 3) == 42



# Generated at 2022-06-24 00:11:29.761683
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    def adder(a, b):
        return a + b
    assert Lazy(adder).to_validation(1, 2) == Validation.success(3)



# Generated at 2022-06-24 00:11:33.841694
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    lazy = Lazy(lambda x: 4 * x)
    assert lazy.to_box() == Box(4 * lazy.constructor_fn(0))



# Generated at 2022-06-24 00:11:44.710007
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    first_lazy = Lazy(lambda x: x)
    second_lazy = Lazy(lambda x: x)
    assert first_lazy.__eq__(second_lazy) is True

    first_lazy = Lazy(lambda x: x)
    second_lazy = Lazy(lambda y: y)
    assert first_lazy.__eq__(second_lazy) is False

    first_lazy = Lazy(lambda x: x)
    second_lazy = Lazy(lambda x: x)
    first_lazy.get()
    second_lazy.get()
    assert first_lazy.__eq__(second_lazy) is True

    first_lazy = Lazy(lambda x: x)

# Generated at 2022-06-24 00:11:48.237774
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def dummy_fn():
        return True

    lazy = Lazy(dummy_fn)
    assert str(lazy) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(dummy_fn, lazy.value, lazy.is_evaluated)



# Generated at 2022-06-24 00:11:58.390715
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(*args):
        return args

    map_fn = lambda arg: arg
    assert Lazy(test_fn).get('whatever') == test_fn('whatever')
    assert Lazy(test_fn).get(1, 'whatever') == test_fn(1, 'whatever')
    assert Lazy(test_fn).get(Box(1), 'whatever') == test_fn(Box(1), 'whatever')
    assert Lazy(test_fn).get(1, Right(1)) == test_fn(1, Right(1))

# Generated at 2022-06-24 00:12:02.983966
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    def thrower():
        raise ValueError('Error message')

    assert Lazy.of(1).to_try() == Try.success(1)
    assert Lazy(thrower).to_try() == Try.failure(Failure(ValueError('Error message'))) == Try.failure(Failure(ValueError('Error message')))



# Generated at 2022-06-24 00:12:08.456577
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    def add_one(x: int) -> Functor[int]:
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(add_one).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy(add_one).ap(Lazy.of(lambda y: y + 1))).get() == 3



# Generated at 2022-06-24 00:12:14.362095
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    Testing constructor of Lazy class.
    """
    def test_function_for_lazy(*args):
        return args

    # Simple case
    def test_lazy_constuctor_function():
        lazy = Lazy(test_function_for_lazy)

        assert lazy.constructor_fn == test_function_for_lazy

    test_lazy_constuctor_function()



# Generated at 2022-06-24 00:12:19.195909
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add_multiply_on_3(a: int,  b: int) -> int:
        return a + b * 3

    assert Lazy(add_multiply_on_3).get(2, 3) == 11
    assert Lazy(add_multiply_on_3).get(2, 0) == 2
    assert Lazy(add_multiply_on_3).get(0, 2) == 6


# Generated at 2022-06-24 00:12:25.569770
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def increment(value):
        return value + 1

    def twice(value):
        return value * 2

    def twice_and_increment(value):
        return twice(increment(value))

    twice_increment_lazy = Lazy.of(1).bind(twice_and_increment)
    assert twice_increment_lazy.get(None) == 4



# Generated at 2022-06-24 00:12:28.188710
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def func():
        raise ValueError('error')

    assert Lazy(func).to_try() == Try.failure(ValueError)

# Generated at 2022-06-24 00:12:36.632777
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Lazy.of(1).to_try() == Try(lambda: 1)
    assert Lazy.of('a').to_try() == Try(lambda: 'a')
    # assert Lazy.of('').to_try() == Try(lambda: Lazy.of('').get())
    assert Lazy.of('').to_try() == Try(lambda: '')
    assert Lazy.of(Maybe.just(2)).to_try() == Try(lambda: Maybe.just(2))

# Generated at 2022-06-24 00:12:46.130239
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Lazy(lambda: 1).to_validation() == Validation.success(1)
    assert Lazy(lambda: 'str').to_validation() == Validation.success('str')
    assert Lazy(lambda: (1, 2)).to_validation() == Validation.success((1, 2))
    assert Lazy(lambda: (1, 2, 3)).to_validation() == Validation.success((1, 2, 3))
    assert Lazy(lambda: []).to_validation() == Validation.success([])
    assert Lazy(lambda: {}).to_validation() == Validation.success({})

# Generated at 2022-06-24 00:12:50.199874
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Unit test for method ap of class Lazy
    """
    def add(x, y):
        return x + y

    lazy = Lazy(lambda x: (lambda y: add(x, y)))

    assert lazy.ap(Lazy(lambda: 1)).get() == 2
    assert lazy.ap(Lazy(lambda: 2)).get() == 3


# Generated at 2022-06-24 00:12:51.635163
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(1) == Lazy(lambda: 1)



# Generated at 2022-06-24 00:13:01.632578
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Lazy.of(2).ap(Lazy.of(lambda x: x + 2)) == Lazy.of(4)
    assert Lazy.of(2).ap(Box.of(lambda x: x + 2)) == Lazy.of(4)
    assert Lazy.of(2).ap(Try.of(lambda x: x + 2)) == Lazy.of(4)
    assert Lazy.of(2).ap(Validation.success(lambda x: x + 2)) == Lazy.of(4)

# Generated at 2022-06-24 00:13:05.017442
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation(): #pragma: no cover
    from pymonet.validation import Validation

    lazy = Lazy.of('val')

    assert lazy.to_validation() == Validation.success('val')

# Generated at 2022-06-24 00:13:15.716863
# Unit test for constructor of class Lazy
def test_Lazy():
    assert (Lazy(lambda: 6) == Lazy(lambda: 6))
    assert (Lazy(lambda: 7) == Lazy(lambda: 7))
    assert (Lazy(lambda: 6) != Lazy(lambda: 7))
    assert (Lazy(lambda: 6) != Lazy(lambda: 1 + 5))
    assert (Lazy(lambda: 6) == Lazy(lambda: 1 + 5))
    assert (Lazy(lambda: 7) != Lazy(lambda: 1 + 6))
    assert str(Lazy(lambda: 6)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x10e9d4598>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:13:18.457614
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:13:23.814924
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    try_fn = lambda x: x + 1
    lazy_fn = Lazy(try_fn)
    try_monad = lazy_fn.to_try(1)
    assert isinstance(try_monad, Try)
    assert try_monad.get() == 2

# Generated at 2022-06-24 00:13:30.386550
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 10).get() == 10
    assert Lazy(lambda input_value: input_value).get(10) == 10
    assert Lazy(sum).get([1, 2]) == 3
    assert Lazy(sum).map(lambda x: x * x).get([1, 2]) == 9

    assert Lazy(sum).get([1, 2]) == 3
    assert Lazy(sum).get([1, 2]) == 3
    assert Lazy(sum).get([1, 2]) == 3
    assert Lazy(sum).map(lambda x: x * x).get([1, 2]) == 9


# Generated at 2022-06-24 00:13:33.959544
# Unit test for constructor of class Lazy
def test_Lazy():
    # Given
    value = 100

    # When
    lazy = Lazy.of(value)

    # Then
    assert lazy == Lazy(lambda *args: value)



# Generated at 2022-06-24 00:13:43.065001
# Unit test for constructor of class Lazy
def test_Lazy():
    def sum_two_numbers(n1, n2):
        return n1 + n2

    lazy = Lazy(sum_two_numbers).ap(Lazy.of(2))
    assert lazy.constructor_fn(4) == 6

    lazy = Lazy(sum_two_numbers)
    assert lazy.map(lambda n: n * 2).constructor_fn(4, 1) == 10
    assert lazy.map(lambda n: n * 2).get(4, 1) == 10
    assert lazy.map(lambda n: n * 2).get(4, 1) == 10

    lazy = Lazy(sum_two_numbers)
    assert lazy.bind(lambda m: Lazy(lambda: m * 2)).constructor_fn(4, 1) == 10

# Generated at 2022-06-24 00:13:49.992161
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of('ho').to_either() == Right('ho')
    assert Lazy.of(True).to_either() == Right(True)
    assert Lazy.of(False).to_either() == Right(False)
    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(set(range(1000))).to_either() == Right(set(range(1000)))



# Generated at 2022-06-24 00:13:56.300007
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.monad_try import Try

    def constructor_fn():
        return 'success'

    assert Right('success') == Lazy(constructor_fn).to_either()
    assert Right('success') == Lazy(constructor_fn).to_either()
    assert constructor_fn() == Lazy(constructor_fn).to_either().get()
    assert constructor_fn() == Lazy(constructor_fn).to_either().fold(lambda err, a: a, lambda a: a)



# Generated at 2022-06-24 00:13:57.110219
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    pass

# Generated at 2022-06-24 00:14:06.054317
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    lazy_values = [
        Lazy.of(1),
        Lazy.of(True).to_box(),
        Lazy.of(True).to_validation(),
        Lazy.of(True).to_maybe(),
        Lazy.of(None)
    ]

    for lazy_value in lazy_values:
        assert lazy_value.to_either() == Right(lazy_value.get())

# Generated at 2022-06-24 00:14:17.832531
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test ap method on Lazy monad.
    """
    def add_fn(a, b):
        return a + b

    def sub_fn(a, b):
        return a - b

    def mul_fn(a, b):
        return a * b

    add_lazy = Lazy.of(add_fn)
    sub_lazy = Lazy.of(sub_fn)
    mul_lazy = Lazy.of(mul_fn)
    add_ap_lazy = add_lazy.ap(add_lazy)
    sub_ap_lazy = sub_lazy.ap(sub_lazy)
    mul_ap_lazy = mul_lazy.ap(mul_lazy)
    assert add_ap_lazy.get(1, 2) == 4


# Generated at 2022-06-24 00:14:27.369226
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.monad_state import State
    from pymonet.monad_writer import Writer
    from pymonet.monad_reader import Reader

    def fn(x: int) -> Try[int]:
        return Try.of(lambda: int(x))

    assert Lazy(lambda: 12).bind(fn).get() == Try.of(lambda: 12).bind(fn).get()

    assert Lazy(lambda: 1).bind(lambda x: State(lambda s: (x + 1, s))).get(1) == (2, 1)

    assert Lazy(lambda: 1).bind(lambda x: Writer(x, x * 2)).get() == (1, 2)


# Generated at 2022-06-24 00:14:29.531959
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(5).to_either() == Right(5)



# Generated at 2022-06-24 00:14:37.718926
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test for method ap of class Lazy.

    :return:
    """
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Lazy.of(1).ap(Lazy.of(lambda a: a + 2)).get() == Lazy.of(3).get()
    assert Lazy.of(2).ap(Box.of(lambda a: a + 3)).get() == Lazy.of(5).get()
    assert Lazy.of(3).ap(Maybe.just(lambda a: a + 4)).get() == Lazy.of(7).get()
    assert Lazy.of(4).ap(Maybe.nothing()).get() == Lazy.of(4).get()

# Generated at 2022-06-24 00:14:45.768185
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left

    def divide(a, b):
        if b == 0:
            raise ValueError()
        return a / b

    assert Right(1 / 2) == Lazy(lambda: divide(1, 2)).to_either()
    assert Left(ValueError) == Lazy(lambda: divide(1, 0)).to_either()



# Generated at 2022-06-24 00:14:51.164759
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    """
    Unit test for method get of class Lazy
    """
    def add_two(*args):
        return 2 + args[0]

    lazy = Lazy(add_two)

    assert lazy.get(10) == 12

    lazy = lazy.map(lambda x: x + 10)
    assert lazy.get(5) == 17

    lazy = lazy.bind(lambda x: Lazy.of(x + 10))
    assert lazy.get(7) == 27


# Generated at 2022-06-24 00:14:55.552672
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    import pytest
    from pymonet.monad_try import Try

    assert Lazy(lambda: 'foo').to_try() == Try.success('foo')
    with pytest.raises(TypeError):
        Lazy(lambda: 'foo').to_try(1)
    assert Lazy(lambda x: x).to_try('bar') == Try.success('bar')
    assert Lazy(lambda: 5 / 0).to_try() == Try.failure(ZeroDivisionError)


# Generated at 2022-06-24 00:15:00.065871
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    def test_either(value):
        return value.to_either()

    assert test_either(Lazy(1)) == Right(1)
    assert test_either(Lazy(lambda: 1 / 0)) == Left(ZeroDivisionError())

# Generated at 2022-06-24 00:15:06.998595
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test Lazy bind method

    :return: True if all assertions are pass
    :rtype: bool
    """
    lazy = Lazy.of(2)

    assert lazy.bind(lambda x: Lazy.of(x ** 2)).get() == 4
    assert lazy.bind(lambda x: Lazy.of(x ** 2)).get() == 4

    # result of constructor was already computed for first call, so for second call will be returned only result
    assert lazy.bind(lambda x: Lazy.of(x ** 2)).get() == 4

    return True



# Generated at 2022-06-24 00:15:10.636408
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    validation = Lazy(lambda: 100).to_validation()

    assert isinstance(validation, Validation)
    assert validation == Validation.success(100)
    assert validation.is_success()
    assert not validation.is_failure()



# Generated at 2022-06-24 00:15:14.514677
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def func_raising():
        raise Exception('Some error')

    assert Lazy(func_raising).to_try() == Lazy(func_raising).to_try('Some', 'other arguments') == Try.error(Exception('Some error'))
    assert Lazy(1).to_try() == Lazy(1).to_try('Some', 'other arguments') == Try.success(1)


# Generated at 2022-06-24 00:15:20.414286
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    x = Lazy(lambda x: x + 1)
    y = Lazy(lambda x: x + 1)
    z = Lazy(lambda x: x + 1)

    x_folded = x.get(1)

    assert x == y
    assert x == z
    assert x == x

    assert not x == Lazy(lambda x: x + 2)
    assert not x == Lazy.of(2)
    assert not x == 1
    assert not x == x.constructor_fn


# Generated at 2022-06-24 00:15:25.785740
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy(lambda x: 2 * x).to_maybe(2) == Maybe.just(4)
    assert (
        Lazy(lambda x: None)
            .to_maybe(2)
            .map(lambda x: 2 * x)
            .get_or_else(1) == 1
    )


# Generated at 2022-06-24 00:15:29.322852
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    lazy = Lazy.of('Test')
    assert lazy.to_either() == Right('Test')



# Generated at 2022-06-24 00:15:35.467167
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.validation import Validation

    def test_fn_1(value: int) -> int:
        return value + 10

    def test_fn_2(value: int) -> int:
        return value - 5

    test_lazy = Lazy(lambda x: x + 5)
    mapped_lazy = test_lazy.map(test_fn_1).map(test_fn_2)

    assert Validation.success(10).equals(mapped_lazy.to_validation(5))



# Generated at 2022-06-24 00:15:38.392859
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe

    lazy = Lazy.of(1)
    assert lazy.bind(lambda _: Maybe.just(2)) == Maybe.just(2)
    assert lazy.bind(lambda _: Maybe.empty()) == Maybe.empty()


# Generated at 2022-06-24 00:15:41.684745
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def fun():
        return 1

    lazy = Lazy(fun)
    from pymonet.either import Right

    assert lazy.to_either() == Right(1)

# Generated at 2022-06-24 00:15:47.204187
# Unit test for method __str__ of class Lazy
def test_Lazy___str__(): # pragma: no cover
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x1125fe2f0>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda x: x)('A')) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x1125fe2f0>, value=A, is_evaluated=True]'


# Generated at 2022-06-24 00:15:52.797633
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(x):
        return x

    def g(x):
        if x is None:
            raise ValueError('None as argument')
        return x

    lazy = Lazy(f)
    assert lazy == Lazy(f)
    assert lazy != Lazy(g)



# Generated at 2022-06-24 00:16:01.369883
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from typing import Callable

    def fn() -> Lazy[int, str]:
        return Lazy.of('string')

    assert Lazy.of(None).bind(fn).get() == 'string'

    def fn1() -> Lazy[int, str]:
        return Lazy.of(None)

    assert Lazy.of(5).bind(fn1).get() is None

    def fn2(*args) -> Lazy[int, str]:
        def aaa(*args):
            return 'aaa'

        return Lazy(aaa)

    assert Lazy.of(5).bind(fn2).get(5) == 'aaa'
    assert Lazy.of(5).bind(fn2).get(6, 7) == 'aaa'



# Generated at 2022-06-24 00:16:05.819755
# Unit test for method map of class Lazy
def test_Lazy_map():
    def lazy_1() -> int:
        return 1

    def lazy_2(args):
        return 2

    assert Lazy(lazy_1).map(lambda value: value * 2).get() == 2
    assert Lazy(lazy_2).map(lambda value: value * 2).get() == 4


# Generated at 2022-06-24 00:16:11.473642
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover

    from pymonet.either import Right

    assert Lazy.of(5).to_either() == Right(5)
    assert Lazy.of(5).to_either(1, 2) == Right(5)


# Generated at 2022-06-24 00:16:16.739834
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def function_to_wrap(*args):
        return 'value' + str(args)

    # given
    lazy = Lazy(function_to_wrap)

    # when
    result = lazy.to_box([1, 2, 3])

    # then
    assert isinstance(result, Box)
    assert result.get_or_else('default') == 'value[1, 2, 3]'



# Generated at 2022-06-24 00:16:21.666679
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.monad_list import List
    from pymonet.box import Box
    from pymonet.monad_try import Try, Error

    assert Lazy.of(2).to_box() == Box(2)
    assert Lazy.of(List(1, 2, 3)).to_box() == Box(List(1, 2, 3))
    assert Lazy.of(1 / 0).to_box() == Try(1 / 0).to_box()



# Generated at 2022-06-24 00:16:31.326000
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.validation import Validation

    def id_fn(x):
        return x

    def to_box_function(value):
        return Lazy.of(Box(value))

    def to_try_function(value):
        return Lazy.of(Try(id_fn, value))

    def to_either_function(value):
        return Lazy.of(Right(value))

    def to_validation_function(value):
        return Lazy.of(Validation.success(value))



# Generated at 2022-06-24 00:16:34.077838
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Error

    assert Lazy.of('a').to_try() == Try.of(lambda: 'a')
    assert Lazy(lambda: 1 / 0).to_try() == Try.fail(Error('division by zero'))

# Generated at 2022-06-24 00:16:38.123826
# Unit test for method map of class Lazy
def test_Lazy_map():
    # given
    def add_one_if_even(value):
        if value % 2 == 0:
            return value + 1
        return value

    # when
    result = Lazy(lambda: 2).map(add_one_if_even)

    # then
    assert result.get() == 3



# Generated at 2022-06-24 00:16:45.670243
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.validation import Validation

    def constructor(x):
        return x + 1

    def mapper(x):
        return x * 2

    assert Lazy(constructor).map(mapper).get(1) == 4
    assert Lazy(constructor).map(mapper).get(2) == 6
    assert Lazy(constructor).map(mapper).to_validation().get(1) == Validation.success(4)


# Generated at 2022-06-24 00:16:55.462297
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    """ Tests for '__str__' function of class Lazy """
    import unittest
    import sys
    import types

    # Arrange
    def mocked_function(): pass

    def mocked_function_two(): pass

    class MockedClass: pass

    # Arrange
    lazy = Lazy(mocked_function)
    lazy.is_evaluated = True
    lazy.value = MockedClass

    # Act
    result = str(lazy)

    # Assert
    unittest.TestCase().assertEqual(
        'Lazy[fn={}, value={}, is_evaluated={}]'.format(mocked_function, MockedClass, True),
        result)


# Generated at 2022-06-24 00:16:56.915724
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    v = 'test'
    f = lambda: v

    z = Lazy(f).to_maybe()

    t = Maybe(v)

    assert z == t