

# Generated at 2022-06-24 00:07:02.124657
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    # Given
    from pymonet.maybe import Maybe
    expected_value = Maybe.just(1)
    lazy: Lazy[str, Maybe] = Lazy(Maybe.just)

    # When
    actual_value = lazy.to_maybe("1")

    # Then
    assert expected_value == actual_value


# Generated at 2022-06-24 00:07:08.465102
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_fn(value):
        def doubled_fn(x):
            return Lazy.of(x * 2)

        return Lazy.of(value).bind(doubled_fn)

    # Check if after binding Lazy fn is not evaluated
    assert test_fn(4).is_evaluated is False

    # Check if binded Lazy value is equal mapper result
    assert test_fn(4).get() == 8

    # Check if mapper was evaluated
    assert test_fn(4).is_evaluated is True



# Generated at 2022-06-24 00:07:18.943470
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Two Lazy are equals where both are evaluated both have the same value and constructor functions.
    """
    from pymonet.fn_utils import compose

    # Cases
    fn = compose(lambda x: x + 1, lambda x: x + 2)

    lazy_1 = Lazy(fn).map(lambda x: x + 10)
    lazy_2 = Lazy(fn).map(lambda x: x + 10)

    assert lazy_1 != lazy_2

    lazy_2._compute_value(1)
    assert lazy_1 != lazy_2

    lazy_1._compute_value(1)
    assert lazy_1 == lazy_2

    lazy_3 = Lazy(fn).map(lambda x: x + 11)
    assert lazy_1 != lazy_3


# Generated at 2022-06-24 00:07:27.893810
# Unit test for method get of class Lazy
def test_Lazy_get():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get(self):
            def func_to_call(x, y):
                return [x, y]

            args = [0, 1]

            lazy = Lazy(func_to_call)
            self.assertEqual(lazy.get(*args), func_to_call(*args))
            self.assertTrue(lazy.is_evaluated)

            lazy = Lazy(func_to_call)
            self.assertEqual(lazy.get(*args), lazy.get(*args))
            self.assertTrue(lazy.is_evaluated)

    unittest.main()


# Generated at 2022-06-24 00:07:37.190111
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x: x + 1).ap(Lazy([1,2,3])).get() == [2,3,4]
    assert Lazy([1,2,3]).ap(Lazy(lambda x: x + 1)).get() == [2,3,4]
    assert Lazy([1,2,3]).ap(Lazy([lambda x: x + 1, lambda x: x + 2])).get() == [2,3,4]
    assert Lazy([lambda x: x + 1, lambda x: x + 2]).ap(Lazy([1,2,3])).get() == [2,3,4]

# Generated at 2022-06-24 00:07:46.782480
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    lazy = Lazy.of(lambda x: x * 10)
    lazy_box = Box(lambda x: x + 2)
    assert lazy.ap(lazy_box).get(5) == (5 + 2) * 10

    lazy_maybe = Maybe.just(lambda x: x * 111)
    assert lazy.ap(lazy_maybe).get(11) == (11 * 111) * 10

    lazy_either = Right(lambda x: x - 1)
    assert lazy.ap(lazy_either).get(12) == (12 - 1) * 10



# Generated at 2022-06-24 00:07:52.061493
# Unit test for method map of class Lazy
def test_Lazy_map():
    # given
    lazy = Lazy.of('Hello')
    mapper_fn = lambda x: '{}!'.format(x)

    # when
    lazy_result = lazy.map(mapper_fn)

    # then
    assert lazy_result.get() == 'Hello!'



# Generated at 2022-06-24 00:08:00.408095
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor, FunctorLaws
    from pymonet.monad import Monad, MonadLaws
    from pymonet.applicative import Applicative, ApplicativeLaws

    class LazyFunctor(Functor[Lazy]):
        def map(self, functor: Lazy, mapper: Callable[[int], int]) -> Lazy:
            return functor.map(mapper)

    class LazyApplicative(Applicative[Lazy]):
        @classmethod
        def of(cls, value: int) -> Lazy[int]:
            return Lazy.of(value)

    class LazyMonad(Monad[Lazy]):
        @classmethod
        def of(cls, value: int) -> Lazy:
            return Lazy.of(value)



# Generated at 2022-06-24 00:08:06.235429
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet import Box

    def fn1(value):
        return Maybe.just(value)

    def fn2(value):
        return Right(value)

    def fn3(value):
        return Box(value)

    def fn4(value):
        return Lazy(lambda: value)

    assert Lazy.of(fn1).ap(Lazy.of('value')).get() == Maybe.just('value')
    assert Lazy.of(fn2).ap(Lazy.of('value')).get() == Right('value')
    assert Lazy.of(fn3).ap(Lazy.of('value')).get() == Box('value')

# Generated at 2022-06-24 00:08:09.744290
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    def returns_maybe() -> Maybe[int]:
        return Maybe.of(1)

    assert Lazy(returns_maybe).to_maybe() == Maybe.of(1)

# Generated at 2022-06-24 00:08:21.719015
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    lazy_f = Lazy(add)
    assert lazy_f.to_try(1) == Try.of(add, 1)

    def divide(x, y):
        if y == 0:
            raise ValueError('division by zero')

        return x / y

    lazy_f = Lazy(divide)

    try_ = lazy_f.to_try(1, 0)
    assert try_ != Try.of(divide, 1, 0)
    assert isinstance(try_, Try)
    assert isinstance(try_.failure, ValueError)

    try_ = lazy_f.to_try(2, 1)
    assert try_ != Try.of

# Generated at 2022-06-24 00:08:25.393420
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    l1 = Lazy(lambda: 1)
    l2 = Lazy(lambda: 1)
    l3 = Lazy(lambda: 2)

    assert l1.__eq__(l2)
    assert not l1.__eq__(l3)
    assert not l2.__eq__(l3)


# Generated at 2022-06-24 00:08:27.329788
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of(2).to_maybe() == Maybe.just(2)



# Generated at 2022-06-24 00:08:32.360480
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    def my_fn(x):
        return x + 1

    lazy1 = Lazy(my_fn)
    lazy2 = Lazy(my_fn)
    lazy3 = Lazy(my_fn)
    lazy3._compute_value(2)
    lazy4 = Lazy(my_fn)
    lazy4._compute_value(2)

    assert lazy1 != lazy2
    assert lazy3 == lazy4
    assert lazy1 != lazy3


# Generated at 2022-06-24 00:08:43.880464
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet import Monad
    from pymonet.monad_try import Try
    from pymonet.monad_try import TryValueError
    from pymonet.monad_try import TryKeyError

    def f(_):
        return 1 / 0

    assert Monad.to_monad(Lazy(f)).to_try() == Try(f)
    assert Monad.to_monad(Lazy(lambda _: 1)).to_try() == Try(1)
    assert Monad.to_monad(Lazy(lambda _: {1: 'a'}[1])).to_try() == Try({1: 'a'}[1])

# Generated at 2022-06-24 00:08:45.504211
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    This function call constructor of Lazy
    """
    Lazy(lambda a: a)

# Generated at 2022-06-24 00:08:51.896131
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def divide(a, b):
        return a / b

    def dangerous_fn(a, b):
        try:
            return Lazy(lambda: divide(a, b))
        except Exception as e:
            return Lazy.of(e)

    assert Lazy.of(1).to_try() == Try.of(lambda x: x, 1)
    assert Lazy.of(1).to_try(1) == Try.of(lambda x: x, 1, 1)

    assert dangerous_fn(0, 1).to_try(0, 1) == Try.success(0)
    assert dangerous_fn(1, 0).to_try(1, 0) == Try.failure(ZeroDivisionError("division by zero"))

# Generated at 2022-06-24 00:09:01.811468
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.either import Either
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def to_try_test__abs(lazy_to_test):
        return lazy_to_test.to_try(Either).get_value().__abs__().get_value()

    assert Try(1).to_lazy() == Try.of(lambda: 1)
    assert Try(1).to_lazy().to_try().get() == 1
    assert to_try_test__abs(Try(1).to_lazy()) == 1
    assert Try(None).to_lazy() == Try.of(lambda: None)
    assert Try(None).to_lazy().to_try().get() == None

# Generated at 2022-06-24 00:09:04.597135
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Lazy.of(1).to_validation()


# Generated at 2022-06-24 00:09:08.930004
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Success case
    mapper = lambda x: x * 2
    lazy = Lazy(lambda: 1).map(mapper)
    assert lazy.get() == mapper(1)
    assert lazy.constructor_fn() == mapper(1)

    # Failure case
    assert not Lazy(lambda: 1).map(mapper).constructor_fn() != mapper(1)


# Generated at 2022-06-24 00:09:11.189074
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy(lambda: None).to_either() == Right(None)

# Generated at 2022-06-24 00:09:13.702475
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Try.of(lambda: 1) == Lazy.of(1).to_try()



# Generated at 2022-06-24 00:09:19.344440
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Box(2).to_box() == Lazy.of(2).to_box()
    assert Box(2).to_lazy().to_box() == Lazy.of(2).to_box()


# Generated at 2022-06-24 00:09:23.723601
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    Tests for Lazy class constructor
    """
    from pymonet.monad_maybe import Maybe

    f_result = Maybe.just(1)
    f_lazy = Lazy(lambda: f_result)

    assert f_lazy.is_evaluated is False
    assert f_lazy.value is None
    assert f_lazy.constructor_fn() == f_result



# Generated at 2022-06-24 00:09:25.529146
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import identity
    f = Lazy.of(identity)
    f_copy = Lazy.of(identity)
    f_modified = Lazy.of(identity)
    f_modified.map(lambda x: x)

    assert f == f_copy
    assert f != f_modified

# Generated at 2022-06-24 00:09:30.226789
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    assert isinstance(Lazy(lambda *args: None), Functor)
    assert isinstance(Lazy(lambda *args: None), Applicative)
    assert isinstance(Lazy(lambda *args: None), Monad)


# Generated at 2022-06-24 00:09:34.255458
# Unit test for method map of class Lazy
def test_Lazy_map():
    def func(*args):
        return '_'.join(map(str, args))

    lazy = Lazy.of(1).map(func)
    assert lazy._compute_value(1) == '1_1'
    assert lazy._compute_value(1, 2) == '1_1'



# Generated at 2022-06-24 00:09:40.109077
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    try_lazy = Lazy.of(1).to_try()
    assert isinstance(try_lazy, Try)
    assert try_lazy == Try.success(1)
    assert try_lazy == Try.of(lambda: 1)

    try_lazy = Lazy(lambda: raise_value_error()).to_try()
    assert isinstance(try_lazy, Try)
    assert try_lazy == Try.failure(ValueError('value_error'))



# Generated at 2022-06-24 00:09:51.226865
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    def add1(x):
        return x + 1

    def throw_exception(x):
        raise TypeError(x)

    assert Lazy.of(1).bind(lambda x: Maybe(add1(x))).get() == 2
    assert Lazy.of(1).bind(lambda x: Validation(add1(x))).get() == 2
    assert Lazy.of(1).bind(lambda x: Try(add1, x)).get() == 2
    assert Lazy.of(1).bind(lambda x: Try(throw_exception, x)).is_failure()

# Generated at 2022-06-24 00:09:58.032299
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def raise_exception(*args):
        raise Exception('This exception is expected in this test')

    def do_nothing(*args):
        pass

    assert Lazy(do_nothing).to_try() == Lazy(do_nothing).to_try('test_args')
    assert Lazy(raise_exception).to_try() != Lazy(raise_exception).to_try('test_args')

# Generated at 2022-06-24 00:10:02.719799
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def fn():
        print('wywołanie tej metody powinno zakończyć się błędem')
        raise Exception

    lazy = Lazy(fn)

    assert lazy.to_try() == Try.of(fn)

# Generated at 2022-06-24 00:10:06.523384
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda x: x) == Lazy(lambda x: x), 'constructor of class Lazy ignore constructor arguments'

# Generated at 2022-06-24 00:10:09.647835
# Unit test for constructor of class Lazy
def test_Lazy():
    from math import sqrt

    def square_root(num):
        return sqrt(num)

    lazy = Lazy(square_root)
    assert lazy.get(4) == 2



# Generated at 2022-06-24 00:10:13.229830
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test for method get of class Lazy.
    """
    assert Lazy(lambda x: x ** 2).get(2) == 4
    assert Lazy(lambda x: 4).get(2) == 4


# Generated at 2022-06-24 00:10:22.769453
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Either
    from pymonet.either import Right
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def ap_test(lazy1: 'Lazy[T, U]', lazy2: 'Lazy[T, U]', expected_result: 'Callable[[Lazy[T, U]], W]') -> None:
        assert expected_result(lazy1.ap(lazy2))

    def create_lazy_fn(fn: Callable[[U], W], value: U) -> 'Lazy[T, W]':
        return Lazy(lambda *args: fn(value))


# Generated at 2022-06-24 00:10:24.183431
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(4).get() == 4


# Generated at 2022-06-24 00:10:30.291918
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe


    def inc(i: int) -> int:
        return i + 1


    def dec(i: int) -> int:
        return i - 1

    m = Lazy(inc).map(dec)
    assert isinstance(m, Lazy)
    assert m.get() == 0
    m = m.map(inc).map(dec)
    assert isinstance(m, Lazy)
    assert m.get() == 0
    m2 = m.map(inc).map(dec)
    assert isinstance(m2, Lazy)
    assert m2.get() == 0
    assert m == m2
    m3 = m.to_box().map(inc)

# Generated at 2022-06-24 00:10:36.430975
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    import pytest

    lazy = Lazy.of(100)
    assert str(lazy) == "Lazy[fn=<function Lazy.of.<locals>.<lambda> at 0x7f7b2a023378>, value=None, is_evaluated=False]"


# Generated at 2022-06-24 00:10:44.457600
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try

    assert Lazy.of(lambda x, y: x * y).ap(Try.of(lambda x: x + 1)).get(2, 3) == 8
    assert Lazy(lambda x: x + 'a').ap(Try.of(lambda x: x + 'b')).get('c') == 'cba'
    assert Try.of(lambda x: x + 'c').ap(Lazy(lambda x: x + 'a')).get('b') == 'bca'
    assert Lazy.of('c').ap(Lazy.of(lambda x: x + 'a')).get('b') == 'bca'

# Generated at 2022-06-24 00:10:45.996242
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda n: n * n)
    assert lazy.get(5) == 25
    assert lazy.get(5) == 25



# Generated at 2022-06-24 00:10:53.228694
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: '123') == Lazy(lambda: '123')
    assert Lazy(lambda: '123') != Lazy(lambda: 123)
    assert Lazy(lambda: '123') != Lazy(lambda: '1234')
    assert Lazy(lambda: 123) != Lazy(lambda: '123')
    assert Lazy(lambda: '123') != Lazy(lambda: '1234').map(lambda x: x * 2)
    assert Lazy(lambda: '123') != 123


# Generated at 2022-06-24 00:10:58.988323
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.function import Function

    assert str(Lazy(Function)) == 'Lazy[fn=<function Function at 0x7fda85b66378>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:11:01.342811
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Lazy.of(1).to_validation()


# Generated at 2022-06-24 00:11:05.583803
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def do_something():
        return 42

    assert Lazy(do_something).to_try() == Try.success(42)

    def raise_exception():
        raise Exception('Boom')

    assert Lazy(raise_exception).to_try() == Try.failure(Exception('Boom'))

# Generated at 2022-06-24 00:11:09.798095
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    fn = lambda val: val

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda val: (val + 1))
    assert Lazy(fn) != fn
    assert Lazy(fn) != 1

# Generated at 2022-06-24 00:11:18.965211
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    val = Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x+1))
    assert val.get()(0) == 1
    assert val.get()(10) == 11
    assert val == Lazy(lambda: lambda x: x+1)(1)

    val = Lazy(lambda: 1).ap(Box(lambda x: x+1))
    assert val.get()(0) == 1
    assert val.get()(10) == 11
    assert val == Lazy(lambda: lambda x: x+1)(1)

    val = Lazy(lambda: 1).ap(lambda x: x+1)
    assert val.get()(0) == 1
    assert val.get()(10) == 11

# Generated at 2022-06-24 00:11:21.817449
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda _: 1)) == 'Lazy[fn=<function Lazy.<lambda> at 0x10c41ea60>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:11:24.464679
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Right(2) == Lazy.of(2).to_either()



# Generated at 2022-06-24 00:11:29.992920
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try, Success, Failure

    def fun_with_error(x):  # pragma: no cover
        if x > 0:
            return x * 2
        raise ValueError('x must be > 0, but x = {}'.format(x))

    def fun_without_error(x):  # pragma: no cover
        return x * 2

    assert Lazy(fun_with_error).to_try(1) == Success(2)
    assert Lazy(fun_with_error).to_try(-1) == Failure(ValueError('x must be > 0, but x = -1'))
    assert Lazy(fun_without_error).to_try(1) == Success(2)



# Generated at 2022-06-24 00:11:34.943877
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Success

    def fn(*args):
        return [1, 2, 3]

    assert Lazy(fn).to_validation() == Validation(Success([1, 2, 3]), [])


# Generated at 2022-06-24 00:11:41.784024
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Test for method to_try of class Lazy
    """
    from pymonet.monad_try import Try, Failure

    def test_fn():
        try:
            1 / 0
        except ZeroDivisionError as e:
            raise Failure(e)

    lazy = Lazy(test_fn)
    assert lazy.to_try() == Try.failure(ZeroDivisionError)



# Generated at 2022-06-24 00:11:44.386144
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    # pylint: disable=unused-variable
    def constructor(x: str) -> int:
        return 1

    def mapper(x: int) -> str:
        return 'mapper'

    def fn(x: int) -> Lazy[int, bool]:
        return Lazy.of(True)

    function = Lazy(constructor).map(mapper).bind(fn)
    assert function.get() == True

# Generated at 2022-06-24 00:11:50.328694
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    def lazy_constructor(number):
        return number

    lazy_number = Lazy(lazy_constructor)

    assert lazy_number.to_box() == Box(1)
    assert lazy_number.to_box(1) == Box(1)
    assert lazy_number.to_box(1, 2, 3) == Box(1)


# Generated at 2022-06-24 00:11:58.811170
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.task import Task
    from pymonet.either import Right

    def mapper(v):
        return Right(v)

    def identity(v):
        return v

    def twice(v):
        return v * 2

    test_cases = {
        'simple': Lazy(identity).ap(Lazy(mapper)),
        'task': Task(identity).ap(Lazy(mapper)),
        'right': Lazy(mapper).ap(Lazy(identity)),
    }

    for test_case in test_cases.values():
        assert test_case == Lazy(twice)
        assert isinstance(test_case, Lazy)



# Generated at 2022-06-24 00:12:03.051853
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(Left(1)).to_either() == Left(1), 'check if function was called'
    assert Lazy.of(Left(lambda _: 1)).to_either() == Left(1), 'check if function was called'


# Generated at 2022-06-24 00:12:07.616119
# Unit test for method get of class Lazy
def test_Lazy_get():

    def assert_get(lazy: Lazy[object, object], value: object):
        assert lazy.get() == value

    assert_get(Lazy(lambda: 1), 1)

    assert_get(Lazy.of(1), 1)

    assert_get(Lazy(lambda: None), None)

    assert_get(Lazy.of(None), None)


# Generated at 2022-06-24 00:12:10.998836
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    def fn():
        return 10

    a = Lazy(fn)
    assert a.to_box() == Box(fn())



# Generated at 2022-06-24 00:12:16.069090
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def fn_to_store():
        pass

    assert str(Lazy(fn_to_store)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn_to_store at 0x7f639b4a70d0>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:12:19.133397
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    def f():
        return 1

    assert Lazy.of(f).to_either(1) == Right(f)
    assert Lazy(lambda: Left('error')).to_either() == Left(None)


# Generated at 2022-06-24 00:12:24.429105
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box

    def f(x):
        return x

    assert f(4) == Lazy(f).get(4)
    assert not Lazy(f).get(4) == Lazy(f).get(5)

# Generated at 2022-06-24 00:12:28.438335
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(2).to_either(1) == Lazy.of(2).constructor_fn(1) == Right(2), \
        "Lazy to Either should return Right(self.fn())"


# Generated at 2022-06-24 00:12:31.553792
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    # pylint: disable=unused-argument
    def fn(value):
        return value

    lazy = Lazy(fn)
    assert lazy.to_maybe() == Maybe.of(fn)



# Generated at 2022-06-24 00:12:37.611570
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """ Tests Lazy.to_either method
    """
    def assert_equal(actual, expected):
        assert actual == expected

    def describe_to_either(Lazy, Either):
        def to_either_should_return_Right_when_Lazy_is_not_empty():
            assert_equal(None, Lazy.of(1).to_either())

    from pymonet.either import Either
    describe_to_either(Lazy, Either)




# Generated at 2022-06-24 00:12:41.091866
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of('str') == Lazy.of('str')

    assert Lazy(lambda x: x+2) != Lazy(lambda x: x+1)
    assert Lazy.of(1) != Lazy.of('str')
    assert Lazy.of(1) != 1


# Generated at 2022-06-24 00:12:47.291009
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    import operator

    assert Lazy.of(1).to_either() == Lazy.of(1).to_either()
    assert Lazy(lambda: 1 + 2).to_either() == 3
    assert Lazy(lambda: 1 + 2).map(operator.neg).to_either() == -3

# Generated at 2022-06-24 00:12:49.704318
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    l = Lazy.of(lambda x, y: x + y)
    assert l.ap(Lazy.of(1)).ap(Lazy.of(2)).get() == 3



# Generated at 2022-06-24 00:12:54.870042
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover

    def fn():
        raise Exception('Test exception')

    assert Lazy.of(1).to_try() == Lazy.of(1).to_maybe().to_try()
    assert Lazy.of(fn).to_try() == Lazy.of(fn).to_maybe().to_try()



# Generated at 2022-06-24 00:13:01.898581
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(lambda: 1)
    assert Lazy.of(1) != Lazy.of(lambda: 1)()
    assert Lazy.of(1) == Lazy.of(lambda: 1)
    assert Lazy.of(1) != Lazy.of(lambda: 1)(1)
    assert Lazy.of(1) != Lazy.of(lambda: 1)(2)



# Generated at 2022-06-24 00:13:05.743425
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def sub(x):
        return Lazy(lambda: x - 1)

    def add(x):
        return Lazy(lambda: x + 1)

    assert Lazy.of(6).bind(sub).bind(add).get() == 6

# Generated at 2022-06-24 00:13:12.194477
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # [given]
    def fn(x):
        return x * 2

    a = Lazy.of(3)
    b = Lazy.of(lambda x: x * 2)
    c = Lazy.of(7)

    # [when]
    result = a.bind(lambda x: b.ap(c.map(fn))).get()

    # [then]
    assert result == 42

# Generated at 2022-06-24 00:13:21.385639
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    assert Lazy.of(2).get() == 2
    assert Lazy.of(2).to_box() == 2
    assert Lazy.of(2).to_either() == 2
    assert Lazy.of(2).to_maybe() == 2
    assert Lazy.of(2).to_try() == 2
    assert Lazy.of(2).to_validation() == 2
    assert Lazy.of(2) == Lazy(lambda x: 2)
    assert Lazy.of(2) != Lazy(lambda x: 3)
    assert Lazy.of(2) != Lazy(lambda x, y: x+y)
    assert Lazy.of(2) != 2

# Generated at 2022-06-24 00:13:27.665978
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        def add_x(y):
            return x + y
        return add_x

    assert Lazy.of(1).ap(Lazy.of(2)) == Lazy.of(3)
    assert Lazy.of(add(2)).ap(Lazy.of(2)) == Lazy.of(4)
    assert Lazy.of(add(2)).ap(Lazy.of(3)) == Lazy.of(5)


# Generated at 2022-06-24 00:13:32.045306
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(lambda x: x + 1).map(lambda x: x(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).map(lambda x: x(1)) != Lazy.of(1)



# Generated at 2022-06-24 00:13:36.261170
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    from pymonet.box import Box

    assert Lazy(lambda x: x + 2).bind(
        lambda x: Box(x + 5)
    ).get(5) == 12


# Generated at 2022-06-24 00:13:46.257126
# Unit test for method ap of class Lazy
def test_Lazy_ap():  # pragma: no cover
    from pymonet.either import Either, Right, Left
    from pymonet.maybe import Maybe

    def add2(value):
        assert isinstance(value, int)

        return value + 2

    add_2 = Lazy.of(add2)

    assert Right(5).ap(add_2) == add_2.ap(Right(3))
    assert Left(5).ap(add_2) == add_2.ap(Left(5))
    assert Maybe.just(3).ap(add_2) == add_2.ap(Maybe.just(1))
    assert Maybe.nothing().ap(add_2) == add_2.ap(Maybe.nothing())



# Generated at 2022-06-24 00:13:50.302957
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(5).to_box() == Box(5)



# Generated at 2022-06-24 00:13:54.140214
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right, Left
    from pymonet.functions import add

    lazy = Lazy.of(3).map(add(5))
    assert lazy.to_either() == Right(8)

    invalid_lazy = Lazy(lambda: 3 / 0).map(add(5))
    assert invalid_lazy.to_either() == Left(ZeroDivisionError)

    invalid_lazy = Lazy(lambda: add(5)("abc"))
    assert invalid_lazy.to_either() == Left(TypeError)



# Generated at 2022-06-24 00:13:55.949707
# Unit test for method map of class Lazy
def test_Lazy_map():
    def test_fn():
        return 2
    my_lazy = Lazy(test_fn)
    assert my_lazy.map(lambda v: str(v)).get() == '2'



# Generated at 2022-06-24 00:13:58.565286
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    assert Lazy(lambda x: x**2).map(lambda x: x+3).fold(6) == 15
    assert Lazy(lambda x: x**2).map(lambda x: x+3).fold(2) == 7


# Generated at 2022-06-24 00:14:07.006428
# Unit test for method map of class Lazy
def test_Lazy_map():

    def identity(x):
        return x

    def addOne(x):
        return x + 1

    def compute(x):
        return x + 2

    def compute2(x):
        return x + 3

    lazy = Lazy.of(1)
    lazy.map(identity).map(addOne).map(identity)
    assert (lazy.get() == 1)
    assert (lazy.map(identity).map(addOne).map(identity).get() == 2)
    assert (lazy.map(identity).map(addOne).map(compute).get() == 4)
    assert (lazy.map(compute).map(compute2).map(addOne).get() == 7)



# Generated at 2022-06-24 00:14:09.292974
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    def test():
        return "abc"

    lazy_obj = Lazy(test)
    assert lazy_obj.to_validation() == Validation.success("abc")


# Generated at 2022-06-24 00:14:12.084875
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)



# Generated at 2022-06-24 00:14:21.245430
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy.of(5).to_box() == Box(5)
    assert Lazy.of(Box(5)).to_box() == Box(5)
    assert Lazy.of(Box('1') + Box('2')).to_box() == Box('12')

    assert Lazy(lambda: 5).to_box() == Box(5)
    assert Lazy(lambda: Box(5)).to_box() == Box(5)
    assert Lazy(lambda: Box('1') + Box('2')).to_box() == Box('12')


# Generated at 2022-06-24 00:14:23.065597
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(2).map(lambda x: x + 1) == Lazy.of(3)



# Generated at 2022-06-24 00:14:29.060679
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def fn(value):
        return value

    lazy = Lazy(fn)
    assert str(lazy) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x7f1f45a6b950>, value=None, is_evaluated=False]'
    assert str(lazy.get(1)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x7f1f45a6b950>, value=1, is_evaluated=True]'


# Generated at 2022-06-24 00:14:33.844926
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def fn(arg):
        return arg

    lazy = Lazy.of(fn)
    assert lazy.to_try(1) == Try.success(fn(1))

    error = ZeroDivisionError("foo")
    lazy2 = Lazy(lambda *args: 1 / 0)
    assert lazy2.to_try() == Try.failure(error)



# Generated at 2022-06-24 00:14:44.579974
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test case should check if mapped Lazy return same result as original Lazy when is not evaluated.
    Test case should check if mapped Lazy return mapped output when is evaluated.

    :return: None
    """

    # Given
    def original_fn(a):
        return a

    def mapper(a):
        return a + 1

    def eval():
        return 1

    lazy = Lazy(original_fn)
    mapped_lazy = lazy.map(mapper)

    # When
    lazy_result = lazy.constructor_fn(eval())
    mapped_lazy_result = mapped_lazy.constructor_fn(eval())

    # Then
    assert lazy_result == mapped_lazy_result
    assert lazy_result == 2


# Generated at 2022-06-24 00:14:51.516762
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    counter = 0

    def increment(_):
        nonlocal counter
        counter += 1

    def increment_lazy(_):
        return Lazy.of(lambda x: x + 1)

    def increment_lazy_f(_):
        return Lazy(lambda x: x + 1)

    lazy_number = Lazy.of(1)
    lazy_number.ap(increment_lazy_f)
    assert lazy_number.get() == 1

    lazy_number = Lazy.of(1)
    lazy_number.bind(increment_lazy).map(increment).map(increment)
    assert lazy_number.get() == 4



# Generated at 2022-06-24 00:14:56.671738
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(2)

    def add_one(x: int) -> int:
        return x + 1

    assert Lazy(add_one) == Lazy(add_one)

# Generated at 2022-06-24 00:15:06.772081
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1).__eq__(Lazy(lambda: 1))
    assert not Lazy(lambda: 1).__eq__(Lazy(lambda: 2))
    assert not Lazy(lambda: 1).__eq__(Lazy(lambda x: x))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda: 1))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x, y: (x, y)))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x, y: (x, y)))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x, y: (x, y)))

# Generated at 2022-06-24 00:15:09.611899
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Just
    from pymonet import Lazy, Maybe

    def maybe_lazy():
        return Maybe.just(3)

    lazy = Lazy(maybe_lazy)
    assert lazy.to_maybe() == Just(3)

# Generated at 2022-06-24 00:15:19.762033
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def function_call_once():
        function_call_once.times_called += 1
        return 1

    # Set up
    function_call_once.times_called = 0

    # Exercises and Verify
    assert Lazy.of(2) == Lazy(lambda: 2)
    assert Lazy(function_call_once).map(lambda x: x + 1) == Lazy(lambda: function_call_once() + 1)
    assert Lazy(function_call_once).bind(lambda x: Lazy(lambda: x + 1)) == Lazy(lambda: 2)

# Generated at 2022-06-24 00:15:24.329705
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.either import Right

    def fn():
        return Right(1)

    lazy = Lazy(fn)
    validation = lazy.to_validation()

    assert validation == Validation.success(1)

# Generated at 2022-06-24 00:15:27.408680
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(3) == Lazy.of(3)
    assert Lazy.of(3) != Lazy.of(4)
    assert Lazy.of(3) != 3



# Generated at 2022-06-24 00:15:36.499847
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    a = Lazy.of(1)
    b = a.bind(lambda x: Lazy.of(x + 1))
    assert b.is_evaluated is False
    assert b.get() == 2
    assert b.is_evaluated is True
    assert b.to_box().unbox() == 2
    assert b.to_either().is_right
    assert b.to_either().get_value() == 2
    assert b.to_maybe().is_just
    assert b.to_maybe().get_value() is 2
    assert b.to_try().is_success

# Generated at 2022-06-24 00:15:44.382615
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.fn import compose
    from pymonet.box import Box

    box = Lazy(compose(lambda i: i, lambda i: i * 2, lambda i: i - 1, lambda i: i))
    assert str(box) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x10d89cd90>, value=None, is_evaluated=False]'

    box = Lazy(lambda: Box(10).get())
    assert str(box) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x10d89c048>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:15:49.847069
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def identity(value):
        return value

    lazy_1 = Lazy(identity)
    lazy_2 = Lazy(identity)
    lazy_3 = Lazy(lambda x: x + 1)

    assert lazy_1 == lazy_1
    assert lazy_1 != lazy_3
    assert lazy_2 == lazy_2
    assert lazy_2 != lazy_3
    assert lazy_1 == lazy_2
    assert lazy_2 == lazy_1
    assert lazy_1.get('test') == 'test'
    assert lazy_2.get('test') == 'test'


# Generated at 2022-06-24 00:15:57.418969
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(5).to_box() == 5
    assert Lazy.of(5).to_box(1, 2, 3) == 5
    assert Lazy.of(lambda x: x).to_box()(5) == 5
    assert Lazy.of(lambda x: x).to_box(1, 2, 3)(4) == 4
    assert Lazy.of(lambda x, y: x + y).to_box(1)(2) == 3



# Generated at 2022-06-24 00:15:59.676046
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of([]).to_either() == Right([])



# Generated at 2022-06-24 00:16:04.363673
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    def test_fn(value): return Lazy(lambda *args: value * 2)

    assert Lazy(lambda *args: 1).bind(test_fn).get() == 2
    assert Lazy(lambda *args: 1).bind(test_fn).constructor_fn == Lazy(lambda *args: 1).get()


# Generated at 2022-06-24 00:16:07.762090
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def function(x: int):
        return x + 1

    def mapper(x: int):
        return x * 2

    lazy = Lazy(function)
    result = lazy.map(mapper)
    assert result.get(1) == 4

    lazy = Lazy(function)
    result = lazy.map(lambda x: x)
    assert result.get(1) == 2



# Generated at 2022-06-24 00:16:10.837836
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 42)) == 'Lazy[fn=<function <lambda> at 0x000001439F51F620>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:16:13.048315
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    lazy = Lazy.of(1)
    assert lazy.to_box() == 1


# Generated at 2022-06-24 00:16:23.055598
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    value = 5
    lazy_box = Lazy.of(lambda *args: Box.of(value).get(*args))
    lazy_either = Lazy.of(lambda *args: Right(value).get(*args))
    lazy_maybe = Lazy.of(lambda *args: Maybe.just(value).get(*args))
    lazy_lazy = Lazy.of(lambda *args: Lazy.of(value).get(*args))

    assert lazy_box.to_maybe().get() == value
    assert lazy_either.to_maybe().get() == value
    assert lazy_maybe.to_maybe().get() == value
    assert lazy_lazy.to_maybe().get() == value

# Generated at 2022-06-24 00:16:30.174301
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.functor import Functor

    class TestClass(Functor):
        def __init__(self, value):
            self.value = value

        @staticmethod
        def map(mapper, value):
            return TestClass(mapper(value.value))

    lazy_value = Lazy.of(TestClass(5))
    plus_one_mapper = lambda value: value + 1
    mapper = lambda value: TestClass(plus_one_mapper(value.value))

    assert lazy_value.map(plus_one_mapper) == Lazy(lambda: 6)
    assert lazy_value.map(mapper).get() == TestClass(6)


# Generated at 2022-06-24 00:16:34.919630
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    # pylint: disable=w0612
    def constructor_fn(value):
        return value

    assert Validation.success(1) == Lazy(constructor_fn).to_validation(1)
    assert Validation.success(2) == Lazy(constructor_fn).to_validation(2)
    assert Validation.success(3) == Lazy(constructor_fn).to_validation(3)


# Generated at 2022-06-24 00:16:40.047966
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function(arg):
        return arg

    assert Lazy(test_function).get(1) == 1
    assert Lazy(test_function).get(None) is None
    assert Lazy(test_function).map(lambda x: x+1).get(1) == 2


# Generated at 2022-06-24 00:16:41.192443
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    lazy = Lazy.of(1)
    assert lazy.to_box() == Box(1)



# Generated at 2022-06-24 00:16:43.373625
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def f(a):
        return a + 1

    assert Lazy(f).to_maybe(1) == Maybe(2)

# Generated at 2022-06-24 00:16:50.444823
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    assert Right(3).to_lazy().to_either() == Right(3)
    assert Right(3).to_lazy().to_either(5) == Right(3)
    assert Lazy(lambda x: x + 1).to_either(5) == Right(6)
    assert Lazy(lambda x: x + 1).to_either() == Right(1)



# Generated at 2022-06-24 00:16:53.119730
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    lazy = Lazy(lambda s: s + 1)
    assert lazy.get(2) == 3
    assert lazy.get(3) == 4

# Generated at 2022-06-24 00:16:59.794723
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.tuple2 import Tuple2

    def add(a):
        return a + 10

    def add_2(a):
        return a + 20

    lazy = Lazy(lambda x: Tuple2(add, add_2)).ap(Lazy.of(10))

    assert lazy.get() == Tuple2(20, 30)
