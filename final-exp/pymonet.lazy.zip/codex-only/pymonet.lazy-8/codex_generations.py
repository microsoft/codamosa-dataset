

# Generated at 2022-06-24 00:06:55.791551
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy.of(12) == Lazy(lambda: 12)



# Generated at 2022-06-24 00:07:02.375617
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Lazy.of(1).to_either('err') == Right(1)
    assert Lazy(lambda: Maybe.nothing()).to_either('err') == Right('err')
    assert Lazy(lambda: Try(lambda: 1 / 0)).to_either('err') == Right('err')



# Generated at 2022-06-24 00:07:06.803872
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    constructor_fn = lambda x: x + 2
    input_value = 2

    assert Validation.success(constructor_fn(input_value)) == Lazy(constructor_fn).to_validation(input_value)

# Generated at 2022-06-24 00:07:17.227242
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.functor import fmap
    from pymonet.monad import bind

    def constructor_fn(value):
        return value * 2

    def value_mapper(value):
        return value + 1

    def lazy_mapper(lazy):
        return lazy.map(value_mapper)

    lazy = Lazy(constructor_fn)
    assert lazy == Lazy(constructor_fn)
    assert str(lazy) == 'Lazy[fn=<function test_Lazy.<locals>.constructor_fn at 0x102ff9c80>, value=None, is_evaluated=False]'
    assert bind(lazy, lazy_mapper) == Lazy(constructor_fn).map(value_mapper)

# Generated at 2022-06-24 00:07:21.528290
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    res = Lazy.of(2).bind(lambda x: Lazy.of(x + 5))
    assert res.get() == 7

    res = Lazy.of(3).bind(lambda x: Lazy.of(x + 5))
    assert res.get() == 8



# Generated at 2022-06-24 00:07:28.116805
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from nose.tools import assert_equals  # type: ignore

    assert_equals(Lazy(lambda a: a).to_maybe(3), Maybe.just(3))
    assert_equals(Lazy(lambda a: a).to_maybe(None), Maybe.nothing())
    assert_equals(Lazy(lambda a: a).to_maybe(Left(3)), Maybe.nothing())



# Generated at 2022-06-24 00:07:39.209177
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Lazy.of(10).to_box() == Box(10)
    assert Lazy.of(None).to_box() == Box(None)
    assert Lazy.of("").to_box() == Box("")
    assert Lazy.of("hello").to_box() == Box("hello")
    assert Lazy.of([]).to_box() == Box([])
    assert Lazy.of([1, 2, 3]).to_box() == Box([1, 2, 3])
    assert Lazy.of({}).to_box() == Box({})
    assert Lazy.of({"a": 1}).to_box() == Box({"a": 1})

# Generated at 2022-06-24 00:07:41.469123
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    method = Lazy(lambda: 10)
    assert method.to_either() == Right(10)



# Generated at 2022-06-24 00:07:47.710189
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def raise_function():
        raise ValueError('Error')

    assert Lazy(lambda: True).to_try() == Try.success(True)
    assert Lazy(lambda: 1 / 0).to_try() == Try.failure(ZeroDivisionError('division by zero'))
    assert Lazy(raise_function).to_try() == Try.failure(ValueError('Error'))

# Generated at 2022-06-24 00:07:52.137740
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy(lambda x: x).to_box('value') == Lazy(lambda x: x).to_box('value')
    assert Lazy(lambda x: x).to_box(1) == Lazy(lambda x: x).bind(lambda x: Lazy.of(x)).to_box(1)

# Generated at 2022-06-24 00:08:00.458586
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.validation import Validation

    def add_1(x: int) -> int:
        """
        Add 1 to x

        :param x: value to add 1
        :type x: int
        :returns: x + 1
        :rtype: int
        """
        return x + 1

    fn = Lazy.of(2)
    assert fn.get() == 2
    assert fn.get() == 2

    assert fn.map(add_1).get() == 3
    assert fn.map(add_1).get() == 3

    assert fn.bind(lambda x: Lazy.of(x + 1)).get()

# Generated at 2022-06-24 00:08:03.034210
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def a():
        return 1

    assert str(Lazy(a)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.a at 0x7ff0d8da9a60>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:08:06.824190
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def divide_by_zero():
        return 1 / 0

    lazy = Lazy(divide_by_zero).to_try()
    assert isinstance(lazy, Try)
    assert lazy.is_failure
    assert lazy.get_error()

    lazy = Lazy.of('some').to_try()
    assert isinstance(lazy, Try)
    assert lazy.is_success
    assert lazy.get() == 'some'


# Generated at 2022-06-24 00:08:09.586237
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    import pytest

    l = Lazy(lambda: 1)
    assert l.to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:08:20.321153
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def make_positive(x):
        return x + 1

    lazy_result = Lazy(make_positive)
    result = lazy_result.to_try(2)

    assert isinstance(result, Try)
    assert result.get() == 3

    def make_error_positive(x):
        if x % 2 != 0:
            raise Exception("Can't compute result for uneven number")

        return x + 1

    lazy_error = Lazy(make_error_positive)
    result_error = lazy_error.to_try(1)

    assert isinstance(result_error, Try)
    assert result.get() == 3

# Generated at 2022-06-24 00:08:25.249750
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert Lazy.of(10).__str__() == 'Lazy[fn=<function <lambda> at 0x10f3c7ea0>, value=10, is_evaluated=True]'
    assert Lazy(lambda x: x * 2).__str__() == 'Lazy[fn=<function <lambda> at 0x10f3c7f28>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:08:27.959835
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    assert Lazy.of(1).to_either() == Right(1)



# Generated at 2022-06-24 00:08:33.068341
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda x: x)) == 'Lazy[fn=<function <lambda> at 0x7f1fc2c1bb00>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda x: x).bind(lambda x: Lazy(lambda y: y))) == 'Lazy[fn=<function <lambda> at 0x7f1fc2c1b840>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:08:37.111096
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def function_raising_exception(value):
        raise ValueError('smth bad happened')

    assert Lazy(function_raising_exception).to_try(10) == Try.failure(ValueError('smth bad happened'))

    def function_returning_value(value):
        return value

    assert Lazy(function_returning_value).to_try(10) == Try.success(10)



# Generated at 2022-06-24 00:08:44.543255
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet import __version__
    from pymonet.lazy import Lazy
    lazy_instance: Lazy = Lazy.of(10)
    assert str(lazy_instance) == 'Lazy[fn=<function Lazy of.<locals>.<lambda> at 0x{}>, value=10, is_evaluated=True]'.format(hex(id(lazy_instance))[2:])


# Generated at 2022-06-24 00:08:47.303581
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(2) == Lazy.of(2)
    assert Lazy.of(lambda x: x + x) == Lazy.of(lambda x: x + x)

    def add_x(x):
        return x + x

    assert Lazy.of(add_x) == Lazy.of(add_x)

    assert Lazy.of(2) != Lazy.of(2.0)
    assert Lazy.of(2) != Lazy.of(1)
    assert Lazy.of(2) != Lazy.of(lambda x: x + x)


# Generated at 2022-06-24 00:08:49.296287
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy.of(1) == Lazy(lambda *args: 1)



# Generated at 2022-06-24 00:08:57.366268
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def add_one(n):
        return Box(n + 1)

    def square(n):
        return Box(n * n)

    def cube(n):
        return Box(n * n * n)

    lazy_result = Lazy.of(2).map(add_one).map(square).map(cube)

    assert lazy_result.get() == Box(27)



# Generated at 2022-06-24 00:09:03.968510
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    def add_one(x):
        return x + 1

    def insert_none_maybe(x):
        return Maybe.just(add_one(x))
    
    assert Lazy.of(1).map(add_one).fold() == 2
    assert Lazy.of(1).map(insert_none_maybe).fold() == 2
    assert Lazy.of(1).map(add_one).map(add_one).fold() == 3
    assert Lazy.of(1).map(add_one).map(insert_none_maybe).fold() == 3
    assert Lazy.of(1).map(lambda x: Validation.success(x)).fold() == Validation.success(1)



# Generated at 2022-06-24 00:09:07.817380
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(1).to_box().equals(Lazy.of(1).to_box())
    assert not Lazy.of(1).to_box().equals(Lazy.of(2).to_box())
    assert Lazy.of(1).to_box().is_instance(Box)



# Generated at 2022-06-24 00:09:12.142014
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of(5).to_maybe(5) == Lazy.of(5)
    assert Lazy.of(5).map(lambda x: x + 1).to_maybe() == Lazy.of(6)
    assert isinstance(Lazy.of(5).to_maybe(), Lazy)


# Generated at 2022-06-24 00:09:14.169338
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(None) == Lazy.of(None)
    assert Lazy.of(None) != Lazy.of(1)

# Generated at 2022-06-24 00:09:24.501532
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    """Unit test for method to_either of class Lazy"""
    # pylint: disable=import-outside-toplevel
    import pymonet.either
    import pymonet.maybe

    # pylint: disable=expression-not-assigned,unused-variable
    lazy_value = pymonet.lazy.Lazy.of(1)
    assert lazy_value.to_either() == pymonet.either.Right(1)

    lazy_value = pymonet.lazy.Lazy(lambda: 1)
    assert lazy_value.to_either() == pymonet.either.Right(1)

    lazy_value = pymonet.lazy.Lazy(lambda: pymonet.maybe.Nothing)

# Generated at 2022-06-24 00:09:26.102021
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of('some test message').to_box() == 'some test message'



# Generated at 2022-06-24 00:09:30.821109
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test of bind method of class Lazy
    """

    # given
    fn = (lambda x: x ** 2)
    lazy_fn = Lazy(fn)
    # when
    lazy_square_fn = lazy_fn.bind(Lazy.of)
    # then
    assert lazy_square_fn == Lazy(lambda x: x ** 2)
    assert lazy_square_fn.get(2) == 4


# Generated at 2022-06-24 00:09:33.801051
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 1).to_maybe().is_just
    assert Lazy(lambda: None).to_maybe().is_nothing


# Generated at 2022-06-24 00:09:42.047952
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def get_lazy_box() -> Lazy[None, Maybe[int]]:
        return Maybe.just(100).to_lazy()

    def get_lazy_maybe() -> Lazy[None, Box[int]]:
        return Box(200).to_lazy()

    def get_lazy_value(key: str) -> Lazy[str, int]:
        return Lazy(lambda: {'a': 100, 'b': 200}[key])

    # Get lazy maybe box
    lazy_box = get_lazy_box()
    # Call get key 'a' and get lazy value
    # Get lazy maybe
    lazy_maybe = lazy_box.bind(get_lazy_value)
    # Get lazy value box
    lazy

# Generated at 2022-06-24 00:09:47.182119
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy(lambda x: x + 1).map(lambda x: str(x)).get(1) == '2'

    assert Lazy(lambda x: x + 1).bind(lambda x: Lazy(lambda _: x + 1)).get(1) == 3

    assert Lazy(lambda x: x + 1).ap(Lazy(lambda x: x + 1)).get(1) == 3

# Generated at 2022-06-24 00:09:52.824183
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    # GIVEN
    test_lazy = Lazy(lambda x: x)

    # WHEN
    result = test_lazy.to_box(0)

    # THEN
    assert isinstance(result, Box)
    assert result.get() == 0



# Generated at 2022-06-24 00:09:57.430528
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def func():
        pass

    assert Lazy(func) == Lazy(func)
    assert not Lazy(func).__eq__(1)
    assert not Lazy(func).__eq__(Lazy(lambda: 1))



# Generated at 2022-06-24 00:10:04.496075
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def func(value):
        return Lazy.of(value+2)

    lazy = Lazy.of(1)
    new_lazy = lazy.bind(func)
    new_lazy._compute_value()
    assert new_lazy == Lazy.of(3)

    lazy2 = Lazy(lambda *args: args[0]+4)
    new_lazy2 = lazy2.bind(func)
    new_lazy2._compute_value(2)
    assert new_lazy2 == Lazy.of(8)


# Generated at 2022-06-24 00:10:07.114951
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy(str).to_maybe() == Maybe.just(str)

    assert Lazy.of(10).to_maybe() == Maybe.just(10)

    # This should be empty Maybe
    assert Lazy(lambda x: x(x)).to_maybe() == Maybe.empty()


# Generated at 2022-06-24 00:10:18.654282
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from .equals_matcher import is_equal_to

    assert Lazy.of(2) == Lazy.of(2)

    assert Lazy.of(2).map(lambda value: value + 1) == Lazy.of(2).map(lambda value: value + 1)

    assert Lazy.of(2).map(lambda value: value + 1) != Lazy.of(2)

    assert Lazy.of(2).map(lambda value: value + 2) != Lazy.of(2).map(lambda value: value + 1)

    assert is_equal_to(Lazy.of(2)) == Lazy.of(2)


# Generated at 2022-06-24 00:10:24.267780
# Unit test for method get of class Lazy
def test_Lazy_get():
    input = 'value to transform'
    expected_output = input.upper()
    assert expected_output == Lazy(lambda value: value.upper()).get(input)



# Generated at 2022-06-24 00:10:30.337741
# Unit test for method ap of class Lazy
def test_Lazy_ap():

    def add_a(a):
        return lambda b: a + b

    def add_b(b):
        return lambda a: a + b

    def add_ab(a):
        return lambda b: add_a(a)(b)

    assert Lazy.of(add_b(2)).ap(Lazy.of(1)) == Lazy.of(3)
    assert Lazy.of(add_b(2)).ap(Lazy.of(add_a(1))) == Lazy.of(4)
    assert Lazy.of(add_ab(1)).ap(Lazy.of(2)) == Lazy.of(3)

    assert Lazy.of(add_b(2)).ap(Lazy(add_a(1))).ap(Lazy(2)) == 6



# Generated at 2022-06-24 00:10:35.602090
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    # pylint: disable=missing-docstring

    def func(a):
        return a

    lazy: Lazy[int, int] = Lazy(func)

    assert lazy.to_maybe(5) == Maybe.just(5)


# Generated at 2022-06-24 00:10:41.528394
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 'str')) == "Lazy[fn=<lambda>, value=None, is_evaluated=False]"
    assert str(Lazy(lambda: 0)) == "Lazy[fn=<lambda>, value=None, is_evaluated=False]"
    assert str(Lazy(lambda: 0).get()) == "Lazy[fn=<lambda>, value=0, is_evaluated=True]"


# Generated at 2022-06-24 00:10:52.283142
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def fn(x):
        return x + 5

    lazy = Lazy(fn)

    assert Lazy.of(5) == Lazy(lambda: 5)
    assert Lazy.of(5) == Lazy.of(5)
    assert lazy.map(lambda x: x * 2) == Lazy(lambda x: (x + 5) * 2)
    assert lazy.ap(Lazy(lambda x: x * 2)) == Lazy(lambda x: (x + 5) * 2)
    assert lazy.bind(lambda x: Lazy(lambda: x * 2)) == Lazy(lambda x: (x + 5) * 2)
    assert lazy.get(1) == 6
    assert lazy.get(9) == 14
    assert lazy.to_box(1) == Box(6)
   

# Generated at 2022-06-24 00:10:55.836830
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def method():
        return 'Method'

    assert str(Lazy(method)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.method at 0x1064e1840>, value=None, is_evaluated=False]'

# Generated at 2022-06-24 00:11:01.368141
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:11:07.184788
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def raise_exception(a):
        raise Exception("test exception")

    def not_raise_exception(a):
        return "test"

    assert Lazy(lambda x: x).to_try("test").is_success()
    assert Lazy(raise_exception).to_try("test").is_failure()
    assert Lazy(not_raise_exception).to_try("test").is_success()
    assert Lazy(not_raise_exception).to_try("test").is_instance(Try)


# Generated at 2022-06-24 00:11:15.984130
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    value1 = Lazy.of(2)
    value2 = value1.map(lambda v: Box(v + 1))

    assert isinstance(value2, Lazy)
    assert value2.get() == Box(3)

    # when value1 is empty
    value1 = Lazy.of(None).bind(lambda v: Lazy.of(v + 1))
    value2 = value1.map(lambda v: Box(v))

    assert isinstance(value2, Lazy)
    assert value2.get() is None


# Generated at 2022-06-24 00:11:23.924167
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.box import Box

    def load_config(filename):
        raise FileNotFoundError('NOPE')

    def load_data(config):
        return 42

    def get_data():
        return Lazy(load_config).map(load_data)

    assert get_data().get() == Box(42)


# Generated at 2022-06-24 00:11:29.659494
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).constructor_fn() == 2
    assert Lazy.of(2).map(lambda x: x ** x).constructor_fn() == 4
    assert Lazy.of(0).map(lambda x: 2 * x).constructor_fn() == 0
    assert Lazy.of(0).map(lambda x: 2 * x).map(lambda x: x + 3).constructor_fn() == 3
    assert Lazy.of(0).map(lambda x: 2 * x).map(lambda x: x + 3).constructor_fn() == 3
    assert Lazy.of(3).map(lambda x: 2 * x).map(lambda x: x + 3).constructor_fn() == 9


# Generated at 2022-06-24 00:11:36.616115
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(0).map(lambda x: x + 12).get() == 12
    assert Lazy.of(2).map(lambda x: x * 3).get() == 6
    assert Lazy.of("lazy").map(lambda value: value + " monad").get() == "lazy monad"
    assert Lazy.of(lambda x: x + 1).map(lambda value: value(12)).get() == 13
    assert Lazy.of(lambda x, y: x + y).map(lambda value: value(10, 12)).get() == 22



# Generated at 2022-06-24 00:11:47.404224
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    assert Functor.lift_a(Lazy, 1) == Lazy.of(1)
    assert Lazy.of(1) == Functor.lift_a(Lazy, 1)
    assert Functor.lift_a(Lazy, 1) == Functor.lift_a(Lazy, 1)
    assert Functor.lift_a(Lazy, 1).map(lambda a: a + 1) == Functor.lift_a(Lazy, 2)
    assert Lazy.of(2).bind(lambda el: Lazy.of(el * 2)) == Lazy.of(4)
    assert Monad.lift_m(Lazy, 1) == Lazy.of(1)

# Generated at 2022-06-24 00:11:50.330478
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    lazy = Lazy(lambda *args: 'test')
    assert lazy.to_either() == Right('test')


# Generated at 2022-06-24 00:11:54.297576
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():

    from pymonet.validation import Validation

    def const_fn():
        return 1
    lazy_value = Lazy(const_fn)
    assert lazy_value.to_validation() == Validation.success(lazy_value.get())



# Generated at 2022-06-24 00:11:58.729343
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    _to_validation = Lazy.of(1).to_validation
    assert isinstance(_to_validation(), Validation)
    _to_validation_result = _to_validation()
    assert not _to_validation_result.failure
    assert _to_validation_result.get() == 1


# Generated at 2022-06-24 00:11:59.892405
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert isinstance(Lazy.of(1).to_either(), is_either)



# Generated at 2022-06-24 00:12:05.386702
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def fn():
        return "value"
    assert Lazy(fn).__str__() == "Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x10a90dc80>, value=None, is_evaluated=False]"  # pragma: no cover
    assert Lazy(fn).get() == "value"  # pragma: no cover
    assert Lazy(fn).__str__() == "Lazy[fn=<function test_Lazy___str__.<locals>.fn at 0x10a90dc80>, value=value, is_evaluated=True]"  # pragma: no cover


# Generated at 2022-06-24 00:12:09.908978
# Unit test for method get of class Lazy
def test_Lazy_get():
    add_one = Lazy(lambda x: x + 1)
    assert add_one.get(5) == 6


# Generated at 2022-06-24 00:12:14.362211
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    assert Lazy.of(1).to_try() == Try.success(1)
    assert Lazy.of(1/0).to_try() == Try.failure(ZeroDivisionError("division by zero"))


# Generated at 2022-06-24 00:12:16.069582
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def test_fn():
        return 100

    lazy_fn = Lazy(test_fn)
    assert lazy_fn.to_either() == Right(100)
    assert lazy_fn.to_either() == Right(100)



# Generated at 2022-06-24 00:12:17.612153
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    lazy = Lazy.of(5)
    assert lazy.get() == 5



# Generated at 2022-06-24 00:12:26.502914
# Unit test for method to_box of class Lazy
def test_Lazy_to_box(): # pragma: no cover
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Lazy.of(1).to_box().to_box() == Box(1)
    assert Lazy(lambda: 1).to_box() == Box(1)
    assert Lazy(lambda: 1/0).to_box() == Box(1)
    assert Lazy(lambda: Try.of(lambda: 1/0).get()).to_box() == Box(1)



# Generated at 2022-06-24 00:12:32.015709
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    test = Lazy.of(1)
    assert test.to_box() == Box(1)



# Generated at 2022-06-24 00:12:35.934112
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    # given
    lazy = Lazy.of(1)

    # when
    validation = lazy.to_validation()

    # then
    result = isinstance(validation, Validation) and validation.is_success() and validation.get_value() == 1

    assert result is True


# Generated at 2022-06-24 00:12:40.853391
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy(lambda: 1).get() == 1

    assert Lazy.of(2).get(1) == 2
    assert Lazy(lambda _: 2).get(1) == 2

    assert Lazy.of(3).get(1, 2) == 3
    assert Lazy(lambda _, __: 3).get(1, 2) == 3



# Generated at 2022-06-24 00:12:50.168122
# Unit test for constructor of class Lazy
def test_Lazy():
    def get_value(value):
        def get_inner_value(*args):
            return value

        return get_inner_value
    assert Lazy(get_value(1)) == Lazy(get_value(1))
    assert Lazy(get_value(1)) != Lazy(get_value(2))
    assert Lazy(get_value(1)) != Lazy(get_value(1.0))
    assert Lazy(get_value(1)) != Lazy(get_value(1.0))
    assert Lazy(get_value(1)) != Lazy(get_value(1))
    assert Lazy(get_value(1)) == Lazy(get_value(1.0))
    assert Lazy(get_value(1)) == Lazy(get_value(1.0))

# Generated at 2022-06-24 00:13:00.965018
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def dummy_function(x):
        return x + 1

    lazy = Lazy(dummy_function)
    lazy2 = Lazy(dummy_function)

    assert lazy == lazy2

    lazy = Lazy(dummy_function).map(lambda x: x * 2)
    lazy2 = Lazy(dummy_function).map(lambda x: x * 2)

    assert lazy == lazy2

    lazy = Lazy(dummy_function).ap(Lazy(dummy_function))
    lazy2 = Lazy(dummy_function).ap(Lazy(dummy_function))

    assert lazy == lazy2

    assert Lazy(dummy_function) != Lazy(lambda x: x / 2)
    assert Lazy(dummy_function) != Lazy(dummy_function).map(lambda x: x * 2)

# Generated at 2022-06-24 00:13:12.624751
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    """
    Assert that structure is transformed correctly

    :returns: None
    :rtype: None
    """
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_lazy().to_box() == Box(1)
    assert Maybe.nothing.to_lazy().to_box() == Box(None)
    assert Try.of(lambda : 1).to_lazy().to_box() == Box(1)
    assert Try.of(lambda : 1/0).to_lazy().to_box() == Box(None)
    assert Try.of(lambda : None).to_lazy().to_box() == Box(None)


# Generated at 2022-06-24 00:13:16.161852
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Maybe.just('value') == Lazy.of('value').to_maybe()

# Generated at 2022-06-24 00:13:26.926748
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    result = Lazy.of(1).to_maybe()
    assert result.get() == 1
    result = Lazy.of(None).to_maybe()
    assert result.is_empty() is True
    result = Lazy.of('foo').to_maybe()
    assert result.get() == 'foo'
    result = Lazy.of(1).to_maybe()
    assert result.get() == 1
    result = Lazy.of(object()).to_maybe()
    assert isinstance(result.get(), object)
    result = Lazy.of(object).to_maybe()
    assert result.get() is object
    result = Lazy.of(Exception('bar')).to_maybe()
    assert result.is_empty() is True


# Generated at 2022-06-24 00:13:32.787190
# Unit test for constructor of class Lazy
def test_Lazy():
    def fn():
        return lambda *args: 'test'

    instance_1 = Lazy(fn())
    instance_2 = Lazy(fn())

    assert instance_1 != instance_2

    instance_1.get()
    instance_2.get()

    assert instance_1 == instance_2


# Unit tests for class Lazy methods

# Generated at 2022-06-24 00:13:35.870864
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    def f(x):
        return x ** x

    result = Lazy.of(2).map(f)
    assert result.get() == f(2)



# Generated at 2022-06-24 00:13:46.893477
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def test_to_maybe(lazy_cls: Lazy[None, T]) -> Maybe[T]:
        return lazy_cls.to_maybe()

    # Should be not empty Maybe
    assert test_to_maybe(Lazy.of(Box.of(1))) == Maybe.just(1)
    # Should be empty Maybe
    assert test_to_maybe(Lazy.of(Box.of(None))) == Maybe.nothing()
    # Should be not empty Maybe
    assert test_to_maybe(Lazy.of(Box.of(Validation.success(2)))) == Maybe.just(2)
    # Should be empty Maybe
    assert test_to_maybe

# Generated at 2022-06-24 00:13:50.985321
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    empty_constructor_fn = lambda: "empty content"
    lazy = Lazy(empty_constructor_fn)
    assert str(lazy) == "Lazy[fn={}, value={}, is_evaluated={}]".format(empty_constructor_fn, None, False)


# Generated at 2022-06-24 00:13:58.821191
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    # Test for with argument being Lazy
    assert Lazy(lambda n: n + 2).bind(
        lambda n: Lazy(lambda: n * 2)
    ).get(2) == 8

    # Test for with argument being Lazy
    assert Lazy(lambda n: n + 2).bind(
        lambda n: Lazy.of(n * 2)
    ).get(2) == 8

    # Test for with argument being Box
    assert Lazy(lambda n: n + 2).bind(
        lambda n: Box(n * 2)
    ).get(2) == 8

    # Test for with argument being Either

# Generated at 2022-06-24 00:14:09.320944
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test bind method of Lazy class
    """
    from pymonet.list import List

    # pylint: disable=protected-access
    # pylint: disable=invalid-name

    def _add_one_lazy(item: int) -> Lazy[int, Lazy[int, int]]:
        return Lazy(lambda *_: item + 1)

    def _double_lazy(item: int) -> Lazy[int, int]:
        return Lazy(lambda *_: item * 2)

    # pylint: disable=no-value-for-parameter

    empty_list_of_lazies = List.empty().map(_add_one_lazy).map(_double_lazy)
    assert empty_list_of_lazies == List.empty()

    list_of_

# Generated at 2022-06-24 00:14:17.212752
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def const(value):
        return Lazy(lambda *args: value)

    fn = lambda value: value + 1
    value = 5
    assert const(value).to_maybe() == Maybe.just(value)

    assert const(value).map(fn).to_maybe() == Maybe.just(fn(value))

    assert const(value).map(fn).map(fn).to_maybe() == Maybe.just(fn(fn(value)))



# Generated at 2022-06-24 00:14:22.006276
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def fn(value):
        return value + 1

    lazy = Lazy.of(3)
    assert lazy.ap(Lazy.of(fn)).get() == fn(3)



# Generated at 2022-06-24 00:14:26.985972
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Failure

    # when
    result = Lazy.of(1).to_try()

    # then
    assert result == Try.success(1)

    # when
    def raise_fn():
        raise ValueError("Error")

    result = Lazy(raise_fn).to_try()

    # then
    assert result == Try.failure(Failure("Error", ValueError))


# Generated at 2022-06-24 00:14:30.719073
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.list import List
    from pymonet.simplified_list import SimplifiedList

    def fn(x):
        return SimplifiedList(x)

    lazy = Lazy(lambda x: List([x]))

    value = lazy.bind(fn).get(2)

    assert isinstance(value, SimplifiedList)
    assert isinstance(value.get(0), List)
    assert value.get(0).get(0).get(0) == 2



# Generated at 2022-06-24 00:14:35.728773
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda x: x + 2).get(40) == 42
    assert Lazy(lambda x: x ** 2).get(4) == 16



# Generated at 2022-06-24 00:14:37.094097
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(1).to_either() == Right(1)



# Generated at 2022-06-24 00:14:44.956161
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    To make it easier to use in method map we are just return value after applying mapper to it.
    How we can test such a thing?
    Let's take a look into method bind.
    """
    # we don't test apply of method ap because it's just returning another Lazy instance with another function bind to it
    lazy_fn = Lazy.of(1)

    def mapper(a):
        return a + 5

    assert lazy_fn.map(mapper).constructor_fn(10) == 6



# Generated at 2022-06-24 00:14:51.545499
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    Test Lazy constructor
    """

    def lambda_fn() -> str:
        return 'test'
    lazy_str = Lazy(lambda_fn)

    assert lazy_str.constructor_fn() == 'test'
    assert isinstance(lazy_str, Lazy)
    assert lazy_str == lazy_str

    with pytest.raises(TypeError):
        Lazy(123)

    with pytest.raises(TypeError):
        Lazy({'test': lambda: None})

    with pytest.raises(TypeError):
        Lazy(lambda: None, 123)



# Generated at 2022-06-24 00:15:01.596421
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.optional import Optional

    def add3(x):
        return x + 3

    def mul2(x):
        return x * 2

    def plus(x, y):
        return x + y

    assert Lazy.of('A').ap(Lazy.of(plus)) == Lazy.of('A')
    assert Lazy.of('A').ap(Lazy.of(mul2)) == Lazy.of('AA')
    assert Lazy.of('A').ap(Lazy.of(add3)) == Lazy.of('AAA')
    assert Lazy.of(2).ap(Lazy.of(mul2)) == Lazy.of(4)
    assert Lazy.of(2).ap(Lazy.of(add3)) == Lazy.of(5)

# Generated at 2022-06-24 00:15:06.021374
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    test_fn = lambda: 1

    lazy = Lazy(test_fn)
    lazy.get()

    assert str(lazy) == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(test_fn, 1, True)


# Unit tests for method __eq__ of class Lazy

# Generated at 2022-06-24 00:15:12.192686
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of(42).to_maybe(None) == Lazy.of(42).to_maybe(None)
    assert Lazy.of(None).to_maybe(None) == Lazy.of(None).to_maybe(None)
    assert Lazy.of(42).map(lambda x: x + 1).to_maybe(None) == Lazy.of(43).to_maybe(None)
    assert Lazy.of(42).ap(Lazy.of(lambda x: x + 1)).to_maybe(None) == Lazy.of(43).to_maybe(None)

# Generated at 2022-06-24 00:15:18.632641
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    import pytest
    from pymonet.validation import Validation

    def fun(a: int) -> int:
        return a + 2

    lazy = Lazy(fun).to_validation(2)

    assert isinstance(lazy, Validation)
    assert lazy.is_success()
    assert lazy.value == 4



# Generated at 2022-06-24 00:15:23.084927
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.functor import Functor
    from unittest import TestCase, main

    def _check_functor(functor_cls):
        class _TestCase(TestCase):
            def test_Lazy___eq__(self):
                self.assertEqual(Lazy.of(functor_cls(1)), Lazy.of(functor_cls(1)))
                self.assertEqual(Lazy.of(functor_cls(1)).map(lambda x: x), Lazy.of(functor_cls(1)).map(lambda x: x))

        return _TestCase

    TestCase = _check_functor(Functor)
    main()



# Generated at 2022-06-24 00:15:33.920087
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    """
    Test to_try method in class Lazy for two cases:
        - constructor_fn raise exception
        - constructor_fn not raise exception
    """
    from pymonet.monad_try import Try

    raise_exception = Lazy(lambda: 1/0)
    assert_equals(Try, type(raise_exception.to_try()))
    assert_equals(False, raise_exception.to_try().is_success())
    assert_equals(True, raise_exception.to_try().is_failure())
    assert_equals(ZeroDivisionError, type(raise_exception.to_try().failure().value))

    not_raise_exception = Lazy(lambda: 'a')

# Generated at 2022-06-24 00:15:40.382827
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    lazy = Lazy(lambda: 1)
    assert str(lazy) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f6f1ac66050>, value=None, is_evaluated=False]'

    assert str(lazy.map(lambda x: x + 1)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f6f1ac66268>, value=None, is_evaluated=False]'

    lazy = Lazy(lambda: 1)._compute_value()
    assert str(lazy) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f6f1ac66598>, value=1, is_evaluated=True]'


# Generated at 2022-06-24 00:15:48.814792
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def test_function(param):
        return param + 2

    assert Lazy.of(5).to_maybe(5) == Maybe.just(5)
    Lazy.of(5).bind(lambda value: Lazy.of(value * 10)).map(lambda value: value / 2).to_maybe() == Maybe.just(25)
    Lazy.of(test_function).map(lambda function: function(5)).bind(lambda value: Lazy.of(value * 10)).to_maybe() == Maybe.just(100)
    Lazy.of(Maybe.just(5)).map(lambda maybe: maybe.get()).to_maybe() == Maybe.just(5)
    Lazy.of(Maybe.just(5)).bind(lambda value: Lazy.of(value + 1)).to_maybe() == Maybe.just(6)
   

# Generated at 2022-06-24 00:16:00.158604
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy.of('test').get() == 'test'
    assert Lazy(lambda: 2).get() == 2
    assert Lazy(lambda: 'test2').get() == 'test2'

    assert Lazy(lambda: 'test').get(1) == 'test'
    assert Lazy(lambda: 2).get(1) == 2
    assert Lazy(lambda: 'test2').get(1) == 'test2'

    assert Lazy(lambda: 'test').get(1, 2) == 'test'
    assert Lazy(lambda: 2).get(1, 2) == 2
    assert Lazy(lambda: 'test2').get(1, 2) == 'test2'

    assert Lazy(lambda a, b: 'test').get(1, 2) == 'test'
   

# Generated at 2022-06-24 00:16:02.810728
# Unit test for method map of class Lazy
def test_Lazy_map():
    def get_value():
        return 42

    lazy = Lazy(get_value)
    def double(arg):
        return arg * 2

    assert lazy.map(double).get() == 84



# Generated at 2022-06-24 00:16:07.973471
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def constructor_fn(val: Any) -> str:
        return val

    assert Lazy.of("foo").to_either() == Right("foo")

    lazy = Lazy(constructor_fn)
    assert lazy.to_either("foo") == Right("foo")
    assert lazy.get("foo") == "foo"
    assert lazy.is_evaluated is True



# Generated at 2022-06-24 00:16:14.586780
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def test(type_):
        f = lambda: 1
        lz = Lazy(f)
        assert type_(lz.get()) == type_(f())
        assert lz.get() == f()
        assert lz.is_evaluated
        assert Lazy(lambda: 0).get() == 0
        assert type_(Lazy(lambda: 0).get()) == type_(0)
        assert Lazy(lambda: 0).get() == 0


# Generated at 2022-06-24 00:16:17.184534
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def test_function(x):
        return x * 2

    def return_2():
        return 2

    lazy = Lazy(return_2)
    lazy2 = lazy.ap(Lazy(test_function))
    assert lazy2.get() == 4

# Generated at 2022-06-24 00:16:19.266451
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(10).to_box() == Lazy.of(10).to_maybe() == Lazy.of(10).to_either() == Lazy.of(10).to_try() == Lazy.of(10).to_validation()
    assert Lazy.of(True).to_box()
    assert Lazy.of(False).to_box()
    assert Lazy.of('text').to_box()


# Generated at 2022-06-24 00:16:29.992789
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def divide(x: float, y: float) -> float:
        if y == 0:
            raise ZeroDivisionError()

        return x / y

    assert Lazy(lambda: divide(2, 0)).to_either() == Right(Lazy(lambda: divide(2, 0)))
    assert Lazy(lambda: divide(0, 0)).to_either() == Right(Lazy(lambda: divide(0, 0)))

    assert Lazy(lambda: divide(2, 2)).to_either() == Right(Lazy(lambda: divide(2, 2)))

# Generated at 2022-06-24 00:16:36.742187
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    """
    Unit test for method to_maybe of class Lazy
    """

    identity = lambda x: x
    identity_mapper = lambda x: identity(x)
    lazy_five = Lazy(lambda: identity(5))
    assert lazy_five.map(identity_mapper).to_maybe().equals(lazy_five.to_maybe())

    # Unit test for method to_maybe of class Lazy using function
    def _function_to_maybe(a_argument):
        return lambda: a_argument

    assert Lazy(_function_to_maybe(5)).to_maybe().equals(Lazy(_function_to_maybe(5)).get())

    # Unit test for method to_maybe of class Lazy using function

# Generated at 2022-06-24 00:16:44.582003
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind for class Lazy.
    """
    Lazy1 = Lazy(lambda x: x).bind(lambda x: Lazy(lambda: x + 1))
    Lazy2 = Lazy(lambda x: x).map(lambda x: x + 1)
    Lazy3 = Lazy(lambda x: x + 1)

    assert Lazy1.get(1) == Lazy2.get(1) == Lazy3.get(1)

# Generated at 2022-06-24 00:16:56.274602
# Unit test for constructor of class Lazy