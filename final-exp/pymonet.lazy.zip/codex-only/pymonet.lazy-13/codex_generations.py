

# Generated at 2022-06-24 00:06:59.046408
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(42).to_either(11).equals(Right(42))


# Generated at 2022-06-24 00:07:06.112791
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    # given
    def normalize_text(s: str) -> str:
        return s.strip().lower()

    def split_text(s: str) -> str:
        return s.split(' ')

    def is_empty_text(s: str) -> bool:
        return s == ''

    def flat_map(x: str, f: Callable[[str], str]) -> str:
        return f(x)

    lazy_data = Lazy.of('')
    # when
    lazy_data \
        .map(normalize_text) \
        .map(split_text)\
        .map(lambda s: s[0])\
        .map(lambda x: flat_map(x, normalize_text))\
        .to_either() \
        .map(is_empty_text)
   

# Generated at 2022-06-24 00:07:08.405411
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    f = Lazy(lambda: 'foo')
    assert f == Lazy(lambda: 'foo')
    assert f == f



# Generated at 2022-06-24 00:07:15.180505
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    lazy = Lazy(lambda x: x)
    print(lazy)
    assert lazy.is_evaluated is False

    lazy = Lazy(lambda x: x).map(lambda x: x + 1).map(lambda x: x * 2)
    print(lazy)
    assert lazy.is_evaluated is False

    computed_value = lazy.get(1)
    print(lazy)
    assert lazy.is_evaluated is True
    assert computed_value == 4


# Generated at 2022-06-24 00:07:20.992718
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    # prepare
    expected_result = 10
    expected_is_evaluated = True

    # execute
    lazy_fn = Lazy(lambda *args: expected_result)
    lazy_fn.get()

    # assert
    assert lazy_fn.is_evaluated == expected_is_evaluated
    assert lazy_fn.value == expected_result



# Generated at 2022-06-24 00:07:29.049592
# Unit test for constructor of class Lazy
def test_Lazy():
    # pylint: disable=comparison-with-callable
    from pymonet.box import Box

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: One())
    assert Lazy(lambda: 1) == Lazy(lambda: One()).map(lambda x: x.value)
    assert Lazy(lambda a: a[0]) == Lazy(lambda a: Box(a[0])).to_box().map(lambda x: x.value)
    assert Lazy(lambda: 1).constructor_fn() == 1

# Generated at 2022-06-24 00:07:35.483103
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try

    def add(a):
        return lambda b: a + b

    def mul(a):
        return lambda b: a * b

    lazy1 = Lazy.of(1)
    lazy2 = Lazy.of(2)
    lazy3 = Lazy.of(3)

    assert lazy1.bind(add(2)).bind(mul(2)).get() == 6
    assert lazy1.bind(add(lazy2)).bind(mul(lazy3)).get() == 9

    assert lazy1.map(add(2)).map(mul(2)).get() == 6
    assert lazy1.map(add(lazy2)).map(mul(lazy3)).get() == 9

    assert lazy1.ap(Lazy.of(7)).get() == 8

# Generated at 2022-06-24 00:07:37.835536
# Unit test for method map of class Lazy
def test_Lazy_map():
    def make_lazy(value):
        def inner():
            return value
        return Lazy(inner)

    def f(x):
        return x + 1

    def g(x):
        return x + 2

    fn = make_lazy(42)
    fn2 = fn.map(f).map(g)

    assert fn2.get() == f(g(42))



# Generated at 2022-06-24 00:07:48.514510
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.either import Right, Left
    from pymonet.validation import Validation

    def validate_name(name: str) -> Validation:
        if len(name) < 3:
            return Validation.fail(['Name must be at least 3 characters'])
        return Validation.success(name)

    def validate_surname(surname: str) -> Validation:
        if len(surname) < 5:
            return Validation.fail(['Surname must be at least 5 characters'])
        return Validation.success(surname)

    def validate_age(age: int) -> Validation:
        if not (1 <= age <= 120):
            return Validation.fail(['Age must be between 1 and 120'])

# Generated at 2022-06-24 00:07:51.905592
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    """test lazy class method map"""
    # given
    l = Lazy(lambda: 2)

    # when
    r = l.map(lambda x: x + 1)

    # then
    assert 3 == r.get()


# Generated at 2022-06-24 00:07:55.188286
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def const_fn(*args):
        return args[0]

    assert Lazy(const_fn) == Lazy(const_fn)
    assert Lazy(const_fn) != Lazy(const_fn(1))



# Generated at 2022-06-24 00:07:59.290481
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left

    def func_to_call_throws_error():
        raise ValueError()

    lazy = Lazy(func_to_call_throws_error)

    assert lazy.to_either().is_left()

    assert lazy.to_either().get_left_value() == Left(ValueError())

# Generated at 2022-06-24 00:08:10.802287
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.either import Right

    def dummy_function():
        return 1

    # Check map for Box
    assert Lazy.of(1).map(Box).map(dummy_function).to_box() == Box(dummy_function())

    # Check map for Either
    assert Lazy.of(1).map(Right).map(dummy_function).to_either() == Right(dummy_function())

    # Check map for Maybe
    assert Lazy.of(1).map(Maybe.just).map(dummy_function).to_maybe() == Maybe.just(dummy_function())

    # Check map for Validation
   

# Generated at 2022-06-24 00:08:15.858784
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.utils import identity

    test_data = 1
    lazy = Lazy(identity)

    assert lazy.get(test_data) == test_data
    assert lazy.is_evaluated
    assert lazy.value == lazy.constructor_fn(test_data)


# Generated at 2022-06-24 00:08:23.449255
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Either
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def fn():
        return Maybe.just('1').to_either()

    assert isinstance(Lazy(fn).to_either(), Either)
    assert isinstance(Lazy(fn).get(), Either)

    def fn():
        return Try.of(lambda: '1').to_either()

    assert isinstance(Lazy(fn).to_either(), Either)
    assert isinstance(Lazy(fn).get(), Either)


# Generated at 2022-06-24 00:08:26.147465
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    assert Lazy.of(42).get() == 42

    example = Lazy.of(1).map(lambda x: x + 1)

    assert example.get() == 2



# Generated at 2022-06-24 00:08:27.651037
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1

# Generated at 2022-06-24 00:08:30.533285
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert (
        Lazy.of(0).to_box() == Box(0)
    ), "Lazy.of(0).to_box() == Box(0)"



# Generated at 2022-06-24 00:08:34.807470
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert Lazy(lambda: 'result').__str__() == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x10a52d6a8>, value=None, is_evaluated=False]'

    def fn():
        return 1

    assert Lazy(fn).__str__() == 'Lazy[fn=<function Lazy.<locals>.fn at 0x10a52d620>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:08:36.720180
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return 9

    lazy = Lazy(fn)

    assert lazy.get() == 9



# Generated at 2022-06-24 00:08:44.851117
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def identity(x):
        return x

    # On neither exception
    assert type(Lazy(lambda x: x).to_either()) == Right
    assert Lazy(lambda x: x).to_either(3).get_or_else(0) == 3

    # On exception
    assert type(Lazy(lambda x: x / 0).to_either()) == Left
    assert type(Lazy(lambda x: x / 0).to_either().get_or_else(0)) == ZeroDivisionError

# Generated at 2022-06-24 00:08:48.963946
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation_types import ValidationFailure

    laz = Lazy.of(None).to_validation()

    assert laz == Validation.success(None)

    laz = Lazy.of(ValidationFailure('error')).to_validation()

    assert laz == Validation.failure('error')

# Generated at 2022-06-24 00:08:59.984849
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.functor import Functor

    a = 5

    lazy1 = Lazy(lambda: 1)
    lazy2 = Lazy(lambda: a + 1)

    # Lazy with function returning 1
    assert lazy1 == Lazy(lambda: 1)
    assert lazy1 != Lazy(lambda: 2)
    assert lazy1 != Lazy(lambda: a)
    assert lazy1 != Lazy(lambda a: 1)

    # Lazy with function returning 2
    assert lazy2 == Lazy(lambda: 2)
    assert lazy2 == Lazy(lambda: a + 1)
    assert lazy2 != Lazy(lambda: 1)
    assert lazy2 != Lazy(lambda: a)
    assert lazy2 != Lazy(lambda a: a + 1)



# Generated at 2022-06-24 00:09:05.697652
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def add(c, d):
        return c + d

    lazy_add2 = Lazy(lambda: add(1, 1))
    assert lazy_add2.to_maybe() == Maybe.just(2)

    lazy_add3 = Lazy(lambda: add(1, 2))
    assert lazy_add3.to_maybe() == Maybe.just(3)

# Generated at 2022-06-24 00:09:13.702275
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def lazy_fn_one(*args):  # pragma: no cover
        return 1

    def lazy_fn_two(*args):  # pragma: no cover
        return 2

    def lazy_fn_three(*args):  # pragma: no cover
        return 3

    lazy_1 = Lazy(lazy_fn_one)
    lazy_2 = Lazy(lazy_fn_two)
    lazy_3 = Lazy(lazy_fn_three)
    lazy = lazy_1.bind(lambda x: lazy_2.bind(lambda y: lazy_3.map(lambda z: x + y + z)))
    assert Lazy.of(6).get() == lazy.get()

# Generated at 2022-06-24 00:09:16.643372
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of('foo').to_box() == Box('foo')
    assert Lazy(lambda: 2 + 4).to_box() == Box(6)



# Generated at 2022-06-24 00:09:26.983740
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from hypothesis import given
    import hypothesis.strategies as st
    from hypothesis.stateful import rule, initialize, bundles, invariant
    from hypothesis.stateful import RuleBasedStateMachine

    class LazyToBox(RuleBasedStateMachine):
        """
        State machine testing Lazy to Box transformation
        """

        def __init__(self):
            super(LazyToBox, self).__init__()
            self.lazys: [Lazy[str, int]] = []

        @rule(st.integers())
        def put_Lazy(self, value: int) -> None:
            """
            Transformation from int value to Lazy with Func() -> int.
            """
            self.lazys.append(Lazy(lambda *args: value))


# Generated at 2022-06-24 00:09:31.460794
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    class Foo:
        pass

    assert Lazy(lambda: Foo()) == Lazy(lambda: Foo())

    foo = Foo()
    assert Lazy(lambda: foo) == Lazy(lambda: foo)

    assert Lazy(lambda: Foo()) != Lazy(lambda: Foo())
    assert Lazy(lambda: 1) != Lazy(lambda: 2)



# Generated at 2022-06-24 00:09:39.298092
# Unit test for constructor of class Lazy
def test_Lazy():
    # pylint: disable=missing-docstring

    assert Lazy.of(1) == Lazy(lambda *args: 1)
    assert Lazy.of(1) != Lazy(lambda *args: 2)

    assert str(Lazy.of(1)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f1738514ea0>, value=None, is_evaluated=False]'
    assert str(Lazy.of(1).map(lambda x: x + 1)) == 'Lazy[fn=<function Lazy.<locals>.<lambda>.<locals>.<lambda> at 0x7f17380a4c80>, value=None, is_evaluated=False]'

# Generated at 2022-06-24 00:09:50.899328
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation, Error

    lazy_success = Lazy.of(Validation.success(10))
    assert lazy_success.to_validation() == Validation.success(10)

    lazy_failure = Lazy.of(Validation.failure([Error('error')]))
    assert lazy_failure.to_validation() == Validation.failure([Error('error')])

# Commented out
# Suite of unit tests
# def test_Lazy(): # pragma: no cover
#     def idLazy(x):
#         return Lazy.of(x)

#     def fLazy(x):
#         return Lazy.of(x + 1)

#     def gLazy(x):
#         return Lazy.of(x + 2)

#    

# Generated at 2022-06-24 00:10:03.309123
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe, Empty

    assert str(Lazy(lambda: 'a')) == "Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f3d3b3c3d08>, value=None, is_evaluated=False]"
    assert str(Lazy.of('a')) == "Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f3d3b3c3b70>, value=None, is_evaluated=False]"
    assert Lazy.of('a').get() == 'a'
    assert isinstance(Lazy.of('a').to_maybe(), Maybe)
    assert Lazy.of('a').to_maybe().get() == 'a'

# Generated at 2022-06-24 00:10:11.047551
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def lazy_test(a):
        # type: (float) -> float
        return a * a

    assert Lazy(lambda a: a * a).to_either().right().get() == 4
    assert Lazy.of(2).to_either().right().get() == 2
    assert Lazy(lazy_test).to_either(2.5).right().get() == 6.25
    assert Lazy.of(2).to_either(2.5).right().get() == 2


# Generated at 2022-06-24 00:10:20.993352
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Right

    def function(x):
        return x + 10

    def function2(x):
        return x * 2

    def mul(x):
        return x * 2

    def add(x):
        return x + 10

    assert str(Lazy.of(5).map(mul)) == 'Lazy[fn=<function Lazy.map.<locals>.<lambda> at 0x7f8e19f74d08>, value=None, is_evaluated=False]'

# Generated at 2022-06-24 00:10:27.649536
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def construct_fn(*args):
        return args[0]

    lazy = Lazy(construct_fn)
    assert lazy.to_try().is_success()

    def construct_fn(*args):
        raise Exception('error')

    lazy = Lazy(construct_fn)
    assert lazy.to_try().is_failure()

    try:
        raise Exception('error')
    except Exception as error:
        lazy = Lazy(construct_fn)
        assert lazy.to_try().get_error() == error


# Generated at 2022-06-24 00:10:29.159239
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(1).to_box() == Box(1)


# Generated at 2022-06-24 00:10:35.536622
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.functor.functor import Lazy

    assert str(Lazy(lambda: 3)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x000002E2A68B7A60>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: 3).map(lambda x: x + 1)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda>.<locals>.<lambda> at 0x000002E2A6FF2F28>, value=None, is_evaluated=False]'

# Generated at 2022-06-24 00:10:40.157152
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_cases():
        for run in range(0, 1000):
            if run == 0:  # Empty Lazy
                yield (Lazy(None), Lazy(None))
            elif run == 1:
                yield (Lazy(None), Lazy(lambda: 5))  # Lazy is not evaluated
            elif run == 2:
                evaluated_lazy_instance = Lazy(lambda: 5)
                evaluated_lazy_instance.get()
                yield (evaluated_lazy_instance, evaluated_lazy_instance)  # Lazy is evaluated
            elif run == 3 or run == 4 or run == 5:
                yield (Lazy(lambda: 5), Lazy(lambda: 5))  # equal, but not evaluated Lazy

# Generated at 2022-06-24 00:10:42.526190
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.utils import to_str

    assert to_str(Lazy(lambda x: x)) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:10:51.936931
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from hypothesis import given
    from hypothesis.strategies import tuples
    from hypothesis.strategies import integers, one_of

    # defining hypothesis strategies for different types of Lazy
    lazy_strategies = one_of(
        tuples(integers(), integers()),
        tuples(integers(), strings())
    )

    @given(lazy_strategies)
    def test_equality_of_lazies(lazy_pair):
        """
        Test equality of Lazy where both are evaluated both have the same value and constructor functions.
        """
        is_equal = lazy_pair[0] == lazy_pair[1]
        assert is_equal == True

    test_equality_of_lazies()



# Generated at 2022-06-24 00:10:54.307989
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    """
    >>> Lazy(lambda x: 1).to_box(1)
    Box(1)
    """



# Generated at 2022-06-24 00:11:05.233006
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    import unittest

    class TestCase(unittest.TestCase):

        def test_map_empty_Lazy(self):
            lz = Lazy.of(lambda x: x * x * x).map(lambda x: x * x)

            self.assertEqual(lz.is_evaluated, False)
            self.assertEqual(lz.value, None)

            lz_value = lz.get(2)

            self.assertEqual(lz_value, 16)
            self.assertEqual(lz.is_evaluated, True)
            self.assertEqual(lz.value, 16)

        def test_map_computed_Lazy(self):
            lz = Lazy.of(lambda x: x * x * x)
            l

# Generated at 2022-06-24 00:11:13.690742
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def f1() -> int:
        return 1

    def f2() -> int:
        raise Exception()

    lazy1 = Lazy.of(f1)
    try1 = lazy1.to_try()
    assert Try.success(1) == try1

    lazy2 = Lazy.of(f2)
    try2 = lazy2.to_try()
    assert isinstance(try2.exception, Exception)



# Generated at 2022-06-24 00:11:17.508197
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of(right_value).to_either() == right_value


# Generated at 2022-06-24 00:11:26.190312
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Left, Right

    div = lambda x, y: x / y
    divide = lambda y: lambda x: div(x, y)

    # test data
    a = Lazy(lambda: 1)
    b = Lazy(lambda: 2)
    c = Lazy(lambda: 3)
    d = Lazy(lambda: 4)

    assert a.to_box() == Box(1)
    assert a.to_box().to_lazy() == a
    assert b.to_box() == Box(2)
    assert b.to_box().to_lazy() == b
    assert c.to

# Generated at 2022-06-24 00:11:33.342023
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    lazy_1 = Lazy(lambda x: x + 1)
    lazy_2 = Lazy(lambda x: x * 2)

    assert lazy_1.ap(Box(lambda x: x + 2)).get(3) == 6
    assert lazy_2.ap(Box(lambda x: x + 2)).get(3) == 8


# Generated at 2022-06-24 00:11:40.621820
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.list import List
    from pymonet.monad_maybe import Maybe

    assert Lazy.of('').to_maybe() == Maybe.empty()
    assert Maybe.just(None).toMaybe() == Maybe.empty()

    assert Lazy.of(None).to_maybe() == Maybe.just(None)
    assert Maybe.just(List([3])).toMaybe() == Maybe.just(List([3]))

# Generated at 2022-06-24 00:11:46.705792
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy(lambda x: x).ap(Lazy(lambda y: x * y)) == Lazy(lambda x, y: x * y)
    assert Lazy(lambda x: x + 1).ap(Lazy(lambda z: z * z)) == Lazy(lambda x, z: (x + 1) * z)
    assert Lazy(lambda x: x + 1).ap(Lazy(lambda z: z + z)) == Lazy(lambda x, z: (x + 1) + z)



# Generated at 2022-06-24 00:11:48.526731
# Unit test for constructor of class Lazy
def test_Lazy(): #pragma: no cover
    assert Lazy.of(1) == Lazy(lambda: 1)



# Generated at 2022-06-24 00:11:54.116929
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(2).map(lambda x: x * 2) == Lazy.of(4)
    assert Lazy.of(2).map(lambda x: x + 2) != Lazy.of(4)
    assert Lazy.of(2).map(lambda x: x * 2).map(lambda x: x + 2) == Lazy.of(6)



# Generated at 2022-06-24 00:11:56.801651
# Unit test for method map of class Lazy
def test_Lazy_map():
    lazy = Lazy(lambda: 1)
    assert lazy.map(lambda x: x * 3).get() == 3
    assert lazy.map(lambda x: x * 7).get() == 7



# Generated at 2022-06-24 00:12:02.474620
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.validation import Validation

    def box_func(x: int, y: int) -> Box[int]:
        return Box(x + y)

    value = Lazy(box_func)
    result = value.to_box(10, 5)
    assert isinstance(result, Box)
    assert result.is_box()
    assert result.get() == 15
    assert result.to_validation() == Validation.success(15)



# Generated at 2022-06-24 00:12:08.346828
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    fn1 = lambda *args: 1
    assert Lazy(fn1).to_box() == Box(1)

    fn2 = lambda *args: 'abc'
    assert Lazy(fn2).to_box() == Box('abc')

    fn3_def = lambda *args: abc
    assert Lazy(fn3_def).to_box() == Box(abc)

    fn4 = lambda *args: 1 / 0
    assert Lazy(fn4).to_box() == Box(1 / 0)


# Generated at 2022-06-24 00:12:11.223774
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(int)("3") == 3
    assert Lazy(int)("3") == 3
    assert Lazy(int)("3") == 3


# Generated at 2022-06-24 00:12:18.244197
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of([1, 2, 3]).to_validation() == Validation.success([1, 2, 3])
    assert Lazy(lambda x: x).to_validation({}) == Validation.success({})
    assert Lazy(lambda x, y: x == y).to_validation(True, True) == Validation.success(True)
    assert Lazy(lambda x, y: x == y).to_validation(True, False) == Validation.success(False)



# Generated at 2022-06-24 00:12:28.397343
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    def throw_error():
        raise Exception('Error was thrown')

    def is_successful(try_obj):
        return isinstance(try_obj, Try) and try_obj.is_successful()

    def is_failure(try_obj):
        return isinstance(try_obj, Try) and try_obj.is_failure()

    assert is_successful(Lazy.of(1).to_try())
    assert is_successful(Lazy.of(throw_error).to_try())
    assert is_failure(Lazy.of(throw_error).to_try())

# Generated at 2022-06-24 00:12:38.062006
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.validation import err

    f1 = lambda x: x * 2
    f2 = lambda x: x + 2
    f3 = lambda x: x * 3

    assert Lazy(f1).__eq__(Lazy(f1)) is True
    assert Lazy(f1).__eq__(Lazy(f2)) is False
    assert Lazy(f2).__eq__(Lazy(f1)) is False
    assert Lazy(f1).__eq__(Lazy(f1).get()) is False
    assert Lazy(f1).__eq__(Try(f2, 3).get()) is False

# Generated at 2022-06-24 00:12:48.472748
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():

    # Function with one string argument returning integer
    def length(string):
        return len(string)

    # Lazy with is not evaluated and contains length function
    not_evaluated_lazy_len_as_int = Lazy(length)

    # Lazy with is evaluated and contains length function
    evaluated_lazy_len_as_int = Lazy(length)
    evaluated_lazy_len_as_int.get('can be any value')

    # Lazy with is evaluated and contains length function
    evaluated_lazy_with_different_value = Lazy(lambda string: len(string))
    evaluated_lazy_with_different_value.get('can be any other value')

    assert (Lazy(length) == Lazy(length)) == True

# Generated at 2022-06-24 00:12:54.779349
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    assert Lazy(lambda: 'a').to_either() == Right('a')

    def throw_exception():
        raise Exception('Boom')

    assert Lazy(throw_exception).to_either() == Left(Exception('Boom'))

    assert Lazy(lambda _: 'a').to_either() == Right('a')


# Generated at 2022-06-24 00:13:04.581259
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Unit test for method map of class Lazy
    """
    from pymonet.compare import compare

    lazy = Lazy.of(0)
    lazy_mapped = lazy.map(lambda x: x + 1)
    
    assert lazy_mapped.get() == 1
    assert lazy_mapped.to_box().get() == 1
    assert lazy_mapped.to_either().get() == 1
    assert lazy_mapped.to_maybe().get() == 1
    assert lazy_mapped.to_try().get() == 1
    assert lazy_mapped.to_validation().get() == 1

    assert compare(lazy, Lazy.of(0))
    assert compare(lazy_mapped, Lazy.of(1))


# Generated at 2022-06-24 00:13:07.081562
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).get() == 2



# Generated at 2022-06-24 00:13:10.554707
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert(isinstance(Lazy.of(1).to_validation(), Validation))
    assert(Lazy.of(1).to_validation() == Validation([], 1))


# Generated at 2022-06-24 00:13:20.139489
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right
    from pymonet.tests.test_either import add, multiply, divide

    assert isinstance(Lazy.of(1).to_either(), Right)
    assert Lazy.of(1).to_either().equals(Right(1))

    assert isinstance(Lazy.of(1).map(add(1)).to_either(), Right)
    assert Lazy.of(1).map(add(1)).to_either().equals(Right(2))

    assert isinstance(Lazy.of(2).ap(Lazy.of(add)).to_either(), Right)
    assert Lazy.of(2).ap(Lazy.of(add)).to_either().equals(Right(3))


# Generated at 2022-06-24 00:13:22.677167
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    x = 1
    assert Lazy(lambda: x).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:13:26.997844
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of('car').get() == 'car'
    assert Lazy.of([1, 2]).get() == [1, 2]
    assert Lazy.of({'a': 123}).get() == {'a': 123}



# Generated at 2022-06-24 00:13:31.695950
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Error

    assert Lazy(lambda: 0).to_try() == Try(0)
    assert Lazy(lambda: 1/0).to_try() == Try(Error(ZeroDivisionError))

# Generated at 2022-06-24 00:13:38.015519
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    maybe_square = Maybe.of(lambda x: x * x)
    maybe_three = Maybe.of(3)
    assert Lazy.of(5).ap(maybe_square).to_maybe() == Maybe.just(9)
    assert Lazy.of(5).ap(Maybe.nothing).to_maybe() == Maybe.nothing
    assert Lazy.of(6).ap(maybe_three).to_maybe() == Maybe.just(18)


# Generated at 2022-06-24 00:13:42.882152
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    def test(argument):
        return argument

    lazy = Lazy.of(test)
    assert lazy.to_box('python') == Box('python')
    assert lazy.to_box(None) == Box(None)


# Generated at 2022-06-24 00:13:48.340682
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right

    from pymonet.validation import Validation

    assert Right(Validation.success(42).get()) == Lazy.of(Lazy.of(Validation.success(42)).get()).to_either()
    assert Left('error') == Lazy.of(Validation.failure(Lazy('error').get())).to_either()


# Generated at 2022-06-24 00:13:51.262095
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function(value):
        return value ** 2

    value = 3
    lazy_instance = Lazy(test_function)

    assert 9 == lazy_instance.get(value)


# Generated at 2022-06-24 00:13:55.127097
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    lazy = Lazy.of(10)
    lazy_fn = Lazy.of(lambda x: x + 10)

    assert lazy.ap(lazy_fn).get() == 20

    lazy_box = Box(lambda x: x + 50)
    assert lazy.ap(lazy_box).get() == 60

# Generated at 2022-06-24 00:14:06.249406
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.functor import Functor

    import operator

    functor = Functor(Lazy.of(2))
    assert not Lazy.of(1) == Lazy.of(2)
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) == functor.map(lambda x: x - 1).f.get()

    functor2 = Functor(Lazy.of(lambda x, y: x + y))
    adder1 = lambda x, y: x + y
    adder2 = lambda x, y: x * y

    assert functor2.map(operator.add).f.get(2, 1) == adder1(2, 1)

# Generated at 2022-06-24 00:14:08.667255
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # pylint: disable=unused-variable
    lazy_fn = Lazy.of(lambda x: x * 2)
    lazy_value = Lazy.of(2)
    result = lazy_value.ap(lazy_fn)

    assert result.get() == 4

# Generated at 2022-06-24 00:14:16.009217
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from functools import partial

    # given
    func = partial(lambda x, y: x + y, 1)
    lazy = Lazy(func)

    # when
    result = lazy.__str__()

    # then
    assert result == 'Lazy[fn=functools.partial(<function <lambda> at 0x{}>, value=None, is_evaluated=False]'.format(
        hex(id(func))[2:]
    )


# Generated at 2022-06-24 00:14:25.883329
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def def_A(*args):
        return 10

    def def_B(*args):
        return 20

    def def_C(*args):
        return 30

    lazy = Lazy(def_A)

    assert lazy.to_maybe().is_just

    # for lazy.map(def_B).get()
    assert lazy.map(def_B).to_maybe().is_just

    # for lazy.map(def_B).map(def_C).get()
    assert lazy.map(def_B).map(def_C).to_maybe().is_just

    # for lazy.map(def_B).map(lambda x: x*3).get()
    assert lazy.map(def_B).map(lambda x: x*3).to_maybe().is_just


# Generated at 2022-06-24 00:14:27.597860
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda x: x) is not None  # type: ignore



# Generated at 2022-06-24 00:14:36.317381
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    constructor_fn = lambda: 1

    lazy1 = Lazy(constructor_fn)
    next_lazy = lazy1.bind(lambda x: Lazy(lambda: x + 1))
    assert next_lazy.get() == 2

    # when constructor_fn is evaluated should not be called again
    assert next_lazy.get() == 2

    lazy2 = Lazy(constructor_fn)
    next_lazy = lazy2.bind(lambda x: Lazy(lambda: x + 1))
    assert next_lazy.get() == 2

    # when constructor_fn is evaluated should not be called again
    assert next_lazy.get() == 2

    # object are equal even if they have different constructor functions
    assert lazy1 == lazy2

    # object are not equal when lazy value is different
    lazy2.constructor_

# Generated at 2022-06-24 00:14:41.989672
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Either

    def succ(x):
        return Lazy(lambda: x)

    def fail(x):
        return Lazy(lambda: 1 / 0)

    assert succ(20).to_either() == Either.pure(20)
    assert fail(20).to_either() == Either.left(ZeroDivisionError())



# Generated at 2022-06-24 00:14:47.420931
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def f(x):
        return x + 1

    def g(x):
        return x + 2

    def h(x):
        return x + 3

    lazy_fn = Lazy.of(f).map(g).ap(Lazy.of(h(1)))
    assert lazy_fn.get() == f(g(h(1)))

# Generated at 2022-06-24 00:14:53.670293
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Lazy(lambda: 10).to_box() == Box(10)
    assert Lazy(lambda: 10).to_either() == Right(10)
    assert Lazy(lambda: 10).to_maybe() == Maybe.just(10)
    assert Lazy(lambda: 10).to_validation() == Validation.success(10)


# Generated at 2022-06-24 00:14:58.951330
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right, Either

    # GIVEN
    lazy = Lazy(lambda x: x * 2)
    # WHEN
    result = lazy.to_either(5)
    # THEN
    assert isinstance(result, Either) is True
    assert isinstance(result, Right) is True
    assert result.value == 10



# Generated at 2022-06-24 00:15:03.465141
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-24 00:15:07.742073
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Validation.of('lazy').to_validation() == Lazy.of(Validation.of('lazy'))
    assert Validation.of('lazy').to_validation().to_validation() == Lazy.of(Validation.of('lazy'))


# Generated at 2022-06-24 00:15:17.881172
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Test for the method get of class Lazy
    """
    lz = Lazy(lambda x: x+2)

    assert lz.get(2) == 4

    lz = Lazy(lambda x: x+2).map(lambda x: x*1)

    assert lz.get(2) == 4

    lz = Lazy(lambda x: x+2).map(lambda x: x*1).map(lambda x: x-3)

    assert lz.get(5) == 4

    lz = Lazy(lambda x: x+2).map(lambda x: x*1).map(lambda x: x-3).map(lambda x: 42 + x)

    assert lz.get(5) == 46


# Generated at 2022-06-24 00:15:20.068202
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of('test').to_either() == Right('test')


# Generated at 2022-06-24 00:15:25.139633
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    obj = Lazy(lambda: 1).to_validation()
    assert type(obj) is Validation
    assert obj.is_success()
    assert obj.is_success()
    assert obj.get_value() == 1



# Generated at 2022-06-24 00:15:32.405040
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def f(x):
        return x + 1

    def g(x):
        return x + 2

    assert Lazy.of(5).to_try() == Try.of(lambda: 5)
    assert Lazy.of(5).map(f).to_try() == Try.of(f, 5)
    assert Lazy.of(5).map(f).map(g).to_try() == Try.of(g, f(5))


# Generated at 2022-06-24 00:15:37.297974
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    """
    Test_Lazy___str__
    """
    from pymonet.test_utils import assert_fn_less_than, assert_fn_more_than

    assert_fn_more_than(Lazy.of(1).__str__(), 1000)
    assert str(Lazy.of(1)) == 'Lazy[fn=<function <lambda> at 0x10c9bf7a0>, value=None, is_evaluated=False]'
    assert str(Lazy.of(1).get()) == '1'


# Generated at 2022-06-24 00:15:42.147093
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def foo(a, b):
        return a + b

    def bar(a, b):
        return foo(a, b)

    def add1(a):
        return a + 1

    def mult2(a):
        return a * 2

    assert Lazy(bar).ap(Lazy(foo)).get(7, 6) == 13



# Generated at 2022-06-24 00:15:49.145138
# Unit test for constructor of class Lazy
def test_Lazy():
    """
    >>> Lazy.of(1)
    Lazy[fn=<function <lambda> at 0x108e8d8c8>, value=None, is_evaluated=False]
    >>> Lazy.of(1) == Lazy.of(1)
    True
    >>> Lazy.of(1) == Lazy.of(2)
    False
    >>> Lazy.of(1).get()
    1
    >>> Lazy.of(1).is_evaluated
    True
    >>> Lazy.of(1).value
    1
    >>> Lazy.of(1).get()
    1
    """
    pass



# Generated at 2022-06-24 00:15:59.024049
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right

    assert Lazy(lambda: 'abc').to_either() == Right('abc')
    assert Lazy(lambda: 10/0).to_either() == Left(ZeroDivisionError('division by zero'))
    assert Lazy(lambda: 'val').to_either() == Right('val')
    assert Lazy(lambda: [1, 2, 3]).to_either() == Right([1, 2, 3])
    assert Lazy(lambda: {'a': 1}).to_either() == Right({'a': 1})
    assert Lazy(lambda: 2 + 2).to_either() == Right(4)


# Generated at 2022-06-24 00:16:03.116512
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def throwing_fn(*args):
        if args[0] == 1:
            raise Exception('Exception')
        return args[0]

    lazy_throwing = Lazy(throwing_fn)
    assert Try.of(lazy_throwing.get, 0).get() == 0
    assert Try.of(lazy_throwing.get, 1).is_failure()



# Generated at 2022-06-24 00:16:08.051957
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn():
        return "A"

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)

    assert lazy_1 == lazy_2
    assert lazy_1.value == lazy_2.value
    assert lazy_1.constructor_fn == lazy_2.constructor_fn



# Generated at 2022-06-24 00:16:14.350275
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.types import Lazy
    from pymonet.function import Function

    f = lambda x: x + 1
    g = lambda x: x - 2
    x = Lazy.of(1).map(f).ap(Lazy.of(g)) # x == 2
    y = Lazy.of(f).ap(Lazy.of(g).ap(Lazy.of(1))) # y == 2

    assert x == y


# Generated at 2022-06-24 00:16:17.379400
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def tryable_fn():
        raise Exception('Error')
        return 'result'

    assert Lazy(tryable_fn).to_try() == Lazy(tryable_fn).to_try().map(lambda x: x.to_lazy()).get().to_try()

# Generated at 2022-06-24 00:16:23.668250
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_try import Try

    def return_arg(arg):
        return arg

    lazy = Lazy(lambda arg: arg)
    assert lazy.get(1) == 1

    def div(arg):
        return 1 / arg

    lazy = Lazy(lambda arg: 1 / arg)
    assert lazy == lazy.get(1)
    assert lazy == lazy.get(0)
    assert lazy.get(1).get(1) == 1
    assert lazy.get(0).get(0) == 1

    def undefined(arg):
        return 1 / 0

    lazy = Lazy(lambda arg: 1 / 0)
    assert lazy.get(0) == 1
    assert Try.of(undefined, 0) == Try.success(1)

# Generated at 2022-06-24 00:16:28.533214
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.monad_maybe import Maybe
    assert Lazy(lambda: 2) == Lazy(lambda: 2)
    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)
    # assert Lazy(lambda: Maybe.of(2)) == Lazy(lambda: Maybe.of(2))



# Generated at 2022-06-24 00:16:30.144896
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    lazy = Lazy.of('abcd')
    box = lazy.to_box()
    assert box == Box('abcd')


# Generated at 2022-06-24 00:16:35.344365
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test __eq__ method of Lazy

    :returns: None
    :rtype: None
    """
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x, y: x))
    assert Lazy(lambda x: x, 10).__eq__(Lazy(lambda x: x, 10))
    assert not Lazy(lambda x: x, 10).__eq__(Lazy(lambda x: x, 11))



# Generated at 2022-06-24 00:16:43.511879
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    assert issubclass(Lazy, Functor)
    assert issubclass(Lazy, Applicative)
    assert issubclass(Lazy, Monad)

    lazy1 = Lazy(lambda: 1)
    assert Lazy.of(1) == lazy1



# Generated at 2022-06-24 00:16:46.043877
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy.of('asd').to_either() == Right('asd')



# Generated at 2022-06-24 00:16:52.228257
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.maybe import Maybe

    lazy = Lazy(lambda x: x + 1)

    assert lazy.bind(Maybe.nothing) == Lazy(lambda x: Maybe.nothing(x + 1))
    assert lazy.bind(lambda x: Maybe.just(x + 1)) == Lazy(lambda x: Maybe.just(x + 1).get(x + 1))



# Generated at 2022-06-24 00:16:54.383040
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy(lambda: 1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:17:03.083849
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    from pymonet.box import Box

    def throw_exception(_):
        print('I shouldn\'t be here')
        raise Exception('It should be dead')

    def return_string(value: str) -> str:
        return value

    assert str(Lazy(return_string)) == 'Lazy[fn=<function test_Lazy.<locals>.return_string at 0x10694a8c8>, value=None, is_evaluated=False]'
    assert Lazy(throw_exception) == Lazy(throw_exception)

    assert Lazy(return_string) == Lazy(return_string)
    assert Lazy(return_string).constructor_fn('Hello') == 'Hello'
    assert Lazy(return_string).get('Test') == 'Test'
    assert Lazy