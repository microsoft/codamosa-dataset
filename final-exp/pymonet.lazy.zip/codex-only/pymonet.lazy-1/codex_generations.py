

# Generated at 2022-06-24 00:06:54.686375
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def f():  # pragma: no cover
        raise ValueError

    lazy = Lazy(f)
    assert lazy != Lazy(f)

    assert lazy.to_try() == lazy
    assert lazy.constructor_fn is f

    assert Lazy.of(123).to_try() == Lazy.of(123)



# Generated at 2022-06-24 00:07:02.479305
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda: 2) == Lazy(lambda: 2)
    assert Lazy(lambda: 2) != Lazy(lambda: 3)
    assert str(Lazy(lambda: 2)) == 'Lazy[fn=<function test_Lazy.<locals>.<lambda> at 0x7fcd8bf53b70>, value=None, is_evaluated=False]'
    assert Lazy.of(3) == Lazy.of(3)
    assert Lazy.of(3) != Lazy.of(2)



# Generated at 2022-06-24 00:07:06.154329
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    lazy = Lazy(lambda: 1)
    assert lazy.to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:07:13.835682
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    add5 = lambda x: x + 5

    assert Lazy.of(4).to_try() == Try.success(4)
    assert Lazy.of(4).map(add5).to_try() == Try.success(9)
    assert Try.of(lambda: 1 / 0).to_try() == Try.failure(ZeroDivisionError)
    assert Try.of(lambda: 1 / 0).map(add5).to_try() == Try.failure(ZeroDivisionError)



# Generated at 2022-06-24 00:07:21.932187
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def divide(a, b):
        return a / b

    success_value = Lazy(lambda: divide(1, 1)).to_try().fold(lambda x: x, lambda: 'test')
    assert success_value == 1

    error_to_try = Lazy(lambda: divide(1, 0)).to_try()
    assert isinstance(error_to_try, Try)
    assert error_to_try.is_failure()

    assert error_to_try.fold(lambda e: True, lambda: False)



# Generated at 2022-06-24 00:07:24.616445
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    def value() -> int:
        return 9

    assert Lazy(value).to_maybe() == Maybe.just(9)



# Generated at 2022-06-24 00:07:27.224199
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda x: x + 1)
    assert lazy.get(3) == 4



# Generated at 2022-06-24 00:07:32.161875
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test for method ap of class Lazy.

    :return: None
    """
    assert Lazy(lambda x: x + 1).ap(Lazy(lambda x: x * 2)) == Lazy(lambda x: x * 2 + 1)



# Generated at 2022-06-24 00:07:37.557500
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add_five(x):
        return x + 5

    def multiply_five(x):
        return x * 5

    def add_and_multiply_five_lazy(num):
        return Lazy(lambda *_: add_five(num)).ap(Lazy(lambda *_: multiply_five(num)))

    assert add_and_multiply_five_lazy(2).get() == 35

# Generated at 2022-06-24 00:07:45.831424
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(None).map(lambda x: x + 1) == Lazy.of(None).map(lambda x: x + 1)
    assert not(Lazy.of(1) == Lazy.of(None))
    assert not(Lazy.of(None).map(lambda x: x + 1) == Lazy.of(None))
    assert not(Lazy.of(None) == Lazy.of(1))
    assert not(Lazy.of(1) == None)

# Generated at 2022-06-24 00:07:50.237602
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def raise_error():
        raise ValueError('raise_error')
    fn = Lazy(raise_error)
    assert isinstance(fn.to_try(), Try)
    assert fn.to_try().is_failure()
    assert (fn.to_try() == Try(raise_error))

    def return_success():
        return 1
    fn = Lazy(return_success)
    assert isinstance(fn.to_try(), Try)
    assert fn.to_try().is_success()
    assert fn.to_try() == Try(1)

# Generated at 2022-06-24 00:07:59.290374
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(2).to_box() == Box(2)
    assert Lazy.of(3).to_either() == Right(3)
    assert Lazy.of(4).to_maybe() == Maybe.just(4)
    assert Lazy.of(5).to_try() == Try.of(lambda: 5)
    assert Lazy.of(6).to_validation() == Validation.success(6)

if __name__ == "__main__":  # pragma: no cover
    test_Lazy_to_validation()

# Generated at 2022-06-24 00:08:06.568335
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_fn(a):
        return a

    def test_mapper(a):
        return a

    assert Lazy(test_fn) == Lazy(test_fn)
    assert Lazy(test_fn) != Lazy(test_mapper)
    assert Lazy(test_fn).map(test_mapper) != Lazy(test_fn).map(test_mapper)


test_Lazy___eq__()

# Generated at 2022-06-24 00:08:09.276150
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    f = lambda: 1
    lazy = Lazy(f)
    maybe = Maybe.just(1)
    assert lazy.to_maybe() == maybe

# Generated at 2022-06-24 00:08:16.300012
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Unit test for method map of class Lazy
    """
    assert Lazy(lambda n: n + 1).map(lambda a: a * 2).get(1) == 4
    assert Lazy(lambda n: n + 1).map(lambda a: a * 2).get(2) == 6
    assert isinstance(Lazy(lambda n: n + 1).map(lambda a: a * 2), Lazy)


# Generated at 2022-06-24 00:08:23.662865
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add(x, y):
        return x + y

    def mul(x, y):
        return x * y

    assert Lazy(add).map(mul) == Lazy(lambda x, y: (x + y) * (x + y))
    assert Lazy(mul).map(add) == Lazy(lambda x, y: (x * y) + (x * y))
    assert Lazy(add).map(add) == Lazy(lambda x, y: (x + y) + (x + y))


# Generated at 2022-06-24 00:08:28.128836
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    # Given
    function = Lazy.of(lambda x: x * 2)
    value = Lazy.of(lambda a, b: a + b)
    # When
    result = function.ap(value)
    # Then
    assert result.constructor_fn(3, 5) == 4 * (3 + 5)



# Generated at 2022-06-24 00:08:34.258753
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    add_box = Box(add)
    five_box = Box(5)
    lazy_box = Lazy.of(add_box)
    maybe = Maybe.just(five_box)
    lazy_maybe = Lazy.of(maybe)

    assert Lazy(lambda x: Lazy(lambda y: x).ap(y)) == Lazy(lambda x: Lazy(lambda y: x).ap(y))
    assert lazy_box.ap(lazy_maybe) == Lazy.of(10)

# Generated at 2022-06-24 00:08:39.448456
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Case: calling bind method.
    Expected: fold function is called
    """
    def fold(input):
        fold.called = True
        return input

    Lazy(lambda: 5).bind(lambda value: Lazy(lambda: fold(value))).get()

    assert fold.called is True


# Generated at 2022-06-24 00:08:45.003250
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    Unit test for method get of class Lazy
    """
    from pymonet.box import Box
    from pymonet.maybe import Just

    assert Lazy.of(1) == Lazy(lambda: 1) == Lazy(lambda: 1).to_box() == Lazy(lambda: 1).to_either() == Just(1) == Box(1)

# Generated at 2022-06-24 00:08:50.646812
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    def lazy_box():
        return Box(42)

    lazy = Lazy(lazy_box)

    box = lazy.to_box()

    assert box == Box(42)

lazy_box = Lazy(lambda: 42)
lazy_empty = Lazy(lambda: '')


# Generated at 2022-06-24 00:08:51.702934
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of(1).to_maybe() == Maybe.just(1)
    assert Lazy.of(2).to_maybe() == Maybe.just(2)



# Generated at 2022-06-24 00:08:56.668239
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert (
        Lazy(lambda: 12).to_maybe() ==
        Lazy.of(12).to_maybe() ==
        Lazy.of(12).map(lambda value: value).to_maybe() ==
        Maybe.just(12)
    )


# Generated at 2022-06-24 00:08:58.712881
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda x: x + 1).bind(lambda x: Lazy.of(x + 1)).get(1) == 3


# Generated at 2022-06-24 00:09:03.717281
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def add_one(value):
        return value + 1

    result = Lazy(add_one).get(1)
    assert result == 2


# Generated at 2022-06-24 00:09:07.311900
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Nothing

    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Nothing()) == Lazy.of(lambda x: x + 1)



# Generated at 2022-06-24 00:09:08.286082
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Either

    assert Lazy.of(1).to_either() == Either.right(1)


# Generated at 2022-06-24 00:09:11.480763
# Unit test for method get of class Lazy
def test_Lazy_get():
    def my_first_evaluated_fn(arg: int) -> int:
        return arg

    lazy = Lazy.of(my_first_evaluated_fn(1))
    assert lazy.constructor_fn(2) == my_first_evaluated_fn(1)
    assert lazy.get(2) == my_first_evaluated_fn(1)
    assert lazy.is_evaluated is True

    assert lazy.get(2) == my_first_evaluated_fn(1)
    assert lazy.is_evaluated is True



# Generated at 2022-06-24 00:09:22.219217
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Will create Lazy with function:
    def foo(a):
        return a ** 2

    And will apply Lazy with function:
    def double(a):
        return a * 2

    And call fold method.
    Value should be 32

    :return: None
    :rtype: NoneType
    """
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def foo(a):
        return a ** 2

    def double(a):
        return a * 2

    applier = Lazy(double)

    result = Lazy(foo).ap(applier).get(2)
    assert result == 32

    result = Lazy(foo).ap(applier).to_try

# Generated at 2022-06-24 00:09:24.977246
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    # given
    lazy = Lazy.of("result")
    # when
    result = lazy.bind(lambda o: Lazy.of("{} - bind".format(o)))
    # then
    assert result == Lazy.of("result - bind")

# Generated at 2022-06-24 00:09:32.987842
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Success, Failure

    lazy_fn = Lazy(lambda name: name)

    assert lazy_fn.to_try().equals(Try.of(lambda: lazy_fn))
    assert lazy_fn.to_try('hello').equals(Try.of(lambda: lazy_fn, 'hello'))
    assert lazy_fn.to_try('hello').equals(Success('hello'))
    assert lazy_fn.to_try(name='hello').equals(Success('hello'))

    lazy_fn = Lazy(lambda name: int(name))

    assert lazy_fn.to_try('4').equals(Success(4))
    assert lazy_fn.to_try('4wew').equals(Failure(ValueError))

# Generated at 2022-06-24 00:09:38.105053
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    def always_return_true(*_):
        return True

    def always_return_false(*_):
        return False

    assert Lazy.of(None).to_either() == Either.right(None)
    assert Lazy.of(1).to_either() == Either.right(1)

    assert Lazy(always_return_true).to_either() == Either.right(True)
    assert Lazy(always_return_false).to_either() == Either.right(False)


# Generated at 2022-06-24 00:09:43.627939
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    fn = lambda x: x * 2

    obj = Lazy.of(1)
    actual = obj.to_either()
    assert actual == Right(1)
    assert actual.is_right()
    assert not actual.is_left()

    actual = obj.map(fn).to_either()
    assert actual == Right(2)
    assert actual.is_right()
    assert not actual.is_left()


# Generated at 2022-06-24 00:09:47.012460
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test case for map method of class Lazy.
    """
    lazy_bool = Lazy(lambda x: True).map(lambda val: not val)

    assert lazy_bool.constructor_fn(None) is False

# Generated at 2022-06-24 00:09:56.203816
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Given
    def lazy_factory(value: int) -> Callable[[int], int]:  # type: ignore
        def lazy(x: int) -> int:
            return value
        return lazy

    # When
    lazy_value = Lazy(lazy_factory(9))
    lazy_mapped = lazy_value.map(lambda x: x + 1)

    # Then
    assert lazy_value != lazy_mapped
    assert lazy_mapped.get() == 10
    assert lazy_mapped.constructor_fn != lazy_value.constructor_fn


# Generated at 2022-06-24 00:10:05.951991
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def init_fn():
        return 1

    def adder_fn(value):
        return value + 1

    def mapper_fn(value):
        return value + 2

    def to_box_fn(value):
        return Box(value + 2)

    def to_maybe_fn(value):
        return Maybe.of(value + 2)

    def to_try_fn(value):
        return Try.of(lambda: value + 2)

    def to_validation_fn(value):
        return Validation.success(value + 2)


# Generated at 2022-06-24 00:10:09.762016
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right

    # GIVEN
    def f():
        return 5

    # WHEN
    value: Right[int] = Lazy(f).to_either()

    # THEN
    assert value == Right(5)



# Generated at 2022-06-24 00:10:19.983265
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.monad_try import Try

    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f0b84ecbd08>, value=None, is_evaluated=False]'\
        '|>Lazy[fn={}, value={}, is_evaluated={}]'.format(lambda: 1, None, False)


# Generated at 2022-06-24 00:10:22.599071
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    def constructor_fn(*args):
        return 42

    assert Lazy(constructor_fn).to_box() == Box(42)



# Generated at 2022-06-24 00:10:29.764201
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Success, Failure

    def f(value):
        if value:
            return Success(value)

        return Failure(value)

    assert Lazy.of(1).to_try() == Success(1)
    assert Lazy.of(None).to_try() == Failure(None)
    assert Lazy.of([{}]).to_try() == Success([{}])
    assert Lazy.of(1).map(f).to_try() == Success(1)
    assert Lazy.of(0).map(f).to_try() == Failure(0)



# Generated at 2022-06-24 00:10:30.966836
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy.of(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:10:39.916844
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    def make_computations():
        raise Exception()

    lazy = Lazy(make_computations)

    assert (Validation.success(None) == lazy.to_validation())

    def make_computations2():
        return 'Some string'

    lazy = Lazy(make_computations2)

    assert (Validation.success('Some string') == lazy.to_validation())



# Generated at 2022-06-24 00:10:45.982845
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    def fn(value):
        return value

    lazy = Lazy.of(0)
    assert lazy.to_box() == Box(0)

    lazy = Lazy(fn).map(Box.of)
    assert lazy.to_box() == Box(Box(0))

    lazy = Lazy(fn).map(Maybe.just)
    assert lazy.to_box() == Box(Maybe.just(0))

    lazy = Lazy(fn).map(Right.of)
    assert lazy.to_box() == Box(Right(0))

    lazy = Lazy(fn).map(Try.ok)
    assert lazy.to_box() == Box(Try.ok(0))

    lazy = Lazy(fn).map(Validation.success)

# Generated at 2022-06-24 00:10:50.849034
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: 1).map(lambda x: x + 1)) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'
    assert str(Lazy(lambda: 1).get()) == 'Lazy[fn=<lambda>, value=1, is_evaluated=True]'
    assert str(Lazy(lambda: 1).map(lambda x: x + 1).get()) == 'Lazy[fn=<lambda>, value=2, is_evaluated=True]'


# Generated at 2022-06-24 00:10:57.144751
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    # given
    lazy = Lazy(lambda: 1)

    # when
    lazy_str = str(lazy)

    # then
    assert lazy_str == 'Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7f3a3b1c8378>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:11:06.547210
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def throwing() -> None:
        raise TypeError('error')


# Generated at 2022-06-24 00:11:17.866304
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import ValidationFailure

    f = Lazy.of(lambda: 1)
    assert f.to_either() == Right(1)

    f = Lazy.of(lambda: 1)
    assert f.to_either("error") == Right(1)

    f = Lazy.of(lambda: Left("error"))
    assert f.to_either() == Left("error")

    f = Lazy.of(lambda: Left("error"))
    assert f.to_either("error") == Left("error")

    f = Lazy.of(lambda: ValidationFailure("error"))
    assert f.to_either() == Left("error")

    f = Lazy.of(lambda: ValidationFailure("error"))
    assert f.to_either("error")

# Generated at 2022-06-24 00:11:20.233219
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    import pymonet.box as box

    assert Lazy(lambda: 1).to_box() == box.Box(1)



# Generated at 2022-06-24 00:11:28.912802
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    def throwing_fn(value: Maybe) -> Maybe:
        def throwing_fn_inner() -> Maybe:
            if value == Maybe.nothing():
                raise ZeroDivisionError("value is nothing")
            return Maybe.just(value.get() / 2)
        return Try.of(throwing_fn_inner).to_maybe()

    assert Lazy.of(Maybe.just(2)).bind(throwing_fn).to_try() == Try.success(Maybe.just(1))
    assert Lazy.of(Maybe.nothing()).bind(throwing_fn).to_try() == Try.failure(Maybe.nothing())

# Generated at 2022-06-24 00:11:36.885103
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    import unittest

    from pymonet.validation import Validation

    class TestLazyToValidation(unittest.TestCase):
        def test_to_validation_returns_validation(self):
            my_lazy = Lazy.of(1)
            self.assertIsInstance(my_lazy.to_validation(), Validation)

        def test_to_validation_returns_validation_with_value(self):
            my_lazy = Lazy.of(1)
            self.assertEqual(my_lazy.to_validation().get_or_else(None), 1)

    unittest.main()


# Generated at 2022-06-24 00:11:39.460430
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy.of(10) == Lazy.of(10)

# Generated at 2022-06-24 00:11:49.086863
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.box import Box
    from pymonet.either import Either
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Lazy.of(1).to_maybe()
    assert Maybe.just(1) == Lazy.of(1).to_maybe()
    assert Maybe.just(1) == Lazy(lambda x: x + 1).to_maybe(2)
    assert Maybe.just(3) == Maybe.just(2).of(lambda x: x + 1).to_maybe()
    assert Maybe.just(3) == Maybe.just(2).bind(lambda x: Maybe.just(x + 1)).to_maybe()
    assert Maybe.just(3) == Maybe.just(2).ap(Maybe.just(lambda x: x + 1))

    assert Maybe.empty() == Maybe.empty

# Generated at 2022-06-24 00:11:51.394968
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda: 'foo') == Lazy(lambda: 'foo')



# Generated at 2022-06-24 00:11:57.230064
# Unit test for method get of class Lazy
def test_Lazy_get():
    def square(value):
        return value ** 2

    lazy = Lazy(square)
    assert lazy.get(10) == 100
    assert lazy.is_evaluated
    assert lazy.value == 100

    lazy = Lazy(square)
    assert lazy.get(10) == 100
    assert lazy.value == 100
    assert lazy.is_evaluated


# Generated at 2022-06-24 00:12:02.301346
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    example_fn = lambda x: x + 1
    lazy1 = Lazy.of(5)
    lazy2 = lazy1.bind(lambda x: Lazy.of(example_fn(x)))
    lazy3 = lazy2.bind(lambda x: Lazy.of(example_fn(x)))
    answer = lazy3.get()
    assert answer == 7


# Generated at 2022-06-24 00:12:08.222992
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    # We have to_maybe method, which return Maybe monad
    # It's only way to call method (λ) store in Lazy monad
    # λ :: T -> U,
    # λ x = Maybe(x+1)
    # λ 1 = Maybe(2)
    # λ x = Just(2)
    # Lazy(λ)
    # to_maybe(Lazy(λ))
    # Maybe(2)
    # Unwrapped value of Maybe monad is result od
    # calling λ 1 = 2

    lazy = Lazy(lambda x: x+1)
    maybe = lazy.to_maybe(1)

    assert maybe == Maybe(2)
    assert maybe.unwrap() == 2

# Generated at 2022-06-24 00:12:18.279424
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.either import Either

    def function(a):
        return a ** 2

    assert Lazy(function).get(2) == 4
    assert Lazy(function).get(1) == 1
    assert Lazy(function).get(3) == 9
    assert Lazy(function).map(lambda x: x + 2).get(2) == 6
    assert Lazy(lambda: 2).get() == 2
    assert Lazy.of(2).get() == 2
    assert Lazy(lambda: function('a')).to_try().get() == Try.failure(TypeError())

# Generated at 2022-06-24 00:12:21.500521
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy.of(1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-24 00:12:31.399030
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def add_one(n):
        return n + 1

    assert Lazy.of(None) == Lazy.of(None)
    assert Lazy.of(None) != Lazy.of(True)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1).map(add_one) == Lazy.of(1).map(add_one)
    assert Lazy.of(1).map(add_one) != Lazy.of(2).map(add_one)
    assert Lazy.of(1).map(add_one).map(add_one) == Lazy.of(1).map(add_one).map(add_one)

# Generated at 2022-06-24 00:12:39.820591
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def test_fn(value):
        return value

    lazy_val_1 = Lazy(test_fn)
    assert lazy_val_1.constructor_fn(1) == 1
    assert lazy_val_1.get(1) == 1
    assert lazy_val_1.get() == 1
    assert lazy_val_1.get(None) == 1

    lazy_val_2 = Lazy(lambda _: test_fn(2))
    assert lazy_val_2.constructor_fn() == 2
    assert lazy_val_2.get(1) == 2
    assert lazy_val_2.get(None) == 2

    lazy_val_3 = Lazy(lambda: test_fn(3))
    assert lazy_val_3.constructor_fn() == 3

# Generated at 2022-06-24 00:12:42.713314
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x * 2).map(lambda x: x - 1).get(3) == 5
    assert Lazy(lambda x: x * 2).map(lambda x: x - 1).get(3) == 5



# Generated at 2022-06-24 00:12:48.711031
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    # Test on empty Lazy
    assert Lazy(lambda _: None).to_validation() == Validation.success(None)

    # Test on empty Lazy with some value
    assert Lazy(lambda x: x).to_validation(None) == Validation.success(None)
    assert Lazy(lambda x: x).to_validation(1) == Validation.success(1)
    assert Lazy(lambda x: x).to_validation(False) == Validation.success(False)

# Generated at 2022-06-24 00:12:59.145863
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.applicative import Applicative

    def add1(x): return x + 1

    assert Lazy.of(3).ap(Box(add1)) == Applicative(add1).ap(Box(3))
    assert Lazy.of(3).ap(Lazy.of(add1)) == Applicative(add1).ap(Applicative(3))
    assert Lazy.of(3).ap(Lazy.of(add1)).get() == Applicative(add1).ap(Applicative(3)).get()


# Generated at 2022-06-24 00:13:00.366365
# Unit test for constructor of class Lazy
def test_Lazy():
    return Lazy(lambda x: x)


# Generated at 2022-06-24 00:13:03.446126
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    def fn(*args):
        return 'test'

    lazy = Lazy(fn)
    assert lazy.to_maybe() == Maybe.just('test')



# Generated at 2022-06-24 00:13:09.507759
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return 1
    lazy = Lazy(fn)
    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    assert lazy == lazy1
    assert lazy1 == lazy
    assert lazy == lazy2
    assert lazy2 == lazy


# Generated at 2022-06-24 00:13:14.818210
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: ()).get() == ()
    assert Lazy(lambda: True).get()
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 'a').get() == 'a'
    assert Lazy(lambda: [1]).get() == [1]
    assert Lazy(lambda: {}).get() == {}



# Generated at 2022-06-24 00:13:19.908933
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def fn(*args):
        return args[0] * 2

    assert Lazy(fn).to_try(2) == Try.success(4)

    def fn2(*args):
        return 1 / 0

    assert Lazy(fn2).to_try(2) == Try.failure(ZeroDivisionError())


# Generated at 2022-06-24 00:13:24.880081
# Unit test for constructor of class Lazy
def test_Lazy():
    assert str(Lazy(lambda: 1)) == 'Lazy[fn=<lambda>, value=None, is_evaluated=False]'
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:13:28.792327
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    #     GIVEN
    lazy = Lazy(lambda: 123)
    #     WHEN
    string = str(lazy)
    #     THEN
    assert string == 'Lazy[fn={}, value={}, is_evaluated={}]'.format(lazy.constructor_fn, lazy.value, lazy.is_evaluated)


# Generated at 2022-06-24 00:13:38.559472
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def simple_mapper(arg):
        return 'mapped_value'

    fn = Lazy(lambda: 'not_mapped_value')
    fn1 = fn.map(simple_mapper)
    fn2 = fn.bind(lambda x: Lazy.of('mapped_value'))
    fn3 = fn.ap(fn1)
    fn4 = fn.map(lambda x: Lazy(lambda: 'mapped_value'))
    fn5 = fn.bind(lambda x: Lazy(lambda: 'mapped_value'))
    fn6 = fn.ap(Lazy(lambda: simple_mapper))

    assert Lazy.of('value1') == Lazy.of('value1')
    assert fn1 == fn2
    assert fn3 == fn5
    assert fn4 == fn5
    assert fn

# Generated at 2022-06-24 00:13:49.009809
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    test_Lazy_bind
    """
    from pymonet.lazy import Lazy
    from pymonet.applicative_maybe import Just

    lazy = Lazy(lambda x: x + 1)
    lazy = lazy.bind(lambda x: Just(x))
    assert lazy.to_maybe() == Just(2)

    lazy = Lazy(None)
    lazy = lazy.bind(lambda _: Just(5))
    assert lazy.to_maybe() == Just(5)

    lazy = Lazy(lambda x, y: x + y)
    lazy = lazy.bind(lambda x: Lazy(lambda x, y: x + y))
    assert lazy.to_maybe(2, 3) == Just(5)


# Generated at 2022-06-24 00:13:50.848233
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert (Lazy(lambda: 1).to_box()) == Box(1)


# Generated at 2022-06-24 00:13:53.932745
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet import Lazy
    from pymonet.validation import Validation
    from pymonet.validation_error import ValidationError

    assert Lazy.of(1).to_validation() == Validation.success(1)
    assert Lazy.of(-1).to_validation() == Validation.success(-1)
    assert Lazy.of(1.5).to_validation() == Validation.success(1.5)


# Generated at 2022-06-24 00:14:03.853047
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe, Nothing

    assert (
        Lazy.of(lambda a: a * 2)
            .ap(Lazy.of(1))
            .get()
    ) == 2

    assert (
        Lazy.of(lambda a: a * 2).ap(Right(1)).get().value
    ) == 2

    assert (
        Lazy.of(lambda a: a * 2).ap(Left(1)).get().value
    ) == 2

    assert (
        Lazy.of(lambda a: a * 2).ap(Maybe.just(1)).get().value
    ) == 2

    assert (
        Lazy.of(lambda a: a * 2).ap(Nothing()).get().value
    ) == 2

# Generated at 2022-06-24 00:14:15.470944
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.functions import compose
    from pymonet.functions import bind

    def add1(a): return a + 1

    add_one = Lazy.of(add1)

    def mul10(a): return a * 10

    mul_ten = Lazy.of(mul10)

    # mul(add(1))
    res = Lazy.of(1).ap(add_one).ap(mul_ten)  # => Lazy[fn=<function Lazy.map.<locals>.<lambda> at 0x10d8d98c8>, value=None, is_evaluated=False]
    assert res == Lazy(lambda: mul10(add1(1)))

    def add2(a): return a + 2


# Generated at 2022-06-24 00:14:25.618519
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Lazy.of('foo').to_box() == Box('foo')
    assert Lazy.of('foo').map(lambda box: box.get).to_box() == Box('foo')
    assert Lazy.of('foo').map(lambda box: box.get).to_box() == Lazy.of('foo').to_box().map(lambda box: box.get)
    assert Lazy.of('foo').to_box().map(lambda box: box.get).to_box() == Lazy.of('foo').to_box()
    assert Lazy.of('foo').to_box().map(lambda box: box.get).to_box() == L

# Generated at 2022-06-24 00:14:31.060735
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    from pymonet.box import Box

    def func_1() -> bool:
        return True

    def func_2(val: bool):
        return Box.of(val)

    lazy_1 = Lazy(func_1)
    lazy_2 = Lazy(func_2)
    assert lazy_1.get()
    assert lazy_2.get() == Box.of(True)



# Generated at 2022-06-24 00:14:32.969313
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)).get() == 3



# Generated at 2022-06-24 00:14:36.579487
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    def test_constructor_fn():
        pass
    lazy = Lazy(test_constructor_fn)
    assert str(lazy) == 'Lazy[fn=<function test_constructor_fn at 0x0357F1C0>, value=None, is_evaluated=False]'



# Generated at 2022-06-24 00:14:38.766189
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    assert Lazy(lambda: 1).to_box() == Lazy(lambda: 1).to_box(1, 'a') == Lazy(lambda: 1).to_box(1, 'a', [])


# Generated at 2022-06-24 00:14:46.650201
# Unit test for method get of class Lazy
def test_Lazy_get():
    # Empty
    x = Lazy.of(0).get()
    x == 0

    # 1 argument
    x = Lazy(lambda x: x + 5).get(1)
    x == 6

    # more argument
    x = Lazy(lambda x, y: x + y).get(2, 3)
    x == 5

    # return None
    x = Lazy(lambda: None).get()
    x == None



# Generated at 2022-06-24 00:14:53.226739
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.either import Left
    from pymonet.validation import Failure

    assert Lazy.of(100).to_either() == Right(100)
    assert Lazy.of(100).to_either(900) == Right(100)
    assert Lazy.of(100).to_either('900') == Right(100)
    assert Lazy.of(100).to_either(Failure(900)) == Right(100)
    assert Lazy.of(100).to_either(Failure('900')) == Right(100)
    assert Lazy.of(100).to_either(Left(900)) == Right(100)
    assert Lazy.of(100).to_either(Left('900')) == Right(100)
    assert Lazy.of

# Generated at 2022-06-24 00:14:56.023871
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert Lazy.of(1).to_validation().is_success()
    assert Lazy.of(1).to_validation().unwrap_or(-1) == 1


# Generated at 2022-06-24 00:14:59.104077
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(2).bind(lambda x: Lazy.of(x ** 2)).get() == Lazy.of(2 ** 2).get()


# Generated at 2022-06-24 00:15:02.236431
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda x: x ** 2).to_box(3)

    assert lazy == Box(9)



# Generated at 2022-06-24 00:15:05.116990
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda : 1) == Lazy(lambda : 1)
    assert Lazy(lambda : 1) != Lazy(lambda : 2)
    assert Lazy(lambda : 1) != None

# Generated at 2022-06-24 00:15:07.219748
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(2).bind(lambda x: Lazy.of(x ** 2)) == Lazy.of(4)



# Generated at 2022-06-24 00:15:17.182690
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try

    def get_int(input_value):
        return int(input_value)

    assert Lazy.of(10).to_try() == Try.of(get_int, '10')
    assert Lazy.of(10).to_try('10') == Try.of(get_int, '10')
    assert Lazy.of(10).to_try(input_value='10') == Try.of(get_int, '10')
    assert Lazy.of(10).to_try(input_value='test') == Try.of(get_int, 'test')
    assert Lazy.of(10).to_try() != Try.of(get_int, 'test')


# Generated at 2022-06-24 00:15:20.925181
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add1(x):
        return x + 1

    lazy = Lazy(add1)
    result = lazy.map(lambda x: add1(add1(x))).get(1)

    assert result == 3


# Generated at 2022-06-24 00:15:24.608340
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def fn():
        return 10

    instance = Lazy(fn)
    assert(instance == Lazy(fn))
    assert(instance != Lazy(lambda: 20))



# Generated at 2022-06-24 00:15:29.409703
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    lazy = Lazy(lambda x: x)
    fn = lambda x: Lazy(lambda *args: x * x)

    assert lazy.get(10) == 10
    assert lazy.bind(fn).get(10) == 100



# Generated at 2022-06-24 00:15:37.049697
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def simple_lazy_constuctor():
        return 5

    lazy_constuctor = Lazy(simple_lazy_constuctor)
    assert not lazy_constuctor.is_evaluated
    assert lazy_constuctor.value is None
    assert lazy_constuctor.constructor_fn == simple_lazy_constuctor


# Generated at 2022-06-24 00:15:44.895832
# Unit test for method map of class Lazy
def test_Lazy_map():
    # Test of Lazy map using pure
    lazy = Lazy(lambda n: n + 2).map(lambda n: n * 10)
    assert lazy.constructor_fn(0) == 20

    # Test of Lazy map using modified
    def simple_mapper(n: int) -> int:
        return n * 10

    lazy = Lazy(lambda n: n + 2).map(simple_mapper)
    assert lazy.constructor_fn(0) == 20



# Generated at 2022-06-24 00:15:48.252811
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def foo():
        return 'foo'

    lazy_foo = Lazy(foo)
    assert lazy_foo.get() == 'foo'
    assert lazy_foo.is_evaluated is True
    assert lazy_foo.value == 'foo'



# Generated at 2022-06-24 00:15:56.526477
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn():
        return 1

    def fn2():
        return 2

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)
    assert Lazy(fn).map(lambda v: v + 1) == Lazy(fn).map(lambda v: v + 1)
    assert Lazy(fn).map(lambda v: v + 1) != Lazy(fn).map(lambda v: v + 2)



# Generated at 2022-06-24 00:15:59.958985
# Unit test for method get of class Lazy
def test_Lazy_get():
    try:
        Lazy(lambda: 10).get()
    except Exception:  # pragma: no cover
        assert False

    try:
        Lazy(lambda a: a).get(10)
    except Exception:  # pragma: no cover
        assert False



# Generated at 2022-06-24 00:16:09.790956
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monoid import AddMonoidInt, AddMonoidString, MappedMonoid
    from pymonet.either import Either
    from pymonet.validation import Validation

    map_fn_str_to_int = MappedMonoid(AddMonoidInt(), AddMonoidString(), lambda x: int(x))
    map_fn_int_to_str = MappedMonoid(AddMonoidString(), AddMonoidInt(), lambda x: str(x))
    map_fn_either_str_to_int = MappedMonoid(AddMonoidInt(), Either(AddMonoidString(), map_fn_int_to_str),
                                            lambda x: x.get_or_else(0))

# Generated at 2022-06-24 00:16:14.663087
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.monad_maybe import Maybe

    empty_lazy = Lazy.of(None)
    assert empty_lazy.to_maybe() == Maybe.nothing()

    not_empty_lazy = Lazy.of(10)
    assert not_empty_lazy.to_maybe() == Maybe.just(10)


# Generated at 2022-06-24 00:16:22.174614
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.validation import Validation

    def negative_input_error(input):
        return Validation.failure(['input {} is negative'.format(input)])

    def not_integer_input_error(input):
        return Validation.failure(['input {} is not integer'.format(input)])

    def is_positive(value: int) -> Lazy[int, Validation[int, list]]:
        return Lazy(lambda input: Validation.success(input) if input >= 0 else negative_input_error(input))

    def is_integer(value: int) -> Lazy[int, Validation[int, list]]:
        return Lazy(lambda input: Validation.success(input) if isinstance(input, int) else not_integer_input_error(input))


# Generated at 2022-06-24 00:16:24.098842
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(str).get(1) == "1"

# Generated at 2022-06-24 00:16:31.093566
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    assert Lazy(lambda x: x * 2).ap(Lazy(lambda x: x + 1)).get(3) == 8
    assert Lazy(lambda x: x + 1).ap(Lazy(lambda x: x * 2)).get(3) == 7
    assert Lazy(lambda x: x + 1).ap(Box(3)).to_box().value == 4
    assert Lazy(lambda x: x * 2).ap(Maybe.just(3)).get() == 6
    assert Lazy(lambda x: x + 2).ap(Maybe.nothing()).get() is None
    assert Lazy(lambda x: x + 2).ap(Right(3)).get() == 5


# Generated at 2022-06-24 00:16:38.061536
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def string_is_number_validator(string):
        try:
            int(string)
            return Validation.success(string)
        except ValueError:
            return Validation.failure([ValueError()])
    number_validator = Lazy(string_is_number_validator)

    assert Validation.success('1') == number_validator.get('1').to_validation()
    assert Validation.failure([ValueError()]) == number_validator.get('abcdef').to_validation()

# Generated at 2022-06-24 00:16:46.228677
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    def my_function(a: int, b: int) -> int:
        return a + b

    def my_failed_function(a: int, b: int) -> int:
        raise ValueError('f')

    assert Try.success(3) == Lazy(my_function).to_try(1, 2)
    assert Try.failure(ValueError('f')) == Lazy(my_failed_function).to_try(1, 2)

# Generated at 2022-06-24 00:16:56.910579
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def fn_to_box(value: int) -> int:
        return value ** 2

    box_test = Lazy(fn_to_box).to_box(2)

    assert isinstance(box_test, Box)
    assert box_test.get() == 4

    box_test = Lazy(fn_to_box).to_box(Maybe.just(3))

    assert isinstance(box_test, Box)
    assert box_test.get() == 9

    box_test = Lazy(fn_to_box).to_box(Try.of(lambda: 3))

    assert isinstance(box_test, Box)