

# Generated at 2022-06-24 00:06:55.743052
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    assert Lazy.of(lambda a: a).ap(Box(4)) == Lazy.of(4)
    assert Lazy.of(lambda a: a ** 2).ap(Lazy.of(2)) == Lazy.of(4)
    assert Lazy.of(lambda a: a ** 2).ap(Lazy.of(2.0)) == Lazy.of(4.0)
    assert Lazy.of(lambda a: a ** 2).ap(Lazy.of(2j)) == Lazy.of(4j)
    assert Lazy.of(lambda a, b: a ** b).ap(Lazy.of(2)) == Lazy.of(lambda b: 2 ** b)

# Generated at 2022-06-24 00:06:59.521524
# Unit test for method get of class Lazy
def test_Lazy_get():
    f = Lazy(lambda: 1)
    assert f.get() == 1
    assert f.is_evaluated
    assert f.get() == f.get()


# Generated at 2022-06-24 00:07:03.570006
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    from pymonet.tools import identity

    lazy = Lazy(identity)
    assert 'fn={}, value={}, is_evaluated={}'.format(lazy.constructor_fn, lazy.value, lazy.is_evaluated) == str(
        lazy)



# Generated at 2022-06-24 00:07:07.131411
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) == Lazy.of(1).map(lambda x: x)

# Generated at 2022-06-24 00:07:10.955788
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():  # pragma: no cover
    from pymonet.validation import Validation
    def fn(x):
        return x * 2

    lazy = Lazy(fn)
    assert lazy.to_validation(2) == Validation.success(4)


# Generated at 2022-06-24 00:07:15.457299
# Unit test for method map of class Lazy
def test_Lazy_map():
    def function_1():
        return 'test'

    def function_2(value):
        return value + '!'

    assert Lazy(function_1).map(function_2) == Lazy(lambda: function_2(function_1()))
    assert Lazy(function_1).map(function_2).fold() == function_2(function_1())



# Generated at 2022-06-24 00:07:21.305516
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    def fn():
        raise AttributeError

    lazy_failure = Lazy(fn)
    lazy_success = Lazy(lambda: Box(Maybe.just(1)))

    assert lazy_failure.to_maybe() == Maybe.nothing()
    assert lazy_success.to_maybe() == Maybe.just(1)

# Generated at 2022-06-24 00:07:24.262422
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    def fn(x) -> Lazy[int, int]:
        return Lazy(lambda: x + 5)

    assert Lazy(lambda: 6).bind(fn).get() == 11

# Generated at 2022-06-24 00:07:31.916392
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    from pymonet.either import Left

    def func1():
        raise ValueError()

    def func2():
        return 'aaa'

    try:
        Lazy(func1).to_either().get()
        assert False
    except ValueError:
        pass

    assert Lazy(func2).to_either().get() == 'aaa'



# Generated at 2022-06-24 00:07:34.556840
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Either

    lazy = Lazy(lambda: 1)
    assert lazy.to_either() == Either.right(1)


# Generated at 2022-06-24 00:07:43.877760
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    def sum_of_two(x: int, y: int) -> int:
        return x + y

    assert Lazy(lambda: 1).to_box() == Box(1)
    assert Lazy(sum_of_two).map(lambda x: x * x).to_box(2, 3) == Box(25)
    assert Lazy(sum_of_two).map(lambda x: x * x).to_box(2, 3) == Lazy(sum_of_two).map(lambda x: x * x).to_box(2, 3)


# Generated at 2022-06-24 00:07:48.690756
# Unit test for method get of class Lazy
def test_Lazy_get():
    # given
    def no_parameters_function():
        return 5

    def one_parameter_function(a: int):
        return 5 + a

    def two_parameters_function(a: int, b: int):
        return 5 + a + b

    def three_parameters_function(a: int, b: int, c: int):
        return 5 + a + b + c

    def four_parameters_function(a: int, b: int, c: int, d: int):
        return 5 + a + b + c + d

    def five_parameters_function(a: int, b: int, c: int, d: int, e: int):
        return 5 + a + b + c + d + e


# Generated at 2022-06-24 00:07:55.781403
# Unit test for constructor of class Lazy
def test_Lazy():
    from pymonet.monad_maybe import Maybe

    def fn1():
        return 1

    def fn2():
        return 2

    l1 = Lazy.of(fn1)
    l2 = Lazy.of(fn2)

    assert l1.to_either() is not l2.to_either()
    assert l1.to_either() == l1.to_either()
    assert l1.get() == 1
    assert l1.get() == l1.get()
    assert l1.map(lambda x: x + 3).get() == 4
    assert l1.bind(lambda x: Lazy.of(lambda: x + 3)).get() == 4
    assert l1.ap(l2).get() == 1

# Generated at 2022-06-24 00:08:07.562670
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    """
    Unit test for method to_box on class Lazy
    """
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy(lambda: 'test').to_box() == Box('test')

    def return_right():
        return Right('test')

    assert Lazy(return_right).to_box() == Box('test')

    def return_just():
        return Maybe.just('test')

    assert Lazy(return_just).to_box() == Box('test')

    def return_success():
        return Validation.success('test')

    assert Lazy(return_success).to_box() == Box('test')

   

# Generated at 2022-06-24 00:08:09.619086
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    assert Lazy.of(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:08:16.200279
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy.of(1).to_box() == Box(1)
    assert Lazy.of(None).to_box() == Box(None)
    assert Lazy.of([]).to_box() == Box([])
    assert Lazy.of({}).to_box() == Box({})
    assert Lazy.of('').to_box() == Box('')



# Generated at 2022-06-24 00:08:17.057046
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(a):
        return a + 1

    lazy = Lazy(fn)
    lazy.get(1) == 2



# Generated at 2022-06-24 00:08:25.036642
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy.of(None) == Lazy(lambda *args: None)
    assert Lazy.of(3) == Lazy(lambda *args: 3)
    assert Lazy.of(3) != Lazy(lambda *args: 4)
    assert Lazy.of(3) != Lazy(lambda *args: 3)

    def some_function(x):
        return x + 1

    assert Lazy.of(None) != Lazy(some_function)
    assert Lazy.of(4) == Lazy(some_function)
    assert Lazy.of(4).is_evaluated == False



# Generated at 2022-06-24 00:08:29.067850
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():  # pragma: no cover
    """
    Unit test for method to_either of class Lazy.
    """
    from pymonet.either import Right

    instance = Lazy.of(1)
    result = instance.to_either(None)
    expected = Right(1)

    assert result == expected


# Generated at 2022-06-24 00:08:36.086681
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.functor import Functor
    from pymonet.box import Box
    from pymonet.monad_nested import Nested

    # Case: function not evaluate
    lazy = Lazy(lambda x: x * 2)
    assert lazy.get(2) == 4

    # Case: function call before
    assert lazy.get(2) == 4

    # Case: function not evaluate for mapper
    lazy = Lazy(lambda x: x * 2)
    lazy = lazy.map(lambda x: x + 1)
    assert lazy.get(2) == 5

    # Case: function call before for mapper
    assert lazy.get(2) == 5

    # Case: function not evaluate for applicative
    nested = Nested(Box, Functor, Lazy(lambda x: x * 2))
    lazy = L

# Generated at 2022-06-24 00:08:37.625925
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    l = Lazy.of(2)

    assert l.to_box() == Box(2)


# Generated at 2022-06-24 00:08:40.855361
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy.of('hello')
    assert lazy.get() == 'hello'



# Generated at 2022-06-24 00:08:44.537639
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    try:
        Lazy(lambda: 1).to_either()
        Lazy(lambda: 1).to_either(2)
        assert False
    except TypeError:
        assert True  # method to_either must not accept any arguments

# Generated at 2022-06-24 00:08:50.357165
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def _fn(value):
        return Box(value + ' world')

    def _try_fn(value):
        return Try(_fn, value)

    def _validation_fn(value):
        return Validation.success(value)

    lazy = Lazy(lambda x: x).bind(_fn).bind(_try_fn).bind(_validation_fn).get('Hello')

    assert lazy == 'Hello world'



# Generated at 2022-06-24 00:08:52.344991
# Unit test for method get of class Lazy
def test_Lazy_get():
    lazy = Lazy(lambda value: value)
    assert lazy.get(1) == 1


# Generated at 2022-06-24 00:08:55.714360
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from tests.utility_for_tests import test_Lazy___str__ as test

    test(Lazy)



# Generated at 2022-06-24 00:09:01.555541
# Unit test for constructor of class Lazy
def test_Lazy():
    x = Lazy.of(2)
    assert str(x) == 'Lazy[fn=<function Lazy.__init__.<locals>.<lambda> at 0x7f6a64f6c1e0>, value=None, is_evaluated=False]'

    x = Lazy.of(2)
    assert x.map(lambda x: x + 1) == Lazy(lambda x: x + 1)

    x = Lazy.of(2)
    assert x.map(lambda x: x + 1).get() == 3


# Generated at 2022-06-24 00:09:06.725524
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def lazy_mul3(a):
        def mul3_fn(b):
            return a * 3 + b
        return Lazy(mul3_fn)
    assert Lazy.of(2).ap(Maybe.just(3)).get() == 8
    assert Lazy.of(2).ap(Maybe.empty()).get() == None



# Generated at 2022-06-24 00:09:08.776926
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy.of(10).to_validation() == Validation.success(10)



# Generated at 2022-06-24 00:09:16.945765
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda *args: 'name')) == "Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7fefc28123b0>, value=, is_evaluated=False]" # noqa: E501
    assert str(Lazy(lambda *args: 'name').get()) == "Lazy[fn=<function Lazy.<locals>.<lambda> at 0x7fefc28123b0>, value=name, is_evaluated=True]" # noqa: E501


# Generated at 2022-06-24 00:09:22.142208
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    def fn(*args):
        return args[0] + args[1]

    lazy = Lazy(fn)
    assert lazy.to_maybe(2, 4) == Maybe.just(6)



# Generated at 2022-06-24 00:09:25.494934
# Unit test for method get of class Lazy
def test_Lazy_get():  # pragma: no cover
    def f():
        return 1

    lazy = Lazy(f)
    assert lazy.get() == 1

    def g(i):
        return 2 * i

    lazy = Lazy(g)
    assert lazy.get(2) == 4



# Generated at 2022-06-24 00:09:29.162375
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert 'Lazy[fn=<function Lazy.<locals>.lambda_fn at 0x7f6cdbff70d0>, value=None, is_evaluated=False]' \
           == Lazy(lambda: 1).__str__()



# Generated at 2022-06-24 00:09:32.277863
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy.of(1).to_box(42) == Box(1)

    assert Lazy(lambda x: x + 1).to_box(41) == Box(42)

    assert str(Lazy(lambda x: x + 1).to_box(41)) == "Box[42]"



# Generated at 2022-06-24 00:09:37.465830
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    assert isinstance(Lazy.of('foo').to_validation('bar'), Validation)
    assert Lazy.of('foo').to_validation('bar').is_valid()
    assert Lazy.of('foo').to_validation('bar').get_value() == 'foo'
    assert Lazy.of('foo').to_validation() == Validation.success('foo')


# Unit tests of method to_try of class Lazy

# Generated at 2022-06-24 00:09:41.635987
# Unit test for method map of class Lazy
def test_Lazy_map():
    value = 'lazy_value'

    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of('abc').map(lambda x: x + '_suffix').get() == 'abc_suffix'
    assert Lazy(lambda: value).map(lambda x: x + '_suffix').get() == 'lazy_value_suffix'



# Generated at 2022-06-24 00:09:47.207965
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.function import Function
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def wrap_monad(x):
        return Validation.success(x)

    assert Lazy.of(1) == Lazy(Function.constant(1))
    assert Lazy(add_one) == Lazy(add_one)
    assert Lazy(add_one).map(wrap_monad) == Lazy(add_one).map(wrap_monad)



# Generated at 2022-06-24 00:09:53.158643
# Unit test for constructor of class Lazy
def test_Lazy():
    assert Lazy(lambda x: x + 1).get(1) == 2
    assert Lazy(lambda x, y: x + y).get(2, 3) == 5
    assert Lazy(lambda x, y, z: x + y + z).get(1, 2, 3) == 6



# Generated at 2022-06-24 00:09:55.062790
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    return Lazy(lambda: 1).to_box()



# Generated at 2022-06-24 00:10:02.334854
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def get_maybe(x: int) -> Maybe[int]:
        return Lazy(lambda y: Maybe.just(x + y)).to_maybe(10)

    assert get_maybe(1) == Maybe.just(11)
    assert get_maybe(None) == Maybe.just(10)



# Generated at 2022-06-24 00:10:10.599946
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    assert Lazy(lambda x: x + 1).to_box(1) == Box(2)
    assert Lazy(lambda x: x + 1).map(lambda x: x + 1).to_box(1) == Box(3)
    assert Lazy(lambda x: x + 1).to_box(1) == Lazy(lambda x: x + 1).map(lambda x: x + 1).to_box(1)


# Generated at 2022-06-24 00:10:17.419156
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    class TestLazy():
        def test(*args):
            return 'result'

    validation = Lazy(TestLazy.test).to_validation()

    assert isinstance(validation, Validation)
    assert validation.is_success()
    assert validation.get_or_else() == 'result'



# Generated at 2022-06-24 00:10:22.005056
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    assert Lazy(lambda x: x).to_box() == Lazy(lambda x: x).to_box(1)
    assert Lazy(lambda x: x).to_box(1) == Lazy(lambda x: x + 1).to_box(2)


# Generated at 2022-06-24 00:10:24.098515
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    assert Lazy.of(2).to_maybe() == Maybe.just(2)



# Generated at 2022-06-24 00:10:25.665013
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1



# Generated at 2022-06-24 00:10:27.939831
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box
    lazy = Lazy.of(1)
    assert lazy.to_box() == Box(1)



# Generated at 2022-06-24 00:10:31.911970
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.applicative import Applicative
    from pymonet.monad_list import List
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Validation

    assert Applicative.ap(Lazy.of(lambda x: x), Maybe.just(1)).is_just
    assert Applicative.ap(Lazy.of(lambda x: x), Maybe.nothing()).is_nothing
    assert Applicative.ap(Lazy.of(lambda x: x), Validation.success(1)).is_success
    assert Applicative.ap(Lazy.of(lambda x: x), Validation.failure([1])).is_failure

# Generated at 2022-06-24 00:10:33.338945
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Box(5) == Lazy(lambda: 5).to_box()



# Generated at 2022-06-24 00:10:42.634098
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Left

    def return_value(value):
        return value

    assert Lazy(return_value).to_either() == Left(None)
    assert Lazy(return_value).to_either(12) == Left(12)
    assert Lazy(return_value).to_either(value=13) == Left(13)
    assert Lazy(return_value).to_either(value=13) == Left(13)
    assert Lazy(return_value).to_either(12, 33) == Left((12, 33))
    assert Lazy(return_value).to_either(value=13, value2=33) == Left((13, 33))
    assert Lazy(return_value).to_either(value=(12, 33)) == Left((12, 33))

# Generated at 2022-06-24 00:10:48.102836
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f1(n):
        return Lazy(lambda *args: n * 2)

    def f2(n):
        return Lazy(lambda *args: n * 3)

    def f3(n):
        return Lazy(lambda *args: n * 4)

    res = Lazy.of(10).bind(f1).bind(f2).bind(f3)
    assert type(res) == Lazy
    assert res._compute_value() == 240



# Generated at 2022-06-24 00:10:50.877014
# Unit test for method map of class Lazy
def test_Lazy_map():
    l = Lazy.of(3)
    l_mapped = l.map(lambda x: x + 2)
    assert l_mapped.get() == 5



# Generated at 2022-06-24 00:11:02.552524
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try

    def lazy_try(*args):
        return Try.of(lambda *args: args[0] + 1, *args)

    def lazy_try_fail(*args):
        return Try.of(lambda *args: int('A' + str(args[0])), *args)

    def sum_all(a: Tuple[int, int]):
        return a[0] + a[1]

    lazy_arg = Lazy(lambda: 1)

    assert lazy_arg.bind(lazy_try).bind(lazy_try).bind(lazy_try).get() == 4
    assert lazy_arg.bind(lazy_try_fail).bind(lazy_try).bind(lazy_try).get().exception is not None


# Generated at 2022-06-24 00:11:05.548541
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Lazy(lambda: 1).to_box() == Box(1)
    assert Lazy(lambda a: a + 1).to_box(1) == Box(2)



# Generated at 2022-06-24 00:11:17.442071
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    def fn_to_map() -> int:
        return 1

    def mapper(x: int) -> int:
        return x + 1

    assert Lazy(fn_to_map).map(mapper).get() == 2
    assert Lazy(fn_to_map).map(lambda x: x + 1).get() == 2
    assert Lazy(fn_to_map).map(mapper).map(mapper).get() == 3
    assert Lazy(fn_to_map).map(mapper).map(lambda x: x + 1).get() == 3
    assert Lazy(fn_to_map).map(lambda x: x + 1).map(mapper).get() == 3

# Generated at 2022-06-24 00:11:24.263365
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    test for method bind of class Lazy
    """
    lazy = Lazy(lambda: 42)
    assert lazy.bind(lambda x: Lazy(lambda: x + 1)).get() == 43

    lazy = Lazy(lambda: 42)
    assert lazy.bind(lambda x: Lazy(lambda: x + 1)).bind(lambda y: Lazy(lambda: y + 1)).get() == 44



# Generated at 2022-06-24 00:11:29.901740
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    This unit test prove that lazy evaluation is working.
    """
    def fn(x):
        print('x')
        return Lazy.of(x + 1)

    def fn2(x):
        print('y')
        return Lazy.of(x + 2)

    lazy = Lazy.of(1)
    lazy2 = lazy.bind(fn).bind(fn2)
    assert lazy2.get() == 4


# Generated at 2022-06-24 00:11:35.898471
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def div(a, b):
        return a / b

    assert Lazy(div).to_try(1, 1) == Lazy(div).to_try(1, 1)
    assert Lazy(div).to_try(1, 0).isFailure()
    assert Lazy(div).to_try(1, 1).isSuccess()
    assert Lazy(div).to_try(1, 1).get() == 1.0

# Generated at 2022-06-24 00:11:47.014614
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.monad_try import Try

    def f():
        return 1
    def g():
        return 2
    def h():
        return 3

    def mapper_fn(x):
        return x + 1

    assert Lazy(f).__eq__(Lazy(f))
    assert Lazy(g).__eq__(Lazy(g))
    assert Lazy(h).__eq__(Lazy(h))
    assert False == Lazy(f).__eq__(Lazy(g))
    assert False == Lazy(g).__eq__(Lazy(h))
    assert False == Lazy(h).__eq__(Lazy(f))


# Generated at 2022-06-24 00:11:49.422252
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    assert Box(1) == Lazy(lambda: 1).to_box()


# Generated at 2022-06-24 00:11:54.292194
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    double = lambda x: x * 2
    double_box = Box(double)
    assert Lazy.of(10).map(lambda x: x * 2).get() == 20
    assert Lazy.of(10).map(double_box.get()).get() == 20



# Generated at 2022-06-24 00:11:59.988065
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def some_fn(x):
        return x

    lazy_value_1 = Lazy.of("some_value").map(some_fn)
    assert lazy_value_1.get() == "some_value"

    lazy_value_2 = Lazy(some_fn).map(some_fn)
    assert lazy_value_2.get("some_value") == "some_value"

    assert lazy_value_1 == lazy_value_2



# Generated at 2022-06-24 00:12:04.179039
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.monad_try import Exception

    assert Lazy.of(5).to_try() == Try.of(lambda: 5)
    assert Lazy.of("value").to_try() == Try.of(lambda: "value")
    assert Lazy.of(Exception("Try this")).to_try() == Try.failure(Exception("Try this"))

# Generated at 2022-06-24 00:12:08.613638
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def f():
        return Lazy(lambda: 123)

    assert f().to_box() == Box(123)

    def g():
        def f():
            return Maybe.just(123)

        return Lazy(f)

    assert g().to_box() == Box(123)



# Generated at 2022-06-24 00:12:18.626197
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    """
    Test ap function of Lazy class.
    """
    import pymonet.box as box
    import pymonet.maybe as maybe

    def _ap(val):
        # pylint: disable=invalid-name
        return Lazy.of(lambda x: x % 2).ap(val)

    result_box = _ap(box.of(3))
    assert isinstance(result_box, Lazy)
    assert result_box.get() == 1

    result_maybe = _ap(maybe.just(3))
    assert isinstance(result_maybe, Lazy)
    assert result_maybe.get() == 1

    result_empty_maybe = _ap(maybe.empty())
    assert isinstance(result_empty_maybe, Lazy)
    assert result_empty_maybe.get() is None

    result

# Generated at 2022-06-24 00:12:23.888696
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    lazy_func = Lazy(lambda a, b: lambda x: x+a+b)
    lazy_value = Lazy(lambda: 1)

    assert lazy_func.ap(lazy_value).get()(5) == 7


# Generated at 2022-06-24 00:12:31.074910
# Unit test for method map of class Lazy
def test_Lazy_map():  # pragma: no cover
    from pymonet.maybe import Maybe

    def double(x):
        return x+x

    lazy_with_three = Lazy(lambda: 3)
    lazy_with_double_three = lazy_with_three.map(double)

    assert lazy_with_double_three.get() == 6
    assert lazy_with_three.get() == 3

    lazy_with_nothing = Lazy(lambda: Maybe.nothing())
    lazy_with_double_nothing = lazy_with_nothing.map(double)
    assert lazy_with_double_nothing.get() == Maybe.nothing()

# Generated at 2022-06-24 00:12:39.181437
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def divide(a, b):
        return a / b

    # Exception wrapped with Try when function is called
    divide_lazy = Lazy(divide)
    divide_try = divide_lazy.to_try(1, 0)
    assert divide_try.is_failure
    assert divide_try.failed_value.__cause__ is ZeroDivisionError

    # Exception NOT wrapped with Try when function is not called
    divide_try = divide_lazy.to_try(1, 1)
    assert divide_try.is_success

    # Value wrapped with Try when function is called
    divide_lazy = Lazy(divide)
    divide_try = divide_lazy.to_try(1, 1)
    assert divide_try.is_success
    assert divide_try.get_value() == 1

    # Value

# Generated at 2022-06-24 00:12:43.029263
# Unit test for method map of class Lazy
def test_Lazy_map():
    doubled = lambda x: x * 2
    triple = lambda x: x * 3
    quadrupled = lambda x: x * 4

    assert Lazy(doubled).map(triple).get(2) == 12
    assert Lazy(doubled).map(triple).map(quadrupled).get(2) == 48


# Generated at 2022-06-24 00:12:49.490442
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    from random import randint
    from operator import eq

    if randint(0, 1) == 1:
        maybe1 = Maybe.empty()
        assert Maybe.empty() == maybe1
    else:
        maybe1 = Maybe.just([1, 2, 3])
        assert Maybe.just([1, 2, 3]) == maybe1

    assert maybe1.to_lazy().to_maybe() == maybe1


# Generated at 2022-06-24 00:12:52.405593
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Lazy.of(1).to_box() == Box(1)



# Generated at 2022-06-24 00:12:58.347682
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    @Lazy
    def test():
        return 1

    @Lazy
    def raise_error():
        raise TypeError

    assert test.to_try() == Try.of(lambda: 1)
    assert raise_error.to_try() == Try.of(raise_error)



# Generated at 2022-06-24 00:13:10.449104
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    lazy1 = Lazy(lambda x: x)
    lazy2 = Lazy(lambda x: x)
    assert lazy1 == lazy2, 'Wrong Lazy equals result'

    lazy1 = Lazy(lambda x: x)
    lazy2 = Lazy(lambda x: x+1)
    assert lazy1 != lazy2, 'Wrong Lazy equals result'

    lazy1 = Lazy(lambda x: x+1)
    lazy2 = Lazy(lambda x: x+1)
    assert lazy1 == lazy2, 'Wrong Lazy equals result'

    lazy1 = Lazy(lambda x: x+1)
    lazy1._compute_value()
    lazy2 = Lazy(lambda x: x+1)
    lazy2._compute_value()
    assert lazy1 == lazy2

# Generated at 2022-06-24 00:13:19.619321
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    def _validate_age(age: int) -> Lazy[int, int]:
        def validate_age_fn(age):
            if age < 0:
                return -age
            return age

        return Lazy(lambda age=age: validate_age_fn(age))

    result = _validate_age(10).to_validation()
    assert isinstance(result, Validation)
    assert result.is_success()
    assert result.value == 10

    result = _validate_age(-10).to_validation()
    assert isinstance(result, Validation)
    assert result.is_success()
    assert result.value == 10


# Generated at 2022-06-24 00:13:24.531109
# Unit test for method get of class Lazy
def test_Lazy_get():
    def function():
        return 1

    assert Lazy(function).get() == 1
    assert Lazy(function).get() == 1

    def function2(arg):
        return arg

    assert Lazy(function2).get(1) == 1
    assert Lazy(function2).get(1) == 1

# Generated at 2022-06-24 00:13:31.599274
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    from pymonet.maybe import Maybe

    def unit_test(a: Lazy[int, int]) -> Maybe[int]:
        return a.to_maybe()

    assert unit_test(Lazy(lambda: 1)) == Maybe.just(1)
    assert unit_test(Lazy(lambda: 0)) == Maybe.just(0)
    assert unit_test(Lazy(lambda: None)) == Maybe.nothing()



# Generated at 2022-06-24 00:13:35.210789
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def sum_numbers(a, b):
        return a + b

    assert Lazy(sum_numbers).fold(lambda x: x(1, 2)) == 3

# Generated at 2022-06-24 00:13:40.558457
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():  # pragma: no cover
    assert str(Lazy(lambda: "a")) == "Lazy[fn=<lambda>, value=None, is_evaluated=False]"
    lazy = Lazy(lambda: "a")
    lazy.get()
    assert str(lazy) == "Lazy[fn=<lambda>, value=a, is_evaluated=True]"


# Generated at 2022-06-24 00:13:51.034243
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    def _get_value() -> int:
        return 20 + 100

    def _get_value_2(value: int) -> int:
        return value + 100

    lazy = Lazy(_get_value)
    assert lazy.is_evaluated is False
    assert lazy.get() == 120
    assert lazy.is_evaluated is True
    assert lazy.get() == 120
    assert lazy.is_evaluated is True

    assert Lazy(_get_value).map(_get_value_2).get() == 220
    assert Lazy(_get_value).map(_get_value_2).map(_get_value_2).get() == 320
    assert Lazy(_get_value).map(_get_value_2).map(_get_value_2).get() == 320


# Generated at 2022-06-24 00:14:00.175798
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Right, Left
    from pymonet.box import Box

    def raise_exception(*args):
        raise Exception()

    assert Lazy.of(1).to_either() == Right(1)
    assert Lazy(raise_exception).to_either() == Left(Exception)
    assert Lazy(Box.of(1)).to_either() == Right(Box(1))
    assert Lazy(Box(raise_exception)).to_either() == Right(Box(Exception))
    assert Lazy(Box(Box(1))).to_either() == Right(Box(Box(1)))


# Generated at 2022-06-24 00:14:09.427920
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    inc = lambda x: x + 1

    def call(value):
        def inner(x):
            return x(value)
        return inner

    add_one = Lazy(call(inc))

    value = Lazy(lambda : 3).bind(lambda v: Lazy.of(v + 1)).to_box()

    assert value == Box(4)
    assert value == add_one.to_box()
    assert isinstance(value, Box)
    assert value.map(lambda v: v * 2) == Box(8)
    assert value.to_maybe() == Maybe.just(4)


# Generated at 2022-06-24 00:14:13.488039
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert not Lazy.of(1) == Lazy.of(2)
    assert not Lazy.of(1) == "lazy"


# Generated at 2022-06-24 00:14:24.360504
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.box import Box
    from pymonet.function import identity

    assert str(Lazy(identity).map(lambda x: x + 2)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x7fb595894cb0>, value=None, is_evaluated=False]'
    assert str(Lazy(identity).map(lambda x: x + 2).fold(identity)) == 'Lazy[fn=<function test_Lazy___str__.<locals>.<lambda> at 0x7fb595894cb0>, value=None, is_evaluated=False]'

# Generated at 2022-06-24 00:14:26.139230
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert "Lazy[fn=<function Lazy.<lambda> at 0x10d9fde60>, value=None, is_evaluated=False]" == str(Lazy(lambda: 5))


# Generated at 2022-06-24 00:14:28.219989
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation

    assert Lazy(lambda: 11).to_validation() == Validation.success(11)

# Generated at 2022-06-24 00:14:33.766392
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1).fold()
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 2)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 1).map(lambda x: x + 1)



# Generated at 2022-06-24 00:14:38.018208
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    lazy = Lazy.of(lambda x: x+1)
    lazy_try = Try.of(lambda x: x+1)
    lazy_maybe = Maybe.just(lambda x: x+1)
    assert lazy.ap(lazy_try).get(1) == lazy.ap(lazy_maybe).get(1) == 2


# Generated at 2022-06-24 00:14:45.136255
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation_error import ValidationError

    def five() -> int:
        return 5

    lazy_five = Lazy(five)
    validation = lazy_five.to_validation()
    assert validation == Validation(5)


# Generated at 2022-06-24 00:14:50.662765
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    from pymonet.monad_try import Try
    from pymonet.either import Right

    def square(x):
        return x * x

    def division(x, y):
        return x / y

    assert (
        Lazy.of(Right(12))
        .to_try()
        .bind(lambda x: Try.of(square, x))
        .bind(lambda x: Try.of(division, x, 2))
        == Try.of(lambda : 12 / 2)
    )

# Generated at 2022-06-24 00:14:53.578802
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy(lambda: 'test')) == 'Lazy[fn=<function <lambda> at 0x...>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:14:59.609731
# Unit test for method to_try of class Lazy
def test_Lazy_to_try():
    def False_assertion(value: int) -> int:
        assert False

    from pymonet.monad_try import Try

    assert Lazy.of(1).to_try(1) == Try.of(lambda x: 1, 1)  # apply constructor
    assert Lazy(False_assertion).to_try(1) == Try.of(False_assertion, 1)  # apply constructor with exception



# Generated at 2022-06-24 00:15:07.252275
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet import Maybe, Either, Box

    def _fn():
        return ['fn 1', 'fn 2']

    def _fn2():
        return ['fn 3', 'fn 4']

    result_fn = Lazy(_fn)
    result_fn2 = Lazy(_fn2)

    result_fn.get()
    result_fn2.get()

    assert result_fn == result_fn2



# Generated at 2022-06-24 00:15:09.066614
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(5).map(lambda x: x * x) == Lazy(lambda: 25)



# Generated at 2022-06-24 00:15:12.454545
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    def double_function(x):
        return 2 * x
    double_Lazy = Lazy(double_function)
    double_Lazy_str = 'Lazy[fn=<function test_Lazy___str__.<locals>.double_function at 0x%x>, value=None, is_evaluated=False]' % id(double_function)
    assert str(double_Lazy) == double_Lazy_str


# Generated at 2022-06-24 00:15:21.906124
# Unit test for method bind of class Lazy
def test_Lazy_bind():

    def add(a):
        return lambda b: a + b

    def mul(a):
        return lambda b: a * b

    def add_list(l):
        def add_l(a):
            return list(map(lambda x: x + a, l))

        return add_l

    a = add(2)
    la = Lazy(a)
    l_arg = Lazy(lambda: 2)
    assert la.bind(lambda x: Lazy(x)).get() == la.get()

    la = Lazy(a)
    assert la.bind(lambda x: Lazy(x)).get(3) == la.get(3)

    la = Lazy(a)
    assert la.get()(3) == la.bind(lambda x: Lazy(x)).get()(3)


# Generated at 2022-06-24 00:15:27.503499
# Unit test for method to_maybe of class Lazy
def test_Lazy_to_maybe():
    """
    Unit test for method to_maybe of class Lazy.

    :returns: nothing
    :rtype: None
    """
    from pymonet.maybe import Maybe

    assert Lazy.of(5).to_maybe() == Maybe.just(5)
    assert Lazy(lambda *args: 5).to_maybe() == Maybe.just(5)


# Generated at 2022-06-24 00:15:32.689615
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    """
    Test conversion Lazy to Validation.
    """
    from pymonet.validation import Validation

    lazy = Lazy.of(5)

    validation = lazy.to_validation()

    assert isinstance(validation, Validation)
    assert validation.is_success()
    assert validation.get() == 5

# Generated at 2022-06-24 00:15:35.303724
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 'test'

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy.of('test2')

    assert lazy1 == lazy2
    assert lazy1 != lazy3

# Generated at 2022-06-24 00:15:40.954863
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.function import identity

    assert str(Lazy(identity)) == 'Lazy[fn=<function identity_function at 0x7f4c335c4d08>, value=None, is_evaluated=False]'


# Generated at 2022-06-24 00:15:44.016023
# Unit test for constructor of class Lazy
def test_Lazy():  # pragma: no cover
    assert Lazy(lambda x: x).constructor_fn(1) == 1
    assert Lazy(lambda x: x).is_evaluated is False
    assert Lazy(lambda x: x).value is None



# Generated at 2022-06-24 00:15:46.639550
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Unit test for method __eq__ of class Lazy.
    """

    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)



# Generated at 2022-06-24 00:15:54.032659
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def increment(i):
        return i + 1

    Lazy.__eq__.assert_errors(
        (Lazy.of(1), Lazy.of(2)),
        (Lazy.of(1), Lazy.of(1)),
        (Lazy.of(1), increment)
    )

    Lazy.__eq__.assert_success(
        (Lazy.of(1), Lazy.of(1)),
    )



# Generated at 2022-06-24 00:15:57.239404
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda _: 3).map(lambda x: x * 2).get() == 6
    assert Lazy(lambda _: 3).map(lambda x: x * 2).map(lambda x: x ** 2).get() == 36


# Generated at 2022-06-24 00:16:00.468529
# Unit test for method to_box of class Lazy
def test_Lazy_to_box():
    from pymonet.box import Box

    def add_three(a):
        return a + 3

    lazy = Lazy(lambda: add_three(2))
    box = lazy.to_box()

    assert box == Box(5)


# Generated at 2022-06-24 00:16:04.091868
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x * 3) == Lazy.of(3)
    assert Lazy.of(1).map(lambda x: x * 2).map(lambda x: x * 3) == Lazy.of(6)


# Generated at 2022-06-24 00:16:06.774335
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    assert str(Lazy.of({}) == 'Lazy[constructor={}, is_evaluated={}, value={}'.format(lambda: {}, False, None))


# Generated at 2022-06-24 00:16:09.196822
# Unit test for method to_validation of class Lazy
def test_Lazy_to_validation():
    def fn():
        return 3
    lazy = Lazy(fn)
    assert lazy.to_validation() == Validation.success(3)



# Generated at 2022-06-24 00:16:16.980179
# Unit test for method bind of class Lazy
def test_Lazy_bind():  # pragma: no cover
    from pymonet.monad_try import Try

    def test_fn(a: str) -> Try[str]:
        if a == '3':
            return Try.failure(TypeError('Test error'))
        else:
            return Try.success(a * 2)

    lazy_try = Lazy(lambda x: x * 3).bind(test_fn).bind(test_fn)

    assert lazy_try.get(2) == '4444'
    assert lazy_try.get(3).is_failure()
    assert lazy_try.get(3).get_or_else(1) == 1



# Generated at 2022-06-24 00:16:26.864831
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.either import Right

    assert Lazy.of(2).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: Lazy.of(x + 1)).ap(Lazy.of(1)) == Lazy.of(2)

    # check composition with Box
    assert Lazy.of(lambda x: Box(x + 1)).ap(Box(1)) == Box(2)
    assert Lazy.of(lambda x: Box(x + 1)).ap(Box(1)).ap(Box(2)) == Box(3)

# Generated at 2022-06-24 00:16:36.037974
# Unit test for method to_either of class Lazy
def test_Lazy_to_either():
    from pymonet.either import Either

    def raise_ex():
        raise Exception("Test Exception")

    def test_fn(*args):
        return args[0]

    def test_mapper(value):
        return value + 1

    not_empty_lazy = Lazy.of("test")
    empty_lazy = Lazy.of(None)
    exception_lazy = Lazy(raise_ex)
    exception_mapper_lazy = Lazy.of("test").map(raise_ex)
    valid_lazy = Lazy.of("test").map(test_mapper)
    right_lazy = Lazy.of("test").map(test_mapper).to_either()

    assert not_empty_lazy.to_either() == Either.right("test")
    assert empty_lazy.to

# Generated at 2022-06-24 00:16:41.862612
# Unit test for method __str__ of class Lazy
def test_Lazy___str__():
    from pymonet.function import identity
    assert(str(Lazy(identity)) == 'Lazy[fn=<function identity_function at 0x7f395b4c4d08>, value=None, is_evaluated=False]')


# Generated at 2022-06-24 00:16:46.473951
# Unit test for constructor of class Lazy
def test_Lazy():
    f = lambda x: x**2 + 3
    lazy = Lazy(f)

    assert lazy.constructor_fn == f
    assert lazy.is_evaluated == False
    assert lazy.value is None

    lazy_evaluated = lazy.get(2)
    assert lazy_evaluated == 7
    assert lazy.is_evaluated == True
    assert lazy.value == 7



# Generated at 2022-06-24 00:16:52.368740
# Unit test for method get of class Lazy
def test_Lazy_get():
    """
    >>> from pymonet.lazy import Lazy

    >>> Lazy(lambda: 99).get()
    99

    >>> Lazy(lambda: 99).get(1, 2)
    99
    """
