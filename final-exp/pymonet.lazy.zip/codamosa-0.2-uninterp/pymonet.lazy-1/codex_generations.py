

# Generated at 2022-06-18 01:40:17.949624
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def fn(x):
        return Maybe.just(x)

    lazy = Lazy(lambda x: x).bind(fn)
    assert lazy.get(1) == 1

    lazy = Lazy(lambda x: x).bind(lambda x: Box(x))
    assert lazy.get(1) == 1

# Generated at 2022-06-18 01:40:28.963958
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)) == Lazy.of(3)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(3)) == Lazy.of(4)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(4)) == Lazy.of(5)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(5)) == Lazy.of(6)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(6)) == Lazy.of(7)

# Generated at 2022-06-18 01:40:40.630201
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: 'a')
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: 1.0)

# Generated at 2022-06-18 01:40:51.355411
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x / 2).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x / 2).map(lambda x: x - 1).get() == 1

# Generated at 2022-06-18 01:40:57.441848
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1():
        return 1

    def fn2():
        return 2

    def fn3():
        return 3

    def fn4():
        return 4

    def fn5():
        return 5

    def fn6():
        return 6

    def fn7():
        return 7

    def fn8():
        return 8

    def fn9():
        return 9

    def fn10():
        return 10

    def fn11():
        return 11

    def fn12():
        return 12

    def fn13():
        return 13

    def fn14():
        return 14

    def fn15():
        return 15

    def fn16():
        return 16

    def fn17():
        return 17

    def fn18():
        return 18

    def fn19():
        return 19

    def fn20():
        return 20

# Generated at 2022-06-18 01:41:10.832674
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x, y):
        return x + y

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8


# Generated at 2022-06-18 01:41:18.134283
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()

# Generated at 2022-06-18 01:41:22.020690
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3


# Generated at 2022-06-18 01:41:33.666666
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:41:44.323634
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return Lazy(lambda: value)

    assert Lazy(lambda: 1).bind(fn) == Lazy(lambda: 1)
    assert Lazy(lambda: 1).bind(fn).to_box() == Box(1)
    assert Lazy(lambda: 1).bind(fn).to_either() == Right(1)
    assert Lazy(lambda: 1).bind(fn).to_maybe() == Maybe.just(1)
    assert Lazy(lambda: 1).bind(fn).to_try() == Try.of(lambda: 1)

# Generated at 2022-06-18 01:41:50.460703
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:41:55.020897
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:41:59.981593
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:42:10.442340
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8

    def add_nine(a):
        return a + 9

    def add_ten(a):
        return a + 10


# Generated at 2022-06-18 01:42:20.404470
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Box(x)

    def fn2(x):
        return Maybe.just(x)

    def fn3(x):
        return Right(x)

    def fn4(x):
        return Try.of(lambda: x)

    def fn5(x):
        return Validation.success(x)

    assert Lazy.of(1).bind(fn) == Box(1)
    assert Lazy.of(1).bind(fn2) == Maybe.just(1)
    assert Lazy.of(1).bind(fn3) == Right(1)


# Generated at 2022-06-18 01:42:30.839157
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()

# Generated at 2022-06-18 01:42:42.471601
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def test_fn(x):
        return x

    def test_mapper(x):
        return x

    lazy_1 = Lazy(test_fn)
    lazy_2 = Lazy(test_fn)
    lazy_3 = Lazy(test_fn)
    lazy_4 = Lazy(test_fn)
    lazy_5 = Lazy(test_fn)
    lazy_6 = Lazy(test_fn)
    lazy_7 = Lazy(test_fn)
    lazy_8 = Lazy(test_fn)
    lazy_9 = Lazy(test_fn)
    lazy_10 = Lazy(test_fn)

    lazy_1.map(test_mapper)

# Generated at 2022-06-18 01:42:52.330697
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != L

# Generated at 2022-06-18 01:42:58.810977
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x, y):
        return x + y

    lazy_add = Lazy(add)
    lazy_add_box = lazy_add.ap(Box(1))
    assert lazy_add_box.get(2) == 3

    lazy_add_maybe = lazy_add.ap(Maybe.just(1))
    assert lazy_add_maybe.get(2) == 3

    lazy_add_nothing = lazy_add.ap(Maybe.nothing())
    assert lazy_add_nothing.get(2) == 2



# Generated at 2022-06-18 01:43:09.963788
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:43:19.336379
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    def fn3(x):
        return x + 3

    def fn4(x):
        return x + 4

    def fn5(x):
        return x + 5

    def fn6(x):
        return x + 6

    def fn7(x):
        return x + 7

    def fn8(x):
        return x + 8

    def fn9(x):
        return x + 9

    def fn10(x):
        return x + 10


# Generated at 2022-06-18 01:43:26.881353
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    lazy_add_one = Lazy(add_one)
    assert lazy_add_one.map(add_two) == Lazy(lambda x: add_two(add_one(x)))
    assert lazy_add_one.map(add_two).map(add_three) == Lazy(lambda x: add_three(add_two(add_one(x))))


# Generated at 2022-06-18 01:43:32.610989
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right

    def add(x):
        return lambda y: x + y

    def multiply(x):
        return lambda y: x * y

    assert Lazy.of(1).ap(Lazy.of(add(2))) == Lazy.of(3)
    assert Lazy.of(1).ap(Lazy.of(multiply(2))) == Lazy.of(2)
    assert Lazy.of(1).ap(Right.of(add(2))) == Lazy.of(3)
    assert Lazy.of(1).ap(Right.of(multiply(2))) == Lazy.of(2)



# Generated at 2022-06-18 01:43:41.767459
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x, y):
        return x + y

    def add_one(x):
        return x + 1

    assert Lazy.of(add).ap(Box(1)).ap(Box(2)).get() == 3
    assert Lazy.of(add).ap(Box(1)).ap(Box(2)).ap(Box(3)).get() == 6
    assert Lazy.of(add).ap(Box(1)).ap(Box(2)).ap(Box(3)).ap(Box(4)).get() == 10
    assert Lazy.of(add).ap(Box(1)).ap(Box(2)).ap(Box(3)).ap(Box(4)).ap(Box(5)).get() == 15


# Generated at 2022-06-18 01:43:52.779609
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 4
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 5
    assert L

# Generated at 2022-06-18 01:43:59.261802
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:44:07.634495
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:44:18.931638
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    class LazyFunctor(Functor[Lazy]):
        def map(self, functor: Lazy[T, U], mapper: Callable[[U], W]) -> Lazy[T, W]:
            return functor.map(mapper)

    class LazyMonad(Monad[Lazy]):
        def bind(self, monad: Lazy[T, U], fn: Callable[[U], Lazy[U, W]]) -> Lazy[T, W]:
            return monad.bind(fn)

    lazy_functor = LazyFunctor()
    lazy_monad = LazyMonad()

    def fn(*args):
        return 1

    def fn2(*args):
        return 2


# Generated at 2022-06-18 01:44:26.853350
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:44:37.860201
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(2).get(1) == 2
    assert Lazy.of(3).get(1, 2) == 3
    assert Lazy.of(4).get(1, 2, 3) == 4
    assert Lazy.of(5).get(1, 2, 3, 4) == 5
    assert Lazy.of(6).get(1, 2, 3, 4, 5) == 6
    assert Lazy.of(7).get(1, 2, 3, 4, 5, 6) == 7
    assert Lazy.of(8).get(1, 2, 3, 4, 5, 6, 7) == 8
    assert Lazy.of(9).get(1, 2, 3, 4, 5, 6, 7, 8) == 9
   

# Generated at 2022-06-18 01:44:49.792248
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: set())
    assert Lazy(fn) != Lazy(lambda: frozenset())
    assert Lazy(fn) != Lazy(lambda: 1)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: '1')

# Generated at 2022-06-18 01:45:00.104857
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:45:11.029625
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    def fn2():
        return 2

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).get()
    assert Lazy(fn) != Lazy(fn).get()
    assert Lazy(fn) != Lazy(fn).get()
    assert Lazy(fn) != Lazy(fn).get()
    assert Lazy(fn) != Lazy(fn).get()
    assert Lazy(fn) != Lazy(fn).get()
    assert Lazy(fn) != Lazy(fn).get()
    assert Lazy(fn) != Lazy(fn).get()


# Generated at 2022-06-18 01:45:13.796857
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f():
        return 1

    def g():
        return 2

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(g)


# Generated at 2022-06-18 01:45:20.507397
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).get()
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()

# Generated at 2022-06-18 01:45:31.559778
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:45:42.093599
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:45:51.894757
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1))

# Generated at 2022-06-18 01:45:57.306881
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    assert Lazy(lambda: 1).map(add_one).get() == 2
    assert Lazy(lambda: 1).map(add_one).map(add_one).get() == 3
    assert Lazy(lambda: 1).map(add_one).map(add_one).map(add_one).get() == 4


# Generated at 2022-06-18 01:46:09.224473
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 'test'

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)

    assert lazy_1 == lazy_2
    assert lazy_1 != Lazy(lambda: 'test2')
    assert lazy_1 != Lazy(lambda: 'test')
    assert lazy_1 != Lazy(lambda: 'test')
    assert lazy_1 != Lazy(lambda: 'test')
    assert lazy_1 != Lazy(lambda: 'test')
    assert lazy_1 != Lazy(lambda: 'test')
    assert lazy_1 != Lazy(lambda: 'test')
    assert lazy_1 != Lazy(lambda: 'test')
    assert lazy_1 != Lazy(lambda: 'test')
    assert lazy_1 != Lazy(lambda: 'test')
    assert lazy_1

# Generated at 2022-06-18 01:46:19.941051
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != L

# Generated at 2022-06-18 01:46:27.723511
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:46:38.052390
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Unit test for method map of class Lazy
    """
    from pymonet.functor import Functor

    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11


# Generated at 2022-06-18 01:46:45.127866
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(value):
        return Lazy.of(value + 1)

    assert Lazy.of(1).bind(add_one).get() == 2
    assert Lazy.of(1).bind(add_one).bind(add_one).get() == 3
    assert Lazy.of(1).bind(add_one).bind(add_one).bind(add_one).get() == 4


# Generated at 2022-06-18 01:46:54.482485
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def divide_by_two(x):
        return x / 2

    def add_two(x):
        return x + 2

    def multiply_by_three(x):
        return x * 3

    def divide_by_three(x):
        return x / 3

    def add_three(x):
        return x + 3

    def multiply_by_four(x):
        return x * 4

    def divide_by_four(x):
        return x / 4

    def add_four(x):
        return x + 4

    def multiply_by_five(x):
        return x * 5

    def divide_by_five(x):
        return x / 5


# Generated at 2022-06-18 01:47:04.807149
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:47:08.397630
# Unit test for method get of class Lazy
def test_Lazy_get():
    def f(x):
        return x + 1

    lazy = Lazy(f)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(2) == 3


# Generated at 2022-06-18 01:47:15.148606
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:47:22.531170
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    lazy = Lazy(add)
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3

    lazy = Lazy(add).map(add_one).map(add_two).map(add_three)
    assert lazy.get(1, 2) == 9
    assert lazy.get(1, 2) == 9

    lazy = Lazy(add).map(add_one).map(add_two).map(add_three)
    assert lazy.get(1, 2) == 9

# Generated at 2022-06-18 01:47:24.284634
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2


# Generated at 2022-06-18 01:47:39.951621
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:47:45.430539
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Try.of(fn)
    assert Lazy(fn) != None
    assert Lazy(fn) != 'Lazy'



# Generated at 2022-06-18 01:47:47.830920
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2



# Generated at 2022-06-18 01:47:58.148095
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    def add(x):
        return lambda y: x + y

    assert Lazy.of(1).ap(Box(add)).get() == 2
    assert Lazy.of(1).ap(Box(add)).get() == 2
    assert Lazy.of(1).ap(Box(add)).get() == 2
    assert Lazy.of(1).ap(Box(add)).get() == 2
    assert Lazy.of(1).ap(Box(add)).get() == 2
    assert Lazy.of(1).ap(Box(add)).get() == 2
    assert Lazy.of(1).ap(Box(add)).get() == 2
    assert Lazy.of(1).ap(Box(add)).get() == 2

# Generated at 2022-06-18 01:48:05.165267
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:48:11.901481
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box

    assert Lazy.of(Box(1)).get() == Box(1)
    assert Lazy.of(Box(1)).get(1) == Box(1)
    assert Lazy.of(Box(1)).get(1, 2) == Box(1)
    assert Lazy.of(Box(1)).get(1, 2, 3) == Box(1)
    assert Lazy.of(Box(1)).get(1, 2, 3, 4) == Box(1)
    assert Lazy.of(Box(1)).get(1, 2, 3, 4, 5) == Box(1)
    assert Lazy.of(Box(1)).get(1, 2, 3, 4, 5, 6) == Box(1)

# Generated at 2022-06-18 01:48:20.768286
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(1).ap(Lazy.of(lambda x: x + 1)) == Lazy.of(2)
    assert Lazy.of(1).ap(Box(lambda x: x + 1)) == Lazy.of(2)
    assert Lazy.of(1).ap(Right(lambda x: x + 1)) == Lazy.of(2)
    assert Lazy.of(1).ap(Maybe.just(lambda x: x + 1)) == Lazy.of(2)

# Generated at 2022-06-18 01:48:26.300314
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x + 1

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(lambda x: x + 2)
    lazy4 = Lazy(fn)
    lazy4._compute_value(1)

    assert lazy1 == lazy2
    assert lazy1 != lazy3
    assert lazy1 != lazy4

# Generated at 2022-06-18 01:48:35.516208
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: '1')
    assert Lazy(fn) != Lazy(lambda: [1])
    assert Lazy(fn) != Lazy(lambda: {1: 1})
    assert Lazy(fn) != Lazy(lambda: (1,))
    assert Lazy(fn) != Lazy(lambda: {1})
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)

# Generated at 2022-06-18 01:48:42.857873
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 'test'

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 'test2')
    assert Lazy(fn) != Lazy(lambda: 'test')
    assert Lazy(fn) != Lazy(lambda: 'test')
    assert Lazy(fn) != Lazy(lambda: 'test')
    assert Lazy(fn) != Lazy(lambda: 'test')
    assert Lazy(fn) != Lazy(lambda: 'test')
    assert Lazy(fn) != Lazy(lambda: 'test')
    assert Lazy(fn) != Lazy(lambda: 'test')
    assert Lazy(fn) != Lazy(lambda: 'test')
    assert Lazy(fn) != Lazy(lambda: 'test')
    assert L

# Generated at 2022-06-18 01:49:01.656080
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:49:10.126615
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:49:16.750644
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 4


# Generated at 2022-06-18 01:49:26.149267
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x: int) -> int:
        return x + 1

    def add_two(x: int) -> int:
        return x + 2

    def add_three(x: int) -> int:
        return x + 3

    def add_four(x: int) -> int:
        return x + 4

    def add_five(x: int) -> int:
        return x + 5

    def add_six(x: int) -> int:
        return x + 6

    def add_seven(x: int) -> int:
        return x + 7


# Generated at 2022-06-18 01:49:34.283408
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()

# Generated at 2022-06-18 01:49:45.627135
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
   

# Generated at 2022-06-18 01:49:49.484066
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1(x):
        return x

    def fn2(x):
        return x

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x).map(lambda x: x).map(lambda x: x)



# Generated at 2022-06-18 01:49:57.700915
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:50:06.084235
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(1) == 1
    assert Lazy(lambda: 1).get(1, 2) == 1
    assert Lazy(lambda: 1).get(1, 2, 3) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:50:13.469768
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: set())
    assert Lazy(fn) != Lazy(lambda: frozenset())
    assert Lazy(fn) != Lazy(lambda: object())
    assert Lazy(fn) != Lazy(lambda: Exception())
    assert Lazy(fn) != Lazy(lambda: Exception('test'))