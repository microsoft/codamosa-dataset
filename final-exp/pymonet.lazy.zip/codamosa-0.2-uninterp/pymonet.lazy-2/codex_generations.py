

# Generated at 2022-06-18 01:40:29.493474
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1():
        return 1

    def fn2():
        return 2

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1)
    assert Lazy(fn1) != Lazy(fn1).get()
    assert Lazy(fn1) != Lazy(fn1).get()
    assert Lazy(fn1) != Lazy(fn1).get()
    assert Lazy(fn1) != Lazy(fn1).get()
    assert Lazy(fn1) != Lazy(fn1).get()
    assert Lazy(fn1) != Lazy(fn1).get()

# Generated at 2022-06-18 01:40:40.795418
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:40:45.825487
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 3


# Generated at 2022-06-18 01:40:54.800854
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:41:05.385308
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def divide_by_two(x):
        return x / 2

    def add_one_and_multiply_by_two(x):
        return multiply_by_two(add_one(x))

    def divide_by_two_and_add_one(x):
        return add_one(divide_by_two(x))

    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x * 2)).get() == 4

# Generated at 2022-06-18 01:41:15.119050
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:41:24.589721
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    lazy_1 = Lazy.of(1)
    lazy_2 = Lazy.of(1)
    lazy_3 = Lazy.of(2)
    lazy_4 = Lazy(add_one)
    lazy_5 = Lazy(add_one)
    lazy_6 = Lazy(add_two)
    lazy_7 = Lazy(add_three)

    assert lazy_1 == lazy_2
    assert lazy_1 != lazy_3
    assert lazy_4 == lazy_5
    assert lazy_4 != lazy_6
    assert lazy_4 != lazy_7

   

# Generated at 2022-06-18 01:41:27.029831
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2

# Generated at 2022-06-18 01:41:29.807202
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2



# Generated at 2022-06-18 01:41:41.183783
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:41:49.416802
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    def add_one(value):
        return Lazy.of(value + 1)

    def add_two(value):
        return Lazy.of(value + 2)

    def add_three(value):
        return Lazy.of(value + 3)

    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7

# Generated at 2022-06-18 01:41:58.354722
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x):
        return x + 1

    def add_2(x):
        return x + 2

    def add_3(x):
        return x + 3

    def add_4(x):
        return x + 4

    def add_5(x):
        return x + 5

    def add_6(x):
        return x + 6

    def add_7(x):
        return x + 7

    def add_8(x):
        return x + 8

    def add_9(x):
        return x + 9

    def add_10(x):
        return x + 10

    def add_11(x):
        return x + 11

    def add_12(x):
        return x + 12

   

# Generated at 2022-06-18 01:42:02.278925
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(x):
        return x + 1

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(2) == 3


# Generated at 2022-06-18 01:42:12.661924
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10


# Generated at 2022-06-18 01:42:18.627565
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))


# Generated at 2022-06-18 01:42:24.051556
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor

    def test_fn(x):
        return x

    lazy_1 = Lazy(test_fn)
    lazy_2 = Lazy(test_fn)
    lazy_3 = Lazy(lambda x: x)
    lazy_4 = Lazy(lambda x: x)
    lazy_5 = Lazy(lambda x: x)
    lazy_6 = Lazy(lambda x: x)

    assert lazy_1 == lazy_2
    assert lazy_3 == lazy_4
    assert lazy_5 == lazy_6
    assert lazy_1 != lazy_3
    assert lazy_1 != lazy_4
    assert lazy_1 != lazy_5
    assert lazy_1 != lazy_6
    assert lazy_2 != lazy_3
    assert lazy_2 != lazy_4

# Generated at 2022-06-18 01:42:33.597139
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    def add(x, y):
        return x + y

    assert Lazy.of(add).ap(Lazy.of(1)).ap(Lazy.of(2)).get() == 3
    assert Lazy.of(add).ap(Lazy.of(1)).ap(Lazy.of(2)).to_maybe().get() == 3
    assert Lazy.of(add).ap(Lazy.of(1)).ap(Lazy.of(2)).to_either().get() == 3
    assert Lazy.of(add).ap(Lazy.of(1)).ap(Lazy.of(2)).to_box().get() == 3

# Generated at 2022-06-18 01:42:43.673855
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: 1)
    assert Lazy(fn) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)

# Generated at 2022-06-18 01:42:48.190382
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    assert Lazy.of(add).ap(Lazy.of(2)).get() == 3
    assert Lazy.of(mul).ap(Lazy.of(2)).get() == 4



# Generated at 2022-06-18 01:42:55.788135
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).get()
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()

# Generated at 2022-06-18 01:43:07.450712
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    lazy = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(fn)
    lazy4 = Lazy(fn)

    assert lazy == lazy2
    assert lazy == lazy3
    assert lazy == lazy4

    lazy2.get(1)
    lazy3.get(1)
    lazy4.get(2)

    assert lazy != lazy2
    assert lazy != lazy3
    assert lazy != lazy4

    lazy.get(1)

    assert lazy == lazy2
    assert lazy == lazy3
    assert lazy != lazy4



# Generated at 2022-06-18 01:43:16.412557
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:43:21.351084
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_box(x):
        return Box(x + 1)

    def add_either(x):
        return Right(x + 1)

    def add_maybe(x):
        return Maybe.just(x + 1)

    def add_try(x):
        return Try.of(lambda: x + 1)

    def add_validation(x):
        return Validation.success(x + 1)

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy

# Generated at 2022-06-18 01:43:24.499191
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    lazy = Lazy(add_one)
    assert lazy.map(add_two).get(1) == 4



# Generated at 2022-06-18 01:43:29.298910
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:43:39.346508
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))

    assert Lazy(lambda: 1) == Functor.of(Lazy, 1)
    assert Lazy(lambda: 1) == Monad.of

# Generated at 2022-06-18 01:43:43.035208
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_maybe import Maybe

    def add(x):
        return lambda y: x + y

    assert Lazy.of(1).ap(Lazy.of(add)).get() == 2
    assert Lazy.of(1).ap(Maybe.just(add)).get() == 2
    assert Lazy.of(1).ap(Maybe.nothing()).get() == 1


# Generated at 2022-06-18 01:43:53.542398
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:44:03.523875
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy = Lazy(fn)

    assert lazy == lazy
    assert lazy == Lazy(fn)
    assert lazy != Lazy(lambda: 2)
    assert lazy != Lazy(lambda: 1)
    assert lazy != Lazy(lambda: 1).map(lambda x: x + 1)
    assert lazy != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert lazy != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert lazy != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert lazy

# Generated at 2022-06-18 01:44:14.477247
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 'test'

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 'test2')
    assert Lazy(fn) != Lazy(lambda: 'test')
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: 1)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy

# Generated at 2022-06-18 01:44:26.723894
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:44:37.710620
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: set())
    assert Lazy(fn) != Lazy(lambda: frozenset())
    assert Lazy(fn) != Lazy(lambda: 1)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: '1')

# Generated at 2022-06-18 01:44:43.688885
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1():
        return 1

    def fn2():
        return 2

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1).get()
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1).get() + 1
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1).get() + 1
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1).get() + 1
    assert Lazy(fn1)

# Generated at 2022-06-18 01:44:49.972217
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    assert Lazy(add).bind(lambda x: Lazy(mul)).get(1) == 4
    assert Lazy(add).bind(lambda x: Lazy(mul)).get(2) == 5
    assert Lazy(add).bind(lambda x: Lazy(mul)).get(3) == 6



# Generated at 2022-06-18 01:44:54.802451
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    def fn3(x):
        return x + 3

    lazy = Lazy(fn)
    lazy2 = lazy.bind(fn2)
    lazy3 = lazy2.bind(fn3)

    assert lazy3.get(1) == 7

# Generated at 2022-06-18 01:45:05.540508
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:45:08.406685
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(a, b):
        return a + b

    lazy = Lazy(add)

    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3



# Generated at 2022-06-18 01:45:17.591564
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def divide_by_two(x):
        return x / 2

    def add_one_and_multiply_by_two(x):
        return add_one(multiply_by_two(x))

    def divide_by_two_and_add_one(x):
        return divide_by_two(add_one(x))

    def divide_by_two_and_multiply_by_two(x):
        return divide_by_two(multiply_by_two(x))


# Generated at 2022-06-18 01:45:29.167225
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()

# Generated at 2022-06-18 01:45:32.130630
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(arg):
        return arg

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 1



# Generated at 2022-06-18 01:45:40.037655
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x * 2

    lazy = Lazy(fn)

    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4



# Generated at 2022-06-18 01:45:45.079399
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(x):
        return x

    def g(x):
        return x

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(g)
    assert Lazy(f) != Lazy(f).map(lambda x: x)
    assert Lazy(f) != Lazy(f).ap(Lazy(g))
    assert Lazy(f) != Lazy(f).bind(lambda x: Lazy(g))
    assert Lazy(f) != Lazy(f).get()
    assert Lazy(f) != Lazy(f).to_box()
    assert Lazy(f) != Lazy(f).to_either()
    assert Lazy(f) != Lazy(f).to_maybe()

# Generated at 2022-06-18 01:45:54.879698
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:46:06.709483
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(x):
        return Lazy(lambda: x + 1)

    def g(x):
        return Lazy(lambda: x * 2)

    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4
    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4
    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4
    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4
    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4
    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4
    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4

# Generated at 2022-06-18 01:46:15.899833
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn_1():
        return 1

    def fn_2():
        return 2

    assert Lazy(fn_1) == Lazy(fn_1)
    assert Lazy(fn_1) != Lazy(fn_2)
    assert Lazy(fn_1) != Lazy(fn_1).map(lambda x: x + 1)
    assert Lazy(fn_1) != Lazy(fn_1).map(lambda x: x + 1).get()
    assert Lazy(fn_1) != Lazy(fn_1).map(lambda x: x + 1).get()
    assert Lazy(fn_1) != Lazy(fn_1).map(lambda x: x + 1).get()
    assert Lazy(fn_1) != Lazy(fn_1).map(lambda x: x + 1).get

# Generated at 2022-06-18 01:46:24.385886
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: "")
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: 1.1)

# Generated at 2022-06-18 01:46:35.127942
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:46:38.542592
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:46:48.070317
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def add(x, y):
        return x + y

    def add_one(x):
        return x + 1

    lazy_add = Lazy(add)
    lazy_add_one = Lazy(add_one)

    assert lazy_add.ap(lazy_add_one) == Lazy(lambda x: add(x, add_one(x)))
    assert lazy_add.ap(Maybe.just(1)) == Lazy(lambda x: add(x, 1))
    assert lazy_add.ap(Maybe.nothing()) == Lazy(lambda x: add(x, None))


# Generated at 2022-06-18 01:46:49.863281
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3



# Generated at 2022-06-18 01:47:07.637706
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return Lazy.of(value + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).to_box().get() == 2
    assert Lazy.of(1).bind(fn).to_either().get() == 2
    assert Lazy.of(1).bind(fn).to_maybe().get() == 2
    assert Lazy.of(1).bind(fn).to_try().get() == 2
    assert Lazy.of(1).bind(fn).to_validation().get

# Generated at 2022-06-18 01:47:14.583232
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    def fn3(x):
        return x + 3

    def fn4(x):
        return x + 4

    def fn5(x):
        return x + 5

    def fn6(x):
        return x + 6

    def fn7(x):
        return x + 7

    def fn8(x):
        return x + 8

    def fn9(x):
        return x + 9

    def fn10(x):
        return x + 10


# Generated at 2022-06-18 01:47:22.364208
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x * 2

    def fn3(x):
        return x * 3

    def fn4(x):
        return x * 4

    def fn5(x):
        return x * 5

    def fn6(x):
        return x * 6

    def fn7(x):
        return x * 7

    def fn8(x):
        return x * 8

    def fn9(x):
        return x * 9

    def fn10(x):
        return x * 10


# Generated at 2022-06-18 01:47:29.049045
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x / 2).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x / 2).map(lambda x: x - 1).get() == 1

# Generated at 2022-06-18 01:47:38.311473
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7
    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7
    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:47:45.295759
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    """
    Test for method __eq__ of class Lazy.
    """
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1)

# Generated at 2022-06-18 01:47:50.780103
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(x):
        return x + 1

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(2) == 3
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3



# Generated at 2022-06-18 01:48:01.225697
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    def add_two(x):
        return Lazy.of(x + 2)

    def add_three(x):
        return Lazy.of(x + 3)

    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7
    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7
    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7
    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7



# Generated at 2022-06-18 01:48:10.485313
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_2(x):
        return x + 2

    def add_3(x):
        return x + 3

    def add_4(x):
        return x + 4

    def add_5(x):
        return x + 5

    def add_6(x):
        return x + 6

    def add_7(x):
        return x + 7

    def add_8(x):
        return x + 8

    def add_9(x):
        return x + 9

    def add_10(x):
        return

# Generated at 2022-06-18 01:48:20.082113
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:48:43.405660
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).bind(fn).get() == 3
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:48:50.186207
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))


# Generated at 2022-06-18 01:48:56.530197
# Unit test for method get of class Lazy
def test_Lazy_get():
    def func(x):
        return x * 2

    lazy = Lazy(func)
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
   

# Generated at 2022-06-18 01:48:59.947439
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:49:08.873121
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).get()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()

# Generated at 2022-06-18 01:49:17.192288
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    def fn2():
        return 2

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).get()
    assert Lazy(fn) != Lazy(fn).to_box()
    assert Lazy(fn) != Lazy(fn).to_either()
    assert Lazy(fn) != Lazy(fn).to_maybe()
    assert Lazy(fn) != Lazy(fn).to_try()
    assert Lazy(fn) != Lazy(fn).to_validation()


# Generated at 2022-06-18 01:49:25.522953
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5



# Generated at 2022-06-18 01:49:33.592257
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(a):
        return Lazy.of(a)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).to_box() == Box(1)
    assert Lazy.of(1).bind(fn).to_either() == Right(1)
    assert Lazy.of(1).bind(fn).to_maybe() == Maybe.just(1)
    assert Lazy.of(1).bind(fn).to_try() == Try.of(lambda: 1)

# Generated at 2022-06-18 01:49:44.747913
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).map(lambda x: x + 1))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).ap(Lazy(lambda x: x + 1)))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).bind(lambda x: Lazy(lambda x: x + 1)))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).get())

# Generated at 2022-06-18 01:49:52.311727
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function(value):
        return value

    lazy = Lazy(test_function)

    assert lazy.get(1) == 1
    assert lazy.get(2) == 1
    assert lazy.get(3) == 1
    assert lazy.get(4) == 1
    assert lazy.get(5) == 1
    assert lazy.get(6) == 1
    assert lazy.get(7) == 1
    assert lazy.get(8) == 1
    assert lazy.get(9) == 1
    assert lazy.get(10) == 1

