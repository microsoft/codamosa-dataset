

# Generated at 2022-06-18 01:40:20.990307
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:40:25.053143
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(a):
        return Lazy(lambda: a + 1)

    assert Lazy(lambda: 1).bind(add_one).get() == 2


# Generated at 2022-06-18 01:40:31.065338
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1

# Generated at 2022-06-18 01:40:34.093937
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(x):
        return x + 1

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 2



# Generated at 2022-06-18 01:40:42.881112
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)

# Generated at 2022-06-18 01:40:53.168312
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    def fn3(x):
        return x + 3

    def fn4(x):
        return x + 4

    def fn5(x):
        return x + 5

    def fn6(x):
        return x + 6

    def fn7(x):
        return x + 7

    def fn8(x):
        return x + 8

    def fn9(x):
        return x + 9

    def fn10(x):
        return x + 10


# Generated at 2022-06-18 01:40:58.563534
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).get()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()

# Generated at 2022-06-18 01:41:03.357472
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def fn(value):
        return Lazy.of(value)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn) == Lazy.of(1)

    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(3)

# Generated at 2022-06-18 01:41:13.576302
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:41:19.918396
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5



# Generated at 2022-06-18 01:41:34.282845
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:41:44.882493
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:41:48.399803
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    lazy = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(lambda x: x)

    assert lazy == lazy2
    assert lazy != lazy3


# Generated at 2022-06-18 01:41:56.701619
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: set())
    assert Lazy(fn) != Lazy(lambda: frozenset())
    assert Lazy(fn) != Lazy(lambda: 1)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: True)

# Generated at 2022-06-18 01:42:07.094789
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)




# Generated at 2022-06-18 01:42:10.614720
# Unit test for method get of class Lazy
def test_Lazy_get():
    def get_value():
        return 'value'

    lazy = Lazy(get_value)

    assert lazy.get() == 'value'
    assert lazy.is_evaluated
    assert lazy.value == 'value'


# Generated at 2022-06-18 01:42:20.540293
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).get() == 2
    assert Lazy.of(1).map(add_one).map(add_two).get() == 3
    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 4

    assert Lazy.of(1).map(add_one).to_box().get()

# Generated at 2022-06-18 01:42:25.832701
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    lazy = Lazy.of(1)
    assert lazy.map(add_one).map(add_two).map(add_three).get() == 7



# Generated at 2022-06-18 01:42:33.308450
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()

# Generated at 2022-06-18 01:42:38.185537
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    lazy = Lazy(add_one)
    assert lazy.map(add_two).map(add_three).get(1) == 7


# Generated at 2022-06-18 01:42:52.335490
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def fn(value):
        return Lazy(lambda: value + 1)

    assert Lazy.of(1).bind(fn).get() == 2

    assert Lazy.of(1).bind(fn).to_box().get() == 2

    assert Lazy.of(1).bind(fn).to_either().get() == 2

    assert Lazy.of(1).bind(fn).to_maybe().get() == 2

    assert Lazy.of(1).bind(fn).to_try().get() == 2

    assert Lazy.of(1).bind(fn).to_validation().get() == 2

# Generated at 2022-06-18 01:42:55.292630
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(value):
        return value + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2



# Generated at 2022-06-18 01:43:05.085522
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x):
        return x + 1

    def add_box(x):
        return Box(x + 1)

    def add_maybe(x):
        return Maybe.just(x + 1)

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_box)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_maybe)) == Lazy.of(2)



# Generated at 2022-06-18 01:43:14.585852
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_two(x, y):
        return x + y

    def add_three(x, y, z):
        return x + y + z

    def add_four(x, y, z, w):
        return x + y + z + w

    def add_five(x, y, z, w, v):
        return x + y + z + w + v

    def add_six(x, y, z, w, v, u):
        return x + y + z + w + v + u


# Generated at 2022-06-18 01:43:20.606066
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).to_box() == Box(2)
    assert Lazy.of(1).bind(fn).to_either() == Right(2)
    assert Lazy.of(1).bind(fn).to_maybe() == Maybe.just(2)
    assert Lazy.of(1).bind(fn).to_try() == Try.of(lambda: 2)

# Generated at 2022-06-18 01:43:29.917279
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 4
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 5
    assert L

# Generated at 2022-06-18 01:43:33.290428
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def func():
        return 1

    lazy_1 = Lazy(func)
    lazy_2 = Lazy(func)
    lazy_3 = Lazy(lambda: 2)

    assert lazy_1 == lazy_2
    assert lazy_1 != lazy_3



# Generated at 2022-06-18 01:43:42.244594
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).get()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to

# Generated at 2022-06-18 01:43:52.981097
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: 1.0)

# Generated at 2022-06-18 01:43:59.448219
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: 'a')
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: 1.1)

# Generated at 2022-06-18 01:44:16.304380
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x * 2

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x * 3)
    assert Lazy(fn) != Lazy(lambda x: x * 2)
    assert Lazy(fn) != Lazy(lambda x: x * 2).map(lambda x: x * 3)
    assert Lazy(fn) != Lazy(lambda x: x * 2).map(lambda x: x * 2)
    assert Lazy(fn) != Lazy(lambda x: x * 2).map(lambda x: x * 2).map(lambda x: x * 2)

# Generated at 2022-06-18 01:44:19.831948
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function():
        return 'test'

    lazy = Lazy(test_function)

    assert lazy.get() == 'test'
    assert lazy.get() == 'test'
    assert lazy.is_evaluated



# Generated at 2022-06-18 01:44:27.410519
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()

# Generated at 2022-06-18 01:44:38.129350
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:44:43.948431
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:44:48.255156
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3



# Generated at 2022-06-18 01:44:58.109305
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:45:09.549535
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_fn(x):
        return x

    assert Lazy(test_fn) == Lazy(test_fn)
    assert Lazy(test_fn) != Lazy(lambda x: x + 1)
    assert Lazy(test_fn) != Lazy(test_fn).map(lambda x: x + 1)
    assert Lazy(test_fn) != Lazy(test_fn).get()
    assert Lazy(test_fn) != Lazy(test_fn).get(1)
    assert Lazy(test_fn) != Lazy(test_fn).get(1, 2)
    assert Lazy(test_fn) != Lazy(test_fn).get(1, 2, 3)
    assert Lazy(test_fn) != Lazy(test_fn).get(1, 2, 3, 4)


# Generated at 2022-06-18 01:45:12.390426
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2



# Generated at 2022-06-18 01:45:19.867220
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return

# Generated at 2022-06-18 01:45:37.746129
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    assert Lazy.of(add).ap(Box(1)).ap(Box(2)).get() == 3
    assert Lazy.of(add_one).ap(Lazy.of(1)).get() == 2

# Generated at 2022-06-18 01:45:47.538510
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(value):
        return Lazy.of(value + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).bind(fn).get() == 3
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:45:57.580824
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:46:04.132618
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))


# Generated at 2022-06-18 01:46:14.211373
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:46:23.533918
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:46:30.335551
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    assert Lazy(add_one).map(add_two).map(add_three).map(add_four).map(add_five).get() == 15


# Generated at 2022-06-18 01:46:36.917946
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    def fn3(x):
        return x + 3

    def fn4(x):
        return x + 4

    def fn5(x):
        return x + 5

    def fn6(x):
        return x + 6

    def fn7(x):
        return x + 7

    def fn8(x):
        return x + 8

    def fn9(x):
        return x + 9

    def fn10(x):
        return x + 10


# Generated at 2022-06-18 01:46:40.564059
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))



# Generated at 2022-06-18 01:46:42.471814
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2


# Generated at 2022-06-18 01:47:04.960159
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:47:12.450488
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(2) == 1
    assert Lazy.of(1).get(2, 3) == 1
    assert Lazy.of(1).get(2, 3, 4) == 1
    assert Lazy.of(1).get(2, 3, 4, 5) == 1
    assert Lazy.of(1).get(2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(2, 3, 4, 5, 6, 7, 8) == 1
    assert Lazy.of(1).get(2, 3, 4, 5, 6, 7, 8, 9) == 1
   

# Generated at 2022-06-18 01:47:20.999425
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_box(x):
        return Box(x + 1)

    def add_either(x):
        return Right(x + 1)

    def add_maybe(x):
        return Maybe.just(x + 1)

    def add_try(x):
        return Try.of(lambda: x + 1)

    def add_validation(x):
        return Validation.success(x + 1)

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy

# Generated at 2022-06-18 01:47:28.240698
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).get()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()

# Generated at 2022-06-18 01:47:37.769221
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for method bind of class Lazy.
    """
    from pymonet.maybe import Maybe

    def fn(value):
        return Maybe.just(value)

    assert Lazy.of(1).bind(fn) == Lazy.of(Maybe.just(1))
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(3)



# Generated at 2022-06-18 01:47:41.888537
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4


# Generated at 2022-06-18 01:47:48.469936
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Lazy.of(lambda x: x + 1).ap(Box(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Maybe.just(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Maybe.nothing()) == Lazy.of(lambda x: x + 1)


# Generated at 2022-06-18 01:47:58.930710
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(2) == 1
    assert Lazy.of(1).get(2, 3) == 1
    assert Lazy.of(1).get(2, 3, 4) == 1
    assert Lazy.of(1).get(2, 3, 4, 5) == 1
    assert Lazy.of(1).get(2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(2, 3, 4, 5, 6, 7, 8) == 1
    assert Lazy.of(1).get(2, 3, 4, 5, 6, 7, 8, 9) == 1
   

# Generated at 2022-06-18 01:48:08.850307
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    assert Lazy.of(1).bind(lambda x: Lazy.of(add_one(x))).get() == 2

# Generated at 2022-06-18 01:48:19.555063
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_try import Try

    def f(x):
        return x + 1

    def g(x):
        return x * 2

    def h(x):
        return x ** 2

    def i(x):
        return x / 2

    def j(x):
        return x - 1

    def k(x):
        return x + 1

    def l(x):
        return x * 2

    def m(x):
        return x ** 2

    def n(x):
        return x / 2

    def o(x):
        return x - 1

    def p(x):
        return x + 1

    def q(x):
        return x * 2

    def r(x):
        return x ** 2

    def s(x):
        return x / 2


# Generated at 2022-06-18 01:48:41.743533
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(1) == 1
    assert Lazy(lambda: 1).get(1, 2) == 1
    assert Lazy(lambda: 1).get(1, 2, 3) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:48:43.549317
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1


# Generated at 2022-06-18 01:48:51.050120
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    def add(a, b):
        return a + b

    lazy_add = Lazy(add)
    lazy_add_2 = Lazy(lambda: 2)
    lazy_add_3 = Lazy(lambda: 3)

    assert lazy_add.ap(lazy_add_2).get() == 5
    assert lazy_add.ap(lazy_add_3).get() == 6
    assert lazy_add.ap(Box(2)).get() == 5
    assert lazy_add.ap(Box(3)).get() == 6


# Generated at 2022-06-18 01:48:54.321938
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).map(add_two).map(add_three).get(1) == 7



# Generated at 2022-06-18 01:49:05.334036
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:49:12.884570
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1) == Lazy(lambda: 2)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy(lambda: 3)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy(lambda: 4)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy(lambda: 5)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map

# Generated at 2022-06-18 01:49:23.029262
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:49:30.652734
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return Lazy(lambda: value + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).to_box().get() == 2
    assert Lazy.of(1).bind(fn).to_either().get() == 2
    assert Lazy.of(1).bind(fn).to_maybe().get() == 2
    assert Lazy.of(1).bind(fn).to_try().get() == 2
    assert Lazy.of(1).bind(fn).to_validation().get

# Generated at 2022-06-18 01:49:37.125467
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:49:40.804686
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add(x):
        return x + 1

    def multiply(x):
        return x * 2

    lazy = Lazy(lambda: 1)
    assert lazy.bind(add).bind(multiply).get() == 4

# Generated at 2022-06-18 01:50:13.716174
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).get()
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()