

# Generated at 2022-06-18 01:40:26.385436
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))


# Generated at 2022-06-18 01:40:38.240383
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return

# Generated at 2022-06-18 01:40:42.298712
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).map(add_two).map(add_three).get(1) == 7



# Generated at 2022-06-18 01:40:53.173367
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    def fn2(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map(lambda x: x).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map

# Generated at 2022-06-18 01:40:59.794073
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 2).bind(fn).get() == 3
    assert Lazy(lambda: 3).bind(fn).get() == 4
    assert Lazy(lambda: 4).bind(fn).get() == 5
    assert Lazy(lambda: 5).bind(fn).get() == 6


# Generated at 2022-06-18 01:41:10.933500
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:41:15.194437
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return lambda y: x + y

    lazy_add = Lazy(add)
    lazy_2 = Lazy.of(2)
    lazy_3 = Lazy.of(3)

    assert lazy_add.ap(lazy_2).get() == 5
    assert lazy_add.ap(lazy_3).get() == 6

# Generated at 2022-06-18 01:41:20.183026
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Lazy.of(lambda x: x + 1).ap(Box(2)) == Lazy.of(3)
    assert Lazy.of(lambda x: x + 1).ap(Maybe.just(2)) == Lazy.of(3)
    assert Lazy.of(lambda x: x + 1).ap(Maybe.nothing()) == Lazy.of(lambda x: x + 1)



# Generated at 2022-06-18 01:41:23.313055
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(add_one).get() == 2


# Generated at 2022-06-18 01:41:34.554216
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:41:47.697422
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:41:51.814684
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn_1():
        return 1

    def fn_2():
        return 2

    lazy_1 = Lazy(fn_1)
    lazy_2 = Lazy(fn_2)
    lazy_3 = Lazy(fn_1)

    assert lazy_1 != lazy_2
    assert lazy_1 == lazy_3


# Generated at 2022-06-18 01:41:56.072179
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:42:00.677429
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    lazy = Lazy(add_one)
    assert lazy.map(add_two).map(add_three).get(1) == 7



# Generated at 2022-06-18 01:42:11.022594
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    assert Lazy(lambda: Box(1)).map(add_one).get() == Box(2)
    assert Lazy(lambda: Box(1)).map(add_one).map(add_two).get() == Box(3)
    assert Lazy(lambda: Box(1)).map(add_one).map(add_two).map(add_one).get() == Box(4)
    assert Lazy(lambda: Box(1)).map(add_one).map(add_two).map(add_one).map(add_two).get() == Box(5)

# Generated at 2022-06-18 01:42:16.886131
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:42:19.866496
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn():
        return 'test'

    lazy = Lazy(test_fn)

    assert lazy.get() == 'test'
    assert lazy.get() == 'test'
    assert lazy.is_evaluated


# Generated at 2022-06-18 01:42:24.438749
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function():
        return 'test_function'

    lazy = Lazy(test_function)
    assert lazy.get() == 'test_function'
    assert lazy.is_evaluated
    assert lazy.get() == 'test_function'



# Generated at 2022-06-18 01:42:33.829502
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 4
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 5
    assert L

# Generated at 2022-06-18 01:42:43.840603
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:42:56.053848
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:43:07.649855
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:43:16.598576
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_ap_with_box(lazy):
        assert lazy.ap(Box.of(lambda x: x + 1)).get() == 2

    def test_ap_with_either(lazy):
        assert lazy.ap(Right.of(lambda x: x + 1)).get() == 2

    def test_ap_with_maybe(lazy):
        assert lazy.ap(Maybe.just(lambda x: x + 1)).get() == 2

    def test_ap_with_try(lazy):
        assert lazy.ap(Try.of(lambda x: x + 1)).get() == 2



# Generated at 2022-06-18 01:43:25.757222
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x, y):
        return x + y

    def add_box(x):
        return Box(add(x, 1))

    def add_maybe(x):
        return Maybe.just(add(x, 1))

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_box)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_maybe)) == Lazy.of(2)



# Generated at 2022-06-18 01:43:32.725773
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(lambda: 1).map(add_one).get() == 2
    assert Lazy(lambda: 1).map(add_one).map(add_two).get() == 3
    assert Lazy(lambda: 1).map(add_one).map(add_two).map(add_three).get() == 4

    assert Lazy(lambda: 1).map(add_one).to_box().get() == 2
    assert Lazy(lambda: 1).map(add_one).map(add_two).to_box().get() == 3

# Generated at 2022-06-18 01:43:41.834543
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(lambda: 1)
    assert Lazy.of(1) != Lazy.of(lambda: 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(lambda: 1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(lambda: 1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(lambda: 1).to_

# Generated at 2022-06-18 01:43:52.780802
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:43:55.616465
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn1():
        return 'a'

    def fn2():
        return 'b'

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != 'a'
    assert Lazy(fn1) != None


# Generated at 2022-06-18 01:44:05.285255
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return Lazy(lambda: value)

    assert Lazy.of(10).bind(fn) == Lazy.of(10)
    assert Lazy.of(10).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(11)
    assert Lazy.of(10).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(12)

# Generated at 2022-06-18 01:44:15.892792
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).get() == 2
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).to_box().get() == 2
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).to_either().get() == 2
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).to_maybe().get() == 2
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).to_try().get() == 2

# Generated at 2022-06-18 01:44:23.936987
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    lazy = Lazy(lambda: 1)
    assert lazy.bind(add_one).bind(add_two).get() == 4



# Generated at 2022-06-18 01:44:33.979699
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: 'a')
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: 1.0)

# Generated at 2022-06-18 01:44:37.040656
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4


# Generated at 2022-06-18 01:44:43.327234
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: '1')
    assert Lazy(fn) != Lazy(lambda: '2')
    assert Lazy(fn) != Lazy(lambda: 'a')

# Generated at 2022-06-18 01:44:48.308670
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).bind(add_four).bind(add_five).get() == 15


# Generated at 2022-06-18 01:44:58.110538
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: 'a')
    assert Lazy(fn) != Lazy(lambda: 'b')
    assert Lazy(fn) != Lazy(lambda: 'c')

# Generated at 2022-06-18 01:45:09.548813
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: None)
    assert Lazy(lambda: 1) != Lazy(lambda: [1])
    assert Lazy(lambda: 1) != Lazy(lambda: {'a': 1})
    assert Lazy(lambda: 1) != Lazy(lambda: (1,))
    assert Lazy(lambda: 1) != Lazy(lambda: '1')
    assert Lazy(lambda: 1) != Lazy(lambda: 1.0)
    assert Lazy(lambda: 1) != Lazy(lambda: True)
    assert Lazy(lambda: 1) != Lazy(lambda: False)
    assert Lazy(lambda: 1)

# Generated at 2022-06-18 01:45:16.099009
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).map(add_two).map(add_three).get(1) == 7
    assert Lazy(add_one).map(add_two).map(add_three).get(2) == 8
    assert Lazy(add_one).map(add_two).map(add_three).get(3) == 9


# Generated at 2022-06-18 01:45:26.909155
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is True
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1)) is False
    assert Lazy(lambda x: x).__eq__(Functor(lambda x: x)) is False
    assert Lazy(lambda x: x).__eq__(Monad(lambda x: x)) is False
    assert Lazy(lambda x: x).__eq__(None) is False
    assert Lazy(lambda x: x).__eq__(1) is False
    assert Lazy(lambda x: x).__eq__('test') is False


# Generated at 2022-06-18 01:45:31.970007
# Unit test for method map of class Lazy
def test_Lazy_map():
    def f(x):
        return x * 2

    def g(x):
        return x + 2

    assert Lazy(f).map(g).get(1) == 4
    assert Lazy(f).map(g).get(2) == 6
    assert Lazy(f).map(g).get(3) == 8



# Generated at 2022-06-18 01:45:47.396871
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:45:57.070707
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).map(add_two).map(add_three).get(1) == 7
    assert Lazy(add_one).map(add_two).map(add_three).get(2) == 8
    assert Lazy(add_one).map(add_two).map(add_three).get(3) == 9
    assert Lazy(add_one).map(add_two).map(add_three).get(4) == 10
    assert Lazy(add_one).map(add_two).map(add_three).get(5) == 11


# Generated at 2022-06-18 01:46:03.954009
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(add_one).get() == 2
    assert Lazy.of(1).bind(add_one).bind(add_one).get() == 3
    assert Lazy.of(1).bind(add_one).bind(add_one).bind(add_one).get() == 4


# Generated at 2022-06-18 01:46:07.711395
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe

    def fn(x):
        return Maybe.just(x + 1)

    lazy = Lazy(lambda x: x + 1)
    assert lazy.bind(fn).get(1) == 3



# Generated at 2022-06-18 01:46:16.772522
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:46:21.464141
# Unit test for method map of class Lazy
def test_Lazy_map():
    def fn(x):
        return x + 1

    def mapper(x):
        return x * 2

    lazy = Lazy(fn)
    assert lazy.map(mapper).get(1) == 4
    assert lazy.map(mapper).get(2) == 6
    assert lazy.map(mapper).get(3) == 8


# Generated at 2022-06-18 01:46:23.397436
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:46:33.972051
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def multiply(x):
        return x * 2

    def divide(x):
        return x / 2

    def divide_by_zero(x):
        return x / 0

    def divide_by_zero_with_exception(x):
        raise ZeroDivisionError()

    def divide_by_zero_with_exception_and_return(x):
        raise ZeroDivisionError()
        return x / 0

    def divide_by_zero_with_exception_and_return_2(x):
        raise ZeroDivisionError()


# Generated at 2022-06-18 01:46:38.117633
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    lazy = Lazy(lambda: 1)
    assert lazy.map(add_one).map(add_two).map(add_three).get() == 7



# Generated at 2022-06-18 01:46:43.529076
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7


# Generated at 2022-06-18 01:47:05.386877
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    lazy_add_one = Lazy(add_one)
    lazy_add = Lazy(add)
    assert lazy_add_one.ap(lazy_add).get(1, 2) == 4
    assert lazy_add_one.ap(Box(add)).get(1, 2) == 4
    assert lazy_add_one.ap(Box(add)).to_box(1, 2) == Box(4)


# Generated at 2022-06-18 01:47:09.287196
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:47:11.437119
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2



# Generated at 2022-06-18 01:47:20.148339
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_two)) == Lazy.of(3)
    assert Lazy.of(1).ap(Lazy.of(add_three)) == Lazy.of(4)

    assert Lazy.of(1).ap(Right(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Right(add_two)) == Lazy.of(3)
   

# Generated at 2022-06-18 01:47:27.692261
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(2).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(2).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))

# Generated at 2022-06-18 01:47:39.035697
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:47:49.668371
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).get() == 2
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).to_box().get() == 2
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).to_either().get() == 2
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).to_maybe().get() == 2

# Generated at 2022-06-18 01:47:51.819531
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2

# Generated at 2022-06-18 01:47:57.195234
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).map(add_four).get() == 11


# Generated at 2022-06-18 01:48:08.055921
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10


# Generated at 2022-06-18 01:48:33.076418
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:48:42.046162
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x: int, y: int) -> int:
        return x + y

    def add_lazy(x: int) -> Lazy[int, int]:
        return Lazy(lambda y: add(x, y))

    assert Lazy.of(1).ap(Lazy.of(add_lazy)) == Lazy.of(2)
    assert Lazy.of(2).ap(Lazy.of(add_lazy)) == Lazy.of(3)
    assert Lazy.of(3).ap(Lazy.of(add_lazy)) == Lazy.of(4)
    assert Lazy.of(4).ap(Lazy.of(add_lazy)) == Lazy.of(5)

# Generated at 2022-06-18 01:48:45.275026
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    assert Lazy(add).map(mul).get(1) == 4



# Generated at 2022-06-18 01:48:48.204466
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda *args: x + 1)

    lazy = Lazy(lambda *args: 1)
    assert lazy.bind(fn).get() == 2

# Generated at 2022-06-18 01:48:55.586056
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy(lambda x: x + 1).ap(Lazy(lambda x: x + 2)) == Lazy(lambda x: x + 1).map(lambda x: x + 2)
    assert Lazy(lambda x: x + 1).ap(Box(2)) == Lazy(lambda x: x + 1).map(lambda x: x + 2)
    assert Lazy(lambda x: x + 1).ap(Right(2)) == Lazy(lambda x: x + 1).map(lambda x: x + 2)

# Generated at 2022-06-18 01:48:59.573158
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:49:02.131932
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:49:06.168344
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy(lambda: x + 1)

    def add_two(x):
        return Lazy(lambda: x + 2)

    lazy_value = Lazy(lambda: 1)
    assert lazy_value.bind(add_one).bind(add_two).get() == 4



# Generated at 2022-06-18 01:49:09.575192
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).map(add_two).map(add_three).get(1) == 7


# Generated at 2022-06-18 01:49:19.978260
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:49:53.228507
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)

    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x)



# Generated at 2022-06-18 01:49:58.594662
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5


# Generated at 2022-06-18 01:50:00.587326
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def fn(x):
        return Box(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2

# Generated at 2022-06-18 01:50:09.807099
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).bind(fn).get() == 3
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:50:19.258729
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Box(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Maybe.just(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Validation.success(1)) == Lazy.of(2)

