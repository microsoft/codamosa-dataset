

# Generated at 2022-06-18 01:40:29.494481
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:40:40.795714
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:40:51.522831
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_2(x):
        return x + 2

    def add_3(x):
        return x + 3

    def add_4(x):
        return x + 4

    def add_5(x):
        return x + 5

    def add_6(x):
        return x + 6

    def add_7(x):
        return x + 7

    def add_8(x):
        return x + 8

    def add_9(x):
        return x + 9

    def add_10(x):
        return

# Generated at 2022-06-18 01:40:53.447002
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function(value):
        return value

    lazy = Lazy(test_function)

    assert lazy.get(1) == 1
    assert lazy.get(2) == 1
    assert lazy.is_evaluated



# Generated at 2022-06-18 01:41:04.423254
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:41:14.364081
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:41:16.159494
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2

# Generated at 2022-06-18 01:41:18.587867
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    assert Lazy(add_one).bind(lambda x: Lazy(add_two)).get(1) == 4

# Generated at 2022-06-18 01:41:30.182574
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(2).get() == 2
    assert Lazy.of(3).get() == 3
    assert Lazy.of(4).get() == 4
    assert Lazy.of(5).get() == 5
    assert Lazy.of(6).get() == 6
    assert Lazy.of(7).get() == 7
    assert Lazy.of(8).get() == 8
    assert Lazy.of(9).get() == 9
    assert Lazy.of(10).get() == 10
    assert Lazy.of(11).get() == 11
    assert Lazy.of(12).get() == 12
    assert Lazy.of(13).get() == 13
    assert Lazy.of(14).get() == 14
    assert L

# Generated at 2022-06-18 01:41:35.727941
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2



# Generated at 2022-06-18 01:41:48.181444
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10


# Generated at 2022-06-18 01:41:51.604482
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(lambda: 2)

    assert lazy1 == lazy2
    assert lazy1 != lazy3
    assert lazy2 != lazy3



# Generated at 2022-06-18 01:41:58.512521
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1():
        return 1

    def fn2():
        return 2

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1).get()
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1).get() + 1
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1).get() + 1
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1).get() + 1
    assert Lazy(fn1)

# Generated at 2022-06-18 01:42:02.737682
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:42:13.201035
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return Lazy(lambda: value)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).to_box() == Box(1)
    assert Lazy.of(1).bind(fn).to_either() == Right(1)
    assert Lazy.of(1).bind(fn).to_maybe() == Maybe.just(1)
    assert Lazy.of(1).bind(fn).to_try() == Try.of(lambda: 1)

# Generated at 2022-06-18 01:42:22.093906
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:42:32.346307
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_to_box(a):
        return Box(add(a, 1))

    def add_to_either(a):
        return Right(add(a, 1))

    def add_to_maybe(a):
        return Maybe.just(add(a, 1))

    def add_to_try(a):
        return Try.of(add, a, 1)

    def add_to_validation(a):
        return Validation.success(add(a, 1))


# Generated at 2022-06-18 01:42:42.790029
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def div(x):
        return x / 2

    def concat(x):
        return x + 'a'

    def raise_exception(x):
        raise Exception('exception')

    def raise_value_error(x):
        raise ValueError('value error')

    def raise_type_error(x):
        raise TypeError('type error')

    def raise_key_error(x):
        raise KeyError('key error')

    def raise_attribute_error(x):
        raise AttributeError('attribute error')


# Generated at 2022-06-18 01:42:52.643329
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    def add_two(x):
        return Lazy.of(x + 2)

    assert Lazy.of(1).bind(add_one).bind(add_two).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_two).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_two).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_two).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_two).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_two).get() == 4
   

# Generated at 2022-06-18 01:42:56.888675
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)


# Generated at 2022-06-18 01:43:10.046892
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:43:14.140420
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor

    def test_fn(x):
        return x

    assert Lazy(test_fn) == Lazy(test_fn)
    assert Lazy(test_fn) != Lazy(lambda x: x + 1)
    assert Lazy(test_fn) != Functor(test_fn)


# Generated at 2022-06-18 01:43:20.391407
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:43:29.749103
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    lazy_add = Lazy(add)
    lazy_add_2 = Lazy(lambda: 2)
    lazy_add_3 = Lazy(lambda: 3)
    lazy_add_4 = Lazy(lambda: 4)

    assert lazy_add.ap(lazy_add_2).get() == 2
    assert lazy_add.ap(lazy_add_3).get() == 3
    assert lazy_add.ap(lazy_add_4).get() == 4

    assert lazy_add.ap(Box(2)).get() == 2
    assert lazy_add.ap(Box(3)).get() == 3
    assert lazy_add.ap(Box(4)).get()

# Generated at 2022-06-18 01:43:39.387197
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 'a').get() == 'a'
    assert Lazy(lambda: 'a').get() == 'a'
    assert Lazy(lambda: 'a').get() == 'a'
    assert Lazy(lambda: 'a').get() == 'a'
    assert Lazy(lambda: 'a').get() == 'a'
    assert Lazy(lambda: 'a').get() == 'a'
    assert Lazy(lambda: 'a').get() == 'a'
    assert Lazy(lambda: 'a').get() == 'a'
    assert Lazy(lambda: 'a').get() == 'a'
    assert Lazy(lambda: 'a').get() == 'a'

# Generated at 2022-06-18 01:43:44.986530
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:43:55.813127
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def func():
        return 1

    assert Lazy(func) == Lazy(func)
    assert Lazy(func) != Lazy(lambda: 2)
    assert Lazy(func) != Lazy(lambda: None)
    assert Lazy(func) != Lazy(lambda: [])
    assert Lazy(func) != Lazy(lambda: {})
    assert Lazy(func) != Lazy(lambda: ())
    assert Lazy(func) != Lazy(lambda: set())
    assert Lazy(func) != Lazy(lambda: frozenset())
    assert Lazy(func) != Lazy(lambda: 1)
    assert Lazy(func) != Lazy(lambda: 1.0)
    assert Lazy(func) != Lazy(lambda: True)

# Generated at 2022-06-18 01:44:05.403600
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:44:09.818502
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2



# Generated at 2022-06-18 01:44:20.588706
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:44:27.048504
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:44:38.034661
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 4
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 5
    assert L

# Generated at 2022-06-18 01:44:43.905517
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)
    lazy_3 = Lazy(fn)
    lazy_4 = Lazy(fn)

    assert lazy_1 == lazy_2
    assert lazy_2 == lazy_3
    assert lazy_3 == lazy_4
    assert lazy_4 == lazy_1

    assert lazy_1 != lazy_1.get()
    assert lazy_2 != lazy_2.get()
    assert lazy_3 != lazy_3.get()
    assert lazy_4 != lazy_4.get()

    assert lazy_1 != lazy_1.map(lambda x: x + 1)
    assert lazy_2 != lazy_2.map(lambda x: x + 1)

# Generated at 2022-06-18 01:44:55.022638
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 2).bind(fn).get() == 3
    assert Lazy(lambda: 3).bind(fn).get() == 4
    assert Lazy(lambda: 4).bind(fn).get() == 5
    assert Lazy(lambda: 5).bind(fn).get() == 6
    assert Lazy(lambda: 6).bind(fn).get() == 7
    assert Lazy(lambda: 7).bind(fn).get() == 8
    assert Lazy(lambda: 8).bind(fn).get() == 9
    assert Lazy(lambda: 9).bind(fn).get() == 10
    assert Lazy(lambda: 10).bind(fn).get() == 11


# Generated at 2022-06-18 01:44:56.799890
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2

# Generated at 2022-06-18 01:45:07.997700
# Unit test for method get of class Lazy
def test_Lazy_get():
    def f(a):
        return a + 1

    lazy = Lazy(f)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
   

# Generated at 2022-06-18 01:45:16.692657
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)
    lazy_3 = Lazy(fn)

    assert lazy_1 == lazy_2
    assert lazy_1 == lazy_3
    assert lazy_2 == lazy_3

    lazy_1._compute_value(1)

    assert lazy_1 != lazy_2
    assert lazy_1 != lazy_3
    assert lazy_2 != lazy_3

    lazy_2._compute_value(1)
    lazy_3._compute_value(1)

    assert lazy_1 == lazy_2
    assert lazy_1 == lazy_3
    assert lazy_2 == lazy_3



# Generated at 2022-06-18 01:45:27.957586
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:45:37.887116
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).bind(lambda x: Lazy(add_two)).bind(lambda x: Lazy(add_three)).get(1) == 7
    assert Lazy(add_one).bind(lambda x: Lazy(add_two)).bind(lambda x: Lazy(add_three)).get(2) == 8
    assert Lazy(add_one).bind(lambda x: Lazy(add_two)).bind(lambda x: Lazy(add_three)).get(3) == 9



# Generated at 2022-06-18 01:45:43.281847
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).map(add_four).get() == 11


# Generated at 2022-06-18 01:45:57.082671
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    def add_two(x):
        return Lazy.of(x + 2)

    def add_three(x):
        return Lazy.of(x + 3)

    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7


# Generated at 2022-06-18 01:46:08.864237
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:46:13.991695
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    assert Lazy.of(1).ap(Box(add)).get() == 2
    assert Lazy.of(1).ap(Box(mul)).get() == 2
    assert Lazy.of(1).ap(Box(add)).ap(Box(mul)).get() == 4


# Generated at 2022-06-18 01:46:18.237001
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1():
        return 1

    def fn2():
        return 2

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != 1


# Generated at 2022-06-18 01:46:22.613317
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    assert Lazy.of(add).ap(Box(1)).ap(Box(2)).get() == 3
    assert Lazy.of(add).ap(Maybe.just(1)).ap(Maybe.just(2)).get() == 3

# Generated at 2022-06-18 01:46:33.163094
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:46:40.169430
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:46:49.637545
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5



# Generated at 2022-06-18 01:46:53.724424
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(value):
        return Lazy.of(value)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).bind(fn) == Lazy.of(1)

    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(3)



# Generated at 2022-06-18 01:47:00.796615
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5


# Generated at 2022-06-18 01:47:24.583115
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()

# Generated at 2022-06-18 01:47:29.679348
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(add_one).get() == 2
    assert Lazy.of(1).bind(add_one).bind(add_one).get() == 3
    assert Lazy.of(1).bind(add_one).bind(add_one).bind(add_one).get() == 4


# Generated at 2022-06-18 01:47:36.364249
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:47:44.201356
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def divide_by_two(x):
        return x / 2

    def divide_by_zero(x):
        return x / 0

    assert Lazy.of(1).bind(lambda x: Lazy.of(add_one(x))).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(add_one(x))).bind(lambda x: Lazy.of(multiply_by_two(x))).get() == 4

# Generated at 2022-06-18 01:47:54.405411
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:48:06.279911
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    assert Lazy(lambda x: x) == Lazy(lambda x: x)
    assert Lazy(lambda x: x) != Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x) != Lazy(lambda x: x + 1).map(lambda x: x)
    assert Lazy(lambda x: x) != Lazy(lambda x: x + 1).map(lambda x: x).map(lambda x: x)
    assert Lazy(lambda x: x) != Lazy(lambda x: x + 1).map(lambda x: x).map(lambda x: x).map(lambda x: x)
    assert Lazy(lambda x: x) != L

# Generated at 2022-06-18 01:48:08.161079
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2



# Generated at 2022-06-18 01:48:17.176596
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1():
        return 1

    def fn2():
        return 2

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn2) == Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != fn1
    assert Lazy(fn1) != 1
    assert Lazy(fn1) != None


# Generated at 2022-06-18 01:48:22.979763
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()

# Generated at 2022-06-18 01:48:33.383449
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:49:10.954069
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:49:17.030403
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test for method map of class Lazy
    """
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:49:26.369660
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:49:34.508676
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:49:45.626246
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x):
        return x + 1

    def add2(x):
        return x + 2

    def add3(x):
        return x + 3

    def add4(x):
        return x + 4

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add)).ap(Lazy.of(add2)) == Lazy.of(4)
    assert Lazy.of(1).ap(Lazy.of(add)).ap(Lazy.of(add2)).ap(Lazy.of(add3)) == Lazy.of(7)

# Generated at 2022-06-18 01:49:55.118108
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:50:02.655384
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: 'a')
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: set())
    assert Lazy(fn) != Lazy(lambda: frozenset())
    assert Lazy(fn) != Lazy(lambda: 1)
    assert Lazy(fn) != Lazy(lambda: 1.0)

# Generated at 2022-06-18 01:50:11.306010
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return

# Generated at 2022-06-18 01:50:15.754001
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    lazy_add_one = Lazy(add_one)
    lazy_add_two = Lazy(add_two)
    lazy_add_three = Lazy(add_three)
    lazy_add_four = Lazy(add_four)

    assert lazy_add_one.map(add_two).get(1) == 3
    assert lazy_add_one.map(add_two).map(add_three).get(1) == 6

# Generated at 2022-06-18 01:50:22.822938
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).to_box() == Box(2)
    assert Lazy(lambda: 1).bind(fn).to_either() == Right(2)
    assert Lazy(lambda: 1).bind(fn).to_maybe() == Maybe.just(2)
    assert Lazy(lambda: 1).bind(fn).to_try() == Try.of(lambda: 1).bind(fn)