

# Generated at 2022-06-18 01:40:20.671805
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def test_eq(lazy: Lazy[int, int], other: Lazy[int, int], expected: bool):
        assert lazy == other == expected

    def test_neq(lazy: Lazy[int, int], other: Lazy[int, int], expected: bool):
        assert lazy != other != expected

    test_eq(Lazy(lambda x: x), Lazy(lambda x: x), True)
    test_eq(Lazy(lambda x: x), Lazy(lambda x: x + 1), False)
    test_eq(Lazy(lambda x: x), Lazy(lambda x: x).map(lambda x: x), True)

# Generated at 2022-06-18 01:40:29.862467
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:40:40.797905
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x - 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x - 1).map(lambda x: x / 2).get() == 1.5
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x - 1).map

# Generated at 2022-06-18 01:40:51.522526
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy(lambda: x + 1)

    def fn2(x):
        return Lazy(lambda: x + 2)

    assert Lazy.of(1).bind(fn).bind(fn2).get() == 4
    assert Lazy.of(1).bind(fn).bind(fn2).to_box().get() == 4
    assert Lazy.of(1).bind(fn).bind(fn2).to_either().get() == 4
    assert Lazy.of(1).bind(fn).bind(fn2).to_maybe().get() == 4
   

# Generated at 2022-06-18 01:40:59.208689
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:41:02.927816
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:41:10.290372
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))


# Generated at 2022-06-18 01:41:17.204905
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:41:25.632770
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5


# Generated at 2022-06-18 01:41:34.287399
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def add(x):
        return lambda y: x + y

    def add_2(x):
        return x + 2

    assert Lazy.of(2).ap(Box(add)).get() == 4
    assert Lazy.of(2).ap(Box(add_2)).get() == 4
    assert Lazy.of(2).ap(Lazy.of(add)).get() == 4
    assert Lazy.of(2).ap(Lazy.of(add_2)).get() == 4


# Generated at 2022-06-18 01:41:39.136361
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:41:49.180457
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(2) == 1
    assert Lazy(lambda: 1).get(2, 3) == 1
    assert Lazy(lambda: 1).get(2, 3, 4) == 1
    assert Lazy(lambda: 1).get(2, 3, 4, 5) == 1
    assert Lazy(lambda: 1).get(2, 3, 4, 5, 6) == 1
    assert Lazy(lambda: 1).get(2, 3, 4, 5, 6, 7) == 1
    assert Lazy(lambda: 1).get(2, 3, 4, 5, 6, 7, 8) == 1
    assert Lazy(lambda: 1).get(2, 3, 4, 5, 6, 7, 8, 9) == 1
   

# Generated at 2022-06-18 01:41:57.971383
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def multiply(x):
        return x * 2

    def divide(x):
        return x / 2

    def raise_error(x):
        raise ValueError('error')

    def raise_type_error(x):
        raise TypeError('error')

    def raise_zero_division_error(x):
        return 1 / 0

    def raise_key_error(x):
        raise KeyError('error')

    def raise_attribute_error(x):
        raise AttributeError('error')


# Generated at 2022-06-18 01:42:08.439316
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add(x):
        return Lazy(lambda y: x + y)

    assert Lazy(lambda x: x).bind(add).get(1) == 1
    assert Lazy(lambda x: x).bind(add).get(2) == 2
    assert Lazy(lambda x: x).bind(add).get(3) == 3
    assert Lazy(lambda x: x).bind(add).get(4) == 4
    assert Lazy(lambda x: x).bind(add).get(5) == 5
    assert Lazy(lambda x: x).bind(add).get(6) == 6
    assert Lazy(lambda x: x).bind(add).get(7) == 7
    assert Lazy(lambda x: x).bind(add).get(8) == 8
    assert Lazy(lambda x: x).bind

# Generated at 2022-06-18 01:42:15.190486
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Lazy.of(1).map(add_one).get() == 2
    assert Lazy.of(1).map(add_one).map(add_two).get() == 3
    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 4



# Generated at 2022-06-18 01:42:21.599747
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    lazy_add_one = Lazy(add_one)
    lazy_multiply_by_two = Lazy(multiply_by_two)

    assert lazy_add_one.bind(lambda x: lazy_multiply_by_two) == Lazy(lambda x: x * 2)
    assert lazy_add_one.bind(lambda x: lazy_multiply_by_two).get(1) == 4


# Generated at 2022-06-18 01:42:31.948372
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:42:42.633306
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).get()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()

# Generated at 2022-06-18 01:42:52.492045
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:42:59.750030
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:43:12.331097
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:43:20.307388
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != L

# Generated at 2022-06-18 01:43:26.622305
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(a):
        return a

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)
    lazy_3 = Lazy(fn)

    lazy_1._compute_value(1)
    lazy_2._compute_value(1)
    lazy_3._compute_value(2)

    assert lazy_1 == lazy_2
    assert lazy_1 != lazy_3
    assert lazy_2 != lazy_3



# Generated at 2022-06-18 01:43:33.218120
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:43:42.188390
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(lambda x: x + 1).ap(Box(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Right(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Maybe.just(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Try.of(lambda x: x + 1, 1)) == Lazy.of(2)

# Generated at 2022-06-18 01:43:52.982072
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:43:59.447605
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def add_two(x):
        return x + 2

    def multiply_by_three(x):
        return x * 3

    def multiply_by_four(x):
        return x * 4

    def multiply_by_five(x):
        return x * 5

    def multiply_by_six(x):
        return x * 6

    def multiply_by_seven(x):
        return x * 7

    def multiply_by_eight(x):
        return x * 8

    def multiply_by_nine(x):
        return x * 9

    def multiply_by_ten(x):
        return x * 10


# Generated at 2022-06-18 01:44:01.884786
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe

    def fn(value):
        return Maybe.just(value)

    lazy = Lazy.of(1)
    assert lazy.bind(fn) == Lazy.of(1)

# Generated at 2022-06-18 01:44:06.393821
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:44:17.245152
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def fn(x):
        return Maybe.just(x + 1)

    assert Lazy.of(1).bind(fn) == Lazy(lambda: fn(1).get())
    assert Lazy.of(1).bind(fn).bind(fn) == Lazy(lambda: fn(1).get()).bind(fn)
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn) == Lazy(lambda: fn(1).get()).bind(fn).bind(fn)
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn) == Lazy(lambda: fn(1).get()).bind(fn).bind(fn).bind(fn)
    assert Lazy.of

# Generated at 2022-06-18 01:44:27.022864
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x * 2

    def fn3(x):
        return x * 3

    def fn4(x):
        return x * 4

    def fn5(x):
        return x * 5

    def fn6(x):
        return x * 6

    def fn7(x):
        return x * 7

    def fn8(x):
        return x * 8

    def fn9(x):
        return x * 9

    def fn10(x):
        return x * 10


# Generated at 2022-06-18 01:44:37.961398
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:44:43.861524
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:44:54.896309
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x + 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 2)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).get()
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).get() + 1
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).get() + 1
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).get() + 1
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).get()

# Generated at 2022-06-18 01:45:01.863025
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x):
        return lambda y: x + y

    assert Lazy.of(1).ap(Box.of(add(1))).get() == 2
    assert Lazy.of(1).ap(Maybe.just(add(1))).get() == 2
    assert Lazy.of(1).ap(Maybe.nothing()).get() == 1



# Generated at 2022-06-18 01:45:11.923804
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:45:15.903248
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Try.of(lambda: 1)
    assert Lazy.of(1) != 1



# Generated at 2022-06-18 01:45:21.353474
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return Lazy(lambda: value + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).to_box().get() == 2
    assert Lazy.of(1).bind(fn).to_either().get() == 2
    assert Lazy.of(1).bind(fn).to_maybe().get() == 2
    assert Lazy.of(1).bind(fn).to_try().get() == 2
    assert Lazy.of(1).bind(fn).to_validation().get

# Generated at 2022-06-18 01:45:32.209638
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(value):
        return Lazy.of(value + 1)

    assert Lazy.of(1).bind(add_one).get() == 2
    assert Lazy.of(1).bind(add_one).bind(add_one).get() == 3
    assert Lazy.of(1).bind(add_one).bind(add_one).bind(add_one).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_one).bind(add_one).bind(add_one).get() == 5
    assert Lazy.of(1).bind(add_one).bind(add_one).bind(add_one).bind(add_one).bind(add_one).get() == 6

# Generated at 2022-06-18 01:45:42.952944
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:45:55.250386
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x):
        return x + 1

    def add_to_box(x):
        return Box(x + 1)

    def add_to_maybe(x):
        return Maybe.just(x + 1)

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_to_box)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_to_maybe)) == Lazy.of(2)

# Generated at 2022-06-18 01:46:07.061456
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).to_box().get() == 2
    assert Lazy.of(1).bind(fn).to_either().get() == 2
    assert Lazy.of(1).bind(fn).to_maybe().get() == 2
    assert Lazy.of(1).bind(fn).to_try().get() == 2
    assert Lazy.of(1).bind(fn).to_validation().get

# Generated at 2022-06-18 01:46:11.937202
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).bind(lambda x: Lazy(add_two)).bind(lambda x: Lazy(add_three)).get(1) == 7


# Generated at 2022-06-18 01:46:22.884257
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(1) == 1
    assert Lazy(lambda x: x).get(1) == 1
    assert Lazy(lambda x, y: x + y).get(1, 2) == 3
    assert Lazy(lambda x, y: x + y).get(1, 2, 3) == 3
    assert Lazy(lambda x, y, z: x + y + z).get(1, 2, 3) == 6
    assert Lazy(lambda x, y, z: x + y + z).get(1, 2, 3, 4) == 6

# Generated at 2022-06-18 01:46:33.424047
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_2(x):
        return x + 2

    def add_3(x):
        return x + 3

    def add_4(x):
        return x + 4

    def add_5(x):
        return x + 5

    def add_6(x):
        return x + 6

    def add_7(x):
        return x + 7

    def add_8(x):
        return x + 8

    def add_9(x):
        return x + 9

    def add_10(x):
        return

# Generated at 2022-06-18 01:46:40.268710
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:46:44.911527
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(2).bind(fn).get() == 3
    assert Lazy.of(3).bind(fn).get() == 4


# Generated at 2022-06-18 01:46:54.345017
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(add_one).get() == 2
    assert Lazy.of(1).bind(add_one).bind(add_one).get() == 3
    assert Lazy.of(1).bind(add_one).bind(add_one).bind(add_one).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_one).bind(add_one).bind(add_one).get() == 5
    assert Lazy.of(1).bind(add_one).bind(add_one).bind(add_one).bind(add_one).bind(add_one).get() == 6

# Generated at 2022-06-18 01:47:04.654972
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:47:12.162390
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(x):
        return x + 1

    def test_fn2(x):
        return x * 2

    def test_fn3(x):
        return x / 2

    def test_fn4(x):
        return x - 1

    def test_fn5(x):
        return x ** 2

    def test_fn6(x):
        return x ** 0.5

    def test_fn7(x):
        return x ** 0.5

    def test_fn8(x):
        return x ** 0.5


# Generated at 2022-06-18 01:47:26.580140
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def add(a, b):
        return a + b

    lazy_add = Lazy(add)
    lazy_add_2 = Lazy(lambda: 2)
    lazy_add_3 = Lazy(lambda: 3)

    assert lazy_add.ap(lazy_add_2).get() == 5
    assert lazy_add.ap(lazy_add_3).get() == 6
    assert lazy_add.ap(Box(2)).get() == 5
    assert lazy_add.ap(Box(3)).get() == 6


# Generated at 2022-06-18 01:47:37.689284
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:47:42.218876
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:47:52.985793
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != L

# Generated at 2022-06-18 01:48:00.093898
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    def multiply(a, b):
        return a * b

    lazy_add = Lazy(add)
    lazy_multiply = Lazy(multiply)

    assert lazy_add.ap(Box(2)).get(1) == 3
    assert lazy_multiply.ap(Box(2)).get(1) == 2
    assert lazy_add.ap(Maybe.just(2)).get(1) == 3
    assert lazy_multiply.ap(Maybe.just(2)).get(1) == 2


# Generated at 2022-06-18 01:48:08.578087
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x / 2).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x / 2).map(lambda x: x - 1).get() == 1



# Generated at 2022-06-18 01:48:19.520164
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:48:21.168080
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:48:25.616746
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    def fn2():
        return 2

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(fn2)

    assert lazy1 == lazy2
    assert lazy1 != lazy3



# Generated at 2022-06-18 01:48:28.831281
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.is_evaluated



# Generated at 2022-06-18 01:48:43.468942
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1.0)
    assert Lazy.of(1) != Lazy.of(1.0).map(int)
    assert Lazy.of(1) != Lazy.of(1.0).map(int).map(float)
    assert Lazy.of(1) != Lazy.of(1.0).map(int).map(float).map(int)
    assert Lazy.of(1) != Lazy.of(1.0).map(int).map(float).map(int).map(float)

# Generated at 2022-06-18 01:48:53.144161
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:49:04.435328
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn_raise():
        raise Exception('test')

    assert Lazy.of(1).ap(Lazy.of(fn)).get() == 2
    assert Lazy.of(1).ap(Lazy.of(fn)).to_box().get() == 2
    assert Lazy.of(1).ap(Lazy.of(fn)).to_either().get() == 2
    assert Lazy.of(1).ap(Lazy.of(fn)).to_maybe().get() == 2

# Generated at 2022-06-18 01:49:12.271871
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative
    from pymonet.foldable import Foldable

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))

    assert Lazy.of(1) == Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_box().to_lazy()

    assert Lazy.of

# Generated at 2022-06-18 01:49:20.343778
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_five(x):
        return x + 5

    assert Lazy.of(add_two).ap(Box(add_three)).get() == add_two(add_three(0))
    assert Lazy.of(add_two).ap(Box(add_three)).ap(Box(add_five)).get() == add_two(add_three(add_five(0)))



# Generated at 2022-06-18 01:49:29.342649
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:49:31.440283
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(x, y):
        return x + y

    lazy = Lazy(add)
    assert lazy.get(1, 2) == 3



# Generated at 2022-06-18 01:49:37.581467
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)
    lazy_3 = Lazy(fn)
    lazy_4 = Lazy(fn)

    assert lazy_1 == lazy_2
    assert lazy_1 == lazy_3
    assert lazy_1 == lazy_4
    assert lazy_2 == lazy_3
    assert lazy_2 == lazy_4
    assert lazy_3 == lazy_4

    lazy_1._compute_value()
    assert lazy_1 == lazy_2
    assert lazy_1 == lazy_3
    assert lazy_1 == lazy_4
    assert lazy_2 == lazy_3
    assert lazy_2 == lazy_4
    assert lazy_3 == lazy_4

    lazy_2._compute_value()
    assert lazy_

# Generated at 2022-06-18 01:49:45.215078
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))


# Generated at 2022-06-18 01:49:51.128951
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).to_box().get() == 2
    assert Lazy.of(1).bind(fn).to_box().get() == Box(2).get()



# Generated at 2022-06-18 01:50:17.010845
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_2(x):
        return x + 2

    def add_3(x):
        return x + 3

    def add_4(x):
        return x + 4

    def add_5(x):
        return x + 5

    def add_6(x):
        return x + 6

    def add_7(x):
        return x + 7

    def add_8(x):
        return x + 8

    def add_9(x):
        return x + 9

    def add_10(x):
        return