

# Generated at 2022-06-18 01:40:16.606927
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:40:22.793132
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:40:30.462187
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value):
        return Lazy.of(value)

    def test_fn_with_error(value):
        return Lazy.of(value)

    assert Lazy.of(1).bind(test_fn) == Lazy.of(1)
    assert Lazy.of(1).bind(test_fn).bind(test_fn) == Lazy.of(1)
    assert Lazy.of(1).bind(test_fn).bind(test_fn).bind(test_fn) == Lazy.of(1)


# Generated at 2022-06-18 01:40:40.950449
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:40:51.522516
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:40:57.529073
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    assert Lazy.of(1).map(add_one).map(add_two).get() == 4
    assert Lazy.of(1).map(add_one).map(add_two).map(add_one).get() == 5
    assert Lazy.of(1).map(add_one).map(add_two).map(add_one).map(add_two).get() == 6
    assert Lazy.of(1).map(add_one).map(add_two).map(add_one).map(add_two).map(add_one).get() == 7

# Generated at 2022-06-18 01:41:00.976336
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(value):
        return Lazy.of(value + 1)

    lazy = Lazy.of(1)
    assert lazy.bind(fn).get() == 2



# Generated at 2022-06-18 01:41:08.102129
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    assert Lazy.of(1).map(add_one).get() == 2
    assert Lazy.of(1).map(add_one).map(add_two).get() == 3
    assert Lazy.of(1).map(add_one).map(add_two).map(add_one).get() == 4


# Generated at 2022-06-18 01:41:13.313303
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return lambda y: x + y

    def multiply(x):
        return lambda y: x * y

    assert Lazy.of(add(1)).ap(Lazy.of(2)) == Lazy.of(3)
    assert Lazy.of(multiply(2)).ap(Lazy.of(3)) == Lazy.of(6)


# Generated at 2022-06-18 01:41:20.552143
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(x):
        return x + 1

    def test_fn_2(x):
        return x + 2

    def test_fn_3(x):
        return x + 3

    def test_fn_4(x):
        return x + 4

    def test_fn_5(x):
        return x + 5

    def test_fn_6(x):
        return x + 6

    def test_fn_7(x):
        return x + 7

    def test_fn_8(x):
        return x + 8


# Generated at 2022-06-18 01:41:34.106860
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x, y):
        return x + y

    def multiply(x, y):
        return x * y

    def divide(x, y):
        return x / y

    def subtract(x, y):
        return x - y

    def raise_exception(x, y):
        raise Exception('Exception')

    def raise_value_error(x, y):
        raise ValueError('ValueError')

    def raise_type_error(x, y):
        raise TypeError('TypeError')

    def raise_key_error(x, y):
        raise KeyError('KeyError')

# Generated at 2022-06-18 01:41:44.713160
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).get()
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()

# Generated at 2022-06-18 01:41:50.893255
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    assert Lazy.of(1).ap(Box(add)).get() == 2
    assert Lazy.of(1).ap(Box(mul)).get() == 2
    assert Lazy.of(1).ap(Box(add)).ap(Box(mul)).get() == 4


# Generated at 2022-06-18 01:41:58.234660
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:42:08.678112
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:42:13.190568
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4


# Generated at 2022-06-18 01:42:22.095125
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_three(a, b, c):
        return a + b + c

    def add_four(a, b, c, d):
        return a + b + c + d

    def add_five(a, b, c, d, e):
        return a + b + c + d + e

    def add_six(a, b, c, d, e, f):
        return a + b + c + d + e + f


# Generated at 2022-06-18 01:42:32.348121
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x

    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1

# Generated at 2022-06-18 01:42:34.642244
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2



# Generated at 2022-06-18 01:42:44.855269
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:42:55.132047
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def fn(*args):
        return args

    lazy = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy == lazy2
    assert lazy == Lazy(fn)
    assert lazy == Lazy(lambda: fn())
    assert lazy == Lazy(lambda x: fn(x))
    assert lazy == Lazy(lambda x, y: fn(x, y))
    assert lazy == Lazy(lambda x, y, z: fn(x, y, z))

    assert lazy != Lazy(lambda: 1)
    assert lazy != Lazy(lambda x: 1)
    assert lazy != Lazy(lambda x, y: 1)
    assert lazy != Lazy(lambda x, y, z: 1)


# Generated at 2022-06-18 01:43:06.727514
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:43:15.824382
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(1, 2) == 1
    assert Lazy(lambda a, b: a + b).get(1, 2) == 3
    assert Lazy(lambda a, b: a + b).get(1, 2) == 3
    assert Lazy(lambda a, b: a + b).get(1, 2) == 3
    assert Lazy(lambda a, b: a + b).get(1, 2) == 3
    assert Lazy(lambda a, b: a + b).get(1, 2) == 3
    assert Lazy(lambda a, b: a + b).get(1, 2) == 3
    assert Lazy(lambda a, b: a + b).get(1, 2) == 3

# Generated at 2022-06-18 01:43:26.336788
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(1) == 1
    assert Lazy(lambda x: x).get(1) == 1
    assert Lazy(lambda x: x).get(1, 2) == 1
    assert Lazy(lambda x, y: x + y).get(1, 2) == 3
    assert Lazy(lambda x, y: x + y).get(1, 2, 3) == 3
    assert Lazy(lambda x, y, z: x + y + z).get(1, 2, 3) == 6
    assert Lazy(lambda x, y, z: x + y + z).get(1, 2, 3, 4) == 6

# Generated at 2022-06-18 01:43:28.454878
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:43:30.334792
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn():
        return 'test'

    lazy = Lazy(test_fn)
    assert lazy.get() == 'test'



# Generated at 2022-06-18 01:43:34.991836
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:43:38.427057
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn():
        return 'test'

    lazy = Lazy(test_fn)

    assert lazy.get() == 'test'
    assert lazy.get() == 'test'
    assert lazy.is_evaluated



# Generated at 2022-06-18 01:43:42.098227
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(1) == 2
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(2) == 3
    assert Lazy(lambda x: x).map(lambda x: x + 1).get(3) == 4


# Generated at 2022-06-18 01:43:52.935924
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def add_two(x):
        return x + 2

    def multiply_by_three(x):
        return x * 3

    def multiply_by_four(x):
        return x * 4

    def multiply_by_five(x):
        return x * 5

    def multiply_by_six(x):
        return x * 6

    def multiply_by_seven(x):
        return x * 7

    def multiply_by_eight(x):
        return x * 8

    def multiply_by_nine(x):
        return x * 9

    def multiply_by_ten(x):
        return x * 10


# Generated at 2022-06-18 01:44:06.284734
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x * 2

    def fn3(x):
        return x - 1

    def fn4(x):
        return x / 2

    def fn5(x):
        return x + 2

    def fn6(x):
        return x * 3

    def fn7(x):
        return x - 2

    def fn8(x):
        return x / 3

    def fn9(x):
        return x + 3

    def fn10(x):
        return x * 4


# Generated at 2022-06-18 01:44:14.572351
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def test_function(value):
        return Lazy(lambda: value)

    assert Lazy(lambda: 1).bind(test_function) == Lazy(lambda: 1)
    assert Lazy(lambda: 2).bind(test_function) == Lazy(lambda: 2)
    assert Lazy(lambda: 3).bind(test_function) == Lazy(lambda: 3)
    assert Lazy(lambda: 4).bind(test_function) == Lazy(lambda: 4)
    assert Lazy(lambda: 5).bind(test_function) == Lazy(lambda: 5)



# Generated at 2022-06-18 01:44:24.276037
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()

# Generated at 2022-06-18 01:44:29.531412
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn_a():
        return 'a'

    def fn_b():
        return 'b'

    assert Lazy(fn_a) == Lazy(fn_a)
    assert Lazy(fn_a) != Lazy(fn_b)
    assert Lazy(fn_a) != 'a'
    assert Lazy(fn_a) != None



# Generated at 2022-06-18 01:44:31.969983
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(f).get() == 2



# Generated at 2022-06-18 01:44:40.761165
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:44:45.299626
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy1 == lazy2
    assert lazy1 != 1
    assert lazy1 != Lazy(lambda: 2)



# Generated at 2022-06-18 01:44:50.068417
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Try.of(fn)


# Generated at 2022-06-18 01:44:54.179235
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(a):
        return a + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(2) == 3


# Generated at 2022-06-18 01:45:04.813871
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_2(x):
        return x + 2

    def add_3(x):
        return x + 3

    def add_4(x):
        return x + 4

    def add_5(x):
        return x + 5

    def add_6(x):
        return x + 6

    def add_7(x):
        return x + 7

    def add_8(x):
        return x + 8

    def add_9(x):
        return x + 9

    def add_10(x):
        return

# Generated at 2022-06-18 01:45:22.013460
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:45:32.677867
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:45:43.420295
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:45:51.519042
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right

    def add(x):
        return x + 1

    def add_to_box(x):
        return Box(x + 1)

    def add_to_either(x):
        return Right(x + 1)

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_to_box)).get() == Box(2)
    assert Lazy.of(1).ap(Lazy.of(add_to_either)).get() == Right(2)


# Generated at 2022-06-18 01:45:58.755503
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))


# Generated at 2022-06-18 01:46:10.316818
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(1) == 1
    assert Lazy(lambda x: x).get(1) == 1
    assert Lazy(lambda x, y: x + y).get(1, 2) == 3
    assert Lazy(lambda x, y, z: x + y + z).get(1, 2, 3) == 6
    assert Lazy(lambda x, y, z, a: x + y + z + a).get(1, 2, 3, 4) == 10
    assert Lazy(lambda x, y, z, a, b: x + y + z + a + b).get(1, 2, 3, 4, 5) == 15

# Generated at 2022-06-18 01:46:14.632544
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3


# Generated at 2022-06-18 01:46:23.680076
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_fn(x):
        return x

    assert Lazy(test_fn) == Lazy(test_fn)
    assert Lazy(test_fn) != Lazy(lambda x: x)
    assert Lazy(test_fn) != Lazy(test_fn).get()
    assert Lazy(test_fn) != Lazy(test_fn).map(lambda x: x)
    assert Lazy(test_fn) != Lazy(test_fn).ap(Lazy(lambda x: x))
    assert Lazy(test_fn) != Lazy(test_fn).bind(lambda x: Lazy(lambda x: x))
    assert Lazy(test_fn) != Lazy(test_fn).get()
    assert Lazy(test_fn) != Lazy(test_fn).to_box()
    assert L

# Generated at 2022-06-18 01:46:24.996044
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1


# Generated at 2022-06-18 01:46:35.686731
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).get()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()

# Generated at 2022-06-18 01:47:00.673222
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).is_evaluated is True
    assert Lazy.of(1).map(lambda x: x + 1).value == 2
    assert Lazy.of(1).map(lambda x: x + 1).constructor_fn(1) == 2
    assert Lazy.of(1).map(lambda x: x + 1).constructor_fn(2) == 2
    assert Lazy.of(1).map(lambda x: x + 1).constructor_fn(3) == 2


# Generated at 2022-06-18 01:47:05.033848
# Unit test for method get of class Lazy
def test_Lazy_get():
    def f(x):
        return x + 1

    lazy = Lazy(f)
    assert lazy.get(1) == 2
    assert lazy.is_evaluated
    assert lazy.get(1) == 2
    assert lazy.is_evaluated


# Generated at 2022-06-18 01:47:08.830498
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:47:15.758519
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:47:22.766286
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value):
        return Lazy.of(value)

    assert Lazy.of(1).bind(test_fn) == Lazy.of(1)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(3)


# Generated at 2022-06-18 01:47:29.220977
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_function(value):
        return Lazy(lambda: value + 1)

    assert Lazy.of(1).bind(test_function).get() == 2
    assert Lazy.of(1).bind(test_function).to_box().get() == 2
    assert Lazy.of(1).bind(test_function).to_either().get() == 2
    assert Lazy.of(1).bind(test_function).to_maybe().get() == 2
    assert Lazy.of(1).bind(test_function).to_try().get() == 2

# Generated at 2022-06-18 01:47:40.426684
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:47:45.673181
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)

    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(2) == 3
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3


# Generated at 2022-06-18 01:47:55.430913
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:48:07.210836
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).get()

# Generated at 2022-06-18 01:48:46.427114
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy == lazy2

    lazy.get()
    lazy2.get()

    assert lazy == lazy2

    lazy3 = Lazy(lambda: 2)

    assert lazy != lazy3

    lazy3.get()

    assert lazy != lazy3

    lazy4 = Lazy(fn)
    lazy4.get()

    assert lazy == lazy4



# Generated at 2022-06-18 01:48:54.924452
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_ap(lazy, applicative):
        assert lazy.ap(applicative) == Lazy.of(lazy.get()).ap(applicative)

    test_ap(Lazy.of(1), Lazy.of(lambda x: x + 1))
    test_ap(Lazy.of(1), Box(lambda x: x + 1))
    test_ap(Lazy.of(1), Right(lambda x: x + 1))
    test_ap(Lazy.of(1), Maybe.just(lambda x: x + 1))

# Generated at 2022-06-18 01:49:05.869614
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:49:12.542081
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x / 2).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x / 2).map(lambda x: x - 1).get() == 1

# Generated at 2022-06-18 01:49:22.839571
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(lambda x, y: x + y)
    assert Lazy(fn) != Lazy(lambda x, y, z: x + y + z)
    assert Lazy(fn) != Lazy(lambda x, y, z, t: x + y + z + t)
    assert Lazy(fn) != Lazy(lambda x, y, z, t, u: x + y + z + t + u)

# Generated at 2022-06-18 01:49:28.658183
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    assert Lazy.of(1).map(add).map(mul).get() == 4
    assert Lazy.of(1).map(add).map(mul).map(add).get() == 5
    assert Lazy.of(1).map(add).map(mul).map(add).map(mul).get() == 10


# Generated at 2022-06-18 01:49:31.517258
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try

    def fn(value):
        return Try.of(lambda: value + 1)

    assert Lazy.of(1).bind(fn).get() == 2



# Generated at 2022-06-18 01:49:37.640824
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:49:48.717605
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:49:57.557313
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   