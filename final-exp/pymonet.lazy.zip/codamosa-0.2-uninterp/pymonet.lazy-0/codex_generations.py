

# Generated at 2022-06-18 01:40:21.622714
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)


# Generated at 2022-06-18 01:40:23.688113
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).bind(fn).get() == 3
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).get() == 4



# Generated at 2022-06-18 01:40:26.934398
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    assert Lazy(add_one).map(add_two).get(1) == 4
    assert Lazy(add_one).map(add_two).get(2) == 5
    assert Lazy(add_one).map(add_two).get(3) == 6


# Generated at 2022-06-18 01:40:33.991619
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).ap(Lazy.of(lambda x: x + 1)).get() == 2


# Generated at 2022-06-18 01:40:36.830268
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:40:46.729704
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:40:55.010999
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 2)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 2)).bind(lambda x: Lazy.of(x + 3)).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get

# Generated at 2022-06-18 01:40:58.588146
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)

    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(3) == 4



# Generated at 2022-06-18 01:41:10.832769
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:41:18.134699
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x))
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is False
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1)) is False
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is False
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is False
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is False
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is False
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x)) is False

# Generated at 2022-06-18 01:41:33.836473
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: 1.0)

# Generated at 2022-06-18 01:41:41.786051
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function(x):
        return x + 1

    lazy = Lazy(test_function)
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(3) == 4
    assert lazy.get(4) == 5
    assert lazy.get(5) == 6
    assert lazy.get(6) == 7
    assert lazy.get(7) == 8
    assert lazy.get(8) == 9
    assert lazy.get(9) == 10
    assert lazy.get(10) == 11


# Generated at 2022-06-18 01:41:51.524477
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:41:58.471174
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    def fn3(x):
        return x + 3

    def fn4(x):
        return x + 4

    def fn5(x):
        return x + 5

    def fn6(x):
        return x + 6

    def fn7(x):
        return x + 7

    def fn8(x):
        return x + 8

    def fn9(x):
        return x + 9

    def fn10(x):
        return x + 10


# Generated at 2022-06-18 01:42:08.917393
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(1) == 1
    assert Lazy(lambda: 1).get(1, 2) == 1
    assert Lazy(lambda: 1).get(1, 2, 3) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:42:10.965412
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:42:15.148446
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    assert Lazy.of(1).ap(Lazy.of(add)).get() == 2
    assert Lazy.of(1).ap(Lazy.of(mul)).get() == 2


# Generated at 2022-06-18 01:42:22.851403
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:42:32.727054
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8

    def add_nine(a):
        return a + 9

    def add_ten(a):
        return a + 10


# Generated at 2022-06-18 01:42:43.023107
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:42:54.607491
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    assert Lazy.of(add).ap(Box(1)).ap(Box(2)).get() == 3
    assert Lazy.of(add).ap(Maybe.just(1)).ap(Maybe.just(2)).get() == 3
    assert Lazy.of(add).ap(Lazy.of(1)).ap(Lazy.of(2)).get() == 3

# Generated at 2022-06-18 01:42:57.063887
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(a, b):
        return a + b

    assert Lazy(add).get(1, 2) == 3
    assert Lazy(add).get(1, 2) == 3


# Generated at 2022-06-18 01:43:08.723155
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def divide_by_two(x):
        return x / 2

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def multiply_by_three(x):
        return x * 3

    def divide_by_three(x):
        return x / 3

    def add_four(x):
        return x + 4

    def multiply_by_four(x):
        return x * 4

    def divide_by_four(x):
        return x / 4

    def add_five(x):
        return x + 5

    def multiply_by_five(x):
        return x * 5


# Generated at 2022-06-18 01:43:13.610228
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:43:16.761307
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def add(a, b):
        return a + b

    lazy = Lazy(lambda: 1)
    box = Box(add)

    assert lazy.ap(box).get() == 2

# Generated at 2022-06-18 01:43:27.246619
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10


# Generated at 2022-06-18 01:43:31.581815
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:43:34.625813
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try

    def fn(x):
        return Try(lambda: x + 1)

    lazy = Lazy(lambda: 1)
    assert lazy.bind(fn).get() == 2



# Generated at 2022-06-18 01:43:43.012053
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:43:48.669794
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:43:55.354503
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(2) == 3


# Generated at 2022-06-18 01:43:58.985106
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def fn(value):
        return Box(value + 1)

    lazy = Lazy.of(1)
    assert lazy.bind(fn) == Lazy.of(2)



# Generated at 2022-06-18 01:44:07.478495
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_function(value):
        return value + 1

    def test_function_with_error(value):
        raise ValueError('test error')

    assert Lazy.of(1).ap(Lazy.of(test_function)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(test_function_with_error)) == Lazy.of(1)
    assert Lazy.of(1).ap(Box.of(test_function)) == Lazy.of(2)

# Generated at 2022-06-18 01:44:18.839476
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value):
        return Lazy(lambda: value)

    assert Lazy.of(1).bind(test_fn).get() == 1
    assert Lazy.of(1).bind(test_fn).to_box().get() == 1
    assert Lazy.of(1).bind(test_fn).to_either().get() == 1
    assert Lazy.of(1).bind(test_fn).to_maybe().get() == 1
    assert Lazy.of(1).bind(test_fn).to_try().get() == 1

# Generated at 2022-06-18 01:44:26.796765
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1.0)
    assert Lazy.of(1) != Lazy.of('1')
    assert Lazy.of(1) != Lazy.of(True)
    assert Lazy.of(1) != Lazy.of(None)
    assert Lazy.of(1) != Lazy.of([1])
    assert Lazy.of(1) != Lazy.of((1,))
    assert Lazy.of(1) != Lazy.of({1})
    assert Lazy.of(1) != Lazy.of({'1': 1})

# Generated at 2022-06-18 01:44:37.785866
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).to_box().get() == 2
    assert Lazy(lambda: 1).bind(fn).to_either().get() == 2
    assert Lazy(lambda: 1).bind(fn).to_maybe().get() == 2
    assert Lazy(lambda: 1).bind(fn).to_try().get() == 2
    assert Lazy(lambda: 1).bind(fn).to_validation().get() == 2

    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x / 0)).to_try

# Generated at 2022-06-18 01:44:42.877216
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    lazy_one = Lazy.of(1)
    lazy_two = Lazy.of(2)
    lazy_three = Lazy.of(3)

    assert lazy_one.bind(lambda x: lazy_two.bind(lambda y: lazy_three.bind(lambda z: Lazy.of(add_one(x) + add_two(y) + add_three(z))))) == Lazy.of(9)



# Generated at 2022-06-18 01:44:48.259680
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 4


# Generated at 2022-06-18 01:44:58.109686
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def divide_by_two(x):
        return x / 2

    def add_two(x):
        return x + 2

    def multiply_by_three(x):
        return x * 3

    def divide_by_three(x):
        return x / 3

    def add_three(x):
        return x + 3

    def multiply_by_four(x):
        return x * 4

    def divide_by_four(x):
        return x / 4

    def add_four(x):
        return x + 4

    def multiply_by_five(x):
        return x * 5

    def divide_by_five(x):
        return x / 5


# Generated at 2022-06-18 01:45:09.549883
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    def fn(x):
        return x

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)
    lazy_3 = Lazy(fn)
    lazy_4 = Lazy(fn)
    lazy_5 = Lazy(fn)
    lazy_6 = Lazy(fn)
    lazy_7 = Lazy(fn)
    lazy_8 = Lazy(fn)
    lazy_9 = Lazy(fn)
    lazy_10 = Lazy(fn)
    lazy_11 = Lazy(fn)
    lazy_12 = Lazy(fn)
    lazy_13 = Lazy(fn)
    lazy_14 = Lazy(fn)
    lazy_15 = Lazy(fn)
    lazy_16 = Lazy(fn)

# Generated at 2022-06-18 01:45:26.111336
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).get()
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()

# Generated at 2022-06-18 01:45:29.026933
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a, b):
        return a + b

    def multiply(a, b):
        return a * b

    def add_multiply(a, b, c):
        return add(multiply(a, b), c)

    assert Lazy.of(add).ap(Lazy.of(multiply)).ap(Lazy.of(1)).ap(Lazy.of(2)).ap(Lazy.of(3)).get() == add_multiply(1, 2, 3)



# Generated at 2022-06-18 01:45:40.141270
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:45:41.787168
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2


# Generated at 2022-06-18 01:45:51.564142
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function(x):
        return x + 1

    lazy = Lazy(test_function)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1)

# Generated at 2022-06-18 01:45:56.286543
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:46:07.842515
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).to_box().get() == 2
    assert Lazy(lambda: 1).bind(fn).to_either().get() == 2
    assert Lazy(lambda: 1).bind(fn).to_maybe().get() == 2
    assert Lazy(lambda: 1).bind(fn).to_try().get() == 2
    assert Lazy(lambda: 1).bind(fn).to_validation().get

# Generated at 2022-06-18 01:46:16.867827
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return lambda y: x + y

    def multiply(x):
        return lambda y: x * y

    assert Lazy.of(add(1)).ap(Lazy.of(2)) == Lazy.of(3)
    assert Lazy.of(add(1)).ap(Lazy.of(2)).ap(Lazy.of(3)) == Lazy.of(6)
    assert Lazy.of(add(1)).ap(Lazy.of(2)).ap(Lazy.of(3)).ap(Lazy.of(4)) == Lazy.of(10)

# Generated at 2022-06-18 01:46:25.277299
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
   

# Generated at 2022-06-18 01:46:36.012836
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:46:50.864607
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    lazy_add = Lazy(add)
    lazy_add_one = Lazy(add_one)

    assert lazy_add.ap(Box(1)).get(2) == 3
    assert lazy_add.ap(Maybe.just(1)).get(2) == 3
    assert lazy_add_one.ap(Box(1)).get() == 2
    assert lazy_add_one.ap(Maybe.just(1)).get() == 2



# Generated at 2022-06-18 01:46:56.502085
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    lazy = Lazy.of(1)
    assert lazy.bind(add_one) == Lazy.of(2)

    def add_one_and_two(x):
        return Lazy.of(x + 1)

    assert lazy.bind(add_one_and_two).bind(add_one) == Lazy.of(3)

    def add_one_and_two_and_three(x):
        return Lazy.of(x + 1)

    assert lazy.bind(add_one_and_two_and_three).bind(add_one_and_two).bind(add_one) == Lazy.of(4)



# Generated at 2022-06-18 01:47:06.377629
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_2(x):
        return x + 2

    def add_3(x):
        return x + 3

    def add_4(x):
        return x + 4

    def add_5(x):
        return x + 5

    def add_6(x):
        return x + 6

    def add_7(x):
        return x + 7

    def add_8(x):
        return x + 8

    def add_9(x):
        return x + 9

    def add_10(x):
        return

# Generated at 2022-06-18 01:47:08.062438
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(a):
        return a + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2



# Generated at 2022-06-18 01:47:11.616830
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4

# Generated at 2022-06-18 01:47:17.175373
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:47:20.896405
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4



# Generated at 2022-06-18 01:47:28.190460
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:47:39.622521
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:47:43.517447
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(a):
        return a + 1

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2


# Generated at 2022-06-18 01:47:58.058712
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)



# Generated at 2022-06-18 01:48:05.475724
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def fn(x):
        return x + 1

    lazy = Lazy.of(1)
    assert lazy.ap(Box.of(fn)) == Lazy.of(2)
    assert lazy.ap(Maybe.just(fn)) == Lazy.of(2)
    assert lazy.ap(Maybe.nothing()) == Lazy.of(1)


# Generated at 2022-06-18 01:48:12.073542
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return

# Generated at 2022-06-18 01:48:15.049068
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(value):
        return value + 1

    lazy = Lazy(lambda: 1)
    assert lazy.map(add_one).get() == 2


# Generated at 2022-06-18 01:48:19.009451
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:48:27.988946
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6


# Generated at 2022-06-18 01:48:37.158560
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:48:39.170936
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2



# Generated at 2022-06-18 01:48:44.640318
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x, y):
        return x + y

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:48:51.645816
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Functor.of(1)
    assert Lazy.of(1) != Monad.of(1)
    assert Lazy.of(1) != Applicative.of(1)



# Generated at 2022-06-18 01:49:05.078267
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:49:09.468564
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:49:15.365136
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(lambda x: x + 1).ap(Box(2)) == Box(3)
    assert Lazy.of(lambda x: x + 1).ap(Right(2)) == Right(3)
    assert Lazy.of(lambda x: x + 1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Lazy.of(lambda x: x + 1).ap(Try.of(lambda: 2)) == Try.of(lambda: 3)
    assert Lazy.of(lambda x: x + 1).ap(Validation.success(2)) == Validation.success

# Generated at 2022-06-18 01:49:25.135942
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value):
        return value + 1

    def test_fn_with_error(value):
        raise ValueError('Error')

    def test_fn_with_error_2(value):
        raise ValueError('Error')

    def test_fn_with_error_3(value):
        raise ValueError('Error')

    def test_fn_with_error_4(value):
        raise ValueError('Error')

    def test_fn_with_error_5(value):
        raise ValueError('Error')


# Generated at 2022-06-18 01:49:27.431442
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:49:35.273681
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:49:46.306862
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value):
        return Lazy(lambda: value + 1)

    assert Lazy.of(1).bind(test_fn).get() == 2
    assert Lazy.of(1).bind(test_fn).to_box().get() == 2
    assert Lazy.of(1).bind(test_fn).to_either().get() == 2
    assert Lazy.of(1).bind(test_fn).to_maybe().get() == 2
    assert Lazy.of(1).bind(test_fn).to_try().get() == 2

# Generated at 2022-06-18 01:49:55.862325
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return

# Generated at 2022-06-18 01:50:00.242513
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x):
        return lambda y: x + y

    assert Lazy.of(1).ap(Box(add(2))) == Lazy.of(3)
    assert Lazy.of(1).ap(Maybe.just(add(2))) == Lazy.of(3)


# Generated at 2022-06-18 01:50:03.417541
# Unit test for method map of class Lazy
def test_Lazy_map():
    def fn(x):
        return x + 1

    def mapper(x):
        return x * 2

    lazy = Lazy(fn)
    assert lazy.map(mapper).get(1) == 4

