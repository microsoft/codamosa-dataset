

# Generated at 2022-06-18 01:40:27.171179
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:40:39.266367
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_box(x):
        return Box(x + 1)

    def add_either(x):
        return Right(x + 1)

    def add_maybe(x):
        return Maybe.just(x + 1)

    def add_try(x):
        return Try.of(lambda: x + 1)

    def add_validation(x):
        return Validation.success(x + 1)

    def add_lazy(x):
        return Lazy.of(x + 1)


# Generated at 2022-06-18 01:40:50.482571
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: set())
    assert Lazy(fn) != Lazy(lambda: frozenset())
    assert Lazy(fn) != Lazy(lambda: 1)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: True)

# Generated at 2022-06-18 01:40:57.019503
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:41:03.488493
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1) == Lazy.of(2)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy.of(3)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy.of(4)


# Generated at 2022-06-18 01:41:05.508471
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    lazy_add = Lazy(add)
    lazy_add_one = Lazy(add_one)

    assert lazy_add.ap(lazy_add_one).get(1, 2) == 4



# Generated at 2022-06-18 01:41:11.166506
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:41:18.632279
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:41:30.182594
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(2).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(2).map(lambda x: x - 1).map(lambda x: x + 1)

# Generated at 2022-06-18 01:41:41.556411
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:41:49.044802
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1():
        return 1

    def fn2():
        return 2

    lazy1 = Lazy(fn1)
    lazy2 = Lazy(fn1)
    lazy3 = Lazy(fn2)

    assert lazy1 == lazy2
    assert lazy1 != lazy3

    assert lazy1 != 1
    assert lazy1 != None
    assert lazy1 != '1'



# Generated at 2022-06-18 01:41:57.696786
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8

    def add_nine(a):
        return a + 9

    def add_ten(a):
        return a + 10


# Generated at 2022-06-18 01:42:08.134849
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    def fn3(x):
        return x + 3

    def fn4(x):
        return x + 4

    def fn5(x):
        return x + 5

    def fn6(x):
        return x + 6

    def fn7(x):
        return x + 7

    def fn8(x):
        return x + 8

    def fn9(x):
        return x + 9

    def fn10(x):
        return x + 10


# Generated at 2022-06-18 01:42:18.458747
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:42:23.984947
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:42:33.565146
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:42:37.181669
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return 'test'

    lazy = Lazy(fn)

    assert lazy.get() == 'test'
    assert lazy.get() == 'test'
    assert lazy.is_evaluated == True


# Generated at 2022-06-18 01:42:47.452239
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1) == Lazy.of(2)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy.of(3)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy.of(4)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy.of(5)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map

# Generated at 2022-06-18 01:42:55.429529
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:43:07.129763
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(x):
        return x + 1

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1)

# Generated at 2022-06-18 01:43:17.812408
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return Lazy(lambda: value)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).to_box() == Box(1)
    assert Lazy.of(1).bind(fn).to_either() == Right(1)
    assert Lazy.of(1).bind(fn).to_maybe() == Maybe.just(1)
    assert Lazy.of(1).bind(fn).to_try() == Try.of(lambda: 1)

# Generated at 2022-06-18 01:43:28.015570
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:43:37.960096
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != L

# Generated at 2022-06-18 01:43:40.607913
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn():
        return 'test'

    lazy = Lazy(test_fn)
    assert lazy.get() == 'test'
    assert lazy.is_evaluated
    assert lazy.value == 'test'


# Generated at 2022-06-18 01:43:51.709573
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:44:01.907236
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(x):
        return x + 1

    def g(x):
        return x + 2

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(g)
    assert Lazy(f) != Lazy(f).map(lambda x: x + 1)
    assert Lazy(f) != Lazy(f).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(f) != Lazy(f).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(f) != Lazy(f).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)

# Generated at 2022-06-18 01:44:04.203223
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2



# Generated at 2022-06-18 01:44:15.148060
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map(lambda x: x).map(lambda x: x).map(lambda x: x)

# Generated at 2022-06-18 01:44:24.717942
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    assert Lazy.of(1).ap(Lazy.of(fn)).get() == 2
    assert Lazy.of(1).ap(Box(fn)).get() == 2
    assert Lazy.of(1).ap(Right(fn)).get() == 2
    assert Lazy.of(1).ap(Maybe.just(fn)).get() == 2
    assert Lazy.of(1).ap(Try.of(fn)).get() == 2
    assert Lazy.of(1).ap(Validation.success(fn)).get() == 2




# Generated at 2022-06-18 01:44:30.208096
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    def fn3(x):
        return x + 3

    def fn4(x):
        return x + 4

    def fn5(x):
        return x + 5

    def fn6(x):
        return x + 6

    def fn7(x):
        return x + 7

    def fn8(x):
        return x + 8

    def fn9(x):
        return x + 9

    def fn10(x):
        return x + 10


# Generated at 2022-06-18 01:44:39.620366
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x - 1).get() == 3



# Generated at 2022-06-18 01:44:45.022653
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:44:55.760631
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:45:00.972282
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:45:11.267881
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)

# Generated at 2022-06-18 01:45:19.324213
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def divide_by_two(x):
        return x / 2

    def add_one_and_multiply_by_two(x):
        return multiply_by_two(add_one(x))

    def divide_by_two_and_add_one(x):
        return add_one(divide_by_two(x))

    assert Lazy(add_one).bind(Lazy.of).get(1) == 2
    assert Lazy(add_one).bind(lambda x: Lazy(multiply_by_two).bind(Lazy.of)).get(1) == 4

# Generated at 2022-06-18 01:45:27.373792
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).map(lambda x: x + 1)


# Generated at 2022-06-18 01:45:38.668931
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x, y):
        return x + y

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8


# Generated at 2022-06-18 01:45:48.293850
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1(x):
        return x

    def fn2(x):
        return x

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x).ap(Lazy(fn2))
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x).ap(Lazy(fn2)).bind(lambda x: Lazy(fn2))
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x).ap(Lazy(fn2)).bind(lambda x: Lazy(fn2)).get()
    assert L

# Generated at 2022-06-18 01:45:55.113921
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).get() == 2
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).bind(lambda x: Lazy(lambda: x + 1)).get() == 3
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).bind(lambda x: Lazy(lambda: x + 1)).bind(lambda x: Lazy(lambda: x + 1)).get() == 4


# Generated at 2022-06-18 01:46:07.881177
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).map(add_two).map(add_three).get(1) == 7


# Generated at 2022-06-18 01:46:16.842020
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    assert Lazy.of(1).map(add_one).map(add_two).get() == 4
    assert Lazy.of(1).map(add_one).map(add_two).to_box().map(add_one).get() == 5
    assert Lazy.of(1).map(add_one).map(add_two).to_box().map(add_one).map(add_two).get() == 6
    assert Lazy.of(1).map(add_one).map(add_two).to_box().map(add_one).map(add_two).map(add_one).get() == 7

# Generated at 2022-06-18 01:46:23.420904
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_try import Try

    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2

    def fn_raise():
        raise Exception('test')

    lazy = Lazy(fn_raise)
    assert lazy.get() == Try.of(fn_raise)
    assert lazy.get() == Try.of(fn_raise)
    assert lazy.get() == Try.of(fn_raise)



# Generated at 2022-06-18 01:46:34.009958
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:46:38.354842
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:46:49.985793
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    def add_one(x):
        return x + 1

    assert Lazy.of(1).map(add_one).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(add_one).map(add_one).get() == 3
    assert Lazy.of(1).map(add_one).map(add_one).map(add_one).get() == 4
    assert Lazy.of(1).map(add_one).map(add_one).map(add_one).map(add_one).get() == 5

# Generated at 2022-06-18 01:46:56.436719
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:47:06.348253
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return x + 1

    def add_2(x):
        return x + 2

    def add_3(x):
        return x + 3

    def add_4(x):
        return x + 4

    def add_5(x):
        return x + 5

    def add_6(x):
        return x + 6

    def add_7(x):
        return x + 7

    def add_8(x):
        return x + 8

    def add_9(x):
        return x + 9

    def add_10(x):
        return x + 10

    def add_11(x):
        return x + 11

    def add_12(x):
        return x + 12

    def add_13(x):
        return x + 13


# Generated at 2022-06-18 01:47:13.695163
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x, y):
        return x + y

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8


# Generated at 2022-06-18 01:47:17.551167
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function(a):
        return a + 1

    lazy = Lazy(test_function)

    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.is_evaluated
    assert lazy.value == 2


# Generated at 2022-06-18 01:47:42.998043
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Lazy.of(lambda x: x + 1).ap(Box(2)) == Lazy.of(3)
    assert Lazy.of(lambda x: x + 1).ap(Box(2)).get() == 3
    assert Lazy.of(lambda x: x + 1).ap(Box(2)).to_box().get() == 3
    assert Lazy.of(lambda x: x + 1).ap(Box(2)).to_maybe().get() == 3
    assert Lazy.of(lambda x: x + 1).ap(Box(2)).to_either().get() == 3
    assert Lazy.of(lambda x: x + 1).ap(Box(2)).to_try().get() == 3

# Generated at 2022-06-18 01:47:53.411184
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_to_box(a):
        return Box(add(a, 10))

    def add_to_either(a):
        return Right(add(a, 10))

    def add_to_maybe(a):
        return Maybe.just(add(a, 10))

    def add_to_try(a):
        return Try.of(add, a, 10)

    def add_to_validation(a):
        return Validation.success(add(a, 10))


# Generated at 2022-06-18 01:48:00.916052
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: 'a')
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: 1.0)

# Generated at 2022-06-18 01:48:08.416706
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).map(lambda x: x + 1)


# Generated at 2022-06-18 01:48:19.519835
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value):
        return Lazy.of(value)

    assert Lazy.of(1).bind(test_fn) == Lazy.of(1)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(3)

# Generated at 2022-06-18 01:48:22.885350
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))


# Generated at 2022-06-18 01:48:31.430370
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:48:37.885442
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: 1.1)
    assert Lazy(fn) != Lazy(lambda: 1.2)

# Generated at 2022-06-18 01:48:43.802207
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)

# Generated at 2022-06-18 01:48:46.339738
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.maybe import Maybe

    def fn(value):
        return Maybe.just(value + 1)

    assert Lazy.of(1).bind(fn).get() == 2

# Generated at 2022-06-18 01:49:22.341606
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return 1

    lazy = Lazy(fn)

    assert lazy.get() == 1
    assert lazy.get() == 1
    assert lazy.is_evaluated
    assert lazy.value == 1



# Generated at 2022-06-18 01:49:27.477320
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy(lambda: x + 1)

    def add_two(x):
        return Lazy(lambda: x + 2)

    assert Lazy(lambda: 1).bind(add_one).bind(add_two).get() == 4



# Generated at 2022-06-18 01:49:35.331133
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def test_function(x):
        return x

    def test_function_2(x):
        return x

    assert Lazy(test_function) == Lazy(test_function)
    assert Lazy(test_function) != Lazy(test_function_2)
    assert Lazy(test_function) != Lazy(test_function).get()
    assert Lazy(test_function) != Lazy(test_function).get()
    assert Lazy(test_function) != Lazy(test_function).get()
    assert Lazy(test_function) != Lazy(test_function).get()
    assert Lazy(test_function) != Lazy(test_function).get()
    assert Lazy(test_function) != Lazy(test_function).get()

# Generated at 2022-06-18 01:49:46.343239
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1(x):
        return x

    def fn2(x):
        return x

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x).map(lambda x: x).map(lambda x: x).map(lambda x: x)

# Generated at 2022-06-18 01:49:51.862114
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a):
        return a + 1

    def add_two(a):
        return a + 2

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_two)) == Lazy.of(3)
    assert Lazy.of(1).ap(Box.of(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Box.of(add_two)) == Lazy.of(3)
    assert Lazy.of(1).ap(Maybe.just(add)) == Lazy.of(2)

# Generated at 2022-06-18 01:49:59.997712
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy.of(x)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).get() == 1
    assert Lazy.of(1).bind(fn).to_box() == Box(1)
    assert Lazy.of(1).bind(fn).to_either() == Right(1)
    assert Lazy.of(1).bind(fn).to_maybe() == Maybe.just(1)
    assert Lazy.of(1).bind(fn).to_try

# Generated at 2022-06-18 01:50:09.200728
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn).map(lambda x: x + 1) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1)

# Generated at 2022-06-18 01:50:14.792167
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.monad_try import Try

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8
