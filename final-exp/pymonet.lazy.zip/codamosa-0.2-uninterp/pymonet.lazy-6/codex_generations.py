

# Generated at 2022-06-18 01:40:21.274082
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 2).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 2).map(lambda x: x + 3).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 2).map(lambda x: x + 3).map(lambda x: x + 4).get() == 5

# Generated at 2022-06-18 01:40:25.516880
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:40:36.921062
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)




# Generated at 2022-06-18 01:40:42.712569
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def add_one_and_multiply_by_two(x):
        return multiply_by_two(add_one(x))

    assert Lazy.of(1).map(add_one).map(multiply_by_two).get() == add_one_and_multiply_by_two(1)



# Generated at 2022-06-18 01:40:45.705990
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7


# Generated at 2022-06-18 01:40:54.752190
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Box(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Maybe.just(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Try.of(lambda: 1)) == Lazy.of(2)

# Generated at 2022-06-18 01:41:01.384218
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))


# Generated at 2022-06-18 01:41:09.688841
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).map(lambda x: x + 1)



# Generated at 2022-06-18 01:41:12.593406
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    lazy = Lazy(lambda: 1)
    assert lazy.bind(fn).get() == 2



# Generated at 2022-06-18 01:41:20.131772
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(fn)

    assert lazy == lazy2
    assert lazy2 == lazy3
    assert lazy == lazy3

    lazy2.get()
    lazy3.get()

    assert lazy == lazy2
    assert lazy2 == lazy3
    assert lazy == lazy3

    lazy2.get()
    lazy3.get()

    assert lazy == lazy2
    assert lazy2 == lazy3
    assert lazy == lazy3

    def fn2():
        return 2

    lazy2 = Lazy(fn2)
    lazy3 = Lazy(fn2)

    assert lazy != lazy2
    assert lazy2 != lazy3
    assert lazy != lazy3

    lazy2.get()
    lazy3.get()

# Generated at 2022-06-18 01:41:31.602045
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5


# Generated at 2022-06-18 01:41:42.340140
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).to_box() == Box(2)
    assert Lazy.of(1).bind(fn).to_either() == Right(2)
    assert Lazy.of(1).bind(fn).to_maybe() == Maybe.just(2)
    assert Lazy.of(1).bind(fn).to_try() == Try.of(lambda: 2)

# Generated at 2022-06-18 01:41:51.936340
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:41:53.120716
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2



# Generated at 2022-06-18 01:42:03.192845
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(2).get() == 2
    assert Lazy.of(3).get() == 3
    assert Lazy.of(4).get() == 4
    assert Lazy.of(5).get() == 5
    assert Lazy.of(6).get() == 6
    assert Lazy.of(7).get() == 7
    assert Lazy.of(8).get() == 8
    assert Lazy.of(9).get() == 9
    assert Lazy.of(10).get() == 10
    assert Lazy.of(11).get() == 11
    assert Lazy.of(12).get() == 12
    assert Lazy.of(13).get() == 13
    assert Lazy.of(14).get() == 14
    assert L

# Generated at 2022-06-18 01:42:08.917665
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4


# Generated at 2022-06-18 01:42:10.614980
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return 'test'

    assert Lazy(fn).get() == 'test'



# Generated at 2022-06-18 01:42:19.980101
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    def fn2():
        return 2

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).get()
    assert Lazy(fn) != Lazy(fn).to_box()
    assert Lazy(fn) != Lazy(fn).to_either()
    assert Lazy(fn) != Lazy(fn).to_maybe()
    assert Lazy(fn) != Lazy(fn).to_try()
    assert Lazy(fn) != Lazy(fn).to_validation()


# Generated at 2022-06-18 01:42:24.828258
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).map(add_two).map(add_three).get(1) == 7


# Generated at 2022-06-18 01:42:28.635305
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box

    def f(x):
        return Box(x + 1)

    def g(x):
        return Box(x * 2)

    assert Lazy.of(1).bind(f).bind(g).get() == 4


# Generated at 2022-06-18 01:42:43.101582
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x).map(lambda x: x)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x).map(lambda x: x).map(lambda x: x)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x).map(lambda x: x).map(lambda x: x).map(lambda x: x)

# Generated at 2022-06-18 01:42:52.975719
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:42:59.921758
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:43:06.200269
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f1(x):
        return x

    def f2(x):
        return x

    assert Lazy(f1) == Lazy(f1)
    assert Lazy(f1) != Lazy(f2)
    assert Lazy(f1) != Lazy.of(1)
    assert Lazy(f1) != 1
    assert Lazy(f1) != None


# Generated at 2022-06-18 01:43:15.449720
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:43:22.867027
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def add(x):
        return lambda y: x + y

    assert Lazy.of(1).ap(Box(add(2))) == Lazy.of(3)
    assert Lazy.of(1).ap(Maybe.just(add(2))) == Lazy.of(3)
    assert Lazy.of(1).ap(Lazy.of(add(2))) == Lazy.of(3)



# Generated at 2022-06-18 01:43:31.141389
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(*args):
        return args

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda *args: args)
    assert Lazy(fn) != Lazy(lambda *args: args[0])
    assert Lazy(fn) != Lazy(lambda *args: args[1])
    assert Lazy(fn) != Lazy(lambda *args: args[2])
    assert Lazy(fn) != Lazy(lambda *args: args[3])
    assert Lazy(fn) != Lazy(lambda *args: args[4])
    assert Lazy(fn) != Lazy(lambda *args: args[5])
    assert Lazy(fn) != Lazy(lambda *args: args[6])

# Generated at 2022-06-18 01:43:40.505767
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: 'a')
    assert Lazy(fn) != Lazy(lambda: 'b')
    assert Lazy(fn) != Lazy(lambda: 'c')

# Generated at 2022-06-18 01:43:45.465457
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:43:56.531250
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(lambda x: x).ap(Lazy.of(1)) == Lazy.of(1)
    assert Lazy.of(lambda x: x).ap(Lazy.of(1)).to_box() == Box(1)
    assert Lazy.of(lambda x: x).ap(Lazy.of(1)).to_maybe() == Maybe.just(1)
    assert Lazy.of(lambda x: x).ap(Lazy.of(1)).to_try() == Try.of(lambda x: x, 1)

# Generated at 2022-06-18 01:44:15.194101
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)
    lazy_3 = Lazy(fn)
    lazy_4 = Lazy(fn)
    lazy_5 = Lazy(fn)

    lazy_1._compute_value(1)
    lazy_2._compute_value(1)
    lazy_3._compute_value(2)
    lazy_4._compute_value(2)
    lazy_5._compute_value(2)

    assert lazy_1 == lazy_1
    assert lazy_1 == lazy_2
    assert lazy_1 != lazy_3
    assert lazy_3 == lazy_4
    assert lazy_3 == lazy_5
    assert lazy_1 != lazy_5



# Generated at 2022-06-18 01:44:24.753666
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x + 1) == Lazy(lambda x: x + 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 2)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda x: x + 1) != Lazy(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert L

# Generated at 2022-06-18 01:44:35.438256
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn_raise():
        raise ValueError('error')

    def fn_error(x):
        return x + 1

    def fn_error_raise():
        raise ValueError('error')

    def fn_error_raise_2():
        raise ValueError('error')

    def fn_error_raise_3():
        raise ValueError('error')

    def fn_error_raise_4():
        raise ValueError('error')

    def fn_error_raise_5():
        raise ValueError('error')


# Generated at 2022-06-18 01:44:42.440369
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try

    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    lazy = Lazy.of(fn)
    assert lazy.ap(Lazy.of(fn2)).get() == 4

    lazy = Lazy.of(fn)
    assert lazy.ap(Try.of(fn2)).get() == 4

    lazy = Lazy.of(fn)
    assert lazy.ap(Try.of(fn2)).to_lazy().get() == 4

    lazy = Lazy.of(fn)
    assert lazy.ap(Try.of(fn2)).to_lazy().to_try().get() == 4

    lazy = Lazy.of(fn)
    assert lazy.ap(Try.of(fn2)).to_lazy

# Generated at 2022-06-18 01:44:49.893799
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(x):
        return x + 1

    def test_fn2(x):
        return x + 2

    def test_fn3(x):
        return x + 3

    def test_fn4(x):
        return x + 4

    def test_fn5(x):
        return x + 5

    def test_fn6(x):
        return x + 6

    def test_fn7(x):
        return x + 7

    def test_fn8(x):
        return x + 8

    def test_fn9(x):
        return x + 9

   

# Generated at 2022-06-18 01:45:00.197059
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box

    assert Lazy.of(lambda x: x + 1).ap(Box(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Box(2)) == Lazy.of(3)
    assert Lazy.of(lambda x: x + 1).ap(Box(3)) == Lazy.of(4)
    assert Lazy.of(lambda x: x + 1).ap(Box(4)) == Lazy.of(5)
    assert Lazy.of(lambda x: x + 1).ap(Box(5)) == Lazy.of(6)
    assert Lazy.of(lambda x: x + 1).ap(Box(6)) == Lazy.of(7)
    assert Lazy.of(lambda x: x + 1).ap

# Generated at 2022-06-18 01:45:11.079283
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).get()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()

# Generated at 2022-06-18 01:45:15.812403
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(2).map(lambda x: x + 1).get() == 3
    assert Lazy.of(2).map(lambda x: x + 1).map(lambda x: x * 2).get() == 6
    assert Lazy.of(2).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x / 2).get() == 3


# Generated at 2022-06-18 01:45:24.271862
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    assert Lazy.of(add).ap(Box(1)).ap(Box(2)).get() == 3
    assert Lazy.of(add_one).ap(Maybe.just(1)).get() == 2
    assert Lazy.of(add_two).ap(Maybe.nothing()).get() == None



# Generated at 2022-06-18 01:45:35.553036
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def test_fn(*args):
        return args

    lazy_1 = Lazy(test_fn)
    lazy_2 = Lazy(test_fn)

    assert lazy_1 == lazy_2

    lazy_1._compute_value(1, 2, 3)
    lazy_2._compute_value(1, 2, 3)

    assert lazy_1 == lazy_2

    lazy_1 = Lazy(test_fn)
    lazy_2 = Lazy(lambda: 1)

    assert lazy_1 != lazy_2

    lazy_1._compute_value(1, 2, 3)
    lazy_2._compute_value(1, 2, 3)

    assert lazy_1 != lazy_2

    lazy

# Generated at 2022-06-18 01:45:45.840450
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2

# Generated at 2022-06-18 01:45:50.076931
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(a):
        return a

    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(2) == 2
    assert Lazy(fn).get(2) == 2


# Generated at 2022-06-18 01:45:56.603024
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5


# Generated at 2022-06-18 01:46:08.246540
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:46:17.081320
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def test_eq(lazy1, lazy2):
        assert lazy1 == lazy2

    def test_not_eq(lazy1, lazy2):
        assert lazy1 != lazy2

    def test_eq_with_different_types(lazy1, lazy2):
        assert lazy1 != lazy2

    def test_eq_with_different_values(lazy1, lazy2):
        assert lazy1 != lazy2

    def test_eq_with_different_constructor_fn(lazy1, lazy2):
        assert lazy1 != lazy2

    def test_eq_with_different_is_evaluated(lazy1, lazy2):
        assert lazy1 != lazy2


# Generated at 2022-06-18 01:46:25.411241
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy.of(x + 1)

    def fn2(x):
        return Lazy.of(x + 2)

    def fn3(x):
        return Lazy.of(x + 3)

    def fn4(x):
        return Lazy.of(x + 4)

    def fn5(x):
        return Lazy.of(x + 5)

    def fn6(x):
        return Lazy.of(x + 6)

    def fn7(x):
        return Lazy.of(x + 7)


# Generated at 2022-06-18 01:46:36.077879
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).bind(fn).get() == 3
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:46:46.883542
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != L

# Generated at 2022-06-18 01:46:55.237049
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:47:05.387272
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:47:21.799909
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:47:28.745811
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:47:31.846581
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(value):
        return Lazy.of(value + 1)

    lazy = Lazy.of(1)
    assert lazy.bind(fn).get() == 2



# Generated at 2022-06-18 01:47:42.194749
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1).map(lambda x: x + 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:47:52.933700
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:47:56.611193
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return 'test'

    lazy = Lazy(fn)
    assert lazy.get() == 'test'
    assert lazy.get() == 'test'
    assert lazy.is_evaluated


# Generated at 2022-06-18 01:48:07.844235
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def add(x, y):
        return x + y

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11


# Generated at 2022-06-18 01:48:19.171360
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:48:29.570756
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for method bind of class Lazy
    """
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value):
        return Lazy.of(value)

    assert Lazy.of(1).bind(test_fn) == Lazy.of(1)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(3)

# Generated at 2022-06-18 01:48:36.787624
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(1) == 1
    assert Lazy(lambda x: x).get(1) == 1
    assert Lazy(lambda x: x).get(1, 2) == 1
    assert Lazy(lambda x, y: x).get(1, 2) == 1
    assert Lazy(lambda x, y: y).get(1, 2) == 2
    assert Lazy(lambda x, y: x + y).get(1, 2) == 3
    assert Lazy(lambda x, y: x + y).get(1, 2, 3) == 3
    assert Lazy(lambda x, y, z: x + y).get(1, 2, 3) == 3

# Generated at 2022-06-18 01:48:51.049493
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:48:56.909818
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:49:03.877841
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    lazy = Lazy(lambda: 1)
    assert lazy.bind(lambda x: Lazy(lambda: add_one(x))).bind(lambda x: Lazy(lambda: add_two(x))).bind(
        lambda x: Lazy(lambda: add_three(x))).get() == 7



# Generated at 2022-06-18 01:49:11.865966
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:49:20.863573
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    assert lazy1 == lazy2

    lazy1.get()
    lazy2.get()
    assert lazy1 == lazy2

    lazy1.get()
    lazy2.get()
    assert lazy1 == lazy2

    def fn2():
        return 2

    lazy3 = Lazy(fn2)
    assert lazy1 != lazy3

    lazy3.get()
    assert lazy1 != lazy3

    lazy1.get()
    assert lazy1 != lazy3

    lazy3.get()
    assert lazy1 != lazy3



# Generated at 2022-06-18 01:49:29.245598
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:49:36.253745
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x * 2

    def fn3(x):
        return x / 2

    def fn4(x):
        return x - 1

    def fn5(x):
        return x + 2

    def fn6(x):
        return x * 3

    def fn7(x):
        return x / 3

    def fn8(x):
        return x - 2

    def fn9(x):
        return x + 3

    def fn10(x):
        return x * 4

    def fn11(x):
        return x / 4

   

# Generated at 2022-06-18 01:49:46.963458
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:49:56.291849
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_to_box(a):
        return Box(add(a, 1))

    def add_to_either(a):
        return Right(add(a, 1))

    def add_to_maybe(a):
        return Maybe.just(add(a, 1))

    def add_to_try(a):
        return Try.of(add, a, 1)

    def add_to_validation(a):
        return Validation.success(add(a, 1))


# Generated at 2022-06-18 01:50:00.337321
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:50:13.733223
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function(value):
        return value

    lazy = Lazy(test_function)
    assert lazy.get(1) == 1
    assert lazy.is_evaluated

