

# Generated at 2022-06-18 01:40:21.671263
# Unit test for method map of class Lazy
def test_Lazy_map():
    """
    Test for method map of class Lazy.
    """
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    lazy = Lazy(lambda: 1)
    assert lazy.map(add_one).map(add_two).map(add_three).map(add_four).map(add_five).get() == 16



# Generated at 2022-06-18 01:40:26.667813
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1.0)
    assert Lazy.of(1) != Lazy.of(None)
    assert Lazy.of(1) != Lazy.of(True)
    assert Lazy.of(1) != Lazy.of(False)
    assert Lazy.of(1) != Lazy.of('1')
    assert Lazy.of(1) != Lazy.of([1])
    assert Lazy.of(1) != Lazy.of((1,))
    assert Lazy.of(1) != Lazy.of({'1': 1})

# Generated at 2022-06-18 01:40:38.596160
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(2).get(1) == 2
    assert Lazy.of(3).get(1, 2) == 3
    assert Lazy.of(4).get(1, 2, 3) == 4
    assert Lazy.of(5).get(1, 2, 3, 4) == 5
    assert Lazy.of(6).get(1, 2, 3, 4, 5) == 6
    assert Lazy.of(7).get(1, 2, 3, 4, 5, 6) == 7
    assert Lazy.of(8).get(1, 2, 3, 4, 5, 6, 7) == 8
    assert Lazy.of(9).get(1, 2, 3, 4, 5, 6, 7, 8) == 9
   

# Generated at 2022-06-18 01:40:45.484270
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def divide_by_two(x):
        return x / 2

    def divide_by_zero(x):
        return x / 0

    assert Lazy.of(1).bind(lambda x: Lazy.of(add_one(x))).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(multiply_by_two(x))).get() == 2
    assert Lazy.of(2).bind(lambda x: Lazy.of(divide_by_two(x))).get() == 1
    assert Lazy.of(2).bind(lambda x: Lazy.of(divide_by_zero(x))).get() == 0

# Generated at 2022-06-18 01:40:54.573133
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()

# Generated at 2022-06-18 01:40:58.835006
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).map(add_two).map(add_three).get(1) == 7


# Generated at 2022-06-18 01:41:04.112437
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function(value):
        return value * 2

    lazy = Lazy(test_function)
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4
    assert lazy.get(2) == 4


# Generated at 2022-06-18 01:41:09.487852
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4


# Generated at 2022-06-18 01:41:18.080138
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:41:22.360458
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(a):
        return a + 1

    lazy = Lazy(fn)

    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(2) == 3


# Generated at 2022-06-18 01:41:27.833090
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    lazy = Lazy.of(1)
    assert lazy.bind(add_one).get() == 2



# Generated at 2022-06-18 01:41:39.240165
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x + 1).get() == 5
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x + 1).map(lambda x: x * 2).get() == 10

# Generated at 2022-06-18 01:41:42.056543
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:41:46.531404
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    assert Lazy.of(1).map(add_one).get() == 2
    assert Lazy.of(1).map(add_one).map(add_two).get() == 3



# Generated at 2022-06-18 01:41:55.286730
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x: int) -> int:
        return x + 1

    def add_two(x: int) -> int:
        return x + 2

    def add_three(x: int) -> int:
        return x + 3

    def add_four(x: int) -> int:
        return x + 4

    def add_five(x: int) -> int:
        return x + 5

    def add_six(x: int) -> int:
        return x + 6

    def add_seven(x: int) -> int:
        return x + 7


# Generated at 2022-06-18 01:41:58.110586
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:42:08.578997
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:42:18.894625
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:42:21.297464
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)

    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2



# Generated at 2022-06-18 01:42:29.648242
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    lazy_add = Lazy(add)
    lazy_add_2 = lazy_add.ap(Box(2))
    assert lazy_add_2.get(1) == 3

    lazy_add_2 = lazy_add.ap(Maybe.just(2))
    assert lazy_add_2.get(1) == 3

    lazy_add_2 = lazy_add.ap(Maybe.nothing())
    assert lazy_add_2.get(1) == 1



# Generated at 2022-06-18 01:42:39.593374
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))


# Generated at 2022-06-18 01:42:49.798407
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:42:52.089823
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:42:55.928485
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)

    assert lazy_1 == lazy_2

    lazy_1._compute_value(1)
    assert lazy_1 != lazy_2

    lazy_2._compute_value(1)
    assert lazy_1 == lazy_2

    lazy_2._compute_value(2)
    assert lazy_1 != lazy_2



# Generated at 2022-06-18 01:43:07.506381
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor

    def test_fn(value):
        return value

    lazy = Lazy(test_fn)
    lazy_copy = Lazy(test_fn)
    lazy_copy_2 = Lazy(test_fn)
    lazy_copy_3 = Lazy(test_fn)
    lazy_copy_4 = Lazy(test_fn)

    assert lazy == lazy_copy
    assert lazy_copy == lazy_copy_2
    assert lazy_copy_2 == lazy_copy_3
    assert lazy_copy_3 == lazy_copy_4

    lazy_copy_2.get()
    lazy_copy_3.get()
    lazy_copy_4.get()

    assert lazy == lazy_copy
    assert lazy_copy == lazy_copy_2
    assert lazy_copy_2

# Generated at 2022-06-18 01:43:16.452264
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(x):
        return x + 1

    def test_fn_2(x):
        return x + 2

    def test_fn_3(x):
        return x + 3

    def test_fn_4(x):
        return x + 4

    def test_fn_5(x):
        return x + 5

    def test_fn_6(x):
        return x + 6

    def test_fn_7(x):
        return x + 7

    def test_fn_8(x):
        return x + 8


# Generated at 2022-06-18 01:43:21.862902
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    def fn2():
        return 2

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(fn2)

    assert lazy1 == lazy2
    assert lazy1 != lazy3
    assert lazy1 != 1
    assert lazy1 != None
    assert lazy1 != object()



# Generated at 2022-06-18 01:43:26.455723
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:43:33.124520
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return

# Generated at 2022-06-18 01:43:42.131206
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    def add_two(x):
        return Lazy.of(x + 2)

    assert Lazy.of(1).bind(add_one).bind(add_two).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_two).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_two).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_two).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_two).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_two).get() == 4
   

# Generated at 2022-06-18 01:43:57.063348
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def sub(a, b):
        return a - b

    def mul(a, b):
        return a * b

    def div(a, b):
        return a / b

    def add_one(a):
        return a + 1

    def sub_one(a):
        return a - 1

    def mul_one(a):
        return a * 1

    def div_one(a):
        return a / 1

    assert Lazy.of(add).ap(Lazy.of(1)).ap(Lazy.of(2)).get() == 3

# Generated at 2022-06-18 01:43:58.831585
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:44:01.733429
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return 1

    lazy = Lazy(fn)
    assert lazy.get() == 1
    assert lazy.get() == 1
    assert lazy.is_evaluated is True


# Generated at 2022-06-18 01:44:08.849529
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_to_box(a):
        return Box(add(a, 1))

    def add_to_maybe(a):
        return Maybe.just(add(a, 1))

    def add_to_try(a):
        return Try.of(add, a, 1)

    def add_to_validation(a):
        return Validation.success(add(a, 1))

    assert Lazy.of(1).ap(Lazy.of(add)).get() == 2

# Generated at 2022-06-18 01:44:14.523745
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    def fn():
        return 1

    def fn2():
        return 2

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)
    assert Lazy(fn) != Try.of(fn)
    assert Lazy(fn) != 1



# Generated at 2022-06-18 01:44:24.238500
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value):
        return Lazy.of(value)

    assert Lazy.of(1).bind(test_fn) == Lazy.of(1)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(3)

# Generated at 2022-06-18 01:44:29.909773
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:44:34.430972
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:44:39.557387
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1():
        return 1

    def fn2():
        return 2

    lazy1 = Lazy(fn1)
    lazy2 = Lazy(fn1)
    lazy3 = Lazy(fn2)
    lazy4 = Lazy(fn1)
    lazy4.get()

    assert lazy1 == lazy2
    assert lazy1 != lazy3
    assert lazy1 != lazy4
    assert lazy4 == lazy4



# Generated at 2022-06-18 01:44:48.672042
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)
    lazy_3 = Lazy(fn)

    assert lazy_1 == lazy_2
    assert lazy_2 == lazy_3
    assert lazy_1 == lazy_3

    lazy_1._compute_value()
    assert lazy_1 == lazy_2
    assert lazy_2 == lazy_3
    assert lazy_1 == lazy_3

    lazy_2._compute_value()
    assert lazy_1 == lazy_2
    assert lazy_2 == lazy_3
    assert lazy_1 == lazy_3

    lazy_3._compute_value()
    assert lazy_1 == lazy_2
    assert lazy_2 == lazy_3
    assert lazy_1 == lazy_3


# Unit test

# Generated at 2022-06-18 01:45:03.456476
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    lazy_add = Lazy(add)
    lazy_add_two = Lazy(add_two)

    assert lazy_add.ap(lazy_add_two).get(1) == 4


# Generated at 2022-06-18 01:45:13.512739
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:45:20.367096
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    def fn3(x):
        return x + 3

    def fn4(x):
        return x + 4

    def fn5(x):
        return x + 5

    def fn6(x):
        return x + 6

    def fn7(x):
        return x + 7

    def fn8(x):
        return x + 8

    def fn9(x):
        return x + 9


# Generated at 2022-06-18 01:45:31.552320
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: '1')
    assert Lazy(fn) != Lazy(lambda: '2')
    assert Lazy(fn) != Lazy(lambda: 'None')

# Generated at 2022-06-18 01:45:37.452619
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(arg):
        return arg

    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(2) == 2
    assert Lazy(fn).get(2) == 2
    assert Lazy(fn).get(3) == 3
    assert Lazy(fn).get(3) == 3


# Generated at 2022-06-18 01:45:47.274190
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def multiply(a, b):
        return a * b

    def divide(a, b):
        return a / b

    def raise_exception(a, b):
        raise Exception('Exception')

    def add_one(a):
        return a + 1

    def multiply_by_two(a):
        return a * 2

    def divide_by_two(a):
        return a / 2

    def raise_exception_in_function(a):
        raise Exception('Exception')


# Generated at 2022-06-18 01:45:57.307324
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x, y):
        return x + y

    def multiply(x, y):
        return x * y

    def divide(x, y):
        return x / y

    def subtract(x, y):
        return x - y

    def raise_exception(x, y):
        raise Exception('Exception')

    def raise_value_error(x, y):
        raise ValueError('ValueError')

    def raise_type_error(x, y):
        raise TypeError('TypeError')

    def raise_zero_division_error(x, y):
        raise ZeroDivisionError

# Generated at 2022-06-18 01:46:01.932301
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for method bind of class Lazy.
    """
    from pymonet.maybe import Maybe

    def test_function(value):
        return Maybe.just(value + 1)

    lazy = Lazy(lambda: 1)
    assert lazy.bind(test_function).get() == 2

# Generated at 2022-06-18 01:46:12.825814
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def test_function(value):
        return value

    def test_function_2(value):
        return value

    def test_function_3(value):
        return value

    def test_function_4(value):
        return value

    def test_function_5(value):
        return value

    def test_function_6(value):
        return value

    def test_function_7(value):
        return value

    def test_function_8(value):
        return value

    def test_function_9(value):
        return value

    def test_function_10(value):
        return value

    def test_function_11(value):
        return value


# Generated at 2022-06-18 01:46:18.829877
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    lazy = Lazy(lambda: 1)
    assert lazy.map(add_one).map(add_two).map(add_three).get() == 7



# Generated at 2022-06-18 01:46:47.081118
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:46:55.345862
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:47:05.486539
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:47:12.934390
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_two)) == Lazy.of(3)
    assert Lazy.of(1).ap(Lazy.of(add_three)) == Lazy.of(4)
    assert Lazy.of(1).ap(Box(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Box(add_two)) == Lazy.of(3)
   

# Generated at 2022-06-18 01:47:21.391822
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:47:28.500582
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    def double(x):
        return Lazy.of(x * 2)

    def triple(x):
        return Lazy.of(x * 3)

    assert Lazy.of(1).bind(add_one).bind(double).bind(triple).get() == 12
    assert Lazy.of(1).bind(add_one).bind(double).bind(triple).get() == 12
    assert Lazy.of(1).bind(add_one).bind(double).bind(triple).get() == 12
    assert Lazy.of(1).bind(add_one).bind(double).bind(triple).get() == 12

# Generated at 2022-06-18 01:47:39.912043
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:47:50.325579
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:47:53.328917
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return 1

    lazy = Lazy(fn)
    assert lazy.get() == 1
    assert lazy.is_evaluated
    assert lazy.get() == 1


# Generated at 2022-06-18 01:48:00.916367
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def multiply(x):
        return x * 2

    def divide(x):
        return x / 2

    def subtract(x):
        return x - 1

    def square(x):
        return x * x

    def cube(x):
        return x * x * x

    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 != 0

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero(x):
        return x == 0


# Generated at 2022-06-18 01:48:39.884630
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x

    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(1) == 1
    assert Lazy(fn).get(2) == 2
    assert Lazy(fn).get(2) == 2


# Generated at 2022-06-18 01:48:43.652991
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))


# Generated at 2022-06-18 01:48:49.811457
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Try.of(lambda: x + 1)

    def fn2(x):
        return Validation.success(x + 1)

    assert Lazy.of(1).bind(fn).get() == Try.of(lambda: 2)
    assert Lazy.of(1).bind(fn2).get() == Validation.success(2)

# Generated at 2022-06-18 01:48:54.994685
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))


# Generated at 2022-06-18 01:49:05.937039
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:49:12.608920
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != L

# Generated at 2022-06-18 01:49:20.580556
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    lazy_add = Lazy(add)
    lazy_add_one = Lazy(add_one)

    assert lazy_add.ap(lazy_add_one).get(1, 2) == 4
    assert lazy_add.ap(Maybe.just(add_one)).get(1, 2) == 4
    assert lazy_add.ap(Maybe.nothing()).get(1, 2) == 3


# Generated at 2022-06-18 01:49:26.030197
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(lambda x: x + 2)

    assert lazy == lazy2
    assert lazy != lazy3
    assert lazy != 1
    assert lazy != Lazy(fn)
    assert lazy != Lazy(lambda x: x + 1)
    assert lazy != Lazy(lambda x: x + 1)
    assert lazy == Lazy(lambda x: x + 1)


# Generated at 2022-06-18 01:49:32.440785
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn_a():
        return 1

    def fn_b():
        return 2

    lazy_a = Lazy(fn_a)
    lazy_b = Lazy(fn_b)
    lazy_c = Lazy(fn_a)

    assert lazy_a != lazy_b
    assert lazy_a == lazy_c
    assert lazy_b != lazy_c

    lazy_a.get()
    lazy_b.get()
    lazy_c.get()

    assert lazy_a != lazy_b
    assert lazy_a == lazy_c
    assert lazy_b != lazy_c



# Generated at 2022-06-18 01:49:42.560112
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8
