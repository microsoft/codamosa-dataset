

# Generated at 2022-06-18 01:40:29.394202
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8

    def add_nine(a):
        return a + 9


# Generated at 2022-06-18 01:40:36.274104
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:40:46.264919
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:40:55.080263
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_to_box(x):
        return Box(x + 1)

    def add_to_either(x):
        return Right(x + 1)

    def add_to_maybe(x):
        return Maybe.just(x + 1)

    def add_to_try(x):
        return Try.of(lambda: x + 1)

    def add_to_validation(x):
        return Validation.success(x + 1)

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy

# Generated at 2022-06-18 01:40:57.337777
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return 'test'

    lazy = Lazy(fn)
    assert lazy.get() == 'test'



# Generated at 2022-06-18 01:41:08.101800
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 2).bind(fn).get() == 3
    assert Lazy(lambda: 3).bind(fn).get() == 4
    assert Lazy(lambda: 4).bind(fn).get() == 5
    assert Lazy(lambda: 5).bind(fn).get() == 6
    assert Lazy(lambda: 6).bind(fn).get() == 7
    assert Lazy(lambda: 7).bind(fn).get() == 8
    assert Lazy(lambda: 8).bind(fn).get() == 9
    assert Lazy(lambda: 9).bind(fn).get() == 10
    assert Lazy(lambda: 10).bind(fn).get() == 11


# Generated at 2022-06-18 01:41:09.657714
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).get() == 2
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).bind(lambda x: Lazy(lambda: x + 1)).get() == 3


# Generated at 2022-06-18 01:41:18.223633
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_2(x):
        return x + 2

    def add_3(x):
        return x + 3

    def add_4(x):
        return x + 4

    def add_5(x):
        return x + 5

    def add_6(x):
        return x + 6

    def add_7(x):
        return x + 7

    def add_8(x):
        return x + 8

    def add_9(x):
        return x + 9

    def add_10(x):
        return

# Generated at 2022-06-18 01:41:27.833655
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def add(x, y):
        return x + y

    def mul(x, y):
        return x * y

    assert Lazy(add) == Lazy(add)
    assert Lazy(add) != Lazy(mul)
    assert Lazy(add) != Lazy(add).map(lambda x: x + 1)
    assert Lazy(add) != Lazy(add).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(add) != Lazy(add).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)



# Generated at 2022-06-18 01:41:39.251715
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(1) == 1
    assert Lazy(lambda: 1).get(1, 2) == 1
    assert Lazy(lambda: 1).get(1, 2, 3) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy(lambda: 1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:41:44.418268
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(a, b):
        return a + b

    lazy = Lazy(add)
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3


# Generated at 2022-06-18 01:41:53.793679
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9


# Generated at 2022-06-18 01:42:03.616646
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:42:13.948462
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:42:19.097044
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    lazy = Lazy.of(1)
    assert lazy.map(add_one).get() == 2
    assert lazy.map(add_one).map(add_two).get() == 3



# Generated at 2022-06-18 01:42:23.070941
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:42:32.909473
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x * 2

    def fn3(x):
        return x ** 2

    def fn4(x):
        return x + '1'

    def fn5(x):
        return x * 2

    def fn6(x):
        return x ** 2

    def fn7(x):
        return x + '1'

    def fn8(x):
        return x * 2

    def fn9(x):
        return x ** 2

    def fn10(x):
        return x + '1'

# Generated at 2022-06-18 01:42:37.757204
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4

# Generated at 2022-06-18 01:42:48.006304
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_lazy(a):
        return Lazy.of(lambda b: add(a, b))

    assert Lazy.of(1).ap(Lazy.of(add_lazy(1))).get(2) == 3
    assert Lazy.of(1).ap(Lazy.of(add_lazy(1))).to_box(2) == 3
    assert Lazy.of(1).ap(Lazy.of(add_lazy(1))).to_either(2) == 3
    assert Lazy.of(1).ap(Lazy.of(add_lazy(1))).to_maybe(2) == 3

# Generated at 2022-06-18 01:42:51.186445
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    assert Lazy.of(add).ap(Box(1)).ap(Box(2)).get() == 3
    assert Lazy.of(add_one).ap(Lazy.of(1)).get() == 2

# Generated at 2022-06-18 01:43:07.789070
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def test_fn(x):
        return x

    def test_mapper(x):
        return x

    lazy = Lazy(test_fn)
    lazy2 = Lazy(test_fn)
    lazy3 = Lazy(test_fn)
    lazy4 = Lazy(test_fn)
    lazy5 = Lazy(test_fn)
    lazy6 = Lazy(test_fn)
    lazy7 = Lazy(test_fn)
    lazy8 = Lazy(test_fn)
    lazy9 = Lazy(test_fn)
    lazy10 = Lazy(test_fn)
    lazy11 = Lazy(test_fn)
    lazy12 = Lazy(test_fn)
    lazy13 = L

# Generated at 2022-06-18 01:43:16.724404
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:43:27.209571
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def f(x):
        return Lazy(lambda: x + 1)

    def g(x):
        return Lazy(lambda: x * 2)

    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4
    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4
    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4
    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4
    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4
    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4
    assert Lazy(lambda: 1).bind(f).bind(g).get() == 4

# Generated at 2022-06-18 01:43:33.542062
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:43:42.407338
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).map(lambda x: x + 1).bind(lambda x: Lazy.of(x + 1))

# Generated at 2022-06-18 01:43:53.030055
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:44:03.093529
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy.of(x)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).to_box() == Box(1)
    assert Lazy.of(1).bind(fn).to_either() == Right(1)
    assert Lazy.of(1).bind(fn).to_maybe() == Maybe.just(1)
    assert Lazy.of(1).bind(fn).to_try() == Try.of(lambda: 1)

# Generated at 2022-06-18 01:44:09.373468
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1).map(lambda x: x + 1) != Lazy.of(1).map(lambda x: x + 2)
    assert Lazy.of(1).map(lambda x: x + 1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1).map(lambda x: x + 1).map

# Generated at 2022-06-18 01:44:16.260266
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).bind(lambda x: Lazy.of(add_one(x))).bind(lambda x: Lazy.of(add_two(x))).bind(lambda x: Lazy.of(add_three(x))).get() == 7


# Generated at 2022-06-18 01:44:25.352466
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def test_eq(lazy1, lazy2):
        assert lazy1 == lazy2

    def test_not_eq(lazy1, lazy2):
        assert lazy1 != lazy2

    def test_eq_with_other_type(lazy):
        assert lazy != 1

    def test_eq_with_other_type_and_other_value(lazy):
        assert lazy != Lazy(lambda: 1)

    def test_eq_with_other_type_and_other_value_and_other_is_evaluated(lazy):
        assert lazy != Lazy(lambda: 1).get()


# Generated at 2022-06-18 01:44:42.432430
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:44:49.893675
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:45:00.196725
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()

# Generated at 2022-06-18 01:45:08.453801
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    def fn(x):
        return x

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)
    lazy_3 = Lazy(fn)
    lazy_4 = Lazy(fn)

    lazy_1._compute_value(1)
    lazy_2._compute_value(1)
    lazy_3._compute_value(2)
    lazy_4._compute_value(2)

    assert lazy_1 == lazy_2
    assert lazy_3 == lazy_4
    assert lazy_1 != lazy_3



# Generated at 2022-06-18 01:45:17.665843
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(x):
        return x

    def g(x):
        return x

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(g)
    assert Lazy(f) != Lazy(f).map(f)
    assert Lazy(f) != Lazy(f).map(g)
    assert Lazy(f) != Lazy(f).ap(Lazy(f))
    assert Lazy(f) != Lazy(f).ap(Lazy(g))
    assert Lazy(f) != Lazy(f).bind(lambda x: Lazy(f))
    assert Lazy(f) != Lazy(f).bind(lambda x: Lazy(g))
    assert Lazy(f) != Lazy(f).get()
    assert Lazy(f)

# Generated at 2022-06-18 01:45:29.264528
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).to_box().get() == 2
    assert Lazy.of(1).bind(fn).to_either().get() == 2
    assert Lazy.of(1).bind(fn).to_maybe().get() == 2
    assert Lazy.of(1).bind(fn).to_try().get() == 2
    assert Lazy.of(1).bind(fn).to_validation().get

# Generated at 2022-06-18 01:45:40.383710
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10


# Generated at 2022-06-18 01:45:45.309171
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Box(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Right(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Maybe.just(1)) == Lazy.of(2)

# Generated at 2022-06-18 01:45:55.160387
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:46:06.975978
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).get()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()

# Generated at 2022-06-18 01:46:25.254979
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_validation import Validation

    def add(x):
        return x + 1

    def add_and_multiply(x, y):
        return x + y * 2

    def add_and_multiply_and_divide(x, y, z):
        return x + y * 2 / z

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_and_multiply)) == Lazy.of(3)
    assert Lazy.of(1).ap(Lazy.of(add_and_multiply_and_divide)) == Lazy.of(1.5)

    assert L

# Generated at 2022-06-18 01:46:35.963277
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return

# Generated at 2022-06-18 01:46:42.381655
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add(x, y):
        return x + y

    def mul(x, y):
        return x * y

    def div(x, y):
        return x / y

    def pow(x, y):
        return x ** y

    assert Lazy(lambda x: x).map(add).map(mul).map(div).map(pow).get(2, 3) == (2 ** (2 * (2 / (2 + 3))))


# Generated at 2022-06-18 01:46:52.820623
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:46:58.721388
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)
    lazy_3 = Lazy(fn)

    lazy_1._compute_value(1)
    lazy_2._compute_value(1)
    lazy_3._compute_value(2)

    assert lazy_1 == lazy_2
    assert lazy_1 != lazy_3


# Generated at 2022-06-18 01:47:07.882450
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:47:14.801916
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1(x):
        return x

    def fn2(x):
        return x

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x)
    assert Lazy(fn1) != Lazy(fn1).ap(Lazy(fn2))
    assert Lazy(fn1) != Lazy(fn1).bind(lambda x: Lazy(fn2))
    assert Lazy(fn1) != Lazy(fn1).get()
    assert Lazy(fn1) != Lazy(fn1).to_box()
    assert Lazy(fn1) != Lazy(fn1).to_either()
    assert Lazy(fn1) != Lazy

# Generated at 2022-06-18 01:47:22.473610
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1.0)
    assert Lazy.of(1) != Lazy.of('1')
    assert Lazy.of(1) != Lazy.of(True)
    assert Lazy.of(1) != Lazy.of(None)
    assert Lazy.of(1) != Lazy.of([1])
    assert Lazy.of(1) != Lazy.of({'1': 1})
    assert Lazy.of(1) != Lazy.of(set([1]))
    assert Lazy.of(1) != Lazy.of(tuple([1]))

# Generated at 2022-06-18 01:47:29.120425
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:47:40.414765
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:47:55.814098
# Unit test for method map of class Lazy
def test_Lazy_map():
    def f(x):
        return x + 1

    def g(x):
        return x * 2

    def h(x):
        return x - 1

    assert Lazy(f).map(g).map(h).get(1) == 2
    assert Lazy(f).map(g).map(h).get(2) == 4
    assert Lazy(f).map(g).map(h).get(3) == 6



# Generated at 2022-06-18 01:48:07.564398
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:48:18.935911
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(add_one).get() == 2

    def add_one_and_two(x):
        return Lazy.of(x + 1).bind(lambda x: Lazy.of(x + 2))

    assert Lazy.of(1).bind(add_one_and_two).get() == 4

    def add_one_and_two_and_three(x):
        return Lazy.of(x + 1).bind(lambda x: Lazy.of(x + 2).bind(lambda x: Lazy.of(x + 3)))

    assert Lazy.of(1).bind(add_one_and_two_and_three).get() == 7



# Generated at 2022-06-18 01:48:24.546197
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:48:32.779918
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9


# Generated at 2022-06-18 01:48:38.948695
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(add_one).get() == 2
    assert Lazy.of(1).bind(add_one).bind(add_one).get() == 3
    assert Lazy.of(1).bind(add_one).bind(add_one).bind(add_one).get() == 4


# Generated at 2022-06-18 01:48:44.508287
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)

# Generated at 2022-06-18 01:48:53.916644
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:49:04.955053
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(a, b):
        return a + b

    lazy = Lazy(add)
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3

# Generated at 2022-06-18 01:49:12.616822
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:49:30.660956
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        pass

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != Lazy(fn)
    assert Lazy(fn) != L

# Generated at 2022-06-18 01:49:37.184859
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn) == Lazy.of(1)

# Generated at 2022-06-18 01:49:48.064878
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:49:57.035899
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy(lambda: x)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).to_box() == Box(1)
    assert Lazy.of(1).bind(fn).to_either() == Right(1)
    assert Lazy.of(1).bind(fn).to_maybe() == Maybe.just(1)
    assert Lazy.of(1).bind(fn).to_try() == Try.of(lambda: 1)

# Generated at 2022-06-18 01:50:03.730777
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def test_function(x):
        return x + 1

    def test_function_2(x):
        return x + 2

    def test_function_3(x):
        return x + 3

    def test_function_4(x):
        return x + 4

    def test_function_5(x):
        return x + 5

    def test_function_6(x):
        return x + 6

    def test_function_7(x):
        return x + 7

    def test_function_8(x):
        return x + 8

    def test_function_9(x):
        return x + 9

    def test_function_10(x):
        return x + 10


# Generated at 2022-06-18 01:50:05.918516
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:50:13.352560
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:50:18.743493
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
