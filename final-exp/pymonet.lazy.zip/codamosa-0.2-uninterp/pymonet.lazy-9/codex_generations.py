

# Generated at 2022-06-18 01:40:22.684144
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) != Lazy.of(1).bind(lambda x: Lazy.of(x + 2))

# Generated at 2022-06-18 01:40:30.441337
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).to_box().get() == 2
    assert Lazy.of(1).bind(fn).to_either().get() == 2
    assert Lazy.of(1).bind(fn).to_maybe().get() == 2
    assert Lazy.of(1).bind(fn).to_try().get() == 2
    assert Lazy.of(1).bind(fn).to_validation().get

# Generated at 2022-06-18 01:40:40.951439
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:40:51.560431
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1.0)
    assert Lazy(lambda: 1) != Lazy(lambda: 1.0)
    assert Lazy(lambda: 1) != Lazy(lambda: 1.0)
    assert Lazy(lambda: 1) != Lazy(lambda: 1.0)
    assert Lazy(lambda: 1) != Lazy(lambda: 1.0)
    assert Lazy(lambda: 1) != Lazy(lambda: 1.0)

# Generated at 2022-06-18 01:40:59.245965
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:41:05.430957
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    def add_two(x):
        return Lazy.of(x + 2)

    def add_three(x):
        return Lazy.of(x + 3)

    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7

# Generated at 2022-06-18 01:41:15.117713
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:41:17.206231
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy_1 = Lazy(fn)
    lazy_2 = Lazy(fn)

    assert lazy_1 == lazy_2



# Generated at 2022-06-18 01:41:24.333938
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.monad_try import Try

    def fn(a):
        return a + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2

    def fn(a):
        raise Exception('Exception')

    lazy = Lazy(fn)
    assert lazy.get(1) == Try.of(fn, 1)



# Generated at 2022-06-18 01:41:35.521946
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    def multiply(a, b):
        return a * b

    def divide(a, b):
        return a / b

    def subtract(a, b):
        return a - b

    def modulo(a, b):
        return a % b

    def power(a, b):
        return a ** b

    def concat(a, b):
        return a + b

    def concat_with_space(a, b):
        return a + ' ' + b

    def concat_with_comma(a, b):
        return a + ', ' + b

    def concat_with_dot(a, b):
        return a + '. ' + b


# Generated at 2022-06-18 01:41:47.785270
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:41:56.242341
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn) != L

# Generated at 2022-06-18 01:42:06.531521
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:42:17.291478
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for method bind of class Lazy
    """
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value):
        return Lazy.of(value)

    assert Lazy(lambda: 1).bind(test_fn) == Lazy.of(1)
    assert Lazy(lambda: 1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy(lambda: 1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(3)

# Generated at 2022-06-18 01:42:23.500201
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(1) == 1
    assert Lazy(lambda a: a).get(1) == 1
    assert Lazy(lambda a: a).get(1, 2) == 1
    assert Lazy(lambda a, b: a + b).get(1, 2) == 3
    assert Lazy(lambda a, b: a + b).get(1, 2, 3) == 3
    assert Lazy(lambda a, b, c: a + b + c).get(1, 2, 3) == 6
    assert Lazy(lambda a, b, c: a + b + c).get(1, 2, 3, 4) == 6

# Generated at 2022-06-18 01:42:33.220405
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:42:38.087614
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2

    lazy = Lazy(fn)
    assert lazy.get(2) == 3
    assert lazy.get(2) == 3



# Generated at 2022-06-18 01:42:48.297139
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:42:54.636436
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)


# Generated at 2022-06-18 01:42:56.808446
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:43:09.971697
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x, y):
        return x + y

    def add_to_box(x):
        return Box(add(x, 1))

    def add_to_either(x):
        return Right(add(x, 1))

    def add_to_maybe(x):
        return Maybe.just(add(x, 1))

    def add_to_try(x):
        return Try.of(add, x, 1)

    def add_to_validation(x):
        return Validation.success(add(x, 1))


# Generated at 2022-06-18 01:43:18.247035
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1).map(lambda x: x + 1) != Lazy(lambda: 1)
    assert Lazy(lambda: 1).map(lambda x: x + 1) == Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1).map(lambda x: x + 1) != Lazy(lambda: 2).map(lambda x: x + 1)
    assert Lazy(lambda: 1).map(lambda x: x + 1) != Lazy(lambda: 2).map(lambda x: x + 2)
   

# Generated at 2022-06-18 01:43:26.455775
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)



# Generated at 2022-06-18 01:43:28.237637
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy == lazy2



# Generated at 2022-06-18 01:43:34.625664
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1).map(lambda x: x + 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:43:40.641479
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8

    def add_nine(a):
        return a + 9

    def add_ten(a):
        return a + 10


# Generated at 2022-06-18 01:43:50.598415
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a, b):
        return a + b

    def multiply(a, b):
        return a * b

    def add_one(a):
        return a + 1

    def multiply_by_two(a):
        return a * 2

    assert Lazy(add).ap(Lazy(multiply)).get(1, 2) == 3
    assert Lazy(multiply).ap(Lazy(add)).get(1, 2) == 2
    assert Lazy(add_one).ap(Lazy(multiply_by_two)).get(1) == 3
    assert Lazy(multiply_by_two).ap(Lazy(add_one)).get(1) == 4

# Generated at 2022-06-18 01:43:57.585276
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:44:06.647128
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1.0)
    assert Lazy(lambda: 1) != Lazy(lambda: '1')
    assert Lazy(lambda: 1) != Lazy(lambda: None)
    assert Lazy(lambda: 1) != Lazy(lambda: [1])
    assert Lazy(lambda: 1) != Lazy(lambda: (1,))
    assert Lazy(lambda: 1) != Lazy(lambda: {1: 1})
    assert Lazy(lambda: 1)

# Generated at 2022-06-18 01:44:11.399413
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:44:23.551216
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()

# Generated at 2022-06-18 01:44:33.625084
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy = Lazy(fn)
    assert lazy == Lazy(fn)
    assert lazy != Lazy(lambda: 2)
    assert lazy != Lazy(lambda: None)
    assert lazy != Lazy(lambda: [])
    assert lazy != Lazy(lambda: {})
    assert lazy != Lazy(lambda: ())
    assert lazy != Lazy(lambda: True)
    assert lazy != Lazy(lambda: False)
    assert lazy != Lazy(lambda: 1.0)
    assert lazy != Lazy(lambda: 1.1)
    assert lazy != Lazy(lambda: '1')
    assert lazy != Lazy(lambda: '2')
    assert lazy != Lazy(lambda: 'a')
    assert lazy != Lazy(lambda: 'b')

# Generated at 2022-06-18 01:44:40.403844
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:44:49.292111
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return Lazy.of(value)

    def fn_box(value):
        return Box(value)

    def fn_maybe(value):
        return Maybe.just(value)

    def fn_try(value):
        return Try.of(lambda: value)

    def fn_validation(value):
        return Validation.success(value)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn_box) == Lazy.of(1)
    assert Lazy.of(1).bind(fn_maybe) == L

# Generated at 2022-06-18 01:44:52.530511
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(a, b):
        return a + b

    lazy = Lazy(add)
    assert lazy.get(1, 2) == 3



# Generated at 2022-06-18 01:45:02.991290
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: set())
    assert Lazy(fn) != Lazy(lambda: frozenset())
    assert Lazy(fn) != Lazy(lambda: 1)
    assert Lazy(fn) != Lazy(lambda: 1.0)
    assert Lazy(fn) != Lazy(lambda: '1')

# Generated at 2022-06-18 01:45:07.859943
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:45:13.591447
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)

    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
   

# Generated at 2022-06-18 01:45:17.628127
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    def add_two(x):
        return Lazy.of(x + 2)

    def add_three(x):
        return Lazy.of(x + 3)

    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7

# Generated at 2022-06-18 01:45:24.195504
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:45:37.228020
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(a):
        return a

    lazy = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(fn)
    lazy4 = Lazy(fn)
    lazy5 = Lazy(fn)

    assert lazy == lazy2
    assert lazy == lazy3
    assert lazy == lazy4
    assert lazy == lazy5
    assert lazy2 == lazy3
    assert lazy2 == lazy4
    assert lazy2 == lazy5
    assert lazy3 == lazy4
    assert lazy3 == lazy5
    assert lazy4 == lazy5

    lazy2._compute_value(1)
    assert lazy != lazy2
    assert lazy2 != lazy3
    assert lazy2 != lazy4
    assert lazy2 != lazy5

    lazy3._compute_value(1)
    assert lazy != lazy3
   

# Generated at 2022-06-18 01:45:40.687408
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Test for method bind of class Lazy
    """
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:45:50.358890
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:46:00.832352
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: set())
    assert Lazy(fn) != Lazy(lambda: frozenset())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: None)

# Generated at 2022-06-18 01:46:11.977926
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:46:17.032847
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1) == Lazy.of(2)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy.of(3)
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1) == Lazy.of(4)



# Generated at 2022-06-18 01:46:20.055922
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn():
        return 'test'

    lazy = Lazy(test_fn)
    assert lazy.get() == 'test'
    assert lazy.is_evaluated
    assert lazy.get() == 'test'



# Generated at 2022-06-18 01:46:27.952069
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()

# Generated at 2022-06-18 01:46:38.220202
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:46:49.888441
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).map(lambda x: x + 1))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).to_box())
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).to_either())
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).to_maybe())
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).to_try())
    assert not Lazy

# Generated at 2022-06-18 01:47:05.033638
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    assert Lazy(add_one).map(add_two).map(add_three).map(add_four).map(add_five).get(0) == 15
    assert Lazy(add_one).map(add_two).map(add_three).map(add_four).map(add_five).get(1) == 16
    assert Lazy(add_one).map(add_two).map(add_three).map(add_four).map(add_five).get(2) == 17
    assert Lazy

# Generated at 2022-06-18 01:47:12.518710
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def add(x):
        return lambda y: x + y

    assert Lazy.of(1).ap(Box(add(2))).get() == 3
    assert Lazy.of(1).ap(Lazy.of(add(2))).get() == 3
    assert Lazy.of(1).ap(Lazy.of(add)).ap(Lazy.of(2)).get() == 3
    assert Lazy.of(1).ap(Lazy.of(add)).ap(Box(2)).get() == 3
    assert Lazy.of(1).ap(Box(add)).ap(Lazy.of(2)).get() == 3
    assert Lazy.of(1).ap(Box(add)).ap(Box(2)).get

# Generated at 2022-06-18 01:47:21.055034
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value):
        return Lazy.of(value)

    assert Lazy.of(1).bind(test_fn) == Lazy.of(1)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(3)

# Generated at 2022-06-18 01:47:28.289230
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).ap(Lazy.of(1)) == Lazy.of(3)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).ap(Lazy.of(1)).ap(Lazy.of(1)) == Lazy.of(4)

# Generated at 2022-06-18 01:47:39.704440
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def add(x: int, y: int) -> int:
        return x + y

    def add_one(x: int) -> int:
        return x + 1

    def add_two(x: int) -> int:
        return x + 2

    def add_three(x: int) -> int:
        return x + 3

    def add_four(x: int) -> int:
        return x + 4

    def add_five(x: int) -> int:
        return x + 5

    def add_six(x: int) -> int:
        return x + 6

    def add_seven(x: int) -> int:
        return x + 7


# Generated at 2022-06-18 01:47:47.486663
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def fn(value):
        return Maybe.just(value + 1)

    lazy = Lazy(lambda: 1)

    assert lazy.bind(fn).get() == 2

    lazy = Lazy(lambda: None)

    assert lazy.bind(fn).get() is None

    lazy = Lazy(lambda: 1)

    assert lazy.bind(lambda value: Box(value + 1)).get() == 2

    lazy = Lazy(lambda: None)

    assert lazy.bind(lambda value: Box(value + 1)).get() is None

# Generated at 2022-06-18 01:47:52.005062
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(x):
        return x

    lazy = Lazy(test_fn)

    assert lazy.get(1) == 1
    assert lazy.get(1) == 1
    assert lazy.get(2) == 2
    assert lazy.get(2) == 2


# Generated at 2022-06-18 01:47:54.962136
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(x):
        return x + 1

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 2
    assert lazy.is_evaluated
    assert lazy.value == 2


# Generated at 2022-06-18 01:48:01.290196
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:48:10.516175
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:48:17.940871
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2

# Generated at 2022-06-18 01:48:23.963815
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:48:26.515038
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2



# Generated at 2022-06-18 01:48:35.701050
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:48:37.477638
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2



# Generated at 2022-06-18 01:48:40.055192
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn():
        return 'test_value'

    lazy = Lazy(test_fn)

    assert lazy.get() == 'test_value'
    assert lazy.is_evaluated is True
    assert lazy.value == 'test_value'



# Generated at 2022-06-18 01:48:45.134328
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4


# Generated at 2022-06-18 01:48:54.297721
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).to_box().get() == 2
    assert Lazy.of(1).bind(fn).to_either().get() == 2
    assert Lazy.of(1).bind(fn).to_maybe().get() == 2
    assert Lazy.of(1).bind(fn).to_try().get() == 2
    assert Lazy.of(1).bind(fn).to_validation().get

# Generated at 2022-06-18 01:49:05.334362
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 4
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 5
    assert L

# Generated at 2022-06-18 01:49:11.736563
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x - 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:49:37.919919
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:49:48.968044
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8

    def add_nine(a):
        return a + 9


# Generated at 2022-06-18 01:49:51.358953
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).bind(lambda x: Lazy(add_two)).bind(lambda x: Lazy(add_three)).get(1) == 7


# Generated at 2022-06-18 01:49:59.605341
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:50:05.215019
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x):
        return lambda y: x + y

    assert Lazy.of(1).ap(Box(add(2))) == Lazy.of(3)
    assert Lazy.of(1).ap(Maybe.just(add(2))) == Lazy.of(3)
    assert Lazy.of(1).ap(Maybe.nothing()) == Lazy.of(1)

# Generated at 2022-06-18 01:50:07.722346
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(value):
        return Lazy(lambda: value + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:50:16.874815
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add(x):
        return x + 1

    def multiply(x):
        return x * 2

    def divide(x):
        return x / 2

    def subtract(x):
        return x - 1

    def square(x):
        return x * x

    def cube(x):
        return x * x * x

    def add_and_multiply(x):
        return add(multiply(x))

    def add_and_multiply_and_divide(x):
        return add_and_multiply(divide(x))

    def add_and_multiply_and_divide_and_subtract(x):
        return add_and_multiply_and_divide(subtract(x))
