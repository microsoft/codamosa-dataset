

# Generated at 2022-06-18 01:40:29.341880
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:40:40.753166
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:40:51.483112
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value):
        return Lazy.of(value)

    assert Lazy.of(1).bind(test_fn) == Lazy.of(1)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(3)

# Generated at 2022-06-18 01:40:53.665883
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(add_one).get() == 2



# Generated at 2022-06-18 01:41:04.429013
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return Lazy(lambda: value + 1)

    def fn_box(value):
        return Box(value + 1)

    def fn_either(value):
        return Right(value + 1)

    def fn_maybe(value):
        return Maybe.just(value + 1)

    def fn_try(value):
        return Try.of(lambda: value + 1)

    def fn_validation(value):
        return Validation.success(value + 1)

    assert Lazy.of(1).bind(fn).get() == 2

# Generated at 2022-06-18 01:41:08.051290
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(a):
        return a

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 1
    assert lazy.get(2) == 1
    assert lazy.is_evaluated



# Generated at 2022-06-18 01:41:17.054945
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:41:28.092621
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:41:39.449145
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()

# Generated at 2022-06-18 01:41:46.485515
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))



# Generated at 2022-06-18 01:41:58.206379
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a: int, b: int) -> int:
        return a + b

    def add_one(a: int) -> int:
        return a + 1

    def add_two(a: int) -> int:
        return a + 2

    def add_three(a: int) -> int:
        return a + 3

    def add_four(a: int) -> int:
        return a + 4

    def add_five(a: int) -> int:
        return a + 5

    def add_six(a: int) -> int:
        return a + 6


# Generated at 2022-06-18 01:42:08.678346
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:42:14.779563
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    lazy_add_one = Lazy.of(add_one)
    lazy_add_two = Lazy.of(add_two)
    lazy_add_three = Lazy.of(add_three)

    assert lazy_add_one.bind(lambda x: lazy_add_two.bind(lambda y: lazy_add_three.bind(lambda z: Lazy.of(x(y(z(0))))))) == Lazy.of(6)

# Generated at 2022-06-18 01:42:19.272871
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 2).get() == 2
    assert Lazy(lambda: 3).get() == 3
    assert Lazy(lambda: 4).get() == 4
    assert Lazy(lambda: 5).get() == 5


# Generated at 2022-06-18 01:42:30.554715
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:42:33.966779
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return x + 1

    def multiply(x):
        return x * 2

    assert Lazy(add).ap(Lazy(multiply)).get(2) == 6
    assert Lazy(multiply).ap(Lazy(add)).get(2) == 6


# Generated at 2022-06-18 01:42:43.968068
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(add_one).get() == 2
    assert Lazy(lambda: 1).bind(add_one).bind(add_one).get() == 3
    assert Lazy(lambda: 1).bind(add_one).bind(add_one).bind(add_one).get() == 4
    assert Lazy(lambda: 1).bind(add_one).bind(add_one).bind(add_one).bind(add_one).get() == 5
    assert Lazy(lambda: 1).bind(add_one).bind(add_one).bind(add_one).bind(add_one).bind(add_one).get() == 6

# Generated at 2022-06-18 01:42:53.654913
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    def fn2(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map(lambda x: x).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map

# Generated at 2022-06-18 01:42:57.003943
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(arg):
        return arg

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 1
    assert lazy.get(2) == 1
    assert lazy.get(3) == 1



# Generated at 2022-06-18 01:43:05.825068
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    assert Lazy.of(add).ap(Box(1)).get() == 2
    assert Lazy.of(add).ap(Maybe.just(1)).get() == 2
    assert Lazy.of(mul).ap(Box(1)).get() == 2
    assert Lazy.of(mul).ap(Maybe.just(1)).get() == 2


# Generated at 2022-06-18 01:43:10.983337
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:43:18.842642
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:43:28.719108
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1.0)
    assert Lazy.of(1) != Lazy.of('1')
    assert Lazy.of(1) != Lazy.of(True)
    assert Lazy.of(1) != Lazy.of(None)
    assert Lazy.of(1) != Lazy.of([1])
    assert Lazy.of(1) != Lazy.of((1,))
    assert Lazy.of(1) != Lazy.of({1})
    assert Lazy.of(1) != Lazy.of({'1': 1})

# Generated at 2022-06-18 01:43:38.897988
# Unit test for method get of class Lazy
def test_Lazy_get():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1

    assert Lazy.of(1).to_box() == Box(1)
    assert Lazy.of(1).to_box(1) == Box(1)
    assert Lazy.of(1).to_box(1, 2) == Box(1)
   

# Generated at 2022-06-18 01:43:44.785294
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:43:55.603292
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).get() == 2
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).to_box().get() == 2
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).to_either().get() == 2
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).to_maybe().get() == 2
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)).to_try().get() == 2

# Generated at 2022-06-18 01:44:05.246960
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:44:15.890785
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_try import Try

    def add(x, y):
        return x + y

    def add_lazy(x):
        return Lazy(lambda y: add(x, y))

    assert Lazy.of(1).ap(Lazy.of(add_lazy(2))) == Lazy.of(3)
    assert Lazy.of(1).ap(Try.of(add_lazy, 2)) == Lazy.of(3)
    assert Lazy.of(1).ap(Try.of(add_lazy, 2)).to_try() == Try.of(lambda: 3)
    assert Lazy.of(1).ap(Try.of(add_lazy, 2)).to_try().get() == 3

# Generated at 2022-06-18 01:44:25.075151
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:44:35.748173
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:44:47.276059
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a):
        return a + 1

    def mul(a):
        return a * 2

    lazy = Lazy.of(1)
    assert lazy.ap(Lazy.of(add)).get() == 2
    assert lazy.ap(Lazy.of(mul)).get() == 2
    assert lazy.ap(Lazy.of(add)).ap(Lazy.of(mul)).get() == 4


# Generated at 2022-06-18 01:44:57.286841
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8

    def add_nine(a):
        return a + 9

    def add_ten(a):
        return a + 10


# Generated at 2022-06-18 01:45:08.643087
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:45:17.807345
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:45:22.013209
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    lazy = Lazy.of(1).bind(add_one)
    assert lazy.get() == 2



# Generated at 2022-06-18 01:45:27.091060
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3
    assert lazy.get(2) == 3
    assert lazy.get(1) == 2
    assert lazy.get(2) == 3



# Generated at 2022-06-18 01:45:38.391819
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:45:48.011348
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:45:53.231784
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:46:04.919178
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 2)
    assert Lazy(fn) != Lazy(lambda: None)
    assert Lazy(fn) != Lazy(lambda: [])
    assert Lazy(fn) != Lazy(lambda: {})
    assert Lazy(fn) != Lazy(lambda: ())
    assert Lazy(fn) != Lazy(lambda: True)
    assert Lazy(fn) != Lazy(lambda: False)
    assert Lazy(fn) != Lazy(lambda: "")
    assert Lazy(fn) != Lazy(lambda: "1")
    assert Lazy(fn) != Lazy(lambda: "a")

# Generated at 2022-06-18 01:46:22.542918
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:46:27.269087
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:46:37.720639
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(lambda: 1)
    assert Lazy.of(1) != Lazy.of(lambda: 2)
    assert Lazy.of(lambda: 1) != Lazy.of(lambda: 2)
    assert Lazy.of(lambda: 1) == Lazy.of(lambda: 1)
    assert Lazy.of(lambda: 1) != Lazy.of(lambda: 2)
    assert Lazy.of(lambda: 1) != Lazy.of(lambda: 2)
    assert Lazy.of(lambda: 1) != Lazy.of(lambda: 2)
    assert Lazy.of(lambda: 1) != L

# Generated at 2022-06-18 01:46:49.721624
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:46:56.304860
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:47:00.091453
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(a, b):
        return a + b

    lazy = Lazy(add)
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3



# Generated at 2022-06-18 01:47:03.835101
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(x):
        return x + 1

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2



# Generated at 2022-06-18 01:47:11.366325
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(2)) == Lazy.of(3)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(3)) == Lazy.of(4)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(4)) == Lazy.of(5)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(5)) == Lazy.of(6)
    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(6)) == Lazy.of(7)

# Generated at 2022-06-18 01:47:15.081011
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)
    assert Lazy(fn) != Try.of(fn)
    assert Lazy(fn) != None
    assert Lazy(fn) != 'Lazy'


# Generated at 2022-06-18 01:47:22.493613
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:47:39.035813
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:47:49.669118
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def fn(x):
        return Box(x)

    def fn2(x):
        return Maybe.just(x)

    assert Lazy.of(1).bind(fn).get() == Box(1)
    assert Lazy.of(1).bind(fn2).get() == Maybe.just(1)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x)).get() == 1
    assert Lazy.of(1).bind(lambda x: Lazy.of(x)).get() == 1
    assert Lazy.of(1).bind(lambda x: Lazy.of(x)).get() == 1
    assert Lazy.of(1).bind(lambda x: Lazy.of(x)).get() == 1

# Generated at 2022-06-18 01:47:53.752736
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function(value):
        return value

    lazy = Lazy(test_function)
    assert lazy.get(1) == 1

    lazy = Lazy(test_function)
    assert lazy.get(1) == 1
    assert lazy.get(2) == 1


# Generated at 2022-06-18 01:47:57.541877
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda *args: x * 2)

    assert Lazy(lambda *args: 1).bind(fn).get() == 2
    assert Lazy(lambda *args: 2).bind(fn).get() == 4
    assert Lazy(lambda *args: 3).bind(fn).get() == 6


# Generated at 2022-06-18 01:48:08.244141
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:48:19.412488
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:48:29.603817
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1(x):
        return x

    def fn2(x):
        return x

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x).map(lambda x: x).map(lambda x: x).map(lambda x: x)

# Generated at 2022-06-18 01:48:33.943577
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:48:36.604086
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).map(add_two).map(add_three).get(1) == 7


# Generated at 2022-06-18 01:48:43.313227
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:49:12.914436
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1():
        return 1

    def fn2():
        return 2

    assert Lazy(fn1) == Lazy(fn1)
    assert Lazy(fn1) != Lazy(fn2)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(fn1) != Lazy(fn1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)

# Generated at 2022-06-18 01:49:23.069192
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_fn(value):
        return value + 1

    def test_fn_raise_exception(value):
        raise Exception('test exception')

    def test_fn_return_none(value):
        return None

    def test_fn_return_empty_list(value):
        return []

    def test_fn_return_empty_string(value):
        return ''

    def test_fn_return_empty_dict(value):
        return {}

    def test_fn_return_empty_set(value):
        return set()


# Generated at 2022-06-18 01:49:27.850217
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(value):
        return Lazy.of(value + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).bind(fn).get() == 3
    assert Lazy.of(1).bind(fn).bind(fn).bind(fn).get() == 4

# Generated at 2022-06-18 01:49:35.610012
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def multiply_by_two(x):
        return x * 2

    def multiply_by_three(x):
        return x * 3

    def divide_by_two(x):
        return x / 2

    def divide_by_three(x):
        return x / 3

    def divide_by_six(x):
        return x / 6

    def divide_by_nine(x):
        return x / 9

    def divide_by_twelve(x):
        return x / 12

    def divide_by_eighteen(x):
        return x / 18

    def divide_by_twenty_four(x):
        return x / 24

    def divide_by_thirty_six(x):
        return x / 36


# Generated at 2022-06-18 01:49:42.245495
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Lazy.of(lambda x: x + 1).ap(Box(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Maybe.just(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Maybe.nothing()) == Lazy.of(lambda x: x + 1)

# Generated at 2022-06-18 01:49:52.861377
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:49:57.683254
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:50:06.080442
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:50:13.469166
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy(lambda: x + 1)

    def fn2(x):
        return Lazy(lambda: x + 2)

    assert Lazy.of(1).bind(fn).bind(fn2).get() == 4
    assert Lazy.of(1).bind(fn).bind(fn2).to_box().get() == 4
    assert Lazy.of(1).bind(fn).bind(fn2).to_either().get() == 4
    assert Lazy.of(1).bind(fn).bind(fn2).to_maybe().get() == 4
    assert Lazy.of(1).bind(fn).bind(fn2).to_try().get() == 4
    assert Lazy

# Generated at 2022-06-18 01:50:21.621415
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5