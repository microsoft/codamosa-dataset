

# Generated at 2022-06-18 01:40:29.236478
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:40:40.754615
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy.of(x + 1)

    def fn2(x):
        return Lazy.of(x + 2)

    def fn3(x):
        return Lazy.of(x + 3)

    def fn4(x):
        return Lazy.of(x + 4)

    def fn5(x):
        return Lazy.of(x + 5)

    def fn6(x):
        return Lazy.of(x + 6)

    def fn7(x):
        return Lazy.of(x + 7)


# Generated at 2022-06-18 01:40:51.483199
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(a, b):
        return a + b

    lazy = Lazy(add)
    assert lazy.get(1, 2) == 3

    lazy = Lazy(add).map(lambda x: x * 2)
    assert lazy.get(1, 2) == 6

    lazy = Lazy(add).map(lambda x: x * 2).map(lambda x: x * 2)
    assert lazy.get(1, 2) == 12

    lazy = Lazy(add).map(lambda x: x * 2).map(lambda x: x * 2).map(lambda x: x * 2)
    assert lazy.get(1, 2) == 24


# Generated at 2022-06-18 01:40:59.170199
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:41:04.946477
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)

    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x)



# Generated at 2022-06-18 01:41:14.727671
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x + 1)
    assert Lazy(fn) != Lazy(lambda x: x)()
    assert Lazy(fn) != Lazy(lambda x: x)()()
    assert Lazy(fn) != Lazy(lambda x: x)()()()
    assert Lazy(fn) != Lazy(lambda x: x)()()()()
    assert Lazy(fn) != Lazy(lambda x: x)()()()()()
    assert Lazy(fn) != Lazy(lambda x: x)()()()()()()
    assert Lazy(fn) != Lazy(lambda x: x)()()()()()()()

# Generated at 2022-06-18 01:41:20.615074
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(x):
        return x + 1

    def add_box(x):
        return Box(x + 1)

    def add_maybe(x):
        return Maybe.just(x + 1)

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_box)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_maybe)) == Lazy.of(2)



# Generated at 2022-06-18 01:41:30.233336
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn_1():
        return 1

    def fn_2():
        return 2

    lazy_1 = Lazy(fn_1)
    lazy_2 = Lazy(fn_1)
    lazy_3 = Lazy(fn_2)
    lazy_4 = Lazy(fn_2)
    lazy_5 = Lazy(fn_1)
    lazy_5.get()

    assert lazy_1 == lazy_2
    assert lazy_3 == lazy_4
    assert lazy_1 != lazy_3
    assert lazy_1 != lazy_5
    assert lazy_2 != lazy_5
    assert lazy_3 != lazy_5


# Generated at 2022-06-18 01:41:33.835630
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    def fn2():
        return 2

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)



# Generated at 2022-06-18 01:41:44.464183
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:41:50.030066
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2



# Generated at 2022-06-18 01:41:59.157103
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:42:09.632244
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()

# Generated at 2022-06-18 01:42:19.791571
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:42:30.696771
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()

# Generated at 2022-06-18 01:42:42.347791
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x

    lazy = Lazy(fn)
    lazy_copy = Lazy(fn)
    lazy_copy_2 = Lazy(fn)
    lazy_copy_3 = Lazy(fn)
    lazy_copy_4 = Lazy(fn)
    lazy_copy_5 = Lazy(fn)
    lazy_copy_6 = Lazy(fn)
    lazy_copy_7 = Lazy(fn)
    lazy_copy_8 = Lazy(fn)
    lazy_copy_9 = Lazy(fn)
    lazy_copy_10 = Lazy

# Generated at 2022-06-18 01:42:52.213708
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy.of(1).bind(fn).get() == 2
    assert Lazy.of(1).bind(fn).to_box().get() == 2
    assert Lazy.of(1).bind(fn).to_either().get() == 2
    assert Lazy.of(1).bind(fn).to_maybe().get() == 2
    assert Lazy.of(1).bind(fn).to_try().get() == 2
    assert Lazy.of(1).bind(fn).to_validation().get

# Generated at 2022-06-18 01:42:55.511574
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 2).get() == 2
    assert Lazy(lambda: 3).get() == 3



# Generated at 2022-06-18 01:43:03.262022
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return value

    def fn2(value):
        return value

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)
    assert Lazy(fn) != Try.of(fn)
    assert Lazy(fn) != Validation.success(fn)
    assert Lazy(fn) != None



# Generated at 2022-06-18 01:43:09.639462
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    from pymonet.monad_try import Try

    def fn():
        return Try.of(lambda: 1)

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda: 1)
    assert Lazy(fn) != Lazy(lambda: Try.of(lambda: 2))
    assert Lazy(fn) != Lazy(lambda: Try.of(lambda: 1).map(lambda x: x + 1))



# Generated at 2022-06-18 01:43:20.550439
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:43:25.552264
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:43:32.598771
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1.0)
    assert Lazy.of(1) != Lazy.of('1')
    assert Lazy.of(1) != Lazy.of(True)
    assert Lazy.of(1) != Lazy.of(None)
    assert Lazy.of(1) != Lazy.of([1])
    assert Lazy.of(1) != Lazy.of((1,))
    assert Lazy.of(1) != Lazy.of({1})
    assert Lazy.of(1) != Lazy.of({'1': 1})

# Generated at 2022-06-18 01:43:41.733024
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.maybe import Maybe

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12


# Generated at 2022-06-18 01:43:52.779809
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_to_box(x):
        return Box(x + 1)

    def add_to_either(x):
        return Right(x + 1)

    def add_to_maybe(x):
        return Maybe.just(x + 1)

    def add_to_try(x):
        return Try.of(lambda: x + 1)

    def add_to_validation(x):
        return Validation.success(x + 1)

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy

# Generated at 2022-06-18 01:44:02.835877
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(a, b):
        return a + b

    def add_lazy(a):
        return Lazy(lambda b: add(a, b))

    assert Lazy.of(1).ap(Lazy.of(add_lazy)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_lazy)).ap(Lazy.of(2)) == Lazy.of(3)
    assert Lazy.of(1).ap(Lazy.of(add_lazy)).ap(Lazy.of(2)).ap(Lazy.of(3)) == Lazy.of(6)

# Generated at 2022-06-18 01:44:05.557409
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:44:16.217340
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return Lazy.of(value)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).to_box() == Box(1)
    assert Lazy.of(1).bind(fn).to_either() == Right(1)
    assert Lazy.of(1).bind(fn).to_maybe() == Maybe.just(1)
    assert Lazy.of(1).bind(fn).to_try() == Try.of(lambda: 1)

# Generated at 2022-06-18 01:44:19.064513
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(add_one).get() == 2


# Generated at 2022-06-18 01:44:27.520803
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).get()
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()

# Generated at 2022-06-18 01:44:41.569670
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(fn)
    lazy4 = Lazy(fn)

    assert lazy == lazy2
    assert lazy == lazy3
    assert lazy == lazy4

    lazy2.get()
    lazy3.get()
    lazy4.get()

    assert lazy == lazy2
    assert lazy == lazy3
    assert lazy == lazy4



# Generated at 2022-06-18 01:44:48.250658
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    assert Lazy.of(1).bind(add_one).get() == 2
    assert Lazy.of(1).bind(add_one).bind(add_one).get() == 3
    assert Lazy.of(1).bind(add_one).bind(add_one).bind(add_one).get() == 4
    assert Lazy.of(1).bind(add_one).bind(add_one).bind(add_one).bind(add_one).get() == 5


# Generated at 2022-06-18 01:44:55.233516
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    lazy_add_one = Lazy(add_one)
    lazy_add_two = Lazy(add_two)

    assert lazy_add_one.bind(lambda x: lazy_add_two) == Lazy(lambda: add_two(add_one(0)))
    assert lazy_add_one.bind(lambda x: lazy_add_two).get(0) == 3


# Generated at 2022-06-18 01:44:57.694891
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:45:09.137584
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:45:18.154082
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:45:30.153942
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(value):
        return Lazy.of(value)

    assert Lazy(lambda: 1).bind(fn) == Lazy.of(1)
    assert Lazy(lambda: 1).bind(fn).bind(fn) == Lazy.of(1)
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn) == Lazy.of(1)

    assert Lazy(lambda: 1).bind(fn).to_box() == Box(1)
    assert Lazy(lambda: 1).bind(fn).to_either() == Right(1)
    assert L

# Generated at 2022-06-18 01:45:40.878206
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:45:50.564333
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:46:00.996479
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy1 == lazy2

    lazy1.get()
    lazy2.get()

    assert lazy1 == lazy2

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy1 != lazy2

    lazy1.get()
    lazy2.get()

    assert lazy1 == lazy2

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy1 != lazy2

    lazy1.get()
    lazy2.get()

    assert lazy1 == lazy2

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy1 != lazy2

    lazy1.get()
    lazy2.get

# Generated at 2022-06-18 01:46:23.393347
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4


# Generated at 2022-06-18 01:46:33.973864
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(value):
        return Lazy(lambda: value + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:46:40.513863
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:46:51.382314
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return

# Generated at 2022-06-18 01:46:57.282287
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def fn(x):
        return Lazy(lambda: x)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).get() == 1
    assert Lazy.of(1).bind(fn).to_box() == Box(1)
    assert Lazy.of(1).bind(fn).to_maybe() == Maybe.just(1)



# Generated at 2022-06-18 01:47:07.084436
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:47:14.142287
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(lambda: 1)
    assert Lazy.of(1) != Lazy.of(lambda: 2)
    assert Lazy.of(lambda: 1) != Lazy.of(lambda: 1)
    assert Lazy.of(lambda: 1) != Lazy.of(lambda: 2)
    assert Lazy.of(lambda: 1) != Lazy.of(1)
    assert Lazy.of(lambda: 2) != Lazy.of(1)
    assert Lazy.of(lambda: 1) != Lazy.of(lambda: 2)

# Generated at 2022-06-18 01:47:20.170627
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    def fn2(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).ap(Lazy(fn))
    assert Lazy(fn) != Lazy(fn).bind(lambda x: Lazy(fn))


# Generated at 2022-06-18 01:47:27.691611
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()
    assert Lazy.of

# Generated at 2022-06-18 01:47:32.937147
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn_a():
        return 'a'

    def fn_b():
        return 'b'

    assert Lazy(fn_a) == Lazy(fn_a)
    assert Lazy(fn_a) != Lazy(fn_b)
    assert Lazy(fn_a) != 'a'
    assert Lazy(fn_a) != None



# Generated at 2022-06-18 01:48:19.012091
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    assert Lazy(lambda: 1).ap(Lazy(lambda: add)).get() == 2
    assert Lazy(lambda: 1).ap(Lazy(lambda: add_one)).get() == 2
    assert Lazy(lambda: 1).ap(Box(add)).get() == 2
    assert Lazy(lambda: 1).ap(Maybe.just(add)).get() == 2
    assert Lazy(lambda: 1).ap(Maybe.nothing()).get() == 1


# Generated at 2022-06-18 01:48:21.929915
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:48:31.010154
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    def fn3(x):
        return x + 3

    def fn4(x):
        return x + 4

    def fn5(x):
        return x + 5

    def fn6(x):
        return x + 6

    def fn7(x):
        return x + 7

    def fn8(x):
        return x + 8

    def fn9(x):
        return x + 9

    def fn10(x):
        return x + 10


# Generated at 2022-06-18 01:48:35.845023
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    assert Lazy.of(add).ap(Box(1)).ap(Box(2)).get() == 3
    assert Lazy.of(add_one).ap(Maybe.just(1)).get() == 2
    assert Lazy.of(add_one).ap(Maybe.nothing()).get() == None


# Generated at 2022-06-18 01:48:43.055619
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:48:45.746715
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn():
        return 1

    lazy = Lazy(fn)
    assert lazy.get() == 1
    assert lazy.get() == 1
    assert lazy.is_evaluated is True


# Generated at 2022-06-18 01:48:51.689767
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(value):
        return Lazy(lambda: value + 1)

    assert Lazy(lambda: 1).bind(add_one).get() == 2
    assert Lazy(lambda: 1).bind(add_one).bind(add_one).get() == 3
    assert Lazy(lambda: 1).bind(add_one).bind(add_one).bind(add_one).get() == 4


# Generated at 2022-06-18 01:49:02.174302
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:49:10.577135
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:49:15.886897
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():  # pragma: no cover
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()
    assert Lazy.of(1) != Lazy.of(1).to_maybe()