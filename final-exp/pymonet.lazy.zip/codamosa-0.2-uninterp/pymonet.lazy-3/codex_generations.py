

# Generated at 2022-06-18 01:40:29.543004
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 'value'

    lazy = Lazy(fn)
    assert lazy == lazy
    assert lazy == Lazy(fn)
    assert lazy != Lazy(lambda: 'other value')
    assert lazy != Lazy(lambda: 'value')
    assert lazy != Lazy(lambda: 'value', is_evaluated=True)
    assert lazy != Lazy(lambda: 'value', is_evaluated=False)
    assert lazy != Lazy(lambda: 'value', is_evaluated=True, value='value')
    assert lazy != Lazy(lambda: 'value', is_evaluated=False, value='value')
    assert lazy != Lazy(lambda: 'value', is_evaluated=True, value='other value')

# Generated at 2022-06-18 01:40:40.796509
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy.of(lambda x: x + 1).ap(Lazy.of(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Box(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Right(1)) == Lazy.of(2)
    assert Lazy.of(lambda x: x + 1).ap(Maybe.just(1)) == Lazy.of(2)

# Generated at 2022-06-18 01:40:45.385763
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    """
    Unit test for method bind of class Lazy
    """
    def add_one(value):
        return Lazy(lambda: value + 1)

    lazy = Lazy(lambda: 1)
    assert lazy.bind(add_one).get() == 2

# Generated at 2022-06-18 01:40:51.355147
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    assert Lazy.of(1).map(add_one).get() == 2
    assert Lazy.of(1).map(add_one).map(add_two).get() == 3
    assert Lazy.of(1).map(add_one).map(add_two).map(add_one).get() == 4


# Generated at 2022-06-18 01:40:58.039438
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.monad_maybe import Maybe

    def add(x):
        return lambda y: x + y

    lazy_add = Lazy(add)
    lazy_add_1 = lazy_add.ap(Maybe.just(1))
    assert lazy_add_1.get() == 2
    assert lazy_add_1.get() == 2

    lazy_add_2 = lazy_add.ap(Maybe.just(2))
    assert lazy_add_2.get() == 3
    assert lazy_add_2.get() == 3

    lazy_add_3 = lazy_add.ap(Maybe.nothing())
    assert lazy_add_3.get() == None
    assert lazy_add_3.get() == None



# Generated at 2022-06-18 01:41:10.832126
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:41:18.134724
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:41:21.423788
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(*args):
        return args

    lazy = Lazy(test_fn)
    assert lazy.get(1, 2, 3) == (1, 2, 3)



# Generated at 2022-06-18 01:41:33.201485
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy(lambda: 1).map(lambda x: x + 1).get() == 2
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy(lambda: 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:41:37.308922
# Unit test for method get of class Lazy
def test_Lazy_get():
    def add(a, b):
        return a + b

    lazy = Lazy(add)

    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3
    assert lazy.get(1, 2) == 3



# Generated at 2022-06-18 01:41:49.829497
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:41:58.875403
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1).map(lambda x: x + 1) != Lazy.of(1)
    assert Lazy.of(1).map(lambda x: x + 1) == Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1).map(lambda x: x + 1) != Lazy.of(1).map(lambda x: x + 2)
    assert Lazy.of(1).map(lambda x: x + 1) != Lazy.of(2).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:42:05.570471
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)
    lazy3 = Lazy(fn)
    lazy4 = Lazy(fn)

    lazy1._compute_value()
    lazy2._compute_value()
    lazy3._compute_value()
    lazy4._compute_value()

    assert lazy1 == lazy2
    assert lazy2 == lazy3
    assert lazy3 == lazy4
    assert lazy4 == lazy1



# Generated at 2022-06-18 01:42:08.438955
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:42:12.618845
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(value):
        return value + 1

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2


# Generated at 2022-06-18 01:42:21.793749
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    def fn2(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(fn2)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map(lambda x: x).map(lambda x: x).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x).map

# Generated at 2022-06-18 01:42:32.111519
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(1) == 1
    assert Lazy.of(1).get(1, 2) == 1
    assert Lazy.of(1).get(1, 2, 3) == 1
    assert Lazy.of(1).get(1, 2, 3, 4) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(1, 2, 3, 4, 5, 6, 7, 8) == 1
   

# Generated at 2022-06-18 01:42:39.226915
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy.of(x * 2)

    assert Lazy.of(2).bind(fn).get() == 4
    assert Lazy.of(2).bind(fn).bind(fn).get() == 8
    assert Lazy.of(2).bind(fn).bind(fn).bind(fn).get() == 16
    assert Lazy.of(2).bind(fn).bind(fn).bind(fn).bind(fn).get() == 32


# Generated at 2022-06-18 01:42:42.829864
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(value):
        return value + 1

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2


# Generated at 2022-06-18 01:42:52.679659
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x - 1).map(lambda x: x + 1).map(lambda x: x - 1)
   

# Generated at 2022-06-18 01:43:09.320355
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()

# Generated at 2022-06-18 01:43:15.478667
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 5

# Generated at 2022-06-18 01:43:19.831420
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn1():
        return 1

    def fn2():
        return 2

    lazy1 = Lazy(fn1)
    lazy2 = Lazy(fn1)
    lazy3 = Lazy(fn2)

    assert lazy1 == lazy2
    assert lazy1 != lazy3
    assert lazy2 != lazy3



# Generated at 2022-06-18 01:43:29.370425
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:43:39.346685
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:43:49.419548
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy(lambda: 1).get() == 1
    assert Lazy(lambda: 1).get(1) == 1
    assert Lazy(lambda x: x).get(1) == 1
    assert Lazy(lambda x: x).get(1, 2) == 1
    assert Lazy(lambda x, y: x + y).get(1, 2) == 3
    assert Lazy(lambda x, y: x + y).get(1, 2, 3) == 3
    assert Lazy(lambda x, y, z: x + y + z).get(1, 2, 3) == 6
    assert Lazy(lambda x, y, z: x + y + z).get(1, 2, 3, 4) == 6



# Generated at 2022-06-18 01:43:56.719578
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).get() == 2
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 3
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)).get() == 4


# Generated at 2022-06-18 01:44:05.995094
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:44:12.574014
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5


# Generated at 2022-06-18 01:44:23.060187
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2
    assert Lazy(lambda: 1).bind(fn).bind(fn).get() == 3
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).get() == 4
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).get() == 5
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 6
    assert Lazy(lambda: 1).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).bind(fn).get() == 7

# Generated at 2022-06-18 01:44:33.612733
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).get() == 4
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x * 2).map(lambda x: x + 1).get() == 5


# Generated at 2022-06-18 01:44:40.403250
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn():
        return 1

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy1 == lazy2

    lazy1.get()
    lazy2.get()

    assert lazy1 == lazy2

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy1 == lazy2

    lazy1.get()
    lazy2.get()

    assert lazy1 == lazy2

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy1 == lazy2

    lazy1.get()
    lazy2.get()

    assert lazy1 == lazy2

    lazy1 = Lazy(fn)
    lazy2 = Lazy(fn)

    assert lazy1 == lazy2

    lazy1.get()
    lazy2.get

# Generated at 2022-06-18 01:44:44.283909
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:44:55.147814
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:45:00.625666
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).get()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()

# Generated at 2022-06-18 01:45:04.344111
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add(a, b):
        return a + b

    def mult(a, b):
        return a * b

    def add_mult(a, b, c):
        return a + b * c

    assert Lazy(add).map(mult).map(add_mult).get(1, 2, 3) == 9
    assert Lazy(add).map(mult).map(add_mult).get(1, 2, 3) == 9
    assert Lazy(add).map(mult).map(add_mult).get(1, 2, 3) == 9


# Generated at 2022-06-18 01:45:14.325918
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(x):
        return x + 1

    lazy = Lazy(test_fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1)

# Generated at 2022-06-18 01:45:19.461117
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))



# Generated at 2022-06-18 01:45:23.404260
# Unit test for method get of class Lazy
def test_Lazy_get():
    def fn(x):
        return x + 1

    lazy = Lazy(fn)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2



# Generated at 2022-06-18 01:45:34.235058
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def fn(x):
        return x

    assert Lazy(fn) == Lazy(fn)
    assert Lazy(fn) != Lazy(lambda x: x)
    assert Lazy(fn) != Lazy.of(1)
    assert Lazy(fn) != Lazy(fn).map(lambda x: x)
    assert Lazy(fn) != Lazy(fn).ap(Lazy(fn))
    assert Lazy(fn) != Lazy(fn).bind(lambda x: Lazy(fn))
    assert Lazy(fn) != Lazy(fn).get()
    assert Lazy(fn) != Lazy(fn).to_box()
    assert Lazy(fn) != Lazy(fn).to_either()
    assert Lazy(fn) != Lazy(fn).to_maybe()

# Generated at 2022-06-18 01:45:49.111226
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(x):
        return x

    def g(x):
        return x

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(g)
    assert Lazy(f) != Lazy(f).map(lambda x: x)
    assert Lazy(f) != Lazy(f).map(lambda x: x).map(lambda x: x)
    assert Lazy(f) != Lazy(f).map(lambda x: x).map(lambda x: x).map(lambda x: x)
    assert Lazy(f) != Lazy(f).map(lambda x: x).map(lambda x: x).map(lambda x: x).map(lambda x: x)

# Generated at 2022-06-18 01:45:51.277310
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2

# Generated at 2022-06-18 01:45:55.250861
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).get() == 2
    assert Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1)).bind(lambda x: Lazy(lambda: x + 1)).get() == 3


# Generated at 2022-06-18 01:46:07.061135
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(1).get(2) == 1
    assert Lazy.of(1).get(2, 3) == 1
    assert Lazy.of(1).get(2, 3, 4) == 1
    assert Lazy.of(1).get(2, 3, 4, 5) == 1
    assert Lazy.of(1).get(2, 3, 4, 5, 6) == 1
    assert Lazy.of(1).get(2, 3, 4, 5, 6, 7) == 1
    assert Lazy.of(1).get(2, 3, 4, 5, 6, 7, 8) == 1
    assert Lazy.of(1).get(2, 3, 4, 5, 6, 7, 8, 9) == 1
   

# Generated at 2022-06-18 01:46:09.902133
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:46:17.895129
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda x: x).__eq__(Lazy(lambda x: x))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x + 1))
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).to_box())
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).to_either())
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).to_maybe())
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).to_try())
    assert not Lazy(lambda x: x).__eq__(Lazy(lambda x: x).to_validation())

# Generated at 2022-06-18 01:46:25.932968
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).ap(Lazy.of(lambda x: x + 1))
    assert Lazy.of(1) != Lazy.of(1).bind(lambda x: Lazy.of(x + 1))
    assert Lazy.of(1) != Lazy.of(1).get()
    assert Lazy.of(1) != Lazy.of(1).to_box()
    assert Lazy.of(1) != Lazy.of(1).to_either()

# Generated at 2022-06-18 01:46:32.288725
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_fn(x):
        return x

    assert Lazy(test_fn).get(1) == 1
    assert Lazy(test_fn).get(1) == 1
    assert Lazy(test_fn).get(2) == 2
    assert Lazy(test_fn).get(2) == 2
    assert Lazy(test_fn).get(1) == 1


# Generated at 2022-06-18 01:46:34.986626
# Unit test for method get of class Lazy
def test_Lazy_get():
    def test_function(x):
        return x + 1

    lazy = Lazy(test_function)
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2
    assert lazy.get(1) == 2


# Generated at 2022-06-18 01:46:37.133609
# Unit test for method get of class Lazy
def test_Lazy_get():
    assert Lazy.of(1).get() == 1
    assert Lazy.of(2).get() == 2
    assert Lazy.of(3).get() == 3


# Generated at 2022-06-18 01:46:54.188899
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_function(x):
        return x + 1

    def test_function_with_error(x):
        if x == 1:
            raise ValueError('error')
        return x + 1

    def test_function_with_validation_error(x):
        if x == 1:
            return Validation.failure(['error'])
        return Validation.success(x + 1)

    def test_function_with_maybe_error(x):
        if x == 1:
            return Maybe.nothing()
        return Maybe.just(x + 1)


# Generated at 2022-06-18 01:46:58.677284
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7



# Generated at 2022-06-18 01:47:05.033038
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    assert Lazy.of(2).ap(Box(lambda x: x + 1)) == Box(3)
    assert Lazy.of(2).ap(Maybe.just(lambda x: x + 1)) == Maybe.just(3)
    assert Lazy.of(2).ap(Right(lambda x: x + 1)) == Right(3)


# Generated at 2022-06-18 01:47:12.518535
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy.of(1) == Lazy.of(1)
    assert Lazy.of(1) != Lazy.of(2)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy.of(1) != Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
   

# Generated at 2022-06-18 01:47:21.054559
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return x + 1

    def fn2(x):
        return x + 2

    def fn3(x):
        return x + 3

    def fn4(x):
        return x + 4

    def fn5(x):
        return x + 5

    def fn6(x):
        return x + 6

    def fn7(x):
        return x + 7

    def fn8(x):
        return x + 8

    def fn9(x):
        return x + 9

    def fn10(x):
        return x + 10


# Generated at 2022-06-18 01:47:25.242767
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    assert Lazy.of(add).ap(Box(1)).ap(Box(2)).get() == 3
    assert Lazy.of(add).ap(Maybe.just(1)).ap(Maybe.just(2)).get() == 3

# Generated at 2022-06-18 01:47:28.065947
# Unit test for method map of class Lazy
def test_Lazy_map():
    assert Lazy.of(1).map(lambda x: x + 1).get() == 2
    assert Lazy.of(1).map(lambda x: x + 1).map(lambda x: x + 1).get() == 3


# Generated at 2022-06-18 01:47:32.643909
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy(add_one).map(add_two).map(add_three).get(1) == 7


# Generated at 2022-06-18 01:47:41.472545
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return Lazy.of(x + 1)

    def add_two(x):
        return Lazy.of(x + 2)

    def add_three(x):
        return Lazy.of(x + 3)

    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7
    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7
    assert Lazy.of(1).bind(add_one).bind(add_two).bind(add_three).get() == 7



# Generated at 2022-06-18 01:47:52.115209
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_to_box(a):
        return Box(add(a, 1))

    def add_to_either(a):
        return Right(add(a, 1))

    def add_to_maybe(a):
        return Maybe.just(add(a, 1))

    def add_to_try(a):
        return Try.of(add, a, 1)

    def add_to_validation(a):
        return Validation.success(add(a, 1))


# Generated at 2022-06-18 01:48:10.545910
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:48:15.657075
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:48:20.242968
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:48:23.393908
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2



# Generated at 2022-06-18 01:48:27.987762
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:48:33.284798
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    def add(x):
        return x + 1

    def add_lazy(x):
        return Lazy(lambda: x + 1)

    assert Lazy.of(1).ap(Lazy.of(add)) == Lazy.of(2)
    assert Lazy.of(1).ap(Lazy.of(add_lazy)) == Lazy.of(2)


# Generated at 2022-06-18 01:48:36.837894
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def fn(x):
        return Lazy(lambda: x + 1)

    assert Lazy(lambda: 1).bind(fn).get() == 2


# Generated at 2022-06-18 01:48:43.449587
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:48:53.144167
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:49:04.398619
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn(x):
        return Lazy(lambda: x)

    assert Lazy.of(1).bind(fn) == Lazy.of(1)
    assert Lazy.of(1).bind(fn).bind(fn) == Lazy.of(1)

    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(2)
    assert Lazy.of(1).bind(lambda x: Lazy.of(x + 1)).bind(lambda x: Lazy.of(x + 1)) == Lazy.of(3)


# Generated at 2022-06-18 01:49:27.966332
# Unit test for method map of class Lazy
def test_Lazy_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Lazy.of(1).map(add_one).map(add_two).map(add_three).get() == 7


# Generated at 2022-06-18 01:49:35.650283
# Unit test for method ap of class Lazy
def test_Lazy_ap():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8


# Generated at 2022-06-18 01:49:46.517345
# Unit test for method bind of class Lazy
def test_Lazy_bind():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 01:49:55.946032
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x, y):
        return x + y

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8


# Generated at 2022-06-18 01:50:03.111939
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    def f(x):
        return x + 1

    def g(x):
        return x + 2

    assert Lazy(f) == Lazy(f)
    assert Lazy(f) != Lazy(g)
    assert Lazy(f) != Lazy(f).map(lambda x: x + 1)
    assert Lazy(f) != Lazy(f).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(f) != Lazy(f).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)
    assert Lazy(f) != Lazy(f).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1)

# Generated at 2022-06-18 01:50:11.733909
# Unit test for method map of class Lazy
def test_Lazy_map():
    from pymonet.box import Box

    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Lazy(lambda: 1).map(add_one).map(add_two).map(add_three).get() == 7
    assert Lazy(lambda: 1).map(add_one).map(add_two).map(add_three).to_box().get() == 7
    assert Lazy(lambda: 1).map(add_one).map(add_two).map(add_three).to_either().get() == 7
    assert Lazy(lambda: 1).map(add_one).map(add_two).map(add_three).to_maybe().get() == 7
    assert Lazy

# Generated at 2022-06-18 01:50:20.842818
# Unit test for method __eq__ of class Lazy
def test_Lazy___eq__():
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).map(lambda x: x + 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 1).bind(lambda x: Lazy(lambda: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).ap(Lazy(lambda: lambda x: x + 1))
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_box()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_either()
    assert Lazy(lambda: 1) != Lazy(lambda: 1).to_maybe()