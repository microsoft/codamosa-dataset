

# Generated at 2022-06-24 05:53:21.575788
# Unit test for function match
def test_match():
    os.path.isdir = lambda x: True
    assert match(Command('cat some_directory', 'cat: some_directory: Is a directory'))
    assert not match(Command('cat some_directory', 'cat: some_directory: Is a file'))
    assert not match(Command('hello', 'cat: some_directory: Is a directory'))
    

# Generated at 2022-06-24 05:53:23.432896
# Unit test for function get_new_command
def test_get_new_command():
    res = get_new_command('')
    assert res == ''


# Unittest for function match

# Generated at 2022-06-24 05:53:25.923666
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /somewhere') == 'ls /somewhere'


# Generated at 2022-06-24 05:53:28.150403
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', ''))

# Generated at 2022-06-24 05:53:29.824275
# Unit test for function match
def test_match():
	assert match(Command('cat /tmp/hello', '')) == True


# Generated at 2022-06-24 05:53:33.793312
# Unit test for function match
def test_match():
    assert match(Command('cat example.txt'))
    assert not match(Command('ls example.txt'))
    assert not match(Command('cat example.txt example.txt'))
    assert match(Command('cat example/'))
    assert not match(Command('cat example'))
    assert not match(Command('cat example.txt example/'))


# Generated at 2022-06-24 05:53:37.052297
# Unit test for function get_new_command
def test_get_new_command():
    command_old = Command("cat /etc/hosts")
    command_new = get_new_command(command_old)
    assert command_new.script == "ls /etc/hosts"

# Generated at 2022-06-24 05:53:39.039306
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat foo') == 'ls foo'

# Generated at 2022-06-24 05:53:41.108834
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /etc') == 'ls /etc'


# Generated at 2022-06-24 05:53:42.247206
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/postgresql'))


# Generated at 2022-06-24 05:53:46.263608
# Unit test for function match
def test_match():
    assert match(Command(script='cat filename'))
    assert match(Command(script='cat *'))
    assert match(Command(script='cat folder'))
    assert not match(Command(script='cat .vimrc'))
    assert not match(Command(script='cat', output='cat: No such file or directory'))



# Generated at 2022-06-24 05:53:49.801603
# Unit test for function match
def test_match():
    assert match(Command('cat',
                         'cat: /tmp/dir/: Is a directory',
                         '/tmp/dir/'))
    assert not match(Command('cat', 'cat: No such file or directory', '/tmp/dir/'))


# Generated at 2022-06-24 05:53:51.177977
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("cat /")) == "ls /"


# Generated at 2022-06-24 05:53:55.315920
# Unit test for function match
def test_match():
    output = 'cat: tmp: Is a directory'
    parts = ['cat', 'tmp']
    os.path.isdir = lambda x: True
    assert match(Command(script='cat tmp', output=output, script_parts=parts))



# Generated at 2022-06-24 05:54:01.806993
# Unit test for function match
def test_match():
    #assert match(Command('cat hey.txt', 'cat: hey.txt: Is a directory'))
    assert match(Command('cat hello.txt', 'cat: hello.txt: Is a directory'))
    assert not match(Command('cat hey.txt', 'cat: hey.txt: No such file or directory'))
    assert not match(Command('ls hey.txt', 'ls: hey.txt: Is a directory'))
    assert not match(Command('ls hey.txt', 'ls: hey.txt: No such file or directory'))


# Generated at 2022-06-24 05:54:04.230608
# Unit test for function get_new_command
def test_get_new_command():
    from mock import Mock
    command = Mock(script='cat filex',
                   script_parts=['cat', 'filex'])
    assert get_new_command(command) == 'ls filex'

# Generated at 2022-06-24 05:54:09.618087
# Unit test for function match
def test_match():
    assert match(Command('cat /home/thiago', '', 'cat: /home/thiago: Is a directory\n'))
    assert not match(Command('ls /home/thiago', '', 'cat: /home/thiago: Is a directory\n'))
    assert not match(Command('cat /home/thiago', '', ''))


# Generated at 2022-06-24 05:54:12.576064
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /tmp/',
        output = """cat: '/tmp/': Is a directory"""
    )

    assert get_new_command(command) == "ls /tmp/"

# Generated at 2022-06-24 05:54:15.383136
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat lol', 'cat: lol: Is a directory')) == 'ls lol'


# Generated at 2022-06-24 05:54:16.400739
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat Documents", "cat: Documents: Is a directory\n")
    assert get_new_command(command) == "ls Documents"


# Generated at 2022-06-24 05:54:19.645400
# Unit test for function match
def test_match():
    command = Command('cat some_file.txt', '', 'cat: some_file.txt: Is a directory')
    assert match(command)


# Generated at 2022-06-24 05:54:21.855584
# Unit test for function get_new_command
def test_get_new_command():
    c = Command('cat test', 'cat: test: Is a directory')
    assert get_new_command(c) == 'ls test'

# Generated at 2022-06-24 05:54:25.173692
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat /path/to/dir'
    new_command = get_new_command(command)
    assert new_command == 'ls /path/to/dir'

# Generated at 2022-06-24 05:54:28.482153
# Unit test for function match
def test_match():
    # Test if it returns False because the file is not a directory
    assert match(Command('cat /test/test.txt', '')) == False
    # Test if it returns True if first parameter is a directory
    assert match(Command('cat /test/', '')) == True


# Generated at 2022-06-24 05:54:30.088835
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /Documents', '/Documents: is a directory')
    assert get_new_command(command) == 'ls /Documents'

# Generated at 2022-06-24 05:54:32.168036
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat readme.md', 'cat: readme.md: Is a directory')
    assert get_new_command(command) == 'ls readme.md'

# Generated at 2022-06-24 05:54:35.891348
# Unit test for function match
def test_match():
    assert match(Command('cat file1.txt', 'cat: file1.txt: Is a directory',
                         '', ''))
    assert not match(Command('cat file1.txt', '', '', ''))

# Generated at 2022-06-24 05:54:38.456500
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test') == "ls test"
    assert get_new_command('cat path/test') == "ls path/test"

# Generated at 2022-06-24 05:54:40.827480
# Unit test for function match
def test_match():
    command = Command('cat ~/Desktop')
    assert match(command)
    command = Command('cat Desktop')
    assert match(command)
    command = Command('cat -l ~/Desktop')
    assert match(command)
    assert not match(Command('ls ~/Desktop'))
    assert not match(Command('cat test.txt'))


# Generated at 2022-06-24 05:54:43.474864
# Unit test for function match
def test_match():
    assert(match(Command('cat .', 'cat: .: Is a directory', '', '')) == True)
    assert(match(Command('cat .', 'cat: .: No such file or directory', '', '')) == False)


# Generated at 2022-06-24 05:54:48.006779
# Unit test for function match
def test_match():
    assert match(Command(script='cat filename.txt'))
    assert not match(Command(script='cat filename.txt > output.txt'))
    assert not match(Command(script='ls filename.txt'))
    assert match(Command(script='cat dirname'))


# Generated at 2022-06-24 05:54:50.867924
# Unit test for function match
def test_match():
    assert match(Command('cat aaa', 'cat: aaa: Is a directory')) == True
    assert match(Command('cat aaa/bbb', 'cat: aaa/bbb: No such file or directory')) == False


# Generated at 2022-06-24 05:54:53.014851
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    assert get_new_command(Command(script='cat docs', output='cat: docs: Is a directory')) == 'ls docs'

# Generated at 2022-06-24 05:54:55.869006
# Unit test for function match
def test_match():
    command = Command('cat log', 'cat: log: Is a directory')
    assert(match(command))

    command = Command('cat log', 'cat: log: Is not a directory')
    assert(not match(command))
    command = Command('cat log', 'cat: log: No such file or directory')
    assert(not match(command))


# Generated at 2022-06-24 05:54:57.947106
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.ls_directory import get_new_command
    assert get_new_command(u'cat /etc') == u'ls /etc'

# Generated at 2022-06-24 05:55:00.229945
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat /var/log/dpkg.log'
    command_n = 'ls /var/log/dpkg.log'
    assert get_new_command(command) == command_n

# Generated at 2022-06-24 05:55:03.409727
# Unit test for function match
def test_match():
    assert match(Command('cat aaa', 'cat: aaa: Is a directory', ''))
    assert not match(Command('cat aaa', '', ''))


# Generated at 2022-06-24 05:55:06.485191
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_dir import get_new_command
    command = 'cat some_dir'
    assert get_new_command(command) == 'ls some_dir'


# Generated at 2022-06-24 05:55:11.403510
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_dir import get_new_command
    assert get_new_command(Command('cat /script1/script2/script3',
                                   'cat: /script1/script2/script3: Is a directory',
                                   '/script1/script2')) == 'ls /script1/script2/script3'

# Generated at 2022-06-24 05:55:13.724501
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script': 'cat /usr'})()
    assert get_new_command(command) == 'ls /usr'

# Generated at 2022-06-24 05:55:16.177805
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat file.txt') == 'ls file.txt'

# Generated at 2022-06-24 05:55:18.429388
# Unit test for function match
def test_match():
    assert match(Command('cat abc', 'cat: abc: Is a directory'))
    assert not match(Command('cat abc', ''))

# Generated at 2022-06-24 05:55:20.445918
# Unit test for function get_new_command
def test_get_new_command():
    assert 'ls' == get_new_command('cat').split(' ')[0]

# Generated at 2022-06-24 05:55:27.952723
# Unit test for function get_new_command
def test_get_new_command():
    """
    Returns A New Command to Fix Mistakes
    """
    from thefuck.rules.cat import get_new_command

    assert get_new_command("cat abcd") == "ls abcd"
    assert get_new_command("cat --help") == "ls --help"
    assert get_new_command("cat") == "ls"
    assert get_new_command("cat -e") == "ls -e"
    assert get_new_command("cat -n") == "ls -n"
    assert get_new_command("cat -v") == "ls -v"
    assert get_new_command("cat | grep xyz") == "ls | grep xyz"
    assert get_new_command("cat abcd xyz") == "ls abcd xyz"

# Generated at 2022-06-24 05:55:30.659637
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat ~/testdir/", "", "/home/user/testdir/")
    assert get_new_command(command) == "ls ~/testdir/"

# Generated at 2022-06-24 05:55:32.195890
# Unit test for function match
def test_match():
    assert match(Command('cat test_file'))



# Generated at 2022-06-24 05:55:34.528385
# Unit test for function match
def test_match():
    command = Command('cat /proc/uptime', 'cat: /proc/uptime: Is a directory')
    assert match(command)
    

# Generated at 2022-06-24 05:55:36.537700
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat dir', stdout='cat: dir: Is a directory')
    assert get_new_command(command) == 'ls dir'

# Generated at 2022-06-24 05:55:38.055556
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat tests') == 'ls tests'

# Generated at 2022-06-24 05:55:39.656593
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat file')) == 'ls file'


# Generated at 2022-06-24 05:55:43.545301
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat asdasd") == "ls asdasd"
    assert get_new_command("cat path/to/dir") == "ls path/to/dir"
    assert get_new_command("git commit -m 'c'") == "git commit -m 'c'"


# Generated at 2022-06-24 05:55:46.097063
# Unit test for function match
def test_match():
    assert match(Command('cat dir', 'cat: dir: Is a directory'))
    assert not match(Command('cat file', ''))


# Generated at 2022-06-24 05:55:48.701139
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    command = Bash('cat /bin')
    assert get_new_command(command) == command.script.replace('cat', 'ls', 1)



# Generated at 2022-06-24 05:55:50.225146
# Unit test for function match
def test_match():
    command = 'cat git'
    actual = match(command)
    assert actual



# Generated at 2022-06-24 05:55:52.785968
# Unit test for function match
def test_match():
    result = match(Command('cat /etc/hosts'))
    assert result is False
    result = match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory\n'))
    assert result is True



# Generated at 2022-06-24 05:55:59.263024
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat', 'cat file')) == 'ls file'
    assert get_new_command(Command('cat', 'cat -l file')) == 'ls -l file'
    assert get_new_command(Command('cat', 'cat document.doc')) == 'ls document.doc'
    assert get_new_command(Command('cat', 'cat "/usr/share/javascript/jquery/jquery.js"')) == 'ls "/usr/share/javascript/jquery/jquery.js"'
    assert get_new_command(Command('cat', 'cat "folder/file"')) == 'ls "folder/file"'


# Generated at 2022-06-24 05:56:01.585583
# Unit test for function match
def test_match():
    assert match(Command(script='cat /etc/hosts',output='cat: /etc/hosts: Is a directory'))


# Generated at 2022-06-24 05:56:04.939047
# Unit test for function match
def test_match():
    assert match(Command('echo foo | cat bar'))
    assert match(Command('cat bar'))
    assert not match(Command('echo foo | cat'))
    assert not match(Command('eho foo | cat bar'))


# Generated at 2022-06-24 05:56:08.042105
# Unit test for function match
def test_match():
    stderr = 'cat: zero: Is a directory\n'
    command = type('Command', (object,), {
        'output': stderr,
        'script_parts': ['cat', 'zero']})
    assert match(command)

# Generated at 2022-06-24 05:56:10.477130
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat testfile.txt") == "ls testfile.txt"
    assert get_new_command("cat folder") == "ls folder"


# Generated at 2022-06-24 05:56:12.051282
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat ~/.bashrc")
    assert get_new_command(command) == "ls ~/.bashrc"

# Generated at 2022-06-24 05:56:12.980394
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /usr') == 'ls /usr'

# Generated at 2022-06-24 05:56:18.062052
# Unit test for function match
def test_match():
    assert match(Command('cat test',
            output='cat: test: Is a directory\n'))
    assert not match(Command('cat test',
            output='cat: test: No such file or directory\n'))
    assert not match(Command('ls test',
            output='cat: test: No such file or directory\n'))


# Generated at 2022-06-24 05:56:26.966887
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('cat /home/xxx/Desktop', 'cat: /home/xxx/Desktop: Is a directory')
    command2 = Command('cat /home/xxx/Desktop', 'cat: /home/xxx/Desktop: Is a directory', '/home/xxx')
    command3 = Command('cat /home/xxx/Desktop', 'cat: /home/xxx/Desktop: Is a directory', '/home/xxx', 'cat')
    assert get_new_command(command1) == 'ls /home/xxx/Desktop'
    assert get_new_command(command2) == 'ls /home/xxx/Desktop'
    assert get_new_command(command3) == 'ls /home/xxx/Desktop'

# Generated at 2022-06-24 05:56:29.068820
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test.txt') == 'ls test.txt'
    assert get_new_command('cat /usr') == 'ls /usr'


# Generated at 2022-06-24 05:56:36.881392
# Unit test for function match
def test_match():
    import pytest
    assert match(Command("cat foo", "cat: foo: Is a directory")) == True
    assert match(Command("cat", "cat: foo: Is a directory")) == False
    assert match(Command("cat foo", "cat: foo: No such file or directory")) == False
    assert match(Command("cat foo bar", "cat: foo: No such file or directory")) == False
    with pytest.raises(CommandNotFound):
        match(Command("ls foo", "cat: foo: No such file or directory")) == False


# Generated at 2022-06-24 05:56:38.265114
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat /etc/resolv')
    assert get_new_command(command) == 'ls /etc/resolv'



# Generated at 2022-06-24 05:56:39.906312
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', 'cat: file.txt: Is a directory', '', 1))
    assert not match(Command('cp file.txt ../', '', '', 1))



# Generated at 2022-06-24 05:56:40.851735
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command("cat") == "ls"

# Generated at 2022-06-24 05:56:45.911075
# Unit test for function match
def test_match():
    assert match(Command('cat test.txt'))
    assert match(Command('cat test'))
    assert match(Command('cat test/'))
    assert not match(Command('cat'))
    assert not match(Command('cat test.md'))
    assert not match(Command('cat test.txt > output.txt'))


# Generated at 2022-06-24 05:56:49.854545
# Unit test for function match
def test_match():
    assert match(Command('cat', stderr='cat: something'))
    assert not match(Command('ls', stderr='cat: something'))
    assert not match(Command('cat', stderr='ls: something'))


# Generated at 2022-06-24 05:56:52.214965
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /etc', '/etc')
    expected = 'ls /etc'
    assert get_new_command(command) == expected

# Generated at 2022-06-24 05:56:56.223445
# Unit test for function match
def test_match():
    assert match(Command('cat a b', 'cat: a: Is a directory\ncat: b: Is a directory'))
    assert not match(Command('cat a b', 'cat: a b: Is a directory'))
    assert not match(Command('cat a b', 'cat: a: Is a directory'))

# Generated at 2022-06-24 05:57:00.247449
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp/file', '/tmp/file', '', ''))
    assert not match(Command('ls /tmp/file', '/tmp/file', '', ''))
    assert not match(Command('cat /tmp/file', '/tmp/file', '', '', None, '/tmp'))


# Generated at 2022-06-24 05:57:02.764180
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/',
                         output="cat: /etc/: Is a directory\n"))
    assert not match(Command('cat file.txt',
                             output="file.txt"))


# Generated at 2022-06-24 05:57:05.579729
# Unit test for function match
def test_match():
    assert match(Command('cat test/',
        "cat: test/: Is a directory", "")) is True
    assert match(Command('cat test',
        "", "")) is False


# Generated at 2022-06-24 05:57:10.008647
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', '', ''))
    assert not match(Command('ls -a /etc/passwd', '', ''))
    assert match(Command('cat /bin /usr/bin', '', ''))
    assert not match(Command('cat /bin/ls /usr/bin/gcc', '', ''))


# Generated at 2022-06-24 05:57:12.168683
# Unit test for function get_new_command
def test_get_new_command():
    command = type("obj", (object,), {
        "script": "cat test",
        "script_parts": ["cat", "test"]
    })
    assert get_new_command(command) == "ls test"

# Generated at 2022-06-24 05:57:13.165313
# Unit test for function match
def test_match():
    assert match(Command('cat tests', ''))


# Generated at 2022-06-24 05:57:15.276166
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/xxx',
                         'cat: /etc/xxx: Is a directory\n'))



# Generated at 2022-06-24 05:57:17.131862
# Unit test for function match
def test_match():
    assert match(Command('cat unknown'))
    assert not match(Command('not_cat unknown'))



# Generated at 2022-06-24 05:57:21.997095
# Unit test for function match
def test_match():
    assert match(Command('cat foo', 'cat: foo: Is a directory'))
    assert not match(Command('cat foo', ''))
    assert not match(Command('foo', 'cat: foo: Is a directory'))
    assert not match(Command('ls foo', 'cat: foo: Is a directory'))


# Generated at 2022-06-24 05:57:25.538549
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', ''))
    assert not match(Command('ls test', 'cat: test: Is a directory'))


# Generated at 2022-06-24 05:57:29.396030
# Unit test for function match
def test_match():
    file = 'tests/fixtures/function_match.sh'
    command = 'cat ' + file
    assert(match(Command(command, '', 'cat: ' + file + ': Is a directory')))


# Generated at 2022-06-24 05:57:30.893545
# Unit test for function match
def test_match():
    assert not match(Command('cat', 'blah'))


# Generated at 2022-06-24 05:57:37.818448
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', 'cat: file.txt: Is a directory\n',
        '/bin/cat: file.txt: Is a directory'))
    assert not match(Command('ls', 'cat: file.txt: Is a directory\n',
        '/bin/cat: file.txt: Is a directory'))
    assert not match(Command('cat file.txt', 'cat: file.txt: No such file or directory\n',
        '/bin/cat: file.txt: No such file or directory'))


# Generated at 2022-06-24 05:57:40.035823
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /tmp')
    assert get_new_command(command) == 'ls /tmp'


# Generated at 2022-06-24 05:57:41.024930
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat path | grep arg') == 'ls path | grep arg'

# Generated at 2022-06-24 05:57:42.557481
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat mydirectory') == 'ls mydirectory'

# Generated at 2022-06-24 05:57:46.189257
# Unit test for function match
def test_match():
    assert match(Command('cat Makefile', 'cat: Makefile: Is a directory',''))
    assert not match(Command('cat Makefile', 'Makefile',''))
    assert not match(Command('ls Makefile', 'cat: Makefile: Is a directory',''))
    assert not match(Command('cat Makefile', 'cat: Makefile: No such file or directory',''))


# Generated at 2022-06-24 05:57:53.675883
# Unit test for function match
def test_match():
    command = Command(script='cat a', output="cat: a: Is a directory")
    assert match(command)
    command = Command(script='cat a b', output="cat: a: Is a directory")
    assert not match(command)
    command = Command(script='cat b ', output="cat: b: Is a directory")
    assert match(command)
    command = Command(script=' cat ', output="cat: : Is a directory")
    assert not match(command)


# Generated at 2022-06-24 05:57:54.992251
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /')) == 'ls /'

# Generated at 2022-06-24 05:57:58.054362
# Unit test for function match
def test_match():
    from thefuck.rules.cat_is_directory import match
    assert match(Command('cat foo/bar', 'cat: foo/bar: Is a directory', ''))
    assert not match(Command('cat foo/bar', '', ''))

# Generated at 2022-06-24 05:58:00.664242
# Unit test for function match
def test_match():

    command = Command('cat folder1 folder2', output='cat: folder: Is a directory')

    assert match(command)

# Generated at 2022-06-24 05:58:02.595004
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        'cat /home/user/Documents'
    ) == 'ls /home/user/Documents'

# Generated at 2022-06-24 05:58:06.617583
# Unit test for function match
def test_match():
    # Test regular case
    command1 = 'cat testfile.txt'
    assert match(command1) is False

    # Test the case where the file name is a directory
    command2 = 'cat folder/'
    assert match(command2) is True

    # Test the case where the file name is a directory
    command3 = 'cat other/'
    assert match(command3) is True


# Generated at 2022-06-24 05:58:09.983943
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_cat_is_file import get_new_command
    assert get_new_command('cat README.md') == 'ls README.md'



# Generated at 2022-06-24 05:58:12.366374
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat ./fuck/the/cock') == 'ls ./fuck/the/cock'

# Generated at 2022-06-24 05:58:13.487548
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /home') == 'ls /home'

# Generated at 2022-06-24 05:58:24.080850
# Unit test for function match
def test_match():
    assert_true(match(Command('cat file.txt', 'cat: file.txt: Is a directory', '', '')))
    assert_true(match(Command('cat /', 'cat: /: Is a directory', '', '')))
    assert_true(match(Command('ls | cat > file.txt', 'ls | cat > file.txt: Is a directory', '', '')))
    assert_true(match(Command('cat file.txt', 'cat: file.txt is a directory', '', '')))
    assert_true(match(Command('cat /', 'cat: / is a directory', '', '')))
    assert_true(match(Command('ls | cat > file.txt', 'ls | cat > file.txt is a directory', '', '')))


# Generated at 2022-06-24 05:58:27.525563
# Unit test for function match
def test_match():
    assert match(Command('cat testDirectory',
                         'cat: testDirectory: Is a directory',
                         '', 1))
    assert match(Command('cat testFile.txt',
                         'cat: testFile.txt: Is a directory',
                         '', 1)) is False

# Generated at 2022-06-24 05:58:31.226061
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    output = 'cat: /home/test: Is a directory' + '\n'
    command = Command('cat /home/test', output)
    assert get_new_command(command) == 'ls /home/test'

# Generated at 2022-06-24 05:58:33.029757
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    assert get_new_command('cat ~/Downloads') == 'ls ~/Downloads'

# Generated at 2022-06-24 05:58:34.249588
# Unit test for function match
def test_match():
    _match = match(c('cat test/'))
    assert _match is True



# Generated at 2022-06-24 05:58:39.839370
# Unit test for function match
def test_match():
    assert match(Command('cat file1 file2 file3 file4', 'cat: file1: Is a directory\ncat: file2: Is a directory\n'))
    assert not match(Command('cat file1 file2 file3 file4', 'cat: file1: Is a directory\n'))
    assert not match(Command('cat', ''))

# Generated at 2022-06-24 05:58:41.935815
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /tmp/')        # Unit test command
    assert get_new_command(command) == "ls /tmp/"

# Generated at 2022-06-24 05:58:44.004268
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /usr/bin')) == 'ls /usr/bin'

# Generated at 2022-06-24 05:58:45.752737
# Unit test for function match
def test_match():
    command = Command('cat folder', output='cat: folder: Is a directory')
    assert match(command)


# Generated at 2022-06-24 05:58:47.813354
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat foo', 'cat: foo: Is a directory')) == 'ls foo'

# Generated at 2022-06-24 05:58:51.722870
# Unit test for function match
def test_match():
    assert match(Command(script='cat testfile')) == False
    assert match(Command(script='cat testdir')) == True
    assert match(Command(script='cat')) == False
    assert match(Command(script='cat')) == False



# Generated at 2022-06-24 05:58:54.528522
# Unit test for function match
def test_match():
    assert match(Command('cat a'))
    assert not match(Command('echo fpp', '', '', 2))
    assert not match(Command('cat', '', '', 2))


# Generated at 2022-06-24 05:58:56.983617
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat bar", "cat: bar: Is a directory")
    assert get_new_command(command) == command.script.replace("cat", "ls", 1)

# Generated at 2022-06-24 05:58:59.101010
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat dir', output='cat: dir: Is a directory')) == 'ls dir'

# Generated at 2022-06-24 05:59:02.015826
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test') == 'ls test'
    assert get_new_command('cat test test2') == 'ls test test2'
    assert get_new_command('cat -l test') == 'ls -l test'
    assert get_new_command('cat -l test test2') == 'ls -l test test2'

# Generated at 2022-06-24 05:59:03.434103
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat test") == "ls test"


# Generated at 2022-06-24 05:59:09.716784
# Unit test for function match
def test_match():
    assert(match(Command('cat /home/laozi', 'cat: /home/laozi: Is a directory', os.path.isdir('/home/laozi'))) == True)
    assert(match(Command('cat /home/laozi', 'cat: /home/laozi: No such file or directory', os.path.isdir('/home/laozi'))) == False)


# Generated at 2022-06-24 05:59:11.992372
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat /bin')) == 'ls /bin'

# Generated at 2022-06-24 05:59:13.378938
# Unit test for function match
def test_match():
    assert match(Command('cat /'))


# Generated at 2022-06-24 05:59:18.537610
# Unit test for function get_new_command
def test_get_new_command():
    script = 'cat несуществующая_папка'

    result = get_new_command(Command(script))

    assert result == 'ls несуществующая_папка'

# Generated at 2022-06-24 05:59:22.007565
# Unit test for function get_new_command
def test_get_new_command():
    # test failed command
    command1 = Command('cat sample', 'cat: sample: Is a directory\n')
    # test new command
    out1 = get_new_command(command1)
    assert out1 == 'ls sample'

# Generated at 2022-06-24 05:59:23.786088
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat /etc/apt'
    assert get_new_command(command) == 'ls /etc/apt'

# Generated at 2022-06-24 05:59:27.193613
# Unit test for function match
def test_match():
    assert match(Command('cat test', '', '', 'cat: test: Is a directory', 1))
    assert not match(Command('cat test', '', '', '', 1))
    assert not match(Command('ls test', '', '', '', 1))



# Generated at 2022-06-24 05:59:29.592016
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat folder', '', (
        'cat: folder: Is a directory\n',
        ''))
    assert get_new_command(command) == 'ls folder'

# Generated at 2022-06-24 05:59:32.981267
# Unit test for function match
def test_match():
    assert match(Command('cat test.txt', 'cat: test.txt: Is a directory\n'))
    assert not match(Command('cat test.txt', 'not a dir\n'))

# Generated at 2022-06-24 05:59:35.760892
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /usr/bin/')
    assert get_new_command(command) == 'ls /usr/bin/'



# Generated at 2022-06-24 05:59:38.180010
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("cat a b c", "cat: a: Is a directory")) == \
        "ls a b c"

# Generated at 2022-06-24 05:59:39.351135
# Unit test for function get_new_command
def test_get_new_command():
    new = get_new_command(Command('cat scripts'))
    assert new == 'ls scripts'

# Generated at 2022-06-24 05:59:45.211675
# Unit test for function match
def test_match():
    # when cat is given a directory
    # we should get an output containing
    # 'cat: ' and the second argument of
    # the command is a directory
    assert match.predicate(Command('cat testfolder', 'cat: testfolder: Is a directory\n'))
    # when cat is given a file
    # we should get an output containing
    # 'cat: ' and the second argument of
    # the command is a file
    assert not match.predicate(Command('cat testfile', 'testfile'))
    # when cat is given a string
    # we should get an output containing
    # 'cat: ' and the second argument of
    # the command is a string
    assert not match.predicate(Command('cat teststring', 'cat: teststring: No such file or directory\n'))
    # when cat is not given any

# Generated at 2022-06-24 05:59:48.307887
# Unit test for function match
def test_match():
    assert match(Command('cat test/test-file', ''))
    assert match(Command('cat test/test-dir', ''))
    assert not match(Command('grep test/test-file', ''))


# Generated at 2022-06-24 05:59:50.726183
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory', ''))
    assert not match(Command('echo test', 'test', ''))


# Generated at 2022-06-24 05:59:53.340497
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat test.txt', 'cat: test.txt: Is a directory')) == 'ls test.txt'

# Generated at 2022-06-24 06:00:04.294594
# Unit test for function match
def test_match():
    # Test first command
    assert match(Command('cat invalid-file', 'cat: invalid-file: No such file or directory'))
    # Test second command
    assert match(Command('cat invalid-file', 'cat: invalid-file: Is a directory'))
    # Test third command
    assert not match(Command('cat invalid-file', 'cat: invalid-file: Is a directory\ncat: invalid-file: No such file or directory'))
    # Test fourth command
    assert not match(Command('cat valid-file invalid-file', 'cat: invalid-file: Is a directory\ncat: invalid-file: No such file or directory'))
    # Test fifth command

# Generated at 2022-06-24 06:00:08.441566
# Unit test for function match
def test_match():
    from thefuck.rules.cat_is_directory import match
    assert match(Command('cat file', 'cat: file: Is a directory'))
    assert not match(Command('ls file', 'cat: file: Is a directory',
                             'ls: file: Is a directory'))



# Generated at 2022-06-24 06:00:14.926853
# Unit test for function match
def test_match():
    assert match(Command('cat etc', output='cannot open etc'))
    assert not match(Command('cat etc', output='cannot open etc\n'))
    assert match(Command('cat /usr/bin/', output='cat: /usr/bin/: Is a directory'))
    assert match(Command('cat /usr/share/doc', output='cat: /usr/share/doc: Is a directory'))
    assert match(Command('cat README.md', output='cat: README.md: Is a directory'))
    assert not match(Command('cat README.md', output='just some text'))


# Generated at 2022-06-24 06:00:18.025208
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('cat file')=='ls file'
	#assert get_new_command('cat src/')=='ls src/'


# Generated at 2022-06-24 06:00:19.577390
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat ./tests')) == 'ls ./tests'

# Generated at 2022-06-24 06:00:21.096446
# Unit test for function match
def test_match():
    assert match(Command(script='cat /home/'))


# Generated at 2022-06-24 06:00:24.007599
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(r'cat /path/to/file') == r'ls /path/to/file'


# Generated at 2022-06-24 06:00:26.019502
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat ', '', 'cat: a: Is a directory')) == 'ls '

# Generated at 2022-06-24 06:00:29.584228
# Unit test for function match
def test_match():
    assert match(Command('cat /dev/null',
                         'cat: /dev/null: Is a directory\n',
                         '', 127))
    assert not match(Command('cat /dev/null',
                             'cat: no such file or directory\n',
                             '', 127))


# Generated at 2022-06-24 06:00:31.350998
# Unit test for function match
def test_match():
    assert match(Command("cat test", None, "cat: test: Is a directory"))


# Generated at 2022-06-24 06:00:39.099518
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="cat README.txt", stdout="cat: README.txt: Is a directory")) \
        == 'ls README.txt'
    assert get_new_command(Command(script="cat README.txt -w", stdout="cat: README.txt: Is a directory")) \
        == 'ls README.txt -w'
    assert get_new_command(Command(script="cat README.txt -w > README.txt", stdout="cat: README.txt: Is a directory")) \
        == 'ls README.txt -w > README.txt'


# Generated at 2022-06-24 06:00:43.129452
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat ~/missing_dir/file',
                                   stdout='cat: /home/pk/missing_dir/file: No such file or directory',
                                   stderr='')) == 'ls ~/missing_dir/file'



# Generated at 2022-06-24 06:00:45.468316
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', 'cat: file.txt: Is a directory\n'))
    assert not match(Command('cat file.txt', ''))
    assert not match(Command('cat', 'cat: file.txt: Is a directory\n'))


# Generated at 2022-06-24 06:00:48.474766
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat ./tests/unit/rules'
    expected = 'ls ./tests/unit/rules'
    actual = get_new_command(command)
    assert expected == actual

# Generated at 2022-06-24 06:00:50.550720
# Unit test for function match
def test_match():
    command = Command(script="cat file", output="cat: file: Is a directory")
    assert match(command)


# Generated at 2022-06-24 06:00:53.079461
# Unit test for function match
def test_match():
    assert match(Command(script = 'cat dir', output = 'cat: dir: Is a directory'))


# Generated at 2022-06-24 06:01:02.848015
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /tmp').script == 'ls /tmp'
    assert get_new_command('cat /tmp/test').script == 'ls /tmp/test'
    assert get_new_command('cat /tmp/test /tmp/test').script == 'ls /tmp/test /tmp/test'
    assert get_new_command('cat /tmp/test /tmp/test | grep').script == 'ls /tmp/test /tmp/test | grep'
    assert get_new_command('cat /tmp/test /tmp/test > /home').script == 'ls /tmp/test /tmp/test > /home'
    assert get_new_command('cat /tmp/test /tmp/test > /home > /tmp').script == 'ls /tmp/test /tmp/test > /home > /tmp'
    assert get_new

# Generated at 2022-06-24 06:01:11.195992
# Unit test for function match
def test_match():
    assert match(Command('cat file1.txt', output='file1.txt file2.txt cat: file1.txt: Is a directory'))
    assert False == match(Command('cat file1.txt', output='cat: file1.txt: No such file or directory'))
    assert False == match(Command('cat file1.txt', output='cat: file1.txt: File exists'))
    assert False == match(Command('cat file1.txt', output='file1.txt file2.txt cat: file1.txt: Is a directory'))


# Generated at 2022-06-24 06:01:11.769722
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat test.txt") == "ls test.txt"

# Generated at 2022-06-24 06:01:13.302483
# Unit test for function get_new_command
def test_get_new_command():
    command = "cat dir"
    assert get_new_command(command) == 'ls dir'

# Generated at 2022-06-24 06:01:17.407079
# Unit test for function match
def test_match():
    # File not found
    assert match(Command('cat file.txt', 'cat: file.txt: No such file or directory'))
    # Directory found
    assert match(Command('cat dir', 'cat: dir: Is a directory'))



# Generated at 2022-06-24 06:01:20.702018
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp'))
    assert not match(Command('cat /etc/hosts'))
    assert not match(Command('ls /tmp'))


# Generated at 2022-06-24 06:01:26.155279
# Unit test for function match
def test_match():
    assert match(Command(script='cat /home/test', stderr='cat: /home/test: Is a directory'))
    assert not match(Command(script='cat /home/test', stderr='cat: /home/test: No such file or directory'))
    assert not match(Command(script='cat /home/test', stderr=''))
    assert not match(Command(script='', stderr='cat: /home/test: Is a directory'))


# Generated at 2022-06-24 06:01:28.901251
# Unit test for function match
def test_match():
    assert match(Command('cat dfsdf', 'cat: dfsdf: Is a directory', ''))
    assert not match(Command('cat dfsdf', '', ''))

# Generated at 2022-06-24 06:01:34.129107
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory\n'))
    assert not match(Command('cat test.py', 'test.py', stderr='cat: test.py: No such file or directory\n'))
    assert not match(Command('caterpillar', stderr='bash: caterpillar: command not found\n'))


# Generated at 2022-06-24 06:01:36.306392
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_dir import get_new_command
    assert get_new_command(Command('cat rules/cat_dir.py')) == \
       'ls rules/cat_dir.py'

# Generated at 2022-06-24 06:01:38.619405
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_directory import get_new_command
    assert get_new_command("cat /usr/") == "ls /usr/"

# Generated at 2022-06-24 06:01:40.801395
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('cat foo', output='cat: foo: Is a directory')) == 'ls foo'

# Generated at 2022-06-24 06:01:43.448144
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat /usr/local/bin", "", "", 0, "")
    assert get_new_command(command) == "ls /usr/local/bin"


# Generated at 2022-06-24 06:01:51.917201
# Unit test for function match
def test_match():
    assert match(Command('cat test.txt', output='cat: test.txt: Is a directory'))
    assert not match(Command('ls test.txt', output='ls: test.txt: No such file or directory'))
    assert match(Command('cat test.txt', output='cat: test.txt: No such file or directory'))
    assert not match(Command('cat test.txt', output='cat: test.txt'))
    assert not match(Command('cat test.txt', output='cat: test.txt: Is a directory', stderr='cat: test.txt'))


# Generated at 2022-06-24 06:01:54.125547
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('cat', 'cat: test: Is a directory')
    assert get_new_command(cmd) == 'ls'

# Generated at 2022-06-24 06:01:56.431999
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat /tmp/foo', output='cat: /tmp/foo: Is a directory')) == 'ls /tmp/foo'

# Generated at 2022-06-24 06:01:57.811268
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /tmp') == 'ls /tmp'


# Generated at 2022-06-24 06:01:59.505707
# Unit test for function match
def test_match():
    assert match(Command('cat', ''))
    assert not match(Command('ls', ''))

# Generated at 2022-06-24 06:02:04.215032
# Unit test for function get_new_command
def test_get_new_command():
    command = Mock()
    command.script = 'cat: test: Is a directory'
    command.script_parts = ['cat', 'test']
    assert get_new_command(command) == 'ls: test: Is a directory'

# Generated at 2022-06-24 06:02:07.513201
# Unit test for function match
def test_match():
    assert match(Command('cat myFile', 'cat: myFile: Is a directory'))
    assert not match(Command('cat myFile', 'myFile: Is a directory'))
    assert not match(Command('cat myFile', 'myFile: No such file or directory'))


# Generated at 2022-06-24 06:02:13.544221
# Unit test for function match
def test_match():
    command = Command('./command_cat.py ', 'cat: ./: Is a directory')
    assert_true(match(command))
    command = Command('./command_cat.py ', 'cat: ./: Is not a directory')
    assert_false(match(command))
    command = Command('./command_cat.py ')
    assert_false(match(command))


# Generated at 2022-06-24 06:02:15.463768
# Unit test for function match
def test_match():
    command = Command(script="cat foo bar", stderr="cat: foo: Is a directory")
    assert match(command)

# Generated at 2022-06-24 06:02:19.638639
# Unit test for function get_new_command
def test_get_new_command():
    output = 'cat: /Users/hong/home/pydev: Is a directory'
    result = get_new_command(Command(script='cat /Users/hong/home/pydev', output=output))
    assert(result == 'ls /Users/hong/home/pydev')



# Generated at 2022-06-24 06:02:20.828947
# Unit test for function match
def test_match():
    command = Command('cat /tmp/nothing', 'cat: /tmp/nothing: Is a directory', '')
    assert match(command)



# Generated at 2022-06-24 06:02:30.710245
# Unit test for function match

# Generated at 2022-06-24 06:02:32.793109
# Unit test for function match
def test_match():
	assert match(Command('cat test', None, 'cat: test: Is a directory'))


# Generated at 2022-06-24 06:02:35.833303
# Unit test for function match
def test_match():
    assert match(Command('cat stuff', 'cat: stuff: Is a directory', ''))
    assert not match(Command('cat stuff', "stuff\nstuff", ''))
    assert not match(Command('cd cat', '', ''))


# Generated at 2022-06-24 06:02:42.038891
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /etc/') == 'ls /etc/'
    assert get_new_command('cat') == 'ls'
    assert get_new_command('cat /etc/') == 'ls /etc/'
    assert get_new_command('cat /etc/') == 'ls /etc/'


# Generated at 2022-06-24 06:02:46.504911
# Unit test for function match
def test_match():
    assert match(Command('cat test/test.py', 'cat: test/test.py: Is a directory', '', 0))
    assert not match(Command('cat -l test/test.py', '', '', 0))
    assert not match(Command('cat -b test/test.py', '', '', 0))


# Generated at 2022-06-24 06:02:50.342386
# Unit test for function match
def test_match():
    # Assert that the match function returns true or false
    assert match(Command('cat example.doc', 'cat: example.doc: Is a directory'))
    assert not match(Command('cat example.doc', 'example.doc'))
    assert not match(Command('pwd', 'test'))


# Generated at 2022-06-24 06:02:57.668066
# Unit test for function match
def test_match():
    assert match(Command('cat testdir',
                         output='cat: testdir: Is a directory',
                         script='cat testdir'))
    assert not match(Command('cat testdir',
                             output='cat: testdir: No such file or directory',
                             script='cat testdir'))
    assert not match(Command('cat testdir',
                             output='Error: uncaught exception testdir',
                             script='cat testdir'))


# Generated at 2022-06-24 06:03:00.564983
# Unit test for function match
def test_match():
    assert match(Command('cat .', 'cat: .: Is a directory'))
    assert not match(Command('cat', 'cat: usage'))

# Generated at 2022-06-24 06:03:06.024798
# Unit test for function match
def test_match():
    # test when directory exists
    assert match(Command('cat .',
        output='cat: .: Is a directory\n',
        script='cat .'))
    # test when directory doesn't exist
    assert not match(Command('cat dne',
        output='cat: dne: No such file or directory\n',
        script='cat dne'))


# Generated at 2022-06-24 06:03:10.152138
# Unit test for function get_new_command
def test_get_new_command():
    vim_dir = os.getcwd() + '/vim/'
    test_command = 'cat ' + vim_dir + 'test.py'
    assert get_new_command(test_command) == 'ls ' + vim_dir + 'test.py'

# Generated at 2022-06-24 06:03:13.638254
# Unit test for function get_new_command
def test_get_new_command():
    command = type('command', (object,), {'script': 'cat /etc/hosts', 'script_parts': ['', '/etc/hosts']})
    assert get_new_command(command) == 'ls /etc/hosts'

# Generated at 2022-06-24 06:03:21.521801
# Unit test for function match
def test_match():
    # Valid Commands
    command_list = [
        'cat any_file',
        'cat folder_name',
        'cat -l folder_name',
    ]
    for command in command_list:
        assert match(Command(command, '', '', '', '')) is True

    # Invalid Commands
    command_list = [
        'cat0 any_file',
        'cat0',
        'cat0 any_file any_file',
        '',
        'cat0 0folder_name',
        'cat 1',
        'cat 2'
    ]
    for command in command_list:
        assert match(Command(command, '', '', '', '')) is False
