

# Generated at 2022-06-24 05:53:19.073795
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='ls')) == "ls"
    assert get_new_command(Command(script='cat file')) == "cat file"
    assert get_new_command(Command(script='cat directory')) == "ls directory"



# Generated at 2022-06-24 05:53:20.425006
# Unit test for function get_new_command
def test_get_new_command():
    assert u'ls' == get_new_command(u'cat /home')

# Generated at 2022-06-24 05:53:22.727350
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home/cabox', '')
    new_command = get_new_command(command)
    assert new_command == 'ls /home/cabox'

# Generated at 2022-06-24 05:53:25.464455
# Unit test for function match
def test_match():
    command = Command('cat', 'cat: test: Is a directory')
    assert match(command)



# Generated at 2022-06-24 05:53:27.694664
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /usr/local', '')
    assert get_new_command(command) == 'ls /usr/local'

# Generated at 2022-06-24 05:53:32.822422
# Unit test for function match
def test_match():
    # Check if file does not exist
    assert match(Command(script='cat stuff'))
    # Check if file does exist
    assert not match(Command(script='cat README.md'))
    # Check if directory does exist
    assert match(Command(script='cat .git'))
    # Check if command is cat with -arguments
    assert match(Command(script='cat -t test.txt'))


# Generated at 2022-06-24 05:53:39.510364
# Unit test for function match
def test_match():
    assert match(Command(script='cat foo',
                                 stderr='cat: foo: Is a directory',
                                 stdout=''))
    
    assert not match(Command(script='cat foo',
                                 stderr='cat: foo: Is not a directory',
                                 stdout=''))
    
    assert not match(Command(script='cat foo',
                                 stderr='',
                                 stdout=''))


# Generated at 2022-06-24 05:53:42.984034
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', 'cat: file.txt: Is a directory', ''))
    assert not match(Command('cat', 'cat: error', ''))
    assert not match(Command('', '', ''))


# Generated at 2022-06-24 05:53:45.970490
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_directory import get_new_command
    correct_command = 'ls /usr'
    wrong_command = 'cat /usr'
    assert get_new_command(wrong_command) == correct_command

# Generated at 2022-06-24 05:53:49.661502
# Unit test for function match
def test_match():
    from thefuck.shells import Bash
    from thefuck.rules.cat_dir import match
    assert match(Bash('cat tests/test_data | grep -e test'))
    assert not match(Bash('ls test | grep -e test'))
    assert match(Bash('cat test | grep -e test'))


# Generated at 2022-06-24 05:53:55.165378
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', '', 'cat: file.txt: Is a directory\n')) == True
    assert match(Command('cat file.txt', '', 'cat: file.txt: Does not exist\n')) == False
    assert match(Command('cat file.txt', '', 'cat: file.txt: Is not readable\n')) == False


# Generated at 2022-06-24 05:53:57.844260
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_not_a_file import get_new_command
    assert get_new_command('cat d').script == 'ls d'

# Generated at 2022-06-24 05:53:59.755095
# Unit test for function match
def test_match():
    assert match('cat /usr/bin/fuck')
    assert not match('ls /usr/bin/fuck')


# Generated at 2022-06-24 05:54:01.252396
# Unit test for function match
def test_match():
    assert match(Command('cat main.py'))
    assert not match(Command('cat foo'))


# Generated at 2022-06-24 05:54:03.549961
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_directory import get_new_command
    command = 'cat /home'
    assert get_new_command(command) == 'ls /home'

# Generated at 2022-06-24 05:54:05.724859
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home/', 
                      'cat: /home/: Is a directory', 
                      "", "", "")

    assert get_new_command(command) == "ls /home/"

# Generated at 2022-06-24 05:54:09.440670
# Unit test for function match
def test_match():
     assert match(Command('cat /tmp', '/tmp'))
     assert not match(Command('cat /tmp/xyz', '/tmp/xyz'))
     assert not match(Command('cat /dev/null', '/dev/null'))
     assert not match(Command('cat -z /tmp/xyz', '-z /tmp/xyz'))
     assert not match(Command('cat /tmp/abs/xyz', '/tmp/abs/xyz'))


# Generated at 2022-06-24 05:54:11.661684
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test.txt') == 'ls test.txt'

# Generated at 2022-06-24 05:54:16.791967
# Unit test for function match
def test_match():
    assert match(Command('cat', '', 'cat: invalid option -- \'\'\nTry `cat --help\' for more information.'))
    assert match(Command('cat', '', 'cat: error'))
    assert not match(Command('cat', '', ''))
    assert not match(Command('cat', '', 'hello, world'))
    assert not match(Command('cat', '', 'cat /home/user/test.txt'))
    assert not match(Command('cat', '', 'cat: '))


# Generated at 2022-06-24 05:54:18.030902
# Unit test for function get_new_command
def test_get_new_command():
    command = """cat /home/foo/Documents"""
    new_command = get_new_command(command)
    assert new_command == """ls /home/foo/Documents"""

# Generated at 2022-06-24 05:54:19.846944
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /etc/passwd') == 'ls /etc/passwd'


# Generated at 2022-06-24 05:54:21.649134
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command=Command(script='cat sample')) == 'ls sample'


# Generated at 2022-06-24 05:54:24.993543
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /etc', 'cat: /etc: Is a directory')
    assert get_new_command(command) == 'ls /etc'



# Generated at 2022-06-24 05:54:26.959340
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat ~/", "cat: ~/: Is a directory")
    assert get_new_command(command) == "ls ~/cat"

# Generated at 2022-06-24 05:54:29.104737
# Unit test for function match
def test_match():
    assert match(Command(script='cat /dev/null', output=''))
    assert not match(Command(script='cat /dev/null', output='cat: file.txt: No such file or directory'))



# Generated at 2022-06-24 05:54:32.753188
# Unit test for function match
def test_match():
    assert match(Command(script='cat /root', output='cat: /root: Is a directory\n'))
    assert not match(Command(script='cat /root/test.txt', output='cat: /root: Is a directory\n'))
    assert not match(Command(script='cat /root/test.txt', output='cat: /root is not a directory\n'))



# Generated at 2022-06-24 05:54:37.385659
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat', '', '')) == 'ls'
    assert get_new_command(Command('cat ~/Downloads', '', '')) == 'ls ~/Downloads'
    assert get_new_command(Command('cat a', '', '')) == 'ls a'

# Generated at 2022-06-24 05:54:45.518237
# Unit test for function match
def test_match():
    # No output
    assert not match(Command(script='cat /tmp/test.txt',
                             output=''))

    # Output, but not for cat
    assert not match(Command(script='cat /tmp/test.txt',
                             output='foo'))

    # Output for cat
    assert not match(Command(script='cat /tmp/test.txt',
                             output='cat: /tmp/test.txt: Is a directory'))

    # Output for cat, but the file is not a directory
    assert not match(Command(script='cat /tmp/test.txt',
                             output='cat: /tmp/test.txt: No such file or directory'))

    # Output for cat, but the file is not a directory

# Generated at 2022-06-24 05:54:46.363752
# Unit test for function match
def test_match():
    assert match(Command('cat s'))


# Generated at 2022-06-24 05:54:48.969100
# Unit test for function get_new_command
def test_get_new_command():
    assert 'ls' in get_new_command(Command('cat test.txt'))
    assert 'ls' in get_new_command(Command('cat /tmp'))


# Generated at 2022-06-24 05:54:53.090528
# Unit test for function match
def test_match():
    # Create a Command object to be used in testing match function
    command = Command('cat /home/')
    assert match(command)
    assert get_new_command(command) == 'ls /home/'

# Generated at 2022-06-24 05:54:55.624664
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat test_script.sh', 'cat: test_script.sh: Is a directory')) == 'ls test_script.sh'

# Generated at 2022-06-24 05:55:00.892739
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /Users/a.txt', 'cat: /Users/a.txt: Is a directory')) == 'ls /Users/a.txt'
    assert get_new_command(Command('cat /Users/a.txt', '')) == 'cat /Users/a.txt'
    assert get_new_command(Command('cat', 'cat: /Users/a.txt: Is a directory')) == 'cat'
    assert get_new_command(Command('cat', '')) == 'cat'

# Generated at 2022-06-24 05:55:03.210377
# Unit test for function get_new_command
def test_get_new_command():
    script = 'cat not_a_file'
    assert get_new_command(Command(script)) == 'ls not_a_file'

# Generated at 2022-06-24 05:55:04.640837
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat tmp") == "ls tmp"


# Generated at 2022-06-24 05:55:06.076652
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat foo')) == 'ls foo'

# Generated at 2022-06-24 05:55:09.829562
# Unit test for function get_new_command
def test_get_new_command():
    command = Mock(script_parts=['cat', '..'],
                   output="cat: '..': Is a directory\n",
                   script='cat ..')
    assert get_new_command(command) == 'ls ..'


# Generated at 2022-06-24 05:55:12.246157
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /dev/pts/3')
    assert get_new_command(command) == 'ls cat /dev/pts/3'
    
    

# Generated at 2022-06-24 05:55:16.690555
# Unit test for function match
def test_match():
    # Test that a command with correct output will return True
    assert match(Command(script=('cat', '~', '~/Desktop'),
                         output=("cat: ~: Is a directory", '')))

    # Test that a command with incorrect output will return False
    assert not match(Command(script=('touch', '~', '~/Desktop'),
                             output=("touch: cannot touch '~': No such file or directory", '')))



# Generated at 2022-06-24 05:55:19.510433
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat $PWD', '', '')) == 'ls $PWD'


# Generated at 2022-06-24 05:55:20.955310
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /tmp') == 'ls /tmp'

# Generated at 2022-06-24 05:55:22.559791
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command='cat /etc/hosts') == 'ls /etc/hosts'

# Generated at 2022-06-24 05:55:23.556444
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /') == 'ls /'

# Generated at 2022-06-24 05:55:24.989120
# Unit test for function get_new_command
def test_get_new_command():
	c = CatCommand('cat /usr')
	assert(get_new_command(c) == 'ls /usr')

# Generated at 2022-06-24 05:55:27.578217
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/issue',
                         output="cat: /etc/issue: Is a directory\n"))



# Generated at 2022-06-24 05:55:30.239187
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat ./gfg', '/usr/bin/cat ./gfg')
    assert get_new_command(command) == '/usr/bin/ls ./gfg'

# Generated at 2022-06-24 05:55:35.767788
# Unit test for function match
def test_match():
    assert match(Command('cat foo', stderr='cat: foo: Is a directory'))
    assert not match(Command('cat foo', stderr='cat: bar: Is a directory'))
    assert not match(Command('ls -al /etc/hosts'))
    assert not match(Command('ls -al /etc/hosts', stderr='cat: bar'))


# Generated at 2022-06-24 05:55:38.785410
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    assert get_new_command(Command('cat some_directory', '')) == 'ls some_directory'


# Generated at 2022-06-24 05:55:41.759736
# Unit test for function match
def test_match():
    command = Command('cat a', 'cat: a: Is a directory\n')
    assert match(command)

    command = Command('cat a', '')
    assert not match(command)

    command = Command('cat -h', 'cat: illegal option -- h\n')
    assert not match(command)



# Generated at 2022-06-24 05:55:46.327537
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat example.py') == 'ls example.py'
    assert get_new_command('cat /tmp') == 'ls /tmp'
    assert get_new_command('cat /tmp/file.py') == 'cat /tmp/file.py'

# Generated at 2022-06-24 05:55:47.946428
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('cat /usr/bin/'))
            == 'ls /usr/bin/')

# Generated at 2022-06-24 05:55:51.491231
# Unit test for function get_new_command
def test_get_new_command():
    command_argument = 'cat /path/to/directory'
    correct_result = 'ls /path/to/directory'
    command = Command(command_argument, "cat: 'my_dir': Is a directory")

    assert get_new_command(command) == correct_result


# Generated at 2022-06-24 05:55:54.928740
# Unit test for function match
def test_match():
    command = Command('cat test')
    assert match(command)
    command = Command('ls test')
    assert not match(command)
    command = Command('cat')
    assert not match(command)


# Generated at 2022-06-24 05:55:56.751279
# Unit test for function get_new_command
def test_get_new_command():
    import os
    assert os.path.isdir('/home')
    assert get_new_command('cat /home') == 'ls /home'

# Generated at 2022-06-24 05:56:01.279013
# Unit test for function match
def test_match():
    assert match(Command('cat requirements.txt', '', 'cat: requirements.txt: Is a directory'))
    assert not match(Command('cat requirements.txt', '', 'cat: requirements.txt: No such file or directory'))
    assert not match(Command('echo "4"', '', ''))

# Generated at 2022-06-24 05:56:02.749745
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat *.txt") == "ls *.txt"

# Generated at 2022-06-24 05:56:07.193018
# Unit test for function match
def test_match():
    assert match(Command('cat /home', 'cat: /home: Is a directory'))
    assert match(Command('cat /home', 'cat: /home: No such file or directory')) is False
    assert match(Command('cat /home', 'cat: /home/file.txt: No such file or directory')) is False


# Generated at 2022-06-24 05:56:09.936129
# Unit test for function match
def test_match():
    assert match(Command('cat Today', 'cat: Today: Is a directory'))
    assert not match(Command('yes | cat Today', 'cat: Today: Is a directory'))


# Generated at 2022-06-24 05:56:14.593545
# Unit test for function match
def test_match():
    assert match(Command(script='cat /dev/null',
        output='cat: /dev/null: Is a directory'))
    assert not match(Command(script='cat /dev/null',
        output='cat: /dev/null: No such file or directory'))
    assert not match(Command(script='ls /dev/null',
        output='ls: /dev/null: No such file or directory'))


# Generated at 2022-06-24 05:56:22.834782
# Unit test for function match
def test_match():
    assert match(Command('cat not_exist_file',
                         'cat: not_exist_file: No such file or directory', '/dir'))
    assert not match(Command('cat same_exist_file',
                             'cat: same_exist_file: No such file or directory', '/dir'))
    assert match(Command('cat ./not_exist_file',
                         'cat: ./not_exist_file: No such file or directory', '/dir'))
    assert match(Command('cat ./../not_exist_file',
                         'cat: ./../not_exist_file: No such file or directory', '/dir'))


# Generated at 2022-06-24 05:56:25.729955
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /etc')) == 'ls /etc'
    assert get_new_command(Command('cat /etc', 'cat: /etc: Is a directory')) == 'ls /etc'

# Generated at 2022-06-24 05:56:27.349376
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /home/some_dir") == "ls /home/some_dir"

# Generated at 2022-06-24 05:56:31.503038
# Unit test for function match
def test_match():
    assert match(Command('cat foo/bar'))
    assert not match(Command('cat foo/bar/baz'))
    assert not match(Command('ls foo/bar'))



# Generated at 2022-06-24 05:56:37.293211
# Unit test for function match
def test_match():
    command = Command('cat /tmp/textfile.txt')
    assert match(command)
    command1 = Command('ls /var/www')
    assert not match(command1)
    command2 = Command('l')
    assert not match(command2)
    comand3 = Command('cat /tmp/')
    assert match(comand3)


# Generated at 2022-06-24 05:56:40.050871
# Unit test for function get_new_command
def test_get_new_command():
    command = "cat /home/afourmy/"
    assert get_new_command(command) == "ls /home/afourmy/"

# Generated at 2022-06-24 05:56:42.658269
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /tmp/', 'cat: /tmp/: Is a directory')
    assert get_new_command(command) == 'ls /tmp/'

# Generated at 2022-06-24 05:56:47.692585
# Unit test for function match
def test_match():
    assert match(Command('cat /home/fake/', 'cat: /home/fake/: Is a directory'))
    assert match(Command('cat /home/fake/', 'cat: /home/fake/: No such file or directory'))
    assert not match(Command('cat /home/fake/', 'cat: /home/fake/: Permission denied'))


# Generated at 2022-06-24 05:56:51.287125
# Unit test for function match
def test_match():
    assert match(Command('cat /home/thefuck/a /home/thefuck/b',
                         output='cat: /home/thefuck/a: Is a directory')) == True


# Generated at 2022-06-24 05:56:54.002765
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat test.txt', output="cat: test.txt: Is a directory")
    assert 'ls test.txt' == get_new_command(command)

# Generated at 2022-06-24 05:56:56.784397
# Unit test for function match
def test_match():
    command = Command('/usr/bin/cat test/', '/usr/bin/cat: test/: Is a directory')
    print(match(command))
    #assert match(command)



# Generated at 2022-06-24 05:57:02.621274
# Unit test for function match
def test_match():
    assert match(Command(script='cat testfile.txt',
        output='cat: testfile.txt: Is a directory'))
    assert not match(Command(script='ls testfile.txt',
        output='ls: testfile.txt: Is a directory'))
    assert not match(Command(script='cat testfile.txt',
        output='cat: testfile.txt: No such file or directory'))
    assert not match(Command(script='cat testfile.txt',
        output='testfile.txt'))


# Generated at 2022-06-24 05:57:03.902491
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /') == 'ls /'

# Generated at 2022-06-24 05:57:10.458676
# Unit test for function match
def test_match():
    assert match(Command('cat file'))
    assert match(Command('cat file1 file2'))
    assert match(Command('cat dir1'))
    assert match(Command('cat file1 file2 dir1'))

    assert not match(Command('cat'))
    assert not match(Command('cat unknown_file'))
    assert not match(Command('cat /tmp'))
    assert not match(Command('cat /tmp dir'))
    assert not match(Command('cat /tmp file'))
    assert not match(Command('cat /tmp dir1 file1'))


# Generated at 2022-06-24 05:57:17.389424
# Unit test for function match
def test_match():
    assert match(Command(script='cat /root/fuck', stderr='cat: /root/fuck: Is a directory'))
    assert match(Command(script='cat /root/fuck/', stderr='cat: /root/fuck/: Is a directory'))
    assert not match(Command(script='cat /root/fuck', stderr='cat: /root/fuck: No such file'))
    assert not match(Command(script='cat /root/fuck/', stderr='cat: /root/fuck/: No such file'))


# Generated at 2022-06-24 05:57:20.871423
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', '/usr/bin/cat /etc/passwd\n/usr/bin/cat: /etc/passwd: Is a directory', '', 2))


# Generated at 2022-06-24 05:57:24.700564
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.ls_F import get_new_command
    assert get_new_command(Command('cat dir',
                                   'cat: dir: Is a directory',
                                   'dir/dir2')) == "ls dir"

# Generated at 2022-06-24 05:57:30.338762
# Unit test for function match
def test_match():
    assert match(Command('cat /an/inexistant/file', '', 'cat: an/inexistant/file: Is a directory', 1))
    assert not match(Command('foo /an/inexistant/file', '', 'cat: an/inexistant/file: Is a directory', 1))
    assert match(Command('cat /an/inexistant/file', '', 'cat: an/inexistant/file: file not found', 1))
    assert not match(Command('foo /an/inexistant/file', '', 'cat: an/inexistant/file: file not found', 1))


# Generated at 2022-06-24 05:57:32.229723
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat hello', '')
    assert get_new_command(command) == 'ls hello'

# Generated at 2022-06-24 05:57:35.530276
# Unit test for function match
def test_match():
    assert not match(Command(script='cat'))
    assert not match(Command(script='cat file'))
    assert not match(Command(script='ls dir'))
    assert match(Command(script='cat dir'))



# Generated at 2022-06-24 05:57:37.048310
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /root') == 'ls /root'

# Generated at 2022-06-24 05:57:41.180917
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.ls_when_cat import get_new_command

    assert get_new_command('cat /') == 'ls /'
    assert get_new_command('cat / | grep test') == 'ls / | grep test'

# Generated at 2022-06-24 05:57:44.287000
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat Documents/") == "ls Documents/"
    assert get_new_command("cat Documents") == "ls Documents"
    assert get_new_command("cat Desktop/") == "ls Desktop/"
    assert get_new_command("cat Projects/") == "ls Projects/"

# Generated at 2022-06-24 05:57:45.832134
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat .'
    new_command = get_new_command(command)
    assert new_command == 'ls .'



# Generated at 2022-06-24 05:57:48.219082
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.ls_cat import get_new_command

    assert get_new_command('cat x') == 'ls x'
    assert get_new_command('cat x y') == 'ls x y'


# Generated at 2022-06-24 05:57:50.424291
# Unit test for function match
def test_match():
    assert match(Command("cat foo", "cat: foo: Is a directory"))
    assert not match(Command("cat foo bar", "cat: foo: Is a directory"))
    assert not match(Command("cat foo", ""))



# Generated at 2022-06-24 05:57:52.815932
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command('cat Document', 'cat: Document: Is a directory')
    assert get_new_command(test_command) == 'ls Document'

# Generated at 2022-06-24 05:57:56.645758
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_file  import get_new_command
    assert get_new_command(Command('cat test', '')) == 'ls test'
    assert get_new_command(Command('cat test.txt', '')) == 'cat test.txt'


# Generated at 2022-06-24 05:58:00.381647
# Unit test for function get_new_command
def test_get_new_command():
    command = random.choice(match.commands)
    script = command.script
    new_command = get_new_command(command)
    assert new_command == script.replace('cat', 'ls', 1)

# Generated at 2022-06-24 05:58:04.991177
# Unit test for function match
def test_match():
    assert match(Command('cat hello.py', 'cat: hello.py: Is a directory', ''))
    assert match(Command('cat /etc', 'cat: /etc: Is a directory', ''))
    assert not match(Command('cat /etc/passwd', '', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory', ''))


# Generated at 2022-06-24 05:58:05.854167
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat  unitest")
    assert get_new_command(command) == "ls  unitest"

# Generated at 2022-06-24 05:58:07.696331
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat captain.txt') == 'ls captain.txt'

# Generated at 2022-06-24 05:58:11.099582
# Unit test for function match
def test_match():
    command = Command('cat test')
    assert not match(command)
    command = Command('cat /testdir')
    assert not match(command)


# Generated at 2022-06-24 05:58:13.599010
# Unit test for function match
def test_match():
    assert match(Command(script='cat test.py',
                         output='cat: test.py: Is a directory\n'))
    assert not match(Command())



# Generated at 2022-06-24 05:58:16.589556
# Unit test for function match
def test_match():
    assert match(Command(script='cat ~/',
                         stderr='cat: /home/dexter/: Is a directory\n'))



# Generated at 2022-06-24 05:58:18.968500
# Unit test for function match
def test_match():
    assert match(Command('cat folder',
                         'cat: folder: Is a directory',
                         '/bin/ls'))


# Generated at 2022-06-24 05:58:25.928716
# Unit test for function match
def test_match():
    assert (match(Command(script='cat /home/',
                          output='cat: /home/: Is a directory')))
    assert (match(Command(script='cat /home/',
                          output='cat: /home/: No such file or directory')))
    assert (not match(Command(script='cat /home/',
                              output='cat: /home/: No such file or directory',
                              stderr='cat: /home/: No such file or directory')))

## Unit test for function get_new_command


# Generated at 2022-06-24 05:58:28.014607
# Unit test for function match
def test_match():
    # Check if command throws correct error
    assert match(Command("cat <filename>"))
    # Check if command throws error at all
    assert not match(Command("echo <filename>"))
    # Check if command throws error for files
    assert not match(Command("cat <filename>"))



# Generated at 2022-06-24 05:58:31.315540
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat /home/test_user/test_dir',
                      stdout='cat: /home/test_user/test_dir: Is a directory')
    assert get_new_command(command) == 'ls /home/test_user/test_dir'



# Generated at 2022-06-24 05:58:33.041494
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /usr/local')
    assert get_new_command(command) == "ls /usr/local"

# Generated at 2022-06-24 05:58:39.889911
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp/foo1',
             output='cat: /tmp/foo1: Is a directory\n',
             stderr='/tmp/foo1: Is a directory',
             script='cat /tmp/foo1'))

    assert not match(Command('cat /tmp/foo1',
                  output='',
                  script='cat /tmp/foo1'))


# Generated at 2022-06-24 05:58:41.642550
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat $HOME") == "ls $HOME"



# Generated at 2022-06-24 05:58:43.856625
# Unit test for function match
def test_match():
    assert match(Command('cat /var/lib/ureadahead/debugfs /var/lib/ureadahead/debugfs'), None)


# Generated at 2022-06-24 05:58:45.604609
# Unit test for function match
def test_match():
    assert match(Command(script='cat test'))
    assert not match(Command(script='echo test'))

# Generated at 2022-06-24 05:58:48.067736
# Unit test for function match
def test_match():
    assert match(Command(script='cat non_existent_directory'))
    assert not match(Command('ls non_existent_directory'))



# Generated at 2022-06-24 05:58:51.106279
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat test_folder', 'cat: test_folder: Is a directory')
    new_command = Command('ls test_folder')
    assert get_new_command(command) == new_command

# Generated at 2022-06-24 05:58:52.589735
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat ../')) == 'ls ../'

# Generated at 2022-06-24 05:58:55.342369
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat /usr/local/bin', output='cat: /usr/local/bin: Is a directory')
    assert get_new_command(command) == 'ls /usr/local/bin'

# Generated at 2022-06-24 05:58:58.920896
# Unit test for function match
def test_match():
    assert match(Command('cat test'))
    assert not match(Command('cat test/'))
    assert not match(Command('cat man'))
    assert not match(Command('cat no-such-dir'))
    assert not match(Command('cat'))


# Generated at 2022-06-24 05:59:00.704852
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    command = 'cat thefuck'
    assert get_new_co

# Generated at 2022-06-24 05:59:01.858409
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat test/B')
    assert get_new_command(command) == 'ls test/B'

# Generated at 2022-06-24 05:59:04.500091
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="cat temp.txt", output="cat: temp.txt: Is a directory")) == "ls temp.txt"


# Generated at 2022-06-24 05:59:08.728211
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_directory import get_new_command
    command = Command('cat src')
    assert get_new_command(command) == command.script.replace('cat', 'ls', 1)



# Generated at 2022-06-24 05:59:10.519168
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('cat myfolder', '')
    assert get_new_command(cmd) == 'ls myfolder'

# Generated at 2022-06-24 05:59:17.124798
# Unit test for function get_new_command
def test_get_new_command():
    # Case: command is 'cat'
    assert get_new_command('cat') == 'ls'

    # Case: command is 'cat ksjdj'
    assert get_new_command('cat ksjd') == 'ls ksjd'

    # Case: command is 'cat kdjjf'
    assert get_new_command('cat kdjjf') == 'ls kdjjf'

# Generated at 2022-06-24 05:59:20.371089
# Unit test for function match
def test_match():
    command = type('Command', (object, ), {'output': 'cat: myfile: Is a directory',
                                           'script_parts': ['cat', 'myfile']})
    assert match(command)


# Generated at 2022-06-24 05:59:28.899546
# Unit test for function match
def test_match():
    assert match(Command('cat', 'cat: foo: Is a directory'))
    assert match(Command('cat', 'cat: foo: Is a directory', env={'LANG': 'en_US.UTF-8'}))
    assert not match(Command('cat', 'cat file.txt'))  # doesn't matter cat file.txt or ls file.txt
    assert not match(Command('cat', 'cat: foo: No such file or directory'))
    assert not match(Command('cat', 'cat: foo: No such file or directory', env={'LANG': 'en_US.UTF-8'}))



# Generated at 2022-06-24 05:59:40.340967
# Unit test for function match
def test_match():
    # Make sure this function returns True, when a cat command on a directory is not successful.
    assert match(Command('cat /tmp; command not found', '/bin/ls', '', 'cat: /tmp: Is a directory\n/bin/ls: \n/bin/ls: \n/bin/ls: Is a directory\n'))
    # Make sure this function returns False, when a cat command on a directory is successful.
    assert not match(Command('cat /tmp', '/bin/ls', '', '/bin/ls\n'))
    # Make sure this function returns False, when a cat command on a file is not successful.

# Generated at 2022-06-24 05:59:43.292780
# Unit test for function match
def test_match():
    assert match(Command('cat test',output='cat: test: Is a directory'))
    assert not match(Command('cat test',output='hey'))


# Generated at 2022-06-24 05:59:48.840914
# Unit test for function match
def test_match():
    assert match(Command('cat src/hello.py', output='cat: src/hello.py: Is a directory'))
    assert not match(Command('cat src/hello.py', output='cat: test/../hello.py: No such file or directory'))
    assert not match(Command('ls src/hello.py', output='ls: src/hello.py: No such file or directory'))


# Generated at 2022-06-24 05:59:52.341680
# Unit test for function match
def test_match():
    assert match(Command('cat file1 file2 file3', 'cat: file1: Is a directory'))
    assert not match(Command('cat file1 file2 file3', 'cat: file1: No such file or directory'))

# Generated at 2022-06-24 05:59:55.144411
# Unit test for function match
def test_match():
	assert match(Command("cat f.txt", "cat: f.txt: Is a directory")).output == "cat: f.txt: Is a directory"


# Generated at 2022-06-24 05:59:59.634545
# Unit test for function match
def test_match():
    assert match(Command('cat /home', output='cat: /home: Is a directory'))
    assert match(Command('cat /home', output='cat: /home: File not found'))
    assert not match(Command('catt /home', output='cat: /home: Is a directory'))


# Generated at 2022-06-24 06:00:03.810748
# Unit test for function match
def test_match():
    assert not match(Command(script='cat /dev/null',
                            stderr='cat: /dev/null: Is a directory'))

    assert match(Command(script='cat /dev/', stderr='cat: /dev/: Is a directory'))



# Generated at 2022-06-24 06:00:05.134847
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat  ~/Downloads') == 'ls ~/Downloads'

# Generated at 2022-06-24 06:00:07.434855
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat', 'cat /usr/bin/')
    assert get_new_command(command) == "ls /usr/bin/"

# Generated at 2022-06-24 06:00:10.823962
# Unit test for function match
def test_match():
    command = 'cat example'
    command_output = 'cat: example: Is a directory'
    new_command = get_new_command(Command(command, command_output))
    assert match(Command(command, command_output))
    assert new_command == 'ls example'

# Generated at 2022-06-24 06:00:12.279158
# Unit test for function match
def test_match():
    command = "cat bin/deploy-staging-1.sh"
    assert match(command)


# Generated at 2022-06-24 06:00:14.184451
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('cat /usr/bin', '', '', '', ''))
    assert new_command == 'ls /usr/bin'

# Generated at 2022-06-24 06:00:15.133893
# Unit test for function match
def test_match():
    assert match("cat script.txt")
    assert not match("ls")


# Generated at 2022-06-24 06:00:24.055168
# Unit test for function match
def test_match():
    output = "cat: c: Is a directory"
    assert match(Command('cat c'))
    assert not match(Command('cat c', output))
    assert not match(Command('cat ./c'))
    assert not match(Command('cat ./c', output))
    assert not match(Command('cat c b'))
    assert not match(Command('cat c b', output))
    assert not match(Command('cat c b', ''))
    assert not match(Command('cat c b', ''))
    assert match(Command('cat c1 c2', output))


# Generated at 2022-06-24 06:00:29.729738
# Unit test for function match
def test_match():
    assert match(Command('cat example.txt', '', 'No such file or directory'))
    assert match(Command('cat example.txt asdfsad.txt', '', 'No such file or directory'))
    assert match(Command('cat /', '', 'Is a directory'))
    assert not match(Command('cat exa'))
    assert not match(Command('cat example.txt', '', ''))
    assert not match(Command('cat', '', ''))



# Generated at 2022-06-24 06:00:33.271085
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/sudoers', '', 'cat: /etc/sudoers: Is a directory'))
    assert not match(Command('cat', '', 'cat: missing file operand'))


# Generated at 2022-06-24 06:00:36.920600
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /home', 'cat: /home: Is a directory')) == 'ls /home'
    assert get_new_command(Command('ls /home', 'ls: /home: Is a directory')) == 'ls /home'

# Generated at 2022-06-24 06:00:38.458184
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat foo','/home/foo')
    assert get_new_command(command) == "ls foo"

# Generated at 2022-06-24 06:00:39.776027
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat stuff') == 'ls stuff'

# Generated at 2022-06-24 06:00:43.148393
# Unit test for function match
def test_match():
    assert match(Command('cat foo.txt', 'foo.txt: Is a directory'))
    assert not match(Command('cat foo.txt', 'foo.txt: Is not a directory'))
    assert not match(Command('ls foo.txt', 'foo.txt: Is a directory'))

# Generated at 2022-06-24 06:00:44.565113
# Unit test for function match
def test_match():
    assert match(Command(script='cat code'))
    assert not match(Command(script='ls code'))


# Generated at 2022-06-24 06:00:47.908493
# Unit test for function match
def test_match():
    assert match(Command('cat file'))
    assert match(Command('cat file dir'))
    assert not match(Command('cat file.txt'))
    assert not match(Command('cat'))


# Generated at 2022-06-24 06:00:49.599453
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /path/to/dir') == 'ls /path/to/dir'

# Generated at 2022-06-24 06:00:50.892726
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat .xinitrc") == 'ls .xinitrc'

# Generated at 2022-06-24 06:00:54.018314
# Unit test for function match
def test_match():
    assert match(Command('cat foo',
                         output='cat: foo: Is a directory'))
    assert not match(Command('cat foo',
                             output='cat: foo: No such file or directory'))
    assert not match(Command('cat',
                             output='cat: invalid option -- foo'))


# Generated at 2022-06-24 06:00:56.908695
# Unit test for function match
def test_match():
	assert(match('cat /home/test/') is True)
	assert(match('test') is False)
	assert(match('cat') is False)


# Generated at 2022-06-24 06:00:58.646385
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat a/b') == 'ls a/b'


# Generated at 2022-06-24 06:01:01.949058
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert match(Command('cat /etc/', 'cat: /etc/: No such file or directory')) is False


# Generated at 2022-06-24 06:01:07.893585
# Unit test for function get_new_command
def test_get_new_command():
    script = "cat /usr/bin/fuck"
    output = "cat: /usr/bin/fuck: Is a directory"
    command = Command(script, output)
    new_script = command.script.replace('cat', 'ls', 1)
    new_command = Command(new_script, output)
    assert get_new_command(command) == new_command

# Generated at 2022-06-24 06:01:09.657461
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat path_to_dir', None)) == 'ls path_to_dir'

# Generated at 2022-06-24 06:01:13.373958
# Unit test for function match
def test_match():
    command_output = 'cat: : Is a directory'
    assert(match(command_output))
    command_output = 'cat'
    assert(not(match(command_output)))
    command_output = 'cat: not a directory'
    assert(not(match(command_output)))


# Generated at 2022-06-24 06:01:22.527578
# Unit test for function match
def test_match():
    assert match(Command('cat dir', None, '', 'cat: dir: Is a directory', ''))
    assert not match(Command('cat dir', None, '', '', ''))
    assert not match(Command('cat dir', None, '', 'cat: dir: No such file or directory', ''))
    assert not match(Command('cat dir', None, '', 'cat: dir: something', ''))
    assert not match(Command('cat', None, '', 'cat: some parameters', ''))
    assert not match(Command('cat dir', None, '', 'cat: some parameters', ''))


# Generated at 2022-06-24 06:01:26.930582
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.ls_F import get_new_command

    # If cat receives a directory name as an argument, it will behave as the
    # equivalent of `ls -F`
    command = 'cat dir'
    new_command = 'ls dir'
    assert get_new_command(command) == new_command

# Generated at 2022-06-24 06:01:36.512338
# Unit test for function match
def test_match():
    assert match(Command('cat nonexistant_file', 'cat: nonexistant_file: No such file or directory', '', 1))
    assert match(Command('cat nonexistant_file.txt', 'cat: nonexistant_file.txt: No such file or directory', '', 1))
    assert match(Command('cat nonexistant_file.py', 'cat: nonexistant_file.py: No such file or directory', '', 1))
    assert not match(Command('cat nonexistant_dir', 'cat: nonexistant_dir: Is a directory', '', 1))
    assert not match(Command('cat nonexistant_dir/', 'cat: nonexistant_dir/: Is a directory', '', 1))

# Generated at 2022-06-24 06:01:40.801153
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat /root/',
                      stdout='cat: /root/: Is a directory',
                      stderr='')
    # Act
    new_command = get_new_command(command)
    # Assert
    assert new_command == 'ls /root/'

# Generated at 2022-06-24 06:01:44.515099
# Unit test for function match
def test_match():
    command = Command('cat /usr/lib/')
    assert match(command)

    command = Command('cat x.py')
    assert not match(command)

    command = Command('ls /usr/lib/')
    assert not match(command)

    command = Command('cat abc')
    assert not match(command)


# Generated at 2022-06-24 06:01:47.773732
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat .config')
    new_command = get_new_command(command)
    assert new_command == 'ls .config'


# Generated at 2022-06-24 06:01:50.197643
# Unit test for function get_new_command
def test_get_new_command():
    output = Command('cat thefuck/rules')
    assert get_new_command(output) == 'ls thefuck/rules'


# Generated at 2022-06-24 06:01:56.836710
# Unit test for function match
def test_match():
    assert match(Command('cat ~/.bashrc',
                         'cat: ~/.bashrc: Is a directory'))
    assert match(Command('cat /etc',
                         'cat: /etc: Is a directory'))
    assert not match(Command('vim /etc',
                         'cat: /etc: Is a directory'))
    assert not match(Command('cat',
                         'cat: : Is a directory'))
    assert not match(Command('cat ~/.vimrc',
                         'cat: ~/.vimrc: No such file or directory'))



# Generated at 2022-06-24 06:01:58.643352
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    correct = 'ls'
    assert get_new_command(['cat', 'test']) == correct

# Generated at 2022-06-24 06:02:03.441693
# Unit test for function match
def test_match():
    # Test is a directory
    assert match(Command('cat some_dir', 'cat: some_dir: Is a directory'))

    # Test is not a directory
    assert not match(Command('cat some_dir', 'dir not found'))



# Generated at 2022-06-24 06:02:06.403053
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_directory import get_new_command
    command = Command('cat /', 'cat: /: Is a directory')
    assert get_new_command(command) == 'ls /'

# Generated at 2022-06-24 06:02:09.463050
# Unit test for function match
def test_match():
    from thefuck.rules.cat_files import match
    command = 'cat no_exists_file'
    assert match(command)



# Generated at 2022-06-24 06:02:13.394050
# Unit test for function match
def test_match():
    # Test 1
    output = 'cat: /example: Is a directory'
    script_parts = ['/bin/ls', '/example']
    command = Command(script_parts, output)

    assert match(command)



# Generated at 2022-06-24 06:02:14.761690
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat test") == "ls test"

# Generated at 2022-06-24 06:02:16.581221
# Unit test for function match
def test_match():
    assert match(Command('cat testdir', 'cat: testdir: Is a directory'))


# Generated at 2022-06-24 06:02:18.538354
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /')
    assert get_new_command(command) == 'ls /'



# Generated at 2022-06-24 06:02:20.737809
# Unit test for function match
def test_match():
    command = Command('cat test.txt', 'cat: test.txt: Is a directory', '', 0, '')
    assert match(command)


# Generated at 2022-06-24 06:02:23.273120
# Unit test for function match
def test_match():
    output = 'cat: /foo/bar/baz: Is a directory'
    assert match(Command('cat /foo/bar/baz', output=output))
    assert not match(Command('cat /foo/bar/baz.txt'))



# Generated at 2022-06-24 06:02:25.102457
# Unit test for function get_new_command
def test_get_new_command():
    # Automatically tests match
    assert get_new_command('cat /').script == 'ls /'

# Generated at 2022-06-24 06:02:32.674927
# Unit test for function match
def test_match():
    command = Command('cat foo/bar')
    assert match(command)
    
    command = Command('cat foo/bar/')
    assert match(command)
    
    command = Command('cat foo/bar/file1')
    assert not match(command)
    
    command = Command('cat foo/bar/not-exists')
    assert not match(command)
    
    command = Command('ls foo/bar')
    assert not match(command)
    
    command = Command('ls foo/bar/file1')
    assert not match(command)
    
    command = Command('ls foo/bar/not-exists')
    assert not match(command)


# Generated at 2022-06-24 06:02:34.464764
# Unit test for function match
def test_match():
    assert match(Command("cat test/output.txt", "cat: test/output.txt: Is a directory"))


# Generated at 2022-06-24 06:02:36.797654
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home/nitin/aditya', 'cat: /home/nitin/aditya: Is a directory')
    assert get_new_command(command) == 'ls /home/nitin/aditya'



# Generated at 2022-06-24 06:02:39.337925
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat ~/Desktop/')) == 'ls ~/Desktop/'

# Generated at 2022-06-24 06:02:40.808276
# Unit test for function get_new_command

# Generated at 2022-06-24 06:02:42.421485
# Unit test for function match
def test_match():
    # Test if the function can recognize wrong command
    assert match(Command('cat test', 'cat: test: Is a directory\n'))
    # Test if the function can recognize right command
    assert not match(Command('ls test', ''))

# Generated at 2022-06-24 06:02:44.033695
# Unit test for function match
def test_match():
    assert match(Command('cat /home/ubuntu/', output='cat: /home/ubuntu/: Is a directory'))
    assert not matc

# Generated at 2022-06-24 06:02:46.834074
# Unit test for function match
def test_match():
    assert match(Command('cat /home', '/home'))
    assert not match(Command('cat', '/home'))
    assert not match(Command('cat file', '/home'))



# Generated at 2022-06-24 06:02:49.988579
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home')
    assert get_new_command(command) == 'ls /home'
    command = Command('echo foo | cat >> /home')
    assert get_new_command(command) == 'echo foo | ls >> /home'

# Generated at 2022-06-24 06:02:53.924393
# Unit test for function match
def test_match():
    assert not match(
        Command('echo uncat file', 'uncat: file: No such file or directory'))
    assert match(Command('cat file', 'cat: file: Is a directory'))


# Generated at 2022-06-24 06:02:56.932115
# Unit test for function match
def test_match():
    assert match(Command('cat .gitignore', '', ''))
    assert not match(Command('cat README.md', '', ''))


# Generated at 2022-06-24 06:03:00.336188
# Unit test for function match
def test_match():
    command = 'cat test.txt'
    assert(not match(command))

    command = 'cat folder'
    assert(match(command))



# Generated at 2022-06-24 06:03:02.716429
# Unit test for function match
def test_match():
    assert match(Command('cat', 'cat: test: Is a directory'))
    assert not match(Command('cat', 'cat: test: No such file or directory'))



# Generated at 2022-06-24 06:03:07.229870
# Unit test for function match
def test_match():
     command = Command('cat foo', '', '', 'cat: foo: Is a directory')
     assert match(command) is True
     command = Command('cat foo bar', '', '', 'cat: foo: Is a directory')
     assert match(command) is False


# Generated at 2022-06-24 06:03:11.246205
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    command = Command('cat smth', 'smth: is a directory')
    assert get_new_command(command) == 'ls smth'

# Generated at 2022-06-24 06:03:13.109815
# Unit test for function match
def test_match():
    assert match(Command('cat file1 file2 file3', 'file1: Is a directory\n'))



# Generated at 2022-06-24 06:03:16.085641
# Unit test for function match
def test_match():
    command = Command('cat fuck.txt')
    assert not match(command)
    command = Command('cat README.txt')
    assert not match(command)
    command = Command('cat spec/thefuck')
    assert match(command)

