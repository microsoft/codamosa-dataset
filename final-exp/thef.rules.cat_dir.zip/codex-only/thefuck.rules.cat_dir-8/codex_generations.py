

# Generated at 2022-06-24 05:53:13.559933
# Unit test for function match
def test_match():
    output = 'cat: /tmp/test: Is a directory'
    assert match(Command('cat /tmp/test', output))



# Generated at 2022-06-24 05:53:15.825093
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat file.py', 'file.py:\ncat: file.py: Is a directory\n')
    assert get_new_command(command) == 'ls file.py'

# Generated at 2022-06-24 05:53:17.576995
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat /etc")
    assert get_new_command(command) == "ls /etc"

# Generated at 2022-06-24 05:53:21.255803
# Unit test for function match
def test_match():
    assert match(Command('cat /dev/null', 'cat: /dev/null: Is a directory'))
    assert not match(Command('cat /dev/null', ''))
    assert not match(Command('cat /dev', 'cat: /dev: Is a directory'))



# Generated at 2022-06-24 05:53:23.831844
# Unit test for function match
def test_match():
    assert match(Command('cat path/to/file',
                         output='cat: path/to/file: Is a directory'))

    assert not match(Command('cat path/to/file',
                             output='cat: No such file or directory'))



# Generated at 2022-06-24 05:53:30.134075
# Unit test for function match
def test_match():
    command = Command(script='cat file',
                      stdout='cat: file: Is a directory')
    assert(match(command))
    command = Command(script='cat file',
                      stdout='cat: file: No such file or directory')
    assert(not match(command))
    command = Command(script='cat file',
                      stdout='file')
    assert(not match(command))


# Generated at 2022-06-24 05:53:35.017264
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /usr/bin/', 'cat: /usr/bin/: Is a directory')) == 'ls /usr/bin/'
    assert get_new_command(Command('cat src/mydir/', 'cat: src/mydir/: Is a directory')) == 'ls src/mydir/'

# Generated at 2022-06-24 05:53:37.983766
# Unit test for function match
def test_match():
    assert match(Command('cat test'))
    assert not match(Command('cat test/'))
    assert not match(Command('stringtest'))


# Generated at 2022-06-24 05:53:42.363698
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {
        'script': 'cat /home/user/Documents',
        'script_parts': ['cat', '/home/user/Documents']
    })
    assert get_new_command(command) == ('ls /home/user/Documents')

# Generated at 2022-06-24 05:53:43.967956
# Unit test for function get_new_command
def test_get_new_command():
    assert 'ls /home/user/test' == get_new_command('cat /home/user/test')


# Generated at 2022-06-24 05:53:45.886548
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('cat test', ''))
    assert not match(Command('cat', ''))



# Generated at 2022-06-24 05:53:47.719310
# Unit test for function match
def test_match():
    output = """'cat: tmp: Is a directory
    '"""

    assert match(Command("cat tmp", output))



# Generated at 2022-06-24 05:53:49.516646
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/'))
    assert not match(Command('cat /tmp/does-not-exists'))


# Generated at 2022-06-24 05:53:51.733534
# Unit test for function match
def test_match():
    assert match(Command('cat ./', '', 'cat: ./: Is a directory'))
    assert not match(Command('cat ./', '', 'cat: ./: No such file or directory'))



# Generated at 2022-06-24 05:53:55.486050
# Unit test for function match
def test_match():
    assert match(Command('cat abc', 'cat: abc: Is a directory', '/usr/bin/cat'))
    assert not match(Command('cat abc', '', '/usr/bin/cat'))



# Generated at 2022-06-24 05:53:58.872257
# Unit test for function match
def test_match():
    command = Command('cat /')
    assert match(command)

    command = Command('pwd /')
    assert not match(command)

    command = Command('cat /home/')
    assert not match(command)



# Generated at 2022-06-24 05:54:02.833585
# Unit test for function match
def test_match():
    assert match(Command('cat folder_does_not_exist', 'cat: folder_does_not_exist: Is a directory'))
    assert not match(Command('cat textfile.txt', 'some content'))
    assert not match(Command('cat folder_does_not_exist', 'cat: folder_does_not_exist: No such file or directory'))
    assert not match(Command('ping google.com', 'ping: unknown host google.com'))


# Generated at 2022-06-24 05:54:05.656675
# Unit test for function match
def test_match():
    assert match(Command('cat file', '', ''))
    assert match(Command('not cat file', '', ''))
    assert match(Command('cat file', 'cat: file: Is a directory', ''))


# Generated at 2022-06-24 05:54:08.248865
# Unit test for function match
def test_match():
    assert match(Command('cat /etc', ''))
    assert not match(Command('ls /etc', ''))


# Generated at 2022-06-24 05:54:11.005559
# Unit test for function match
def test_match():
    assert match(Command(script='cat', output='cat: file.txt: Is a directory'))
    assert not match(Command(script='cat /etc/hosts', output=''))

# Generated at 2022-06-24 05:54:12.174712
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp',
        '/bin/cat: /tmp: Is a directory\n',
        '/bin/cat /tmp'))

# Generated at 2022-06-24 05:54:13.724991
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat mydir", "") == "ls mydir"


# Generated at 2022-06-24 05:54:16.643345
# Unit test for function get_new_command
def test_get_new_command():
    script = 'cat test.txt'
    assert get_new_command(Command(script, '')) == script.replace('cat', 'ls', 1)

# Generated at 2022-06-24 05:54:19.793465
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    new_command = get_new_command(Command('cat rvr'))
    assert new_command == 'ls rvr'

# Generated at 2022-06-24 05:54:20.837208
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_comma

# Generated at 2022-06-24 05:54:24.185442
# Unit test for function match
def test_match():
    assert not match(Command(script="cat /etc/passwd", output="foo"))
    assert not match(Command(script="cat /etc/passwd", output="cat: /etc/passwd: Is a directory"))
    assert match(Command(script="cat /etc/", output="cat: /etc/: Is a directory"))

# Generated at 2022-06-24 05:54:26.087132
# Unit test for function match
def test_match():
    assert match(Command('cat a', 'cat: a: Is a directory'))
    assert not match(Command('cat a', "line 1\nline 2"))


# Generated at 2022-06-24 05:54:27.753603
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat folder', '')) == 'ls folder'


# Generated at 2022-06-24 05:54:30.230393
# Unit test for function get_new_command
def test_get_new_command():
    res = "ls /home/user/test.txt"
    command = types.Command(script='cat /home/user/test.txt', stdout=res)
    new_command = get_new_command(command)

    assert new_command == res

# Generated at 2022-06-24 05:54:32.781390
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_directory import get_new_command
    assert get_new_command(Command('cat home')) == 'ls home'
    assert get_new_command(Command('cat -la ~')) == 'ls -la ~'


# Generated at 2022-06-24 05:54:33.674235
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat src') == 'cat src'

# Generated at 2022-06-24 05:54:36.698190
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    result = get_new_command(Command('cat /tmp', '/tmp'))
    assert result == 'ls /tmp'

# Generated at 2022-06-24 05:54:38.456564
# Unit test for function match
def test_match():
    test_command = Command('cat testDir')
    assert match(test_command)



# Generated at 2022-06-24 05:54:40.929741
# Unit test for function match
def test_match():
	command = Command("cat file.txt")
	assert match(command)
	assert not match(Command("git commit"))
	

# Generated at 2022-06-24 05:54:45.993120
# Unit test for function match
def test_match():
    new_command = get_new_command("cat foo")
    assert new_command == "ls foo"

    new_command = get_new_command("cat -l foo")
    assert new_command == "ls -l foo"

    new_command = get_new_command("cat -n foo")
    assert new_command == "ls -n foo"

    new_command = get_new_command("cat -q foo")
    assert new_command == "ls -q foo"

    new_command = get_new_command("cat -v foo")
    assert new_command == "ls -v foo"

# Generated at 2022-06-24 05:54:47.359254
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_for_dir import get_new_command
    assert get_new_command("cat dir1") == "ls dir1"

# Generated at 2022-06-24 05:54:48.738276
# Unit test for function match
def test_match():
    assert match(Command('cat blah blah blah blah blah blah blah blah',
        'cat: argument 1: Is a directory'))


# Generated at 2022-06-24 05:54:52.701551
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat test -l", "cat: test: Is a directory")
    assert get_new_command(command) == command.script.replace("cat", "ls", 1)

# Generated at 2022-06-24 05:54:55.240983
# Unit test for function match
def test_match():
    match_test_case_1=['cat','~','~','ls']
    
    assert match(match_test_case_1)==True



# Generated at 2022-06-24 05:54:58.390081
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/hosts', '127.0.0.1 localhost'))


# Generated at 2022-06-24 05:55:03.560038
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('cat ../') == 'ls ../')
    assert(get_new_command('cat ../../') == 'ls ../../')
    assert(get_new_command('cat test') == 'ls test')
    assert(get_new_command('cat script1 script2') == 'ls script1 script2')


# Generated at 2022-06-24 05:55:05.896440
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat tests')
    ret = get_new_command(command)
    assert ret == 'ls tests'

# Generated at 2022-06-24 05:55:08.536432
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('cat /home/loki/Documents'))
    assert new_command == 'ls /home/loki/Documents'

# Generated at 2022-06-24 05:55:12.104472
# Unit test for function match
def test_match():
    command = Command('cat file.txt', 'cat: file.txt: Is a directory')
    assert match(command)

    command = Command('cat other.txt', 'cat: other.txt: No such file')
    assert not match(command)

# Generated at 2022-06-24 05:55:14.663572
# Unit test for function match
def test_match():
    assert match(Command('cat /home/login', 'cat: /home/login: Is a directory'))
    assert not match(Command('cat', 'cat: f1: No such file or directory'))



# Generated at 2022-06-24 05:55:17.510298
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('cat /Users/mannyvera/Documents/github/')) ==
            'ls /Users/mannyvera/Documents/github/')

# Generated at 2022-06-24 05:55:20.404468
# Unit test for function get_new_command
def test_get_new_command():

    command = Command("cat test")
    new_command = get_new_command(command)
    assert new_command == "ls test"

# Generated at 2022-06-24 05:55:24.352632
# Unit test for function match
def test_match():
    assert match(Command('cat test.txt', 'cat: test.txt: Is a directory'))
    assert not match(Command('cat not_exist.txt', "cat: 'not_exist.txt': No such file or directory"))
    assert not match(Command('ls test.txt', "ls: cannot access 'test.txt': Is a directory"))


# Generated at 2022-06-24 05:55:26.483028
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /usr/local/share/', 'cat: /usr/local/share/: Is a directory\nsomething\n')) == 'ls /usr/local/share/'

# Generated at 2022-06-24 05:55:30.396943
# Unit test for function match
def test_match():
    assert match(Command('cat text', 'cat: text: Is a directory')) 
    assert not match(Command('dog text', 'cat: text: Is a directory')) 
    assert not match(Command('cat text', 'cat: text: Is not a directory')) 


# Generated at 2022-06-24 05:55:34.080139
# Unit test for function match
def test_match():
    from thefuck.rules.cat_is_directory import match
    command = 'cat /tmp/foo'
    assert match(command) == False
    command1 = 'cat /etc/apache2'
    assert match(command1) == True

# Generated at 2022-06-24 05:55:36.137928
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat $HOME')
    assert match(command)
    assert get_new_command(command) == 'ls $HOME'

# Generated at 2022-06-24 05:55:42.617804
# Unit test for function match
def test_match():
    assert match("cat file.txt", "cat: file.txt: Is a directory")
    assert not match("cat file.txt", "something")
    assert not match("something", "cat: something: Is a directory")
    assert not match("cat file1.txt file2.txt", "cat: file1.txt: Is a directory")
    assert not match("cat file.txt", "cat: file.txt: No such file or directory")
    assert not match("cat file.txt", "file.txt")


# Generated at 2022-06-24 05:55:48.701345
# Unit test for function match
def test_match():
    assert match(Command('cat hello', '', stderr='cat: hello: Is a directory\n', stdout='', script='cat hello'))
    assert not match(Command('cat hello', '', stderr='cat: hello: No such file or directory\n', stdout='', script='cat hello'))
    assert not match(Command('cat hello', '', stderr='cat: \'hello\' is a directory\n', stdout='', script='cat hello'))



# Generated at 2022-06-24 05:55:50.835596
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('cat /test/test', '', 'cat: /test/test: Is a directory')) == 'ls /test/test'

# Generated at 2022-06-24 05:55:53.144000
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("cat .git", "cat: .git: Is a directory")) == "ls .git"

# Generated at 2022-06-24 05:55:56.185450
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user', output='cat: /usr/local/bin: Is a directory'))
    assert not match(Command('cat /home/user', output='cat: /usr/local/bin: Is not a directory'))

# Generated at 2022-06-24 05:56:05.916395
# Unit test for function match
def test_match():
    assert match(Command('cat non_existing_dir', 'cat: non_existing_dir: Is a directory'))
    assert match(Command('cat non_existing_dir', 'cat: non_existing_dir: Is a directory'))

    assert not match(Command('cat non_existing_dir', ''))
    assert not match(Command('cat non_existing_dir', 'cat: non_existing_dir: No such file or directory'))
    assert not match(Command('cat non_existing_dir', 'cat: non_existing_dir: Is a directory '))
    assert not match(Command('cat non_existing_dir', 'cat: non_existing_dir: Is a directoryz'))


# Generated at 2022-06-24 05:56:12.169430
# Unit test for function match
def test_match():
    assert match(
        Command('cat file',
        'cat: file: Is a directory\n',
        '/home/user/',
        'file'))
    assert not match(
        Command('cat file',
        'cat: file: Is a directory\n',
        '/home/user/',
        'file', '', 'file'))
    assert not match(
        Command('cat',
        'cat: file: Is a directory\n',
        '/home/user/',
        'file'))


# Generated at 2022-06-24 05:56:14.457567
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /etc/') == 'ls /etc/'
    assert get_new_command('cat src/') == 'ls src/'


#Unit test for function match

# Generated at 2022-06-24 05:56:15.455346
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('') == ''

# Generated at 2022-06-24 05:56:18.017065
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command(script='cat /', output='cat: /: Is a directory'))
    assert new_command == 'ls /'

# Generated at 2022-06-24 05:56:19.397295
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /google") == "ls /google"

# Generated at 2022-06-24 05:56:22.645758
# Unit test for function match
def test_match():
    assert match(Command('cat /etc', '', 'cat: /etc: Is a directory'))
    assert not match(Command('cat foo.txt', '', 'bar'))


# Generated at 2022-06-24 05:56:25.180103
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_directory import get_new_command
    assert get_new_command('cat dir1 dir2') == 'ls dir1 dir2'

# Generated at 2022-06-24 05:56:26.829770
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /tmp') == 'ls /tmp'


# Generated at 2022-06-24 05:56:31.606797
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/os-release', ''))
    assert not match(Command('cat /etc/os-release', '/etc/os-release: Permission denied\nthefuck: command not found', 1))
    assert not match(Command('cat /etc/os-release', 'this is a dir\nthisfile.txt', 1))
    assert not match(Command('cat /etc/os-release', 'thisfile.txt\nthisfile2.txt', 1))


# Generated at 2022-06-24 05:56:33.245030
# Unit test for function get_new_command
def test_get_new_command():
    line = 'cat: Makefile: Is a directory'
    command = Command(line, [line])
    assert get_new_command(command) == 'ls: Makefile: Is a directory'

# Generated at 2022-06-24 05:56:38.005611
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat') == 'ls'
    assert get_new_command('cat /d') == 'ls /d'
    assert get_new_command('cat /d ') == 'ls /d '
    assert get_new_command('cat /d /r') == 'ls /d /r'
    assert get_new_command('cat /d /r ') == 'ls /d /r '
    assert get_new_command('cat /d /r /f') == 'ls /d /r /f'
    assert get_new_command('cat /d /r /f ') == 'ls /d /r /f '


# Generated at 2022-06-24 05:56:41.384439
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('cat home/yuqi/', '', 'cat: home/yuqi/: Is a directory\n', '', 1))
            == 'ls home/yuqi/')

# Generated at 2022-06-24 05:56:47.692946
# Unit test for function match
def test_match():
    command = Command('cat /tmp/foo/bar', 'cat: /tmp/foo/bar: Is a directory')
    assert match(command)
    command = Command('cat /tmp/foo/bar', 'cat: /tmp/foo/bar: No such file or directory')
    assert not match(command)
    command = Command('cat /tmp/foo/bar', 'cat: /tmp/foo/bar: Is not a directory')
    assert not match(command)


# Generated at 2022-06-24 05:56:52.310512
# Unit test for function match
def test_match():
    assert match(Command('cat test', ''))  # Correct command
    assert match(Command('cat test', ''))  # Correct command
    assert not match(Command('ls test', ''))  # Correct command
    assert not match(Command('cat', ''))  # Correct command

# Generated at 2022-06-24 05:57:00.985356
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    # Verify path to file is processed correctly
    command = "cat ~/Documents/Test"
    assert get_new_command(command) == command.replace('cat', 'ls', 1)
    # Verify path with spaces is processed correctly
    command = "cat ~/Documents/Test Folder"
    assert get_new_command(command) == command.replace('cat', 'ls', 1)
    # Verify path with space in middle of folder name is processed correctly
    command = "cat ~/Documents/Neil Youngs/Test Folder"
    assert get_new_command(command) == command.replace('cat', 'ls', 1)
    # Verify files with spaces in their names are processed correctly
    command = "cat '~/Documents/Neil Youngs/Test Folder/test spaces.txt'"

# Generated at 2022-06-24 05:57:05.864748
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.ls_cat import get_new_command
    assert get_new_command(Command('cat log.txt', 'cat: log.txt: Is a directory')) == 'ls log.txt'
    assert get_new_command(Command('cat log.txt', 'cat: log.txt: Is a directory\n')) == 'ls log.txt'

enabled_by_default = True

# Generated at 2022-06-24 05:57:08.276165
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat README.md", "cat: README.md: Is a directory\n")
    assert get_new_command(command) == "ls README.md"

# Generated at 2022-06-24 05:57:09.792547
# Unit test for function match
def test_match():
    assert match(Command('cat', 'cat: flipper: Is a directory'))


# Generated at 2022-06-24 05:57:14.473843
# Unit test for function match
def test_match():
  cmd = Mock(script='cat test.txt', script_parts=['cat', 'test.txt'], output='cat: test.txt: Is a directory')
  os.path.isdir = Mock(return_value=False)
  assert match(cmd) == False
  os.path.isdir = Mock(return_value=True)
  assert match(cmd) == True

# Generated at 2022-06-24 05:57:17.494280
# Unit test for function get_new_command
def test_get_new_command():
    Examples = [
            ('cat /home/kit/Documents/', 'ls /home/kit/Documents/'),
    ]
    for example in Examples:
        assert get_new_command(example[0]) == example[1]

# Generated at 2022-06-24 05:57:21.532595
# Unit test for function match
def test_match():
    assert match(Command('cat file', 'cat: file: Is a directory\n', ''))
    assert not match(Command('cat', '', ''))
    assert not match(Command('cat file', '', ''))


# Generated at 2022-06-24 05:57:26.441179
# Unit test for function match
def test_match():
    assert match(Command(script='cat one two'))
    assert match(Command(script='cat one two', output='cat: not a tty'))
    assert not match(Command(script='cat one two three'))
    assert not match(Command(script='cat one two', output='cat: not a tty', stdout='not a tty'))


# Generated at 2022-06-24 05:57:29.924770
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat folder')
    assert get_new_command(command).script == 'ls folder'
    command = Command('cat folder/')
    assert get_new_command(command).script == 'ls folder/'

# Generated at 2022-06-24 05:57:32.964771
# Unit test for function match
def test_match():
    command_output = 'cat: /home/neo: Is a directory\n'
    assert match(Command(script="cat /home/neo", output=command_output))


# Generated at 2022-06-24 05:57:36.815754
# Unit test for function match
def test_match():
    assert match(Command('cat pwd', 'cat: pwd: Is a directory\n'))
    assert not match(Command('cat'))
    assert not match(Command('cat pwd', 'cat: pwd: Is not a valid directory\n'))


# Generated at 2022-06-24 05:57:40.963889
# Unit test for function match
def test_match():
    print("Testing function match")
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test.docx', "test.docx: Microsoft Word 2007+"))
    assert not match(Command('cat test', 'test'))



# Generated at 2022-06-24 05:57:43.516372
# Unit test for function match
def test_match():
    # Success
    assert match(Command('cat dir', output='cat: dir: Is a directory'))
    
    # Failure
    assert not match(Command('cat file', output='file contents'))



# Generated at 2022-06-24 05:57:45.310031
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
                WhileCommand('cat directory', 'cat: ‘directory’: Is a directory')) == 'ls directory'


# Generated at 2022-06-24 05:57:48.070440
# Unit test for function match
def test_match():
    assert match(Command('cat test.py', 'cat: test.py: Is a directory'))
    assert not match(Command('cat', 'cat: test.py: Is a directory'))
    assert not match(Command('cat test.py', 'cat: test.py: No such file or directory'))


# Generated at 2022-06-24 05:57:52.073923
# Unit test for function match
def test_match():
    assert match(Command('cat test',
                         'cat: test: Is a directory',
                         '',
                         '',
                         ''))
    assert not match(Command(()))



# Generated at 2022-06-24 05:57:54.330274
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /usr', 'cat: /usr: Is a directory')) == 'ls /usr'

# Generated at 2022-06-24 05:57:57.490716
# Unit test for function get_new_command
def test_get_new_command():
    command1 = 'cat ./dir'
    command2 = 'cat test.txt'
    assert 'ls ./dir' == get_new_command(command1)
    assert 'cat test.txt' == get_new_command(command2)

# Generated at 2022-06-24 05:58:01.511958
# Unit test for function match
def test_match():
    assert match(Command('cat test_directory'))
    assert not match(Command('ls'))
    assert not match(Command('ls test_directory'))
    assert not match(Command('cat test_file'))


# Generated at 2022-06-24 05:58:05.210402
# Unit test for function match
def test_match():
    assert match(Command('cat some/path', 'cat: some/path: Is a directory'))

    # Test for different file name
    assert not match(Command('cat some/path', 'cat: some/path: No such file or directory'))

    # Test for different command
    assert not match(Command('ls some/path', 'cat: some/path: Is a directory'))

# Generated at 2022-06-24 05:58:08.014110
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /etc/hosts')
    assert get_new_command(command) == 'ls /etc/hosts'



# Generated at 2022-06-24 05:58:11.365953
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="cat /tmp", stderr="cat: /tmp: Is a directory")
    assert (get_new_command(command) == "ls /tmp")

# Generated at 2022-06-24 05:58:12.746472
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat nonexistant_dir') == 'ls nonexistant_dir'

# Generated at 2022-06-24 05:58:14.264447
# Unit test for function match
def test_match():
    command = Command('cat /etc')
    assert match(command) is True


# Generated at 2022-06-24 05:58:16.110242
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt',stderr='cat: not a directory'))


# Generated at 2022-06-24 05:58:19.778243
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat a_dir')) == 'ls a_dir'
    assert get_new_command(Command('cat a_dir | tr a c')) == ('ls a_dir | tr a c')

# Generated at 2022-06-24 05:58:24.424020
# Unit test for function match
def test_match():
    command = Command('cat test', 'cat: test: Is a directory', '')
    assert not match(command)

    command = Command('cat test', 'cat: test: No such file or directory', '')
    assert not match(command)

    command = Command('cat test', 'cat: test: Is a directory', '')
    assert match(command)

# Generated at 2022-06-24 05:58:25.301203
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat testdir')
    assert get_new_command(command) == 'ls testdir'

# Generated at 2022-06-24 05:58:27.279070
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /usr/local/bin') == 'ls /usr/local/bin'


# Generated at 2022-06-24 05:58:28.790657
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home/')
    assert get_new_command(command) == 'ls /home/'

# Generated at 2022-06-24 05:58:30.208237
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat /tmp'))== 'ls /tmp'

# Generated at 2022-06-24 05:58:32.110776
# Unit test for function match
def test_match():
    assert match(Command('cat foo', None, 'cat: foo: Is a directory'))
    assert not match(Command('cat foo', None, 'foo'))


# Generated at 2022-06-24 05:58:37.844889
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_directory import get_new_command

    # The command prints an error after receiving the word cat and the word directory
    command = "cat /home/user/Projects/"

    # The command will be replaced by the word ls
    assert get_new_command(command) == "ls /home/user/Projects/"

# Generated at 2022-06-24 05:58:39.986613
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('cat /usr') == 'ls /usr')


# Generated at 2022-06-24 05:58:42.952956
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp', '', 'cat: /tmp: Is a directory'))
    assert not match(Command('cat /tmp', '', 'cat: /tmp: No such file or directory'))


# Generated at 2022-06-24 05:58:53.532008
# Unit test for function match
def test_match():
    assert match(Command('cat non-existing-file', ''))
    assert match(Command('cat non-existing-file', '',
                         'cat: non-existing-file: No such file or directory'))
    assert match(Command('cat non-existing-file', '',
                         'cat: non-existing-file: Is a directory'))
    assert not match(Command('cat existing-file', ''))
    assert not match(Command('cat non-existing-file', '',
                             'cat: non-existing-file: No such file or directory\n'))
    assert not match(Command('cat', ''))

# Generated at 2022-06-24 05:58:55.577551
# Unit test for function match
def test_match():
    command = Command('cat /home', 'cat: /home: Is a directory')
    assert match(command)



# Generated at 2022-06-24 05:58:58.100433
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /etc/', 'cat: /etc/: Is a directory')
    assert get_new_command(command) == 'ls /etc/'

# Generated at 2022-06-24 05:59:01.040608
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat /home/'  # Script
    command = Command(command)  # Initialize Command object
    new_command = get_new_command(command)  # Get new command
    assert new_command == 'ls /home/'

# Generated at 2022-06-24 05:59:02.716110
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat foo') == 'ls foo'
    assert get_new_command('cat bar foo') == 'cat bar ls foo'

# Generated at 2022-06-24 05:59:08.049566
# Unit test for function match
def test_match():
    assert match(Command('cat etc', 'cat: etc: Is a directory', '', 3))
    assert not match(Command('cat etc', 'cat: etc: No such file or directory', '', 3))
    assert not match(Command('grep foo bar', 'cat: etc: Is a directory', '', 3))


# Generated at 2022-06-24 05:59:10.344746
# Unit test for function get_new_command
def test_get_new_command():
    script = 'cat /usr/local/bin'
    script_parts = script.split()

# Generated at 2022-06-24 05:59:12.954179
# Unit test for function get_new_command
def test_get_new_command():
    command1 = "cat /home/"
    assert get_new_command(command1) == "ls /home/"

# Generated at 2022-06-24 05:59:14.425117
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat folder") == 'ls folder'

# Generated at 2022-06-24 05:59:17.363559
# Unit test for function match
def test_match():
    assert match(Command(script='cat file', output='cat: file: Is a directory'))
    assert not match(Command(script='cat file', output='cat: file: No such file'))

# Generated at 2022-06-24 05:59:20.674438
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', ''))
    assert not match(Command('dircat', ''))


# Generated at 2022-06-24 05:59:22.850572
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command("cat")
    new_cmd = get_new_command(cmd)
    assert new_cmd == 'ls'

# Generated at 2022-06-24 05:59:23.499593
# Unit test for function get_new_command

# Generated at 2022-06-24 05:59:26.511155
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home/user/')
    assert get_new_command(command) == 'ls /home/user/'

# Generated at 2022-06-24 05:59:28.176252
# Unit test for function match
def test_match():
    assert match(Command('cat abc', 'cat: abc: Is a directory'))


# Generated at 2022-06-24 05:59:30.747353
# Unit test for function match
def test_match():
    assert match(Command('cat f'))
    assert match(Command('cat f f'))
    assert not match(Command('cat f | grep f'))
    assert not match(Command('cat'))



# Generated at 2022-06-24 05:59:33.365676
# Unit test for function match
def test_match():
    assert match(Command('cat /dev/sda',
                         '/dev/sda is a directory',
                         '/dev/sda'))



# Generated at 2022-06-24 05:59:36.725271
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat talamasca', '')
    new_command = get_new_command(command)
    assert new_command == 'ls talamasca'

# Generated at 2022-06-24 05:59:38.228724
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /dir") == "ls /dir"

# Generated at 2022-06-24 05:59:39.689295
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /etc/opt/','/etc/opt/')
    assert get_new_command(command) == 'ls /etc/opt/'

# Generated at 2022-06-24 05:59:47.957159
# Unit test for function match
def test_match():
    assert(match(Command(script="cat /tmp/test", output="cat: /tmp/test: Is a directory", stderr="")) == True)
    assert(match(Command(script="cat /tmp/test", output="/tmp", stderr="")) == False)
    assert(match(Command(script="cat /tmp/test", output="cat: /tmp/test: Is a directory", stderr="")) == True)
    assert(match(Command(script="cat /tmp/test", output="/tmp", stderr="")) == False)



# Generated at 2022-06-24 05:59:49.814357
# Unit test for function get_new_command
def test_get_new_command():
    script = 'cat /home/test/test'
    assert get_new_command(script) == script.replace('cat', 'ls', 1)

# Generated at 2022-06-24 05:59:54.000587
# Unit test for function match
def test_match():
    # Argument is a file
    assert match(Command('cat file.txt', 'hello')) is False

    # Argument is not a file
    assert match(Command('cat file', 'cat: file: Is a directory')) is True


# Generated at 2022-06-24 05:59:59.225117
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat test', 'cat: test: Is a directory')) == 'ls test'
    assert get_new_command(Command('cat test/', 'cat: test/: Is a directory')) == 'ls test/'
    assert get_new_command(Command('cat test\\', 'cat: test\\: Is a directory')) == 'ls test\\'

# Generated at 2022-06-24 06:00:05.641446
# Unit test for function match
def test_match():
    assert match(Command('cat lol', '', 'cat: lol: Is a directory'))
    assert match(Command('cat lol.py', '', 'cat: lol.py: Is a directory'))
    assert not match(Command('cat lol', '', 'lol'))
    assert not match(Command('cat lol', '', 'cat: lol: NOT Is a directory'))
    assert not match(Command('ls lol', '', 'cat: lol: Is a directory'))


# Generated at 2022-06-24 06:00:07.572752
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat test/')
    assert get_new_command(command) == 'ls test/'

# Generated at 2022-06-24 06:00:13.726175
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('cat /etc', '')) == 'ls /etc'
    assert get_new_command(Command('cat -r /etc', '')) == 'ls -r /etc'
    assert get_new_command(Command('cat -r', '/etc')) == 'ls -r'
    assert get_new_command(Command('cat', '/etc')) == 'ls'
    assert get_new_command(Command('cat /etc/bind', '')) == 'ls /etc/bind'

enabled_by_default = True

# Generated at 2022-06-24 06:00:17.747502
# Unit test for function match
def test_match():
    example_os_output = """cat: name: Is a directory"""
    assert match(Command('cat testname', example_os_output, os.getcwd()))
    assert not match(Command('ls testname', example_os_output, os.getcwd()))



# Generated at 2022-06-24 06:00:20.204438
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat ./dir', 'cat: ./dir: Is a directory', '')
    assert get_new_command(command) == "ls ./dir"

# Generated at 2022-06-24 06:00:22.972823
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /etc/hosts')
    assert get_new_command(command) == 'ls /etc/hosts'

# Generated at 2022-06-24 06:00:26.194854
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat /home/', output='cat: /home/: Is a directory', stderr='cat: /home/: Is a directory')) == 'ls /home/'

# Generated at 2022-06-24 06:00:28.439372
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat folder',
                                   output='cat: folder: Is a directory')) == 'ls folder'

# Generated at 2022-06-24 06:00:36.075586
# Unit test for function match
def test_match():
    assert match(Command('cat dir1 dir2', 'cat: dir2: Is a directory'))
    assert match(Command('cat dir1 dir2', 'cat: dir2: Is a directory\ncat: dir2: Is a directory'))
    assert not match(Command('cat filename', ''))
    assert not match(Command('cat filename', 'cat: filename: No such file or directory'))
    assert not match(Command('cat filename', 'filename: Is a directory'))
    assert not match(Command('cat filename', 'cat: filename: Is a directory'))


# Generated at 2022-06-24 06:00:38.714799
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat test.txt")
    assert get_new_command(command) == "ls test.txt"

# Generated at 2022-06-24 06:00:41.952848
# Unit test for function match
def test_match():
    command = Command('cat testcases/cat_folder_error.py', '', Output('cat: testcases/cat_folder_error.py: Is a directory'))
    assert match(command)


# Generated at 2022-06-24 06:00:43.758952
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /usr/bin/') == 'ls /usr/bin/'

# Generated at 2022-06-24 06:00:45.103231
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /bin/b') == 'ls /bin/b'

# Generated at 2022-06-24 06:00:48.806252
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', '', 'cat: \''
                         'file.txt\': Is a directory', '', ''))
    assert not match(Command('cat file.txt', '', '', '', ''))



# Generated at 2022-06-24 06:00:52.041985
# Unit test for function match
def test_match():
    assert match(Command('cat /',
                'cat: /: Is a directory'))
    assert match(Command('cat .',
                'cat: .: Is a directory'))
    assert not match(Command('cat',
                    'cat: missing file operand'))


# Generated at 2022-06-24 06:00:53.684992
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test').startswith('ls')

# Generated at 2022-06-24 06:00:56.014319
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test'))

# Generated at 2022-06-24 06:00:59.024443
# Unit test for function get_new_command
def test_get_new_command():
    command = """
cat: /home/michael/.cache/dein: Is a directory
"""
    assert get_new_command(command) == """
ls /home/michael/.cache/dein""".strip()

# Generated at 2022-06-24 06:01:03.185512
# Unit test for function match
def test_match():
    command = Command(script='cat file1 file2 > file3', output = 'cat: file1: Is a directory')
    assert match(command)
    command = Command(script='cat file1 file2 > file3', output = 'cat: file1: No such file or directory')
    assert not match(command)

    # Unit test for function get_new_command

# Generated at 2022-06-24 06:01:05.642076
# Unit test for function match
def test_match():
    assert match( Command('cat c:/') )
    assert not match( Command('cat file.txt') )



# Generated at 2022-06-24 06:01:07.752628
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /etc/hosts') == 'ls /etc/hosts'

# Generated at 2022-06-24 06:01:11.105870
# Unit test for function match
def test_match():
	assert match(create_command('cat file'))
	assert match(create_command('cat file/'))
	assert not match(create_command('ls file'))
	assert not match(create_command('rm file/'))


# Generated at 2022-06-24 06:01:12.812509
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/.ssh/settings', ''))
    assert not match(Command('cat ~/.ssh/settings', ''))



# Generated at 2022-06-24 06:01:14.861943
# Unit test for function get_new_command
def test_get_new_command(): 
    assert get_new_command('cat test') == 'ls test'

# Generated at 2022-06-24 06:01:16.819498
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat /etc/'
    assert get_new_command(command) == 'ls /etc/'

# Generated at 2022-06-24 06:01:17.515377
# Unit test for function match
def test_match():
    ass

# Generated at 2022-06-24 06:01:21.250897
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat ..', '')) == 'ls ..'
    assert get_new_command(Command('cat ../', '')) == 'ls ../'


# Generated at 2022-06-24 06:01:23.830209
# Unit test for function match
def test_match():
    assert match(Command('cat TODO', 'cat: TODO: Is a directory\n'))
    assert not match(Command('cat TODO', 'TODO: Is a directory\n'))



# Generated at 2022-06-24 06:01:26.784124
# Unit test for function match
def test_match():
    assert match(Command('cat /d', 'cat: /d: Is a directory'))
    assert not match(Command('cat /d', 'cat: /d: No such file or directory'))

# Generated at 2022-06-24 06:01:30.923365
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_directory import get_new_command
    command = """cat: ./utils: Is a directory"""
    assert get_new_command(command).script == "ls ./utils: Is a directory"


# Generated at 2022-06-24 06:01:38.261715
# Unit test for function get_new_command
def test_get_new_command():
    # Test case 1
    # input: cat /tmp
    # expected: ls /tmp
    input_command = "cat /tmp\n"
    expected_output = "ls /tmp\n"
    assert get_new_command(Command(script=input_command, prefix='', suffix='')) == expected_output

    # Test case 2
    # input: cat /tmp/test1.txt /tmp/test2.txt /tmp/test3.txt
    # expected: ls /tmp/test1.txt /tmp/test2.txt /tmp/test3.txt
    input_command = "cat /tmp/test1.txt /tmp/test2.txt /tmp/test3.txt\n"
    expected_output = "ls /tmp/test1.txt /tmp/test2.txt /tmp/test3.txt\n"

# Generated at 2022-06-24 06:01:40.853568
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', '')) == 'ls /etc/passwd'

# Generated at 2022-06-24 06:01:50.542025
# Unit test for function match
def test_match():
    output1 = "cat: /home/incognito: Is a directory"
    output2 = "cat: /home/incognito: Not a directory"
    output3 = "cat: /home/incognito: No such file or directory"

    assert match(Command("cat /home/incognito", output1))
    assert match(Command("cat /home/incognito", output2))
    assert match(Command("cat /home/incognito", output3)) is False
    assert match(Command("cat -n /home/incognito", output1))
    assert match(Command("cat -n /home/incognito", output2)) is False
    assert match(Command("cat -n /home/incognito", output3)) is False
    assert match(Command("cat /home/incognito", "")) is False




# Generated at 2022-06-24 06:01:52.453440
# Unit test for function match
def test_match():
    assert match(Command('cat testdir', 'cat: testdir: Is a directory'))


# Generated at 2022-06-24 06:01:55.022210
# Unit test for function match
def test_match():
    output = 'cat: abc.txt: Is a directory'
    assert match(Command(script='cat abc.txt', output=output, env={}))



# Generated at 2022-06-24 06:01:56.918786
# Unit test for function match
def test_match():
    assert match(Command('cat test', ''))
    assert match(Command('cat test/', ''))
    assert match(Command('cat test/a.txt', ''))
    assert not match(Command('cat test/a.txt', '', ''))
    assert not match(Command('ls test/', ''))



# Generated at 2022-06-24 06:02:04.111389
# Unit test for function match
def test_match():
    assert match(Command('cat app.py'))
    assert not match(Command('dont_get_fucked cat foo.py'))
    assert not match(Command('cat bar.py', 'cat: bar.py: Is a directory'))
    assert not match(Command('cat', 'cat: foo.py: Is a directory'))
    assert not match(Command('cat', ''))


# Generated at 2022-06-24 06:02:07.152177
# Unit test for function match
def test_match():
    assert match(Command('cat NOTEXISTINGFILE', 'cat: NOTEXISTINGFILE: No such file or directory'))
    assert not match(Command('cat', 'cat: '))
    assert not match(Command('cat', ''))



# Generated at 2022-06-24 06:02:11.427734
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp/sdfe', 'cat: /tmp/sdfe: Is a directory'))
    assert not match(Command('cat /tmp/sdfe', "cat: 'sdfe': No such file or directory"))

# unit test for function get_new_command

# Generated at 2022-06-24 06:02:14.310753
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'test\ntest'))
    assert not match(Command('ls test', 'test\ntest'))


# Generated at 2022-06-24 06:02:18.226365
# Unit test for function match
def test_match():
    assert match(Command('cat test', output='cat: test: Is a directory\n'))
    assert not match(Command('ls test', output='cat: test: Is a directory\n'))
    assert not match(Command('cat test', output='cat: test test'))


# Generated at 2022-06-24 06:02:21.115051
# Unit test for function match
def test_match():
    assert match(Command('cat file'))
    assert match(Command('cat file1 file2 file3'))
    assert not match(Command('catt file1 file2 file'))
    assert not match(Command('cat'))



# Generated at 2022-06-24 06:02:24.196523
# Unit test for function match
def test_match():
    assert match(Command('cat /home/it'))
    assert not match(Command('cat /home/it/shell'))



# Generated at 2022-06-24 06:02:27.100770
# Unit test for function match
def test_match():
    assert match(Command('cat test'))
    assert not match(Command('cat'))
    assert not match(Command('ls test'))
    assert not match(Command('ls'))


# Generated at 2022-06-24 06:02:29.883382
# Unit test for function get_new_command
def test_get_new_command():
    command_list = ['cat .gitignore']
    for command in command_list:
        test_command = get_new_command(command)
        assert test_command == command.replace('cat', 'ls', 1) 


# Generated at 2022-06-24 06:02:31.878307
# Unit test for function get_new_command
def test_get_new_command():
    command = "cat /usr/bin/thefuck"
    assert get_new_command(command) == 'ls /usr/bin/thefuck'

# Generated at 2022-06-24 06:02:33.149061
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('cat test') == 'ls test'

# Generated at 2022-06-24 06:02:34.614960
# Unit test for function match
def test_match():
    assert not match(Command('cat hello'))
    assert match(Command('cat /'))


# Generated at 2022-06-24 06:02:36.925508
# Unit test for function match
def test_match():
    assert match(Command('cat file.cpp', output='cat: file.cpp: Is a directory'))
    assert not match(Command('cat file.cpp', output='cat: file.cpp: File Not Found'))


# Generated at 2022-06-24 06:02:38.835027
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /tmp/') == 'ls /tmp/'

# Generated at 2022-06-24 06:02:40.565416
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test') == 'ls test'

# Generated at 2022-06-24 06:02:41.974383
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test') == 'ls test'

# Generated at 2022-06-24 06:02:44.200398
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("cat var/log/auth.log", "")) == "ls var/log/auth.log"

# Generated at 2022-06-24 06:02:45.897047
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat ~/.config', '', '')) == 'ls ~/.config'

# Generated at 2022-06-24 06:02:47.567903
# Unit test for function match
def test_match():
    assert match(Command('cat test'))
    assert not match(Command('ls test'))


# Generated at 2022-06-24 06:02:48.598699
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat') == 'ls'

# Generated at 2022-06-24 06:02:49.828012
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat test', 'cat: test: Is a directory')
    assert get_new_command(command) == 'ls test'

# Generated at 2022-06-24 06:02:51.724934
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /tmp/some/dir', '', '')
    assert get_new_command(command) == 'ls /tmp/some/dir'


# Generated at 2022-06-24 06:02:56.235081
# Unit test for function match
def test_match():
	command = Command('cat test.txt')
	os.path.isdir = lambda path: True
	assert match(command) == False
	command.script_parts = ['cat', '.']
	assert match(command) == True


# Generated at 2022-06-24 06:03:01.272875
# Unit test for function match
def test_match():
    assert match(Command(script='cat folder',
                         stderr='cat: folder: Is a directory',
                         output='',))
    assert not match(Command(script='cat file',
                             stderr='cat: file: No such file or directory',
                             output=''))


# Generated at 2022-06-24 06:03:03.081880
# Unit test for function get_new_command
def test_get_new_command():
    from .utils import Command
    assert get_new_command(Command('cat /tmp')) == 'ls /tmp'

# Generated at 2022-06-24 06:03:06.339414
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp', ''))
    assert not match(Command('cat', ''))
    assert not match(Command('ls /tmp', ''))


# Generated at 2022-06-24 06:03:07.814440
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test') == 'ls test'

# Generated at 2022-06-24 06:03:13.501412
# Unit test for function match
def test_match():
    command = Command('cat first second', 'cat: second: Is a directory', 1)
    assert match(command)
    command = Command('cat first second', 'cat: second: No such file or directory', 1)
    assert not match(command)
    command = Command('ls first second', 'ls: second: Is a directory', 1)
    assert not match(command)
