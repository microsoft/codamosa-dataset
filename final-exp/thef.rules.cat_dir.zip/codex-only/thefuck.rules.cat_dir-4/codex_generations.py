

# Generated at 2022-06-24 05:53:18.188995
# Unit test for function match
def test_match():
    assert match(Command('cat', '', 'cat: test: Is a directory'))
    assert not match(Command('cat test', '', ''))



# Generated at 2022-06-24 05:53:21.072729
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(
        Command('cat ~/Documents/Sample/Folders', '')
    )
    assert result == 'ls ~/Documents/Sample/Folders'

# Generated at 2022-06-24 05:53:23.433881
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /usr/bin/') == 'ls /usr/bin/'
    assert get_new_command('cat README.md') == 'cat README.md'

# Generated at 2022-06-24 05:53:25.923630
# Unit test for function match
def test_match():
    command = Command('cat /home/git/gitbook')
    assert match(command)


# Generated at 2022-06-24 05:53:28.943745
# Unit test for function match
def test_match():
    assert match(Command('cat ~/.bashrc', '', 'cat: ~/.bashrc: Is a directory'))
    assert match(Command('cat /etc/passwd', '', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat ~/.bashrc', '', ''))
    assert not match(Command('cat /etc/passwd', '', ''))


# Generated at 2022-06-24 05:53:29.880292
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /home/test') == 'ls /home/test'


# Generated at 2022-06-24 05:53:32.962735
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('cat etc', 'cat: etc: Is a directory', 'etc'))
    assert new_command == 'ls etc'

# Generated at 2022-06-24 05:53:37.476447
# Unit test for function match
def test_match():
    output = 'cat: wnpm: Is a directory'
    assert match(Command(script = 'cat wnpm', output = output)) is True
    assert match(Command(script = 'cat', output = output)) is False
    assert match(Command(script = 'cat fakefile', output = output)) is False



# Generated at 2022-06-24 05:53:44.060340
# Unit test for function match
def test_match():
    assert match(Command(stderr='cat: /usr/local/etc/php/5.6/php.ini: Is a directory'))
    assert not match(Command(stderr='cat: /usr/local/etc/php/5.6/php.ini: No such file or directory'))
    assert not match(Command(stderr='cat: /usr/local/etc/php/5.6/php.ini: Invalid argument'))


# Generated at 2022-06-24 05:53:46.674034
# Unit test for function match
def test_match():
    assert match(Command(script='cat /home', output='cat: /home: Is a directory'))
    assert not match(Command(script='cat file.txt', output=''))


# Generated at 2022-06-24 05:53:49.405082
# Unit test for function match
def test_match():
    assert match(Command(script='cat testdir', output='cat: testdir: Is a directory'))
    assert match(Command(script='cat ~/.vimrc', output='cat: ~/.vimrc: No such file or directory'))



# Generated at 2022-06-24 05:53:51.487109
# Unit test for function get_new_command
def test_get_new_command():
        assert get_new_command('cat filename') == 'ls filename'
        assert get_new_command('cat Documents') == 'ls Documents'


# Generated at 2022-06-24 05:53:55.429845
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('cat ~/Downloads',
                "cat: ~/Downloads: Is a directory\n",
                os.environ,
                '~',
                'cat ~/Downloads')) == "ls ~/Downloads"

# Generated at 2022-06-24 05:53:59.481488
# Unit test for function match
def test_match():
    assert match(Command('cat /usr/local/bin/test', 'cat: /usr/local/bin/test: Is a directory'))
    assert not match(Command('cat /usr/local/bin/test', 'test: /usr/local/bin/test: Is a directory'))


# Generated at 2022-06-24 05:54:07.232760
# Unit test for function match
def test_match():
    test_commands = [
        command.Command('cat wrongpath', 'cat: wrongpath: Is a directory')
    ]
    correct_match_tests = [
        'cat wrongpath',
    ]
    incorrect_match_tests = [
        'cat',
        'cat test/test_wrong_path.txt',
        'cat test/test_wrong_path.txt test/test_correct_path.txt',
        'cat wrongpath test/test_correct_path.txt',
        'cat test/test_wrong_path.txt wrongpath'
    ]
    for test_command in test_commands:
        for correct_match_test in correct_match_tests:
            assert match(
                command.Command(correct_match_test, test_command.output)
            ) is True

# Generated at 2022-06-24 05:54:09.618396
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat Desktop', 'cat: Desktop: Is a directory')
    assert get_new_command(command).script == 'ls Desktop'

# Generated at 2022-06-24 05:54:11.126915
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /tmp") == "ls /tmp"

# Generated at 2022-06-24 05:54:13.978306
# Unit test for function match
def test_match():
    assert match(Command('cat', 'cat: hello.txt: Is a directory', ''))
    assert not match(Command('cat', 'cat: hello.txt: Is not a directory', ''))
    assert not match(Command('cat', 'cat: hello.txt: Is not a directory'))
    assert not match(Command('cat', 'cat: hello.txt: Is a directory', ''))
    assert not match(Command('ls', 'cat: hello.txt: Is a directory', ''))


# Generated at 2022-06-24 05:54:21.857877
# Unit test for function match
def test_match():
    assert match(Command('cat bla.txt', 'cat: bla.txt: Is a directory'))
    assert match(Command('cat bla', 'cat: bla: Is a directory'))
    assert match(Command('cat bla.fdf fg.txt', 'cat: bla.fdf: Is a directory'))
    assert not match(Command('cat bla.txt fg.txt', 'hello world'))
    assert not match(Command('cat bla.txt', 'hello world'))



# Generated at 2022-06-24 05:54:31.069998
# Unit test for function match
def test_match():
    assert match(Command("cat non-exist-file", "cat: non-exist-file: No such file or directory\n", "", "", ""))
    assert match(Command("cat non-exist-dir/", "cat: non-exist-dir/: Is a directory\n", "", "", ""))
    assert not match(Command("cat exist-file", "", "", "", ""))
    assert not match(Command("cat exist-dir/", "", "", "", ""))
    assert not match(Command("cat non-exist-file non-exist-file", "cat: non-exist-file: No such file or directory\n", "", "", ""))

# Generated at 2022-06-24 05:54:32.049734
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat foo') == 'ls foo'

# Generated at 2022-06-24 05:54:37.603410
# Unit test for function match
def test_match():

    # Case 1:
    # Output: cat: /home: Is a directory
    # Script: cat /home
    output = "cat: /home: Is a directory"

    # Case 1: Correct answer is second form
    script_correct_answer_1 = "cat /home"
    script_correct_answer_2 = "cat /home/some_file"
    script_wrong_answers = ["cat /home/some_file/some_folder"]

    assert match(Command(script_correct_answer_1,output))
    assert match(Command(script_correct_answer_2, output))

    for script_wrong_answer in script_wrong_answers:
        assert not match(Command(script_wrong_answer, output))

    # Case 2:
    # Output: cat: /home: Is a directory
    # Script:

# Generated at 2022-06-24 05:54:41.901026
# Unit test for function get_new_command
def test_get_new_command():
    """
    tests command "cat test/fodder/test_dir"
    returns command "ls test/fodder/test_dir"
    """
    command = Command('cat test/fodder/test_dir', '')
    assert get_new_command(command) == 'ls test/fodder/test_dir'

# Generated at 2022-06-24 05:54:46.088813
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_directory import get_new_command

    command = Command(script='cat /home', output='cat: /home: Is a directory')
    assert get_new_command(command) == 'ls /home'

# Generated at 2022-06-24 05:54:49.699187
# Unit test for function match
def test_match():
    command = Command('cat readme.txt')
    assert match(command)
    assert not match(Command('ls readme.txt'))
    assert not match(Command('cat dir'))
    command = Command('cat dir')
    assert match(command)


# Generated at 2022-06-24 05:54:51.377808
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('cat test', 'cat: test: Is a directory')
    ) == 'ls test'

# Generated at 2022-06-24 05:54:54.712402
# Unit test for function match
def test_match():
    assert(match(Command('cat /tmp/foo', 'cat: /tmp/foo: Is a directory')))
    assert(not match(Command('cat /tmp/foo', 'cat: /tmp/foo: No such file')))
    assert(not match(Command('ls /tmp/foo', 'cat: /tmp/foo: Is a directory')))



# Generated at 2022-06-24 05:54:56.901274
# Unit test for function match
def test_match():
    assert match(Command('cat foo bar baz', ''))
    assert not match(Command('cat foo bar baz', '', None))


# Generated at 2022-06-24 05:55:00.695806
# Unit test for function match
def test_match():
    assert match(Command('cat file', 'cat: file: Is a directory', '', ''))
    assert match(Command('cat /', 'cat: /: Is a directory', '', ''))
    assert not match(Command('cat file', 'file', '', ''))
    assert not match(Command('cat file', 'cat: file: No such file or directory', '', ''))


# Generated at 2022-06-24 05:55:02.756538
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat directory_name'
    assert get_new_command(command) == 'ls directory_name'

# Generated at 2022-06-24 05:55:06.259156
# Unit test for function match
def test_match():
    assert match(Command('cat test', None, 'cat: test: Is a directory'))
    assert not match(Command('git commit', None, 'git: \'commit\' is not a git command. See \'git --help\'.'))


# Generated at 2022-06-24 05:55:10.459529
# Unit test for function match
def test_match():
		assert match(Command('cat test', output='cat: test: Is a directory'))
		assert not match(Command('cat test.txt', output='test'))
		assert match(Command('cat test', output='cat: test: No such file or directory'))


# Generated at 2022-06-24 05:55:13.854033
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat ~/IdeaProjects/thefuck")
    assert get_new_command(command) == "ls ~/IdeaProjects/thefuck"

    command = Command("cat /")
    assert get_new_command(command) == "ls /"



# Generated at 2022-06-24 05:55:14.989793
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /usr/bin") == "ls /usr/bin"

# Generated at 2022-06-24 05:55:19.563361
# Unit test for function get_new_command
def test_get_new_command():
    # Create a Command object to test get_new_command
    from thefuck.types import Command
    command = Command('cat $HOME', 'cat: /home/user: Is a directory')
    assert get_new_command(command) == 'ls $HOME'


# Generated at 2022-06-24 05:55:21.767446
# Unit test for function get_new_command
def test_get_new_command():
    new = get_new_command("cat /etc")
    print(new)


# Command test for function get_new_command

# Generated at 2022-06-24 05:55:25.767438
# Unit test for function match
def test_match():
    assert for_app('ls', at_least=1)(match)(Command('ls test1 test2'))
    assert not for_app('ls', at_least=1)(match)(Command('cat test1 test2'))
    assert not for_app('ls', at_least=1)(match)(Command('dmesg test1 test2'))


# Generated at 2022-06-24 05:55:29.519804
# Unit test for function match
def test_match():
    command = type('Command', (object,), {
        'script_parts': ['cat', 'some/dir'],
        'output': 'cat: some/dir: Is a directory'
    })
    assert match(command)



# Generated at 2022-06-24 05:55:32.758009
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat foo bar',
                                   stderr='cat: foo: Is a directory',
                                   script_parts=['cat', 'foo', 'bar'])) == 'ls foo bar'

# Generated at 2022-06-24 05:55:34.746133
# Unit test for function match
def test_match():
    command = Command(script='cat',output='cat: DIR: Is a directory')
    assert match(command)


# Generated at 2022-06-24 05:55:36.044438
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /home') == 'ls /home'

# Generated at 2022-06-24 05:55:38.694942
# Unit test for function match
def test_match():
    command = Command('cat new_folder')
    assert match(command)
    command = Command('cat new_file')
    assert not match(command)



# Generated at 2022-06-24 05:55:39.474545
# Unit test for function get_new_command
def test_get_new_command():
   assert get_new_command('cat folder') == 'ls folder'

# Generated at 2022-06-24 05:55:44.964769
# Unit test for function get_new_command
def test_get_new_command():
    command_ls = Command('ls /etc/', '/home/user')
    assert get_new_command(command_ls) == 'ls /etc/'

    command_cat = Command('cat /etc/', '/home/user')
    assert get_new_command(command_cat) == 'ls /etc/'

    command_cd = Command('cd /etc/', '/home/user')
    assert get_new_command(command_cd) == 'ls /etc/'



# Generated at 2022-06-24 05:55:51.021841
# Unit test for function match
def test_match():
    assert match(Command('cat somedir', 'cat: somedir: Is a directory',
                         'cd somedir && ls'))
    assert not match(Command('cat somedir', '', ''))
    assert not match(Command('ls somedir', 'cat: somedir: Is a directory',
                         'cd somedir && ls'))
    assert not match(Command('cat somedir', 'cat: somedir: Is a directory',
                         'cd somedir && cat'))

# Generated at 2022-06-24 05:55:52.930193
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /tmp/test') == 'ls /tmp/test'

# Generated at 2022-06-24 05:55:55.014469
# Unit test for function get_new_command
def test_get_new_command():
    assert match(Command(script='cat ./test'))
    assert get_new_command(Command(script='cat ./test')) == 'ls ./test'

# Generated at 2022-06-24 05:55:59.254870
# Unit test for function match
def test_match():
    assert match(Command('cat script.sh', 'cat: script.sh: Is a directory'))
    assert not match(Command('cp script.sh', ''))
    assert not match(Command('cp script.sh', 'cp: script.sh: No such file or directory'))



# Generated at 2022-06-24 05:56:00.839127
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /tmp/') == 'ls /tmp/'

# Generated at 2022-06-24 05:56:02.655373
# Unit test for function match
def test_match():
    command = Command('cat xxx', 'cat: xxx: Is a directory')
    assert match(command)


# Generated at 2022-06-24 05:56:04.088443
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat .') == 'ls .'

# Generated at 2022-06-24 05:56:08.042755
# Unit test for function match
def test_match():
    command = Command('cat thenoisysea', output='cat: thenoisysea: Is a directory')
    assert match(command) is True
    command = Command('cat thenoisysea', output='cat: thenoisysea: No such file or directory')
    assert match(command) is False


# Generated at 2022-06-24 05:56:10.476867
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat ~/foo", "cat: /home/bar/foo: Is a directory")
    assert get_new_command(command) == "ls ~/foo"

# Generated at 2022-06-24 05:56:11.616034
# Unit test for function match
def test_match():
    assert match(Command("cat logs/main.log", ""))
    assert match(Command("cat README.md", ""))


# Generated at 2022-06-24 05:56:13.642485
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat ./Documents/', 'cat: ./Documents/: Is a directory')
    assert get_new_command(command) == 'ls ./Documents/'



# Generated at 2022-06-24 05:56:15.603406
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /usr/bin") == "ls /usr/bin"

# Generated at 2022-06-24 05:56:19.301603
# Unit test for function match
def test_match():
    assert match(Command('', '', 'cat: command not found'))
    assert not match(Command('', '', 'cat: /etc/debian_version: Is a directory'))
    assert not match(Command('', '', 'cat: /etc/debian_version: Is a directory'))

# Generated at 2022-06-24 05:56:28.069666
# Unit test for function match
def test_match():
    assert not match(Command('cat'))
    assert not match(Command('cat foo'))
    assert match(Command('cat foo', output='cat: foo: Is a directory'))
    assert not match(Command('cat foo', output='cat: foo: No such file or directory'))
    assert not match(Command('cat foo', output='cat: foo: No such file or directory\n'))
    assert match(Command('cat foo bar', output='cat: foo: Is a directory'))
    assert not match(Command('cat foo bar', output='cat: bar: No such file or directory'))
    assert not match(Command('cat foo bar', output='cat: bar: No such file or directory\n'))


# Generated at 2022-06-24 05:56:31.321394
# Unit test for function match
def test_match():
    assert match(Command('cat /etc', 'cat: /etc: Is a directory'))
    assert not match(Command('cat /etc/passwd', '', ''))

# Generated at 2022-06-24 05:56:32.507530
# Unit test for function match
def test_match():
    assert match(Command('cat dirname'))
    assert not match(Command('cat filename'))

# Generated at 2022-06-24 05:56:35.985090
# Unit test for function match
def test_match():
    assert match(Command('cat testfolder',
        'cat: testfolder: Is a directory'))
    assert not match(Command('cat testfile',
        'testfile contents'))

# Generated at 2022-06-24 05:56:41.996442
# Unit test for function match
def test_match():
    assert match(Command(
        script='cat assignment.txt',
        output='cat: assignment.txt: Is a directory'))
    assert not match(Command(
        script='cat assignment.txt',
        output='assignment.txt: Is a directory'))
    assert not match(Command(
        script='cat assignment.txt',
        output='cat: assignment.txt: No such file or directory'))


# Generated at 2022-06-24 05:56:46.269133
# Unit test for function get_new_command
def test_get_new_command():
    assert match(
        Command('cat unknown_dir', '', 'cat: unknown_dir: Is a directory'))
    assert get_new_command(
        Command('cat unknown_dir', '', 'cat: unknown_dir: Is a directory')) \
        == 'ls unknown_dir'

# Generated at 2022-06-24 05:56:50.300544
# Unit test for function match
def test_match():
    assert match(
        Command(script='cat /home/User/Documents',
                output="cat: '/home/User/Documents' is a directory"))
    assert not match(Command(script='cat /home/User/Documents'))


# Generated at 2022-06-24 05:56:53.422448
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('cat test.txt').script == 'ls test.txt')
    assert (get_new_command('cat ../../').script == 'ls ../../')


# Generated at 2022-06-24 05:56:54.759578
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('cat *') == 'ls *')

# Generated at 2022-06-24 05:56:57.484171
# Unit test for function match
def test_match():
	assert match(Command('cat testdir', 'cat: testdir: Is a directory', '', 1))
	assert not match(Command('cat testfile', '', '', 1))


# Generated at 2022-06-24 05:56:59.456174
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat file1 file2 file3',
                           'cat: file1: Is a directory') == 'ls file1 file2 file3'

# Generated at 2022-06-24 05:57:08.456265
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_doesnt_work import get_new_command

    assert get_new_command(Command('cat /etc', '')) == 'ls /etc'
    assert get_new_command(Command('cat /etc/', '')) == 'ls /etc/'
    assert get_new_command(Command('cat /etc/ /bin/', '')) == 'ls /etc/ /bin/'
    assert get_new_command(Command('cat /etc/ /bin/ | wc', '')) == 'ls /etc/ /bin/'
    assert get_new_command(Command('cat /etc/ /bin/ > /tmp/', '')) == 'ls /etc/ /bin/'
    assert get_new_command(Command('cat /etc/ /bin/', '')) == 'ls /etc/ /bin/'


# Generated at 2022-06-24 05:57:11.609541
# Unit test for function match
def test_match():
    match_ = partial(match, Command('cat testdata',
                                    'cat: testdata: Is a directory'))
    assert match_()
    assert not match_(Command('cat testdata', ''))
    assert not match_(Command('ls testdata', ''))
    assert not match_(Command('ls testdata',
                              'cat: testdata: Is a directory'))
    assert not match_(Command('cat testdata',
                              'cat: testdata: Is a directory',
                              'ls: testdata: Is a directory'))


# Generated at 2022-06-24 05:57:17.288833
# Unit test for function match
def test_match():
    assert match(Command("cat /etc/hosts", output="cat: /etc/hosts: Is a directory\n"))
    assert not match(Command("cat /etc/hosts", output="cat: /etc/hosts: Permission denied\n"))
    assert not match(Command("cat /etc/hosts", output="cat: /etc/hosts: No such file or directory\n"))


# Generated at 2022-06-24 05:57:22.810248
# Unit test for function match
def test_match():
    assert (match(Command(script='cat /usr/bin', output='')) == False)
    assert (match(Command(script='cat', output='')) != False)
    assert (match(Command(script='cat /usr/bin', output='cat: /usr/bin: Is a directory')) == True)


# Generated at 2022-06-24 05:57:25.656710
# Unit test for function match
def test_match():
    assert match(Command('cat', 'cat: /etc/lib/*: Is a directory', ''))
    assert not match(Command('cat', 'cat: /etc/lib/i: Is a directory', ''))


# Generated at 2022-06-24 05:57:27.137103
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat abc') == 'ls cat abc'

# Generated at 2022-06-24 05:57:29.771266
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_dir import get_new_command
    assert get_new_command('cat /tmp/').script == 'ls /tmp/'

# Generated at 2022-06-24 05:57:31.684370
# Unit test for function match
def test_match():
    command = Command('cat /home/None/Documents/', '')
    assert match(command)


# Generated at 2022-06-24 05:57:33.766197
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat test_file'
    assert get_new_command(command) == 'ls test_file'

# Generated at 2022-06-24 05:57:35.267477
# Unit test for function match
def test_match():
    command = Command('cat test', 'cat: test: Is a directory')
    assert match(command)



# Generated at 2022-06-24 05:57:38.314325
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp/'))
    assert not match(Command('ls /tmp/'))
    assert not match(Command('cat /tmp/test.txt'))



# Generated at 2022-06-24 05:57:39.792892
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test') == 'ls test'


# Generated at 2022-06-24 05:57:42.173101
# Unit test for function match
def test_match():
    assert match(Command('cat app tests',
                         output='cat: app: Is a directory'))
    assert not match(Command('cat foo bar',
                             output='foo'))

# Generated at 2022-06-24 05:57:44.254376
# Unit test for function get_new_command
def test_get_new_command():
    output = subprocess.check_output('cat testfiles', shell=True)
    command = Command('cat testfiles', '', output)
    assert get_new_command(command) == 'ls testfiles'

# Generated at 2022-06-24 05:57:45.798569
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /etc/hosts')
    assert get_new_command(command) == 'ls /etc/hosts'

# Generated at 2022-06-24 05:57:47.110332
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat somefile'
    assert get_new_command(command) == 'ls somefile'

# Generated at 2022-06-24 05:57:50.320617
# Unit test for function get_new_command
def test_get_new_command():

    # Initialize the command
    command = Command('cat test')

    # Test if get_new_command works
    assert get_new_command(command) == 'ls test'

# Generated at 2022-06-24 05:57:53.071176
# Unit test for function match
def test_match():
    os.path.isdir = lambda path: path.endswith('/')
    assert match(Command('cat /', 'cat: /: Is a directory\n'))



# Generated at 2022-06-24 05:58:01.541075
# Unit test for function match
def test_match():
    assert match(Command(script='cat index.html', output='cat: index.html: Is a directory'))
    assert not match(Command(script='cat index.html', output='cat: index.html: No such file or directory'))
    assert match(Command(script='cat index.html', output='cat: index.html: No such file or directory', stderr='cat: index.html: No such file or directory'))
    assert not match(Command(script='cat index.html foo', output='cat: index.html: No such file or directory\ncat: foo: No such file or directory'))
    assert not match(Command(script='cat index.html foo', output='cat: index.html: No such file or directory\ncat: foo: Is a directory'))


# Generated at 2022-06-24 05:58:03.599777
# Unit test for function match
def test_match():

    command = Command('cat fuck', '')
    assert match(command)

    command = Command('fuck cat', '')
    assert not match(command)


# Generated at 2022-06-24 05:58:05.155675
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('cat', 'cat: foo: Is a directory', 'foo')) == 'ls'

# Generated at 2022-06-24 05:58:06.157410
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /etc').script == 'ls /etc'

# Generated at 2022-06-24 05:58:12.558812
# Unit test for function match
def test_match():
    assert match(Command(script='cat README.md',
                         output='cat: README.md: Is a directory'))
    assert not match(Command(script='cat README.md',
                             output='README.md: Is a directory'))
    assert not match(Command(script='ls README.md',
                             output='cat: README.md: Is a directory'))



# Generated at 2022-06-24 05:58:14.360952
# Unit test for function match
def test_match():
    command = Command('cat lol', '')
    assert match(command)
    # TODO: Better test


# Generated at 2022-06-24 05:58:17.082297
# Unit test for function match
def test_match():
    command = Command('cat ./')
    assert match(command)

    command = Command('cat ./not_existing_file')
    assert not match(command)


# Generated at 2022-06-24 05:58:19.884159
# Unit test for function match
def test_match():
    from thefuck.rules.cat_isdir import match
    command = 'cat /etc/apt/sources.list'
    assert match(command)



# Generated at 2022-06-24 05:58:27.362773
# Unit test for function get_new_command
def test_get_new_command():
    # Test case 1: get_new_command('cat')
    command_input = Command('cat')
    assert get_new_command(command_input) == 'ls'
    # Test case 2: get_new_command('cat test')
    command_input = Command('cat test')
    assert get_new_command(command_input) == 'ls test'
    # Test case 3: get_new_command('cat test test2/')
    command_input = Command('cat test test2/')
    assert get_new_command(command_input) == 'ls test test2/'


# Generated at 2022-06-24 05:58:30.724547
# Unit test for function match
def test_match():
    assert(match(Command('', 'cat foo', 'cat: foo: Is a directory')))
    assert not (match(Command('', 'cat foo', 'cat: foo: Is not a directory')))
    assert not (match(Command('', 'cat foo', 'cat: foo: No ')))
    assert not (match(Command('', 'ls foo', 'cat: foo: Is a directory')))


# Generated at 2022-06-24 05:58:36.845602
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('cat /etc/hosts') == 'ls /etc/hosts')
    assert (get_new_command('cat /etc/hosts -l') == 'ls /etc/hosts -l')
    assert (get_new_command('cat') == 'ls')
    assert (get_new_command('cat -l') == 'ls -l')

# Generated at 2022-06-24 05:58:39.838670
# Unit test for function match
def test_match():
    assert match("cat **/*.py")
    assert match("cat -- **/*.py")
    assert not match("cat **/*.py 2>&1")



# Generated at 2022-06-24 05:58:43.425448
# Unit test for function match
def test_match():
    list = ['cat: hello.py: Is a directory',
        'cat: no.py: Is a directory',
        'cat hello.txt']
    for i in range(len(list)):
        assert match(Command(script=list[i], output=list[i]))


# Generated at 2022-06-24 05:58:45.655696
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('zsh', script='cat /Users/')) == 'zsh -c ls /Users/')

# Generated at 2022-06-24 05:58:55.877077
# Unit test for function get_new_command
def test_get_new_command():
    print('Testing get_new_command')
    assert get_new_command(['cat', '../test/test_pwd', '-a']) == ['ls', '../test/test_pwd', '-a']
    assert get_new_command(['cat ~/Documents/try_pwd -a']) == ['ls', '~/Documents/try_pwd', '-a']
    assert get_new_command(['cat', '~/Documents/try_pwd', '-a']) == ['ls', '~/Documents/try_pwd', '-a']
    assert get_new_command(['cat', '/Documents/try_pwd', '-a']) == ['ls', '/Documents/try_pwd', '-a']

# Generated at 2022-06-24 05:58:59.478122
# Unit test for function match
def test_match():
    assert not match(Command('ls', '', ''))
    assert not match(Command('cat foo', '', 'cat: foo: Is a directory'))
    assert match(Command('cat bar/', '', 'cat: bar/: Is a directory'))



# Generated at 2022-06-24 05:59:02.247188
# Unit test for function match
def test_match():
    assert match(Command(script='cat', output='cat: /bin: Is a directory\n'))
    assert not match(Command(script='cat', output='cat: /bin: Is not a directory\n'))
    
    

# Generated at 2022-06-24 05:59:04.743304
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home/test/testfile.txt')
    assert get_new_command(command) == 'ls /home/test/testfile.txt'


# Generated at 2022-06-24 05:59:06.865566
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test_dir') == 'ls test_dir'

# Generated at 2022-06-24 05:59:08.781769
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat file.txt') == 'ls file.txt'



# Generated at 2022-06-24 05:59:10.214115
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))

# Generated at 2022-06-24 05:59:14.008719
# Unit test for function match
def test_match():
    assert match(Command('cat foo bar', 'cat: bar: Is a directory\n'))
    assert not match(Command('cat foo.py', 'foo.py'))
    assert not match(Command('cat foo', 'foo'))
    assert not match(Command('cat foo bar', 'foo bar'))


# Generated at 2022-06-24 05:59:19.591949
# Unit test for function match
def test_match():
    command = Command('cat test', 'cat: test: Is a directory')
    assert match(command)
    command = Command('cat test.py', 'cat: test.py: No such file or directory')
    assert not match(command)
    command = Command('cat test test.py', 'cat: test.py: No such file or directory')
    assert not match(command)


# Generated at 2022-06-24 05:59:24.829081
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat dir/') == 'ls dir/'
    assert get_new_command('cat dir') == 'ls dir'
    assert get_new_command('cat dir/test') == 'ls dir/test'
    assert get_new_command('cat dir/test/') == 'ls dir/test/'
    assert get_new_command('cat dir/test/') == 'ls dir/test/'

# Generated at 2022-06-24 05:59:26.805005
# Unit test for function match
def test_match():
    command = Command('cat /home/user', '/home/user', 'File not found')
    assert match(command)



# Generated at 2022-06-24 05:59:30.784977
# Unit test for function match
def test_match():
    command = Command('cat /home', 'cat: /home: Is a directory')
    assert match(command)
    command = Command('cat /home', 'cat: /home')
    assert not match(command)
    command = Command('ls /home', 'cat: /home: Is a directory')
    assert not match(command)


# Generated at 2022-06-24 05:59:34.776078
# Unit test for function match
def test_match():
    app = "cat"

# Generated at 2022-06-24 05:59:36.777842
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat --version') == 'ls --version'

# Generated at 2022-06-24 05:59:41.099154
# Unit test for function get_new_command
def test_get_new_command():
    commands = ['cat /usr/local/Cellar/', 'cat /usr/local/share']
    expected_results = [
        'ls /usr/local/Cellar/',
        'ls /usr/local/share']
    assert list(map(get_new_command, map(Command, commands))) == expected_results

# Generated at 2022-06-24 05:59:45.306510
# Unit test for function match
def test_match():
    cat_dir = Command('cat /home', 'cat: /home: Is a directory')
    cat_nonexist = Command('cat /nonexistfile', '')
    assert match(cat_dir)
    assert not match(cat_nonexist)



# Generated at 2022-06-24 05:59:46.668072
# Unit test for function match
def test_match():
    assert match(Command('cat /etc'))
    assert not match(Command('cat /etc/hosts'))


# Generated at 2022-06-24 05:59:50.052823
# Unit test for function match
def test_match():
    assert not match(Command('ls a', ''))
    assert match(Command('cat a', 'cat: a: Is a directory'))
    assert not match(Command('cat a b', ''))
    assert not match(Command('cat a', 'cat: a: No such file or directory'))


# Generated at 2022-06-24 05:59:54.590342
# Unit test for function match
def test_match():
    # Create command object
    command = Command('cat test.txt', 'cat: test.txt: is a directory')
    # Initialize match
    assert match(command)
    command = Command('cat test.txt', '')
    assert not match(command)
    

# Generated at 2022-06-24 05:59:58.043671
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('cat /home/', 'cat: /home/: Is a directory')
    assert get_new_command(command) == 'ls /home/'

# Generated at 2022-06-24 06:00:00.817843
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat /etc/issue', stdout='cat: /etc/issue: Is a directory\n')
    assert get_new_command(command) == 'ls /etc/issue'

# Generated at 2022-06-24 06:00:03.465588
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat test', 'cat: test: Is a directory')
    assert get_new_command(command) == 'ls test'

# Generated at 2022-06-24 06:00:05.598356
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat test", "cat: test: Is a directory\n")

    assert get_new_command(command) == "ls test"

# Generated at 2022-06-24 06:00:07.205541
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat file.txt') == 'ls file.txt'

# Generated at 2022-06-24 06:00:12.241343
# Unit test for function match
def test_match():
    assert not match(Command("cat foobar"))
    assert not match(Command("cat", output="foobar"))
    assert match(Command("cat foobar", output="cat: foobar: Is a directory\n"))
    assert match(Command("cat foobar", output="cat: foobar: No such file or directory\n"))
    assert match(Command("cat foobar", output="cat: foobar: Permission denied\n"))


# Generated at 2022-06-24 06:00:14.196138
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    assert get_new_command(Command('cat /etc/')) == 'ls /etc/'

# Generated at 2022-06-24 06:00:16.801993
# Unit test for function match
def test_match():
    assert match(Command('cat /home/c/ ', None, '', 'cat: /home/c/: Is a directory\n', '', 1)) != None


# Generated at 2022-06-24 06:00:20.680332
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_directory import match, get_new_command
    assert match(Command('cat .', ''))
    assert get_new_command(Command('cat .', '')) == 'ls .'

# Generated at 2022-06-24 06:00:26.862793
# Unit test for function get_new_command
def test_get_new_command():
    cat_command = Command('cat a b c',
                          'cat: a: Is a directory\ncat: b: Is a directory\ncat: c: Is a directory')
    ls_command = Command('ls a b c',
                         'ls: a/:\nls: b/:\nls: c/:\n')
    assert get_new_command(cat_command) == str(ls_command)

# Generated at 2022-06-24 06:00:28.661560
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /root/') == 'ls /root/'

# Generated at 2022-06-24 06:00:33.523046
# Unit test for function match
def test_match():
    assert match(Command('cat test', '/bin/cat: test: Is a directory',
                         '', 1, None, None))
    assert not match(Command('cat test', '', '', 1, None, None))
    assert not match(Command('ls test', '/bin/ls: test: Is a directory',
                         '', 1, None, None))

# Generated at 2022-06-24 06:00:35.710313
# Unit test for function get_new_command
def test_get_new_command():
    command = "cat /home/bakunin/Documents/"
    assert get_new_command(command) == command.replace('cat', 'ls', 1)

# Generated at 2022-06-24 06:00:37.302713
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('cat /')) == 'ls /')


# Generated at 2022-06-24 06:00:41.087718
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'test: Is a directory'))
    assert not match(Command('cat test', 'test: Is not a directory'))
    assert not match(Command('cat test', '', stderr='test: Is a directory'))
    assert not match(Command('cat', 'test: Is a directory'))


# Generated at 2022-06-24 06:00:44.479235
# Unit test for function match
def test_match():
    command = type('', (), {})()
    command.output = 'cat: file.txt: Is a directory'
    command.script_parts = ['cat', 'file.txt']

    get_new_command(command) == 'ls file.txt'

# Generated at 2022-06-24 06:00:53.790639
# Unit test for function match
def test_match():
    # cat should work if we are not getting an error
    assert not match(Command('cat test.txt', 'test\n', None, 0, 'cat'))

    # cat should only match if we get "cat 'filename': is a directory"
    assert not match(Command('cat test.txt', 'cat: test.txt: is a directory', None, 1, 'cat'))

    # We should not match if there are other issues
    assert not match(Command('cat test.txt', 'cat: test.txt: No such file or directory', None, 1, 'cat'))
    assert not match(Command('cat test.txt', 'cat: test.txt: Permission denied', None, 1, 'cat'))


# Generated at 2022-06-24 06:00:55.689893
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status | cat')
    assert get_new_command(command).script == 'git status | ls'

# Generated at 2022-06-24 06:00:57.733118
# Unit test for function match
def test_match():
    assert match(Command('cat /abc', ''))
    assert not match(Command('git cat-file', ''))

# Generated at 2022-06-24 06:01:02.624406
# Unit test for function match
def test_match():
    fake_command = Command('cat /etc/hh')
    assert match(fake_command)
    fake_command = Command('tac /etc/hh')
    assert not match(fake_command)
    fake_command = Command('tac /etc/hh')
    assert not match(fake_command)
    fake_command = Command('cat /root/abc')
    assert not match(fake_command)


# Generated at 2022-06-24 06:01:05.484344
# Unit test for function match
def test_match():
    assert match(Command('cat root', ''))
    assert not match(Command('cat root', '', ''))


# Generated at 2022-06-24 06:01:08.065903
# Unit test for function match
def test_match():
    from thefuck.rules.cat_is_not_a_command import match
    command = 'cat README.md'
    assert match(command) is True

# Generated at 2022-06-24 06:01:12.760227
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', None, 'cat: file.txt: is a directory', ''))
    assert not match(Command('cat file.txt', None, "cat: file.txt: No such file or directory", ''))
    assert not match(Command('cat file.txt', None, "cat: file.txt: Is a directory", ''))



# Generated at 2022-06-24 06:01:16.548698
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home/user/', '', '', 'cat: /tmp/: Is a directory')
    assert get_new_command(command) == 'ls /home/user/'

# Generated at 2022-06-24 06:01:18.495949
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command('cat desktop')
    assert result == 'ls desktop', result



# Generated at 2022-06-24 06:01:24.601261
# Unit test for function match
def test_match():
    helper = MockCommand(script='cat foobar.txt',
            output='cat: foobar.txt: Is a directory')
    assert match(helper) is True

    helper = MockCommand(script='cat foobar.txt',
            output='cat: foobar.txt: No such file or directory')
    assert match(helper) is False

    helper = MockCommand(script='foo bar',
            output='cat: bar: Is a directory')
    assert match(helper) is False

# Generated at 2022-06-24 06:01:27.175772
# Unit test for function match
def test_match():
    command = Command("cat main.cpp", "cat: main.cpp: Is a directory")
    assert match(command)



# Generated at 2022-06-24 06:01:30.552227
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat test_dir', '', 'cat: test_dir: Is a directory\n')
    assert get_new_command(command) == 'ls test_dir'

# Generated at 2022-06-24 06:01:35.146185
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /etc/passwd', '', 'cat: /etc/passwd: Is a directory')
    assert get_new_command(command) == 'ls /etc/passwd'
    command = Command('cat /etc/passwd', '', 'cat: /etc/passwd: No such file or directory')
    assert get_new_command(command) == 'cat /etc/passwd'


# Generated at 2022-06-24 06:01:38.921294
# Unit test for function match
def test_match():
    # True case
    os.system("touch test1.txt")
    assert match(Command("cat test1.txt", "cat: test1.txt: Is a directory", ""))
    # False case
    os.system("rm -f test1.txt")
    assert not match(Command("cat test.txt", "test.txt: No such file or directory", ""))
    assert not match(Command("cat test1.txt", "test1.txt: No such file or directory", ""))


# Generated at 2022-06-24 06:01:44.066392
# Unit test for function match
def test_match():
    assert match(Command('cat code'))
    assert not match(Command(''))
    assert not match(Command('cat code', '', 'codecodecode'))
    assert not match(Command('cat code'))
    assert match(Command('cat script.py', '', 'script.py is a directory'))
    assert not match(Command("ls script.py", '', 'script.py is a directory'))



# Generated at 2022-06-24 06:01:46.633355
# Unit test for function get_new_command
def test_get_new_command():
    command = "cat ~/testfile"
    assert get_new_command(command) == "ls ~/testfile"

# Generated at 2022-06-24 06:01:48.025352
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat *')) == 'ls *'

# Generated at 2022-06-24 06:01:50.803444
# Unit test for function get_new_command
def test_get_new_command():
    return_command = "ls ./"
    assert return_command == get_new_command(Command('cat ./', 'cat: ./', '', 1))

# Generated at 2022-06-24 06:01:57.358560
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_dir import get_new_command

    assert get_new_command(Command('cat dir', '', '')) == 'ls dir'
    assert get_new_command(Command('cat dir1 dir2', '', '')) == 'ls dir1 dir2'
    assert get_new_command(Command('cat /usr/bin/', '', '')) == 'ls /usr/bin/'
    assert get_new_command(Command('cat -a /usr/bin/', '', '')) == 'ls -a /usr/bin/'

# Generated at 2022-06-24 06:01:59.934373
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /my/path')
    assert get_new_command(command) == 'ls /my/path'

# Generated at 2022-06-24 06:02:04.164200
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /tmp') == 'ls /tmp'
    assert get_new_command('  cat "tmp"') == 'ls "tmp"'

enabled_by_default = True

# Generated at 2022-06-24 06:02:06.594429
# Unit test for function match
def test_match():
    cmd = Command('cat nonExistantFile')
    assert match(cmd)
    cmd = Command('cat /etc/vimrc')
    assert not match(cmd)


# Generated at 2022-06-24 06:02:09.932143
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat www').script == 'ls www'
    assert get_new_command('cat hello.txt').script == 'cat hello.txt'



# Generated at 2022-06-24 06:02:15.893086
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="/home/neel/Development/Open-Source/PyWallpaper/.gitignore",
                      stdout="cat: /home/neel/Development/Open-Source/PyWallpaper/.gitignore: Is a directory",
                      stderr="",)
    assert get_new_command(command) == 'ls /home/neel/Development/Open-Source/PyWallpaper/.gitignore'

# Generated at 2022-06-24 06:02:17.232052
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat b") == "ls b"

# Generated at 2022-06-24 06:02:19.104920
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /home/')) == 'ls /home/'

# Generated at 2022-06-24 06:02:21.809120
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script': "cat /opt/", 'script_parts': ['cat', '/opt/']})
    assert get_new_command(command) == "ls /opt/"


# Generated at 2022-06-24 06:02:25.055023
# Unit test for function match
def test_match():
    assert match(Command('cat 1', None, 'cat: 1: Is a directory'))
    assert not match(Command('cat 1', None, 'cat: 1: no such file'))

# Generated at 2022-06-24 06:02:27.511535
# Unit test for function match
def test_match():
    command = Command(
        '/bin/cat test.txt',
        'cat: test.txt: Is a directory'
    )
    assert match(command)



# Generated at 2022-06-24 06:02:31.079924
# Unit test for function get_new_command
def test_get_new_command():
    command_ls_dir = Command(
        script='', 
        stderr='cat: .: Is a directory', 
        script_parts=[], 
        output='cat: .: Is a directory')
    assert get_new_command(command_ls_dir) == ''
    

# Generated at 2022-06-24 06:02:32.710924
# Unit test for function match
def test_match():
    assert match(Command('cat file'))
    assert not match(Command('ls file'))

# Generated at 2022-06-24 06:02:36.319180
# Unit test for function match
def test_match():
    assert match(Command('cat foo', 'cat: foo: Is a directory\n'))
    assert not match(Command('ls foo', 'cat: foo: Is a directory\n'))
    assert not match(Command('foo', 'cat: foo: Is a directory\n'))


# Generated at 2022-06-24 06:02:41.370572
# Unit test for function match
def test_match():
    assert match(Command('cat path', 'cat: path: Is a directory', None))
    assert not match(Command('cat path', 'cat: path: No such file', None))
    assert not match(Command('ls path', 'cat: path: Is a directory', None))



# Generated at 2022-06-24 06:02:46.227232
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', output='cat: file.txt: Is a directory'))
    assert not match(Command('cat file.txt', output='cat: file.txt: Is a directory',
                             script_parts=['ls', 'file.txt']))
    assert not match(Command('cat file.txt', output='cat: file.txt: No such file or directory'))

# Generated at 2022-06-24 06:02:47.163607
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat') == 'ls'

# Generated at 2022-06-24 06:02:49.615825
# Unit test for function get_new_command
def test_get_new_command():
    command = "cat /tmp/dir"
    expected_new_command = "ls /tmp/dir"
    assert get_new_command(command) == expected_new_command

# Generated at 2022-06-24 06:02:53.321471
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /usr/local/') == 'ls /usr/local/'  # cat /usr/local/
    assert get_new_command('cat /etc/hosts') == 'cat /etc/hosts'   # the file /etc/hosts exists
    assert get_new_command('cat -a /etc/hosts') == 'cat -a /etc/hosts' # the file /etc/hosts exists

# Generated at 2022-06-24 06:03:01.850255
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat ABC', stderr=b'cat: ABC: Is a directory\n')) == 'ls ABC'
    assert get_new_command(Command(script='cat asdf', stderr=b'cat: asdf: No such file or directory\n')) == 'cat asdf'
    assert get_new_command(Command(script='cat asdf', stderr=b'cat: asdf: No such file or directory\n')) == 'cat asdf'



# Generated at 2022-06-24 06:03:10.905528
# Unit test for function match
def test_match():
    # first command does not work
    assert not match(Command(script="cat lololol.txt", output="cat: lololol.txt: No such file or directory"))
    # second command does not work
    assert not match(Command(script="cat lololol", output="cat: lololol: Is a directory"))
    # third command does not work
    assert not match(Command(script="cat --lololol", output="cat: invalid option -- 'l'"))
    # fourth command works
    assert match(Command(script="cat lololol", output="cat: lololol: Is a directory"))


# Generated at 2022-06-24 06:03:14.993439
# Unit test for function match
def test_match():
    match(Command("cat missing_file",
                  "cat: missing_file: No such file or directory"))
    match(Command("cat missing_dir",
                  "cat: missing_dir: Is a directory",
                  "missing_dir"))
    assert not match(Command("cat", "missing_file"))

# Generated at 2022-06-24 06:03:21.217471
# Unit test for function match
def test_match():
    assert match(Command(script='cat /halloo', output='cat: /halloo: Is a directory', stderr='cat: /halloo: Is a directory',))
    assert not match(Command(script='cat /hallo', output='cat: /halloo: Is a directory', stderr='cat: /halloo: Is a directory',))
    assert not match(Command(script='cat /hallo', output='cat: /halloo: No such file or directory', stderr='cat: /halloo: No such file or directory',))
