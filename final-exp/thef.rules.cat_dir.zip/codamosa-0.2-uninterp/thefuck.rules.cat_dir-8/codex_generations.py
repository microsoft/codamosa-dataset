

# Generated at 2022-06-18 07:28:47.379812
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('ls /home/user/', 'ls: /home/user/: Is a directory'))


# Generated at 2022-06-18 07:28:53.349429
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', 'cat: file.txt: Is a directory'))
    assert not match(Command('cat file.txt', 'cat: file.txt: No such file'))
    assert not match(Command('cat file.txt', 'cat: file.txt: No such file',
                             stderr='cat: file.txt: No such file'))


# Generated at 2022-06-18 07:29:00.519948
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))

# Generated at 2022-06-18 07:29:10.553032
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:29:14.751351
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:29:24.443252
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such device or address'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))

# Generated at 2022-06-18 07:29:30.382306
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '', '', '', '', ''))


# Generated at 2022-06-18 07:29:35.780461
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))


# Generated at 2022-06-18 07:29:46.724307
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))

# Generated at 2022-06-18 07:29:51.559948
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))

# Generated at 2022-06-18 07:29:57.788363
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory\n'))
    assert not match(Command('cat test', ''))
    assert not match(Command('ls test', 'cat: test: Is a directory\n'))


# Generated at 2022-06-18 07:30:05.361287
# Unit test for function match
def test_match():
    command = Command('cat /home/', 'cat: /home/: Is a directory')
    assert match(command)
    command = Command('cat /home/', 'cat: /home/: No such file or directory')
    assert not match(command)
    command = Command('cat /home/', 'cat: /home/: Permission denied')
    assert not match(command)


# Generated at 2022-06-18 07:30:09.721679
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:30:15.742693
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory',
                             stderr='cat: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:30:20.536486
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:30:30.317586
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/', 'ls /home/', 'ls /home/'))

# Generated at 2022-06-18 07:30:36.094191
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory', stderr='cat: /home/user/: No such file or directory'))


# Generated at 2022-06-18 07:30:41.717766
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory', ''))
    assert not match(Command('cat /home/', '', ''))
    assert not match(Command('ls /home/', 'cat: /home/: Is a directory', ''))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory', ''))


# Generated at 2022-06-18 07:30:48.332836
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such device or address'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Text file busy'))

# Generated at 2022-06-18 07:30:56.069504
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '/etc/hosts'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '/etc/hosts', 'cat'))


# Generated at 2022-06-18 07:31:06.091139
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:31:11.056231
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:31:15.932463
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', '', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/passwd', '', 'root:x:0:0:root:/root:/bin/bash'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: No such file or directory'))



# Generated at 2022-06-18 07:31:20.965087
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:31:22.873198
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))

# Generated at 2022-06-18 07:31:25.893954
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'test'))


# Generated at 2022-06-18 07:31:31.225572
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file', 'cat: /etc/hosts: Is a directory'))


# Generated at 2022-06-18 07:31:35.032844
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:31:39.093832
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:31:42.673057
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:32:00.573931
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:32:10.518300
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '', 1))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '', 123))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '', 0))


# Generated at 2022-06-18 07:32:16.745673
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', 'sudo'))


# Generated at 2022-06-18 07:32:20.827559
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:32:24.909880
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory', '', 1))


# Generated at 2022-06-18 07:32:34.400328
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory\n'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory\ncat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory\ncat: /etc/: No such file or directory\n'))

# Generated at 2022-06-18 07:32:39.131813
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('ls /home/user/', 'ls: /home/user/: Is a directory'))


# Generated at 2022-06-18 07:32:42.263382
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))

# Generated at 2022-06-18 07:32:52.882441
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory', '', 1))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory', '', 2))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory', '', 3))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory', '', 4))
    assert not match

# Generated at 2022-06-18 07:32:58.864918
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such device or address'))


# Generated at 2022-06-18 07:33:33.318849
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:33:37.985436
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', 'ls'))


# Generated at 2022-06-18 07:33:47.142269
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:33:52.046124
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:33:57.002116
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:34:06.136006
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: Is a directory', script='cat /etc/'))

# Generated at 2022-06-18 07:34:11.875363
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:34:17.590062
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'cat /etc/hosts'))


# Generated at 2022-06-18 07:34:22.066789
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:34:26.807666
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:35:35.234493
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))

# Generated at 2022-06-18 07:35:41.963478
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: Is a directory', stderr='cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: Is a directory', stderr='cat: /home/user/: Is a directory', script='ls /home/user/'))


# Generated at 2022-06-18 07:35:44.433685
# Unit test for function match
def test_match():
    assert match(Command('cat file', 'cat: file: Is a directory'))
    assert not match(Command('cat file', 'cat: file: No such file or directory'))
    assert not match(Command('cat file', 'file'))


# Generated at 2022-06-18 07:35:48.296003
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('ls /etc/hosts', 'ls: /etc/hosts: Is a directory'))


# Generated at 2022-06-18 07:35:51.875369
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:35:54.813525
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:35:57.379668
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'test'))


# Generated at 2022-06-18 07:36:03.846787
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', stderr='cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', stderr='cat: /etc/hosts: No such file or directory', script='cat /etc/hosts'))

# Generated at 2022-06-18 07:36:07.581891
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is not a directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:36:09.447727
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', ''))
    assert not match(Command('cat /etc/passwd', '', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory', ''))


# Generated at 2022-06-18 07:38:30.303098
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))


# Generated at 2022-06-18 07:38:34.646472
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:38:37.923936
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', 'cat: /home/: Is a directory'))


# Generated at 2022-06-18 07:38:41.660278
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: Is a directory',
                             'cat: test: Is a directory'))


# Generated at 2022-06-18 07:38:52.010601
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))