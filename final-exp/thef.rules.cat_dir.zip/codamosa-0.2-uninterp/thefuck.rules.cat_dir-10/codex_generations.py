

# Generated at 2022-06-18 07:28:50.757830
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: Is a directory'))


# Generated at 2022-06-18 07:28:55.122730
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', 'cat: /home/: Is a directory'))

# Generated at 2022-06-18 07:28:58.661607
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: Is a directory', 'ls test'))


# Generated at 2022-06-18 07:29:05.711638
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:29:15.628614
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', '', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: No such device or address'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:29:22.575220
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))


# Generated at 2022-06-18 07:29:25.640759
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:29:33.447779
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:29:37.031262
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:29:43.574656
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/dir', 'cat: /home/user/dir: Is a directory'))
    assert not match(Command('cat /home/user/dir', 'cat: /home/user/dir: No such file or directory'))
    assert not match(Command('cat /home/user/dir', 'cat: /home/user/dir: Is a directory', 'ls /home/user/dir'))


# Generated at 2022-06-18 07:29:51.004608
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))

# Generated at 2022-06-18 07:29:55.948654
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:29:59.057916
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:30:06.190365
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', 'cat: /home/: Is a directory'))


# Generated at 2022-06-18 07:30:10.605648
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', 'ls'))


# Generated at 2022-06-18 07:30:16.366373
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', '', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', '', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', '', 'ls: /home/: No such file or directory'))


# Generated at 2022-06-18 07:30:21.160596
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:30:24.554843
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('ls test', 'cat: test: Is a directory'))


# Generated at 2022-06-18 07:30:29.133589
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:30:34.068679
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))


# Generated at 2022-06-18 07:30:46.976737
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', ''))
    assert not match(Command('cat /etc/passwd', '', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory', ''))


# Generated at 2022-06-18 07:30:50.208908
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', ''))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:31:00.552010
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))

# Generated at 2022-06-18 07:31:05.740724
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a file'))


# Generated at 2022-06-18 07:31:16.088748
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/', 'ls /etc/', 'ls /etc/'))

# Generated at 2022-06-18 07:31:20.748000
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:31:25.893993
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:31:32.063901
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory\n'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory\n\n'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory\n\n\n'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory\n\n\n\n'))

# Generated at 2022-06-18 07:31:37.543874
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:31:43.321310
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', '/etc/passwd'))
    assert not match(Command('cat /etc/passwd', '', '/etc/passwd'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', '/etc/passwd', 'sudo'))


# Generated at 2022-06-18 07:32:00.369087
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:32:08.263429
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file', 'cat: /etc/hosts: Is a directory'))


# Generated at 2022-06-18 07:32:13.182902
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:32:18.669649
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: Permission denied'))


# Generated at 2022-06-18 07:32:22.570891
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('ls /etc/hosts', 'cat: /etc/hosts: Is a directory'))


# Generated at 2022-06-18 07:32:27.654712
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', '', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', '', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', '', 'cat: /home/: Is a directory'))

# Generated at 2022-06-18 07:32:32.700976
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', '', stderr='cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', '', stderr='cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:32:41.442613
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: Is a directory', 'ls /home/user/'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: Is a directory', 'ls /home/user/', 'ls /home/user/'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: Is a directory', 'ls /home/user/', 'ls /home/user/', 'ls /home/user/'))

# Generated at 2022-06-18 07:32:45.723811
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:32:50.668812
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:33:25.390539
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:33:31.080839
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Permission denied'))


# Generated at 2022-06-18 07:33:40.083816
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', '', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', '', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', '', 'cat: /etc/hosts: Permission denied'))
    assert not match(Command('cat /etc/hosts', '', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', '', 'cat: /etc/hosts: Permission denied'))
    assert not match(Command('cat /etc/hosts', '', 'cat: /etc/hosts: No such file or directory'))

# Generated at 2022-06-18 07:33:43.995870
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a file'))


# Generated at 2022-06-18 07:33:48.575554
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:33:52.747357
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:33:57.491015
# Unit test for function match
def test_match():
    assert match(Command('cat /dev/null', 'cat: /dev/null: Is a directory'))
    assert not match(Command('cat /dev/null', ''))
    assert not match(Command('cat /dev/null', 'cat: /dev/null: No such file or directory'))


# Generated at 2022-06-18 07:34:00.813484
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is not a directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:34:03.612342
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', ''))
    assert not match(Command('ls test', 'cat: test: Is a directory'))


# Generated at 2022-06-18 07:34:07.316563
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a file'))


# Generated at 2022-06-18 07:35:12.614468
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', stderr='cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', stderr='cat: /home/: Is a directory', script='ls /home/'))


# Generated at 2022-06-18 07:35:17.683182
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', ''))
    assert not match(Command('cat /etc/', '', ''))
    assert not match(Command('cat /etc/', '', '', ''))
    assert not match(Command('cat /etc/', '', '', '', ''))
    assert not match(Command('cat /etc/', '', '', '', '', ''))
    assert not match(Command('cat /etc/', '', '', '', '', '', ''))
    assert not match(Command('cat /etc/', '', '', '', '', '', '', ''))
    assert not match(Command('cat /etc/', '', '', '', '', '', '', '', ''))

# Generated at 2022-06-18 07:35:29.115508
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No space left on device'))

# Generated at 2022-06-18 07:35:35.774859
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory', 'ls /etc/hosts'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory', 'ls /etc/hosts', 'cat /etc/hosts'))


# Generated at 2022-06-18 07:35:38.679223
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:35:44.083985
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory\n'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory\n'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory\n',
                             '/etc/passwd'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory\n',
                             '/etc/passwd', '-l'))


# Generated at 2022-06-18 07:35:51.844402
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:35:54.337800
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', ''))


# Generated at 2022-06-18 07:35:56.923256
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:35:59.283793
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: Is a directory'))

# Generated at 2022-06-18 07:37:16.489251
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory',
                             stderr='cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory',
                             stderr='cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:37:21.044951
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', 'cat: file.txt: Is a directory', ''))
    assert not match(Command('cat file.txt', '', ''))
    assert not match(Command('cat file.txt', 'cat: file.txt: No such file or directory', ''))


# Generated at 2022-06-18 07:37:25.356526
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:37:28.996383
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', ''))
    assert not match(Command('ls test', 'cat: test: Is a directory'))


# Generated at 2022-06-18 07:37:36.972182
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory', script='cat /etc/'))

# Generated at 2022-06-18 07:37:42.419564
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:37:46.754386
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', 'sudo'))


# Generated at 2022-06-18 07:37:51.434696
# Unit test for function match
def test_match():
    assert match(Command('cat /etc', 'cat: /etc: Is a directory'))
    assert not match(Command('cat /etc', 'cat: /etc: No such file or directory'))
    assert not match(Command('cat /etc', 'cat: /etc: No such file or directory',
                             stderr='cat: /etc: No such file or directory'))


# Generated at 2022-06-18 07:37:58.337629
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory', '', 1))


# Generated at 2022-06-18 07:38:02.403324
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))
