

# Generated at 2022-06-18 07:28:46.836070
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp/', 'cat: /tmp/: Is a directory'))
    assert not match(Command('cat /tmp/', 'cat: /tmp/: No such file or directory'))
    assert not match(Command('ls /tmp/', 'cat: /tmp/: Is a directory'))

# Generated at 2022-06-18 07:28:50.706474
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:28:55.081227
# Unit test for function match
def test_match():
    assert match(Command('cat /etc', 'cat: /etc: Is a directory'))
    assert not match(Command('cat /etc', 'cat: /etc: No such file or directory'))
    assert not match(Command('cat /etc', 'cat: /etc: Is a file'))


# Generated at 2022-06-18 07:28:58.569308
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', '', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: Permission denied'))


# Generated at 2022-06-18 07:29:04.195218
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:29:14.238230
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:29:18.716436
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))

# Generated at 2022-06-18 07:29:21.718317
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))


# Generated at 2022-06-18 07:29:25.013033
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:29:32.375529
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Permission denied'))


# Generated at 2022-06-18 07:29:40.804310
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory', ''))
    assert not match(Command('cat /etc/', '', ''))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory', ''))


# Generated at 2022-06-18 07:29:50.150172
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such device or address'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:29:55.261542
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))

# Generated at 2022-06-18 07:29:59.097570
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', 'cat: /home/: Is a directory'))

# Generated at 2022-06-18 07:30:10.484244
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such device or address'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))

# Generated at 2022-06-18 07:30:16.552181
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/test', 'cat: /home/user/test: Is a directory'))
    assert not match(Command('cat /home/user/test', 'cat: /home/user/test: No such file or directory'))
    assert not match(Command('cat /home/user/test', 'cat: /home/user/test: Is a file'))


# Generated at 2022-06-18 07:30:19.900434
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:30:25.254804
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:30:29.631479
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', 'cat: /home/: Is a directory'))


# Generated at 2022-06-18 07:30:32.926817
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', ''))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:30:44.148716
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory', '', 1))


# Generated at 2022-06-18 07:30:48.101432
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', 'cat: file.txt: Is a directory', ''))
    assert not match(Command('cat file.txt', '', ''))
    assert not match(Command('cat file.txt', 'cat: file.txt: No such file or directory', ''))


# Generated at 2022-06-18 07:30:53.316909
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts',
                         '/etc/hosts is a directory',
                         '', 1))
    assert not match(Command('cat /etc/hosts',
                             '', '', 1))
    assert not match(Command('ls /etc/hosts',
                             '/etc/hosts is a directory',
                             '', 1))


# Generated at 2022-06-18 07:30:59.553781
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a file'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))


# Generated at 2022-06-18 07:31:05.018794
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))


# Generated at 2022-06-18 07:31:11.330057
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Permission denied'))


# Generated at 2022-06-18 07:31:16.887471
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is not a directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: Is a directory'))


# Generated at 2022-06-18 07:31:23.060112
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', 'ls'))


# Generated at 2022-06-18 07:31:27.194342
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:31:30.390334
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:31:46.476010
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: Is a directory',
                             'cat: test: Is a directory'))


# Generated at 2022-06-18 07:31:50.562900
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:31:53.843296
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))


# Generated at 2022-06-18 07:32:00.333900
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:32:05.194006
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))

# Generated at 2022-06-18 07:32:10.377041
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))


# Generated at 2022-06-18 07:32:13.575400
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', ''))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:32:18.711365
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))


# Generated at 2022-06-18 07:32:28.124963
# Unit test for function match
def test_match():
    assert match(Command('cat /etc', 'cat: /etc: Is a directory'))
    assert not match(Command('cat /etc', 'cat: /etc: No such file or directory'))
    assert not match(Command('cat /etc', 'cat: /etc: Permission denied'))
    assert not match(Command('cat /etc', 'cat: /etc: Input/output error'))
    assert not match(Command('cat /etc', 'cat: /etc: Resource temporarily unavailable'))
    assert not match(Command('cat /etc', 'cat: /etc: Cannot allocate memory'))
    assert not match(Command('cat /etc', 'cat: /etc: Bad file descriptor'))
    assert not match(Command('cat /etc', 'cat: /etc: Too many open files in system'))

# Generated at 2022-06-18 07:32:31.362712
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:33:05.433503
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory', 'ls /home/', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory', 'ls /home/', 'ls /home/', 'ls /home/'))


# Generated at 2022-06-18 07:33:09.700188
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:33:12.691041
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('ls test', 'cat: test: Is a directory'))


# Generated at 2022-06-18 07:33:23.121432
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))


# Generated at 2022-06-18 07:33:26.355052
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:33:31.875382
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:33:35.345618
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))

# Generated at 2022-06-18 07:33:39.572751
# Unit test for function match
def test_match():
    assert match(Command('cat /etc', 'cat: /etc: Is a directory'))
    assert not match(Command('cat /etc', 'cat: /etc: No such file or directory'))
    assert not match(Command('cat /etc', 'cat: /etc: Is a directory', 'ls /etc'))


# Generated at 2022-06-18 07:33:44.418939
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', '', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', '', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('ls /etc/passwd', '', 'cat: /etc/passwd: Is a directory'))


# Generated at 2022-06-18 07:33:46.262690
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:34:42.982036
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:34:47.169170
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a file'))


# Generated at 2022-06-18 07:34:50.292774
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))

# Generated at 2022-06-18 07:34:54.518588
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: Is a directory'))

# Generated at 2022-06-18 07:35:02.795995
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr=True))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr=False))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr=None))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr=''))


# Generated at 2022-06-18 07:35:10.711164
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such device or address'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))

# Generated at 2022-06-18 07:35:13.630321
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: Is a directory', 'ls test'))


# Generated at 2022-06-18 07:35:16.229595
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('ls test', 'cat: test: Is a directory'))


# Generated at 2022-06-18 07:35:27.488351
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/', 'ls /etc/', 'ls /etc/'))

# Generated at 2022-06-18 07:35:31.827304
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:37:53.149774
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a file'))


# Generated at 2022-06-18 07:37:57.298644
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp', 'cat: /tmp: Is a directory'))
    assert not match(Command('cat /tmp', ''))
    assert not match(Command('ls /tmp', 'cat: /tmp: Is a directory'))


# Generated at 2022-06-18 07:38:02.788292
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory', script='ls /etc/'))


# Generated at 2022-06-18 07:38:06.517057
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', '', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', '', 'ls: /etc/: Is a directory'))

# Generated at 2022-06-18 07:38:09.051354
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:38:16.810972
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory', stderr='cat: /home/: No such file or directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory', stderr='cat: /home/: No such file or directory', script='cat /home/'))

# Generated at 2022-06-18 07:38:19.985417
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:38:24.265296
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: Is a directory',
                             'cat: test: Is a directory'))


# Generated at 2022-06-18 07:38:28.628399
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('ls /home/user/', 'ls: /home/user/: Is a directory'))


# Generated at 2022-06-18 07:38:32.695788
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
