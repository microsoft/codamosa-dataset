

# Generated at 2022-06-18 07:28:51.268418
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: Is not a directory'))


# Generated at 2022-06-18 07:28:59.740862
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:29:05.449338
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:29:15.380569
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', '', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:29:20.829454
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: Is a directory', 'ls /home/user/'))


# Generated at 2022-06-18 07:29:23.365443
# Unit test for function match
def test_match():
    command = Command('cat test', 'cat: test: Is a directory')
    assert match(command)
    command = Command('cat test', 'cat: test: No such file or directory')
    assert not match(command)
    command = Command('cat test', 'cat: test: No such file or directory',
                      'cat: test: No such file or directory')
    assert not match(command)


# Generated at 2022-06-18 07:29:27.324181
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))


# Generated at 2022-06-18 07:29:33.301451
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('ls /home/user/', 'ls: /home/user/: Is a directory'))


# Generated at 2022-06-18 07:29:36.943694
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a file'))


# Generated at 2022-06-18 07:29:42.038752
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory', 'ls test'))


# Generated at 2022-06-18 07:29:47.989532
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: Is a directory'))

# Generated at 2022-06-18 07:29:54.179512
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '', '', '', '', '', ''))


# Generated at 2022-06-18 07:30:02.436717
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:30:09.628566
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory',
                             '/etc/passwd'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory',
                             '/etc/passwd', '-l'))


# Generated at 2022-06-18 07:30:15.211788
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:30:22.440952
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:30:31.699699
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory', script='cat /etc/'))

# Generated at 2022-06-18 07:30:35.945489
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', ''))
    assert not match(Command('cat /etc/passwd', '', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory', ''))


# Generated at 2022-06-18 07:30:38.641851
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))


# Generated at 2022-06-18 07:30:44.549550
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:30:54.143069
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:31:03.805343
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory', 'ls /etc/hosts'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory', 'ls /etc/hosts'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory', 'ls /etc/hosts'))

# Generated at 2022-06-18 07:31:08.978324
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: Is not a directory'))
    assert not match(Command('cat test', 'cat: test: No such directory'))


# Generated at 2022-06-18 07:31:14.351225
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:31:17.921347
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: Is a directory', 'ls test'))


# Generated at 2022-06-18 07:31:23.112879
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:31:27.513286
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '/etc/hosts'))


# Generated at 2022-06-18 07:31:31.659104
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:31:36.240934
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))


# Generated at 2022-06-18 07:31:45.664415
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', stderr='cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', stderr='cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', stderr='cat: /etc/: Is a directory'))

# Generated at 2022-06-18 07:32:04.246429
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:32:09.616948
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))

# Generated at 2022-06-18 07:32:14.330353
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('ls /home/user/', 'ls: /home/user/: Is a directory'))


# Generated at 2022-06-18 07:32:19.443546
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:32:22.460578
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))


# Generated at 2022-06-18 07:32:26.511006
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('ls test', 'cat: test: Is a directory'))


# Generated at 2022-06-18 07:32:36.477702
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory', script='cat /etc/'))

# Generated at 2022-06-18 07:32:43.927725
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert match(Command('cat test', 'cat: test: Is a directory\n'))
    assert not match(Command('cat test', 'cat: test: Is a directory\n',
                             stderr='cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: Is a directory\n',
                             stderr='cat: test: Is a directory\n'))
    assert not match(Command('cat test', 'cat: test: Is a directory\n',
                             stderr='cat: test: Is a directory\n',
                             script='ls test'))

# Generated at 2022-06-18 07:32:49.212990
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory',
                             stderr='cat: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:32:56.505172
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/', 'ls /etc/'))


# Generated at 2022-06-18 07:33:29.971488
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))


# Generated at 2022-06-18 07:33:34.370670
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))

# Generated at 2022-06-18 07:33:36.825738
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:33:40.835706
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', '', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', '', ''))


# Generated at 2022-06-18 07:33:44.970610
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', '', '', '', '', ''))

# Generated at 2022-06-18 07:33:51.260325
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:33:56.509557
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:33:59.954506
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:34:03.342374
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', ''))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:34:06.913520
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('ls /home/user/', 'ls: /home/user/: Is a directory'))


# Generated at 2022-06-18 07:35:09.805522
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:35:13.039756
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', '', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', '', 'ls: /etc/: Is a directory'))

# Generated at 2022-06-18 07:35:16.330136
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:35:20.054938
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', 'cat: /home/: Is a directory'))

# Generated at 2022-06-18 07:35:26.753582
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:35:33.713551
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'cat /etc/'))


# Generated at 2022-06-18 07:35:37.359809
# Unit test for function match
def test_match():
    assert match(Command('cat test.txt', 'cat: test.txt: Is a directory'))
    assert not match(Command('cat test.txt', 'test.txt'))
    assert not match(Command('cat test.txt', 'cat: test.txt: No such file or directory'))


# Generated at 2022-06-18 07:35:41.222893
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:35:45.421826
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory', '', 1))


# Generated at 2022-06-18 07:35:48.853199
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))

# Generated at 2022-06-18 07:38:11.404061
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:38:15.214760
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:38:18.373782
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:38:20.948471
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))


# Generated at 2022-06-18 07:38:30.894704
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such device or address'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))

# Generated at 2022-06-18 07:38:35.163675
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is not a directory'))


# Generated at 2022-06-18 07:38:37.324717
# Unit test for function match
def test_match():
    assert match(Command('cat file', 'cat: file: Is a directory'))
    assert not match(Command('cat file', ''))
    assert not match(Command('cat file', 'cat: file: No such file or directory'))
    assert not match(Command('cat file', 'cat: file: Is not a directory'))


# Generated at 2022-06-18 07:38:42.144004
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('ls /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:38:46.685721
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', '', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', '', ''))
    assert not match(Command('cat /etc/passwd', '', 'cat: /etc/passwd: No such file or directory'))
