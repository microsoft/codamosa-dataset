

# Generated at 2022-06-18 07:28:51.687766
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp', 'cat: /tmp: Is a directory', ''))
    assert not match(Command('cat /tmp', '', ''))
    assert not match(Command('ls /tmp', 'cat: /tmp: Is a directory', ''))
    assert not match(Command('cat /tmp', 'cat: /tmp: No such file or directory', ''))


# Generated at 2022-06-18 07:28:56.579380
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: Is not a directory'))


# Generated at 2022-06-18 07:29:03.329992
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:29:07.584524
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', 'cat: /home/: Is a directory'))

# Generated at 2022-06-18 07:29:17.694565
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))

# Generated at 2022-06-18 07:29:22.323837
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:29:32.560709
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/', 'ls /etc/', 'ls /etc/'))

# Generated at 2022-06-18 07:29:36.787535
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('ls /home/user/', 'cat: /home/user/: Is a directory'))


# Generated at 2022-06-18 07:29:42.424544
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:29:47.337429
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is not a directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:29:53.804392
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'test'))


# Generated at 2022-06-18 07:30:00.468987
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory',
                             stderr='cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory',
                             stderr='cat: test: No such file or directory',
                             script='ls test'))


# Generated at 2022-06-18 07:30:05.772192
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory', ''))
    assert not match(Command('cat test', '', ''))
    assert not match(Command('ls test', 'cat: test: Is a directory', ''))


# Generated at 2022-06-18 07:30:09.476668
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: Is a directory'))


# Generated at 2022-06-18 07:30:14.660599
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:30:19.585497
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', '', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', '', 'cat: /home/: No such file or directory'))
    assert not match(Command('cat /home/', '', 'cat: /home/: Is a file'))


# Generated at 2022-06-18 07:30:22.940869
# Unit test for function match
def test_match():
    assert match(Command('cat foo', 'cat: foo: Is a directory', ''))
    assert not match(Command('cat foo', '', ''))
    assert not match(Command('ls foo', 'cat: foo: Is a directory', ''))


# Generated at 2022-06-18 07:30:32.057436
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))

# Generated at 2022-06-18 07:30:36.059376
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', ''))
    assert not match(Command('cat /etc/passwd', '', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory', ''))


# Generated at 2022-06-18 07:30:43.387347
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory', '/etc/passwd'))


# Generated at 2022-06-18 07:30:55.447562
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:31:00.550920
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:31:05.742293
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Permission denied'))


# Generated at 2022-06-18 07:31:11.433579
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory', '', 1))
    assert not match(Command('cat test', 'cat: test: No such file or directory', '', 2))


# Generated at 2022-06-18 07:31:16.314654
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:31:21.635724
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:31:25.826922
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))

# Generated at 2022-06-18 07:31:32.029504
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '/etc/hosts'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '/etc/hosts', 'cat /etc/hosts'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '/etc/hosts', 'cat /etc/hosts', 'cat /etc/hosts'))

# Generated at 2022-06-18 07:31:38.214562
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Permission denied'))


# Generated at 2022-06-18 07:31:47.894016
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:32:06.770141
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: Is a directory'))

# Generated at 2022-06-18 07:32:11.699771
# Unit test for function match
def test_match():
    assert match(Command('cat /etc', 'cat: /etc: Is a directory'))
    assert not match(Command('cat /etc', 'cat: /etc: No such file or directory'))
    assert not match(Command('cat /etc', 'cat: /etc: No such file or directory', '', 1))


# Generated at 2022-06-18 07:32:15.607542
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:32:18.864689
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:32:22.167675
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))


# Generated at 2022-06-18 07:32:27.526621
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:32:32.248242
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is not a directory'))


# Generated at 2022-06-18 07:32:35.982289
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: Is a directory', 'test'))


# Generated at 2022-06-18 07:32:40.046774
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', '', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', '', 'ls: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:32:42.192119
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('ls test', 'cat: test: Is a directory'))


# Generated at 2022-06-18 07:33:14.139884
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:33:21.806791
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp', 'cat: /tmp: Is a directory'))
    assert not match(Command('cat /tmp', ''))
    assert not match(Command('ls /tmp', 'cat: /tmp: Is a directory'))
    assert not match(Command('cat /tmp', 'cat: /tmp: Is a directory',
                             stderr='cat: /tmp: Is a directory'))


# Generated at 2022-06-18 07:33:24.760389
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))

# Generated at 2022-06-18 07:33:32.389171
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))


# Generated at 2022-06-18 07:33:36.205130
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', '', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', '', 'ls: /etc/: Is a directory'))

# Generated at 2022-06-18 07:33:37.699449
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:33:42.815440
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory', 'ls /etc/passwd'))


# Generated at 2022-06-18 07:33:47.064825
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/', 'cat: /home/user/: Is a directory'))
    assert not match(Command('cat /home/user/', 'cat: /home/user/: No such file or directory'))
    assert not match(Command('ls /home/user/', 'ls: /home/user/: Is a directory'))


# Generated at 2022-06-18 07:33:57.444344
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))

# Generated at 2022-06-18 07:34:02.241355
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', 'cat: /home/: Is a directory'))


# Generated at 2022-06-18 07:35:08.021374
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '', 1))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '', 123))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '', 123))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', '', 123))
    assert not match

# Generated at 2022-06-18 07:35:12.037164
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', '', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', '', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', '', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:35:13.748820
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))


# Generated at 2022-06-18 07:35:16.819426
# Unit test for function match
def test_match():
    assert match(Command('cat /etc', 'cat: /etc: Is a directory'))
    assert not match(Command('cat /etc', 'cat: /etc: No such file or directory'))
    assert not match(Command('cat /etc', 'cat: /etc: Is a file'))


# Generated at 2022-06-18 07:35:19.943487
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:35:24.665836
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'root:x:0:0:root:/root:/bin/bash'))


# Generated at 2022-06-18 07:35:34.198649
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))

# Generated at 2022-06-18 07:35:38.480882
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:35:41.868376
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:35:44.433969
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('ls test', 'cat: test: Is a directory'))


# Generated at 2022-06-18 07:38:06.357454
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))


# Generated at 2022-06-18 07:38:12.362141
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/', 'ls /etc/'))


# Generated at 2022-06-18 07:38:15.645551
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))

# Generated at 2022-06-18 07:38:17.202124
# Unit test for function match
def test_match():
    command = Command('cat /home/', 'cat: /home/: Is a directory')
    assert match(command)


# Generated at 2022-06-18 07:38:21.023981
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))

# Generated at 2022-06-18 07:38:28.473668
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory', script='ls /etc/'))


# Generated at 2022-06-18 07:38:34.359238
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:38:38.330057
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:38:47.625366
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))