

# Generated at 2022-06-18 07:28:45.642730
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:28:49.558717
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', 'ls: /home/: Is a directory'))

# Generated at 2022-06-18 07:28:54.496196
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:28:57.863289
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory', '', 1))


# Generated at 2022-06-18 07:29:01.823248
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: Is a file'))


# Generated at 2022-06-18 07:29:07.191105
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:29:10.592969
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))

# Generated at 2022-06-18 07:29:21.555868
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))

# Generated at 2022-06-18 07:29:25.562455
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory', stderr='cat: test: No such file or directory'))


# Generated at 2022-06-18 07:29:36.850943
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))
    assert not match(Command('cat /home/', 'cat: /home/: Is a directory', 'ls /home/'))

# Generated at 2022-06-18 07:29:41.222134
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))

# Generated at 2022-06-18 07:29:45.403772
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', 'cat: /home/: Is a directory'))


# Generated at 2022-06-18 07:29:50.542281
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))

# Generated at 2022-06-18 07:29:55.262972
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:30:00.023861
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory',
                             stderr='cat: /etc/: No such file or directory'))


# Generated at 2022-06-18 07:30:05.358308
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:30:08.846599
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: Is a directory', 'ls test'))


# Generated at 2022-06-18 07:30:12.516034
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', 'ls: /home/: Is a directory'))


# Generated at 2022-06-18 07:30:18.853609
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))

# Generated at 2022-06-18 07:30:23.317042
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:30:32.090078
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: Is a directory',
                             'test'))


# Generated at 2022-06-18 07:30:42.398931
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:30:52.495920
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such device or address'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))

# Generated at 2022-06-18 07:31:02.415134
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:31:07.756771
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:31:12.936467
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', ''))
    assert not match(Command('ls test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:31:17.595659
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', 'ls /etc/'))


# Generated at 2022-06-18 07:31:21.593059
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))


# Generated at 2022-06-18 07:31:29.611912
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such device or address'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))

# Generated at 2022-06-18 07:31:32.296538
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', ''))
    assert not match(Command('cat test', 'cat: test: Is a directory', '', '', '', '', ''))


# Generated at 2022-06-18 07:31:49.025115
# Unit test for function match
def test_match():
    assert match(Command('cat test.txt', 'cat: test.txt: Is a directory'))
    assert not match(Command('cat test.txt', 'test.txt'))
    assert not match(Command('ls test.txt', 'cat: test.txt: Is a directory'))


# Generated at 2022-06-18 07:31:56.577531
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:31:59.410358
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:32:04.074239
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:32:11.067155
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', stderr='cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:32:17.269324
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('ls /etc/', 'ls: /etc/: Is a directory'))

# Generated at 2022-06-18 07:32:24.784370
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Bad file descriptor'))

# Generated at 2022-06-18 07:32:32.382623
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory', stderr='cat: /etc/: No such file or directory', script='cat /etc/'))


# Generated at 2022-06-18 07:32:37.773186
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a file'))


# Generated at 2022-06-18 07:32:41.711096
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is not a directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:33:12.473227
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'test'))
    assert not match(Command('cat test', 'cat: test: Is a directory', 'test'))


# Generated at 2022-06-18 07:33:17.947310
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/', 'ls /etc/'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', 'ls /etc/', 'ls /etc/', 'ls /etc/'))

# Generated at 2022-06-18 07:33:22.228038
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', ''))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))


# Generated at 2022-06-18 07:33:31.569949
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', stderr=''))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', stderr=None))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', stderr=False))
    assert not match(Command('cat /etc/', 'cat: /etc/: Is a directory', stderr=True))


# Generated at 2022-06-18 07:33:35.103529
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))

# Generated at 2022-06-18 07:33:44.035498
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is not a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))

# Generated at 2022-06-18 07:33:47.451338
# Unit test for function match
def test_match():
    assert match(Command('cat /home/', 'cat: /home/: Is a directory'))
    assert not match(Command('cat /home/', 'cat: /home/: No such file or directory'))
    assert not match(Command('ls /home/', 'cat: /home/: Is a directory'))

# Generated at 2022-06-18 07:33:51.763088
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('ls /etc/passwd', 'cat: /etc/passwd: Is a directory'))


# Generated at 2022-06-18 07:33:56.657398
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:34:03.572261
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))


# Generated at 2022-06-18 07:35:05.247319
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', ''))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))


# Generated at 2022-06-18 07:35:09.333112
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: No such file or directory'))
    assert not match(Command('cat /etc/passwd', 'cat: /etc/passwd: Is a file'))


# Generated at 2022-06-18 07:35:12.361547
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'ls: /etc/: Is a directory'))

# Generated at 2022-06-18 07:35:15.262773
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:35:19.519121
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:35:31.046838
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such device or address'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Device not configured'))

# Generated at 2022-06-18 07:35:35.194508
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:35:39.716369
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:35:44.432821
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))


# Generated at 2022-06-18 07:35:47.520573
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'cat: test: No such file or directory'))
    assert not match(Command('cat test', 'cat: test: Is a file'))


# Generated at 2022-06-18 07:38:05.029057
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp/', 'cat: /tmp/: Is a directory', ''))
    assert not match(Command('cat /tmp/', '', ''))
    assert not match(Command('cat /tmp/', 'cat: /tmp/: No such file or directory', ''))


# Generated at 2022-06-18 07:38:09.560224
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('ls /etc/', 'cat: /etc/: Is a directory'))


# Generated at 2022-06-18 07:38:13.648367
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a file'))


# Generated at 2022-06-18 07:38:17.460799
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:38:21.761890
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('ls /etc/hosts', 'cat: /etc/hosts: Is a directory'))


# Generated at 2022-06-18 07:38:24.363529
# Unit test for function match
def test_match():
    command = Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory')
    assert match(command)


# Generated at 2022-06-18 07:38:28.751866
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory', '', 1))
    assert not match(Command('cat test', '', '', 1))
    assert not match(Command('ls test', 'cat: test: Is a directory', '', 1))
    assert not match(Command('cat test', 'cat: test: No such file or directory', '', 1))


# Generated at 2022-06-18 07:38:34.269916
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))


# Generated at 2022-06-18 07:38:39.653489
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts', 'cat /etc/hosts'))
    assert not match(Command('cat /etc/hosts', 'cat: /etc/hosts: No such file or directory', 'ls /etc/hosts', 'cat /etc/hosts', 'ls /etc/hosts'))

# Generated at 2022-06-18 07:38:50.161718
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Permission denied'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Input/output error'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such device or address'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Resource temporarily unavailable'))
    assert not match(Command('cat /etc/', 'cat: /etc/: Cannot allocate memory'))