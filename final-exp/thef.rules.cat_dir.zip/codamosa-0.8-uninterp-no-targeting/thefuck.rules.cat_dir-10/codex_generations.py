

# Generated at 2022-06-22 01:01:44.116030
# Unit test for function get_new_command
def test_get_new_command():
    assert os.path.isdir('/etc') == True
    assert get_new_command('cat /etc') == 'ls /etc'
    assert get_new_command('cat /etc/peers') == 'cat /etc/peers'

# Generated at 2022-06-22 01:01:47.592758
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /etc/hosts', 'cat: /etc/hosts: Is a directory')
    assert get_new_command(command) == 'ls /etc/hosts'

# Generated at 2022-06-22 01:01:51.518688
# Unit test for function get_new_command
def test_get_new_command():
    """Returns ls if cat returned error: Is a directory"""
    assert get_new_command(Command('cat /usr/local/bin', '', 'cat: /usr/local/bin: Is a directory\n', '')) == 'ls /usr/local/bin'

# Generated at 2022-06-22 01:01:54.366469
# Unit test for function match
def test_match():
    assert match(Command('cat file', ''))
    assert not match(Command('cat file', None))
    assert match(Command('cat /etc', "cat: /etc: Is a directory"))


# Generated at 2022-06-22 01:01:56.941351
# Unit test for function get_new_command
def test_get_new_command():
     command = type('Command', (object,), {'script':'cat folder'})
     new_command = get_new_command(command)
     assert new_command == "ls folder"

# Generated at 2022-06-22 01:01:59.829247
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_directory import get_new_command
    assert get_new_command(Command('cat /home/user/', 'cat: /home/user/: Is a directory')) == 'ls /home/user/'

# Generated at 2022-06-22 01:02:06.794570
# Unit test for function match
def test_match():
    command = Command("cat /dev/null", "/dev/null is a directory")
    assert match(command)
    command = Command("ls /dev/null", "/dev/null is a directory")
    assert not match(command)
    command = Command("cat /dev/null", "cat: /dev/null: Is a directory")
    assert match(command)
    command = Command("cat /dev/null", "cat: /dev: Is a directory")
    assert not match(command)
    command = Command("cat /", "cat: /: Is a directory")
    assert match(command)
    command = Command("cat .", "cat: .: Is a directory")
    assert match(command)



# Generated at 2022-06-22 01:02:08.389971
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat foo') == 'ls foo'

# Generated at 2022-06-22 01:02:12.029649
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /opt/lampp/htdocs')
    new_command = get_new_command(command)
    assert new_command == command.script.replace('cat', 'ls', 1)

# Generated at 2022-06-22 01:02:17.564043
# Unit test for function match
def test_match():
    assert match(Command('cat a/b.txt', '', 'cat: a/b.txt: Is a directory'))
    assert not match(Command('cat a/b.txt', '', ''))
    assert not match(Command('ls a/b.txt', '', 'cat: a/b.txt: Is a directory'))
    assert not match(Command('ls a/b.txt', '', ''))


# Generated at 2022-06-22 01:02:25.751347
# Unit test for function match
def test_match():
    assert match(Command('cat non-existant non-existant-dir',
                         stderr='cat: non-existant: No such file or directory\ncat: non-existant-dir: Is a directory\n'))
    assert not match(Command('cat non-existant',
                             stderr='cat: non-existant: No such file or directory\n'))


# Generated at 2022-06-22 01:02:29.652534
# Unit test for function get_new_command
def test_get_new_command():
    command = "cat /usr/local/bin"
    assert get_new_command(command) == "ls /usr/local/bin"
    command = "cat ~/Documents/"
    assert get_new_command(command) == "ls ~/Documents/"

# Generated at 2022-06-22 01:02:31.476369
# Unit test for function get_new_command
def test_get_new_command():
    cat_ls = get_new_command('cat /home/')
    assert cat_ls == 'ls /home/'

# Generated at 2022-06-22 01:02:35.274107
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_dir import get_new_command
    assert get_new_command('cat test.txt') == 'cat test.txt'
    assert get_new_command('cat foo') == 'ls foo'

# Generated at 2022-06-22 01:02:39.159414
# Unit test for function match
def test_match():
    assert(match(Command("cat /home/nikhil", "/home/nikhil")) is True)
    assert(match(Command("cat /home/nikhil.txt", "/home/nikhil.txt")) is False)


# Generated at 2022-06-22 01:02:41.896402
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test.txt', ''))


# Generated at 2022-06-22 01:02:45.036069
# Unit test for function match
def test_match():
    assert match(Command('cat not_exist.txt', 'cat: not_exist.txt: No such file or directory'))
    # Script parts returns 'cat not_exist.txt' so script_parts[1] returns 'not_exist.txt'
    # os.path.isdir() returns False
    assert not match(Command('cat not_exist.txt', 'cat: not_exist.txt: No such file or directory'))


# Generated at 2022-06-22 01:02:48.515436
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat test-thefuck", "cat: test-thefuck: Is a directory")
    assert get_new_command(command) == "ls test-thefuck"

# Generated at 2022-06-22 01:02:53.264576
# Unit test for function match
def test_match():
    assert match(Command(script='cat foo', stderr='cat: foo: Is a directory'))
    assert not match(Command(script='cat foo', output='cat: foo: Is a directory'))
    assert not match(Command(script='cat foo', stderr='cat: foo: No such file or directory'))


# Generated at 2022-06-22 01:02:56.306505
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/'))
    assert not match(Command('cat /etc/passwd'))
    assert not match(Command('ls /etc/'))



# Generated at 2022-06-22 01:03:01.895229
# Unit test for function match
def test_match():
    assert match(Command(script='cat README.md'))
    assert not match(Command(script='ls README.md'))
    assert not match(Command(script='cat README.md package.json'))


# Generated at 2022-06-22 01:03:07.125813
# Unit test for function match
def test_match():
    assert match(Command('cat /usr', '', 'cat: /usr: Is a directory'))
    assert not match(Command('cat /usr', '', ''))
    assert not match(Command('cat /usr/', '', ''))
    assert not match(Command('cat /usr/bin', '', 'cat: /usr/bin: No such'))



# Generated at 2022-06-22 01:03:08.898653
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /tmp/') == 'ls /tmp/'

# Generated at 2022-06-22 01:03:13.830047
# Unit test for function match
def test_match():
    command = type('Command', (object,), {
        'output': 'cat: iptables: Is a directory',
        'script_parts': ['cat', 'iptables']
    })
    assert match(command)


# Generated at 2022-06-22 01:03:17.702326
# Unit test for function match
def test_match():
    command = Command('cat foo/')
    assert match(command)
    command = Command('cat foo/bar')
    assert not match(command)
    command = Command('foo/cat')
    assert not match(command)


# Generated at 2022-06-22 01:03:21.522263
# Unit test for function match
def test_match():
    assert match(Command('cat test', ''))
    assert not match(Command('cat', ''))
    assert not match(Command('cat foo', ''))
    assert not match(Command('cat foo bar', ''))


# Generated at 2022-06-22 01:03:25.951108
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    new_command = get_new_command(Command(script='cat C:/',
                                          script_parts=['cat',
                                                        'C:/'],
                                          output='cat: C:/: Is a directory',
                                          stderr=''))
    assert new_command == 'ls C:/'

# Generated at 2022-06-22 01:03:28.799265
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {
        'script': 'cat /home/fred'
    })

    assert get_new_command(command) == 'ls /home/fred'

# Generated at 2022-06-22 01:03:34.549684
# Unit test for function match
def test_match():
    command = Command('cat /tmp/', '', 'cat: /tmp/: Is a directory')
    assert match(command)
    command = Command('cat /tmp/', '', 'No such file or directory')
    assert not match(command)
    command = Command('ls /tmp/', '', 'cat: /tmp/: Is a directory')
    assert not match(command)


# Generated at 2022-06-22 01:03:37.908677
# Unit test for function match
def test_match():
    assert(match(Command('cat pom.xml', 'cat: pom.xml: Is a directory', '', 7)) == True)


# Generated at 2022-06-22 01:03:41.171531
# Unit test for function match
def test_match():
    command = Command('cat /tmp/test')
    assert not match(command)

    command = Command('cat /tmp')
    assert match(command)



# Generated at 2022-06-22 01:03:44.632703
# Unit test for function match
def test_match():
    command = Command(script='cat /home/vagrant/')
    assert match(command)
    assert not match(Command(script='echo cat /home/vagrant/'))
    assert not match(Command(script='cat'))



# Generated at 2022-06-22 01:03:47.709618
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat /home/test', output='cat: /home/test: Is a directory')

    assert get_new_command(command) == 'ls /home/test'

# Generated at 2022-06-22 01:03:50.861611
# Unit test for function get_new_command
def test_get_new_command():
    command_to_test = 'cat /usr/bin'
    correct_command = 'ls /usr/bin'
    assert get_new_command(command_to_test) == correct_command


# Generated at 2022-06-22 01:03:54.936467
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_to_ls import get_new_command
    command = Command('cat a b', 'cat: b: Is a directory')
    assert get_new_command(command) == 'ls a b'

# Generated at 2022-06-22 01:03:59.269180
# Unit test for function match
def test_match():
    assert match(Command('cat', '', 'cat: dosa: Is a directory'))
    assert not match(Command('cat', '', 'cat: dosa'))
    assert not match(Command('cat'))

# Unit tests for function get_new_command

# Generated at 2022-06-22 01:04:04.632615
# Unit test for function match
def test_match():
    assert match(Command('cat not_existing_file'))
    assert match(Command('cat not_existing_file other_file'))
    assert match(Command('cat existing_file'))
    assert not match(Command('cat existing_file other_file'))
    assert not match(Command('cat'))
    assert not match(Command('not_cat file'))


# Generated at 2022-06-22 01:04:06.562641
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat doop') == 'ls doop'



# Generated at 2022-06-22 01:04:07.792027
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command("cat /usr/bin/ls") == "ls /usr/bin/ls"

# Generated at 2022-06-22 01:04:09.963189
# Unit test for function match
def test_match():
    assert match(Command('cat xxx', 'cat: xxx: Is a directory'))


# Generated at 2022-06-22 01:04:14.328330
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    assert get_new_command(command='cat ./test') == 'ls ./test'

# Generated at 2022-06-22 01:04:16.350736
# Unit test for function get_new_command
def test_get_new_command():
    assert_equal(get_new_command(e('cat test.txt')), u('ls test.txt'))

# Generated at 2022-06-22 01:04:18.731689
# Unit test for function match
def test_match():
    assert match(Command('cat file1.txt', 'cat: file1.txt: Is a directory'))
    assert not match(Command('cat file1.txt', 'text'))
    assert not match(Command('cat', 'cat: Is a directory'))


# Generated at 2022-06-22 01:04:24.432234
# Unit test for function match
def test_match():
    assert match(Command('cat /etc', 'cat: /etc: Is a directory'))
    assert not match(Command('cat hello.txt', ''))
    assert not match(Command('cat /etc/hosts', '127.0.0.1 localhost'))
    assert not match(Command('cat hello.txt', 'hello world'))


# Generated at 2022-06-22 01:04:28.215515
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat test')
    assert get_new_command(command) == 'ls test'
    command = Command('cat test test2')
    assert get_new_command(command) == 'ls test test2'


# Generated at 2022-06-22 01:04:36.919310
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.wrong_command import get_new_command

    # nothing to change
    assert (not get_new_command(Command('git status', ''))
            and not get_new_command(Command('ls', ''))
            and not get_new_command(Command('', '')))

    # replace one
    assert get_new_command(Command('cat file.txt', '')) == 'ls file.txt'

    # replace all
    assert (get_new_command(Command('cat file.txt git status', ''))
            == 'ls file.txt git status')

# Generated at 2022-06-22 01:04:40.415996
# Unit test for function match
def test_match():
    assert match(Command('cat README.md', 'cat: README.md: Is a directory'))
    assert not match(Command('cat README.md', ''))
    assert not match(Command('ls README.md', 'cat: README.md: Is a directory'))


# Generated at 2022-06-22 01:04:45.516284
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_directory import get_new_command
    command = type('Command', (object,), {'script': 'cat /etc/passwd'})
    assert get_new_command(command) == 'ls /etc/passwd'

# Generated at 2022-06-22 01:04:47.331127
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat ../')
    assert get_new_command(command) == 'ls ../'

# Generated at 2022-06-22 01:04:49.483091
# Unit test for function match
def test_match():
    command = 'cat ~/bin/fuck'
    assert match(command) == True


# Generated at 2022-06-22 01:04:52.426392
# Unit test for function match
def test_match():
    assert match(Command('cat hello world', 'cat: hello: Is a directory'))


# Generated at 2022-06-22 01:04:56.413151
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /tmp') == 'ls /tmp'
    assert get_new_command('cat /tmp/hello') == 'ls /tmp/hello'
    assert get_new_command('cat hello') == 'ls hello'

# Generated at 2022-06-22 01:05:03.072933
# Unit test for function match
def test_match():
    command = Command('cat testdir')
    assert not match(command)

    command = Command('cat testdir a b c')
    assert not match(command)

    command = Command('cat testdir', 'cat: testdir: Is a directory')
    assert match(command)

    command = Command('cat testdir a b c', 'cat: testdir: Is a directory')
    assert match(command)



# Generated at 2022-06-22 01:05:03.703973
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat test/").script == "ls test/"

# Generated at 2022-06-22 01:05:07.685741
# Unit test for function match
def test_match():
    assert match(Command('cat /home', 'cat: /home: Is a directory'))
    assert not match(Command('cat /home', 'cat: /home: No such file or directory'))


# Generated at 2022-06-22 01:05:09.099629
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command=Command('cat /tmp')) == 'ls /tmp'

# Generated at 2022-06-22 01:05:12.609424
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat /home'
    new_command = 'ls /home'
    assert get_new_command(command) == new_command

# Generated at 2022-06-22 01:05:15.893358
# Unit test for function match
def test_match():
    from thefuck.rules.ls_file import match
    command = 'cat test'
    assert match(command) is True
    command = 'test'
    assert match(command) is False


# Generated at 2022-06-22 01:05:17.558118
# Unit test for function match
def test_match():
    assert match(Command('cat testfile', 'cat: testfile: Is a directory',
                         ''))



# Generated at 2022-06-22 01:05:20.575086
# Unit test for function match
def test_match():
    assert match(Command('cat test/test1.txt', 'test/test1.txt: Is a directory'))
    assert not match(Command('cat test/test1.txt', 'test/test1.txt: Is not a directory'))

# Generated at 2022-06-22 01:05:23.806839
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat .')) == 'ls .'

# Generated at 2022-06-22 01:05:26.160358
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat file',
        output='cat: file: Is a directory')) == 'ls file'

# Generated at 2022-06-22 01:05:29.207246
# Unit test for function match
def test_match():
    assert match(Command('cat file', '', 'cat: file: Is a directory'))
    assert not match(Command('cat file', '', 'cat: file: No such file or directory'))

# Generated at 2022-06-22 01:05:30.747452
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /etc") == "ls /etc"

# Generated at 2022-06-22 01:05:33.915807
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = 'cat /')
    assert get_new_command(command) == command.script.replace('cat', 'ls', 1)

# Generated at 2022-06-22 01:05:37.691771
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('cat my_dir', 'cat: my_dir: Is a directory',
                                   '', [],
                                   1)) == 'ls my_dir'

# Generated at 2022-06-22 01:05:48.399176
# Unit test for function match
def test_match():
    assert(match('cat testDir')
            and os.path.isdir('testDir')
            and not os.path.isfile('testDir'))
    assert(not match('pwd')
            and os.path.isdir('/Users/xinghao/Dropbox/Projects/Thefuck/thefuck'))
    assert(match('cat fileThatDoesNotExist')
            and not os.path.isdir('fileThatDoesNotExist')
            and not os.path.isfile('fileThatDoesNotExist'))
    # default test
    assert(not match('pwd')
            and os.path.isdir('/Users/xinghao/Dropbox/Projects/Thefuck/thefuck'))


# Generated at 2022-06-22 01:05:52.800843
# Unit test for function match
def test_match():
    command = Command('cat /tmp/example.txt',
                      output='cat: /tmp/example.txt: Is a directory')
    assert match(command)
    command = Command('cat /tmp')
    assert not match(command)


# Generated at 2022-06-22 01:05:56.968917
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat .',
                      stderr=u"cat: .: Is a directory\n",
                      stdout=u"",
                      env={},
                      use_raw=False)
    assert get_new_command(command) == "ls .\n"

# Generated at 2022-06-22 01:06:01.063539
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat /etc/test/test.py',
                      stdout='cat: /etc/test/test.py: Is a directory')
    assert get_new_command(command) == 'ls /etc/test/test.py'

# Generated at 2022-06-22 01:06:07.154265
# Unit test for function get_new_command
def test_get_new_command():
    # on the command "cat mydir"
    command = Command("cat mydir", "cat: mydir: Is a directory")
    assert get_new_command(command) == "ls mydir"

# Generated at 2022-06-22 01:06:10.246480
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_directory import get_new_command
    command = 'cat /home'
    expected_command = 'ls /home'
    assert get_new_command(command) == expected_command

# Generated at 2022-06-22 01:06:12.817977
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat /usr/local/bin')
    assert get_new_command(command) == 'ls /usr/local/bin'

# Generated at 2022-06-22 01:06:17.960669
# Unit test for function match
def test_match():
    # Test case true
    output1='cat: /tt: Is a directory'
    assert match(for_app('cat', at_least=1)(output1))
    # Test case false
    output2='cat: /tt: Is a cat'
    assert not match(for_app('cat', at_least=1)(output2))


# Generated at 2022-06-22 01:06:20.424527
# Unit test for function match
def test_match():
    cmd = Command('cat test/')
    assert not match(cmd)
    cmd = Command('cat test')
    assert match(cmd)



# Generated at 2022-06-22 01:06:21.956460
# Unit test for function match
def test_match():
    assert match(Command('cat ls'))


# Generated at 2022-06-22 01:06:25.623608
# Unit test for function get_new_command
def test_get_new_command():
    command = "cat "
    command_replaced = get_new_command(command)
    assert command_replaced == command.replace('cat', 'ls', 1)

# Generated at 2022-06-22 01:06:28.325792
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {
        'script': 'cat data table'
    })
    assert get_new_command(command) == 'ls data table'

# Generated at 2022-06-22 01:06:30.974580
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', 'cat: file.txt: Is a directory',
                                 'ls file.txt', 3))


# Generated at 2022-06-22 01:06:32.993880
# Unit test for function get_new_command
def test_get_new_command():
    # Start testing
    assert get_new_command('cat /etc/') == 'ls /etc/'

# Generated at 2022-06-22 01:06:36.207192
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat test_dir')
    assert get_new_command(command) == 'ls cat test_dir'

# Generated at 2022-06-22 01:06:38.455950
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', 'cat: file.txt: Is a directory'))
    assert not match(Command('cat', ''))


# Generated at 2022-06-22 01:06:45.684362
# Unit test for function get_new_command
def test_get_new_command():
    # Test case 1: cat command with one argument
    command = types.Command('cat test', '', '')
    assert get_new_command(command) == 'ls test'
    # Test case 2: cat command with two arguments
    command = types.Command('cat test test2', '', '')
    assert get_new_command(command) == 'ls test test2'

# Generated at 2022-06-22 01:06:47.192910
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat hello') == 'ls hello'

# Generated at 2022-06-22 01:06:54.029453
# Unit test for function match
def test_match():
    # Test with a directory
    output = u'cat: test: Is a directory'
    commands = ["cat test"]
    assert match(Command(commands, output))

    # Test with a file that doesn't exist
    output = u'cat: test.txt: No such file or directory'
    commands = ["cat test.txt"]
    assert not match(Command(commands, output))

    # Test with a dir that doesn't exist
    output = u'cat: test: No such file or directory'
    commands = ["cat test"]
    assert match(Command(commands, output))



# Generated at 2022-06-22 01:06:58.072093
# Unit test for function match
def test_match():
    assert match(Command('cat some_folder', 'cat: some_folder: Is a directory'))
    assert not match(Command('cat some_file', 'some_file'))

# Generated at 2022-06-22 01:07:00.336881
# Unit test for function match
def test_match():
    assert match(Command('cat test.py', stderr='cat: test.py: Is a directory'))



# Generated at 2022-06-22 01:07:02.881024
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(CatError('''cat: /path/to/dir: Is a directory''', 'ls /path/to/dir')) == 'ls /path/to/dir'


available_by_default = True

# Generated at 2022-06-22 01:07:08.097933
# Unit test for function match
def test_match():
    assert match(Command('cat foo', 'cat: foo: Is a directory', '/bin'))
    assert not match(Command('cat foo', '', '/bin'))
    assert not match(Command('vim foo', 'cat: foo: Is a directory', '/bin'))
    assert not match(Command('cat foo', 'cat: foo: Is a directory', '/bin'))


# Generated at 2022-06-22 01:07:09.916000
# Unit test for function get_new_command
def test_get_new_command():
    c = Command('cat /var/log')
    c.output = 'cat: /var/log: Is a directory'
    assert get_new_command(c) == 'ls /var/log'

# Generated at 2022-06-22 01:07:16.491095
# Unit test for function match
def test_match():
    assert match(Command('cat c:\'', ''))
    assert match(Command('cat c:\'', ''))
    assert not match(Command('ls c:\'', ''))
    assert not match(Command('ls c:\'', ''))
    assert not match(Command('ls c:\'', ''))

# Generated at 2022-06-22 01:07:18.059120
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat foo', '')) == 'ls foo'

# Generated at 2022-06-22 01:07:21.311497
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_directory import get_new_command
    command = 'cat'
    new_command = get_new_command(command)
    assert new_command == 'ls'

# Generated at 2022-06-22 01:07:23.588719
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("cat bin/fish", "/bin/fish/bin")) == "ls bin/fish"


# Generated at 2022-06-22 01:07:27.571795
# Unit test for function match
def test_match():
    assert match(Command(script="cat /", output='cat: /: Is a directory'))
    assert not match(Command(script="cat /", output='cat: /: No such file or directory'))


# Generated at 2022-06-22 01:07:29.588883
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat ~/Downloads')) == 'ls ~/Downloads'

# Generated at 2022-06-22 01:07:30.645214
# Unit test for function match
def test_match():
    assert match('cat test.txt')


# Generated at 2022-06-22 01:07:36.010990
# Unit test for function match
def test_match():
    assert match(Command('cat foo', '', 'cat: foo: Is a directory', ''))
    assert not match(Command('cat foo bar', '', '', 'cat: foo: No such file or directory\nbar\n'))
    assert not match(Command('cat foo bar', '', '', 'foo\nbar\n'))


# Generated at 2022-06-22 01:07:40.530220
# Unit test for function match
def test_match():
    assert match(Command('cat /home/user/test', '', ''))
    assert not match(Command('cat file1 file2', '', ''))
    assert not match(Command('cat file1', '', ''))



# Generated at 2022-06-22 01:07:43.145399
# Unit test for function match
def test_match():
    command = Command('cat /tmp')
    assert match(command) is True
    command = Command('cat /tmp/file')
    assert match(command) is False



# Generated at 2022-06-22 01:07:46.970654
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat test', '', 'cat: test: Is a directory\n')
    assert get_new_command(command) == 'ls test'

# Generated at 2022-06-22 01:07:53.027252
# Unit test for function match
def test_match():
    # when the command output states cat file is a directory and the file is a directory
    assert match(Command('cat directory'))
    # when the command output states cat file is a directory but the file is not a directory
    assert not match(Command('cat file'))
    # when the command output does not state cat file is a directory
    assert not match(Command('cat file', output='file not found'))


# Generated at 2022-06-22 01:07:56.696784
# Unit test for function match
def test_match():
    assert match(Command('cat', 'cat: foo: Is a directory'))
    assert not match(Command('cat', 'Usage: cat FILE ...'))
    assert not match(Command('ls', 'cat: foo: Is a directory'))



# Generated at 2022-06-22 01:07:58.667905
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /tmp')) == 'ls /tmp'


# Generated at 2022-06-22 01:08:02.720988
# Unit test for function match
def test_match():
    assert match(
        Command('cat /etc', 'cat: /etc: Is a directory', '')
    )
    assert not match(
        Command('xxx', '', '')
    )


# Generated at 2022-06-22 01:08:04.868342
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat test')
    assert get_new_command(command) == 'ls test'

# Generated at 2022-06-22 01:08:06.490780
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat testdir', '')) == 'ls testdir'

# Generated at 2022-06-22 01:08:15.782292
# Unit test for function get_new_command
def test_get_new_command():
    # Test when input = 'cat'
    input1 = Command('cat', '', '', '', '')
    assert get_new_command(input1) == 'ls'
    # Test when input = 'cat foo'
    input2 = Command('cat foo', '', '', '', '')
    assert get_new_command(input2) == 'ls foo'
    # Test when input = 'cat foo/abc'
    input3 = Command('cat foo/abc', '', '', '', '')
    assert get_new_command(input3) == 'ls foo/abc'

# Generated at 2022-06-22 01:08:22.160887
# Unit test for function match
def test_match():
    f = match(Command('cat /etc', '/etc/ls'))
    assert(f is True)
    f = match(Command('cat /etc2', 'ls: cannot access /etc/ls: No such file or directory'))
    assert(f is False)
    f = match(Command('cat /etc2', '/etc/ls'))
    assert(f is False)


# Generated at 2022-06-22 01:08:24.447635
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat file_name') == 'ls file_name'

# Generated at 2022-06-22 01:08:30.836277
# Unit test for function match
def test_match():
    assert match(Command(script='cat test.txt'))
    assert match(Command(script='cat /home/'))
    assert not match(Command(script='cat'))
    assert not match(Command(script='catt t.txt'))


# Generated at 2022-06-22 01:08:32.257827
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test') == 'ls test'

# Generated at 2022-06-22 01:08:34.930925
# Unit test for function match
def test_match():
    from thefuck.rules.cat_is_a_directory import match
    assert match('cat test')
    assert not match('cat test.py')



# Generated at 2022-06-22 01:08:35.632547
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /') == 'ls /'

# Generated at 2022-06-22 01:08:36.657012
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat dir/') == 'ls dir/'

# Generated at 2022-06-22 01:08:41.287802
# Unit test for function match
def test_match():
    assert match(Command(
        'cat pluto',
        'cat: pluto: Is a directory\n'))
    assert not match(Command(
        'ls pluto',
        'cat: pluto: No such file or directory\n'))

# Generated at 2022-06-22 01:08:45.616962
# Unit test for function match
def test_match():
    assert match(Command(script="cat example.py",
        output="cat: example.py: Is a directory")
        ) == True
    assert match(Command(script="cat example.py",
        output="cat: example.py: Is a not directory")
        ) == False


# Generated at 2022-06-22 01:08:48.717028
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = 'cat data.txt')
    assert get_new_command(command) == command.script.replace('cat', 'ls', 1)

# Generated at 2022-06-22 01:08:55.559071
# Unit test for function match
def test_match():
    # function match is only for app 'cat'
    assert not match(Command('ls some_file'))

    # cat does not have this kind of output
    assert not match(Command('cat', 'some_file'))

    # Test match version 1
    assert match(Command('cat', 'some_directory'))
    assert match(Command('cat', 'some_directory', 'another_file'))

    # Test match version 2
    assert match(Command('cat', 'some_file', 'another_directory'))
    assert match(Command('cat', 'some_file', 'another_directory',
                                           'yet_another_file'))


# Generated at 2022-06-22 01:09:00.354965
# Unit test for function match
def test_match():
    cat_dir = Command('cat dir', output='cat: dir: Is a directory')
    cat_file = Command('cat file', output='File contents')
    assert match(cat_dir)
    assert not match(cat_file)


# Generated at 2022-06-22 01:09:05.423494
# Unit test for function match
def test_match():
    assert match(Command('cat app.py'))
    assert not match(Command('ls app.py'))



# Generated at 2022-06-22 01:09:07.859150
# Unit test for function match
def test_match():
    output='cat: some: Is a directory'
    assert match(Command('notimportant', output)) == True


# Generated at 2022-06-22 01:09:10.865544
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat .') == 'ls .'


# Note: unittest test for function match is not needed because this rule is
# already tested in test_for_app

# Generated at 2022-06-22 01:09:13.699471
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    command = 'cat /'
    assert get_new_command(command) == 'ls /'

# Generated at 2022-06-22 01:09:15.565286
# Unit test for function get_new_command
def test_get_new_command(): 
    import os
    assert get_new_command(os.system('cat')) is os.system('ls')

# Generated at 2022-06-22 01:09:17.537009
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat folder')
    assert get_new_command(command) == "ls folder"

# Generated at 2022-06-22 01:09:18.642181
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat foo/bar', '')) == 'ls foo/bar'

# Generated at 2022-06-22 01:09:22.857686
# Unit test for function match
def test_match():
    from thefuck.rules.cat_is_directory import match

    assert match(Command('cat /bin', 'cat: /bin: Is a directory'))
    assert not match(Command('cat /bin', 'cat: /bin'))
    assert not match(Command('cat /bin', 'cat: /bin', 'thing'))


# Generated at 2022-06-22 01:09:25.717176
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('cat /etc/') == 'ls /etc/')


# Generated at 2022-06-22 01:09:27.652126
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat file'
    assert get_new_command(command) == 'ls file'

# Generated at 2022-06-22 01:09:33.350835
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat testdir', 'cat: testdir: Is a directory\n', None)) == 'ls testdir'


# Generated at 2022-06-22 01:09:35.012434
# Unit test for function match
def test_match():
    assert match(Command('cat test.txt',
    'cat: test.txt: Is a directory\ntest.txt\nfile3', ''))
    assert not match(Command('ls', '', ''))

# Generated at 2022-06-22 01:09:36.840165
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /some/directory', 'cat: /some/directory: Is a directory', '', None, '', '')) == 'ls /some/directory'

# Generated at 2022-06-22 01:09:41.663382
# Unit test for function get_new_command
def test_get_new_command():
    command = type('', (object,), {
        'script': 'cat testdir',
        'script_parts': ['cat', 'testdir']
    })
    assert get_new_command(command) == 'ls testdir'

# Generated at 2022-06-22 01:09:44.344601
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /usr/path/to/directory/')=='ls /usr/path/to/directory/'

# Generated at 2022-06-22 01:09:47.665354
# Unit test for function match
def test_match():
    assert match(Command('cat test.txt',
                         'cat: test.txt: Is a directory'))
    assert not match(Command('cat test.txt',
                         'hello world'))



# Generated at 2022-06-22 01:09:49.548437
# Unit test for function get_new_command
def test_get_new_command():
    a = get_new_command(Command(script = 'cat test'))
    assert(a == 'ls test')

# Generated at 2022-06-22 01:09:51.719174
# Unit test for function get_new_command
def test_get_new_command():
    command.script = 'ls'
    assert get_new_command(command) == 'ls'


enabled_by_default = True

# Generated at 2022-06-22 01:10:02.891353
# Unit test for function match
def test_match():
    assert match(Command(script='cat /some/thing/some/where', output='cat: some/where: Is a directory'))
    assert match(Command(script='cat /some/thing/some/where', output='cat: some/where: Is a directory'))
    assert not match(Command(script='cat /some/thing/some/where', output='whatever'))
    assert not match(Command(script='cat /some/thing/some/where', output='cat: some/where: Is a directory'))
    assert not match(Command(script='echo /some/thing/some/where', output='cat: some/where: Is a directory'))
    assert not match(Command(script='cat /some/thing/some/where', output='cat: some/where: Is a directory'))

# Generated at 2022-06-22 01:10:09.686534
# Unit test for function match
def test_match():
    command = Command('cat /tmp', '/tmp is a directory')
    assert match(command)
    command = Command('cat /tmp/file', '/tmp/file does not exist')
    assert not match(command)
    command = Command('cat /tmp/file', 'some error')
    assert not match(command)
    command = Command('cat /tmp/file', '/tmp/file')
    assert not match(command)



# Generated at 2022-06-22 01:10:23.703258
# Unit test for function match
def test_match():
    command = 'cat test.txt'
    assert for_app('cat', at_least=1)(command)
    assert not for_app('cat', at_least=1)('echo test')
    assert not for_app('cat', at_least=1)('ls test')
    assert not for_app('cat', at_least=1)('cat .')
    assert for_app('cat', at_least=1)('cat test')


# Generated at 2022-06-22 01:10:29.222583
# Unit test for function match
def test_match():
    # assert match('cat newfile.txt')
    assert match('cat folder1')
    assert not match('ls folder1')
    assert not match('ls file')
    assert not match('catt newfile.txt')
    assert not match('cat file')
    assert not match('catt file')



# Generated at 2022-06-22 01:10:31.955616
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat dir', 'cat: dir: Is a directory', 'dir')) == 'ls dir'

# Generated at 2022-06-22 01:10:34.360453
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('ls -a ~/.config/', '', '', '', '')
    assert get_new_command(command) == 'cat -a ~/.config/'

# Generated at 2022-06-22 01:10:38.368247
# Unit test for function match
def test_match():
    assert match(Command('cat test.txt',
                         output="cat: test.txt: Is a directory",))



# Generated at 2022-06-22 01:10:45.884459
# Unit test for function match
def test_match():
    command1 = Command('cat /home/user/bin', '', 'cat: /home/user/bin: Is a directory', '', '', '')
    command2 = Command('cat /home/user/Documents', '', 'cat: /home/user/Documents: Is a directory', '', '', '')
    command3 = Command('cat file.txt', '', 'This is a test file', '', '', '')
    assert match(command1)
    assert match(command2)
    assert not match(command3)



# Generated at 2022-06-22 01:10:47.479655
# Unit test for function match
def test_match():
    command = Command('cat tests', 'cat: tests: Is a directory')
    assert match(command)



# Generated at 2022-06-22 01:10:51.383792
# Unit test for function match
def test_match():
    assert match(Command('cat /home'))
    assert not match(Command('ls /home', '', '', '', 'ls: /home: Is a directory',
                       '', 'ls /home'))

# Generated at 2022-06-22 01:10:56.876047
# Unit test for function match
def test_match():
    assert match("cat test/fixtures/lorem.txt") is False
    assert match("cat test/fixtures/fuck_unit_test.txt") is False
    assert match("cat test/fixtures") is True
    assert match("cat test/fixtures/lorem.txt | grep -v even") is False


# Generated at 2022-06-22 01:11:01.180444
# Unit test for function match
def test_match():
    command1 = Command('cat /folder', '/folder: Is a directory')
    command2 = Command('cat', 'cat: im_a_file: No such file or directory')
    assert match(command1)
    assert not match(command2)


# Generated at 2022-06-22 01:11:15.551343
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat dir', 'cat: dir: Is a directory')
    assert get_new_command(command) == "ls dir"

# Generated at 2022-06-22 01:11:17.865781
# Unit test for function match
def test_match():
    assert match(Command('cat foo', 'cat: foo: Is a directory'))
    assert not match(Command('cat foo', ''))


# Generated at 2022-06-22 01:11:19.267032
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat test')) == 'ls test'

# Generated at 2022-06-22 01:11:21.167425
# Unit test for function match
def test_match():
    assert match(Command('cat /root', '', 'cat: is a directory'))


# Generated at 2022-06-22 01:11:24.230637
# Unit test for function match
def test_match():
    assert match(Command('cat abc', 'cat: abc: Is a directory'))
    assert not match(Command('cat abc', 'abc'))


# Generated at 2022-06-22 01:11:27.189199
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.ls_cat import get_new_command
    assert get_new_command(Command(script = 'cat lib')) == 'ls lib'


# Generated at 2022-06-22 01:11:31.404389
# Unit test for function match
def test_match():
    assert match(Command('cat', '', 'cat: test: Is a directory'))
    assert not match(Command('cat', '', 'cat: command not found'))
    assert not match(Command('cat', '', 'cat: test: Is a file'))



# Generated at 2022-06-22 01:11:39.466342
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat ../../.')) == 'ls ../../.'
    assert get_new_command(Command('cat -n greetings.txt')) == 'ls -n greetings.txt'
    assert get_new_command(Command('cat -n -e greetings.txt')) == 'ls -n -e greetings.txt'
    assert get_new_command(Command('cat -n -e cat')) == 'ls -n -e cat'
    assert get_new_command(Command('cat -n -e cat.txt')) == 'ls -n -e cat.txt'
    assert get_new_command(Command('cat -n -e "cat.txt"')) == 'ls -n -e "cat.txt"'