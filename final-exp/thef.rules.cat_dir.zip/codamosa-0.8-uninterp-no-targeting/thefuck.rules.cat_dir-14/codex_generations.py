

# Generated at 2022-06-22 01:01:42.880337
# Unit test for function get_new_command
def test_get_new_command():
    command = "cat ./labs"
    assert get_new_command(command) == command.replace('cat', 'ls', 1)

# Generated at 2022-06-22 01:01:44.313239
# Unit test for function get_new_command
def test_get_new_command():
    assert 'ls file1 file2' == get_new_command('cat file1 file2')

# Generated at 2022-06-22 01:01:47.814928
# Unit test for function match
def test_match():
    assert match(Command('cat non-existed-dir', 'cat: non-existed-dir: Is a directory'))
    assert not match(Command('ls another-dir', ''))

# Generated at 2022-06-22 01:01:51.721393
# Unit test for function match
def test_match():
    assert match(Command('cat xxx', 'cat: xxx: Is a directory\n'))
    assert not match(Command('cat file', "xxx\n"))
    assert not match(Command('cat file', "", error="xxx",))


# Generated at 2022-06-22 01:01:53.931900
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_directory import get_new_command
    assert get_new_command(u'cat test') == 'ls test'
    assert get_new_command(u'cat test/test.py') == 'cat test/test.py'

# Generated at 2022-06-22 01:01:55.675882
# Unit test for function get_new_command
def test_get_new_command():
  assert get_new_command("cat /home/user/").script == "ls /home/user/"

# Generated at 2022-06-22 01:01:58.589085
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat foo') == 'ls foo'
    assert get_new_command('cat foo bar') == 'ls foo bar'
    assert get_new_command('cat /usr') == 'ls /usr'

# Generated at 2022-06-22 01:02:01.296580
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script': 'cat file'})
    assert get_new_command(command) == 'ls file'

# Generated at 2022-06-22 01:02:03.427699
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat') == 'ls'
    assert get_new_command('cat /home') == 'ls /home'


# Generated at 2022-06-22 01:02:07.345466
# Unit test for function match
def test_match():
    assert match(Command('cat XXX',
        output='cat: XXX: Is a directory'))
    assert not match(Command('cat XXX',
        output='cat: XXX: No such file or directory'))

# Generated at 2022-06-22 01:02:11.438266
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /usr', 'cat: /usr: Is a directory')
    assert get_new_command(command) == 'ls /usr'

# Generated at 2022-06-22 01:02:13.799067
# Unit test for function match
def test_match():
    command = Command('cat /', 'cat: /: Is a directory\n')
    assert match(command)



# Generated at 2022-06-22 01:02:16.099627
# Unit test for function match
def test_match():
    command = Command('cat /usr/', '')
    assert match(command)


# Unit test functions get_new_command

# Generated at 2022-06-22 01:02:22.202079
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/passwd', '', '', 'cat: /etc/passwd: Is a directory', ''))
    assert match(Command('cat /usr/bin', '', '', 'cat: /usr/bin: Is a directory', ''))
    assert not match(Command('cat /etc/passwd', '', '', '', ''))



# Generated at 2022-06-22 01:02:24.467479
# Unit test for function get_new_command
def test_get_new_command():
    # more realistic example
    assert get_new_command("cat /etc/test") == "ls /etc/test"

# Generated at 2022-06-22 01:02:27.076730
# Unit test for function get_new_command
def test_get_new_command():
    command_ = Command('cat a_file')
    assert get_new_command(command_).script == 'ls a_file'

# Generated at 2022-06-22 01:02:32.582587
# Unit test for function match
def test_match():
    command = Command('cat foo', 'cat: foo: Is a directory')
    assert match(command)
    command = Command('cat foo', 'cat: foo: No such file or directory')
    assert not match(command)
    command = Command('cat bar', 'cat: bar: Is a directory')
    assert not match(command)


# Generated at 2022-06-22 01:02:37.385719
# Unit test for function match
def test_match():
    assert match(Command('cat test.txt'))
    assert not match(Command('ls test.txt'))
    assert not match(Command('cat test.txt', 'test.txt is a directory'))
    assert not match(Command('cat test.txt', 'test.txt: Invalid argument'))



# Generated at 2022-06-22 01:02:42.246626
# Unit test for function match
def test_match():
    assert not match(Command('cat foo', '', '', '', None, None))
    assert not match(Command('cat /tmp', 'file content', '',  '', None, None))
    assert match(Command('cat /tmp', 'cat: /tmp: Is a directory', '',  '', None, None))


# Generated at 2022-06-22 01:02:45.662325
# Unit test for function get_new_command
def test_get_new_command():
    assert match(cat('cat /home'))
    # Pop the first element of a list, which is a command
    assert get_new_command(cat('cat /home')).script_parts[0] == 'ls'

# Generated at 2022-06-22 01:02:52.876540
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /etc/hosts') == 'ls /etc/hosts'
    assert get_new_command('cat /etc/hosts | grep 127') == 'ls /etc/hosts | grep 127'
    assert get_new_command('cat /etc/hosts | grep 127 > /etc/hosts') == 'ls /etc/hosts | grep 127 > /etc/hosts'

# Generated at 2022-06-22 01:02:55.910295
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /tmp/") == "ls /tmp/"
    assert get_new_command("cat /tmp/blah") == "ls /tmp/blah"



# Generated at 2022-06-22 01:03:07.175533
# Unit test for function get_new_command
def test_get_new_command():
    # Test if cat is replaced by ls for directory
    assert get_new_command('cat /etc/').script == 'ls /etc/'
    assert get_new_command('cat /etc/.').script == 'ls /etc/.'
    assert get_new_command('cat /etc/..').script == 'ls /etc/..'
    # Test if cat is replaced by ls for file
    assert get_new_command('cat /etc/passwd').script == 'cat /etc/passwd'
    assert get_new_command('cat /tmp/does_not_exist').script == 'cat /tmp/does_not_exist'
    # Test if cat is replaced by ls using sudo
    assert get_new_command('sudo cat /etc/').script == 'sudo ls /etc/'

# Generated at 2022-06-22 01:03:12.239244
# Unit test for function match
def test_match():
    command = Command('cat /tmp', 'cat: tmp: Is a directory')
    assert match(command)

    command = Command('cat /etc/hosts', 'cat: etc/hosts: No such file or directory')
    assert not match(command)


# Generated at 2022-06-22 01:03:17.979360
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/hosts', output='cat: /etc/hosts: Is a directory'))
    assert not match(Command('cat /etc/hosts', output='cat: /etc/hosts: No such file or directory'))
    assert not match(Command('cat /etc/hosts', output='/etc/hosts'))


# Generated at 2022-06-22 01:03:18.918078
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /Users/test')) == 'ls /Users/test'


# Generated at 2022-06-22 01:03:21.416515
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat test/test', '')
    assert get_new_command(command) == 'ls test/test'



# Generated at 2022-06-22 01:03:23.677925
# Unit test for function get_new_command
def test_get_new_command():
    command = Command.from_string('cat /root/')
    assert get_new_command(command) == 'ls /root/'

# Generated at 2022-06-22 01:03:25.719063
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /home/') == 'ls /home/'

# Generated at 2022-06-22 01:03:28.624608
# Unit test for function match
def test_match():
    assert match(Command(script='cat abc',output='cat: abc: Is a directory'))
    assert not match(Command(script='cat abc',output='abc'))

# Generated at 2022-06-22 01:03:31.767145
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command) == command.script.replace('cat', 'ls', 1)

# Generated at 2022-06-22 01:03:33.117263
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat ls') == 'ls ls'

# Generated at 2022-06-22 01:03:37.698428
# Unit test for function match
def test_match():
    assert(match(Command('cat /var/log',
                         '/var/log is a directory')) == True)
    assert(match(Command('cat foo.txt',
                         'foo.txt is a file')) == False)


# Generated at 2022-06-22 01:03:39.330467
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat foo") == "ls foo"

# Generated at 2022-06-22 01:03:41.303082
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat text.txt') == 'ls text.txt'

# Generated at 2022-06-22 01:03:43.125775
# Unit test for function get_new_command
def test_get_new_command():
    test_input = 'cat /home'
    test_output = 'ls /home'
    asser

# Generated at 2022-06-22 01:03:44.530944
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat ./test') == 'ls ./test'

# Generated at 2022-06-22 01:03:48.849616
# Unit test for function match
def test_match():
    assert match(Command('cat /usr/local/bin/', 
        'cat: /usr/local/bin/: Is a directory\n'))
    #assert not match(Command('cat /tmp/ls/',
    #    ''))
    assert not match(Command('cat --help',
        ''))

# Generated at 2022-06-22 01:03:55.926882
# Unit test for function match
def test_match():
    output1 = "cat: cat: Is a directory\n"
    output2 = "cat: foo: Is a directory\n"
    output3 = "cat: foo: No such file or directory\n"

    assert match(Command('cat foo', output=output1))
    assert not match(Command('cat foo', output=output2))
    assert not match(Command('cat foo', output=output3))

test_match()


# Generated at 2022-06-22 01:04:00.643587
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat tmp/file.txt') == 'ls tmp/file.txt'
    assert get_new_command('cat tmp/file.txt | wc') == 'ls tmp/file.txt | wc'
    assert get_new_command('cat tmp') == 'ls tmp'

# Generated at 2022-06-22 01:04:06.804823
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat /usr/bin", "cat: /usr/bin: Is a directory")
    new_command = get_new_command(command)
    assert new_command == "ls /usr/bin"

# Generated at 2022-06-22 01:04:08.240119
# Unit test for function match
def test_match():
	assert match(Command('cat /home/user/test', ''))
	assert not match(Command('cat test.txt', ''))



# Generated at 2022-06-22 01:04:10.713807
# Unit test for function match
def test_match():
    assert (match('cat /var/log/wu-ftpd/ftp-access.log') == True)


# Generated at 2022-06-22 01:04:13.531819
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /usr/bin/', 'cat: /usr/bin/: Is a directory')
    assert get_new_command(command) == 'ls /usr/bin/'

# Generated at 2022-06-22 01:04:17.370289
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(
        'cat /Users/c/Desktop/fuck',
        'cat: /Users/c/Desktop/fuck: Is a directory'
    )).script == 'ls /Users/c/Desktop/fuck'

# Generated at 2022-06-22 01:04:19.557604
# Unit test for function match
def test_match():
    assert match('cat foo')
    assert not match('ls foo')
    assert not match('ls')


# Generated at 2022-06-22 01:04:21.893809
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /tmp/')) == 'ls /tmp/'

# Generated at 2022-06-22 01:04:26.598767
# Unit test for function match
def test_match():
    assert match(Command('cat test.txt', output='cat: test.txt: Is a directory'))
    assert not match(Command('cat test.txt', output='cat: No such file or directory'))
    assert not match(Command('ls test.txt', output='cat: No such file or directory'))


# Generated at 2022-06-22 01:04:30.393836
# Unit test for function get_new_command
def test_get_new_command():
    c = Command('cat src', '/tmp')
    assert get_new_command(c) == 'ls src'
    c = Command('cat src/', '/tmp')
    assert get_new_command(c) == 'ls src/'



# Generated at 2022-06-22 01:04:35.449005
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object, ), {'script':'cat /home/dir', 'script_parts':['cat', '/home/dir']})
    assert get_new_command(command) == 'ls /home/dir'
    assert get_new_command(command).startswith('ls')


# Generated at 2022-06-22 01:04:40.330839
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home', '')
    assert get_new_command(command) == 'ls /home'



# Generated at 2022-06-22 01:04:43.331010
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /etc/passwd") == "ls /etc/passwd"

# Generated at 2022-06-22 01:04:47.231186
# Unit test for function get_new_command
def test_get_new_command():
    cat_cmd = Command('cat a/b/c', 'cat: a/b/c: Is a directory')
    ls_cmd = Command('ls a/b/c', '')
    assert get_new_command(cat_cmd) == ls_cmd.script

# Generated at 2022-06-22 01:04:49.383975
# Unit test for function match
def test_match():
    assert(match(Command('cat /', output='cat: /: Is a directory')))


# Generated at 2022-06-22 01:04:53.035740
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat ./') == 'ls ./'
    assert get_new_command('cat ./test') == 'ls ./test'
    assert get_new_command('cat /etc') == 'ls /etc'
    assert get_new_command('cat /etc/hosts') == 'ls /etc/hosts'



# Generated at 2022-06-22 01:04:55.147113
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat food')) == 'ls food'


# Generated at 2022-06-22 01:04:58.092161
# Unit test for function match
def test_match():
    assert match(Command('cat test.txt', '', ''))
    assert not match(Command('ls test.txt', '', ''))



# Generated at 2022-06-22 01:05:00.229408
# Unit test for function match
def test_match():
    assert match(Command('cat', 'cat: filename: Is a directory', ''))


# Generated at 2022-06-22 01:05:04.785380
# Unit test for function match
def test_match():
    assert not match(Command('ls'))
    assert not match(Command('cat', 'foobar'))
    assert match(Command('cat', 'hallo/'))
    assert match(Command('cat','"hallo/"'))

# Generated at 2022-06-22 01:05:08.625519
# Unit test for function match
def test_match():
    assert match(Command('cat dir', 'cat: dir: Is a directory', None))
    assert not match(Command('cat dir', '', None))
    assert not match(Command('cat file', '', None))


# Generated at 2022-06-22 01:05:19.484943
# Unit test for function match
def test_match():
    # Test for given output 
    command = Command(script='cat some_file.txt',
                      output='cat: some_file.txt: Is a directory')
    assert match(command)

    # Test for wrong output
    command = Command(script='cat some_file.txt',
                      output='cat: some_file.txt: No such file or directory')
    assert not match(command)

    # Test for wrong output
    command = Command(script='cat some_file.txt',
                      output='cat: some_file.txt: No such file or directory')
    assert not match(command)


# Generated at 2022-06-22 01:05:25.141386
# Unit test for function match
def test_match():
    if not os.path.isdir('/home/root/Downloads'):
        assert not match(Command('cd home/root/Downloads', '', '/home/root/Downloads'))
    else:
        assert not match(Command('cd home/root/Downloads', '', '/home/root/Downloads'))


# Generated at 2022-06-22 01:05:29.467022
# Unit test for function match
def test_match():
    assert match(Command('cat code.py',
                         output="cat: 'code.py': Is a directory"))
    assert not match(Command('ls code.py',
                             output="ls: cannot access 'code.py': Is a directory"))
    assert match(Command('cat a'))

# Generated at 2022-06-22 01:05:31.429644
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /usr/')
    assert get_new_command(command) == 'ls /usr/'

# Generated at 2022-06-22 01:05:35.173365
# Unit test for function get_new_command
def test_get_new_command():
    import tempfile
    d = tempfile.mkdtemp()
    c = Command('cat ' + d)
    assert get_new_command(c) == 'ls ' + d

# Generated at 2022-06-22 01:05:38.492784
# Unit test for function match
def test_match():
	assert_match(match, "cat /etc/passwd")
	assert_not_match(match, "cat --help")
	assert_not_match(match, "mkdir /etc/passwd")


# Generated at 2022-06-22 01:05:40.385423
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home/')
    assert get_new_command(command) == 'ls /home/'

# Generated at 2022-06-22 01:05:42.554445
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /usr/bin/')
    assert get_new_command(command) == 'ls /usr/bin/'

# Generated at 2022-06-22 01:05:48.262043
# Unit test for function match
def test_match():
    assert match(Command(script='cat test.txt', output='cat: test.txt: Is a directory'))
    assert not match(Command(script='cat test.txt', output='cat: test.txt: No such file or directory'))
    assert match(Command(script='cat test.txt', output='cat: test.txt: Permission denied'))

# Generated at 2022-06-22 01:05:51.756977
# Unit test for function get_new_command
def test_get_new_command():
    script = "cat ~/Desktop"
    output = "cat: Desktop: Is a directory"
    new_command = get_new_command(Command(script, output))
    assert new_command == "ls ~/Desktop"

# Generated at 2022-06-22 01:05:57.221085
# Unit test for function match
def test_match():
    assert match(Command('cat README.md', 'cat: README.md: Is a directory'))
    assert not match(Command('cat README.md', 'README.md content'))

# Generated at 2022-06-22 01:06:02.439361
# Unit test for function match
def test_match():
    # Example for a correct input
    assert match(Command('cat ../test', None)) == True
    # Example for a wrong input
    assert match(Command('ls ../test', None)) == False
    # Correct input, but given wrong script_parts
    assert match(Command('cat: test', None)) == False


# Generated at 2022-06-22 01:06:06.577125
# Unit test for function match
def test_match():
    assert match(Command('cat xxx', ''))
    assert match(Command('cat xxx', 'cat: xxx: Is a directory', ''))


# Generated at 2022-06-22 01:06:09.680600
# Unit test for function match
def test_match():
    assert match(Command(script = 'cat README.md'))
    assert not match(Command(script = 'cat README.md', output = 'cat: README.md: Is a directory'))


# Generated at 2022-06-22 01:06:12.176185
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home/foo/bar')
    assert get_new_command(command)\
        == "ls /home/foo/bar"

# Generated at 2022-06-22 01:06:21.202782
# Unit test for function match
def test_match():
    assert match(Command('cat test', None, "cat: test: Is a directory\n"))
    assert not match(Command('cat test', None, "cat: test: No such file or directory\n"))
    assert match(Command('cat test/', None, "cat: test/: Is a directory\n"))
    assert not match(Command('cat test/', None, "cat: test/: No such file or directory\n"))
    assert match(Command('cat dir1/dir2/dir3/', None, "cat: dir1/dir2/dir3/: Is a directory\n"))
    assert not match(Command('cat dir1/dir2/dir3/', None, "cat: dir1/dir2/dir3/: No such file or directory\n"))


# Generated at 2022-06-22 01:06:27.132278
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('cat test', 'cat: test: is a directory\n', '')
    command2 = Command('cat test ', 'cat: test : is a directory\n', '')
    assert get_new_command(command1) == 'ls test'
    assert get_new_command(command2) == 'ls test '

# Generated at 2022-06-22 01:06:28.514866
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat more').script == 'ls more'

# Generated at 2022-06-22 01:06:31.941142
# Unit test for function match
def test_match():
    assert match(Command('cat does_not_exist', ''))
    assert match(Command('cat /tmp/does_not_exist', ''))
    assert not match(Command('cat /tmp', ''))

# Generated at 2022-06-22 01:06:36.439733
# Unit test for function match
def test_match():
    assert match(Command('cat non_existent_dir', ''))
    assert not match(Command('cat', ''))
    assert not match(Command('cat_non_existent_dir', ''))
    assert not match(Command('cat_a', ''))



# Generated at 2022-06-22 01:06:41.613549
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory')) == True



# Generated at 2022-06-22 01:06:45.780572
# Unit test for function match
def test_match():
    assert match(Command('cat abc', 'cat: abc: Is a directory', ''))
    assert not match(Command('cat abc', 'cat: abc: No such file or directory', ''))


# Generated at 2022-06-22 01:06:52.178470
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command(Command('cat aFile', 'cat: aFile.txt: No such file or directory')),
        'ls aFile')
    assert_equals(get_new_command(Command('cat aFile', 'cat: aFile.txt: Is a directory')),
        'ls aFile')
    assert_equals(get_new_command(Command('cat aFile', 'cat: aFile.txt: Permission denied')),
        'cat aFile')

# Generated at 2022-06-22 01:06:58.976160
# Unit test for function match
def test_match():
    assert match(Command('cat abc', '')) is False
    assert match(Command('cat test', 'cat: test: Is a directory')) is True
    assert match(Command('cat test/test', 'cat: test/test: Is a directory')) is True
    assert match(Command('cat', 'cat: missing file operand')) is False


# Generated at 2022-06-22 01:07:02.011744
# Unit test for function match
def test_match():
    assert match(Command('$ cat dir', 'cat: dir: Is a directory'))
    assert not match(Command('$ cat dir', 'cat: dir: No such file or directory'))


# Generated at 2022-06-22 01:07:05.165103
# Unit test for function match
def test_match():
    command = Command('cat test', '/bin/ls')
    assert not match(command)
    command = Command('cat test', '/bin/cat')
    assert match(command)


# Generated at 2022-06-22 01:07:10.367484
# Unit test for function get_new_command

# Generated at 2022-06-22 01:07:13.263006
# Unit test for function match
def test_match():
    assert match(Command('cat', 'cat: sfsfsf: Is a directory\n'))
    assert not match(Command('cat file1 file2', ''))


# Generated at 2022-06-22 01:07:19.677228
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp/doesnotexist', 'cat: /tmp/doesnotexist: No such file or directory'))
    assert not match(Command('cat /tmp', ''))
    assert not match(Command('cat /tmp', '', stderr='foo'))
    assert not match(Command('cat /tmp', 'foo'))
    assert not match(Command('echo foo', ''))


# Generated at 2022-06-22 01:07:22.712946
# Unit test for function match
def test_match():
    assert match(Command('cat', 'cat: tmp/: Is a directory', 'tmp/'))
    assert match(Command('cat', 'cat: tmp/: Is a directory', 'tmp/')) is False


# Generated at 2022-06-22 01:07:33.069589
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    assert get_new_command(Command(script='cat', output='cat: test: Is a directory')) == 'ls'
    assert get_new_command(Command(script='cat file', output='cat: file: Is a directory')) == 'ls file'

# Generated at 2022-06-22 01:07:36.659288
# Unit test for function get_new_command
def test_get_new_command():
    new_command = Command('cat /usr', 'cat: /usr: Is a directory\n')
    assert get_new_command(new_command) == 'ls /usr'

# Generated at 2022-06-22 01:07:40.972773
# Unit test for function match
def test_match():
    assert match(Command(script='cat ./src',
                         output='cat: ./src: Is a directory'))
    assert not match(Command(script='cat ./src',
                             output='cat: ./src: No such file'))


# Generated at 2022-06-22 01:07:44.912308
# Unit test for function match
def test_match():
    assert match(Command(script='cat myfile', output='cat: myfile: Is a directory'))
    assert not match(Command(script='cat myfile', output='error message'))
    assert not match(Command(script='ls', output='ls: command not found'))


# Generated at 2022-06-22 01:07:48.192447
# Unit test for function match
def test_match():
    assert match(Command(script='cat\tmp', output='cat: tmp: Is a directory'))
    assert not match(Command(script='ls\tmp', output='cat: tmp: Is a directory'))

# Generated at 2022-06-22 01:07:55.078950
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /foo/bar/baz') == 'ls /foo/bar/baz'
    assert get_new_command('cat /foo/bar/baz.txt') == 'cat /foo/bar/baz.txt'
    assert get_new_command('cat foo bar baz') == 'cat foo bar baz'
    assert get_new_command('cat foo bar baz') == 'cat foo bar baz'


# Generated at 2022-06-22 01:07:56.591963
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test.txt') == 'ls test.txt'

# Generated at 2022-06-22 01:08:02.832587
# Unit test for function match
def test_match():
    assert match(Command('cat /usr/bin/', 'cat: /usr/bin/: Is a directory'))
    assert not match(Command('cat /usr/bin/', 'cat: /usr/bin: Is a directory'))
    assert not match(Command('cat /usr/bin/', 'cat: /usr/bin/: No such file or directory'))


# Generated at 2022-06-22 01:08:06.454881
# Unit test for function match
def test_match():
    command = Command('cat test')
    assert match(command)
    command = Command('ls test')
    assert not match(command)
    command = Command('')
    assert not match(command)


# Generated at 2022-06-22 01:08:09.637797
# Unit test for function get_new_command
def test_get_new_command():
    assert 'ls' == get_new_command('cat /usr/local').script_parts[0]

# Generated at 2022-06-22 01:08:24.789234
# Unit test for function match
def test_match():
    assert match(Command('cat blah blah blah', 'blah'))
    assert not match(Command('ls', 'blah'))


# Generated at 2022-06-22 01:08:28.297729
# Unit test for function match
def test_match():
    assert not match(Command('ls /'))
    assert match(Command('cat src'))
    assert not match(Command('cat main.py', 'ls'))


# Generated at 2022-06-22 01:08:30.220000
# Unit test for function get_new_command
def test_get_new_command():
    command = command = Command('cat something/')
    assert get_new_command(command) == 'ls something/'

# Generated at 2022-06-22 01:08:37.451747
# Unit test for function match
def test_match():
    assert match(Command('cat~/abc'))
    assert match(Command('cat /home/abc'))
    assert match(Command('cat /home/abc/def'))
    assert not match(Command('cat'))
    assert not match(Command('cat fake'))
    assert not match(Command('cat /home'))
    assert not match(Command('cat /home/abc/def/ghi'))
    assert not match(Command('cat /home/abc/def /home'))
    assert not match(Command('cat /home/abc/def /home/abc'))

# Generated at 2022-06-22 01:08:40.868472
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home/user/Desktop', '/home/user/Desktop')
    assert get_new_command(command) == 'ls /home/user/Desktop'

# Generated at 2022-06-22 01:08:45.608516
# Unit test for function get_new_command
def test_get_new_command():
    output = get_new_command('''cat: /etc/nodenv/versions/10.13.0/lib/node_modules/nodenv-versions/: Is a directory''')
    assert output == 'ls /etc/nodenv/versions/10.13.0/lib/node_modules/nodenv-versions/'

# Generated at 2022-06-22 01:08:54.155251
# Unit test for function match
def test_match():
    os.path.isdir('/tmp')
    command = Command(script='cat /tmp',
                      stderr='cat: /tmp: Is a directory',
                      stdout='output')
    assert "cat: /tmp: Is a directory" == command.output
    assert True == match(command)

    os.path.isdir('/tmp/toto')
    command = Command(script='cat /tmp/toto',
                      stderr='cat: /tmp/toto: No such file or directory',
                      stdout='output')
    assert False == match(command)



# Generated at 2022-06-22 01:09:01.367004
# Unit test for function match
def test_match():
    from thefuck.rules.cat_is_directory import match
    command1 = 'cat: /usr/local/share/man/man5: Is a directory'
    command2 = 'cat: file: Is a directory'
    command3 = 'cat: file: No such file or directory'
    command4 = 'echo "hello"'
    assert match(command1)


# Generated at 2022-06-22 01:09:03.157198
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat './directory'") == "ls './directory'"


# Generated at 2022-06-22 01:09:11.462104
# Unit test for function match
def test_match():
    command = Command('cat /etc/passwd',
    '/usr/bin/cat: /etc/passwd: Is a directory\n')
    assert match(command)
    command = Command('catt /etc/passwd',
    '/usr/bin/cat: /etc/passwd: Is a directory\n')
    assert not match(command)
    command = Command('catt /etc/passwd',
    'Usage: cat [OPTION]... [FILE]...\nConcatenate FILE(s) to standard output.\n')
    assert not match(command)


# Generated at 2022-06-22 01:09:28.926208
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cat /path/test/test_1/test_2 test_3/test_4")
    assert get_new_command(command) == "ls /path/test/test_1/test_2 test_3/test_4"


# Generated at 2022-06-22 01:09:31.227593
# Unit test for function match
def test_match():
    assert match(Command('cat thefuck', ''))
    assert not match(Command('cat test.py', ''))


# Generated at 2022-06-22 01:09:34.706489
# Unit test for function match
def test_match():
    assert match(Command("cat path", "cat: path: Is a directory"))
    assert match(Command("cat path/", "cat: path/: Is a directory"))
    assert not match(Command("cat nonexistent"))


# Generated at 2022-06-22 01:09:37.483316
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('cat test.txt', '', stderr='cat: test.txt: Is a directory', script='cat test.txt')
    assert get_new_command(cmd) == 'ls test.txt'

# Generated at 2022-06-22 01:09:39.050670
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat dir') == 'ls dir'

# Generated at 2022-06-22 01:09:44.908531
# Unit test for function get_new_command
def test_get_new_command():
    parts = ['/usr/bin/cat', '/home/stefan/.mutt/accounts']
    output = '/home/stefan/.mutt/accounts: Is a directory'
    assert get_new_command(Command(parts, output)) == 'ls /home/stefan/.mutt/accounts'

# Generated at 2022-06-22 01:09:46.571141
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat folder') == 'ls folder'

# Generated at 2022-06-22 01:09:48.854672
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home/user/folder')
    assert get_new_command(command) == 'ls /home/user/folder'

# Generated at 2022-06-22 01:09:52.242103
# Unit test for function match
def test_match():
    # Test 1
    output = "/cat: /bin: Is a directory"
    assert True == match(output)

    # Test 2
    output = "/cat: /bin: No such file or directory"
    assert False == match(output)



# Generated at 2022-06-22 01:09:56.123034
# Unit test for function match
def test_match():
    assert match(Command('cat abc', 'cat: abc: Is a directory'))
    assert not match(Command('cat abc', 'cat abc'))
    assert not match(Command('cat abc', 'cat: abc: Is not a directory'))


# Generated at 2022-06-22 01:10:15.437063
# Unit test for function match
def test_match():
    assert match(Command('cat ../', 'cat: ../: Is a directory'))
    assert not match(Command('cat input.txt', ''))


# Generated at 2022-06-22 01:10:17.894144
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /usr/bin') == 'ls /usr/bin'


enabled_by_default = True

# Generated at 2022-06-22 01:10:20.194128
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat ~', output='cat: ~: Is a directory')
    assert get_new_command(command) == 'ls ~'

# Generated at 2022-06-22 01:10:21.697550
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat dir1') == 'ls dir1'

# Generated at 2022-06-22 01:10:25.153996
# Unit test for function match
def test_match():
    if os.path.isdir('/Applications/'):
        assert match(Command('cat /Applications/'))
    elif os.path.isdir('/bin/'):
        assert match(Command('cat /bin/'))
    assert not match(Command('cat foo'))



# Generated at 2022-06-22 01:10:27.757268
# Unit test for function get_new_command
def test_get_new_command():
    command_script = "cat test.txt"
    res = get_new_command(command_script)
    assert res == "ls test.txt"

# Generated at 2022-06-22 01:10:32.553999
# Unit test for function match
def test_match():
    command = Command('cat /var/lib/dpkg/status', 'cat: /var/lib/dpkg/status: Is a directory')
    assert match(command)

    command = Command('cat status', 'cat: status: No such file or directory')
    assert not match(command)


# Generated at 2022-06-22 01:10:34.523684
# Unit test for function match
def test_match():
    assert not match(Command('cat /usr/bin/ls'))
    assert match(Command('cat /bin'))



# Generated at 2022-06-22 01:10:39.843371
# Unit test for function match
def test_match():
    assert match(Command('cat /etc', 'cat: /etc: Is a directory'))
    assert not match(Command('cat /etc/apt/sources.list', 'cat: /etc/apt/sources.list: No such file or directory'))

# Generated at 2022-06-22 01:10:42.261209
# Unit test for function match
def test_match():
    assert match(Command('cat README.md', 'cat: README.md: Is a directory\n', None))


# Generated at 2022-06-22 01:11:10.843067
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat import get_new_command
    assert get_new_command(
        Command('cat dir',
                'cat: dir: Is a directory',
                'dir')) == 'ls dir'


# Generated at 2022-06-22 01:11:12.575585
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat invalid/path | less') == 'ls invalid/path | less'

# Generated at 2022-06-22 01:11:14.746252
# Unit test for function match
def test_match():
    assert match(Command('cat foo',
                         'cat: foo: Is a directory',
                         '/bin/ls foo'))

# Generated at 2022-06-22 01:11:19.123323
# Unit test for function match
def test_match():
    command = Command("cat file1 file2", "cat: file1 file2: Is a directory")
    assert(match(command))
    command = Command("cat file1 file2", "cat: file1 file2: Is not a directory")
    assert(not match(command))


# Generated at 2022-06-22 01:11:23.882787
# Unit test for function match
def test_match():
    assert match(Command('cat file',
                         'cat: file: Is a directory',
                         ''))
    assert not match(Command('cat file',
                             '',
                             ''))
    assert not match(Command('cat file',
                             'cat: another: Is a directory',
                             ''))



# Generated at 2022-06-22 01:11:26.782773
# Unit test for function get_new_command
def test_get_new_command():
    script = 'cat /home'
    command = Command(script, 'cat: /home: Is a directory')
    assert get_new_command(command) == 'ls /home'

# Generated at 2022-06-22 01:11:29.796134
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /path/to/file/')
    new_command = get_new_command(command)
    assert new_command == 'ls /path/to/file/'


enabled_by_default = True

# Generated at 2022-06-22 01:11:33.942059
# Unit test for function match
def test_match():
    assert match(Command('cat Makefile', '/home/amy', '', '', '', '', 0))
    assert not match(Command('cat foo', '/home/amy', '', '', '', '', 0))


# Generated at 2022-06-22 01:11:35.848832
# Unit test for function get_new_command
def test_get_new_command():
    import thefuck
    assert thefuck.get_new_command("cat /var/log/syslog") == 'ls /var/log/syslog'

# Generated at 2022-06-22 01:11:37.791618
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /home/") == "ls /home/"