

# Generated at 2022-06-22 01:01:40.948024
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('cat test.txt') == 'ls test.txt')

# Generated at 2022-06-22 01:01:42.429687
# Unit test for function match

# Generated at 2022-06-22 01:01:45.085675
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('cat a b', 'cat: b: Is a directory')) == 'ls a b'

# Generated at 2022-06-22 01:01:55.728631
# Unit test for function match
def test_match():
    assert match(Command('cat test', None, 'cat: test: Is a directory'))
    assert match(Command('cat --help', None, 'cat: --help: Is a directory'))
    assert not match(Command('cat test', None, 'cat: test: No such file or directory'))
    assert not match(Command('cat test', None, 'cat: test: Permission denied'))
    assert not match(Command('cat test test2', None, 'cat: test test2: No such file or directory'))
    assert not match(Command('cat test', None, 'cat: test: Is not a directory'))
    assert not match(Command('cat test', None, 'cat: test: Is not a directory'))


# Generated at 2022-06-22 01:01:57.129957
# Unit test for function match
def test_match():
    assert match(Command('cat tmp'))



# Generated at 2022-06-22 01:01:59.384707
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_comm

# Generated at 2022-06-22 01:02:04.098802
# Unit test for function get_new_command
def test_get_new_command():
    command = "cat /home/developer"
    command2 = "cat /home/developer/file.txt"
    command3 = "cat file.txt"

    assert get_new_command(command) == "ls /home/developer"
    assert get_new_command(command2) == "ls file.txt"
    assert get_new_command(command3) == "ls file.txt"

# Generated at 2022-06-22 01:02:06.831109
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /sfsd')
    assert get_new_command(command) == 'ls /sfsd'

# Generated at 2022-06-22 01:02:12.734215
# Unit test for function match
def test_match():
    assert match(Command('cat bla bla'))
    assert match(Command('cat bla bla bla bla'))
    assert match(Command('cat ../../'))
    assert not match(Command('cat'))
    assert not match(Command('ls bla bla'))
    assert not match(Command('cat bla/bla'))


# Generated at 2022-06-22 01:02:15.524966
# Unit test for function get_new_command
def test_get_new_command():
    script = 'cat'
    command = Command(script, script_parts=script.split())
    assert(get_new_command(command) == 'ls')


# Generated at 2022-06-22 01:02:18.827735
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /home/') == 'ls /home/'

# Generated at 2022-06-22 01:02:21.224802
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat a', 'cat: a: Is a directory\n')) == 'ls a'

# Generated at 2022-06-22 01:02:23.297739
# Unit test for function match
def test_match():
    command = Command('cat test', 'cat: test: Is a directory')
    assert match(command)



# Generated at 2022-06-22 01:02:26.491346
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('echo test', 'echo: test: Is a directory'))

# Generated at 2022-06-22 01:02:29.924044
# Unit test for function match
def test_match():
    assert match(
        Command('cat test',
                output='cat: test: Is a directory'))
    assert not match(
        Command('cat test',
                output=''))


# Generated at 2022-06-22 01:02:31.605377
# Unit test for function match
def test_match():
    assert match(Command('cat test', 'cat: test: Is a directory'))
    assert not match(Command('cat test', 'hello'))

# Generated at 2022-06-22 01:02:34.952691
# Unit test for function get_new_command
def test_get_new_command():
    command = u'cat /home/user/documents'
    assert get_new_command(command) == 'ls /home/user/documents'



# Generated at 2022-06-22 01:02:37.006851
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /etc')
    assert get_new_command(command) == 'ls /etc'


prin

# Generated at 2022-06-22 01:02:38.931899
# Unit test for function match
def test_match():
    assert not match(Command('ls'))
    assert match(Command('cat a/b/c'))

# Generated at 2022-06-22 01:02:45.663937
# Unit test for function match
def test_match():
    # Test for command cat
    assert match(Command('cat file_1', 'cat: file_1: Is a directory', '', 1))
    # Test for command cat -a, cat --a
    assert not match(Command('cat -a file_1', 'cat: file_1: Is a directory', '', 1))
    assert not match(Command('cat --a file_1', 'cat: file_1: Is a directory', '', 1))


# Generated at 2022-06-22 01:02:50.093200
# Unit test for function match
def test_match():
    command = Command("cat ~/.bash_profile")
    assert match(command)



# Generated at 2022-06-22 01:02:53.563205
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat import get_new_command
    assert get_new_command(Command(script='cat file.txt',
                                   stdout='cat: file.txt: is a directory')) == 'ls file.txt'

# Generated at 2022-06-22 01:02:58.065864
# Unit test for function get_new_command
def test_get_new_command():
    command_parm = 'cat /Users/hj/Documents'
    command = re.sub(r'^(\w+)', r'fuck \1', command_parm)
    assert get_new_command(command) == 'fuck ls /Users/hj/Documents'

# Generated at 2022-06-22 01:03:07.075898
# Unit test for function match
def test_match():
    # Test for command.output
	assert_raises(AttributeError) == \
		match('cat <non-existing-file>')
	assert_raises('No such file or directory') == \
		match('cat <non-existing-file>')
	assert_raises(IsADirectoryError)
	# Test for command.script_parts
	assert_raises(AttributeError) == \
		match('cat <non-existing-file>')
	assert_raises('No such file or directory') == \
		match('cat <non-existing-file>')
	assert_raises(IsADirectoryError)


# Generated at 2022-06-22 01:03:12.115298
# Unit test for function match
def test_match():
    assert not match({'script_parts': ["cat", "hello.txt"], 'output':"my name is\n"})
    assert match({'script_parts': ['cat', 'hello.txt/'], 'output': 'cat: hello.txt/: Is a directory'})


# Generated at 2022-06-22 01:03:16.092382
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('sudo cat /usr/bin') == 'sudo ls /usr/bin'
    assert get_new_command('cat /etc/apache2/sites-available') == 'ls /etc/apache2/sites-available'

# Generated at 2022-06-22 01:03:22.905474
# Unit test for function match
def test_match():
    assert match(Command('cat abc',
        '/usr/bin/cat: abc: Is a directory\n', '', 1, None))
    assert not match(Command('cat abc', 'abc', '', 1, None))
    assert not match(Command('cat', '', '', 1, None))
    assert not match(Command('cat abc',
        '/usr/bin/cat: abc: Is a directory\n', '', 1, None))


# Generated at 2022-06-22 01:03:24.606105
# Unit test for function match
def test_match():
    command = Command('cat /etc')
    assert match(command)



# Generated at 2022-06-22 01:03:29.293201
# Unit test for function get_new_command
def test_get_new_command():
    assert 'ls' == get_new_command('cat')
    assert 'ls ' == get_new_command('cat ')
    assert 'ls ' == get_new_command('cat  ')
    assert 'ls ' == get_new_command('cat   ')


# Generated at 2022-06-22 01:03:32.681711
# Unit test for function match
def test_match():
    command_1 = 'cat does/not/exist'
    assert not match(command_1)
    command_2 = 'cat src/'
    assert match(command_2)


# Generated at 2022-06-22 01:03:40.125847
# Unit test for function get_new_command
def test_get_new_command():
    from testing.shell import assert_execute

    assert_execute(get_new_command, 'cat /usr/bin') == 'ls /usr/bin'

# Generated at 2022-06-22 01:03:43.908846
# Unit test for function match
def test_match():
    assert match(Command('cat myfile.txt'))
    assert match(Command('cat myfolder'))
    assert not match(Command('cat myfile.txt | grep foo'))
    assert not match(Command('cat nonexistentfile.txt'))


# Generated at 2022-06-22 01:03:46.943609
# Unit test for function match
def test_match():
    assert match(Command('cat file', '', 'cat: file: Is a directory'))
    assert not match(
        Command('cat file', '', 'cat: file: No such file or directory'))


# Generated at 2022-06-22 01:03:49.259001
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_dir import get_new_command
    assert get_new_command('cat dir') == 'ls dir'

# Generated at 2022-06-22 01:03:52.846464
# Unit test for function match
def test_match():
    assert match(Command('cat /home/usr', 'cat: /home/usr: Is a directory'))
    assert not match(Command('cat /home/usr', ''))
    assert not match(Command('ls /home/usr', ''))


# Generated at 2022-06-22 01:03:56.136637
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat whatever') == 'ls whatever'
    assert get_new_command('cat /') == 'ls /'

# Generated at 2022-06-22 01:04:00.007560
# Unit test for function match
def test_match():
    assert match(Command('cat /home/yawen', output='cat: /home/yawen: Is a directory'))
    assert not match(Command('cat /home/yawen', output='/home/yawen'))



# Generated at 2022-06-22 01:04:05.846721
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('cat a', None, 'cat: a: Is a directory', '', ''))
    assert not match(Command('cat a', None, '', '', ''))
    assert not match(Command('cat', None, 'cat: a: Is a directory', '', ''))
    assert not match(Command('cat a', None, '', '', ''))


# Generated at 2022-06-22 01:04:12.988526
# Unit test for function match
def test_match():
    command = Command(script='cat not_existing_file.txt')
    assert match(command)
    command = Command(script='ls')
    assert not match(command)
    command = Command(script='cat', stderr='cat: not_existing_file.txt: No such file or directory')
    assert match(command)
    command = Command(script='cat', stderr='cat: not_existing_file.txt: Is a directory')
    assert match(command)


# Generated at 2022-06-22 01:04:15.910017
# Unit test for function match
def test_match():
    # Try if command matches
    assert match(Command('cat test'))
    # Try if command does not match
    assert not match(Command('ls test'))



# Generated at 2022-06-22 01:04:26.942880
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat testfile") == "ls testfile"


# Generated at 2022-06-22 01:04:28.876755
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat user/info', '')
    assert get_new_command(command) == 'ls user/info'

# Generated at 2022-06-22 01:04:32.124193
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    command = get_new_command("cat /etc/hosts")
    assert command == "ls /etc/hosts"

# Generated at 2022-06-22 01:04:33.226371
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /tmp', 'cat: /tmp: Is a directory')) == 'ls /tmp'

# Generated at 2022-06-22 01:04:37.299811
# Unit test for function match
def test_match():
    assert match(Command(script='cat main.cpp', output='cat: main.cpp: Is a directory'))
    assert match(Command(script='cat main.cpp', output='cat: main.cpp: Is not a directory')) == False


# Generated at 2022-06-22 01:04:38.736265
# Unit test for function match
def test_match():
    assert match(Command("cat a", "cat: a: Is a directory", ""))

# Generated at 2022-06-22 01:04:44.127931
# Unit test for function match
def test_match():

    # x is not a file
    assert match(Command('cat x', 'cat: x: Is a directory'))

    # this is a file
    assert not match(Command('cat hello', 'hello'))

    # cat is not in the command
    assert not match(Command('ls hello', 'hello'))

# Generated at 2022-06-22 01:04:46.359361
# Unit test for function get_new_command
def test_get_new_command():
    # Test if get_new_command returns the correct string
    assert get_new_command('cat') == 'ls'


# Generated at 2022-06-22 01:04:48.260295
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('foo') == 'foo'


enabled_by_default = True

# Generated at 2022-06-22 01:04:49.936357
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat ~/D*') == 'ls ~/D*'

# Generated at 2022-06-22 01:05:11.535688
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat /etc/make.conf'
    assert get_new_command(command) == 'ls /etc/make.conf'

# Generated at 2022-06-22 01:05:13.204795
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat test')) == \
        'ls test'

# Generated at 2022-06-22 01:05:16.265036
# Unit test for function match
def test_match():
    assert match(Command('cat file', 'cat: file: Is a directory', ''))
    assert not match(Command('cat file', '', ''))
    assert not match(Command('cat', '', ''))


# Generated at 2022-06-22 01:05:18.050665
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat', '/home/user/file')
    assert get_new_command(command) == 'ls /home/user/file'

# Generated at 2022-06-22 01:05:23.033515
# Unit test for function match
def test_match():
    output_with_error = 'cat: /etc/: Is a directory'
    assert match(Command('cat /etc/', output_with_error))
    assert not match(Command('cat foo'))
    assert not match(Command('ls /etc/'))


# Generated at 2022-06-22 01:05:25.853058
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat something/other', 'cat: something/other: Is a directory')
    assert get_new_command(command) == 'ls something/other'

# Generated at 2022-06-22 01:05:27.831704
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home/')
    assert get_new_command(command) == "ls /home/"

# Generated at 2022-06-22 01:05:32.809254
# Unit test for function match
def test_match():
    assert match(Command("cat", "cat: /home/lichen: Is a directory"))
    assert match(Command("cat /home/lichen/note.txt", "cat: /home/lichen: Is a directory"))
    assert not match(Command("ls", "asdfg"))


# Generated at 2022-06-22 01:05:40.237189
# Unit test for function match
def test_match():
    assert match(Command('cat foo', stderr='cat: foo: Is a directory'))
    assert match(Command(
        'cat ~/.vimrc foo',
        stderr='cat: foo: Is a directory'))
    assert not match(Command('cat foo', stderr="cat: foo: No such file"))
    assert not match(Command(
        'cat foo | xargs bar',
        stderr='cat: foo: Is a directory'))



# Generated at 2022-06-22 01:05:41.915912
# Unit test for function match
def test_match():
    assert match(Command("cat foo", "cat: foo: Is a directory"))
    assert not match(Command("cat foo", "foo"))
    assert not match(Command("cat", ""))

# Generated at 2022-06-22 01:06:20.652542
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat file_name') == 'ls file_name'

# Generated at 2022-06-22 01:06:22.562991
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat a/b/c', '')) == 'ls a/b/c'

# Generated at 2022-06-22 01:06:24.554337
# Unit test for function match
def test_match():
    assert(match(u'cat /tmp'))

# Generated at 2022-06-22 01:06:29.865268
# Unit test for function match
def test_match():
    assert match(Command("cat", output='cat: hello.txt: Is a directory\n'))
    assert match(Command("cat", output='cat: hello.txt: Is a directory'))
    assert not match(Command("cat", output='cat: hello.txt: No such file or directory'))
    assert not match(Command("cat hello.txt", output='cat: hello.txt: Is a directory'))

# Generated at 2022-06-22 01:06:32.710919
# Unit test for function match
def test_match():
    assert not match(Command('cd cd /'))
    assert match(Command('cat test.txt'))
    assert match(Command('cat /'))


# Generated at 2022-06-22 01:06:35.614561
# Unit test for function match
def test_match():
    assert match(Command('cat .', 'cat: .: Is a directory'))
    assert match(Command('cat .', '')) is False


# Generated at 2022-06-22 01:06:39.818218
# Unit test for function match
def test_match():
    assert match(Command("cat /home/", "cat: /home/: Is a directory\n", ""))
    assert not match(Command("cat /home/", "", ""))
    assert not match(Command("ls /home/", "cat: /home/: Is a directory\n", ""))
    assert not match(Command("ls /home/", "", ""))



# Generated at 2022-06-22 01:06:43.390098
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat')
    assert get_new_command(command) == 'ls'
    command = Command('cat abc')
    assert get_new_command(command) == 'ls abc'

# Generated at 2022-06-22 01:06:46.893026
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test/') == 'ls test/'
    assert get_new_command('cat test/ test/') == 'ls test/ test/'

# Generated at 2022-06-22 01:06:50.253698
# Unit test for function match
def test_match():
    assert match(Command('cat dir', 'cat: dir: Is a directory', ''))
    assert not match(Command('cat', '', ''))
    assert not match(Command('cat file', '', ''))


# Generated at 2022-06-22 01:08:09.641675
# Unit test for function get_new_command
def test_get_new_command():
  command = Command('cat /tmp/', '/tmp/\n')
  assert get_new_command(command) == 'ls /tmp/'

# Generated at 2022-06-22 01:08:15.581255
# Unit test for function match
def test_match():
    assert match(Command('cat dummy', 'cat: dummy: Is a directory\n'))
    assert match(Command('cat dummy foo', 'cat: dummy: Is a directory\n'))
    assert not match(Command('cat dummy', 'cat: dummy: No such file or directory\n'))
    assert not match(Command('cat dummy', 'cat: dummy: No such file or directory\n'))



# Generated at 2022-06-22 01:08:17.838898
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(' cat code', 'cat: code: Is a directory')) == ' ls code'

# Generated at 2022-06-22 01:08:19.877830
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat file') == 'ls file'
    assert get_new_command('cat folder') == 'ls folder'

# Generated at 2022-06-22 01:08:25.550563
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt',
                         output="cat: file.txt: Is a directory",
                         script_parts=['cat', 'file.txt']))
    assert not match(Command('cat file.txt',
                         output="cat: file.txt: No such file or directory",
                         script_parts=['cat', 'file.txt']))


# Generated at 2022-06-22 01:08:29.126294
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat /home/bob'
    new_command = 'ls /home/bob'
    assert get_new_command(command) == new_command

# Generated at 2022-06-22 01:08:32.595932
# Unit test for function match
def test_match():
    output = "cat: /home/kai/Projects/: Is a directory"
    command = Command(script='cat test.py',
                      stderr=output,
                      output=output)
    assert match(command)


# Generated at 2022-06-22 01:08:34.179706
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat test.txt") == "ls test.txt"

# Generated at 2022-06-22 01:08:36.414821
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat dirname'
    new_command = 'ls dirname'
    assert get_new_command(command) == new_command

# Generated at 2022-06-22 01:08:40.967696
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat', output='cat: No such file or directory')) == 'ls'
    assert get_new_command(Command(script='cat', output='cat: dir1: Is a directory')) == 'ls dir1'

# Generated at 2022-06-22 01:11:35.569708
# Unit test for function get_new_command
def test_get_new_command():
    new_command = "ls -a"
    print(new_command)
    assert new_command == get_new_command(
        Command('cat -a', 'cat: -a: Is a directory', ''))

# Generated at 2022-06-22 01:11:37.606492
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    assert get_new_command(Command('cat /home/name/Desktop', '')).script == 'ls /home/name/Desktop'