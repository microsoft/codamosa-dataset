

# Generated at 2022-06-22 01:01:43.028527
# Unit test for function match
def test_match():
    match(Command("cat /dev/null/", output="cat: /dev/null/: Is a directory"))


# Unit tests for function get_new_command

# Generated at 2022-06-22 01:01:44.850949
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat ~/.ssh/id_rsa') == 'ls ~/.ssh/id_rsa'

# Generated at 2022-06-22 01:01:48.023664
# Unit test for function match
def test_match():
    assert match(Command('cat', 'cat: example: Is a directory'))
    assert not match(Command('cat', 'cat: hello'))

# Generated at 2022-06-22 01:01:51.624924
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', 'cat: file.txt: Is a directory',
             script='cat file.txt',
             stdout='file1.txt\nfile2.txt',
             stderr='cat: file.txt: Is a directory',
             ))


# Generated at 2022-06-22 01:01:54.071434
# Unit test for function match
def test_match():
    assert match(Command('cat path/to/dir', 'cat: path/to/dir: Is a directory'))
    assert match(Command('cat file', 'cat: file: is a directory'))
    assert not match(Command('cat file', 'content'))


# Generated at 2022-06-22 01:01:56.970788
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('cat test.txt',
                                   'cat: test.txt: Is a directory',
                                   '/home/')) == 'ls test.txt'

# Generated at 2022-06-22 01:02:00.460749
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /home/chris/") == "ls /home/chris/"

# Generated at 2022-06-22 01:02:04.562898
# Unit test for function match
def test_match():
    assert match(Command('cat file.txt', 'cat: file.txt: Is a directory', ''))
    assert not match(Command('cat file1 file2',
                             'cat: file1: No such file or directory', ''))
    assert not match(Command('ls', '', ''))


# Generated at 2022-06-22 01:02:12.139277
# Unit test for function match
def test_match():
    assert match(Command('cat /etc', 'cat: /etc: Is a directory\n'))
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory\n'))
    assert match(Command('cat /etc//', 'cat: /etc//: Is a directory\n'))
    assert match(Command('find /etc/ -name x', 'cat: /etc: Is a directory\n'))


# Generated at 2022-06-22 01:02:14.519322
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_a_directory import get_new_command
    assert get_new_command(Command('cat /home/vagrant/test_directory')) == 'ls /home/vagrant/test_directory'


# Generated at 2022-06-22 01:02:20.610524
# Unit test for function match
def test_match():
    assert match(Command('cat hello', 'cat: hello: Is a directory'))
    assert not match(Command('cat hello', ''))
    assert not match(Command('cat hello', 'cat: hello: No such file or directory'))

test_match()

# Generated at 2022-06-22 01:02:27.933672
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat /etc/', output='cat: /etc/: Is a directory', stderr='cat: /etc/: Is a directory')) == 'ls /etc/'
    assert get_new_command(Command(script='cat /etc/foo', output='cat: /etc/foo: Is a directory', stderr='cat: /etc/foo: Is a directory')) == 'ls /etc/foo'



# Generated at 2022-06-22 01:02:29.975825
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat /'
    assert get_new_command(command) == 'ls /'


# Generated at 2022-06-22 01:02:31.915093
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat /path/to/dir', output='cat: /path/to/dir: Is a directory')) == 'ls /path/to/dir'

# Generated at 2022-06-22 01:02:36.604091
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat a b c', output='cat: b: Is a directory')) == 'ls a b c'
    assert get_new_command(Command(script='cat x', output='cat: x: Is a directory')) == 'ls x'

# Generated at 2022-06-22 01:02:39.091851
# Unit test for function match
def test_match():
    assert match(Command(script="cat tests.py"))
    assert not match(Command(script="ls tests.py"))


# Generated at 2022-06-22 01:02:44.490003
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('grep')) == 'grep'
    assert get_new_command(Command('cat test')) == 'ls test'
    assert get_new_command(Command('cat test test2')) == 'ls test test2'
    assert get_new_command(Command('cat test test2 test4')) == 'ls test test2 test4'

# Generated at 2022-06-22 01:02:49.221825
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /Users/Sajid/Downloads', 'cat: /Users/Sajid/Downloads: Is a directory')
    new_command = get_new_command(command)
    assert new_command == 'ls /Users/Sajid/Downloads'

# Generated at 2022-06-22 01:02:51.188099
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat /etc/')
    assert get_new_command(command) == 'ls /etc/'

# Generated at 2022-06-22 01:02:53.743146
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': "cmd with cat and some text"})
    assert get_new_command(command) == "cmd with ls and some text"

# Generated at 2022-06-22 01:02:57.800580
# Unit test for function match
def test_match():
    assert match(Command("cat ~/Downloads", "cat: /home/david/Downloads: Is a directory"))


# Generated at 2022-06-22 01:03:00.278743
# Unit test for function match
def test_match():
    assert not match(Command('cat foo bar', ''))
    assert match(Command('cat foo bar', 'cat: bar: Is a directory\n'))

# Generated at 2022-06-22 01:03:03.668216
# Unit test for function match
def test_match():
    assert match(Command('cat /etc/', 'cat: /etc/: Is a directory'))
    assert not match(Command('cat /etc/', 'cat: /etc/: No such file or directory'))

# Generated at 2022-06-22 01:03:08.220978
# Unit test for function get_new_command
def test_get_new_command():
    command = "cat --version"
    assert get_new_command(command) == command
    command = "cat /home"
    assert get_new_command(command) == "ls /home"
    command = "cat /home/stuff/morestuff"
    assert get_new_command(command) == "ls /home/stuff/morestuff"

# Generated at 2022-06-22 01:03:09.580303
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat test')) == 'ls test'

# Generated at 2022-06-22 01:03:16.871101
# Unit test for function match
def test_match():
    assert match(Command(script='cat /usr/share/profile',
                         output='cat: /usr/share/profile: Is a directory'))
    assert not match(Command(script='cat /usr/share/profile',
                             output='cat: - Bad file descriptor'))
    assert not match(Command(script='cat /usr/share/profile',
                             output=''))


# Generated at 2022-06-22 01:03:26.999746
# Unit test for function match
def test_match():
    command = Command('cat testdir', 'cat: testdir: Is a directory', '', 1, 'bash')
    assert match(command)

    command = Command('cat testdir', 'cat: testdir: Is a directory', '', 1, 'zsh')
    assert match(command)

    command = Command('cat testdir', 'cat: testdir: Is a directory', '', 1, 'fish')
    assert match(command)

    command = Command('cat testfile', 'cat: testfile: No such file', '', 1, 'bash')
    assert not match(command)

    command = Command('cat testfile', 'cat: testfile: No such file', '', 1, 'zsh')
    assert not match(command)


# Generated at 2022-06-22 01:03:30.741656
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /tmp', 'cat: /tmp: Is a directory', '', 0)
    assert type(get_new_command(command)) == str
    assert get_new_command(command) == 'ls /tmp'


# Generated at 2022-06-22 01:03:32.771915
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /usr/bin | grep somestring") == "ls /usr/bin | grep somestring"

# Generated at 2022-06-22 01:03:37.291181
# Unit test for function match
def test_match():
	c = Command('cat test', 'cat: test: Is a directory')
	assert match(c)
	c = Command('cat test.txt', 'cat: test: No such file or directory')
	assert not match(c)


# Generated at 2022-06-22 01:03:41.889199
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_directory import get_new_command
    assert get_new_command(Command('cat test', 'cat: test: Is a directory')) == 'ls test'

# Generated at 2022-06-22 01:03:43.271395
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('cat folder') == 'ls folder'

# Generated at 2022-06-22 01:03:47.554413
# Unit test for function match
def test_match():
    command = Command('cat /home/user/','/home','cat /home/user/', '','')
    assert match(command)
    command = Command('ls /home/user/','/home','ls /home/user/', '','')
    assert not match(command)


# Generated at 2022-06-22 01:03:54.990116
# Unit test for function match
def test_match():
    # Test for 'cat: FILENAME: Is a directory'
    output = 'cat: desktop: Is a directory\n'
    command = Command("cat 'desktop'", output)
    assert match(command)
    # Test for 'cat: FILENAME: No such file or directory'
    output = 'cat: bla: No such file or directory\n'
    command = Command("cat 'bla'", output)
    assert not match(command)


# Generated at 2022-06-22 01:03:57.358489
# Unit test for function match
def test_match():
    command = Command('cat Desktop', 'cat: Desktop: Is a directory', '')
    assert match(command)



# Generated at 2022-06-22 01:03:59.937633
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('cat ..', 'cat: ..: Is a directory')
    assert get_new_command(cmd) == 'ls ..'



# Generated at 2022-06-22 01:04:01.845967
# Unit test for function match
def test_match():
    assert match(Command('cat x', 'cat: x: Is a directory'))


# Generated at 2022-06-22 01:04:10.768758
# Unit test for function match
def test_match():
    assert match(Command(script='cat /home/roshan',
                         output='cat: /home/roshan: Is a directory',
                         stderr='cat: /home/roshan: Is a directory'))
    assert not match(Command(script='cat /home/roshan.txt',
                             output='roshan',
                             stderr=''))
    assert not match(Command(script='cat /home/roshan.txt /home/roshan/test.txt',
                             output='roshan',
                             stderr=''))


# Generated at 2022-06-22 01:04:17.639222
# Unit test for function match
def test_match():
    command = Command("cat lol")
    assert match(command)
    command = Command("cat .bashrc .zshrc")
    assert not match(command)
    command = Command("cat .bashrc .zshrc")
    command.script_parts[1] = "cat"
    assert not match(command)
    command.script_parts[1] = "cat"
    command.output='cat: cat: Is a directory'
    assert match(command)    
    

# Generated at 2022-06-22 01:04:19.386791
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat testfile') == 'ls testfile'

# Generated at 2022-06-22 01:04:24.850175
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals('ls /etc/', get_new_command(Command(script='cat /etc/', stderr='cat: /etc/: Is a directory')))


# Generated at 2022-06-22 01:04:28.220704
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp'))
    assert match(Command('cat /tmp | wc -l'))
    assert not match(Command('cat /tmp/foo'))


# Generated at 2022-06-22 01:04:30.547897
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat src/', 'cat: src/: Is a directory')
    assert get_new_command(command) == 'ls src/'

# Generated at 2022-06-22 01:04:32.073429
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /test/test') == 'ls /test/test'

# Generated at 2022-06-22 01:04:34.912212
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command(script='cat a',
                stdout="cat: a: Is a directory"),
                ) == 'ls a'

# Generated at 2022-06-22 01:04:37.084095
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /etc/passwd') == 'ls /etc/passwd'


# Generated at 2022-06-22 01:04:38.545412
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("cat /home", '')) == "ls /home"

# Generated at 2022-06-22 01:04:40.745597
# Unit test for function get_new_command
def test_get_new_command():
    command1 = """command1"""
    command2 = """command2"""
    command3 = """cat filename"""
    command4 = """cat -t"""

# Generated at 2022-06-22 01:04:45.426501
# Unit test for function match
def test_match():
    assert match(Command('cat /tmp/test_file', 'cat: /tmp/test_file: Is a directory'))
    assert not match(Command('cat /tmp/test_file', '/tmp/test_file'))


# Generated at 2022-06-22 01:04:52.837078
# Unit test for function match
def test_match():
    assert match(Command(script='cat a/b/c.txt', output='cat: a/b/c.txt: Is a directory'))
    assert not match(Command(script='cat a/b/c.txt', output='cat: a/b/c.txt: No such file or directory'))
    assert not match(Command(script='cat a/b/c.txt', output='cat: a/b/c.txt: Is not a directory'))
    assert not match(Command(script='cat a/b/c.txt', output='a/b/c.txt'))


# Generated at 2022-06-22 01:04:59.060852
# Unit test for function get_new_command
def test_get_new_command():
    command = 'cat /home/julian'
    output = 'cat: /home/julian: Is a directory'
    assert get_new_command(Command(script=command, output=output)) == 'ls /home/julian'


# Generated at 2022-06-22 01:05:10.461039
# Unit test for function match
def test_match():
    from thefuck.types import Command
    error_msg = 'cat: asdf/: Is a directory'
    command = Command('cat asdf/', error_msg) # Test command with valid directory
    assert(match(command) == True)
    command = Command('cat asdf/non_exist', error_msg) # Test command with non-existent directory
    assert(match(command) == False)
    command = Command('cat asdf/ not_a_directory', error_msg) # Test command with file and directory
    assert(match(command) == True)
    command = Command('cat asdf/ not_a_directory', error_msg) # Test command with 2 directories
    assert(match(command) == True)
    command = Command('cat not_a_directory asdf/', error_msg) # Test command with 2 directories reversed

# Generated at 2022-06-22 01:05:13.549667
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command('cat folder', 'cat: folder: Is a directory', ''))
    assert result == 'ls folder'

# Generated at 2022-06-22 01:05:15.794905
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('cat qwe', 'cat: qwe: Is a directory', ''))



# Generated at 2022-06-22 01:05:18.240190
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat test.txt', 'cat: test.txt: Is a directory')
    assert get_new_command(command) == 'ls test.txt'

# Generated at 2022-06-22 01:05:21.378490
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /etc',
    ('cat: /etc: Is a directory\n', '', 95))) == 'ls /etc'

# Generated at 2022-06-22 01:05:25.140661
# Unit test for function match
def test_match():
    assert match(Command('cat abc', 'abc'))
    assert match(Command('cat directory/', 'cat: directory/: Is a directory'))
    assert not match(Command('cat abc', 'no match'))


# Generated at 2022-06-22 01:05:35.653837
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('') == ''
    assert get_new_command('cat') == 'ls'
    assert get_new_command('cat nonexistent_file') == 'ls nonexistent_file'
    assert get_new_command('cat nonexistent_file nonexistent_file2') == 'ls nonexistent_file nonexistent_file2'
    assert get_new_command('cat nonexistent_file nonexistent_file2 nonexistent_file3') == 'ls nonexistent_file nonexistent_file2 nonexistent_file3'
    assert get_new_command('cat nonexistent_file nonexistent_file2 nonexistent_file3 nonexistent_file4') == 'ls nonexistent_file nonexistent_file2 nonexistent_file3 nonexistent_file4'

# Generated at 2022-06-22 01:05:39.789695
# Unit test for function match
def test_match():
    assert match(Command(script='cat /dev/null', output='cat: /dev/null: Is a directory'))
    assert not match(Command(script='cat /dev/null', output='cat: /dev/null: No such file or directory'))


# Generated at 2022-06-22 01:05:42.748745
# Unit test for function match
def test_match():
    assert match(Command(script='cat /home/foo/bar/baz', stderr='''cat: /home/foo/bar/baz: Is a directory'''))


# Generated at 2022-06-22 01:05:54.833699
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat ~/sample') == 'ls ~/sample'

# Generated at 2022-06-22 01:05:57.499057
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /home')
    command.script_parts.append('/home')
    command.output = 'cat: /home: Ist ein Verzeichnis'

    assert get_new_command(command) == 'ls /home'

# Generated at 2022-06-22 01:06:00.259555
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /bin', '', 'cat: /bin: Is a directory')
    assert get_new_command(command) == 'ls /bin'

# Generated at 2022-06-22 01:06:01.648164
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat file.txt") == "ls file.txt"

# Generated at 2022-06-22 01:06:04.639531
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat /tmp', 'cat: /tmp: Is a directory')) == 'ls /tmp'

# Generated at 2022-06-22 01:06:09.264257
# Unit test for function match
def test_match():
    assert match(Command('cat file', 'cat: file: Is a directory'))
    assert match(Command('cat file', 'cat: file: No such file or directory'))
    assert not match(Command('cat file', 'file'))
    assert not match(Command('cat file', ''))



# Generated at 2022-06-22 01:06:10.859297
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat .') == 'ls .'

# Generated at 2022-06-22 01:06:12.509086
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat ~/') == 'ls ~/'



# Generated at 2022-06-22 01:06:15.931116
# Unit test for function match
def test_match():
    assert match(Command(script='cat test'))
    assert match(Command(script='cat ./'))
    assert not match(Command(script='ls test'))
    assert not match(Command(script='cat test.txt'))
    assert not match(Command(script='cat test ', stderr='cat: test: Is a directory'))


# Generated at 2022-06-22 01:06:20.079122
# Unit test for function match
def test_match():
    assert match(Command('cat test1.txt', 'cat: test1.txt: Is a directory'))
    assert not match(Command('cat test1.txt', 'cat: test1.txt: Is not a directory'))
    assert not match(Command('ls test1.txt', 'ls: test1.txt: Is a directory'))


# Generated at 2022-06-22 01:06:41.788802
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /tmp')
    assert get_new_command(command) == 'ls /tmp'

# Generated at 2022-06-22 01:06:44.698991
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('cat /src/folder') == 'ls /src/folder')


# Generated at 2022-06-22 01:06:47.045748
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat hello') == 'ls hello'
    assert get_new_command('cat hello.py') == 'cat hello.py'

# Generated at 2022-06-22 01:06:50.003145
# Unit test for function match
def test_match():
	# The cat command is directed towards a directory instead of a file
	assert(match(Command('cat testdir', 'cat: testdir: Is a directory', '')) == True)


# Generated at 2022-06-22 01:06:52.844129
# Unit test for function match
def test_match():
    command = Command('cat app/core/views.py', stderr='cat: app/core/views.py: Is a directory')
    assert match(command)
    assert not match(Command('cat app/core/views.py'))



# Generated at 2022-06-22 01:06:59.821331
# Unit test for function get_new_command
def test_get_new_command():
    string = 'cat ./bin/tests/rules'
    command = Command(script=string,
                      script_parts=[string],
                      stderr='cat: ./bin/tests/rules: Is a directory',
                      output='cat: ./bin/tests/rules: Is a directory')

    new_command = get_new_command(command)
    assert new_command == string.replace('cat', 'ls', 1)

# Generated at 2022-06-22 01:07:01.653456
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cat /home/kat/Desktop") == "ls /home/kat/Desktop"

# Generated at 2022-06-22 01:07:11.052084
# Unit test for function match
def test_match():
    from thefuck.rules.cat_is_directory import match
    command = Mock(script='cat ../hello',
                   output='./thefuck/rules/cat_is_directory.py',
                   script_parts=['cat','..','hello'])
    assert match(command)
    command = Mock(script='cat ../hello',
                   output='cat: ../hello: Is a directory',
                   script_parts=['cat', '../hello'])
    assert match(command)
    command = Mock(script='cat ../hello',
                   output='cat: ../hello: No such file or directory',
                   script_parts=['cat', '../hello'])
    assert not match(command)

# Generated at 2022-06-22 01:07:13.921026
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('cat folder', 'cat: folder: Is a directory',
                                   'ls folder'))

# Generated at 2022-06-22 01:07:18.924123
# Unit test for function match
def test_match():
    script = 'cat Makefile'
    command = Command(script, script, 'cat: Makefile: Is a directory')
    assert match(command)

    script = 'cat thing'
    command = Command(script, script, 'cat: thing: No such file or directory')
    assert not match(command)



# Generated at 2022-06-22 01:07:46.872289
# Unit test for function match
def test_match():
    assert match(Command(script='cat /home/deploy/eko_logs/',
                         output='cat: /home/deploy/eko_logs/: Is a directory'))
    assert not match(Command(script='cat /home/deploy/eko_logs/',
                             output='cat: No such file or directory'))
    assert match(Command(script='cat ./home/deploy/eko_logs/',
                         output='cat: ./home/deploy/eko_logs/: Is a directory'))



# Generated at 2022-06-22 01:07:51.469709
# Unit test for function match
def test_match():
    assert match(Command("cat README.md", "cat: README.md: Is a directory"))
    assert not match(Command("cat README.md", "README.md"))
    assert not match(Command("ls README.md", "cat: README.md: Is a directory"))


# Generated at 2022-06-22 01:07:53.133822
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat .') == 'ls .'

# Generated at 2022-06-22 01:07:55.076738
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /etc') == 'ls /etc'


# Generated at 2022-06-22 01:08:05.017127
# Unit test for function match
def test_match():
    assert match(Command('cat ~/mock_dir/', None, 'cat: mock_dir: Is a directory\n', ''))
    assert not match(Command('cat mock_dir/', None, 'cat: mock_dir: Is a directory\n', ''))
    assert not match(Command('cat mock_dir', None, 'cat: mock_dir: Is a directory\n', ''))
    assert not match(Command('cat ~/mock_dir/', None, 'cat: mock_dir: No such file or directory\n', ''))
    assert not match(Command('cat mock_file', None, 'Hello world\n', ''))



# Generated at 2022-06-22 01:08:07.879638
# Unit test for function match
def test_match():
    """
    assert match is the correct Command to replace with ls
    """
    command = Command('cat ./test_directory', 'cat: ./test_directory: Is a directory')
    assert match(command)


# Generated at 2022-06-22 01:08:12.521941
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cat bashrc', '')) == 'ls bashrc'
    assert get_new_command(Command(
        'cat --color=auto /etc/bashrc_helloworld', '')) == 'ls --color=auto /etc/bashrc_helloworld'

# Generated at 2022-06-22 01:08:14.348286
# Unit test for function match
def test_match():
    assert match(Command('cat dir1 dir2', 'cat: dir2: Is a directory'))


# Generated at 2022-06-22 01:08:17.294885
# Unit test for function match
def test_match():
    command = Command('cat test')
    assert match(command)
    command = Command('echo "test"')
    assert not match(command)


# Generated at 2022-06-22 01:08:19.289793
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /usr/bin/ls') == 'ls /usr/bin/ls'



# Generated at 2022-06-22 01:09:03.847206
# Unit test for function match
def test_match():
    assert match('cat')
    assert not match('ls')
    assert not match('cat file')
    assert not match('cat not_exist_file')
    assert match('cat some_directory')


# Generated at 2022-06-22 01:09:07.294077
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cat /home/guillaume/test/')
    new_command = get_new_command(command)
    assert new_command == 'ls /home/guillaume/test/'

# Generated at 2022-06-22 01:09:08.954499
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat /home') == 'ls /home'

# Generated at 2022-06-22 01:09:11.842988
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat mydir', 'cat: mydir: Is a directory')
    assert get_new_command(command) == 'ls mydir'

# Generated at 2022-06-22 01:09:21.038633
# Unit test for function get_new_command
def test_get_new_command():
    # Tests for the get_new_command function
    assert get_new_command('cat') == 'ls'
    assert get_new_command('cat ') == 'ls '
    assert get_new_command('cat  ') == 'ls  '
    assert get_new_command('cat/') == 'ls/'
    assert get_new_command('cat  /') == 'ls  /'
    assert get_new_command('cat   /') == 'ls   /'
    assert get_new_command('cat	/') == 'ls	/'
    assert get_new_command('cat	 /') == 'ls	 /'
    assert get_new_command('cat	  /') == 'ls	  /'
    

# Generated at 2022-06-22 01:09:25.994490
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cat test.txt') == 'ls test.txt'
    assert get_new_command('cat test_folder/test.txt') == 'ls test_folder/test.txt'

# Generated at 2022-06-22 01:09:30.402373
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_dir_lsdir import get_new_command
    command = type("command", (object,), {"output": "cat: /home/user: Is a directory", "script": "cat /home/user"})
    assert get_new_command(command) == "ls /home/user"

# Generated at 2022-06-22 01:09:35.086690
# Unit test for function match
def test_match():
    assert not match(Command('ls', '', ''))

# Generated at 2022-06-22 01:09:36.477553
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cat /etc/')
    assert get_new_command(command) == "ls /etc/"

# Generated at 2022-06-22 01:09:38.066212
# Unit test for function match
def test_match():
    assert match(Command(script='cat /home/'))



# Generated at 2022-06-22 01:10:32.257218
# Unit test for function match
def test_match():
    command = type("Command", (object,), {
        "output": "cat: /tmp: Is a directory",
        "script_parts": ["cat", "/tmp"]
    })
    assert match(command)

# Generated at 2022-06-22 01:10:36.167153
# Unit test for function match
def test_match():
    assert match(Command("cat some_dir", "cat: some_dir: Is a directory"))
    assert match(Command("cat file", "file"))
    assert not match(Command("cat some_dir", "some_dir"))
    assert not match(Command("cat file", "cat: file: No such file or directory"))


# Generated at 2022-06-22 01:10:40.737173
# Unit test for function get_new_command
def test_get_new_command():
    output = Command('cat test_data/test', 'cat: test_data/test: Is a directory').output
    assert get_new_command(Command('cat test_data/test', output)) == 'ls test_data/test'


# Generated at 2022-06-22 01:10:42.593639
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('cat /etc/hosts') == 'ls /etc/hosts'

# Generated at 2022-06-22 01:10:44.478900
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('', '', output='The is file')) == 'ls'

# Generated at 2022-06-22 01:10:46.704878
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('cat thefuck', '')) \
        == 'ls thefuck'

# Generated at 2022-06-22 01:10:49.563797
# Unit test for function match
def test_match():
    assert match(Command('cat folder'))
    assert not match(Command('cat file'))
    assert not match(Command('less file'))
    assert not match(Command('cat folder', stderr='cat: folder: Is a directory'))


# Generated at 2022-06-22 01:10:52.705082
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='cat /home')) == 'ls /home'


# Generated at 2022-06-22 01:10:53.981301
# Unit test for function match
def test_match():
    assert match(Command('cat file', output='cat: file: Is a directory'))
    assert not match(Command('cat file', output='cat: file'))


# Generated at 2022-06-22 01:10:57.833448
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.cat_is_directory import get_new_command
    assert get_new_command(Command(script='cat cat',
                                   stderr='cat: cat: Is a directory',
                                   )) == 'ls cat'