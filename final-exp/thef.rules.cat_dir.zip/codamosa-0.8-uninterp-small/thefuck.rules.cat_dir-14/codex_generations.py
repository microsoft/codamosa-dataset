

# Generated at 2022-06-26 05:25:09.689825
# Unit test for function match
def test_match():
    str_0 = 'cat: /var/tmp/pip-req-build-F59Mvw: Is a directory'
    var_0 = match(str_0)
    assert var_0 == True

    str_1 = 'cat: /var/lib/apt/lists/ca.archive.ubuntu.com_ubuntu_dists_xenial_main_i18n_Translation-en_gpg: No such file or directory'
    var_1 = match(str_1)
    assert var_1 == False


# Generated at 2022-06-26 05:25:15.448180
# Unit test for function match
def test_match():
    assert  match('content') == False
    assert  match('cat') == False
    assert  match('cat cat') == False
    assert  match('cat toto') == False
    assert  match('cat toto') == False

# Generated at 2022-06-26 05:25:23.437755
# Unit test for function match
def test_match():
    str_1 = 'content'
    assert match(str_1) == True
    str_1 = 'cat: aaa: Is a directory'
    assert match(str_1) == True
    str_2 = 'content'
    assert match(str_2) == False
    str_3 = 'cat: aaa: No such file or directory'
    assert match(str_3) == False

# Generated at 2022-06-26 05:25:26.795113
# Unit test for function match
def test_match():
    str_0 = 'cat: '
    str_1 = os.path.isdir('cat: ')
    assert(match(str_0) == True)
    assert(match(str_1) == False)


# Generated at 2022-06-26 05:25:32.622629
# Unit test for function match
def test_match():
    data = 'cat: test: Is a directory'
    result = match(data)
    assert result == True


# Generated at 2022-06-26 05:25:35.776515
# Unit test for function match

# Generated at 2022-06-26 05:25:36.659328
# Unit test for function match
def test_match():

    assert var_0 == True


# Generated at 2022-06-26 05:25:38.816731
# Unit test for function match
def test_match():
    str_0 = 'content'
    var_0 = match(str_0)
    str_1 = 'content'
    var_1 = match(str_1)


# Generated at 2022-06-26 05:25:43.894044
# Unit test for function match
def test_match():
    str_0 = 'cat: /usr/local/bin/thefuck: Is a directory'
    var_0 = match(str_0)
    assert var_0 == True
    
test_case_0()
test_match()

# Generated at 2022-06-26 05:25:46.254703
# Unit test for function match
def test_match():
    var_1 = match(str_0)
    assert(var_1 == None)



# Generated at 2022-06-26 05:25:48.622136
# Unit test for function match
def test_match():
    assert match("cat /dev/urandom")



# Generated at 2022-06-26 05:25:56.309096
# Unit test for function match
def test_match():
    var_1 = find_command('cat', 'cat: stdout: Broken pipe')
    assert match(var_1)
    var_1 = find_command('cat', 'cat: fake')
    assert not match(var_1)


# Generated at 2022-06-26 05:25:58.694841
# Unit test for function match
def test_match():
    int_0 = -2283
    if match(int_0):
        int_0 = -2283
    else:
        int_0 = -2283


# Generated at 2022-06-26 05:26:00.632727
# Unit test for function match
def test_match():
    assert match(5) == -5
    assert match(10) == -10


# Generated at 2022-06-26 05:26:02.235573
# Unit test for function match
def test_match():
    assert match(int_0)
    assert not match(var_0)

# Generated at 2022-06-26 05:26:07.537545
# Unit test for function match
def test_match():
    var_1 = str()
    var_2 = type('[C@1052db7c', (object,), {
        'output': var_1,
        'script' : var_1,
        'script_parts' : var_1
    })
    var_3 = match(var_2)
    assert var_3 == None


# Generated at 2022-06-26 05:26:10.532023
# Unit test for function match
def test_match():
    var_2 = set()
    int_0 = -4838
    var_1 = match(int_0)


# Generated at 2022-06-26 05:26:11.882987
# Unit test for function match
def test_match():
    assert match(int_0) == True


# Generated at 2022-06-26 05:26:16.911112
# Unit test for function match
def test_match():
    match_00 = match(Command('cat test', 'cat: test: Is a directory\n'))
    with open(os.devnull, 'wb') as null:
        match_01 = match(Command('cat test', 'test\n', stderr=null))
    assert match_00 is True
    assert match_01 is False


# Generated at 2022-06-26 05:26:18.689022
# Unit test for function match
def test_match():
    assert match('cat foo')
    assert match('cat foo bar')
    assert not match('ls foo')
    assert not match('ls')



# Generated at 2022-06-26 05:26:25.684059
# Unit test for function match
def test_match():
    assert False == match("cat /dev/null")
    
    assert False == match("cat /dev/null /home/file.txt")
    
    assert False == match("cat /home/file.txt")


# Generated at 2022-06-26 05:26:27.173167
# Unit test for function match
def test_match():
    assert match('cat 2.c')
    assert not match('ls')


# Generated at 2022-06-26 05:26:29.501011
# Unit test for function match
def test_match():
    assert (match({'script_parts': ['/usr/bin/cat', './', 
        './hello_world.c'], 'output': 'cat: ./: Is a directory\n'}))


# Generated at 2022-06-26 05:26:33.550708
# Unit test for function match
def test_match():
    assert match(Command('', 'cat: test: Is a directory'))
    assert not match(Command('', 'cat: test: Is a directory', ''))
    assert not match(Command('', 'cat test:Is a directory'))


# Generated at 2022-06-26 05:26:34.608863
# Unit test for function match
def test_match():
    int_0 = -2283
    match_0 = match(int_0)

# Generated at 2022-06-26 05:26:36.776617
# Unit test for function match
def test_match():
    assert match(Command('cat main.py', '', '', '', ''))
    assert not match(Command('python main.py', '', '', '', ''))


# Generated at 2022-06-26 05:26:39.664767
# Unit test for function match
def test_match():
    assert match(Command('cat dir', 'cat: dir: Is a directory', ''))
    assert not match(Command('catdir', '', ''))


# Generated at 2022-06-26 05:26:48.267101
# Unit test for function match
def test_match():
    def test_case(command, expected):
        result = match(command)
        assert result == expected
    int_0 = -2183
    int_1 = -2363
    int_2 = int("-3543", 32)
    int_3 = -2387
    int_4 = int("-7269", 16)
    int_5 = -4469
    int_6 = int("-2933", 16)
    int_7 = int("-4113", 32)
    int_8 = int("-5501", 23)
    int_9 = int("-2877", 16)
    var_0 = Command("cat -r", "cat: foo: Is a directory", "foo")
    var_1 = Command("cat -r", "cat: bar: Is a directory", "bar")
    var_2 = Command

# Generated at 2022-06-26 05:26:52.517152
# Unit test for function match
def test_match():
    int_0 = -2328
    var_0 = match(int_0)
    assert var_0 == (
        int_0.output.startswith('cat: ') and
        os.path.isdir(int_0.script_parts[1])
    ), "Incorrect return value."




# Generated at 2022-06-26 05:27:02.451356
# Unit test for function match
def test_match():
    int_1 = -2756
    var_1 = match(int_1)
    int_2 = -2756
    var_2 = match(int_2)
    int_3 = -2756
    var_3 = match(int_3)
    int_4 = -2756
    var_4 = match(int_4)
    int_5 = -2756
    var_5 = match(int_5)
    int_6 = -2756
    var_6 = match(int_6)
    int_7 = -2756
    var_7 = match(int_7)
    int_8 = -2756
    var_8 = match(int_8)
    int_9 = -2756
    var_9 = match(int_9)
    int_10 = -2756
   

# Generated at 2022-06-26 05:27:08.551174
# Unit test for function match
def test_match():
    assert match(int_0)


# Generated at 2022-06-26 05:27:10.402107
# Unit test for function match
def test_match():
    assert(match('cat data') == True)
    assert(match('ls data') == False)


# Generated at 2022-06-26 05:27:11.266495
# Unit test for function match
def test_match():
    assert(match(script)) == False 


# Generated at 2022-06-26 05:27:14.637821
# Unit test for function match
def test_match():
    var_0 = -8454
    var_1 = match(var_0)


# Generated at 2022-06-26 05:27:17.200007
# Unit test for function match
def test_match():
	assert match(int_0) == True


# Generated at 2022-06-26 05:27:29.044634
# Unit test for function match
def test_match():
    assert match('cat')
    assert match('cat -n')
    assert match('cat /etc/hosts')
    assert match('cat /etc/hosts.conf')
    assert match('cat /etc/hosts.conf | grep localhost')
    assert not match('ls /etc/hosts.conf | grep localhost')
    assert not match('ls /etc/hosts.conf')
    assert not match('ls')
    assert not match('ls -l')
    assert not match('ls /etc/hosts | grep localhost')


# Generated at 2022-06-26 05:27:29.502469
# Unit test for function match
def test_match():
	assert match(match) == True


# Generated at 2022-06-26 05:27:34.575272
# Unit test for function match
def test_match():
    # test_match_0
    var_0 = 7888
    var_1 = {'script': 'cat .gitignore', 'stderr': 'cat: .gitignore: Is a directory', 'stderr_matches': '.*', 'script_parts': ['cat', '.gitignore'], 'output': 'cat: .gitignore: Is a directory'}
    var_2 = match(var_1)
    print(var_2)
    var_3 = True
    if (var_2 != var_3):
        print('FAILED: test_match_0')
        print('Expected: ')
        print(var_3)
        print('Actual: ')
        print(var_2)


# Generated at 2022-06-26 05:27:45.445147
# Unit test for function match
def test_match():
    assert match(Command(script='cat /etc', output='cat: /etc: Is a directory'))
    assert match(Command(script='cat /usr', output='cat: /usr: Is a directory'))
    assert match(Command(script='cat /usr', output='cat: /usr: Is a directory'))
    assert match(Command(script='cat /home', output='cat: /home: Is a directory'))
    assert match(Command(script='cat /var', output='cat: /var: Is a directory'))
    assert match(Command(script='cat /var/run', output='cat: /var/run: Is a directory'))
    assert match(Command(script='cat /var/run/apt', output='cat: /var/run/apt: Is a directory'))

# Generated at 2022-06-26 05:27:48.727074
# Unit test for function match
def test_match():
    assert match(command) == False


# Generated at 2022-06-26 05:28:07.938988
# Unit test for function match
def test_match():
    def test_func(words, output, at_least, stdout=None, stderr=None):
        assert match(Command(
            script=words,
            output=output,
            stdout=stdout,
            stderr=stderr,
            at_least=(at_least)))

    test_func(['cat', 'test.txt'], 'cat: test.txt: No such file', 0)
    test_func(['cat', 'test.txt'], 'test: Oh noes!', 1)
    test_func(['cat', 'test.txt'], 'cat: test.txt: Is a directory', 2,
              stdout='test')
    test_func(['cat', 'test.txt'], 'cat: test.txt: Is a directory', 2,
              stderr='test')

# Generated at 2022-06-26 05:28:13.701502
# Unit test for function match
def test_match():
    with mock.patch('os.path.isdir') as mock_isdir:
        mock_isdir.return_value = True
        assert (match(Command(script='cat dir',
            stderr='cat: dir: Is a directory',
            )))

    with mock.patch('os.path.isdir') as mock_isdir:
        mock_isdir.return_value = False
        assert not (match(Command(script='cat dir',
            stderr='cat: dir: Is a directory',
            )))

    assert not (match(Command(script='cat file',
        stderr='cat: file: Is a directory',
        )))

    assert not (match(Command(script='cat file',
        stderr='cat: file: Is a directory\ncat: file: Is a directory',
        )))

# Generated at 2022-06-26 05:28:17.497436
# Unit test for function match
def test_match():
    init_0 = Command('cat test.txt', 'cat: test.txt: Is a directory', '')
    assert match(init_0)
    init_1 = Command('cat test.txt', 'test.txt', '')
    assert not match(init_1)

# Generated at 2022-06-26 05:28:19.630235
# Unit test for function match
def test_match():
    assert match(Command('cat <file>', 'cat: <file>: Is a directory'))
    assert not match(Command('cat <file>', 'cat: <file>: Is not a directory'))



# Generated at 2022-06-26 05:28:21.972149
# Unit test for function match
def test_match():
    int_1 = -2255
    var_1 = match(int_1)
    assert var_1 == True


# Generated at 2022-06-26 05:28:23.460489
# Unit test for function match
def test_match():
    assert match(int_0)


# Generated at 2022-06-26 05:28:27.046008
# Unit test for function match
def test_match():
    var_0 = match({'script_parts': ['cat', '\/var\/log'], 'output': 'cat: \/var\/log: Is a directory', 'script': 'cat \/var\/log'})
    assert var_0 == True

# Generated at 2022-06-26 05:28:33.249451
# Unit test for function match
def test_match():
    var_4 = '/opt/local/var/macports/software/'
    var_3 = str
    var_3 = (
        'cat: /opt/local/var/macports/software/numpy-1.9.1: Is a directory'
    )
    var_2 = [
        'cat',
        '/opt/local/var/macports/software/numpy-1.9.1'
    ]
    var_1 = var_3, var_2
    var_5 = match(var_1)
    assert var_5 == True


# Generated at 2022-06-26 05:28:34.864610
# Unit test for function match
def test_match():
    assert match(
        Command('cat foo', output='cat: foo: Is a directory')
    )


# Generated at 2022-06-26 05:28:38.640732
# Unit test for function match
def test_match():
    assert match({'output': 'cat: 01.txt: Is a directory'})
    assert match({'output': 'cat: foo: Is a directory'})
    assert not match({'output': 'cat: foo: No such file or directory'})
    assert not match({'output': 'cat: foo: No such file or directory'})


# Generated at 2022-06-26 05:29:07.192166
# Unit test for function match
def test_match():
    assert match(Command(script='cat /etc/se', output='cat: /etc/se: Is a directory\n'))
    assert match(Command(script='cat /etc/sea', output='cat: /etc/sea: Is a directory\n'))
    assert match(Command(script='cat /etc/seah', output='cat: /etc/seah: Is a directory\n'))
    assert match(Command(script='cat /etc/seah:', output='cat: /etc/seah:: Is a directory\n'))
    assert match(Command(script='cat /etc/seahor', output='cat: /etc/seahor: Is a directory\n'))
    assert match(Command(script='cat /etc/seahor', output='cat: /etc/seahor: Is a directory\n'))


# Generated at 2022-06-26 05:29:07.919187
# Unit test for function match
def test_match():
    assert match() == True


# Generated at 2022-06-26 05:29:09.626804
# Unit test for function match
def test_match():
    assert match(-3) is None
    assert match(get_new_command(1)) == get_new_command(1)


# Generated at 2022-06-26 05:29:17.912475
# Unit test for function match
def test_match():
    var_0 = {
        'script_parts': ['/usr/bin/cat'],
        'stderr': None,
        'script': '/usr/bin/cat',
        'stdout': 'cat: /usr/share/dict/words: Is a directory',
        'env': {},
        'output': 'cat: /usr/share/dict/words: Is a directory',
        'script_parts_quoted': ["'/usr/bin/cat'"],
        'stderr_raw': None}
    assert match(var_0)

# Generated at 2022-06-26 05:29:20.088728
# Unit test for function match
def test_match():
    assert match(Command('cat /home', ''))


# Generated at 2022-06-26 05:29:22.753521
# Unit test for function match
def test_match():
    # AssertionError: assert <function match at 0x7f87f0f7b488> == None
    pass


# Generated at 2022-06-26 05:29:32.466507
# Unit test for function match
def test_match():
    int_0 = chr(68)
    int_1 = -2685
    int_2 = -2791
    int_3 = ord(int_2)
    int_4 = ord(int_3)
    int_5 = -2103
    int_6 = ord(int_5)
    int_7 = ord(int_6)
    int_8 = int_5 + int_7
    int_9 = int_8 + int_3
    int_10 = int_1 + int_9

    with patch('thefuck.rules.cat_file.isdir') as isdir_mock,\
         patch('thefuck.rules.cat_file.Command') as command_mock:
        command_mock.output = int_10

# Generated at 2022-06-26 05:29:36.037819
# Unit test for function match
def test_match():
    assert match(Command('cat /cafebabe'))
    assert not match(Command('/usr/bin/cat /cafebabe'))
    assert not match(Command('ls /cafebabe'))



# Generated at 2022-06-26 05:29:37.153730
# Unit test for function match
def test_match():
    assert match(command=None) == False


# Generated at 2022-06-26 05:29:42.343756
# Unit test for function match
def test_match():
    assert match(int_0) == 'var_0'


# Generated at 2022-06-26 05:30:26.598320
# Unit test for function match
def test_match():
    assert match(Command(script='ls -l'))
    assert not match(Command(script='l'))
    assert not match(Command(script='cat'))
    assert match(Command(script='cat /tmp/anything'))


# Generated at 2022-06-26 05:30:28.311099
# Unit test for function match
def test_match():
    int_0 = -2283
    if match(int_0):
        pass


# Generated at 2022-06-26 05:30:37.277705
# Unit test for function match
def test_match():
    assert match('cat file.txt') == True
    assert match('cat everything.txt') == False
    assert match('cat file.jpg') == False
    assert match('cat stuff.py') == False
    assert match('cat file0.py') == False
    assert match('cat file.txt') == True
    assert match("cat ../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../etc/passwd") == False
    assert match("cat ../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../etc/passwd") == False
    assert match("cat /dev/urandom") == False
    assert match("cat /dev/urandom") == False

# Generated at 2022-06-26 05:30:41.384475
# Unit test for function match
def test_match():
    assert match([]) == False
    assert match([ 'cat: /tmp/: Is a directory',
  '',
  'cat: write error: Broken pipe']) == True
    assert match([ 'boo: command not found',
  '',
  'cat: write error: Broken pipe']) == False


# Generated at 2022-06-26 05:30:43.437982
# Unit test for function match
def test_match():
    var_2 = -2
    var_3 = match(var_2)
    assert 'get_new_command' in globals()


# Generated at 2022-06-26 05:30:51.820113
# Unit test for function match

# Generated at 2022-06-26 05:30:53.933485
# Unit test for function match
def test_match():
    int_0 = -2263
    var_0 = match(int_0)
    assert var_0 is False

# Generated at 2022-06-26 05:30:57.599830
# Unit test for function match
def test_match():
    print("Testing match() function.")
    assert(match("cat file") == True)
    assert(match("cat /root/nonexistent") == True)
    assert(match("cat a_text_file") == False)
    assert(match("ls /home") == False)
    print("Success!")


# Generated at 2022-06-26 05:30:59.094237
# Unit test for function match
def test_match():
    int_0 = -1303
    assert match(int_0) == True


# Generated at 2022-06-26 05:30:59.891614
# Unit test for function match
def test_match():
    assert match(lambda : 1) == True

# Generated at 2022-06-26 05:32:30.143175
# Unit test for function match
def test_match():
    int_0 = -9817
    assert match(int_0) is False


# Generated at 2022-06-26 05:32:32.345511
# Unit test for function match
def test_match():
    int_0 = 1
    var_0 = match(int_0)


# Generated at 2022-06-26 05:32:36.620961
# Unit test for function match
def test_match():
    assert match(Command('cat .'))
    assert not match(Command('cat'))
    assert not match(Command('cat foo'))
    assert not match(Command('ls .'))
    assert not match(Command('  cat .'))
    assert not match(Command('cat  .'))
    assert not match(Command('  cat  .'))
    assert not match(Command('\tcat\t.'))



# Generated at 2022-06-26 05:32:40.024754
# Unit test for function match
def test_match():
    with patch('os.path.isdir') as mock_isdir:
        mock_isdir.return_value = True
        assert match(if_config) == True


# Generated at 2022-06-26 05:32:40.844923
# Unit test for function match
def test_match():
	assert match(int_0)


# Generated at 2022-06-26 05:32:47.473042
# Unit test for function match
def test_match():
	assert(match(Command(script='cat /tmp/',output='cat: /tmp/: Is a directory'))==True)
	assert(match(Command(script='cat /tmp/',output='cat: /tmp/: Is a directory'))==True)
	assert(match(Command(script='cat /tmp/',output='cat: /tmp/: Is a directory'))==True)
	assert(match(Command(script='cat /tmp/',output='cat: /tmp/: Is a directory'))==True)

# Generated at 2022-06-26 05:32:54.080147
# Unit test for function match
def test_match():
    var_1 = {
        'script': 'cat dir',
        'script_parts': ['cat', 'dir'],
        'output': 'cat: dir: Is a directory\n'
    }
    assert match(var_1) == True

    int_1 = -2885
    var_2 = get_new_command(int_1)


# Generated at 2022-06-26 05:32:57.416291
# Unit test for function match
def test_match():
    int_0 = -5
    var_0 = match(int_0)

# Generated at 2022-06-26 05:32:58.737894
# Unit test for function match
def test_match():
    var_0 = match(1)


# Generated at 2022-06-26 05:33:00.066512
# Unit test for function match
def test_match():
    assert match(command) == bool_0
