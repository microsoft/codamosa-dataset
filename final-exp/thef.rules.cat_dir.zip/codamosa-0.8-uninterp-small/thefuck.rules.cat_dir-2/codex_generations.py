

# Generated at 2022-06-26 05:25:13.929467
# Unit test for function match
def test_match():
    str_0 = 'cat test_files/cat: Is a directory'
    var_0 = match(str_0)
    assert var_0 == True

    str_1 = 'cat: test_files/cat: Is a directory'
    var_1 = match(str_1)
    assert var_1 == True

    str_2 = 'cat: test_files/cat: Is a directory'
    var_2 = match(str_2)
    assert var_2 == True

    str_3 = ''
    var_3 = match(str_3)
    assert var_3 == False

    str_4 = '~'
    var_4 = match(str_4)
    assert var_4 == False



# Generated at 2022-06-26 05:25:19.913356
# Unit test for function match
def test_match():
    string = '|aG8|\t`0{;\x0b'
    result = get_new_command(string)
    assert result == 'ls|aG8|\t`0{;\x0b'
    string = '|aG8|\t`0{;\x0b'
    result = get_new_command(string)
    assert result == 'ls|aG8|\t`0{;\x0b'
    string = '|aG8|\t`0{;\x0b'
    result = get_new_command(string)
    assert result == 'ls|aG8|\t`0{;\x0b'
    string = '|aG8|\t`0{;\x0b'

# Generated at 2022-06-26 05:25:25.174282
# Unit test for function match
def test_match():
    # Command without file.
    assert match('cat') is None

    # Command with a file.
    assert match('cat foobar') is False

    # Command with an invalid file.
    assert match('cat .asdf') is False

    # Command with a directory.
    assert match('cat /') is True

    # Command with a directory.
    assert match('cat /') is True


# Generated at 2022-06-26 05:25:27.695119
# Unit test for function match
def test_match():
    str_0 = 'cat: DIR: Is a directory'
    var_0 = ('DIR',)
    var_1 = match(str_0)
    assert var_1 == var_0


# Generated at 2022-06-26 05:25:32.665643
# Unit test for function match
def test_match():
    command_0 = 'cat /tmp/test'
    status_0 = match(command_0)
    assert status_0 == True


# Generated at 2022-06-26 05:25:38.502013
# Unit test for function match
def test_match():
    assert not match('')
    assert match('cat: Usage: cat [OPTION]... [FILE]...')
    assert not match('cat: -: Is a directory')
    assert not match('cat: -: No such file or directory')
    assert not match('cat: foo: Is a directory')
    assert not match('cat: foo: No such file or directory')
    assert not match('Usage: cat [OPTION]... [FILE]...')


# Generated at 2022-06-26 05:25:42.987944
# Unit test for function match
def test_match():
    g = match('cat')
    assert(not g)
    # Now we are just checking for the output of get_new_command
    g = get_new_command('cat')
    assert(g == 'ls')

# Generated at 2022-06-26 05:25:46.727517
# Unit test for function match
def test_match():
    if __debug__:
        command = 'cat ~/tests/examples/test.py'
        var_1 = match(command)
        assert var_1 == False



# Generated at 2022-06-26 05:25:48.876151
# Unit test for function match
def test_match():
    assert match(u'cat: /etc/inputrc: Is a directory')
    assert not match(u'ls: /etc/inputrc: Is a directory')


# Generated at 2022-06-26 05:25:58.188398
# Unit test for function match
def test_match():
    assert match('cat: /usr/local/lib/python3.5/dist-packages/tensorflow/examples/tutorials: Is a directory')
    assert not match('cat: /usr/local/lib/python3.5/dist-packages/tensorflow/examples/tutorials: No such file or directory')
    assert not match('cat test.txt')
    return


# Generated at 2022-06-26 05:26:11.200769
# Unit test for function match
def test_match():
	str_1 = 'No such file or directory'
	str_2 = 'No such file or directory'
	str_3 = 'No such file or directory'
	str_4 = 'No such file or directory'
	str_5 = 'No such file or directory'
	str_6 = 'No such file or directory'
	str_7 = 'No such file or directory'
	str_8 = 'No such file or directory'
	str_9 = 'No such file or directory'
	str_10 = 'No such file or directory'
	var_2 = '123.txt'
	var_3 = '123.txt'
	var_4 = '123.txt'
	var_5 = '123.txt'
	var_6 = '123.txt'
	var_7 = '123.txt'
	var_

# Generated at 2022-06-26 05:26:13.085665
# Unit test for function match
def test_match():
    assert match(command='') == ''


# Generated at 2022-06-26 05:26:21.302989
# Unit test for function match
def test_match():
    str_0 = '5|'
    var_0 = match(str_0)
    assert var_0 == None
    str_0 = 'P|\x0c'
    var_0 = match(str_0)
    assert var_0 == None
    str_0 = '\r5r'
    var_0 = match(str_0)
    assert var_0 == None
    str_0 = '\x0f#\tt'
    var_0 = match(str_0)
    assert var_0 == None
    str_0 = '\x0f#X'
    var_0 = match(str_0)
    assert var_0 == None
    str_0 = '\x0bX\'\x0c'
    var_0 = match(str_0)
    assert var_

# Generated at 2022-06-26 05:26:22.384206
# Unit test for function match
def test_match():
    assert match('cat desktop')



# Generated at 2022-06-26 05:26:25.887853
# Unit test for function match
def test_match():
    assert match(
        Command(
            script = 'cat: /bin/ls: Is a directory',
            script_parts = 'cat /usr/local'.split(),
            stderr = 'cat: /bin/ls: Is a directory',
            )
        ) is True


# Generated at 2022-06-26 05:26:27.257972
# Unit test for function match
def test_match():
	global str_0
	assert test_case_0


# Generated at 2022-06-26 05:26:29.289760
# Unit test for function match
def test_match():
    assert match(str_0) == var_0



# Generated at 2022-06-26 05:26:37.340659
# Unit test for function match
def test_match():
    var_0 = 'cat: a: Is a directory'
    var_0 = match(var_0)

    var_1 = 'cat: b: Is a directory'
    var_1 = match(var_1)

    var_2 = 'cat: c: Is a directory'
    var_2 = match(var_2)

    var_3 = 'cat: .: Is a directory'
    var_3 = match(var_3)

    var_4 = 'cat: ..: Is a directory'
    var_4 = match(var_4)

    var_5 = 'cat: ~: Is a directory'
    var_5 = match(var_5)

    var_6 = ':~: Is a directory'
    var_6 = match(var_6)


# Generated at 2022-06-26 05:26:38.209135
# Unit test for function match
def test_match():
    assert match('') == None


# Generated at 2022-06-26 05:26:39.704659
# Unit test for function match
def test_match():
    assert match(str_0) == var_0

# Generated at 2022-06-26 05:26:49.337603
# Unit test for function match
def test_match():
    assert match(b'cat: C:\\Documents and Settings\\: Is a directory\r\n')
    assert match(b'cat: C:\\Documents and Settings\\: Is a directory\r\n')
    assert match(b'cat: C:\\Documents and Settings\\: Is a directory\r\n')
    assert not match(b'cat: C:\\Documents and Settings\\: Is a directory\r\n')
    assert not match(b'cat: C:\\Documents and Settings\\: Is a directory\r\n')
    assert not match(b'cat: C:\\Documents and Settings\\: Is a directory\r\n')
    assert not match(b'cat: C:\\Documents and Settings\\: Is a directory\r\n')

# Generated at 2022-06-26 05:26:56.281802
# Unit test for function match
def test_match():
    bytes_0 = b'\xc2\xc4\x82\xae\x1d\x14r\xa7\x02\xd6G\x1d\xe6\x08\x0c/\xec\x90\x02Ya\x8a\xe3\xda\x01\x8b\xe6'
    var_0 = match(bytes_0)


# Generated at 2022-06-26 05:26:57.658744
# Unit test for function match
def test_match():
    assert match(command)


# Generated at 2022-06-26 05:27:00.507047
# Unit test for function match
def test_match():
    var_0 = os.path.isdir.return_value = '5'
    var_1 = CatRule.match('cat: ')
    assert var_1 == var_0


# Generated at 2022-06-26 05:27:02.760787
# Unit test for function match
def test_match():
    assert match('cat /etc')
    assert not match('ls /etc')
    assert not m

# Generated at 2022-06-26 05:27:12.998141
# Unit test for function match
def test_match():
    bytes_0 = b'\xb8\xde\x04\x87u\x97'
    var_0 = match(bytes_0)
    assert type(var_0) == bool
    bytes_0 = b'\xb8\xde\x04\x87u\x97'
    with mock.patch('thefuck.rules.cat_dir.os.path.isdir', return_value=False):
        var_0 = match(bytes_0)
        assert var_0 == False
    bytes_0 = b'\xb8\xde\x04\x87u\x97'
    with mock.patch('thefuck.rules.cat_dir.os.path.isdir', return_value=True):
        var_0 = match(bytes_0)
        assert var_0 == False

# Generated at 2022-06-26 05:27:14.431571
# Unit test for function match
def test_match():
    assert match(bytes_0) == True


# Generated at 2022-06-26 05:27:19.143330
# Unit test for function match
def test_match():
    bytes_0 = b'\xb8\xde\x04\x87u\x97'
    assert match(bytes_0) == True


# Generated at 2022-06-26 05:27:30.426678
# Unit test for function match
def test_match():
    bytes_0 = b'\x87\x98\x99\x9a\x9b\x9c\x9d\x9e\x9f\xa0\xa1\xa2\xa3\xa4\xa5\xa6\xa7\xa8\xa9\xaa\xab\xac\xad\xae\xaf\xb0\xb1\xb2\xb3\xb4\xb5\xb6\xb7\xb8\xb9\xba\xbb\xbc\xbd\xbe\xbf'
    var_0 = match(bytes_0)
    assert var_0 == False


# Generated at 2022-06-26 05:27:31.325788
# Unit test for function match
def test_match():
    assert False


# Generated at 2022-06-26 05:27:42.726694
# Unit test for function match
def test_match():
    var_0 = os.path.isdir('/usr')
    assert var_0
    var_1 = os.path.isdir('/usr/bin')
    assert var_1
    var_2 = get_new_command('cat /usr/bin')
    assert var_2 == 'ls /usr/bin'
    var_3 = os.path.isdir('/usr/bin/cat')
    assert not var_3
    var_4 = get_new_command('cat /usr/bin/cat')
    assert var_4 == 'cat /usr/bin/cat'

# Generated at 2022-06-26 05:27:44.498234
# Unit test for function match
def test_match():
    command = 'cat dir'
    assert match(command)


# Generated at 2022-06-26 05:27:49.663609
# Unit test for function match
def test_match():
    assert match(command='cat /home/zk/Documents') == True
    
    

# Generated at 2022-06-26 05:27:53.417465
# Unit test for function match
def test_match():
    arg_list_0 = []
    arg_list_0.append("cat: test.txt: Is a directory")
    arg_list_0.append("test.txt")
    var_0 = match(arg_list_0)
    assert var_0 == True


# Generated at 2022-06-26 05:27:58.322994
# Unit test for function match
def test_match():
    var_2 = False
    bytes_0 = b'\xb8\xde\x04\x87u\x97'
    if (var_2):
        pass
    else:
        var_1 = match(bytes_0)
        if (var_1):
            var_2 = True


# Generated at 2022-06-26 05:28:02.491108
# Unit test for function match
def test_match():
    assert match(bytes_0) == True
    assert match(bytes_1) == False
    assert match(bytes_2) == False
    assert match(bytes_3) == False
    assert match(bytes_4) == False


# Generated at 2022-06-26 05:28:05.191957
# Unit test for function match
def test_match():
    assert match('cat some_directory', None)
    assert not match('cat some_file', None), 'Should only match directories'
    assert not match('ls some_file', None)


# Generated at 2022-06-26 05:28:06.118849
# Unit test for function match
def test_match():
    assert(test_case_0)

# Generated at 2022-06-26 05:28:07.940055
# Unit test for function match
def test_match():
    assert match(b'cat: /foo: Is a directory\n')
    assert not match(b'cat: /foo: No such file or directory\n')

# Generated at 2022-06-26 05:28:09.846640
# Unit test for function match
def test_match():
    assert match(command) == True


# Generated at 2022-06-26 05:28:19.787634
# Unit test for function match
def test_match():
    try:
        method = match.__func__
        bytes_0 = b'\xb8\xde\x04\x87u\x97'
        var_0 = get_new_command(bytes_0)

        #fail
        assert (method(var_0) is None), "Should return None"
    except Exception as e:
        print('Exception: ' + str(e))


# Generated at 2022-06-26 05:28:21.344383
# Unit test for function match
def test_match():
    assert match(bytes_0) == True


# Generated at 2022-06-26 05:28:23.600324
# Unit test for function match
def test_match():
    out = cat("cat: abc: Is a directory")
    assert match(out)


# Generated at 2022-06-26 05:28:26.794096
# Unit test for function match
def test_match():
    var_0 = TestCase()
    args = []
    var_1 = ['foo']
    var_2 = var_0.run_test(match, args, var_1)


# Generated at 2022-06-26 05:28:34.608317
# Unit test for function match
def test_match():
    assert match('cat foo')
    assert match('cat foo bar')
    assert match('cat --help')
    assert match('cat -h')
    assert match('cat -V')
    assert match('cat --version')
    assert match('cat -v')
    assert match('cat foo bar baz')
    assert match('cat foo bar baz | cat')
    assert match('cat -v foo bar baz')
    assert not match('git cat foo')
    assert not match('/tmp/cat foo')
    assert not match('cmdcat foo')
    assert not match('cat')
    assert not match('cat foo bar baz | tac')
    assert not match('cat foo bar baz | tac | cat')
    assert not match('cat -v /tmp/foo')



# Generated at 2022-06-26 05:28:37.036200
# Unit test for function match
def test_match():
    assert(match(b'cat: test: Is a directory\n') == True)
    assert(match(b'cat: test: Not a directrory\n') == False)
    

# Generated at 2022-06-26 05:28:38.864348
# Unit test for function match
def test_match():
    assert match(b'cat test/') is not None
    assert match(b'cat /etc/') is None



# Generated at 2022-06-26 05:28:39.683593
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-26 05:28:47.627006
# Unit test for function match
def test_match():
    assert match(b'cat: \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00') == True


# Generated at 2022-06-26 05:28:48.681459
# Unit test for function match
def test_match():
    assert match(command)


# Generated at 2022-06-26 05:29:01.902257
# Unit test for function match

# Generated at 2022-06-26 05:29:06.605059
# Unit test for function match
def test_match():
    test_script = """cat: one: Is a directory
cat: two: Is a directory
cat: three: Is a directory
cat: four: Is a directory
cat: five: Is a directory"""

    test_command = Command(script = test_script, stdout=test_script, stderr=test_script)

    assert match(test_command)


# Generated at 2022-06-26 05:29:08.782877
# Unit test for function match
def test_match():
    bytes_0 = '\x97^\x9e\x8cA\x1a\x90'
    assert match(bytes_0) == '\x80'


# Generated at 2022-06-26 05:29:12.351285
# Unit test for function match
def test_match():
    assert not match('echo lol')
    assert not match('cat')
    assert not match('cat file.txt')
    assert not match('cat file.txt > file2.txt')
    assert match('cat directory')



# Generated at 2022-06-26 05:29:16.792121
# Unit test for function match
def test_match():
    assert match('cat: blah: Is a directory')
    assert not match('cat: blah: No such file or directory')


# Generated at 2022-06-26 05:29:28.023008
# Unit test for function match

# Generated at 2022-06-26 05:29:29.650934
# Unit test for function match
def test_match():
    assert match('')
    assert match(b'')


# Generated at 2022-06-26 05:29:31.133273
# Unit test for function match
def test_match():
    command = Command('cat /does/not/exist')
    assert not match(command)
    command = Command('cat /tmp/')
    assert match(command)
    command = Command('cat /tmp/')
    assert match(command)


# Generated at 2022-06-26 05:29:32.947598
# Unit test for function match
def test_match():
    assert match('cat ./test/test_utils.py')
    assert not match('cat')


# Generated at 2022-06-26 05:29:34.622645
# Unit test for function match
def test_match():
    assert match('cat') == False



# Generated at 2022-06-26 05:30:12.939952
# Unit test for function match

# Generated at 2022-06-26 05:30:17.848489
# Unit test for function match
def test_match():
    bytes_0 = b'\xb8\xde\x04\x87u\x97'
    bytes_1 = b'[ERROR]\x9e'
    bytes_2 = b'\x88\x83\xe0\x8a\xc1\xc4\xe9\xb4\x8e\x1d'
    assert not match(bytes_0 + bytes_1 + bytes_2)


# Generated at 2022-06-26 05:30:23.857503
# Unit test for function match
def test_match():
    bytes_0 = b'\xb8\xde\x04\x87u\x97'
    var_0 = match(bytes_0)
    assert var_0 == True


# Generated at 2022-06-26 05:30:27.099778
# Unit test for function match
def test_match():
    var_0 = b'cat: test: Is a directory'
    var_1 = match(var_0)
    assert var_1 == True


# Generated at 2022-06-26 05:30:32.022385
# Unit test for function match
def test_match():
    inp_0 = b'cat: sample: Is a directory\n'
    inp_1 = b'cat: sample_2: Is a directory\n'
    var_0 = Match(inp_0, inp_1, inp_2)
    print(var_0)


# Generated at 2022-06-26 05:30:38.577075
# Unit test for function match

# Generated at 2022-06-26 05:30:40.094941
# Unit test for function match
def test_match():
    assert match(bytes_0) == True


# Generated at 2022-06-26 05:30:41.090406
# Unit test for function match
def test_match():
    assert match(0) == 0


# Generated at 2022-06-26 05:30:41.947994
# Unit test for function match
def test_match():
	assert match(command) == True


# Generated at 2022-06-26 05:30:48.437386
# Unit test for function match
def test_match():
    assert not match(Command('cat'))
    assert not match(Command('cat /etc'))
    assert not match(Command('cat /etc/hosts'))
    assert match(Command('cat boh'))
    assert match(Command('cat `pwd`'))
    assert match(Command('cat `pwd`/boh'))
    assert match(Command('cat `pwd`/boh `pwd`/boh'))

# Generated at 2022-06-26 05:31:49.276600
# Unit test for function match
def test_match():
    bytes_0 = b's\x11\x15\x81\x8a\x9f'
    var_0 = match(bytes_0)
    assert 'cat: ' in var_0 and os.path.isdir(var_0[var_0.find('cat: ') + 5:])


# Generated at 2022-06-26 05:31:50.463520
# Unit test for function match
def test_match():
    assert match(command) == True


# Generated at 2022-06-26 05:31:53.072263
# Unit test for function match
def test_match():
    var_3 = os.popen('cat testfile')
    assert match(var_3)


# Generated at 2022-06-26 05:31:55.999589
# Unit test for function match
def test_match():
    bytes_0 = b'\x00\x00\x00'
    var_0 = match(bytes_0)
    assert var_0


# Generated at 2022-06-26 05:32:00.679871
# Unit test for function match
def test_match():
    assert match('\xca\xfb\xa9\xa5\xb0\x0b\xab')
    assert match('\xca\xfb\xa9\xa5\xb0\x0b\xab')
    assert not match('\xca\xfb\xa9\xa5\xb0\x0b\xab')
    assert not match('\xca\xfb\xa9\xa5\xb0\x0b\xab')


# Generated at 2022-06-26 05:32:05.743240
# Unit test for function match
def test_match():
    assert match(Command('cat file'))
    assert match(Command('cat file/'))
    assert match(Command('cat file/file/', ''))
    assert not match(Command('cat file', ''))
    assert not match(Command('cat file/file', ''))


# Generated at 2022-06-26 05:32:08.811279
# Unit test for function match
def test_match():
    def test_match_matchs():
        assert match('cat /home/user')
        assert match('cat /home/user/file.txt')

    def test_match_no_match():
        assert not match('ls /home/user')
        assert not match('cat')

    test_match_matchs()
    test_match_no_match()

# Generated at 2022-06-26 05:32:12.581001
# Unit test for function match
def test_match():
    command_0 = 'cat: mybook: Is a directory'.strip()
    ret_val_0 = match(command_0)
    assert ret_val_0 == True
    command_1 = 'cat: no such file or directory'.strip()
    ret_val_1 = match(command_1)
    assert ret_val_1 == False
    command_2 = 'cat: mybook: Is a directory'.strip()
    ret_val_2 = match(command_2)
    assert ret_val_2 == True


# Generated at 2022-06-26 05:32:23.862508
# Unit test for function match

# Generated at 2022-06-26 05:32:30.500371
# Unit test for function match
def test_match():
    assert match(b'cat: tmp/: Is a directory') == True
    assert match(b'cat: tmp/: No such file or directory') == False
    assert match(b'tmp/: Is a directory') == False
    assert match(b'cat: tmp/: No such file') == False
    assert match(b'cat: tmp/: No such file') == False
    assert match(b'') == False
    assert match(b'cat: tmp/: Is a directory') == True
    assert match(b'cat: tmp/: Is a directory') == True
    assert match(b'tmp/: Is a directory') == False
    assert match(b'tmp/: Is a directory') == False
    assert match(b'cat: tmp/: No such file or directory') == False

# Generated at 2022-06-26 05:34:37.114614
# Unit test for function match
def test_match():
    assert match(command) == (
        bytes_0.output.startswith('cat: ') and
        os.path.isdir(bytes_0.script_parts[1])
    )


# Generated at 2022-06-26 05:34:41.633162
# Unit test for function match
def test_match():
    bytes_0 = b'\xb8\xde\x04\x87u\x97'
    var_0 = match(bytes_0)


# Generated at 2022-06-26 05:34:51.025059
# Unit test for function match
def test_match():
    bytes_0 = b'7\xcd\xabVg\xee'
    var_0 = match(bytes_0)
    assert var_0 == (False, False)

    bytes_0 = b'\xff\xb8\xb5\x84\xa1\x9e'
    var_0 = match(bytes_0)
    assert var_0 == (True, False)

    bytes_0 = b'\xf5\xab\xd5\xe0\xc7\xd6'
    var_0 = match(bytes_0)
    assert var_0 == (False, False)

    bytes_0 = b'\xfb\x02\x9e\x86\xc8\xfe'
    var_0 = match(bytes_0)
    assert var_0 == (False, False)



# Generated at 2022-06-26 05:35:00.427003
# Unit test for function match
def test_match():
    assert(
        match(
            command.Command(
                script='cat file.doc',
                output='cat: file.doc: Is a directory',
                stderr='cat: file.doc: Is a directory'
            )
        )
    )
    assert(
        not match(
            command.Command(
                script='cat file.doc',
                output='No such file',
                stderr='cat: file.doc: No such file'
            )
        )
    )
    assert(
        not match(
            command.Command(
                script='cat file.doc',
                output='foo',
                stderr='cat: file.doc: foo'
            )
        )
    )


# Generated at 2022-06-26 05:35:06.596504
# Unit test for function match
def test_match():
    bytes_0 = b'\x08\xdc\x03\x00\x80\x00\x00\x00\xff\xff\xff\xff\xff\xff\xff\xff\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\xe0\x00\x00\x00\x00\x00'
    var_0 = get_new_command(bytes_0)
    assert var_0 == bytes

# Generated at 2022-06-26 05:35:08.355416
# Unit test for function match
def test_match():
    assert match(bytes_0) == 'cat /etc/anacrontab'

if __name__ == '__main__':
    test_case_0()
    test_match()
    print("Test has been passed")