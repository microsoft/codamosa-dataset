

# Generated at 2022-06-26 05:25:12.517603
# Unit test for function match
def test_match():
    assert match(bytes_0)

# Generated at 2022-06-26 05:25:15.791936
# Unit test for function match
def test_match():
    bytes_0 = 'cat'
    bool_0 = match(bytes_0)


# Generated at 2022-06-26 05:25:21.930488
# Unit test for function match
def test_match():
    assert match(Command('cat /foo/bar', '/foo/bar: is a directory', '/foo/bar'))
    assert not match(Command('cat /foo/bar', 'cat: /foo/bar: No such file or directory', '/foo/bar'))


# Generated at 2022-06-26 05:25:24.499401
# Unit test for function match
def test_match():
    bytes_1 = None
    assert match(bytes_1)



# Generated at 2022-06-26 05:25:27.493134
# Unit test for function match
def test_match():
    bytes_0 = b'cat: /etc/resolv.conf: Is a directory\n'
    var_0 = match(bytes_0)
    print(var_0)
    assert var_0 == True


# Generated at 2022-06-26 05:25:32.666743
# Unit test for function match
def test_match():
    bytes_0 = None
    bool_0 = match(bytes_0)
    #assertEquals(bool_0, None)


# Generated at 2022-06-26 05:25:34.233810
# Unit test for function match
def test_match():
    var_1 = None
    var_2 = match(var_1)

# Generated at 2022-06-26 05:25:35.201866
# Unit test for function match
def test_match():
    assert match(bytes_0)


# Generated at 2022-06-26 05:25:40.661711
# Unit test for function match
def test_match():
    var_7 = False
    def side_effect(x):
        return var_7
    command_1 = Command('cat file')
    bytes_0 = MagicMock()
    bytes_0.script_parts = ['cat', 'file']
    bytes_0.output = 'cat: file: Is a directory\n'
    bytes_0.script = 'cat file'
    side_effect.__name__ = 'os.path.isdir'
    wi

# Generated at 2022-06-26 05:25:48.008683
# Unit test for function match
def test_match():
    assert match(Command("cat /root/test.txt", "cat: '/root/test.txt': Is a directory", "", 0))==True
    assert match(Command("cat /root/test", "cat: '/root/test': No such file or directory", "", 0))==False
    assert match(Command("cat /root/test", "cat: '/root/test': Is not a directory", "", 0))==False



# Generated at 2022-06-26 05:25:54.715898
# Unit test for function match
def test_match():
    with patch('os.path') as mock_os_path:
        mock_os_path.isdir.return_value = True
        assert match(Command('cat foo'))
        

# Generated at 2022-06-26 05:25:56.671040
# Unit test for function match
def test_match():
    bytes_0 = None
    var_1 = match(bytes_0)


# Generated at 2022-06-26 05:26:03.160264
# Unit test for function match
def test_match():
    assert match(Command('cat nonexistent', 'cat: nonexistent: No such file or directory\n'))
    assert not match(Command('cat nonexistent', 'cat: nonexistent: No such file or directory\n', '', '', '', 1))
    assert match(Command('cat nonexistent', 'cat: nonexistent: Is a directory\n'))
    assert not match(Command('cat nonexistent', 'cat: nonexistent: Is a directory\n', '', '', '', 1))
    assert not match(Command('cat nonexistent'))
    assert not match(Command('ls nonexistent', 'ls: nonexistent: No such file or directory\n'))
    assert not match(Command('ls nonexistent', 'ls: nonexistent: No such file or directory\n', '', '', '', 1))
    assert not match(Command('ls nonexistent', 'ls: nonexistent: Is a directory\n'))

# Generated at 2022-06-26 05:26:05.037740
# Unit test for function match
def test_match():
    bytes_0 = Command('cat test.txt')
    var_0 = match(bytes_0)
    assert var_0 == False

# Generated at 2022-06-26 05:26:06.871397
# Unit test for function match
def test_match():
    assert match(bytes_0) == True


# Generated at 2022-06-26 05:26:09.274425
# Unit test for function match
def test_match():
    # Create mock object
    arg_0 = None
    var_0 = match(arg_0)



# Generated at 2022-06-26 05:26:13.446877
# Unit test for function match
def test_match():
    var_1 = os.path.isdir('./test/test_utils/match')
    assert var_1
    var_2 = match('./test/test_utils/match')
    assert var_2
    var_3 = match('cd test')
    assert not var_3

# Generated at 2022-06-26 05:26:14.512692
# Unit test for function match
def test_match():
    assert match('cat /tmp/')


# Generated at 2022-06-26 05:26:15.610294
# Unit test for function match
def test_match():
    bool_0 = match(None)


# Generated at 2022-06-26 05:26:16.951925
# Unit test for function match
def test_match():
    assert match(bytes_0) == False


# Generated at 2022-06-26 05:26:19.407385
# Unit test for function match
def test_match():
    assert match('command', 'error') == False


# Generated at 2022-06-26 05:26:21.400061
# Unit test for function match
def test_match():
    str_0 = 'cat foo'
    var_0 = match(str_0)
    assert var_0 == ('cat foo')


# Generated at 2022-06-26 05:26:24.693032
# Unit test for function match
def test_match():
    # Assertion
    str_0 = 'cat foo'
    result = match(str_0)
    assert result is True


# Generated at 2022-06-26 05:26:28.130212
# Unit test for function match
def test_match():
    var = ''
    str_0 = 'cat foo'
    str_1 = 'cat: foo: Is a directory'
    var = match(str_0, str_1)

    assert(var is False)


# Generated at 2022-06-26 05:26:37.049396
# Unit test for function match
def test_match():
    str_0 = 'cat foo'
    str_1 = 'cat /dev/null'
    str_2 = 'cat foo bar baz'
    str_3 = 'cat -n /dev/null'
    str_4 = 'cat /dev/null'
    str_5 = 'cat foo'
    str_6 = 'cat -n /dev/null'
    str_7 = 'cat foo bar baz'
    str_8 = 'cat /dev/null'
    str_9 = 'cat -n /dev/null'
    str_10 = 'cat foo'
    str_11 = 'cat -n /dev/null'
    str_12 = 'cat foo bar baz'
    str_13 = 'cat /dev/null'

    assert test_case_0() == 'cat: foo: Is a directory'

# Generated at 2022-06-26 05:26:39.584794
# Unit test for function match
def test_match():
    try:
        assert match('cat foo') == False
    except AssertionError as e:
        print("Failed function match")


# Generated at 2022-06-26 05:26:45.715718
# Unit test for function match
def test_match():
    test_case_0_input_var = str_0
    generated_code = match(test_case_0_input_var)
    print(generated_code)
    assert generated_code == 'ls foo'
    # Unit test for function get_new_command
    test_case_1_input_var = str_0
    generated_code = get_new_command(test_case_1_input_var)
    print(generated_code)
    assert generated_code == 'ls foo'

# Generated at 2022-06-26 05:26:51.426899
# Unit test for function match
def test_match():
    str_1 = 'cat foo'

    tuple_0 = ()
    tuple_1 = ()
    tuple_2 = (None,)
    tuple_3 = (None,)
    tuple_4 = (None,)
    tuple_5 = (None,)

    # Testing for branch coverage
    str_2 = 'cat '
    str_3 = 'cat -'
    str_4 = 'cat -'
    str_5 = 'cat -'

    tuple_0 = (str_1,)
    tuple_1 = tuple_0
    tuple_2 = (str_2,)
    tuple_3 = (str_3,)
    tuple_4 = (str_4,)
    tuple_5 = (str_5,)


# Generated at 2022-06-26 05:26:53.107132
# Unit test for function match
def test_match():
    assert match(str_0) == False



# Generated at 2022-06-26 05:26:56.424929
# Unit test for function match
def test_match():
    str_0 = 'cat foo'
    str_1 = "cat: 'foo': Is a directory"
    obj_0 = match(command)
    assert obj_0 is None


# Generated at 2022-06-26 05:27:09.042355
# Unit test for function match
def test_match():
    # Testing with expected true
    args = thefuck.shells.shell.And(script='cat foo', script_parts=['cat', 'foo'], output='cat: foo: Is a directory')
    func = match(args)
    assert func == True
    # Testing with expected false
    args = thefuck.shells.shell.And(script='cat foo', script_parts=['cat', 'foo'], output='cat: foo: No such file or directory')
    func = match(args)
    assert func == False


# Generated at 2022-06-26 05:27:12.182782
# Unit test for function match
def test_match():
    str_0 = 'cat foo'

    with mock.patch('thefuck.rules.ls_a_file.os.path.isdir', 
                    mock.Mock(return_value=False)):
        assert not match(Command(script=str_0))


# Generated at 2022-06-26 05:27:17.152240
# Unit test for function match
def test_match():
    line = 'cat: test: Is a directory'

    assert_function_matches(match, line) == True
    assert_function_matches(match, line) == True


# Generated at 2022-06-26 05:27:27.562910
# Unit test for function match
def test_match():
    str_0 = 'cat foo'
    str_1 = 'ls foo'

    test_0 = match(Command(script=str_0, output='cat: foo: Is a directory'))
    assert test_0 == True

    test_1 = get_new_command(Command(script=str_0, output='cat: foo: Is a directory'))
    assert test_1 == str_1

# Generated at 2022-06-26 05:27:30.224810
# Unit test for function match
def test_match():
    assert (
        command.output.startswith('cat: ') and
        os.path.isdir(command.script_parts[1])
    ) == match(str_0)


# Generated at 2022-06-26 05:27:32.853112
# Unit test for function match
def test_match():
    assert(match(type('Command', (object,), {
        'script': str_0,
        'script_parts': list_0
    })) == True)
    assert(match(type('Command', (object,), {
        'script': str_0,
        'script_parts': list_0
    })) == True)


# Generated at 2022-06-26 05:27:37.747025
# Unit test for function match
def test_match():
    str_1 = 'cat foo'
    assert match(str_1) == True
    str_2 = 'mv foo bar'
    assert match(str_2) == False
    str_3 = 'cd foo'
    assert match(str_3) == False
    str_4 = 'ls foo'
    assert match(str_4) == False



# Generated at 2022-06-26 05:27:41.109101
# Unit test for function match
def test_match():
    str_0 = 'cat foo'
    assert match(str_0) == True


# Generated at 2022-06-26 05:27:44.680380
# Unit test for function match
def test_match():
    str_0 = 'cat foo'

    bash_0 = Bash(str_0)

    script, output = bash_0.execute()

    assert (script == str_0 and output.startswith('cat: ') and os.path.isdir('foo') == False)


# Generated at 2022-06-26 05:27:49.849557
# Unit test for function match
def test_match():
    assert match(str_0,str_1) == False

test_match()

# Generated at 2022-06-26 05:27:56.930198
# Unit test for function match
def test_match():
    x = match(test_case_0)
    print(x)


# Generated at 2022-06-26 05:27:57.947260
# Unit test for function match
def test_match():
    assert match('cat foo') == True
    assert match('cat foo') == True

# Unit Test for function get_new_command

# Generated at 2022-06-26 05:28:01.031267
# Unit test for function match
def test_match():
    str_0 = 'cat foo'
    str_1 = 'ls foo\n'
    str_1 = 'ls foo'



# Generated at 2022-06-26 05:28:09.530677
# Unit test for function match
def test_match():
    # check if the match function works for the case 0 given by the website
    str_0 = 'cat foo'
    assert(match(str_0))

    # check if match function works for certain edge cases
    str_1 = 'cat foo bar'
    assert(match(str_1))

    # check if match function works for certain edge cases
    str_2 = 'cat foo bar baz'
    assert(match(str_2))

    # check if match function works for certain edge cases
    str_3 = 'cat foo/bar'
    assert(match(str_3))

    # check if match function works for certain edge cases
    str_4 = 'cat foo/bar/'
    assert(match(str_4))

    # check if match function works for certain edge cases

# Generated at 2022-06-26 05:28:12.115185
# Unit test for function match
def test_match():
    str_0 = 'cat foo'
    str_1 = str_0.split(" ")
    str_2 = str_1[1]
    assert str_2 == "foo"

# Generated at 2022-06-26 05:28:14.752146
# Unit test for function match
def test_match():
    try:
        assert match(str_0) == 1
        return 1
    except:
        return 0


# Generated at 2022-06-26 05:28:16.060723
# Unit test for function match
def test_match():
    assert match(str_0) == False


# Generated at 2022-06-26 05:28:17.299448
# Unit test for function match
def test_match():
    func_0 = match()
    return func_0


# Generated at 2022-06-26 05:28:22.454724
# Unit test for function match
def test_match():
    cmd = get_new_command(make_command('cat foo'))
    assert(match(cmd))

    cmd = get_new_command(make_command('cat foo bar'))
    assert(match(cmd))

    cmd = get_new_command(make_command('cat bar foo'))
    assert(not match(cmd))

    cmd = get_new_command(make_command('cat foo bar foo'))
    assert(match(cmd))

    cmd = get_new_command(make_command('cat foo foo bar'))
    assert(match(cmd))

    cmd = get_new_command(make_command('cat bar bar foo'))
    assert(match(cmd))



# Generated at 2022-06-26 05:28:23.985409
# Unit test for function match
def test_match():
    assert(match(str_0)) == True


# Generated at 2022-06-26 05:28:30.285080
# Unit test for function match
def test_match():
    assert match(str_0) == expected_0



# Generated at 2022-06-26 05:28:32.615763
# Unit test for function match
def test_match():
    # Make sure that command output begins with 'cat: '
    str_0 = 'cat foo'
    assert match(str_0) == (str_0.output.startswith('cat: ') and os.path.isdir(str_0.script_parts[1]))



# Generated at 2022-06-26 05:28:34.101474
# Unit test for function match
def test_match():
    str_0 = 'cat foo'
    print(match(str_0))


# Generated at 2022-06-26 05:28:36.542288
# Unit test for function match
def test_match():
    # Test 1
    str_0 = 'cat foo'
    var_0 = fnmatch_filter(str_0)
    assert var_0[0] == str_0


# Generated at 2022-06-26 05:28:39.607332
# Unit test for function match
def test_match():
    # Assert that
    # match(command)
    # return os.path.isdir(command.script_parts[1])
    # when
    # command.output.startswith('cat: ')
    # is True
    pass


# Generated at 2022-06-26 05:28:40.804366
# Unit test for function match
def test_match():
    assert match(str_0)


# Generated at 2022-06-26 05:28:42.444825
# Unit test for function match
def test_match():
    str_0 = 'cat foo'
    assert match(str_0)


# Generated at 2022-06-26 05:28:44.092497
# Unit test for function match
def test_match():
    assert match('cat foo') == True


# Generated at 2022-06-26 05:28:55.901827
# Unit test for function match
def test_match():
    str_0 = 'cat foo'
    str_1 = 'ls foo'
    str_2 = 'ls'
    str_3 = 'cat'
    str_4 = 'ls > '
    str_5 = 'cat > '
    str_6 = 'cat >> '
    str_7 = 'ls > '
    str_8 = 'ls '
    str_9 = 'ls >> '
    command_0 = Command(script=str_0)
    command_1 = Command(script=str_1, output='cat: foo')
    command_2 = Command(script=str_2, output='cat: foo')
    command_3 = Command(script=str_3, output='cat: foo')
    command_4 = Command(script=str_4, output='cat: foo')

# Generated at 2022-06-26 05:28:57.478009
# Unit test for function match
def test_match():
    str_0 = 'cat foo'
    assert match(str_0) == True


# Generated at 2022-06-26 05:29:06.229798
# Unit test for function match
def test_match():
    var_0 = get_new_command(
        Command('cat /usr/lib', '/usr/lib is a directory\n')
    )
    assert var_0 == 'ls /usr/lib'

# Generated at 2022-06-26 05:29:08.262661
# Unit test for function match
def test_match():
    input_bytes = bytes(b'cat /dev/urandom')
    output_bytes = None
    assert match(input_bytes) == output_bytes


# Generated at 2022-06-26 05:29:08.986290
# Unit test for function match
def test_match():
    var_1 = match(None)


# Generated at 2022-06-26 05:29:17.680264
# Unit test for function match
def test_match():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    bytes_0 = os.popen('cat something', 'r')
    bytes_0.close()
    var_2 = os.popen('cat ../../some/thing', 'r')
    var_2.close()
    var_3 = os.popen('cat something/else', 'r')
    var_3.close()
    var_4 = os.popen('cat something; else', 'r')
    var_4.close()
    var_5 = os.popen('cat foo', 'r')
    var_5.close()
    var_6 = os.popen('cat something else', 'r')

# Generated at 2022-06-26 05:29:26.110475
# Unit test for function match
def test_match():

    def test_case_0():
        bytes_0 = b'cat: test_directory: Is a directory\n'
        str_0 = str(bytes_0, 'utf-8')
        str_1 = '/bin/cat'
        str_2 = 'test_directory'
        list_0 = [str_1, str_2]
        tuple_0 = ('', list_0, str_1)
        var_0 = Command(tuple_0, str_0)
        var_1 = match(var_0)
        assert var_1 == True


# Generated at 2022-06-26 05:29:30.218272
# Unit test for function match
def test_match():
    bytes_0 = None
    
    var_0 = for_app('cat', at_least=1)
    var_1 = match(bytes_0)

    assert var_0 == var_1, 'Expected {}, got {}'.format(
        var_0,
        var_1)


# Generated at 2022-06-26 05:29:31.369157
# Unit test for function match
def test_match():
    assert match(magic_mock()) is None


# Generated at 2022-06-26 05:29:39.952927
# Unit test for function match
def test_match():
    thefuck_alias = 'fuck'
    thefuck_priority = 10
    thefuck_enabled_by_default = True
    thefuck_no_colors = False
    thefuck_wait_command = 3
    thefuck_settings = None
    thefuck_env = os.environ
    thefuck_alias_mode = 'bash'
    thefuck_require_confirmation = True
    thefuck_debug = False
    thefuck_slow_commands = 1
    thefuck_history_limit = None
    thefuck_exclude_rules = []
    thefuck_rules = [
        {
            '_name': 'test',
            '_match': match,
            '_get_new_command': get_new_command
        }
    ]
    thefuck_python = '/usr/bin/env python'
    the

# Generated at 2022-06-26 05:29:41.011999
# Unit test for function match
def test_match():
    bytes_0 = None
    var_1 = match(bytes_0)


# Generated at 2022-06-26 05:29:43.705385
# Unit test for function match
def test_match():
    var_0 = Command('cat /home/ubuntu/fuck_you',
                    '/home/ubuntu/fuck_you: Is a directory')
    var_1 = match(var_0)
    assert(var_1)


# Generated at 2022-06-26 05:30:05.522010
# Unit test for function match
def test_match():

    # test_case_1
    bytes_1 = type('command', (object,), {
            'output': 'cat: file.txt: Is a directory\n',
            'script': 'cat file.txt',
            'script_parts': [
                'cat',
                'file.txt'
            ]
        })
    var_1 = match(bytes_1)
    assert var_1 == False, var_1
    # test_case_2
    bytes_2 = type('command', (object,), {
            'output': 'cat: file.txt: Is a directory\n',
            'script': 'cat file.txt',
            'script_parts': [
                'cat',
                '/file.txt'
            ]
        })
    var_2 = match(bytes_2)
    assert var_2 == False

# Generated at 2022-06-26 05:30:10.228558
# Unit test for function match
def test_match():
    assert match(Command('cat foo')) == False
    assert match(Command('cat foo', "cat: 'foo': Is a directory\n")) == True
    assert match(Command('cat foo', "cat: 'foo': No such file or directory\n")) == False


# Generated at 2022-06-26 05:30:12.940287
# Unit test for function match
def test_match():
    print("Start method match")
    assert match(bytes_0) != var_0
    print("End method match")


# Generated at 2022-06-26 05:30:14.245881
# Unit test for function match
def test_match():
    assert match(bytes_0) == True


# Generated at 2022-06-26 05:30:15.750044
# Unit test for function match
def test_match():
    var_1 = match(bytes_0)
    assert var_1 == None


# Generated at 2022-06-26 05:30:16.839457
# Unit test for function match
def test_match():
    assert match(None) == None



# Generated at 2022-06-26 05:30:17.899588
# Unit test for function match
def test_match():
    assert match(None) is False


# Generated at 2022-06-26 05:30:24.338599
# Unit test for function match
def test_match():
    # Test with records in the database
    bytes_0 = None
    var_0 = match(bytes_0)
    # Test with records not in the database
    bytes_1 = None
    var_1 = match(bytes_1)


# Generated at 2022-06-26 05:30:26.463958
# Unit test for function match
def test_match():
    bytes_0 = None
    var_1 = match(bytes_0)

# Generated at 2022-06-26 05:30:27.739556
# Unit test for function match
def test_match():
    bytes_0 = None
    assert match(bytes_0)


# Generated at 2022-06-26 05:30:53.245456
# Unit test for function match
def test_match():
    assert match(bytes_0) == False
    assert match(bytes_1) == False


# Generated at 2022-06-26 05:30:56.302725
# Unit test for function match
def test_match():
    assert match(Command(script='cat dir', stderr='cat: dir: Is a directory\n'))
    assert not match(Command(script='cat file', stderr='cat: file: No such file or directory\n'))


# Generated at 2022-06-26 05:30:58.107486
# Unit test for function match
def test_match():
    bytes_0 = None
    var_0 = match(bytes_0)
    assert var_0 != None

# Generated at 2022-06-26 05:31:00.465061
# Unit test for function match
def test_match():

    # Tested function
    try:
        assert match == 'This function is expected to return a value'
    except AssertionError as e:
        print('AssertionError:', e)


# Generated at 2022-06-26 05:31:01.964562
# Unit test for function match
def test_match():
    assert match(command) == True


# Generated at 2022-06-26 05:31:10.009654
# Unit test for function match
def test_match():
    var_0 = os.path.isdir('/Users')
    var_1 = Command(
        '/usr/bin/cat /Users',
        '/usr/bin/cat /Users',
        'cat: /Users: Is a directory',
        '',
        '/Users',
        os.path.expanduser('~'),
        True
    )
    assert match(var_1) == True

# Generated at 2022-06-26 05:31:11.646255
# Unit test for function match
def test_match():
    assert not match(bytes_0)
    assert not match(var_0)



# Generated at 2022-06-26 05:31:17.079955
# Unit test for function match
def test_match():
    var_0 = Command.from_string('cat /dev/urandom', None)
    var_1 = Command.from_string('cat /dev/urandom', None)
    var_2 = Command.from_string('cat /dev/urandom', None)
    var_3 = Command.from_string('cat /dev/urandom', None)
    var_4 = Command.from_string('cat /dev/urandom', None)
    var_5 = Command.from_string('cat /dev/urandom', None)
    var_6 = Command.from_string('cat /dev/urandom', None)
    var_7 = Command.from_string('cat /dev/urandom', None)
    var_8 = Command.from_string('cat /dev/urandom', None)
    var_9 = Command.from_string

# Generated at 2022-06-26 05:31:25.226453
# Unit test for function match
def test_match():
    assert match(get_new_command('cat foo')) == False
    assert match(get_new_command('cat test/test.py')) == False
    assert match(get_new_command('cat test/')) == True



# Generated at 2022-06-26 05:31:33.818809
# Unit test for function match
def test_match():
    # Test when command.output.startswith('cat: ') is true
    assert match(MagicMock(output=MagicMock(startswith=MagicMock(return_value=True)), script_parts=MagicMock(__getitem__=MagicMock(return_value=MagicMock(isdir=MagicMock(return_value=True))), __len__=MagicMock(return_value=2))))
    # Test when command.output.startswith('cat: ') is false

# Generated at 2022-06-26 05:32:27.372039
# Unit test for function match
def test_match():
    bytes_0 = None
    assert match(bytes_0) == (None, [])


# Generated at 2022-06-26 05:32:31.635549
# Unit test for function match
def test_match():
    f = os.path.isdir
    f = match
    f = get_new_command

if __name__ == '__main__':
    test_case_0()
    test_match()

# Generated at 2022-06-26 05:32:32.851979
# Unit test for function match
def test_match():
    assert match(bytes_0) == False


# Generated at 2022-06-26 05:32:33.900196
# Unit test for function match
def test_match():
    var_2 = None
    assert match(var_2) == True


# Generated at 2022-06-26 05:32:35.664544
# Unit test for function match
def test_match():
    var_0 = u'/usr/bin/clear'
    var_0 = get_new_command(var_0)


# Generated at 2022-06-26 05:32:40.225615
# Unit test for function match
def test_match():
    assert match(
        Command('cat build.gradle',
                'cat: build.gradle: Is a directory',
                '', 1)
    )
    assert not match(Command('cat asd', '', '', 1))
    assert not match(Command('cat build.gradle', '', '', 1))

# Generated at 2022-06-26 05:32:46.189765
# Unit test for function match
def test_match():
    assert match(Command(script='cat ~/forbidden/path', output='cat: ~/forbidden/path: Is a directory'))
    assert match(Command(script='cat /dev/stdin', output='cat: -: Is a directory'))
    assert not match(Command(script='cat', output='cat: : Is a directory'))
    assert not match(Command(script='cat foo', output='foo'))


# Generated at 2022-06-26 05:32:47.498743
# Unit test for function match
def test_match():
    assert match(bytes_0)


# Generated at 2022-06-26 05:32:53.472426
# Unit test for function match
def test_match():
    assert match("cat: test_files: Is a directory")
    assert match("cat: test_files/test_file.txt: No such file or directory")
    assert not match("ls test_files")
    assert not match("cat test_files")
    assert not match("")


# Generated at 2022-06-26 05:32:58.117714
# Unit test for function match
def test_match():
    bytes_0 = os.path.isdir
    var_0 = match(bytes_0)


# Generated at 2022-06-26 05:34:57.733025
# Unit test for function match
def test_match():
    bytes_0 = None
    var_0 = match(bytes_0)
    assert var_0 == None
    var_0 = match(bytes_0)
    assert var_0 == None


# Generated at 2022-06-26 05:34:59.039759
# Unit test for function match
def test_match():
    bytes_0 = None
    assert match(bytes_0) == None


# Generated at 2022-06-26 05:35:00.249774
# Unit test for function match
def test_match():
    assert match('cat foo')
    assert not match('foo')


# Generated at 2022-06-26 05:35:01.349205
# Unit test for function match
def test_match():
    assert match(bytes_0)


# Generated at 2022-06-26 05:35:03.095858
# Unit test for function match
def test_match():
    bytes_0 = None
    var_0 = match(bytes_0)
    print("var_0: " + str(var_0))

# Generated at 2022-06-26 05:35:04.119440
# Unit test for function match
def test_match():
    assert match(get_new_command)


# Generated at 2022-06-26 05:35:09.945830
# Unit test for function match
def test_match():
    str_0 = 'cat: .: Is a directory'
    bytes_0 = Command("cat .", str_0)
    assert match(bytes_0) == True

    str_0 = 'cat: .git: Is a directory'
    bytes_0 = Command("cat .git", str_0)
    assert match(bytes_0) == True

    str_0 = 'grep: .git: Is a directory'
    bytes_0 = Command("grep .git", str_0)
    assert match(bytes_0) == False

    str_0 = 'cat: file not found'
    bytes_0 = Command("cat not-found.txt", str_0)
    assert match(bytes_0) == False
