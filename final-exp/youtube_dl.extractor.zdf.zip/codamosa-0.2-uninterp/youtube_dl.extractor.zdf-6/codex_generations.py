

# Generated at 2022-06-18 15:17:00.625517
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:05.905395
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:07.159341
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:17:17.821337
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:17:27.607693
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:17:30.176314
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:33.148871
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:37.527986
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:44.125027
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:17:47.812073
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:36.725521
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-18 15:18:41.935443
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio.html')
    assert not ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio/video-100.html')
    assert not ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio/video-100.html?foo=bar')

# Generated at 2022-06-18 15:18:48.031331
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_download import fake_urlopen
    from .test_download import FakeUrlTestCase

    class TestZDFChannelIE(FakeUrlTestCase):
        def setUp(self):
            FakeUrlTestCase.setUp(self)
            self.test_url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
            self.test_channel_id = 'das-aktuelle-sportstudio'

# Generated at 2022-06-18 15:18:50.521532
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:51.179942
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-18 15:18:54.388843
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:58.961551
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.ie_key() == ZDFBaseIE.ie_key()
    assert ie.ie_key() == InfoExtractor.ie_key()


# Generated at 2022-06-18 15:19:10.623939
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUITES == ['zdf']
    assert ie.GEO_COUNTRIES == ['DE']
    assert ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie.extract_format == ZDFBaseIE._extract_format
    assert ie.extract_ptmd == ZDFBaseIE._extract_ptmd
    assert ie.extract_subtitles == ZDFBaseIE._extract_subtitles
    assert ie.extract_entry == ZDFBaseIE._extract_entry
    assert ie.extract_regular == ZDFBaseIE._extract_regular
   

# Generated at 2022-06-18 15:19:18.007418
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not ZDFIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert ZDFIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')


# Generated at 2022-06-18 15:19:21.694765
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:22.548792
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:20:26.232127
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable(ZDFChannelIE._VALID_URL)
    assert not zdf_channel_ie.suitable(ZDFIE._VALID_URL)


# Generated at 2022-06-18 15:20:29.298810
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:30.976104
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:34.456658
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:38.734425
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:48.282633
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUCCESS == ZDFIE.SUCCESS
    assert ie._VALID_URL == ZDFIE._VALID_URL
    assert ie._TESTS == ZDFIE._TESTS
    assert ie._GEO_COUNTRIES == ZDFIE._GEO_COUNTRIES
    assert ie._QUALITIES == ZDFIE._QUALITIES
    assert ie._call_api == ZDFIE._call_api
    assert ie._extract_subtitles == ZDFIE._extract_subtitles
    assert ie._extract_format == ZDFIE._extract_format
    assert ie._extract_ptmd == ZDFIE

# Generated at 2022-06-18 15:20:56.800797
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')

# Generated at 2022-06-18 15:21:06.915741
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:21:17.246672
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUITES == ['zdf']
    assert ie.SUITES == ZDFIE.SUITES
    assert ie.WEB_URL_TEMPLATE == 'https://www.zdf.de/%s'
    assert ie.WEB_URL_TEMPLATE == ZDFIE.WEB_URL_TEMPLATE
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._VALID_URL == ZDFIE._VALID_URL

# Generated at 2022-06-18 15:22:53.718707
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-18 15:23:06.047791
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUITES == ['ZDF']
    assert ie.SUITES == ZDFIE.SUITES
    assert ie.WEB_URL == 'https://www.zdf.de/'
    assert ie.WEB_URL == ZDFIE.WEB_URL
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._VALID_URL == ZDFIE._VALID_URL

# Generated at 2022-06-18 15:23:09.084224
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:23:12.665730
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:23:20.171899
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-18 15:23:31.894964
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.ie_key() == ZDFBaseIE.ie_key()
    assert ie.ie_key() == InfoExtractor.ie_key()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:23:41.716438
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:23:45.034681
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:23:47.146311
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()


# Generated at 2022-06-18 15:23:49.966300
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
