

# Generated at 2022-06-18 15:17:13.769030
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor of class ZDFBaseIE
    ie = ZDFBaseIE()
    assert ie.ie_key() == 'zdf'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'Zdf'
    assert ie.ie_key() == 'zDF'
    assert ie.ie_key() == 'zdF'
    assert ie.ie_key() == 'ZdF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'zdf'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:17:21.948038
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:17:25.131357
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:32.827211
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:17:37.153719
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:41.208855
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:45.016635
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')


# Generated at 2022-06-18 15:17:56.688716
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:17:57.620259
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:18:04.132615
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:18:57.603381
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')


# Generated at 2022-06-18 15:19:01.561989
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:03.389408
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:19:13.158942
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key_map
    assert ie.ie_key() in ZDFIE.ie_key_map.keys()
    assert ie.ie_key() in ZDFIE.ie_key_map.values()
    assert ie.ie_key() in ZDFIE.ie_key_map.keys()
    assert ie.ie_key() in ZDFIE.ie_key_map.values()
    assert ie.ie_key() in ZDFIE.ie_key_map.keys()
    assert ie.ie_key() in ZDFIE.ie_key_map.values()
    assert ie.ie_key() in ZDFIE.ie_key_map.keys()

# Generated at 2022-06-18 15:19:14.085287
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-18 15:19:14.956034
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')


# Generated at 2022-06-18 15:19:23.030355
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUITES == ['zdf']
    assert ie.GEO_COUNTRIES == ['DE']
    assert ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie.VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie.VALID_URL == ZDFIE.VALID_URL


# Generated at 2022-06-18 15:19:24.983030
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test ZDFBaseIE constructor
    ZDFBaseIE(ZDFIE.ie_key(), ZDFIE.ie_key())


# Generated at 2022-06-18 15:19:28.415936
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:33.068445
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE(url)
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.channel_id == 'planet-e'
    assert ie.url == url
    assert ie.title == 'planet e.'
    assert ie.description is None
    assert ie.thumbnail is None
    assert ie.duration is None
    assert ie.timestamp is None
    assert ie.uploader is None
    assert ie.uploader_id is None
    assert ie.uploader_url is None
    assert ie.age_limit is None
    assert ie.view_count is None
    assert ie.like_count is None
    assert ie.dislike_count is None
   

# Generated at 2022-06-18 15:21:15.245696
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:18.030646
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:20.474500
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:23.291621
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()


# Generated at 2022-06-18 15:21:26.306560
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:36.439828
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_

# Generated at 2022-06-18 15:21:39.983357
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:43.459027
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:50.295379
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test for constructor of class ZDFChannelIE
    #
    # Test case 1:
    #   Test for constructor of class ZDFChannelIE
    #   with valid url
    #   expected result:
    #   url is valid
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert ZDFChannelIE.suitable(url)

    # Test case 2:
    #   Test for constructor of class ZDFChannelIE
    #   with invalid url
    #   expected result:
    #   url is invalid
    url = 'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'
    assert not ZDFChannel

# Generated at 2022-06-18 15:21:55.768431
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:26:05.787809
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:26:14.302370
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.ie_key() == ZDFBaseIE.ie_key()
    assert ie.ie_key() == InfoExtractor.ie_key()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.ie_key() == ZDFBaseIE.ie_key()
    assert ie.ie_key() == InfoExtractor.ie_key()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.ie_key() == ZDFBaseIE.ie_key()

# Generated at 2022-06-18 15:26:17.486312
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:26:19.820027
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE()
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDFChannel'

# Generated at 2022-06-18 15:26:22.750538
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:26:25.200877
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:26:30.408921
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:26:31.810113
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases
    for case in get_testcases(ZDFChannelIE, {
        '__main__': {
            'suitable': False,
        },
    }):
        yield case

# Generated at 2022-06-18 15:26:36.129117
# Unit test for constructor of class ZDFChannelIE