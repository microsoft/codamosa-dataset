

# Generated at 2022-06-18 15:16:59.939748
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-18 15:17:01.207752
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:17:14.267473
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE()
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.extract_id(url) == 'planet-e'
    assert ie.extract_url(url) == url
    assert ie.extract_title(url) == 'planet e.'
    assert ie.extract_description(url) == 'Planet E.'
    assert ie.extract_thumbnail(url) == 'https://www.zdf.de/assets/img/planet-e/planet-e-logo-16x9-100~16x9~b5f2d8e3.jpg'
    assert ie.extract_duration(url) == 0

# Generated at 2022-06-18 15:17:19.577996
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:29.217037
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test ZDFChannelIE.suitable()
    assert ZDFChannelIE.suitable(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ZDFChannelIE.suitable(
        'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

    # Test ZDFChannelIE._real_extract()
    zdf_channel_ie = ZDFChannelIE()

# Generated at 2022-06-18 15:17:35.306546
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:17:36.409123
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-18 15:17:42.869218
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')

# Generated at 2022-06-18 15:17:46.529408
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:58.107976
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert ie.suitable('https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html')
    assert ie.suitable('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')

# Generated at 2022-06-18 15:18:58.428975
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:19:10.184923
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE(url)
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.channel_id() == 'planet-e'
    assert ie.channel_url() == url
    assert ie.channel_title() == 'planet e.'
    assert ie.channel_description() == 'md5:f8f2d8b9c3f9c9f9d8d8c8c8c8c8c8c8'
    assert ie.channel_thumbnail() == 're:https?://.*\.jpg'
    assert ie.channel_timestamp() == 1588291200
    assert ie.channel_total_videos() == 50

# Generated at 2022-06-18 15:19:13.198890
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:15.944649
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:21.425432
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

# Generated at 2022-06-18 15:19:26.040361
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE(url)
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.channel_id == 'planet-e'
    assert ie.url == url
    assert ie.video_id is None
    assert ie.player is None
    assert ie.content is None
    assert ie.api_token is None
    assert ie.referrer is None
    assert ie.webpage is None
    assert ie.title is None
    assert ie.description is None
    assert ie.duration is None
    assert ie.timestamp is None
    assert ie.thumbnails is None
    assert ie.subtitles is None
    assert ie.formats is None
    assert ie

# Generated at 2022-06-18 15:19:34.929749
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:19:42.416216
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE(url)
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.channel_id() == 'planet-e'
    assert ie.channel_url() == url
    assert ie.channel_title() == 'planet e.'
    assert ie.channel_description() == 'md5:d41d8cd98f00b204e9800998ecf8427e'
    assert ie.channel_thumbnail() == 'https://www.zdf.de/assets/zdf-logo-fb-d9e8b1a7b4f4c2f4d4b8e8f7c9e9b9d9.png'


# Generated at 2022-06-18 15:19:52.513257
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key_map
    assert ie.ie_key() in ZDFIE.ie_key_map.values()
    assert ie.ie_key() in ZDFIE.ie_key_map.keys()
    assert ZDFIE.ie_key() in ZDFIE.ie_key_map
    assert ZDFIE.ie_key() in ZDFIE.ie_key_map.values()
    assert ZDFIE.ie_key() in ZDFIE.ie_key_map.keys()
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() == ie.ie_key()

# Generated at 2022-06-18 15:19:55.212968
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:35.804650
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:39.606056
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor of class ZDFBaseIE
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:43.041340
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:45.684713
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:57.136742
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:22:04.165063
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:22:10.603570
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:22:15.246600
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test for the constructor of class ZDFChannelIE
    #
    # Input:
    #    -
    # Expected result:
    #    An instance of ZDFChannelIE
    #
    # Return value:
    #    -

    ie = ZDFChannelIE()
    assert isinstance(ie, ZDFChannelIE)


# Generated at 2022-06-18 15:22:19.345277
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:29.358219
# Unit test for constructor of class ZDFChannelIE