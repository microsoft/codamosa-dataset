

# Generated at 2022-06-18 15:17:00.582750
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:03.342745
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')


# Generated at 2022-06-18 15:17:05.798607
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-18 15:17:16.644279
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio/das-aktuelle-sportstudio-vom-28-november-2020-100.html')

# Generated at 2022-06-18 15:17:19.921064
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:21.404727
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:17:24.588049
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:27.608640
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:34.509756
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not zdf_channel_ie.suitable(
        'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert not zdf_channel_ie.suitable(
        'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')

# Generated at 2022-06-18 15:17:38.369200
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbaseie = ZDFBaseIE()
    assert zdfbaseie._GEO_COUNTRIES == ['DE']
    assert zdfbaseie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:32.544925
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:18:36.059692
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:39.335104
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:42.621714
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:45.636549
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:48.481218
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:51.263504
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor of class ZDFBaseIE
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:53.773823
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()


# Generated at 2022-06-18 15:19:05.455087
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:19:08.821314
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:02.806620
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')

# Generated at 2022-06-18 15:20:04.619611
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:06.352522
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:11.080872
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUITABLE_DEFAULT == [ZDFIE.ie_key()]
    assert ie.SUITABLE_DEFAULT == ZDFIE.SUITABLE_DEFAULT
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._GEO_COUNTRIES == ZDFIE._GEO_COUNTRIES
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._VALID_URL == ZDFIE._VALID_URL

# Generated at 2022-06-18 15:20:12.942951
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key_map
    assert ie.ie_key() in ZDFIE.ie_key_map.values()


# Generated at 2022-06-18 15:20:20.385175
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_download import _test_download_json
    from .test_download import _test_download_webpage
    from .test_download import _test_download_webpage_handle
    from .test_download import _test_download_webpage_handle_no_download
    from .test_download import _test_download_webpage_handle_no_download_no_expected_status
    from .test_download import _test_download_webpage_no_download
    from .test_download import _test_download_webpage_no_download_no_expected_status
    from .test_download import _test_download_webpage_no_download_no_test
    from .test_download import _test_download_webpage_no_test
    from .test_download import _test_download_webpage_raise_on_

# Generated at 2022-06-18 15:20:32.043099
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:20:37.505568
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.ie_key() == ZDFBaseIE.ie_key()
    assert ie.ie_key() == InfoExtractor.ie_key()


# Generated at 2022-06-18 15:20:44.202081
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/')


# Generated at 2022-06-18 15:20:47.890733
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:33.721765
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:22:36.486872
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:42.277300
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    channel_id = 'planet-e'

# Generated at 2022-06-18 15:22:45.801296
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:46.222137
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-18 15:22:46.645419
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-18 15:22:49.817990
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:52.357601
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:58.846399
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:23:02.477641
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
