

# Generated at 2022-06-18 15:17:00.805354
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable(ZDFChannelIE._VALID_URL)
    assert not zdf_channel_ie.suitable(ZDFIE._VALID_URL)


# Generated at 2022-06-18 15:17:13.954686
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ie.supported_ie_keys()
    assert ie.ie_key() in ie.supported_ie_keys(include_universal=True)
    assert ie.ie_key() in ie.supported_ie_keys(include_universal=False)
    assert ie.ie_key() in ie.supported_ie_keys(include_universal=True, include_fallback=True)
    assert ie.ie_key() in ie.supported_ie_keys(include_universal=False, include_fallback=True)
    assert ie.ie_key() in ie.supported_ie_keys(include_universal=True, include_fallback=False)

# Generated at 2022-06-18 15:17:19.151461
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:28.835072
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:17:31.830630
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases
    for case in get_testcases(ZDFChannelIE, {
            '__main__': {
                'suitable': False,
            },
            'ZDFIE': {
                'suitable': True,
            },
        }):
        yield case

# Generated at 2022-06-18 15:17:36.257944
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor of class ZDFBaseIE
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:39.605782
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE
    zdf = ZDFChannelIE()
    assert zdf.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not zdf.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')


# Generated at 2022-06-18 15:17:44.039873
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.ie_key() == ZDFBaseIE.ie_key()


# Generated at 2022-06-18 15:17:56.209567
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_

# Generated at 2022-06-18 15:18:03.227137
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:18:34.127442
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test for constructor of class ZDFBaseIE
    # Input:
    #   - None
    # Expect:
    #   - An instance of ZDFBaseIE
    assert isinstance(ZDFBaseIE(), ZDFBaseIE)


# Generated at 2022-06-18 15:18:37.822486
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:41.150915
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:42.092032
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:18:50.526250
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:18:53.106402
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()


# Generated at 2022-06-18 15:18:55.774327
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()


# Generated at 2022-06-18 15:19:07.508696
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ie.supported_ie_keys
    assert ie.ie_key() in ie.supported_ie_keys_map
    assert ie.supported_ie_keys_map[ie.ie_key()] == ie.__class__
    assert ie.supported_ie_keys_map[ie.ie_key()].__name__ == ie.__class__.__name__
    assert ie.supported_ie_keys_map[ie.ie_key()].__name__ == ie.__class__.__name__
    assert ie.supported_ie_keys_map[ie.ie_key()].__name__ == ie.__class__.__name__

# Generated at 2022-06-18 15:19:10.756679
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:14.431985
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'ZDF'
    assert zdfie.ie_key() in ZDFIE.ie_key()
    assert zdfie.ie_key() in ZDFBaseIE.ie_key()


# Generated at 2022-06-18 15:20:06.552520
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases
    for case in get_testcases(ZDFChannelIE, {
        'url': 'https://www.zdf.de/dokumentation/planet-e',
        'only_matching': True,
    }):
        yield case

# Generated at 2022-06-18 15:20:09.369617
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:13.505871
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:16.674663
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:27.646091
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.utils import parse_duration
    from youtube_dl.extractor.zdf import ZDFChannelIE
    from youtube_dl.extractor.zdf import ZDFIE
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.utils import orderedSet
    from youtube_dl.utils import unescapeHTML
    from youtube_dl.utils import try_get
    from youtube_dl.utils import unified_timestamp
    from youtube_dl.utils import int_or_none
    from youtube_dl.utils import float_or_none
    from youtube_dl.utils import url_or_none
    from youtube_dl.utils import qualities
    from youtube_dl.utils import parse_duration


# Generated at 2022-06-18 15:20:30.894985
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:34.324493
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:38.641580
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:40.358088
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-18 15:20:43.313694
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:24.566872
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:28.648521
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test for the constructor of class ZDFChannelIE
    #
    # Input:
    #   - None
    #
    # Expected result:
    #   - Instance of class ZDFChannelIE
    assert isinstance(ZDFChannelIE(), ZDFChannelIE)


# Generated at 2022-06-18 15:22:36.098538
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key_map
    assert ie.ie_key() in ZDFIE.ie_key_map.values()
    assert ie.ie_key() in ZDFIE.ie_key_map.keys()
    assert ie.ie_key() in ZDFIE.ie_key_map.keys()
    assert ie.ie_key() in ZDFIE.ie_key_map.values()
    assert ie.ie_key() in ZDFIE.ie_key_map
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-18 15:22:45.953742
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUITES == ['zdf']
    assert ie.GEO_COUNTRIES == ['DE']
    assert ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie.VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:22:49.261487
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:23:00.169003
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')

# Generated at 2022-06-18 15:23:11.329086
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUCCESS == ZDFIE.SUCCESS
    assert ie._VALID_URL == ZDFIE._VALID_URL
    assert ie._TESTS == ZDFIE._TESTS
    assert ie._GEO_COUNTRIES == ZDFIE._GEO_COUNTRIES
    assert ie._QUALITIES == ZDFIE._QUALITIES
    assert ie._call_api == ZDFIE._call_api
    assert ie._extract_subtitles == ZDFIE._extract_subtitles
    assert ie._extract_format == ZDFIE._extract_format
    assert ie._extract_ptmd == ZDFIE

# Generated at 2022-06-18 15:23:15.641948
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.ie_key() == ZDFBaseIE.ie_key()
    assert ie.ie_key() == InfoExtractor.ie_key()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-18 15:23:23.925823
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE(url)
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.channel_id == 'planet-e'
    assert ie.channel_url == url
    assert ie.channel_title == 'planet e.'
    assert ie.channel_description == None
    assert ie.channel_thumbnail == None
    assert ie.channel_timestamp == None
    assert ie.channel_duration == None
    assert ie.channel_view_count == None
    assert ie.channel_like_count == None
    assert ie.channel_dislike_count == None
    assert ie.channel_comment_count == None
    assert ie.channel_average_rating == None


# Generated at 2022-06-18 15:23:27.943478
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
