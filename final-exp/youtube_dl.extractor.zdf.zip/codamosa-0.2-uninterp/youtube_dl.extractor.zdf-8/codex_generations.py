

# Generated at 2022-06-18 15:17:13.541657
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:17:19.106565
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_html import get_testdata
    from .common import get_testcases
    from .zdf import ZDFIE

    testcases = get_testcases(get_testdata(), ZDFChannelIE)
    for testcase in testcases:
        yield testcase

# Generated at 2022-06-18 15:17:28.792205
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUCCESS == ZDFIE.SUCCESS
    assert ie.FAILED == ZDFIE.FAILED
    assert ie.extract_format == ZDFIE._extract_format
    assert ie.extract_ptmd == ZDFIE._extract_ptmd
    assert ie.extract_player == ZDFIE._extract_player
    assert ie.extract_entry == ZDFIE._extract_entry
    assert ie.extract_regular == ZDFIE._extract_regular
    assert ie.extract_mobile == ZDFIE._extract_mobile
    assert ie.real_extract == ZDFIE._real_extract

# Generated at 2022-06-18 15:17:31.525656
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:33.056341
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()


# Generated at 2022-06-18 15:17:35.029935
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-18 15:17:46.027967
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:17:57.663070
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:18:06.829027
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:18:16.545057
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUITES == [ZDFIE.ie_key()]
    assert ie.SUITES == ZDFIE.SUITES
    assert ie.WEB_URL == 'https://www.zdf.de/'
    assert ie.WEB_URL == ZDFIE.WEB_URL
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._GEO_COUNTRIES == ZDFIE._GEO_COUNTRIES
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
   

# Generated at 2022-06-18 15:18:45.722152
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:46.583063
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-18 15:18:54.710342
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert not ZDFChannelIE.suitable

# Generated at 2022-06-18 15:19:06.555237
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')

# Generated at 2022-06-18 15:19:15.620206
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:19:25.278362
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUCCESS == ZDFIE.SUCCESS
    assert ie._GEO_COUNTRIES == ZDFIE._GEO_COUNTRIES
    assert ie._VALID_URL == ZDFIE._VALID_URL
    assert ie._TESTS == ZDFIE._TESTS
    assert ie._call_api == ZDFIE._call_api
    assert ie._extract_subtitles == ZDFIE._extract_subtitles
    assert ie._extract_format == ZDFIE._extract_format
    assert ie._extract_ptmd == ZDFIE._extract_ptmd

# Generated at 2022-06-18 15:19:34.421345
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.ie_key() == 'zdf'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'Zdf'
    assert ie.ie_key() == 'zDF'
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie.ie_

# Generated at 2022-06-18 15:19:37.186257
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:43.941529
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key_map
    assert ie.ie_key() in ZDFIE.ie_key_map.values()
    assert ie.ie_key() in ZDFIE.ie_key_map.keys()
    assert ZDFIE.ie_key() in ZDFIE.ie_key_map
    assert ZDFIE.ie_key() in ZDFIE.ie_key_map.values()
    assert ZDFIE.ie_key() in ZDFIE.ie_key_map.keys()


# Generated at 2022-06-18 15:19:44.957298
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:20:39.158843
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:42.159693
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:43.102135
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:20:46.710166
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:20:47.672714
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-18 15:20:49.360735
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-18 15:20:53.190607
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases
    for case in get_testcases(ZDFChannelIE, {
            'url': 'https://www.zdf.de/dokumentation/planet-e',
            'only_matching': True,
        }):
        yield case

# Generated at 2022-06-18 15:20:56.540990
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test for the constructor of class ZDFChannelIE
    #
    # Input:
    #    -
    # Expectation:
    #    -
    ie = ZDFChannelIE()
    assert ie.suitable(ZDFChannelIE._VALID_URL)
    assert not ie.suitable(ZDFIE._VALID_URL)


# Generated at 2022-06-18 15:20:59.660341
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:10.073807
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE
    from . import ZDFIE
    from . import YoutubeIE
    from . import YoutubePlaylistIE
    from . import YoutubeSearchIE
    from . import YoutubeShowIE
    from . import YoutubeSubtitlesIE
    from . import YoutubeUserIE
    from . import YoutubeUserVideosFeedIE
    from . import YoutubeWatchHistoryIE
    from . import YoutubeWatchLaterIE
    from . import YoutubeWatchVideosFeedIE
    from . import YoutubeSearchDateIE
    from . import YoutubeSearchURLIE
    from . import YoutubeSearchPlaylistIE
    from . import YoutubeSearchChannelIE
    from . import YoutubeSearchUsernameIE
    from . import YoutubeSearchChannelIE
    from . import YoutubeSearchUsernameIE
    from . import YoutubeSearchPlaylistIE
    from . import YoutubeSearchDateIE
    from . import YoutubeSearchURL

# Generated at 2022-06-18 15:22:09.700089
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-18 15:22:13.122696
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:17.146414
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:20.456519
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:30.332228
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key_map
    assert ie.ie_key() in ZDFIE.ie_key_map.values()
    assert ie.ie_key() in ZDFIE.ie_key_map.keys()
    assert ie.ie_key() in ZDFIE.ie_key_map.items()
    assert ie.ie_key() in ZDFIE.ie_key_map.__contains__
    assert ie.ie_key() in ZDFIE.ie_key_map.__iter__
    assert ie.ie_key() in ZDFIE.ie_key_map.__len__
    assert ie.ie_key() in ZDFIE.ie_key_map.__getitem

# Generated at 2022-06-18 15:22:38.568460
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:22:48.802040
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:22:51.473371
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:54.168911
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:58.880493
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:25:17.104783
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:25:18.244066
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_zdf import test_ZDFIE
    test_ZDFIE(ZDFChannelIE)

# Generated at 2022-06-18 15:25:20.641008
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:25:23.441466
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:25:25.306188
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(None)._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE(None)._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:25:26.224719
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:25:28.262049
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-18 15:25:30.948457
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:25:33.437028
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-18 15:25:35.902574
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
