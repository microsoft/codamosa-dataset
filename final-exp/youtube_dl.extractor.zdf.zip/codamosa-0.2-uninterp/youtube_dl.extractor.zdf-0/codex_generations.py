

# Generated at 2022-06-18 15:17:12.267528
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:17:24.726672
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie._VALID_URL == ZDFIE._VALID_URL
    assert ie._TESTS == ZDFIE._TESTS
    assert ie._GEO_COUNTRIES == ZDFIE._GEO_COUNTRIES
    assert ie._QUALITIES == ZDFIE._QUALITIES
    assert ie._call_api == ZDFIE._call_api
    assert ie._extract_subtitles == ZDFIE._extract_subtitles
    assert ie._extract_format == ZDFIE._extract_format
    assert ie._extract_ptmd == ZDFIE._extract_ptmd

# Generated at 2022-06-18 15:17:25.743210
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-18 15:17:31.554633
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/') == False
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e') == True
    assert zdf_channel_ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html') == False

# Generated at 2022-06-18 15:17:34.165906
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable(ZDFChannelIE._VALID_URL)
    assert not zdf_channel_ie.suitable(ZDFIE._VALID_URL)
    assert zdf_channel_ie.ie_key() == 'ZDF:channel'


# Generated at 2022-06-18 15:17:45.684759
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in globals()
    assert ie.ie_key() in dir(ZDFIE)
    assert ie.ie_key() in dir(globals()['ZDFIE'])
    assert ie.ie_key() in dir(globals()['ZDFIE']())
    assert ie.ie_key() in ZDFIE().ie_key()
    assert ie.ie_key() in ZDFIE().ie_keys()
    assert ie.ie_key() in ZDFIE().ie_key()
    assert ie.ie_key() in ZDFIE().ie

# Generated at 2022-06-18 15:17:50.716758
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

# Generated at 2022-06-18 15:17:51.300338
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-18 15:17:56.026524
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ie.extractor_key_map
    assert ie.extractor_key_map[ie.ie_key()] == ie.__class__


# Generated at 2022-06-18 15:17:57.753797
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor of class ZDFBaseIE
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:54.653785
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:01.401504
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test for constructor of class ZDFChannelIE
    #
    # Create an instance of ZDFChannelIE
    #
    # This does not require a network connection.
    ie = ZDFChannelIE()

    # Test for the method suitable
    #
    # This does not require a network connection.
    assert ie.suitable(ZDFChannelIE._VALID_URL) == True
    assert ie.suitable(ZDFIE._VALID_URL) == False


# Generated at 2022-06-18 15:19:05.768082
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:08.953909
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:14.874658
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')


# Generated at 2022-06-18 15:19:24.302784
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_

# Generated at 2022-06-18 15:19:26.955350
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-18 15:19:28.710009
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases
    for case in get_testcases(ZDFChannelIE, {
            '__main__': {
                'url': 'https://www.zdf.de/dokumentation/planet-e',
            },
        }):
        yield case

# Generated at 2022-06-18 15:19:37.223294
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:19:45.549432
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

# Generated at 2022-06-18 15:20:42.514680
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-18 15:20:52.584460
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    ie = ZDFChannelIE()
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.extract_id(url) == 'taunuskrimi'
    assert ie.extract_urls(url) == [url]
    assert ie.extract_title(url) == 'taunuskrimi'
    assert ie.extract_description(url) == None
    assert ie.extract_thumbnail(url) == None
    assert ie.extract_duration(url) == None
    assert ie.extract_timestamp(url) == None
    assert ie.extract_uploader(url) == None
    assert ie.extract_uploader_id

# Generated at 2022-06-18 15:20:59.320481
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:21:01.599696
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'


# Generated at 2022-06-18 15:21:04.826805
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:15.164322
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')

# Generated at 2022-06-18 15:21:22.520534
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUITES == [ZDFIE.ie_key()]
    assert ie.SUITES == ZDFIE.SUITES
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._GEO_COUNTRIES == ZDFBaseIE._GEO_COUNTRIES
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie._QUALITIES == ZDFBaseIE._QUALITIES

# Generated at 2022-06-18 15:21:26.013365
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable(ZDFChannelIE._VALID_URL)
    assert not zdf_channel_ie.suitable(ZDFIE._VALID_URL)


# Generated at 2022-06-18 15:21:36.117548
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.ie_key() == 'zdf'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'Zdf'
    assert ie.ie_key() == 'zDF'
    assert ie.ie_key() == 'zdF'
    assert ie.ie_key() == 'ZdF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_

# Generated at 2022-06-18 15:21:36.712612
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-18 15:23:42.097269
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:23:45.307967
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:23:53.680050
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:24:02.654117
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:24:10.268592
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

# Generated at 2022-06-18 15:24:11.094691
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-18 15:24:20.376149
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:24:24.141188
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.ie_key() == ZDFBaseIE.ie_key()


# Generated at 2022-06-18 15:24:26.578504
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:24:28.660718
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')