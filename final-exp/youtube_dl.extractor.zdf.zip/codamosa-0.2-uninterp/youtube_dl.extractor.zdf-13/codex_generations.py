

# Generated at 2022-06-18 15:17:13.439542
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors_by_class
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urljoin
    from youtube_dl.compat import compat_urllib_parse_urlsplit
    from youtube_dl.compat import compat_urllib_parse_urlunsplit
    from youtube_dl.compat import compat_

# Generated at 2022-06-18 15:17:14.400109
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:17:22.409134
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')

# Generated at 2022-06-18 15:17:24.584461
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:25.611273
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-18 15:17:28.592599
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:29.750334
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test for constructor of class ZDFIE
    ZDFIE()


# Generated at 2022-06-18 15:17:30.283361
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-18 15:17:36.355728
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    channel = ZDFChannelIE()
    assert channel.suitable(url)
    assert channel.ie_key() == 'ZDFChannel'
    assert channel._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert channel._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert channel._TESTS[0]['info_dict']['id'] == 'das-aktuelle-sportstudio'

# Generated at 2022-06-18 15:17:40.877015
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test for constructor of class ZDFChannelIE
    test_url = "https://www.zdf.de/dokumentation/planet-e"
    test_channel = ZDFChannelIE()
    assert test_channel.suitable(test_url)
    assert test_channel.ie_key() == "ZDFChannel"
    assert test_channel.ie_key() != "ZDF"
    assert test_channel.ie_key() != "ZDFMediathek"
    assert test_channel.ie_key() != "ZDFMobile"


# Generated at 2022-06-18 15:18:07.426392
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-18 15:18:10.368645
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:11.358169
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:18:16.250553
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test for the constructor of class ZDFChannelIE
    #
    # Input:
    #    -
    # Expectation:
    #    -
    ie = ZDFChannelIE()
    assert ie.suitable(ZDFChannelIE._VALID_URL)
    assert not ie.suitable(ZDFIE._VALID_URL)



# Generated at 2022-06-18 15:18:22.181233
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

# Generated at 2022-06-18 15:18:30.413677
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:18:34.213552
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:43.190219
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key_map
    assert ie.ie_key() in ZDFIE.ie_key_map.keys()
    assert ie.ie_key() in ZDFIE.ie_key_map.values()
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() in ZDFIE.ie_key_map
    assert ZDFIE.ie_key() in ZDFIE.ie_key_map.keys()
    assert ZDFIE.ie_key() in ZDFIE.ie_key_map.values()


# Generated at 2022-06-18 15:18:45.140084
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:18:46.333086
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_zdf import test_ZDFIE
    test_ZDFIE(ZDFChannelIE)

# Generated at 2022-06-18 15:19:41.303454
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:19:44.253703
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases
    for testcase in get_testcases(ZDFChannelIE, [{
        'url': 'https://www.zdf.de/dokumentation/planet-e',
        'playlist_mincount': 50,
    }]):
        yield testcase

# Generated at 2022-06-18 15:19:45.324486
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:19:55.177901
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.suitable()
    assert ie.ie_key() in ZDFIE.suitable(url='https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')

# Generated at 2022-06-18 15:20:01.864343
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:20:05.522331
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDFBase'
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie.ie_key() == 'ZDFIE'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDFBase'
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie.ie_key() == 'ZDFIE'


# Generated at 2022-06-18 15:20:10.020242
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:20:12.394551
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE(url)
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.channel_id == 'planet-e'
    assert ie.url == url
    assert ie.title == 'planet e.'

# Generated at 2022-06-18 15:20:13.218830
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-18 15:20:22.135733
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test with a channel URL
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE()
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.extract_id(url) == 'planet-e'
    assert ie.extract_url(url) == url
    assert ie.extract_title(url) == 'planet e.'
    assert ie.extract_description(url) == 'Planet e.'
    assert ie.extract_thumbnail(url) == 'https://www.zdf.de/assets/img/zdf-logo-fb-share.png'
    assert ie.extract_duration(url) == None
    assert ie.extract_timestamp(url) == None

# Generated at 2022-06-18 15:22:08.285373
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:13.476833
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.SUITES == ['http://zdf.de/rels/target']
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:19.854462
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')

# Generated at 2022-06-18 15:22:29.833713
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:22:38.210195
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_keys()
    assert ie.ie_key() in ZDFIE.ie_

# Generated at 2022-06-18 15:22:41.431167
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:51.168904
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.ie_key() in ZDFIE.ie_

# Generated at 2022-06-18 15:22:53.880286
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:22:58.529328
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:23:02.215207
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
