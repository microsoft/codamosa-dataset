

# Generated at 2022-06-18 15:16:57.621183
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:16:59.211970
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:17:12.470785
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:17:25.311425
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')

# Generated at 2022-06-18 15:17:28.305491
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:34.901635
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-18 15:17:39.772713
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test with a channel that has a video with a subtitle
    url = 'https://www.zdf.de/dokumentation/planet-e'
    zdf_channel_ie = ZDFChannelIE()
    zdf_channel_ie.suitable(url)
    zdf_channel_ie.extract(url)
    # Test with a channel that has a video without a subtitle
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    zdf_channel_ie = ZDFChannelIE()
    zdf_channel_ie.suitable(url)
    zdf_channel_ie.extract(url)

# Generated at 2022-06-18 15:17:42.868536
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test that ZDFChannelIE is not suitable for ZDFIE
    assert not ZDFChannelIE.suitable(ZDFIE._VALID_URL)
    # Test that ZDFChannelIE is suitable for ZDFChannelIE
    assert ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL)


# Generated at 2022-06-18 15:17:46.529251
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:17:58.113052
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:18:51.730890
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')

# Generated at 2022-06-18 15:18:55.007123
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:06.822980
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:19:10.096377
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:11.772053
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(ZDFChannelIE.ie_key(), ZDFChannelIE._VALID_URL)

# Generated at 2022-06-18 15:19:13.406006
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-18 15:19:15.910611
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:19.554849
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:19:20.517688
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-18 15:19:24.168675
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test for constructor of class ZDFChannelIE
    #
    # The constructor of class ZDFChannelIE should return an instance of class ZDFChannelIE
    #
    # Args:
    #     None
    #
    # Returns:
    #     An instance of class ZDFChannelIE
    #
    # Raises:
    #     None

    # Create an instance of class ZDFChannelIE
    zdf_channel_ie = ZDFChannelIE()

    # Test if the instance is an instance of class ZDFChannelIE
    assert isinstance(zdf_channel_ie, ZDFChannelIE)



# Generated at 2022-06-18 15:20:56.308659
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-18 15:21:01.702432
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test if ZDFChannelIE is suitable for given url
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    # Test if ZDFChannelIE is able to extract playlist
    assert ZDFChannelIE()._real_extract('https://www.zdf.de/dokumentation/planet-e')

# Generated at 2022-06-18 15:21:11.539817
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:21:16.269346
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()
    assert ie.ie_key() == ZDFBaseIE.ie_key()
    assert ie.ie_key() == InfoExtractor.ie_key()


# Generated at 2022-06-18 15:21:23.264336
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key_map
    assert ie.ie_key() in ZDFIE.ie_key_map.values()
    assert ie.ie_key() in ZDFIE.ie_key_map.keys()
    assert ie.ie_key() in ZDFIE.ie_key_map.items()
    assert ie.ie_key() in ZDFIE.ie_key_map.__contains__(ie.ie_key())
    assert ie.ie_key() in ZDFIE.ie_key_map.__contains__(ie.ie_key())
    assert ie.ie_key() in ZDFIE.ie_key_map.__contains__(ie.ie_key())

# Generated at 2022-06-18 15:21:26.265253
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:21:36.402319
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:21:38.605330
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-18 15:21:47.239317
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_url = 'https://www.zdf.de/dokumentation/planet-e'
    channel_id = 'planet-e'
    channel_title = 'planet e.'

# Generated at 2022-06-18 15:21:48.549655
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_zdf import test_ZDFIE
    test_ZDFIE(ZDFChannelIE)

# Generated at 2022-06-18 15:25:28.982424
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-18 15:25:33.607025
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:25:36.588693
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:25:38.728963
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:25:43.809910
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio/das-aktuelle-sportstudio-vom-11-april-2020-100.html')

# Generated at 2022-06-18 15:25:45.998432
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ZDFChannelIE.suitable(url)
    ZDFChannelIE.ie_key()
    ZDFChannelIE.ie(ZDFChannelIE.ie_key())
    ZDFChannelIE.working()
    ZDFChannelIE.get_info(url)


# Generated at 2022-06-18 15:25:50.108548
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor of class ZDFBaseIE
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-18 15:25:57.489854
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-18 15:26:05.362928
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-18 15:26:11.249373
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')