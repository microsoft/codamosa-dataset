

# Generated at 2022-06-22 09:01:00.284580
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest

    class TestZDFChannel(unittest.TestCase):
        def test_constructor(self):
            obj = ZDFChannelIE(ZDFChannelIE.create_ie_key())
            assert obj.ie_key() == ZDFChannelIE.ie_key()
            assert obj.suitable(ZDFChannelIE._VALID_URL) == True
            assert obj.suitable(ZDFIE._VALID_URL) == False
            assert obj.suitable('https://www.zdf.de/sendungen/frontal-21/frontal-21-vom-21-mai-2019-100.html') == False

    suite = unittest.TestLoader().loadTestsFromTestCase(TestZDFChannel)
    unittest.TextTestRunner().run(suite)



# Generated at 2022-06-22 09:01:08.503331
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ZDFIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert ie._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert ie._T

# Generated at 2022-06-22 09:01:10.265408
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE.ie_key() == 'ZDF'

# Generated at 2022-06-22 09:01:12.726948
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdff = ZDFIE()
    assert zdff is not None


# Generated at 2022-06-22 09:01:21.446638
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase = ZDFBaseIE()
    assert zdfbase._call_api("https://api.zdf.de/content/documents/",
                             "24394514", "metadata")

# Generated at 2022-06-22 09:01:30.331618
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfie = ZDFBaseIE()
    zdfie._call_api("", "", "")
    zdfie._extract_subtitles(None)
    zdfie._extract_format("", [], orderedSet(), None)
    zdfie._extract_ptmd("", "", None, None)
    zdfie._extract_player("", "")
    zdfie._extract_player("", "", fatal=False)
# end of test_ZDFBaseIE



# Generated at 2022-06-22 09:01:33.152998
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-22 09:01:38.582512
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_obj = ZDFBaseIE()
    from ..compat import compat_str
    assert_equals(zdf_obj._GEO_COUNTRIES, ['DE'])
    assert_equals(zdf_obj._QUALITIES, ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))



# Generated at 2022-06-22 09:01:43.002486
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_id = 'das-aktuelle-sportstudio'
    channel_url = 'https://www.zdf.de/sport/' + channel_id
    assert ZDFChannelIE.suitable(channel_url)
    assert ZDFIE.suitable(channel_url) == False

    entry_urls = set()
    r = ZDFChannelIE._real_extract(ZDFChannelIE(), channel_url)
    assert r['id'] == channel_id
    assert r['title'] == channel_id + ' | ZDF'
    for e in r['entries']:
        assert e['id'] not in entry_urls
        entry_urls.add(e['id'])

        item_url = e['url']
        assert ZDFIE.suitable(item_url)

# Generated at 2022-06-22 09:01:47.168003
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBaseIE = ZDFBaseIE("http://www.zdf.de/ZDFmediathek/index", "http://zdf.de", "http://zdf.de/ZDFmediathek/index/titel", "http://www.zdf.de/ZDFmediathek/index/titel")

# Generated at 2022-06-22 09:02:14.599865
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None)
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:02:15.530701
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()

# Generated at 2022-06-22 09:02:23.103730
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test if constructor of class ZDFIE doesn't change
    # from https://github.com/rg3/youtube-dl/pull/10452/
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    z = ZDFIE._build_url_result(ZDFIE._VALID_URL, url)
    assert z.id == '151025_magie_farben2_tex'
    assert z.groupdict['id'] == '151025_magie_farben2_tex'


# Generated at 2022-06-22 09:02:34.361342
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    if not hasattr(ZDFChannelIE, '_real_extract'):
        return

    # 2nd argument is playlist's title, the rest are URLs of items in the playlist

# Generated at 2022-06-22 09:02:36.447163
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_instance = ZDFIE()
    assert "ngplayer_2_4" in zdf_instance.get_content.__doc__


# Generated at 2022-06-22 09:02:44.774020
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE('https://www.zdf.de/.*')
    assert zdf.ie_key() == 'ZDF'
    assert zdf.SUITABLE_URL == ZDFChannelIE._VALID_URL
    assert zdf.SUITABLE == ZDFChannelIE.suitable
    assert zdf.WEBPAGE_URL_TEMPLATE == 'https://www.zdf.de/dokumentation/planet-e'
    assert zdf.IE_NAME == 'ZDF'
    assert zdf.channel_id == 'planet-e'
    assert zdf.url == 'https://www.zdf.de/dokumentation/planet-e'
    assert zdf.player_url == 'https://www.zdf.de/.*'
    assert zdf._TEST == {}

# Generated at 2022-06-22 09:02:47.962438
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    site_instance = ZDFChannelIE()
    assert (site_instance.suitable('https://www.zdf.de/dokumentation/planet-e'))

# Generated at 2022-06-22 09:02:52.054412
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE(None)
    assert inst._GEO_COUNTRIES == ['DE']
    assert inst._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:02:52.852297
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:02:54.018977
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()



# Generated at 2022-06-22 09:03:21.042087
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    c = ZDFChannelIE()
    assert c.suitable("https://www.zdf.de/dokumentation/planet-e")
    assert c.suitable("https://www.zdf.de/dokumentation/planet-e.html")

# Generated at 2022-06-22 09:03:28.323231
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_cases = [
        ('https://www.zdf.de/sport/das-aktuelle-sportstudio'),
        ('https://www.zdf.de/dokumentation/planet-e'),
        ('https://www.zdf.de/filme/taunuskrimi/'), # Only for coverage
    ]

    for url in test_cases:
        zdf_channel = get_info_extractor(url)
        assert isinstance(zdf_channel, ZDFChannelIE)
        assert zdf_channel.suitable(url)
        assert zdf_channel.ie_key() == 'ZDF:channel'

# Generated at 2022-06-22 09:03:35.221963
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    info_extractor = ZDFIE()
    parser = info_extractor._search_regex
    assert(parser('(?is)(parser)(.*)(?=example regexp)','parser is used for parsing example regexp','parser') == 'parser is used for parsing')
    assert(parser('(?is)(parser)(.*)(?=example regexp)','parser is used for parsing example regexp','string') == None)


# Generated at 2022-06-22 09:03:41.579558
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE()
    assert zdf_base._GEO_COUNTRIES == ['DE'] and zdf_base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Unit tests for _extract_ptmd

# Generated at 2022-06-22 09:03:47.352393
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test creating instance of class ZDFBaseIE"""
    # run
    zdf_base_ie = ZDFBaseIE()
    # check
    assert zdf_base_ie


# Generated at 2022-06-22 09:03:50.544226
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Basic test case to check the constructor of class ZDFBaseIE
    """
    ZDFBaseIE("ZDFBaseIE", "zdf.de", False)


# Generated at 2022-06-22 09:03:54.071629
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable('https://www.zdf.de/live-tv/zdf/heute')


# Generated at 2022-06-22 09:04:01.169453
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE._build_extractors_table()
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')


# Generated at 2022-06-22 09:04:09.631683
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-22 09:04:18.720801
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfie = ZDFIE('https://www.zdf.de/nachrichten/heute-plus/heute-plus-vom-18-11-2019-100.html')
    zdfie = ZDFIE('https://www.zdf.de/filme/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')


# Generated at 2022-06-22 09:05:17.603577
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.utils import ExtractorError
    
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'

# Generated at 2022-06-22 09:05:22.673241
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert isinstance(
        zdf_channel.suitable('https://www.zdf.de/filme/taunuskrimi/'),
        bool)


# Generated at 2022-06-22 09:05:33.183731
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    channel_id = re.match(ZDFChannelIE._VALID_URL, url).group('id')
    webpage = str(get_testdata_file('sportstudio.txt', encoding='iso-8859-1'))
    channel = ZDFChannelIE(ZDFChannelIE.suitable(url))
    entries = channel._real_extract(url)

# Generated at 2022-06-22 09:05:37.890782
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Constructor test
    """
    ie = ZDFBaseIE()
    assert(ie._GEO_COUNTRIES == ['DE'])
    assert(ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-22 09:05:42.339037
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zb = ZDFBaseIE()
    assert zb._GEO_COUNTRIES == ['DE']
    assert zb._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    return zb


# Generated at 2022-06-22 09:05:53.202447
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    class ZDF_IE_Constructor(ZDFIE):
        _VALID_URL = r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    ZDF_IE_Constructor().download('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')
    ZDF_IE_Constructor().download('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')

# Generated at 2022-06-22 09:05:56.935877
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    zdf = ZDFChannelIE()
    assert zdf.suitable(url)

# Generated at 2022-06-22 09:06:02.256919
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert hasattr(ie, '_GEO_COUNTRIES')
    assert hasattr(ie, '_QUALITIES')

    assert callable(ie._extract_subtitles)
    assert callable(ie._extract_format)
    assert callable(ie._extract_ptmd)
    assert callable(ie._extract_player)


# Generated at 2022-06-22 09:06:03.290789
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_instance = ZDFIE()

# Generated at 2022-06-22 09:06:09.217566
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl import YoutubeDL
    from .zdf_mediathek import ZDFMediathekIE
    zdf_channel_ie = ZDFChannelIE()
    ydl_obj = YoutubeDL(zdf_channel_ie.extractor_key)
    assert "zdf_channel" == zdf_channel_ie.ie_key()
    assert zdf_channel_ie == ydl_obj.get_info_extractor(zdf_channel_ie.ie_key())
    assert "zdf_mediathek" == ZDFMediathekIE.ie_key()
    assert ZDFMediathekIE == ydl_obj.get_info_extractor(ZDFMediathekIE.ie_key())

# Generated at 2022-06-22 09:07:47.383689
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # ZDFBaseIE(self, ie_key, ie_name, *args, **kwargs)
    assert ZDFIE.ie_key() == 'zdf'
    assert ZDFIE.ie_name() == 'ZDF'


# Generated at 2022-06-22 09:07:55.906890
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ZDFIE()._TESTS
    assert ZDFIE()._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert ZDFIE()._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'

# Generated at 2022-06-22 09:08:00.874735
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    x = ZDFIE()
    assert x.ie_key() == 'ZDF'
    assert x.ie_key() in ZDFIE._ies
    assert ZDFIE.ie_key() in ZDFIE._ies



# Generated at 2022-06-22 09:08:07.711082
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    c = ZDFBaseIE()
    assert c._GEO_COUNTRIES == ['DE']
    assert c._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert callable(c._extract_subtitles)
    assert callable(c._extract_format)
    assert callable(c._extract_ptmd)
    assert callable(c._extract_player)


# Generated at 2022-06-22 09:08:12.198863
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test = ZDFIE(None)
    assert test._GEO_COUNTRIES == ['DE']
    assert test._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert test._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'



# Generated at 2022-06-22 09:08:23.082181
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-22 09:08:28.418669
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    IE = ZDFBaseIE(InfoExtractor())
    assert IE._GEO_COUNTRIES == ['DE']
    assert IE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:08:36.868237
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    i = ZDFIE(None)
    assert i._VALID_URL == "https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html"

# Generated at 2022-06-22 09:08:37.879407
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(None, None)


# Generated at 2022-06-22 09:08:42.034170
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ZDFIE()._TESTS != []