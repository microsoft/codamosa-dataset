

# Generated at 2022-06-22 09:00:48.283025
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:01:00.421286
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():

    zdf_channel_ie = ZDFChannelIE.__new__(ZDFChannelIE)

    assert zdf_channel_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 09:01:02.911216
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_object = ZDFIE()
    assert isinstance(test_object, ZDFIE)
# Unit test 2 for constructor of class ZDFIE

# Generated at 2022-06-22 09:01:06.198307
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    run all tests
    """
    unittest.main()

if __name__ == '__main__':
    """
    run all tests
    """
    test_ZDFChannelIE()

# Generated at 2022-06-22 09:01:07.781286
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')


# Generated at 2022-06-22 09:01:09.088571
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None)


# Generated at 2022-06-22 09:01:13.954701
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    with warnings.catch_warnings(record=True) as w:
        ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
        assert len(w) == 1
        assert str(w[0].message) == 'zdf exposed issue #3565'

# Generated at 2022-06-22 09:01:22.141306
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from ..compat import compat_urllib_request
    from ..utils import url_basename
    from .common import InfoExtractor
    from .zdf import ZDFIE

    uri = 'https://www.zdf.de/dokumentation/planet-e/planet-e-100.html'
    webpage = compat_urllib_request.urlopen(uri).read()
    ie = ZDFBaseIE()

    assert ie is not None
    assert ie.SUFFIX == 'ZDF'
    assert ie.ie_key() == 'zdf'
    assert ie.BASE_URL == 'https://api.zdf.de'
    assert ie._GEO_COUNTRIES == ['DE']

# Generated at 2022-06-22 09:01:30.973244
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE(None)
    assert zdfChannelIE is not None
    assert zdfChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e') == True
    assert zdfChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/') == True
    assert zdfChannelIE.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html') == False

# Generated at 2022-06-22 09:01:36.048093
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    class_name = 'ZDFIE'
    # class_name = 'ZDFBaseIE'
    # class_name = 'ZDFKeenIE'
    tmp_instance = globals()[class_name]()
    tmp_instance.extract('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html')

if __name__ == '__main__':
    test_ZDFIE()



# Generated at 2022-06-22 09:02:00.503614
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor of class ZDFBaseIE
    ie = ZDFBaseIE("test", "test")
    assert ie.name == "ZDF Base"



# Generated at 2022-06-22 09:02:13.030822
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE("https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandmime-100.html")
    assert isinstance(zdfie, ZDFIE)
    assert zdfie.mobile_app == False
    assert zdfie.player_id == False
    assert zdfie._extract_ptmd("https://zdf-cdn.live.cellular.de/mediathekV2/document/210222_phx_nachgehakt_corona_protest", "210222_phx_nachgehakt_corona_protest", None, None)

# Generated at 2022-06-22 09:02:17.517332
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie._download_webpage(
        'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html', '210222_phx_nachgehakt_corona_protest')

# Generated at 2022-06-22 09:02:19.770089
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE._search_regex('', '', '')     # pylint: disable=protected-access
    assert qualities(['low', 'med'])('high') == -1


# Generated at 2022-06-22 09:02:24.028707
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Assert that the constructor of class ZDFChannelIE
    # raises an error when the URL points to a video
    with pytest.raises(ExtractorError):
        ZDFChannelIE().suitable("https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html")


# Generated at 2022-06-22 09:02:25.336366
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert type(ie) == ZDFIE


# Generated at 2022-06-22 09:02:26.922026
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
  import doctest
  doctest.testmod()


# Generated at 2022-06-22 09:02:29.287415
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Create an instance of class ZDFChannelIE and print its __doc__.
    print(ZDFChannelIE.__doc__)



# Generated at 2022-06-22 09:02:31.178323
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    constructor_test(
        'ZDFBaseIE',
        ie = ZDFBaseIE
    )


# Generated at 2022-06-22 09:02:34.657926
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    obj = ZDFChannelIE().construct_from_url(
        'https://www.zdf.de/dokumentation/planet-e')
    assert obj.channel_id == 'planet-e' and obj.channel == None



# Generated at 2022-06-22 09:02:57.215775
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert _test_class_get_set(ZDFChannelIE, 'url', 'https://www.zdf.de/dokumentation/planet-e')

# Generated at 2022-06-22 09:03:07.776749
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # 1. Test URL: https://www.zdf.de/filme/taunuskrimi/
    url = "https://www.zdf.de/filme/taunuskrimi/"
    channel_id = "taunuskrimi"
    webpage = '<body xmlns:zdf="http://zdf.de/" data-plusbar-url="https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html" class=" m-taunuskrimi">'
    webpage = webpage + '</body>'
    channel = ZDFChannelIE(url=url)
    channel.extract(webpage=webpage)
    assert channel.playlist_result()['id'] == channel

# Generated at 2022-06-22 09:03:15.444458
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_url = 'https://www.zdf.de/dokumentation/planet-e'

    channel_page_tree = extract_page_tree(request(channel_url))
    channel = ZDFChannelIE(channel_page_tree)

    assert channel.name == 'zdf:channel'
    assert channel.channel_id == 'planet-e'
    assert channel.channel_url == channel_url
    assert channel.channel_title == 'planet e.'
    assert channel.channel_page_tree == channel_page_tree


# Generated at 2022-06-22 09:03:19.792296
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    a = ZDFIE()
    assert(isinstance(a._VALID_URL, str))
    assert(isinstance(a._GEO_COUNTRIES, list))
    assert(isinstance(a._QUALITIES, list))


# Generated at 2022-06-22 09:03:24.964845
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    print("\nTesting ZDFChannelIE() constructor...")
    print("\tUnit test for '__init__()' passed!\n")



# Generated at 2022-06-22 09:03:28.748595
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'



# Generated at 2022-06-22 09:03:33.492394
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print(ZDFChannelIE().suitable('https://www.zdf.de/filme/taunuskrimi/'))
    print(ZDFChannelIE().suitable('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html'))

# Generated at 2022-06-22 09:03:39.753076
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(ZDFIE()._GEO_COUNTRIES == ['DE'])
    assert(ZDFIE()._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-22 09:03:41.572324
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFBaseIE()
    assert isinstance(zdfie, InfoExtractor)


# Generated at 2022-06-22 09:03:54.749244
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfe = ZDFChannelIE('https://www.zdf.de')
    assert zdfe.name == 'ZDF'
    assert zdfe.description == 'Zweites Deutsches Fernsehen'
    assert zdfe.suitable('https://www.zdf.de/dokumentation/planet-e') is True
    assert zdfe.suitable('https://www.zdf.de/filme/taunuskrimi/falsche-spuren-1---ein-taunuskrimi-100.html') is False
    assert zdfe.suitable('https://www.3sat.de/film/spielfilm/der-hauptmann-100.html') is False

# Generated at 2022-06-22 09:04:17.850175
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # pylint: disable =E0602, E0102
    ZDFIE()


# Generated at 2022-06-22 09:04:18.599133
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
	zdfBase = ZDFBaseIE()


# Generated at 2022-06-22 09:04:20.108478
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdbe = ZDFBaseIE()
    assert zdbe is not None


# Generated at 2022-06-22 09:04:23.990417
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    player = ZDFBaseIE()._extract_player('', '', False)
    assert player == {}, 'Invalid constructor for class ZDFBaseIE'


# Generated at 2022-06-22 09:04:27.152098
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE("example.com")
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:04:29.038124
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:04:31.876356
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdbase = ZDFBaseIE()
    assert zdbase
    assert zdbase.__class__.__name__ == 'ZDFBaseIE'


# Generated at 2022-06-22 09:04:39.984944
# Unit test for constructor of class ZDFIE
def test_ZDFIE():   
    url = "https://www.zdf.de/kinder/logo/was-ist-was-junior-die-geheimnisse-der-burgen-100.html"
    video_id = "logo_wasistwasjunior_diegeheimnissecond"
    # url = "https://www.zdf.de/kinder/logo/logo-uebersichtsseite-weitere-abenteuer-mit-logo-100.html"
    # video_id = "logo_logo_uebersichtsseite_weitereabenteuerm"
    webpage = "Test"    
    video_webpage = ZDFIE(ZDFBaseIE)._download_webpage(url, video_id, fatal=False)

# Generated at 2022-06-22 09:04:51.709435
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE = ZDFIE()
    assert ZDFIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-22 09:04:57.054374
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class TestZDFBaseIE(ZDFBaseIE):
        _VALID_URL = "%s.zdf.de/%s"
        _TEST = {
            "url": "https://www.wiso.zdf.de/sendung/wiso/sendung-vom-16-11-2015-100.html",
            "info_dict": {
                "id": "100",
            }
        }
    return TestZDFBaseIE


# Generated at 2022-06-22 09:05:45.851011
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = 'https://www.zdf.de/dokumentation/planet-e'
    channel_id = 'planet-e'
    ie = ZDFChannelIE(channel)
    assert ie.suitable(channel)
    webpage = ie._download_webpage(channel, channel_id)
    assert isinstance(webpage, compat_str)
    assert ie._match_id(channel) == channel_id
    assert ie._real_extract(channel)['_type'] == 'playlist'

# Generated at 2022-06-22 09:05:56.197663
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    x = ZDFChannelIE()
    print(x)
    #assert x.suitable('https://www.zdf.de/kinder')
    #assert x.suitable('https://www.zdf.de/kinder')
    #assert x.suitable('https://www.zdf.de/dokumentation/planet-e')
    #assert x.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    #assert x.suitable('https://www.zdf.de/serien/helen-dorn/helen-dorn---fahnenflucht-100.html')
    #assert x.suitable('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html

# Generated at 2022-06-22 09:05:59.710387
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:06:04.696905
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE.__bases__ == (InfoExtractor,)
    assert ZDFBaseIE.ie_key() == 'zdf'
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:06:16.100902
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    # We want a 'dict' type object
    assert isinstance(ie._TEST, dict)
    # It should have a key 'input_urls' under the 'test_videos' key
    assert 'input_urls' in ie._TEST['test_videos'][0]
    # It should have an entry with 'zdf.de' domain in hostname
    assert 'zdf.de' in ie._TEST['test_videos'][0]['input_urls'][0]
    # It should be a 'str' type object
    assert isinstance(ie._TEST['test_videos'][0]['input_urls'][0], compat_str)

# Generated at 2022-06-22 09:06:26.091211
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import zdf
    from . import zdfie

    zdf_channel_ie = zdf.ZDFChannelIE()
    zdf_ie = zdfie.ZDFIE()
    assert zdf_channel_ie is not zdf_ie
    assert zdf_channel_ie.ie_key() == zdf_ie.ie_key()
    assert not zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/')



# Generated at 2022-06-22 09:06:27.005125
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert issubclass(ZDFIE, ZDFBaseIE)


# Generated at 2022-06-22 09:06:29.260828
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() == 'ZDF'


# Generated at 2022-06-22 09:06:32.320790
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFIE()
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-22 09:06:44.041817
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    global ZDFIE
    video_id = '210222_phx_nachgehakt_corona_protest'
    assert ZDFIE._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ZDFIE._GEO_COUNTRIES == ['DE']
    assert ZDFIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ZDFIE.ie_key() == 'ZDF'

# Generated at 2022-06-22 09:07:30.114158
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE(None)

    for method in ('_call_api', '_extract_subtitles', '_extract_format', '_extract_ptmd', '_extract_player'):
        assert hasattr(obj, method)



# Generated at 2022-06-22 09:07:32.267059
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE(None, None)
    except TypeError as e:
        assert "abstract class" in str(e)


# Generated at 2022-06-22 09:07:33.266333
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # TODO: add test
    pass


# Generated at 2022-06-22 09:07:37.848546
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFIE.suitable(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio') is False
    assert ZDFChannelIE.suitable(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio') is True

# Generated at 2022-06-22 09:07:38.793915
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-22 09:07:43.087153
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-22 09:07:50.596321
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()._call_api('https://api.zdf.de/', '', '')

    assert(ZDFBaseIE._GEO_COUNTRIES[0] == 'DE')

    assert(ZDFBaseIE._QUALITIES[0] == 'auto')
    assert(ZDFBaseIE._QUALITIES[1] == 'low')
    assert(ZDFBaseIE._QUALITIES[2] == 'med')
    assert(ZDFBaseIE._QUALITIES[3] == 'high')
    assert(ZDFBaseIE._QUALITIES[4] == 'veryhigh')
    assert(ZDFBaseIE._QUALITIES[5] == 'hd')


# Generated at 2022-06-22 09:07:54.093285
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannelie = ZDFChannelIE()
    assert zdfchannelie.suitable('https://www.zdf.de/foo/bar')
    assert not zdfchannelie.suitable('https://www.zdf.de/bar/foo.html')



# Generated at 2022-06-22 09:08:07.036861
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    video_id = '151025_magie_farben2_tex'

# Generated at 2022-06-22 09:08:09.933572
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_ZDFChannel = ZDFChannelIE().suitable('https://www.zdf.de/dokumentation/planet-e')
    assert test_ZDFChannel is True

# Generated at 2022-06-22 09:09:09.453678
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._extract_ptmd("http://www.zdfmediathek.de/zdf/content/1234", '1234', '123', 'http://www.zdf.de') is not None


# Generated at 2022-06-22 09:09:10.512697
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # There is nothing to check
    assert True



# Generated at 2022-06-22 09:09:18.947766
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # This ZDFChannelIE object has been created by running the command below.
    ZDFChannelIE_obj = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    # Following command will extract the URLs from the data obtained from the
    # webpage as mentioned above. These URLs are passed to the function
    # playlist_result.
    entries = ZDFChannelIE_obj.extract_entries()
    # The items of the playlist will be extracted from playlist_result.
    for item in entries:
        print(item)



# Generated at 2022-06-22 09:09:30.213778
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    import sys
    import os
    import unittest
    from unittest import mock

    class MockZDFBaseIE(ZDFBaseIE):
        def _real_extract(self, url):
            pass

    class MockZDFIE(ZDFIE):
        def _real_extract(self, url):
            pass

    sys.modules[__name__] = MockZDFBaseIE
    sys.modules[__name__] = MockZDFIE
    os.environ['COUNTRY'] = 'DE'

    video_id = '210222_phx_nachgehakt_corona_protest'

# Generated at 2022-06-22 09:09:35.802477
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert isinstance(zdfie._VALID_URL, str)
    assert isinstance(zdfie._TESTS, list)
    assert isinstance(zdfie._player_cache, dict)
    assert isinstance(zdfie._player_cache_lock, object)
    assert zdfie._player_cache == {}


# Generated at 2022-06-22 09:09:37.234822
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'



# Generated at 2022-06-22 09:09:38.349086
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:09:48.696555
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test URL for channel
    url = 'https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html'
    # Expected output when running extractor with test URL
    expected = {'_type': 'url_transparent', 'ie_key': 'ZDF', 'url': 'https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html', 'id': '115553_zdfmediathek'}
    # Extract video with test URL
    video = ZDFIE()._real_extract(url)
    # Check if test URL resulted in expected output
    assert(video == expected)

# Unit test

# Generated at 2022-06-22 09:09:55.495328
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    p = ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert p == True
    p = ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/')
    assert p == True
    p = ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert p == False
    p = ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100')


# Generated at 2022-06-22 09:09:56.297629
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()
