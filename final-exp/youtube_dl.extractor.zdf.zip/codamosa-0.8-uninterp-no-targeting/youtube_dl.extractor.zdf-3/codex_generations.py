

# Generated at 2022-06-22 09:00:49.635567
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    res = ZDFIE._VALID_URL
    print(res)



# Generated at 2022-06-22 09:00:54.194186
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(downloader=None)
    assert ie.downloader is downloader


# No tests for ZDFIE.ie_key
# No tests for ZDFIE.ie_docs


# Generated at 2022-06-22 09:00:57.182693
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    x = ZDFIE()
    # Check if _VALID_URL and _TESTS is not None
    assert x._VALID_URL is not None and  x._TESTS is not None


# Generated at 2022-06-22 09:01:02.315447
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Exception should be raised if URLs do not have the pattern /(?:[^/]+/)*(?P<id>[^/?#&]+)
    with pytest.raises(Exception):
            ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio/123.html')

# Generated at 2022-06-22 09:01:04.226648
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('http://www.zdf.de/')



# Generated at 2022-06-22 09:01:07.250806
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:01:11.543766
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfIE = ZDFBaseIE()
    assert zdfIE._GEO_COUNTRIES == ['DE']
    assert zdfIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:01:16.898006
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfie = ZDFBaseIE('ZDFBaseIE', 'zdf.de')
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdfie._call_api('http://www.zdf.de', 'foo', 'bar') is not NO_DEFAULT


# Generated at 2022-06-22 09:01:19.316658
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    a = ZDFIE()
    print(a)

if __name__ == '__main__':
    test_ZDFIE()

# Generated at 2022-06-22 09:01:33.322352
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    import unittest
    from .common import FakeYDL
    from .test_youtube import FakeHttpResponse
    from .test_youtube import match_id
    from .test_youtube import parse_duration
    from .test_youtube import parse_iso8601
    from .test_youtube import unified_timestamp
    from .test_youtube import try_get
    from .test_youtube import urljoin
    from .test_youtube import url_or_none
    from .test_youtube import qualities
    from .test_youtube import NO_DEFAULT
    from .test_youtube import orderedSet
    from .test_youtube import update_url_query
    from .test_youtube import try_get
    from ..compat import compat_str

# Generated at 2022-06-22 09:02:01.686737
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    assert ZDFChannelIE.suitable(url)
    ie = ZDFChannelIE()
    ie.extract(url)
    assert len(ie._entries) > 0

# Generated at 2022-06-22 09:02:12.320750
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .zdf import ZDFBaseIE
    from ..utils import extract_attributes
    assert ZDFBaseIE.__name__ == 'ZDFBaseIE'
    assert ZDFBaseIE.ie_key() == 'zdf'
    assert ZDFBaseIE.test('https://ly.zdf.de/8Wc/').get('url') == 'https://ly.zdf.de/8Wc/'
    assert ZDFBaseIE.test('https://www.zdf.de/comedy/heute-show/heute-show-vom-2-november-2018-100.html', {}).get('url') == 'https://www.zdf.de/comedy/heute-show/heute-show-vom-2-november-2018-100.html'

# Generated at 2022-06-22 09:02:13.308053
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass


# Generated at 2022-06-22 09:02:19.452455
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    # This should not raise an error.
    ie.suitable(ie.VALID_URL)
    # This should not raise an error.
    ie.suitable(ZDFIE.VALID_URL)
    # This should raise an error.
    try:
        ie.suitable('https://www.example.com')
        raise Exception('URL is not valid, but this raised no error.')
    except:
        pass


# Generated at 2022-06-22 09:02:27.019399
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .zdf import ZDFIE
    from ..utils import url_basename

    ie = ZDFBaseIE(ZDFIE.ie_key())
    assert ie
    assert ie.IE_NAME == ZDFIE.ie_key()
    assert ie._VALID_URL == ZDFIE._VALID_URL
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    res = ie._extract_player(b'<html><body></body></html>', 0, True)
    assert res == {}
    res = ie._extract_subtitles({})
    assert res == {}


# Generated at 2022-06-22 09:02:33.503596
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE()
    assert inst._GEO_COUNTRIES == [u'DE']
    assert inst._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:02:36.908621
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    InfoExtractor.test_extract(ZDFBaseIE(), urls=['https://zdf.de/mediathek/'])



# Generated at 2022-06-22 09:02:42.800678
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    search_key = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie = ZDFChannelIE(search_key, {})
    assert ie._match_id(search_key) == 'das-aktuelle-sportstudio'
    # ie._real_extract(search_key) should run for more than a minute
    assert ie.extract_id(search_key) == 'das-aktuelle-sportstudio'


# Generated at 2022-06-22 09:02:48.491088
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    run this code by:
    1. $ cd ..
    2. $ PYTHONPATH=. ./youtube_dl/__main__.py 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    """
    this_module = sys.modules[__name__]
    this_class = getattr(this_module, 'ZDFChannelIE')
    this_instance = this_class()

# Generated at 2022-06-22 09:02:50.777812
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert isinstance(ie, ZDFBaseIE)


# Generated at 2022-06-22 09:03:39.828413
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html'
    extractor = ZDFIE()
    assert extractor._real_extract(url) is not None



# Generated at 2022-06-22 09:03:42.397459
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """ test if initializing works """
    ie = ZDFBaseIE('ZDF')
    assert ie is not None
    assert isinstance(ie, ZDFBaseIE)
    return


# Generated at 2022-06-22 09:03:43.759978
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()
    print("test_ZDFIE finished!")

# Generated at 2022-06-22 09:03:45.733884
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(None, None)



# Generated at 2022-06-22 09:03:47.060572
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:03:51.801980
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # test for class constructor
    ie = ZDFBaseIE()
    assert ie.geo_countries == ['DE']
    assert ie.max_downloads == 0
    assert ie.ie_key() == 'zdf'
    assert ie.ie_name() == 'ZDF'


# Generated at 2022-06-22 09:04:03.214756
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    player = {
        'apiToken': 'foo',
        'content': 'https://api.zdf.de/content/documents/bar.json?profile=player',
    }
    channel_id = 'das-aktuelle-sportstudio'

# Generated at 2022-06-22 09:04:05.771073
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor of class ZDFBaseIE
    ie = ZDFBaseIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, ZDFBaseIE)



# Generated at 2022-06-22 09:04:12.342795
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi'
    ie = ZDFChannelIE()
    # Check if it is initialized correctly
    assert ie.name == 'zdf.de:channel'
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDF'
    assert ie.format_id(url) == 'taunuskrimi'
    # Test extract_id()
    assert ie.extract_id(url) == 'taunuskrimi'



# Generated at 2022-06-22 09:04:14.349089
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Basic test for constructor
    ie = ZDFBaseIE()


# Generated at 2022-06-22 09:05:46.176394
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_object = ZDFIE(None)
    assert zdf_object.ie_key() == "ZDF"


# Generated at 2022-06-22 09:05:52.001790
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannelie = ZDFChannelIE()
    # test with valid URL of a ZDF channel
    zdfchannelie.suitable(test_ZDFChannelIE.__dict__['_TESTS'][0]['url'])
    # test with valid URL of a ZDF programme
    zdfchannelie.suitable(test_ZDFIE.__dict__['_TESTS'][0]['url'])

# Generated at 2022-06-22 09:05:56.068931
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('ZDFChannel', 'https://www.zdf.de/sport/das-aktuelle-sportstudio')._real_extract(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    )

# Generated at 2022-06-22 09:05:57.262545
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()



# Generated at 2022-06-22 09:05:58.959938
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert (ZDFBaseIE.__name__ == "ZDFBaseIE") == True


# Generated at 2022-06-22 09:06:01.760615
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE(ZDFIE())
    assert zdf_base_ie._downloader is not None



# Generated at 2022-06-22 09:06:03.942506
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    main_url = 'https://www.zdf.de/dokumentation/planet-e'
    assert ZDFChannelIE.suitable(main_url)



# Generated at 2022-06-22 09:06:10.400316
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(None)._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE(None)._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-22 09:06:11.836262
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
  zdf = ZDFIE()
  assert zdf


# Generated at 2022-06-22 09:06:17.237114
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/serie/wilsberg'
    zdf_channel_ie = ZDFChannelIE()
    zdf_channel_ie._download_webpage = lambda url, video_id: None
    assert zdf_channel_ie.suitable(url)
    assert zdf_channel_ie.ie_key() == 'ZDF:channel'



# Generated at 2022-06-22 09:09:32.962447
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    extractor = ZDFIE()
    assert extractor.__class__.__name__ == 'ZDFIE'
    assert extractor._GEO_COUNTRIES == ['DE']
    assert extractor._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:09:39.350430
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    iframe_url = "https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html"
    ie = ZDFIE()
    ie.url_result(iframe_url, "ZDF")



# Generated at 2022-06-22 09:09:42.125049
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE('ZDF', 'www.zdf.de')

# Generated at 2022-06-22 09:09:52.438139
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-22 09:09:53.997387
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-22 09:09:58.890313
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    inst = ZDFChannelIE()
    result = inst._real_extract('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert result['_type'] == 'playlist'
    assert len(result['entries']) > 0
    for entry in result['entries']:
        assert entry['_type'] == 'url'
        assert ZDFIE.suitable(entry['url'])

# Generated at 2022-06-22 09:10:08.371385
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert hasattr(ZDFBaseIE, "_GEO_COUNTRIES")
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert hasattr(ZDFBaseIE, "_QUALITIES")
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    from ..compat import compat_str
    from ..utils import (
        determine_ext,
        float_or_none,
        int_or_none,
        merge_dicts,
        NO_DEFAULT,
        orderedSet,
        parse_codecs,
        qualities,
        try_get,
        unified_timestamp,
        update_url_query,
        url_or_none,
        urljoin,
    )