

# Generated at 2022-06-22 09:00:51.093549
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._extract_player(
        '<html><head>...<div data-zdfplayer-jsb=\'{"basename": "210222_phx_nachgehakt_corona_protest"}\'>...</div>...</head></html>',
        '210222_phx_nachgehakt_corona_protest',
        'Downloading JSON metadata')


# Generated at 2022-06-22 09:00:55.680952
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    instance_of_ZDFBaseIE = issubclass(ZDFIE, ZDFBaseIE)
    assert instance_of_ZDFBaseIE == True


# Generated at 2022-06-22 09:01:05.502165
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Create a ZDFIE instance
    instance_zdfie = ZDFIE()

    # Check that it is correct
    assert instance_zdfie.ie_key() == 'ZDF'
    assert instance_zdfie._VALID_URL == 'https?://www\\.zdf\\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\\.html'

# Generated at 2022-06-22 09:01:08.418488
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    infoExtractor = ZDFBaseIE()
    assert isinstance(infoExtractor, ZDFBaseIE)
    assert infoExtractor._GEO_COUNTRIES is not None
    assert infoExtractor._QUALITIES is not None


# Generated at 2022-06-22 09:01:18.911947
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdf._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert zdf._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert zdf._TESTS[0]['info_dict']['id'] == '210222_phx_nachgehakt_corona_protest'
    assert zdf._T

# Generated at 2022-06-22 09:01:28.273574
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-22 09:01:36.529310
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    player = {
		'apiToken': '56d96dbe-f3da-4562-8b6c-d6d08a6f9a6e',
		'content': 'https://api.zdf.de/content/documents/',
		'stack': 'ngplayer2',
	}
    content = {
		'mainVideoContent': {
			'http://zdf.de/rels/target': {
			'http://zdf.de/rels/streams/ptmd': 'https://api.zdf.de/content/documents/210222_phx_nachgehakt_corona_protest/vod/ptmd.json',
			'duration': '1691000',
			},
		},
	}
   

# Generated at 2022-06-22 09:01:37.888895
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    global ZDFIE
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() == 'ZDFMediathek'


# Generated at 2022-06-22 09:01:40.166892
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE()

    assert isinstance(inst, InfoExtractor)
    assert isinstance(inst, ZDFBaseIE)


# Generated at 2022-06-22 09:01:41.261169
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()


# Generated at 2022-06-22 09:02:33.884426
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test ZDFBaseIE constructor
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:02:34.948758
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('dummy_url')

# Generated at 2022-06-22 09:02:37.631291
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie = ZDFChannelIE()
    assert ie.suitable(url)



# Generated at 2022-06-22 09:02:38.634463
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE is not None


# Generated at 2022-06-22 09:02:44.317049
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(None, None)._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE(None, None)._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

##### ZDF #####

# Generated at 2022-06-22 09:02:51.329426
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = '123'
    url = 'http://www.zdf.de/foo'
    headers = {'Api-Auth': 'Bearer foo'}
    geocountries = ['DE']
    qualities = ['auto', 'low', 'med', 'high', 'veryhigh', 'hd']
    player_json = {'foo': 'bar'}
    ie_cls = ZDFBaseIE()
    ie_cls._APP_NAME = 'test_app'
    ie_cls._call_api(url, video_id, 'test', 'foo', 'http://www.example.com/')
    assert ie_cls._extract_subtitles({'foo': 'bar'}) == {}

# Generated at 2022-06-22 09:02:52.373003
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE({},{})


# Generated at 2022-06-22 09:02:53.455803
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    t = ZDFChannelIE()


# Generated at 2022-06-22 09:02:58.003276
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test with a channel URL
    channel_url = "https://www.zdf.de/dokumentation/planet-e/"
    i = ZDFChannelIE()
    assert i.suitable(channel_url)
    assert i.url_result(channel_url, ie=ZDFIE.ie_key())


# Generated at 2022-06-22 09:03:01.869608
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .common import test_zdf_channel_ie
    test_zdf_channel_ie('https://www.zdf.de/dokumentation/planet-e')

# Generated at 2022-06-22 09:03:53.030489
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:03:54.749971
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    x = ZDFIE()
    assert x.ie_key() == 'ZDF'


# Generated at 2022-06-22 09:03:56.458991
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    assert isinstance(instance, ZDFBaseIE)

# Generated at 2022-06-22 09:04:00.153468
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-22 09:04:09.001706
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')

# Generated at 2022-06-22 09:04:14.302099
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/nachrichten/konfrontation/'
    assert ZDFChannelIE.suitable(url)
    assert not ZDFIE.suitable(url)

# Generated at 2022-06-22 09:04:17.543487
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # test constructor of class ZDFIE
    a = [
        'http://www.zdf.de/nachrichten/zdf-mittagsmagazin/nachrichten-vom-28-06-2016-100.html',
        'http://www.zdf.de/ZDFmediathek/kanaluebersicht/aktuelles/live?flash=off'
        ]
    zdf = ZDFIE()
    print('unit test: ZDFIE', a)


# Generated at 2022-06-22 09:04:18.108170
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:04:26.638095
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Test constructor of class ZDFChannelIE."""
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable(
        'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    channel = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert channel._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 09:04:29.962078
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'zdf'


# Generated at 2022-06-22 09:06:07.345383
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """Unit test for constructor of class ZDFIE"""
    _ZDFIE = ZDFIE() # pylint: disable=unused-variable


# Generated at 2022-06-22 09:06:19.687730
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Test ZDFChannelIE constructor"""
    url = 'https://www.zdf.de/dokumentation/planet-e'
    # check constructor without video id set
    zdf_channel_ie = ZDFChannelIE(url)
    assert zdf_channel_ie.name == 'ZDF.de - Channel'
    assert zdf_channel_ie.ie_key() == 'ZDFChannel'
    assert not zdf_channel_ie.video_id
    # check constructor with video id set
    zdf_channel_ie = ZDFChannelIE(url, '1234567')
    assert zdf_channel_ie.video_id == '1234567'
    zdf_channel_ie.video_id = None
    assert not zdf_channel_ie.video_id
    # check if suitable checks for playlist
   

# Generated at 2022-06-22 09:06:29.127689
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Tests for class ZDFBaseIE"""
    # Instantiate an instance of ZDFBaseIE to test
    test_instance = ZDFBaseIE()
    # Test attribute _GEO_COUNTRIES of class ZDFBaseIE
    assert test_instance._GEO_COUNTRIES == ['DE']
    # Test attribute _QUALITIES of class ZDFBaseIE
    assert test_instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    # Test method _call_api of class ZDFBaseIE
    # Test method _extract_subtitles of class ZDFBaseIE
    # Test method _extract_format of class ZDFBaseIE
    # Test method _extract_ptmd of class ZDFBaseIE
    # Test method _extract_player of class ZDFBase

# Generated at 2022-06-22 09:06:36.175002
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():  # now I have a function with a nice name
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert ZDFChannelIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ZDFChannelIE.suitable(url)



# Generated at 2022-06-22 09:06:41.304765
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        c = ZDFIE()
        c.extract('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    except Exception:
        return False
    return True

#######################################################################################################


# Generated at 2022-06-22 09:06:52.425071
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-22 09:06:54.617536
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test with empty arguments
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie is not None
# Test: Fail with empty arguments



# Generated at 2022-06-22 09:07:04.226066
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    inst = ZDFIE()
    assert inst.TEST_ENTRIES[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert inst.TEST_ENTRIES[0]['info_dict']['title'] == 'Wohin führt der Protest in der Pandemie?'
    assert inst.TEST_ENTRIES[1]['md5'] == '0aff3e7bc72c8813f5e0fae333316a1d'
    assert inst.TEST_ENTRIES[1]['info_dict']['title'] == 'Ab 18! - 10 Wochen Sommer'

# Generated at 2022-06-22 09:07:08.022112
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert isinstance(ZDFChannelIE('https://test.test/test.html'), ZDFChannelIE)
    assert not isinstance(ZDFChannelIE('https://www.zdf.de/test.html'), ZDFChannelIE)


# Generated at 2022-06-22 09:07:20.811276
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import sys
    import inspect
    import time
    import unittest
    from datetime import datetime

    class TestZDFBaseIE(unittest.TestCase):
        def setUp(self):
            self.ie = ZDFBaseIE()
