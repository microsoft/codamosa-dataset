

# Generated at 2022-06-22 09:00:49.091853
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    c = ZDFChannelIE()
    assert c.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')

# Generated at 2022-06-22 09:00:55.820880
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    zdfie._VALID_URL
    zdfie._TESTS
    zdfie._real_extract
    zdfie._extract_player
    zdfie._extract_ptmd
    zdfie._extract_entry
    zdfie._extract_regular
    zdfie._extract_mobile

# Generated at 2022-06-22 09:01:01.793999
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        from . import abstract_test
        assert(isinstance(abstract_test.AbstractTest(), ZDFIE))
    except ImportError:
        import unittest
        class TestZDFBaseIE(unittest.TestCase):
            def test_is_instance(self):
                self.assertIsInstance(ZDFIE(), ZDFIE)
        unittest.main()


# Generated at 2022-06-22 09:01:08.213677
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    tester = ZDFBaseIE()
    # OK
    tester._download_json('http://www.zdf.de/ZDFmediathek/json/999999999', '999999999', 'Downloading JSON')
    # Fail
    tester._download_json('http://www.zdf.de/ZDFmediathek/json/999999999', '999999999', 'Downloading JSON', headers={'Api-Auth': 'Bearer %s' % '999999999'})


# Generated at 2022-06-22 09:01:15.190332
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    _id = 'U2FsdGVkX1-UfB9XksdI-6MklpyAuMf1KUhac6IbU1lTD99Z5c5L-9zqx3x4'
    zdfbase_ie = ZDFBaseIE(None)
    url = urljoin(zdfbase_ie._API_BASE, _id)
    assert url == 'https://api.zdf.de/content/documents/%s' % _id



# Generated at 2022-06-22 09:01:19.082806
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase_test = ZDFBaseIE()
    assert zdfbase_test._GEO_COUNTRIES == ['DE']
    assert zdfbase_test._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:01:23.524039
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-22 09:01:34.498436
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE("")
    assert zdfie


# Generated at 2022-06-22 09:01:37.704998
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import _test_channel
    _test_channel(ZDFChannelIE, 'https://www.zdf.de/politik/phoenix-sendungen')

# Generated at 2022-06-22 09:01:46.506744
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_test_cases
    from .zdf import ZDFPlaylistBaseIE

    ZDFChannelIE._TESTS = [
        {
            'url': 'https://www.zdf.de/dokumentation/planet-e',
            'only_matching': True,
        }
    ]

    test_cases = get_test_cases(ZDFIE, ZDFChannelIE, ZDFPlaylistBaseIE, [{
        'url': 'https://www.zdf.de/dokumentation/planet-e',
        'only_matching': True,
    }])

    for test_case in test_cases:
        test_case()


# Generated at 2022-06-22 09:02:11.529548
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES is not None
    assert ZDFBaseIE._QUALITIES is not None
    assert ZDFBaseIE._extract_subtitles is not None
    assert ZDFBaseIE._extract_format is not None



# Generated at 2022-06-22 09:02:14.647374
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Instanciate the class
    zdfIE = ZDFIE()
    # Make sure the class is well instantiated
    assert zdfIE is not None



# Generated at 2022-06-22 09:02:17.084460
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_url = 'https://www.zdf.de/dokumentation/planet-e'
    obj = ZDFChannelIE()
    assert obj._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert obj.suitable(test_url)

# Generated at 2022-06-22 09:02:20.700745
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zie = ZDFIE()
    assert zie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert len(zie._TESTS) == 10


# Generated at 2022-06-22 09:02:26.233891
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Unit test for constructor of class ZDFBaseIE"""

    ietest = ZDFBaseIE('ZDFBaseIE', {})
    assert isinstance(ietest, InfoExtractor)

    if hasattr(ZDFBaseIE, '_GEO_COUNTRIES'):
        assert ZDFBaseIE._GEO_COUNTRIES == ['DE']

    if hasattr(ZDFBaseIE, '_QUALITIES'):
        assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:02:32.456479
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:02:33.486825
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()



# Generated at 2022-06-22 09:02:38.391337
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = 'https://www.zdf.de/dokumentation/terra-x/das-ende-der-maya-100.html'
    ie = ZDFBaseIE()
    assert ie.ie_key() == 'zdf'
    assert ie.suitable(url)


# Generated at 2022-06-22 09:02:47.834016
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base = ZDFBaseIE()
    assert 'DE' in base._GEO_COUNTRIES
    assert '_QUALITIES' in base.__dict__
    assert (sorted(base._QUALITIES) ==
            ['auto', 'hd', 'high', 'low', 'med', 'veryhigh'])
    assert base._call_api
    assert base._extract_subtitles
    assert base._extract_format
    assert base._extract_ptmd
    assert base._extract_player
    assert base._extract_video
    assert base.ie_key()
    assert base.suitable



# Generated at 2022-06-22 09:02:51.019950
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel = ZDFChannelIE()
    assert zdf_channel.suitable(u'https://www.zdf.de/filme/taunuskrimi/') == True

# Generated at 2022-06-22 09:03:34.955887
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        zdfChannel = ZDFChannelIE()
    except AttributeError as err:
        print('Error: {}'.format(err))
        return

    print('ZDFChannelIE has been initialized.\n')


# Generated at 2022-06-22 09:03:39.778318
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    e = ZDFBaseIE()
    assert e._GEO_COUNTRIES == ['DE']
    assert e._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:03:41.347336
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Empty ZDFIE
    instance = ZDFIE()


# Generated at 2022-06-22 09:03:42.363146
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, ZDFBaseIE)



# Generated at 2022-06-22 09:03:52.092807
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert ZDFChannelIE.suitable('https://www.zdf.de/verbraucher/wiso/wiso-sternzeichen-fische-100.html')

    # Test for class member '_VALID_URL'

# Generated at 2022-06-22 09:03:54.163459
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
	assert (ZDFIE('zdf') == 'zdf') #Check if the return value is equal to the passed parameter


# Generated at 2022-06-22 09:03:56.566184
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:04:03.541972
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://zdf.de/') == False
    assert ZDFChannelIE.suitable('https://www.zdf.de/politik/') == False
    assert ZDFChannelIE.suitable('https://www.zdf.de/politik/abc') == True
    assert ZDFChannelIE.suitable('https://www.zdf.de/politik/abc.html') == False



# Generated at 2022-06-22 09:04:09.214730
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE("http://www.zdf.de")
    assert ie.country == 'DE'
    assert ie.qualities == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie.IE_NAME == 'zdf:base'


# Generated at 2022-06-22 09:04:11.703661
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-22 09:05:45.488595
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    '''
    check if ZDFChannelIE.suitable(url) == False for url of ZDFShowIE
    '''
    url = 'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'
    assert ZDFChannelIE.suitable(url) == False
    url = 'https://www.zdf.de/dokumentation/planet-e'
    assert ZDFChannelIE.suitable(url) == True
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    assert ZDFChannelIE.suitable(url) == True


# Generated at 2022-06-22 09:05:47.405762
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE().suitable('https://www.zdf.de/filme/taunuskrimi/')

# Generated at 2022-06-22 09:05:50.357239
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test extractor id
    _ = ZDFBaseIE.ie_key()
    # Test constructor
    ZDFBaseIE(ZDFBaseIE.ie_key())



# Generated at 2022-06-22 09:05:53.416626
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:05:55.075724
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE
    assert ie.suitable(ie._VALID_URL) == True

# Generated at 2022-06-22 09:05:58.915069
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:06:00.445718
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE is not None


# Generated at 2022-06-22 09:06:04.647400
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie
    assert zdfie.ie_key() == 'zdf'
    assert zdfie.ie_key() == ZDFIE.ie_key()
    assert zdfie.ie_key() == ZDFBaseIE.ie_key()


# Generated at 2022-06-22 09:06:12.377394
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = 'https://www.zdf.de/comedy/heute-show/heute-show-vom-19.-februar-2016-100.html'
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie.IE_NAME == 'ZDF'
    assert ie._VALID_URL.match(url)


# Generated at 2022-06-22 09:06:14.034116
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    pass


# Generated at 2022-06-22 09:09:13.837751
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert "ZDFBaseIE" == type(instance).__name__


# Generated at 2022-06-22 09:09:15.327671
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE('ZDFBaseIE')


# Generated at 2022-06-22 09:09:26.352599
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    for url in (
        'https://www.zdf.de/politik/frontal-21/frontal-21-uebersichtsseite-100.html',
        'https://www.zdf.de/filme/die-hebamme',
        'https://www.zdf.de/wissen/planeta/planeta-uebersichtsseite-100.html',
        'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
    ):
        assert ZDFChannelIE.suitable(url)


# Generated at 2022-06-22 09:09:30.053876
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:09:41.091077
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Unit test
    # assert ZDFChannelIE().suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')
    assert ZDFChannelIE().suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ZDFChannelIE().suitable('https://www.zdf.de/dokumentation/planet-e')
    assert ZDFChannelIE().suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')


# Generated at 2022-06-22 09:09:50.660675
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for constructor of class ZDFChannelIE
    """
    url = 'https://www.zdf.de/dokumentation/terra-x'
    ie = ZDFChannelIE(url)
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://www.zdf.de/dokumentation/terra-x',
        'info_dict': {
            'id': 'terra-x',
            'title': 'terra x',
        },
        'playlist_mincount': 50,
    }]
    assert ie.suitable(url) is True

# Generated at 2022-06-22 09:09:56.204187
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    cases = [
        {
            "url": "https://www.zdf.de/politik/phoenix-sendungen/",
            "result": {
                'id': 'phoenix-sendungen',
                'title': 'Sendungen A-Z | Phoenix',
            },
        }
    ]
    for case in cases:
        url = case.pop("url")
        result = case.pop("result")
        assert len(case) == 0

        zdfChannel = ZDFChannelIE()
        assert zdfChannel._match_id(url) == result["id"]
        assert zdfChannel._og_search_title(url) == result["title"]



# Generated at 2022-06-22 09:09:56.773563
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None, {})



# Generated at 2022-06-22 09:10:02.175396
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    id = 'taunuskrimi'
    video_id = '141007_ab18_10wochensommer_film'

    t = ZDFIE(id)
    assert t.ie_key() == id

    t = ZDFIE(id,video_id)
    assert t.ie_key() == id
    assert t._real_extract(video_id)


# Generated at 2022-06-22 09:10:03.962734
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    This is a unit test for ZDFIE constructor.
    """
    extractor = ZDFIE()
    return extractor
