

# Generated at 2022-06-22 09:00:51.359719
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_zdf import test_ZDFIE
    # noinspection PyTypeChecker
    test_ZDFIE(ZDFChannelIE, entries=1)



# Generated at 2022-06-22 09:00:53.353844
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE


# Generated at 2022-06-22 09:00:57.046835
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert(obj._GEO_COUNTRIES == ['DE'])
    assert(obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))



# Generated at 2022-06-22 09:01:07.250312
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import test_youtube
    from . import test_generic_channel
    from . import test_common

    testcases = [
        test_youtube.testcases[0],
        test_generic_channel.testcases[0],
    ]
    for testcase in testcases:
        for ie in test_common.gen_extractors(ZDFChannelIE, testcase.get('url')):
            try:
                test_common.fetch_extractor(ie, testcase.get('url'), testcase.get('id'))
            except Exception as e:
                raise Exception('%s %s' % (ie, testcase)) from e



# Generated at 2022-06-22 09:01:12.042879
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    klass = ZDFIE
    # Unit test for url initialization
    assert(klass._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html')
    # Unit test for extract_id

    # Unit test for valid_url



# Generated at 2022-06-22 09:01:20.198856
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Create an instance of class ZDFChannelIE, then call extract_entries().
    # Check that playlist items are returned.
    ie = ZDFChannelIE()
    ie.url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie.entries = []
    ie.extract_entries()
    assert len(ie.entries) > 0
    # Check that entries are indeed instance of class Entry.
    assert all([isinstance(e, Entry) for e in ie.entries])
    # Check that entries are indeed of video_id.
    assert all([e.video_id!=None for e in ie.entries])

# Generated at 2022-06-22 09:01:26.616042
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE
    assert zdf._TESTS is not None
    assert zdf.ie_key() == 'zdf'
    assert zdf.IE_NAME == 'zdf'
    assert zdf.supported_domains[0] == "www.zdf.de"



# Generated at 2022-06-22 09:01:30.431909
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info_extractor = ZDFBaseIE()
    assert info_extractor is not None, "Failed to construct an object of type ZDFBaseIE"


# Generated at 2022-06-22 09:01:37.581801
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'ZDF'

    expected = {
        'extractor_key': 'ZDF',
        'id': '210222_phx_nachgehakt_corona_protest',
        'ext': 'mp4',
        'title': 'Wohin führt der Protest in der Pandemie?',
        'description': 'md5:7d643fe7f565e53a24aac036b2122fbd',
        'duration': 1691,
        'timestamp': 1613948400,
        'upload_date': '20210221',
    }
    # return value from method _extract_regular

# Generated at 2022-06-22 09:01:47.775053
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():

    # Initialize unit tests for class ZDFBaseIE
    field_names = ['_GEO_COUNTRIES', '_QUALITIES']
    fields = [ZDFBaseIE._GEO_COUNTRIES, ZDFBaseIE._QUALITIES]
    types = [list, tuple]
    for field_name, field, type_ in zip(field_names, fields, types):
        assert(isinstance(field, type_))

    # Initialize unit tests for method _call_api
    res = ZDFBaseIE._call_api('http://www.zdf.de', 'sample_video', 'sample_item')
    assert(res['_type'] == 'url')
    assert(res['url'] == 'http://www.zdf.de')
    assert(res['ie_key'] == 'Generic')

# Generated at 2022-06-22 09:02:14.694507
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()._real_initialize()
    assert ie.SUCCESS == True
 

# Generated at 2022-06-22 09:02:19.052773
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._extract_subtitles({}) == {}
    assert ZDFBaseIE._extract_subtitles({'captions': [{'language': 'enu', 'uri': 'http://example.com/foo'}]}) == {'enu': [{'url': 'http://example.com/foo'}]}



# Generated at 2022-06-22 09:02:21.530033
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # The test here is kinda dummy, we just make a call to the constructor
    # and check if it raises any exception.
    ZDFChannelIE(None, None)

# Generated at 2022-06-22 09:02:26.272896
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None)
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:02:29.892976
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:02:31.061980
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE is not None



# Generated at 2022-06-22 09:02:34.841004
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test in function _real_extract, self._extract_mobile
    ZDFIE._extract_mobile('210222_phx_nachgehakt_corona_protest')



# Generated at 2022-06-22 09:02:43.364028
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # region : Constructor testing
    # Test the constructor of class ZDFChannelIE
    # with a valid url
    info_dict = {
        'id': 'das-aktuelle-sportstudio',
        'title': 'das aktuelle sportstudio | ZDF',
    }
    zdf_channelie = ZDFChannelIE(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio', info_dict)

    # Test the constructor of class ZDFChannelIE
    # with a invalid url
    try:
        zdf_channelie = ZDFChannelIE('abc.com', info_dict)
    except RegexNotFoundError:
        pass
    # endregion



# Generated at 2022-06-22 09:02:54.021187
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    tests = [
        # URL, [error message], [expected {'id': '...'}]
        ('https://www.zdf.de/sport/das-aktuelle-sportstudio', [], {'id': 'das-aktuelle-sportstudio'}),
        ('https://www.zdf.de/dokumentation/planet-e', [], {'id': 'planet-e'}),
        ('https://www.zdf.de/filme/taunuskrimi/', ['Invalid URL'], None),
    ]
    for url, e_msg, e_ext_data in tests:
        err_msg = 'URL: %s should %s.' % (url, ('raise ValueError', 'be accepted')[e_ext_data != None])

# Generated at 2022-06-22 09:02:55.485517
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None)


# Generated at 2022-06-22 09:03:53.344465
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    unit_test_example_url = 'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'
    expected_id = '151025_magie_farben2_tex'

    zdf_ie = ZDFIE()
    zdf_ie_entry = zdf_ie._real_extract(unit_test_example_url)

    # Test for id
    assert zdf_ie_entry['id'] == expected_id



# Generated at 2022-06-22 09:03:56.093441
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:03:58.015520
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFIE()
    except Exception:
        assert False



# Generated at 2022-06-22 09:04:07.691574
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    fmt_dict = [{u'src': 1}, {u'dst': 2}]
    playlist = [{u'fmt': u'fmt'}]
    info_dict = {
        u'id': u'id_1',
        u'duration': 1.0,
        u'formats': [1,2],
        u'subtitles': {u'lang': u'ger'}
    }
    ext = 'ext'

# Generated at 2022-06-22 09:04:08.967332
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBase = ZDFBaseIE()
    assert zdfBase



# Generated at 2022-06-22 09:04:17.904817
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'


# Generated at 2022-06-22 09:04:26.558333
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Basic unit test for ZDFChannelIE
    from youtube_dl.utils import DateRange

    from datetime import datetime, timedelta
    from calendar import timegm
    import pytz

    def get_utc(date):
        tz = pytz.timezone('Europe/Berlin')
        return timegm(pytz.utc.localize(datetime.combine(
            date, datetime.min.time())).astimezone(tz).timetuple())

    def get_date(utc):
        tz = pytz.timezone('Europe/Berlin')
        return datetime.fromtimestamp(utc, tz).date()

    today = get_utc(datetime.now())
    tomorrow = get_utc(datetime.now() + timedelta(days=1))
    yesterday = get_

# Generated at 2022-06-22 09:04:29.910665
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(ZDFIE() is not None)


# Generated at 2022-06-22 09:04:31.304802
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(None, None)
test_ZDFBaseIE()



# Generated at 2022-06-22 09:04:39.574214
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
        Unit test for constructor of class ZDFIE
    """
    ie = ZDFIE()
    ie.ie_key()
    ie.geo_verification_headers()
    ie.js_to_json(None)
    ie.report_warning(None)
    ie._build_json_search_regex(None, None, None)
    ie._check_formats(None, None)
    ie._convert_subtitles(None)
    ie._download_json(None, None, None)
    ie._get_video_id(None)
    ie._get_subtitles(None)
    ie._get_subtitles(None, None)
    ie._get_subtitles(None, None, None)
    ie._get_subtitles(None, None, None, None)
   

# Generated at 2022-06-22 09:06:23.868580
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE("https://www.zdf.de/dokumentation/planet-e/")
    print("URL is: ", zdfChannelIE.url)
    print("Extractor key is: ", zdfChannelIE.ie_key())


# Generated at 2022-06-22 09:06:25.589061
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(object(), object(), object())


# Generated at 2022-06-22 09:06:34.341230
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    inputs_outputs = [
        # Use constructor of class ZDFIE
        (ZDFIE, [r'sport', r'das\saktuelle\ssportstudio', r'sport/das-aktuelle-sportstudio']),
        # Use constructor of class ZDFChannelIE
        (ZDFChannelIE, [r'dokumentation', r'planet\se', r'dokumentation/planet-e']),
        (ZDFChannelIE, [r'filme', r'taunuskrimi', r'filme/taunuskrimi']),
    ]

    for (IE_class, matches) in inputs_outputs:
        assert IE_class.suitable(
            'https://www.zdf.de/' + matches[1]) is True, matches[0]

# Generated at 2022-06-22 09:06:39.968589
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from ..utils import (
        check_url, ExtractionError
    )

    # Dummy URL
    url = 'https://www.zdf.de/dummy'

    # Test class constructor
    ie = ZDFIE()

    # Test URL parsing
    assert ie._match_id(url)
    assert check_url(ie, url)

    # Test metadata extraction
    with pytest.raises(ExtractionError):
        ie._extract_metadata(url)


# Generated at 2022-06-22 09:06:42.835996
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert 'apiToken' in ie._extract_player('{}', '', fatal=False)


# Generated at 2022-06-22 09:06:53.211940
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Divide video url in parts and then use them in constructor."""

# Generated at 2022-06-22 09:06:54.429453
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE('http://www.zdf.de') is not None


# Generated at 2022-06-22 09:07:02.906213
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    if 'ZDFIE' not in globals():
        return
    if 'ZDFBaseIE' not in globals():
        return
    if 'InfoExtractor' not in globals():
        return

    # Test/Verify attributes of classes using basic assertions
    assert isinstance(ZDFIE.ie_key(), compat_str)
    assert isinstance(ZDFIE.ie_key(), compat_str)
    assert isinstance(ZDFIE.ie_key(), compat_str)
    assert isinstance(ZDFIE._TESTS, list)
    assert isinstance(ZDFIE._TESTS, list)


# Generated at 2022-06-22 09:07:15.493074
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = '1'
    info_dict = {
        'extractor_key': ZDFIE.ie_key(),
        'id': '1',
        'duration': 100,
        'formats': [],
        'subtitles': {},
        }
    zdbaseie = ZDFBaseIE()
    zdbaseie._call_api('http://zdf.de', video_id, 'metadata')
    zdbaseie._extract_player('data-zdfplayer-jsb={}',video_id)
    zdbaseie._extract_ptmd('http://zdf.de', video_id, 'api_token', 'referrer')
    zdbaseie._extract_format(video_id, [], set(), info_dict)
    zdbaseie._extract_sub

# Generated at 2022-06-22 09:07:19.406443
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z = ZDFChannelIE()

    assert z.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html') == False
    assert z.suitable('https://www.zdf.de/filme/taunuskrimi/') == True

