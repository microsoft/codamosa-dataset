

# Generated at 2022-06-22 09:00:47.758934
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Constructor needs only two arguments, one of which is self
    base_ie = ZDFBaseIE('youtube', 'youtube')
    assert base_ie is not None


# Generated at 2022-06-22 09:00:48.978621
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    res = ZDFBaseIE()
    assert res is not None


# Generated at 2022-06-22 09:00:51.880481
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() == 'zdf'



# Generated at 2022-06-22 09:00:54.988714
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('http://www.zdf.de/ZDFmediathek/hauptnavigation/startseite', {})
    assert ie.__class__.__name__ == 'ZDFBaseIE'


# Generated at 2022-06-22 09:00:56.731694
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e');

# Generated at 2022-06-22 09:01:06.326165
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test case for ZDFIE
    test_ZDFIE = ZDFIE()
    print("Testing ZDFIE")
    assert(test_ZDFIE is not None)
    # Test case for _extract_entry
    test_ZDFIE._extract_entry("sample_url", "sample_player", "sample_content", "sample_video_id")
    print("Testing _extract_entry")
    assert(test_ZDFIE._extract_entry("sample_url", "sample_player", "sample_content", "sample_video_id") is not None)
    # Test case for _extract_regular
    test_ZDFIE._extract_regular("sample_url", "sample_player", "sample_video_id")
    print("Testing _extract_regular")

# Generated at 2022-06-22 09:01:08.190781
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()

# Generated at 2022-06-22 09:01:18.596742
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-22 09:01:24.521700
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    testvar = ZDFIE._VALID_URL
    assert testvar == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'


# Generated at 2022-06-22 09:01:30.936301
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_zdf_download import test_ZDFDownloadIE
    zdf_download_test_cases = test_ZDFDownloadIE()._TESTS
    output = '\n'.join(
        ['"%s",' % case['url']
         for case in zdf_download_test_cases[:50]])
    print(output)



# Generated at 2022-06-22 09:02:19.255372
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(InfoExtractor, "abc")


# Generated at 2022-06-22 09:02:20.864654
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE("ZDF", "https://www.3sat.de/")


# Generated at 2022-06-22 09:02:21.720501
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_ie = ZDFBaseIE()


# Generated at 2022-06-22 09:02:23.782511
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE()

# Generated at 2022-06-22 09:02:35.616903
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    x = ZDFIE(None)
    assert x.name == 'ZDF'
    assert x._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-22 09:02:37.463358
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ief = ZDFIE()
    # Calling in the constructor of the parent class
    assert (isinstance(ief, InfoExtractor))


# Generated at 2022-06-22 09:02:39.311608
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')._real_extract(
        'https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')



# Generated at 2022-06-22 09:02:41.509861
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:02:42.853240
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None)

# Generated at 2022-06-22 09:02:46.820526
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE({})
    assert inst._GEO_COUNTRIES == ['DE']
    assert inst._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:03:33.606224
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-22 09:03:37.965859
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # This checks that the derived class is instantiating its abstract base class.
    # We don't care what the constructor's arguments are.
    ZDFIE('url', None, None, None)

# Generated at 2022-06-22 09:03:44.162649
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE('ZDFBaseIE', '1.zdf.de', False)
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Unit tests for _extract_format method of class ZDFBaseIE

# Generated at 2022-06-22 09:03:52.211992
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE().suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE().suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert not ZDFIE().suitable('https://www.zdf.de/dokumentation/planet-e')

# Generated at 2022-06-22 09:04:00.431276
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z = ZDFChannelIE()
    assert z.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not z.suitable('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html')
    assert not z.suitable('https://www.zdf.de/sport/zdf-sportreportage')
    assert not z.suitable('https://www.zdf.de/nachrichten/heute-journal')

# Generated at 2022-06-22 09:04:09.218665
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert issubclass(ZDFChannelIE, ZDFBaseIE)
    assert ZDFChannelIE.__name__ == 'ZDFChannelIE'
    assert ZDFChannelIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ZDFChannelIE.__doc__ is not None
    assert len(get_class_functions(ZDFChannelIE)) == 2
    assert len(get_class_functions_names(ZDFChannelIE)) == 2
    assert len(get_class_methods(ZDFChannelIE)) == 8
    assert len(get_class_methods_names(ZDFChannelIE)) == 8
    assert len(get_class_properties(ZDFChannelIE)) == 0

# Generated at 2022-06-22 09:04:22.403597
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    instance._call_api("https://www.zdf.de/livestreams/zdf/live", "", "user_data",
                       "gvdfhbhnj,kmjnhbgv")
    instance._extract_subtitles("{}")
    instance._extract_ptmd("https://www.zdf.de/livestreams/zdf/live",
                           "", "gvdfhbhnj,kmjnhbgv", "https://www.zdf.de/livestreams/zdf/live")
    instance._extract_player("www.zdf.de/livestreams/zdf/live", "")
    instance._GEO_COUNTRIES
    instance._QUALITIES



# Generated at 2022-06-22 09:04:25.794586
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    actual_channel_ie = ZDFChannelIE()
    if not actual_channel_ie.suitable(url):
        assert False, 'ZDFChannelIE is not suitable for url: ' + url


# Generated at 2022-06-22 09:04:30.709574
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_url = 'https://www.zdf.de/filme/taunuskrimi'
    ZDFChannelIE.suitable(test_url)



# Generated at 2022-06-22 09:04:33.845992
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:05:22.885035
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-22 09:05:27.660128
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE.ie_key() == 'zdf'
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:05:31.419041
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():

    # Test with simple URL
    zdfie = ZDFBaseIE()

    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:05:43.622028
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test _extract_format
    base_ie = ZDFBaseIE()
    formats = []
    set = set()
    assert base_ie._extract_format(
        "Content_ID", formats, set, {
            'url': 'Url',
            'type': 'Type',
            'mimeType': 'Mime_Type',
            'quality': 'Quality',
            'language': 'Language',
        }
    ) == None
    assert formats[0] == {
        'url': 'Url',
        'format_id': 'http-Type-Quality',
        'format_note': 'Quality',
        'language': 'Language',
        'quality': 0,
        'preference': -10,
    }

    # Test _extract_subtitles

# Generated at 2022-06-22 09:05:46.496603
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        ZDFChannelIE(test=True)
    except:
        assert False, "Unit test for constructor of class ZDFChannelIE is not passing"



# Generated at 2022-06-22 09:05:48.694141
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-22 09:05:54.157073
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases
    from .zdf import _ZDFBaseIE
    from .zdf import _ZDFBaseIE_TEST_CASES
    for tc in get_testcases(_ZDFBaseIE, _ZDFBaseIE_TEST_CASES):
        ZDFChannelIE(*tc[:2])
test_ZDFChannelIE()



# Generated at 2022-06-22 09:05:57.481725
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    Tries to call the ZDFIE constructor ZDFBaseIE().
    """
    assert ZDFBaseIE()._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-22 09:06:06.210489
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    string_object = """
    <script class="playerdata" type="text/javascript">
    var playerdata={
    apiToken: "anonymous",
    content: "https://api.zdf.de/content/documents/das-aktuelle-sportstudio.json?profile=player",
    config: "https://api.zdf.de/content/documents/zdfplayer_das-aktuelle-sportstudio.json?profile=player",
    docId: "das-aktuelle-sportstudio",
    initialVideo: null,
    pageTitle: "das aktuelle sportstudio | ZDF",
    };
    </script>
    """

# Generated at 2022-06-22 09:06:08.371845
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.IE_NAME == 'zdf'



# Generated at 2022-06-22 09:06:53.765244
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE(ZDFChannelIE.create_ie_instance()).ie_key() == 'ZDF'

# Generated at 2022-06-22 09:06:54.669815
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()


# Generated at 2022-06-22 09:07:04.225171
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE()
    assert channel.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') is True
    assert ZDFIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') is False
    assert channel.suitable('https://www.zdf.de/dokumentation/planet-e') is True
    assert ZDFIE.suitable('https://www.zdf.de/dokumentation/planet-e') is False
    assert channel.suitable('https://www.zdf.de/filme/taunuskrimi/') is True
    assert ZDFIE.suitable('https://www.zdf.de/filme/taunuskrimi/') is False



# Generated at 2022-06-22 09:07:07.070720
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Description:
        Test if constructor of class ZDFBaseIE can be called without
        any error.
    """
    ZDFBaseIE()


# Generated at 2022-06-22 09:07:09.737500
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._extract_mobile('170220_NEWSTICKER_ZDFHIGHLIGHT_NORDKOREA_SOUTH')

# Generated at 2022-06-22 09:07:12.152742
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBaseIE = ZDFBaseIE()
    assert isinstance(zdfBaseIE, InfoExtractor)



# Generated at 2022-06-22 09:07:16.749633
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:07:21.734874
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == zdfie.GEO_COUNTRIES
    assert zdfie._GEO_BYPASS == zdfie.GEO_BYPASS
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._GEO_BYPASS == False


# Generated at 2022-06-22 09:07:23.398825
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE is not None


# Generated at 2022-06-22 09:07:36.094457
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .tests.test_wdr import FakeBrowser
    from .common import BaseInfoExtractor
    from .common import InfoExtractor

    url = 'https://www.zdf.de/dokumentation/planet-e'
    base_ie = BaseInfoExtractor(FakeBrowser())
    ie = InfoExtractor(base_ie)

    zdfchannelie = ZDFChannelIE(base_ie, ie, url)
    assert zdfchannelie._VALID_URL == ZDFChannelIE._VALID_URL
    assert zdfchannelie.url == url
    assert zdfchannelie.name == ZDFChannelIE.ie_key()
    assert zdfchannelie.ie == ie
    assert zdfchannelie.suitable(url) == True

# Generated at 2022-06-22 09:08:33.002208
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.ie_key() == 'zdf'
    assert ZDFChannelIE.ie_key() == 'zdf'



# Generated at 2022-06-22 09:08:44.193287
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')
    assert not ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

# Generated at 2022-06-22 09:08:51.008777
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    fieldnames = [
        'url', 'webpage_url', 'channel_id', 'webpage', 'entries_urls', 'entries'
    ]
    rows = []
    with open('zdf_channel_urls.csv', 'r') as csvfile:
        reader = csv.DictReader(csvfile, fieldnames)
        for row in reader:
            rows.append(row)
    ie = ZDFChannelIE()
    for row in rows:
        print(row['webpage_url'])
        ie.url = row['url']
        ie.webpage_url = row['webpage_url']
        ie.channel_id = row['channel_id']
        ie.webpage = row['webpage']
        ie.entries_urls = row['entries_urls']
       

# Generated at 2022-06-22 09:08:51.902488
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_zdfbaseie = ZDFBaseIE()

# Generated at 2022-06-22 09:08:54.429005
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:09:01.218303
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    Test for constructor of class ZDFIE
    """
    parse = ZDFIE()
    assert parse._TESTS[0]['url'] == "https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html"
    assert parse._TESTS[0]['md5'] == "34ec321e7eb34231fd88616c65c92db0"
    assert parse._TESTS[0]['info_dict']['id'] == "210222_phx_nachgehakt_corona_protest"
    assert parse._TESTS[0]['info_dict']['ext'] == "mp4"

# Generated at 2022-06-22 09:09:03.988469
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test if the constructor of ZDFIE raises no exceptions
    ZDFIE()


# Generated at 2022-06-22 09:09:07.396438
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:09:09.293739
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_ZDFChannelIE = ZDFChannelIE()
    assert test_ZDFChannelIE != None


# Generated at 2022-06-22 09:09:16.867375
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import json
    import pprint
    HTML = open("zdfchannel.html").read()
    tests = [
        dict(
            url = 'https://www.zdf.de/politik/phoenix-sendungen',
            playlist_mincount = 28),
        dict(
            url = 'https://www.zdf.de/dokumentation/planet-e',
            playlist_mincount = 50),
        dict(
            url = 'https://www.zdf.de/filme/taunuskrimi',
            playlist_mincount = 21),
        dict(
            url = 'https://www.zdf.de/nachrichten/heute',
            playlist_mincount = 3),
    ]
    for test in tests:
        test['info_dict'] = ZDFChannelIE._real_extract