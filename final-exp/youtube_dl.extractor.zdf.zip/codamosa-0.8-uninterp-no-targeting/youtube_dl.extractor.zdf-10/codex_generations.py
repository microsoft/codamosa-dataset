

# Generated at 2022-06-22 09:01:00.419971
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    print("Testing ZDFBaseIE")
    sample_input = {
        "video_id": "051834a4-7c62-4c4f-8f4e-2818c5d5fb2b",
        "webpage": "https://www.zdf.de/comedy/hermann-und-hannah-besser-als-schlafen-100.html",
        "fatal": True
    }
    player_json = {
        "assetUri": "/de/bla/bla",
        "title": "Foo",
        "headline": "Foo"
    }

# Generated at 2022-06-22 09:01:01.604113
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-22 09:01:04.425717
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, ZDFBaseIE)


# Generated at 2022-06-22 09:01:07.517490
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = "https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html"
    ZDFIE(url).test_zdf_ie_constructor(url)


# Generated at 2022-06-22 09:01:08.252449
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-22 09:01:09.922802
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Initialize a ZDFIE object
    ZDFIE()
    # No error shall be thrown



# Generated at 2022-06-22 09:01:11.448784
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # TODO: Implement
    assert False



# Generated at 2022-06-22 09:01:18.254593
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDF')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie._call_api('', '', '', api_token=None, referrer=None)['url'] == 'https://json.zdf.de/'
    assert ie._extract_subtitles({}) == {}
    assert ie._extract_player('', '') == {}

# Generated at 2022-06-22 09:01:23.124595
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        import pytest
        pytest.skip('Since we do not want to create an instance of ZDFBaseIE, this test is skipped')
    except ImportError:
        print('pytest is not available, we are not skipping the constructor test for ZDFBaseIE')

    obj = ZDFBaseIE()
    assert isinstance(obj, ZDFBaseIE)


# Generated at 2022-06-22 09:01:24.308651
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE(None)


# Generated at 2022-06-22 09:02:02.653240
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # The ZDFBaseIE needs a test because it is an abstract base class.
    # The only part of the class that is not abstract is the _extract_player method,
    # so we need to test that.
    youtube_url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    info_dict = {
        'extractor_key': 'Youtube',
        'video_id': 'BaW_jenozKc',
        'title': 'youtube-dl test video "\'/\\ä↭',
        'ext': 'mp4',
        'duration': 10,
        'uploader': 'Philipp Hagemeister',
        'webpage_url': youtube_url,
    }

# Generated at 2022-06-22 09:02:07.300106
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
  zdfIE = ZDFIE()
  # Test case 1
  zdfIE._extract_regular('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html',
                         {'content': 'https://api.zdf.de/content/documents/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.json?profile=player', 'apiToken': 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9'},
                         'wohin-fuehrt-der-protest-in-der-pandemie')
  # Test case 2


# Generated at 2022-06-22 09:02:19.095496
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert zdf.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not zdf.suitable('https://www.zdf.de/politik/heute-journal/heute-journal-podcast-100.html')
    assert not zdf.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')

# Generated at 2022-06-22 09:02:19.504580
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()

# Generated at 2022-06-22 09:02:21.642130
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    with open('zdf_output.txt', 'w') as f:
        f.write(ZDFIE().ie_key())



# Generated at 2022-06-22 09:02:24.663123
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(None)._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-22 09:02:28.414416
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print("TEST:", ZDFChannelIE.ie_key())
    ZDFChannelIE().suitable(ZDFChannelIE._VALID_URL) # Prints "SUITABLE"
    print("INSTANTIATION_TEST_COMPLETE")


# Generated at 2022-06-22 09:02:29.094159
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE({}, None)


# Generated at 2022-06-22 09:02:30.344915
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'

# Test of the method _extract_player of class ZDFIE

# Generated at 2022-06-22 09:02:32.814826
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf is not None


# Generated at 2022-06-22 09:03:32.690609
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._downloader is None
    assert ie.ie_key() == 'ZDF'
    assert ie.SUCCESS == True
    assert ie._GEO_COUNTRIES == ['DE']

# Generated at 2022-06-22 09:03:33.974719
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    a=ZDFIE()
    assert(a)


# Generated at 2022-06-22 09:03:46.186427
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-22 09:03:47.572018
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_extractor = ZDFBaseIE(None)



# Generated at 2022-06-22 09:03:53.072349
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from nose.tools import assert_equals

    # Dummy object for testing
    class DummyIE(ZDFIE):
        ie_key = 'dummy'

    # A simple test
    dummy_ie = DummyIE()
    assert_equals(dummy_ie._VALID_URL, 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html')



# Generated at 2022-06-22 09:04:01.259803
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Creating object of class ZDFIE
    ie = ZDFIE()
    # Testing constructor
    if ie._GEO_COUNTRIES != ['DE']:
        raise Exception('ZDFIE._GEO_COUNTRIES is not set to ["DE"]')
    if ie._QUALITIES != ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'):
        raise Exception('ZDFIE._QUALITIES is not set to ("auto", "low", "med", "high", "veryhigh", "hd")')

test_ZDFIE()


# Generated at 2022-06-22 09:04:08.716811
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Basic unit test for ZDFBaseIE.
    """

    class MockZDFIE(ZDFBaseIE):
        IE_NAME = "Test ZDFBaseIE"
        _VALID_URL = "https://zdf.de/nachrichten/test"

    zdfbase = MockZDFIE()

    # Ensure that all the callbacks are called without any error
    zdfbase._call_api("https://example.com/api", "testid", "testitem")
    zdfbase._extract_ptmd("ptmdurl", "testid", "testtoken", "testref")
    zdfbase._extract_player("{}", "testid")



# Generated at 2022-06-22 09:04:15.293048
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase = ZDFBaseIE()
    test_url = 'http://someurl.com'
    test_video_id = '12345'
    test_item = 'someitem'
    zdfbase._call_api(test_url, test_video_id, test_item)


# Generated at 2022-06-22 09:04:25.413188
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    u = ZDFIE._VALID_URL
    assert ZDFIE._TESTS[0]['url'] == ZDFIE._VALID_URL
    assert ZDFIE._TESTS[1]['url'] == ZDFIE._VALID_URL
    assert ZDFIE._TESTS[2]['url'] == ZDFIE._VALID_URL
    assert ZDFIE._TESTS[3]['url'] == ZDFIE._VALID_URL
    assert ZDFIE._TESTS[4]['url'] == ZDFIE._VALID_URL
    assert ZDFIE._TESTS[5]['url'] == ZDFIE._VALID_URL
    assert ZDFIE._TESTS[6]['url'] == ZDFIE._VALID_URL

# Generated at 2022-06-22 09:04:32.874791
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    x = ZDFChannelIE("https://www.zdf.de/dokumentation/planet-e")
    assert x.get_url("https://www.zdf.de/dokumentation/planet-e") == "https://www.zdf.de/dokumentation/planet-e"
    assert x.channel_id() == "planet-e"


# Generated at 2022-06-22 09:06:17.645240
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_ZDFBaseIE = ZDFBaseIE()
    assert test_ZDFBaseIE.geo_verification_headers() == {'x-country-code': 'DE'}


# Generated at 2022-06-22 09:06:28.095598
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert ie.suitable('https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html')
    assert ie.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')

# Generated at 2022-06-22 09:06:32.014786
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases

    for case in get_testcases(ZDFChannelIE, 'test_ZDFChannelIE'):
        if case.cls is ZDFChannelIE:
            yield case



# Generated at 2022-06-22 09:06:34.924341
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Make sure that we can create an instance of class ZDFIE
    IE = ZDFIE()
    assert isinstance(IE, InfoExtractor)


# Generated at 2022-06-22 09:06:37.787898
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFIE
    except:
        failed = True
    else:
        failed = False
    assert not failed



# Generated at 2022-06-22 09:06:41.625065
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z = ZDFBaseIE()
    assert z._GEO_COUNTRIES == ['DE']
    assert z._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    return True



# Generated at 2022-06-22 09:06:46.460662
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE
    assert(zdfie._GEO_COUNTRIES == ['DE'])
    assert(zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-22 09:06:54.593094
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    # Call method '_call_api' with invalid parameters
    video_id = 'video_id'
    url = 'url'
    item = 'item'
    assert zdf_base_ie._call_api(url, video_id, item, None, None) is None
    # Call method '_extract_format' with invalid parameters
    video_id = 'video_id'
    formats = []
    format_urls = []
    meta = {}

# Generated at 2022-06-22 09:06:59.677015
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html', 'test')
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e', 'test')

# Generated at 2022-06-22 09:07:11.885924
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE(None)
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'