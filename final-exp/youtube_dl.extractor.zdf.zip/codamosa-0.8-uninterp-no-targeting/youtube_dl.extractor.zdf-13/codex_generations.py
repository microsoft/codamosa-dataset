

# Generated at 2022-06-22 09:00:50.020445
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    obj = ZDFIE(object)



# Generated at 2022-06-22 09:01:02.166065
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = 'https://www.zdf.de'
    ie = ZDFBaseIE()

    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    url = 'https://www.test.de'
    ie._call_api(url, 'id', 'test', 'test_token', 'test_referrer')
    assert ie._download_json.called
    ie._download_json.assert_called_once_with(
        'https://www.test.de', 'id', ie._download_json.expected_args[2], ie._download_json.expected_args[3]
    )

# Generated at 2022-06-22 09:01:08.704971
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'
    assert ie.ie_key() in ie.extractors
    assert ie.is_suitable(ie.ie_key())
    assert ie.is_suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert ie.extractors[ie.ie_key()] == ZDFIE
    assert ie.suitable(ie.ie_key())
    assert ie._TESTS
    assert ie._VALID_URL
    assert ie._call_api


# Generated at 2022-06-22 09:01:19.492982
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert not ie.suitable('https://www.phoenix.de/sendungen/ereignisse/corona-nachgehakt/wohin-fuehrt-der-protest-in-der-pandemie-a-2050630.html')

# Generated at 2022-06-22 09:01:33.364767
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert(zdfie._NAME == 'ZDF')
    assert(zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html')

# Generated at 2022-06-22 09:01:44.563669
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    #TODO: use a mock for the webpage
    webpage = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio/das-aktuelle-sportstudio-vom-06-03-2021-100.html'
    zdfie = ZDFChannelIE()
    assert zdfie.suitable(webpage) == True
    assert zdfie.suitable(url) == False
    assert zdfie._real_extract(webpage) == zdfie.playlist_result( zdfie.url_result(url, ie=ZDFIE.ie_key()), 'das-aktuelle-sportstudio')

# Generated at 2022-06-22 09:01:49.022907
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert ie._TESTS[1]['url'] == 'https://www.zdf.de/dokumentation/planet-e'

# Generated at 2022-06-22 09:02:01.762103
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        video_id = 'k4iq0g'
        # object instantiation
        zdfIE = ZDFIE()
        zdfIE.url = 'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
        zdfIE.extractor_key = zdfIE.ie_key()
        zdfIE.webpage = zdfIE._download_webpage(zdfIE.url, video_id)
        zdfIE.player = zdfIE._extract_player(zdfIE.webpage, video_id)
        print(zdfIE.extractor_key)

    except Exception as e:
        print(e)
# End of the unit test


# Generated at 2022-06-22 09:02:05.050510
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:02:07.719603
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    tester = ZDFIE()

# Generated at 2022-06-22 09:03:01.386694
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL)
    assert not ZDFChannelIE.suitable('https://www.zdf.de/serien/die-deutschen/die-deutschen-a-z-100.html')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/kultur/das-literarische-quartett/das-literarische-quartett-c-100.html')
    assert not ZDFChannelIE.suitable(ZDFIE._VALID_URL)

# Generated at 2022-06-22 09:03:03.336516
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:03:04.698309
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE("ZDFIE", "", True)


# Generated at 2022-06-22 09:03:08.806823
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Constructor should check if 'ZDFBaseIE' is indeed a subclass of InfoExtractor
    assert issubclass(ZDFBaseIE, InfoExtractor)
    # Constructor should not throw any errors
    zdftest = ZDFBaseIE(InfoExtractor())


# Generated at 2022-06-22 09:03:18.622785
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie=ZDFChannelIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert ie._TESTS[1]['url'] == 'https://www.zdf.de/dokumentation/planet-e'
    assert ie._TESTS[2]['url'] == 'https://www.zdf.de/filme/taunuskrimi/'

# Generated at 2022-06-22 09:03:21.731825
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannel = ZDFChannelIE()
    zdfchannel._real_extract(r'https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-22 09:03:23.715278
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-22 09:03:33.916817
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # test channel homepage
    ie = ZDFChannelIE()
    channel_id = 'das-aktuelle-sportstudio'
    channel_url = 'https://www.zdf.de/sport/%s' % (channel_id)
    web_page = ie._download_webpage(channel_url, channel_id)
    zdf_player = ie._extract_player(web_page, channel_url)
    channel_data = ie._call_api(
        'https://api.zdf.de/content/documents/%s.json' % channel_id,
        zdf_player, channel_url, channel_id)
    assert channel_data['id'] == channel_id

    # test channel de leder
    ie = ZDFChannelIE()

# Generated at 2022-06-22 09:03:38.369415
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """Test constructor of class ZDFIE"""
    parser = ZDFIE()
    assert parser.title() == 'zdf'


# Generated at 2022-06-22 09:03:46.186063
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.IE_NAME == 'ZDF'
    assert ie.ie_key() == ZDFIE.IE_NAME
    assert ie.VALID_URL == ZDFIE._VALID_URL
    assert ie.GEO_COUNTRIES == ZDFBaseIE._GEO_COUNTRIES
    assert ie.TEST == ZDFIE._TESTS
    assert ie.extract('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')



# Generated at 2022-06-22 09:05:19.745192
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    Test constructor for ZDFIE class
    """
    ie = ZDFIE(ZDFIE())
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:05:24.673434
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable({'url': 'https://www.zdf.de/dokumentation/planet-e'})
    assert ZDFChannelIE.suitable({'url': 'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'}) == False


# Generated at 2022-06-22 09:05:27.554140
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('youtube')
    res = ie._GEO_COUNTRIES
    assert res == ['DE']

# Generated at 2022-06-22 09:05:28.949042
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfie = ZDFBaseIE()
    assert zdfie


# Generated at 2022-06-22 09:05:30.201427
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(0, "test")

# Generated at 2022-06-22 09:05:33.205289
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # testing constructors of ZDFIE
    ZDFIE()


# Generated at 2022-06-22 09:05:37.037140
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    ZDFChannelIE('https://www.zdf.de/politik/phoenix-sendungen/')

# Generated at 2022-06-22 09:05:42.876714
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Tests to check if the constructor of the class works properly."""
    zdf_base_ie = ZDFBaseIE("youtube.com")
    assert zdf_base_ie._GEO_COUNTRIES == ["DE"]
    assert zdf_base_ie._QUALITIES == ("auto", "low", "med", "high", "veryhigh", "hd")



# Generated at 2022-06-22 09:05:44.784532
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        ZDFChannelIE()
    except Exception as e:
        assert False, e.message


# Generated at 2022-06-22 09:05:46.394023
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    instance = ZDFChannelIE()
    assert isinstance(instance, ZDFChannelIE)



# Generated at 2022-06-22 09:09:01.194152
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDF')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:09:12.901468
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    zdf_channel = ZDFChannelIE(url)
    assert zdf_channel.suitable(url) == True
    with pytest.raises(Exception) as e_info:
        assert zdf_channel.suitable(url, True) == True
    assert 'Function suitable() is not allowed' in str(e_info.value)
    assert zdf_channel.IE_NAME == 'zdf:channel'
    assert zdf_channel.INFO_LABEL == 'channel'
    assert zdf_channel._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert zdf_channel._TESTS[0]['url']

# Generated at 2022-06-22 09:09:18.171247
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_url = 'https://www.zdf.de/dokumentation/planet-e'
    ZDFChannelIE.suitable(test_url)
    ie = ZDFChannelIE(ZDFChannelIE.create_ie_instance())
    ie.setup()
    ie._download_webpage = mock.Mock()
    ie._real_extract(test_url)


# Generated at 2022-06-22 09:09:22.357159
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:09:23.632151
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:09:25.987775
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    name = 'ZDFBaseIE'
    base = ZDFBaseIE()
    assert base.__class__.__name__ == name


# Generated at 2022-06-22 09:09:32.812968
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE("ZDF", "https://www.zdf.de/politik/frontal-21/frontal-21-vom-13-dezember-2016-100.html?hmac=b8ee79dbe7d0b11c553201dcad9f01f3adec3b37a3a7f852e54b0ab6f88d6f66", "13")
    result = ie._GEO_COUNTRIES
    assert result == ["DE"]

# Generated at 2022-06-22 09:09:43.181513
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-22 09:09:46.512494
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        # check if the class can be constructed
        ZDFIE()
    except:
        # Assertion error is raised - class can not be constructed
        assert False


# Generated at 2022-06-22 09:09:53.897205
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():

    class test_ZDFChannelIE(ZDFChannelIE):
        def _extract_player(self, webpage, url, fatal=True):
            return {
                'content': 'https://path/to/content',
                'apiToken': 'test',
            }
