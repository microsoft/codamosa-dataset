

# Generated at 2022-06-22 09:00:43.883467
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        # Test the constructor of class ZDFIE
        ZDFIE()
        print("The construction of class ZDFIE was successful")
    except:
        print("The construction of class ZDFIE failed")



# Generated at 2022-06-22 09:00:53.412119
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie is not None
    assert zdf_ie._valid_url(
        'https://www.zdf.de/filme/heute-show/heute-show-vom-21.-februar-2020-100.html') == True
    assert zdf_ie._valid_url(
        'https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html') == True
    assert zdf_ie._valid_url(
        'https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html') == True

# Generated at 2022-06-22 09:00:54.875550
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-22 09:01:04.361751
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    video_urls = ['https://www.zdf.de/sport/das-aktuelle-sportstudio',
                  'https://www.zdf.de/dokumentation/planet-e',
                  'https://www.zdf.de/filme/taunuskrimi/',]
    for video_url in video_urls:
        zdf_channel_ie = ZDFChannelIE(video_url)
        zdf_channel_ie.suitable(video_url)
        zdf_channel_ie.extract(video_url)
        zdf_channel_ie._entries()
        zdf_channel_ie._extract_entries()
        zdf_channel_ie._real_extract()


# Generated at 2022-06-22 09:01:08.001090
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_ie = ZDFBaseIE()
    assert test_ie._GEO_COUNTRIES == ['DE']
    test_ie2 = ZDFBaseIE(geo_countries=['BB'])
    assert test_ie2._GEO_COUNTRIES == ['BB']


# Generated at 2022-06-22 09:01:16.661420
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        assert not ZDFChannelIE.suitable('http://example.com/')
        assert ZDFChannelIE.suitable('http://www.zdf.de/dokumentation/planet-e')
        assert ZDFChannelIE.suitable(
            'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    except Exception as e:
        print('test_ZDFChannelIE() failed:', repr(e))
        raise



# Generated at 2022-06-22 09:01:19.385085
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .common import expected
    from .test_zdf_ie import test_tests

    t = test_tests(ZDFChannelIE, expected)
    t.test()


# Generated at 2022-06-22 09:01:22.607008
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:01:28.913924
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_url = 'https://www.zdf.de/politik/konflikte-der-welt/konflikte-der-welt-100.html'
    channel = ZDFChannelIE()
    assert channel.suitable(channel_url)
    assert not channel.suitable(ZDFIE._VALID_URL)


# Generated at 2022-06-22 09:01:30.832638
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .zdf.test_suite import test_suite
    test_suite(ZDFIE)



# Generated at 2022-06-22 09:02:23.398131
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info_extractor = ZDFBaseIE("http://www.zdf.de/ZDFmediathek/hauptnavigation/startseite#/beitrag/video/2815674/Tatort---Kreise---Tatort-Preview", 1)
    assert(info_extractor.suitable("http://www.zdf.de/ZDFmediathek/hauptnavigation/startseite#/beitrag/video/2815674/Tatort---Kreise---Tatort-Preview"))
    assert(not info_extractor.suitable("http://www.zdf.de/"))



# Generated at 2022-06-22 09:02:25.708589
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE()
    zdfChannelIE._extract_player('', '')



# Generated at 2022-06-22 09:02:38.180217
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
	ie = ZDFIE()
	assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-22 09:02:41.033585
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    extractor = ZDFBaseIE()
    assert extractor._GEO_COUNTRIES == ['DE']
    assert extractor._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:02:43.837297
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()._call_api("https://zdfplayer.de", "1234", "test")


# Generated at 2022-06-22 09:02:51.155294
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = "https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html"
    ie = ZDFIE()

# Generated at 2022-06-22 09:03:00.837131
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    unit test for constructor of class ZDFIE.
    """
    # pylint: disable=too-few-public-methods
    class MyZDFIE(ZDFIE):
        """
        This Class is used in tests to ensure that ZDFIE instance could be
        constructed properly.
        """
        def __init__(self):
            super(MyZDFIE, self).__init__()
            self._initialize()
    # pylint: enable=too-few-public-methods
    zdf_ie = MyZDFIE()
    assert zdf_ie.name == "ZDF"
    assert zdf_ie.ie_key() == "zdf"
    assert zdf_ie.description == 'Zweites Deutsches Fernsehen'

# Generated at 2022-06-22 09:03:02.122603
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE()

# Generated at 2022-06-22 09:03:11.784794
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Instantiation of class ZDFIE with no parameters
    zdf_ie = ZDFIE()
    # Unit test for function _GEO_COUNTRIES
    assert zdf_ie._GEO_COUNTRIES == ['DE']
    # Unit test for function _QUALITIES
    assert zdf_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    # Unit test for function _extract_ptmd

# Generated at 2022-06-22 09:03:18.593889
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not ZDFIE.suitable('https://zap.rbb-online.de/play/media/b0e6e3c6-eb7f-42d0-b7f5-b6b200ccd837')


# Generated at 2022-06-22 09:04:45.252304
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:04:50.287673
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    pass
#    import pdb; pdb.set_trace()
#    zdf = ZDFIE()
#    zdf._extract_regular('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')

# Generated at 2022-06-22 09:04:51.759432
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    print(ie)



# Generated at 2022-06-22 09:04:54.627259
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base = ZDFBaseIE()
    assert isinstance(base, InfoExtractor)
    assert base._GEO_COUNTRIES == ['DE']
    assert base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:04:58.780457
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie is not None


# Generated at 2022-06-22 09:05:01.937169
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info = ZDFBaseIE()._download_webpage('https://info.zdf.de/playlist/playlist/playlist.json', 'video_id')
    print(info)
    assert 'content' in info

# Generated at 2022-06-22 09:05:10.995329
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() == 'ZDF'
    assert zdfie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-22 09:05:17.124810
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # test for static method ZDFChannelIE.suitable(url)
    # called by YoutubeDL in process of determining whether
    # this class is suitable for processing a specific URL
    assert ZDFChannelIE.suitable("http://www.zdf.de/notsuitable") is False
    assert ZDFChannelIE.suitable("http://www.zdf.de/filme/taunuskrimi/") is True


# Generated at 2022-06-22 09:05:21.172793
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert hasattr(ZDFBaseIE, '_GEO_COUNTRIES')
    assert hasattr(ZDFBaseIE, '_QUALITIES')
    assert hasattr(ZDFBaseIE, '_call_api')
    assert hasattr(ZDFBaseIE, '_extract_subtitles')
    assert hasattr(ZDFBaseIE, '_extract_format')
    assert hasattr(ZDFBaseIE, '_extract_ptmd')
    assert hasattr(ZDFBaseIE, '_extract_player')



# Generated at 2022-06-22 09:05:27.970949
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert re.search(
        r'(?s)data-zdfplayer-jsb=(["\'])(?P<json>{.+?})\1',
        r'data-zdfplayer-jsb=\'{ "json": "bla" }\'',
        'player JSON', default='{}', group='json') == '{ "json": "bla" }'


# Generated at 2022-06-22 09:07:00.093322
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    infoExtractor = ZDFBaseIE()
    assert infoExtractor is not None, 'Problem with constructor of class ZDFBaseIE'


# Generated at 2022-06-22 09:07:03.952185
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import doctest
    sys.stderr.write(doctest.testmod().__str__())
    """
    >>> test_ZDFChannelIE()
    TestResults(failed=0, attempted=2)
    >>>
    """



# Generated at 2022-06-22 09:07:07.024138
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = 'https://zdf.de/'
    zdf_base_ie = ZDFBaseIE()
    zdf_base_ie.suitable(url)


# Generated at 2022-06-22 09:07:13.630632
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Test the constructor of class ZDFChannelIE
    """
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')



# Generated at 2022-06-22 09:07:14.854262
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None, None)



# Generated at 2022-06-22 09:07:22.879275
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie._GEO_COUNTRIES == ['DE']
    assert zdf_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdf_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdf_ie.__name__ == 'ZDF'


# Generated at 2022-06-22 09:07:32.509615
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test with the following URL
    # https://www.zdf.de/filme/taunuskrimi/
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    zdf_c_ie = ZDFChannelIE()
    # Test the method suitable
    assert zdf_c_ie.suitable(url)
    # Test the method suitable
    assert not ZDFIE.suitable(url)
    # Test the method _real_extract
    zdf_c_ie._real_extract(url)


# Generated at 2022-06-22 09:07:37.492636
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html'
    # Test all required conditions for new constructor
    if ZDFIE.suitable(url):
        assert ZDFChannelIE is None
    else:
        assert ZDFChannelIE is not None

# Generated at 2022-06-22 09:07:43.898332
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBaseIE = ZDFBaseIE("ZDFBaseIE")
    assert(zdfBaseIE.GEO_COUNTRIES == ['DE'])
    assert(zdfBaseIE.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))

# Generated at 2022-06-22 09:07:45.034725
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()
