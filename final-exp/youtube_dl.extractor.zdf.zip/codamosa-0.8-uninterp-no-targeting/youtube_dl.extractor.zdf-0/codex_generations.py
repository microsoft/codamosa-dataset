

# Generated at 2022-06-22 09:00:52.982882
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
    except TypeError as e:
        assert e.args[0] == 'Can\'t instantiate abstract class ZDFBaseIE with abstract methods _extract_ptmd'



# Generated at 2022-06-22 09:01:03.681349
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-22 09:01:08.620061
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from zdf_channel_channel import ZDFChannelChannelIE
    return ZDFChannelChannelIE().ie_key() == ZDFChannelIE.ie_key()

# Generated at 2022-06-22 09:01:12.635782
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf.GEO_COUNTRIES == ['DE']
    assert zdf.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:01:21.416654
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    obj = ZDFChannelIE()
    assert obj.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') is True
    assert obj.suitable(
        'https://www.phoenix.de/sendungen/ereignisse/corona-nachgehakt/wohin-fuehrt-der-protest-in-der-pandemie-a-2050630.html'
    ) is False
    assert obj.suitable(
        'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html') is False

# Generated at 2022-06-22 09:01:29.101102
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
   ie = ZDFChannelIE(ZDFChannelIE._VALID_URL)
   if ie.suitable(ZDFChannelIE._VALID_URL):
       print('Debug: Extractor suitable for URL: %s' % ZDFChannelIE._VALID_URL)
   else:
       print('Debug: Extractor not suitable for URL: %s' % ZDFChannelIE._VALID_URL)


# Generated at 2022-06-22 09:01:32.847703
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ZDFChannelIE.suitable(ZDFIE._VALID_URL) is False


# Generated at 2022-06-22 09:01:33.849829
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannel()

# Generated at 2022-06-22 09:01:35.674681
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    a = ZDFIE(ZDFIE.ie_key())
    assert a.ie_key() == 'ZDFIE'
# end of test for constructor of class ZDFIE


# Generated at 2022-06-22 09:01:38.117471
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class_ = ZDFBaseIE
    ie = class_()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:02:39.056109
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # test for empty URL
    with pytest.raises(AssertionError):
        ZDFIE('')
        # test for correct URL
    zdfie = ZDFIE('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert zdfie.url == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert zdfie.url_name == 'zdf'

# Generated at 2022-06-22 09:02:43.090838
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-22 09:02:45.335363
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbaseie = ZDFBaseIE()
    return zdfbaseie


# Generated at 2022-06-22 09:02:49.290618
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE("https://www.zdf.de/nachrichten/heute")
    assert ie.suitable()
    assert ie.IE_NAME == "ZDF Channel"


# Generated at 2022-06-22 09:03:00.985697
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_url = 'https://www.zdf.de/dokumentation/planet-e'
    channel = ZDFChannelIE()
    assert channel.suitable(channel_url)
    assert channel._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert channel._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert channel._TESTS[0]['info_dict']['id'] == 'das-aktuelle-sportstudio'
    assert channel._TESTS[0]['info_dict']['title'] == 'das aktuelle sportstudio | ZDF'
   

# Generated at 2022-06-22 09:03:11.426120
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert ie._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert ie._TESTS[0]['info_dict']['id'] == '210222_phx_nachgehakt_corona_protest'

# Generated at 2022-06-22 09:03:21.815490
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():

    dummy_webpage = """
        <body>
            <script>
                var zdf = window.zdf = {
                    player: {
                        content: "https://api.zdf.de/content/data/p/dokumentation/planet-e.json?acl=%2Fcontent%2Fdata%2Fp%2Fdokumentation%2Fplanet-e.json",
                        apiToken: "f3d6b3f9b9c6b897f04b3327f8cd61b1"
                    }
                };
            </script>
        </body>
    """


# Generated at 2022-06-22 09:03:33.190493
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie.ie_key() == 'ZDF'
    assert zdf_ie.ie_key() == zdf_ie.ie_name()
    url_string = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert zdf_ie.matches(url_string)
    assert zdf_ie.matches(url_string, False)
    assert zdf_ie.matches(url_string, True)

# Generated at 2022-06-22 09:03:46.266627
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('http://www.zdf.de/ZDFmediathek/beitrag/video/2194668/ZDF heute journal%3A%20Nachrichten%20vom%2019.12.2012#/beitrag/video/2194668/ZDF heute journal%3A%20Nachrichten%20vom%2019.12.2012');
    ZDFIE('http://www.zdf.de/ZDFmediathek/beitrag/video/2194668/ZDF heute journal%3A%20Nachrichten%20vom%2019.12.2012');
    ZDFIE('http://www.zdf.de/ZDFmediathek/beitrag/video/2194668/ZDF heute journal%3A%20Nachrichten%20vom%2019.12.2012');

# Generated at 2022-06-22 09:03:47.669691
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj_ZDFBaseIE = ZDFBaseIE()


# Generated at 2022-06-22 09:05:28.714323
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    testobj = ZDFIE()
    assert testobj._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'


# Generated at 2022-06-22 09:05:31.055350
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(ZDFBaseIE(), 'https://www.zdf.de/filme/taunuskrimi/')

# Generated at 2022-06-22 09:05:36.651605
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'

    ie = ZDFIE()
    ie._real_extract(url)



# Generated at 2022-06-22 09:05:37.890717
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:05:40.221828
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE()
    assert isinstance(inst, InfoExtractor)
    assert isinstance(inst, ZDFBaseIE)

# Unit tests for _extract_player method of class ZDFBaseIE

# Generated at 2022-06-22 09:05:44.786843
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE'], ie._GEO_COUNTRIES
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'), ie._QUALITIES


# Generated at 2022-06-22 09:05:48.619548
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:05:49.998238
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:05:55.376867
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    cl = ZDFIE(None)
    cl = ZDFIE({}, 'http://foo.bar/', {}, {
        'a': 'b', 'd': 'e', 'y': 'z', 'f': None,
    })
    assert cl.a == 'b'
    assert cl.d == 'e'
    assert cl.y == 'z'
    assert cl.f == None



# Generated at 2022-06-22 09:06:01.420925
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie._call_api('https://zdf.de', '1234', 'Download') == {
        '_type': 'url',
        'id': '1234',
        'url': 'https://zdf.de',
        'ie_key': 'ZDFBaseIE',
        'display_id': 'Download',
        'title': 'Download'
    }
    assert ie._extract_subtitles({}) == {}

# Generated at 2022-06-22 09:07:45.895200
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:07:54.961390
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfie = ZDFIE
    zdfch = ZDFChannelIE
    # validate
    assert zdfch.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')
    assert zdfch.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert zdfch.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert zdfch.su

# Generated at 2022-06-22 09:08:05.610088
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-22 09:08:15.906647
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = (
        'http://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-'
        'koenigspurpur-und-jeansblau-100.html')
    # pylint: disable=protected-access
    zdf_ie = ZDFIE._build_video_result(url, ZDFIE._VALID_URL)
    assert zdf_ie.extractor.IE_NAME == 'ZDF'
    assert zdf_ie._TYPE == 'url'
    assert zdf_ie.url == url
    assert 'ZDFBaseIE' in str(type(zdf_ie.extractor))



# Generated at 2022-06-22 09:08:23.277501
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import _TESTS_INFO_KEYS

# Generated at 2022-06-22 09:08:27.319236
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_html import test_extractor_implementing
    test_extractor_implementing(ZDFChannelIE)


# Generated at 2022-06-22 09:08:28.373437
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:08:32.174169
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Args: url, video_id
    ZDFIE(url='https://www.zdf.de/dokumentation/planet-e/die-natur-ist-der-beste-baumeister-100.html', video_id='1234')



# Generated at 2022-06-22 09:08:42.133487
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from unittest import TestCase
    from ytdl.extractor import ExtractorError

    class T(TestCase):
        def test_ZDFChannel(self):
            ie = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
            self.assertEqual(ie.IE_NAME, 'ZDF:channel')

        def test_ZDF(self):
            self.assertRaises(ExtractorError, ZDFChannelIE, 'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    return T



# Generated at 2022-06-22 09:08:49.010731
# Unit test for constructor of class ZDFChannelIE