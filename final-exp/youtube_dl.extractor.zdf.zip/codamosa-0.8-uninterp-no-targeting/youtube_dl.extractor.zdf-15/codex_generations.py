

# Generated at 2022-06-22 09:00:55.729881
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    a = ZDFBaseIE('zdf.de', {})
    assert a.get_countries() == ('DE',)
    assert a.get_qualities() == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert a.get_call_api_url() == 'https://api.zdf.de/%s'


# Generated at 2022-06-22 09:00:57.046409
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zbfie = ZDFBaseIE()
    assert zbfie


# Generated at 2022-06-22 09:01:04.584438
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    instance = ZDFChannelIE()
    #print(instance)
    #print(instance.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'))
    #print(instance.suitable(ZDFChannelIE._VALID_URL))
    assert instance.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'), "Expected sports channel"
    assert instance.suitable(ZDFChannelIE._VALID_URL), "Expected valid URL"



# Generated at 2022-06-22 09:01:09.500276
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert ie.GEO_COUNTRIES == ['DE']
    assert ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:01:15.102087
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    if (ZDFIE._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'):
        print('The URL format is the same as before.')
    else:
        print('The URL format is different from before. Please update the unit test file.')


# Generated at 2022-06-22 09:01:16.112840
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE("ZDF")


# Generated at 2022-06-22 09:01:17.961476
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(ZDFBaseIE._GEO_COUNTRIES, ZDFBaseIE._QUALITIES)

# Generated at 2022-06-22 09:01:19.384834
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None)
    print(ie)


# Generated at 2022-06-22 09:01:26.035686
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE("www.zdf.de", "123", {
        "title": "Test",
        "thumbnail": "URL",
        "duration" : "123",
        "upload_date": "2015-12-12T16:54:32.000Z"
    })

# Generated at 2022-06-22 09:01:28.671099
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # implement test for ZDFIE
    pass


# Generated at 2022-06-22 09:02:04.916353
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()

    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-22 09:02:07.704035
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE.suitable(
        "https://www.zdf.de/dokumentation/planet-e")
    assert(ie == True)

# Generated at 2022-06-22 09:02:14.966821
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_IE = ZDFChannelIE("https://www.zdf.de/filme/taunuskrimi/")
    assert zdf_channel_IE.name == "ZDF" and zdf_channel_IE.ie_key() == "ZDFChannel"
    assert zdf_channel_IE.suitable("https://www.zdf.de/filme/taunuskrimi/") == True

# Generated at 2022-06-22 09:02:23.718834
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
	assert(ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/planet-e"))
	assert(not ZDFChannelIE.suitable("https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html"))
	assert(not ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html"))

# Generated at 2022-06-22 09:02:34.801938
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_cases = {
        'https://www.zdf.de/sport/das-aktuelle-sportstudio': 'das-aktuelle-sportstudio',
        'https://www.zdf.de/dokumentation/planet-e': 'planet-e',
        'https://www.zdf.de/filme/taunuskrimi/': None
    }
    for url, expected_class in test_cases.items():
        test_instance = ZDFChannelIE(url)
        assert test_instance.url == url
        if expected_class:
            assert test_instance.channel_id == expected_class
        else:
            assert ZDFIE.suitable(url)



# Generated at 2022-06-22 09:02:36.809692
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    print("\nUnit test of ZDFIE")
    ZDFIE()
    print("Unit test done\n")


# Generated at 2022-06-22 09:02:45.091147
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .ttvdb import try_get
    video_id = 'das-aktuelle-sportstudio'

# Generated at 2022-06-22 09:02:46.710369
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE(determine_ext).executor() == 'ffmpeg'


# Generated at 2022-06-22 09:02:57.861035
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE("https://www.zdf.de/dokumentation/planet-e")
    assert zdf_channel_ie.suitable("https://www.zdf.de/dokumentation/planet-e")
    assert zdf_channel_ie.suitable("https://www.zdf.de/politik/")
    assert zdf_channel_ie.suitable("https://www.zdf.de/")
    assert not zdf_channel_ie.suitable("https://www.zdf.de/dokumentation/planet-e/doku-spot-zur-uebersichtsseite-der-interaktiven-doku-zu-biene-und-mensch-100.html")


# Generated at 2022-06-22 09:03:08.579672
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    video_id = '210222_phx_nachgehakt_corona_protest'
    webpage = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    response = '{...'
    ie = ZDFIE()
    ie._download_webpage = lambda url, video_id, fatal=False: response

# Generated at 2022-06-22 09:04:01.966780
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    # Call method to raise exception if ie was constructed incorrectly
    ie._call_api("https://www.zdf.de/", "ZDF", "api")


# Generated at 2022-06-22 09:04:04.690594
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable(ZDFIE._VALID_URL)
    ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL)


# Generated at 2022-06-22 09:04:07.366322
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:04:08.406295
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDF = ZDFIE()

# Generated at 2022-06-22 09:04:21.392045
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie._VALID_URL == "https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html"

# Generated at 2022-06-22 09:04:26.330613
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert 'www.zdf.de' == ie._VALID_URL
    assert ['auto', 'low', 'med', 'high', 'veryhigh', 'hd'] == ie._QUALITIES
    assert 'DE' == ie._GEO_COUNTRIES[0]
    return True


# Generated at 2022-06-22 09:04:27.625211
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf is not None


# Generated at 2022-06-22 09:04:32.466569
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # constructor test
    assert isinstance(ZDFBaseIE(), InfoExtractor)
    # _call test
    # TODO
    # _extract_subtitles test
    assert ZDFBaseIE._extract_subtitles(None) == {}
    # _extract_format test
    # TODO
    # _extract_ptmd test
    # TODO
    # _extract_player test
    # TODO



# Generated at 2022-06-22 09:04:39.436913
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # channel_id = 'das-aktuelle-sportstudio'
    channel_id = 'das-aktuelle-sportstudio'
    url = 'https://www.zdf.de/sport/%s' % channel_id
    zdf_channel_ie = ZDFChannelIE()
    zdf_channel_ie.extract(url)



# Generated at 2022-06-22 09:04:51.320387
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.IE_NAME == ie.ie_key() == 'zdf:channel'
    assert ie.IE_DESC == 'ZDF Mediathek - Video Channels'
    assert ie.SUCCESS == True
    assert ie.SUITABLE == False
    assert ie.webpage_url == 'https://www.zdf.de/'
    assert ie.video_id == 'zdf-mediathek-trailer-100'
    assert ie.video_id_re == r'docId\s*:\s*(["\'])(?P<id>(?!\1).+?)\1'
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 09:06:44.710104
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Simple test for ZDFBaseIE using an example from the argentinian site
    """
    test_url = 'http://www.zdf.de/ZDFmediathek/beitrag/video/2026338/Fu%C3%9Flball-WM-1978-Das-Endspiel-Deutschland-gegen-Argentinien#/beitrag/video/2026338/Fu%C3%9Flball-WM-1978-Das-Endspiel-Deutschland-gegen-Argentinien'
    result = ZDFBaseIE().extract(test_url)
    assert result['id'] == '2026338'



# Generated at 2022-06-22 09:06:52.381165
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    For the given test url, create and instantiate a test object.
    """
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    test_obj = ZDFChannelIE()
    res = test_obj.extract(url)
    print('test_ZDFChannelIE:')
    for key in res.keys():
        print('  {}: {}'.format(key, res[key]))

# Intentionally no registration of ZDFChannelIE, as it's a channel


# Generated at 2022-06-22 09:07:02.543077
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE._GEO_COUNTRIES = ZDFBaseIE._GEO_COUNTRIES
    ZDFIE._QUALITIES = ZDFBaseIE._QUALITIES
    ZDFIE._extract_subtitles = ZDFBaseIE._extract_subtitles
    ZDFIE._extract_format = ZDFBaseIE._extract_format
    ZDFIE._extract_ptmd = ZDFBaseIE._extract_ptmd
    ZDFIE._extract_player = ZDFBaseIE._extract_player
    ZDFIE.ie_key = ZDFBaseIE.ie_key
    ZDFIE._call_api = ZDFBaseIE._call_api
    ZDFIE._real_extract = ZDFBaseIE._real_extract

# Generated at 2022-06-22 09:07:03.643054
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-22 09:07:08.380688
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test for https://github.com/ytdl-org/youtube-dl/issues/18994
    i = ZDFBaseIE()
    i._extract_player('<html><script>var data-zdfplayer-jsb={"foo":"bar"}; <script></html>', '123')


# Generated at 2022-06-22 09:07:15.599388
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Omit border case, since it is covered by unit test for ZDFIE
    # (ZDFBaseIE.suitable)

    # Normal case
    assert ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-22 09:07:16.742334
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    >>> i = ZDFBaseIE()
    """


# Generated at 2022-06-22 09:07:18.377375
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    print(ZDFIE(ZDFIE._downloader)._TESTS)



# Generated at 2022-06-22 09:07:20.341088
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie is not None


# Generated at 2022-06-22 09:07:21.262102
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._real_extract('link to some page')

