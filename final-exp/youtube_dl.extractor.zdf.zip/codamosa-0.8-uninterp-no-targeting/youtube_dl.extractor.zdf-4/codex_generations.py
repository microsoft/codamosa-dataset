

# Generated at 2022-06-22 09:00:48.577498
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-22 09:00:53.864677
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import urlparse
    url = u'https://www.zdf.de/dokumentation/planet-e'
    zdfchannel = ZDFChannelIE(url);
    assert zdfchannel.suitable(url) == True
    url_info = urlparse.urlparse(url);
    assert zdfchannel._match_id(url) == url_info.path.split('/')[1]
# End unit test


# Generated at 2022-06-22 09:00:55.496684
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.content_domain == 'zdf.de'
    assert ie.player_domain == 'zdf.de'
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:00:58.840853
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_ZDFBaseIE_class = ZDFBaseIE()
    assert test_ZDFBaseIE_class.GEO_COUNTRIES == ['DE']
    assert test_ZDFBaseIE_class.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:01:03.893742
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    try:
        assert ie.ie_key() == 'zdf'
    except AssertionError:
        return False

    # Ensure that the API key is not empty
    try:
        assert len(ie._API_KEY) > 0
    except AssertionError:
        return False
    return True


# Generated at 2022-06-22 09:01:13.718726
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    video_id = '210222_phx_nachgehakt_corona_protest'
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'

# Generated at 2022-06-22 09:01:17.418829
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE is not None


# Generated at 2022-06-22 09:01:26.036441
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    b1 = ZDFIE()
    assert isinstance(b1, ZDFBaseIE)
    b2 = ZDFBaseIE()
    assert isinstance(b2, ZDFBaseIE)
    b3 = ZDFIE()
    assert isinstance(b3, ZDFBaseIE)
    assert b2 == b1
    assert b3 == b2
    assert b2 == b3
    assert b1 == b3


# Generated at 2022-06-22 09:01:27.035082
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    a = ZDFIE()
    b = ZDFBaseIE()
    return (a == b)



# Generated at 2022-06-22 09:01:31.824572
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)', "URLs that match this pattern will return True"

# Generated at 2022-06-22 09:01:58.251497
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-22 09:02:01.876117
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._valid_url("https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html", "89468") == "89468"



# Generated at 2022-06-22 09:02:14.789556
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Tested using mocha
    import unittest
    # Define the class to be tested
    class TestZDFIE(unittest.TestCase):
        # Define the constructor to be tested
        def test_ZDFIE(self):
            self.assertTrue(ZDFIE.ie_key().startswith('ZDF'))
            self.assertTrue(ZDFIE.ie_key() == 'ZDF')
            self.assertTrue(ZDFIE.ie_key() in ZDFIE.ie_key())
            self.assertTrue(ZDFIE.ie_key() in IE_DESC)


    # Define all test_* test cases, i.e. all methods starting with test_
    suite = unittest.TestLoader().loadTestsFromTestCase(TestZDFIE)
    # Run all

# Generated at 2022-06-22 09:02:15.391344
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert isinstance(ZDFIE(), ZDFIE)

# Generated at 2022-06-22 09:02:18.063443
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.geo_countries == ['DE']
    assert ie.qualities == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:02:25.908758
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    player = {
        'content': 'https://api.zdf.de/content/documents/%s.json?apiVersion=2',
        'apiToken': 'Bearer abcdefghijklmnopqrstuvwxyz0123456789',
    }
    content = {
        'mainVideoContent': {
            'http://zdf.de/rels/target': {
                'http://zdf.de/rels/streams/ptmd-template': '/foo/bar/{playerId}/ptmd/documents/foo.json',
                'duration': '1234',
            },
        },
        'teaserHeadline': 'Lorem ipsum',
        'teasertext': 'Dolor sit amet',
        'title': 'Foo bar',
    }

# Generated at 2022-06-22 09:02:31.274543
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()
    assert zdf.suitable(' http://www.zdf.de/filme/taunuskrimi/')
    assert not zdf.suitable('http://www.zdf.de/dokumentation/planet-e')
    assert not ZDFIE.suitable('http://www.zdf.de/dokumentation/planet-e')

# Generated at 2022-06-22 09:02:38.051893
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE(None)._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ZDFIE(None)._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'

# test for the main extraction

# Generated at 2022-06-22 09:02:40.369340
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key('zdf') == 'ZDF'


# Generated at 2022-06-22 09:02:41.893508
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    _test_constructor(ZDFChannelIE, video_id='das-aktuelle-sportstudio')

# Generated at 2022-06-22 09:03:33.981829
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for constructor of class ZDFChannelIE.
    """
    inst = ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')
    assert inst.channel_id == 'taunuskrimi'

# Generated at 2022-06-22 09:03:37.650920
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert isinstance(ZDFChannelIE(), ZDFChannelIE)

# Generated at 2022-06-22 09:03:48.050302
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ZDFChannelIE.suitable('http://www.zdf.de/zdfneo/')
    assert ZDFChannelIE.suitable('https://www.zdf.de/1-1/my-zdf/zdf-kinder/sendungen/zdf-tivi/index.html')
    assert ZDFChannelIE.suitable('https://www.zdf.de/kinokino/kinokino-index.html')
    assert ZDFChannelIE.suitable('https://www.zdf.de/kultur/wunder-der-technik/index.html')

# Generated at 2022-06-22 09:03:50.545613
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')

# Generated at 2022-06-22 09:04:01.259189
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE._GEO_COUNTRIES == ['DE']
    assert ZDFIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    assert ZDFIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.suitable(None) == False
    assert ZDFIE.suitable({"url": "http://www.zdf.de/tatort/tatort-1101.html"}) == True

# Generated at 2022-06-22 09:04:03.218975
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    expected_instance = ZDFBaseIE()
    assert expected_instance



# Generated at 2022-06-22 09:04:10.937602
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test constructor"""
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert obj._call_api(None, None, None) is None
    assert obj._extract_subtitles(None) == {}
    assert obj._extract_ptmd(None, None, None, None) is None
    assert obj._extract_player(None, None) is None

# Generated at 2022-06-22 09:04:20.471813
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_instance = ZDFChannelIE()
    assert test_instance.suitable ('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not test_instance.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    #assert test_instance.extract('https://www.zdf.de/sport/das-aktuelle-sportstudio')

# Generated at 2022-06-22 09:04:24.677894
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:04:26.022282
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert isinstance(ZDFBaseIE(), InfoExtractor)


# Generated at 2022-06-22 09:06:07.189980
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:06:08.693978
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'zdf'


# Generated at 2022-06-22 09:06:20.950347
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    import sys
    import os
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
        if not hasattr(builtins, "unicode"):
            builtins.unicode = str

    if sys.version_info[0] >= 3:
        from unittest.mock import Mock
    else:
        from mock import Mock

    context = Mock()
    context.get = lambda x:  x

    IE = ZDFIE(context)

    url = 'http://www.zdf.de/nachrichten/-/id=100976/1bd4oji/index.html'

    webpage = IE._download_webpage(url, '100976')

# Generated at 2022-06-22 09:06:29.765071
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE as _ZDFChannelIE
    from .extractor.zdf import ZDFBaseIE
    # Remove class after test
    ZDFBaseIE.IE_DESC = ZDFBaseIE.IE_DESC.replace('ZDF Channel', 'ZDF Channel TEST')

    ZDF_CHANNEL_TEST = _ZDFChannelIE.suitable
    assert ZDF_CHANNEL_TEST('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ZDF_CHANNEL_TEST('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

    ZDFBaseIE.IE_DES

# Generated at 2022-06-22 09:06:41.678019
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    # test _VALID_URL regex
    valid_regex = r'^https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html$'
    if (ie._VALID_URL != valid_regex):
        raise AssertionError('Expected {0}; received {1}'.format(valid_regex, ie._VALID_URL))
    # test _TESTS index

# Generated at 2022-06-22 09:06:44.655508
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    client = ZDFChannelIE._build_client('', '')
    assert isinstance(client, ZDFChannelIE)



# Generated at 2022-06-22 09:06:46.559491
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

# Generated at 2022-06-22 09:06:55.866732
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-22 09:07:08.527829
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html', {'age_limit': 18})
    assert ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert ie.suitable('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')

# Generated at 2022-06-22 09:07:13.370788
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
