

# Generated at 2022-06-22 09:01:01.306949
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # This function will be replaced with a fully-fledged unit test after
    # https://github.com/rg3/youtube-dl/pull/14335 lands.
    # For the time being we just want to make sure the class constructor is
    # called and self.suitable() is called with the correct parameters
    ZDFChannelIE.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')
    zdf_channel_ie = ZDFChannelIE('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')

# Generated at 2022-06-22 09:01:08.590672
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie.IE_DESC == 'ZDF.de and ZDFmediathek and 3sat'
    assert zdf_base_ie.ie_key() == 'ZDF'
    assert zdf_base_ie._VALID_URL == r'https?://(?:www\.)?zdf\.de/[^/]+/(?P<id>[^/]+)(?:/video)?/(?P<display_id>.+?)(?:\.html)?'
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:01:12.310332
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:01:21.157390
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE() # test for constructor of ZDFIE

    content = {'http://zdf.de/rels/streams/ptmd': '/content/document/abcdefg'}
    content['http://zdf.de/rels/target']['duration'] = 60.5
    content['http://zdf.de/rels/target']['http://zdf.de/rels/streams/ptmd'] = '/content/document/abcdefg'


# Generated at 2022-06-22 09:01:23.701683
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE()
    assert(True)


# Generated at 2022-06-22 09:01:26.900723
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = infoExtractors['zdf']
    ZDFBaseIE(zdf_base_ie.compat_str, zdf_base_ie.compat_urllib)



# Generated at 2022-06-22 09:01:32.141427
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.get_domain() == 'zdf.de'
    assert ie.get_geo_countries() == ['DE']
    assert ie.get_quality() == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:01:44.113754
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    debug = False

# Generated at 2022-06-22 09:01:47.021243
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    ie = ZDFIE()
    ie.extract(test_url)
    # print(ie.results)
    assert ie.results['url'] == test_url


# Generated at 2022-06-22 09:01:49.737691
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE(ZDFBaseIE)
    # Asserting that ZDFIE is the type of zdfIE
    assert zdfIE.__class__ == ZDFIE

if __name__ == '__main__':
    test_ZDFIE()

# Generated at 2022-06-22 09:02:13.548675
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()

# Generated at 2022-06-22 09:02:20.944305
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    match = re.search(r'VideoPageInfo\((?P<json>{.+?})\)', "VideoPageInfo({'videoId': '32276028', 'title': 'Welcome to Germany'})")
    assert match.group('json') == "{'videoId': '32276028', 'title': 'Welcome to Germany'}"
    ZDFBaseIE.test()
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert len(ZDFBaseIE._QUALITIES) == 6
    assert len(qualities(ZDFBaseIE._QUALITIES)) == 6


# Generated at 2022-06-22 09:02:30.928898
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    og_source = '<meta property="og:source" content="https://www.zdf.de/politik/phoenix-sendungen/phoenix-im-netz-100.html">'
    og_url = '<meta property="og:url" content="https://www.zdf.de/politik/phoenix-sendungen/phoenix-im-netz-100.html">'
    og_image = '<meta property="og:image" content="https://zdf.de/t/l/t/teaser_phx_im_netz_og.jpg">'
    og_site_name = '<meta property="og:site_name" content="ZDF">'

# Generated at 2022-06-22 09:02:38.834982
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test for description of function _real_extract in ZDFChannelIE
    from youtube_dl.extractor import ZDFChannelIE
    # Test with following url in _TESTS in ZDFChannelIE
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    # Test with following arguments in _real_extract in ZDFChannelIE
    channel_id = 'taunuskrimi'
    webpage = """<html> ... </html>"""
    # Test instances of ZDFChannelIE
    ZDFChannelIE._real_extract(ZDFChannelIE, url, channel_id, webpage)

# Generated at 2022-06-22 09:02:45.975752
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE("https://www.zdf.de/")
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:02:51.070214
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:02:59.097579
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi')
    ZDFChannelIE.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html')

# Generated at 2022-06-22 09:03:09.301986
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE._GEO_COUNTRIES
    ZDFBaseIE._QUALITIES
    ZDFBaseIE._call_api("http://example.com", "123", "item", "token", "referer")
    ZDFBaseIE._extract_subtitles("src")
    ZDFBaseIE._extract_format("id", [], set(), {'url': 'url', 'type': 'type',
                                                'mimeType': 'mimeType', 'quality': 'quality',
                                                'language': 'language'})
    ZDFBaseIE._extract_ptmd("http://example.com", "123", "token", "referer")
    ZDFBaseIE._extract_player("webpage", "123", fatal=True)

# Generated at 2022-06-22 09:03:17.265212
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    # assert zdf._TESTS == [dict(), dict()]
    assert zdf._extract_player == ZDFBaseIE._extract_player
    assert zdf._extract_ptmd == ZDFBaseIE._extract_ptmd



# Generated at 2022-06-22 09:03:23.643279
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .zdf import ZDFIE
    from .youtube import YoutubeIE
    assert ZDFBaseIE.ie_key() == 'ZDFBase'
    info_extractors = [ZDFIE, YoutubeIE]
    assert ZDFBaseIE.suitable(info_extractors) == False
    assert ZDFBaseIE.suitable(info_extractors, url="http://zdf.de") == True
    assert ZDFBaseIE.suitable(info_extractors, url="http://youtube.com") == False

# Generated at 2022-06-22 09:04:11.012049
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert(instance._GEO_COUNTRIES == ['DE'])
    assert(instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-22 09:04:14.092279
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None, ZDFIE._download_webpage, ZDFIE._download_json)



# Generated at 2022-06-22 09:04:24.749378
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class TestZDFBase(ZDFBaseIE):
        IE_NAME = 'test_zdfbase'
        _VALID_URL = r'https?://example.com/(?P<id>.+?)'
        _TEST = {
            'url': 'https://example.com/test',
            'info_dict': {
                'id': 'test',
                'extractor_key': 'ZDF',
            },
            'params': {
                'skip_download': True,
            },
        }
    TestZDFBase()._download_webpage('https://example.com/test', 'test', 'abc')
    assert 'abc' == TestZDFBase()._download_json('https://zdf.de/test', 'test', 'abc')['abc']

# Generated at 2022-06-22 09:04:26.454712
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert instance._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-22 09:04:28.183113
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/nachrichten/heute-journal')


# Generated at 2022-06-22 09:04:29.837078
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie is not None

# Generated at 2022-06-22 09:04:32.668325
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    player = ZDFBaseIE({})
    assert player._GEO_COUNTRIES == ['DE']
    assert player._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:04:37.745123
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import unittest
    from ykdl.tests.extractors.test_common import MockInfoExtractor
    class TestZDFBaseIE(ZDFBaseIE, MockInfoExtractor):
        pass
    TestZDFBaseIE.test()

# Generated at 2022-06-22 09:04:38.917775
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie == ZDFIE()


# Generated at 2022-06-22 09:04:41.073445
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:06:13.981553
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie


# Generated at 2022-06-22 09:06:18.629749
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:06:19.787279
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()



# Generated at 2022-06-22 09:06:29.174789
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == "https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html"
    assert ie._TESTS[0]["url"] == "https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html"
    assert ie._TESTS[0]["md5"] == "34ec321e7eb34231fd88616c65c92db0"

# Generated at 2022-06-22 09:06:32.322937
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Constructor of class ZDFChannelIE
    """
    ZDFChannelIE()


# Generated at 2022-06-22 09:06:35.176093
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    res = re.match(r'^[a-zA-Z]\w{3,}$',ZDFBaseIE.__name__)
    assert res is not None



# Generated at 2022-06-22 09:06:38.094479
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE()
    assert zdfChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-22 09:06:49.724798
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = "https://www.zdf.de/comedy/heute-show/heute-show-vom-5-5-2017-100.html"

# Generated at 2022-06-22 09:06:55.787431
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    TestUnitBase.test_class_unit_for_ie(
        ZDFChannelIE.ie_key(), ZDFChannelIE, [
            'https://www.zdf.de/serien/heute-show/heute-show-vom-15-januar-2016-100.html',
            'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html',
        ])


# Generated at 2022-06-22 09:06:59.267135
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE("https://www.zdf.de/sport/das-aktuelle-sportstudio")

# Generated at 2022-06-22 09:08:46.455047
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')


# Generated at 2022-06-22 09:08:49.651382
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    export_tests('ZDFChannelIE', 'zdf_channel')


# Generated at 2022-06-22 09:08:51.739504
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE().ie_key() == 'ZDF'


# Generated at 2022-06-22 09:08:54.353636
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.playlist_id, 'playlist_id should not be empty'


# Generated at 2022-06-22 09:08:57.108391
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-22 09:09:03.802867
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from youtube_dl.extractor import platform

    # Check the constructor of class ZDFBaseIE
    #
    # Check that an instance of class ZDFBaseIE is created with the
    # correct arguments
    #
    ie = ZDFBaseIE(platform='platform')

    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:09:05.691023
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    assert isinstance(instance, ZDFBaseIE)


# Generated at 2022-06-22 09:09:07.788059
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFIE.suitable(ZDFIE._VALID_URL)

# Generated at 2022-06-22 09:09:09.606372
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL)



# Generated at 2022-06-22 09:09:16.976608
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Please enter your api token below
    api_token = "NotImplemented"
    player = ZDFIE()._download_json(
        'https://zdfplayer.de/api/v1/playerconfig/pc/ngplayer_2_4',
        'Test', 'Downloadng player 2_4',
        headers={'Api-Auth': 'Bearer %s' % api_token})
    assert player['apiToken'] == api_token
    video_id = "210222_phx_nachgehakt_corona_protest"