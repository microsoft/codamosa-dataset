

# Generated at 2022-06-22 09:00:49.055822
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
    except TypeError as err:
        return 'Wrong constructor for class ZDFBaseIE: %s' % err
    return False


# Generated at 2022-06-22 09:00:53.760040
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """To make sure it is compatible with https://www.zdf.de/geostorm"""
    url = 'https://www.zdf.de/geostorm'
    obj = ZDFChannelIE()
    obj.suitable(url)


# Generated at 2022-06-22 09:00:55.173496
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()



# Generated at 2022-06-22 09:01:02.121369
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Testing extractor methods of class ZDFIE
# _extract_entry

# Generated at 2022-06-22 09:01:03.026094
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-22 09:01:06.845283
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:01:17.267024
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Test creating instance of _ZDFChannelIE.
    """
    ie = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert ie.suitable('')
    assert not ie.suitable('https://www.zdf.de/politik/wahl-2018/wahl-2018-uebersichtsseite-100.html')
    assert ie.extract_id('') == 'dokumentation/planet-e'
    assert ie.extract_id('https://www.zdf.de/wissenschaft/nano/nano-2019-01-06-100.html') == 'wissenschaft/nano'

# Generated at 2022-06-22 09:01:26.760901
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._VALID_URL == ZDFIE._VALID_URL
    assert ZDFIE()._TESTS == ZDFIE._TESTS
    assert ZDFIE()._GEO_COUNTRIES == ZDFIE._GEO_COUNTRIES
    assert ZDFIE()._QUALITIES == ZDFIE._QUALITIES
    assert ZDFIE()._TESTS == ZDFIE._TESTS
    #assert ZDFIE()._extract_entry()


# Generated at 2022-06-22 09:01:36.348391
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    def test_case(video_id, video_url, expect_VIDEO_INFO):
        VIDEO_INFO = ZDFIE()._extract_mobile(video_id)
        VIDEO_INFO['url'] = video_url
        assert VIDEO_INFO == expect_VIDEO_INFO


# Generated at 2022-06-22 09:01:39.241026
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert_equal(ie.__class__.__name__, ZDFIE.__name__)
    assert_equal(ie.ie_key(), 'ZDF')
    assert_equal(ie.ie_key, ZDFIE.ie_key)
    assert_equal(ie._VALID_URL, ZDFIE._VALID_URL)
    assert_equal(ie._TESTS, ZDFIE._TESTS)



# Generated at 2022-06-22 09:02:07.657811
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    def test_ZDFIE_extract_regular(url, player, video_id):
        def test_ZDFIE_extract_entry(url, player, content, video_id):
            title = content.get('title') or content['teaserHeadline']
            t = content['mainVideoContent']['http://zdf.de/rels/target']
            ptmd_path = t.get('http://zdf.de/rels/streams/ptmd')
            if not ptmd_path:
                ptmd_path = t['http://zdf.de/rels/streams/ptmd-template'].replace(
                        '{playerId}', 'ngplayer_2_4')

# Generated at 2022-06-22 09:02:14.152837
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    #https://www.zdf.de/politik/abendschau
    # https://www.zdf.de/politik/abendschau/nachrichten-abendschau-1614.html
    url = 'https://www.zdf.de/politik/abendschau/nachrichten-abendschau-1614.html'
    ie = ZDFChannelIE()
    assert ie.suitable(url)
    print('test_ZDFChannelIE finish')

# Generated at 2022-06-22 09:02:17.438774
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    for url, res in [
        ('https://www.zdf.de/sport/das-aktuelle-sportstudio', {'id': 'das-aktuelle-sportstudio'}),
        ('https://www.zdf.de/dokumentation/planet-e', {'id': 'planet-e'}),
        ('https://www.zdf.de/filme/taunuskrimi/', None)
    ]:
        assert (ZDFChannelIE, url).res == res

# Generated at 2022-06-22 09:02:20.762083
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(ZDFBaseIE.ie_key())
    assert ie._GEO_COUNTRIES
    assert ie._QUALITIES


# Generated at 2022-06-22 09:02:21.867363
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None)

# Generated at 2022-06-22 09:02:24.116737
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None)


# Generated at 2022-06-22 09:02:25.389186
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test calling the constructor of the class ZDFIE
    zdfie = ZDFIE()

# Generated at 2022-06-22 09:02:29.083905
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_url = "https://www.zdf.de/mehrspieler"
    ie = ZDFChannelIE()
    # assert(ie.suitable(channel_url))
    # ie.extract(channel_url)

# Generated at 2022-06-22 09:02:33.538072
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    player = {
        'content': 'http://zdf.de/content/content.json',
        'apiToken': '6e06f6be-ed0b-3a73-9a7a-9d0b1f0727aa',
    }
    content = {
        'mainVideoContent': {
            'http://zdf.de/rels/target': {
                'http://zdf.de/rels/streams/ptmd-template': '{playerId}',
            },
        },
    }
    zdfIE = ZDFIE('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html', player, content)

# Generated at 2022-06-22 09:02:37.640787
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:03:05.974640
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:03:13.367707
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = '56960'
    ie = ZDFBaseIE()
    # player
    webpage = ie._download_webpage(
        ie._build_url(video_id),
        video_id)
    player = ie._extract_player(webpage, video_id)
    # data
    data = player.get('data')
    assert data['id'] == video_id
    assert re.match(r'https?://.*\.(mp4|m3u8)$', data['m3u8'])
    assert data['subtitleUrl'].startswith('https://')
    assert data['subtitleUrl'].endswith('.ttml')
    assert data['subtitleUrl'].find(video_id) > 0
    # ptmd
    ptmd_url = data['ptmdUrl']

# Generated at 2022-06-22 09:03:17.316483
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-22 09:03:18.410179
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return ZDFChannelIE()


# Generated at 2022-06-22 09:03:21.857867
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = mpx_IE(ZDFChannelIE)
    channel_url = 'https://www.zdf.de/dokumentation/planet-e'
    ie.get_info(channel_url)


# Generated at 2022-06-22 09:03:29.390592
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # first argument is the variable that will be bound to the
    # initialized instance of the class; the variable is not used
    # in this test case
    # second argument is the URL for which to run the unit test
    # third argument is optional;
    #  if present, unit test is for a regular ZDF channel (playlist)
    #  if not present, unit test is for a news article
    (ZDFChannelIE, 'https://www.zdf.de/nachrichten/heute-journal').test()


# Generated at 2022-06-22 09:03:35.946467
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE("www.zdf.de/politik/phoenix-sendungen")
    ZDFIE("www.zdf.de/filme/filme-sonstige")
    # make sure that this line doesn't cause an exception
    ZDFIE("www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html")


# Generated at 2022-06-22 09:03:36.550337
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()


# Generated at 2022-06-22 09:03:46.353998
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfch = ZDFChannelIE()
    zdfch.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True
    zdfch.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio.html') == False
    zdfch.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html') == False
    zdfch.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio.html') == False

# Generated at 2022-06-22 09:03:57.513511
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from re import sub
    from json import loads
    from unittest import TestCase

    from . import ExtractorTest

    valid_url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    webpage = ExtractorTest.download_webpage(
        valid_url, 'ZDFChannelIE_test')

    class TestZDFChannelIE(TestCase):

        def test_ZDFChannelIE_constructor(self):
            self.assertEqual(
                ZDFChannelIE.suitable(valid_url),
                True)

# Generated at 2022-06-22 09:04:47.030829
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try: 
        print(ZDFIE())
    except Exception as e:
        print(e)


# Generated at 2022-06-22 09:04:51.148903
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE(ZDFBaseIE.ie_key(), ZDFBaseIE.ie_key())
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:04:53.694260
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import _test_constructor
    # Test for a playlist
    _test_constructor(ZDFChannelIE, 'https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-22 09:04:55.576791
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assertZDFIE(ZDFIE)


# Generated at 2022-06-22 09:05:01.544116
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None, 'http://example.com/')._real_extract('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')



# Generated at 2022-06-22 09:05:06.398820
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    info = tests_lib.get_info_from_url(ZDFChannelIE.ie_key(), "https://www.zdf.de/dokumentation/planet-e")
    content = [i for i in info['entries'] if i['id'] == '150306_planet-e_planet-e8_doku']
    assert len(content) == 1
    assert content[0]['extractor_key'] == 'ZDF'

# Generated at 2022-06-22 09:05:18.195919
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/nachrichten/politik'

# Generated at 2022-06-22 09:05:21.273564
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    my_test_ZDFChannelIE = ZDFChannelIE()
    my_test_ZDFChannelIE._real_extract("https://www.zdf.de/dokumentation/planet-e")


# Generated at 2022-06-22 09:05:32.423168
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE({})
    assert ie.IE_NAME == 'ZDF'
    assert ie.IE_DESC == 'ZDF, ZDFMediathek and 3Sat'

# Generated at 2022-06-22 09:05:40.010917
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    urls = ['https://www.zdf.de/dokumentation/planet-e', 'https://www.zdf.de/sport/das-aktuelle-sportstudio', 'https://www.zdf.de/filme/taunuskrimi/']
    for url in urls:
        assert ZDFChannelIE._VALID_URL.match(url), url
    for url in urls:
        assert ZDFChannelIE.suitable(url), url


# Generated at 2022-06-22 09:07:15.492476
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:07:20.084415
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase = ZDFBaseIE()
    assert zdfbase._GEO_COUNTRIES == ['DE']
    assert zdfbase._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:07:22.148129
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._real_extract(
        'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')



# Generated at 2022-06-22 09:07:25.468325
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase = ZDFBaseIE("test_ZDFBaseIE")
    assert zdfbase.get_geo_countries() == ['DE']
    assert zdfbase.get_ie_key() == 'zdf'


# Generated at 2022-06-22 09:07:26.344888
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-22 09:07:30.121260
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        ZDFChannelIE("https://www.zdf.de/dokumentation/planet-e")
    except:
        print("Error: Failed to initialize class ZDFChannelIE")

# Generated at 2022-06-22 09:07:39.751260
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases
    from .common import InfoExtractor

    # Let's assume that this pattern can be used to get all the
    # channels (not only the ones that ZDFChannelIE is designed
    # to handle).
    extractor = InfoExtractor()
    url = "https://www.zdf.de/sport/das-aktuelle-sportstudio.html"
    webpage = extractor._download_webpage(url, url)
    # extractor._parser = lambda s: '<div>{0}</div>'.format(s)
    extractor._search_regex = lambda s, p, n: '<div>{0}</div>'.format(s)
    extractor._html_search_regex = extractor._search_regex

    items = []

# Generated at 2022-06-22 09:07:41.332259
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.ie_key() == 'zdf'


# Generated at 2022-06-22 09:07:45.036578
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert instance._GEO_COUNTRIES == ['DE']
    assert instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:07:48.575856
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie = ZDFIE('test')
    ie = ZDFIE('test', 'test2')

