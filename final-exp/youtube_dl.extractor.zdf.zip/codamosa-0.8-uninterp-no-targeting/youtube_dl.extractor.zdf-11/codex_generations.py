

# Generated at 2022-06-22 09:00:48.017895
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()

# Generated at 2022-06-22 09:01:00.420915
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 09:01:04.539499
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert hasattr(zdfie, "_extract_entry")
    assert hasattr(zdfie, "_extract_regular")
    assert hasattr(zdfie, "_extract_mobile")



# Generated at 2022-06-22 09:01:08.284617
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE().suitable("https://www.zdf.de/politik/tagesgespräch")

# Generated at 2022-06-22 09:01:12.589610
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base_ie = ZDFBaseIE()
    assert base_ie._GEO_COUNTRIES == ['DE']
    assert base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:01:15.101323
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']

# Test ZDFBaseIE._extract_ptmd() method

# Generated at 2022-06-22 09:01:19.720497
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.IE_NAME == 'ZDF'
    assert ie.IE_DESC == 'Zweites Deutsches Fernsehen'
    assert ie._VALID_URL == None


# Generated at 2022-06-22 09:01:23.985953
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_test = ZDFChannelIE()
    assert zdf_channel_test


# Generated at 2022-06-22 09:01:28.767898
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class type_check:
        def __init__(self, *args, **kwargs):
            pass

    zdf = type_check(*[], **{})
    assert isinstance(zdf, type_check)



# Generated at 2022-06-22 09:01:37.314904
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE
    url = "https://www.zdf.de/dokumentation/planet-e"
    assert ZDFChannelIE.suitable(url)
    assert ZDFChannelIE.ie_key() == "ZDFChannel"
    zie = ZDFChannelIE()
    zie._download_json = lambda url, video_id: {'document': {}}
    zie._call_api = lambda url, video_id, note, api_token, referrer: {'module': []}

# Generated at 2022-06-22 09:02:24.980745
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE

    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')


# Generated at 2022-06-22 09:02:26.207062
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    IE = ZDFIE()
    assert IE.ie_key() == ZDFIE.ie_key()


# Generated at 2022-06-22 09:02:36.603675
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()

    hlstoken = "bcxjdsbcxmbcjdsbcjkdsbckjdsbcksdbckjsdbckj"

# Generated at 2022-06-22 09:02:39.341256
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    # Tests that _VALID_URL is not empty
    assert zdf._VALID_URL != ''

# Unit tests for methods of class ZDFIE

# Generated at 2022-06-22 09:02:41.511381
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()


# Generated at 2022-06-22 09:02:45.325791
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'


# Generated at 2022-06-22 09:02:48.632867
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert "ZDFChannelIE" in globals()
    assert issubclass(ZDFChannelIE, GenericIE)
    assert isinstance(ZDFChannelIE(), GenericIE)


# Generated at 2022-06-22 09:02:59.011916
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    unit_test_ZDFIE = ZDFIE()
    assert unit_test_ZDFIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert unit_test_ZDFIE._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert unit_test_ZDFIE._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'

# Generated at 2022-06-22 09:03:01.741113
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
        assert False
    except Exception:
        assert True



# Generated at 2022-06-22 09:03:07.540744
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert isinstance(zdf_base_ie, InfoExtractor)


# Generated at 2022-06-22 09:03:52.754746
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')._real_extract('')


# Generated at 2022-06-22 09:03:54.077892
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('ZDFBaseIE', 'ZDF')

# Generated at 2022-06-22 09:03:59.282807
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    def callback(value):
        return 'zdf_base_ie'

    obj = ZDFBaseIE(callback)
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:04:03.263777
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:04:04.856357
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert isinstance(ie, ZDFBaseIE)


# Generated at 2022-06-22 09:04:06.033008
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE().extractor_key() == 'ZDFIE'


# Generated at 2022-06-22 09:04:06.917344
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-22 09:04:11.696467
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/') == False
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e/') == True



# Generated at 2022-06-22 09:04:14.296002
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'ZDF'


# Generated at 2022-06-22 09:04:22.491920
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    ZDFIE()._extract_mobile('151025_magie_farben2_tex')
    ZDFIE()._extract_mobile('141007_ab18_10wochensommer_film')
    ZDFIE()._extract_mobile('210222_phx_nachgehakt_corona_protest')

# Generated at 2022-06-22 09:05:54.531853
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE(None)
    assert zdfie

# Generated at 2022-06-22 09:05:55.922471
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None)



# Generated at 2022-06-22 09:05:59.092015
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable(ZDFChannelIE._VALID_URL) == True
    assert ie.suitable(ZDFIE._VALID_URL) == False

# Generated at 2022-06-22 09:06:02.860340
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info_extractor = ZDFBaseIE()
    assert info_extractor._GEO_COUNTRIES == ['DE']
    assert info_extractor._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:06:05.936535
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert (
        ZDFChannelIE.ie_key() == 'ZDF:channel')



# Generated at 2022-06-22 09:06:12.414491
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from you_get.extractors import cdn
    assert "ZDFChannelIE" == ZDFChannelIE(cdn.VideoExtractor).name
    assert ZDFChannelIE(cdn.VideoExtractor)._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 09:06:17.591833
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-22 09:06:28.067405
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_id = 'das-aktuelle-sportstudio'
    channel_title = 'das aktuelle sportstudio | ZDF'
    entries = [
        RegexNotFoundError('1.html', ''),
        RegexNotFoundError('2.html', ''),
        RegexNotFoundError('3.html', ''),
        RegexNotFoundError('4.html', ''),
        RegexNotFoundError('5.html', ''),
    ]

# Generated at 2022-06-22 09:06:32.373082
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'zdf'


# Generated at 2022-06-22 09:06:36.806230
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test for constructor of class ZDFBaseIE."""
    class_name = 'ZDFBaseIE'
    klass = globals()[class_name]
    instance = klass(None)
    assert isinstance(instance, klass)
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-22 09:09:51.668572
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Importing directly causes an error as the class is not defined
    from ..ZDFBase import ZDFBaseIE
    ie = ZDFBaseIE(null_out(), {}, ZDFIE.ie_key())
    assert ie is not None
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-22 09:09:52.995014
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE()
    return channel, channel._VALID_URL, channel._TESTS


# Generated at 2022-06-22 09:09:54.279264
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-22 09:09:58.864221
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import sys
    if sys.version_info.major < 3:
        import imp
        imp.reload(sys)
        sys.setdefaultencoding('utf-8')
    v = ZDFBaseIE()
    assert v is not None
    assert isinstance(v, InfoExtractor)



# Generated at 2022-06-22 09:10:00.096042
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_ie = ZDFBaseIE()


# Generated at 2022-06-22 09:10:03.752322
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE(None)._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'



# Generated at 2022-06-22 09:10:08.442950
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE('ZDF', 'ZDF')
    assert zdf_channel_ie._VALID_URL == r'https?://(?:www\.zdf\.de|zdf\.de)(?P<id>[^/?#&]+)'

