

# Generated at 2022-06-24 13:50:05.165130
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE("Test", "1")
    assert ie._GEO_COUNTRIES == ["DE"]
    assert ie._QUALITIES == ("auto", "low", "med", "high", "veryhigh", "hd")


# Generated at 2022-06-24 13:50:07.220641
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_ZDFBaseIE = 'test_ZDFBaseIE'
    assert(test_ZDFBaseIE in globals())


# Generated at 2022-06-24 13:50:13.988988
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z = ZDFBaseIE
    assert z._GEO_COUNTRIES == ['DE']
    assert z._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    # Test _call_api
    # TODO
    # Test _extract_format
    # TODO
    # Test _extract_ptmd
    # TODO
    # Test _extract_player
    # TODO


# Generated at 2022-06-24 13:50:24.246034
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .. import ZDFBaseIE

# Generated at 2022-06-24 13:50:25.974593
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie is not None


# Generated at 2022-06-24 13:50:30.814492
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:39.984784
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
	# Check extraction of player JSON
	if webpage is None:
		raise Exception(
			'No webpage given for test_ZDFBaseIE()')

		# Extract JSON source code
		player_json = re.findall(
			r'(?s)data-zdfplayer-jsb=(["\'])(?P<json>{.+?})\1', webpage,
			'player JSON', default='{}' if not fatal else NO_DEFAULT,
			group='json')

		# Convert string to JSON Dict
		player = json.loads(player_json)

	# Test player JSON
	if not isinstance(player, dict):
		raise Exception(
			'Player JSON is not a dictionary')


# Generated at 2022-06-24 13:50:43.545297
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:44.241562
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert 'ZDFBaseIE' == ZDFBaseIE.ie_key()



# Generated at 2022-06-24 13:50:45.380478
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:50:50.958565
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE([
        {'url': 'https://www.zdf.de/filme/taunuskrimi/'},
        {'url': 'https://www.zdf.de/politik/fernsehen-aus-dem-ausland/fernsehen-aus-dem-ausland-100.html'}
    ])
    assert zdf_channel_ie._compat_str == compat_str

# Generated at 2022-06-24 13:50:54.864067
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    _ZDFBaseIE = ZDFBaseIE()
    assert _ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert _ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:56.907232
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('test', 'http://zdf.de/')
    assert True

# Generated at 2022-06-24 13:51:09.003460
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    ZDFChannelIE._download_webpage = lambda self, url, video_id: '<html/>'
    ZDFChannelIE._og_search_title = lambda webpage, default=None: 'taunuskrimi',
    ZDFChannelIE._real_extract = lambda self, url: '<html/>'
    ZDFChannelIE._extract_player = lambda webpage, url, fatal=True: {}
    ZDFChannelIE.suitable = lambda url: True
    ZDFChannelIE.playlist_result = lambda entries, id_, title: (entries, id_, title)
    info = ZDFChannelIE()._real_extract(url)
    assert len(info) == 3

# Generated at 2022-06-24 13:51:10.926279
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
        assert True
    except NameError as e:
        assert False, "Failed to instantiate ZDFBaseIE constructor"



# Generated at 2022-06-24 13:51:12.175809
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE();


# Generated at 2022-06-24 13:51:18.988407
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/politik/frontal-21/frontal-21-in-voller-laenge-100.html'
    info_dict = {'id': '210222_phx_nachgehakt_corona_protest', 'ext': 'mp4', 'title': 'Wohin führt der Protest in der Pandemie?', 'description': 'md5:7d643fe7f565e53a24aac036b2122fbd', 'duration': 1691, 'timestamp': 1613948400, 'upload_date': '20210221'}
    assert ZDFIE().suitable(url)
    assert ZDFChannelIE().suitable(url) == False
    assert ZDFIE()._real_extract(url) == info_dict

# Generated at 2022-06-24 13:51:25.735748
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
  test_cases = [
      ('https://www.zdf.de/sport/das-aktuelle-sportstudio', 'das-aktuelle-sportstudio'),
      ('https://www.zdf.de/dokumentation/planet-e', 'planet-e'),
  ]
  for test_case in test_cases:
    assert ZDFChannelIE._match_id(test_case[0]) == test_case[1]



# Generated at 2022-06-24 13:51:29.798957
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    zcie = ZDFChannelIE()
    zcie.suitable(test_url)
    zcie._real_extract(test_url)

# Generated at 2022-06-24 13:51:43.440809
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    urls_to_test = (
        ("http://www.zdf.de/politik/ausland/ausland-aktuell", "ausland-aktuell", "ausland aktuell"),
        ("http://www.zdf.de/nachrichten/heute", "heute", "heute"),
    )
    for url , channelID , title in urls_to_test:
        zdfChannel = ZDFChannelIE(url)
        assert zdfChannel._match_id(url) == channelID
        assert zdfChannel._og_search_title(zdfChannel._download_webpage(url, channelID), fatal=False) == title
        assert zdfChannel.suitable(url) == True



# Generated at 2022-06-24 13:51:45.787213
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # This test's purpose is to validate static class variables
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']

# Generated at 2022-06-24 13:51:46.787674
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:51:49.770394
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = "https://www.zdf.de/sport/das-aktuelle-sportstudio"
    ZDFChannelIE().suitable(url)

# Generated at 2022-06-24 13:51:54.287703
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ie.extractors
    assert ie.extractors[ie.ie_key()](None) == ie
    assert ie.completeness_sum == 0

# Unit tests for decorator @require_permission_of_class

# Generated at 2022-06-24 13:51:56.389113
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    instance = ZDFChannelIE()
    assert isinstance(instance, ZDFChannelIE)


# Generated at 2022-06-24 13:52:04.162972
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    example_url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    if example_url not in globals().keys():
        print('Error: example_url {} not in globals keys.'.format(example_url))
    else:
        print('Success: example_url {} in globals keys.'.format(example_url))


# Generated at 2022-06-24 13:52:06.652161
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test whether the constructor of ZDFBaseIE works
    ZDFBaseIE("http://zdf.de/videos/")



# Generated at 2022-06-24 13:52:10.439353
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:52:18.954415
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():

  # Test with a valid input that has entries
  channelIE = ZDFChannelIE("https://www.zdf.de/sport/das-aktuelle-sportstudio")
  channelIE.extract()
  assert channelIE.getId() is not None
  assert channelIE.getId() == "das-aktuelle-sportstudio"
  assert channelIE.getTitle() is not None
  assert channelIE.getTitle() == "das aktuelle sportstudio | ZDF"
  assert channelIE.getEntries() is not None
  assert len(channelIE.getEntries()) > 0

  # Test with a valid input that does not have any entries
  channelIE = ZDFChannelIE("https://www.zdf.de/filme/taunuskrimi/")
  channelIE

# Generated at 2022-06-24 13:52:29.999550
# Unit test for constructor of class ZDFIE
def test_ZDFIE():

    # test default constructor
    zdf = ZDFIE()
    assert zdf.GEO_COUNTRIES == ['DE']
    assert zdf.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    # test constructor with given geo and qualities
    zdf = ZDFIE(
        GEO_COUNTRIES=["DE","AT"],
        QUALITIES=('auto', 'low', 'med', 'high', 'veryhigh', 'hd', 'super'))
    assert zdf.GEO_COUNTRIES == ['DE', 'AT']
    assert zdf.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd', 'super')


# Generated at 2022-06-24 13:52:34.471568
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # pylint: disable=assignment-from-no-return
    zdfChannelIE = ZDFChannelIE('ZDFChannelIE', 'http://zdf.de')
    assert zdfChannelIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+).html'
    # pylint: enable=assignment-from-no-return

# Generated at 2022-06-24 13:52:39.115470
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._call_api("http://www.zdf.de/ZDFmediathek/content/12345").status_code == 200
    assert ie._call_api("http://www.zdf.de/ZDFmediathek/content/12345","12345", "test").status_code == 200


# Generated at 2022-06-24 13:52:45.736110
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:52:49.541061
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')


# Generated at 2022-06-24 13:52:50.925482
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None)
# End unit test



# Generated at 2022-06-24 13:52:54.197668
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(InfoExtractor())._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE(InfoExtractor())._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:52:57.234807
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:53:00.020303
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    i = ZDFBaseIE()
    assert i is not None


# Generated at 2022-06-24 13:53:01.278994
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:53:13.925772
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
  class UnitTestZDFChannelIE(ZDFChannelIE):
    def __init__(self, *args, **kwargs):
      # Superclass (ZDFChannelIE) is expected to use the .url_result() method, which needs
      # the referer URL for some video extractors. It is hard to construct such a valid
      # URL, so we just pass an empty string to the superclass constructor.
      super(UnitTestZDFChannelIE, self).__init__('', *args, **kwargs)
  # constructor test
  if 'das-aktuelle-sportstudio' not in UnitTestZDFChannelIE.suitable(
      'https://www.zdf.de/sport/das-aktuelle-sportstudio'):
    raise Exception('Test for ZDFChannelIE constructor failed')



# Generated at 2022-06-24 13:53:14.907574
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Instantiate ZDFChannelIE
    ZDFChannelIE()


# Generated at 2022-06-24 13:53:18.281093
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    cfg = {
        '_GEO_COUNTRIES': 'DE',
        '_QUALITIES': ['auto', 'low', 'med', 'high', 'veryhigh', 'hd']
    }
    zdfie = ZDFIE()
    assert zdfie


# Generated at 2022-06-24 13:53:21.394913
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    return ZDFIE("https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html")


# Generated at 2022-06-24 13:53:24.131568
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:53:25.859790
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'test'



# Generated at 2022-06-24 13:53:31.467547
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(object)
    assert ie._GEO_COUNTRIES is not None
    assert ie._QUALITIES is not None
    assert ie._call_api is not None
    assert ie._extract_subtitles is not None
    assert ie._extract_format is not None
    assert ie._extract_ptmd is not None
    assert ie._extract_player is not None
    assert ie.geo_verification_headers is not None


# Generated at 2022-06-24 13:53:35.931434
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('https://www.zdf.de/sendung/die-tatortreiniger/die-tatortreiniger-folge-1-100.html')



# Generated at 2022-06-24 13:53:37.484937
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie is not None


# Generated at 2022-06-24 13:53:43.005252
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    constructor_test({
        'url': 'https://zdf.de/dokumentation/wiso/wiso-vom-6-februar-2018-100.html',
        'only_matching': True
    })


# Generated at 2022-06-24 13:53:47.476391
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert isinstance(ie, ZDFBaseIE)
    assert ie.ie_key() == 'ZDFBaseIE'


# Generated at 2022-06-24 13:53:57.470324
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE("http://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html", "ZDFIE")
    assert zdfie.expected_results == 1
    assert zdfie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:53:58.453945
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:54:00.221448
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert isinstance(ZDFIE(), InfoExtractor)



# Generated at 2022-06-24 13:54:00.870927
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return ZDFChannelIE._TESTS

# Generated at 2022-06-24 13:54:04.753928
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Test if constructor of Channel ie correctly parses url"""
    ie = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert ie.channel_id == 'planet-e'



# Generated at 2022-06-24 13:54:10.095506
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFIE()
    ie = ZDFIE(None)
    ie = ZDFIE(None, None)
    ie = ZDFMediathekIE()
    ie = ZDFMediathekIE(None)
    ie = ZDFMediathekIE(None, None)
    ie = ZDFChannelIE()
    ie = ZDFChannelIE(None)
    ie = ZDFChannelIE(None, None)


# Generated at 2022-06-24 13:54:18.521529
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest
    import os
    from .test_utils import run_test_cases_for_class


# Generated at 2022-06-24 13:54:27.575020
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-24 13:54:36.584167
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """Unit test for constructor of class ZDFIE"""
    # Test when video_id is a parameter of url
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html?video_id=210222_phx_nachgehakt_corona_protest'
    zdfie = ZDFIE()
    match = zdfie._VALID_URL.match(url)
    assert match is not None, 'Could not extract video_id from %s' % url
    assert match.group('id') == '210222_phx_nachgehakt_corona_protest'

# Generated at 2022-06-24 13:54:41.953721
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    video_id = 'https://www.zdf.de/'
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie = ZDFChannelIE()
    ie._real_extract(url)
    ie = ZDFChannelIE(url)
    ie.extract(url)

# Generated at 2022-06-24 13:54:45.752482
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest
    from .test_zdf import get_testcases
    cases = get_testcases(ZDFChannelIE)
    # Remove the first case
    return unittest.TestSuite(cases[1:])

# Generated at 2022-06-24 13:54:47.520072
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    IE = ZDFIE()
    assert IE.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:54:49.584374
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """Test instance creation of ZDFIE class"""
    assert ZDFIE is not None



# Generated at 2022-06-24 13:54:51.217932
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    temp = ZDFIE()
    assert(temp.ie_key() == 'ZDF')



# Generated at 2022-06-24 13:54:54.340206
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:56.422406
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert isinstance(zdfie, ZDFBaseIE)



# Generated at 2022-06-24 13:55:02.340249
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test with url
    url = 'https://www.zdf.de/dokumentation/planet-e'
    o = ZDFChannelIE()
    assert o.suitable(url)
    assert not ZDFIE.suitable(url)
    # Test with base_url
    base_url = 'https://www.zdf.de'
    o = ZDFChannelIE()
    assert o.suitable(base_url)
    assert not ZDFIE.suitable(base_url)

# Generated at 2022-06-24 13:55:05.742630
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test ZDFBaseIE constructor
    # Init ZDFBaseIE object
    ZDFBaseIE()


# Generated at 2022-06-24 13:55:11.131133
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()

    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    assert isinstance(ie, InfoExtractor)

    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:55:12.346188
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_ZDFChannelIE_x()

# Generated at 2022-06-24 13:55:13.606640
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:55:14.245649
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-24 13:55:19.652877
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_url = 'https://www.zdf.de/filme/taunuskrimi/'
    channel_page = compat_urlopen(channel_url).read().decode()
    channel = ZDFChannelIE()
    assert channel.suitable(channel_url)
    assert channel.extract(channel_url) == \
           channel.url_result(channel_url, ie=ZDFIE.ie_key())



# Generated at 2022-06-24 13:55:31.750302
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(_download_webpage=lambda x, y, z, data=None: ({}, None),
                     _extract_subtitles=lambda x: {},
                     _extract_format=lambda x, y, z, meta: None,
                     _extract_ptmd=lambda x, y, z, v: {},
                     _extract_player=lambda x, y: {},
                     _call_api=lambda x, y, z, api_token=None, r=None: {},
                     _sort_formats=lambda x: None).GEO_COUNTRIES == ['DE']

# Generated at 2022-06-24 13:55:39.240549
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():

    # Instanciation of class ZDFBaseIE
    zdf_base_ie = ZDFBaseIE()
    # Assert to verify the defined attributes.
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')        

    # Verify the method _call_api.
    assert zdf_base_ie._call_api("https://zdf-cdn.live.cellular.de/mediathek/zdf/hbbtvv2/4530906/master.json", "4530906", "master.json")
    
    # Verify the method _extract_subtitles.

# Generated at 2022-06-24 13:55:43.889592
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ie.GEO_COUNTRIES
    assert ie._QUALITIES == ie.QUALITIES

# Generated at 2022-06-24 13:55:50.558855
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    IE = ZDFIE()
    assert IE.ie_key() == 'ZDF'
    assert IE.ie_key() != 'ZDFMediathek'
    assert IE.ie_key() in ZDFIE.ie_key
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() != 'ZDFMediathek'
    assert ZDFIE.ie_key() in ZDFIE.ie_key

# Generated at 2022-06-24 13:55:52.257727
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():  assert ZDFBaseIE()

# Generated at 2022-06-24 13:55:56.178651
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:58.105548
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase_ie = ZDFBaseIE(None)
    assert zdfbase_ie is not None



# Generated at 2022-06-24 13:56:00.048534
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE is not None
    print("Test Pass.")
    return 0


# Generated at 2022-06-24 13:56:00.675110
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass



# Generated at 2022-06-24 13:56:01.455613
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBaseIE = ZDFBaseIE()


# Generated at 2022-06-24 13:56:07.188665
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert zdf_channel_ie.suitable(zdf_channel_ie._VALID_URL)
    assert not zdf_channel_ie.suitable(zdf_channel_ie._TESTS[0]['url'])



# Generated at 2022-06-24 13:56:08.061261
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE

# Generated at 2022-06-24 13:56:09.975602
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:56:12.025432
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie is not None
    return ie


# Generated at 2022-06-24 13:56:14.000578
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE('../test.html')




# Generated at 2022-06-24 13:56:24.570887
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for constructor of ZDFChannelIE.
    """
    ie = ZDFChannelIE()
    assert ie._VALID_URL == ZDFChannelIE._VALID_URL
    assert ie._TESTS == ZDFChannelIE._TESTS
    assert ie.IE_NAME == 'zdf:channel'
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.is_initialized()
    assert ie.NAME == 'ZDF'
    assert ie.DESCRIPTION == 'ZDF and ZDFneo'
    assert ie.SUFFIX == 'Plugin'
    assert ie.VERSION == '2.0.0'
    assert ie.BUILD == '20201020.04.01'
    assert ie.COMPATIBLE_RE == ZDFChannelIE.COMPATIBLE_RE
    # assert

# Generated at 2022-06-24 13:56:28.417528
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        s = ZDFIE()
        return True
    except:
        return False

# Generated at 2022-06-24 13:56:30.338966
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:56:33.179312
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    Test ZDFIE class's constructor.
    """
    ZDFIE()

if __name__ == '__main__':
    test_ZDFIE()

# Generated at 2022-06-24 13:56:33.796884
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass


# Generated at 2022-06-24 13:56:37.346916
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ZDFChannelIE().suitable(url)
    ZDFChannelIE().extract(url)

# Generated at 2022-06-24 13:56:43.703209
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        markdown(ZDFChannelIE.__doc__)
    except NameError:
        pass
    ZDFChannelIE._download_webpage = lambda x, y: 'dummy_webpage'
    x = ZDFChannelIE()
    assert x.SUITABLE(ZDFChannelIE.ie_key()) == True
    # We do not need the ZDFChannelIE instance anymore
    x = None

# Generated at 2022-06-24 13:56:45.977282
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE()
    assert channel.ie_key() == 'ZDF:channel'

# Generated at 2022-06-24 13:56:49.103675
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = "https://www.zdf.de/sport/das-aktuelle-sportstudio"
    ZDFChannelIE(url)



# Generated at 2022-06-24 13:56:51.094919
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE('ZDFIE', 'ZDFIE').ie_key() == 'ZDFIE'


# Generated at 2022-06-24 13:56:52.150361
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:56:55.484507
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE()
    assert(inst._GEO_COUNTRIES == ['DE'])
    assert(inst._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))



# Generated at 2022-06-24 13:57:07.944279
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test case for empty api_token
    try:
        ZDFBaseIE(None)
    except (NameError, TypeError):
        pass
    else:
        assert False
    # Test case for empty referrer
    try:
        ZDFBaseIE(None, None)
    except (NameError, TypeError):
        pass
    else:
        assert False
    # Test case for empty quality_preset
    try:
        ZDFBaseIE(None, None, None)
    except (NameError, TypeError):
        pass
    else:
        assert False
    # Test case for wrong api_token
    try:
        ZDFBaseIE('', None, None)
    except (NameError, TypeError):
        pass
    else:
        assert False
    # Test case for wrong referrer

# Generated at 2022-06-24 13:57:17.356385
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    _url = "https://www.zdf.de/dokumentation/planet-e"
    _channel_id = "planet-e"

# Generated at 2022-06-24 13:57:24.308231
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:57:34.358776
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-24 13:57:45.287272
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test mobile extraction
    zdfIE = ZDFIE()
    mobile_test_url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    mobile_test_video_id = '151025_magie_farben2_tex'
    mobile_test_result = zdfIE._extract_mobile(mobile_test_video_id)
    assert mobile_test_result['id'] == '151025_magie_farben2_tex'
    assert mobile_test_result['title'] == 'Die Magie der Farben (2/2)'

# Generated at 2022-06-24 13:57:47.885808
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    globals()['ZDFIE'] = ZDFIE
    ie = globals()['ZDFIE']()


# Generated at 2022-06-24 13:57:49.265659
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie is not None


# Generated at 2022-06-24 13:57:53.058446
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'


# Generated at 2022-06-24 13:58:00.480536
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokus-und-reportagen/mach-mich-reich-100.html')
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio?a=b')

# Generated at 2022-06-24 13:58:03.236601
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    global ZDFBaseIE, ZDFIE
    try:
        from .zdf import ZDFBaseIE, ZDFIE
    except:
        pass
    ZDFIE()

# Generated at 2022-06-24 13:58:10.852006
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        url = 'http://www.zdf.de/ZDFmediathek/kanaluebersicht/aktuell#/beitrag/video/2958444/Abendschau--Startseite'
        ie = ZDFBaseIE()
        ie.extract(url)
        assert ie
    except AssertionError:
        assert False, 'Unit test for constructor of class ZDFBaseIE is failed.'
    finally:
        print('Unit test for constructor of class ZDFBaseIE is completed.')


# Generated at 2022-06-24 13:58:16.870290
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannelie = ZDFChannelIE()
    assert hasattr(zdfchannelie, '_valid_url')
    assert hasattr(zdfchannelie, '_TESTS')
    assert hasattr(zdfchannelie, '_real_extract')
    assert hasattr(zdfchannelie, 'suitable')


# Generated at 2022-06-24 13:58:25.483770
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE("https://www.zdf.de/filme/taunuskrimi/")
    assert zdf_channel_ie.suitable("https://www.zdf.de/filme/taunuskrimi/")
    assert zdf_channel_ie.suitable("https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html")

# Generated at 2022-06-24 13:58:26.265580
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    InfoExtractor('example.com')


# Generated at 2022-06-24 13:58:38.404698
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE('1', '2', '3')
    entries = zdf_channel_ie.extract_entries(
        'https://www.zdf.de/filme/taunuskrimi/', '1', '2')
    assert len(entries) > 0

# Generated at 2022-06-24 13:58:43.400474
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    zdfChannelIE = ZDFChannelIE()
    zdfChannelIE.suitable(url)
    zdfChannelIE._real_extract(url)
    zdfChannelIE.suitable(url)
    zdfChannelIE._real_extract(url)
    zdfChannelIE._real_extract(url)
    zdfChannelIE._real_extract(url)


# Generated at 2022-06-24 13:58:47.267629
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE_instance = ZDFIE()
    assert isinstance(ZDFIE_instance, ZDFIE)
# Test if the url matches the url pattern

# Generated at 2022-06-24 13:58:58.821200
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE

# Generated at 2022-06-24 13:59:01.121152
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    inst = ZDFIE()
    assert inst._VALID_URL == ZDFIE._VALID_URL
    assert inst._TESTS == ZDFIE._TESTS


# Generated at 2022-06-24 13:59:10.978369
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    assert ie._VALID_URL == "https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)"
    assert ie.suitable("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    raw_result = ie._real_extract("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    assert raw_result["_type"] == "playlist"
    assert raw_result["id"] == "das-aktuelle-sportstudio"

# Generated at 2022-06-24 13:59:12.076901
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return ZDFChannelIE().test()



# Generated at 2022-06-24 13:59:16.819731
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    print("Testing ZDFIE()")
    try:
        ZDFIE()
        print("\tSucessfully passed test ZDFIE()")
    except AssertionError as e:
        print("\tZDFIE test failed: " + str(e))



# Generated at 2022-06-24 13:59:18.427876
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test = ZDFBaseIE()
    assert isinstance(test, ZDFBaseIE)
    assert issubclass(ZDFBaseIE, InfoExtractor)


# Generated at 2022-06-24 13:59:23.358352
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html') is False
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') is True


# Generated at 2022-06-24 13:59:24.848916
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    check_ZDFBaseIE = lambda x: isinstance(x, ZDFBaseIE)
    assert check_ZDFBaseIE(ZDFIE())


# Generated at 2022-06-24 13:59:31.389604
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    video_id = 'foo'
    url = 'https://www.zdf.de/foo/foo.html'
    player = {
        u'apiToken': u'foo',
        u'content': u'https://foo.bar/bar/foo'
    }
    test = ZDFIE(video_id = video_id, url = url, player = player)
    return test



# Generated at 2022-06-24 13:59:32.758112
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE('test')._GEO_COUNTRIES == ['DE']

# Generated at 2022-06-24 13:59:44.632680
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test constructor of class ZDFChannelIE
    url = 'https://www.zdf.de/dokumentation/planet-wissen'
    channel = ZDFChannelIE._build_url(url)

    # Test with "https://www.zdf.de/dokumentation/planet-wissen"
    assert channel == 'https://www.zdf.de/dokumentation/planet-wissen'

    # Test with "https://www.zdf.de/dokumentation/planet-wissen?a=b"
    channel = ZDFChannelIE._build_url('https://www.zdf.de/dokumentation/planet-wissen?a=b')
    assert channel == 'https://www.zdf.de/dokumentation/planet-wissen'

    # Test

# Generated at 2022-06-24 13:59:47.412988
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE({'test_value': "test"})
    assert zdfChannelIE.test_value == "test"

# Generated at 2022-06-24 13:59:53.101103
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ZDF_IE = ZDFChannelIE(url)
    assert ZDF_IE.url == url
    assert ZDF_IE.playlist_mincount == 50
    assert ZDF_IE._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 14:00:00.086899
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE(None)._GEO_COUNTRIES == ['DE']
    assert ZDFIE(None)._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ZDFIE(None)._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 14:00:09.349815
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from unittest import mock
    video_id = "210222_phx_nachgehakt_corona_protest"

    url = "https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html"
    with mock.patch('youtube_dl.extractor.zdf.ZDFBaseIE._extract_ptmd') as ptmd, \
            mock.patch('youtube_dl.extractor.zdf.ZDFBaseIE._call_api') as api:
        ptmd.return_value = {'id': video_id}
        api_token = "hello"
        api.return_value = {'apiToken': api_token}
        ie = ZDFIE()
        ie._download