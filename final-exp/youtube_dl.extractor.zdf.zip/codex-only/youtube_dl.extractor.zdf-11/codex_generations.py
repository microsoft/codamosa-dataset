

# Generated at 2022-06-24 13:50:03.107783
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'

# Unit tests for class ZDFBaseIE

# Generated at 2022-06-24 13:50:06.460701
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.ie_key() == 'ZDF:channel'
    assert zdf_channel_ie.ie_key() in zdf_channel_ie._IES



# Generated at 2022-06-24 13:50:11.161505
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert "object" in str(type(ie))
    assert 'IE_DESC(ZDF)' in ie.IE_NAME
    assert "zdf.de" in ie.IE_DESC
    assert ie.ie_key() == "ZDF"

# Unit test to check if _extract_player works

# Generated at 2022-06-24 13:50:22.047099
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:50:27.779729
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Unit test for constructor of class ZDFBaseIE.
    """

    # Instantiate unit test cookie object
    test_zdfie = ZDFBaseIE()
    test_zdfie.geo_verification_headers = {'x-country-code':'DE'}

    # Assert True: _GEO_COUNTRIES = ['DE']
    assert test_zdfie._GEO_COUNTRIES == ['DE']

# End of unit test


# Generated at 2022-06-24 13:50:32.424277
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek'
    if not ZDFChannelIE.suitable(url):
        assert False, 'not suitable for channel:%s' % (url)
    ZDFChannelIE().extract(url)



# Generated at 2022-06-24 13:50:34.840420
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFIE()
        assert True
    except:
        assert False


# Generated at 2022-06-24 13:50:45.281611
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:50:46.328149
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE() is not None


# Generated at 2022-06-24 13:50:55.100142
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE('zdf_ie', 'zdf', 'http://www.zdf.de/', True)
    assert(zdf_ie.name == 'zdf_ie')
    assert(zdf_ie.ie_key() == 'zdf')
    assert(zdf_ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html')
    assert(ZDFIE._GEO_COUNTRIES == ['DE'])
    assert(ZDFIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-24 13:50:57.888880
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/reportage-dokumentation/exakt/exakt-die-story-100.html')

# Generated at 2022-06-24 13:51:00.187104
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test instantiations
    zdf_ie = ZDFBaseIE()

    assert zdf_ie is not None


# Generated at 2022-06-24 13:51:01.920820
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-24 13:51:06.017273
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:06.942445
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    e = ZDFChannelIE()
    print(e)


# Generated at 2022-06-24 13:51:08.132017
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()



# Generated at 2022-06-24 13:51:10.432801
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie.ie_key() == 'zdf'


# Generated at 2022-06-24 13:51:12.455490
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    with pytest.raises(ExtractorError):
        # Test constructor
        z = ZDFChannelIE(ZDFBaseIE)

# Generated at 2022-06-24 13:51:17.237335
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:19.853038
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE
    ZDFChannelIE.suitable('any url')


# Generated at 2022-06-24 13:51:24.844862
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('test')
    assert ie._GEO_COUNTRIES == ['DE'], 'Class variable _GEO_COUNTRIES should be overwritten'
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'), 'Class variable _QUALITIES should be overwritten'



# Generated at 2022-06-24 13:51:31.326409
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    zdfie = ZDFIE()
    zdfie._real_initialize()
    result = zdfie.extract({'url': url})
    assert 'id' in result and result['id'] == '151025_magie_farben2_tex'

# Generated at 2022-06-24 13:51:32.579760
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._extract_regular


# Generated at 2022-06-24 13:51:38.113006
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:38.809023
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:51:40.959180
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:51:42.875495
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for constructor of class ZDFChannelIE
    """
    ZDFChannelIE()



# Generated at 2022-06-24 13:51:50.570069
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_cases = [
        # test case
        [
            'https://www.zdf.de/dokumentation/planet-e',
            {
                'id': 'planet-e',
                'title': 'planet e.',
            }
        ],
    ]
    for index, test_case in enumerate(test_cases):
        url = test_case[0]
        expect = test_case[1]
        instance = ZDFChannelIE(url)
        info = instance._real_extract(url)
        print('test case:', index + 1)
        print('URL:', url)
        print('response:')
        from pprint import pprint
        pprint(info)
        print('expect:')
        pprint(expect)

# Generated at 2022-06-24 13:51:51.344718
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    obj = ZDFIE()

# Generated at 2022-06-24 13:51:53.769081
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:54.896843
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'


# Generated at 2022-06-24 13:52:05.249952
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert zdf.name == 'zdf:channel'
    assert zdf._VALID_URL == ZDFChannelIE._VALID_URL
    # Unit test for suitable()
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/10-wochen-sommer-108.html')


# Generated at 2022-06-24 13:52:15.615367
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    test = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'

    assert ie.suitable(test) == True
    assert ie.ie_key() == 'ZDF'
    assert hasattr(ie, '_VALID_URL') == True
    assert hasattr(ie, '_TESTS') == True
    assert hasattr(ie, '_download_webpage') == True
    assert hasattr(ie, '_extract_player') == True
    assert hasattr(ie, '_extract_ptmd') == True
    assert hasattr(ie, '_extract_regular') == True

# Generated at 2022-06-24 13:52:27.616721
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:52:33.094372
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.ie_key()
    assert ie.GEO_COUNTRIES == ['DE']
    assert ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:52:41.983718
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:52:49.590492
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(ZDFIE.ie_key(), ZDFIE.ie_key())
    assert ZDFBaseIE(ZDFIE.ie_key(), ZDFIE.ie_key())._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE(ZDFIE.ie_key(), ZDFIE.ie_key())._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:52:52.628471
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:52:55.438794
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import json
    assert json.dumps({'url': 'https://www.zdf.de/dokumentation/planet-e'}) == '{"url": "https://www.zdf.de/dokumentation/planet-e"}'



# Generated at 2022-06-24 13:52:57.095063
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    data = ZDFBaseIE
    assert data.ie_key() == 'zdf'


# Generated at 2022-06-24 13:53:06.517206
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    TestZDFBaseIE = type('TestZDFBaseIE', (ZDFBaseIE,), {})
    TestZDFBaseIE._GEO_COUNTRIES = ['DE']
    assert TestZDFBaseIE._GEO_COUNTRIES == ['DE']
    TestZDFBaseIE._QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert TestZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    TestZDFBaseIE._call_api()
    TestZDFBaseIE._extract_subtitles()
    TestZDFBaseIE._extract_format()
    TestZDFBaseIE._extract_ptmd()
    TestZDFBaseIE._extract_player()



# Generated at 2022-06-24 13:53:09.433731
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:53:21.394444
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html'
    video_id = ZDFIE()._match_id(url)
    webpage = ZDFIE()._download_webpage(url, video_id, fatal=False)
    player = ZDFIE()._extract_player(webpage, url, fatal=False)
    content = ZDFIE()._call_api(player['content'], video_id, 'content', player['apiToken'], url)
    entry = ZDFIE()._extract_entry(url, player, content, video_id)
    assert entry['id'] == '170112_derhauptmann_film'
    assert entry['extractor_key'] == ZDFIE.ie_key()
    assert entry

# Generated at 2022-06-24 13:53:27.057790
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    if ie._GEO_COUNTRIES is None:
        ie._GEO_COUNTRIES = []
    if ie._QUALITIES is None:
        ie._QUALITIES = []
    if ie._TESTS is None:
        ie._TESTS = []
    assert ie._TESTS == []
    assert ie._GEO_COUNTRIES == []
    assert ie._QUALITIES == []


# Generated at 2022-06-24 13:53:31.873669
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Create an instance of class ZDFChannelIE
    zdChannel = ZDFChannelIE.ZDFChannelIE()

    # Check if the class was created correctly
    assert not zdChannel is None



# Generated at 2022-06-24 13:53:36.634848
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi'
    channel_ie = ZDFChannelIE._init(ZDFChannelIE)
    channel_ie.suitable(url)
    channel_ie.extract(url)

# Generated at 2022-06-24 13:53:39.754602
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()

    assert zdf_ie.ie_key() == 'ZDF'

    assert zdf_ie.extractor_key() == 'ZDF'



# Generated at 2022-06-24 13:53:46.870233
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Usage: python -m youtube_dl.extractor.zdf --test-ZDFChannelIE
    """
    url = 'https://www.zdf.de/politik/frontal-21'
    ie = ZDFChannelIE(url)
    assert ie._match_id(url) == 'frontal-21'
    # assert ie.channel_id == 'frontal-21'

# Generated at 2022-06-24 13:53:49.795750
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print(ZDFChannelIE.suitable('https://www.zdf.de/serien/volle-kaefig/volles-rohr-100.html'))
    print(ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e'))



# Generated at 2022-06-24 13:53:58.622579
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # This test is using some html from a youtube video.
    # That's just for testing purposes...
    from .youtube import YoutubeIE

    # First create a testurl
    testurl = 'http://www.youtube.com/watch?v=BaW_jenozKc&playnext=1&list=PLdOToU6NBcq6qr2-9LaU1J5U6K1ECcY7V'

    # Now we can create the InfoExtractor object
    ies = [ZDFBaseIE(), YoutubeIE()]
    ie = get_info_extractor(testurl, ies)

    # Test if the right object was created
    assert(isinstance(ie, YoutubeIE))

    # Test if the constructor was successful
    zdf = ZDFBaseIE()
    assert(zdf is not None)




# Generated at 2022-06-24 13:54:04.526136
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Required arguments for constructor
    url = 'https://www.zdf.de/dokumentation/planet-e'

    # Call constructor
    ie = ZDFChannelIE(url)

    # Check if the number of entries is greater than 0
    if len(ie._real_extract(url)) > 0:
        assert True
    else:
        assert False


# Generated at 2022-06-24 13:54:07.222173
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('zdf') 
    assert ie.name == 'zdf-de'
    assert ie.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:54:08.358505
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:09.941629
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    result = ZDFIE()
    assert result.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:54:18.403166
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    cls = ZDFChannelIE.__name__
    assert eval(cls)({'ie': 'zdf', 'url': url})._VALID_URL == url
    assert eval(cls)({'ie': 'zdf', 'url': url, 'channel_id': 'taunuskrimi'})._VALID_URL == url
    assert eval(cls)({'ie': 'zdf', 'url': 'https://www.zdf.de/sport/das-aktuelle-sportstudio'})._VALID_URL == 'https://www.zdf.de/(?:[^/]+/)*(?P<id>[^/?#&]+[^/].*)'



# Generated at 2022-06-24 13:54:26.929882
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info_extractor = ZDFBaseIE()
    assert info_extractor._call_api('www.youtube.com', '12345', 'video metadata', 'xyz', 'www.youtube.com')
    assert info_extractor._extract_subtitles({'captions':[{'uri':'http://www.youtube.com', 'language':'deu'}]})
    assert info_extractor._extract_player('www.youtube.com', '12345', True)


# Generated at 2022-06-24 13:54:33.644824
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # The main function of File "youtube_dl/extractor/zdf.py"
    ZDF = ZDFIE()
    # The main function of File "youtube_dl/extractor/common.py"
    InfoExtractor = InfoExtractor()
    # Function of File "youtube_dl/extractor/common.py"
    InfoExtractor._sort_formats(ZDF._extract_mobile('100_a3q'))
    # print(ZDF._extract_mobile('100_a3q')[0]['url'])

# Generated at 2022-06-24 13:54:40.250106
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:54:51.100892
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert(ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html')

# Generated at 2022-06-24 13:54:52.137508
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:54:53.774373
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base_ie = ZDFBaseIE(InfoExtractor())
    assert base_ie


# Generated at 2022-06-24 13:54:56.345617
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_zdfie = ZDFIE()
    assert test_zdfie._TESTS is not None


# Generated at 2022-06-24 13:55:01.177359
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_ie_1 = ZDFBaseIE(ZDFIE.ie_key())
    assert zdf_ie_1.ieid == ZDFIE.ie_key()
    assert zdf_ie_1.geo_countries == ['DE']
    assert zdf_ie_1.qualities == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:55:13.336052
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    # Test parse_codecs function
    assert ie._extract_ptmd(
        "https://zdf-cdn.live.cellular.de/mediathekV2/document/aa", "aa",
        "bb", "cc")["formats"][1]["vcodec"] == 'none'
    assert ie._extract_ptmd(
        "https://zdf-cdn.live.cellular.de/mediathekV2/document/aa", "aa",
        "bb", "cc")["formats"][0]["vcodec"] == 'avc1.4D401F'
    # Test _extract_regular function

# Generated at 2022-06-24 13:55:21.609709
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print('unit test for constructor of class ZDFChannelIE')

    # Create an instance of class ZDFChannelIE
    zdf_channel_ie = ZDFChannelIE()

    # Unit test of method suitable
    assert zdf_channel_ie.suitable(
        'https://www.zdf.de/dokumentation/planet-e')
    assert zdf_channel_ie.suitable(
        'https://www.zdf.de/dokumentation/planet-e')
    assert zdf_channel_ie.suitable(
        'https://www.zdf.de/dokumentation/planet-e')

    # Unit test of method extract_id

# Generated at 2022-06-24 13:55:31.150766
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    a = ZDFChannelIE()
    assert a._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert a.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not a.suitable('https://www.zdf.de/dokumentation/planet-e/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')


# Generated at 2022-06-24 13:55:35.463029
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert not ZDFIE.suitable('https://www.zdf.de/')



# Generated at 2022-06-24 13:55:45.807335
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    input1 = 'https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html'
    input2 = 'https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html'
    input3 = 'https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html'
    input4 = 'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'
    output1 = ZDFIE()._real_extract(input1)
    output2 = ZDFIE()._real_ext

# Generated at 2022-06-24 13:55:54.926897
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()

    def dummy_download_webpage(url, *args, **kwargs):
        return {
            'https://www.zdf.de/dokumentation/planet-e': (
                '<html><head><title>planet e.</title></head><body>',
                {}
            )
        }[url]

    ie._download_webpage = dummy_download_webpage

    # Need to disable tests for methods that are not implemented by mocked class
    ie._call_api = lambda *args, **kwargs: None


# Generated at 2022-06-24 13:56:01.140311
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:56:02.598761
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie != None


# Generated at 2022-06-24 13:56:06.519670
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(_download_json = lambda self, url, video_id, note=None,
          errnote=None, fatal=True, **kwargs: {
              'content' : 'content',
              'apiToken' : 'apiToken'
          })


# Generated at 2022-06-24 13:56:15.116147
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE("zdf.de/phoenix");
    assert zdfChannelIE.name() == "ZDF";
    assert zdfChannelIE.ie_key() == "zdf:channel";
    assert zdfChannelIE.suitable("zdf.de/phoenix");
    assert not zdfChannelIE.suitable("https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html");
    assert "zdf.de/phoenix" == zdfChannelIE._VALID_URL;

# Generated at 2022-06-24 13:56:17.971782
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class tester(ZDFBaseIE):
        _VALID_URL = None

    ie = tester()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:25.541568
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE(None)
    assert ie.suitable(
        'https://www.zdf.de/dokumentation/planet-e') == True
    assert ie.suitable(
        'https://www.zdf.de/filme/taunuskrimi/') == True
    assert ie.suitable(
        'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') == False



# Generated at 2022-06-24 13:56:27.996230
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.__init__()


# Generated at 2022-06-24 13:56:32.074965
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    fetcher = ZDFChannelIE()
    assert fetcher.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not fetcher.suitable('https://www.zdf.de/filme/taunuskrimi/')



# Generated at 2022-06-24 13:56:34.614435
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    inst = ZDFIE()._real_extract('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    print(inst)

test_ZDFIE()

# Generated at 2022-06-24 13:56:38.351019
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:39.361746
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert isinstance(ZDFBaseIE(), InfoExtractor)


# Generated at 2022-06-24 13:56:43.315720
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    i = ZDFBaseIE();
    assert(i._GEO_COUNTRIES == ['DE'])
    assert(i._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))

# Generated at 2022-06-24 13:56:45.974884
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from ..test.test_extractors import test_ZDFBaseIE
    test_ZDFBaseIE(ZDFBaseIE)



# Generated at 2022-06-24 13:56:49.001555
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Arrange
    url = "https://www.zdf.de/comedy/heute-show"
    video_id = "3410"
    item = "metadata"

    # Act
    ZDF = ZDFBaseIE()
    test_call_api = ZDF._call_api(url, video_id, item)

    # Assert
    assert test_call_api is not None



# Generated at 2022-06-24 13:56:58.340305
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert (zdf._GEO_COUNTRIES == ['DE'])
    assert (zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))
    assert (zdf._TEST == {})
    assert (zdf._fallback_url == 'https://www.zdf.de/dynamic/player/{id}.json')
    assert (zdf._fallback_player == 'https://www.zdf.de/dynamic/player/{id}.json')
    assert (zdf.age_limit == 0)
    assert (zdf.IE_DESC == 'ZDF')
    assert (zdf.IE_NAME == 'zdf')
    assert (zdf.ie_key() == 'ZDF')

# Generated at 2022-06-24 13:56:59.410713
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:57:01.787736
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Constructor of class ZDFChannelIE should not raise any exception
    """
    ZDFChannelIE()

# Generated at 2022-06-24 13:57:05.305973
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel = ZDFChannelIE()
    zdf_channel._match_id('https://www.zdf.de/sport/das-aktuelle-sportstudio')



# Generated at 2022-06-24 13:57:15.738449
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    data = {
        'title': 'sport',
        'module': [
            {
                'teaser': [
                    {
                        'http://zdf.de/rels/target': {
                            'id': 'test_id',
                            'http://zdf.de/rels/sharing-url': 'test_url',
                        },
                    },
                ],
            },
        ],
    }
    player = {'apiToken': 'test'}
    url = 'http://www.zdf.de/sport'
    ie = ZDFChannelIE(url, data, player)

# Generated at 2022-06-24 13:57:16.324401
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

# Generated at 2022-06-24 13:57:19.458768
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # type: () -> None
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e').suitable('https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-24 13:57:23.255535
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        Test = ZDFIE()
        Test.suite()
        Test.test_ZDFIE()
    except:
        print ('Error')

if __name__ == '__main__':
    test_ZDFIE()

# Generated at 2022-06-24 13:57:33.733103
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test class ZDFBaseIE
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    # Test method _call_api
    # For example:
    # _call_api(url: https://api.zdf.de/content/documents/aktuell-nachrichten/16978, video_id: zdf:20404310, item: metadata, api_token: None, referrer: None)
    # _call_api(url: https://api.zdf.de/content/documents/aktuell-nachrichten/16978/?profile=player, video_id: zdf:20404310, item: metadata, api_

# Generated at 2022-06-24 13:57:41.752347
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannel_unit_test = Unit_Test()
    zdfchannel_unit_test.set_unit_test(ZDFChannelIE, 'ZDFChannelIE')
    zdfchannel_unit_test.assert_match_url(ZDFChannelIE, 'https://www.zdf.de/filme/taunuskrimi/')
    zdfchannel_unit_test.assert_match_url(ZDFChannelIE, 'https://www.zdf.de/filme/')


# Generated at 2022-06-24 13:57:50.104833
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.IE_NAME == 'zdf'
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:57:51.407869
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:57:57.008862
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases
    for url, expected_results in get_testcases(__name__).items():
        assert ZDFChannelIE().suitable(url) == (expected_results is not None), \
            'Testcase #%s' % url
        assert ZDFIE().suitable(url), 'Testcase #%s' % url

# Generated at 2022-06-24 13:57:58.204419
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE("ZDFBaseIE", "zdf.de")


# Generated at 2022-06-24 13:58:07.438313
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    channel_id = ZDFChannelIE._match_id(url)
    channel_ie = ZDFChannelIE(url)
    assert(channel_ie._match_id(url) == channel_id)
    channel_ie = ZDFChannelIE(channel_id)
    assert(channel_ie._match_id(url) == channel_id)
    assert(not ZDFChannelIE.suitable(ZDFIE._VALID_URL))
    assert(not ZDFChannelIE.suitable('https://www.zdf.de/'))


# Generated at 2022-06-24 13:58:08.290772
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    pass

# Generated at 2022-06-24 13:58:11.597201
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE(ZDFBaseIE)
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_name() == 'zdf.de'

# Generated at 2022-06-24 13:58:19.312920
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test the constructor of class ZDFChannelIE
    cls = type('ZDFChannelIE_Test', (ZDFChannelIE, ), dict(ZDFChannelIE.__dict__.items()))
    assert cls.suitable('https://www.zdf.de/filme/taunuskrimi/') == False
    assert cls.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True

# Generated at 2022-06-24 13:58:20.703910
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(ZDFChannelIE.ie_key())



# Generated at 2022-06-24 13:58:30.061818
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:58:36.658962
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_vid = ZDFIE("ZDFIE", "https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html")
    assert test_vid.name == "ZDFIE"
    assert test_vid.url == "https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html"

# Generated at 2022-06-24 13:58:41.858038
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test ZDFBaseIE constructor"""
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Test functions for ZDFBaseIE's APIs

# Generated at 2022-06-24 13:58:43.021662
# Unit test for constructor of class ZDFIE
def test_ZDFIE(): # noqa: N802
    ZDFIE()



# Generated at 2022-06-24 13:58:45.174517
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # TODO please implement this unit test
    pass


# Generated at 2022-06-24 13:58:46.193090
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE is not None


# Generated at 2022-06-24 13:58:58.391529
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Audio
    assert_no_error(lambda: ZDFBaseIE.test_audio())
    # Video
    assert_no_error(lambda: ZDFBaseIE.test_video_simple())
    assert_no_error(lambda: ZDFBaseIE.test_video_mediathek())
    assert_no_error(lambda: ZDFBaseIE.test_video_subtitles())
    assert_no_error(lambda: ZDFBaseIE.test_video_subtitles_no_subtitles())
    assert_no_error(lambda: ZDFBaseIE.test_video_subtitles_subtitles_many())
    assert_no_error(lambda: ZDFBaseIE.test_video_zdfsport_streams_to_other_services())

# Generated at 2022-06-24 13:59:05.210268
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    zdfIE.fieldname()
    zdfIE.fieldname(default=13)
    zdfIE.fieldname(default=None)
    zdfIE.fieldname(type=int, default=None)
    zdfIE.fieldname(type=type)
    zdfIE.fieldname(type=type, default=None)
    zdfIE.fieldname(type=type, default=type)

# Generated at 2022-06-24 13:59:08.258096
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()

    # Check that all qualities are supported by API
    ie._extract_mobile('100100_dwds_wirtschaft_zdf_omu')



# Generated at 2022-06-24 13:59:09.379889
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:59:10.848067
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()



# Generated at 2022-06-24 13:59:11.476309
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass


# Generated at 2022-06-24 13:59:16.615863
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .core import get_testcases
    from . import ExtractorError

    for (key, values) in get_testcases().items():
        if key == 'ZDFChannelIE':
            for (val, errcode) in values:
                extractor = ZDFChannelIE()
                assert callable(extractor)
                errcode = int(errcode)
                try:
                    test = extractor(val)
                except Exception as err:
                    if not errcode:
                        print('ERROR: "{0}" failed and should not have'.format(val))
                else:
                    if errcode:
                        print('ERROR: "{0}" succeeded and should not have'.format(val))

# Generated at 2022-06-24 13:59:19.815182
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie is not None

###################################################################################################
# Test code for class ZDFIE below
###################################################################################################
import unittest


# Generated at 2022-06-24 13:59:25.124078
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    t = ZDFBaseIE(None)
    assert t._GEO_COUNTRIES == ['DE']
    assert t._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert t._call_api is not None
    assert t._extract_format is not None
    assert t._extract_ptmd is not None
    assert t._extract_player is not None



# Generated at 2022-06-24 13:59:26.924648
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.ie_key() == 'ZDFChannel'



# Generated at 2022-06-24 13:59:29.458766
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test the constructor of ZDFBaseIE."""
    # Test the ZDFBaseIE constructor
    ie = ZDFBaseIE()

    # TODO: Complete these tests


# Generated at 2022-06-24 13:59:34.327537
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases
    from .test import list_testcases, run_testcases

    all_testcases = get_testcases(ZDFChannelIE)
    list_testcases(ZDFChannelIE, all_testcases, 'Channel')
    run_testcases(ZDFChannelIE, all_testcases, 'Channel', True)



# Generated at 2022-06-24 13:59:36.619533
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:59:41.452853
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases
    from .utils import get_entry
    for entry in get_testcases(ZDFChannelIE, [ZDFChannelIE.ie_key()]):
        get_entry(entry)



# Generated at 2022-06-24 13:59:43.034368
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE('https://zdf.de/')



# Generated at 2022-06-24 13:59:50.756048
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    zdf_base_ie._call_api('http://www.zdf.de', '123', 'test')
    zdf_base_ie._extract_subtitles([])
    zdf_base_ie._extract_subtitles({'captions': [{'uri': 'http://www.zdf.de'}]})
    zdf_base_ie._extract_player('data-zdfplayer-jsb="{}', 'test')


# Generated at 2022-06-24 13:59:53.052884
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    inst = ZDFIE()
    assert inst.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:59:55.146537
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # test ZDFIE constructor
    ZDFIE('zdf', 'DE')

    # test ZDFIE() is an instance of InfoExtractor
    assert isinstance(ZDFIE('zdf', 'DE'), InfoExtractor)



# Generated at 2022-06-24 13:59:58.840406
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE._TESTS[0]['url'] = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    # Test to create ChannelIE instance
    instance = ZDFChannelIE(ZDFChannelIE._TESTS[0]['url'])
    assert isinstance(instance, ZDFChannelIE)



# Generated at 2022-06-24 14:00:00.831342
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie is not None and zdfie.thumbnail == None

