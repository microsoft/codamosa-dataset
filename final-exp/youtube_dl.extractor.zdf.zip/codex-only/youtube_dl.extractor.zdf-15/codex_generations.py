

# Generated at 2022-06-24 13:50:01.150755
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    return

# Generated at 2022-06-24 13:50:07.446136
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie.name != 'undefined'
    assert zdf_ie.name == 'zdf'
    assert zdf_ie.title != 'undefined'
    assert zdf_ie.title == 'ZDF'
    assert zdf_ie.description != 'undefined'
    assert zdf_ie.description == 'Zweites Deutsches Fernsehen'



# Generated at 2022-06-24 13:50:08.469587
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-24 13:50:12.753682
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase = ZDFBaseIE()
    zdfbase._call_api(
        'http://www.zdf.de/', 'audio_35393008', 'url', 'token', 'refer')
# Test has been done


# Generated at 2022-06-24 13:50:14.276466
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
	ie = ZDFIE()
	assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-24 13:50:23.960418
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest
    class TestZDFChannelIE(unittest.TestCase):
        def test_get_target(self):
            self.assertEqual(ZDFChannelIE.get_target('https://www.zdf.de/filme/taunuskrimi/'), (ZDFChannelIE, 'https://www.zdf.de/filme/taunuskrimi/'))
            self.assertEqual(ZDFChannelIE.get_target('https://www.zdf.de/dokumentation/planet-e'), (ZDFChannelIE, 'https://www.zdf.de/dokumentation/planet-e'))

# Generated at 2022-06-24 13:50:25.558376
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('das-aktuelle-sportstudio', )

# Generated at 2022-06-24 13:50:36.151009
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:50:43.578737
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_str
    from .test import get_testdata_file

    # 20170710:
    #   250 entries from
    #    https://www.zdf.de/dokumentation/ab-18
    #   300 entries from
    #    https://www.zdf.de/dokumentation/planet-e
    #   400 entries from
    #    https://www.zdf.de/dokumentation/terra-x

    filename = get_testdata_file('/zdf/dokumentation/ab-18-2.html')

    ie = ZDFChannelIE({})
    fd = FileDownloader({})
    fd.add_info_extractor(ie)

# Generated at 2022-06-24 13:50:46.379255
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()._extract_player({
        'content' : 'content',
        'apiToken' : 'apiToken',
    }, '', 'content', 'apiToken')

# Generated at 2022-06-24 13:50:51.119551
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .common import _test_generic_info_extractor
    ie = ZDFChannelIE('https://www.zdf.de/foo-bar')
    assert ie.name == 'zdf.de:channel'
    assert ie.ie_key() == 'ZDF:channel'
    _test_generic_info_extractor('zdf.de/foo-bar')

# Generated at 2022-06-24 13:50:52.310636
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'zdf'

# Generated at 2022-06-24 13:50:58.296342
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')



# Generated at 2022-06-24 13:50:59.437476
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_ZDFIE = ZDFIE()


# Generated at 2022-06-24 13:51:05.064461
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == ZDFIE._VALID_URL
    assert zdf._TESTS == ZDFIE._TESTS
    assert zdf._GEO_COUNTRIES == ZDFBaseIE._GEO_COUNTRIES
    assert zdf._QUALITIES == ZDFBaseIE._QUALITIES


# Generated at 2022-06-24 13:51:09.772726
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj.ie_key() == 'zdf'
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:22.086755
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import os
    import sys
    import tempfile
    import unittest
    from io import BytesIO

    import youtube_dl
    from youtube_dl.YoutubeDL import YoutubeDL

    from .common import FileDownloader

    if not os.path.exists('test_files'):
        os.mkdir('test_files')
    try:
        if os.path.exists('test_files/test_video.mp4'):
            os.remove('test_files/test_video.mp4')
    except OSError as e:
        print(e)
    with open('test_files/test_video.mp4', 'wb+') as f:
        f.write(b'\0' * 10000000)
        f.close()


# Generated at 2022-06-24 13:51:25.340155
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    obj = ZDFChannelIE
    assert obj.suitable(url)



# Generated at 2022-06-24 13:51:28.217625
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    output=ZDFChannelIE()
    try:
        assert output.__class__==ZDFChannelIE
    except:
        raise ValueError("test failed")


# Generated at 2022-06-24 13:51:29.192637
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    Object = ZDFBaseIE('')


# Generated at 2022-06-24 13:51:30.219037
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    return ZDFIE(None)


# Generated at 2022-06-24 13:51:33.719511
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/politik/frontal-21/frontal-21-vom-11-08-2020-100.html') == False
    assert ie.suitable('https://www.zdf.de/politik/frontal-21') == True

# Generated at 2022-06-24 13:51:39.630414
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base_ie = ZDFBaseIE()
    assert base_ie._GEO_COUNTRIES == ['DE']
    assert base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:41.789722
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    pass


# Generated at 2022-06-24 13:51:51.324975
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:51:52.830226
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    data = ZDFIE()._extract_player(
        webpage="", video_id="", fatal=True)
    assert data is not None


# Generated at 2022-06-24 13:51:59.603341
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannel = ZDFChannelIE()
    assert zdfchannel._VALID_URL==r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 13:52:07.243855
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = "https://www.zdf.de/dokumentation/planet-e"
    instance = ZDFChannelIE()
    try:
        instance.suitable(url)
    except:
        print("Error at line 237 in file /zdf_extractor.py")
        print("Please check your code you inputted.")
        print("If necessary, please modify the unit test code.")
        print("unit test will abort.")
        assert(False)



# Generated at 2022-06-24 13:52:12.147312
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    videourl = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    player = ZDFIE()._extract_player(None, videourl, fatal=False)
    print(player)


# Generated at 2022-06-24 13:52:15.942204
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE();
    if zdf.suitable('https://www.zdf.de/filme/taunuskrimi/'):
        assert(True)
    else:
        assert(False)

# Generated at 2022-06-24 13:52:17.616469
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zd = ZDFIE().ie_key()
    assert zd == 'ZDF'


# Generated at 2022-06-24 13:52:19.790681
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFIE()
    assert isinstance(inst, ZDFBaseIE)



# Generated at 2022-06-24 13:52:28.428932
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE("")
    assert '_GEO_COUNTRIES' in obj.__dict__
    assert '_QUALITIES' in obj.__dict__
    assert '_call_api' in obj.__dict__
    assert '_extract_format' in obj.__dict__
    assert '_extract_ptmd' in obj.__dict__
    assert '_extract_player' in obj.__dict__
    assert '_extract_subtitles' in obj.__dict__


# Generated at 2022-06-24 13:52:32.673678
# Unit test for constructor of class ZDFIE
def test_ZDFIE():

    class TestZDFIE(ZDFIE):
        pass

    TestZDFIE('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')



# Generated at 2022-06-24 13:52:34.882677
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert isinstance(ie, ZDFIE)

# Tests for function _extract_player of class ZDFIE

# Generated at 2022-06-24 13:52:42.340328
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    if not is_Py_3:
        print('This code is for Python 3 only because compatible_str is not defined in Python 2')
        return

    from compat_str import compatible_str

    # Using compatible_str() to force str() in Python 2 and str() or bytes() in Python 3
    # to rely on the 'str' type, rather than the 'bytes' type

    def check_type_str(x):
        assert isinstance(x, str)

    for y in (ZDFChannelIE(chr(ord('a') + x)) for x in range(26)):
        check_type_str(y.SUFFIX)

    check_type_str(ZDFChannelIE.SUFFIX)
    check_type_str(ZDFChannelIE._VALID_URL)

# Generated at 2022-06-24 13:52:45.713757
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:52:55.344147
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test data provided by: Jens Jaenisch
    test_values = [
        (
            # Unit test for video
            'https://www.zdf.de/politik/frontal21/frontal21-vom-9-mai-2018-100.html',
            # Expected result (the video)
            'https://www.zdf.de/politik/frontal21/frontal21-vom-9-mai-2018-100.html'
        ),
        (
            # Unit test for channel
            'https://www.zdf.de/politik/frontal21',
            # Expected result (the channel)
            'https://www.zdf.de/politik/frontal21'
        )
    ]
    ie = ZDFChannelIE()

# Generated at 2022-06-24 13:52:56.613349
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    if __name__ == '__main__':
        obj_zdfbaseie = ZDFBaseIE()

# Generated at 2022-06-24 13:52:58.422053
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base = ZDFBaseIE()
    assert base._GEO_COUNTRIES == ['DE']
    assert base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:53:00.256146
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    with pytest.raises(TypeError):
        ZDFBaseIE()


# Generated at 2022-06-24 13:53:08.047170
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    constructor = lambda url: ZDFChannelIE.suitable(url) and ZDFChannelIE(url)
    assert constructor('https://www.zdf.de/politik/panorama') is not None
    assert constructor('https://www.zdf.de/politik/panorama.html') is not None
    assert constructor('https://www.zdf.de/politik/panorama/') is not None



# Generated at 2022-06-24 13:53:11.501394
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # pylint: disable=protected-access
    assert ZDFChannelIE._TESTS[0]['url'] == ZDFChannelIE(ZDFChannelIE._TESTS[0]['url'])._VALID_URL



# Generated at 2022-06-24 13:53:14.886289
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.GEO_COUNTRIES == ['DE']
    assert ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:53:21.663419
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zd = ZDFBaseIE()
    zd = zd._call_api('https://test', '1234')
    zd = zd._extract_subtitles('https://test')
    zd = zd._extract_format('1234', 'formats', 'track_uris', {'url' : 'someurl'})
    zd = zd._extract_ptmd('url', '1234', 'token', 'refer')
    zd = zd._extract_player('webpage', '1234')


# Generated at 2022-06-24 13:53:24.901666
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE()
    assert isinstance(ie, ZDFChannelIE)
    assert ie._VALID_URL == ZDFChannelIE._VALID_URL
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.working == True

# Generated at 2022-06-24 13:53:25.472485
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-24 13:53:38.420015
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE_ = ZDFChannelIE.__c__()
    assert ZDFChannelIE_._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ZDFChannelIE_._TESTS[0] == {
        'url': 'https://www.zdf.de/sport/das-aktuelle-sportstudio',
        'info_dict': {
            'id': 'das-aktuelle-sportstudio',
            'title': 'das aktuelle sportstudio | ZDF',
        },
        'playlist_mincount': 23,
    }

# Generated at 2022-06-24 13:53:39.056966
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannel = ZDFChannelIE()

# Generated at 2022-06-24 13:53:40.030213
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    extractor = ZDFBaseIE()
    return extractor

# Generated at 2022-06-24 13:53:42.517575
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert isinstance(zdf_base_ie, InfoExtractor)
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:53:54.620646
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')
    ZDFChannelIE('https://www.zdf.de/nachrichten/heute/zeitraum')
    ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    ZDFChannelIE('https://www.zdf.de/dokumentation/unter-uns-bekannte-gesichter/39595028-b5a5-4162-ab3d-f49097c3c8be')

# Generated at 2022-06-24 13:53:56.579085
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE()
    # TODO: add meaningful tests


# Generated at 2022-06-24 13:54:00.921614
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:08.236569
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    channel_id = zdf._match_id('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert channel_id == 'das-aktuelle-sportstudio'

# Generated at 2022-06-24 13:54:09.848200
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    player = ZDFBaseIE._extract_player('{}', '', fatal=True)
    assert player == {}



# Generated at 2022-06-24 13:54:12.198427
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')


# Generated at 2022-06-24 13:54:17.419132
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from ..test import get_testcase_func
    from .common import InfoExtractor


# Generated at 2022-06-24 13:54:29.182001
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert ie._TESTS[1]['url'] == 'https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html'

# Generated at 2022-06-24 13:54:31.504479
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # This test is only for initializing and checking the instance
    # of class ZDFChannelIE
    zdf_channel_ie = ZDFChannelIE()
    zdf_channel_ie.suitable('')
    zdf_channel_ie.extract('')



# Generated at 2022-06-24 13:54:34.902863
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    assert isinstance(instance, ZDFBaseIE)
    assert instance._GEO_COUNTRIES == ['DE']
    assert instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:35.565550
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE() is not None

# Generated at 2022-06-24 13:54:42.873541
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    x = ZDFBaseIE()
    assert x._GEO_COUNTRIES == ['DE']
    assert x._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert x._VALID_URL == r'''(?x)
        https?://
            (?:
                www\.(?:zdf|zdfsport)\.de/(?:[^/]+/)*(?P<id>[0-9]{8,})[^/]*\.html|
                zdfmediathek\.de/(?:#/)?[^/]+/(?:[^/]+/)*(?P<id>[0-9]{8,})
            )
        '''
    assert x._API_BASE == 'https://api.zdf.de/'
    assert x._API_

# Generated at 2022-06-24 13:54:49.926336
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert (ZDFBaseIE._extract_ptmd('/blob', 'video_id', 'api_token', 'referrer')['extractor_key'] == 'ZDF')
    assert (ZDFBaseIE._extract_player('/blob', 'video_id', 'api_token', 'referrer')['extractor_key'] == 'ZDF')
    assert (ZDFBaseIE._call_api('/blob', 'video_id', '[1]', 'api_token', 'referrer')[0] == 1)

# Generated at 2022-06-24 13:54:52.743992
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    baseIE = ZDFBaseIE()
    assert baseIE._GEO_COUNTRIES == ['DE']
    assert baseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:55.547813
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert len(ZDFBaseIE._QUALITIES) == 5, ZDFBaseIE._QUALITIES
    return True


# Generated at 2022-06-24 13:55:03.332295
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    print("Testing constructor of class ZDFIE...")
    print("\nConstructor:")
    zdf_ie = ZDFIE(None)
    print("Testing attribute _GEO_COUNTRIES of ZDFIE: " + str(zdf_ie._GEO_COUNTRIES))
    print("Testing attribute _QUALITIES of ZDFIE: " + str(zdf_ie._QUALITIES))
    assert(zdf_ie._GEO_COUNTRIES == ['DE'])
    assert(zdf_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))
    return


# Generated at 2022-06-24 13:55:03.966954
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE is not None


# Generated at 2022-06-24 13:55:06.979872
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_id = 'das-aktuelle-sportstudio'
    channel_url = 'http://www.zdf.de/sport/' + channel_id
    # This would call the constructor, which calls _real_extract
    ZDFChannelIE().suitable(channel_url)



# Generated at 2022-06-24 13:55:17.837672
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Test constructor of class ZDFBaseIE
    """
    instance = ZDFBaseIE()
    assert instance.IE_NAME == 'ZDF'
    assert instance._VALID_URL == r'https?://(?:www\.)?(zdf\.de|zdfmediathek\.de)/[^/]+/(?P<id>[0-9+])(?:/video)?/?$'

# Generated at 2022-06-24 13:55:18.789043
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE is not None



# Generated at 2022-06-24 13:55:30.901272
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test that the import of the empty class defined in this file is
    # set up properly
    assert hasattr(ZDFBaseIE, '_GEO_COUNTRIES')
    assert hasattr(ZDFBaseIE, '_call_api')
    assert hasattr(ZDFBaseIE, '_extract_subtitles')
    assert hasattr(ZDFBaseIE, '_extract_ptmd')
    assert hasattr(ZDFBaseIE, '_extract_player')

    # Test the private method "call_api"
    assert ZDFBaseIE._call_api('https://example.org', 'test', 'API') == {u'status': u'ok'}
    # Test the private method "_extract_subtitles"

# Generated at 2022-06-24 13:55:38.947387
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():

    # Constructor without an URL argument must fail
    try:
        ie = ZDFBaseIE()
    except TypeError:
        pass

    # Constructor with a correct URL
    try:
        ie = ZDFBaseIE('http://someurl')
        assert isinstance(ie, ZDFBaseIE)
    except TypeError:
        raise TypeError('ZDFBaseIE constructor with a correct URL must succeed')

# vim: set ts=4 sw=4 tw=0 et :

# Generated at 2022-06-24 13:55:41.469104
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Constructor of class ZDFChannelIE.
    """
    from .zdf import ZDFChannelIE
    ZDFChannelIE()


# Generated at 2022-06-24 13:55:48.964065
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    zdf_ie = ZDFIE()
    zdf_ie_key = zdf_ie.ie_key()
    assert zdf_channel_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert zdf_channel_ie.ie_key() == 'ZDF:channel'
    assert zdf_channel_ie.suitable(r'https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not zdf_channel_ie.suitable(r'https://www.zdf.de/politik/frontal-21/aktuell-100.html')
    assert zdf_channel

# Generated at 2022-06-24 13:55:52.333998
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    kwargs = {
        'url': 'https://www.zdf.de/dokumentation/planet-e',
        'playlist_count': {
            'mincount': 50,
        }
    }
    ZDFChannelIE(kwargs)._real_extract({})

# Generated at 2022-06-24 13:55:56.178404
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:01.136321
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE()
    zdf_base._call_api('https://www.zdf.de/und/zdf/api/asset/video/',
                       '1234',
                       'Video')
    assert zdf_base._GEO_COUNTRIES
    assert zdf_base._QUALITIES


# Generated at 2022-06-24 13:56:02.945667
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    print(repr(instance))
    pass


# Generated at 2022-06-24 13:56:11.238969
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test two constructors of the class:
    # 1. Constructor with only player JSON
    pj = {'platform': 'WEB'}
    zb = ZDFBaseIE(player_json=pj)
    assert zb.player_json == pj
    assert zb.device_type == 'WEB'
    # 2. Constructor with both player JSON and webpage
    webpage = '<div></div>'
    pj = {'platform': 'DASH', 'basename': 'foo'}
    zb = ZDFBaseIE(webpage, player_json=pj)
    assert zb.player_json == pj
    assert zb.device_type == 'DASH'
    assert zb.basename == 'foo'


# Generated at 2022-06-24 13:56:16.795617
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    # Check if the class works in general by using an example.
    ie.extract("https://www.zdf.de/dokumentation/planet-e")
    # Test for result if no playlist is found.
    ie.extract("https://www.zdf.de/filme/taunuskrimi/")


# Generated at 2022-06-24 13:56:26.810964
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    zdf_base_obj = ie.ZDFBaseIE()
    assert zdf_base_obj._GEO_COUNTRIES == ['DE']
    assert zdf_base_obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    # _call_api
    assert zdf_base_obj._call_api('http://www.zdf.de/live-tv', '12345', 'Video Metadata') is None
    # _extract_subtitles
    assert zdf_base_obj._extract_subtitles(None) == {}
    assert zdf_base_obj._extract_subtitles({}) == {}

# Generated at 2022-06-24 13:56:30.393501
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE({})
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:56:38.801357
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    p = ZDFIE()

# Generated at 2022-06-24 13:56:44.993974
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Test for ZDFChannelIE
    """
    import unittest
    from urllib.parse import urlparse
    from .test_zdf_id import class_get_id
    import unittest.mock
    from .test_zdf_ie import extractor_for_url, find_entry
    from .test_zdf_ie import make_results_with_id, build_results_with_id

    # Do not use "self." before class name in class method
    class ZDFChannelIE_from_URL(ZDFChannelIE):
        """
        Create ZDFChannelIE class from URL
        """
        def __init__(self, url):
            """
            Constructor

            :param url: URL
            """
            # Do not change class name
            ZDFChannelIE.__init__(self)

# Generated at 2022-06-24 13:56:55.752016
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Unit test for constructor of class ZDFBaseIE"""

    def test_call_api(url, video_id, item, api_token=None, referrer=None):
        return ZDFBaseIE._call_api(url, video_id, item, api_token, referrer)


# Generated at 2022-06-24 13:56:57.180676
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    print(ie._VALID_URL)


# Generated at 2022-06-24 13:57:01.095983
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.geo_countries == ie._GEO_COUNTRIES
    assert ie.qualities == ie._QUALITIES



# Generated at 2022-06-24 13:57:03.817055
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """Test that the ZDFIE class is defined."""
    zdfie = ZDFIE()
    assert zdfie is not None


# Generated at 2022-06-24 13:57:04.492284
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert isinstance(ZDFChannelIE, type)

# Generated at 2022-06-24 13:57:06.745212
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE._GEO_COUNTRIES
    ZDFBaseIE._QUALITIES
    return None


# Generated at 2022-06-24 13:57:07.893776
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:57:11.295385
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie.ie_key() == 'zdf'
    assert zdf_ie.ie_key() == ZDFIE.ie_key()


# Generated at 2022-06-24 13:57:13.116852
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test whether constructor of class ZDFIE can be executed.
    ie = ZDFIE()



# Generated at 2022-06-24 13:57:21.047218
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._extract_regular("https://www.zdf.de/nachrichten/heute/wahl-usa-news-und-hintergrund-100.html", {
            "content":"https://www.zdf.de/wahl-usa/nachrichten/heute/wahl-usa-news-und-hintergrund-100.json",
            "apiToken":"Jb2d9XWz6D0v0EyxmGftQt86xlBtfPjw",
            "csrfToken":""} , "wahl-usa-news-und-hintergrund-100.json")

# Generated at 2022-06-24 13:57:24.857732
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert not ie.suitable(ZDFIE._VALID_URL)  # Should return False
    assert ie.suitable(ZDFChannelIE._VALID_URL)  # Should return True

# Generated at 2022-06-24 13:57:27.832561
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Run unit test for class ZDFChannelIE"""
    ZDFChannelIE.suitable('http://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-24 13:57:34.579738
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie =  ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:57:42.943598
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Provide a correct url
    url = 'http://www.zdf.de/serien/Feuerwehrmann-Sam/episodenguide/staffel-9/6/episodenguide-6-229.html'
    ZDFBaseIE().suitable(url)
    ZDFBaseIE()._real_extract(url)

    # Provide an incorrect url
    assert not ZDFBaseIE().suitable('https://www.google.com')
    assert not ZDFBaseIE()._real_extract('https://www.google.com')

# Generated at 2022-06-24 13:57:47.940493
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        cls = ZDFChannelIE
        cls('https://www.zdf.de/dokumentation/planet-e')
        raise AssertionError('Test failure')
    except AssertionError as e:
        if 'no suitable IE found' not in str(e):
            raise


# Generated at 2022-06-24 13:57:50.368461
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
    except Exception as e:
        print(e)

test_ZDFBaseIE()

# Generated at 2022-06-24 13:57:56.437097
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Arrange
    url = 'https://www.zdf.de/geschichte/terra-x/terra-x-uebersichtsseite-100.html'
    test_ZDFChannelIE_expected = 'Terra X'
    # Act
    entry = ZDFChannelIE()._real_extract(url)
    # Assert
    assert entry['_type'] == 'playlist'
    assert entry['title'] == test_ZDFChannelIE_expected


# Generated at 2022-06-24 13:57:57.791245
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    global ZDFChannelIE
    ZDFChannelIE = gen_extractor_class(ZDFChannelIE)


# Generated at 2022-06-24 13:58:01.663575
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.geo_countries == ['DE']
    assert ie.qualities == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie.extractor_key == 'ZDFIE'



# Generated at 2022-06-24 13:58:03.185906
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # TODO write cases
    assert ZDFBaseIE


# Generated at 2022-06-24 13:58:04.585262
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    dl = ZDFBaseIE()
    assert dl


# Generated at 2022-06-24 13:58:11.063291
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Instantiate ZDFBaseIE
    ZDFBaseIE()
    # Instantiate ZDFIE
    ZDFIE()
    # Instantiate ZDFChannelIE
    ZDFChannelIE()

    # Check that ZDFBaseIE has an ie_key that is a member of _IES
    for ie_key in InfoExtractor._IES:
        if ie_key == ZDFBaseIE.ie_key():
            return
    assert False



# Generated at 2022-06-24 13:58:15.243326
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:58:16.389691
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('ZDFBaseIE')

# Generated at 2022-06-24 13:58:27.973108
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.geo_countries() == ['DE']
    assert ie.extract('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert ie.extract('https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html')
    assert ie.extract('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html')
    assert ie.extract('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')

# Generated at 2022-06-24 13:58:29.084467
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()



# Generated at 2022-06-24 13:58:30.233963
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()


# Generated at 2022-06-24 13:58:31.607582
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE() is not None


# Generated at 2022-06-24 13:58:34.272305
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # there is a poor unittest(which is not a true unittest) 
    # for a class ZDFIE, module zdf
    # in file unittest_zdf.py
    # this is a simple test for it's constructor
    if True:
        ie = ZDFIE()
        return ie



# Generated at 2022-06-24 13:58:40.770504
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    item = ZDFChannelIE()
    assert item.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') is True
    assert item.suitable('https://www.zdf.de/dokumentation/planet-e') is True
    assert item.suitable('https://www.zdf.de/filme/taunuskrimi/') is True


# Generated at 2022-06-24 13:58:41.570008
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert issubclass(ZDFIE, InfoExtractor)


# Generated at 2022-06-24 13:58:53.884875
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    a=ZDFIE()
    assert a._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:59:02.502651
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFIE.ie_key = lambda: 'zdf'
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.SUITABLE_URLS == [(re.compile(ZDFChannelIE._VALID_URL), ZDFChannelIE)]
    assert zdf_channel_ie.IE_NAME == 'zdf:channel'
    assert zdf_channel_ie.LANG == 'de'
    assert zdf_channel_ie.ie_key() == 'ZDFChannel'
    assert zdf_channel_ie.BASE_URL == 'https://www.zdf.de/'
    assert zdf_channel_ie.NAME == 'ZDF'
    assert zdf_channel_ie.DESCRIPTION == 'German public service television broadcaster'

# Generated at 2022-06-24 13:59:03.772375
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_class = ZDFChannelIE()
    test_class.suitable(test_class._VALID_URL)


# Generated at 2022-06-24 13:59:06.996843
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        zdf = ZDFIE()
        assert zdf._GEO_COUNTRIES == ['DE']
    except Exception as e:
        assert False, e

# Generated at 2022-06-24 13:59:13.337576
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
	# Arrange
	test_ZDFChannelIE.url = "https://www.zdf.de/sport/das-aktuelle-sportstudio"
	test_ZDFChannelIE.result = True
	
	# Act
	result = ZDFChannelIE.suitable(test_ZDFChannelIE.url)

	# Assert
	assert result == test_ZDFChannelIE.result

# Generated at 2022-06-24 13:59:14.773691
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:59:17.502578
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE('DE') is not None, "Requires the country code for georestricted access"

# Generated at 2022-06-24 13:59:23.256045
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print('test channel')

    channel = ZDFChannelIE._build_url_result('https://somehost.com', 'das-aktuelle-sportstudio')
    assert channel.get('id') == 'das-aktuelle-sportstudio'
    assert channel.get('url') == 'https://somehost.com/sport/das-aktuelle-sportstudio.html'



# Generated at 2022-06-24 13:59:28.285761
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/') == False
    assert zdf_channel_ie.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html') == True


# Generated at 2022-06-24 13:59:31.376652
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()

# Test to verify that ZDFIE does not attempt to download private videos

# Generated at 2022-06-24 13:59:35.222524
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')

_ZDF_MODULE_PAGE_TEMPLATE = 'https://www.zdf.de/{}/{}/modulpage/-/{}/page'


# Generated at 2022-06-24 13:59:47.574372
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class ZDFChannelIE_for_test(ZDFChannelIE):
        def _real_extract(self, url):
            return self.url_result(
                'https://www.zdf.de/dokumentation/planet-e',
                ie=ZDFIE.ie_key())

    # Check if unit test is valid
    assert ZDFChannelIE.suitable(
        'https://www.zdf.de/dokumentation/planet-e') == True
    assert ZDFChannelIE.suitable(
        'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html') == False

    # Check if initial list of entries is valid

# Generated at 2022-06-24 13:59:57.923057
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    IEClass = ZDFIE()
    assert(IEClass._VALID_URL == "https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html")

# Generated at 2022-06-24 14:00:02.842648
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL)
    ZDFChannelIE.suitable(ZDFIE._VALID_URL) # This site is also a channel, if you see its json response.
    # A valid URL which is not a channel
    assert not ZDFChannelIE.suitable(ZDFIE._TESTS[0]['url'])