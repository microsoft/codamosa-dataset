

# Generated at 2022-06-24 13:50:04.406068
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    canal = ZDFChannelIE.suitable(u'https://www.zdf.de/dokumentation/planet-e')
    assert canal

# Generated at 2022-06-24 13:50:07.632123
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z=ZDFIE()
    y=z._TESTS
    assert(y[4]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html')
    assert(y[4]['only_matching'] == True)


# Generated at 2022-06-24 13:50:08.282190
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('')


# Generated at 2022-06-24 13:50:13.652199
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.ie_key() == 'ZDFChannel'
    assert zdf_channel_ie.ie_key() in ZDFChannelIE.ie_key_map, 'The ie_key should be added to ie_key_map'


# Generated at 2022-06-24 13:50:23.920163
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z = ZDFBaseIE()
    z._call_api('http://vod.zdf.de/thumbnail/6/1/610616_3803_11400_L-1280x720-16_9.jpg',
                '1', 'test_api')
    z._extract_subtitles([{'captions': [{'uri': '/test.xml'}]}])
    z._extract_format('1', [], {}, {'url': '/test.mp3', 'type': 'audio'})
    z._extract_format('1', [], {}, {'url': '/test.m3u', 'type': 'http'})

# Generated at 2022-06-24 13:50:25.907702
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    if ie.ie_key()  != 'zdf':
        assert False, 'IE key set error'

# Generated at 2022-06-24 13:50:28.602750
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE('zdf.de') is ZDFChannelIE.ie_key()



# Generated at 2022-06-24 13:50:31.001339
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    ZDFChannelIE.suitable(url)



# Generated at 2022-06-24 13:50:31.492782
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE

# Generated at 2022-06-24 13:50:35.316952
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    print(ZDFChannelIE().suitable(url))
    ie = ZDFChannelIE()
    ie._real_extract(url)


# Generated at 2022-06-24 13:50:43.550479
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    (api_url, _, _, _, _) = ie._call_api('api', 'video_id', 'item', 'api_token', 'referrer')
    assert api_url == 'api'
    ptmd = ie._extract_ptmd('ptmd_url', 'video_id', 'api_token', 'referrer')
    assert ptmd['extractor_key'] == 'ZDF'
    assert ptmd['id'] == 'video_id'
    assert not ptmd['duration']
    assert not ptmd['formats']
    assert not ptmd['subtitles']



# Generated at 2022-06-24 13:50:46.426188
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test with mock html data
    from .test_download import _mock_webpage, _MockNetworkAccess
    url = "https://zdf.de/test"
    webpage = _mock_webpage(url)
    network_access = _MockNetworkAccess(webpage)
    expected_result = ZDFBaseIE(network_access=network_access)

    # Constructor of ZDFBaseIE
    actual_result = ZDFBaseIE(network_access=network_access)
    assert actual_result == expected_result


# Generated at 2022-06-24 13:50:49.855078
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_url = "https://www.zdf.de/dokumentation/planet-e"
    webpage = "https://www.zdf.de/dokumentation/planet-e"
    assert webpage == channel_url


# Generated at 2022-06-24 13:50:59.757544
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ZDFChannelIE._download_webpage = lambda x, y: y
    ZDFChannelIE._extract_player = lambda x, y, z: y
    ZDFChannelIE.suitable = lambda x: True
    zdf_channel_ie = ZDFChannelIE(url)
    assert zdf_channel_ie.match(url)
    assert zdf_channel_ie.ie_key() == 'ZDFChannel'
    assert zdf_channel_ie.ie_key() == 'ZDFChannel'
    assert zdf_channel_ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert zdf_channel_ie

# Generated at 2022-06-24 13:51:01.234774
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    # Test that class is not None
    assert ie is not None


# Generated at 2022-06-24 13:51:12.493628
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-24 13:51:16.769241
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(ZDFIE.ie_key())
    assert ie.ie_key() == 'ZDF'
    assert ie.GEO_COUNTRIES == ['DE']



# Generated at 2022-06-24 13:51:17.449643
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass



# Generated at 2022-06-24 13:51:19.572862
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    unit_test_ZDFIE = ZDFIE(0)



# Generated at 2022-06-24 13:51:24.567564
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test for constructor
    # with no parameters
    IE = ZDFBaseIE()
    assert IE.ie_key() == 'ZDF'
    assert IE.geo_countries() == ['DE']

    # with a key parameter
    IE = ZDFBaseIE(ie = 'test')
    assert IE.ie_key() == 'Test'



# Generated at 2022-06-24 13:51:29.798825
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    zdfchannel = ZDFChannelIE()
    zdfchannel._real_extract(url)
    zdfchannel1 = zdfchannel.suitable(url)
    assert zdfchannel1 == True


# Generated at 2022-06-24 13:51:36.785305
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert(hasattr(ZDFChannelIE, 'ie_key'))
    i = ZDFChannelIE()
    assert(i.ie_key() == 'ZDF')

# Generated at 2022-06-24 13:51:39.611007
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE()
    assert ie.suitable(url) == True
    ie.extract(url)
    assert ie._real_extract(url) == ZDFChannelIE._real_extract(ie, url)

# Generated at 2022-06-24 13:51:50.703217
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen'
    channel_id = 'phoenix-sendungen'
    webpage = BaseIE._download_webpage(url, channel_id, fatal=False)
    player = ZDFBaseIE._extract_player(webpage, channel_id, fatal=False)
    channel = ZDFBaseIE._call_api(
        'https://api.zdf.de/content/documents/%s.json' % channel_id,
        player, url, channel_id)
    #print(player)
    #print(channel)

    items = []

# Generated at 2022-06-24 13:51:52.606209
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()

    # test with an empty constructor
    assert ie.geo_countries == ie._GEO_COUNTRIES
    assert ie.qualities == ie._QUALITIES

# Generated at 2022-06-24 13:51:54.135070
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    zdf_ie._extract_player('{"content": "foo"}', 'video_id', True)


# Generated at 2022-06-24 13:51:55.333377
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE(id='ZDF') is not None

# Generated at 2022-06-24 13:52:03.830202
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES is not None
    assert ZDFBaseIE._QUALITIES is not None
    assert ZDFBaseIE._call_api is not None
    assert ZDFBaseIE._extract_subtitles is not None
    assert ZDFBaseIE._extract_format is not None
    assert ZDFBaseIE._extract_ptmd is not None
    assert ZDFBaseIE._extract_player is not None


# Generated at 2022-06-24 13:52:11.920932
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    newZDFIE = ZDFIE("ZDFIE", "The name of extracting used in kodion", "ZDF", "['DE']")
    assert newZDFIE.name == "ZDFIE"
    assert newZDFIE.description == "The name of extracting used in kodion"
    assert newZDFIE.ie_key() == "ZDF"
    assert newZDFIE._GEO_COUNTRIES == ['DE']
    assert newZDFIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:52:14.502713
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    videos = ZDFIE()
    videos.extract_videos(videos.ie_key(), videos._VALID_URL)

# Constructor test
test_ZDFIE()


# Generated at 2022-06-24 13:52:16.160548
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-24 13:52:18.332915
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie == ZDFIE
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:52:22.345207
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    baseIE = ZDFBaseIE()
    assert baseIE._GEO_COUNTRIES == ['DE']
    assert baseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:52:26.080131
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    BaseIE = type('BaseIE', (ZDFBaseIE, ), {})
    base = BaseIE(InfoExtractor())
    assert base._GEO_COUNTRIES == ['DE']

# Generated at 2022-06-24 13:52:36.181324
# Unit test for constructor of class ZDFIE
def test_ZDFIE():

    # test for get_video_info is not implemented, because the URL is not available in free internet
    assert ZDFIE().get_video_info('NA', 'NA') == None

    assert ZDFIE.ie_key() == 'zdf'

    # test_extract_format is not implemented, because the URL is not available in free internet
    assert ZDFIE()._extract_format('NA', 'NA', 'NA', 'NA') == None

    # test_extract_regular is not implemented, because the URL is not available in free internet
    assert ZDFIE()._extract_regular('NA', 'NA', 'NA') == None

    # test_extract_mobile is not implemented, because the URL is not available in free internet
    assert ZDFIE()._extract_mobile('NA') == None


# Generated at 2022-06-24 13:52:39.439853
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """ Unit test for constructor of class ZDFBaseIE
    """
    try:
        ZDFBaseIE(None, None)
    except TypeError as e:
        print(e)



# Generated at 2022-06-24 13:52:40.274841
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()



# Generated at 2022-06-24 13:52:52.150422
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html'
    video_id = '80004029'

# Generated at 2022-06-24 13:52:52.923787
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return ZDFChannelIE()

# Generated at 2022-06-24 13:52:54.763626
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    name = instance.IE_NAME
    expected_name = 'ZDF'
    assert name == expected_name


# Generated at 2022-06-24 13:52:57.142113
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE
    channel = ZDFChannelIE("https://www.zdf.de/sport/das-aktuelle-sportstudio")

# Generated at 2022-06-24 13:52:58.469107
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE().suitable(ZDFIE._VALID_URL)



# Generated at 2022-06-24 13:53:07.618781
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()
    zdf.suitable('http://www.zdf.de/sport')
    zdf.suitable('https://www.zdf.de/filme/filme-sonstige')
    zdf._real_extract('https://www.zdf.de/sport')
    zdf._real_extract('https://www.zdf.de/filme/filme-sonstige')



# Generated at 2022-06-24 13:53:16.658344
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .common import TEST_ROOT
    from .zdf import ZDFIE
    from .zdf_mediathek import ZDFMediathekIE

    # This test is mainly to ensure that the docstring example is valid
    # and to remind me to update the docstring example when new key are added
    # to the info dictionary.

    info = {
        '_type': 'url',
        'url': 'http://www.zdf.de/ZDFmediathek/kanaluebersicht/A-Z',
        'id': 'kanaluebersicht',
        'title': 'ZDFmediathek'
    }

    info_dict = ZDFChannelIE._build_info_dict(info)
    assert info_dict['id'] == 'kanaluebersicht'

    t = info_dict['_type']


# Generated at 2022-06-24 13:53:18.686175
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE()
    assert z.IE_NAME == 'ZDF'
    assert z.geo_countries == ['DE']

# Generated at 2022-06-24 13:53:19.966332
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-24 13:53:21.669360
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE is not None


# Generated at 2022-06-24 13:53:24.763357
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('id')
    assert ie.video_id == 'id'
    assert ie._GEO_COUNTRIES['DE']
    assert ie._QUALITIES[3] == 'high'



# Generated at 2022-06-24 13:53:27.322998
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    '''
    Test constructor for class ZDFChannelIE
    '''
    try:
        ZDFChannelIE()
    except Exception as e:
        print ('Exception in constructor ZDFChannelIE: ', e)
        raise



# Generated at 2022-06-24 13:53:35.980481
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('http://www.zdf.de/wissen/nano/')
    assert not ZDFChannelIE.suitable('http://www.zdf.de/politik/wahl-2017/wahlen/wahlen-nachrichten-zu-bundestagswahl/wahl-2017-bundestag-wahlomat-100.html')

# Generated at 2022-06-24 13:53:39.569421
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:53:51.999792
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    t1 = ZDFIE()

    try:
        t1._extract_regular()
    except:
        print ('_extract_regular() failed as expected')
    try:
        t1._extract_mobile()
    except:
        print ('_extract_mobile() failed as expected')

    try:
        t1._extract_entry()
    except:
        print ('_extract_entry() failed as expected')

    try:
        t1._extract_player()
    except:
        print ('_extract_player() failed as expected')

    try:
        t1._extract_ptmd()
    except:
        print ('_extract_ptmd() failed as expected')

# Generated at 2022-06-24 13:53:55.766556
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie = ZDFChannelIE(url)
    assert ie.suitable(url)
    assert ie.url == url
    assert ie.channel_id == 'das-aktuelle-sportstudio'
    assert ie.ie_key() == 'ZDFChannel'


# Generated at 2022-06-24 13:54:01.826557
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    IE = ZDFIE()
    assert IE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Unit tests for function _extract_player

# Generated at 2022-06-24 13:54:08.055506
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('http://zdf.de', 'https://zdf.de/path/to/url', 'http://zdf.de/path/to/referer')
    # Test creating an instance of ZDFBaseIE
    assert ie

# Generated at 2022-06-24 13:54:10.938170
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # set up the test object
    obj = ZDFBaseIE()
    # check if the object is valid
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:12.616439
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_ZDFIE()
    test_ZDFBaseIE(ZDFChannelIE)



# Generated at 2022-06-24 13:54:13.623782
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return ZDFChannelIE()



# Generated at 2022-06-24 13:54:16.484572
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:22.878874
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    for i, item in enumerate(ZDFIE._TESTS, 1):
        print('Processing test {}/{} ...'.format(i, len(ZDFIE._TESTS)))
        zdfie = ZDFIE()
        result = zdfie._real_extract(item['url'])
        print(result.keys())



# Generated at 2022-06-24 13:54:26.740379
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:54:32.705848
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class TestZDFChannelIE(ZDFChannelIE):
        def _real_extract(self, url):
            class FakeInfoExtractor:
                def __init__(self, ie_key):
                    self.ie_key = ie_key
            super(TestZDFChannelIE, self).__init__(
                FakeInfoExtractor('TestZDFChannelIE'))
            return super(TestZDFChannelIE, self)._real_extract(url)

    def test_ZDFChannelIE_suitable():
        assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')

# Generated at 2022-06-24 13:54:33.673911
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')

# Generated at 2022-06-24 13:54:34.568649
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    constructor_test(ZDFBaseIE)



# Generated at 2022-06-24 13:54:35.753357
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test = ZDFIE()
    assert isinstance(test, InfoExtractor)
    assert isinstance(test, ZDFBaseIE)


# Generated at 2022-06-24 13:54:36.763932
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_case = ZDFChannelIE()

# Generated at 2022-06-24 13:54:37.641587
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'

# Generated at 2022-06-24 13:54:41.381429
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
  from .common import parse_resolution
  geolocation = 'DE'
  assert geolocation in ZDFBaseIE._GEO_COUNTRIES
  qualities = [
    'auto',
    'low',
    'med',
    'high',
    'veryhigh',
    'hd'
  ]
  assert qualities == ZDFBaseIE._QUALITIES

# Generated at 2022-06-24 13:54:51.313606
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test case 1
    test_case_1 = ZDFBaseIE()
    assert test_case_1._GEO_COUNTRIES == ['DE']
    assert test_case_1._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert test_case_1._downloader is not None
    assert test_case_1._html_search_meta is not None
    assert test_case_1._html_search_regex is not None
    assert test_case_1._js_to_json is not None
    assert test_case_1._LOGGER_CLASS is not None
    assert test_case_1._logger is not None
    assert test_case_1._search_meta is not None
    assert test_case_1._search_regex is not None
   

# Generated at 2022-06-24 13:54:52.045309
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-24 13:54:54.037103
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test for constructor of class ZDFBaseIE
    ZDFBaseIE(None, 'http://www.example.com/')


# Generated at 2022-06-24 13:54:58.619932
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ret = ZDFIE._VALID_URL
    assert ret == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    ret = ZDFIE.__name__
    assert ret == 'ZDFIE'


# Generated at 2022-06-24 13:55:01.697664
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:06.497844
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    x = ZDFChannelIE('ZDFChannelIE', 'zdf.de', 'das-aktuelle-sportstudio')
    assert x._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert x._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'

# Generated at 2022-06-24 13:55:10.556781
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE("https://www.zdf.de/")
    assert ie.IE_NAME == "zdf"
    assert ie.GEO_COUNTRIES == ['DE']
    assert ie.QUALITIES == ['auto', 'low', 'med', 'high', 'veryhigh', 'hd']
    assert ie.http_headers == {}


# Generated at 2022-06-24 13:55:14.814646
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Testing with correct input
    zdf_baseie = ZDFBaseIE()

    assert zdf_baseie._GEO_COUNTRIES == ['DE']
    assert zdf_baseie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:18.329984
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    expected_instance_type = 'ZDFBaseIE'
    assert ZDFBaseIE.ie_key() == expected_instance_type
    assert isinstance(ZDFBaseIE, type)
    assert issubclass(ZDFBaseIE, InfoExtractor)


# Generated at 2022-06-24 13:55:30.556244
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    _download_webpage = ZDFChannelIE._download_webpage
    ZDFChannelIE._download_webpage = lambda x,y,z: z

    url = 'https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html'
    channel_id = ZDFChannelIE._match_id(url)
    webpage = ZDFChannelIE._download_webpage(None, channel_id, NO_DEFAULT)
    print('webpage:', webpage, '\n')
    player = ZDFChannelIE._extract_player(webpage, channel_id)
    print('player:', player, '\n')

# Generated at 2022-06-24 13:55:41.041168
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = '12345'
    ptmd_url = 'http://blah.blah/blah'
    api_token = 'abcdefg'
    referrer = 'http://www.zdf.de/'
    mock_obj = ZDFBaseIE()

    resp_obj = mock_obj._call_api(ptmd_url, video_id, 'metadata', api_token, referrer)

    assert resp_obj == mock_obj._download_json(
        ptmd_url, video_id, 'Downloading JSON metadata', headers={'Api-Auth': 'Bearer %s' % api_token, 'Referer': referrer})



# Generated at 2022-06-24 13:55:42.668999
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(ZDFIE._VALID_URL, ZDFIE._TESTS)


# Generated at 2022-06-24 13:55:45.990317
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:55:47.924956
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._VALID_URL == ZDFBaseIE._VALID_URL

# Generated at 2022-06-24 13:55:50.416116
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._VALID_URL == ZDFIE._VALID_URL
    assert ZDFIE()._TESTS == ZDFIE._TESTS


# Generated at 2022-06-24 13:55:52.582057
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-24 13:55:55.076788
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie.IE_NAME in ZDFIE.ie_key()

# Generated at 2022-06-24 13:56:05.174286
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._call_api("https://api.zdf.de/tmd/2/ngplayer_2_3/vod/ptmd/smil/34911100/ngs/index.smil", "", "", "", "") == None
    assert zdf._extract_subtitles({'captions': [{'betterThanSubtitles': False, 'language': 'deu', 'uri': 'foo'}, {'betterThanSubtitles': False, 'language': 'eng', 'uri': 'bar'}]}) == {'deu': [{'url': 'foo'}], 'eng': [{'url': 'bar'}]}
    assert zdf._extract_player('', '') == {}


# Generated at 2022-06-24 13:56:14.444689
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Unit test for ZDFChannelIE"""
    with pytest.raises(AssertionError):
        ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    with pytest.raises(AssertionError):
        ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e.html')
    with pytest.raises(AssertionError):
        ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e/test')
    with pytest.raises(AssertionError):
        ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e/test.html')

# Generated at 2022-06-24 13:56:18.133212
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.ie_key(url='https://www.zdf.de/test/test-test-test-test.html') == 'ZDF'

# Generated at 2022-06-24 13:56:19.441088
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    #ZDFIE()
    return


# Generated at 2022-06-24 13:56:22.449304
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:25.227281
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE(ZDFBaseIE())
    except ValueError as e:
        print(e)


# Generated at 2022-06-24 13:56:33.932773
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_suite = [
        [ 'hello world', False ],
        [ 'https://www.zdf.de/news/frontal-21/frontal-21-vom-28-november-2016-100.html', False ],
        [ 'https://www.zdf.de/dokumentation/planet-e', True ],
    ]

    for url, expected_result in test_suite:
        url = url.split(' ')[0]
        assert ZDFChannelIE.suitable(url) == expected_result, "%s failed" % url

# Generated at 2022-06-24 13:56:38.300506
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE("ZDFIE", "No such module")
    zdfie_api_call = zdfie._call_api("https://www.zdf.de/", "", "", None, None)
    assert(zdfie_api_call == {})


# Generated at 2022-06-24 13:56:50.259494
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    url = "https://www.zdf.de/dokumentation/planet-e"
    m = re.match(zdf_channel_ie._VALID_URL, url)
    assert m.groupdict()["id"] == "planet-e"
    assert ZDFChannelIE._match_id(url) == "planet-e"
    assert ZDFChannelIE.suitable(url)
    assert not ZDFChannelIE.suitable("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    assert zdf_channel_ie.ie_key() == "zdf"
    assert zdf_channel_ie.ie_key() == ZDFChannelIE.ie_key()
    assert ZDFChannelIE.ie_key

# Generated at 2022-06-24 13:56:59.162193
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test constructor
    check_method_works(ZDFChannelIE.suitable)
    check_method_works(ZDFChannelIE._match_id)
    check_method_works(ZDFChannelIE._real_extract)
    # Test suitable
    assert ZDFChannelIE.suitable(url='https://www.zdf.de/filme/taunuskrimi/')
    assert ZDFChannelIE.suitable(url='https://www.zdf.de/filme/taunuskrimi')
    assert not ZDFChannelIE.suitable(url='https://www.zdf.de/filme/taunuskrimi.html')
    # Test _match_id

# Generated at 2022-06-24 13:57:06.801236
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    for url in [
            'https://www.zdf.de/sport/das-aktuelle-sportstudio',
            'https://www.zdf.de/dokumentation/planet-e',
            'https://www.zdf.de/filme/taunuskrimi/']:
        ie = ZDFChannelIE(url)
        assert ie.suitable(url) is True
        assert ie.ie_key() == 'ZDFChannel'

# Generated at 2022-06-24 13:57:08.367425
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert isinstance(ZDFIE(), InfoExtractor)


# Generated at 2022-06-24 13:57:11.280096
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    zdf_ie.match()
    zdf_ie.extract()


# Confirm that all attributes of class ZDFIE is accessible

# Generated at 2022-06-24 13:57:16.357440
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = 'https://www.zdf.de/comedy/die-anstalt/die-anstalt-vom-3-mai-2017-100.html'

    zdf_base_ie_class = ZDFBaseIE
    zdf_base_ie_object = zdf_base_ie_class(url)
    assert type(zdf_base_ie_object) == zdf_base_ie_class


# Generated at 2022-06-24 13:57:22.565120
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert 'https://www.zdf.de/sport/das-aktuelle-sportstudio' == str(ZDFChannelIE._build_url(
        {'id': 'das-aktuelle-sportstudio'}))
    assert 'https://www.zdf.de/dokumentation/planet-e' == str(ZDFChannelIE._build_url(
        {'id': 'planet-e'}))


# Generated at 2022-06-24 13:57:33.234426
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Stub has_geo_restriction
    def has_geo_restriction(countries):
        return False
    # Stub get_countries
    def get_countries():
        return ['DE']
    # Stub download_json
    def download_json(url, video_id, note, headers):
        url = url.replace('/', '_').replace(':', '_').replace('=', '_').replace('&', '_').replace('?', '_')
        with open('test_data/' + url + '.json', 'r') as myfile:
            return json.loads(myfile.read())
    # Stub search_regex

# Generated at 2022-06-24 13:57:38.861883
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    ZDFBaseIE __init__ method
    """
    for ie in [ZDFIE(), ZDFBaseIE()]:
        assert ie.ie_key() == 'ZDF'
        assert ie._GEO_COUNTRIES == ['DE']
        assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:57:43.614722
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info_extractor = ZDFBaseIE()
    assert(info_extractor._GEO_COUNTRIES == ['DE'])
    assert(info_extractor._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))

#########################################################


# Generated at 2022-06-24 13:57:51.442010
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .youtube_dl.extractor import gen_extractors_by_class
    from .youtube_dl import YoutubeDL

    url = 'https://www.zdf.de/politik/frontal21'
    klass = list(gen_extractors_by_class(ZDFChannelIE))[0]
    ydl = YoutubeDL(dict(forceurl=True, forceduration=True))
    ydl.add_info_extractor(klass)
    ydl.process_ie_result(klass.suitable(url), download=False)


# Generated at 2022-06-24 13:57:58.452072
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/')



# Generated at 2022-06-24 13:58:01.175569
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    InfoExtractor._sort_formats([])
    _extract_ptmd('', '', '', '')
    _extract_player('', '', True)

# Generated at 2022-06-24 13:58:02.554485
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:58:11.227542
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    input_output_dict = [{
        'input': 'https://www.zdf.de/filme/taunuskrimi/',
        'output': {
            '_type': 'playlist',
            'entries': [],
            'id': 'taunuskrimi',
            'title': 'Taunuskrimis | ZDFmediathek',
        },
    }, {
        'input': 'https://www.zdf.de/nachrichten/heute-journal',
        'output': {
            '_type': 'playlist',
            'entries': [],
            'id': 'heute-journal',
            'title': 'heute journal | ZDF',
        },
    }]

# Generated at 2022-06-24 13:58:12.260129
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()



# Generated at 2022-06-24 13:58:15.579933
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    initial_ZDFBaseIE = ZDFBaseIE('ZDFBaseIE')
    assert initial_ZDFBaseIE.geo_countries == ['DE']
    assert initial_ZDFBaseIE._call_api('example_url', 'example_video_id',
                                       'example_item')

# Generated at 2022-06-24 13:58:16.708981
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_constructor(ZDFChannelIE)

# Generated at 2022-06-24 13:58:24.326755
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    IE = globals()["ZDF" + "ChannelIE"]()

    # It must return an instance of its own class
    assert isinstance(IE, ZDFChannelIE)

    # noinspection PyProtectedMember
    assert "suitable" in dir(IE)
    # assert "suitable" in IE.__dict__
    assert not IE.suitable("https://www.zdf.de/sport/das-aktuelle-sportstudio")

# Generated at 2022-06-24 13:58:25.714344
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf is not None



# Generated at 2022-06-24 13:58:37.506110
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()
    assert zdf.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert zdf.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert zdf.suitable('https://www.zdf.de/dokumentation/planet-e')

    # not suitable as ZDFIE should have been selected
    assert not zdf.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

# Generated at 2022-06-24 13:58:43.192349
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    video_id = '100.html'
    url = r'https?://www\.zdf\.de/filme/filme-sonstige/(?P<id>[^/?#&]+)\.html'
    url = url.replace('(?P<id>[^/?#&]+)', video_id)

# Generated at 2022-06-24 13:58:47.537762
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:58:58.926437
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test with https://www.zdf.de/dokumentation/zdfinfo/die-mumie-100.html
    # URL='https://www.zdf.de/dokumentation/zdfinfo/die-mumie-100.html'
    URL = 'https://www.zdf.de/dokumentation/zdfinfo/die-mumie-100.html'

# Generated at 2022-06-24 13:59:06.810505
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # ZDFChannelIE.suitable(url)
    assert not ZDFChannelIE.suitable('')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/')
    # ZDFChannelIE._real_extract(self, url)
    _real_extract = ZDFChannelIE()._real_extract
    assert _real_extract('https://www.zdf.de/dokumentation/planet-e/')

# Generated at 2022-06-24 13:59:10.941785
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:59:21.891727
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:59:27.098185
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    inst = ZDFChannelIE()
    res = inst.suitable(url)
    if (res == False):
        print("This test should have returned true as it is a ZDFChannelIE URL")
        sys.exit(1)
    return res

if __name__ == "__main__":
    test_ZDFChannelIE()

# Generated at 2022-06-24 13:59:30.829027
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    zdfie.IE_NAME = 'zdf'
    zdfie.ie_key()

# Generated at 2022-06-24 13:59:34.396040
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
	zdf_ie = ZDFIE()
	assert zdf_ie != None	
	zdf_ie.extract('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')


# Generated at 2022-06-24 13:59:38.152646
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:59:40.134185
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL[0])

# Generated at 2022-06-24 13:59:51.884518
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdf_ie._GEO_COUNTRIES == ['DE']
    assert zdf_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:59:54.221428
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    inst = ZDFIE()
    inst._extract_player(
        '', 'a-b-c', 'player.content')


# Generated at 2022-06-24 14:00:02.193888
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    fake_url = 'https://www.zdf.de/dokumentation/planet-e'
    fake_html = '<html></html>'
    fake_player = {'content': 'https://www.fake-api.de/content/'}

    class A(ZDFChannelIE):
        def _real_extract(self, url):
            items = []
            item = {}
            item.update(self._extract_regular(url, fake_player, fake_url))
            items.append(item)
            return self.playlist_result(items, self._match_id(url), fake_url)

    inst = A()
    inst._download_webpage = lambda url, video_id, fatal=True: fake_html
    inst._extract_player = lambda webpage, url, fatal=True: fake_