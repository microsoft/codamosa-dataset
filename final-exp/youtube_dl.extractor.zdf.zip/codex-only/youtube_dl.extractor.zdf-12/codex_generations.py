

# Generated at 2022-06-24 13:50:03.876616
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE()
    assert z.__class__.__name__ == "ZDFIE"



# Generated at 2022-06-24 13:50:05.945923
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']

# end of unit test



# Generated at 2022-06-24 13:50:10.684861
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_url = 'https://www.zdf.de/filme/taunuskrimi/'
    assert ZDFChannelIE.suitable(channel_url)
    ie = ZDFChannelIE(url=channel_url)
    assert ie.channel_id == 'taunuskrimi'
    assert ie.channel_title == None


# Generated at 2022-06-24 13:50:14.519615
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Calling the constructor of class ZDFChannelIE should return an instance of class ZDFChannelIE
    IEInstance = ZDFChannelIE("url")
    assert isinstance(IEInstance, ZDFChannelIE)



# Generated at 2022-06-24 13:50:18.410810
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ydl = YoutubeDL()
    ydl.add_info_extractor(ZDFChannelIE)
    print(ydl.extract_info(
        'https://www.zdf.de/dokumentation/planet-e', download=False
    )['title'])  # 'planet e.'

# Generated at 2022-06-24 13:50:23.174360
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE(InfoExtractor())
    assert isinstance(zdf_base_ie._GEO_COUNTRIES, list)
    assert isinstance(zdf_base_ie._QUALITIES, tuple)
    assert isinstance(zdf_base_ie, InfoExtractor)



# Generated at 2022-06-24 13:50:24.743379
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    global ZDFBaseIE
    ZDFBaseIE



# Generated at 2022-06-24 13:50:29.288642
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:31.189042
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert len(zdf_ie._VALID_URL) > 10

# Generated at 2022-06-24 13:50:38.099535
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_ie = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert test_ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True
    assert test_ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html') == False


# Generated at 2022-06-24 13:50:41.706417
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # the following method tests the constructor for class ZDFIE
    ie = ZDFIE()
    if ie is None:
        print("There is no instance of class ZDFIE")
    else:
        print("An instance of class ZDFIE exists")


# Generated at 2022-06-24 13:50:44.255951
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie is not None

# Generated at 2022-06-24 13:50:45.724970
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    return ZDFBaseIE('ZDFBaseIE')


# Generated at 2022-06-24 13:50:52.518319
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    '''
    Test method. Calling without param
    '''
    zdf = ZDFIE()
    zdf.get_id(0)
    zdf.get_id(1)    
    zdf.get_id(2)
    zdf.get_id(3)
    zdf.get_id(4)
    zdf.get_id(5)
    zdf.get_id(6)
    zdf.get_id(7)
    zdf.get_id(8)
    zdf.get_id(9)

# Generated at 2022-06-24 13:50:58.515143
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/') == False
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') == True


# Generated at 2022-06-24 13:51:01.140427
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable(ZDFChannelIE._VALID_URL)


# Generated at 2022-06-24 13:51:12.409940
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:51:19.120379
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdftest = ZDFIE()
    zdftest._VALID_URL = 'https://www.zdf.de/filme/zdf-klassik-kino/gewuerzpapst-der-moench-aus-dem-ara-100.html'

# Generated at 2022-06-24 13:51:21.699723
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE("https://www.zdf.de/sport/das-aktuelle-sportstudio")



# Generated at 2022-06-24 13:51:24.317438
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE')

# -----------------------------------------------------


# Generated at 2022-06-24 13:51:32.587084
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
  if __name__ == '__main__':
    zdf_base_ie = ZDFBaseIE()
    zdf_base_ie._FORMAT_VERSIONS += ('2.6.9')
    zdf_base_ie.setFormats('v_mp4_webm_h264_h265_vp9')
    zdf_base_ie._extract_subtitles('subtitles')
    zdf_base_ie._extract_ptmd('test_url', 'test_id', 'test_token', 'test_referer')
    zdf_base_ie._extract_player('test_webpage', 'test_id')


# Generated at 2022-06-24 13:51:37.228398
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()

    assert hasattr(ie, '_GEO_COUNTRIES') == True
    assert hasattr(ie, '_QUALITIES') == True

    e = ie
    assert hasattr(e, '_call_api') == True
    assert hasattr(e, '_extract_subtitles') == True
    assert hasattr(e, '_extract_format') == True
    assert hasattr(e, '_extract_ptmd') == True
    assert hasattr(e, '_extract_player') == True


# Generated at 2022-06-24 13:51:42.971496
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE(None)
    zdfie.content
    zdfie.player
    zdfie.video_id
    zdfie.mediaUrl
    zdfie.title
    zdfie.ptmd_path
    zdfie.api_token
    zdfie.referrer
    zdfie.url


# Generated at 2022-06-24 13:51:46.341277
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    print(ie._GEO_COUNTRIES)
    print(ie._QUALITIES)
    print(re.compile(ie._VALID_URL))
    print(ie._TESTS)
    print(ie.ie_key())
    

# Generated at 2022-06-24 13:51:50.755259
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE.ie_key() == 'zdf'
    assert ZDFBaseIE.ie_key() == 'ZDF'
    assert ZDFBaseIE.ie_key() == 'ZDFBase'
    assert ZDFBaseIE.ie_key() == 'zdfbase'


# Generated at 2022-06-24 13:51:52.990367
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:54.245709
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    print(instance)


# Generated at 2022-06-24 13:51:56.376741
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase_ie = ZDFBaseIE("test")

    assert zdfbase_ie._GEO_COUNTRIES == ['DE']
    assert zdfbase_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:52:00.506081
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ZDFChannelIE(url)



# Generated at 2022-06-24 13:52:02.145522
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    _test_playlist_class(ZDFChannelIE)


# Generated at 2022-06-24 13:52:13.668511
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    out = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    # assert that url is set to url
    assert out.url == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    # assert that the function _match_id gives the correct output
    assert out._match_id('https://www.zdf.de/sport/das-aktuelle-sportstudio') == 'das-aktuelle-sportstudio'
    # assert that the function _match_id gives the correct output

# Generated at 2022-06-24 13:52:16.378193
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    # Test the length of _QUALITIES
    assert len(ie._QUALITIES) == 6


# Generated at 2022-06-24 13:52:28.428819
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # This is a test for the constructor of class ZDFChannelIE.
    # Test-Cases
    # 1. Constructor with invalid URL
    # 2. Constructor with valid URL but not a channel
    # 3. Constructor with valid URL but not a channel
    url_tc1 = "invalid_url"
    url_tc2 = "https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html"
    url_tc3 = "https://www.zdf.de/sport/das-aktuelle-sportstudio"
    # Expected Outputs
    # 1. Constructor return value is None
    # 2. Constructor return value is None
    # 3. Constructor

# Generated at 2022-06-24 13:52:30.970688
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie.get_url() == ''
    assert zdf_ie.get_ie() == ZDFIE



# Generated at 2022-06-24 13:52:40.504831
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert hasattr(ZDFIE, 'IE_DESC')
    assert type(ZDFIE.IE_DESC) == str
    assert len(ZDFIE.IE_DESC) > 10
    assert len(ZDFIE.IE_DESC) < 50
    assert hasattr(ZDFIE, '_VALID_URL')
    assert type(ZDFIE._VALID_URL) == str
    assert hasattr(ZDFIE, '_TESTS')
    assert type(ZDFIE._TESTS) == list
    assert len(ZDFIE._TESTS) > 10
    for test in ZDFIE._TESTS:
        assert hasattr(ZDFIE, '_real_extract')
        assert len(test) > 5
        assert 'url' in test

# Generated at 2022-06-24 13:52:41.596227
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert(ZDFBaseIE)


# Generated at 2022-06-24 13:52:43.489408
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel = ZDFChannelIE()

# Generated at 2022-06-24 13:52:44.954906
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:52:47.220418
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        ZDFChannelIE()
    except Exception as e:
        raise AssertionError(e)

# Generated at 2022-06-24 13:52:53.463159
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        instance = ZDFBaseIE('ZDFBaseIE', 'www.zdf.de')
    except Exception as e:
        assert False, "Couldn't create ZDFBaseIE instance"
    assert instance._GEO_COUNTRIES==['DE'], "ZDFBaseIE._GEO_COUNTRIES not set"
    assert instance._QUALITIES==('auto', 'low', 'med', 'high', 'veryhigh', 'hd'), "ZDFBaseIE._QUALITIES not set"



# Generated at 2022-06-24 13:52:57.552657
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    info = ZDFChannelIE()._real_extract('https://www.zdf.de/dokumentation/planet-e')
    assert info['_type'] == 'playlist'
    assert info['title'] == 'planet e.'
    assert info['id'] == 'planet-e'
    assert len(info['entries']) >= 50



# Generated at 2022-06-24 13:53:01.775796
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:53:06.908413
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE()._VALID_URL == 'https?://(?:www\.)?zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 13:53:16.231737
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:53:17.953089
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:53:24.479051
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from urllib.parse import urlparse
    from .common import urlencode_postdata
    from .compat import compat_urllib_parse_urlencode


# Generated at 2022-06-24 13:53:30.099747
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .youtube import YoutubeIE
    from .playlist import PlaylistIE
    from .common import InfoExtractor
    from .extractor import gen_extractors
    from .zdf import _pirate_playlist_result
    from collections import OrderedDict
    import inspect

    for _, ie in gen_extractors():
        try:
            if not issubclass(ie, InfoExtractor):
                continue
        except TypeError:
            continue
        print(ie.__name__)
        assert(inspect.isclass(ie))
        assert(issubclass(ie, InfoExtractor))
        if not issubclass(ie, (PlaylistIE, YoutubeIE)):
            continue
        else:
            if issubclass(ie, YoutubeIE):
                continue
            assert(inspect.isclass(ie))


# Generated at 2022-06-24 13:53:35.631402
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE()._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:53:38.034941
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie._UNIT_TESTING = True
    ie.init(ie._VALID_URL)

# Generated at 2022-06-24 13:53:45.279506
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()
    assert ie._VALID_URL == ZDFIE._VALID_URL
    assert ie._TESTS == ZDFIE._TESTS
    assert ie._GEO_COUNTRIES == ZDFBaseIE._GEO_COUNTRIES
    assert ie._QUALITIES == ZDFBaseIE._QUALITIES

# Generated at 2022-06-24 13:53:55.827418
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_IE = ZDFChannelIE()
    # This is the basic information needed in the initializer

# Generated at 2022-06-24 13:54:03.238841
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # We must check that the class ZDFBaseIE is instanciable
    ie = ZDFBaseIE()
    # We must check that the class ZDFBaseIE has these members
    assert hasattr(ie, '_call_api')
    assert hasattr(ie, '_extract_format')
    assert hasattr(ie, '_extract_ptmd')


# Generated at 2022-06-24 13:54:07.617491
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import pytest
    with pytest.raises(ExtractorError):
        ZDFChannelIE()

# Generated at 2022-06-24 13:54:08.653215
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    IE = ZDFBaseIE()
    assert IE is not None


# Generated at 2022-06-24 13:54:17.308154
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.utils import parse_iso8601
    import pytz
    from datetime import datetime
    from urllib.parse import parse_qs
    print('Unit test for ZDFChannelIE')
    zdf_channel_ie = ZDFChannelIE()
    zdf_channel_ie._downloader = None

    def get_testfiles(ie_module, channel_name):
        return glob.glob(os.path.join('downloads', 'tests', 'testfiles', ie_module, channel_name, '*'))

    def get_testfile(ie_module, channel_name, filename):
        return glob.glob(os.path.join('downloads', 'tests', 'testfiles', ie_module, channel_name, filename))[0]


# Generated at 2022-06-24 13:54:21.002778
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:29.182030
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test valid URL
    url = 'http://www.zdf.de/ZDFmediathek/hauptnavigation/startseite#/beitrag/video/21493764/Das-Geheimnis-der-Schatzinsel-Teil-6'
    assert ZDFBaseIE._is_valid_url(url) is True

    # Test invalid URL
    url = 'http://www.zdf.de/test/test/test'
    assert ZDFBaseIE._is_valid_url(url) is False



# Generated at 2022-06-24 13:54:30.227500
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:54:35.562137
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-24 13:54:41.219765
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert isinstance(ie, InfoExtractor)
    assert hasattr(ie, '_GEO_COUNTRIES')
    assert hasattr(ie, '_QUALITIES')
    assert hasattr(ie, '_call_api')
    assert hasattr(ie, '_extract_subtitles')
    assert hasattr(ie, '_extract_format')
    assert hasattr(ie, '_extract_ptmd')
    assert hasattr(ie, '_extract_player')



# Generated at 2022-06-24 13:54:49.861749
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    zdf.set_downloader(None)
    assert zdf._call_api(None, None, None) is None
    assert zdf._extract_format(None, None, None, None) is None
    assert zdf._extract_ptmd(None, None, None, None) == {}
    assert zdf._extract_player(None, None, None) == {}
    assert zdf.IE_NAME == 'ZDF'
    assert zdf.ie_key() == 'zdf'
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:54:54.844003
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannel = ZDFChannelIE()
    assert zdfChannel.suitable('https://www.zdf.de/filme/taunuskrimi')
    assert not zdfChannel.suitable('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')



# Generated at 2022-06-24 13:54:56.140430
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('ZDFBaseIE')


# Generated at 2022-06-24 13:54:57.441007
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert isinstance(ZDFIE('zdf'), ZDFIE)

# Generated at 2022-06-24 13:54:58.704696
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(InfoExtractor("foo"))


# Generated at 2022-06-24 13:54:59.676808
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable(None)


# Generated at 2022-06-24 13:55:07.525766
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdf_channel_ie.suitable(
        'https://www.zdf.de/dokumentation/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/russias-frauen-im-kampf-gegen-die-mafia-100.html')

# Generated at 2022-06-24 13:55:08.777463
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None, None)


# Generated at 2022-06-24 13:55:11.609281
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'ZDF'

####################################################################################


# Generated at 2022-06-24 13:55:13.649877
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Test case for constructor of class ZDFChannelIE.
    """
    parser = ZDFChannelIE()

# Generated at 2022-06-24 13:55:22.007561
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class TestZDFChannelIE(ZDFChannelIE):
        # Method '_call_api' used in ZDFChannelIE
        # should be implemented by subclass itself.
        # This is just for unittest purpose.
        def _call_api(self, url, video_id, player_param, api_token, referrer):
            return self._download_json(
                url, video_id, 'Downloading content', query={player_param: api_token},
                headers={'Referer': referrer})

    channel_url = 'https://www.zdf.de/dokumentation/planet-e'
    # This is a test for subclass
    # so this test should be run in another file.
    # For unittest purpose we make this test run
    # in class ZDFIE.
    test_channel = TestZDF

# Generated at 2022-06-24 13:55:25.737521
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie is not None

# Generated at 2022-06-24 13:55:30.600224
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from ..ZDFChannelIE import ZDFChannelIE
    from ..test import get_testcases
    for case in get_testcases(ZDFChannelIE, playlist=True, merge=True):
        zdf_channel_ie = ZDFChannelIE(case['url'])
        assert zdf_channel_ie.suitable(case['url']) == True

# Generated at 2022-06-24 13:55:34.215724
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import logging
    import unittest
    import urllib
    import zdf_channel
    zdf_channel.ZDFChannelIE(logging.getLogger(unittest.__name__))
    zdf_channel.test_ZDFChannelIE()


# Generated at 2022-06-24 13:55:38.273286
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie is not None

# Generated at 2022-06-24 13:55:43.504374
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Create an instance of class ZDFChannelIE with given url
    zdf_channel_ie = ZDFChannelIE("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    # Print the url of the channel
    print(zdf_channel_ie._match_id("https://www.zdf.de/sport/das-aktuelle-sportstudio"))


# Generated at 2022-06-24 13:55:47.487664
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.__class__.__name__ == "ZDFBaseIE"
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, ZDFBaseIE)


# Generated at 2022-06-24 13:55:48.885255
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'zdf'


# Generated at 2022-06-24 13:55:59.276631
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor of class ZDFBaseIE
    obj = ZDFBaseIE()
    # Check result of call of method _call_api
    obj._call_api(
        "http://test.test",
        "idtest",
        "itemtest",
        "apitest",
        "reftest"
    )
    # Check result of call of method _extract_subtitles
    print(obj._extract_subtitles({
        u'captions': [{
            u'uri': u'datatest',
            u'language': u'lantest',
        }],
    }))
    # Check result of call of method _extract_format

# Generated at 2022-06-24 13:56:00.678339
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()



# Generated at 2022-06-24 13:56:11.231077
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:56:12.189318
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
	zdf_ie = ZDFIE()



# Generated at 2022-06-24 13:56:21.529405
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    instance._call_api('https://page-with-json.json', 'video_id', 'item')
    instance._extract_subtitles({})
    instance._extract_format('video_id', [], set(), {})
    pts = 'https://conf.zdf.de/api/asset/3lj1/PTMD'
    instance._extract_ptmd(pts, 'video_id', 'api_token', 'referrer')
    instance._extract_player('{"data-zdfplayer-jsb": "{}"}', 'video_id')



# Generated at 2022-06-24 13:56:25.580661
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert isinstance(ie, ZDFBaseIE)


# Generated at 2022-06-24 13:56:28.039961
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:30.710373
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase = ZDFBaseIE();
    assert zdfbase._GEO_COUNTRIES == ['DE'];
    assert zdfbase._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd');


# Generated at 2022-06-24 13:56:38.962824
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    constr = ZDFChannelIE.suitable # call constructor
    assert (constr('https://www.zdf.de/nachrichten/heute-1930/heute-in-europa-100.html'))
    assert (not constr('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'))
    assert (not constr('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'))
    assert (constr('https://www.zdf.de/dokumentation/planet-e/'))

# Generated at 2022-06-24 13:56:42.984701
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    with pytest.raises(AssertionError):
        ZDFChannelIE.suitable('http://www.zdf.de/test.html')
        ZDFIE.suitable('https://www.zdf.de/test.html')

# Generated at 2022-06-24 13:56:54.262715
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == "https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html"

# Generated at 2022-06-24 13:57:06.204939
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    video_id = '151025_magie_farben2_tex'
    webpage = '<html></html>'

    ZDFIE(None)._extract_player(webpage, url, fatal=False)

    ZDFIE(None)._call_api('/abc', video_id, 'abc', None, None)

    ZDFIE(None)._extract_mobile(video_id)


# Generated at 2022-06-24 13:57:14.812616
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')


# Generated at 2022-06-24 13:57:16.339035
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    aie = ZDFBaseIE('ZDFBaseIE', 'zdf')



# Generated at 2022-06-24 13:57:16.925646
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    pass

# Generated at 2022-06-24 13:57:27.514742
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest
    import yaml
    class TestZDFChannelIE(unittest.TestCase):
        def test_constructor(self):
            class_name = 'ZDFChannelIE'
            ie = globals()[class_name]()
            self.assertEqual(ie.IE_NAME, class_name)
            self.assertEqual(ie._VALID_URL, ie.VALID_URL)
            self.assertEqual(ie._TESTS, ie.TESTS)
            self.assertTrue(hasattr(ie, '_download_webpage'))
            self.assertTrue(hasattr(ie, '_real_extract'))
    unittest.main(argv=['--verbose'], exit=False)


# Generated at 2022-06-24 13:57:31.508703
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'





# Generated at 2022-06-24 13:57:43.292193
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() == 'ZDF'
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:57:44.122849
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert(isinstance(instance, InfoExtractor))


# Generated at 2022-06-24 13:57:54.328043
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html') == False
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') == False
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html') == False

# Generated at 2022-06-24 13:57:56.961911
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._extract_regular(None, None, None)


# Generated at 2022-06-24 13:57:57.886693
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable(None)

# Generated at 2022-06-24 13:57:59.665365
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Create a ZDFIE instance
    ZDFIE('wwww.zdf.de')


# Generated at 2022-06-24 13:58:09.090182
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    #test normal case
    ie = ZDFIE()
    assert(ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html')
    #test different url
    ie = ZDFIE(VALID_URL = r'https?://www\.zdf\.de/sport/video/(?P<id>[^/?#&]+)\.html')
    assert(ie._VALID_URL == r'https?://www\.zdf\.de/sport/video/(?P<id>[^/?#&]+)\.html')


# Generated at 2022-06-24 13:58:11.702709
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    title = ie.title
    assert(title == 'das aktuelle sportstudio | ZDF')

# Generated at 2022-06-24 13:58:13.555061
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_ZDFIE = ZDFIE()



# Generated at 2022-06-24 13:58:16.284262
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print("testing constructor of class ZDFChannelIE")
    # test empty constructor
    ZDFChannelIE()
    return True


# Generated at 2022-06-24 13:58:27.975193
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()

    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:58:29.452430
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test = ZDFChannelIE()
    assert test.suitable(ZDFChannelIE._VALID_URL)
    assert not test.suitable(ZDFIE._VALID_URL)

# Generated at 2022-06-24 13:58:30.489442
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()


# Generated at 2022-06-24 13:58:41.960876
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test whether constructor of class ZDFChannelIE
    #  raises exception if arguments are invalid
    with pytest.raises(TypeError):
        ZDFChannelIE()
    # Test whether constructor raises exception if argument
    #  'url' is missing
    with pytest.raises(TypeError):
        ZDFChannelIE('http://test.test', 'test')
    # Test whether constructor raises exception if argument
    #  'test' is missing
    with pytest.raises(TypeError):
        ZDFChannelIE('http://test.test', id='test')
    # Test whether constructor raises exception if argument
    #  'ie_key' is missing
    with pytest.raises(TypeError):
        ZDFChannelIE('http://test.test', 'test', 'test')
    # Test whether constructor raises exception if argument
   

# Generated at 2022-06-24 13:58:54.256136
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    video_id = '210222_phx_nachgehakt_corona_protest'
    ie = ZDFIE()
    # test the constructor of class ZDFIE
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._TESTS[0]['url'] == url
    assert ie._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'

# Generated at 2022-06-24 13:59:00.322069
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_suite = [{
            'url': 'https://www.zdf.de/dokumentation/planet-e'
        }, {
            'url': 'https://www.zdf.de/sport/das-aktuelle-sportstudio',
        }]
    for test in test_suite:
        ie = ZDFChannelIE(test['url'])
        assert ie._match_id(test['url'])
        assert not hasattr(ie, "_default_headers")


# Generated at 2022-06-24 13:59:02.445451
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test constructor of class ZDFIE
    zdf = ZDFIE()



# Generated at 2022-06-24 13:59:03.297067
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'zdf'


# Generated at 2022-06-24 13:59:08.925443
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('https://www.zdf.de/film/vox-pop')
    assert ie.url == 'https://www.zdf.de/film/vox-pop'
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:59:11.275769
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE()._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:59:18.569352
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie._call_api('url', 'id', 'item') == None
    assert ie._extract_subtitles('src') == None
    # TODO: continue to implement this test

# Test for _extract_format of class ZDFBaseIE

# Generated at 2022-06-24 13:59:25.172403
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class_ = globals()['ZDFChannelIE']
    assert class_.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert class_.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not class_.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert class_ == globals()['ZDFChannelIE']



# Generated at 2022-06-24 13:59:35.809374
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:59:48.166980
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Update: module urllib3.response changes #4186
    from .test_downloader import TestDownloader
    from .test_youtube import YoutubeDL

    ZDFChannelIE.suitable('')
    assert test_ZDFChannelIE.__module__ == 'test_zdf'
    TestDownloader.suitable('')
    assert TestDownloader.__module__ == 'test_downloader'
    # Must be tested before ZDFChannelIE._download_webpage() is called
    YoutubeDL.suitable('')
    assert YoutubeDL.__module__ == 'test_youtube'

    # Test proper path initialisation with __name__ == '__main__'
    instance = ZDFChannelIE(YoutubeDL())
    assert instance._downloader is not None

# Generated at 2022-06-24 13:59:58.359833
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbaseie_test = ZDFBaseIE('ZDFBaseIE', 'zdf.de')
    assert zdfbaseie_test._GEO_COUNTRIES == ['DE']
    assert zdfbaseie_test._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert re.match(
        r'(?s)\A{"class": "ZDFBaseIE", "ie_key": "ZDFBaseIE", "title": "zdf.de"'.format(), zdfbaseie_test.__str__()) is not None
    assert zdfbaseie_test.ie_key() == 'ZDFBaseIE'
    assert zdfbaseie_test.working == False
    assert zdfbaseie_test.title == 'zdf.de'
    assert zdfbaseie

# Generated at 2022-06-24 14:00:08.354953
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    inst = ZDFChannelIE()
    assert(inst.suitable(ZDFIE._VALID_URL))
    assert(not inst.suitable('http://www.phoenix.de/cms/mediathek/'))
    assert(not inst.suitable('http://www.phoenix.de/cms/mediathek/'))
    assert(not inst.suitable(ZDFIE._VALID_URL))
    assert(not inst.suitable(ZDFIE._VALID_URL))
    assert(not inst.suitable('https://www.3sat.de/mediathek/?_=1591628181523#!/'))
    assert(not inst.suitable('https://www.3sat.de/mediathek/?_=1591628181523#!/'))