

# Generated at 2022-06-24 13:50:04.690171
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('zdf.de', 'ab-18')
    assert ie.url_result == ZDFIE.url_result
    assert ie.suitable == ZDFIE.suitable
    assert ie._real_extract == ZDFChannelIE._real_extract



# Generated at 2022-06-24 13:50:06.415330
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDF')
    assert isinstance(ie, ZDFBaseIE)


# Generated at 2022-06-24 13:50:09.995081
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:20.853786
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # TODO: Covert this unit test to test
    # unit test for class ZDFIE
    from pprint import pprint
    instance = ZDFIE()  # create an object
    pprint(vars(instance)) # pretty print the object 'instance'
    instance.urls = (  # feed URLs to the object
        'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html',
        'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html',
    )

    # extract the URLs
    # instance._real_extract


# Generated at 2022-06-24 13:50:24.425452
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:26.119263
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert isinstance(ZDFChannelIE({}), ZDFChannelIE)



# Generated at 2022-06-24 13:50:30.198779
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class_zdfchannelie = globals()['ZDFChannelIE']
    assert class_zdfchannelie.suitable(
        'https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-24 13:50:39.685829
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from zdf_downloader.zdf_downloader import ZDFDownloader
    print("Test: [SITE] [zdf.de] [ZDFChannelIE]")
    zdf_dl = ZDFDownloader()
    zdf_dl.init_httplib2_handler()
    zdf_dl.init_url_extractor()
    url = "https://www.zdf.de/dokumentation/planet-e"
    ie = zdf_dl.get_info_extractor(url)
    if ie is None:
        assert False, "No suitable info extractor found for [%s]" %url
    assert ie.name == 'ZDFChannelIE'
    assert ie.get_info_url(url) == url
    assert ie.get_info_id(url) == 'planet-e'
   

# Generated at 2022-06-24 13:50:50.396339
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """unit-test class ZDFChannelIE"""

    # ~ __name__ = 'ZDFChannelIE'
    # ~ __doc__ = ZDFChannelIE.__doc__
    # ~ __module__ = ZDFChannelIE.__module__

    # ~ locals().update(func(ZDFChannelIE))

    IE = ZDFChannelIE()
    IE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    IE.suitable('https://www.zdf.de/filme/taunuskrimi/')


# Generated at 2022-06-24 13:50:53.682431
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    m = ZDFChannelIE(ZDFChannelIE.suitable)._match_id('https://www.zdf.de/dokumentation/planet-e/')
    assert m == 'planet-e'



# Generated at 2022-06-24 13:50:58.771504
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Test of method _call_api
# Comment: This is a method to call API using specified parameters.

# Generated at 2022-06-24 13:51:03.262598
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert obj._call_api([])
    assert obj._extract_subtitles([])


# Generated at 2022-06-24 13:51:13.780765
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    obj = ZDFChannelIE()
    assert obj._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 13:51:15.659389
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
  ZDFIE() # Test loading of the module

# Generated at 2022-06-24 13:51:27.160510
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import json
    webpage = '<span id=bla><a href="http://someurl.de/video/1234567890123456">Link</a></span>'


# Generated at 2022-06-24 13:51:28.173425
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None)
    ZDFBaseIE(None, 'zdf.de')



# Generated at 2022-06-24 13:51:31.563779
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    zdf._call_api(
        "https://api.zdf.de/content/documents/zdf/3w/gid-1433195/version.json?profile=player",
        "0100023",
        "version information")

# Generated at 2022-06-24 13:51:33.098640
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()



# Generated at 2022-06-24 13:51:45.394196
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Unit test for contructor of class ZDFBaseIE"""
    from ..compat import compat_urllib_request
    from ..utils import HEADRequest
    try:
        # first use a HEAD request to check if the URL still exists
        compat_urllib_request.urlopen(HEADRequest(
            'http://www.zdf.de/ZDFmediathek/kanaluebersicht/?flash=off'))
    except:
        # if the URL is not found (returns 404), skip this unit test
        return True
    # otherwise, do the regular test
    zdf = ZDFBaseIE()
    # first try with 'otv' channel

# Generated at 2022-06-24 13:51:47.903136
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    extractor = ZDFIE()
    assert extractor.ie_key() == 'ZDF'
    assert extractor.ie_key() == ZDFIE.ie_key()


# Generated at 2022-06-24 13:51:50.928605
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE('ZDFIE', 'zdfde')
    zdf_ie.report_warning = lambda *args, **kwargs: None
    zdf_ie.add_default_format_to_url = lambda *args, **kwargs: None
    return zdf_ie


# Generated at 2022-06-24 13:51:54.934052
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/'
    cls = update_url_query(ZDFChannelIE.suitable, {'force': True})
    assert cls(url) == False
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    assert cls(url) == True



# Generated at 2022-06-24 13:52:00.140551
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # two cases for testing
    test_case_1 = {
        'url': 'https://www.zdf.de/comedy/praxis-b%C3%BClowbogen/video/clip-neue-wege-b%C3%BClowbogen-zwei-kommt-nie-allein-29393312',
        'only_matching': True,
    }
    test_case_2 = {
        'url': 'https://www.zdf.de/serien/das-traumschiff/folgen/das-traumschiff-folge-66-30990092',
        'only_matching': True,
    }
    # creating object from class ZDFBaseIE
    obj = ZDFBaseIE()
    # testing 1st case
    assert obj._WORK

# Generated at 2022-06-24 13:52:00.865459
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

# Generated at 2022-06-24 13:52:02.427549
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    p = ZDFBaseIE()
    assert p != None


# Generated at 2022-06-24 13:52:06.514826
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE._GEO_COUNTRIES = ['DE']
    ZDFBaseIE._QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    ZDFBaseIE._call_api('zdf_url', 'tkDdG0Ws', 'item')
    ZDFBaseIE._extract_subtitles({})
    ZDFBaseIE._extract_ptmd('ptmd_url', 'tkDdG0Ws', 'api_token', 'referrer')
    ZDFBaseIE._extract_player('webpage', 'tkDdG0Ws')


# Generated at 2022-06-24 13:52:16.486215
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    import concurrent.futures
    import time

    start = time.perf_counter()

    executor = concurrent.futures.ThreadPoolExecutor()

    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    pattern = re.compile(r'https://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html',
                         re.IGNORECASE | re.VERBOSE)

    matches = pattern.match(url)
    if matches is None:
        return

    groups = matches.groupdict()
    video_id = groups['id']

    ie = ZDFIE()
    ie

# Generated at 2022-06-24 13:52:19.742247
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    print("Qualities: " + str(zdf._QUALITIES))
    print("Geo Countries: " + str(zdf._GEO_COUNTRIES))


# Generated at 2022-06-24 13:52:21.901489
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE()
    # assert that no error is raised
    assert z is not None



# Generated at 2022-06-24 13:52:25.801850
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen'
    obj = ZDFChannelIE()
    assert obj._VALID_URL == url


# Generated at 2022-06-24 13:52:27.762029
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:52:31.452617
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test that constructor throws an exception
    with pytest.raises(TypeError):
        # These statements should fail
        type(None)('https://www.zdf.de/dokumentation/planet-e', zdf=None)
        ZDFChannelIE(None)

# Generated at 2022-06-24 13:52:40.936772
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE().suitable('https://www.zdf.de/dokumentation/planet-e')
    assert ZDFChannelIE().suitable('https://www.zdf.de/dokumentation/planet-e') == False
    assert ZDFChannelIE().suitable('https://www.zdf.de/dokumentation/planet-e/') == False
    assert ZDFChannelIE().suitable('https://www.zdf.de/dokumentation/planet-e/test') == False
    assert ZDFChannelIE().suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == False
    assert ZDFChannelIE().suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio/')

# Generated at 2022-06-24 13:52:52.846449
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # exercise constructor of class ZDFChannelIE
    ie = ZDFChannelIE()
    assert ie.name == 'zdf.de:channel'
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.description == 'ZDF Mediathek'
    assert ie.extractor_key == ZDFChannelIE.ie_key()
    assert ie.formats == ('bestvideo', 'bestaudio')
    assert ie.thumbnails == False
    assert ie.compat_list() == [
        'ZDFChannel_Live',
        'ZDFChannel',
    ]
    assert ie.can_extract_url(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio')

# Generated at 2022-06-24 13:52:57.866329
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_class = ZDFIE('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert test_class.GEO_COUNTRIES == ['DE']
    assert test_class.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:53:04.486654
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    import unittest

    _QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    class TestZDFIE(unittest.TestCase):
        def test_constructor(self):
            ie = ZDFIE()

            self.assertEqual(ie._GEO_COUNTRIES, ['DE'])
            self.assertEqual(ie._QUALITIES, _QUALITIES)

    unittest.main(argv=['first-arg-is-ignored'], exit=False)



# Generated at 2022-06-24 13:53:05.774129
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE()
    zdfChannelIE._real_extract("https://www.zdf.de/dokumentation/planet-e")

# Generated at 2022-06-24 13:53:07.190607
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # assert that instantiating the class is possible
    test = ZDFChannelIE()
    # assert that _real_extract is not None
    assert test._real_extract is not None

# Generated at 2022-06-24 13:53:08.189079
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:53:19.814804
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdfIE._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert zdfIE._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'

# Generated at 2022-06-24 13:53:22.995989
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:53:25.137222
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    inst = ZDFChannelIE()
    assert inst.suitable(inst._VALID_URL)
    assert inst.suitable(ZDFIE()._VALID_URL) == False
    assert inst._VALID_URL != ZDFIE()._VALID_URL


# Generated at 2022-06-24 13:53:28.968907
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Test for constructor of class ZDFBaseIE
    """
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:53:33.366854
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """Unit test for constructor of class ZDFIE"""
    from .test_download import test_download
    test_download(ZDFIE().ie_key(), 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html', 'test_zdfie.mp4')

# Generated at 2022-06-24 13:53:45.478157
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    _GEO_COUNTRIES = ['DE']
    _QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:53:47.661213
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('ZDFBaseIE')


# Generated at 2022-06-24 13:53:53.857360
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/100.html')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert not ZDFChannelIE._VALID_URL.match('https://www.zdf.de/filme/taunuskrimi/100.html')

# Generated at 2022-06-24 13:54:00.221520
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    t = ZDFChannelIE('https://www.zdf.de/sport/')
    assert t._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert isinstance(t, ZDFChannelIE)
    

# Generated at 2022-06-24 13:54:10.438132
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:54:13.097916
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None)
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:54:18.205210
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Same as https://www.zdf.de/tatort/tatort-uebersicht-100.html
    url = "https://www.zdf.de/tatort"
    url_channel = ZDFChannelIE._build_url(url, "tatort")
    assert url_channel == "https://www.zdf.de/tatort/tatort-uebersicht-100.html"

    # Same as https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html
    url = "https://www.zdf.de/dokumentation/planet-e"
    url_channel = ZDFChannelIE._build_url(url, "planet-e")

# Generated at 2022-06-24 13:54:30.050574
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class TestZDFBaseIE(ZDFBaseIE):
        _VALID_URL = r'https?://(?:www\.)?zdf\.de/[^/]+/(?P<id>[^/]+)/'

# Generated at 2022-06-24 13:54:31.419446
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:54:37.323953
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE()
    assert zdf_base._GEO_COUNTRIES == ['DE']
    assert zdf_base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:44.618324
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import doctest
    doctest.testmod()
# Test ZDFChannelIE
# print(ZDFChannelIE()._real_extract('https://www.zdf.de/dokumentation/planet-e'))
# Test ZDFIE
# print(ZDFIE()._real_extract('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html'))
# print(ZDFIE()._real_extract('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'))
# print(ZDFIE()._real_extract('https://www.zdf

# Generated at 2022-06-24 13:54:54.975319
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'

# Generated at 2022-06-24 13:55:00.318662
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    print(ie._call_api('url', 'video_id', 'item'))
    assert(ie._extract_subtitles('something') == {})
    assert(ie._extract_ptmd('url', 'video_id', 'api_token', 'referrer'))
    assert(ie._extract_player('webpage', 'video_id', fatal=True))


# Generated at 2022-06-24 13:55:07.902829
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    # Test 1: Get suitable status, since ZDFIE is not suitable for above url
    assert ZDFChannelIE.suitable(url)
    # Test 2: Test url_result from class ZDFChannelIE
    assert ZDFIE().url_result(url, ie=ZDFIE.ie_key()).url == 'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'
    # Test 3: Test playlist_result from class ZDFChannelIE

# Generated at 2022-06-24 13:55:12.164437
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE("")
    except ValueError as e:
        assert 'ZDFBaseIE() takes at most 2 positional arguments (3 given)' == str(e)

# Test if dict_to_str() can convert a dict to str

# Generated at 2022-06-24 13:55:15.125255
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:55:22.686081
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_ie = ZDFChannelIE()
    assert channel_ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-4---ein-taunuskrimi-100.html')
    assert channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-24 13:55:27.745541
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE()
    channel.suitable("https://www.zdf.de/dokumentation/planet-e")
    channel.suitable("https://www.zdf.de/dokumentation/planet-e.html")
    channel.suitable("https://www.zdf.de/dokumentation/planet-e.html?query")
    channel.suitable("https://www.zdf.de/dokumentation/planet-e.json?query")



# Generated at 2022-06-24 13:55:33.615250
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE()
    zdfChannelIE.suitable(None)
    zdfChannelIE.suitable('')
    zdfChannelIE.suitable('https://www.zdf.de/politik/frontal-21/frontal-21-vom-21-01-2020-100.html')
    zdfChannelIE.suitable('https://www.zdf.de/kultur/aspekte/aspekte-vom-10-maerz-2020-100.html')

# Generated at 2022-06-24 13:55:38.222579
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(InfoExtractor())
    assert ie._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-24 13:55:38.956309
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE() != None



# Generated at 2022-06-24 13:55:51.607766
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import sys
    import logging
    logging.basicConfig(stream=sys.stdout)
    logging.getLogger('youtube_dl').setLevel(logging.DEBUG)

    zdf_ie = ZDFChannelIE()

    obj_urls = [
        "https://www.zdf.de/sport/das-aktuelle-sportstudio",
        "https://www.zdf.de/dokumentation/planet-e",
        "https://www.zdf.de/serien/markus-lanz/markus-lanz-vom-28-juni-2017-100.html",
        "https://www.zdf.de/serien/markus-lanz/markus-lanz-vom-28-juni-2017-100.html"
    ]


# Generated at 2022-06-24 13:55:54.761315
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        print(ZDFBaseIE)
        assert True
    except Exception as ex:
        print(ex.args)
        assert False

# Run all test
test_ZDFBaseIE()



# Generated at 2022-06-24 13:55:57.295811
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE')
    assert ie
    assert ie._GEO_COUNTRIES == ['DE']



# Generated at 2022-06-24 13:56:04.319708
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html', "ZDFIE._VALID_URL changed"
    assert ie._GEO_COUNTRIES == ['DE'], "ZDFIE._GEO_COUNTRIES changed"
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'), "ZDFIE._QUALITIES changed"


# Generated at 2022-06-24 13:56:09.071015
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE(InfoExtractor())
    except TypeError:
        pass
    else:
        raise Exception(
            'Unit test for constructor of class ZDFBaseIE should fail.')

# Unit tests for method _call_api in class ZDFBaseIE

# Generated at 2022-06-24 13:56:10.414215
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFIE()
    except Exception:
        assert False, 'constructor of class ZDFIE failed'

# Generated at 2022-06-24 13:56:12.678360
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(ZDFIE.ie_key(), ZDFIE._VALID_URL)


# Generated at 2022-06-24 13:56:16.545675
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:20.495319
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:27.470154
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE('zdf://')
    assert zdfie.extractor_key() == ZDFIE.ie_key()
    assert zdfie._VALID_URL == ZDFIE._VALID_URL
    assert zdfie._TESTS == ZDFIE._TESTS



# Generated at 2022-06-24 13:56:31.920056
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    # When
    ie.class_type_extractor_by_ie['ZDFBaseIE'] = ZDFBaseIE
    # Then
    assert ie.class_type_extractor_by_ie == {'ZDFBaseIE': ZDFBaseIE}


# Generated at 2022-06-24 13:56:33.463202
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    obj = ZDFIE()
    print(obj)


# Generated at 2022-06-24 13:56:39.688022
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from ..utils import str_to_int

    assert ZDFBaseIE.ie_key() == 'zdf'
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    assert callable(ZDFBaseIE._call_api)
    assert callable(ZDFBaseIE._extract_subtitles)
    assert callable(ZDFBaseIE._extract_format)
    assert callable(ZDFBaseIE._extract_ptmd)
    assert callable(ZDFBaseIE._extract_player)

    ie = ZDFBaseIE()
    assert ie.params['geo_bypass']

# Generated at 2022-06-24 13:56:40.407625
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert repr(ZDFBaseIE())


# Generated at 2022-06-24 13:56:52.004792
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_class = ZDFChannelIE(None)
    if test_class.__class__ == ZDFChannelIE:
        print('Succesfully created instance of class ZDFChannelIE')

    if test_class.ie_key() == 'ZDFChannel':
        print('Succesfully tested ZDFChannelIE.ie_key()')

    if (test_class.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True and
        test_class.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html') == False):
        print('Succesfully tested ZDFChannelIE.suitable()')

# Generated at 2022-06-24 13:56:54.626456
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE.ie_key()
    assert zdf_ie is not None
    assert type(zdf_ie) is str


# Generated at 2022-06-24 13:56:57.418318
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.info()
    assert('ZDFIE' == ie._VALID_URL)
    assert(set(ie._TESTS) > set(ZDFIE()))


# Generated at 2022-06-24 13:57:01.607094
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    constants.testSet = {ZDFChannelIE.ie_key(): ZDFChannelIE}
    print('test_ZDFChannelIE: %s' % ZDFChannelIE.ie_key())


# Generated at 2022-06-24 13:57:13.024075
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html')
    assert ie.suitable('https://www.zdf.de/dokumentation/one-eins-thema/bilderserie-ein-schoepferisches-phantom-100.html')

# Generated at 2022-06-24 13:57:14.688733
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    t = ZDFBaseIE()
    assert t is not None
    test_ZDFBaseIE()



# Generated at 2022-06-24 13:57:24.570741
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:57:34.502007
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z = ZDFChannelIE()
    z.ie_key() # Without this, the assertions below fail.
    assert z.ie_key() != ZDFIE.ie_key()
    assert z.ie_key() == 'ZDFChannel'
    assert z.SUITABLE_UNKNOWN_CASE == -1
    assert z.LOGIN_URL == 'https://passport.zdf.de/sso'
    assert z.TOKEN_URL == 'https://www.zdf.de/zdfportal/blob/zdf/token'
    assert z.QUALITIES == ZDFIE.QUALITIES
    assert z.BRIGHTCOVE_URL_TEMPLATE == ZDFIE.BRIGHTCOVE_URL_TEMPLATE
    assert z.CLIENT_HEADERS == ZDFIE.CLIENT

# Generated at 2022-06-24 13:57:36.419010
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    '''
    Constructor of the class works.
    '''
    ie = ZDFBaseIE()


# Generated at 2022-06-24 13:57:39.238081
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:57:44.445087
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    global_params = {'global_param': 'global_value'}
    allowed_formats = ['mp4v', 'mp4a']
    instance = ZDFIE(global_params, allowed_formats)
    assert(instance.global_params == global_params)
    assert(instance.allowed_formats == allowed_formats)
    return

# Generated at 2022-06-24 13:57:54.544502
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:58:03.273602
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Test the constructor of class ZDFChannelIE"""
    ie = ZDFChannelIE("https://www.zdf.de/dokumentation/planet-e")
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == "https://www.zdf.de/dokumentation/planet-e"
    assert ie._TESTS[1]['url'] == "https://www.zdf.de/filme/taunuskrimi/"
    assert ie._TESTS[0]['playlist_mincount'] == 50

# Unit tests for class ZDFIE

# Generated at 2022-06-24 13:58:11.808015
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-24 13:58:18.897740
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.name == 'ZDF'
    assert zdfie.ie_key() == 'ZDF'
    assert zdfie.ie_key() == 'ZDFMediathek'
    assert zdfie.ie_key() == '3SatMediathek'
    assert zdfie.ie_key() == 'PHOENIXMediathek'



# Generated at 2022-06-24 13:58:24.079281
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    i = ZDFChannelIE("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    assert isinstance(i, ZDFChannelIE)
    assert (i.playlist_mincount == 23)
    assert (i.protocol == 'https')


# Generated at 2022-06-24 13:58:29.654338
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    expected_GEO_COUNTRIES = ['DE']
    expected_QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    assert instance._GEO_COUNTRIES == expected_GEO_COUNTRIES
    assert instance._QUALITIES == expected_QUALITIES


# Generated at 2022-06-24 13:58:41.326783
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = common_get('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 13:58:42.524556
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-24 13:58:44.357397
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zie = ZDFBaseIE()
    assert zie is not None



# Generated at 2022-06-24 13:58:55.136221
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Try to extract video entries with forbidden georestriction
    playlist = ZDFBaseIE._extract_playlist('https://www.zdf.de/serien/die-anstalt/video-die-anstalt-wie-sind-sie-so-als-deutsche-17.html', '17')
    assert len(playlist) == 0
    # Try to extract video entries with allowed georestriction
    playlist = ZDFBaseIE._extract_playlist('https://www.zdf.de/serien/die-anstalt/video-die-anstalt-wie-sind-sie-so-als-deutsche-17.html', '17', 'DE')
    assert len(playlist) > 0


# Generated at 2022-06-24 13:58:58.948742
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    # FIXME: the download URLs have changed and need to be updated
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:59:05.451084
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .zdf import ZDFIE
    t = ZDFBaseIE(ZDFIE())
    t._call_api("", "", "", None, None)
    t._extract_subtitles("")
    t._extract_format("", None, None, None)
    t._extract_ptmd("", "", None, None)
    t._extract_player("", "")


# Generated at 2022-06-24 13:59:06.669081
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:59:17.316524
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test constructor of class ZDFIE
    # with correct input
    test_ZDFIE = ZDFIE.__new__(ZDFIE)
    print('test: ZDFIE __init__() with correct input')
    print('Result: ', test_ZDFIE)
    # Test constructor of class ZDFIE
    # with wrong input
    print('test: ZDFIE __init__() with wrong input')
    try:
        test_ZDFIE = ZDFIE.__new__(object)
        print('Result: ', test_ZDFIE)

    except Exception:
        print('Exception: ', Exception)

if __name__ == "__main__":
    test_ZDFIE()

# Generated at 2022-06-24 13:59:21.769622
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Unit tests for method _extract_subtitles

# Generated at 2022-06-24 13:59:29.950499
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.downloader import ZDFChannelIE
    zdfChannelIE = ZDFChannelIE()
    assert zdfChannelIE, 'zdfChannelIE is empty'
    assert zdfChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e'), 'Failed to test URL https://www.zdf.de/dokumentation/planet-e'

# Generated at 2022-06-24 13:59:35.062857
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.IE_NAME == 'ZDF'
    assert ie.IE_DESC == 'Zweites Deutsches Fernsehen'

# Generated at 2022-06-24 13:59:38.804865
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base = ZDFBaseIE()
    assert base._call_api ('', '', '')
    assert base._extract_subtitles({}) == {}
    assert base._extract_player('', '') == {}


# Generated at 2022-06-24 13:59:46.258645
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Call __init__ to make sure that parameters get set.
    ie = ZDFIE()
    ie._download_webpage(
          'https://www.zdf.de/'
        + 'politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
        , '210222_phx_nachgehakt_corona_protest')


# Generated at 2022-06-24 13:59:48.216314
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:59:54.874248
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie=ZDFIE()
    assert zdfie is not None
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 14:00:01.159482
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None)
    assert ie.name == 'ZDF'