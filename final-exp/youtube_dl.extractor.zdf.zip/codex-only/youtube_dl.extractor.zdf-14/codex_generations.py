

# Generated at 2022-06-24 13:50:04.275395
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:50:07.809416
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('https://example.com/index.html', '123')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:09.860709
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE("ZDFBaseIE")
    assert zdf_base_ie



# Generated at 2022-06-24 13:50:14.011094
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    my_object = ZDFBaseIE()
    assert my_object._GEO_COUNTRIES == ['DE']
    assert my_object._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:18.047412
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Unit test for constructor of class ZDFChannelIE
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert ZDFChannelIE.suitable(url) is False

# Generated at 2022-06-24 13:50:26.646108
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # This unit test checks if the class is properly constructed and works in the simplest case
    url = 'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
    zdf = ZDFIE()
    zdf._download_webpage = lambda *args: '{}'
    zdf._parse_json = lambda *args: {'content': {}, 'player': {}}
    info = zdf._real_extract(url)
    assert info['id'] == '151025_magie_farben2_tex'



# Generated at 2022-06-24 13:50:30.215972
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():

    assert ZDFBaseIE._call_api('www.zdf.de/api/video', '12345', 'video')
    assert ZDFBaseIE._extract_subtitles({'captions': 'captions'}) is None
    assert ZDFBaseIE._extract_format('12345', [], set(), {'url': 'www.zdf.de'}) is None

# Generated at 2022-06-24 13:50:39.649578
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """Unit test for constructor of class ZDFIE"""
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:50:50.395462
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    a = ZDFIE()
    assert a._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:50:52.270275
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    _zdfIE = ZDFIE()
    _zdfIE._VALID_URL
    _zdfIE._TESTS



# Generated at 2022-06-24 13:51:02.213336
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-24 13:51:04.392808
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z = ZDFChannelIE('www.zdf.de')
    print(z)



# Generated at 2022-06-24 13:51:06.604629
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:51:13.852754
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info = ZDFBaseIE()._call_api("https://api.zdf.de/tmd/2/ngplayer_2_3/vod/ptmd/mediathek/filter/basename/video-bilanz-2018-09-25-ticker,f4v", "video-bilanz-2018-09-25-ticker", "metadata")

    assert('title' in info)
    assert(info['title'] == "video-bilanz-2018-09-25-ticker")

    assert(info['basename'] == "video-bilanz-2018-09-25-ticker")


# Generated at 2022-06-24 13:51:20.724499
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test = ZDFBaseIE()
    assert isinstance(test, ZDFBaseIE)
    assert ZDFBaseIE.ie_key() == "zdf"
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:51:24.614965
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert isinstance(ie, InfoExtractor)

# TODO: exclude zdf: remove when zdf extractor is removed

# Generated at 2022-06-24 13:51:27.308861
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    IE = ZDFIE()
    assert(IE.ie_key() == 'ZDF')


# Generated at 2022-06-24 13:51:28.306607
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:51:29.666191
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE("http://example.com") != None


# Generated at 2022-06-24 13:51:33.551377
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie_metaclass = type("ZDFIE", (ZDFIE, object), {})
    zdfie_instance = zdfie_metaclass()
    zdfie_instance.extract("https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html")

test_ZDFIE()


# Generated at 2022-06-24 13:51:39.472637
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    IE = ZDFBaseIE()
    assert isinstance(IE, InfoExtractor)
    assert IE._GEO_COUNTRIES == ['DE']
    assert IE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:43.766263
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:47.335745
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfie = ZDFBaseIE()
    assert zdfie
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:49.031005
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('ZDFBaseIE', 'DE')


# Generated at 2022-06-24 13:51:52.201738
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:55.118961
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/', {
        'show': ZDFIE,
        'episode': ZDFIE,
        'clip': ZDFIE,
        'live': ZDFIE,
    })

# Generated at 2022-06-24 13:51:56.572446
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test for constructor of class ZDFBaseIE
    pass


# Generated at 2022-06-24 13:51:59.546354
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Successful test of constructor
    assert ZDFIE is not None

# GIVEN:  Illegal URL

# Generated at 2022-06-24 13:52:04.975920
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-24 13:52:09.044982
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class_ = ZDFChannelIE
    # The URL should be ZDFChannelIE type
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert class_.suitable(url)
    assert class_(url)


# Generated at 2022-06-24 13:52:13.539424
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    #
    # Test case 1
    #
    ZDFIE(mock.Mock(), 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')


# Generated at 2022-06-24 13:52:17.924627
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.GEO_COUNTRIES == ['DE']
    assert ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Test for function _call_api
from .test_ZDFIE import ZDFIE

# Generated at 2022-06-24 13:52:19.349445
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:52:21.416492
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    processor = ZDFIE()
    assert processor.ie_key() == 'zdf'


# Generated at 2022-06-24 13:52:25.361644
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen'
    ZDFChannelIE(url)._real_extract(url)

# Generated at 2022-06-24 13:52:29.409878
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    _ZDFBaseIE = ZDFBaseIE()
    assert _ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert _ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:52:34.173613
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')
    assert not ie.suitable('https://www.zdf.de/dokumentation/planet-e/schutz-vor-strahlung-100.html')


# Generated at 2022-06-24 13:52:34.635701
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()

# Generated at 2022-06-24 13:52:35.658607
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()



# Generated at 2022-06-24 13:52:40.468720
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE("http://www.zdf.de/ZDFmediathek/beitrag/video/2227226/Das-kleine-Kino-im-Ersten#/beitrag/video/2227226/Das-kleine-Kino-im-Ersten", "", "")
    assert ie != None, 'Should not be None'


# Generated at 2022-06-24 13:52:42.899674
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    class_ZDFIE = ZDFIE()
    assert class_ZDFIE



# Generated at 2022-06-24 13:52:44.031184
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE()

# Generated at 2022-06-24 13:52:46.916505
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """Unit test constructor of class ZDFIE"""
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'zdf'

# Generated at 2022-06-24 13:52:48.104193
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()



# Generated at 2022-06-24 13:52:56.678897
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Fixture.
    # Three possible class candidates ZDFBaseIE, ZDFIE, ZDFChannelIE should
    # all instantiate.
    for url in ('https://www.zdf.de/dokumentation/planet-e',
                'https://www.zdf.de/sport/das-aktuelle-sportstudio',
                'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'
               ):
        cls, ie_key = _get_info_extractor(url)
        assert cls is not None
        assert issubclass(cls, InfoExtractor)
        cls()
        # Test that the same instance is returned, ie. that

# Generated at 2022-06-24 13:52:58.909503
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    a = ZDFBaseIE("http://www.tv.com/movies/a/01")
    assert a._GEO_COUNTRIES == ['DE']
    assert a._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:53:03.202777
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    # _QUALITIES:
    formats = ie._QUALITIES
    assert formats == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'), 'Checking format list of class ZDFBaseIE'


# Generated at 2022-06-24 13:53:05.813927
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie != '', 'ZDFIE failed to load'


# Generated at 2022-06-24 13:53:09.547264
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    e = ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert e == True
    e = ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert e == False
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') == False



# Generated at 2022-06-24 13:53:16.136774
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == "zdf"
    assert ie.ie_key() in InfoExtractor._ALL_CLASSES
    assert ie.ie_key() in ZDFIE._ALL_CLASSES
    assert ie.ie_key() in ZDFIE.ie_key()



# Generated at 2022-06-24 13:53:17.985607
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(InfoExtractor())
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:53:18.539663
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-24 13:53:20.689073
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert type(ie) == ZDFChannelIE


# Generated at 2022-06-24 13:53:24.313485
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE()
    z._VALID_URL = 'https://www.zdf.de/xxx/xxx'
    z.extract('https://www.zdf.de/xxx/xxx')

# Function to test by invoking from command line

# Generated at 2022-06-24 13:53:26.409161
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-24 13:53:34.907723
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:53:39.089609
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id='37575944'
    return ZDFBaseIE._call_api('https://zdfmeta.cdn.c3d2.de/conf/zdf/player/video/ptmd/'+video_id+'.json', video_id, 'ptmd')



# Generated at 2022-06-24 13:53:41.843043
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()



# Generated at 2022-06-24 13:53:52.725395
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert(ie.is_valid_url('https://www.zdf.de/filme/nuhr-im-ersten/nuhr-im-ersten-die-michl-mueller-show-folge-12-100.html'))
    assert(not ie.is_valid_url('https://www.youtube.com/watch?v=oHg5SJYRHA0'))
    assert(ie.is_valid_url('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html'))



# Generated at 2022-06-24 13:53:54.307309
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:54:06.984556
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfc = ZDFChannelIE()
    zdfi = ZDFIE()
    regex = r'data-plusbar-url=["\'](http.+?\.html)';
    url = 'https://www.zdf.de/dokumentation/planet-e'
    html = zdfi.downloader.get(url).text
    urls = re.findall(regex, html)
    playlist = zdfc._real_extract(url)
    for i in playlist['entries']:
        assert i['_type'] == 'url'
        assert i['url'] in urls
    assert playlist['id'] == 'planet-e'
    urls = []
    for url in urls:
        html = zdfi.downloader.get(url).text
        old_urls = re.find

# Generated at 2022-06-24 13:54:08.851635
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:54:12.571846
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    f = globals()['ZDFChannelIE'].suitable
    assert not f('https://www.zdf.de/politik/frontal-21/frontal-21-donnerstag-100.html')
    assert f('https://www.zdf.de/politik/frontal-21')

# Generated at 2022-06-24 13:54:17.670909
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    with pytest.raises(ExtractorError) as excinfo:
        ZDFChannelIE.suitable(url)
    assert 'ZDF' in str(excinfo.value)

# Generated at 2022-06-24 13:54:26.563742
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import io
    import json
    from collections import OrderedDict

    # Load webpage without a player
    webpage = io.open(
        'test/testdata/channel1.html', 'r', encoding='utf8').read()

    # Load webpage with a player
    webpage2 = io.open(
        'test/testdata/channel2.html', 'r', encoding='utf8').read()

    channel_id = 'das-aktuelle-sportstudio'

    # Unpack constructor parameters
    v = ZDFChannelIE._parse_json(
        ZDFChannelIE._search_regex(
            r'data-zdfplayer-jsb=(["\'])(?P<json>{.+?})\1',
            webpage2, 'player JSON', group='json'), channel_id)

    # Prepare objects

# Generated at 2022-06-24 13:54:32.555197
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert_true(ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e'))
    assert_true(ZDFChannelIE.suitable('https://www.zdf.de/politik/frontal-21'))
    assert_false(ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'))
    assert_false(ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio/100.html'))

# Generated at 2022-06-24 13:54:39.881821
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test = ZDFChannelIE().suitable
    assert test('https://www.zdf.de/dokumentation/planet-e')
    assert test('https://www.zdf.de/dokumentation/planet-e/')
    assert test('https://www.zdf.de/dokumentation/planet-e.html')
    assert test('https://www.zdf.de/filme/taunuskrimi')
    assert test('https://www.zdf.de/filme/taunuskrimi/')
    assert test('https://www.zdf.de/filme/taunuskrimi.html')

# Generated at 2022-06-24 13:54:40.565389
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:54:43.301850
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z = ZDFChannelIE()
    assert z.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')



# Generated at 2022-06-24 13:54:44.302316
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:54:54.620073
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # check the valid_url() function of the class ZDFIE
    assert (ZDFIE._VALID_URL == '(?P<id>.+)')

    # check the constructor of the class ZDFIE
    ZDFIE_test = ZDFIE('test')

    # Check that the class ZDFIE can be instantiated
    assert isinstance(ZDFIE_test, ZDFIE)

    # Check the value of the member variable _TESTS from the class ZDFIE
    assert len(ZDFIE._TESTS) == 10

    # Check a match to the regular expression for the member variable _VALID_URL
    # of the class ZDFIE

# Generated at 2022-06-24 13:55:02.922423
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url_types = [
        "https://www.zdf.de/dokumentation/planet-e",
        "https://www.zdf.de/politik/phoenix-sendungen",
        "https://www.zdf.de/nachrichten/"
    ]

    for url in url_types:
        print("\n")
        for ie_class in gen_extractors(ZDFChannelIE):
            print(repr(ie_class.suitable(url)))
            assert ie_class.suitable(url) == True
        print("\n")

    print(ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e'))



# Generated at 2022-06-24 13:55:07.583307
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDF_URL = 'https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html'

    zdf_IE = ZDFIE()

    zdf_IE._match_id(ZDF_URL)
    zdf_IE._real_extract(ZDF_URL)
    zdf_IE._extract_mobile(ZDFIE._match_id(ZDF_URL))
    zdf_IE.ie_key()


# Generated at 2022-06-24 13:55:12.301974
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    s = ZDFBaseIE()
    assert type(s) == ZDFBaseIE
    assert s._GEO_COUNTRIES == ['DE']
    assert s._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:21.946836
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        from pycaption import DFXPReader
    except ImportError:
        DFXPReader = None

    valid_url = 'http://www.zdf.de/ZDFmediathek#/beitrag/video/2087148/ZDF-Morgenmagazin-vom-2.-M%C3%A4rz-2016-13-00-Uhr'
    valid_url2 = 'http://www.zdf.de/ZDFmediathek/beitrag/video/2904766/Heute-Nachrichten#/beitrag/video/2904766/Heute-Nachrichten'

# Generated at 2022-06-24 13:55:23.366846
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()

# Generated at 2022-06-24 13:55:25.409293
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE("https://www.zdf.de/dokumentation/planet-e").ie_key() == "ZDFChannel"


# Generated at 2022-06-24 13:55:27.959533
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.geo_countries == ['DE']
    assert ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:55:37.515802
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    t = ZDFChannelIE()
    assert t.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert t.suitable('https://www.zdf.de/politik/phoenix-sendungen/')
    assert t.suitable('https://www.zdf.de/')
    assert t.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not t.suitable('https://www.zdf.de/')


# Generated at 2022-06-24 13:55:38.538230
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert isinstance(ZDFIE(), ZDFBaseIE);
# test_ZDFIE()

# Generated at 2022-06-24 13:55:46.955748
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import main
    with main.get_test_result_path('zdf_channel.json') as path:
        with open(path, 'rb') as f:
            webpage = f.read()
    zdf_channel = ZDFChannelIE()
    player = zdf_channel._extract_player(webpage, 'das-aktuelle-sportstudio')
    channel_id = zdf_channel._search_regex(
            r'docId\s*:\s*(["\'])(?P<id>(?!\1).+?)\1', webpage,
            'channel id', group='id')

# Generated at 2022-06-24 13:55:49.502779
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE(None)
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Testing _call_api method of class ZDFBaseIE

# Generated at 2022-06-24 13:55:59.609186
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    import unittest
    import re

    class TestZDFIE(unittest.TestCase):
        def setUp(self):
            self._media_id = '210222_phx_nachgehakt_corona_protest'
            self._url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'

        def test_global_variables(self):
            self.assertRegex(ZDFIE._VALID_URL, re.compile(r'^https?://(?:www\.)?zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html$'))

# Generated at 2022-06-24 13:56:08.934542
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    #
    # Test _extract_subtitles
    assert ie._extract_subtitles({}) == {}
    assert ie._extract_subtitles({'captions': [{'uri': '/foo/bar.vtt'}]}) == {
        'deu': [{'url': 'https://zdf.de/foo/bar.vtt'},]
    }
    #
    # Test _extract_format
    formats = []
    format_urls = orderedSet()

# Generated at 2022-06-24 13:56:16.515305
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # A valid url is a parameter
    zdfie = ZDFIE("https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html")
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:56:21.233663
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbaseIE = ZDFBaseIE('ZDFBaseIE', 'zdf.de')
    assert zdfbaseIE._GEO_COUNTRIES == ['DE']
    assert zdfbaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:56:22.655598
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    o = ZDFBaseIE()
    assert o is not None



# Generated at 2022-06-24 13:56:28.049452
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:34.614429
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    URL = "https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html"
    GEO_COUNTRIES = ['DE']
    QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    VALID_URL = r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:56:38.037126
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    obj = ZDFChannelIE(url)
    obj._real_extract(url)

# Generated at 2022-06-24 13:56:40.786337
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

# Test checking ZDFBaseIE class. Check that apitoken is correctly added to _call_api method.

# Generated at 2022-06-24 13:56:50.673805
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE()
    assert channel.suitable(None) == False

    url = 'https://www.zdf.de/dokumentation/planet-e'
    result = channel.suitable(url)
    assert result == True

    url = 'https://www.zdf.de/filme/taunuskrimi/'
    result = channel.suitable(url)
    assert result == True

    url = 'https://www.zdf.de/dokumentation/planet-e'
    result = ZDFChannelIE.suitable(url)
    assert result == True
# End of unit test for class ZDFChannelIE



# Generated at 2022-06-24 13:56:59.613762
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    t = ZDFIE()
    instance = t.ie_key()
    # Check if the result is correct
    assert t._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert t.__class__.__name__ == 'ZDFIE'

# Generated at 2022-06-24 13:57:04.741645
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    result = zdf._call_api('https://api.zdf.de/',
                           '7620f503-5d8e-4c08-9edc-6fd1cc6e6432', 'metadata', '', '')
    assert result


# Generated at 2022-06-24 13:57:15.367531
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdfIE._GEO_COUNTRIES == ['DE']
    assert zdfIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdfIE.ie_key() == 'ZDF'
    assert 'download_webpage' in dir(zdfIE)
    assert 'extract_m3u8_formats' in dir(zdfIE)
    assert 'parse_codecs' in dir(zdfIE)
    assert 'parse_webpage' in dir(zdfIE)

# Generated at 2022-06-24 13:57:20.693738
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannel = ZDFChannelIE()
    zdfchannel._VALID_URL = ZDFChannelIE._VALID_URL
    zdfchannel._TESTS = ZDFChannelIE._TESTS
    for _test in zdfchannel._TESTS:
        print('test_ZDFChannelIE: test %s' % _test)
        assert zdfchannel.suitable(_test['url'])
        zdfchannel.extract(_test['url'])



# Generated at 2022-06-24 13:57:25.400213
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert(zdfIE.geo_countries == ['DE'])
    assert(zdfIE.qualities == ['auto', 'low', 'med', 'high', 'veryhigh', 'hd'])


# Generated at 2022-06-24 13:57:28.668395
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdf._call_api
    assert zdf._extract_subtitles
    assert zdf._extract_format
    assert zdf._extract_ptmd
    assert zdf._extract_player


# Generated at 2022-06-24 13:57:35.060226
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFIE.ie_key()
    assert type(ie) == ZDFIE

if __name__ == '__main__':
    test_ZDFIE()
    from unittest.main import main
    main()

# Generated at 2022-06-24 13:57:43.077010
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    is_zdf = ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert is_zdf == True
    is_not_zdf = ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/vid-97b607d3-3eab-4516-9de1-2e7ebb5dc297.html')
    assert is_not_zdf == False



# Generated at 2022-06-24 13:57:45.612232
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor
    ZDFBaseIE('test', 'DE', ['DE'], ['auto', 'low', 'med', 'high', 'veryhigh', 'hd'])('test')


# Generated at 2022-06-24 13:57:47.097060
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
  ie = ZDFBaseIE()
  assert ie is not None

# Generated at 2022-06-24 13:57:56.780242
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/') == True
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e') == True
    assert ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e') == True
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e/') == True

# Generated at 2022-06-24 13:58:00.611615
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor of class ZDFBaseIE
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:58:02.529585
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()
    ZDFBaseIE()

# Generated at 2022-06-24 13:58:06.766645
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Create a fake url
    url = 'www.zdf.de/filme/taunuskrimi/'
    # Instantiate ZDFChannelIE
    zdfchannelIE = ZDFChannelIE()
    # Check the result of using method suitable
    assert zdfchannelIE.suitable(url) == True

# Generated at 2022-06-24 13:58:08.969797
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie is not None
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, ZDFBaseIE)


# Generated at 2022-06-24 13:58:09.873802
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass


# Generated at 2022-06-24 13:58:14.505400
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        print("Testing class ZDFIE")
        t = ZDFIE()
        assert t != None
        print("Testing class ZDFIE passed")
    except:
        print("Testing class ZDFIE failed")


# Generated at 2022-06-24 13:58:24.122425
# Unit test for constructor of class ZDFIE
def test_ZDFIE():

    url = 'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
    test_ZDFIE = ZDFIE()
    ZDFIE._download_webpage(url)
    ZDFIE._parse_json(ZDFIE.ZDFIE._search_regex(
                r'(?s)data-zdfplayer-jsb=(["\'])(?P<json>{.+?})\1', webpage,
                'player JSON', default='{}' if not fatal else NO_DEFAULT,
                group='json'), "sometext")
    ZDFIE._extract_player(webpage, url, fatal=False)

# Generated at 2022-06-24 13:58:27.369229
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE('zdf')
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:58:39.745972
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:58:43.891203
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.GEO_COUNTRIES == ['DE']
    assert zdfie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:58:45.271049
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert type(ZDFIE) == type



# Generated at 2022-06-24 13:58:47.374677
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie is not None



# Generated at 2022-06-24 13:58:52.383812
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Tests for ZDFChannelIE
    assert ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL)
    assert not ZDFChannelIE.suitable(ZDFIE._VALID_URL)
    assert ZDFChannelIE.ie_key() == 'ZDFChannel'



# Generated at 2022-06-24 13:59:01.856345
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # TODO: Remove class ZDFChannelIE, because ZDFIE can handle channel URL
    # and this class is no longer called.
    # Issue: https://github.com/rg3/youtube-dl/issues/19056
    import youtube_dl.utils
    import youtube_dl.extractor.zdf

    zdf_channel_ie = youtube_dl.extractor.zdf.ZDFChannelIE()
    assert zdf_channel_ie.extractor_key == 'ZDFChannel'
    assert zdf_channel_ie.IE_NAME == 'zdf:channel'
    assert zdf_channel_ie.SUITABLE == youtube_dl.utils.is_url('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert zdf_channel_ie.BASE

# Generated at 2022-06-24 13:59:02.970657
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    obj = ZDFIE()
    assert obj.__class__.__name__ == 'ZDFIE'

# Generated at 2022-06-24 13:59:07.583033
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase = ZDFBaseIE()
    assert isinstance(zdfbase, ZDFBaseIE)
    assert zdfbase._GEO_COUNTRIES == ['DE']
    assert zdfbase._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:59:10.753668
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE.ie_key() == "ZDF"
    assert zdfIE._GEO_COUNTRIES == ["DE"]


# Generated at 2022-06-24 13:59:11.830611
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()

# ------------------------------------------------------------------------------


# Generated at 2022-06-24 13:59:18.350151
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannel = ZDFChannelIE()
    zdfchannel.suitable('https://www.zdf.de/dokumentation/planet-e')
    zdfchannel.suitable('https://www.zdf.de/filme/taunuskrimi/')
    zdfchannel.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')



# Generated at 2022-06-24 13:59:27.479621
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:59:32.008192
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBase = ZDFBaseIE()
    assert(zdfBase)
    assert(zdfBase._GEO_COUNTRIES == ['DE'])
    assert(zdfBase._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-24 13:59:35.414968
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:59:36.427117
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-24 13:59:48.759112
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:59:50.197923
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Basic functionality
    ZDFBaseIE()
    # No exception raised


# Generated at 2022-06-24 13:59:59.899128
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL


# Generated at 2022-06-24 14:00:04.497303
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        # Instance without a valid URL
        zdfie = ZDFIE()
    except Exception as ex:
        assert type(ex) == ValueError
        assert str(ex) == "ZDFIE must be instantiated with a " \
                          "valid URL of http[s]://www.zdf.de/... format!"

