

# Generated at 2022-06-24 13:50:01.108853
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()



# Generated at 2022-06-24 13:50:05.257445
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases
    from youtube_dl.utils import ExtractorError

    for url in get_testcases(ZDFChannelIE):
        with pytest.raises(ExtractorError):
            ZDFChannelIE().suitable(url)

# Generated at 2022-06-24 13:50:16.153073
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdfIE._TESTS[0]['info_dict']['id'] == '210222_phx_nachgehakt_corona_protest'
    assert zdfIE._TESTS[0]['info_dict']['title'] == 'Wohin führt der Protest in der Pandemie?'
    assert zdfIE._TESTS[0]['info_dict']['upload_date'] == '20210221'

# Generated at 2022-06-24 13:50:26.239530
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:50:29.767368
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z = ZDFBaseIE()
    z._extract_format('', [], set(), {})
    z._extract_ptmd('', '', '', '')

# Generated at 2022-06-24 13:50:31.729300
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('http://zdf.de/test', 'http://zdf.de/test_video')
    assert ie is not None


# Generated at 2022-06-24 13:50:39.380560
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_cases = [
        'https://www.zdf.de/filme/traumfabrik/traumfabrik-episode-7-105.html',
        'https://www.zdf.de/dokumentation/terra-x/terra-x-uebersichtsseite-weitere-folgen-von-terra-x-100.html',
    ]
    for url in test_cases:
        ie = ZDFIE(url)

# Generated at 2022-06-24 13:50:44.584982
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = 'http://www.zdf.de/ZDFmediathek/hauptnavigation/startseite#/beitrag/video/2145232/ZDF-Morgenmagazin'
    obj = ZDFBaseIE()
    data = obj._call_api(url, None, None)
    assert data is not None


# Generated at 2022-06-24 13:50:46.479430
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Tests if the class can be initialized and returns a ZDFChannelIE object
    ZDFChannelIE()

# Generated at 2022-06-24 13:50:53.376460
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    vid = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    vdata = ie.extract(vid)
    assert vdata['title'] == 'Die Magie der Farben (2/2)'
    assert vdata['duration'] == 2615



# Generated at 2022-06-24 13:51:00.195139
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e') is True
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/') is True
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') is False


# Generated at 2022-06-24 13:51:04.658400
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Generate a playlist.
    """
    playlist = ZDFChannelIE()._real_extract(
        "https://www.zdf.de/filme/taunuskrimi/")
    assert isinstance(playlist, dict)



# Generated at 2022-06-24 13:51:05.319565
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:51:09.635628
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    with open('test_download.txt') as file:
        try:
            test_url = file.readline()
            return ie.extract_from_url(test_url)
        except Exception as e:
            print(e)

# Generated at 2022-06-24 13:51:17.349130
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-24 13:51:18.230338
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None, {}, None)


# Generated at 2022-06-24 13:51:19.780151
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:29.734975
# Unit test for constructor of class ZDFIE
def test_ZDFIE():

    import pytest

    @pytest.fixture(scope="class")
    def ZDFIE_instance(request):
        request.cls.ie = ZDFIE()

    request = pytest.FixtureRequest(lambda: None)
    ZDFIE_instance(request)

    # Test case 1:
    # url: https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html
    # same as https://www.phoenix.de/sendungen/ereignisse/corona-nachgehakt/wohin-fuehrt-der-protest-in-der-pandemie-a-2050630.html
    test_case_1 = request.cls.ie.extract

# Generated at 2022-06-24 13:51:31.005455
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    return ZDFIE(compat_str(1))



# Generated at 2022-06-24 13:51:34.279607
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_ie_object = zdf_ie_object = ZDFBaseIE()
    assert zdf_ie_object._GEO_COUNTRIES == ['DE']
    assert zdf_ie_object._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:46.065795
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Basic test of creation of class ZDFBaseIE
    """
    zdf = ZDFBaseIE()
    test_video_id = 'test_video_id'
    assert zdf._call_api('test_url', test_video_id, 'test_item') == None

    assert ZDFBaseIE._extract_subtitles(None) == {}

    assert zdf._extract_format(test_video_id, [], set(), {}) == None

    # TODO: Solve problem with accessing of protected information
    # assert zdf._extract_ptmd('test_ptmd_url', test_video_id, 'test_api_token', 'test_referrer') == None

    assert zdf._extract_player('test_webpage', test_video_id) == None


# Generated at 2022-06-24 13:51:47.395302
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    # Ensure that the class is instantiated
    assert ie

# Generated at 2022-06-24 13:51:48.496002
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel = ZDFChannelIE()
    assert zdf_channel is not None

# Generated at 2022-06-24 13:51:51.809643
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('http://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html', 'id', 'title')

# Generated at 2022-06-24 13:51:54.346594
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(None, None)._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE(None, None)._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:52:07.456601
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._downloader.params['http_chunk_size'] == 10485760
    assert ie._downloader.params['test'] == False
    assert ie._downloader.params['proxy'] == None
    assert ie._downloader.params['noprogress'] == True
    assert ie._downloader.params['prefer_insecure'] == False
    assert ie._downloader.params['socket_timeout'] == 300
    assert ie._downloader.params['source_address'] == None
    assert ie._downloader.params['nocheckcertificate'] == False
    assert ie._downloader.params['forceurl']

# Generated at 2022-06-24 13:52:13.769139
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    res = ZDFChannelIE.suitable(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert res == True
    res = ZDFChannelIE.suitable(
        'https://www.zdf.de/dokumentation/planet-e')
    assert res == True
    res = ZDFChannelIE.suitable(
        'https://www.zdf.de/serien/heute-show/heute-show-vom-06-11-2020-100.html')
    assert res == False



# Generated at 2022-06-24 13:52:22.833938
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z = ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')
    z2 = ZDFIE('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert z.suitable(z.ie_key())
    assert not z2.suitable(z.ie_key())
    assert not z.suitable(z2.ie_key())
    assert z2.suitable(z2.ie_key())

# Generated at 2022-06-24 13:52:31.101200
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base_ie = ZDFBaseIE()

    # test _extract_ptmd
    ptmd = base_ie._extract_ptmd(
        'http://www.zdf.de/ZDFmediathek/kanaluebersicht',
        'test_id',
        None,
        None)

    assert isinstance(ptmd, object)
    assert isinstance(ptmd['duration'], float_or_none)
    assert isinstance(ptmd['subtitles'], object)
    assert isinstance(ptmd['id'], compat_str)

    # test custom method in _call_api

# Generated at 2022-06-24 13:52:39.937309
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie is not None
    # test the regex in _call_api
    assert ie._call_api(1,2,3) is not None
    # test the regex in _extract_subtitles
    assert ie._extract_subtitles(1) is not None
    # test the regex in _extract_format
    assert ie._extract_format(1,2,3,4) is not None
    # test the regex in _extract_ptmd
    assert ie._extract_ptmd(1,2,3,4) is not None
    # test the regex in _extract_player
    assert ie._extract_player(1,2) is not None


# Generated at 2022-06-24 13:52:46.270627
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = "https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html"
    ie = ZDFIE()
    ie._extract_ptmd(url, "", "", "")

# Generated at 2022-06-24 13:52:55.513189
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE._download_webpage.cache_clear()

    class UnitTestZDFChannelIE(ZDFChannelIE):
        def __init__(self, *args, **kwargs):
            super(UnitTestZDFChannelIE, self).__init__(*args, **kwargs)
            self._download_webpage = lambda *args, **kwargs: (
                expected_webpage if args[1] == expected_channel_id else None
            )

    # Construct a test ZDFChannelIE instance and call the _real_extract function
    # using the snippet from the snippet from the 'dokumentation/planet-e' page
    # as 'webpage' argument.

# Generated at 2022-06-24 13:53:06.632793
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test the constructor of class ZDFBaseIE
    """
    # Test with no input
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    # Test with correct values
    ie = ZDFBaseIE(
        _GEO_COUNTRIES=['ES'],
        _QUALITIES=('awesome', 'lame')
    )
    assert ie._GEO_COUNTRIES == ['ES']
    assert ie._QUALITIES == ('awesome', 'lame')


# Generated at 2022-06-24 13:53:09.595506
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/politik/phoenix-sendungen')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html')
    return ZDFChannelIE('https://www.zdf.de/politik/phoenix-sendungen')

# Generated at 2022-06-24 13:53:10.603256
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()



# Generated at 2022-06-24 13:53:19.396645
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from UnitTesting.ZDFBaseIE import ZDFBaseIE
    IE = ZDFBaseIE()
    test_obj = {'a':1, 'b':2, 'c':3}
    test_obj1 = {'b':2, 'c':3, 'd':4}
    test_list = [{'a':1, 'b':2, 'c':3}, {'a':1, 'b':2, 'c':3}]
    test_list1 = [{'b':2, 'c':3, 'd':4}, {'a':1, 'b':2, 'c':3}]
    assert isinstance(IE, ZDFBaseIE)
    assert isinstance(IE._GEO_COUNTRIES, list)
    assert isinstance(IE._QUALITIES, tuple)
    assert IE._

# Generated at 2022-06-24 13:53:22.252483
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie = ZDFChannelIE()
    assert ie.suitable(url)
    assert ie._real_extract(url)
    assert ie.IE_NAME == 'ZDF'
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.test()


# Generated at 2022-06-24 13:53:26.813577
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        # Check inherited InfoExtractor class constructor
        ie = ZDFBaseIE(None, None)
        assert ie._GEO_COUNTRIES == ['DE'], ie._GEO_COUNTRIES
        assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    except Exception:
        pass


# Generated at 2022-06-24 13:53:30.632962
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    
# Unit tests for method _call_api of class ZDFBaseIE

# Generated at 2022-06-24 13:53:38.471491
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    obj = ie._real_extract('https://www.zdf.de/sport/das-aktuelle-sportstudio')

    assert len(obj['entries']) > 0
    assert obj['id'] == 'das-aktuelle-sportstudio'
    assert obj['title'] == 'das aktuelle sportstudio | ZDF'

# Generated at 2022-06-24 13:53:39.472926
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()


# Generated at 2022-06-24 13:53:40.467765
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')

# Generated at 2022-06-24 13:53:41.508770
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()


# Generated at 2022-06-24 13:53:43.125111
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert instance._GEO_COUNTRIES == ['DE']
    assert instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:53:45.378736
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-24 13:53:50.518842
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_info_extractor = ZDFIE()
    assert sorted(zdf_info_extractor._QUALITIES) == [
        'auto', 'hd', 'high', 'low', 'med', 'veryhigh']
    assert sorted(zdf_info_extractor.IE_NAME) == ['ZDF']



# Generated at 2022-06-24 13:53:52.527446
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE(url)
    assert ie.suitable(url)



# Generated at 2022-06-24 13:53:55.547004
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:54:00.330229
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.country == 'DE'
    assert ie.qualities == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:10.567268
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """test_ZDFChannelIE"""
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi')
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/wissen/der-machbarkeitstest-100.html')

# Generated at 2022-06-24 13:54:11.524327
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()

# Generated at 2022-06-24 13:54:17.423817
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE(ZDFChannelIE.ie_key())
    url = 'https://www.phoenix.de/sendungen/das-phoenix-runde.html'
    ie.suitable(url)
    ie.extract(url)


# Generated at 2022-06-24 13:54:29.181451
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    inst = ZDFIE()
    assert inst._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert inst._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert inst._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert inst._TESTS[0]['info_dict']['id'] == '210222_phx_nachgehakt_corona_protest'

# Generated at 2022-06-24 13:54:34.273087
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._VALID_URL == ZDFIE._VALID_URL
    assert ZDFIE()._GEO_COUNTRIES == ZDFIE._GEO_COUNTRIES
    assert ZDFIE()._TESTS == ZDFIE._TESTS
    assert ZDFIE()._QUALITIES == ZDFIE._QUALITIES

test_ZDFIE()

# Generated at 2022-06-24 13:54:35.791581
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        assert ZDFIE.ie_key() == 'ZDF'
    except AssertionError:
        print("test failed")


# Generated at 2022-06-24 13:54:37.302572
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_extractor
    from .zdf import ZDFChannelIE
    cls = get_extractor(ZDFChannelIE.ie_key())
    assert cls == ZDFChannelIE



# Generated at 2022-06-24 13:54:41.130270
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    for geo_country in ZDFBaseIE._GEO_COUNTRIES:
        for quality in ZDFBaseIE._QUALITIES:
            print('geo_country: {}, quality: {}'.format(geo_country, quality))
    print(ZDFBaseIE._download_json('http://0.0.0.0', '1', 'json'))


# Generated at 2022-06-24 13:54:51.209243
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._real_extract('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100')
    ZDFIE()._real_extract('https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102')
    ZDFIE()._real_extract('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100')

# Generated at 2022-06-24 13:54:53.258199
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/')



# Generated at 2022-06-24 13:54:56.865015
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE();
    assert zdfie._GEO_COUNTRIES == ['DE'];
    assert zdfie._QUALITIES == ('auto','low','med','high','veryhigh','hd');

# Generated at 2022-06-24 13:55:01.400329
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/nachrichten/heute/heute-in-europa-19-05-2021-100.html'
    zdfie = ZDFIE()
    zdfie.ie_key()
    zdfie._match_id(url)
    zdfie._real_extract(url)


# Generated at 2022-06-24 13:55:08.950231
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .zdf import ZDFIE
    from ..utils import parse_codecs

    zdf = ZDFBaseIE(ZDFIE)

    test_values = [
        {'quality': 'low',  'expected': 1},
        {'quality': 'med',  'expected': 2},
        {'quality': 'high', 'expected': 3},
        {'quality': 'hd',   'expected': 4}
    ]

    for test_value in test_values:
        quality_value = qualities(zdf._QUALITIES)(test_value['quality'])
        assert test_value['expected'] == quality_value, \
            'Unexpected quality value (got %s instead of %s) for \'%s\'' \
            % (quality_value, test_value['expected'], test_value['quality'])

    audio

# Generated at 2022-06-24 13:55:10.512801
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:55:20.433923
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    fk = ZDFChannelIE.suitable
    assert fk(url) == True
    assert fk('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html') == False
    ie = ZDFChannelIE(url)
    assert ie.channel_id == 'planet-e'
    assert ie.channel_url == 'https://www.zdf.de/dokumentation/planet-e'
    assert ie.channel_json == 'https://www.zdf.de/documentData/{channel_id}'

# Generated at 2022-06-24 13:55:21.444674
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None)



# Generated at 2022-06-24 13:55:25.073073
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == "ZDF" 


# Generated at 2022-06-24 13:55:28.233885
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        instance = ZDFIE()
        print('Instance created successfully ' + str(instance))
    except Exception as e:
        print('Instance creation failed ' + str(e))


# Generated at 2022-06-24 13:55:31.169090
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None)
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:32.350888
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    k = ZDFBaseIE()
    assert callable(k)


# Generated at 2022-06-24 13:55:38.027073
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:42.979492
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE({})
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:55:44.431924
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-24 13:55:48.884809
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    for test in ZDFIE._TESTS:
        if 'only_matching' not in test:
            ZDFIE()._extract_regular(test['url'], ZDFIE._extract_player(test['url'], test['url']), test['url'])

# Generated at 2022-06-24 13:55:52.528696
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base = ZDFBaseIE(None)
    assert base._GEO_COUNTRIES == ['DE'] or base._GEO_COUNTRIES == ['AT', 'CH', 'DE']
    assert base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:56.126779
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print('start the test')
    obj = ZDFChannelIE()
    assert obj.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')


# Generated at 2022-06-24 13:55:57.142349
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()


# Generated at 2022-06-24 13:55:58.846655
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Should not raise an exception
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-24 13:55:59.949165
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # No test for abstract class
    pass



# Generated at 2022-06-24 13:56:01.162379
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE = ZDFIE()
    print(ZDFIE)

# Generated at 2022-06-24 13:56:04.113529
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # create an instance of the class to be unit tested
    instance = ZDFBaseIE()
    # simple test to see if it was created correctly
    assert instance._GEO_COUNTRIES == ['DE']



# Generated at 2022-06-24 13:56:05.789658
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    e = ZDFBaseIE()
    assert e


# Generated at 2022-06-24 13:56:14.654435
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 13:56:25.269522
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:56:31.046617
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    _VALID_URL = r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie.VALID_URL == _VALID_URL
    _TESTS = [{
        'url': 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html',
        'only_matching': True,
    }]
    assert ie.TESTS == _TESTS



# Generated at 2022-06-24 13:56:37.022532
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # This method of testing is deprecated.
    import requests
    instance = ZDFChannelIE()

    # Since we don't use any url here and the url is a required argument
    # to the constructor of ZDFChannelIE,
    # it will throw an error if the code below is executed at all.
    instance.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    print('Unit test for the zdfie.py file.')



# Generated at 2022-06-24 13:56:38.141725
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._extract_entry()


# Generated at 2022-06-24 13:56:39.997461
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == '0110'


# Generated at 2022-06-24 13:56:51.608192
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test = ZDFIE()
    assert test._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:56:54.264435
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('', {'content': 'https://zdf-cdn.live.cellular.de/mediathekV2/content/baseUrl'})


# Generated at 2022-06-24 13:56:55.523419
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()
# End of unit test for constructor of class ZDFIE



# Generated at 2022-06-24 13:56:56.768014
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE(None).ie_key() == 'ZDF'



# Generated at 2022-06-24 13:57:01.903921
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE().video_result('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')



# Generated at 2022-06-24 13:57:11.382148
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

# Generated at 2022-06-24 13:57:18.242071
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for ZDFChannelIE
    """
    try:
        ZDFChannelIE("https://www.zdf.de/filme/taunuskrimi/")
    except:
        print("not suitable for ZDFChannelIE")
    try:
        ZDFChannelIE("https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html")
    except:
        print("suitable for ZDFChannelIE")

# Generated at 2022-06-24 13:57:24.869090
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-24 13:57:30.338850
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'

# Generated at 2022-06-24 13:57:38.261016
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import sys
    import datetime
    if sys.version_info[0] != 3:
        print('ERROR: Python 2 detected. Unit test untested. Aborting')
        return
    # Construct new object to test
    obj = ZDFChannelIE()
    # Test format_time_string function
    assert obj._format_time_string(
        datetime.datetime.fromtimestamp(4000000), '-') == '03:46:40'
# End unit test for constructor of class ZDFChannelIE


# Generated at 2022-06-24 13:57:43.935332
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('http://www.zdf.de/filme/taunuskrimi/taunuskrimi-die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') is False
    assert ie.suitable('http://www.zdf.de/filme/taunuskrimi/') is True

# Generated at 2022-06-24 13:57:47.382285
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    Unit test for constructor of class ZDFIE.
    """
    try:
        # Test for a URL for which ydl_opts['geo_bypass'] is True
        zdf_ie = ZDFIE()
        zdf_ie
    finally:
        # Cleanup
        if zdf_ie:
            del zdf_ie


# Generated at 2022-06-24 13:57:51.441665
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'
    zdfe = ZDFIE();
    assert zdfe._VALID_URL == ZDFIE._VALID_URL
    assert zdfe._TESTS == ZDFIE._TESTS

# Generated at 2022-06-24 13:57:57.436328
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert hasattr(ZDFBaseIE, '_GEO_COUNTRIES')
    assert hasattr(ZDFBaseIE, '_QUALITIES')
    assert hasattr(ZDFBaseIE, '_call_api')
    assert hasattr(ZDFBaseIE, '_extract_format')
    assert hasattr(ZDFBaseIE, '_extract_ptmd')
    assert hasattr(ZDFBaseIE, '_extract_player')
    assert hasattr(ZDFBaseIE, '_sort_formats')



# Generated at 2022-06-24 13:57:58.903816
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert isinstance(ie, ZDFBaseIE)


# Generated at 2022-06-24 13:58:02.063490
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    instance.suite()
    instance.format_suite()
    assert ZDFIE.suite() is None
    assert ZDFIE.format_suite() is None

# Generated at 2022-06-24 13:58:07.428669
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie = ZDFChannelIE()
    ie.prepare_extraction(url)
    assert ie.is_suitable(url)
    assert not ie.is_suitable((ZDFIE.suitable(url), url)[1])
    pass


# Generated at 2022-06-24 13:58:12.123165
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    I = ZDFIE('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert I._VALID_URL == ZDFIE._VALID_URL
    assert orderedSet(I._GEO_COUNTRIES) == orderedSet(ZDFBaseIE._GEO_COUNTRIES)
    assert I._QUALITIES == ZDFBaseIE._QUALITIES

# Generated at 2022-06-24 13:58:22.954438
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import FakeZDFBaseIE
    from . import FakeZDFIE
    from . import FakeZDFBaseIE
    from . import FakeZDFIE

    class FakeZDFChannelIE(FakeZDFBaseIE, ZDFChannelIE):
        pass

    FakeZDFChannelIE._download_json = FakeZDFBaseIE._download_json
    FakeZDFChannelIE._download_webpage = FakeZDFBaseIE._download_webpage
    FakeZDFChannelIE._extract_player = FakeZDFBaseIE._extract_player
    FakeZDFChannelIE._call_api = FakeZDFBaseIE._call_api
    FakeZDFChannelIE._extract_ptmd = FakeZDFIE._extract_ptmd

    FakeZDFChannelIE._extract_subtitles = FakeZDFIE._extract_subtitles



# Generated at 2022-06-24 13:58:27.756130
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    pass
#     channel_url = 'https://www.zdf.de/kinder/logo'
#     channel_id = ZDFChannelIE._match_id(channel_url)
#     zdf_channel = ZDFChannelIE()
#     assert channel_id == zdf_channel._match_id(channel_url)
#     assert channel_id == 'logo'

# Generated at 2022-06-24 13:58:38.701161
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.utils import parse_duration
    url = 'https://www.zdf.de/dokumentation/planet-e'
    a = ZDFChannelIE()
    a.suitable(url)
    r = a._real_extract(url)
    assert 'playlist' in r
    print(r['playlist'])
    assert 'entries' in r
    assert len(r['entries']) > 0
    assert len(r['entries']) == 50
    print(r['entries'][0]['url'])
    print(r['entries'][0]['id'])
    print(r['entries'][0]['title'])


# Generated at 2022-06-24 13:58:41.393352
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test the constructor of ZDFChannelIE
    # ToDo: Please write you test code here.
    zdfchannelie = ZDFChannelIE()


# Generated at 2022-06-24 13:58:45.554329
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:58:49.184579
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testdata
    html = get_testdata()
    assert isinstance(ZDFChannelIE(html), type(ZDFChannelIE))


# Generated at 2022-06-24 13:58:51.492967
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert callable(ZDFBaseIE)
    assert isinstance(ZDFBaseIE, type)



# Generated at 2022-06-24 13:58:55.753771
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    # Test whether the list of quality names is sorted
    assert zdfie._QUALITIES == sorted(zdfie._QUALITIES, key=qualities(zdfie._QUALITIES)._func)



# Generated at 2022-06-24 13:58:58.863233
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None)
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:59:03.363397
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE(None)
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

################################################################################


# Generated at 2022-06-24 13:59:05.258377
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test ZDFIE constructor
    ZDFIE

# Generated at 2022-06-24 13:59:08.243231
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Create an instance of ZDFBaseIE and test if it's working
    """
    # Create an instance of ZDFBaseIE
    obj = ZDFBaseIE(False)

    return True


# Generated at 2022-06-24 13:59:08.809658
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass



# Generated at 2022-06-24 13:59:11.573584
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE()
    zdfChannelIE.suitable(ZDFChannelIE._VALID_URL)
    pass

# Generated at 2022-06-24 13:59:16.223888
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES is None or len(ZDFBaseIE._GEO_COUNTRIES) > 0
    assert ZDFBaseIE._QUALITIES is None or len(ZDFBaseIE._QUALITIES) > 0


# Generated at 2022-06-24 13:59:25.396478
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()

    assert zdfie._GEO_COUNTRIES == ['DE']

    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

    assert zdfie._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert zdfie._TESTS[1]['url'] == 'https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html'

# Generated at 2022-06-24 13:59:26.795088
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:59:37.068611
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_url = 'https://ZDFBaseIE'
    test_video_id = '12345'
    test_response = 'This is a test response'
    assert ZDFBaseIE._download_json(test_url, test_video_id, 'test') == test_response

    test_mime_type = 'application/x-mpegURL'
    test_subtitles = {'eng': [{'url': 'https://subtitles'}]}
    assert ZDFBaseIE._extract_subtitles({'captions': [{'uri': 'https://subtitles', 'language': 'eng'}]}) == test_subtitles

    test_json_response = {'uri': 'https://test_url'}
    test_extract_format = [{'url': 'https://test_url'}]

# Generated at 2022-06-24 13:59:38.047613
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()

# Generated at 2022-06-24 13:59:45.531856
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE
    TestCase().assertTrue(zdf.suitable('https://www.zdf.de/filme/taunuskrimi/'))
    TestCase().assertFalse(zdf.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'))



# Generated at 2022-06-24 13:59:48.423126
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(None)._real_extract('https://www.zdf.de/sport/das-aktuelle-sportstudio')

# Generated at 2022-06-24 13:59:51.097767
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert hasattr(ie, '_call_api')
    assert hasattr(ie, '_extract_player')


# Generated at 2022-06-24 13:59:53.403526
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:59:54.831063
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from .test_download import test_download
    assert test_download(ZDFIE, '151025_magie_farben2_tex')



# Generated at 2022-06-24 13:59:56.205614
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import theplatform_download_playlist
    theplatform_download_playlist.main()

# Generated at 2022-06-24 14:00:05.166249
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie._call_api.__name__ == '_call_api'
    assert ie._extract_subtitles.__name__ == '_extract_subtitles'
    assert ie._extract_format.__name__ == '_extract_format'
    assert ie._extract_ptmd.__name__ == '_extract_ptmd'
    assert ie._extract_player.__name__ == '_extract_player'

