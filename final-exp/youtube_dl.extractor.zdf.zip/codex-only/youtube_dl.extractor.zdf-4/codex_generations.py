

# Generated at 2022-06-24 13:50:06.180372
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ZDFChannelIE().suitable(url)
    ZDFChannelIE._real_extract(ZDFChannelIE(), url)
    assert ZDFChannelIE.ie_key() == 'ZDF'

# Generated at 2022-06-24 13:50:09.757732
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE("ZDFBaseIE")
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:11.932715
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    def make_ZDFChannelIE():
        import zdf_dl
        return zdf_dl.ZDFChannelIE()

    assert_raises(AttributeError, make_ZDFChannelIE)



# Generated at 2022-06-24 13:50:13.887123
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    return ZDFIE(InfoExtractor(), 'zdfthese')


# Generated at 2022-06-24 13:50:22.444113
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    print(ie._TESTS[0]["url"])
    print(ie._VALID_URL)
url = ie._TESTS[0]["url"]
print(ie._VALID_URL)
print(url)
mobj = re.match(ie._VALID_URL,url)
print(mobj)

id = mobj.group('id')
print(id)
n = url.rfind("/")
n = url[n+1:-1]
print(n)
print(ie._ALL_FORMATS)
print(list(ie._ALL_FORMATS.values()))

import itertools as it

# Generated at 2022-06-24 13:50:24.011439
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_ZDFBaseIE = ZDFBaseIE()  # noqa

# Generated at 2022-06-24 13:50:26.988493
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base_ie = ZDFBaseIE()
    assert base_ie._GEO_COUNTRIES == ['DE']
    assert base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:31.988551
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for class ZDFChannelIE
    """
    url = 'https://www.zdf.de/dokumentation/planet-e'
    item = ZDFChannelIE()._real_extract(url)
    assert item['id'] == 'planet-e'
    assert item['title'] == 'planet e.'

# Generated at 2022-06-24 13:50:37.324513
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    f = ZDFBaseIE._extract_embed
    ZDFBaseIE._extract_embed = lambda self, video_id, webpage: None
    try:
        ZDFChannelIE()._real_extract("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    finally:
        ZDFBaseIE._extract_embed = f

# Generated at 2022-06-24 13:50:38.811055
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from ..test import test_ZDFBaseIE
    test_ZDFBaseIE()


# Generated at 2022-06-24 13:50:40.144515
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    inst = ZDFIE()
    assert(inst.__class__)



# Generated at 2022-06-24 13:50:42.695864
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zd = ZDFChannelIE()
    assert zd.suitable('https://www.zdf.de/filme/taunuskrimi/') == True

# Generated at 2022-06-24 13:50:46.479024
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    global ZDFChannelIE
    ZDFChannelIE = ZDFChannelIE()
# Test of constructor of class ZDFChannelIE
test_ZDFChannelIE()
test_ZDFChannelIE = None



# Generated at 2022-06-24 13:50:56.148413
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()

    assert zdfIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:50:59.787087
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE(ZDFChannelIE.suitable)
    assert isinstance(zdfChannelIE, ZDFChannelIE)


# Generated at 2022-06-24 13:51:00.967704
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert isinstance(instance,InfoExtractor)

# Generated at 2022-06-24 13:51:04.336825
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .tests.playlist_examples import test_channels
    IE = ZDFChannelIE
    for example in test_channels(IE):
        yield example

# Generated at 2022-06-24 13:51:08.845851
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('das-aktuelle-sportstudio', '1')
    ZDFChannelIE('dokumentation/planet-e', '2')
    ZDFChannelIE('filme/taunuskrimi/', '3')


# Generated at 2022-06-24 13:51:12.024662
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf.IE_NAME == 'ZDF'
    assert zdf.IE_DESC == 'ZDF Mediathek'
    assert zdf._VALID_URL == ZDFIE._VALID_URL

# Generated at 2022-06-24 13:51:12.900283
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()
    
    

# Generated at 2022-06-24 13:51:15.815612
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._call_api(None, None, None)



# Generated at 2022-06-24 13:51:17.065937
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    return ZDFBaseIE


# Generated at 2022-06-24 13:51:18.178081
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:51:26.098597
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdf._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert zdf.ie_key() == 'zdf'


# Generated at 2022-06-24 13:51:34.581194
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-24 13:51:36.719716
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()


# Generated at 2022-06-24 13:51:46.772570
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Gather test cases from class ZDFChannelIE._TESTS
    test_cases = ZDFChannelIE._TESTS

    # Initialize dictionaries
    results = {}
    report = {
        'success': 0,
        'failed': 0,
        'expected_fail': 0,
    }
    expected_fail_cases = [
    ]
    expected_fail_count = len(expected_fail_cases)

    # Iterate through test cases and invoke constructor of class ZDFChannelIE
    for (i, test_case) in enumerate(test_cases):
        # Extract URL of test case
        url = test_case['url']

        # Initialize entry in dictionary

# Generated at 2022-06-24 13:51:51.941446
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE'], 'Erro: The value of _GEO_COUNTRIES is incorrect'
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'), 'Erro: The value of _QUALITIES is incorrect'



# Generated at 2022-06-24 13:51:56.491412
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.is_suitable("https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html")
    assert ie.is_suitable("https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html")



# Generated at 2022-06-24 13:51:59.417828
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:52:00.405343
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-24 13:52:05.618594
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    print(zdfIE._GEO_COUNTRIES)
    print(zdfIE._VALID_URL)
    print(zdfIE.ie_key())
    #print(zdfIE._extract_regular(url, player, video_id))



# Generated at 2022-06-24 13:52:08.486139
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = "https://www.zdf.de/filme/taunuskrimi/"
    channel = ZDFChannelIE()
    assert channel.suitable(url)



# Generated at 2022-06-24 13:52:13.001177
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert(ZDFBaseIE.__name__ == "ZDFBaseIE")
    assert(ZDFBaseIE._GEO_COUNTRIES == ['DE'])
    assert(ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-24 13:52:17.083284
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE()
    assert channel.suitable('https://www.zdf.de/dokumentation/planet-e')

    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-24 13:52:18.561805
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    zdf_test = ZDFIE()



# Generated at 2022-06-24 13:52:30.609970
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie._VALID_URL == ZDFChannelIE._VALID_URL
    assert ie.__name__ == 'ZDFChannel'
    assert ie.ie_key() == 'ZDF'
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ie.suitable('https://www.zdf.de/dokumentation/planet-e.html')
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e/')
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e/subdir/')
    assert not ie.suitable('https://www.zdf.de/dokumentation/planet-e-subdir/')


# Generated at 2022-06-24 13:52:34.722893
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('url', 'info_dict')
    assert ie.ie_key() == 'ZDF'
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:52:37.900745
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass



# Generated at 2022-06-24 13:52:48.954990
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Test ZDFChannelIE.suitable() and ZDFChannelIE._real_extract()
    """
    # Test that a subclass of ZDFChannelIE (e.g. ZDFSportIE) has been registered
    assert ZDFChannelIE.ie_key() in gen_extractors.keys()

    # Test the construction of a ZDFChannelIE object by calling the constructor
    ie = ZDFChannelIE()

    # Test that URL from a channel page is suitable for ZDFChannelIE
    url = "https://www.zdf.de/sport/das-aktuelle-sportstudio"
    # Test that ZDFChannelIE.suitable() returns 'True' for this URL
    assert(ZDFChannelIE.suitable(url))
    # Test that ZDFChannelIE._real_extract() returns a dictionary with

# Generated at 2022-06-24 13:52:51.385237
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from unittest import TestCase
    from youtube_dl.utils import DownloadError
    try:
        zdfie = ZDFBaseIE();
    except DownloadError as e:
        assert e.args[0] == 'zdf+mediathek extractor is disabled by configuration.'
        return
    else:
        assert False # ZDFBaseIE should not be callable



# Generated at 2022-06-24 13:53:00.345046
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest
    class ZDFChannelIETestCase(unittest.TestCase):
        def test_zdfchannel_match_id(self):
            self.assertEqual(ZDFChannelIE._match_id('https://www.zdf.de/sport/das-aktuelle-sportstudio'), 'das-aktuelle-sportstudio')
            self.assertEqual(ZDFChannelIE._match_id('https://www.zdf.de/dokumentation/planet-e'), 'planet-e')
            self.assertEqual(ZDFChannelIE._match_id('https://www.zdf.de/dokumentation/planet-e/'), 'planet-e')

# Generated at 2022-06-24 13:53:12.792460
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    Url = namedtuple('Url', ['url', 'entries'])

# Generated at 2022-06-24 13:53:14.139099
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE.ie_key() == 'zdf'


# Generated at 2022-06-24 13:53:18.127185
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFBaseIE.init(ZDFBaseIE)
    assert hasattr(ZDFBaseIE, 'ie_key')
    iface = ZDFBaseIE.ie_key()
    assert iface.endswith('.ZDFIE')
    assert iface.startswith('ZDFIE')


# Generated at 2022-06-24 13:53:24.613011
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import youtube_dl
    import re

    # unit test for constructor of ZDFChannelIE
    ie = ZDFChannelIE()

    # test valid and invalid URLs
    assert ie.suitable(ie.VALID_URL)
    assert not ie.suitable(ie.VALID_URL[:-1])
    assert not ie.suitable(ie.VALID_URL[:-6])
    assert not ie.suitable(ie.VALID_URL[:-8])
    assert not ie.suitable(ie.VALID_URL[:-10])
    assert not ie.suitable(ie.VALID_URL[:-12])
    assert not ie.suitable(ie.VALID_URL[:-14])
    assert not ie.suitable(ie.VALID_URL[:-16])

# Generated at 2022-06-24 13:53:27.158880
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Test constructor of class ZDFChannelIE.
    """
    try:
        # Create object instance.
        obj = ZDFChannelIE()
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-24 13:53:29.443274
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/planet-e")

# Generated at 2022-06-24 13:53:35.490756
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class TestZDFBaseIE(ZDFBaseIE):
        IE_NAME = 'ZDF IE'
        IE_DESC = 'ZDF IE'
        _VALID_URL = r'.*'

    assert TestZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert TestZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    # TODO: if possible, create a ptmd.json uri to test the call of _call_api
    # TODO: test _extract_subtitles



# Generated at 2022-06-24 13:53:38.373777
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from ..test import get_testcases
    for case in get_testcases(ZDFChannelIE, {'extractors': [ZDFChannelIE]}):
        yield case

# Generated at 2022-06-24 13:53:48.392266
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # create the class
    zdfie = ZDFIE()
    # get the test cases
    tests = zdfie._TESTS
    # check the tests
    for test in tests:
        # check _VALID_URL
        assert(zdfie._VALID_URL == "https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html")
        # get the video id
        video_id = zdfie._match_id(test.get('url'))
        assert(video_id == test.get('info_dict').get('id'))



# Generated at 2022-06-24 13:53:52.812447
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:05.330616
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_url = 'https://www.zdf.de/dokumentation/planet-e'
    # call constructor of class ZDFChannelIE
    instance = ZDFChannelIE()
    # check the value of class attribute SUITABLE
    # the value must be a regex string
    assert isinstance(instance.SUITABLE, compat_str)
    # check the value of class attribute _VALID_URL
    assert isinstance(instance._VALID_URL, compat_str)
    # check the value of instance property name
    assert isinstance(instance.name, compat_str)
    # check the value of instance property ie_key()
    assert instance.ie_key() == 'ZDFChannel'
    # check the callable of instance method _real_extract()
    assert callable(instance._real_extract)
    # check the

# Generated at 2022-06-24 13:54:07.930637
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()


# Generated at 2022-06-24 13:54:18.415816
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .zdf import ZDFIE
    from .zdf_mediathek import ZDFMediathekIE
    from .zdf_sport import ZDFSportIE
    from .zdf_neo import ZDFNeoIE
    from .zdf_kinder import ZDFKinderIE
    from .funk import FunkIE
    from .funk import FunkBaseIE
    from .funk import FunkRouletteIE
    from .funk import FunkPopIE
    from .funk import FunkSoulIE
    from .funk import FunkHouseIE
    from .vier import VierIE
    from .neun import NeunIE
    from .tagesschau import TagesschauIE
    from .tagesschau import TagesschauPlayerIE
    from .tagesschau import Tagesschau24IE

# Generated at 2022-06-24 13:54:30.316163
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test a mobile page
    page = ZDFIE._download_webpage(
        'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html',
        'c4cf53e4-4b04-4f3c-80e0-8d9e9288e1b2',
        fatal=False)
    
    # Test a regular page

# Generated at 2022-06-24 13:54:33.039361
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()
    zdf.suitable(ZDFChannelIE._VALID_URL)
    zdf.suitable(ZDFIE._VALID_URL)
    zdf.suitable('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')

# Generated at 2022-06-24 13:54:39.016461
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfcie = ZDFChannelIE()
    assert zdfcie.suitable(
        'https://www.zdf.de/dokumentation/planet-e') == True
    assert zdfcie.suitable(
        'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') == False
# end of constructor testing for class ZDFChannelIE


# Generated at 2022-06-24 13:54:47.847076
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest
    from zdf_dl import ZDFIE, ZDFChannelIE
    from zdf_dl.extractor import (
        ZDFIE, ZDFBaseIE
    )  # ... from target module to avoid circular reference
    # pass a function reference to constructor of class ZDFChannelIE ...
    ZDFChannelIE._download_webpage = ZDFBaseIE._download_webpage
    # ... as well as to _download_webpage
    ZDFChannelIE._extract_player = ZDFIE._extract_player



# Generated at 2022-06-24 13:54:50.278932
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:54:51.570219
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.name == 'ZDF'


# Generated at 2022-06-24 13:55:01.042944
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    zdfChannelIE = ZDFChannelIE()
    zdfChannelIE._download_any_available_format_mock = {'url': '1'}
    zdfChannelIE._download_webpage_mock = "fixed static content"
    zdfChannelIE._extract_player_mock = {'content': '1'}

# Generated at 2022-06-24 13:55:07.067419
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:17.883874
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:55:19.199797
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie


# Generated at 2022-06-24 13:55:20.342088
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:55:26.818444
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    zdfie._VALID_URL
    zdfie._TESTS
    zdfie._extract_player
    zdfie._extract_regular
    zdfie._extract_mobile
    zdfie._real_extract


# Generated at 2022-06-24 13:55:36.293775
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():

    class TestZDFBaseIE(ZDFBaseIE):
        _VALID_URL = r'https?://(?:www\.)?zdf\.de/[^/]+/(?P<id>[^/]+)'

        def _real_extract(self, url):
            return {
                'id': self._match_id(url)
            }

    ie = TestZDFBaseIE()
    zdf_base_dict = {
        '_call_api': ie._call_api,
        '_extract_subtitles': ie._extract_subtitles,
        '_extract_format': ie._extract_format,
        '_extract_ptmd': ie._extract_ptmd,
        '_extract_player': ie._extract_player,
    }
    assert zdf_base

# Generated at 2022-06-24 13:55:41.889034
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None)
    # test for instance of ZDFBaseIE
    assert isinstance(ie, ZDFBaseIE)
    # test for attributes of ZDFBaseIE
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:43.696489
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable({"url": "http://1.example.com"})

# Generated at 2022-06-24 13:55:53.545695
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """ Test case for constructor of class ZDFChannelIE """

    assert ZDFChannelIE.suitable(
        ZDFChannelIE._VALID_URL)  # pylint: disable=protected-access
    assert ZDFChannelIE.suitable(
        'https://www.zdf.de/politik/themen-der-woche')
    assert not ZDFChannelIE.suitable(
        'https://www.zdf.de/verbraucher/marktcheck/marktcheck-vom-10-april-2020-100.html')

    # Constructor test 1
    zdf = ZDFChannelIE()
    zdf.suitable(
        'https://www.zdf.de/politik/themen-der-woche')  # pylint: disable=no-value-for-parameter

# Generated at 2022-06-24 13:55:56.834359
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE('test', 'www.zdf.de')
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-24 13:56:01.032617
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    # check for some required attributes of class ZDFIE
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:56:05.488602
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    def get_entries(url):
        ie = ZDFChannelIE()
        entries = ie.extract_entries(url)
        return [e for e in entries if isinstance(e, ZDFIE)]

    assert len(get_entries('https://www.zdf.de/dokumentation/planet-e')) == 50



# Generated at 2022-06-24 13:56:07.480253
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    o = ZDFIE()
    assert o._GEO_COUNTRIES == ['DE']
    assert o._QUALITIES == ['auto', 'low', 'med', 'high', 'veryhigh', 'hd']

# Generated at 2022-06-24 13:56:15.342945
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/planet-e")
    assert ZDFChannelIE.suitable("https://www.zdf.de/filme/taunuskrimi/")
    assert not ZDFChannelIE.suitable("https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html")
    assert not ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html")

# Generated at 2022-06-24 13:56:25.810004
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie = ZDFIE('ZDF')
    ie = ZDFIE('ZDF', 'ZDF')
    global _VALID_URL
    ie = ZDFIE('ZDF', 'ZDF', _VALID_URL)
    ie = ZDFIE('ZDF', 'ZDF', _VALID_URL, 'ZDFIE')
    ie = ZDFIE('ZDF', 'ZDF', _VALID_URL, 'ZDFIE', ['DE'])
    ie = ZDFIE('ZDF', 'ZDF', _VALID_URL, 'ZDFIE', ['DE'], ['auto', 'low', 'med', 'high', 'veryhigh', 'hd'])

# Generated at 2022-06-24 13:56:27.974101
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test empty constructor
    print("Test empty constructor")
    try:
        ZDFBaseIE()
    except NameError:
        print("NameError exception raised. Expected")


# Generated at 2022-06-24 13:56:37.428304
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Added unit test to check whether the ZDFChannelIE class is created or not
    """
    test_url = "https://www.zdf.de/sport/das-aktuelle-sportstudio"
    ZDFChannelIE._download_webpage = lambda self,url,channel_id:"test webpage"
    ZDFChannelIE._og_search_title = lambda self, webpage, default, channel_id, fatal=True:"test title"
    ZDFChannelIE._search_regex = lambda self,pattern, string, name, default=None, group=None:"test channel id"
    ZDFChannelIE._call_api = lambda self, url, video_id, note, fatal=True:"test api response"

# Generated at 2022-06-24 13:56:41.985725
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Tests a ZDF channel URL
    # Test correct import of ZDFChannelIE
    ZDFChannelIE.suitable("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    assert True


# Generated at 2022-06-24 13:56:43.099450
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('ZDFBaseIE')


# Generated at 2022-06-24 13:56:44.862000
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE().ie_key() == 'ZDF'

# Generated at 2022-06-24 13:56:50.090391
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._call_api("")
    assert ie._extract_subtitles({})
    assert ie._extract_format("")
    assert ie._extract_ptmd("")
    assert ie._extract_player("")
# endregion
# region class ZDFIE(ZDFBaseIE)

# Generated at 2022-06-24 13:56:56.352360
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-24 13:56:58.809937
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # should not raise any exception
    ZDFBaseIE()



# Generated at 2022-06-24 13:57:00.524389
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()


# Generated at 2022-06-24 13:57:12.268263
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:57:17.871132
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_cases = [
        {
            'url': 'https://www.zdf.de/dokumentation/planet-e'
        }
    ]
    for test_case in test_cases:
        ie = ZDFChannelIE()
        assert ie.suitable(test_case['url']) is True
        # TODO: we may need to check the results of real_extract()



# Generated at 2022-06-24 13:57:23.520593
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    with open('test_files/zdf_result.html') as f:
        html_string = f.read()
    info = ZDFIE()._extract_player(html_string, "Doesn't matter", True)
    with open('test_files/zdf_result_exp.html') as f:
        assert info == json.loads(f.read())
        print("Test successful")
    return



# Generated at 2022-06-24 13:57:30.408986
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = urljoin('https://www.zdf.de/', 'dokumentation/planet-e')
    ie = ZDFChannelIE(url)
    assert ie.suitable(url)
    assert not ie.suitable(urljoin('https://www.zdf.de/', 'dokumentation/planet-e/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'))


# Generated at 2022-06-24 13:57:39.182975
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    ie._extract_ptmd(
        "https://zdf-cdn.live.cellular.de/i/v1/1/default/master.m3u8/ptmd/f6/23/2eac47f1-8eb1-45f6-b6a5-e2096a9e19f6.xml", "testvideoID", "testapiToken", "testReferrer")
    # All parameters should be the same and then call self._call_api() should be called.
    assert ie


# Generated at 2022-06-24 13:57:42.580005
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable(ZDFChannelIE._VALID_URL) and not ie.suitable(ZDFIE._VALID_URL)



# Generated at 2022-06-24 13:57:53.929165
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    if obj._GEO_COUNTRIES != ['DE']: raise Exception(obj._GEO_COUNTRIES)
    if obj._QUALITIES != ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'): raise Exception(obj._QUALITIES)
    if obj._call_api('url', 'id', 'item', api_token='api_token', referrer='referrer') != None: raise Exception('_call_api() returned unexpected value')
    if obj._extract_subtitles('src') != {}: raise Exception(obj._extract_subtitles('src'))
    if obj._extract_format('video_id', 'formats', 'format_urls', 'meta') != None: raise Exception('_extract_format() returned unexpected value')


# Generated at 2022-06-24 13:58:00.957190
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # test_content_id
    assert ZDFBaseIE._extract_ptmd(None,None,None,None)['id'] == 'basename'
    # test_duration
    assert ZDFBaseIE._extract_ptmd(None,None,None,None)['duration'] == 1000
    # test_extractor_key
    assert ZDFBaseIE._extract_ptmd(None,None,None,None)['extractor_key'] == 'zdf'
    # test_duration_None
    assert ZDFBaseIE._extract_ptmd(None,None,None,None)['duration'] != None
    # test_formats_notNone

# Generated at 2022-06-24 13:58:01.964028
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-24 13:58:06.161522
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        a = ZDFIE(None)
        assert(a is not None)
        assert(ZDFIE.ie_key() == 'ZDF')
    except Exception:
        print('Error constructing class ZDFIE')
        raise

# Test for function _extract_entry

# Generated at 2022-06-24 13:58:18.392029
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .common import FakeZDFIE
    # Test URL
    test_url = 'https://www.zdf.de/serien/die-tudors/folge-25-staffel-4-folge-25-100.html'
    # Initialize a ZDFBaseIE object with the test URL
    ZDFBaseIE_test = ZDFBaseIE(FakeZDFIE(), test_url)
    # Check if the test URL is initialized
    assert ZDFBaseIE_test._url == test_url
    # Check if the test URL is parsed correctly
    assert ZDFBaseIE_test._match_id == '100'
    # Check if the test URL is parsed correctly
    assert ZDFBaseIE_test._BRAND_ID == 'die-tudors'
    # Check if the test URL is parsed correctly
    assert ZDFBase

# Generated at 2022-06-24 13:58:28.311764
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE("http://www.zdf.de/ZDFmediathek")
    ie.extract("http://www.zdf.de/ZDFmediathek/beitrag/video/2172206/Volleyball-EM-Von-der-Ungluecks-zur-Siegerin#/beitrag/video/2172206/Volleyball-EM-Von-der-Ungluecks-zur-Siegerin")
    ie.extract("http://www.zdf.de/ZDFmediathek/beitrag/video/2800792/Russian-Girls-in-Dessous#/beitrag/video/2800792/Russian-Girls-in-Dessous")


# Generated at 2022-06-24 13:58:32.701426
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_WORKING')


# Generated at 2022-06-24 13:58:38.556057
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_url = 'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
    ie = ZDFChannelIE()
    assert ie.suitable(test_url)
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:58:42.864979
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_zdf import all_cases_for_testing_zdf_ie
    for test_case in all_cases_for_testing_zdf_ie():
        if test_case['url'].startswith('https://www.zdf.de/'):
            yield test_case

# Generated at 2022-06-24 13:58:45.365871
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test if ability to initialize class ZDFBaseIE."""
    assert ZDFBaseIE is not None


# Generated at 2022-06-24 13:58:54.802968
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    def check_url(url):
        assert isinstance(ZDFChannelIE._match_id(url), compat_str)
        assert isinstance(ZDFChannelIE._extract_channel_id(url), compat_str)

    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    check_url(url)
    url = 'https://www.zdf.de/dokumentation/planet-e'
    check_url(url)
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    check_url(url)

# Generated at 2022-06-24 13:59:03.441553
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import glob
    import os.path
    import unittest

    class ZDFChannelIETest(unittest.TestCase):
        def test_for_unittest_only(self):
            unittest_path = os.path.dirname(os.path.realpath(__file__))
            unit_test_folder = os.path.join(unittest_path, 'unittest_data')
            for unittest_json_path in glob.glob(os.path.join(unit_test_folder, '*.json')):
                with self.subTest(unittest_json_path=unittest_json_path):
                    with open(unittest_json_path, 'rb') as f:
                        unit_test_json_content = f.read().decode('utf8')
                    ie

# Generated at 2022-06-24 13:59:06.998671
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFIE()
        assert False
    except TypeError as e:
        assert str(e) == 'This class must be subclassed; define a _real_extract method'



# Generated at 2022-06-24 13:59:19.050213
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    # Test case with HTML page
    webpage = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    result = ie.extract(webpage)
    assert result['id'] == '210222_phx_nachgehakt_corona_protest'
    assert result['title'] == 'Wohin führt der Protest in der Pandemie?'
    assert re.match('Wohin führt der Protest in der Pandemie\? In Thüringen*', result['description'])
    assert result['duration'] == 1691
    assert result['timestamp'] == 1613948400

# Generated at 2022-06-24 13:59:22.507090
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert ie.url == 'https://www.zdf.de/dokumentation/planet-e'
    assert ie.channel_id == 'planet-e'

# Generated at 2022-06-24 13:59:24.686362
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')



# Generated at 2022-06-24 13:59:28.247531
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() != 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() != 'ZDF'



# Generated at 2022-06-24 13:59:37.213719
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    IE = ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi')
    assert IE.url_result('https://www.zdf.de/filme/taunuskrimi/taunuskrimi-die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html', 'ZDFIE') is not None
    assert IE.url_result('https://www.zdf.de/filme/die-wunderwelt-der-tiere/die-wunderwelt-der-tiere-katzen-wolfskinder-und-co-100.html', 'ZDFIE') is not None

# Generated at 2022-06-24 13:59:41.621124
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    c = ZDFChannelIE()
    try_get(c, lambda x: x.extract(
        'https://www.zdf.de/dokumentation/planet-e'), dict)

# Generated at 2022-06-24 13:59:53.052050
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .zdf import ZDFIE
    from .ooyala import OoyalaIE
    from .ard import ARDIE
    from .br import BRMediathekIE
    from .arte import ArteTvIE

# Generated at 2022-06-24 13:59:54.458171
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zie = ZDFBaseIE()
    assert zie


# Generated at 2022-06-24 13:59:58.270705
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Basic object test, check if constructor throws an exception with generic
    # self values.
    expected_test_values = {
        "test_url": "http://www.zdf.de/ZDFmediathek/beitrag/video/2055500/",
        "test_title": "test_title"
    }
    ZDFBaseIE(expected_test_values)



# Generated at 2022-06-24 13:59:59.872575
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfBaseIE = ZDFIE()
    assert zdfBaseIE != None

# Generated at 2022-06-24 14:00:01.909648
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(InfoExtractor)
    assert isinstance(ie, InfoExtractor)
