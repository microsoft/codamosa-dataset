

# Generated at 2022-06-24 13:50:06.729690
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie.url == 'https://www.zdf.de/filme/taunuskrimi/'


# Generated at 2022-06-24 13:50:08.038350
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
  ie = ZDFBaseIE()
  assert ie is not None


# Generated at 2022-06-24 13:50:08.434857
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass


# Generated at 2022-06-24 13:50:13.692823
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None)
    eq_(ie._GEO_COUNTRIES, ['DE'])
    eq_(ie._QUALITIES, ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))

# Unit tests for method _call_api of class ZDFBaseIE

# Generated at 2022-06-24 13:50:19.333632
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()._call_api('', '', 'hello')
    assert callable(ZDFBaseIE()._extract_subtitles)
    assert callable(ZDFBaseIE()._extract_format)
    assert callable(ZDFBaseIE()._extract_ptmd)
    assert callable(ZDFBaseIE()._extract_player)
# /Unit test for constructor of class ZDFBaseIE


# Generated at 2022-06-24 13:50:23.356029
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Simple test for constructor of class ZDFBaseIE
    """
    zdf_base_ie = ZDFBaseIE()
    assert isinstance(zdf_base_ie.geo_countries, list)
    assert not zdf_base_ie.geo_countries



# Generated at 2022-06-24 13:50:27.260681
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:37.229231
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Channel:
    #   https://www.zdf.de/dokumentation/planet-e
    #   https://www.zdf.de/sport/das-aktuelle-sportstudio
    ie = ZDFChannelIE()
    assert cap(ie) is False
    assert len(ie._TESTS) == 2
    assert ie._TESTS[1]['url'] == \
        'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    # assert ie._TESTS[0]['url'] == \
    #     'https://www.zdf.de/dokumentation/planet-e'
    assert ie._TESTS[1]['playlist_mincount'] == 23
    # assert ie._TESTS[0

# Generated at 2022-06-24 13:50:39.482048
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannelie = ZDFChannelIE()
    zdfchannelie.suitable("https://www.zdf.de/dokumentation/planet-e")

# Generated at 2022-06-24 13:50:44.748735
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(ZDFIE.ie_key() == "zdf")
    assert(ZDFIE.ie_key() != "youtube")

# Test of extractor "ZDFIE", including test of its constructor.
# For the unit test of class ZDFIE, the extractor is accessed as an instance of
# class InfoExtractor and the test is executed.

# Generated at 2022-06-24 13:50:47.348542
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    i = ZDFBaseIE()
    assert i.ie_key() == 'zdf'
    assert i.ie_key() != 'test'


# Generated at 2022-06-24 13:50:57.529632
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import requests
    import requests_mock

# Generated at 2022-06-24 13:51:00.430297
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()

    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:06.016669
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    instance = ie._call_api('http://www.zdf.de/interessantes', 'dummy_video_id', 'dummy_item', 'dummy_api_token', 'dummy_referrer')
    assert isinstance(instance, dict), 'Failed to return a dictionary'



# Generated at 2022-06-24 13:51:09.725842
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    IE = ZDFBaseIE()
    assert IE._GEO_COUNTRIES == ['DE']
    assert IE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:17.380630
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:51:21.649181
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:32.689658
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Here we test that the constructor of class ZDFChannelIE is correct.
    # This is important as the information extracted from the webpage
    # and the real link to download the video is only found out by
    # the constructor.
    obj = ZDFChannelIE()

    # First we put some known urls of videos that belongs to class ZDFChannelIE.
    urls = [
        'https://www.zdf.de/sport/das-aktuelle-sportstudio',
        'https://www.zdf.de/dokumentation/planet-e'
    ]

    # Here we check if the urls match the known regex and also if the right
    # class is selected.
    for url in urls:
        assert obj.suitable(url)
        assert obj.ie_key() == 'ZDFChannel'

# Generated at 2022-06-24 13:51:33.985866
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbaseIE = ZDFBaseIE()
    assert isinstance(zdfbaseIE, InfoExtractor)


# Generated at 2022-06-24 13:51:36.302828
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test method constructor of class ZDFBaseIE."""
    pass



# Generated at 2022-06-24 13:51:37.616741
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass


# Generated at 2022-06-24 13:51:46.638024
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'

    try_get_json = ZDFChannelIE.try_get_json
    try_get_json_value = ZDFChannelIE.try_get_json_value
    progress_hooks = []
    try:
        _, _, _ = ZDFChannelIE._download_json(url, '', '', '', '', '',
                                              '')
    except Exception as ex:
        assert False, ('_download_json', url, '', '', '', str(ex),
                       progress_hooks)

    try_get_json_value.cache_clear()
    try_get_json.cache_clear()



# Generated at 2022-06-24 13:51:48.406849
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(ZDFChannelIE._VALID_URL, {})


# Generated at 2022-06-24 13:51:51.015628
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE("test_ZDFBaseIE", "mock_webpage", "mock_video_id")
    assert inst != None


# Generated at 2022-06-24 13:51:55.297343
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.extract('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')

test_ZDFIE()
# End of Unit test for constructor of class ZDFIE


# Generated at 2022-06-24 13:51:56.281129
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    _ = ZDFBaseIE('ZDFBaseIE')
# Test ends



# Generated at 2022-06-24 13:51:57.330548
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:52:03.722686
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE({})
    assert ZDFIE({'_GEO_COUNTRIES': ['AT']})

    zdf_ie = ZDFIE({'geo_countries': ['AT']})
    assert zdf_ie._GEO_COUNTRIES == ['AT']



# Generated at 2022-06-24 13:52:08.341963
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zd = ZDFIE()
    assert zd._GEO_COUNTRIES == ['DE']
    assert zd._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'


# Generated at 2022-06-24 13:52:10.931790
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # instance of class ZDFIE
    instance = ZDFIE()
    assert isinstance(instance, ZDFIE)


# Generated at 2022-06-24 13:52:14.189950
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBase = ZDFBaseIE(InfoExtractor())
    assert zdfBase.q is not None
    assert zdfBase.q.formats is not None
    assert zdfBase.q.qualities is not None


# Generated at 2022-06-24 13:52:15.900406
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()



# Generated at 2022-06-24 13:52:19.099559
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.IE_NAME == 'zdf'
    assert ie.IE_DESC == 'ZDF'
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:52:28.481879
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    def _test_ZDFBaseIE_helper(countries, expected):
        ie = type('TestZDFBaseIE', (ZDFBaseIE,), {
            '_GEO_COUNTRIES': countries,
        })
        assert ie._GEO_COUNTRIES == expected
    # no argument
    _test_ZDFBaseIE_helper([], ['DE'])
    # not a list
    _test_ZDFBaseIE_helper('DE', ['DE'])
    # contains tuples
    _test_ZDFBaseIE_helper(['DE'], ['DE'])



# Generated at 2022-06-24 13:52:30.393284
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    testInst = ZDFBaseIE()

    # Can be instantiated
    assert(testInst is not None)

# Generated at 2022-06-24 13:52:31.710080
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie is not None


# Generated at 2022-06-24 13:52:34.110960
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannel = ZDFChannelIE()
    assert ZDFChannel._VALID_URL == "https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)"



# Generated at 2022-06-24 13:52:38.529391
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    import ytdl
    ytdl.youtube_dl = __import__('youtube_dl')
    ie = ZDFIE()
    ie.download = True
    ie.test()

# Generated at 2022-06-24 13:52:42.043114
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'



# Generated at 2022-06-24 13:52:43.973199
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.SUCCESS == True


# Generated at 2022-06-24 13:52:44.965588
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

# Generated at 2022-06-24 13:52:47.640035
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    #TODO
    assert False

# Unit test:
# Download HTML content of given URL, extract some information,
# and print to stdout

# Generated at 2022-06-24 13:52:51.346461
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE', 'zdf.de')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:52:55.444355
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test on class constructor
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(ZDFIE)

    extractor = ydl.info_extractors.get(ZDFIE.ie_key())
    assert(extractor)
    assert(isinstance(extractor, ZDFIE))

# Generated at 2022-06-24 13:53:05.422226
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    expected = 'https://api.zdf.de/content/documents/das-aktuelle-sportstudio.json'

    ins = ZDFChannelIE()
    assert ins._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

    assert ins.suitable(url)
    assert ins.construct_request(url) == expected


# Generated at 2022-06-24 13:53:09.566759
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for constructor of class ZDFChannelIE
    """
    url = "https://www.zdf.de/geschichte/zdf-history/zdf-history-uebersichtsseite-100.html"
    ZDFChannelIE(url)



# Generated at 2022-06-24 13:53:11.426610
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()


# Generated at 2022-06-24 13:53:13.797169
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL is not None
    assert zdfie._TESTS is not None


# Generated at 2022-06-24 13:53:20.115362
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Extractor for zdf.de, zdf_neo.de, zdfmediathek.de and tivi.de
# Your consumer_token will be revoked by zdf.de at any time
# See https://api.zdf.de/docs/oauth/

# Generated at 2022-06-24 13:53:27.027672
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdfIE._GEO_COUNTRIES == ['DE']
    assert zdfIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:53:35.480660
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    object = ZDFIE('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert object._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'


# Generated at 2022-06-24 13:53:47.557044
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = "https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html"
    class_for_test = ZDFIE()
    player = class_for_test._extract_player(webpage, video_id, fatal=False)
    content = class_for_test._call_api(player['content'], video_id, 'content', player['apiToken'], url)
    info = class_for_test._extract_entry(player['content'], player, content, video_id)
    assert info['id'] == '151025_magie_farben2_tex'
    assert info['ext'] == 'mp4'

# Generated at 2022-06-24 13:53:49.575157
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from pytube import YouTube
    YouTube('https://www.zdf.de/dokumentation/planet-e')

# Generated at 2022-06-24 13:53:50.615690
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:53:53.210487
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Create instance
    constructor = globals().get('ZDFChannelIE')
    if not isinstance(constructor, type):
        return
    instance = constructor()

    # Check compatibility
    assert 'zdf.de' in instance.compat_urls

# Generated at 2022-06-24 13:54:00.234886
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.name == 'zdf:channel'
    assert ie.__class__ == ZDFChannelIE
    assert ie.info_dict == None
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 13:54:05.125499
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj.DEFAULT_HEADERS == {}
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# -------------------------------------------------------------------------


# Generated at 2022-06-24 13:54:08.947846
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Input: url
    # Output: ZDFIE object
    ZDFIE('http://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')


# Generated at 2022-06-24 13:54:14.752548
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/') is False
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e') is True
    assert ZDFChannelIE.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html') is False

# Generated at 2022-06-24 13:54:20.259311
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    lo = lambda x: 'https://www.zdf.de/dokumentation/%s/' % x
    assert ZDFChannelIE.suitable(lo('taunuskrimi'))
    assert ZDFChannelIE.suitable(lo('taunuskrimi/'))
    assert ZDFChannelIE.suitable(lo('taunuskrimi/taunuskrimi-uebersichtsseite-weitere-folgen-von-taunuskrimi-100.html'))
    assert not ZDFChannelIE.suitable(ZDFIE._VALID_URL)


# Generated at 2022-06-24 13:54:22.976508
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    o = ZDFBaseIE()
    assert o._GEO_COUNTRIES == ['DE']



# Generated at 2022-06-24 13:54:24.124979
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-24 13:54:34.196640
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    info_extractor = ZDFIE()
    assert info_extractor._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert info_extractor._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert info_extractor._TESTS[1]['url'] == 'https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html'

# Generated at 2022-06-24 13:54:38.192741
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = 'url'
    ie = ZDFBaseIE(url)
    assert ie.url == url
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:41.097391
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zc = ZDFChannelIE();
    assert zc.suitable('https://www.zdf.de/dokumentation') == False;
    assert zc.suitable('https://www.zdf.de/dokumentation/planet-e') == True;

# Generated at 2022-06-24 13:54:44.928278
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/politik/frontal-21')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/politik/frontal-21/das-aktuelle-sportstudio')

# Generated at 2022-06-24 13:54:49.925556
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:54:59.313331
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import os
    import sys

    _CWD = os.getcwd()
    # change CWD to util directory
    os.chdir(os.path.join(os.path.dirname(__file__), os.pardir, 'utils'))
    # add utils directory to import search path
    sys.path.insert(0, os.getcwd())

    import extractor

    # import ZDFBaseIE in extractor and get the class
    ZDFBaseIE_class = getattr(extractor, 'ZDFBaseIE')

    assert ZDFBaseIE_class

    # create and instance of ZDFBaseIE
    ZDFBaseIE_instance = ZDFBaseIE_class()

    assert ZDFBaseIE_instance

    # Test the class and instance variable

# Generated at 2022-06-24 13:55:04.054153
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('http://www.zdf.de/ZDFmediathek/kanaluebersicht/aktuellste/beitrag?id=d0e0ea12-09e7-4127-9dd9-f2c0cde3a2f2', {
        'apiToken': 'abcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabc',
    })

# Generated at 2022-06-24 13:55:06.215080
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
        assert False, 'Should raise an exception'
    except TypeError:
        pass



# Generated at 2022-06-24 13:55:17.197413
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBaseIE = ZDFBaseIE('ZDFBaseIE', 'http://example.com')
    # Test _call_api method
    example_api_token = 'TestAPIToken'
    assert(zdfBaseIE._call_api(
        'TestJSON', 'TestVideoID', 'TestJSONDownloading',
        api_token=example_api_token, referrer='TestReferrer') == {'TestJSON': 'TestJSON'})
    # Test _extract_subtitles method

# Generated at 2022-06-24 13:55:18.800569
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:55:30.943181
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    site = ZDFChannelIE()._get_site(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio',
        'STATIC')
    assert site == Site.ZDF
    site = ZDFChannelIE()._get_site(
        'https://www.zdf.de/dokumentation/planet-e',
        'STATIC')
    assert site == Site.ZDF
    site = ZDFChannelIE()._get_site(
        'https://www.zdf.de/politik/frontal-21',
        'STATIC')
    assert site == Site.ZDF

# Generated at 2022-06-24 13:55:38.983488
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():

    ie = ZDFBaseIE('http://www.zdf.de/ZDFmediathek/hauptnavigation/startseite#/beitrag/video/290022/Die-schnsten-Momente-des-ZDF-Fernsehgarten-2017')

    print(ie._call_api('https://api.zdf.de/content/documents/zdf_de-mediathek_de.json', '', 'categories'))



# Generated at 2022-06-24 13:55:41.842127
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    i = ZDFBaseIE()
    assert i != None

# Generated at 2022-06-24 13:55:46.126805
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Make sure the code of ZDFChannelIE is executed
    # by using keyword argument 'ie'
    ZDFChannelIE(ie=ZDFIE.ie_key())('https://www.zdf.de/sport/das-aktuelle-sportstudio')



# Generated at 2022-06-24 13:55:55.137939
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.ie_can_extract('https://www.zdf.de/politik/frontal-21/frontal-21-vom-6-oktober-2020-100.html') == True
    assert ZDFIE.ie_can_extract('https://www.zdf.de/politik/frontal-21/frontal-21-vom-6-oktober-2020-100.html?ref=suche') == True
    assert ZDFIE.ie_can_extract('https://www.zdf.de/politik/zdf-spezial/impfen-aber-wie-100.html') == True

# Generated at 2022-06-24 13:55:58.495459
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_name() == 'ZDF: Der Zweite Deutsche Fernsehsender'



# Generated at 2022-06-24 13:56:01.651109
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie is not None
    assert hasattr(ie, '_GEO_COUNTRIES')
    assert hasattr(ie, '_QUALITIES')


# Generated at 2022-06-24 13:56:03.737729
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBase_instance = ZDFBaseIE()
    assert isinstance(ZDFBase_instance, ZDFBaseIE)

# Generated at 2022-06-24 13:56:07.482186
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    s = "-"*100+"\n"
    s += "Unit test for constructor of class ZDFBaseIE\n"

    # call the constructor of the class
    zdfb = ZDFBaseIE()

    s += "-"*100+"\n"
    # return the information
    return s


# Generated at 2022-06-24 13:56:13.223739
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url_zdf_base_ie = 'https://www.zdf.de/comedy/neo-magazin-mit-jan-boehmermann-100.html'
    headers = {
        'Api-Auth': 'Bearer %s' % 'video_id',
        'Referer': '%s' % 'video_id',
    }
    return ZDFBaseIE()._download_json(
        url_zdf_base_ie, 'video_id', 'Downloading JSON %s' % 'video_id', headers=headers)


# Generated at 2022-06-24 13:56:16.847753
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    obj = ZDFIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:22.020639
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert isinstance(zdf_channel_ie, ZDFChannelIE)
    assert zdf_channel_ie != ZDFChannelIE
    assert zdf_channel_ie.name != ZDFChannelIE
    assert zdf_channel_ie.description != ZDFChannelIE


# Generated at 2022-06-24 13:56:29.393259
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/nachrichten/heute-journal/heute-journal-aktuell-100.html'
    ie = ZDFIE()
    assert (ie.suitable(url) == True)
    assert (ZDFChannelIE.suitable(url) == False)
    assert (ZDFIE.suitable(url) == True)



# Generated at 2022-06-24 13:56:31.336087
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Lazy test: just check that ZDFBaseIE doesn't fail when constructed
    ZDFBaseIE()


# Generated at 2022-06-24 13:56:39.216414
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = '1234567890'
    url = 'https://www.zdf.de/mediathek/video/1234567890'
    ie = ZDFBaseIE(video_id=video_id, url=url)
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie._call_api('url', video_id, 'item') is not None
    assert ZDFBaseIE._extract_subtitles({'captions': [{'uri': 'https://example.com'}]})['deu'] == [{'url': 'https://example.com'}]
    formats = []
    format_urls = set()

# Generated at 2022-06-24 13:56:40.957311
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    pass

ZDFMediathekChannelIE = ZDFChannelIE



# Generated at 2022-06-24 13:56:45.353648
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor with an expected argument
    ie_base = ZDFBaseIE(ZDFBaseIE._GEO_COUNTRIES)
    assert ie_base._GEO_COUNTRIES == ZDFBaseIE._GEO_COUNTRIES


# Generated at 2022-06-24 13:56:56.006006
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('test')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie._call_api('https://www.example.com/search.json', 'test', 'Search') == ['https://www.example.com/search.json', 'test', 'Downloading JSON Search', {}]
    uri = 'https://www.example.com/subtitle.vtt'
    subtitle = ie._extract_subtitles({
        'captions': [
            {
                'language': 'eng',
                'uri': uri,
            }
        ]
    })
    assert len(subtitle) == 1
    assert subtitle['eng'][0]['url'] == ur

# Generated at 2022-06-24 13:56:56.944560
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # TODO: test
    pass



# Generated at 2022-06-24 13:57:09.911734
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    obj = ZDFIE()

# Generated at 2022-06-24 13:57:13.669871
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    ie = ZDFIE()
    ie.extract(url)



# Generated at 2022-06-24 13:57:14.600414
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()

# Generated at 2022-06-24 13:57:24.701811
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
	test_video_id = 'SXV1'

# Generated at 2022-06-24 13:57:28.095406
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        ZDFChannelIE()
    except:
        print("FAILED: Couldn't create an instance of channel extractor")
        exit(2)
test_ZDFChannelIE()



# Generated at 2022-06-24 13:57:28.723904
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # TODO: write this test
    pass



# Generated at 2022-06-24 13:57:31.611590
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:57:35.805700
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert('ZDF IE' in zdf.IE_NAME)
    assert(zdf.ie_key() == 'zdf')
    assert(zdf.IE_DESC == 'ZDF and 3sat')
    assert('DE' in zdf._GEO_COUNTRIES)
    assert(len(zdf._QUALITIES) == 6)



# Generated at 2022-06-24 13:57:46.200725
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import sys
    if sys.version_info < (3, 0):
        from unittest import TestCase
    else:
        from unittest import TestCase, mock
        from io import StringIO, BytesIO

    class MockZDFIE(ZDFBaseIE):

        @classmethod
        def _download_webpage(cls, *args, **kwargs):
            return """<!DOCTYPE html><html><body><h1>Do you want to be happy?</h1></body></html>""";

    # Test if ZDFBaseIE extractor was properly initialized
    TestCase.assertEqual(MockZDFIE._GEO_COUNTRIES, ['DE'])

# Generated at 2022-06-24 13:57:53.463089
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(ZDFIE(None)._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html')
    assert(ZDFIE(None)._TESTS[2]['info_dict']['title'] == 'Die Magie der Farben (2/2)')
    assert(ZDFIE(None)._TESTS[1]['info_dict']['title'] == 'Ab 18! - 10 Wochen Sommer')


# Generated at 2022-06-24 13:58:03.415843
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    (instance, error) = construct_IE(ZDFIE)
    assert error is None
    assert instance.ie_key() == 'ZDF'
    assert instance.ie_key() == 'ZDFBase'
    assert instance.ie_key() == 'ZDFBaseIE'
    assert instance.ie_key() == 'InfoExtractor'
    assert instance.ie_key() == 'compat_str'
    assert instance.ie_key() == 'urljoin'
    assert instance.ie_key() == 'compat_str'
    assert instance.ie_key() == 'InfoExtractor'
    assert instance.ie_key() == 'compat_str'
    assert instance.ie_key() == 'InfoExtractor'
    assert instance.ie_key() == 'urljoin'

# Generated at 2022-06-24 13:58:04.321280
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:58:06.593304
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Check isinstance of class ZDFBaseIE
    assert isinstance(ZDFBaseIE(), ZDFBaseIE)



# Generated at 2022-06-24 13:58:11.946223
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert (ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/planet-e/") == True)
    assert (ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/doku-atlas/der-nullpunkt-der-menschheit-100.html") == False)

# Generated at 2022-06-24 13:58:15.353936
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test for '_GEO_COUNTRIES' variable
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']



# Generated at 2022-06-24 13:58:17.720715
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    info = ZDFChannelIE("https://www.zdf.de/dokumentation/planet-e")
    info.result()


# Generated at 2022-06-24 13:58:21.990226
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Number of country codes
    assert len(ZDFBaseIE._GEO_COUNTRIES) > 0
    # Enumerate for loop for _QUALITIES
    for item in ZDFBaseIE._QUALITIES:
        assert isinstance(item, compat_str)


# Generated at 2022-06-24 13:58:24.233423
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(ZDFChannelIE.ie_key(), ZDFChannelIE._VALID_URL)

# Generated at 2022-06-24 13:58:30.532280
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = 'http://www.zdf.de/ZDFmediathek/beitrag/video/2880566/Heute-Xpress#/beitrag/video/2880566/Heute-Xpress'
    ie = ZDFBaseIE()
    info = ie.extract(url)
    assert('2880566' in info['id'])
    assert('http' in info['formats'][0]['format_id'])
    assert('deu' in info['subtitles']['deu'][0]['url'])
    assert(info['duration'] == 92)



# Generated at 2022-06-24 13:58:34.443983
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE('ZDFBase')

    assert zdf_base_ie.SUCCESS == 0
    assert zdf_base_ie.FAILED == -1


# Generated at 2022-06-24 13:58:35.826667
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test that no exception is raised
    ZDFIE()


# Generated at 2022-06-24 13:58:38.000003
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    i = ZDFBaseIE()
    assert i._GEO_COUNTRIES == ['DE']
    assert i._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:58:45.632084
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.utils import urlopen

    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    webpage = urlopen(url).read().decode('utf-8')
    player = ZDFChannelIE._extract_player(webpage, url, fatal=False)

    channel_id = ZDFChannelIE._search_regex(
        r'docId\s*:\s*(["\'])(?P<id>(?!\1).+?)\1', webpage,
        'channel id', group='id')


# Generated at 2022-06-24 13:58:57.916810
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdf_ie._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert zdf_ie._GEO_COUNTRIES == ['DE']
    assert zdf_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdf_ie._TESTS[0]['info_dict']['title'] == 'Wohin führt der Protest in der Pandemie?'

# Generated at 2022-06-24 13:59:08.926251
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:59:14.450207
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Test method to test the constructor of class ZDFBaseIE.
    """
    ie = ZDFBaseIE('ZDFBaseIE')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:59:18.404509
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE(None)
    assert obj.geo_countries == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:59:26.549458
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    Test whether the initialization of the class is correct
    """
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == set(['DE'])
    assert zdfie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdfie._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert zdfie._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert zdfie._

# Generated at 2022-06-24 13:59:27.467362
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('zdf', 'DE')

# Generated at 2022-06-24 13:59:28.950061
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(ZDFIE.ie_key() == 'zdf')



# Generated at 2022-06-24 13:59:30.911817
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert isinstance(ZDFBaseIE(None), InfoExtractor)


# Generated at 2022-06-24 13:59:31.571204
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()



# Generated at 2022-06-24 13:59:33.781885
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert(ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'))

# Generated at 2022-06-24 13:59:35.605445
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-24 13:59:37.015429
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase = ZDFBaseIE()
    assert zdfbase


# Generated at 2022-06-24 13:59:38.854905
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE.__base__.__init__()


# Generated at 2022-06-24 13:59:43.467534
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('zdft.videothek', lambda x: x)
    test = ie._call_api('www.zdf.de', '1337', 'ptmd')
    assert test == None
    return


# Generated at 2022-06-24 13:59:52.722543
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf.geo_verification_headers() == {'Accept': '*/*',
                                             'Accept-Language': 'de-DE,de;q=0.8,en-US;q=0.6,en;q=0.4',
                                             'Referer': 'https://www.zdf.de/',
                                             'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36'}


# Generated at 2022-06-24 13:59:59.492815
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    name = ZDFChannelIE.ie_key()
    url = 'https://www.zdf.de/dokumentation/planet-e'
    # Standard usage
    ie = ZDFChannelIE()
    assert ie.name == name
    assert ie.suitable(url)
    # Constructor with name
    ie = ZDFChannelIE(name)
    assert ie.name == name
    assert ie.suitable(url)
    # Constructor with name and module
    module = 'test_module'
    ie = ZDFChannelIE(name, module)
    assert ie.name == name
    assert ie.suitable(url)
    # Constructor with instance
    ie2 = ZDFChannelIE()
    ie = ZDFChannelIE(ie2)
    assert ie.name == name
    assert ie.suitable(url)

# Generated at 2022-06-24 14:00:01.145489
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.json.loads()
    
    