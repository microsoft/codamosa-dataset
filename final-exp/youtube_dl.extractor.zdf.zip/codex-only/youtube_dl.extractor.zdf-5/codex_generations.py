

# Generated at 2022-06-24 13:50:03.010429
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(smuggle_url('https://www.zdf.de/filme/taunuskrimi/'))

# Generated at 2022-06-24 13:50:13.124504
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    class_ = ZDFIE()
    class_._TESTS = []
    class_._TESTS.append({
        'url': 'https://www.zdf.de/politik/frontal-21/u-boot-skandal-im-tiefen-staat-100.html',
    })
    class_._downloader = None
    class_._download_webpage = None
    class_._extract_regular(class_._TESTS[0]['url'], {
        'content': 'https://www.zdf.de/politik/frontal-21/video/',
        'apiToken': 'some_token',
    }, 'some_id')

# This test verifies that ZDFIE extracts all available subtitles

# Generated at 2022-06-24 13:50:16.721652
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie.extract() == None


# Generated at 2022-06-24 13:50:20.145684
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES
    assert zdf._QUALITIES
    assert zdf._extract_subtitles({}) == {}


# Generated at 2022-06-24 13:50:23.402578
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert instance._GEO_COUNTRIES == ['DE']
    assert instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:31.520551
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    check_ZDFIE = ZDFIE()
    assert check_ZDFIE._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:50:39.098511
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    print("Test ZDF Base IE")
    ie = ZDFBaseIE('zdf')
    ie._call_api('http://example.com', 'test', 'a')
    ie._extract_format({'formats': []}, set(), 'test', {'url': ''})
    ie._extract_ptmd('https://example.com', 'test', 'a', 'b')
    ie._extract_player("""
    data-zdfplayer-jsb="{
        data:'test'
    }"
    """, 'test')
    print("Successfully executed ZDF Base IE")



# Generated at 2022-06-24 13:50:40.098792
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE



# Generated at 2022-06-24 13:50:41.565302
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()
    ZDFBaseIE()


# Generated at 2022-06-24 13:50:51.985478
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Mock downloads with the expected result
    def download_webpage(self, url, **kwargs):
        webpage = compat_urllib_request.urlopen(url).read().decode('utf-8')
        # Clean up the webpage
        webpage = webpage.replace('[','')
        webpage = webpage.replace(']','')
        return webpage

    ZDFChannelIE_class = ZDFChannelIE()
    ZDFChannelIE_class.download_webpage = download_webpage.__get__(ZDFChannelIE_class,ZDFChannelIE)
    # Check result
    assert(ZDFChannelIE_class._real_extract('https://www.zdf.de/dokumentation/planet-e')['id'] == 'planet-e')

# Generated at 2022-06-24 13:51:01.196300
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class DummyChannel(ZDFChannelIE):
        _TEST = {
            'url': 'https://www.zdf.de/sport/das-aktuelle-sportstudio',
            'playlist_mincount': 0,
        }
        def _real_extract(self, url):
            return super(DummyChannel, self)._real_extract(url)

    dummy_channel = DummyChannel()
    dummy_channel._real_initialize(dummy_channel._TEST['url'])
    re_match = dummy_channel._match_id(dummy_channel._TEST['url'])
    assert re_match == 'das-aktuelle-sportstudio'


# Generated at 2022-06-24 13:51:06.124810
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE('ZDFIE')
    assert zdfie.GEO_COUNTRIES == ['DE']
    assert zdfie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:07.730336
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:51:11.099866
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:23.666645
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable(
        'https://www.zdf.de/politik/standpunkte/standpunkte-uebersicht-100.html')
    ie = ZDFChannelIE('https://www.zdf.de/politik/standpunkte')
    assert ie.suitable('https://www.zdf.de/politik/standpunkte/standpunkte-uebersicht-100.html')
    assert not ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not ie.suitable('https://www.zdf.de/filme/taunuskrimi/')


# Generated at 2022-06-24 13:51:30.706308
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Run extractor on all test cases from ZDFChannelIE.
    """
    from .test_downloads import _check_extractor_on_all_possible_cases
    return _check_extractor_on_all_possible_cases(ZDFChannelIE, [
        'https://www.zdf.de/sport/das-aktuelle-sportstudio',
        'https://www.zdf.de/dokumentation/planet-e',
    ])



# Generated at 2022-06-24 13:51:31.300127
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert True

# Generated at 2022-06-24 13:51:40.904691
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()

    assert isinstance(zdfie,InfoExtractor)
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert len(zdfie._TESTS) == 13
    assert zdfie.ie_key() == 'ZDF'
    print("Unit test for ZDFIE is successful!")


# Generated at 2022-06-24 13:51:42.171885
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()


# Generated at 2022-06-24 13:51:43.278604
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from zdfextractor.zdf import zdf_channel
    zdf_channel()

# Generated at 2022-06-24 13:51:52.836640
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class TestZDFChannelIE(ZDFChannelIE):
        def _real_extract(self, url):
            return ZDFChannelIE._real_extract(self, url)

    channel = 'https://www.zdf.de/dokumentation/planet-e'
    ie = TestZDFChannelIE()
    result = ie.suitable(channel)
    assert result is True, 'channel URL is not recognized.'

    info_dict = ie.extract(channel)
    assert info_dict['id'] == 'planet-e', 'channel id is not correct.'
    assert info_dict['title'] == 'planet e.', 'channel title is not correct.'
    assert len(info_dict['entries']) >= 50, 'channel entries are not enough.'


# Generated at 2022-06-24 13:52:03.060806
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    unit_test_ok = True

    # Test with valid URL
    try:
        ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    except:
        unit_test_ok = False
        print('ZDFChannelIE test for valid URL failed')

    # Test with invalid URL
    try:
        ZDFChannelIE('https://www.zdf.de/sport/invalid-url')
    except:
        unit_test_ok = False
        print('ZDFChannelIE test for invalid URL failed')

    if unit_test_ok:
        print('ZDFChannelIE unittest succeeded')



# Generated at 2022-06-24 13:52:07.810090
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi/'

    # Test that ZDFChannel is not suitable for this URL.
    # And it should be suitable for URL of ZDFIE
    assert (not ZDFChannelIE.suitable(url)) and ZDFIE.suitable(url)

# Generated at 2022-06-24 13:52:08.835349
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:52:18.148383
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:52:29.595182
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    a = ZDFChannelIE()
    print (a)
    print (a.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'))
    print (a.suitable('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html'))
    print (a.extract('https://www.zdf.de/sport/das-aktuelle-sportstudio'))
    print (a.extract('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html'))


# Generated at 2022-06-24 13:52:31.017020
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None)


# Generated at 2022-06-24 13:52:33.692014
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(ZDFBaseIE._downloader, ZDFBaseIE._DOWNLOADER_CLS.ZDF_IE_KEY)
    return True


# Generated at 2022-06-24 13:52:42.381614
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:52:53.301767
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test empty object:
    x = ZDFBaseIE()
    assert(x._GEO_COUNTRIES == ['DE'])
    assert(x._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))
    assert(x._call_api("foo1","foo2","foo3") is None)
    assert(ZDFBaseIE._extract_subtitles("foo") is None)
    assert(ZDFBaseIE._extract_format("foo1","foo2",set(),{}) is None)
    assert(ZDFBaseIE._extract_ptmd("foo1","foo2","foo3","foo4") is None)
    assert(ZDFBaseIE._extract_player("foo1","foo2") is None)

# Generated at 2022-06-24 13:52:58.851125
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from ydl.extractor.youtube import YoutubeIE
    m1 = YoutubeIE.suitable
    m2 = ZDFChannelIE.suitable
    ZDFChannelIE.suitable = YoutubeIE.suitable
    YoutubeIE.suitable = lambda x: True

    try:
        m = ZDFChannelIE()
        assert m is not None
    except:
        pass
    finally:
        YoutubeIE.suitable = m1
        ZDFChannelIE.suitable = m2



# Generated at 2022-06-24 13:53:01.332977
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class_ = globals()['ZDFChannelIE']
    instance = class_(None)
    assert instance is not None

# Generated at 2022-06-24 13:53:03.313614
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    iege = ZDFBaseIE()
    assert iege._GEO_COUNTRIES is not None
    assert iege._QUALITIES is not None



# Generated at 2022-06-24 13:53:03.931334
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:53:05.012035
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # check that the constructors of class ZDFBaseIE is actually static
    assert not hasattr(ZDFBaseIE, '__init__')


# Generated at 2022-06-24 13:53:09.952588
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_case = ZDFChannelIE()

    assert test_case.suitable(ZDFChannelIE._VALID_URL)
    assert not test_case.suitable('https://www.zdf.de/logo.html')
    assert not test_case.suitable('https://www.zdf.de/zdfmediathek/logo.html')
    assert not test_case.suitable('https://www.zdf.de/dokumentation/filme-und-serien/logo.html')
    assert not test_case.suitable('https://www.zdf.de/filme-und-serien/logo.html')
    assert not test_case.suitable('https://www.zdf.de/dokumentation/phoenix-sendungen/logo.html')
    assert not test

# Generated at 2022-06-24 13:53:14.193681
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Test whether the constructor of class ZDFChannelIE doesn't raise any
    exception.
    """
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    # self.assertTrue(True)



# Generated at 2022-06-24 13:53:15.542669
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE()
    assert inst is not None



# Generated at 2022-06-24 13:53:18.729661
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    e = ZDFBaseIE()
    assert e._GEO_COUNTRIES == ['DE']
    assert e._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:53:21.524671
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:53:24.990470
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():

    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:53:33.915693
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:53:35.905184
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    zdf.ie_key()
    zdf._VALID_URL
    zdf._TESTS
    zdf._extract_entry
    zdf._extract_regular
    zdf._extract_mobile
    zdf._real_extract


# Generated at 2022-06-24 13:53:37.485443
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert isinstance(ZDFBaseIE(), ZDFBaseIE)


# Generated at 2022-06-24 13:53:40.086602
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert hasattr(ZDFBaseIE, '_call_api')
    assert hasattr(ZDFBaseIE, '_extract_subtitles')
    assert hasattr(ZDFBaseIE, '_extract_format')
    assert hasattr(ZDFBaseIE, '_extract_ptmd')
    assert hasattr(ZDFBaseIE, '_extract_player')



# Generated at 2022-06-24 13:53:52.459072
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from ..compat import compat_urllib_parse
    from ..utils import ExtractorError
    from .zdf_mediathek import ZDFIE
    from ..extractor import gen_extractors_map

    (ZDFIE,) = gen_extractors_map([ZDFIE])

    # match
    ZDFBaseIE._GEO_COUNTRIES = ['AT']
    assert ZDFIE._match_url('http://www.zdf.de/ZDFmediathek/hauptnavigation/startseite#/')
    zdfmediathek_areas = 'http://www.zdf.de/ZDFmediathek/hauptnavigation/startseite#/beitrag/video/2078566/WDR-5-Nachrichtenupdate'

# Generated at 2022-06-24 13:53:53.385088
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE.ie_key() == 'zdf'


# Generated at 2022-06-24 13:53:57.799950
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    IE = ZDFIE()
    assert IE.ie_key() == 'zdf'
    assert IE.ie_key() == 'ZDF'
    assert IE.ie_key() == ZDFIE.ie_key()

# Generated at 2022-06-24 13:54:01.823947
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    zdf._extract_player(
        '<div></div><script>window.getMeta({'
        '"jsb":{"player":{"basename":"141507_13550","priorityList":[{'
        '"formitaeten":[{"type":"application/dash+xml","qualities":[{"quality":"veryhigh","audio":{'
        '"tracks":[{"format":"m4a","language":"deu"}]}}]}]}]}}});</script>',
        '141507_13550')

# Generated at 2022-06-24 13:54:09.814169
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    o = ZDFIE('parse_ZDF')
    assert (o.IE_NAME == 'ZDF')
    assert (o.IE_DESC == 'ZDF')
    assert (o.VALID_URL == 'https?://www\\.zdf\\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\\.html')
    assert (o.IE_KEY == 'ZDF')



# Generated at 2022-06-24 13:54:13.875495
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    # Test raise exception if call _extract_player with webpage is None
    webpage = None
    video_id = '123'
    assert ie._extract_player(webpage, video_id, fatal=False) == {}, '_extract_player with webpage is None should return {}'


# Generated at 2022-06-24 13:54:17.716395
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = 'KanalId@123456'
    url = 'https://www.zdf.de/' + video_id
    ie = ZDFBaseIE(url)
    assert ie._extract_player(url, video_id) == {}



# Generated at 2022-06-24 13:54:22.863619
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None)
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
# end unit test constructor of class ZDFBaseIE


# Generated at 2022-06-24 13:54:29.347361
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE();
    zdfie.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    zdfie.suitable('https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html')
    zdfie.suitable('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')

# Generated at 2022-06-24 13:54:34.775481
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE as ZDF, ZDFIE as ZDF_IE
    from . import YoutubePlaylistIE as YT_PL, YoutubeIE as YT
    YT_PL_IE = YT_PL()
    YT_PL_IE_key = YT_PL_IE.ie_key()
    YT_IE = YT()
    YT_IE_key = YT_IE.ie_key()
    ZDF_PL_IE = ZDF()
    ZDF_PL_IE_key = ZDF_PL_IE.ie_key()
    ZDF_IE = ZDF_IE()
    ZDF_IE_key = ZDF_IE.ie_key()
    ie_list = [YT_PL_IE, YT_IE, ZDF_PL_IE, ZDF_IE]

# Generated at 2022-06-24 13:54:35.608462
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(ZDFIE.ie_key() == 'zdf')


# Generated at 2022-06-24 13:54:42.392880
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Testing a class represented in the website 'https://zdf.de/'
    # The class is 'ZDFBaseIE'
    # We are going to test its constructor
    # In the constructor we have a static defined variable.
    # The static variable is '_GEO_COUNTRIES'
    # We are going to check if it is defined
    # if it is not, the test will fail
    # else the test will pass
    video_id = "h-itv"
    test_ZDFBaseIE_var = ZDFBaseIE._GEO_COUNTRIES
    assert (test_ZDFBaseIE_var != None)
    #print(test_ZDFBaseIE_var)


# Generated at 2022-06-24 13:54:44.586345
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:49.006603
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:50.245390
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(InfoExtractor(None))



# Generated at 2022-06-24 13:54:53.331566
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_output = ZDFBaseIE()

    assert test_output._GEO_COUNTRIES == ['DE']
    assert test_output._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:54:56.660760
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFIE()
    assert ie.get_geo_countries() == ['DE']
    assert ie.get_qualities() == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:05.342256
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:55:06.034105
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    t = ZDFBaseIE()


# Generated at 2022-06-24 13:55:07.123909
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE


# Generated at 2022-06-24 13:55:11.332527
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('ZDFIE')
    assert ie.ie_key() == 'ZDF'
    assert ie.description() == 'ZDF mediathek'
    assert ie.extractor_key() == 'ZDF'


# Generated at 2022-06-24 13:55:12.484133
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert True #TODO

# Generated at 2022-06-24 13:55:18.742877
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Mock the object for class ZDFIE with the help of the module 'mock' (3rd-party)
    mocked_ZDFIE = mock.Mock(wraps=ZDFIE())
    # Verify the value return by function _download_json()
    mocked_ZDFIE.assert_called_once(_download_json)
    # Verify the return value of the function properties() in mocked_ZDFIE
    assert mocked_ZDFIE.properties.return_value == 'ZDF'
# End of unit test


# Generated at 2022-06-24 13:55:19.697578
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()


# Generated at 2022-06-24 13:55:25.184811
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:25.966959
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-24 13:55:33.316709
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    youtube_url = 'https://youtube.com/watch?v=BaW_jenozKc'
    youtu_be_url = 'https://youtu.be/BaW_jenozKc'
    url = 'https://www.zdf.de/'
    # Constructor of class ZDFChannelIE should not dislike well-formed URLs
    ZDFChannelIE._handle_link(url, youtube_url)
    ZDFChannelIE._handle_link(url, youtu_be_url)
    # Constructor of class ZDFChannelIE should return True
    assert ZDFChannelIE.suitable(url) is True

# Generated at 2022-06-24 13:55:41.295892
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ies = list(ZDFChannelIE.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'))
    assert len(ies) == 2
    assert ies[0].IE_NAME == 'ZDF'
    assert ies[1].IE_NAME == 'ZDFChannel'


# Generated at 2022-06-24 13:55:48.852278
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert not ie.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')

# Generated at 2022-06-24 13:55:59.304361
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():

    webpage = 'https://www.zdf.de/dokumentation/planet-e'
    channel_id = 'planet-e'
    channel = 'https://api.zdf.de/content/documents/%s.json' % channel_id
    url = 'https://www.zdf.de/dokumentation/planet-e'

    class ZDFChannelIE(ZDFIE):

        def _download_webpage(self, *args, **kwargs):
            return webpage

    ie = ZDFChannelIE(url)
    assert ie._match_id(url) == channel_id
    assert ie._extract_player(webpage, channel_id)['content'] == channel

    # test for constructor of class ZDFBaseIE
    # make a copy of ZDFChannelIE and rename it to ZDFBaseIE
   

# Generated at 2022-06-24 13:56:10.382851
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE._VALID_URL = 'https://www.zdf.de/filme/logo-startseite-100.html'
    ZDFIE._TESTS = [{'url': 'https://www.zdf.de/filme/logo-startseite-100.html', 'info_dict': {'id': '634872_logo_startseite', 'ext': 'mp4', 'title': 'Logo Startseite', 'description': 'md5:9be9b59a4c19a8e032c1727e2c96d37e', 'duration': 2660, 'timestamp': 1604200800, 'upload_date': '20201107'}, 'params': {'skip_download': True}}]
    ie = ZDFIE()

# Generated at 2022-06-24 13:56:14.640203
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:21.477523
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    s = {}

# Generated at 2022-06-24 13:56:24.610856
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:29.204690
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    zdf = ZDFChannelIE()._real_extract(url)


# Generated at 2022-06-24 13:56:31.233393
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    c = ZDFChannelIE()
    c.init()
    assert c is not None
    return c


# Generated at 2022-06-24 13:56:33.605330
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_extractor = ZDFIE()
    assert zdf_extractor._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-24 13:56:36.567387
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE()
    assert inst._GEO_COUNTRIES == ['DE']
    assert inst._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:37.672796
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()


# Generated at 2022-06-24 13:56:46.401556
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('zdf')
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/') == False
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') == True
    assert ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True



# Generated at 2022-06-24 13:56:49.876110
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:56:58.873670
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:57:10.873748
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # test construction of an instance of class ZDFChannelIE
    html = """
    <html>
    <head></head>
    <body>
        <div class="mainMediaTeaser" data-plusbar-url="https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html">
    </body>
    </html>
    """
    xtest_ZDFChannelIE = ZDFChannelIE()
    # check that the variable 'url' is from the correct type
    assert(isinstance(xtest_ZDFChannelIE, object))
    # check that the variable 'url' is from the correct type
    assert(xtest_ZDFChannelIE.url == None)
    # check that the

# Generated at 2022-06-24 13:57:14.158944
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:57:17.684710
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert(ie.ie_key() == 'zdf')
    assert(ie.GEO_COUNTRIES == ['DE'])
    assert(ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-24 13:57:20.025685
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    constructor_test_base(ZDFBaseIE, module_name="zdf", IE_NAME="ZDFBaseIE")

# test for _extract_ptmd

# Generated at 2022-06-24 13:57:22.618628
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    res = ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert res == False

# Generated at 2022-06-24 13:57:23.918171
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBaseIE = ZDFBaseIE()
    assert zdfBaseIE is not None


# Generated at 2022-06-24 13:57:27.988931
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
# Unit test end


# Generated at 2022-06-24 13:57:36.443547
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    #https://www.zdf.de/dokumentation/planet-e
    #https://www.zdf.de/sport/das-aktuelle-sportstudio
    #https://www.zdf.de/filme/taunuskrimi
    channel_id = "planet-e" # "das aktuelle sportstudio" #"taunuskrimi"
    channel_url = "https://www.zdf.de/dokumentation/%s" % channel_id
    channel_url = "https://www.zdf.de/filme/%s" % channel_id

# Generated at 2022-06-24 13:57:47.556846
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import sys
    import os
    import unittest
    import requests
    import requests_mock
    from json import loads

    if sys.version_info.major < 3:
        raise unittest.SkipTest("ZDF tests require Python 3.0 or later")

    class ZDFBaseIETest(unittest.TestCase):

        def setUp(self):
            self.the_id = '123456789'
            self.the_token = 'dummytoken'
            self.the_referrer = 'http://www.zdf.de/dummy/referrer'

# Generated at 2022-06-24 13:57:48.531232
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:57:57.065047
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # pylint: disable=missing-docstring
    class ZDFIE_ext(ZDFIE):
        def _real_extract(self, url):
            return self._extract_mobile('151025_magie_farben2_tex')
    ie = ZDFIE_ext()
    zdf = ie._extract_mobile('151025_magie_farben2_tex')
    assert zdf.keys() == {
        'id',
        'title',
        'description',
        'duration',
        'timestamp',
        'thumbnails',
        'subtitles',
        'formats',
        'extractor_key'}
    assert isinstance(zdf, dict)



# Generated at 2022-06-24 13:57:59.735600
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:58:02.485827
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None)()


# Generated at 2022-06-24 13:58:11.117346
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('ZDFChannelIE')
    assert ie.ie_key() == 'ZDFChannelIE'
    assert ie.suitable('http://www.zdf.de/filme/taunuskrimi/')
    assert not ie.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')


# Generated at 2022-06-24 13:58:19.049651
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test the module initialization
    # Normal initialization
    myobj = ZDFChannelIE()
    assert myobj != None
    # Initialization with no scrape_info parameter
    myobj2 = ZDFChannelIE('testScrape_url')
    assert myobj2 != None
    # Initialization with invalid scrape_info parameter
    try:
        ZDFChannelIE('notExisting')
        assert False
    except Exception as e:
        assert isinstance(e, ExtractorError)
        pass


# Generated at 2022-06-24 13:58:24.015800
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE._GEO_COUNTRIES = ['DE']
    ZDFBaseIE._QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    # Call to _call_api does not raise an exception
    # Call to _extract_format does not raise an exception
    # Call to _extract_ptmd does not raise an exception
    # Call to _extract_player does not raise an exception



# Generated at 2022-06-24 13:58:24.999936
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()



# Generated at 2022-06-24 13:58:26.302179
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert 'ZDFBaseIE' in globals()


# Generated at 2022-06-24 13:58:38.455341
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
  # Example: 
  #   url = "https://www.zdf.de/news/frontal-21/frontal-21-100.html"
  #   video_id = "frontal-21-100"
  #   player = ZDFIE._extract_player(ZDFIE._download_webpage(url, video_id), video_id)
  #   content = ZDFIE._call_api(player["content"], video_id, "content", api_token=player["apiToken"], referrer=url)
  #   entry = ZDFIE._extract_entry(player["content"], player, content, video_id)
  #   info_dict = ZDFIE._extract_ptmd(entry["url"], video_id, api_token=player["apiToken"], referrer=url)
  pass


# Generated at 2022-06-24 13:58:39.355779
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()



# Generated at 2022-06-24 13:58:42.662376
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Unit test for constructor of class ZDFChannelIE."""
    z = ZDFChannelIE(ZDFChannelIE.ie_key())
    assert z.suitable(ZDFChannelIE._VALID_URL)



# Generated at 2022-06-24 13:58:45.650650
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()
    assert zdf.suitable(ZDFChannelIE._VALID_URL) == True


# Generated at 2022-06-24 13:58:48.305313
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-24 13:58:50.490954
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    with pytest.raises(AttributeError):
        ZDFChannelIE('test', 'base_url')


# Generated at 2022-06-24 13:58:54.458047
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    zdf_channel_ie = ZDFChannelIE()
    if zdf_channel_ie.suitable(url):
        zdf_channel_ie._real_extract(url)

# Generated at 2022-06-24 13:58:55.495106
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE().IE_KEY

# Generated at 2022-06-24 13:58:58.604132
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:59:05.831790
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    class ZDFIE_class(ZDFIE):
        def __init__(self):
            super(ZDFIE, self).__init__()
            self.info_dict = self.extract(url)
    ZDFIE_class()


# Generated at 2022-06-24 13:59:08.677825
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()

    assert ie.IE_NAME == 'zdf'
    assert ie.IE_DESC == 'ZDF Mediathek'



# Generated at 2022-06-24 13:59:14.293925
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_baseie_test_1 = ZDFBaseIE()
    zdf_baseie_test_2 = ZDFBaseIE()
    assert zdf_baseie_test_1 != zdf_baseie_test_2
    assert zdf_baseie_test_1 == zdf_baseie_test_2



# Generated at 2022-06-24 13:59:18.731572
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
# Test case for method _extract_entry()

# Generated at 2022-06-24 13:59:27.638167
# Unit test for constructor of class ZDFIE
def test_ZDFIE():

    # In this test a constructor of a class is tested.
    # Therefore it has to be decorated by '@pytest.fixture'
    # and it has to have a parameter 'request'
    #
    # An object is created without calling it's constructor. This is done
    # by the fixture 'mock.Mock()'. The mocking object is passed to the
    # 'request.cls.new()' call. The mocked object will be passed to the
    # constructor as first parameter. This is the standard behavior of
    # pytest.
    @pytest.fixture(autouse=True)
    def fix(request):
        request.cls.new = partial(
            ZDFIE, mock.Mock(), 'https://zdf.de/')

    # The class to be tested

# Generated at 2022-06-24 13:59:33.606094
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.geo_countries() == ['DE']
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie.ie_key() == 'ZDF'
    assert ie.name() == 'ZDF'


# Generated at 2022-06-24 13:59:45.699204
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    site = 'http://www.zdf.de/ZDFmediathek/beitrag/video/2970338/Das-Erste-in-der-ARD-Mediathek#/beitrag/video/2970338/Das-Erste-in-der-ARD-Mediathek'
    # Constructor of class ZDFBaseIE
    info_extractor = ZDFBaseIE(site)
    # Test private method _call_api, it would return a json object
    api_url = 'https://api.zdf.de/content/documents/zdf/sportschau/fussball/fifa-wm-2018/spielplan-tabelle-frauen-wm?profile=player'

# Generated at 2022-06-24 13:59:56.442653
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/politik/talk-runde/talk-runde-mit-jauch-100.html')
    # Same as https://www.3sat.de/film/spielfilm/der-hauptmann-100.html and https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/filme-sonstige/')

# Generated at 2022-06-24 14:00:00.082489
# Unit test for constructor of class ZDFIE
def test_ZDFIE(): # TODO:
    mainurl = 'https://www.zdf.de/kinder/checker-cannabis-100.html'
    content = {}
    video_id = 'content_id'

    playe = ZDFIE(url=mainurl)._extract_player()
    entry = ZDFIE(url=mainurl)._extract_entry()
    print("constructor for ZDFIE tested")
