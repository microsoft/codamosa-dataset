

# Generated at 2022-06-24 13:50:01.402619
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:50:03.058335
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE({})


# Generated at 2022-06-24 13:50:06.365916
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFBaseIE.ie_key()
    assert ie.ie_key() == InfoExtractor.ie_key()



# Generated at 2022-06-24 13:50:16.634129
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert ie._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert ie._TESTS[0]['info_dict']['id'] == '210222_phx_nachgehakt_corona_protest'

# Generated at 2022-06-24 13:50:21.150552
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_zdf_base_ie = ZDFBaseIE()
    assert test_zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert test_zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:24.653087
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:50:28.338095
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDF = ZDFIE(ZDFBaseIE(), {}, {})
    assert ZDF._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:50:32.164683
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE'], ie._GEO_COUNTRIES
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:40.544665
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # test constructors of the class
    instance = ZDFBaseIE('http://example.com/watch')
    assert(instance._GEO_COUNTRIES == ['DE'])
    assert(instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))
    assert(instance._extract_player('<html></html>', 'videoid') == {})
    assert(instance._extract_ptmd('http://example.com/media/video.xml',
        'videoid', 'token', 'http://referrer.com')['extractor_key'] == ZDFIE.ie_key())

# Test for ZDFBaseIE._call_api()

# Generated at 2022-06-24 13:50:45.120758
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e') == True
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/100.html') == False


# Generated at 2022-06-24 13:50:55.145760
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Create the class
    ZDFChannelIE_class = ZDFChannelIE([])
    # Test case when url is not suitable
    suitable_url_1 = ""
    suitable_url_2 = "http://www.zdf.de/sport/das-aktuelle-sportstudio/test"
    suitable_url_3 = "https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html"
    print("ZDFChannelIE_class.suitable({}) == False:".format(suitable_url_1),
          ZDFChannelIE_class.suitable(suitable_url_1) == False)

# Generated at 2022-06-24 13:51:01.984739
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_id = 'sport'
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    channel_info = {
        'id': channel_id,
        'title': 'das aktuelle sportstudio | ZDF',
    }
    # Test constructor of class ZDFChannelIE
    channel_info_result = ZDFChannelIE.extract_channel_info(url, channel_id)
    # Compare the result of constructor with the expected result
    assert channel_info_result == channel_info



# Generated at 2022-06-24 13:51:12.770398
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert hasattr(ie, '_VALID_URL'), 'VALID_URL should be set'
    assert hasattr(ie, '_TESTS'), 'TESTS should be set'
    assert hasattr(ie, '_GEO_COUNTRIES'), 'GEO_COUNTRIES should be set'
    assert hasattr(ie, '_QUALITIES'), 'QUALITIES should be set'
    assert hasattr(ie, '_call_api'), '_call_api should be set'
    assert hasattr(ie, '_extract_subtitles'), '_extract_subtitles should be set'
    assert hasattr(ie, '_extract_format'), '_extract_format should be set'

# Generated at 2022-06-24 13:51:19.964362
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .ZDFChannelIE import ZDFChannelIE

    assert ZDFChannelIE.suitable(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio') is True

    assert ZDFChannelIE.suitable(
        'https://www.zdf.de/filme/taunuskrimi/') is True


# Generated at 2022-06-24 13:51:21.542889
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfie = ZDFBaseIE(None)


# Generated at 2022-06-24 13:51:24.581792
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # test for constructor (No exception is success)
    ZDFBaseIE(None)


# Generated at 2022-06-24 13:51:25.968137
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()



# Generated at 2022-06-24 13:51:30.877929
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # First, construct the class
    test_obj = ZDFChannelIE()
    # Here we examine the resulting object
    assert "ZDFChannelIE" == test_obj._real_extract("https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html")

# Generated at 2022-06-24 13:51:44.245267
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
	from .zdf import ZDFIE
	from .ooyala import OoyalaIE
	from .mgtv import MgTVIE
	from .iqiyi import IQiyiIE
	from .utils import parse_codecs
	video_id = 'o7yedx'
	webpage = 'http://www.zdf.de/comedy/heute-show/heute-show-vom-15-dezember-2017-100.html'
	# Test for field url_transparent
	assert ZDFBaseIE.url_transparent(webpage) == False
	# Test for method _call_api
	ie = ZDFIE()

# Generated at 2022-06-24 13:51:45.246783
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:51:48.063939
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Usually you would use pytest to run your unit tests. This is just an example.
    a = ZDFBaseIE()
    assert a.player_sources() == None



# Generated at 2022-06-24 13:51:49.538000
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()
    ZDFBaseIE()

# test the ordered set class

# Generated at 2022-06-24 13:51:56.373963
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    channel_id = 'planet-e'
    channel = ZDFChannelIE()

    # Test case 1: test get channel id
    channel_id_got = channel._match_id(url)
    assert channel_id_got == channel_id, \
        'Failed to get channel id.'

    # Test case 2: test get page content
    pageContent_got = channel._download_webpage(url, channel_id).strip()
    assert pageContent_got is not None, \
        'Failed to get page content.'



# Generated at 2022-06-24 13:52:09.356520
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE(
            'https://www.zdf.de/',
            'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html',
            '210222_phx_nachgehakt_corona_protest')
    assert zdfie._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'

# Generated at 2022-06-24 13:52:13.357710
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie = ZDFChannelIE()
    assert ie.suitable(url) is True
    assert ie.ie_key() == 'ZDF'

# Generated at 2022-06-24 13:52:20.583323
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._extract_player(b'test', 'abc', fatal=False) == {}

# Generated at 2022-06-24 13:52:32.272356
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    example_url = 'http://example.com/'
    video_id = '12345'
    item = 'foo'
    ptmd_url = 'http://example.com/foo/bar/baz'

    class ZDFBaseIE_test(ZDFBaseIE):
        def __init__(self, example_url, video_id, item, api_token, ptmd_url):
            self._GEO_COUNTRIES = ['DE']
            self._QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
            self.example_url = example_url
            self.video_id = video_id
            self.item = item
            self.api_token = api_token
            self.ptmd_url = ptmd_url

    _ = ZDFBaseIE_test

# Generated at 2022-06-24 13:52:36.395141
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFIE('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    except Exception as e:
        print("Exception in constructor\n",e)


# Generated at 2022-06-24 13:52:40.452706
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = 'N-b0414'
    webpage = 'https://ly.zdf.de/lX9G7/'
    api_token = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ik9FSTVNVVV3UmtSR1FrRkZPVEkyTkRBM1JqTTJNVVkwTmtRMk5UWkVOdyJ9.eyJodHRwczovL2x5LnpkZi5kZS9zaXRlL2xvZ2luLw'
    format_id = 'http-low-deu'

    # check whether the ZDFBaseIE object can be instantiated
    ZDFBaseIE()

    # check whether the _call_api

# Generated at 2022-06-24 13:52:51.971171
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert TypeError == type(zdf._call_api('http://google.com', '123', 'content'))
    assert TypeError == type(zdf._extract_subtitles({}))
    assert TypeError == type(zdf._extract_format('123', [], [], {}))
    assert TypeError == type(zdf._extract_ptmd('http://google.com', '123', None, None))
    assert TypeError == type(zdf._extract_player('http://google.com', '123'))



# Generated at 2022-06-24 13:52:52.761520
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()

# Generated at 2022-06-24 13:53:04.901246
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ie == ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio/')
    assert isinstance(ie, ZDFChannelIE)
    assert ie._TYPE == 'playlist'
    assert ie._title == 'das aktuelle sportstudio | ZDF'
    assert ie._id == 'das-aktuelle-sportstudio'
    assert ie._is_supported(ie.url) == True
    assert ie._is_supported('https://www.zdf.de/kontakt') == False

# Generated at 2022-06-24 13:53:09.071099
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zchannel = ZDFChannelIE('<html></html>', 'https://www.zdf.de/sport/das-aktuelle-sportstudio')
    import pprint
    entries = zchannel.extract()['entries']
    pprint.pprint(entries)
    return entries

# Generated at 2022-06-24 13:53:20.827170
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:53:26.638235
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == "ZDF"
    assert ie.host() == "www.zdf.de"
    assert ie.extract_url("https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html") == "210222_phx_nachgehakt_corona_protest"


# Generated at 2022-06-24 13:53:28.703206
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    Test constructor of class ZDFIE
    Returns:
        An instance of ZDFIE
    """
    return ZDFIE

# Generated at 2022-06-24 13:53:42.116781
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE()
    z._VALID_URL = 'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'

# Generated at 2022-06-24 13:53:48.765354
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    with open('test/test_data/test_ZDFBaseIE.html', 'r') as test_file:
        webpage = test_file.read()
        test_object = ZDFBaseIE()
        assert test_object._extract_player(webpage, 'video_id', fatal = True)['videoId'] == 'video_id'

# Generated at 2022-06-24 13:53:50.662827
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() in InfoExtractor.get_IE_key_map()


# Generated at 2022-06-24 13:53:55.797127
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        from . import test_utils as test_utils
    except ImportError:
        from .. import test_utils as test_utils

    test_utils.load_and_call_module_function(
        __name__, [('ZDFBaseIE', '__init__', 'ZDFBaseIE')],
        {
            '_GEO_COUNTRIES': ['DE'],
            '_QUALITIES': ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'),
        },
        {'DE': 'DE'}
    )


# Generated at 2022-06-24 13:54:08.226956
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('http://www.zdf.de/filme/taunuskrimi') is True
    assert ZDFChannelIE.suitable('http://www.zdf.de/filme/taunuskrimi/') is True
    assert ZDFChannelIE.suitable('http://www.zdf.de/filme/taunuskrimi/index.html') is True
    assert ZDFChannelIE.suitable('http://www.zdf.de/filme/taunuskrimi/invalid.html') is True
    assert ZDFChannelIE.suitable('http://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') is False
    assert ZDF

# Generated at 2022-06-24 13:54:09.615221
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(ZDFChannelIE.ie_key(), ZDFChannelIE._VALID_URL)

# Generated at 2022-06-24 13:54:10.911088
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
	IE = ZDFIE('', {})


# Generated at 2022-06-24 13:54:19.070420
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Create instance of class ZDFChannelIE
    zdf_channel_ie = ZDFChannelIE()

    assert zdf_channel_ie._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert zdf_channel_ie._TESTS[0]['info_dict']['id'] == 'das-aktuelle-sportstudio'
    assert zdf_channel_ie._TESTS[0]['info_dict']['title'] == 'das aktuelle sportstudio | ZDF'
    assert zdf_channel_ie._TESTS[0]['playlist_mincount'] == 23


# Generated at 2022-06-24 13:54:21.144319
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE_test = ZDFIE(ZDFIE._downloader)


# Generated at 2022-06-24 13:54:23.642539
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._VALID_URL == ZDFIE._VALID_URL
    assert ZDFIE()._TESTS == ZDFIE._TESTS


# Generated at 2022-06-24 13:54:33.804721
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test = ZDFIE(ZDFIE.ie_key(), ZDFIE._VALID_URL)
    assert test._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert test._GEO_COUNTRIES == ['DE']
    assert test._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:54:38.482125
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE('extractor name', 'example.net', 'IE_KEY', 'IE_NAME')

    assert zdf_base_ie.name == 'example.net'
    assert zdf_base_ie._VALID_URL == ZDFBaseIE._VALID_URL
    assert zdf_base_ie._api_token == None


# Generated at 2022-06-24 13:54:41.800672
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert isinstance(ZDFChannelIE(), InfoExtractor)


# Generated at 2022-06-24 13:54:44.445730
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    cls = ZDFChannelIE
    assert cls.suitable(cls._VALID_URL)
    assert not cls.suitable(ZDFIE._VALID_URL)

# Generated at 2022-06-24 13:54:45.567816
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-24 13:54:49.048615
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFIE = ZDFChannelIE()
    assert ZDFIE.suitable('https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-24 13:54:58.401382
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # test valid id
    player = {'apiToken': 'test', 'content': 'test_url'}
    content = {'mainVideoContent': {}}
    player['content'] = content
    content['mainVideoContent'] = {'http://zdf.de/rels/streams/ptmd-template': 'test_ptmd', 'http://zdf.de/rels/streams/ptmd': 'https://test/ptmd'}
    info = ZDFIE._extract_entry(player['content'], player, content, 'test_id')
    assert info['url'] == 'https://test/ptmd'

    player['content'] = content
    content['mainVideoContent'] = {'http://zdf.de/rels/streams/ptmd-template': 'test_ptmd'}
    info = Z

# Generated at 2022-06-24 13:55:00.456235
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        zdf = ZDFIE()
    except Exception as e:
        print(e)
    assert zdf



# Generated at 2022-06-24 13:55:03.462228
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE_instance = ZDFIE()
    if zdfIE_instance.ie_key() != 'ZDF':
        raise AssertionError('Wrong key was returned')
    if zdfIE_instance.ie_key() != 'zdf':
        raise AssertionError('Wrong key was returned')


# Generated at 2022-06-24 13:55:04.876037
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # This test is needed so the ZDFChannelIE constructor is called during unit test run
    return ZDFChannelIE('1')

# Generated at 2022-06-24 13:55:12.209397
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE(ZDFBaseIE._GEO_COUNTRIES, ZDFBaseIE._QUALITIES)
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == []
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:16.233729
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/tatortreiniger'
    instance = ZDFChannelIE.suitable(url)
    assert isinstance(instance, ZDFChannelIE)
    assert instance.ie_key() == 'ZDFChannel'


# Generated at 2022-06-24 13:55:20.624671
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    assert ZDFChannelIE.suitable(url)
    assert ZDFIE.suitable(url) == False
    assert ZDFChannelIE(ZDFChannelIE.ie_key())._real_extract(url)

# Generated at 2022-06-24 13:55:32.593122
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()

# Generated at 2022-06-24 13:55:39.729379
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    assert zdf_channel_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'



# Generated at 2022-06-24 13:55:44.881062
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Check if constructor of class is able to print an error message
    # on wrong JSON input
    try:
        ZDFIE("http://www.zdf.de/ZDFmediathek/hauptnavigation/startseite?flash=off").run(None, "", "", "", "")
        assert False
    except Exception as e:
        assert str(e).startswith("URL was not found in JSON input:\n")



# Generated at 2022-06-24 13:55:49.265538
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('ZDFIE', 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html', 'ZDF', 'DE')


# Generated at 2022-06-24 13:55:52.863723
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    return True


# Generated at 2022-06-24 13:56:00.522147
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        from zdf import ZDFChannelIE, ZDFIE
        assert(ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True)
        assert(ZDFIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == False)
    except Exception as e:
        raise AssertionError("Unit test for ZDFChannelIE fails: " + str(e))


# Generated at 2022-06-24 13:56:02.008625
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Constructor of class ZDFBaseIE
    ZDFBaseIE()


# Generated at 2022-06-24 13:56:04.995718
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # pylint: disable=protected-access
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie._VALID_URL == ZDFChannelIE._VALID_URL



# Generated at 2022-06-24 13:56:06.278646
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie

# Generated at 2022-06-24 13:56:11.075462
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()._real_extract(
        "https://www.zdf.de/filme/taunuskrimi/")
    ZDFChannelIE()._real_extract(
        "https://www.zdf.de/dokumentation/planet-e")



# Generated at 2022-06-24 13:56:22.311277
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Tests of the test_suite from __main__
    request = compat_urllib_request.Request(
        'https://www.zdf.de/dokumentation/planet-e')
    request.add_header('User-Agent', 'Wget/1.17.1 (darwin16.5.0)')
    try:
        response = compat_urllib_request.urlopen(request)
    except (compat_urllib_error.HTTPError, compat_urllib_error.URLError) as err:
        pytest.fail('Downloading webpage failed with error: %s' % str(type(err)))
    else:
        webpage = response.read()

    from . import ZDFChannelIE
    ZDFChannelIE = ZDFChannelIE()
    ZDFChannelIE._real_ext

# Generated at 2022-06-24 13:56:27.311768
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test = ZDFIE()
    assert test._TESTS
    assert test._VALID_URL
    assert test._GEO_COUNTRIES
    assert test.ie_key()


# Generated at 2022-06-24 13:56:37.056329
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test case 1: Channel with only series
    # Same as https://www.zdf.de/filme/taunuskrimi/
    url = 'https://www.zdf.de/filme/taunuskrimi'
    zdf = ZDFChannelIE()
    assert zdf.suitable(url) == True
    zdf_result = zdf.extract(url)
    assert zdf_result['id'] == 'taunuskrimi'
    assert zdf_result['title'] == 'Taunuskrimi'
    assert len(zdf_result['entries']) == 50

    # Test case 2: Channel with only documentaries and live streams
    # Same as https://www.zdf.de/dokumentation/planet-e
    # Note: Due to the live streams, the expected number of entries is

# Generated at 2022-06-24 13:56:48.886381
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:56:55.214251
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instances = [ZDFBaseIE(), ZDFBaseIE()]
    assert instances[0]._GEO_COUNTRIES == ['DE'] and instances[0]._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert instances[1]._GEO_COUNTRIES == ['DE'] and instances[1]._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:58.564625
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase = ZDFBaseIE('ZDFBaseIE')
    # Currently this unit test is empty.
    assert zdfbase.initialize() is None



# Generated at 2022-06-24 13:57:01.605146
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None, 'https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html')


# Generated at 2022-06-24 13:57:02.728810
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase = ZDFBaseIE()

# Generated at 2022-06-24 13:57:04.457093
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    print(instance)



# Generated at 2022-06-24 13:57:10.956685
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        import sys
        if sys.version_info.major < 3:
            raise unittest.SkipTest('Only for python3')
        else:
            exec("sys.modules['zdf'] = sys.modules['zdf_ie']")
        import zdf
        from zdf import ZDFChannelIE
    except (ImportError, KeyError):
        raise unittest.SkipTest('test requires zdf package from '
                                'https://github.com/rg3/youtube-dl/pull/19195')

    x = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert x.suitable('https://www.zdf.de/verbraucher/markt/markt-2021-01-29-100.html')

# Generated at 2022-06-24 13:57:19.118485
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE', {})

    # Example call of _extract_subtitles
    content = {
        'captions': [{
            'uri': '/some-uri/caption.ttml',
            'language': 'deu',
        }]
    }
    subtitles = ie._extract_subtitles(content)
    assert subtitles == {
        'deu': [{
            'url': 'http://www.zdf.de/some-uri/caption.ttml',
        }]
    }

    # Example call of _extract_format
    formats = []
    format_urls = set()

# Generated at 2022-06-24 13:57:25.353103
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e/'
    inst = ZDFChannelIE(url)
    assert inst.suitable(url) == True


# Generated at 2022-06-24 13:57:27.833183
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ins_ZDFIE = ZDFIE('ZDFIE')
    assert ins_ZDFIE.ie_key() == 'ZDF'

# Generated at 2022-06-24 13:57:39.238682
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('channel_url')
    assert ie.suitable('channel_url')
    assert not ie.suitable('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert ie.__class__ == ZDFChannelIE
    assert ie.IE_NAME == 'zdf:channel'
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 13:57:45.080491
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    a = ZDFBaseIE()
    assert(a._call_api('','','',None,None) == None)
    assert(a._extract_subtitles('{}') == {})
    assert(a._extract_format('','','','{}') == None)
    assert(a._extract_ptmd('','','','') == None)
    assert(a._extract_player('','',True) == {})

# Generated at 2022-06-24 13:57:47.320779
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    check_constructor(ZDFChannelIE)
    print('The constructor of ZDFChannelIE passed the unit test.')


# Generated at 2022-06-24 13:57:58.046239
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    if not hasattr(ZDFChannelIE, 'suitable'):
        raise ValueError('ZDFChannelIE.suitable is undefined')
    if not hasattr(ZDFChannelIE, '_real_extract'):
        raise ValueError('ZDFChannelIE._real_extract is undefined')
    if not hasattr(ZDFChannelIE, '_call_api'):
        raise ValueError('ZDFChannelIE._call_api is undefined')

    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    zdf_channel_IE = ZDFChannelIE()
    zdf_channel_IE.suitable(url)
    zdf_channel_IE.get_url(url)



# Generated at 2022-06-24 13:57:59.064381
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie != None

# Generated at 2022-06-24 13:58:03.861349
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_ZDFBaseIE = ZDFBaseIE()
    assert test_ZDFBaseIE
    assert test_ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert test_ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:58:07.252905
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'
    assert ie.ie_key() in ZDFIE.ie_key_map.keys()
    assert ZDFIE.ie_key() == 'zdf'


# Generated at 2022-06-24 13:58:09.064864
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-24 13:58:11.307531
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE is ZDFChannelIE._create_ie_instance({}, {})



# Generated at 2022-06-24 13:58:13.071135
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie



# Generated at 2022-06-24 13:58:17.419380
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base = ZDFBaseIE()
    from ..compat import compat_str
    assert(base._GEO_COUNTRIES == ['DE'])
    assert(base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))



# Generated at 2022-06-24 13:58:20.092209
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    obj = ZDFIE()
    assert obj.IE_NAME == 'zdf'
    assert obj.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:58:29.734269
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable('https://www.zdf.de/filme/die-anrheiner')
    ZDFChannelIE.suitable('http://www.zdf.de/filme/die-anrheiner')
    ZDFChannelIE.suitable('https://www.zdf.de/filme/die-anrheiner.html')
    ZDFChannelIE.suitable('http://www.zdf.de/filme/die-anrheiner.html')
    ZDFChannelIE.suitable('https://www.zdf.de/nachrichten/heute.html')

    # Confirm that this is not a valid channel_id

# Generated at 2022-06-24 13:58:35.789784
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert(hasattr(ZDFBaseIE, "_call_api"))
    assert(hasattr(ZDFBaseIE, "_extract_format"))
    assert(hasattr(ZDFBaseIE, "_extract_ptmd"))
    assert(hasattr(ZDFBaseIE, "_extract_player"))
    assert(hasattr(ZDFBaseIE, "test_ZDFBaseIE"))



# Generated at 2022-06-24 13:58:44.537969
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Build class
    ZDFIE = ZDFIE()

    # Unit test for _extract_player in ZDFIE
    def test_ZDFIE_extract_player(self):
        # no player
        assert(self._extract_player(None, None, fatal=False) == None)
        assert(self._extract_player('{}', None, fatal=False) == {})

        # with player
        player = {
            'apiToken': 'my-api-token',
            'content': 'content-url',
        }
        assert(self._extract_player('{"title": "Video title", "settings": {"player": %s}}' % player, None) == player)

    # Unit test for _extract_entry in ZDFIE

# Generated at 2022-06-24 13:58:46.405194
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from .test_zdf_mediathek import test_ZDFMediathekIE_constructor
    return test_ZDFMediathekIE_constructor('ZDFIE', ZDFIE)

# Module test for class ZDFIE

# Generated at 2022-06-24 13:58:58.519605
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test _call_api
    import json
    from urllib import urlencode
    from urllib2 import Request, urlopen
    from unittest import TestCase
    from urlparse import urlparse

    url = 'https://zdf-cdn.live.cellular.de/mediathekV1/_definst_/smil:zdf/6c12e6e1-eea0-43eb-8c80-b7df39b0b260.smil/playlist.m3u8'
    video_id = '0'
    item = 'Playlist'
    api_token = 'sometoken'
    referrer = 'http://a.b'


# Generated at 2022-06-24 13:59:02.929882
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()

    assert zdf.suitable("https://www.zdf.de/dokumentation/planet-e")
    assert not zdf.suitable("https://www.zdf.de/dokumentation/planet-e.html")
    assert not zdf.suitable("https://www.zdf.de/dokumentation/planet-e/102.html")

# Generated at 2022-06-24 13:59:09.037149
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    s = ZDFIE()
    assert s.ie_key() == 'ZDF'
    assert s._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert s._GEO_COUNTRIES == ['DE']
    assert s._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:59:12.129165
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'
    assert ie.ie_key() in ZDFIE.ie_key_map()


# Generated at 2022-06-24 13:59:23.256303
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    def check_ZDFChannelIE(self, url, channel_id, channel_title):
        # Check the channel_id is not empty
        self.assertTrue(channel_id)
        # Check that the channel id is same as the one in the url
        self.assertEqual(channel_id, self._match_id(url))
        entries = self._real_extract(url)['entries']
        self.assertIsInstance(entries, list)
        # Check there are at least one entry
        self.assertGreaterEqual(len(entries), 1)
        # Check that all the entries are URLs
        self.assertFalse(any(map(lambda x: not x.startswith('https://www.zdf.de'), entries)))
        # Check that the channel_id in the URL is same as the channel id of the channel

# Generated at 2022-06-24 13:59:27.359444
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'
    the_zdfie = ZDFIE()
    assert isinstance(the_zdfie, ZDFIE)
    assert the_zdfie.ie_key() == 'ZDF'
    assert the_zdfie._VALID_URL == ZDFIE._VALID_URL
# end unit test for constructor of class ZDFIE


# Generated at 2022-06-24 13:59:31.164050
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'zdf'
    assert zdfie.ie_key() != '3sat'
    assert zdfie.ie_key() != 'phoenix'


# Generated at 2022-06-24 13:59:42.758402
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zc = ZDFChannelIE()

# Generated at 2022-06-24 13:59:44.746543
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.gen_extractors()
    assert ie.IE_NAME == 'zdf'
    assert ie.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:59:47.470313
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    entry = ZDFBaseIE._call_api('https://www.zdf.de', '1234', 'Test')
    assert entry != None


# Generated at 2022-06-24 13:59:50.628529
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from ..extractor import gen_extractors_by_ie
    ie = gen_extractors_by_ie.ZDFBaseIE
    obj = ie("http://www.abc.com/", {})
    assert obj
    assert obj.url == "http://www.abc.com/"
    assert obj.ie_key() == "ZDFBaseIE"


# Generated at 2022-06-24 13:59:56.705761
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('http://dummy.url')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'


# Generated at 2022-06-24 14:00:02.102120
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.suitable('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert ZDFIE.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert not ZDFIE.suitable('https://test.test/test/test.html')
