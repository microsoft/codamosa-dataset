

# Generated at 2022-06-24 13:50:05.173172
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 13:50:16.110681
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .common_test import _TESTS as COMMON_TESTS

    # Note: The following unit tests are designed to test ZDFChannelIE,
    #       but they are also useful for testing ZDFIE

# Generated at 2022-06-24 13:50:18.372044
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE(None, None, None)
    except Exception:
        assert False, 'Construktor of ZDFBaseIE failed'


# Generated at 2022-06-24 13:50:20.483888
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    n = ZDFIE()
    assert n.name == 'ZDF'


# Generated at 2022-06-24 13:50:22.179473
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
    except:
        assert False
    assert True



# Generated at 2022-06-24 13:50:30.503272
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ins = ZDFIE()
    assert ins._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ins._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert ins._TESTS[0]['info_dict']['id'] == '210222_phx_nachgehakt_corona_protest'
    assert ins._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:50:33.992964
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDF', 'DE', 'http://www.zdf.de/tv')
    assert ie.name == 'ZDF'
    assert ie.geo_countries == ('DE',)
    assert ie.base_url == 'http://www.zdf.de/tv'



# Generated at 2022-06-24 13:50:37.302004
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """creates a simple instance of ZDFIE"""
    from ..compat import compat_str
    ZDFIE = ZDFIE(compat_str("test_zdf_ie"), compat_str("Zdf"))
    return ZDFIE



# Generated at 2022-06-24 13:50:38.435175
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # pylint: disable=pointless-statement
    ZDFIE


# Generated at 2022-06-24 13:50:40.054529
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from ..extractor import YoutubeIE
    assert issubclass(ZDFBaseIE, YoutubeIE)

# Generated at 2022-06-24 13:50:44.144901
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE(None)
    assert zdf.ie_key() == 'ZDF'
    assert zdf.ie_key() == zdf.ie_key()
    assert zdf.ie_key() != '1'


# Generated at 2022-06-24 13:50:53.716316
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    info = {'url': 'https://www.zdf.de/sport/das-aktuelle-sportstudio',
            'id': 'das-aktuelle-sportstudio',
            'title': 'das aktuelle sportstudio | ZDF'}
    
    zdf = ZDFChannelIE()
    
    assert zdf.suitable(info['url'])
    assert zdf._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert zdf._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    
test_ZDFChannelIE()

# Generated at 2022-06-24 13:50:56.277149
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_ie = ZDFBaseIE('url')
    assert zdf_ie != None


# Generated at 2022-06-24 13:51:08.900637
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    #
    # Unit test for _call_api method of class ZDFIE
    #
    response = zdfie._call_api('http://api.zdf.de', '4f736ab4-79b8-41e4-a6c5-1b7c9796c3de', 'content', 'jgfjgfjhgfh', 'http://www.zdf.de')
    assert response['pageType'] == 'news'
    #
    # Unit test for _extract_format method of class ZDFIE
    #
    url, video_id, formats, track_uris = 'http://www.zdf.de', '4f736ab4-79b8-41e4-a6c5-1b7c9796c3de', list

# Generated at 2022-06-24 13:51:20.509173
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE()
    assert ie.suitable(url)
    assert ie.ie_key() == 'ZDF:channel'


# Generated at 2022-06-24 13:51:30.186219
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert ie._TESTS[0]['info_dict']['id'] == 'das-aktuelle-sportstudio'
    assert ie._TESTS[0]['info_dict']['title'] == 'das aktuelle sportstudio | ZDF'
    assert ie._TESTS[0]['playlist_mincount'] == 23

# Generated at 2022-06-24 13:51:44.160707
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:51:47.057174
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    assert ie._TESTS[0]["url"] == ie._VALID_URL

# Generated at 2022-06-24 13:51:48.778076
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """ Test the constructor of class ZDFBaseIE """
    ZDFBaseIE()


# Generated at 2022-06-24 13:51:51.746138
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE._VALID_URL
    ZDFIE._TESTS
    ZDFIE._extract_entry
    ZDFIE._extract_regular
    ZDFIE._extract_mobile


# Generated at 2022-06-24 13:51:55.297469
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    if zdfie.extractor_key == 'ZDF':
        print('Unit test of class ZDFIE(constructor) is completed.')
    else:
        print('Unit test of class ZDFIE(constructor) is failed.')


# Generated at 2022-06-24 13:51:57.211178
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test that all required parameters are present
    assert ZDFIE._VALID_URL
    assert ZDFIE._TESTS
    assert ZDFIE._downloader
    assert ZDFIE._WORKING



# Generated at 2022-06-24 13:52:02.254189
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    unit_test = ZDFBaseIE()
    assert unit_test._GEO_COUNTRIES == ['DE']
    assert unit_test._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:52:04.383540
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()


# Generated at 2022-06-24 13:52:13.538032
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    # Some test case for _extract_player
    player = ie._extract_player('', 'test_id')
    assert player == {}
    # Ugly code but I don't know how to write a test case for _call_api
    # Some test case for _extract_ptmd
    ptmd = ie._extract_ptmd('http://some_url', 'test_id', 'test_token', 'test_referrer')
    assert ptmd['id'] == 'http://some_url'
    assert ptmd['duration'] == 0
    assert ptmd['formats'] == []
    assert ptmd['subtitles'] == {}


# Generated at 2022-06-24 13:52:16.599587
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE()
    channel.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')



# Generated at 2022-06-24 13:52:28.657508
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest

    class ZDFChannelIETest(unittest.TestCase):
        def test_suitable(self):
            self.assertTrue(ZDFChannelIE.suitable("https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html"))
            self.assertTrue(ZDFChannelIE.suitable("https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html"))

# Generated at 2022-06-24 13:52:35.979370
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('') is False
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/') is True
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html') is False
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/') is True

# Generated at 2022-06-24 13:52:37.461340
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None, None)


# Generated at 2022-06-24 13:52:38.442937
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE().ie_key() == "zdf"


# Generated at 2022-06-24 13:52:39.470126
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie


# Generated at 2022-06-24 13:52:51.300928
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Unit test for constructor of class ZDFChannelIE
    """
    url="https://www.zdf.de/dokumentation/planet-e"
    zdfc=ZDFChannelIE(url)
    assert zdfc._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert zdfc.suitable(url)
    zdfc=ZDFChannelIE("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    assert zdfc._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert zdfc.suitable(url)


# Generated at 2022-06-24 13:52:51.886387
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass


# Generated at 2022-06-24 13:52:54.084584
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = 'none'
    webpage = 'none'
    fatal = True
    ZDFBaseIE.ZDFBaseIE(webpage, video_id, fatal)



# Generated at 2022-06-24 13:53:00.165175
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    def _test_api_token(api_token, expected_api_token):
        if expected_api_token is None:
            return
        assert api_token == expected_api_token, \
            'api_token = %r != %r = expected_api_token' % (
                api_token, expected_api_token)

    def constructor_test(expected_token_param, expected_token_value,
                         token_param, token_value=None):
        zdfie = ZDFBaseIE({token_param: token_value})
        _test_api_token(
            zdfie._downloader.params.get(expected_token_param),
            expected_token_value)
    constructor_test('zdf_api_token', None, 'token_param', 'token_value')

# Generated at 2022-06-24 13:53:11.206408
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class FakeFactory:
        class FakeInfoExtractor:
            ie_key = 'fakedummy'

            class FakeResult:
                def __init__(self, url):
                    self.url = url

    ie = ZDFChannelIE()
    ie.ie_key = 'fakedummy'
    ie.ie_factory = FakeFactory()

    entries = ie.entries(ie.url_result('https://www.zdf.de/dokumentation/planet-e', ie.ie_key()))
    assert isinstance(entries, list)
    assert len(entries) > 50
    assert isinstance(entries[0], ZDFChannelIE.FakeFactory.FakeResult)

# Generated at 2022-06-24 13:53:12.908410
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()
    assert zdf == ZDFChannelIE



# Generated at 2022-06-24 13:53:16.188391
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import test_zdf
    obj_test = test_zdf.get_test_instance()
    assert not isinstance(obj_test, ZDFChannelIE)
    obj_test = test_zdf.get_test_instance(ZDFChannelIE)
    assert isinstance(obj_test, ZDFChannelIE)

# Generated at 2022-06-24 13:53:22.984726
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for constructor of class ZDFChannelIE
    """
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    zdf_channel_ie = ZDFChannelIE()
    zdf_channel_ie_suitable = zdf_channel_ie.suitable(url)
    assert zdf_channel_ie_suitable is True
    zdf_channel_ie_result = zdf_channel_ie._real_extract(url)
    # TODO: Implement better test
    for entry in zdf_channel_ie_result['entries']:
        if entry['_type'] == 'url':
            assert entry['ie_key'] == ZDFIE.ie_key()



# Generated at 2022-06-24 13:53:24.243087
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    a = ZDFChannelIE('url', 'a', 'b')
    assert isinstance(a, ZDFBaseIE)


# Generated at 2022-06-24 13:53:29.917285
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import time
    from . import ZDFChannelIE as _class

    curtime = time.time()
    self = _class()
    self.suitable('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-mächtigen-100.html')
    self.suitable('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-mächtigen-100.html?asdfasdf')

    # self.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    # self._extract_mobile('b1e859a9-3f13-4834-b

# Generated at 2022-06-24 13:53:37.386426
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert isinstance(zdf._GEO_COUNTRIES, list)
    assert isinstance(zdf._QUALITIES, tuple)
    assert zdf.ie_key() == 'zdf:base'



# Generated at 2022-06-24 13:53:49.528406
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # by default, a new instance is returned
    ie = ZDFChannelIE().suitable('https://www.zdf.de/')
    assert ie == False
    ie = ZDFChannelIE().suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert ie == True
    ie = ZDFChannelIE().suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert ie == False
    ie = ZDFChannelIE().suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ie == True

# Generated at 2022-06-24 13:53:58.504794
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:54:01.982973
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannel_ie = ZDFChannelIE()
    assert zdfchannel_ie.suitable("https://www.zdf.de/dokumentation/planet-e")
    assert not zdfchannel_ie.suitable("https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html")


# Generated at 2022-06-24 13:54:11.919005
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # NOTE: This test depends on the data in domain api.zdf.de.
    # If the data changes, this test is expected to fail.
    ie = ZDFChannelIE()
    r = ie._call_api(
        'https://api.zdf.de/content/documents/das-aktuelle-sportstudio.json',
        ie._extract_player('', 'https://www.zdf.de/sport/das-aktuelle-sportstudio'),
        'https://www.zdf.de/sport/das-aktuelle-sportstudio',
        'das-aktuelle-sportstudio')
    assert r


# Generated at 2022-06-24 13:54:15.387175
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(object());


# Generated at 2022-06-24 13:54:22.731867
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    When passing an URL to the constructor of the class ZDFChannelIE,
    it should detect whether the URL is from zdf.de and build a
    ZDFChannelIE object with that.
    The object should be able to extract the ID as well.
    """
    for url in ['https://www.zdf.de/sport/das-aktuelle-sportstudio', 'https://www.zdf.de/dokumentation/planet-e',
                'https://www.zdf.de/filme/taunuskrimi']:
        obj = ZDFChannelIE.suitable(url)
        assert obj, 'URL {} should be supported by ZDFChannelIE'.format(url)

        zdfchannel = obj(url)

# Generated at 2022-06-24 13:54:33.153566
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    class_name = ie.__class__.__name__
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert ie._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'

# Generated at 2022-06-24 13:54:34.477272
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test the constructor of ZDFChannelIE class
    ZDFChannelIE()

# Generated at 2022-06-24 13:54:39.736928
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for constructor of class ZDFChannelIE.

    """
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie is not None
    assert ZDFChannelIE.suitable('https://www.zdf.de/politik/heute-journal')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/politik/fragen-der-woche')


# Generated at 2022-06-24 13:54:50.713177
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    a = ZDFChannelIE()
    assert a._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 13:54:52.404822
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase = ZDFBaseIE(InfoExtractor())
    assert zdfbase != None


# Generated at 2022-06-24 13:54:55.254247
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel = ZDFChannelIE()
    assert zdf_channel.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')



# Generated at 2022-06-24 13:54:59.020468
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    t = ZDFIE()
    assert t.suitable('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert not t.suitable('https://www.zdf.de/kultur/zdfkultur/leute-heute/leute-heute-vom-22-april-2016-100.html')



# Generated at 2022-06-24 13:55:03.776430
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('https://www.zdf.de/politik/wahl-2019/deutschland-trend/deutschland-trend-zur-bundestagswahl-2019-waehlen-sie-zu-haus-100.html')
    assert ie.extractor_key == 'ZDFIE'
    assert ie.ie_key() == 'ZDFIE'


# Generated at 2022-06-24 13:55:05.077279
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE


# Generated at 2022-06-24 13:55:06.329855
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    instance = InfoExtractor()
    instance = ZDFBaseIE()


# Generated at 2022-06-24 13:55:07.258020
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:55:17.973106
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class TestZDFIE(ZDFBaseIE):
        _VALID_URL = 'http://www.zdf.de/ZDFmediathek/beitrag/video/2489690/Sport-im-Ostseebad#/beitrag/video/2489690/Sport-im-Ostseebad'

# Generated at 2022-06-24 13:55:18.618920
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    pass

# Generated at 2022-06-24 13:55:30.773460
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # starts with first test of class ZDFChannelIE
    # tests are reading from left to right
    ie = ZDFChannelIE('test', True)
    # parameter url tested in test_ZDFIE.py

    # parameter ie_key tested in test_ZDFChannelIE
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    # test _TESTS see below

    # test _extract_player
    msg = ie._extract_player('http://www.zdf.de/', "", "")
    assert msg == '{}'

    # test _real_extract

# Generated at 2022-06-24 13:55:35.761806
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()

    assert zdf.IE_NAME == 'zdf'
    assert zdf.IE_DESC == 'ZDF'
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:38.676341
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """ test for ZDFBaseIE.__init__() """
    ZDFBaseIE(InfoExtractor())



# Generated at 2022-06-24 13:55:51.198579
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.IE_NAME == 'zdf'
    assert zdfie.GEO_COUNTRIES == ['DE']
    assert zdfie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdfie.VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdfie.API_BASE == 'https://api.zdf.de/'
    assert zdfie.API_URL == 'https://api.zdf.de/%s'
    assert zdfie.APP_ID == 'ngplayer_2_4'
    assert zdfie.SUMMARY_CACHE

# Generated at 2022-06-24 13:55:56.983149
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.player_re == re.compile(r'(?s)data-zdfplayer-jsb=(["\'])(?P<json>{.+?})\1')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:59.595180
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert isinstance(ie, ZDFIE)
    assert isinstance(ie, ZDFBaseIE)

# Generated at 2022-06-24 13:56:06.369023
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    video_url = 'https://www.zdf.de/dokumentation/planet-e'
    item_url = 'https://www.zdf.de/dokumentation/planet-e/100.html'
    webpage = ie._download_webpage(video_url, 'planet-e')
    m = ie._search_regex(r'data-plusbar-url=["\'](http.+?\.html)', webpage, 'data-plusbar-url')
    assert m == item_url

# Generated at 2022-06-24 13:56:10.795161
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:56:22.021366
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:56:22.646955
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    pass


# Generated at 2022-06-24 13:56:27.624910
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import base
    with base.mock.patch('sys.stdout.write') as mock_stdout:
        ie = ZDFBaseIE()
        assert ie._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-24 13:56:32.128788
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_const = ZDFChannelIE()
    assert zdf_channel_const._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\Z(?![?#])'
    return True


# Generated at 2022-06-24 13:56:34.773203
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE()._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 13:56:38.581616
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert ZDFIE.ie_key() == 'zdf'


# Generated at 2022-06-24 13:56:50.464922
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_case = {
        'url': 'https://www.zdf.de/stichtag-des-tages/zdf-baut-ein-neues-hauptstadtstudio-in-berlin-100.html',
        'info_dict': {
            'id': '180427_stgt_zdf-baut-ein-neues-hauptstadtstudio-in-berlin',
            'ext': 'mp4',
            'title': 'ZDF baut ein neues Hauptstadtstudio in Berlin',
            'description': 'md5:cbec56b22fa43804dd07e824e4a9484f',
            'duration': 78,
            'timestamp': 1535914800,
            'upload_date': '20180903',
        },
    }

# Generated at 2022-06-24 13:56:52.065827
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbasie_obj = ZDFBaseIE()
    assert zdfbasie_obj is not None


# Generated at 2022-06-24 13:56:56.448788
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    ZDFChannelIE.__init__(zdf_channel_ie)
    assert zdf_channel_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 13:57:01.316611
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Entry point for unit tests.
    """
    from tests.test_downloader import FakeDownloader
    downloader = FakeDownloader()

# Generated at 2022-06-24 13:57:05.818096
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = 'zdf_video_id'
    player_json = 'player_json'
    ZDFBaseIE()._extract_player(player_json, video_id)

test_ZDFBaseIE.func_annotations = {}



# Generated at 2022-06-24 13:57:13.440487
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .extractor import gen_extractors_by_class
    config = {}
    extractors = gen_extractors_by_class(ZDFChannelIE, config)
    assert len(extractors) == 1
    assert 'https://www.zdf.de/filme/taunuskrimi' not in extractors
    assert 'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html' in extractors

# Generated at 2022-06-24 13:57:18.582288
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_ie = ZDFChannelIE()
    assert channel_ie.suitable(ZDFChannelIE._VALID_URL)
    assert channel_ie.suitable(ZDFIE._VALID_URL) is False
    assert channel_ie._real_extract(ZDFChannelIE._TESTS[0]['url'])



# Generated at 2022-06-24 13:57:20.339125
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    obj = ZDFIE()
    assert isinstance(obj, ZDFIE)

# Generated at 2022-06-24 13:57:24.592681
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:57:29.974181
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import unittest

    class TestZDFBaseIE(unittest.TestCase):
        def test_constructor_without_any_arguments(self):
            instance = ZDFBaseIE()
            self.assertEqual(instance._GEO_COUNTRIES, ['DE'])
            self.assertEqual(instance._QUALITIES, ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))

        def test_constructor_with_invalid_geo_countries(self):
            self.assertRaises(AssertionError, ZDFBaseIE, geo_countries=None)
            self.assertRaises(AssertionError, ZDFBaseIE, geo_countries='DE')

# Generated at 2022-06-24 13:57:33.980262
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(ZDFIE().extract('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html') is not None)



# Generated at 2022-06-24 13:57:35.344738
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
  ZDFBase_test = ZDFBaseIE(None, None)


# Generated at 2022-06-24 13:57:45.959201
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()

    channel_id = 'das-aktuelle-sportstudio'
    channel_url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'

    # Test video url
    video_url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio/aspern-sieg-nicht-zufall-100.html'

    # Test video id
    video_id = '100216_dasaktuellesportstudio_aspernsieg4_d'

    # Test invalid url

# Generated at 2022-06-24 13:57:49.658767
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import logging
    logger = logging.getLogger(__name__)
    channelIE = ZDFChannelIE(logger)

    logger.info('Testing %s' % repr(channelIE))
    channelIE('https://www.zdf.de/politik/report-mainz')

# Generated at 2022-06-24 13:57:52.232352
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()._real_extract('https://www.zdf.de/sport/das-aktuelle-sportstudio')

# Generated at 2022-06-24 13:58:02.273978
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE()
    print(ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'))
    print(zdfChannelIE._real_extract('https://www.zdf.de/sport/das-aktuelle-sportstudio'))
    print(ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio/ludovic-orban-steht-wieder-allein-an-der-spitze-der-pnl-100.html'))

# Generated at 2022-06-24 13:58:05.701028
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')


# Generated at 2022-06-24 13:58:07.304980
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.__name__ == 'ZDFIE'

# Generated at 2022-06-24 13:58:19.633685
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE
    assert ie.suitable(url="https://www.zdf.de/dokumentation/planet-e")
    assert not ie.suitable(url="https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html")
    assert not ie.suitable(url="https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html")
    assert ie.suitable(url="https://www.zdf.de/filme/taunuskrimi/")

# Generated at 2022-06-24 13:58:29.446314
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE().ie_key() == 'zdf'
    assert ZDFIE()._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ZDFIE()._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert ZDFIE()._TESTS[1]['url'] == 'https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html'

# Generated at 2022-06-24 13:58:41.133733
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi')
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/index.html')
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi?parameter=1')
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/index.html?parameter=1')

# Generated at 2022-06-24 13:58:44.604895
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    for t in ie._TESTS:
        assert t['md5'] =='34ec321e7eb34231fd88616c65c92db0'
    return ie


# Generated at 2022-06-24 13:58:49.904171
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Use the same set of test URLs for both classes
    for test_dict in ZDFIE._TESTS:
        url = test_dict['url']
        video_id = ZDFIE._match_id(url)
        upload_date = test_dict.get('upload_date')
        title = test_dict.get('title')
        description = test_dict.get('description')
        duration = test_dict.get('duration')
        timestamp = test_dict.get('timestamp')
        zdf_ie = ZDFIE(url)
        zdf_ie.video_id = video_id

        video = zdf_ie._extract_mobile(video_id)

        assert(upload_date == video['upload_date'])
        assert(title == video['title'])

# Generated at 2022-06-24 13:58:53.302233
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE().suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')
    pass

# Generated at 2022-06-24 13:58:54.629554
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:58:59.980469
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('http://www.zdf.de/ZDFmediathek/kanaluebersicht/aktuellste/21460340?flash=off')
    assert ie is not None
    assert ie.ie_key() == 'ZDF'
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:59:06.887256
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    i = ZDFChannelIE()
    assert i.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not i.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not i.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert not i.suitable('https://www.zdf.de/sendungen/wiso/wiso-vorsorge-geld-fuer-kinder-100.html')


# Generated at 2022-06-24 13:59:10.989959
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:59:13.337324
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfie = ZDFBaseIE()
    zdfie._call_api('https://zdf.de', '', 'something')


# Generated at 2022-06-24 13:59:16.821875
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    constructor = getattr(
        sys.modules[__name__],ZDFChannelIE.__name__).__init__
    assert constructor == ZDFBaseIE.__init__


# Generated at 2022-06-24 13:59:18.786451
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base_ie = ZDFBaseIE()
    assert type(base_ie) == ZDFBaseIE



# Generated at 2022-06-24 13:59:20.027457
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass



# Generated at 2022-06-24 13:59:21.828662
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Just testing if raw ZDFBaseIE is defined
    assert 'ZDFBaseIE' in globals()

# Generated at 2022-06-24 13:59:23.554158
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .zdf import ZDFIE
    instance = ZDFBaseIE(ZDFIE)
    assert isinstance(instance, ZDFBaseIE)


# Generated at 2022-06-24 13:59:33.473338
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
   

# Generated at 2022-06-24 13:59:39.334866
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Basic test to make sure a few methods are working as expected.
    """
    ie = ZDFBaseIE()
    assert ie._extract_ptmd("https://www.zdf.de/somemedia", "somemedia_id", None, None) == None
    assert ie._extract_player("https://www.zdf.de/somemedia", "somemedia_id") == {}

# Generated at 2022-06-24 13:59:51.166382
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    i = ZDFChannelIE()
    assert i.suitable("https://www.zdf.de/")
    assert i.suitable("https://www.zdf.de/video/")
    assert i.suitable("https://www.zdf.de/comedy/heute-show")
    assert i.suitable("https://www.zdf.de/politik/das-aktuelle-sportstudio")
    assert not i.suitable("https://www.zdf.de/dokumentation/planet-e/scheepers-traumschiff-der-weltreise-102.html")

# Generated at 2022-06-24 13:59:59.096356
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannel = ZDFChannelIE('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html', 'ZDFChannelIE')
    assert zdfchannel.name == 'zdf'
    assert zdfchannel.title == 'zdf'
    assert zdfchannel.description == 'zdf'
    assert zdfchannel.ie_key() == 'ZDFChannelIE'
    assert zdfchannel.ie_key() == 'ZDFChannelIE'
    assert zdfchannel.thumbnail == 're:^https?://.*'

# Generated at 2022-06-24 14:00:04.646864
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE.ie_key() == 'zdf'
    assert ZDFBaseIE.ie_key() == 'ZDF'
    assert ZDFBaseIE.ie_key() == 'Zdf'
    assert ZDFBaseIE.ie_key() == 'zDF'
    assert ZDFBaseIE.ie_key() == 'ZDFIE'
    assert ZDFBaseIE.ie_key() == 'ZDFie'
