

# Generated at 2022-06-24 13:50:04.785059
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE()
    assert zdf_base._GEO_COUNTRIES == ['DE']
    assert zdf_base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:06.504587
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 13:50:17.463828
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert len(ie._TESTS) == 8
    assert ie._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert ie._TESTS[0]['info_dict']['id'] == '210222_phx_nachgehakt_corona_protest'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:50:27.337568
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = 'https://www.zdf.de/comedy/sturm-der-liebe/folge-2325-helene-und-co-freuten-sich-auf-den-zweiten-hochzeitstag-100.html'
    video_id = 'https://api.zdf.de/content/documents/zdf-mam/video/2325@video'
    # Test constructor of class ZDFBaseIE
    ie = ZDFBaseIE()
    assert ie._call_api(url, video_id, 'api_token') is not None

# Generated at 2022-06-24 13:50:33.760174
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    inst = ZDFChannelIE()
    assert inst.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not inst.suitable('https://www.zdf.de/dokumentation/planet-e.html')
    assert not inst.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio/video-corona-und-der-sport-wie-geht-es-weiter-100.html')

# Generated at 2022-06-24 13:50:42.465515
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    info_extractor = ZDFIE()

# Generated at 2022-06-24 13:50:46.328149
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        doc = globals()[ZDFIE.__name__]
        assert(doc == "ZDFIE")
    except:
        print("ZDFIE class is not found.")

# Generated at 2022-06-24 13:50:49.489298
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:51.655286
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:50:52.825669
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    print(ie)
    assert ie


# Generated at 2022-06-24 13:50:57.348668
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class ZDFBaseIE_Test(ZDFBaseIE):
        def test_suite(self):
            return 'test'
    zdfbaseie_instance = ZDFBaseIE_Test()
    assert zdfbaseie_instance.test_suite() == 'test'


# Generated at 2022-06-24 13:50:58.602088
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:50:59.739032
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()


# Generated at 2022-06-24 13:51:00.707582
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    temp = ZDFIE(5)

# Generated at 2022-06-24 13:51:11.975863
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_html import get_testdata

    entries = ZDFChannelIE()._real_extract(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio')['entries']

    assert entries[0]['id'] == '5f25417a-6428-4eee-9f9a-0b8fc727d8c2'
    assert entries[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio/sport-kompakt-vom-16-01-2021-100.html'
    assert entries[0]['title'] == 'Sport kompakt vom 16.01.2021'

# Generated at 2022-06-24 13:51:12.817861
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(None) == None


# Generated at 2022-06-24 13:51:15.338580
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    class_test = ZDFIE()
    assert(class_test)


# Generated at 2022-06-24 13:51:26.913446
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Silent log output
    logging.getLogger('youtube_dl').setLevel(logging.CRITICAL)
    zdf_channel_ie = ZDFChannelIE()
    # Accessing this private function using function name
    # We need to build a string of the start of the function and access it
    # e.g. if we have a function named func(), func is stored in __name__
    # and we can do zdf_channel_ie.__name__ to obtain function func
    # and we can add parameters to obtain function func(arg1, arg2)
    # which is the constructor for ZDFChannelIE
    # For example:
    # Accessing private class variable _VALID_URL of ZDFChannelIE class
    # zdf_channel_ie._VALID_URL
    # is the same as accessing the the variable outside of the class


# Generated at 2022-06-24 13:51:27.900386
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:51:31.326255
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    q = qualities(['verylow', 'low', 'med', 'high', 'veryhigh'])
    assert q('high') == 90
    assert q('veryhigh') == 100
    assert q('wtf') is None
    assert q(None) is None



# Generated at 2022-06-24 13:51:31.874872
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

# Generated at 2022-06-24 13:51:38.674956
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio.html')



# Generated at 2022-06-24 13:51:42.447587
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:46.974527
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Unit test constructor of class ZDFChannelIE"""
    ie = ZDFChannelIE()
    assert ie.ie_key() == 'ZDF:channel'
    assert ie.SUITABLE_URL.match(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ie.SUITABLE_URL.match('https://www.zdf.de/filme/taunuskrimi/')
    assert ie.SUITABLE_URL.match('https://www.zdf.de/politik/panorama')


# Generated at 2022-06-24 13:51:51.842359
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
        assert ZDFIE.suitable(url)
        assert ZDFChannelIE.suitable(url)
        ZDFChannelIE(ZDFChannelIE.ie_key())
        assert not ZDFIE(ZDFIE.ie_key()).suitable(url)
    except AssertionError:
        raise Exception('Unit test of constructor of class ZDFChannelIE failed.')



# Generated at 2022-06-24 13:51:52.866328
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE() is not None


# Generated at 2022-06-24 13:52:04.701704
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_ZDFIE = True
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    zdf_ie = ZDFIE()
    zdf_ie._match_id(url)
    zdf_ie._real_extract(url)
    zdf_ie._download_webpage('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html', '210222_phx_nachgehakt_corona_protest', fatal=False)

# Generated at 2022-06-24 13:52:07.244009
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test = ZDFIE()
    assert test != None

if __name__ == '__main__':
    test_ZDFIE()

# Generated at 2022-06-24 13:52:17.031149
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():

    channel_urls = [
        'https://www.zdf.de/dokumentation/planet-e',
        'https://www.zdf.de/sport/das-aktuelle-sportstudio',
        'https://www.zdf.de/filme/taunuskrimi/'
    ]

    for channel_url in channel_urls:

        ZDFChannelIE.suitable(channel_url)

        ie = ZDFChannelIE(channel_url);

        # Test to find suitable video id.
        assert ie.suitable(channel_url) is True
        assert ie.video_id is None

        # Test to execute real_extract() method.
        ie.real_extract()

        # Test to execute real_extract() method with an invalid URL.

# Generated at 2022-06-24 13:52:17.968540
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE is not None


# Generated at 2022-06-24 13:52:20.129715
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Confirm that the constructor of the class runs without errors
    zdf = ZDFBaseIE()


# Generated at 2022-06-24 13:52:21.416043
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()

# Generated at 2022-06-24 13:52:25.689615
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Mock an instance of ZDFBaseIE.
    base = ZDFBaseIE()
    # Use assertTrue to test whether it is an instance or not.
    assert isinstance(base, ZDFBaseIE)


# Generated at 2022-06-24 13:52:26.442077
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

# Generated at 2022-06-24 13:52:37.226242
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    for module in (ZDFIE, ZDFChannelIE):
        assert(module.suitable(VALID_URL_1)) == (module == ZDFIE)
        assert(module.suitable(VALID_URL_2)) == (module == ZDFIE)
        assert(module.suitable(VALID_URL_3)) == (module == ZDFIE)
        assert(module.suitable(VALID_URL_4)) == (module == ZDFIE)
        assert(module.suitable(VALID_URL_5)) == (module == ZDFIE)
        assert(module.suitable(VALID_URL_6)) == (module == ZDFIE)
        assert(module.suitable(VALID_URL_7)) == (module == ZDFIE)

# Generated at 2022-06-24 13:52:39.273568
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFIE()
    except:
        assert False, 'Failed to create ZDFIE'

if __name__ == '__main__':
    test_ZDFIE()

# Generated at 2022-06-24 13:52:40.908692
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._call_api("https://api.zdf.de/content/documents/zdf/419872", "419872", "meta", "123")

# Generated at 2022-06-24 13:52:52.846979
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .common import fake_http_server
    from json import loads
    from youtube_dl.utils import unescapeHTML

    server = fake_http_server(lambda x: None)
    server.start()


# Generated at 2022-06-24 13:52:53.370978
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()

# Generated at 2022-06-24 13:52:58.512593
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/taunuskrimi-episodenliste-100.html')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/serien/taunuskrimi/')

# Generated at 2022-06-24 13:53:01.895433
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.__class__.__name__ == ZDFIE.__name__
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == ZDFIE.ie_key()



# Generated at 2022-06-24 13:53:04.487134
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE()

    assert zdf_base._GEO_COUNTRIES == ['DE']
    assert zdf_base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:53:07.234998
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .unit.test_iedata import test_bed_base_iedata_constructor
    test_bed_base_iedata_constructor(ZDFChannelIE)


# Generated at 2022-06-24 13:53:14.920702
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Check that ZDFBaseIE detects a ZDF webpage
    assert ZDFBaseIE._is_zdf(
        {'ie_key': 'ZDF'},
        'https://www.zdf.de/politik/frontal-21/frontal-21-vom-5-5-2020-100.html',
    )
    # Check that ZDFBaseIE does *not* detect a non-ZDF webpage
    assert not ZDFBaseIE._is_zdf(
        {'ie_key': 'ZDF'},
        'https://example.com/',
    )



# Generated at 2022-06-24 13:53:15.668167
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass


# Generated at 2022-06-24 13:53:21.200594
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_cases = (
            # test case 1: check the default value of instance variable _QUALITIES
            lambda self: self.assertEqual(
                ZDFIE._QUALITIES, ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
            ),
            # test case 2: check the default value of instance variable _GEO_COUNTRIES
            lambda self: self.assertEqual(
                ZDFIE._GEO_COUNTRIES, ['DE']
            ),
    )
    for test_case in test_cases:
        test_case(unittest.TestCase())

# Generated at 2022-06-24 13:53:24.991934
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfie = ZDFBaseIE('ZDFBaseIE', 'zdf.de')
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:53:33.867773
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:53:35.681330
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:53:37.314587
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import doctest
    doctest.testmod()
# FIXME: Add unit test

# Generated at 2022-06-24 13:53:39.520368
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # test qualities
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:53:43.614643
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE()
    assert ie.suitable(url) == True
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.ie_key == 'ZDFChannel'


# Generated at 2022-06-24 13:53:47.194180
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('ZDFIE', 'www.zdf.de', 'DE')



# Generated at 2022-06-24 13:53:57.313429
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    video_id = 'something'
    url = 'https://www.zdf.de/something.html'
    webpage = '<html></html>'
    player = {
        'content': 'https://zdf-cdn.live.cellular.de/mediathekV2/document/something',
        'apiToken': 'Bearer something',
    }

# Generated at 2022-06-24 13:54:04.282667
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_ie = ZDFChannelIE()
    assert channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/') == True
    assert channel_ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html') == False


# Generated at 2022-06-24 13:54:10.706427
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    importer = importlib.import_module('..zdf', __name__)
    class_name = 'ZDFChannelIE'
    class_constructor = getattr(importer, class_name)
    assert class_constructor is ZDFChannelIE
    print("Successfully tested constructor of class %s" % class_name)

test_ZDFChannelIE()

# Generated at 2022-06-24 13:54:16.641275
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'zdf'
    assert zdfie.name() == 'ZDF'


# Generated at 2022-06-24 13:54:19.309366
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from_url = ZDFIE.from_url
    zdfie = from_url(test_ZDFIE.__doc__)
    assert zdfie.__class__ == ZDFIE
    # assert zdfie._search_regex is ZDFIE._search_regex

# Generated at 2022-06-24 13:54:27.234820
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # case 1
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    _suitable = ZDFChannelIE.suitable(url)
    assert _suitable == False

    # case 2
    url = 'https://www.zdf.de/dokumentation/planet-e'
    _suitable = ZDFChannelIE.suitable(url)
    assert _suitable == True

    # case 3
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    _suitable = ZDFChannelIE.suitable(url)
    assert _suitable == True

# Generated at 2022-06-24 13:54:28.406911
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-24 13:54:29.775383
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.to_screen('test output')

# Generated at 2022-06-24 13:54:34.648954
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
	# These are tests for the init function in the ZDFBaseIE class
  obj = ZDFBaseIE()
  assert(obj._GEO_COUNTRIES == ['DE'])
  assert(obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-24 13:54:39.326980
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for constructor of class ZDFChannelIE
    """
    urls = [
        "https://www.zdf.de/dokumentation",
        "https://www.zdf.de/sport/heute-im-stadium"
    ]
    for url in urls:
        print(url)
        ZDFChannelIE(url)



# Generated at 2022-06-24 13:54:50.713300
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_url = 'http://test/test/test_url'
    test_video_id = 'test_video_id'
    test_item = 'test_item'
    test_api_token = 'test_api_token'
    test_referrer = 'test_referrer'
    test_headers = {'Api-Auth': 'Bearer %s' % test_api_token}
    test_download_json = 'downloaded_json'

    zdfbase = ZDFBaseIE()
    zdfbase.downloadJson = lambda *a, **kw: test_download_json

    # Testing for _call_api with valid arguments

# Generated at 2022-06-24 13:54:59.141679
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    m = ZDFChannelIE()
    assert m.suitable('http://www.zdf.de/nachrichten/heute-journal')
    assert m.suitable('https://www.zdf.de/nachrichten/heute-journal')
    assert not ZDFChannelIE.suitable('http://www.zdf.de/nachrichten/heute-journal/schlappe-fuer-die-spd-100.html')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/nachrichten/heute-journal/schlappe-fuer-die-spd-100.html')

# Generated at 2022-06-24 13:55:07.184793
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    obj = ZDFIE()
    video_id = ZDFIE._match_id(ZDFIE._VALID_URL)

    # Test for method _extract_player
    # This method is used for extracting a JSON file for the video
    # and is used by both regular and mobile methods
    assert obj._extract_player(ZDFIE._TESTS[0].get('webpage'),
                               video_id,
                               fatal=False)
    assert obj._extract_player(ZDFIE._TESTS[1].get('webpage'),
                               video_id,
                               fatal=False)

    # Test for method _extract_entry

# Generated at 2022-06-24 13:55:17.927818
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from ..utils import urljoin
    from .common import InfoExtractor
    from ..compat import compat_str
    # Test for class ZDFBaseIE
    ie = ZDFBaseIE()
    assert ie.IE_NAME == 'ZDFBaseIE'
    assert ie._VALID_URL == r''
    assert ie._TEST == {}
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/%s/default_default/index.html?videoId=%s'
    assert ie._TESTS == []
    assert ie.SUCCESS_REGEX == r'<(?:video|audio|source)[^>]+>'
    assert ie.SUCCESS_EXPECTED == False
    assert ie.SUCCESS_INCREASES_VIEW_COUNT == True

# Generated at 2022-06-24 13:55:21.214282
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    IE = ZDFBaseIE()
    assert IE._GEO_COUNTRIES == ['DE']
    assert IE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:28.880533
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    eff = ZDFChannelIE()
    assert eff._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert eff._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'


# Generated at 2022-06-24 13:55:29.894066
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert(ZDFBaseIE(None) != None)


# Generated at 2022-06-24 13:55:38.318589
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    Simple test case for video extraction of class ZDFBaseIE
    """
    test_data = {
        'url': 'https://www.example.com/test/test-video',
        'id': 'test-video'
    }
    example_video = ZDFBaseIE()
    assert example_video._GEO_COUNTRIES == ['DE']
    assert example_video._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:55:40.027480
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    crawler = ZDFBaseIE()
    assert crawler != None

# Generated at 2022-06-24 13:55:48.112764
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test = ZDFIE()
    assert test._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:55:55.929383
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from youtube_dl.utils import parse_codecs
    from ..utils import (
        # Uncomment the following line:
        # extract_attributes,
        try_get,
    )

    ZDFBaseIE._extract_subtitles
    ZDFBaseIE._extract_format
    ZDFBaseIE._extract_ptmd

    # Uncomment the following lines:
    # url = 'https://www.zdf.de/ZDFmediathek/hauptnavigation/startseite#/beitrag/video/3340762/Best-of-Luise-Kinseher',
    # webpage = '<html></html>'
    # ZDFBaseIE()._extract_player(webpage, url)
    # ZDFBaseIE._GEO_COUNTRIES
    # ZDFBaseIE._QUAL

# Generated at 2022-06-24 13:55:57.518873
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:56:08.277682
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    # Test the header parameter of _download_json
    content = ie._download_json('www.zdf.de/tests', 'video_id',
                                'video desc', headers={"Api-Auth": "Bearer abcd"})
    assert content['headers']['Api-Auth'] == 'Bearer abcd'
    # Test the _extract_ptmd function
    test_ptmd_url = 'http://www.zdf.de/ZDFmediathek/podcast/123456789'
    test_api_token = 'abcdefghijklmnopqrstuvwxyz'
    test_content = ie._extract_ptmd(test_ptmd_url, 'dummy_id', test_api_token, None)
    assert test_content['id']

# Generated at 2022-06-24 13:56:18.958612
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdf._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert zdf._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert zdf._TESTS[0]['info_dict']['id'] == '210222_phx_nachgehakt_corona_protest'
    assert zdf._T

# Generated at 2022-06-24 13:56:25.423686
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        t = ZDFBaseIE()
        t._call_api(None, None, None)
        t._extract_subtitles(None)
        t._extract_format(None, None, None, None)
        t._extract_ptmd(None, None, None, None)
        t._extract_player(None, None)
    except TypeError:
        assert False, 'Failed to create a instance of class ZDFBaseIE'
    assert True


# Generated at 2022-06-24 13:56:26.811081
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE(object(), object())
    assert zdf is not None


# Generated at 2022-06-24 13:56:30.447578
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE("https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html")



# Generated at 2022-06-24 13:56:38.828640
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFBaseIE
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    
    # test instance of ie
    assert isinstance(ZDFIE(), ZDFIE)

    # test extract_ptmd method
    extractor_key = ZDFIE.ie_key()
    content_id = '210222_phx_nachgehakt_corona_protest'
    url = 'https://api.zdf.de/content/documents/210222_phx_nachgehakt_corona_protest.ptmd.xml'
    api_token = 'xxx'

# Generated at 2022-06-24 13:56:39.746137
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE()
    assert z is not None


# Generated at 2022-06-24 13:56:51.479205
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfextractor=ZDFIE()
    assert zdfextractor.IE_NAME=='ZDF'
    assert zdfextractor._VALID_URL==r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdfextractor.GEO_COUNTRIES==['DE']

# Generated at 2022-06-24 13:56:53.391303
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._GEO_COUNTRIES == ['DE']

# Generated at 2022-06-24 13:57:04.514350
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test for private function _extract_player
    url = 'https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html'
    zdf = ZDFIE()
    webpage = zdf._download_webpage(url, '112', fatal=False)
    player = zdf._extract_player(webpage, url, fatal=False)
    assert player['apiToken']

    # Test for private function _extract_mobile
    video_id = '112'
    video = zdf._download_json(
        'https://zdf-cdn.live.cellular.de/mediathekV2/document/%s' % video_id,
        video_id)
    document = video['document']
    assert document['titel']

# Generated at 2022-06-24 13:57:06.394080
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test 1: Extractor ZDFBaseIE
    # Check if instance is created
    base = ZDFBaseIE()
    print(base)


# Extractor for Mediathek

# Generated at 2022-06-24 13:57:12.054648
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio/100.html')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html')



# Generated at 2022-06-24 13:57:15.786589
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()

    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:57:22.489567
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test valid URL
    info = ZDFChannelIE._build_url_result('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert info['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert info['ie_key'] == 'ZDF'

    # Test invalid URL - URL is from a different website (https://www.ardmediathek.de/)
    info = ZDFChannelIE._build_url_result('https://www.ardmediathek.de/pilker/')
    assert info is None

    # Test invalid URL - the URL is valid but the channel doesn't exist

# Generated at 2022-06-24 13:57:24.804846
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.test()

test_ZDFIE()



# Generated at 2022-06-24 13:57:34.635233
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:57:41.103335
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    obj = ZDFChannelIE()
    # Test for suitable (an instance method) - test of suitable is implemented in method real_extract
    assert obj.suitable('https://www.zdf.de/filme/taunuskrimi/') == False
    assert obj.suitable('https://www.zdf.de/dokumentation/planet-e') == True


# Generated at 2022-06-24 13:57:43.251836
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
    except Exception as e:
        assert(False) # should not throw exception
    assert(True)



# Generated at 2022-06-24 13:57:43.695707
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass



# Generated at 2022-06-24 13:57:47.321259
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        ZDFChannelIE.suitable('https://www.ag.ru/video/spy/xfiles/220251/')
        return False
    except:
        return True
assert test_ZDFChannelIE()


# Generated at 2022-06-24 13:57:53.242670
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Only run this test if there is no __init__() in class ZDFBaseIE
    if object.__getattribute__(ZDFBaseIE, "__init__") != object.__getattribute__(InfoExtractor, "__init__"):
        return

    # Test the normal constructor
    zdf_base_ie = ZDFBaseIE()
    # Test that we have an instance
    assert zdf_base_ie is not None


# Generated at 2022-06-24 13:57:54.314914
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    assert isinstance(instance, ZDFIE)


# Generated at 2022-06-24 13:57:57.335385
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE(None, None)
    assert ie.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:57:59.427718
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBase = ZDFBaseIE()
    # In this test, the ZDFBaseIE class is supposed to be instantiated.
    # The test should not raise any exception.


# Generated at 2022-06-24 13:58:04.266016
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z = ZDFBaseIE(object)

    assert z.ie_key() == 'zdf'
    assert set(z._GEO_COUNTRIES) == set(['DE'])
    assert set(z._QUALITIES) == set(['auto', 'low', 'med', 'high', 'veryhigh', 'hd'])



# Generated at 2022-06-24 13:58:05.571099
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('ZDFBaseIE','zdftivi')


# Generated at 2022-06-24 13:58:06.697016
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None)


# Generated at 2022-06-24 13:58:08.917185
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test type check
    with pytest.raises(TypeError):
        ZDFChannelIE(None)

# Generated at 2022-06-24 13:58:11.115618
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None, 'https://www.zdf.de/', None, None)


# Generated at 2022-06-24 13:58:21.607101
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE()._QUALITIES == ('auto','low','med','high','veryhigh','hd')
    assert ZDFBaseIE()._call_api("url", "video_id", "item")
    assert ZDFBaseIE()._extract_subtitles("src")
    assert ZDFBaseIE()._extract_format("video_id", "formats", "format_urls", "meta")
    assert ZDFBaseIE()._extract_ptmd("ptmd_url", "video_id", "api_token", "referrer")
    assert ZDFBaseIE()._extract_player("webpage", "video_id")


# Generated at 2022-06-24 13:58:27.226252
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    a = ZDFChannelIE()
    print(a.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'))
    print(a.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'))

# Generated at 2022-06-24 13:58:39.747597
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # First, test for correct error if ZDFIE.suitable() returns True
    zdf_ie = ZDFChannelIE()
    url = 'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
    with pytest.raises(ExtractorError) as excinfo:
        assert zdf_ie.suitable(url)
    assert 'The url seems to be an url of type ZDFIE' in str(excinfo.value)

    # Test that ZDFChannelIE.suitable() returns True for ZDFChannelIE urls
    # and False for ZDFIE urls
    zdf_channel_ie = ZDFChannelIE()
    zdf_ie = ZDFIE()
   

# Generated at 2022-06-24 13:58:41.057498
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert callable(ZDFBaseIE)


# Generated at 2022-06-24 13:58:42.446039
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(ZDFChannelIE.ie_key(), ZDFChannelIE._VALID_URL)



# Generated at 2022-06-24 13:58:44.305134
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    t = ZDFIE()
    type(t)


# Generated at 2022-06-24 13:58:46.471986
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:58:51.745039
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE(ZDFChannelIE.suitable)
    zdf_ie = ZDFIE(ZDFIE.suitable)
    zdf_channel_ie.extract('https://www.zdf.de/dokumentation/planet-e')
    zdf_ie.extract('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')


# Generated at 2022-06-24 13:58:54.003253
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Just make sure that it doesn't raise any exception
    ZDFBaseIE()


# Generated at 2022-06-24 13:58:55.451737
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    zdfie


# Generated at 2022-06-24 13:58:58.906293
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    zdf._download_json("https://api.zdf.de/", "id", 'formats', None)
    zdf._extract_format("id", [], [], {})
    assert(1)


# Generated at 2022-06-24 13:59:01.497626
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    i = ZDFIE()
    assert i.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:59:04.219337
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Constructor of class ZDFBaseIE should not throw any exception
    assert "ZDFBaseIE" not in globals() or ZDFBaseIE is not None


# Generated at 2022-06-24 13:59:16.224112
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    instance = ZDFChannelIE(
        compat_urllib_request.Request(
            'https://www.zdf.de/politik/phoenix-sendungen'))
    assert instance._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 13:59:20.174414
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE', 'zdf.de')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:59:21.963054
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .zdf import ZDFIE
    assert isinstance(ZDFIE(), ZDFBaseIE)


# Generated at 2022-06-24 13:59:30.057145
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.work() is True

# Generated at 2022-06-24 13:59:31.656437
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for constructor of class ZDFChannelIE
    """
    ZDFChannelIE(ZDFChannelIE.ie_key(),ZDFChannelIE._VALID_URL)



# Generated at 2022-06-24 13:59:35.049186
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert (ZDFBaseIE._GEO_COUNTRIES == ['DE'])
    assert (ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))



# Generated at 2022-06-24 13:59:47.361670
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert ie._TESTS[0]['info_dict']['id'] == 'das-aktuelle-sportstudio'
    assert ie._TESTS[0]['info_dict']['title'] == 'das aktuelle sportstudio | ZDF'
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e') == True

# Generated at 2022-06-24 13:59:48.758141
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie != None
# ---------------------------------------------------------------------------------


# Generated at 2022-06-24 13:59:49.850806
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()



# Generated at 2022-06-24 13:59:51.303332
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'



# Generated at 2022-06-24 13:59:55.121091
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:59:56.085599
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None)


# Generated at 2022-06-24 14:00:00.137728
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    dest = 'https://www.zdf.de/politik/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
    assert ZDFChannelIE._fix_url(url) == dest

