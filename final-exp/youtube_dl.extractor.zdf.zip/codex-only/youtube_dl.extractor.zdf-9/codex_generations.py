

# Generated at 2022-06-24 13:50:04.119230
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:50:05.118451
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()



# Generated at 2022-06-24 13:50:07.632431
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable(ZDFChannelIE._VALID_URL)
    assert not ie.suitable(ZDFIE._VALID_URL)


# Generated at 2022-06-24 13:50:15.557566
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    extractor = ZDFBaseIE('ZDFBaseIE')
    assert extractor._GEO_COUNTRIES == ['DE']
    assert extractor._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert extractor._call_api is not None
    assert extractor._extract_subtitles is not None
    assert extractor._extract_format is not None
    assert extractor._extract_ptmd is not None
    assert extractor._extract_player is not None



# Generated at 2022-06-24 13:50:22.399313
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test for condition that import error is raised when you import ZDFBaseIE
    # without lxml dependency
    # When you run this test on local machine, this should succeed.
    # When you run this test on Travis-CI, this should fail.
    # Hence, this test works as an integration test between Travis-CI and local machine.
    del sys.modules['..zdf_base']
    test = ZDFChannelIE()
    assert test is not None
    # __main__.ZDFChannelIE
    test = ZDFChannelIE()
    assert test is not None

# Generated at 2022-06-24 13:50:25.780576
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        import pytest
    except ImportError:
        print("Test skipped because pytest wasn't found")
    else:
        pytest.main(["-x", "--pdb", __file__])


# Generated at 2022-06-24 13:50:31.048567
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    obj = ZDFChannelIE()
    extractor_key = obj.ie_key()
    assert extractor_key == 'ZDFChannel'
    # Check if class can be instantiated.
    instance = obj(ZDFChannelIE._VALID_URL)
    assert isinstance(instance, ZDFChannelIE)

# Generated at 2022-06-24 13:50:32.801701
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')


# Generated at 2022-06-24 13:50:41.835732
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Create test object of class ZDFIE
    zdfie_test = ZDFIE()
    # Test for method _extract_entry
    video_id = '210222_phx_nachgehakt_corona_protest'
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    player = {
        'apiToken': '_YOUR_API_TOKEN_',
        'content': 'https://api.zdf.de/content/documents/%s' % video_id,
    }

# Generated at 2022-06-24 13:50:44.310770
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    if __name__ == '__main__':
        test_ZDFBaseIE()



# Generated at 2022-06-24 13:50:49.037143
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    info = {
        'id': '210222_phx_nachgehakt_corona_protest',
        'ext': 'mp4',
        'title': 'Wohin führt der Protest in der Pandemie?',
        'description': 'md5:7d643fe7f565e53a24aac036b2122fbd',
        'duration': 1691,
        'timestamp': 1613948400,
        'upload_date': '20210221',
        'extractor_key': 'ZDF',
    }
    assert zdf._GEO_COUNTRIES == ['DE']

# Generated at 2022-06-24 13:50:51.563891
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None, None)



# Generated at 2022-06-24 13:51:01.373224
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # we need to test if channel_id is being extracted properly
    # currently the channel_id is same as the video_id that is extracted
    # and then we use the channel_id as a part of API Call to get the
    # channel info, if the channel_id is not been extracted properly
    # the API call will fail, we can't test the API call because that
    # is the task for integration test and we need to test API calls
    # indivisually so this is way we check the channel_id here
    ie = ZDFChannelIE(ZDFChannelIE._create_ie_instance())
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    channel_id = 'das-aktuelle-sportstudio'

# Generated at 2022-06-24 13:51:06.005529
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    module = ZDFChannelIE()
    assert ZDFChannelIE.suitable(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio') is True
    assert module._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)(?:\.html)?'
    assert ZDFChannelIE.suitable(
        'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-184.html') is False

# Generated at 2022-06-24 13:51:07.101647
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Assert that class ZDFIE is constructed successfully
    assert ZDFIE(None) is not None

# Generated at 2022-06-24 13:51:10.568692
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    inst = ZDFChannelIE()
    result = inst.suitable(url)
    print(result)

    url = 'https://www.zdf.de/dokumentation/planet-e/planet-e-22-april-2021-109.html'
    inst = ZDFChannelIE()
    result = inst.suitable(url)
    print(result)



# Generated at 2022-06-24 13:51:14.426136
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    "Unit test for constructor of class ZDFIE"
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() == 'ZDFMediathek'


# Generated at 2022-06-24 13:51:17.444137
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj.playlist_count == 0
    assert obj.playlist_title == None


# Generated at 2022-06-24 13:51:18.815432
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    inst = ZDFIE()
    assert inst._GEO_COUNTRIES == ['DE']
    assert inst._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:20.724833
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert not ZDFChannelIE.suitable(ZDFIE)



# Generated at 2022-06-24 13:51:24.290246
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert instance._GEO_COUNTRIES == ['DE']
    assert instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:51:27.648519
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    e = ZDFIE()
    assert e._GEO_COUNTRIES == ['DE']
    assert e._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:29.150155
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert hasattr(ie, '_QUALITIES')


# Generated at 2022-06-24 13:51:34.157491
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE(None)._GEO_COUNTRIES == ['DE']
    assert ZDFIE(None)._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:51:44.875628
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    input_url = 'https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html'
    expected_output = ('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html',
                       'https://www.3sat.de/film/spielfilm/der-hauptmann-100.html')
    assert ZDFIE(input_url)._VALID_URL == expected_output[0]
    assert ZDFIE(input_url)._real_extract(input_url).get('url') == expected_output[1]



# Generated at 2022-06-24 13:51:46.967170
# Unit test for constructor of class ZDFIE
def test_ZDFIE():

    # Test the constructor
    ZDFIE('ZDFBaseIE', 'zdf', ZDFIE._VALID_URL)


# Generated at 2022-06-24 13:51:48.355796
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()

# Generated at 2022-06-24 13:51:51.582960
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test if the constructor of ZDFIE works
    IE = ZDFIE()
    print(IE.__class__.__name__)
    if IE.__class__.__name__ != ZDFIE.__name__:
        print('test failed')
        exit(1)
    else:
        print('test successful')
        exit(0)


# Generated at 2022-06-24 13:51:58.123085
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test with a doc that has ZDFBaseIE.ie_key() in entries
    html = utils.file_to_str(os.path.join(
        os.path.dirname(__file__), 'zdf_test_data/test_zdf_channel.html'))
    url = 'https://www.zdf.de/dokumentation/planet-e'
    info_dict = ZDFChannelIE()._real_extract(url)
    assert info_dict['id'] == 'planet-e'
    assert info_dict['title'] == 'planet e.'
    assert len(info_dict['entries']) == 50
    assert all(ent_info['_type'] == 'url' for ent_info in info_dict['entries'])

# Generated at 2022-06-24 13:52:10.689037
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        from collections import OrderedDict
        from unittest import mock
    except ImportError:
        return
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    webpage = mock.Mock(return_value=b'foobar')
    channel_id = 'das-aktuelle-sportstudio'

# Generated at 2022-06-24 13:52:17.617276
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        import pytest
    except ImportError:
        return

    # Unit test for constructor of class ZDFChannelIE
    @pytest.mark.parametrize('url', [
        'https://www.zdf.de/dokumentation/planet-e',
        'https://www.zdf.de/filme/taunuskrimi/',
    ])
    def test_ZDFChannelIE_constructor(url):
        print(ZDFChannelIE(url))
        
    test_ZDFChannelIE_constructor()



# Generated at 2022-06-24 13:52:27.859752
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    parameters = {
        'url': 'https://www.zdf.de/politik/themen-sammlungen/themen/themen-sammlung/',
        'expected_result': {
            'id': 'themen-sammlung',
            'title': 'Themen-Sammlung',
            'webpage_url': 'https://www.zdf.de/politik/themen-sammlungen/themen/themen-sammlung/',
        }
    }
    ie = ZDFChannelIE(parameters)
    result = ie.extract()
    assert result == parameters['expected_result']

# Generated at 2022-06-24 13:52:34.865242
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Just use one test case to test constructor of class ZDFChannelIE
    ZDFChannelIE([{
        'url': 'https://www.zdf.de/sport/das-aktuelle-sportstudio',
        'info_dict': {
            'id': 'das-aktuelle-sportstudio',
            'title': 'das aktuelle sportstudio | ZDF',
        },
        'playlist_mincount': 23,
    }])



# Generated at 2022-06-24 13:52:37.315422
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIEfail = ZDFIE('url', {'id':'1'})
    assert not zdfIEfail._VALID_URL
    zdfIEpass = ZDFIE('url', {'id':'1'})
    assert zdfIEpass._VALID_URL

# Generated at 2022-06-24 13:52:38.248593
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()


# Generated at 2022-06-24 13:52:38.753378
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

# Generated at 2022-06-24 13:52:40.836616
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .zdf import ZDFIE
    assert ZDFBaseIE.ie_key() == ZDFIE.ie_key()
    assert ZDFBaseIE.ie_key() == 'ZDF'
    assert ZDFBaseIE.ie_key() == 'zdf'



# Generated at 2022-06-24 13:52:45.907154
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE', 'ZDFBaseIE')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie._call_api('http://url.com', 'video_id', 'item', 'api_token', 'referer')
    assert ie._extract_subtitles({'captions': [{'language': 'en', 'uri': 'url'}, {'uri': 'url2'}]}) == {'deu': [{'url': 'url2'}], 'en': [{'url': 'url'}]}

# Generated at 2022-06-24 13:52:50.440889
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.locales[0] == "de_DE"
    assert ie.http_headers["Accept-Language"] == "de-DE,de;q=0.8,en-US;q=0.6,en;q=0.4"
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert not ie._call_api("URL", "VIDEO ID", "ITEM", None, None)
    assert ie._extract_subtitles("JSON") == {}
    assert ie._extract_format("VIDEO_ID", [], set(), {}) is None

# Generated at 2022-06-24 13:52:52.803299
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFIE()
    ie.extract("http://www.zdf.de/ZDFmediathek/beitrag/video/2467996")



# Generated at 2022-06-24 13:52:53.662300
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-24 13:52:54.535696
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()


# Generated at 2022-06-24 13:52:56.679283
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE()._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:53:02.177593
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannel = ZDFChannelIE(ZDFIE(), {
        'url': 'https://www.zdf.de/dokumentation/planet-e',
        'id': 'planet-e',
    })
    assert zdfchannel.suitable(zdfchannel.url)
    assert zdfchannel.id == 'planet-e'



# Generated at 2022-06-24 13:53:06.581371
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Constructor test
    """
    channel = ZDFChannelIE()
    assert channel.suitable(ZDFChannelIE._VALID_URL) is True


# Generated at 2022-06-24 13:53:17.646031
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    #Video url and video_id is given
    url = "https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html"
    video_id = "210222_phx_nachgehakt_corona_protest"

    #Assertions
    assert ZDFIE._TESTS[0]['url'] == url
    assert ZDFIE._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert ZDFIE._TESTS[0]['info_dict']['id'] == video_id
    assert ZDFIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:53:18.600269
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:53:21.339419
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')



# Generated at 2022-06-24 13:53:22.639808
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._call_api


# Generated at 2022-06-24 13:53:23.948320
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Check if ZDFBaseIE class is initialized
    assert ZDFBaseIE


# Generated at 2022-06-24 13:53:27.937532
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html')
    assert not ie.suitable('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')


# Generated at 2022-06-24 13:53:41.790863
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Tests that the correct class is loaded when constructor is invoked.
    """
    # Test a URL that should match ZDFChannelIE.
    print("\nTesting that ZDFChannelIE is loaded for a URL that should match ZDFChannelIE...\n")
    u = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFIE.construct_from_url(u)
    assert(isinstance(ie, ZDFChannelIE))
    print("Test successful!\n")

    # Test a URL that should match ZDFIE.
    print("\nTesting that ZDFChannelIE is not loaded for a URL that should match ZDFIE...\n")

# Generated at 2022-06-24 13:53:54.033796
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Ensure that we don't inappropriately create a channel page (i.e. a page with a list of videos).
    # Channel pages are created by a URL that matches ZDFChannelIE._VALID_URL.
    # Since we don't want to create a channel page, the URL must not match ZDFChannelIE._VALID_URL.
    video_url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert not re.match(ZDFChannelIE._VALID_URL, video_url)

    # Create a channel page (i.e. a page with a list of videos)

# Generated at 2022-06-24 13:54:06.663336
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test the constructor of class ZDFChannelIE
    # for a given URL, i.e. check that the class is suitable for this URL
    url = 'http://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html'
    assert ZDFChannelIE._suitable_url(url), 'ZDFChannelIE should be suitable for url ' + url
    url = 'http://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
    assert ZDFChannelIE._suitable_url(url), 'ZDFChannelIE should be suitable for url ' + url

# Generated at 2022-06-24 13:54:09.618827
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE()
    assert hasattr(inst, '_GEO_COUNTRIES')
    assert inst._GEO_COUNTRIES == ['DE']
    assert hasattr(inst, '_QUALITIES')
    assert inst._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:11.054779
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info_extractor = ZDFBaseIE()
    assert info_extractor is not None
    assert info_extractor._call_api is not None


# Generated at 2022-06-24 13:54:11.653659
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-24 13:54:12.963571
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert issubclass(ZDFIE, InfoExtractor)
    assert issubclass(ZDFIE, ZDFBaseIE)


# Generated at 2022-06-24 13:54:20.392121
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    channel_url = 'https://www.zdf.de/dokumentation/planet-e'
    channel_id = 'planet-e'
    assert ie.suitable(channel_url)
    assert ie._match_id(channel_url) == channel_id

    entry_url = 'https://www.zdf.de/dokumentation/planet-e/planet-e-die-gaehrung-des-saftes-100.html'
    assert not ie.suitable(entry_url)
    assert not ie._match_id(entry_url) == channel_id

    entry_url = 'https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html'

# Generated at 2022-06-24 13:54:21.429814
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    pass

# Generated at 2022-06-24 13:54:23.350736
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    d = ZDFIE()
    assert d



# Generated at 2022-06-24 13:54:25.382616
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('ZDFIE', 'www.zdf.de')
    assert ie


# Generated at 2022-06-24 13:54:29.959769
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    expected_geo_countries = ['DE']
    assert zdf._GEO_COUNTRIES == expected_geo_countries

    expected_qualities = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdf._QUALITIES == expected_qualities


# Generated at 2022-06-24 13:54:37.477833
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test URL with hyphen in ID
    channel = ZDFChannelIE()
    channel._VALID_URL = 'ZDFChannelIE'
    channel._TESTS = [{
        'url': 'https://www.zdf.de/dokumentation/planet-e',
        'info_dict': {
            'id': 'planet-e',
            'title': 'planet e.',
        },
    }]
    p = channel.suitable(channel._TESTS[0]["url"])
    assert p == True


# Generated at 2022-06-24 13:54:46.288807
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:54:49.707091
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBase = ZDFBaseIE()
    assert zdfBase._GEO_COUNTRIES == ['DE']
    assert len(zdfBase._QUALITIES) == 6


# Generated at 2022-06-24 13:54:51.703249
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    #assert ie.name == 'ZDF'


# Generated at 2022-06-24 13:55:01.049370
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    test for constructor of class ZDFIE
    """
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdfie.name == "ZDF"
    assert zdfie.ie_key() == "ZDF"
    assert zdfie.description == "ZDF"
    assert zdfie.url_pattern == r"https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html"
    assert zdfie.params == {"skip_download": True}


# Generated at 2022-06-24 13:55:05.345738
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE('zdf')
    print(zdf)


# Generated at 2022-06-24 13:55:06.394838
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(ZDFChannelIE.ie_key())


# Generated at 2022-06-24 13:55:10.274254
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE()
    assert channel.suitable(ZDFChannelIE._VALID_URL)
    assert not channel.suitable(ZDFIE._VALID_URL)

# Generated at 2022-06-24 13:55:12.569000
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        baseIE = ZDFBaseIE()
    except:
        assert False
    assert isinstance(baseIE, ZDFBaseIE)



# Generated at 2022-06-24 13:55:14.832223
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.__class__.__name__ == 'ZDFIE'
    assert ie.IE_NAME == 'ZDF'


# Generated at 2022-06-24 13:55:17.738421
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    class MyZDFIE(ZDFIE):
        def _extract_regular(self, url, player, video_id):
            return

    MyZDFIE('http://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')



# Generated at 2022-06-24 13:55:29.861645
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_ie = ZDFBaseIE({})
    assert zdf_ie.IE_NAME == 'ZDF'
    assert zdf_ie.ie_key() == 'zdf'
    assert zdf_ie._GEO_COUNTRIES == ['DE']
    assert zdf_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    assert zdf_ie._call_api('https://www.zdf.de', 'test', 'api-call') == {}

    # _extract_subtitles unit test
    assert zdf_ie._extract_subtitles({'captions': []}) == {}

# Generated at 2022-06-24 13:55:31.168064
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE != None


# Generated at 2022-06-24 13:55:37.385270
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = 'test_video_id'
    webpage = 'test_webpage'
    expected_player_json = 'test_json'
    actual_player_json = ZDFBaseIE._extract_player(webpage, video_id)
    assert expected_player_json == actual_player_json


# Generated at 2022-06-24 13:55:46.206647
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-24 13:55:51.071797
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFIE()
        assert(False)
    except ValueError:
        assert(True)
    try:
        ZDFIE(ZDFBaseIE())
        assert(False)
    except ValueError:
        assert(True)
    # Actual constructor
    ZDFIE(InfoExtractor())



# Generated at 2022-06-24 13:56:02.070533
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannel_ie = ZDFChannelIE()
    zdfie = ZDFIE()

    assert zdfchannel_ie.suitable(zdfie.suitable('https://www.zdf.de/dokumentation/planet-e')) == False
    assert zdfchannel_ie.suitable(zdfie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')) == False
    assert zdfchannel_ie.suitable(zdfie.suitable('https://www.zdf.de/filme/taunuskrimi/')) == False

# Generated at 2022-06-24 13:56:04.235371
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # check that isinstance(ZDFIE(), InfoExtractor) is True
    assert isinstance(ZDFIE(), InfoExtractor)

# Generated at 2022-06-24 13:56:10.204382
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/politik/frontal21/frontal21-uebersicht-100.html'
    ie = ZDFChannelIE(url, 'Frontal 21')
    # Note:  you can use next line to test your code
    #url_result_json = ie.url_result(url).to_json()


# Generated at 2022-06-24 13:56:21.729589
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .zdf import ZDFIE
    from .zdf_mediathek import ZDFMediathekIE
    from .zdf_sport import ZDFSportIE
    from .zdf_mobil import ZDFMobilIE
    from .zdf_heute import ZDFHeuteIE
    from .zdf_channel import ZDFChannelIE


# Generated at 2022-06-24 13:56:23.096159
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE().ie_key() == 'zdf'

# Generated at 2022-06-24 13:56:24.713935
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()(ZDFIE._TESTS[0]['url'])

# Generated at 2022-06-24 13:56:32.071614
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info_extractor = ZDFBaseIE()
    info_extractor._call_api(
        'https://api.zdf.de/content/documents/der-zeitgeist', 'test-output-video_id', 'Downloading JSON %s')
    info_extractor._extract_subtitles({
        'captions': [
            {
                'language': 'deu',
                'uri': 'https://api.zdf.de/content/documents/der-zeitgeist.xml',
            },
            {
                'language': 'ita',
                'uri': 'https://api.zdf.de/content/documents/der-zeitgeist-ita.xml',
            },
        ],
    })

# Generated at 2022-06-24 13:56:35.379278
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')


# Generated at 2022-06-24 13:56:43.537623
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    controller = ZDFIE()
    assert controller.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not controller.suitable('https://www.zdf.de/nachrichten/heute-sport/heute-sport-vom-6-mai-2019-100.html')

# Unit tests for constructor of class ZDFBaseIE

# Generated at 2022-06-24 13:56:53.594703
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.downloader.httpie import HTTPieDownloader

    # construct ZDFChannelIE object
    zdf_channel_ie = ZDFChannelIE()
    zdf_channel_ie.httpie = HTTPieDownloader('httpie.py')

    # get the url of the zdf-channel
    url_zdf_channel = 'https://www.zdf.de/dokumentation/planet-e'

    # extract video-urls from zdf-channel
    extracted_video_urls = zdf_channel_ie._real_extract(url_zdf_channel)

    # print all video urls
    for i in extracted_video_urls:
        print(i['url'])

# Generated at 2022-06-24 13:56:54.274609
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    pass



# Generated at 2022-06-24 13:57:00.060045
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE()
# assert zdf_base._call_api('test_url', 'test_video_id', 'test_item') is None
    assert zdf_base._extract_subtitles({}) == {}
    assert zdf_base._extract_format('test_video_id', [], [], {}) is None



# Generated at 2022-06-24 13:57:07.515699
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url_good = "https://www.zdf.de/dokumentation/planet-e"
    url_bad = "https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html"
    assert(ZDFChannelIE.suitable(url_good))
    assert(not(ZDFChannelIE.suitable(url_bad)))


# Generated at 2022-06-24 13:57:15.629040
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Tested constructor
    assert(ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e'))
    assert(ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/'))
    assert(ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'))
    assert(ZDFChannelIE.suitable('https://www.zdf.de/nachrichten/heute/heute-19-uhr-100.html'))


# Generated at 2022-06-24 13:57:20.663045
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE("http://www.zdf.de/ZDFmediathek/kanaluebersicht", {},
                     downloader=None)
    assert inst._GEO_COUNTRIES == ['DE']
    assert inst._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert inst._call_api("/json/prism_player_update/10275",
                          "10275", "metadata", "12345") is not None
    assert inst._extract_player({}, "") == {}


# Generated at 2022-06-24 13:57:31.882836
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .. import unescapeHTML
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/taunuskrimi/')
    ZDFChannelIE.suitable('https://www.zdf.de/filme/ab-18/')
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/ab-18/')

# Generated at 2022-06-24 13:57:33.887095
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:57:38.697493
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# ---------------------------------------------------------
# ZDF player
# ---------------------------------------------------------



# Generated at 2022-06-24 13:57:49.167376
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE("")
    assert ie.suitable("")==False
    assert ie.IE_NAME == 'zdf'
    assert ie.IE_DESC == 'Zweites Deutsches Fernsehen (ZDF)'
    assert ie._VALID_URL == '(?x)https?://(?:www\.(?:zdf\.de/ZDFmediathek/)|player\.zdf\.de/)(?:(?:#/)?(?:[^/]+/)?beitrag/video/([^/]+)(?:/[^/?#]+)?|content/(?:[^/]+/)?byId/(\d+))'
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:57:52.610404
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Create an instance of ZDFIE()
    ie_zdf = ZDFIE()

    # Check if ZDFIE instance was created
    if ie_zdf is None:
        reportError()



# Generated at 2022-06-24 13:57:54.282844
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        inst = ZDFBaseIE()
    except Exception as e:
        raise e
    return inst


# Generated at 2022-06-24 13:57:57.600111
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE'], "Constructor of ZDFBaseIE failed."
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'), "Constructor of ZDFBaseIE failed."



# Generated at 2022-06-24 13:57:59.644374
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ZDFBaseIE.ie_key_map


# Generated at 2022-06-24 13:58:02.484809
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()


# Generated at 2022-06-24 13:58:07.429077
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert ie.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html') == False


# Generated at 2022-06-24 13:58:10.648104
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    Testing ZDFIE
    """
    ZDFIE('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')



# Generated at 2022-06-24 13:58:11.312274
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert True


# Generated at 2022-06-24 13:58:13.187580
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:58:17.119955
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:58:19.446382
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info = ZDFBaseIE()
    s = info._GEO_COUNTRIES[0]
    assert s == 'DE'


# Generated at 2022-06-24 13:58:26.865929
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    class TestZDFIE(unittest.TestCase):
        def test_constructor(self):
            instance1 = ZDFIE(ZDFIE.ie_key())
            self.assertEqual(instance1._VALID_URL, ZDFIE._VALID_URL)
            self.assertEqual(instance1._TESTS, ZDFIE._TESTS)
            self.assertEqual(instance1._GEO_COUNTRIES, ZDFBaseIE._GEO_COUNTRIES)
            self.assertEqual(instance1._QUALITIES, ZDFBaseIE._QUALITIES)
            self.assertEqual(instance1._TEST, ZDFBaseIE._TEST)
            instance2 = ZDFIE(ZDFIE.ie_key())
            self.assertEqual(instance1, instance2)


# Generated at 2022-06-24 13:58:39.260736
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html', False)
    ie = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert ie.channel_id == 'planet-e'

# Generated at 2022-06-24 13:58:41.393881
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    parser = ZDFChannelIE()
    assert parser.suitable(ZDFChannelIE._VALID_URL)

# Generated at 2022-06-24 13:58:47.445177
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # error expected if title not found
    channel = ZDFChannelIE(ZDFChannelIE.ie_key())
    content_id = 'https://www.zdf.de/dokumentation/planet-e'
    webpage = channel._download_webpage(content_id, None, fatal=False)
    player = channel._extract_player(webpage, content_id, fatal=False)
    channel_id = channel._search_regex(
        r'docId\s*:\s*(["\'])(?P<id>(?!\1).+?)\1', webpage,
        'channel id', group='id')
    channel_json = channel._call_api(
        'https://api.zdf.de/content/documents/%s.json' % channel_id, player, content_id, channel_id)

# Generated at 2022-06-24 13:58:51.221571
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.geo_countries == ['DE']
    assert ie.qualities == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:58:53.525159
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:59:02.469316
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    This function tests the constructor of ZDFIE class
    """
    print("Testing construction of ZDFIE class")
    zdf = ZDFIE()
    # Check IE name
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:59:03.108021
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass



# Generated at 2022-06-24 13:59:08.499413
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return
    # Test from https://www.zdf.de/kinder/kika/fiktional/logo-quiz-100.html
    zdfi4 = ZDFChannelIE(ZDFIE.ie_key())
    zdfi4.extract('https://www.zdf.de/kinder/kika/fiktional')



# Generated at 2022-06-24 13:59:20.263548
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert isinstance('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html', ZDFBaseIE)
    assert not isinstance('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html', ZDFChannelIE)
    assert not isinstance('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html', ZDFChannelIE)

# Generated at 2022-06-24 13:59:23.136647
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    ie.extract('https://www.zdf.de/comedy/heute-show/heute-show-vom-11-mai-2018-100.html')

# Generated at 2022-06-24 13:59:24.108406
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()


# Generated at 2022-06-24 13:59:29.836269
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Test for constructor of class ZDFChannelIE
    """
    channel_url = 'https://www.zdf.de/dokumentation/planet-e'
    channel_ie = ZDFChannelIE(channel_url)
    assert channel_ie.SUITABLE(channel_url)
    assert channel_ie.ie_key() == 'ZDFChannel'
    assert channel_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'



# Generated at 2022-06-24 13:59:31.404424
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    global ZDFIE
    ZDFIE = ZDFIE()


# Generated at 2022-06-24 13:59:32.803295
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE("ZDFBaseIE")
    return



# Generated at 2022-06-24 13:59:35.856569
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class TestZDFBaseIE(ZDFBaseIE):
        _VALID_URL = 'dummyurl'
        _IE_NAME = 'ZDF'

    TestZDFBaseIE()


# Generated at 2022-06-24 13:59:38.043698
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFIE()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-24 13:59:50.097854
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfIE = ZDFChannelIE()

    # Test URLs where the constructor should not return an instance of ZDFChannelIE
    invalid_urls = (
        'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html',
        'https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html',
    )
    for url in invalid_urls:
        assert not zdfIE.suitable(url)

    # Test URLs where the constructor should return an instance of ZDFChannelIE

# Generated at 2022-06-24 13:59:59.796476
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    neue_zdf_mediathek = {
        'channel_name': 'zdf',
        'channel_id': 'zdf',
        'channel_url': 'https://www.zdf.de/dokumentation/nano',
        'channel_config': {
            'content': 'https://api.zdf.de/content/documents/zdf.json',
            'apiToken': 'O2wMYo0VRUUjKMHOXh3q9Yd0TyGux0yIkHV7w',
            'apiContext': 'hbbtv'
        }
    }
