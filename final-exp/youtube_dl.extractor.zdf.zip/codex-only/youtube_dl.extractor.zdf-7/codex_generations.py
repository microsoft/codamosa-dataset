

# Generated at 2022-06-24 13:50:04.970924
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE("https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html")
    assert instance


# Generated at 2022-06-24 13:50:06.640281
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfie = ZDFBaseIE()
    assert zdfie is not None


# Generated at 2022-06-24 13:50:09.161161
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')

# Generated at 2022-06-24 13:50:13.742663
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE().suitable(ZDFChannelIE._VALID_URL) == True
# Tested with
# https://www.zdf.de/dokumentation/planet-e
# https://www.zdf.de/sport/sportreportage

# Generated at 2022-06-24 13:50:15.509337
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_ie = ZDFBaseIE(None)
    assert zdf_ie is not None


# Generated at 2022-06-24 13:50:16.999746
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    return zdf_ie



# Generated at 2022-06-24 13:50:26.944246
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_ZDFIE = ZDFIE()
    assert test_ZDFIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    valid_url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert test_ZDFIE._valid_url(valid_url, 'ZDFIE')
    invalid_url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html?set=0'
    assert not test_ZDFIE._

# Generated at 2022-06-24 13:50:33.953350
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info = ZDFBaseIE('ZDFBaseIE')
    assert info._GEO_COUNTRIES == ['DE']
    assert info._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert callable(info._call_api)
    assert callable(info._extract_subtitles)
    assert callable(info._extract_format)
    assert callable(info._extract_ptmd)
    assert callable(info._extract_player)



# Generated at 2022-06-24 13:50:35.663850
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    c = ZDFChannelIE('https://www.zdf.de/planet-wissen/')


# Generated at 2022-06-24 13:50:43.290515
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    UnitTestZDFChannelIE = collections.namedtuple('UnitTestZDFChannelIE', ['url', 'expected_channel_id'])
    # This is a minimal test
    unit_test_cases = [
        UnitTestZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio', 'das-aktuelle-sportstudio'),
        UnitTestZDFChannelIE('https://www.zdf.de/dokumentation/planet-e', 'planet-e'),
        UnitTestZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/', 'filme/taunuskrimi')
    ]
    for unit_test_case in unit_test_cases:
        actual_channel_id = ZDFChannelIE._match

# Generated at 2022-06-24 13:50:45.330895
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        ZDFChannelIE()
        assert False
    except AssertionError:
        pass



# Generated at 2022-06-24 13:50:55.327422
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    name = "ZDFChannelIE"
    url = "https://www.zdf.de/sport/das-aktuelle-sportstudio"
    url_result = url_result
    ZDFChannelIE = ZDFChannelIE
    def _download_webpage(url, video_id):
        return open(os.path.join(__dir__, 'zdf-das-aktuelle-sportstudio.html'), 'rb').read()


    with open(os.path.join(__dir__, 'zdf-das-aktuelle-sportstudio.html'), 'rb') as webpage:
        webpage = webpage.read()
    webpage = webpage.decode()

    def _real_download_webpage(self, *args):
        return _download_webpage(*args)



# Generated at 2022-06-24 13:50:58.813637
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(object(), 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')



# Generated at 2022-06-24 13:51:10.346060
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()
    assert zdf.suitable('https://www.zdf.de/dokumentation/planet-e') == True
    assert zdf.suitable('https://www.zdf.de/dokumentation/planet-e/') == True
    assert zdf.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html') == True
    assert zdf.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True
    assert zdf.suitable('https://www.zdf.de/dokumentation/planet-e') == True

# Generated at 2022-06-24 13:51:12.616970
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE().suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')



# Generated at 2022-06-24 13:51:20.620598
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ydl = YoutubeDL({'verbose': False})
    if ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e'):
        ydl = YoutubeDL({'verbose': False})
        zdf_c = ZDFChannelIE()
        zdf_c._real_extract('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-24 13:51:25.476313
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() is 'ZDF'
    assert zdfie.ie_key() == 'ZDF'
    assert zdfie == ZDFIE()
    assert zdfie != InfoExtractor()
    assert str(zdfie) == 'zdf'


# Generated at 2022-06-24 13:51:26.992375
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return ZDFChannelIE



# Generated at 2022-06-24 13:51:31.479634
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()._call_api(
        'https://api.zdf.de/content/documents/%s.json' % 'das-aktuelle-sportstudio',
        {},
        "https://www.zdf.de/sport/das-aktuelle-sportstudio",
        'das-aktuelle-sportstudio')

# Generated at 2022-06-24 13:51:43.018757
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test with a video not available in your country
    video_id = 'TjKL-Ozt_CQ'
    ie = ZDFBaseIE()
    if ie._is_valid_url(ie.extract(video_id)):
        raise AssertionError('%s must not be downloaded in your country' % video_id)

    # Test with a video available in your country
    video_id = 'H_C7_p6ne0U'
    if not ie._is_valid_url(ie.extract(video_id)):
        raise AssertionError('%s must be downloaded in your country' % video_id)



# Generated at 2022-06-24 13:51:45.357037
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return ZDFBaseIE._test_constructor(ZDFChannelIE, [
        'https://www.zdf.de/filme/taunuskrimi/']).get('entries')

# Generated at 2022-06-24 13:51:52.072300
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    info_dicts = []

    # some old channels
    for url in (
            'https://www.zdf.de/kultur/artur-und-die-minimoys',
            'https://www.zdf.de/comedy/dittsche',
            'https://www.zdf.de/dokumentation/planet-e'):
        channel = ZDFChannelIE(url)
        info_dicts.append(channel.extract())

    assert len(info_dicts) > 1

# Generated at 2022-06-24 13:51:58.786165
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:52:10.981300
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('http://example.com/', 'test')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    assert ie._call_api(
        'http://example.com/', 'test', 'Downloading JSON %s', headers={'Api-Auth': 'Bearer test'}) == 'Downloading JSON %s'

    assert ie._extract_subtitles({'captions': [{'uri': 'test'}, {'uri': 'test2'}]}) == {'deu': [{'url': 'test'}, {'url': 'test2'}]}


# Generated at 2022-06-24 13:52:12.151628
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'


# Generated at 2022-06-24 13:52:19.988033
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.IE_NAME == 'ZDF'
    assert ie.http_headers == {
        'User-Agent': 'ZDF-App/8.8.1 (Android; SDK 27; arm-v7a; phoenix-player-ng) okhttp/4.4.0'
    }
    assert ie.host == 'zdf.de'
    assert ie.origin == 'https://www.zdf.de'
    assert ie.name == 'ZDF'
    assert ie.age_limit == 0
    assert ie.geo_countries == ['DE']
    assert ie.extractor_key == 'ZDF'
    assert ie.IE_DESC == 'ZDF'

# Generated at 2022-06-24 13:52:25.299232
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zb1 = ZDFBaseIE()
    zb2 = ZDFBaseIE()
    assert zb1._GEO_COUNTRIES == zb2._GEO_COUNTRIES
    assert zb1._QUALITIES == zb2._QUALITIES



# Generated at 2022-06-24 13:52:28.475201
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Constructor of class ZDFChannelIE."""
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.get_url_regex() == ZDFChannelIE._VALID_URL

# Generated at 2022-06-24 13:52:32.813266
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._call_api('www.zdf.com', '42', 'api') is None
    assert not ie._extract_subtitles({})
    assert ie._extract_format('42', [], set(), {}) is None
    assert ie._extract_ptmd('www.zdf.com', '42', 'api_token', 'referrer') is None
    assert ie._extract_player('webpage', '42', fatal=True) is None


# Generated at 2022-06-24 13:52:38.014475
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    assert ZDFChannelIE.suitable(url) is True
    ie = ZDFChannelIE()
    assert ie.SUITABLE_URL == ZDFChannelIE._VALID_URL
    assert ie.VALID_URL == ZDFChannelIE._VALID_URL
    assert ie.IE_NAME == 'zdf:channel'

# Generated at 2022-06-24 13:52:49.154314
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    zdfcie = ZDFChannelIE(url)
    assert zdfcie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert zdfcie._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert zdfcie._TESTS[0]['playlist_mincount'] == 23
    assert zdfcie._TESTS[1]['url'] == 'https://www.zdf.de/dokumentation/planet-e'

# Generated at 2022-06-24 13:52:54.220333
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # prevent execution of tests from other classes
    if not inspect.stack()[1][3].startswith('test_'):
        return
    # test for constructor of class ZDFChannelIE
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE.suitable(url)
    assert isinstance(ie, ZDFChannelIE)


# Generated at 2022-06-24 13:52:56.235537
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE(None)
    assert zdfie._GEO_COUNTRIES == ['DE']

# Generated at 2022-06-24 13:52:57.910498
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    extractor = ZDFBaseIE()
    assert(extractor.ie_key() == 'zdf')


# Generated at 2022-06-24 13:53:08.142895
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """Test if constructor of class ZDFBaseIE is working properly."""
    ZDFIE_instance = ZDFIE('http://www.zdf.de/Nachrichten')
    assert ZDFIE_instance._GEO_COUNTRIES == ['DE']
    assert ZDFIE_instance._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ZDFIE_instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:53:15.792380
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ZDFChannelIE.__name__ == 'ZDFChannelIE'
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    

# Generated at 2022-06-24 13:53:17.073438
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import doctest
    doctest.testmod()


# Generated at 2022-06-24 13:53:21.128268
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    extractor = ZDFBaseIE('ZDFBaseIE', {'url': 'https://www.zdf.de'})
    assert extractor._GEO_COUNTRIES == ['DE']
    assert extractor._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-24 13:53:22.415753
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie


# Generated at 2022-06-24 13:53:23.357237
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()


# Generated at 2022-06-24 13:53:26.500840
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:53:27.496898
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:53:29.209182
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    a = ZDFIE()
    assert_equal(a.ie_key(), 'ZDF')

# Generated at 2022-06-24 13:53:41.413130
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channels = [
        'https://www.zdf.de/dokumentation/planet-e',
        'https://www.zdf.de/dokumentation/terra-x',
        'https://www.zdf.de/sport/das-aktuelle-sportstudio',
        'https://www.zdf.de/filme/taunuskrimi',
        'https://www.zdf.de/tv-programm/rubrik/comedy/comedy-spots',
        'https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek',
    ]
    for url in channels:
        ZDFChannelIE()._real_extract(url)

# Generated at 2022-06-24 13:53:45.952566
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE(None)
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:53:56.122649
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url1 = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    url2 = 'https://www.zdf.de/dokumentation/planet-e'
    url3 = 'https://www.zdf.de/filme/taunuskrimi/'
    assert not ZDFChannelIE.suitable(url1)
    assert ZDFChannelIE.suitable(url2)
    assert not ZDFChannelIE.suitable(url3)
    zdf_channelie = ZDFChannelIE()
    zdf_channelie._match_id(url1)
    zdf_channelie._match_id(url2)
    zdf_channelie._match_id(url3)
    zdf_channelie._extract_channel_id('')


# Generated at 2022-06-24 13:53:59.063752
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    zdf = ZDFBaseIE()



# Generated at 2022-06-24 13:54:09.525866
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .. import ZDFBaseIE
    assert ZDFBaseIE is not None
    ZDFBaseIE._GEO_COUNTRIES = ['DE']
    ZDFBaseIE._QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert determine_ext('https://zdf-cdn.live.cellular.de/hls/zdf/index.m3u8') == 'm3u8'
    assert determine_ext('https://zdf-cdn.live.cellular.de/zdf/video/f2c1bfd6-35e0-4090-b7ec-f91247e6693a/170514_flash_neues_roter_teppich_wm_08/master.f4m') == 'f4m'
    assert determine_ext

# Generated at 2022-06-24 13:54:10.445104
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE({})



# Generated at 2022-06-24 13:54:14.207568
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    zdf_ie._VALID_URL
    zdf_ie._TESTS
    zdf_ie._extract_entry
    zdf_ie._extract_regular
    zdf_ie._extract_mobile
    zdf_ie._real_extract

# Generated at 2022-06-24 13:54:21.104713
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:54:23.953205
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie is not None


# Generated at 2022-06-24 13:54:27.872708
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'

    # Object creation
    ie = ZDFChannelIE(url)

    # Tests
    # Test class variable
    assert ie._VALID_URL == url

    url = 'https://www.zdf.de/filme/taunuskrimi/'

    # Object creation
    ie = ZDFChannelIE(url)

    # Test class variable
    assert ie._VALID_URL == url

# Generated at 2022-06-24 13:54:36.765577
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    t = ie._TESTS[0]
    assert t['url'] == ie._VALID_URL
    assert t['md5'] == ie._VALID_MD5
    assert t['info_dict']['id'] == ie._VALID_ID
    assert t['info_dict']['ext'] == ie._VALID_EXT
    assert t['info_dict']['title'] == ie._VALID_TITLE
    assert t['info_dict']['description'] == ie._VALID_DESCRIPTION
    assert t['info_dict']['duration'] == ie._VALID_DURATION
    assert t['info_dict']['timestamp'] == ie._VALID_TIMESTAMP

# Generated at 2022-06-24 13:54:38.883788
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ["DE"]
    assert ie._QUALITIES == ("auto", "low", "med", "high", "veryhigh", "hd")



# Generated at 2022-06-24 13:54:50.714129
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    webpage = 'https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html'
    ie = ZDFIE()
    ie.extract(webpage)
    assert ie._download_webpage(url=webpage, video_id=None, fatal=False)
    assert ie._extract_player(webpage=webpage, video_id=None, fatal=False)
    player = {
        "apiToken": "dlwDnFpBskvZugA8",
        "content": "https://api.zdf.de/content/documents/zdfmediathek-trailer-100.html?profile=player"
    }

# Generated at 2022-06-24 13:54:55.113068
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'ZDF'
    assert zdfie.GEO_COUNTRIES == ['DE']
    assert zdfie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:54:55.735604
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-24 13:55:03.581110
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE_instance = ZDFChannelIE()
    print(zdfChannelIE_instance)
    # Test if _VALID_URL of class ZDFChannelIE is "https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)"
    print(zdfChannelIE_instance._VALID_URL)
    # Test if ie_key of class ZDFChannelIE is "ZDFChannel"
    print(zdfChannelIE_instance.ie_key())
    # Test constructor
    print(ZDFChannelIE('ZDFChannel'))
    # Test if suitable method is working successfully

# Generated at 2022-06-24 13:55:13.380169
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from unittest import mock
    from .common_test_data import DOCUMENT_WITH_MODULE_TWO_TEASER as data
    # Construct a new object with mocked config and session
    with mock.patch('youtube_dl.extractor.zdf.ZDFBaseIE.config', new_callable=dict) as config, \
         mock.patch('youtube_dl.extractor.zdf.ZDFBaseIE.session', new_callable=compat_HTTPErrorProcessor) as session:
        content = data.read()
        config['http_chunk_size'] = lambda *args, **kwargs: 1024
        session.get.return_value = compat_StringIO(content)
        zdf = ZDFChannelIE()

# Generated at 2022-06-24 13:55:15.044741
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = "https://www.zdf.de/dokumentation/planet-e"
    ie = ZDFChannelIE.suitable(url)
    assert ie == ZDFChannelIE


# Generated at 2022-06-24 13:55:19.015940
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        from pytube import YouTube
    except ImportError:
        return
    # Attempts to construct a ZDFChannelIE.
    youtube = YouTube('https://www.zdf.de/nachrichten/zdf-newsticker')
    assert isinstance(youtube, YouTube)


# Generated at 2022-06-24 13:55:19.672002
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE

# Generated at 2022-06-24 13:55:25.625997
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    '''
    Constructor test
    '''
    ie = ZDFIE()

    assert ie.geo_countries == ['DE']
    assert ie.qualities == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    return ie



# Generated at 2022-06-24 13:55:28.649483
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE()
    assert inst._GEO_COUNTRIES == ['DE']
    assert inst._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Unit tests for ZDFBaseIE._call_api

# Generated at 2022-06-24 13:55:31.649692
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:55:32.281455
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-24 13:55:34.306110
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Unit test for class ZDFBaseIE"""
    # Assert calls constructor
    ie = ZDFBaseIE()
    assert ie is not None



# Generated at 2022-06-24 13:55:38.630429
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE([])
        assert False
    except TypeError as e:
        assert True

# Generated at 2022-06-24 13:55:43.205204
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:55:47.185112
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES is ie.__class__._GEO_COUNTRIES
    assert ie._QUALITIES is ie.__class__._QUALITIES


# Generated at 2022-06-24 13:55:48.178401
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(ZDFBaseIE())


# Generated at 2022-06-24 13:55:49.962998
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE(_VALID_URL, None).ie_key() == 'ZDF'



# Generated at 2022-06-24 13:55:52.581518
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-24 13:55:53.962049
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    cache = {}
    ie = ZDFBaseIE(cache)
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 13:56:02.059964
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test for _call_api of class ZDFBaseIE"""
    try:
        import requests
    except ImportError:
        requests = None
    if requests is None:
        return
    dummy_url = 'https://www.zdf.de/'

    zdf_base_ie = ZDFBaseIE()
    zdf_base_ie._download_json = lambda a: requests.get(a).content
    dummy_response = zdf_base_ie._call_api(dummy_url, None, None)
    assert isinstance(dummy_response, str)

# Generated at 2022-06-24 13:56:10.819786
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
	from . import YoutubeIE
	ie = ZDFBaseIE()
	assert youtube_ie
	assert (re.match(r'\Ahttps?://www\.zdf\.de/', ie.ZDF_URL) != None)
	assert ie.ZDF_URL != ""
	assert ie.ZDF_URL == "https://www.zdf.de/"
	assert ie._GEO_COUNTRIES == ['DE']
	assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
	assert type(ie._call_api) == instancemethod
	assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
	assert type(ie._extract_subtitles) == instancemethod

# Generated at 2022-06-24 13:56:15.952505
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert hasattr(obj,'_call_api')
    assert hasattr(obj,'_extract_subtitles')
    assert hasattr(obj,'_extract_format')
    assert hasattr(obj,'_extract_ptmd')
    assert hasattr(obj,'_extract_player')


# Generated at 2022-06-24 13:56:17.977669
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    Constructor for class ZDFIE
    """
    class_ = ZDFIE



# Generated at 2022-06-24 13:56:21.676523
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-24 13:56:25.955298
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert ie.title() == 'Die Magie der Farben (2/2)'


# Generated at 2022-06-24 13:56:32.881186
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.geo_countries == ie._GEO_COUNTRIES

# Generated at 2022-06-24 13:56:34.321143
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie is not None

# Extractor for downloadable old ZDF videos.

# Generated at 2022-06-24 13:56:37.687957
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannelie_obj = ZDFChannelIE()
    assert zdfchannelie_obj.suitable('https://www.zdf.de/filme/taunuskrimi/') == True



# Generated at 2022-06-24 13:56:39.564387
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    b = ZDFChannelIE()
    assert b.suitable(ZDFChannelIE._VALID_URL)
    assert not b.suitable(ZDFIE._VALID_URL)

# Generated at 2022-06-24 13:56:47.289108
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channels = [
        "https://www.zdf.de/dokumentation",
        "https://www.zdf.de/sport",
        "https://www.zdf.de/tatort",
        "https://www.zdf.de/terra-x/videos",
        "https://zdf-kinder.de",
    ]

    for channel in channels:
        zdf_channel = ZDFChannelIE()
        assert zdf_channel.suitable(channel)

# Generated at 2022-06-24 13:56:57.060665
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert 'ZDFBaseIE' in globals()
    assert 'InfoExtractor' in globals()
    assert issubclass(ZDFBaseIE, InfoExtractor)
    assert isinstance(ZDFBaseIE, type)
    assert hasattr(ZDFBaseIE, '_GEO_COUNTRIES')
    assert hasattr(ZDFBaseIE, '_QUALITIES')
    assert hasattr(ZDFBaseIE, '_call_api')
    assert hasattr(ZDFBaseIE, '_extract_subtitles')
    assert hasattr(ZDFBaseIE, '_extract_format')
    assert hasattr(ZDFBaseIE, '_extract_ptmd')
    assert hasattr(ZDFBaseIE, '_extract_player')

# Generated at 2022-06-24 13:57:10.063379
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE('www.zdf.de/sport/das-aktuelle-sportstudio')
    print(zdf)
    print(zdf.suitable(''))
    print(zdf.suitable('https://www.zdf.de/filme/taunuskrimi/'))
    print(zdf.suitable('https://www. zdf.de/dokumentation/planet-e'))
    print(zdf.suitable('https://www.zdf.de/dokumentation/planet-e/'))
    print(zdf.suitable('https://www.zdf.de/dokumentation/planet-e/'))

# Generated at 2022-06-24 13:57:13.069468
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-24 13:57:15.949518
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert(ZDFBaseIE._GEO_COUNTRIES == ['DE'])
    assert(ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-24 13:57:18.242602
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    print(ZDFIE()._call_api('testurl', 'testid', 'testitem', 'testapi', 
                            'testref'))



# Generated at 2022-06-24 13:57:20.387730
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() == 'ZDF'


# Generated at 2022-06-24 13:57:24.592728
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Unit tests for class InfoExtractor

# Generated at 2022-06-24 13:57:25.555710
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Tests the constructor of the class ZDFBaseIE
    assert callable(ZDFBaseIE)



# Generated at 2022-06-24 13:57:29.986556
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    r"""
    # constructor of class ZDFChannelIE
    """

    # self.to_screen('Unit test for constructor of class ZDFChannelIE')
    #
    # # Construct an instance of ZDFChannelIE
    # zdf_channel_ie_obj = ZDFChannelIE()

    pass


# Generated at 2022-06-24 13:57:35.111720
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Unit test for constructor of class ZDFChannelIE"""
    # The upper code is commented out, so that it can be pasted into
    # the appropriate class definition.  The unit test code should
    # be kept separate.
    assert False, 'Unit test code must be pasted into class definition.'


# Generated at 2022-06-24 13:57:37.472706
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    # We don't want to run this actually
    raise NotImplementedError


# Generated at 2022-06-24 13:57:39.079624
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

# Test extraction of ZDFIE and subclass

# Generated at 2022-06-24 13:57:49.495212
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert isinstance(ie, InfoExtractor) # Test the inheritance
    assert ie.geo_verification_headers() == {'X-Geoblocking-Origin': '1'} # Test the geo verification headers
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html' # Test the regular expression
    assert ie._GEO_COUNTRIES == ['DE'] # Test the geo countries
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd') # Test the qualities

# Generated at 2022-06-24 13:57:58.490823
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFBaseIE
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ZDFIE
    assert ZDFIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-24 13:58:02.063151
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert repr(ZDFChannelIE.get_ie(ZDFChannelIE.ie_key())).startswith("<class 'youtube_dl.extractor.zdf.ZDFChannelIE'>")   # pylint: disable=protected-access


# Generated at 2022-06-24 13:58:03.240011
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-24 13:58:04.675671
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE().ie_key() == 'ZDF'


# Generated at 2022-06-24 13:58:13.662367
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    fieldnames = ['url', 'playlist_mincount']
    reader = unicodecsv.DictReader(
        io.BytesIO(b'''url,playlist_mincount
%s,%s''' % (ZDFChannelIE._TESTS[0]['url'].encode('utf-8'),
            ZDFChannelIE._TESTS[0]['playlist_mincount'])),
        fieldnames=fieldnames,
        delimiter=',')
    row = next(reader)
    assert ZDFChannelIE._get_test_cases().next() == row



# Generated at 2022-06-24 13:58:19.732337
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannel = ZDFChannelIE()
    assert zdfchannel.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdfchannel.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')


# Generated at 2022-06-24 13:58:29.478124
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # test valid url
    extractor = ZDFChannelIE.from_url('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert extractor.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert extractor.suitable('https://www.zdf.de/filme/taunuskrimi/')
    # test invalid url
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/fernsehserien/taunuskrimi/taunuskrimi-die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert not ZDFChannelIE

# Generated at 2022-06-24 13:58:37.004106
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # create dummy class to instantiate the IE
    # this will allow us to call the constructor of ZDFChannelIE
    class TestZDFChannelIE(ZDFChannelIE):
        ie_key = 'test'
        _VALID_URL = r'(?:https?://)?(?:\w+\.)?zdf\.de/.+'
    # assert that we create an instance of a `_ZDFChannelIE`
    assert isinstance(TestZDFChannelIE(), ZDFChannelIE)

# Generated at 2022-06-24 13:58:38.352373
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE.ZDFChannelIE('test')
    assert_true(isinstance(ie, ZDFChannelIE))

# Generated at 2022-06-24 13:58:41.561143
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannelie = ZDFChannelIE()
    assert zdfchannelie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 13:58:42.257343
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass

# Generated at 2022-06-24 13:58:46.397073
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE.__name__ == 'ZDFBaseIE', 'Class name is wrong'
    assert ZDFBaseIE.ie_key() == 'ZDF', 'IeKey is wrong'
    return ZDFBaseIE

# Generated at 2022-06-24 13:58:47.791501
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Assert that constructor of subclass ZDFChannelIE doesn't raise error
    assert ZDFChannelIE(ZDFChannelIE.ie_key())



# Generated at 2022-06-24 13:58:51.604064
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._extract_regular(None, None, None)
    ZDFIE()._extract_mobile(None)
    ZDFIE()._real_extract(None)


# Generated at 2022-06-24 13:59:01.818065
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z = ZDFChannelIE()
    assert z._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert z._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert z._TESTS[0]['info_dict']['id'] == 'das-aktuelle-sportstudio'
    assert z._TESTS[0]['playlist_mincount'] == 23
    assert z._TESTS[1]['url'] == 'https://www.zdf.de/dokumentation/planet-e'

# Generated at 2022-06-24 13:59:11.434465
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    results = ie._TESTS[0]
    test, = results['info_dict']['id']
    url = ie._VALID_URL + test
    webpage = ie._download_webpage(url, test, fatal=False)
    player = ie._extract_player(webpage, test, fatal=False)
    content = ie._call_api(
            player['content'], test, 'content', player['apiToken'], url)
    entry = ie._extract_entry(player['content'], player, content, test)
    assert entry['title'] == results['info_dict']['title']
    assert entry['description'] == results['info_dict']['description']
    assert entry['timestamp'] == results['info_dict']['timestamp']

# Generated at 2022-06-24 13:59:22.310259
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.utils import ExtractorError
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.http import HttpRequest
    from youtube_dl.downloader.http import HEADRequest
    from youtube_dl.compat import compat_urllib_parse_urlencode

    class ZDFChannelHttpFD(HttpFD):
        # File descriptor used for testing

        def __init__(self, info_dict, filename, expected_headers, expected_query, expected_url):
            self.filename = filename
            self.expected_headers = expected_headers
            self.expected_query = expected_query
            self.expected_url = expected_url

        def _fetch(self, url_or_request, *args, **kwargs):
            parsed_url = compat_urllib_parse_

# Generated at 2022-06-24 13:59:23.270349
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # TODO: to implement
    assert 0


# Generated at 2022-06-24 13:59:28.993779
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    zdf = ZDFBaseIE(geo_countries=['DE'])
    zdf = ZDFBaseIE(geo_countries=['DE'], qualities=['low', 'mid', 'high'])

# Generated at 2022-06-24 13:59:40.192417
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    c = ZDFChannelIE()
    assert c._VALID_URL == ZDFChannelIE._VALID_URL
    assert c._TESTS == ZDFChannelIE._TESTS
    assert c.suitable(ZDFChannelIE._TESTS[0].get('url')) == True
    url = ZDFChannelIE._TESTS[0].get('url')
    assert url == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert c.suitable(url) == True
    assert c.suitable(ZDFChannelIE._TESTS[1].get('url')) == True
    assert c.suitable(ZDFChannelIE._TESTS[2].get('url')) == True


# Generated at 2022-06-24 13:59:42.072058
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE({})
    assert z is not None


# Generated at 2022-06-24 13:59:53.503090
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

    assert ie._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert ie._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert ie._TESTS

# Generated at 2022-06-24 14:00:01.015609
# Unit test for constructor of class ZDFBaseIE