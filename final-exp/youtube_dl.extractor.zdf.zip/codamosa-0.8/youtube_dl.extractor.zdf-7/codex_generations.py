

# Generated at 2022-06-12 18:49:29.444564
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    assert instance._VALID_URL ==  r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:49:37.932649
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        from youtube_dl.extractor import ZDFIE
    except ImportError:
        return
    ie = ZDFIE()
    assert ie.geo_verification_headers() is not None
    assert ie.geo_verification_proxy() is None

    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    with open('test/testdata/zdf_base.txt') as myfile:
        data=myfile.read()
    player_info = json.loads(js_to_json(data))
    url = 'https://www.zdf.de/servic...'
    info = ie._extract_player(url, player_info, None, None)

# Generated at 2022-06-12 18:49:40.412165
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-12 18:49:43.321167
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE('name', None)
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:49:44.468660
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE() # Just test constructor


# Generated at 2022-06-12 18:49:52.401773
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_utils import get_testdata_video

    webpage = get_testdata_video('zdf-dokumentation/planet-e')['webpage']
    channel_id = 'planet-e'
    player = ZDFIE()._extract_player(webpage, 'https://www.zdf.de/dokumentation/planet-e')

    channel = ZDFChannelIE()._call_api('https://api.zdf.de/content/documents/%s.json' % channel_id, player, 'https://www.zdf.de/dokumentation/planet-e', channel_id)

    assert channel['id'] == channel_id
    assert channel.get('title') == 'planet e.'
    assert len(channel['module']) == 2

    # Test for class attribute '_VALID_

# Generated at 2022-06-12 18:50:01.270243
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print('-'*50, 'Testing constructor of class ZDFChannelIE'+'-'*50)
    import sys
    from inspect import getdoc
    from inspect import getsource
    from inspect import getmembers
    from inspect import isclass
    from importlib import import_module
    from os.path import dirname
    from os.path import realpath
    module_obj = import_module(__package__ + '.' + ZDFChannelIE.__name__)
    for _, obj in getmembers(module_obj):
        if isclass(obj):
            if obj.__doc__:
                print('-'*50, 'Documentation of', obj.__name__+'-'*50)
                print((getdoc(obj)))

# Generated at 2022-06-12 18:50:05.995134
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    zdf._VALID_URL = 'https://www.zdf.de/sport/zdf-sport/'
    assert zdf._VALID_URL == 'https://www.zdf.de/sport/zdf-sport/'


# Generated at 2022-06-12 18:50:14.143179
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Missing tag "zdf:player"
    webpage = """<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head></html>"""
    assert ZDFBaseIE()._extract_player(webpage, 'dummy', False) == {}

    # Invalid JSON

# Generated at 2022-06-12 18:50:17.509514
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('test_ZDFBaseIE', 'test_ZDFBaseIE', 'test_ZDFBaseIE')
    ie.to_screen('test_ZDFBaseIE')


# Generated at 2022-06-12 18:51:02.554101
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()

# Generated at 2022-06-12 18:51:08.302821
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.ZDFChannelIE import ZDFChannelIE
    from youtube_dl.utils import parse_age_limit
    from tests.helper import FakeYDL
    ydl = FakeYDL()
    ydl.add_info_extractor(ZDFChannelIE)
    # Test for 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ydl.params['nooverwrites'] = True
    ydl.params['noplaylist'] = True
    r = ydl.extract_info(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio', download=False)

# Generated at 2022-06-12 18:51:09.032189
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-12 18:51:10.814207
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    _test_class(ZDFChannelIE, [
        'https://www.zdf.de/dokumentation/planet-e'])
# }}}

# {{{ ARDNewstival

# Generated at 2022-06-12 18:51:13.817357
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    expected = ZDFIE._TESTS[0]
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'
    assert ie.GEO_COUNTRIES == ZDFBaseIE._GEO_COUNTRIES

# Test whether ZDFIE provides the correct video when searching on it's website

# Generated at 2022-06-12 18:51:24.795818
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import requests
    import requests_mock


# Generated at 2022-06-12 18:51:36.018310
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try: # Fails on Windows due to Python bug #25195
        ZDFChannelIE._build_m3u8_formats.get_caller_name()
    except Exception as e:
        raise SkipTest('test_ZDFChannelIE(): %s' % e)
    url = 'https://www.zdf.de/dokumentation/planet-e'
    obj = ZDFChannelIE()
    assert obj.suitable(url)
    obj._download_webpage = lambda *args: 'webpage'
    obj._og_search_title = lambda *args: 'title'
    obj._extract_player = lambda *args: {'apiToken': 'apiToken', 'content': 'content'}

# Generated at 2022-06-12 18:51:37.534283
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-12 18:51:41.104293
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()
    assert zdf.ie_key() == 'ZDFChannel'
    assert zdf.name == 'ZDF Channel'
    assert zdf.description == 'zdf.de videos, grouped by channel'
    assert zdf.available == True
    assert zdf.url_re == ZDFChannelIE._VALID_URL
    assert repr(zdf) == 'ZDFChannel(ZDF Channel,zdf.de videos, grouped by channel,available)'



# Generated at 2022-06-12 18:51:49.868109
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url_test_1 = 'http://www.zdf.de'
    url_test_2 = 'https://www.zdf.de'
    url_test_3 = 'http://zdf.de'
    url_test_4 = 'https://zdf.de'
    # ZDFBaseIE is abstract and must not be instantiated
    try:
        # pylint: disable=abstract-class-instantiated
        ZDFBaseIE(url_test_1)
        print("ERROR: Test #1 (%s) has not thrown exception" % url_test_1)
    except NotImplementedError:
        pass
    else:
        print("ERROR: Test #2 (%s) has not failed" % url_test_2)

# Generated at 2022-06-12 18:52:41.439417
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE({})

# Generated at 2022-06-12 18:52:46.991622
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():

    ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    ZDFChannelIE.suitable('https://www.zdf.de/filme/zdf-history/')
    ZDFChannelIE.suitable('https://www.zdf.de/kinder/logo!-das-quiz')
    ZDFChannelIE.suitable('https://www.zdf.de/politik/')
    ZDFChannelIE.suitable('https://www.zdf.de/sport/')



# Generated at 2022-06-12 18:52:53.139275
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.downloader.http import HttpFD

    # Set up downloader
    ydl = FileDownloader({})
    ydl.httpfd = HttpFD(ydl)

    # Test for a channel.
    # Make sure at least one item has been added to the list of dicts.
    assert ZDFChannelIE(ydl).extract_info(
        'https://www.zdf.de/dokumentation/planet-e')['_type'] == 'playlist'

# Generated at 2022-06-12 18:52:57.315982
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    if ie.suitable(None):
        print("Test failed: suitable()")
    if ie._VALID_URL != ie.VALID_URL:
        print("Test failed: VALID_URL")



# Generated at 2022-06-12 18:52:59.991880
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # arrange
    expected = ZDFIE
    # act
    actual = ZDFIE('ZDFIE', 'zdf', 'ZDF')
    # assert
    assert actual is expected



# Generated at 2022-06-12 18:53:06.271561
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE
    channel_ie = ZDFChannelIE('http://www.zdf.de/dokumentation/planet-e');
    # test_class
    assert channel_ie.__class__.__name__ == 'ZDFChannelIE'
    # test_suitable
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e.html')
    # test_real_extract
    assert channel_ie._real_extract('https://www.zdf.de/dokumentation/planet-e')['_type'] == 'playlist'

# Generated at 2022-06-12 18:53:14.839954
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = 'http://www.zdf.de/ZDFmediathek/beitrag/video/3000008/xxx'
    video_id = '3000008'
    ie = ZDFIE(url)
    test_meta = ie._extract_ptmd('http://foo.bar/ptmd/123.xml', 'test_id', 'test_token', 'test_referrer')
    assert test_meta == {'extractor_key': 'Zdf', 'id': '123', 'duration': None, 'formats': [], 'subtitles': {}}
    test_player_json = ie._extract_player('<div data-zdfplayer-jsb="{}"></div>', 'test_player')
    assert test_player_json == {}



# Generated at 2022-06-12 18:53:15.933434
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert isinstance(ZDFBaseIE, type)


# Generated at 2022-06-12 18:53:18.840430
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    obj = ie._RealZDFIE__extract_regular
    assert obj('url', {'content': 'content_url'}, 'video_id') is None
    assert obj('url', {'content': 'content_url'}, 'video_id') is None


# Generated at 2022-06-12 18:53:27.582634
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Unit test for constructor of class ZDFChannelIE
    """
    from . import ZDFChannelIE
    k = ZDFChannelIE(ZDFChannelIE.suitable)
    assert not k.suitable('https://www.zdf.de/filme-und-serien/die-strassen-von-berlin/die-strassen-von-berlin-der-tote-im-tiergarten-100.html')
    assert k.suitable('https://www.zdf.de/filme-und-serien/die-strassen-von-berlin/')


# Generated at 2022-06-12 18:55:40.793866
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    instance = ZDFChannelIE()
    # To be compatible with python 2, class ZDFChannelIE can't be decorated by
    # @classmethod.
    assert_equal(instance.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'), True)
    assert_equal(instance.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html'), False)

# Generated at 2022-06-12 18:55:44.345826
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie
    assert zdf_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdf_ie._GEO_COUNTRIES == ['DE']

# Generated at 2022-06-12 18:55:49.238045
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
  video_id = 'test'
  website = 'http://www.zdf.de/ZDFmediathek/hauptnavigation/startseite'
  ie = ZDFBaseIE(ZDFBaseIE.ie_key())
  player = ie._extract_player(website, video_id)
  assert player['data']['config']['mediaCollection']['items'][0]['apiBaseUri'] == 'https://api.zdf.de/content/'
  return player

test_ZDFBaseIE()


# Generated at 2022-06-12 18:55:51.450914
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Tests to know if the constructor of class ZDFBaseIE raises an exception
    from .zdf import ZDFIE
    inst = ZDFIE()


# Generated at 2022-06-12 18:55:55.705588
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE()
    test_cases = [
            {
                'url': 'https://www.zdf.de/dokumentation/planet-e',
                'expected': True,
            },
            {
                'url': 'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html',
                'expected': False,
            }
    ]
    for test_case in test_cases:
        result = zdfChannelIE.suitable(test_case['url'])
        assert result == test_case['expected'], 'suitable(url) failed with %s' % test_case['url']



# Generated at 2022-06-12 18:55:59.378333
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdfie._TESTS is not None

# Generated at 2022-06-12 18:56:03.340622
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test cases for constructor
    # Passed when assert-statement is True
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.BRAND_KEY == 'zdf'



# Generated at 2022-06-12 18:56:10.808773
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/kultur')
    assert ZDFChannelIE.suitable('https://www.zdf.de/wissen/kultur')
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

# Generated at 2022-06-12 18:56:16.412385
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from ..extractor import gen_extractors
    extractors = gen_extractors()
    for ie in orderedSet(extractors.values()):
        if ie.ie_key() == 'ZDF':
            zdf_ie = ie
            break
    zdf = zdf_ie(None)
    res = zdf._call_api(
        'https://zdf-cdn.live.cellular.de/mediathekV2/aktuell/live-377924',
        '377924',
        'live')
    assert isinstance(res, dict)
    assert res['name'] == 'heute Xpress'



# Generated at 2022-06-12 18:56:18.192867
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base = ZDFBaseIE()
    assert base
