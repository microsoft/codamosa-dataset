

# Generated at 2022-06-12 18:49:29.444750
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    # The following assertions ensure that the constructor has the same argument names
    # as in the class definition above.
    assert ie.IE_NAME == 'zdf'
    assert ie.IE_DESC == 'ZDF'
    # assert ie._GEO_COUNTRIES == ['DE']

# Generated at 2022-06-12 18:49:31.700562
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.__class__.__name__ == 'ZDFBaseIE'


# Generated at 2022-06-12 18:49:39.018756
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base_ie = ZDFBaseIE()
    assert base_ie._GEO_COUNTRIES == ['DE']
    assert base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert isinstance(base_ie._call_api('https://www.zdf.de/', 'test', 'test'), dict)
    assert isinstance(base_ie._extract_subtitles({'captions': [{'uri': 'https://www.zdf.de/', 'language': 'deu'}, {'language': 'deu'}]}), dict)

# Generated at 2022-06-12 18:49:40.379343
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

# Generated at 2022-06-12 18:49:44.991602
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    class_ = ZDFIE

    assert class_.ie_key() == 'ZDF'
    assert class_.ie_key() == 'ZDF'
    assert class_._VALID_URL.strip() == 'https?://www\\.zdf\\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\\.html'
    assert isinstance(class_._TESTS, list)


# Generated at 2022-06-12 18:49:46.306186
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Just test the constructor for a successful execution
    ZDFBaseIE()


# Generated at 2022-06-12 18:49:47.851367
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert True == isinstance(ZDFIE(), InfoExtractor)



# Generated at 2022-06-12 18:49:53.817912
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print("Testing constructor of class ZDFChannelIE ...")
    zdf_channel_url = 'https://www.zdf.de/dokumentation/planet-e'
    zdf_channel_ie = ZDFChannelIE(ZDFChannelIE.suitable(zdf_channel_url))
    assert zdf_channel_ie is not None
    print("Test of class ZDFChannelIE constructor successful.")


# Generated at 2022-06-12 18:50:02.118249
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/nachrichten/politik/thema/tau-bgbl-fuer-die-bundeswehr/video/1-tauechte-bundestagsabstimmung-verschiebt-sich-neu-ab-18-uhr/bundestag-hat-tauechte-verabschiedet-100.html'
    
    test_ZDFIE = ZDFIE()
    webpage = test_ZDFIE._download_webpage(url, video_id=url, fatal=False)
    assert webpage is not None
    
    player = test_ZDFIE._extract_player(webpage, url, fatal=False)
    assert player is not None
    

# Generated at 2022-06-12 18:50:05.559840
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
    except(AttributeError, TypeError) as e:
        assert(False, 'Cannot construct ZDFBaseIE object. Wrong arguments passed.')
        return


# Generated at 2022-06-12 18:50:54.311983
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_class = ZDFBaseIE()
    test_class.report_warning = lambda msg: None
    test_class._call_api('http://example.com', '163004', 'video')



# Generated at 2022-06-12 18:50:59.016508
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_str = 'https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html'
    ZDFChannelIE.suitable(test_str)
    ZDFChannelIE(test_str)


# Generated at 2022-06-12 18:51:07.759941
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class TestZDFChannelIE(ZDFChannelIE):
        def _call_api(self, url, video_id, query_id, api_token, referrer=None):
            self.assertEqual(url, 'https://api.zdf.de/content/documents/%s.json' % video_id)
            self.assertEqual(video_id, 'das-aktuelle-sportstudio')
            self.assertEqual(query_id, 'content')


# Generated at 2022-06-12 18:51:09.609322
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Construct an instance of ZDFBaseIE
    
    This test instantiates an instance of ZDFBaseIE and checks if the
    instance is properly constructed.
    """
    ZDFBaseIE()


# Generated at 2022-06-12 18:51:12.184185
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable(url)
    assert zdf_channel_ie._VALID_URL == \
        ZDFChannelIE._VALID_URL

# Generated at 2022-06-12 18:51:18.780316
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class_ = ZDFChannelIE
    assert class_.name == "ZDFChannel"
    assert class_.description == "ZDF Mediathek"
    assert class_.suitable
    assert class_.ie_key() == "ZDFMediathek"
    assert class_.api_host == "https://api.zdf.de"
    assert class_.player_host == "https://www.zdf.de"
    assert class_.subtitle_host == "https://subtitle.zdf.de"
    assert class_.quality_threshold == 0.85

# Generated at 2022-06-12 18:51:22.429751
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie1 = ZDFBaseIE()
    assert ie1._GEO_COUNTRIES == ['DE']
    assert ie1._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    return


# Generated at 2022-06-12 18:51:28.743285
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = 'https://www.zdf.de/politik/zdf-morgenmagazin/morgenmagazin-als-podcast-100.html'
    ie = InfoExtractor.get_info_extractor(ZDFBaseIE.ie_key())
    try:
        ie.suitable(url)
        assert(True)
    except:
        assert(False)


# Generated at 2022-06-12 18:51:36.205472
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._call_api is not None
    assert zdf._extract_format is not None
    assert zdf._extract_player is not None
    assert zdf._extract_ptmd is not None
    assert zdf._extract_subtitles is not None
    assert zdf._GEO_COUNTRIES is not None
    assert zdf._QUALITIES is not None
    assert type(zdf) == ZDFBaseIE
    assert zdf.__class__.__name__ == 'ZDFBaseIE'

# Generated at 2022-06-12 18:51:37.468667
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    custom_test_ie_test('ZDFIE', 'ZDFIE')   # Method implemented in test utils


# Generated at 2022-06-12 18:52:38.046669
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    # ptmd_video
    ptmd_video_url = 'https://api.zdf.de/content/documents/zdf/d1fc8f55-34a2-4f9d-90e5-6f5fd7fd5f10~playerXml.xml'
    ie._extract_ptmd(ptmd_video_url, 'd1fc8f55-34a2-4f9d-90e5-6f5fd7fd5f10', 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9',
        'https://www.zdf.de/kinder/logo/sendung-mit-der-maus-und-logo-im-ersten-100.html')


# Generated at 2022-06-12 18:52:41.115080
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    instance = ZDFChannelIE()
    assert isinstance(instance, ZDFChannelIE)


# Generated at 2022-06-12 18:52:46.709064
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():

    # Empty list of urls
    urls = []
    try:
        channel = ZDFChannelIE(urls)
    except AssertionError:
        channel = None
    assert channel is None, 'Expected channel to be None'

    urls = ['https://zdf.de/foo']
    correct_ie_key = 'zdf:channel'
    try:
        channel = ZDFChannelIE(urls)
    except AssertionError:
        channel = None
    assert channel.ie_key() == correct_ie_key, 'Expected ie_key to be %s, but was %s' % (correct_ie_key, channel.ie_key())

# Generated at 2022-06-12 18:52:52.540014
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE()

# Generated at 2022-06-12 18:52:56.614726
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:53:03.717785
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    # Test when 'player' is not defined
    zdf_ie._extract_regular('test_url', None, 'test_id')
    # Test when 'content' is not defined
    zdf_ie._extract_regular('test_url', {'apiToken': 'test_token'}, 'test_id')
    # Test when 'apiToken' is not defined
    zdf_ie._extract_regular('test_url', {'content': 'test_url'}, 'test_id')
    # Test when 'content' is not defined
    zdf_ie._extract_regular('test_url', {'apiToken': 'test_token', 'content': {}}, 'test_id')



# Generated at 2022-06-12 18:53:13.185351
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfe = ZDFIE()
    zdfe.geo_blocked_countries = []
    zdfe.geo_verification_headers = {}
    zdfe.geo_bypass = False
    zdfe.geo_bypass_ip = None
    zdfe.geo_bypass_ip_list = []
    assert zdfe._GEO_COUNTRIES == ['DE']
    assert zdfe._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdfe._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:53:20.259178
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Tests for ZDFIE
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-vom-koenigspurpur-bis-jeansblau-100.html'
    ie = ZDFIE()
    assert ie is not None
    assert ie.ie_key() == 'ZDF'
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:53:22.801382
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Dummy instance of ZDFBaseIE
    ie = ZDFBaseIE()
    if ie is not None:
        print('Instantiated a dummy instance of class ZDFBaseIE')

# Generated at 2022-06-12 18:53:26.528167
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:55:55.062211
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()

    assert zdf_ie.IE_KEY == 'ZDF'
    assert zdf_ie.ie_key() == 'ZDF'
    assert zdf_ie._downloader.params.get('nocheckcertificate') == '1'
    assert isinstance(zdf_ie._GEO_COUNTRIES, tuple)
    assert isinstance(zdf_ie._QUALITIES, tuple)
    assert len(zdf_ie._QUALITIES) == 6
    assert len(zdf_ie.GEO_BYPASS) == 2
    assert zdf_ie.GEO_BYPASS_COUNTRIES == zdf_ie._GEO_COUNTRIES
    assert zdf_ie.DEFAULT_HEADERS['Api-Auth'] == 'Bearer null'

#

# Generated at 2022-06-12 18:55:58.473332
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # First, the standard test
    base_ie = ZDFBaseIE()
    assert base_ie is not None
    # Now, the test with invalid arguments
    try:
        ZDFBaseIE(None, None)
    except AssertionError:
        pass



# Generated at 2022-06-12 18:56:04.375690
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # test constructor of ZDFBaseIE
    ie = ZDFBaseIE()
    assert ie.IE_NAME == 'ZDF'
    assert ie.GEO_COUNTRIES == ['DE']
    assert ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-12 18:56:05.532883
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('ZDFBaseIE')


# Generated at 2022-06-12 18:56:06.698642
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import doctest
    doctest.testmod()


# Generated at 2022-06-12 18:56:08.209681
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE('http://www.zdf.de/Doku/22.html')


# Generated at 2022-06-12 18:56:16.064133
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.utils import DEFAULT_OUTTMPL as DEFAULT_OUTTMPL
    with NamedTemporaryFile(dir='.', prefix='', suffix='.mp4') as f:
        outtmpl = f.name

# Generated at 2022-06-12 18:56:16.721403
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    t = ZDFBaseIE('1', '2')

# Generated at 2022-06-12 18:56:18.192752
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE("ZDFBaseIE")

# Generated at 2022-06-12 18:56:21.013442
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
