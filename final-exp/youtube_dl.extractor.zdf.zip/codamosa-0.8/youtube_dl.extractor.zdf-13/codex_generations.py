

# Generated at 2022-06-12 18:49:18.978310
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE(None, None)
    assert hasattr(ie, "download_json")
    return True


# Generated at 2022-06-12 18:49:23.328734
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    parse_codecs('avc1.64001E, mp4a.40.2')
    update_url_query('https://www.example.com', {'hdcore': '3.7.0'})



# Generated at 2022-06-12 18:49:27.871523
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.geo_countries == ['DE']
    assert zdfie.qualities == ['auto', 'low', 'med', 'high', 'veryhigh', 'hd']


# Generated at 2022-06-12 18:49:31.180777
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'ZDF'
    assert zdfie.ie_key() == 'ZDF'


# Generated at 2022-06-12 18:49:38.218766
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    a = ZDFChannelIE('a', 'b', 'c')
    assert a.suitable('https://www.zdf.de/dokumentation/planet-e') == True
    assert a.suitable('https://www.zdf.de/sport/die-sport-show') == True
    assert a.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html') == False
    assert a.suitable('https://www.zdf.de/dokumentation/planet-e/ab-18-10-wochen-sommer-102.html') == False



# Generated at 2022-06-12 18:49:42.571983
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Instantiate class ZDFChannelIE
    zdfchannel_ie = ZDFChannelIE()
    # Call _real_extract(url) method, return list of entries
    entries = (zdfchannel_ie._real_extract("https://www.zdf.de/dokumentation/planet-e"))

    # Test if number of entries is > 0 
    assert(len(entries['entries']) > 0)


# Generated at 2022-06-12 18:49:43.524415
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('url', 'video_id')

# Generated at 2022-06-12 18:49:44.475040
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-12 18:49:47.727628
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_ie = ZDFBaseIE(None)
    assert(test_ie._GEO_COUNTRIES == ['DE'])
    assert(test_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))



# Generated at 2022-06-12 18:49:49.619895
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase_ie = ZDFBaseIE()
    assert(zdfbase_ie is not None)


# Generated at 2022-06-12 18:50:34.701038
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()


# Generated at 2022-06-12 18:50:40.753112
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert not ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

# Generated at 2022-06-12 18:50:41.576287
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-12 18:50:46.693357
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert(ie.url == 'https://www.zdf.de/sport/das-aktuelle-sportstudio')

# Generated at 2022-06-12 18:50:47.287706
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-12 18:50:56.072835
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_ZDFBaseIE = ZDFBaseIE()
    assert ZDFBaseIE.ie_key() == 'zdf'
    assert test_ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert test_ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert test_ZDFBaseIE._VALID_URL == r'https?://(?:www\.)?zdf\.de/(?:[^/]+/)+(?P<id>[^/#?]+)'

# Generated at 2022-06-12 18:51:01.357232
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print(ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e'))
    print(ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/'))
    print(ZDFChannelIE.suitable('https://www.zdf.de/filme/die-anstaendigen'))

# Generated at 2022-06-12 18:51:07.039874
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    data = {'_GEO_COUNTRIES': ['DE'], '_QUALITIES': ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')}
    data2 = ZDFBaseIE._extract_player(data, 'webpage', 'video_id')
    assert(data == {'_GEO_COUNTRIES': ['DE'], '_QUALITIES': ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')})
    assert(data2 == {})


# Generated at 2022-06-12 18:51:09.941577
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class TestZDFBaseIE(ZDFBaseIE):
        _VALID_URL = r'^https?://.*$'
        _NETRC_MACHINE = None
        _API_TOKEN = None
        _API_REFERRER = None

    t = TestZDFBaseIE()
    assert isinstance(t, InfoExtractor)


# Generated at 2022-06-12 18:51:11.053180
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'



# Generated at 2022-06-12 18:52:55.559342
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import re
    url = 'https://www.zdf.de/dokumentation/terra-x'
    webpage = open(os.path.join('tests', 'data', 'zdf.de', 'terra-x.html'), 'rb').read().decode('utf-8')
    items = []
    for module in json.loads(re.search(r'window\.__APOLLO_STATE__\s*=\s*({.+?});', webpage, re.DOTALL).group(1))['modules']:
        for teaser in try_get(module, lambda x: x['teaser'], list) or []:
            t = try_get(
                teaser, lambda x: x['http://zdf.de/rels/target'], dict)
            if not t:
                continue

# Generated at 2022-06-12 18:52:57.277592
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    obj = ZDFChannelIE()
    assert obj.ie_key() == "ZDFChannelIE"


# Generated at 2022-06-12 18:52:59.615702
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.name == 'zdf.de'


# Generated at 2022-06-12 18:53:09.361398
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdfie._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert zdfie._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert zdfie._TESTS[0]['info_dict']['id'] == '210222_phx_nachgehakt_corona_protest'

# Generated at 2022-06-12 18:53:10.826444
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert instance._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-12 18:53:12.855414
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = "https://www.zdf.de/dokumentation/planet-e"
    ie = ZDFChannelIE()
    assert ie.suitable(url)

# Generated at 2022-06-12 18:53:19.940906
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    # test with string

# Generated at 2022-06-12 18:53:25.250848
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Verify that the class constructor of class ZDFBaseIE works properly"""
    zdf_ie = ZDFBaseIE()
    assert zdf_ie._GEO_COUNTRIES == ['DE']
    assert zdf_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:53:35.993516
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    parse_codecs = compat_str
    NO_DEFAULT = compat_str
    orderedSet = compat_str
    qualities = compat_str
    part = compat_str
    merge_dicts = compat_str

    assert(type(parse_codecs) == type(type(compat_str)))
    assert(type(NO_DEFAULT) == type(type(compat_str)))
    assert(type(orderedSet) == type(type(compat_str)))
    assert(type(qualities) == type(type(compat_str)))
    assert(type(part) == type(type(compat_str)))
    assert(type(merge_dicts) == type(type(compat_str)))
    print("Test ZDFBaseIE __init__() passed")



# Generated at 2022-06-12 18:53:44.779189
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    video_id = '151025_magie_farben2_tex'
    webpage = ''
    player = ''
    content = ''

# Generated at 2022-06-12 18:56:01.221296
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.__class__.__name__ == 'ZDFIE'
    assert ie.ie_key() == 'zdf'
    assert ie.ie_key() == ZDFIE.ie_key()


# Generated at 2022-06-12 18:56:08.526517
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Check if all the attributes are present in instance of the class
    # ZDFBaseIE
    video_id = 'Kz2uZ7f4Iz'
    base_ie = ZDFBaseIE(InfoExtractor())
    assert base_ie._GEO_COUNTRIES == ['DE']
    assert base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert sorted(base_ie._FORMATS.keys()) == ['high', 'low', 'med', 'veryhigh']
    assert isinstance(base_ie._FORMATS['high'], dict)
    assert isinstance(base_ie._FORMATS['low'], dict)
    assert isinstance(base_ie._FORMATS['med'], dict)

# Generated at 2022-06-12 18:56:16.336773
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-12 18:56:17.700897
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import collections
    assert 'ZDFChannelIE' in globals()
    assert isinstance(globals()['ZDFChannelIE'], collections.Callable)

# Generated at 2022-06-12 18:56:21.650907
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Case 1:
    # url is of class ZDFIE
    url = 'https://www.zdf.de/sendungen-a-z/zdfneo/preis-der-freiheit-1---ein-taunuskrimi-100.html'
    assert not ZDFChannelIE.suitable(url)

    # Case 2:
    # url is of class ZDFChannelIE
    url = 'https://www.zdf.de/filme/taunuskrimi'
    assert ZDFChannelIE.suitable(url)



# Generated at 2022-06-12 18:56:26.646232
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    '''
    Unit test for constructor of class ZDFBaseIE
    '''
    # According to class name, this kind of test should be written in test_zdf.py.
    # It is no matter to combine these tests.
    info_extractor = ZDFBaseIE()
    assert info_extractor._GEO_COUNTRIES == ['DE']
    assert info_extractor._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:56:29.786426
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.SUITABLE(
        'https://www.zdf.de/dokumentation/planet-e')
    assert not(
        zdf_channel_ie.SUITABLE('https://www.zdf.de/dokumentation/planet-e/'))
    assert (
        zdf_channel_ie.SUITABLE('https://www.zdf.de/filme/taunuskrimi/'))



# Generated at 2022-06-12 18:56:34.177155
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
	try:
		assert 'pass!'
	except AssertionError:
		raise AssertionError('Test failed.')
test_ZDFIE()	



# Generated at 2022-06-12 18:56:35.232121
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-12 18:56:42.997245
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()

    assert zdf._call_api(
        "https://api.zdf.de/documents/zattoo/s/s/f968539a-b43a-11e8-8f38-0026b975f2e6/2.0/resources/streaming/h264-hd-live.json", "", "", "", "") != None
