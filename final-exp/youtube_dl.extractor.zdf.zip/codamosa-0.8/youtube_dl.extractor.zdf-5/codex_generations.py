

# Generated at 2022-06-12 18:49:22.559902
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None)

    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:49:24.049960
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-12 18:49:33.332477
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    def test_suitable(url, is_suitable):
        ie = ZDFChannelIE(
            compat_urllib_request.Request(
                url, headers={'User-Agent': 'Wget/1.16 (linux-gnu)'}))
        assert ie.suitable(url) == is_suitable
    # Positive test cases
    test_suitable("https://www.zdf.de/filme/taunuskrimi/", True)
    test_suitable("https://www.zdf.de/dokumentation/planet-e", True)
    test_suitable("https://www.zdf.de/sport/das-aktuelle-sportstudio", True)
    # Negative test cases

# Generated at 2022-06-12 18:49:34.890277
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
  try:
    obj = ZDFChannelIE("")
  except:
    # Specified exception to raise
    raise NameError("Failed to instantiate ZDFChannelIE")
  assert obj != None


# Generated at 2022-06-12 18:49:37.662490
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    I = ZDFBaseIE()
    instance = isinstance(I, InfoExtractor)
    assert instance

test_ZDFBaseIE()



# Generated at 2022-06-12 18:49:40.185320
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    key = ie.ie_key()
    assert key == 'ZDF'



# Generated at 2022-06-12 18:49:43.302137
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """ test for constructor of class ZDFBaseIE """
    try:
        ZDFBaseIE()
    except TypeError:
        raise AssertionError("Unit test for constructor of class ZDFBaseIE has been failed")


# Generated at 2022-06-12 18:49:45.712359
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE()
    assert zdfChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi')

# Generated at 2022-06-12 18:49:49.261682
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    config = {
        'ie': 'ZDFChannel',
        'url': 'http://www.zdf.de/sport/das-aktuelle-sportstudio',
    }
    x = ZDFChannelIE(config)
    x.get_entries()



# Generated at 2022-06-12 18:49:52.134050
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        obj = ZDFChannelIE()
        obj._extract_player('', '')
    except:
        assert False



# Generated at 2022-06-12 18:50:40.042648
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE == type(ZDFIE())


# Generated at 2022-06-12 18:50:41.686459
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE().suitable('https://www.zdf.de/dokumentation/planet-e')
    assert channel == True


# Generated at 2022-06-12 18:50:50.071259
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import _TESTS as TESTS
    for entry in TESTS:
        if 'info_dict' in entry:
            continue
        url = entry['url']
        try:
            ZDFChannelIE(url)
        except ExtractorError as e:
            if e.args[0].startswith('Cannot identify') or e.args[0].startswith('Unsupported URL'):
                continue
        raise ExtractorError('URL "%s" is not a valid %r URL.' % (url, ZDFChannelIE))


# Generated at 2022-06-12 18:50:51.302470
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE()
    z._extract_ptmd("http://www.im.de", "VIDEO_ID", None, None)



# Generated at 2022-06-12 18:50:58.409254
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE()
    # Test with channel
    channel.suitable('https://www.zdf.de/filme/taunuskrimi/')
    # Test with video
    ZDFIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')



# Generated at 2022-06-12 18:51:00.418025
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    global ZDFIE
    ZDFIE('ZDF', 'zdf.de')


# Generated at 2022-06-12 18:51:03.726743
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    Test = type("Test", (object,), dict(__module__="__main__"))
    test = Test()
    test.to_screen = lambda x: x
    ZDFBaseIE("youtube_dl.ZDFBaseIE", test)
    return 0



# Generated at 2022-06-12 18:51:09.501543
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._TESTS[0]['url'] == zdfie._VALID_URL
    assert zdfie._TESTS[0]['md5'] == zdfie._extract_player(zdfie._download_webpage(zdfie._TESTS[0]['url'], 'zdfie_test'), zdfie._TESTS[0]['url'], fatal=False)

# Generated at 2022-06-12 18:51:14.394363
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_IE = ZDFChannelIE()

    assert channel_IE.suitable(ZDFChannelIE._VALID_URL) == True
    assert channel_IE.suitable(ZDFIE._VALID_URL) == False

    assert ZDFChannelIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ZDFChannelIE._TESTS == [{
        'url': 'https://www.zdf.de/sport/das-aktuelle-sportstudio',
    }, {
        'url': 'https://www.zdf.de/dokumentation/planet-e',
    }]

# Generated at 2022-06-12 18:51:22.503262
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.HOST == 'www.zdf.de'
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie.GEO_COUNTRIES == ['DE']
    assert ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:53:17.331228
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    _ZDFIE = ZDFIE('ZDF.DE')
    assert _ZDFIE.ie_key() == 'ZDF'
    assert _ZDFIE._VALID_URL == ZDFIE._VALID_URL


# Generated at 2022-06-12 18:53:25.288603
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.codecs = ['h264', 'vp8', 'vp9']
    ie.prefs = ['h264', 'vp9']
    formats = ie.extract_formats('test.m3u8', 'test', 'hls')
    assert formats == [{'url': 'test.m3u8',
                        'format_id': 'hls',
                        'ext': 'mp4',
                        'protocol': 'm3u8_native',
                        'preference': -10}]

# Generated at 2022-06-12 18:53:26.996052
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # initializing for constructor of class ZDFBaseIE
    ZDFBaseIE(ZDFIE())
    assert True



# Generated at 2022-06-12 18:53:31.328506
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:53:40.626388
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBase = ZDFBaseIE('ZDFBaseIE', 'zdf.de')
    # test _call_api
    zdfBase._call_api('https://www.zdf.de/', '12345', 'test_api', api_token='test_token', referrer='https://www.zdf.de/')
    # test _extract_subtitles
    zdfBase._extract_subtitles({})
    zdfBase._extract_subtitles({'captions': []})
    zdfBase._extract_subtitles({'captions': [{}]})
    zdfBase._extract_subtitles({'captions': [{'language': 'deu'}]})

# Generated at 2022-06-12 18:53:43.793204
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.extract('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')



# Generated at 2022-06-12 18:53:49.452979
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert isinstance(ZDFChannelIE.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html'), bool)
    assert ie.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html') == False

# Generated at 2022-06-12 18:53:52.712261
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    i = ZDFChannelIE()
    assert i.suitable(ZDFChannelIE._VALID_URL)
    assert not i.suitable(ZDFIE._VALID_URL)
    assert i._real_extract(ZDFChannelIE._TESTS[0]['url'])

# Generated at 2022-06-12 18:53:57.264333
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_instance = ZDFIE()
    assert zdf_instance.ie_key() == 'ZDF'
    assert zdf_instance._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:53:58.496523
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE(type='test_ZDFBaseIE')
