

# Generated at 2022-06-12 18:49:18.838521
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:49:21.661849
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:49:24.831947
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from ..extractor import shared as shared_module
    shared = type('shared', (object,), {'get_head_request': dict})
    zdf_ie = ZDFIE(shared)
    assert isinstance(zdf_ie, shared_module.ZDFBaseIE)

# Generated at 2022-06-12 18:49:34.168906
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_download import FakeZDFChannelIE

    class MyZDFChannelIE(FakeZDFChannelIE, ZDFChannelIE):
        pass

    url = 'https://www.zdf.de/dokumentation/planet-e'

# Generated at 2022-06-12 18:49:35.237786
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    t = ZDFIE.ie_key()
    assert t == 'zdf'

# Generated at 2022-06-12 18:49:37.421380
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_object = ZDFBaseIE()
    assert test_object
#test_ZDFBaseIE()



# Generated at 2022-06-12 18:49:38.154962
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()


# Generated at 2022-06-12 18:49:40.311381
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    z = ZDFChannelIE.suitable(url)
    assert z is not None, 'This URL is not supposed to be True'

# Generated at 2022-06-12 18:49:43.036696
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():

    # Test ZDFBaseIE constructor
    obj1 = ZDFBaseIE()

    # Check object of class ZDFBaseIE
    assert obj1.__class__.__name__ == 'ZDFBaseIE'



# Generated at 2022-06-12 18:49:45.095182
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')

# Generated at 2022-06-12 18:50:21.552808
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannelie = ZDFChannelIE()
    assert zdfchannelie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 18:50:22.382247
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(None)


# Generated at 2022-06-12 18:50:24.276884
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('www.zdf.de', None)


# Generated at 2022-06-12 18:50:27.138682
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('zdf').real_extract('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')


# Generated at 2022-06-12 18:50:30.866216
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:50:40.188068
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE(True)
    assert ie.name() == "ZDF"
    assert ie.ie_key() == "ZDF"
    assert ie.valid_urls[0] == "https?://www\.zdf\.de/.*"
    assert ie.url_result("https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html") == "https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html"

    ie = ZDFIE(False)
    assert ie.name() == "ZDF"
    assert ie.ie_key() == "ZDF"


# Generated at 2022-06-12 18:50:51.112344
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import sys
    # test case: https://www.3sat.de/gesellschaft/gesundheit/150507/video/index.html
    # it is a page that have no key 'player' in webpage
    webpage = sys.modules[__package__]._download_webpage(
        'https://www.zdf.de/dokumentation/planet-e',
        'planet-e',
        sys.modules[__package__]._downloader)
    player = sys.modules[__package__]._extract_player(webpage, 'planet-e', fatal=False)
    assert player is not None
    # test case: https://www.3sat.de/film/spielfilm/der-hauptmann-100.html
    # it is a page that have 'player' in webpage

# Generated at 2022-06-12 18:50:53.849608
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE()

    assert issubclass(channel.__class__, ZDFBaseIE)

# Generated at 2022-06-12 18:50:58.926478
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = 'test_video'
    ZDFBaseIE._call_api('url', video_id, 'item')
    ZDFBaseIE._extract_player(None, video_id)
    ZDFBaseIE._GEO_COUNTRIES
    ZDFBaseIE._QUALITIES
    ZDFBaseIE.ie_key()


# Generated at 2022-06-12 18:51:00.870852
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.ie_key() == 'ZDF'



# Generated at 2022-06-12 18:52:04.450518
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # scenario 1: the url is a channel page
    url = "https://www.zdf.de/politik/phoenix-sendungen"
    assert ZDFChannelIE.suitable(url)
    assert ZDFChannelIE.ie_key() == "ZDFChannel"
    # scenario 2: the url is a program page
    url = "https://www.zdf.de/politik/phoenix-sendungen/phoenix-sofakino-113.html"
    assert ZDFIE.suitable(url)
    assert ZDFIE.ie_key() == "ZDF"



# Generated at 2022-06-12 18:52:09.028768
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test with an attribute (xx) not in object (yy)
    class Test(object):
        yy = {}
        xx = yy['xx']
    with pytest.raises(AttributeError):
        Test()
    # Test with an attribute (xx) not in object (yy)
    class Test(object):
        yy = {}
        xx = yy['xx']
    with pytest.raises(AttributeError):
        Test().xx
    # Test with an attribute (name) for a matching class
    class Test(ZDFChannelIE):
        name = 'Test'
    assert Test().name == 'Test'
    # Test with an attribute (name) for a non-matching class
    class Test(object):
        name = 'Test'
    with pytest.raises(AttributeError):
        Test().name
   

# Generated at 2022-06-12 18:52:16.373058
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert hasattr(ie, '_download_json'), 'Download JSON method not found'
    assert hasattr(ie, '_call_api'), 'Call API method not found'
    assert hasattr(ie, '_extract_format'), 'Extract format method not found'
    assert hasattr(ie, '_extract_subtitles'), 'Extract subtitles method not found'
# End of unit test for constructor of class ZDFBaseIE



# Generated at 2022-06-12 18:52:22.941485
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE({})
    assert zdf_base_ie.extractor_key() == "ZDFBase"
    assert zdf_base_ie.IE_NAME == "ZDFBase"
    assert [zdf_base_ie.ie_key()] == [info_extractor.ie_key() for info_extractor in InfoExtractor.__subclasses__() if info_extractor.ie_key() == "ZDFBase"]
    assert InfoExtractor.get_info_extractor("ZDFBase") == ZDFBaseIE



# Generated at 2022-06-12 18:52:31.657102
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class C(object):
        def __init__(self, url, ie_key = None, video_id = None):
            self.url = url
            self.ie_key = ie_key
            self.video_id = video_id
    assert C('https://www.zdf.de/filme/taunuskrimi/', 'ZDF', 'taunuskrimi').__dict__ == \
           {'ie_key': 'ZDF', 'url': 'https://www.zdf.de/filme/taunuskrimi/', 'video_id': 'taunuskrimi'}

# Generated at 2022-06-12 18:52:37.190974
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Check whether url is a url of channel
    url = 'https://www.zdf.de/wissen/tatort-recherche'
    assert re.match(ZDFChannelIE._VALID_URL, url)
    info_dict = ZDFChannelIE()._real_extract(url)
    assert info_dict['id'] == 'tatort-recherche'
    assert info_dict['title'] == 'tatort: recherche | ZDF'


# Generated at 2022-06-12 18:52:41.223686
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE()
    assert zdf_base._GEO_COUNTRIES == ['DE']
    assert zdf_base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdf_base._API_BASE == 'http://api.zdf.de'


# Generated at 2022-06-12 18:52:42.280670
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('das-aktuelle-sportstudio');

# Generated at 2022-06-12 18:52:43.152629
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None, {'test': 'test'})

# Generated at 2022-06-12 18:52:44.625760
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    '''
    Unit test for constructor of class ZDFBaseIE
    '''
    assert hasattr(ZDFBaseIE, "ie_key")


# Generated at 2022-06-12 18:54:49.528059
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    result = ZDFChannelIE()
    assert(result.name == "zdf:channel")

# Generated at 2022-06-12 18:54:50.498911
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Constructing ZDFBaseIE
    ZDFBaseIE()


# Generated at 2022-06-12 18:54:51.450190
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    zdfie._TESTS

# Generated at 2022-06-12 18:54:52.655872
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'


# Generated at 2022-06-12 18:54:54.827700
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE() is not None


# Generated at 2022-06-12 18:54:55.335552
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass



# Generated at 2022-06-12 18:54:56.646671
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Not enough to test entire class
    assert(ZDFBaseIE.ie_key() == 'zdf')


# Generated at 2022-06-12 18:55:01.219733
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Create a mocked instance of the YoutubeIE class and returns the mocked value for the 'is_enabled' attribute
    class FakeYoutubeIE(youtube_dl.extractor.common.InfoExtractor):
        _VALID_URL = r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 18:55:03.620681
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_ie = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert 'https://www.zdf.de/dokumentation/planet-e' == channel_ie._url
    assert 'planet-e' == channel_ie._id
    assert 'Planet E' == channel_ie._title


# Generated at 2022-06-12 18:55:07.420485
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zie = ZDFChannelIE()
    assert zie.suitable("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    assert not zie.suitable("https://www.zdf.de/dokumentation/planet-e")
    assert not zie.suitable("https://www.zdf.de/filme/taunuskrimi/")
    assert not zie.suitable("https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html")

