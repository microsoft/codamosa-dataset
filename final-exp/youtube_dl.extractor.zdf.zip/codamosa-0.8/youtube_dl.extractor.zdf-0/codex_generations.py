

# Generated at 2022-06-12 18:49:26.870917
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zd = ZDFBaseIE()
    assert '_GEO_COUNTRIES' in dir(zd)
    assert '_QUALITIES' in dir(zd)
    assert '_call_api' in dir(zd)
    assert '_extract_subtitles' in dir(zd)
    assert '_extract_format' in dir(zd)
    assert '_extract_ptmd' in dir(zd)
    assert '_extract_player' in dir(zd)


# Generated at 2022-06-12 18:49:29.692823
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    '''
    Test for constructor of class ZDFBaseIE
    '''
    g_y_d = ZDFBaseIE()
    assert(g_y_d is not None)


# Generated at 2022-06-12 18:49:31.133993
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()

# Generated at 2022-06-12 18:49:37.407022
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import types
    import sys
    try:
        ZDFChannelIE.__init_subclass__
    except AttributeError:
        ZDFChannelIE.__init_subclass__ = types.MethodType(lambda cls: None, None)
    try:
        if sys.version_info.major == 3 and sys.version_info.minor == 6:
            # python 3.6
            ZDFChannelIE.__init_subclass_with_meta__ = types.MethodType(lambda cls, name,
                bases, dct: None, None)
    except AttributeError:
        pass
    ZDFChannelIE(None)

# Generated at 2022-06-12 18:49:39.782841
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE(None)
    assert zdf_channel_ie.name == 'zdf.de:channel'
    assert zdf_channel_ie.chromedriver == 'zdf_dl'
    assert zdf_channel_ie.geckodriver == 'zdf_dl'

# Generated at 2022-06-12 18:49:49.540039
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-12 18:49:53.064290
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import zdf
    cls = zdf.ZDFChannelIE
    assert cls.suitable('https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-12 18:49:57.658021
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """ constructor of the class ZDFIE """
    zdf_ie = ZDFIE()
    assert zdf_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'



# Generated at 2022-06-12 18:50:03.856492
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    x = ZDFIE()
    assert url_or_none('https://zdf.de/bla.mp4') == 'https://zdf.de/bla.mp4'
    assert url_or_none(['https://zdf.de/bla.mp4']) == 'https://zdf.de/bla.mp4'
    assert url_or_none(['https://zdf.de/bla.mp4', 'https://zdf.de/bla2.mp4']) == 'https://zdf.de/bla.mp4'
    assert parse_codecs('mime=video/mp4;codecs="avc1.42c01e"') == {'vcodec': 'avc1.42c01e', 'ext': 'mp4'}
    assert parse_cod

# Generated at 2022-06-12 18:50:06.733845
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testcases

    channel_ie = ZDFChannelIE
    assert channel_ie.ie_key().lower() == 'zdf:channel'

    res = get_testcases(channel_ie, 'ZDFChannelIE')
    for (url, info) in res:
        assert channel_ie().suitable(url)
        channel_ie()._real_extract(url)



# Generated at 2022-06-12 18:50:35.427859
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbaseie = ZDFBaseIE()
    assert zdfbaseie
    assert zdfbaseie._GEO_COUNTRIES == ['DE']
    assert zdfbaseie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:50:36.590786
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert (ZDFIE().ie_key() == 'ZDF') 


# Generated at 2022-06-12 18:50:38.508204
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Unit test for constructor of class ZDFBaseIE"""
    zdfbase_ie = ZDFBaseIE()



# Generated at 2022-06-12 18:50:49.988227
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-12 18:50:54.896957
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/kultur/zdf-kultur-uebersichtsseite'
    IE = ZDFChannelIE()
    IE._real_initialize()
    IE._real_extract(url)


# Generated at 2022-06-12 18:50:59.155733
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test constructor of class ZDFIE
    ie = ZDFIE
    assert ie.ie_key() == 'ZDF'
    assert ie.SUFFIX == 'zdf.de'
    assert ie.BR_DESC
    assert ie.is_suitable



# Generated at 2022-06-12 18:51:01.827661
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(ZDFChannelIE.suitable, 'https://www.zdf.de/sport/das-aktuelle-sportstudio')


# Generated at 2022-06-12 18:51:06.228368
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj is not None
    assert len(obj._GEO_COUNTRIES) > 0
    assert obj._GEO_COUNTRIES[0] == 'DE'
    assert len(obj._QUALITIES) > 0
    assert obj._QUALITIES[0] == 'auto'
    assert len(obj._TESTS) == 0


# Generated at 2022-06-12 18:51:12.125698
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    import unittest
    class TestZDFIE(unittest.TestCase):
        def setUp(self):
            self.zdf = ZDFIE()

        def test_is_suitable(self):
            self.zdf.url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
            self.assertTrue(self.zdf.suitable(self.zdf.url))
            self.zdf.url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100'

# Generated at 2022-06-12 18:51:15.397395
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Create an instance of ZDFChannelIE
    ie = ZDFChannelIE()

    # Create a variable with zdf.de/dokumentation/planet-e
    u = 'https://www.zdf.de/dokumentation/planet-e'

    # Use the method suitable of ZDFChannelIE to check the URL
    assert ie.suitable(u)

    # Use the method _real_extract of ZDFChannelIE to run the script
    ie._real_extract(u)

# Generated at 2022-06-12 18:51:55.487693
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class_ = globals()['ZDFChannelIE']
    assert class_ is not None
    # Check if the class could be instantiated
    obj = class_(None)
    assert obj is not None
    # Module import
    m = sys.modules[__name__]
    # Get the unit test for the class
    # test_ZDFIE is imported, test_ZDFIE is the name of the unit test for the class ZDFIE
    test_ZDFIE = getattr(m, 'test_ZDFIE')
    # assert that test_ZDFIE is not None
    assert test_ZDFIE is not None
    # Get the UnitTestCase instance from the unit test
    # tests is a list, isinstance(test_ZDFIE, unittest.case.TestCase) returns True for all
    # UnitTestCase instances
   

# Generated at 2022-06-12 18:52:01.148646
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannel = ZDFChannelIE()
    url = 'https://www.zdf.de/dokumentation/planet-e'
    r = zdfChannel.suitable(url)
    if r == True:
        print('[+] ZDFChannelIE.suitable is true')
    elif r == False:
        print('[-] ZDFChannelIE.suitable is false')
    else:
        print('[-]  unexpected result')


# Generated at 2022-06-12 18:52:06.723228
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # See https://github.com/ytdl-org/youtube-dl/issues/18186
    # and https://github.com/ytdl-org/youtube-dl/pull/18040
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    zdf_base_ie = ZDFBaseIE('https://zdf.de', {})
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    return True



# Generated at 2022-06-12 18:52:10.228537
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
# End unit test



# Generated at 2022-06-12 18:52:12.427618
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert(ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/'))
    assert(not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'))

# Generated at 2022-06-12 18:52:14.400719
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(False)


# Generated at 2022-06-12 18:52:23.565119
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    info_extractor = ZDFIE()
    assert info_extractor._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert info_extractor._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert info_extractor._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'

# Generated at 2022-06-12 18:52:34.451681
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url = "http://www.zdf.de/ZDFmediathek/beitrag/video/2866796/Neue-Herausforderung-fuer-Kerner#/beitrag/video/2866796/Neue-Herausforderung-fuer-Kerner"
    info = ZDFBaseIE().extract(url)
    print(info['id'])
    assert info['id'] == '2866796'
    assert info['title'] == 'Neue Herausforderung für Kerner'
    assert info['duration'] == 606
    assert info['duration'] == 606
    assert info['formats'][0]['format_id'] == 'http-video-veryhigh'
    assert info['formats'][0]['format_note'] == 'veryhigh'
    assert info

# Generated at 2022-06-12 18:52:41.620541
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    obj = ZDFChannelIE()
    assert obj.__class__.__name__ == "ZDFChannelIE"
    assert obj.name == "ZDF:channel"
    assert obj.ie_key() == "ZDF:channel"
    assert obj.valid_url("https://www.zdf.de/verbraucher/zdf-verbraucher")
    assert obj.valid_url("https://www.zdf.de/sport/titel/titel-titel-titel")
    assert obj.valid_url("https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html")
    assert not obj.valid_url("https://www.zdf.de/politik")
   

# Generated at 2022-06-12 18:52:42.524494
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    ie = ZDFBaseIE()


# Generated at 2022-06-12 18:53:44.707395
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFIE
    from . import ZDFChannelIE
    assert ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL) and not ZDFChannelIE.suitable(ZDFIE._VALID_URL)

# Generated at 2022-06-12 18:53:48.950936
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    t = ZDFIE()

    assert t._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert t._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:53:50.498995
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Testing constructor of class ZDFBaseIE
    ZDFBaseIE()
    return True


# Generated at 2022-06-12 18:53:51.406825
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-12 18:53:53.294287
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFChannelIE
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-12 18:53:54.200719
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(ZDFChannelIE.create_ie_cloning_downloader())



# Generated at 2022-06-12 18:53:58.799986
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        from IPython.lib.pretty import pretty
    except ImportError:
        pretty = lambda x: x
    def test_constructor(url):
        ie = ZDFChannelIE(ZDFChannelIE.suitable(url))
        assert ie is not None
        #assert ie.extractor_key == ZDFChannelIE.extractor_key()
        assert ie.suitable(url)

    channels = [
        'https://www.zdf.de/sport/das-aktuelle-sportstudio',
        'https://www.zdf.de/dokumentation/planet-e',
        'https://www.zdf.de/filme/taunuskrimi/'
    ]

    for channel in channels:
        print(pretty(channel))
        test_constructor(channel)

# Generated at 2022-06-12 18:54:02.633102
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        assert(ZDFBaseIE._GEO_COUNTRIES == ['DE'])
        assert(ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))
    except:
        raise AssertionError("TEST FAILED")



# Generated at 2022-06-12 18:54:04.356075
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-12 18:54:05.324180
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # No exception expected
    ZDFChannelIE()

# Unit tests for methods of class ZDFChannelIE

# Generated at 2022-06-12 18:55:25.099373
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:55:26.251888
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-12 18:55:35.348786
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test if constructor is able to set _VALID_URL value and _GEO_COUNTRIES value
    # expected value
    exp_valid_url = r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    exp_geo_countries = ['DE']

    # create instance of class ZDFIE
    youtube_ie = ZDFIE()
    # get attribute value of _VALID_URL
    act_valid_url = youtube_ie._VALID_URL
    # get attribute value of _GEO_COUNTRIES
    act_geo_countries = youtube_ie._GEO_COUNTRIES

    # check if call to constructor is successful by checking attribute values
    assert act_valid_url == exp_valid_url and act

# Generated at 2022-06-12 18:55:37.680412
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    global ZDFBaseIE
    e = ZDFBaseIE
    assert e._GEO_COUNTRIES == ['DE']
    assert e._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:55:40.576712
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:55:43.446128
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from ytdl.extractor import class_constructor
    ie = class_constructor(
        'https://www.zdf.de/politik/phoenix-sendungen',
        ZDFChannelIE.ie_key())()
    assert ie.suitable('https://www.zdf.de/politik/phoenix-sendungen')
    assert not ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/video-100.html')



# Generated at 2022-06-12 18:55:45.979337
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_obj = ZDFBaseIE()
    assert test_obj._GEO_COUNTRIES == ['DE']
    assert test_obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:55:48.802721
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    ZDFIE()._real_extract(url)


# Generated at 2022-06-12 18:55:51.246878
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'
    assert ZDFIE.ie_key() == 'zdf'



# Generated at 2022-06-12 18:55:52.676415
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    baseIE = ZDFBaseIE()
    assert baseIE.ie_key() == 'ZDF'


# Generated at 2022-06-12 18:58:37.458025
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'zdf'
    assert ie.GEO_COUNTRIES == ['DE']
    assert ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:58:38.086331
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE(None)


# Generated at 2022-06-12 18:58:38.995705
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """test if ZDFIE() has been defined."""
    assert ZDFIE



# Generated at 2022-06-12 18:58:41.994119
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test constructor without arguments
    inst1 = ZDFBaseIE()

    # Test constructor with arguments
    inst2 = ZDFBaseIE(downloader=None, download_mode=None, params=None)
    assert inst2 is not None


# Generated at 2022-06-12 18:58:44.768886
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:58:51.861485
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
   # Test case where we pass default value for channel_id argument
   class_object = ZDFChannelIE()
   class_object._real_extract(url)
   # Test case where we pass channel_id value
   class_object = ZDFChannelIE(channel_id = channel_id)
   class_object._real_extract(url)