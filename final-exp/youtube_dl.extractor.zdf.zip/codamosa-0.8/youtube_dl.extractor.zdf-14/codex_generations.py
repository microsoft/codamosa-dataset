

# Generated at 2022-06-12 18:49:17.194697
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(object)



# Generated at 2022-06-12 18:49:20.494931
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-12 18:49:28.749836
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert (ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL)) is True
    assert (ZDFChannelIE.suitable('https://www.zdf.de/filme')) is True
    assert (ZDFChannelIE.suitable('https://www.zdf.de/dokumentation')) is True
    assert (ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi')) is True
    assert (ZDFChannelIE.suitable('https://www.zdf.de/politik/frontal-21')) is True
    assert (ZDFChannelIE.suitable('https://www.zdf.de/kinder/logo!-schule')) is True

# Generated at 2022-06-12 18:49:36.116189
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .zdf import ZDFChannelIE
    from .zdf import ZDFIE
    zdfchannelIE = ZDFChannelIE()
    zdfIE = ZDFIE()
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert zdfchannelIE.suitable(url) is True
    assert zdfchannelIE._match_id(url) == 'das-aktuelle-sportstudio'
    assert zdfchannelIE.ie_key() == 'ZDFChannel'
    assert zdfIE.suitable(url) is False

# Generated at 2022-06-12 18:49:38.934704
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    for entry in iter_tests_ZDFChannelIE():
        test_constr = ZDFChannelIE(entry['url'], entry['channel_id'])
        test_constr = ZDFChannelIE(entry['url'], entry['channel_id'])
        assert (test_constr.channel_id == entry['channel_id'])

# Test case of class ZDFChannelIE

# Generated at 2022-06-12 18:49:43.841608
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    # _GEO_COUNTRIES (attribute)
    assert instance._GEO_COUNTRIES == ['DE']
    # _QUALITIES (attribute)
    assert instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:49:48.155550
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_zdfie = ZDFIE()
    assert test_zdfie._GEO_COUNTRIES == ['DE']
    assert test_zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

test_ZDFIE()

# Generated at 2022-06-12 18:49:54.760770
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    import subprocess
    cmd = 'wget -q --no-check-certificate %s -O - | python -m json.tool' % 'https://zdf-cdn.live.cellular.de/mediathekV2/document/210222-phx-nachgehakt-corona-protest'
    p = subprocess.Popen([cmd], stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    out, err = p.communicate()
    if out:
        obj = ZDFIE()
        result = obj._extract_mobile('210222-phx-nachgehakt-corona-protest')
        assert(result['id'] == '210222_phx_nachgehakt_corona_protest')

# Generated at 2022-06-12 18:49:59.823432
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # pylint: disable=W0212
    # Unit test for class ZDFChannelIE
    assert (ZDFChannelIE._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)')
    assert (ZDFChannelIE._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert (ZDFChannelIE._TESTS[1]['url'] == 'https://www.zdf.de/dokumentation/planet-e')
    assert (ZDFChannelIE._TESTS[2]['url'] == 'https://www.zdf.de/filme/taunuskrimi/')

# Generated at 2022-06-12 18:50:03.762947
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    ie = ZDFBaseIE.get_ie(url)
    assert ie is ZDFIE

    url = 'https://www.zdf.de/dokumentation/planet-e/'
    ie = ZDFBaseIE.get_ie(url)
    assert ie is ZDFChannelIE


# Generated at 2022-06-12 18:50:30.053747
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE is not None


# Generated at 2022-06-12 18:50:33.796218
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase = ZDFBaseIE()
    assert zdfbase._GEO_COUNTRIES == ['DE']
    assert zdfbase._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:50:34.701912
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    return ZDFBaseIE(None)



# Generated at 2022-06-12 18:50:38.594513
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert_raises(ExtractorError, ZDFChannelIE, 'https://zdf.de/kultur/fernsehfilm-festival/live/live-startseite')
test_ZDFChannelIE()

# Generated at 2022-06-12 18:50:44.338927
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class ZDFBaseTest(ZDFBaseIE):
        def _real_extract(self, url):
            return
    assert ZDFBaseTest()._GEO_COUNTRIES == ['DE']
    assert ZDFBaseTest()._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:50:48.368296
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Initialize
    zdf = ZDFIE()
    # Test
    zdf_test = ZDFIE._extract_player(zdf, '{}', 'https://example.com/')
    # Check
    assert isinstance(zdf_test, dict)


# Generated at 2022-06-12 18:50:49.933439
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    return ZDFBaseIE()



# Generated at 2022-06-12 18:51:00.648422
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Test for constructor of class ZDFChannelIE
    """
    from .test import get_testfile_content
    from .zdf import ZDFChannelIE

    url = "https://www.zdf.de/dokumentation/planet-e"

    list_page = get_testfile_content(ZDFChannelIE.ie_key(), url)
    content = ZDFChannelIE._real_extract(ZDFChannelIE(), url)

    ie_key_list = []
    title_list = []
    for entry in content['entries']:
        ie_key_list.append(entry['ie_key'])
        title_list.append(entry['title'])
    print(ie_key_list)

# Generated at 2022-06-12 18:51:04.278750
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    IE = ZDFBaseIE('test', 'test')
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert IE._downloader.params['geo_verification_headers'] == {'X-Forwarded-For': '200.200.200.200'}
    assert IE._downloader.params['geo_bypass'] == True



# Generated at 2022-06-12 18:51:05.822774
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE()
    z2 = ZDFIE()
    assert z._GEO_COUNTRIES == z2._GEO_COUNTRIES


# Generated at 2022-06-12 18:52:06.148694
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE()
    assert zdf_base._GEO_COUNTRIES == ['DE']
    assert zdf_base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdf_base._call_api([], '', '') == None


# Generated at 2022-06-12 18:52:07.850549
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Construct a module of class ZDFIE
    a = ZDFIE()
    # Access the attribute of the module
    print(a)


# Generated at 2022-06-12 18:52:14.253129
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    TestFixture = ZDFIE('http://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert TestFixture.valid_url()
    assert TestFixture.id() == 'http://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
    assert TestFixture.title() == 'e'
    assert TestFixture.description() == None
    assert (len(TestFixture.formats()) == 2)
    assert TestFixture.duration() == 0
    assert TestFixture.thumbnail() == None

# Generated at 2022-06-12 18:52:23.491929
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-12 18:52:25.289756
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-12 18:52:28.510095
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('zdf.de/filme/taunuskrimi')

    assert ie.SUITABLE(ie.url)
    assert not ie.IE_NAME == 'zdf:channel'

# Generated at 2022-06-12 18:52:33.114019
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Test for _call_api function of class ZDFBaseIE

# Generated at 2022-06-12 18:52:34.354149
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert isinstance(ZDFIE(), InfoExtractor)


# Generated at 2022-06-12 18:52:37.041903
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z = ZDFBaseIE()
    assert z._GEO_COUNTRIES == ['DE']
    assert z._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
#

# Generated at 2022-06-12 18:52:43.993539
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert not ZDFChannelIE.suitable('https://m.zdf.de/filme/die-geissens/der-geissens-urlaub-in-new-york-100.html')
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')

    # test no channel title
    channel_id = 'das-aktuelle-sportstudio'

# Generated at 2022-06-12 18:54:58.598644
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE()
    assert zdf_base._GEO_COUNTRIES == ['DE']
    assert zdf_base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:55:06.895872
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = "test"
    webpage = "test"
    assertZDFBaseIE = ZDFBaseIE(
        "1",
        "2")

    assert assertZDFBaseIE._call_api(
        "1",
        "2",
        "3",
        api_token='test')

    assert assertZDFBaseIE._download_json(
        "1",
        "2",
        "3")

    assert assertZDFBaseIE._extract_subtitles(
        "1")

    assert assertZDFBaseIE._extract_format(
        "1",
        "2",
        "3",
        "4")

    assert assertZDFBaseIE._extract_ptmd(
        "1",
        "2",
        "3",
        "4")

    assert assertZDFBase

# Generated at 2022-06-12 18:55:09.581732
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('test', 'DE')
    assert ie.geo_countries == ['DE']
    assert ie.qualities == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:55:15.236428
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        plugin_test_file = downloader.ExternalDownloader('http://www.youtube.com',
        'youtube.py').real_download(
            'https://www.zdf.de/sport/das-aktuelle-sportstudio', 'das aktuelle sportstudio | ZDF')
        assert(plugin_test_file == "das aktuelle sportstudio | ZDF\n")
    except Exception as e:
        assert(str(e) == "http://www.youtube.com is not a supported downloader")



# Generated at 2022-06-12 18:55:16.136217
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert isinstance(ZDFBaseIE("ZDF", "ZDF"), ZDFBaseIE)


# Generated at 2022-06-12 18:55:24.268827
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    def test_valid_url( url, video_id ):
        assert ZDFIE._VALID_URL.search(url) is not None
        assert ZDFIE._match_id(url) == video_id
    test_valid_url( "https://www.zdf.de/politik/frontal-21/aus-dem-leben-eines-fluechtlings-102.html" , '141114_frontal21_ausdemlebeneinesfluechtlings_komplett' )
    test_valid_url( "https://www.zdf.de/nachrichten/heute-journal/zdf-heute-journal-vom-100.html" , '170811_heute_journal_live_live' )

# Generated at 2022-06-12 18:55:25.661732
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()._extract_player(None, "https://foo.bar")

# Generated at 2022-06-12 18:55:28.952135
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE(test_url)
    assert ie._match_id(test_url) == 'planet-e'


# Generated at 2022-06-12 18:55:34.349130
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    (channel_id, channel_name) = ZDFChannelIE()._match_id(url)
    expected_id = 'planet-e'
    assert(channel_id == expected_id)
    assert(channel_name == expected_id)
    assert(channel_name == ZDFChannelIE()._real_extract(url)['id'])



# Generated at 2022-06-12 18:55:35.145286
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()
