

# Generated at 2022-06-12 18:49:18.410371
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zDFIE = ZDFIE('test')
    assert zDFIE.ie_key() == 'ZDF'


# Generated at 2022-06-12 18:49:21.271300
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE().ie_key() == 'ZDF'
    assert ZDFIE().ie_key() in ZDFIE.ie_key_map

# Generated at 2022-06-12 18:49:22.993590
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')


# Generated at 2022-06-12 18:49:35.300631
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # TODO: Test ZDFBaseIE._extract_player
    # TODO: Test ZDFBaseIE._call_api
    # TODO: Test ZDFBaseIE._extract_ptmd
    # TODO: Test ZDFBaseIE._extract_format
    # TODO: Test ZDFBaseIE._extract_subtitles
    # TODO: Test ZDFBaseIE.suitable
    # TODO: Test ZDFBaseIE.extract
    from .zdf import ZDFIE
    ZDFBaseIE.ie_key()
    # zdf = ZDFIE()
    # zdf.ie_key()
    # zdf._call_api()
    # zdf._extract_format()
    # zdf._extract_player()
    # zdf._extract_ptmd()
    # zdf

# Generated at 2022-06-12 18:49:41.704913
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        zdfBaseIE = ZDFBaseIE()
    except:
        assert False, 'there should not be any exceptions'
    try:
        zdfIE = ZDFChannelIE()
    except:
        assert False, 'there should not be any exceptions'
    try:
        ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
        ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
        assert False, 'fail case is needed'
    except:
        pass
    assert zdfBaseIE.url_result('https://www.zdf.de/', 'ZDFChannelIE')['_type'] == 'url', 'the output should be of type url'
    assert zdf

# Generated at 2022-06-12 18:49:51.888202
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # ZDFBaseIE shows in constructor a warning message if there is any exception
    # during self._download_json function.
    # On this way I'm testing if the constructor is working
    # Because the video of ZDFIE is in German, I set the preferred language to de
    # otherwise YouTube will show messages in English
    old_preferred_language_code = preferences.get("General", "language")
    preferences.set("General", "language", "de")
    zdfie = ZDFIE()
    zdfie._download_json('https://www.zdf.de/', '', '')
    # resetting the preferred language to old value
    preferences.set("General", "language", old_preferred_language_code)
    assert(zdfie.player == {})



# Generated at 2022-06-12 18:49:53.913236
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test id 0
    assert("ZDFBaseIE" == ZDFBaseIE("ZDF").__class__.__name__)


# Generated at 2022-06-12 18:49:55.594122
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE({}) is not None

# Generated at 2022-06-12 18:50:01.886427
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest

    class ZDFChannelIETest(unittest.TestCase):
        def test_smoke(self):
            self.assertIsNone(ZDFChannelIE._match_id(None))
            self.assertIsNone(ZDFChannelIE._match_id(''))
            self.assertIsNone(ZDFChannelIE._match_id('https://www.dummy.com'))
            self.assertEqual(ZDFChannelIE._match_id('https://www.zdf.de/programm/terra-x/terra-x-uebersichtseite-100.html'),
                             'terra-x')

    unittest.main()



# Generated at 2022-06-12 18:50:02.549702
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-12 18:50:53.863329
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert isinstance(zdf, InfoExtractor)
    assert isinstance(zdf._call_api, object)
    assert isinstance(zdf._extract_format, object)
    assert isinstance(zdf._extract_player, object)
    assert isinstance(zdf._extract_ptmd, object)



# Generated at 2022-06-12 18:50:57.821531
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:51:01.315487
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()

    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:51:03.681001
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:51:09.473563
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # test two functions of class ZDFChannelIE
    obj_ZDFChannelIE = ZDFChannelIE()
    # method xpath_text
    node1 = {'data-plusbar-url': 'data-plusbar-url.html'}
    node2 = {'data-plusbar-url': 'data-plusbar-url.html', 'data-plusbar-url': 'data-plusbar-url.html'}
    node3 = {'data-plusbar-url': 'data-plusbar-url.html', 'href': 'href.html'}
    node4 = {}
    test_result1 = 'data-plusbar-url.html'
    test_result2 = 'data-plusbar-url.html'
    test_result3 = None
    test_result4 = None
    assert obj_ZDFChannelIE

# Generated at 2022-06-12 18:51:11.462098
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('ZDFBaseIE', 'ZDF', 'DE')


# Generated at 2022-06-12 18:51:16.141448
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    result0 = ie._call_api('https://www.zdf.de/', 'testvideo', 'test')
    assert isinstance(result0, dict)

    if result0 is not None:
        assert isinstance(result0['title'], compat_str)
        assert isinstance(result0['subtitle'], compat_str)


# Generated at 2022-06-12 18:51:26.532081
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        assert callable(ZDFIE._call_api)
    except AssertionError:
        raise Exception("ZDFIE._call_api is not callable")
    try:
        assert callable(ZDFIE._extract_subtitles)
    except AssertionError:
        raise Exception("ZDFIE._extract_subtitles is not callable")
    try:
        assert callable(ZDFIE._extract_format)
    except AssertionError:
        raise Exception("ZDFIE._extract_format is not callable")
    try:
        assert callable(ZDFIE._extract_ptmd)
    except AssertionError:
        raise Exception("ZDFIE._extract_ptmd is not callable")

# Generated at 2022-06-12 18:51:36.991548
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    if __name__ == "__main__":
        ie = ZDFBaseIE()
        ie._call_api(
            'http://some.url',
            '12345',
            'api',
            api_token='abcdef',
            referrer='http://some.referrer.url')
        ie._extract_subtitles({'captions': [{'uri': 'http://some.url', 'language': 'eng'}, {'uri': 'http://some.url', 'language': 'deu'}]})

# Generated at 2022-06-12 18:51:37.703963
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(InfoExtractor())



# Generated at 2022-06-12 18:53:21.677122
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE().suitable("https://www.zdf.de/politik/frontal-21/")


# Generated at 2022-06-12 18:53:33.476639
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = ZDFIE._TESTS[0]['url']
    video_id = ZDFIE._TESTS[0]['info_dict']['id']

    zdfie = ZDFIE(url, video_id)
    zdfie.player = zdfie._extract_player(zdfie._download_webpage(url, video_id), video_id)

    content = zdfie._call_api(
        zdfie.player['content'], video_id, 'content', zdfie.player['apiToken'], url)

    entry = zdfie._extract_entry(zdfie.player['content'], zdfie.player, content, video_id)
    entry_title = entry['title']


# Generated at 2022-06-12 18:53:37.592017
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    zdfie = ZDFChannelIE.suitable(url)
    if zdfie:
        print('ZDFChannelIE constructor: SUCCESS')
    else:
        print('ZDFChannelIE constructor: FAIL')
    return zdfie



# Generated at 2022-06-12 18:53:38.851285
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.is_geo_restricted



# Generated at 2022-06-12 18:53:42.538724
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Test the constructor of class ZDFChannelIE."""
    url = ('https://www.zdf.de/dokumentation/planet-e')
    o = ZDFChannelIE()
    o.suitable(url)
    # o._real_extract(url)

# Generated at 2022-06-12 18:53:45.056824
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie=ZDFIE()
    assert(ie._GEO_COUNTRIES==['DE'])
    assert(ie._QUALITIES==('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-12 18:53:50.699875
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    A simple test to check that the constructor of each subclass
    of InfoExtractor works.
    """
    # Disable in xenial CI for now
    if os.environ.get('TRAVIS_BUILD_DIR') == '/home/travis/build/ytdl-org/youtube-dl':
        pytest.skip('Skipping test in xenial CI.')

    ie = ZDFChannelIE()
    pytest.raises(TypeError, ie)



# Generated at 2022-06-12 18:53:54.731694
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    allProperties = {
        'id': 'video_id'
    }
    mustHaveProperties = ['id']
    haveAllProperties = True
    for property in allProperties:
        if not property in mustHaveProperties:
            haveAllProperties = False
            break
    assert haveAllProperties == True



# Generated at 2022-06-12 18:53:55.866442
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()

# Generated at 2022-06-12 18:53:56.678257
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()



# Generated at 2022-06-12 18:58:55.363481
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.compat import compat_urllib_request

    # Generate test data via program:
    #
    # import requests
    # url = 'https://www.zdf.de/politik/frontal-21/frontal-21-uebersicht-100.html'
    # api_path = 'http://api.zdf.de/content/documents/frontal-21.json'
    # html_path = '/tmp/frontal-21.html'
    # api_path = '/tmp/frontal-21.json'
    # with open(html_path, 'wb') as f:
    #     f.write(requests.get(url).content)
    # with open(api_path, 'wb') as f:
   