

# Generated at 2022-06-12 18:49:17.514136
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-12 18:49:28.309791
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-12 18:49:37.307948
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._extract_regular('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html',
                             {"content": "https://zdf-cdn.live.cellular.de/mediathekV2/content/2050630?profile=pc&dnt=0&platform=desktop&deviceType=desktop"},
                             '2050630_phx_nachgehakt_corona_protest')
    # A bit specific test for ptmd: the content id should be the same as the video_id,
    # so it's easy to identify broken video_ids

# Generated at 2022-06-12 18:49:42.991944
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    zdf_base_ie_geo_countries = ie._GEO_COUNTRIES
    zdf_base_ie_geo_countries_should_be = ['DE']
    assert zdf_base_ie_geo_countries == zdf_base_ie_geo_countries_should_be, 'Instances are not the same'



# Generated at 2022-06-12 18:49:46.766947
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE()
    ie.suitable(url)
    assert ie.suitable(url)
    ie.extract(url)
    assert ie.extract(url)



# Generated at 2022-06-12 18:49:53.875189
# Unit test for constructor of class ZDFIE
def test_ZDFIE(): # pylint: disable=missing-docstring

    entry_urls = set()
    def extract_entries(entries, first_page_url, second_page_url): # pylint: disable=missing-docstring
        for entry in entries:
            entry_urls.add(entry['url'])

    ie = ZDFIE(None, ZDFIE.ie_key())
    ie._extract_entries = extract_entries

# Generated at 2022-06-12 18:49:57.658071
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE('zdf.de')
    assert instance._GEO_COUNTRIES == ['DE']
    assert instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:49:58.622438
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(1,1)


# Generated at 2022-06-12 18:50:00.179762
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie is not None


# Generated at 2022-06-12 18:50:10.704523
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:50:58.046156
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._VALID_URL == ZDFIE._VALID_URL
    assert ZDFIE()._TESTS == ZDFIE._TESTS


# Generated at 2022-06-12 18:50:59.419959
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    extractor = ZDFBaseIE()
    assert extractor



# Generated at 2022-06-12 18:51:08.027444
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE("https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html")
    assert zdfie.ie_key() == "ZDF"
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdfie.search_title == "ab 18"
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdfie.IE_NAME == 'ZDF'
    assert zdf

# Generated at 2022-06-12 18:51:10.730560
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    if not ZDFChannelIE.suitable(url):
        raise Exception(
            'URL %s should be suitable for ZDFChannelIE' % url)
    ie = ZDFChannelIE()
    ie._real_extract(url)

# Generated at 2022-06-12 18:51:19.326856
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    print ("[+] Executing test_ZDFIE()")
    assert ZDFIE('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ZDFIE('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')._TESTS is not None

# Generated at 2022-06-12 18:51:31.008624
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE is not None
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e') == True
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e') == True
    assert ZDFChannelIE.suitable('https://www.zdf.de/nachrichten/heute/heute-im-stern-woher-kommt-der-erfolg-der-deutschen-schluempfe-100.html') == False

# Generated at 2022-06-12 18:51:34.534230
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(
        ZDFBaseIE.ie_key(),
        'http://example.com/?url=http%3A%2F%2Fzdf.de%2Ffoo')  # noqa: F821



# Generated at 2022-06-12 18:51:41.081517
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    video_id = '151025_magie_farben2_tex'
    video_title = 'Die Magie der Farben (2/2)'

# Generated at 2022-06-12 18:51:42.438229
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE()
    # since constructor has empty body, can be removed
    assert zdfChannelIE

# Generated at 2022-06-12 18:51:44.090041
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_player = ZDFBaseIE()


# Generated at 2022-06-12 18:52:32.905820
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return ZDFChannelIE({})

# Generated at 2022-06-12 18:52:34.949481
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    channel_ie = ZDFChannelIE(url=url)
    assert channel_ie.suitable(url) == True
    assert channel_ie.ie_key() == 'ZDFChannel'


# Generated at 2022-06-12 18:52:37.545083
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.geo_countries == ['DE']
    assert ie.qualities == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:52:39.270189
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_ZDFBaseIE = ZDFBaseIE()
    print(test_ZDFBaseIE)


# Generated at 2022-06-12 18:52:44.800710
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable("https://www.zdf.de/dokumentation/planet-e/") is True
    assert zdf_channel_ie.suitable("https://www.zdf.de/dokumentation/planet-e/test") is True
    assert zdf_channel_ie.suitable("https://www.zdf.de/dokumentation/planet-e/?test=1") is True
    assert zdf_channel_ie.suitable("https://www.zdf.de/dokumentation/planet-e/#test") is True


# Generated at 2022-06-12 18:52:46.253266
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('ZDF', 'www.zdf.de')


# Generated at 2022-06-12 18:52:47.130570
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    device = ZDFBaseIE()
    assert device is not None


# Generated at 2022-06-12 18:52:48.304618
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # create object
    o = ZDFBaseIE()

    # test object
    assert o is not None

# Generated at 2022-06-12 18:52:50.461083
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie is not None
    print(zdf_base_ie)


# Generated at 2022-06-12 18:52:53.667787
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
    zdfie = ZDFIE()
    zdfie._real_extract(url)
    #print(zdfie._extract_player(url, video_id, fatal=False))
    #print(zdfie._extract_regular(url, video_id))


# Generated at 2022-06-12 18:55:11.033144
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    #assert ie.name == "zenodotus"
    #assert ie.host == "zenodotus.com"
    #assert ie.IE_DESC == "zenodotus"
    #assert ie.age_limit == 18
    #assert ie.supported_countries == ['DE']
    assert ie._GEO_COUNTRIES == ['DE']
    #assert ie.extract_flat == False
    #assert ie.ad_free == False
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-12 18:55:15.864901
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = globals()['ZDFChannelIE']
    obj = ie("https://www.zdf.de/dokumentation/planet-e")
    assert obj.suitable("https://www.zdf.de/dokumentation/planet-e")
    assert obj.suitable("https://www.zdf.de/dokumentation/planet-e.html")
    assert obj.suitable("https://www.zdf.de/dokumentation/planet-e/")



# Generated at 2022-06-12 18:55:17.306794
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE("https://www.zdf.de/filme/taunuskrimi/")


# Generated at 2022-06-12 18:55:19.538379
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest

    validURL = "https://www.zdf.de/"
    URL = ZDFChannelIE._VALID_URL
    # print validURL
    # print "-----------"
    # print URL
    # print "-----------"
    m = re.search(URL, validURL)
    # print m.groupdict()
    unittest.main()

# Generated at 2022-06-12 18:55:28.607571
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from ..compat import compat_str
    from .common import InfoExtractor
    from ..utils import determine_ext, qualities

    my_zdfbaseie = ZDFBaseIE()
    infoExtractor = InfoExtractor()
    str_compat_str = 'compat_str'
    str_determine_ext = 'determine_ext'
    str_qualities = 'qualities'
    str_compat_str_class = '<class \'youtube_dl.compat.compat_str\'>'
    str_determine_ext_class = '<class \'youtube_dl.utils.determine_ext\'>'
    str_qualities_class = '<class \'youtube_dl.utils.qualities\'>'


# Generated at 2022-06-12 18:55:34.243043
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from .zdf_mediathek import ZDFMediathekIE
    zdfie=ZDFIE("https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html")
    zdfie2=ZDFMediathekIE("https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html")
    assert zdfie is not zdfie2



# Generated at 2022-06-12 18:55:35.345384
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie



# Generated at 2022-06-12 18:55:45.361942
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:55:47.064940
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'

# Unit test to check if a given URL is detected or not

# Generated at 2022-06-12 18:55:49.449750
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Without including protocol
    ie = ZDFChannelIE('www.zdf.de/dokumentation/planet-e')
    assert ie.__class__ == ZDFChannelIE
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ie.suitable('https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-12 18:58:14.397788
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        ZDFChannelIE(None)
    except Exception:
        pass

# Generated at 2022-06-12 18:58:17.184044
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base_object = ZDFBaseIE()
    assert isinstance(base_object, InfoExtractor)
    assert base_object._GEO_COUNTRIES == ['DE']
    assert base_object._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:58:19.666364
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie='ZDFIE()'
    assert zdfie

# Generated at 2022-06-12 18:58:24.747968
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Test the constructor of class ZDFChannelIE
    """
    zdfcie = ZDFChannelIE()
    assert zdfcie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not zdfcie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert isinstance(zdfcie.ie_key(), str)
    assert isinstance(zdfcie.ie, type)
    assert isinstance(zdfcie.ie, type)
    assert issubclass(zdfcie.ie, InfoExtractor)

# Generated at 2022-06-12 18:58:26.962996
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    This unit test asserts that ZDFChannelIE.suitable
    will return true for ZDF urls which should be supported.
    """
    assert not ZDFChannelIE.suitable(ZDFIE._VALID_URL)
    assert ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL)

# Generated at 2022-06-12 18:58:29.783760
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Only run test_ZDFIE() once for the whole class
    setattr(ZDFIE, '__test__', False)
    # Run tests
    run_test(ZDFIE, ZDFIE._TESTS)



# Generated at 2022-06-12 18:58:36.801255
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Constructor for class ZDFIE
    zdf_ie = ZDFIE()
    # _Queries and constants
    assert zdf_ie._GEO_COUNTRIES == ['DE']
    assert zdf_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    # _VALID_URL
    assert zdf_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    # _TESTS

# Generated at 2022-06-12 18:58:38.918580
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.ie_key()
    ie.suitable()
    ie.add_ie()


# Generated at 2022-06-12 18:58:40.685077
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None, 'http://')
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-12 18:58:46.180436
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import warnings
    warnings.simplefilter('error', Warnings)
    zdf_channel_ie = ZDFChannelIE()
    zdf_channel_ie.suitable('https://www.zdf.de/politik/frontal-21/frontal-21-aktuell/frontal-21-aktuell-100.html')
    zdf_channel_ie._match_id('https://www.zdf.de/politik/frontal-21/frontal-21-aktuell/frontal-21-aktuell-100.html');