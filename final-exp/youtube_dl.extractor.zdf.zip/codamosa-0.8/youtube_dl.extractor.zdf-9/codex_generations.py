

# Generated at 2022-06-12 18:49:29.414891
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    for url in (
            'https://www.zdf.de/filme/taunuskrimi/',
            'https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html',
            'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html',
            'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html',
            ):
        assert ZDFChannelIE.suitable(url)

# Generated at 2022-06-12 18:49:31.978978
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbaseIE = ZDFBaseIE()
    assert zdfbaseIE
    #~ print(zdfbaseIE)


# Generated at 2022-06-12 18:49:32.825641
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE("youtube")



# Generated at 2022-06-12 18:49:39.015066
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = "https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html"
    zdfie = ZDFIE()
    assert(zdfie.ie_key() == 'zdf')
    assert(zdfie.ie_key() in ZDFIE.ie_key())
    assert(zdfie.suitable(url))
    assert(zdfie._TESTS[0]['url'] == url)
    assert(zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html')

# Generated at 2022-06-12 18:49:41.028407
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert type(ZDFIE) == type


# Generated at 2022-06-12 18:49:49.857743
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.downloader import ZDFDownloader
    from youtube_dl.extractor.zdf import ZDFChannelIE
    from youtube_dl.utils import urljoin
    from youtube_dl.compat import compat_urlparse
    from datetime import date, datetime
    # Test all information extractions for a channel feed
    def extractChannelPage(url, expect, count, items_count=None):
        downloader = ZDFDownloader(None, {'verbose': True})
        ie = ZDFChannelIE()
        result = ie.extract(url)
        assert result['id'] == expect['id']
        assert result['title'] == expect['title']
        items_count = expect.get('count', count) if items_count is None else items_count
        assert result.get('_type', 'playlist') == expect

# Generated at 2022-06-12 18:49:51.579462
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE



# Generated at 2022-06-12 18:50:00.683515
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-12 18:50:05.627065
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base_ie = ZDFBaseIE('http://www.zdf.de', 'test_extractor_key')
    assert base_ie.geo_countries == ['DE']
    assert base_ie.qualities == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
# End of unit test


# Generated at 2022-06-12 18:50:08.255246
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for constructor of class ZDFChannelIE
    """
    test_input_url = "https://www.zdf.de/filme/taunuskrimi/"
    if ZDFChannelIE.suitable(test_input_url):
        actual_output = ZDFChannelIE.suitable(test_input_url)
    else:
        print("Error: input url is not valid")


# Generated at 2022-06-12 18:50:34.495606
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Construct an instance of class ZDFIE
    ZDFIE()._download_webpage('http://bild.rtl.de','test')


# Generated at 2022-06-12 18:50:35.254460
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    pass

# Generated at 2022-06-12 18:50:47.347848
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-12 18:50:50.819790
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    __import__(ZDFChannelIE.__module__)
    ZDFChannelIE.__module__ = ZDFChannelIE.__module__ + '_' + ZDFChannelIE.ie_key()
    return ZDFChannelIE()



# Generated at 2022-06-12 18:51:00.555947
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():

	assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
	assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
	assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
	assert not ZDFIE.suitable('https://www.zdf.de/filme/taunuskrimi/')

if __name__ == '__main__':
    test_ZDFChannelIE()
    from sys import exit
    exit(0)

# Generated at 2022-06-12 18:51:01.828382
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(ZDFIE.ie_key() == "zdf")


# Generated at 2022-06-12 18:51:05.350745
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert "title" in ZDFChannelIE()._extract_regular(
        "https://www.zdf.de/sport/das-aktuelle-sportstudio", {
            "content": "",
            "apiToken": ""
        }, "das-aktuelle-sportstudio")

# Generated at 2022-06-12 18:51:06.850962
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE(ZDFChannelIE.create_ie_key(), URL_CHANNEL)


# Generated at 2022-06-12 18:51:07.398512
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    return None

# Generated at 2022-06-12 18:51:09.998676
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    klass = ZDFBaseIE
    zdf_base = klass(InfoExtractor())
    assert zdf_base._GEO_COUNTRIES == ['DE']
    assert zdf_base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:52:07.584500
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_url = 'https://www.zdf.de/dokumentation/planet-e'
    channel_id = 'planet-e'
    channel_title = 'planet e.'
    ie = ZDFChannelIE(channel_url, channel_title, channel_id)
    assert isinstance(ie, ZDFChannelIE), "Create object of class ZDFChannelIE failed"

# Generated at 2022-06-12 18:52:09.934066
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')



# Generated at 2022-06-12 18:52:13.788255
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .youtube import YouTubeIE
    from .dailymotion import DailymotionIE
    from .facebook import FacebookIE

    zdfbase = ZDFBaseIE.__new__(ZDFBaseIE)

    assert zdfbase.name == 'ZDF'
    assert zdfbase.ie == [
        ZDFIE.ie_key(),
        YouTubeIE.ie_key(),
        DailymotionIE.ie_key(),
        FacebookIE.ie_key(),
    ]



# Generated at 2022-06-12 18:52:16.552980
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_common import list_test_data
    assert len(list_test_data(ZDFChannelIE)) > 0, "It seems that a new test data is added."

# Generated at 2022-06-12 18:52:20.045493
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from zdf_playlist_extractor import ZDFChannelIE
    url = 'https://www.zdf.de/dokumentation/planet-e'
    assert ZDFChannelIE.suitable(url)
    assert ZDFChannelIE._VALID_URL == url


# Generated at 2022-06-12 18:52:25.442697
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()

    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie._TESTS[1]['url'][-11:] == ie._TESTS[2]['url'][-11:]
    assert ie._TESTS[3]['url'][-12:] == ie._TESTS[4]['url'][-12:]
    assert ie._TESTS[5]['url'][-10:] == ie._TESTS[6]['url'][-10:]
    assert ie._TESTS[7]['url'][-16:] == ie._TESTS[8]['url'][-16:]
    assert ie._TESTS[9]['url'][-17:] == ie._TESTS[10]['url'][-17:]



# Generated at 2022-06-12 18:52:26.514686
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE()

# Generated at 2022-06-12 18:52:28.509546
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    ie._call_api("https://zdf.de", "", "")

# Generated at 2022-06-12 18:52:32.938116
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Unit test for constructor of class ZDFChannelIE"""
    channel_id = 'das-aktuelle-sportstudio'
    url = 'https://www.zdf.de/sport/%s' % channel_id

# Generated at 2022-06-12 18:52:36.700760
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        from zenlogging import UnitTestLogHandler
        import logging
        logger = logging.getLogger()
        logger.addHandler(UnitTestLogHandler())
        zdf_channel = ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')
        result = zdf_channel.suitable(['https://www.zdf.de/filme/taunuskrimi/', None])
        if not result:
            raise Exception('Unit test for ZDFChannelIE failed: False is not True')
    except Exception as e:
        print(e)


# Generated at 2022-06-12 18:54:37.290043
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert channel._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 18:54:38.914964
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'


# Generated at 2022-06-12 18:54:41.295500
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for constructor of class ZDFChannelIE.
    """
    zdf_channel_ie = ZDFChannelIE()
    assert isinstance(zdf_channel_ie, ZDFChannelIE) and isinstance(zdf_channel_ie, InfoExtractor)


# Generated at 2022-06-12 18:54:50.324058
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Set to True to enable assert checking
    run_assert = False

    ie = ZDFIE()

    assert ie.ie_key() == 'ZDF'

    if run_assert:
        assert ie.title() == 'ZDF'
        assert ie.extract_id('https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html') == '141007_ab18_10wochensommer_film'

        assert ie.GEO_COUNTRIES == ['DE']
        assert ie.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:54:51.915617
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    zdf._extract_player("data-zdfplayer-jsb='{.+?}'", "abc")



# Generated at 2022-06-12 18:54:54.319329
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    return ZDFBaseIE


# Generated at 2022-06-12 18:54:58.839373
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_url = 'https://www.zdf.de/dokumentation/planet-e'
    channel_id = 'planet-e'
    channel_title = 'planet e.'

# Generated at 2022-06-12 18:54:59.626873
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-12 18:55:00.628338
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(ZDFIE._VALID_URL, ZDFIE._TESTS)

# Generated at 2022-06-12 18:55:04.985983
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    all_video_urls = list()
    test_url = 'https://www.zdf.de/filme/taunuskrimi'
    ies = tuple(gen_extractors())
    for ie in ies:
        if ie.suitable(test_url):
            result = ie.extract(test_url)
            for video_url in result['entries']:
                if video_url['url'] not in all_video_urls:
                    all_video_urls.append(video_url['url'])

# Untested extractors
#
# - 'artenschutz' and 'zdfinfo' (not actually implemented)
# - 'zdfmediathek' (embeds zdf and zdfchannel)