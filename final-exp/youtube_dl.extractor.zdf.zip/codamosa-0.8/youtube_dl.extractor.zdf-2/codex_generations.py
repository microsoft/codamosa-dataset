

# Generated at 2022-06-12 18:49:17.809959
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    x = ZDFIE()
    assert x.name == "ZDF"



# Generated at 2022-06-12 18:49:24.051277
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE(
        ZDFChannelIE._build_url_result('https://www.zdf.de/filme/taunuskrimi/')
    )
    if not ie._VALID_URL.match(ie._TESTS[2]['url']):
        raise AssertionError('Invalid id extracted')

# Generated at 2022-06-12 18:49:28.605168
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:49:33.894393
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable(url)
    assert 'channel id' in zdf_channel_ie._VALID_URL
    assert 'playlist_mincount' in zdf_channel_ie._TESTS[0]

# Generated at 2022-06-12 18:49:36.544125
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/serie/mach-mit/mach-mit-folgenuebersicht-100.html'
    id = 'mach-mit-folgenuebersicht-100'
    assert ZDFChannelIE._match_id(url) == id
    assert ZDFChannelIE._TESTS[0]['url'] == url


# Generated at 2022-06-12 18:49:37.888663
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print(ZDFChannelIE(ZDFChannelIE.suitable).extract('https://www.zdf.de/nachrichten/politik'))

# Generated at 2022-06-12 18:49:39.838775
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannelie = ZDFChannelIE('http://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert zdfchannelie.__class__.__name__ == 'ZDFChannelIE'

# Generated at 2022-06-12 18:49:41.667761
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE._download_json("", "", "", headers={})


# Generated at 2022-06-12 18:49:45.353329
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Some basic checks to make sure that the constructor is sane
    ie = ZDFBaseIE("ZDFBaseIE")
    assert ie.ie_key() == "ZDFBaseIE"
    assert ie.test()
    assert ie.working == True
    assert ie.result_type == "_VIDEO_SOURCES"

# Unit tests for ZDFBaseIE._extract_player

# Generated at 2022-06-12 18:49:48.666024
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'zdf'
    assert ZDFIE.ie_key() not in ZDFIE._IES


# Generated at 2022-06-12 18:50:15.954686
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # test case-1: assert whether the parameter passed is instance of ZDFChannelIE class
    assert isinstance(ZDFChannelIE(), ZDFChannelIE)


# Generated at 2022-06-12 18:50:17.299709
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    assert(instance is not None)


# Generated at 2022-06-12 18:50:18.876421
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:50:23.907161
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    assert ZDFChannelIE.suitable(url) is True
    ie = ZDFChannelIE()
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.SUITABLE_URL == ZDFChannelIE._VALID_URL
    assert ie.VALID_URL == ZDFChannelIE._VALID_URL
    assert ie.EXTENSION == 'mp4'

# Test for constructor of class ZDFIE

# Generated at 2022-06-12 18:50:25.139082
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert(
        isinstance(ZDFBaseIE('test'), InfoExtractor))



# Generated at 2022-06-12 18:50:27.781675
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    IE = ZDFIE()
    assert isinstance(IE, ZDFBaseIE)
    assert IE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'



# Generated at 2022-06-12 18:50:33.871004
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    videos_found = 0
    videos_skipped_due_to_missing_url = 0
    videos_skipped_due_to_wrong_url = 0
    params = {
        'skipped_due_to_missing_url': videos_skipped_due_to_missing_url,
        'skipped_due_to_wrong_url': videos_skipped_due_to_wrong_url,
    }


# Generated at 2022-06-12 18:50:37.612522
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # pylint: disable=protected-access
    assert ZDFChannelIE._VALID_URL == ZDFIE._VALID_URL[:-5]
    assert ZDFChannelIE.__name__ == ZDFIE.__name__[:-2]
    assert ZDFChannelIE.ie_key() == ZDFIE.ie_key() + ':channel'
    assert ZDFChannelIE.ie_key() in ZDFChannelIE._ies
    assert 'zdf:channel' in ZDFChannelIE._downloader_types

# Generated at 2022-06-12 18:50:38.195443
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    raise NotImplementedError('Must be implemented')

# Generated at 2022-06-12 18:50:44.529337
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/') == True
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') == False

# Generated at 2022-06-12 18:51:07.973187
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.geo_countries


# Generated at 2022-06-12 18:51:10.457187
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .. import get_testdata_files # pylint: disable=unreachable
    from .common import get_unit_test_case
    video_tests = get_testdata_files(get_unit_test_case())
    for video_test in video_tests:
        video_test.test()


# Generated at 2022-06-12 18:51:16.986967
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    with vcr.use_cassette('/paths/zdf/zdf_channel_ie.yaml'):
        test = ZDFChannelIE()
        assert test.suitable(None) == False
        assert test.suitable(ZDFChannelIE._VALID_URL) == True
        test_result = test._real_extract(ZDFChannelIE._TESTS[0]['url'])
        assert test_result['_type'] == 'playlist'
        assert len(test_result['entries']) == test_result['playlist_mincount']

# Generated at 2022-06-12 18:51:20.048320
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e') is not None
    assert ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio') is not None

# Generated at 2022-06-12 18:51:27.728868
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_cases = [('ZDFIE', {'url': 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'})]
    for klass, kw in test_cases:
        ie = globals()[klass]()
        for key, value in kw.items():
            assert ie._downloader.params[key] == value


# Generated at 2022-06-12 18:51:31.625388
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert ie is not None


# Generated at 2022-06-12 18:51:34.938832
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # This test checks whether the constructor of class ZDFIE works as expected.
    zdfie = ZDFIE()
    assert zdfie.extract.__name__ == "ZDFIE.extract", "Extract name error."



# Generated at 2022-06-12 18:51:37.056112
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Tries to create an instance of class ZDFIE
    # and assert that it is not None
    instance = ZDFIE()
    assert instance is not None


# Generated at 2022-06-12 18:51:43.266096
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel = ZDFChannelIE(ZDFChannelIE.ie_key())
    assert zdf_channel.suitable('https://www.zdf.de/politik/maybritt-illner')
    assert not zdf_channel.suitable('https://www.zdf.de/politik/maybritt-illner/gefluechtete-tuerkische-rapper-im-interview-mit-maybritt-illner-100.html')
    assert not zdf_channel.suitable('https://www.zdf.de/politik/maybritt-illner/gefluechtete-tuerkische-rapper-im-interview-mit-maybritt-illner-100')

# Generated at 2022-06-12 18:51:45.413666
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')



# Generated at 2022-06-12 18:52:38.046210
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    player = ZDFBaseIE()._extract_player("""
        var gain = gain || {};
        var data-zdfplayer-jsb = {
            "foo": "bar",
            "qux": "quux"
        };
        var foo = "bar";
        news = {
            "foo": "bar",
            "qux": "quux"
        };
    """, "123")
    assert player == {
        "foo": "bar",
        "qux": "quux"
    }

# Generated at 2022-06-12 18:52:48.656009
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test that ZDFIE.suitable fails
    # Note: mocker.patch(ZDFIE.suitable) doesn't apply because
    # ZDFIE.suitable is a @classmethod
    with mocker.patch('%s.ZDFIE.suitable' % __name__):
        ZDFIE.suitable.return_value = False
        ZDFChannelIE.suitable('www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')

    # Test that ZDFIE.suitable succeeds
    with mocker.patch('%s.ZDFIE.suitable' % __name__):
        ZDFIE.suitable.return_value = True

# Generated at 2022-06-12 18:52:49.918263
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    a = ZDFIE(3,4)



# Generated at 2022-06-12 18:52:53.322398
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie_ = ZDFChannelIE()
    assert ie_._TESTS[0]['info_dict']['id'] == 'das-aktuelle-sportstudio'
    assert ie_._TESTS[1]['info_dict']['id'] == 'planet-e'
    return

# Generated at 2022-06-12 18:52:54.993673
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert issubclass(ZDFIE, InfoExtractor)

# Generated at 2022-06-12 18:52:59.170870
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Unit test for constructor of class ZDFBaseIE
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:53:01.371053
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    IE = ZDFBaseIE()
    assert IE._GEO_COUNTRIES == ['DE']
    assert IE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:53:06.992344
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channels = [
        'https://www.zdf.de/filme/taunuskrimi/',
        'https://www.zdf.de/dokumentation/planet-e/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html',
        'https://www.3sat.de/film/spielfilm/der-hauptmann-100.html',
        'https://www.phoenix.de/sendungen/dokumentationen/gesten-der-maechtigen-i-a-89468.html?ref=suche',
    ]
    for ch in channels:
        # This should not raise an exception.
        ZDFChannelIE.suitable(ch)

# Generated at 2022-06-12 18:53:12.183778
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ExtractorTestCase
    from .test_zdf import ZDFBaseTestCase
    from .test_zdf import ZDFBaseIE
    from .test_zdf import ZDFIE

    ExtractorTestCase.test_value_assert.__dict__.update(ZDFBaseTestCase.test_value_assert.__dict__)
    ExtractorTestCase.test_value_assert.__dict__.update(ZDFBaseIE.test_value_assert.__dict__)
    ExtractorTestCase.test_value_assert.__dict__.update(ZDFIE.test_value_assert.__dict__)
    ExtractorTestCase.test_value_assert.__dict__.update(ZDFChannelIE.test_value_assert.__dict__)

    test_case = ExtractorTestCase()

    test_case

# Generated at 2022-06-12 18:53:19.398872
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() != 'zdf'
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:55:20.030660
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-12 18:55:20.868819
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert(ZDFBaseIE)


# Generated at 2022-06-12 18:55:30.214205
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from collections import defaultdict
    from itertools import count
    from .extractors import common
    from .htmlentitydefs import name2codepoint

    # Source: https://zdfstore.zdf.de/mediathekV2/document/das-aktuelle-sportstudio

# Generated at 2022-06-12 18:55:33.365902
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    i = ZDFBaseIE()
    assert i._GEO_COUNTRIES == ['DE']
    assert i._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:55:36.517649
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie._GEO_COUNTRIES == ['DE']
    assert isinstance(zdf_ie._VALID_URL, (str, unicode)) == True
    assert isinstance(zdf_ie._TESTS, list) == True



# Generated at 2022-06-12 18:55:37.834810
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('http://www.zdf.de/filme/taunuskrimi')

# Generated at 2022-06-12 18:55:38.828655
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'



# Generated at 2022-06-12 18:55:41.007696
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:55:41.611222
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBase = ZDFBaseIE()


# Generated at 2022-06-12 18:55:44.888421
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_zdf_base_ie = ZDFBaseIE("https://www.zdf.de/")
    if test_zdf_base_ie._GEO_COUNTRIES == ['DE']:
        if test_zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'):
            print("Unit test for ZDFBaseIE passed!")
    else:
        print("Unit test for ZDFBaseIE failed!")



# Generated at 2022-06-12 18:58:26.468315
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-12 18:58:34.964075
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-12 18:58:43.598303
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE("https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html")
    assert ie._VALID_URL == ZDFChannelIE._VALID_URL
    assert ie._TESTS == ZDFChannelIE._TESTS
    assert ie.ie_key() == ZDFChannelIE.ie_key()
    assert ie.suitable("https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html") == False
    assert ie.suitable("https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek") == True

# Generated at 2022-06-12 18:58:49.767942
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    youtube_dl_instance = youtube_dl.YoutubeDL({})
    ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    ZDFChannelIE.suitable('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')
    zdf_channel_ie_instance = ZDFChannelIE(youtube_dl_instance)
    zdf_channel_ie_instance.suitable('https://www.zdf.de/filme/taunuskrimi/')
    zdf_channel_ie_instance.suitable('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')

# Generated at 2022-06-12 18:58:56.085222
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    zdf_channel = ZDFChannelIE().suitable(url)
    assert zdf_channel is True
    assert ZDFChannelIE()._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ZDFChannelIE()._TESTS[0]['url'] == 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert ZDFChannelIE()._TESTS[0]['playlist_mincount'] == 23
    channel_id = ZDFChannelIE()._match_id(url)