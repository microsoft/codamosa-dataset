

# Generated at 2022-06-12 18:49:19.094574
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        zdfbase = ZDFBaseIE()
    except:
        zdfbase = None
    assert zdfbase is not None


# Generated at 2022-06-12 18:49:21.869299
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')

# Generated at 2022-06-12 18:49:22.631260
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass



# Generated at 2022-06-12 18:49:35.109488
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._call_api('http://www.zdf.de/path/to/api', '1234', 'video details') == {}
    assert ie._call_api('http://www.zdf.de/path/to/api', '1234', 'video details', 'some_token') == {}
    assert ie._extract_subtitles({}) == {}
    # _extract_ptmd
    assert ie._extract_ptmd(
        'http://api.zdf.de/content/documents/priorities/zdf/zdf_master_protected.json',
        '1234', 'some_token', 'http://www.zdf.de/referrer') == {}

# Generated at 2022-06-12 18:49:37.917018
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/planet-e")
    assert not ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html")



# Generated at 2022-06-12 18:49:42.945990
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class TestZDFBaseIE(ZDFBaseIE):
        pass

    test_obj = TestZDFBaseIE()
    assert test_obj.geo_countries == ZDFBaseIE._GEO_COUNTRIES
    assert test_obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:49:47.055901
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/politik/frontal-21/index.html'
    ie = ZDFChannelIE.get_ie(url)
    assert ie.ie_key() == 'ZDF'
    assert ie.suitable(url)
    assert isinstance(ie, ZDFChannelIE)


# Generated at 2022-06-12 18:49:49.741149
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    code = ZDFChannelIE.suitable(url)
    assert code is True


# Generated at 2022-06-12 18:49:51.578061
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-12 18:50:00.653875
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class TestZDFBaseIE(ZDFBaseIE):
        IE_NAME = 'test:zdf'
    test_zdfbaseie = TestZDFBaseIE()
    assert test_zdfbaseie._GEO_COUNTRIES == ['DE']
    assert test_zdfbaseie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert test_zdfbaseie._call_api('https://zdf.de/url/', 'video_id', 'item', None, None)['_type'] == 'playlist'

# Generated at 2022-06-12 18:50:26.531863
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_ie = ZDFBaseIE()
    assert zdf_ie._GEO_COUNTRIES == ['DE']
    # TODO: Add assertion to _QUALITIES


# Generated at 2022-06-12 18:50:36.554743
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from .common import InfoExtractor
    from .zdf import ZDFIE
    from ..utils import unescapeHTML
    ie = InfoExtractor(ZDFIE.ie_key())
    ie = ZDFIE('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')
    assert ie.ie_key() == 'ZDF'
    assert ie.suitable('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')
    assert ie.video_id == 'der-hauptmann-112'
    assert ie.url == 'https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html'

# Generated at 2022-06-12 18:50:42.446309
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    ie._call_api('http://url1', '1', 'url1')
    ie._extract_subtitles([{'captions': [{'uri': 'http://url2', 'language': 'deu'}]}])
    ie._extract_format('video_id', [], set(), {'url': 'http://url3'})
    ie._sort_formats([{'format_id': 'id1'}, {'format_id': 'id2'}])
    ie._extract_ptmd('http://url4', '2', 'Bearer hello, world', 'http://url5')
    ie._extract_player('data-zdfplayer-jsb=\'{}\'', '3')
    assert ie._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-12 18:50:46.693111
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from pytube import extract

    url = 'https://www.zdf.de/dokumentation/planet-e'
    # This is checking that the regex does not fail
    extract.constructor(ZDFChannelIE)(url)


# Generated at 2022-06-12 18:50:52.718305
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from ..utils import get_testdata_files_path, get_testdata_folder_path
    zdfie = ZDFIE()
    zdfie._get_subtitles = _get_subtitles
    zdfie._formats = _formats
    info = zdfie._call_api('url','video_id','item','api_token','referrer')
    info = zdfie._download_json('url','video_id','item')
    info = zdfie._parse_json('json','video_id')


# Generated at 2022-06-12 18:50:55.435029
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, ZDFBaseIE)



# Generated at 2022-06-12 18:50:59.017222
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:51:03.356875
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE'], "Test for _GEO_COUNTRIES failed"
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'),  "Test for _QUALITIES failed"


# Generated at 2022-06-12 18:51:05.576764
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    return ZDFIE()._real_extract('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')



# Generated at 2022-06-12 18:51:07.110012
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    assert instance.ie_key() == 'ZDF'
    assert instance.ie_key() in ZDFIE._ies

# Extracting content information

# Generated at 2022-06-12 18:51:59.379719
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBase = ZDFBaseIE()
    assert zdfBase._GEO_COUNTRIES == ['DE']
    assert zdfBase._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:52:07.652646
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.__class__.__name__ == 'ZDFIE'
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:52:09.294562
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'



# Generated at 2022-06-12 18:52:10.180228
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')

# Generated at 2022-06-12 18:52:21.225528
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zb = ZDFBaseIE()
    assert zb.suitable('https://www.zdf.de/dokumentation/zdfinfo-doku/wasser-zu-wertvoll-fuer-die-tonne-100.html')
    assert zb.suitable('https://www.zdf.de/kinder/logo!116/logo-folge-116-des-tages-100.html')
    assert zb.suitable('https://www.zdf.de/filme/der-alte/der-alte-die-tote-im-see-102.html')
    assert not zb.suitable('http://www.arte.tv/de/videos/062042-001-A/das-geheimnis-der-piraten-kapitaeler/')
   

# Generated at 2022-06-12 18:52:23.746418
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest

    testsuite = unittest.TestLoader().loadTestsFromTestCase(ZDFChannelIE)
    assert testsuite.countTestCases() == 1


# Generated at 2022-06-12 18:52:26.310332
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import ZDFIE, ZDFBaseIE, ZDFChannelIE
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'ZDF'
    zdfbaseie = ZDFBaseIE()
    assert zdfbaseie.ie_key() == 'ZDFBase'
    zdfchannelie = ZDFChannelIE()
    assert zdfchannelie.ie_key() == 'ZDFChannel'



# Generated at 2022-06-12 18:52:31.657464
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbaseie = ZDFBaseIE()
    zdfbaseie._download_json('http://www.zdf.de/', None, 'downloading json')
    zdfbaseie._extract_ptmd('http://www.zdf.de/', None, None, None)


# Generated at 2022-06-12 18:52:35.287969
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:52:37.785866
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e') == True
    assert ie.suitable('https://www.zdf.de/dokumentarfilm/die-zukunft-der-erde-10-wochen-sommer-103.html') == False

# Generated at 2022-06-12 18:54:40.389447
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie.ie_key() == 'ZDF'
    assert zdfie.ie_key_likes() == orderedSet(['ZDF'])
    return


# Generated at 2022-06-12 18:54:49.229447
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._extract_regular('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html', {'apiToken': '2.4', 'content': 'https://api.zdf.de/content/documents/wohin-fuehrt-der-protest-in-der-pandemie-100.html'}, 'wohin-fuehrt-der-protest-in-der-pandemie-100.html')

# Generated at 2022-06-12 18:54:53.589077
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-12 18:55:03.097586
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # https://www.zdf.de/serien/tatort/tatort-koeln-ein-dunkler-fleck-100.html
    zdfer = ZDFBaseIE()

    link = "https://www.zdf.de/serien/tatort/tatort-koeln-ein-dunkler-fleck-100.html"

    # Create instance with arguments:
    # * local variables
    # * video_id
    # * title
    # * languages
    # * subtitles
    # * download_thumbnails
    # * subtitles_format
    # * dump
    # * verbose
    # * download_store_dir
    # * download_thumbnail_dir
    # * download_subtitles_dir
    # * download_format
    # * download_archive_dir


# Generated at 2022-06-12 18:55:08.373101
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    # call _call_api with api_token and referrer
    ie._call_api('https://zdfmediathk.sourcefabric.org/api2/assets/', 'test_id', 'test_item'
        , api_token = 'some_token', referrer = 'some_referrer')
    # call _call_api without api_token and referrer
    ie._call_api('https://zdfmediathk.sourcefabric.org/api2/assets/', 'test_id', 'test_item')


# Generated at 2022-06-12 18:55:11.808491
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE("www.zdf.de/live-tv/zdf")
    assert ie.suitable("https://www.zdf.de/live-tv/zdf") == True
    assert ie.suitable("https://www.zdf.de/serien/marie-brand-und-der-feuersturm-100.html") == False

# Generated at 2022-06-12 18:55:17.984874
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class TestZDFChannelIE(ZDFChannelIE):
        def _extract_player(self, webpage, video_id, fatal=True):
            return self._parse_json(
                self._search_regex(
                    r'(?s)data-zdfplayer-jsb=(["\'])(?P<json>{.+?})\1', webpage,
                    'player JSON', default='{}' if not fatal else NO_DEFAULT,
                    group='json'),
                video_id)
    TestZDFChannelIE()._real_extract("https://www.zdf.de/dokumentation/planet-e")

# Generated at 2022-06-12 18:55:21.272919
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbaseie = ZDFBaseIE()
    zdfbaseie._call_api('http://www.zdf.de', 'id', 'item', api_token=None, referrer=None)
    zdfbaseie._extract_subtitles({})
    zdfbaseie._extract_format('video_id', [], set(), {})
    zdfbaseie._extract_ptmd('ptmd_url', 'video_id', 'token', 'referrer')
    zdfbaseie._extract_player('webpage', 'video_id', fatal=True)



# Generated at 2022-06-12 18:55:30.662399
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    parse_ZDFChannelIE = lambda url: (  # NOQA
        ZDFChannelIE
        .suitable(url)
        .is_applicable(url)
        .extract(url))  # NOQA

    assert parse_ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/') is None
    assert parse_ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') is not None

# Generated at 2022-06-12 18:55:33.917530
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
