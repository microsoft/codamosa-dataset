

# Generated at 2022-06-12 18:49:16.597229
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-12 18:49:17.657980
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE(None, {}, None)



# Generated at 2022-06-12 18:49:22.824466
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie_ZDFIE = ZDFIE()
    if ie_ZDFIE is not None:
        print("Default construct ok!")
    else:
        print("Default construct failure!")
        assert False

# Generated at 2022-06-12 18:49:27.340913
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:49:35.066532
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE(None)
    assert ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert not ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')

# Generated at 2022-06-12 18:49:36.352922
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio').suitable(None)

# Generated at 2022-06-12 18:49:47.015986
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'

# Generated at 2022-06-12 18:49:57.980707
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel = ZDFChannelIE("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    assert zdf_channel.suitable("https://www.zdf.de/sport/das-aktuelle-sportstudio") == True
    assert zdf_channel.suitable("https://www.zdf.de/sport/das-aktuelle-sportstudio/") == True
    assert zdf_channel.suitable("https://www.zdf.de/filme/taunuskrimi/") == True
    assert zdf_channel.suitable("https://www.zdf.de/filme/taunuskrimi") == True
    # test case for unsuitable

# Generated at 2022-06-12 18:49:59.951697
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    assert 'zdf' in ydl.InfoExtractors 


# Generated at 2022-06-12 18:50:01.306021
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    obj = ZDFIE()


# Generated at 2022-06-12 18:50:26.368831
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE();
    assert obj._GEO_COUNTRIES == ['DE'];



# Generated at 2022-06-12 18:50:28.318178
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert channel.channel_id == 'planet-e'
    assert channel.title == 'planet e.'


# Generated at 2022-06-12 18:50:31.698414
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Author of this test: Kika-n
    _test_url = 'https://www.zdf.de/dokumentation/planet-e'
    playlist_data = ZDFChannelIE()._real_extract(_test_url)
    assert (playlist_data['id'] == 'planet-e')
    assert playlist_data['entries']
    assert (playlist_data['title'] == 'planet e.')

# Generated at 2022-06-12 18:50:32.654983
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert isinstance(ZDFChannelIE(), ZDFChannelIE)


# Generated at 2022-06-12 18:50:41.145318
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # The URL below is different from the one in _TESTS below.
    # It is used by the unit test to verify the correctness of the
    # constructor of ZDFIE() class.
    zdfie = ZDFIE('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    # Assertions
    assert zdfie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:50:44.230068
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE("https://www.zdf.de/filme/taunuskrimi/")

# Generated at 2022-06-12 18:50:46.486828
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    IE = ZDFIE(None)
    assert(IE.__class__.__name__ == "ZDFIE")


# Generated at 2022-06-12 18:50:55.688048
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'
    video_id = '151025_magie_farben2_tex'

# Generated at 2022-06-12 18:51:00.235744
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z = ZDFBaseIE()
    assert z._GEO_COUNTRIES == ['DE']
    assert z._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Test for function _extract_subtitles(src) in ZDFBaseIE

# Generated at 2022-06-12 18:51:07.645036
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test_vars = {
        'name': 'ZDFChannelIE',
        'url': 'https://www.zdf.de/dokumentation/planet-e',
        'channel_id': 'planet-e',
    }
    url = test_vars['url']
    channel_ie = ZDFChannelIE()
    assert channel_ie.suitable(url) == True
    assert channel_ie.IE_NAME.lower() == test_vars['name'].lower()
    assert channel_ie._VALID_URL == test_vars['url']
    assert channel_ie._match_id(url) == test_vars['channel_id']
test_ZDFChannelIE()



# Generated at 2022-06-12 18:52:01.587938
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Test if the test cases are working.
    """
    def test_item(item):
        ie = ZDFChannelIE()
        assert ie.suitable(item['url']), 'Url:"%s" is not suitable' % item['url']
        video = ie.extract(item['url'])
        assert item.get('mincount') is None or len(video['entries']) >= item['mincount'], \
            'Video:"%s" has: %d entries but expected at least %d' % (
                item['url'], len(video['entries']), item['mincount'])
    for item in ZDFChannelIE._TESTS:
        test_item(item)


# Generated at 2022-06-12 18:52:02.518720
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-12 18:52:04.327372
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test for constructor of class ZDFBaseIE
    # Set all inputs to constructor
    ZDFBaseIE(None, None, '', '')



# Generated at 2022-06-12 18:52:04.845202
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass


# Generated at 2022-06-12 18:52:15.194564
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    IE = ZDFBaseIE('ZDFBaseIE', 'http://www.zdf.de/zdf/zdfportal/bla')
    assert IE.name == 'ZDFBaseIE'
    assert IE._VALID_URL == r'https?://www\.zdf\.de/.*/?[^/]+-?\d+(?P<id>[a-z0-9]+)\.html'
    assert IE._GEO_COUNTRIES == ['DE']
    assert IE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    #_call_api test
    #_extract_subtitles test
    assert ZDFBaseIE._extract_subtitles({}) == {}
    #_extract_format test

# Generated at 2022-06-12 18:52:24.477721
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from .common import InfoExtractor

    ie = ZDFIE()
    # Test '_GEO_COUNTRIES'
    assert ie._GEO_COUNTRIES == ['DE']

    # Test '_VALID_URL'
    valid_url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._match_id(valid_url)

    # Test '_extract_entry'

# Generated at 2022-06-12 18:52:27.561585
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Basic test case
    """
    from . import _test_classes
    from .zdf import ZDFIE
    _test_classes.ZDFChannelIE = ZDFChannelIE
    _test_classes.ZDFIE = ZDFIE

# Generated at 2022-06-12 18:52:37.814737
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert isinstance(ie, ZDFBaseIE)
    assert ie.ie_key() == 'zdf'
    assert ie.tmpfilename == 'ZDF'
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:52:48.346928
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class FakeException(Exception):
        """To fake extracting of an entry."""
    # Test the constructor of class ZDFChannelIE
    ZDFChannelIE._real_extract = lambda url: FakeException("constructor of ZDFChannelIE shouldn't call this method.")
    # Test for non-existing channel
    with pytest.raises(ExtractorError, match="Channel ID 'non-existing-channel' doesn't exist"):
        fake_url = 'http://www.zdf.de/non-existing-channel'
        ZDFChannelIE().suitable(fake_url)
        ZDFChannelIE()._real_extract(fake_url)
        ZDFChannelIE()._real_extract(fake_url)
    # Test for existing channel

# Generated at 2022-06-12 18:52:52.265849
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    print("\nUnit Test for ZDFIE Constrcutor.")
    zdfie = ZDFIE()
    zdfie._download_webpage("http://www.zdf.de/ZDFmediathek/podcast/2135838?view=podcast", "2135838", fatal=False)
    print("Unit test completed.")



# Generated at 2022-06-12 18:53:56.521010
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(InfoExtractor)
    if ie._GEO_COUNTRIES != ['DE']:
        # pylint: disable=W0212
        ie._GEO_COUNTRIES = ['DE']
    if ie._QUALITIES != ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'):
        # pylint: disable=W0212
        ie._QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-12 18:54:00.235392
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
  video = ZDFBaseIE()
  assert video is not None
  assert hasattr(video, '_call_api')
  assert hasattr(video, '_extract_subtitles')
  assert hasattr(video, '_extract_format')
  assert hasattr(video, '_extract_player')
  return True



# Generated at 2022-06-12 18:54:04.613054
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-12 18:54:06.668224
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    example_url = 'https://www.zdf.de/wissen/nano'
    ie.suitable(example_url)
    ie = ZDFIE()
    ie.suitable(example_url)
    assert ie.suitable(example_url) == False



# Generated at 2022-06-12 18:54:14.175179
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
    video_id = 'p-e/uebersichtsseite/weitere-dokumentationen-von-planet-e'

    zdf = ZDFIE()
    player = zdf._extract_player(url, video_id)
    content = zdf._call_api(player['content'], video_id, 'content', player['apiToken'], url)
    entry = zdf._extract_entry(player['content'], player, content, video_id)
    print(entry)



# Generated at 2022-06-12 18:54:24.932628
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class ZDFBaseIEMock(ZDFBaseIE):
        IE_DESC = 'ZDF Mock'
        _VALID_URL = r'https?://mock\.com/'
        _TESTS = [{
            'url': 'https://mock.com/',
            'info_dict': {
                'id': 'test',
            }
        }]
        _GEO_COUNTRIES = ['DE', 'FR']
        _QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
            }

    # Instantiate the mock class that extends ZDFBaseIE and check that it is working
    mock_obj = ZDFBase

# Generated at 2022-06-12 18:54:29.050536
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()

    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-12 18:54:34.876226
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    for ie_class in ie_key_map.values():
        if ie_class is ZDFChannelIE:
            print('%s: pass' % ie_class.__name__)
            continue
        try:
            ie_class.suitable(ie_class._VALID_URL)
            print('%s: suitable() should not return True for ZDFChannel.' % ie_class.__name__)
        except TypeError:
            print('%s: pass' % ie_class.__name__)


# Generated at 2022-06-12 18:54:40.159959
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print(ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'))
    print(ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e'))
    print(ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/'))



# Generated at 2022-06-12 18:54:40.665157
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    pass


# Generated at 2022-06-12 18:57:11.057145
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE.ie_key() == 'zdf'


# Generated at 2022-06-12 18:57:16.646050
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import time
    import urllib

    url = urllib.parse.quote(
        'https://www.zdf.de/dokumentation/planet-e', safe="%/:=&?~#+!$,;'@()*[]")
    html = '<html><head><title>1</title></head><body><h1>Hello, World!</h1></body></html>'
    zdf_channel_ie = ZDFChannelIE()
    zdf_channel_ie._download_webpage(url, 'dokumentation/planet-e', fatal=False)
    assert zdf_channel_ie._download_webpage(url, 'dokumentation/planet-e',
                                            fatal=False) == html

# Generated at 2022-06-12 18:57:18.080239
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen'
    channel = ZDFChannelIE(url)
    assert channel.suitable(url)



# Generated at 2022-06-12 18:57:25.991699
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Unit test for constructor of class ZDFChannelIE
    """

# Generated at 2022-06-12 18:57:30.065020
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test ZDFBaseIE constructor"""

    # Arrange
    info_extractor = ZDFBaseIE()

    try:
        # Act
        assert info_extractor is not None
    except AssertionError:
        # Assert
        assert False, "Creation of ZDFBaseIE failed"


# Generated at 2022-06-12 18:57:39.515206
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import pytest
    from youtube_dl.downloader import YoutubeDL
    return_value = YoutubeDL(
        {
            'simulate': True,
            'skip_download': True,
            'listformats': True,
            'dump_intermediate_pages': True,
            'writesubtitles': True,
        }
    ).list_ie(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    )
    assert len(return_value) > 0
    for entry in return_value:
        if not isinstance(entry, dict):
            pytest.fail('Expected to get a dictionary object.')
        assert 'extractor' in entry
        assert 'id' in entry
        assert 'title' in entry

# Generated at 2022-06-12 18:57:40.556777
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()

# Generated at 2022-06-12 18:57:46.482317
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # For example see https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/common.py
    webpage = 'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
    regexUrl = 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    ZDFIE.test_cases(webpage, regexUrl)


# Generated at 2022-06-12 18:57:48.597745
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert re.match(r'^zdf:.+$', ZDFBaseIE.ie_key()) is not None
    assert re.match(r'^zdf:.+$', ZDFBaseIE().ie_key()) is not None


# Generated at 2022-06-12 18:57:49.704402
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(ZDFIE({}) == ZDFIE)

# Unit tests for functions of class ZDFIE