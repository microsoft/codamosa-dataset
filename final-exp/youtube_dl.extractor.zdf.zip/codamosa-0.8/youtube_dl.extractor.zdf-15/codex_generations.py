

# Generated at 2022-06-12 18:49:21.158407
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.get_geo_countries() == ['DE']



# Generated at 2022-06-12 18:49:29.821316
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-12 18:49:31.560530
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')



# Generated at 2022-06-12 18:49:37.262496
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie._GEO_COUNTRIES == ['DE']
    assert zdf_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdf_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Test-Cases for _extract_ptmd(self, ptmd_url, video_id, api_token, referrer)

# Generated at 2022-06-12 18:49:40.809762
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE(None, 'http://some.url')
    assert ie.ie() == ZDFIE.ie()
    assert ie._VALID_URL is ZDFIE._VALID_URL


# Generated at 2022-06-12 18:49:49.668728
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """Test function for constructor of class ZDFIE"""
    zdf_ie = ZDFIE()
    assert zdf_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:49:52.217980
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')

# Generated at 2022-06-12 18:49:59.059528
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_ie = ZDFBaseIE(
        'ZDF', 'http://www.zdf.de/ZDFmediathek/kanaluebersicht/aktuellste',
        'http://www.zdf.de/ZDFmediathek/kanaluebersicht/aktuellste/186260')
    assert zdf_ie._GEO_COUNTRIES == ['DE']
    assert zdf_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:50:03.856474
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto','low','med','high','veryhigh','hd')
    assert ie._call_api == ZDFBaseIE._call_api


# Generated at 2022-06-12 18:50:06.083613
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFIE()
    except ValueError as e:
        assert str(e) == 'ZDFBaseIE expects an ie_key!'

# Generated at 2022-06-12 18:50:34.130823
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zt = ZDFIE()
    assert zt._GEO_COUNTRIES == ['DE']
    assert zt._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:50:46.533433
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .common import BASE_URL
    from .abc_common_test import ABCTestBase
    from .abc_playlist_extractor_test import ABCPlaylistExtractorTest
    from .abc_playlist_extractor_test import check_valid_playlist
    from .abc_playlist_extractor_test import check_invalid_playlist

    def init_and_check_valid_playlist(input_url, **kwargs):
        url = BASE_URL + input_url
        ie = ZDFChannelIE()
        check_valid_playlist(ie, url, **kwargs)

    def init_and_check_invalid_playlist(input_url):
        url = BASE_URL + input_url
        ie = ZDFChannelIE()
        check_invalid_playlist(ie, url)

    init_and

# Generated at 2022-06-12 18:50:47.517446
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    '''
    Run tests on constructor of class ZDFIE
    '''
    ZDFIE()


# Generated at 2022-06-12 18:50:51.794613
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    e = ZDFIE()
    ZDFIE()._download_webpage('')
    ZDFIE()._extract_player('')
    ZDFIE()._real_extract('')
    ZDFIE()._extract_regular('')
    ZDFIE()._extract_mobile('')
    ZDFIE()._extract_ptmd('')
    ZDFIE()._extract_format('')
    ZDFIE()._extract_entry('')
    ZDFIE()._extract_subtitles('')
    ZDFIE()._sort_formats([])
    ZDFIE()._call_api('')

# Generated at 2022-06-12 18:50:55.592058
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable(
        'https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert True



# Generated at 2022-06-12 18:51:05.239280
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE()
    zdfChannelIE._download_webpage = lambda url, video_id: get_test_html()
    zdfChannelIE._call_api = lambda url, player, content, api_token, referrer: {}
    zdfChannelIE._extract_entry = lambda url, player, content, video_id: {}
    zdfChannelIE._extract_player = lambda webpage, video_id, fatal: {
        'content': 'https://www.zdf.de/dokumentation/planet-e',
        'apiToken': 'abc'
    }

    zdfChannelIE.url_result('example.com', 'ZDFIE')

    zdfChannelIE.playlist_result([], 'dokumentation/planet-e')


# Generated at 2022-06-12 18:51:08.351737
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    https://www.zdf.de/sport/die-uebertragungen-bei-zdf-sport-100.html
    This page contains all the necessary attributes for the constructor
    of ZDFBaseIE to run.
    """
    InfoExtractor("ZDFBaseIE")



# Generated at 2022-06-12 18:51:09.048142
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-12 18:51:11.211604
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE(None)
    assert inst.geo_countries == ['DE']
    assert inst.formats == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# test for _call_api for ZDFBaseIE

# Generated at 2022-06-12 18:51:12.215753
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """ Test for the constructor of ZDFIE class.
    """
    zdfie = ZDFBaseIE()

# Generated at 2022-06-12 18:51:46.741363
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    
    from .common import InfoExtractor
    
    # create a new InfoExtractor class
    test_class = ZDFIE()
    # check whether the name is the same
    assert test_class.ie_key() == 'ZDF', "extractor class does not have the same name with the test"
    # check whether it is an instance of the InfoExtractor class
    assert isinstance(test_class, InfoExtractor) == True, "extractor class is not an instance of the InfoExtractor class"



# Generated at 2022-06-12 18:51:49.300429
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None)._check_valid_url(ZDFIE._VALID_URL, 'https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')



# Generated at 2022-06-12 18:51:50.322161
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-12 18:52:00.048006
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    _ZDFBaseIE = ZDFBaseIE()
    assert isinstance(_ZDFBaseIE, ZDFBaseIE)
    assert hasattr(_ZDFBaseIE, '_GEO_COUNTRIES')
    assert isinstance(_ZDFBaseIE._GEO_COUNTRIES, list)
    assert len(_ZDFBaseIE._GEO_COUNTRIES) == 1
    assert 'DE' in _ZDFBaseIE._GEO_COUNTRIES

    assert hasattr(_ZDFBaseIE, '_QUALITIES')
    assert isinstance(_ZDFBaseIE._QUALITIES, tuple)
    assert len(_ZDFBaseIE._QUALITIES) == 6
    assert 'auto' in _ZDFBaseIE._QUALITIES
    assert 'low' in _ZDFBaseIE._QUALITIES

# Generated at 2022-06-12 18:52:00.647748
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-12 18:52:05.451440
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen'
    ie = ZDFChannelIE(url)
    expected = 'https://api.zdf.de/content/documents/phoenix-sendungen.json'
    assert ie.API_TEMPLATE == expected
    assert ie.content_id == 'online/phoenix-sendungen'
    assert ie.url == url


# Generated at 2022-06-12 18:52:16.016924
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    file_a = 'test_ZDFBaseIE_1.html'
    file_b = 'test_ZDFBaseIE_2.html'
    file_c = 'test_ZDFBaseIE_3.html'
    print('\n')
    print('this is a unit test for constructor of class ZDFBaseIE')

    if True:
        ZDFBase = ZDFBaseIE()
        player_meta = ZDFBase._extract_player(self.get_testdata_file(file_a), '886482', fatal=False)
        print('\nplayer_meta: %s', player_meta)
        assert '886482' in player_meta
        assert 'videoAssets' in player_meta
        assert player_meta['videoAssets'] is not None

# Generated at 2022-06-12 18:52:21.842748
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Extraction from webpage.
    webpage = """
        <html>
        <head>
        <script>
        var dataZdfPlayerJsb = {
            "smarttvPlayerJson": '{"mainVideoContent": "https://api.zdf.de/contents/%s?profile=player", "contentId":"https://api.zdf.de/contents/%s?profile=webapp", "playerId": "main", "apiToken": "your_api_token"}'
        };
        </script>
        </head>
        <body>
        </body>
        </html>
    """.strip() % ('content', 'content')
    player = ZDFIE._extract_player(webpage, "ie_unit_test", fatal=False)

# Generated at 2022-06-12 18:52:32.553774
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # When an instance is created,
    instance = ZDFBaseIE()
    # it should have the following attributes.
    attr_dict = {
        '_GEO_COUNTRIES': ['DE'],
        '_QUALITIES': ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'),
    }

    for key in attr_dict:
        # attr_dict[key] is the expected value of the attribute.
        expected_value = attr_dict[key]
        # instance.<key> is the actual value of the attribute.
        actual_value = getattr(instance, key)

        # The actual value should be equal to the expected value.
        assert actual_value == expected_value, '%s != %s' % (
            actual_value, expected_value)



# Generated at 2022-06-12 18:52:40.312506
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test to check that the constructor of the ZDFIE class has the correct
    # arguments and returns a ZDFIE object with the correct attributes
    # Test 1
    url = "https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html"
    webpage = "https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html"
    player = ZDFIE._extract_player(webpage,url,fatal=False)
    assert player is not None
    content = ZDFIE._call_api(player['content'],url,'content',player['apiToken'],url)

# Generated at 2022-06-12 18:53:39.229169
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()

    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:53:39.971751
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-12 18:53:41.451211
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base = ZDFBaseIE('zdf');
    # TODO: other methods.


# Generated at 2022-06-12 18:53:46.032012
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    info = ZDFIE()._real_extract('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert info['id'] == 'dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100'

# Generated at 2022-06-12 18:53:54.733266
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    webpage = download_webpage(url, 'ZDFChannelIE')
    player = ZDFChannelIE._extract_player(webpage, url)
    channel_id = ZDFChannelIE._search_regex(
        r'docId\s*:\s*(["\'])(?P<id>(?!\1).+?)\1', webpage,
        'channel id', group='id')
    channel = ZDFChannelIE._call_api(
        'https://api.zdf.de/content/documents/%s.json' % channel_id,
        player, url, channel_id)
    items = []

# Generated at 2022-06-12 18:53:56.586701
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    IE = ZDFChannelIE.suitable('')
    assert not IE
    IE = ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    assert IE == ZDFChannelIE.ie_key()

# Generated at 2022-06-12 18:53:57.597485
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie.suitable(ZDFChannelIE._VALID_URL)

# Generated at 2022-06-12 18:53:58.415388
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # TODO:
    pass

# Generated at 2022-06-12 18:54:05.163194
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test with the second test input
    ZDFIE()._extract_regular('https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html',
                             'https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html',
                             'https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html')


# Generated at 2022-06-12 18:54:13.861247
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """Unit test code for class ZDFIE"""
    result = []
    zdf_ie = ZDFIE()
    assert zdf_ie is not None
    assert zdf_ie._GEO_COUNTRIES == ['DE']
    assert zdf_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    result += [zdf_ie._VALID_URL]
    assert zdf_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    result += [zdf_ie._QUALITIES]
    assert zdf_ie.ie_key() == 'zdf'
    result += [zdf_ie.ie_key()]
    return result

# Generated at 2022-06-12 18:55:40.539070
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # make sure the inherited class ZDFBaseIE hasn't broken the constructor of InfoExtractor
    ie = ZDFBaseIE(InfoExtractor(None))
    assert ie.extractor_key == ZDFIE.ie_key()
    assert ie.ie_key() == ZDFIE.ie_key()


# Generated at 2022-06-12 18:55:42.188852
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-12 18:55:44.026509
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Check if the 'ZDFBaseIE' class can be initialized
    assert ZDFBaseIE is not None


# Generated at 2022-06-12 18:55:44.615494
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zcf = ZDFChannelIE()


# Generated at 2022-06-12 18:55:47.520584
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    class_name = 'ZDFChannelIE'

    ie = globals()[class_name](class_name, url)
    assert ie._match_id(url)
    assert class_name == ie.ie_key()
    assert url == ie._VALID_URL

    # Test URL matches the regular expression
    assert re.match(ie._VALID_URL, url)

# Generated at 2022-06-12 18:55:48.344424
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-12 18:55:55.325534
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        # raise Exception('Not a unit test')
        # ExtractorError: Cannot identify player URL; please report this issue on https://yt-dl.org/bug . Make sure you are using the latest version; see  https://yt-dl.org/update  on how to update. Be sure to call youtube-dl with the --verbose flag and include its complete output.
        player_json = '{"foo":["bar"]}'
        ZDFBaseIE()._parse_json(player_json, 'None')
    except Exception:
        pass
    else:
        assert False, 'Should not reach here'



# Generated at 2022-06-12 18:56:05.997873
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-12 18:56:07.971013
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE(): # pylint: disable=R0903, R0913
    ZDFChannelIE('http://url', 'fetch_info', 'http://webpage')


# Generated at 2022-06-12 18:56:11.174329
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE'] and zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
