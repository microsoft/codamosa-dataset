

# Generated at 2022-06-12 18:49:19.994376
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBaseIE = ZDFBaseIE()
    assert zdfBaseIE._GEO_COUNTRIES == ['DE']
    assert zdfBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:49:24.574625
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE', [])
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Unit tests for _call_api

# Generated at 2022-06-12 18:49:29.120654
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:49:32.825748
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    zdf_channel_ie = ZDFChannelIE(url)
    assert zdf_channel_ie.suitable(url)


# Generated at 2022-06-12 18:49:37.973966
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel = ZDFChannelIE()
    assert zdf_channel.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True
    assert zdf_channel.suitable('https://www.zdf.de/filme/taunuskrimi/') == True
    assert zdf_channel.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') == False

# Generated at 2022-06-12 18:49:43.531599
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    cls = globals()['ZDFChannelIE']

    assert cls.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True
    assert cls.suitable('https://www.zdf.de/filme/taunuskrimi') == True
    assert cls.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') == False

# Generated at 2022-06-12 18:49:50.108677
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'ZDF'
    assert ie.ie_key() in ie._ies
    assert ie.ie_key() in [i.ie_key() for i in ie._ies.values()]

# Unit tests for _VALID_URL, _TESTS, _download_webpage, _real_extract
# _extract_player, _extract_regular, _call_api, _extract_ptmd, _extract_format,
# _extract_entry, _extract_mobile, _extract_subtitles

# Generated at 2022-06-12 18:49:52.262322
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    x = ZDFBaseIE()
    assert x._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-12 18:49:58.493092
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import sys
    import unittest
    if sys.version_info < (3, 6):
        raise unittest.SkipTest("since Python 3.6")

    assert ZDFChannelIE('zdfde', 'https://www.zdf.de/sport/das-aktuelle-sportstudio') == ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')



# Generated at 2022-06-12 18:50:01.802003
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Tests that all entries of class ZDFChannelIE are successfully run
    for entry in ZDFChannelIE.__dict__:
        if entry.startswith('_') or not callable(getattr(ZDFChannelIE, entry)):
            continue
        if entry == '__init__':
            continue
        instance = ZDFChannelIE()
        getattr(instance, entry)()

# Generated at 2022-06-12 18:50:51.672509
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf is not None


# Generated at 2022-06-12 18:50:53.906219
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert instance


# Generated at 2022-06-12 18:50:57.022890
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'
    assert ie.GEO_COUNTRIES == ['DE']



# Generated at 2022-06-12 18:51:00.555805
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:51:04.196247
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    Test that arguments are handled correctly in the constructor of class ZDFIE.
    """
    zdfIE = ZDFIE(ZDFIE.ie_key(), ZDFIE._VALID_URL, ZDFIE._TESTS)
    assert zdfIE.ie_key() == ZDFIE.ie_key()
    assert zdfIE._VALID_URL == ZDFIE._VALID_URL
    assert zdfIE._TESTS == ZDFIE._TESTS


# Generated at 2022-06-12 18:51:09.964523
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')
    assert ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html')
    assert not ie.suitable('https://www.phoenix.de/sendungen/ereignisse/corona-nachgehakt/wohin-fuehrt-der-protest-in-der-pandemie-a-2050630.html')

# Generated at 2022-06-12 18:51:12.297448
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    zdfIE.ie_key()
    zdfIE.geo_countries()
    zdfIE._VALID_URL
    zdfIE._TESTS
    zdfIE._extract_player()


# Generated at 2022-06-12 18:51:22.285755
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_ZDFBaseIE_instance = ZDFBaseIE(None)
    assert test_ZDFBaseIE_instance._GEO_COUNTRIES == ['DE']
    assert test_ZDFBaseIE_instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert test_ZDFBaseIE_instance._call_api('https://www.zdf.de/', '4', 'Downloading JSON 4')['config']['attributes']['title'] == 'ZDFheute Startseite - ZDFmediathek'

# Generated at 2022-06-12 18:51:23.772424
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    x = ZDFIE()
    assert x is not None

####################################################################################


# Generated at 2022-06-12 18:51:26.709770
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_baseIE = ZDFBaseIE()
    assert zdf_baseIE is not None
# Unit test ends


# Generated at 2022-06-12 18:53:17.300144
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()


# Generated at 2022-06-12 18:53:28.000487
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    """
    Test for constructor of class ZDFIE.
    """

    # Function is used to test the constructor of class ZDFIE
    # 
    # This is a test for constructor of class ZDFIE or any process before the real extract process
    # 
    # Args:
    #     None
    # 
    # Returns:
    #     None
    # 
    # Raises:
    #     ValueError
    
    
    ####################################################
    #
    # Unit test body
    #
    ####################################################

    # Initialize the test object
    extractor = ZDFIE()

    # Get the test URL

# Generated at 2022-06-12 18:53:29.130927
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    # Tests for method auto_skip_ad
    assert ie._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-12 18:53:32.401139
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_zdf import test_urls as zdf_test_urls
    test_urls = [item[0] for item in zdf_test_urls]
    for url in test_urls:
        if ZDFChannelIE.suitable(url):
            ie = ZDFChannelIE(url)
            if ie.playlist_mincount is not None:
                break



# Generated at 2022-06-12 18:53:34.187822
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE(None)
    except TypeError:
        return True
    return False


# Generated at 2022-06-12 18:53:35.486666
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE().ie_key() == 'ZDF'


# Generated at 2022-06-12 18:53:41.617073
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    config = {"publish-info": "1", "apiToken": "2", "csrfToken": "3"}
    url = "https://www.zdf.de/sport/das-aktuelle-sportstudio"
    ie = ZDFChannelIE(ZDFIE.create_ie_instance(), config)
    result = ie.extract(url)
    assert result["_type"] == "playlist"
    assert result["id"] == "das-aktuelle-sportstudio"


# Generated at 2022-06-12 18:53:43.714621
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        InfoExtractor("test")
    except Exception:
        print("Error,Unit test fail")


# Generated at 2022-06-12 18:53:49.453312
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    ZDFIE._download_webpage(url, 'test', fatal=False)
    ZDFIE._extract_player('', url, fatal=False)
    ZDFIE.test_ZDFIE(url)

test_ZDFIE()


# Generated at 2022-06-12 18:53:51.693914
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie._VALID_URL = ZDFIE._VALID_URL
    ie._TESTS = ZDFIE._TESTS



# Generated at 2022-06-12 18:56:16.959555
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 18:56:20.181977
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:56:21.009887
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-12 18:56:24.756342
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    instance.extract_formats('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html', '151025_magie_farben2_tex')

# Generated at 2022-06-12 18:56:27.338598
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE', 'https://www.zdf.de/')
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:56:31.159481
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:56:38.494656
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_url = 'http://www.zdf.de/ZDFmediathek/beitrag/video/'\
               '2833642/Bericht-aus-Berlin-vom-30.-Dezember-2015#/beitrag/video/2833642/'\
               'Bericht-aus-Berlin-vom-30.-Dezember-2015'

    instance = ZDFBaseIE()
    webpage = instance._download_webpage(test_url, None, note='Download webpage')

    # test whether the methods can be called without error
    instance._extract_player(webpage, None)



# Generated at 2022-06-12 18:56:46.409056
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdf._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert zdf._TESTS[1]['url'] == 'https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html'

# Generated at 2022-06-12 18:56:51.056082
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:56:56.651663
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.__name__ == 'ZDFIE'
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() in ZDFIE.gen_extractors()