

# Generated at 2022-06-12 18:49:24.582041
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(InfoExtractor())._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE(InfoExtractor())._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Unit tests for _call_api of class ZDFBaseIE

# Generated at 2022-06-12 18:49:28.194402
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.IE_NAME == 'ZDF'
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:49:29.486260
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-12 18:49:33.062971
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:49:39.076000
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE(compat_str())
    assert zdfie.IE_NAME == "ZDF"
    assert zdfie.IE_DESC == "Französische TV-Sender"
    assert zdfie.ie_key() == "zdf"
    assert zdfie.QUERY_ENCODING == "utf-8"
    assert zdfie.DEFAULT_FORMAT == "best"
    assert zdfie._GEO_COUNTRIES == ["FR"]
    assert zdfie._QUALITIES == ["sd", "720", "hls"]
    assert zdfie._VALID_URL == r"https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html"

# Generated at 2022-06-12 18:49:43.301869
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie = ZDFChannelIE(url)
    assert url == ie.url
    assert ie.url == ie.parameters['url']

# Generated at 2022-06-12 18:49:44.611315
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    o = ZDFBaseIE()
    assert o is not None



# Generated at 2022-06-12 18:49:46.132074
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-12 18:49:47.520602
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()


# Generated at 2022-06-12 18:49:48.694840
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie


# Generated at 2022-06-12 18:50:17.384379
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'



# Generated at 2022-06-12 18:50:25.383938
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # For test purposes we can use any 'ZDFChannelIE' instance, so let's use
    # the 'planet e' ZDF channel
    test_url = "https://www.zdf.de/dokumentation/planet-e"
    # Construct an instance of 'ZDFChannelIE'
    zdie = ZDFChannelIE()

    # Test if the video URL is suitable for this instance of 'ZDFChannelIE'
    assert zdie.is_suitable_url(test_url) == True

    # Test if the video URL is suitable for this instance of 'ZDFBaseIE'
    assert ZDFBaseIE.is_suitable_url(test_url) == True

    # Test if the video URL is suitable for any instance of 'ZDFBaseIE'
    assert GenericIE.is_suitable_url(test_url) == True

# Generated at 2022-06-12 18:50:28.963419
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_zdfbase = ZDFBaseIE()
    assert test_zdfbase._GEO_COUNTRIES == ['DE']
    assert test_zdfbase._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:50:30.817609
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert isinstance(ie, ZDFBaseIE)



# Generated at 2022-06-12 18:50:32.589633
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj_ZDFBaseIE = ZDFBaseIE()



# Generated at 2022-06-12 18:50:38.509512
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Unit test for constructor
    assert ZDFIE._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html', 'ZDFIE._VALID_URL="%s" is wrong' % ZDFIE._VALID_URL
    assert ZDFIE._TESTS != [], 'ZDFIE._TESTS is empty'
    assert ZDFIE._QUALITIES != (), 'ZDFIE._QUALITIES is empty'

# Generated at 2022-06-12 18:50:40.199019
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('http://www.zdf.de/dokumentation/planet-e')
    assert ZDFChannelIE.suitable('http://www.zdf.de/sport/das-aktuelle-sportstudio')


# Generated at 2022-06-12 18:50:51.112488
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import sys
    import inspect
    import pprint
    # ZDFChannelIE.__init__(cls, name='zdf-channel', ie_key=None, compat_str=None, compat_urllib_parse_urlencode=None, compat_urlparse_parse_qs=None, compat_urllib_parse_unquote=None, compat_urlparse_urlparse=None, compat_urllib_parse_urlparse=None, compat_urllib_parse_urlsplit=None, compat_urllib_parse_urlunsplit=None, compat_urlparse_ParseResult=None, compat_str_types=None, compat_kwargs=None, compat_xpath=None, compat_xpath_text=None, compat_xpath_element=None, compat_b64decode=None)
    cls

# Generated at 2022-06-12 18:50:55.699377
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:50:57.450477
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Just check if calling constructor of ZDFBaseIE works
    ZDFBaseIE()


# Generated at 2022-06-12 18:51:35.495485
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # We can't use fixtures in a unittest, so we copy one of the existing urls.
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    video_id = '210222_phx_nachgehakt_corona_protest'
    zdfIE = ZDFIE({})
    # As expected, there is a web page
    webpage = zdfIE._download_webpage(url, video_id, fatal=False)
    assert webpage
    # As expected, the web page contains a <script> tag with the data-zdfplayer-jsb attribute
    player = zdfIE._extract_player(webpage, video_id, fatal=False)
   

# Generated at 2022-06-12 18:51:36.672597
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE("")
    assert ie is not None


# Generated at 2022-06-12 18:51:44.212562
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class ZDFBaseTestIE(ZDFBaseIE):
        IE_NAME = 'ZDFBaseTest.de'
        _VALID_URL = r'https://www.ZDFBaseTest.test/test_url'

    ie = ZDFBaseTestIE()
    assert ie.identify('https://www.ZDFBaseTest.test/test_url') == True # pylint: disable=comparison-with-callable
    assert ie.ie_key() == 'ZDFBaseTest'



# Generated at 2022-06-12 18:51:49.937872
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    def test(classname):
        classname.suitable('')
    yield test, ZDFChannelIE

_CHANNEL_ID_MAP = {
    '3sat': '3sat',
    'arte': 'arte',
    'zdfinfo': 'zdfinfo',
    'zdfneo': 'zdfneo',
    'phoenix': 'phoenix',
    'kika': 'kika',
    'zdf': 'zdf',
    'one': 'one',
    'zdf_neo': 'zdfneo',
}


# Generated at 2022-06-12 18:51:54.345336
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    with pytest.raises(AssertionError):
        ZDFChannelIE.suitable('https://www.zdf.de/kultur/das-philosophische-quartett/das-philosophische-quartett-der-erste-eindruck-100.html')

# Generated at 2022-06-12 18:51:56.312069
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        ZDFChannelIE(_TEST_CASES, lambda x: x)
    except TypeError:
        pass



# Generated at 2022-06-12 18:52:05.110857
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    i = ZDFChannelIE()
    assert i.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not i.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio.html')
    assert not i.suitable('https://www.zdf.de/dokumentation/planet-e/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert not i.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')



# Generated at 2022-06-12 18:52:06.975864
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # time() returns the time in seconds since the epoch as a floating point
    # number.
    print(ZDFChannelIE()._download_webpage('https://www.zdf.de/dokumentation/planet-e', 'planet-e', '%f' % time()))


# Generated at 2022-06-12 18:52:09.217745
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_in = ZDFIE()
    zdf_out = zdf_in
    assert zdf_in is zdf_out


# Generated at 2022-06-12 18:52:17.427635
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try_get({}, lambda x: x['y']['z'])
    unified_timestamp({})
    qualities(('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))
    orderedSet()
    parse_codecs("")
    update_url_query("", {})
    determine_ext("")
    float_or_none("")
    int_or_none("")
    merge_dicts({}, {})
    url_or_none("")
    urljoin("", "")
    return 'success'

# Generated at 2022-06-12 18:53:26.442943
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test the constructor of ZDFBaseIE."""
    zdf = ZDFBaseIE
    assert zdf._GEO_COUNTRIES == ['DE'], "Incorrect geo countries"
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'), "Incorrect qualities"



# Generated at 2022-06-12 18:53:30.760530
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-12 18:53:36.643432
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # has to be imported here because of circular dependencies
    from . import ZDFIE
    ZDFIE._search_regex('(?s)data-zdfplayer-jsb=(["\'])(?P<json>{.+?})\1', 'https://www.zdf.de/nachrichten/heute/sendung/heute-210120-100.html', 'player JSON', default='{}' if not fatal else NO_DEFAULT, group='json')

# Generated at 2022-06-12 18:53:44.779569
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test on the number of incorrect URLs
    count = 0
    # Test all URLs in ZDFIE
    for test_url in ZDFIE._TESTS:
        # Use the URL as input URL
        url = test_url['url']
        # Check if the URL is suitable to be an input URL to this IE
        if not ZDFChannelIE.suitable(url):
            # If the URL is not suitable, then the constructor should fail
            try:
                # Construct a ZDFChannelIE object with the URL
                ZDFChannelIE(url)
                # If the constructor succeeds, it is an error
                # Increment the number of incorrect URLs
                count += 1
            except:
                # If the constructor fails, it is correct
                pass
    return count


# Generated at 2022-06-12 18:53:47.659314
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    args = {
        "url": "https://www.zdf.de/sport/das-aktuelle-sportstudio",
    }
    assert ZDFChannelIE(**args)



# Generated at 2022-06-12 18:53:55.717820
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Unit test for constructor of class ZDFBaseIE"""
    class TestZDFBaseIE(InfoExtractor):
        _VALID_URL = r'https?://(?:www\.)?zdf\.de/[^/]+/(\d+)'
        IE_NAME = 'zdf:metadata'

# Generated at 2022-06-12 18:54:04.821111
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    id = '210222_phx_nachgehakt_corona_protest'

    ie = ZDFIE()
    ie.extract(url)

    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._TESTS[0]['url'] == url
    assert ie._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'

# Generated at 2022-06-12 18:54:08.665640
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
	print()
	print("Start unit test-case")
	zdfChannelIe = ZDFChannelIE()

	assert zdfChannelIe.ie_key() == "ZDFChannel"
	assert zdfChannelIe.suitable(ZDFChannelIE._VALID_URL)

	testURLs = [
		"https://www.zdf.de/dokumentation/planet-e",
		"https://www.zdf.de/filme/taunuskrimi/"
	]
	for url in testURLs:
		assert ZDFChannelIE.suitable(url)

	print("End unit test-case")


# Generated at 2022-06-12 18:54:11.122502
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test if constructor correctly extracts given video
    youtube_ie = ZDFIE()
    youtube_ie.extract('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    return youtube_ie


# Generated at 2022-06-12 18:54:14.694322
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        from zdf.ZDFChannelIE import ZDFChannelIE
    except ImportError:
        print('To test ZDFChannelIE, you need to install ZDFChannelIE separately')
        print('Run "pip install -e .[test]" in the youtube_dl git checkout directory')
        return

    url = 'https://www.zdf.de/dokumentation/planet-e'
    print('url = ' + url)
    ie = ZDFChannelIE()
    result = ie._real_extract(url)
    print(result)



# Generated at 2022-06-12 18:56:53.823681
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()

# Generated at 2022-06-12 18:56:55.280983
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('%s/dokumentation/planet-e' % ('https://www.zdf.de'))

# Generated at 2022-06-12 18:56:59.114969
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE.ie_key() == 'ZDF'
    assert ZDFBaseIE.ie_key() == 'zdf'
    assert ZDFBaseIE.ie_key() == 'Zdf'
    assert ZDFBaseIE.ie_key() == 'zDF'
    assert ZDFBaseIE.ie_key() == 'ZdF'



# Generated at 2022-06-12 18:57:06.252435
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = "https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html"
    video_id = "151025_magie_farben2_tex"
    webpage = "https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html"
    player = "https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html"

# Generated at 2022-06-12 18:57:07.161347
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    my_ZDFIE = ZDFIE()


# Generated at 2022-06-12 18:57:10.612921
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ''' returns True if the constructor of ZDFBaseIE raises no exceptions '''
    # instantiate object
    yt = ZDFBaseIE();
    return hasattr(yt, '_GEO_COUNTRIES');



# Generated at 2022-06-12 18:57:11.779616
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test if constructor works."""
    ZDFBaseIE()



# Generated at 2022-06-12 18:57:15.375227
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Injecting test values and checking result
    assert test_ZDFChannelIE.__module__ == 'zdf.zdftests'
    ZDFChannelIE._TESTS += [{
        'url': 'https://www.zdf.de/filme/taunuskrimi/',
        'only_matching': True,
    }]
    assert len(ZDFChannelIE._TESTS) == 3



# Generated at 2022-06-12 18:57:22.579674
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test ZDFBaseIE._extract_ptmd
    class TestZDFBaseIE(ZDFBaseIE):
        def _real_extract(self, url):
            video_id = '123'
            player = {'apiToken': 'abc'}
            content = {
                'mainVideoContent': {
                    'http://zdf.de/rels/target': {
                        'http://zdf.de/rels/streams/ptmd-template':
                        'https://example.com/{playerId}/123.json',
                    },
                },
            }
            return self._extract_entry(url, player, content, video_id)

    test_ZDFBaseIE = TestZDFBaseIE()

# Generated at 2022-06-12 18:57:24.082414
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert re.match(r'(?s){"basename":[^}]+}',
                    ZDFBaseIE()._call_api('http://a.b.c/', '', ''))