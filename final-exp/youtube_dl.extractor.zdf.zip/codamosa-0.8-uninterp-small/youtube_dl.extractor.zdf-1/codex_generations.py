

# Generated at 2022-06-26 13:23:54.001074
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert test_case_0() == None

# Generated at 2022-06-26 13:23:55.017996
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e = ZDFChannelIE()

# Generated at 2022-06-26 13:23:57.479421
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e = ZDFIE()
    assert z_d_f_i_e is not None


# Generated at 2022-06-26 13:24:00.321925
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test normal instantiation.
    z_d_f_channel_i_e = ZDFChannelIE()
    # TO-DO: Test another instantiation.
    # Test the subclass of the class.
    assert issubclass(ZDFChannelIE, InfoExtractor)

# Generated at 2022-06-26 13:24:02.378817
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Tested with no parameters
    ZDFIE()


# Generated at 2022-06-26 13:24:03.306524
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_case_0()



# Generated at 2022-06-26 13:24:12.162353
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-26 13:24:13.643339
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_1 = ZDFIE()


# Generated at 2022-06-26 13:24:14.354352
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    pass


# Generated at 2022-06-26 13:24:18.483847
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_obj = ZDFChannelIE()

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-26 13:24:45.505625
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    # The class has been initialized, the test passed
    zdf_ie = None
    return True

# Generated at 2022-06-26 13:24:47.415940
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info_extractor_zdf = ZDFBaseIE()
    assert(info_extractor_zdf)


# Generated at 2022-06-26 13:24:48.893270
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()
    assert zdf.suitable(ZDFChannelIE._VALID_URL)



# Generated at 2022-06-26 13:24:50.124824
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE('zdf').ie_key() == 'ZDF'



# Generated at 2022-06-26 13:24:53.542237
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    expected = object.__new__(ZDFBaseIE)
    instance = ZDFBaseIE()
    assert isinstance(instance, expected.__class__)


# Generated at 2022-06-26 13:25:00.800990
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE = ZDFBaseIE()
    # Testing _call_api function
    assert ZDFBaseIE._call_api('url', 'video_id', 'item', 'token', 'referrer')

    # Testing _extract_subtitles function
    assert ZDFBaseIE._extract_subtitles({})
    assert ZDFBaseIE._extract_subtitles({'captions': None})
    assert ZDFBaseIE._extract_subtitles({'captions': []})
    assert ZDFBaseIE._extract_subtitles({'captions': [{'uri': 'uri'}]})

    # Testing _extract_format function
    ZDFBaseIE = ZDFBaseIE()
    formats = []
    format_urls = set()
    video_id = 'test'

# Generated at 2022-06-26 13:25:02.152172
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert isinstance(ZDFChannelIE(), InfoExtractor)
    assert isinstance(ZDFChannelIE(), ZDFBaseIE)



# Generated at 2022-06-26 13:25:03.300897
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    player = ZDFBaseIE._extract_player('', '123')
    assert player == {}



# Generated at 2022-06-26 13:25:07.766997
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html'
    zdf = ZDFIE()
    assert zdf.ie_key() == 'ZDF'
    assert zdf._VALID_URL == ZDFIE._VALID_URL



# Generated at 2022-06-26 13:25:12.853177
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ie = ZDFBaseIE()
        assert ie.geo_countries == ['DE']
        assert ie.qualities == ['auto', 'low', 'med', 'high', 'veryhigh', 'hd']
    except Exception:
        raise Exception('Unable to initialize ZDFBaseIE')



# Generated at 2022-06-26 13:26:11.322316
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    downloader = YoutubeDL()
    downloader.params = {
        'num_entries': 2,
        'skip_download': True,
    }

    channel_id = 'das-aktuelle-sportstudio'
    channel_url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    expected_entries_id = {
        '210222_phx_nachgehakt_corona_protest',
        '141007_ab18_10wochensommer_film',
    }

    downloader._setup_opener()
    ie = ZDFChannelIE(downloader, {'channel_id': channel_id})
    assert ie._VALID_URL == ZDFChannelIE._VALID_URL
    assert ie._VALID

# Generated at 2022-06-26 13:26:14.748564
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test for site with empty result for search.
    for _ in range(3):
        try:
            ZDFChannelIE().suitable('')
            break
        except ExtractorError:
            pass



# Generated at 2022-06-26 13:26:27.216568
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ydl = YoutubeDL({
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]',
        'outtmpl': '%(extractor)s-%(title)s-%(id)s.%(ext)s',
        'sleep_interval': 5,
        'nooverwrites': True,
        'verbose': True,
    })
    # Test 1
    ydl.params['logger'].debug('\n\n\n\nTest 1\n\n\n\n')
    ydl.params['test'] = True
    ydl._prepare_utils()

# Generated at 2022-06-26 13:26:30.072951
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    channel_id = 'das-aktuelle-sportstudio'
    ZDFChannelIE()._match_id(url) == channel_id
test_ZDFChannelIE()

# Generated at 2022-06-26 13:26:33.416687
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:26:35.871795
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base_ie = ZDFBaseIE('TestName')
    assert base_ie.ie_key() == 'ZDFBase'
    assert base_ie._GEO_COUNTRIES == ['DE']
    assert base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:26:36.875874
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.__name__ == 'ZDFIE'

# Generated at 2022-06-26 13:26:40.545905
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info_extractor = ZDFBaseIE()
    assert info_extractor is not None

test_ZDFBaseIE()



# Generated at 2022-06-26 13:26:43.055011
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._to_extractors() == [ZDFIE]
    assert ZDFIE.ie_key() == 'zdf'
# End of unit test for constructor of class ZDFIE



# Generated at 2022-06-26 13:26:50.004301
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    if os.environ.get('TRAVIS') == 'true':
        pytest.skip(
            'I am uncertain how to reproduce the test failure, '
            'so let us skip this test temporarily')
    if os.environ.get('TRAVIS_PYTHON_VERSION') == 'pypy':
        pytest.skip('PyPy\'s JSON module is too slow to work through the test')
    from .. import ZDFChannelIE
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/')
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e?foo=bar')

# Generated at 2022-06-26 13:28:37.089668
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
# end of test_ZDFBaseIE


# Generated at 2022-06-26 13:28:47.553260
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-26 13:28:52.857852
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.extract('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')

test_ZDFIE()



# Generated at 2022-06-26 13:29:01.903975
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ies = (cls for cls in globals().values() if isinstance(cls, type) and issubclass(cls, ZDFBaseIE))
    ie_choosen = next(ies)
    print('ZDFChannel:', ie_choosen)
    assert ie_choosen.suitable(url)
    assert ie_choosen is ZDFChannelIE
    print('ZDFChannel:', ie_choosen.ie_key())
    assert ie_choosen.ie_key() == 'zdf:channel'
    ie = ie_choosen(url)
    assert ie.suitable(url)
    assert ie.ie_key() == 'zdf:channel'
    # Test extracted playlist
    playlist = ie.extract

# Generated at 2022-06-26 13:29:07.569883
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    import unittest
    class TestZDFIE(unittest.TestCase):
        def test_ZDFIE(self):
            ie = ZDFIE('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
            self.assertTrue(ie._VALID_URL.match('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'))

# Generated at 2022-06-26 13:29:10.064371
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ZDFChannelIE(url)


# Generated at 2022-06-26 13:29:19.444744
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()

# Generated at 2022-06-26 13:29:22.914708
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = "https://www.zdf.de/politik/frontal-21/meinungsfreiheit-im-internet-100.html"
    test_object = ZDFIE()
    result = test_object._extract_player(ZDFIE._download_webpage(url, "test"), url)
    print(result)
    assert(result != None)



# Generated at 2022-06-26 13:29:27.064415
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Simple unit test for constructor of class ZDFChannelIE."""
    zdf_channel_ie = ZDFChannelIE("https://www.zdf.de/filme/taunuskrimi/")
    assert zdf_channel_ie.suitable("https://www.zdf.de/filme/taunuskrimi/") == False



# Generated at 2022-06-26 13:29:29.773309
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'