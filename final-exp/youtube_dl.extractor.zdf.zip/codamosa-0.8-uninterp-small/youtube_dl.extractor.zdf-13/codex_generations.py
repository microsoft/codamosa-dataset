

# Generated at 2022-06-26 13:23:49.608311
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-26 13:23:52.812707
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    print("%s" % ZDFBaseIE)

# Generated at 2022-06-26 13:23:54.304591
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_extractor = ZDFIE()


# Generated at 2022-06-26 13:23:56.138329
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-26 13:23:57.960693
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert True


# Generated at 2022-06-26 13:23:59.309748
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    if __name__ == '__main__':
        import unittest
        unittest.main()

# Generated at 2022-06-26 13:24:00.718051
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()


# Generated at 2022-06-26 13:24:02.626042
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE()._VALID_URL=='https?://www.zdf.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 13:24:04.141525
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zd = ZDFIE()

# Generated at 2022-06-26 13:24:06.895958
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_const = ZDFIE('ZDF', ['DE'], ['auto', 'low', 'med', 'high', 'veryhigh', 'hd'])


# Generated at 2022-06-26 13:24:35.310549
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .. import ZDFBaseIE

    inst = ZDFBaseIE()

    assert inst._GEO_COUNTRIES == ['DE']
    assert inst._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:24:42.661340
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import _TEST_URL
    from .zdf import ZDFIE
    from .zdf_mediathek import ZDFMediathekIE
    for test_url, ie_result in [
            (ZDFIE._TESTS[0]['url'], ZDFIE),
            (ZDFMediathekIE._TESTS[0]['url'], ZDFMediathekIE),
            (_TEST_URL, None),
    ]:
        assert isinstance(ZDFChannelIE.get_ie(test_url)()._downloader, ie_result)



# Generated at 2022-06-26 13:24:45.969796
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test for channel url https://www.zdf.de/dokumentation/planet-e
    url = 'https://www.zdf.de/dokumentation/planet-e'
    assert ZDFChannelIE._TESTS[1]['url'] == url
    assert ZDFChannelIE(url) is not None



# Generated at 2022-06-26 13:24:51.516829
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')

# Generated at 2022-06-26 13:24:55.469195
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    i = ZDFBaseIE()
    assert isinstance(i, InfoExtractor)
    assert i._GEO_COUNTRIES == ['DE']
    assert i._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-26 13:24:58.647433
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Tests for ZDFBaseIE
    # Code for constructor of class ZDFBaseIE
    ZDFBaseIE._GEO_COUNTRIES = ['DE']
    ZDFBaseIE._QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:25:00.818960
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:25:02.367962
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert channel.id == 'planet-e'


# Generated at 2022-06-26 13:25:03.798779
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-26 13:25:07.154176
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:26:04.608848
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # url = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    url = 'https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html'
    # video_id = '210222_phx_nachgehakt_corona_protest'
    video_id = '141007_ab18_10wochensommer_film'

    print(ZDFIE()._real_extract(url))


# Generated at 2022-06-26 13:26:07.497512
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._TESTS[0]['md5'] == ie.ie_key()



# Generated at 2022-06-26 13:26:08.290533
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_ZDFIE = ZDFIE()

# Generated at 2022-06-26 13:26:10.344632
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base_url = 'https://www.zdf.de/'
    zdfbase_test = ZDFBaseIE(base_url)
    assert zdfbase_test._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-26 13:26:21.865533
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    zdfChannelIE = ZDFChannelIE()
    assert zdfChannelIE._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert zdfChannelIE.suitable(url) == True
    assert zdfChannelIE.ie_key() == 'ZDFChannel'
    assert zdfChannelIE._match_id(url) == 'das-aktuelle-sportstudio'
    assert zdfChannelIE._real_extract(url) != None



# Generated at 2022-06-26 13:26:30.656206
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info_extractor = ZDFBaseIE()
# Assert false because there's no constructor in ZDFBaseIE
    assert info_extractor._GEO_COUNTRIES is None, 'check that _GEO_COUNTRIES is None'
    assert info_extractor._QUALITIES is None, 'check that _QUALITIES is None'
    assert info_extractor._call_api() is None, 'check that _call_api() returns None'
    assert info_extractor._extract_subtitles() is None, 'check that _extract_subtitles() returns None'
    assert info_extractor._extract_format() is None, 'check that _extract_format() returns None'
    assert info_extractor._extract_ptmd() is None, 'check that _extract_ptmd() returns None'


# Generated at 2022-06-26 13:26:32.331596
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannelIE = ZDFChannelIE()
    zdfchannelIE.suitable("https://www.zdf.de/filme/taunuskrimi/")


# Generated at 2022-06-26 13:26:34.975056
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .test_zdf import TestZDFIE
    instance = TestZDFIE()
    assert isinstance(instance, ZDFBaseIE)
    # Call inherited class (test_zdf) method
    instance.test_extract_series()


# Generated at 2022-06-26 13:26:36.216135
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ied = ZDFIE()
    assert ied.ie_key() == 'ZDF'


# Generated at 2022-06-26 13:26:36.877568
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()


# Generated at 2022-06-26 13:28:31.145966
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbase_ie = ZDFBaseIE()
    assert zdfbase_ie._GEO_COUNTRIES == ['DE']
    assert zdfbase_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:28:35.711121
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannel = ZDFChannelIE('https://www.zdf.de/dokumentation/planet-e')
    assert zdfchannel.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not zdfchannel.suitable('https://www.zdf.de/dokumentation/planet-e/video-100.html')


# Generated at 2022-06-26 13:28:39.010196
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    import unittest
    class TestZDFIE(unittest.TestCase):
        def test_simple(self):
            objZDFIE = ZDFIE()
            self.assertIsNot(None, objZDFIE)
    unittest.main()

if __name__ == '__main__':
    test_ZDFIE()

# Generated at 2022-06-26 13:28:40.423549
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf is not None


# Generated at 2022-06-26 13:28:51.898492
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import zdf as zdf_mod
    from . import test_utils as test_utils_mod

    ChannelIE = zdf_mod.ZDFChannelIE.__class__


# Generated at 2022-06-26 13:28:55.855031
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:28:57.425914
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
    except:
        return False
    return True


# Generated at 2022-06-26 13:29:01.618456
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    result = ie._GEO_COUNTRIES
    assert(result == ['DE'])
    result = ie._QUALITIES
    assert(result == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-26 13:29:04.519469
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE(ZDFChannelIE.ie_key(), ZDFChannelIE._VALID_URL)
    assert ie._VALID_URL == ZDFChannelIE._VALID_URL
    assert ie.ie_key() == ZDFChannelIE.ie_key()
    assert ie.suitable(ZDFChannelIE._VALID_URL)
    assert not ie.suitable(ZDFIE._VALID_URL)
    assert ie._TESTS == ZDFChannelIE._TESTS


# Generated at 2022-06-26 13:29:08.030175
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdfie.ie_key() == 'ZDF'


# Generated at 2022-06-26 13:33:04.747933
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
    except TypeError:
        pass
    else:
        if __name__ == '__main__':
            exit(3)
    if __name__ == '__main__':
        exit(1)



# Generated at 2022-06-26 13:33:09.221411
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base = ZDFBaseIE()
    assert base._GEO_COUNTRIES == ['DE']
    assert base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

