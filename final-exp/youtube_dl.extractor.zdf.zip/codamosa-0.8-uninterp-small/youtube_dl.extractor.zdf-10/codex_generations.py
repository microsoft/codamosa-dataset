

# Generated at 2022-06-26 13:23:49.803505
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

if __name__ == '__main__':
    test_case_0()
    test_ZDFIE()

# Generated at 2022-06-26 13:23:51.426755
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 13:23:53.413970
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()


# Generated at 2022-06-26 13:23:55.020479
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert not hasattr(ZDFBaseIE, '_download_webpage_handle')


# Generated at 2022-06-26 13:24:02.848112
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    content = {
        "http://zdf.de/rels/target": {
            "http://zdf.de/rels/streams/ptmd": "https://cdn-storage.br.de/zdf/ptmd/15/04/150406_ab18_preisderjugend_doku_starker_f/150406_ab18_preisderjugend_doku_starker_f.xml",
            "http://zdf.de/rels/streams/ptmd-template": "https://cdn-storage.br.de/zdf/ptmd/{playerId}/{year}/{basename}/{basename}.xml",
            "duration": "2660"
        }
    }


# Generated at 2022-06-26 13:24:04.009074
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()


# Generated at 2022-06-26 13:24:04.972985
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    return ZDFBaseIE


# Generated at 2022-06-26 13:24:06.171329
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e = ZDFChannelIE()


# Generated at 2022-06-26 13:24:08.076057
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    z_d_f_channel_i_e_0 = ZDFChannelIE(url)


# Generated at 2022-06-26 13:24:09.668775
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e = ZDFBaseIE()


# Generated at 2022-06-26 13:24:35.003764
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(None)


# Generated at 2022-06-26 13:24:36.441891
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie


# Generated at 2022-06-26 13:24:36.919118
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE() is not None



# Generated at 2022-06-26 13:24:40.011672
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    zdf.suitable(None)
    zdf.get_url()
    zdf.set_cookie()
    zdf.set_handle()


# Generated at 2022-06-26 13:24:42.289231
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert isinstance(ie, ZDFChannelIE)
    assert ie.suitable(ZDFChannelIE._VALID_URL)

# Generated at 2022-06-26 13:24:44.345771
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ZDFChannelIE(ZDFChannelIE.suitable, url)

# Generated at 2022-06-26 13:24:50.324828
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    web_page = download_webpage(url, 'zdf_channel')
    video_id = 'das-aktuelle-sportstudio'
    player = ZDFChannelIE()._extract_player(web_page, video_id)
    channel_id = ZDFChannelIE()._search_regex(r'docId\s*:\s*(["\'])(?P<id>(?!\1).+?)\1', web_page, 'channel id', group='id')
    channel = ZDFChannelIE()._call_api('https://api.zdf.de/content/documents/%s.json' % channel_id, player, url, channel_id)

# Generated at 2022-06-26 13:24:58.276713
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.suitable('https://www.zdf.de/nachrichten/heute-journal/viele-staedte-schotten-sich-vor-corona-100.html') == False
    assert ie.suitable('https://www.zdf.de/kinder/logo/logo-maskottchen-100.html') == False
    assert ie.suitable('https://www.zdf.de/kinder/logo/logo-maskottchen-100.json') == False
    assert ie.suitable('https://www.zdf.de/kinder/logo/logo-maskottchen-100.xml') == False
# End of program

# Generated at 2022-06-26 13:25:01.095846
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()
    assert isinstance(instance.geo_countries, orderedSet)
    assert instance.geo_countries == ZDFBaseIE._GEO_COUNTRIES
    assert isinstance(instance._QUALITIES, tuple)
    assert instance._QUALITIES == ZDFBaseIE._QUALITIES



# Generated at 2022-06-26 13:25:03.139271
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from zdfdl.downloader import ZDFDL
    from zdfdl.extractor import ZDFDLIE
    for entry in [ZDFDL, ZDFDLIE]:
        assert entry.ie_key() in entry.ie_key_map

# Generated at 2022-06-26 13:25:55.509156
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert NO_DEFAULT is not None

# Generated at 2022-06-26 13:26:00.342804
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_IE = ZDFBaseIE()
    assert zdf_base_IE._GEO_COUNTRIES == ['DE']
    assert zdf_base_IE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:26:03.248162
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'


# Generated at 2022-06-26 13:26:11.444505
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('www.zdf.de', 'www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'

# Generated at 2022-06-26 13:26:15.145925
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-26 13:26:27.550870
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import io
    import json
    from .common import BaseIE
    from ..utils import ExtractorError

    url = 'http://www.zdf.de/ZDFmediathek/beitrag/video/2237806'
    Class = ZDFBaseIE
    ie_inst = Class()

    # Test 1:
    # Check if we can load a webpage and that are able to parse the player
    # json data. Assert that that player json data is well formatted json
    # and that the returned data is a dict.
    data = ie_inst._download_webpage_handle(url)
    player_data = ie_inst._extract_player(data, '2237806')
    assert(isinstance(player_data, dict))

    # Test 2:
    # Check if the player data has required attributes

# Generated at 2022-06-26 13:26:29.007024
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass
    # TODO How to test the constructor?
# test_ZDFBaseIE()



# Generated at 2022-06-26 13:26:35.038784
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.video_id = '151025_magie_farben2_tex'
    ie._download_webpage = lambda url: ''
    ie._extract_player = lambda webpage, video_id, fatal: {
        'content': 'https://m.zdf.de/api/m/{}/{}'.format(ie.video_id, 'content'),
        'apiToken': 'a34d0a5a-1f53-4a5f-9c37-7e30aa734500'
    }

# Generated at 2022-06-26 13:26:36.279122
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')


# Generated at 2022-06-26 13:26:37.052272
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE.ie_key()


# Generated at 2022-06-26 13:28:34.453007
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    g = globals()
    g.update(locals())
    ie = ZDFChannelIE()
    ie._VALID_URL = ie.VALID_URL
    ie._download_webpage = lambda *args: g['webpage']
    ie.suitable = lambda *args: True
    ie._extract_player = lambda *args: g['player']
    ie._call_api = lambda *args: g['channel']
    ie._search_regex = lambda *args: g['channel_id']
    ie._real_extract()

    # Test with named groups in _VALID_URL
    ie = ZDFChannelIE()
    ie._VALID_URL = ie.VALID_URL
    ie._download_webpage = lambda *args: g['webpage']
    ie.suitable = lambda *args: True
   

# Generated at 2022-06-26 13:28:45.316971
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print(ZDFChannelIE.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'))
    print(ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'))
    print(ZDFChannelIE.suitable('https://www.zdf.de/wissen/nano/nano-vom-31-01-2020-102.html'))
    print(ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e'))

# Generated at 2022-06-26 13:28:56.534028
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    # Test for _GEO_COUNTRIES
    assert ie._GEO_COUNTRIES == ['DE']
    # Test for _QUALITIES
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    # Test for _call_api method
    # TODO: complete this unit test
    # Test for _extract_subtitles method
    # TODO: complete this unit test
    # Test for _extract_format method
    # TODO: complete this unit test
    # Test for _extract_ptmd method
    # TODO: complete this unit test
    # Test for _extract_player method
    # TODO: complete this unit test


# Generated at 2022-06-26 13:28:58.518996
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class_ = globals()['ZDFChannelIE']
    base_test(test_ZDFChannelIE, class_)


# Generated at 2022-06-26 13:29:00.407403
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    return ZDFBaseIE('ZDFBaseIE', 'zdf.de').test()



# Generated at 2022-06-26 13:29:06.416209
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()

# Generated at 2022-06-26 13:29:11.034726
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')



# Generated at 2022-06-26 13:29:15.104000
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    cls = ZDFChannelIE
    cls.suitable(ZDFIE.ie_key())
    assert cls.suitable(None)
    #assert cls.suitable(ZDFChannelIE)
    assert not cls.suitable(ZDFIE)
    return True


# Generated at 2022-06-26 13:29:19.859099
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html'
    zdfIE = ZDFIE()
    zdfIE.set_request_webpage() # mock request_webpage
    zdfIE.set_request_json_url() # mock request_json_url
    zdfIE.extract(url)



# Generated at 2022-06-26 13:29:20.757749
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()
