

# Generated at 2022-06-26 13:23:53.903894
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE()


# Generated at 2022-06-26 13:23:55.672567
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:23:58.598280
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # assert statement 1
    zdfchannelie = ZDFChannelIE()
    assert zdfchannelie is not None


# Generated at 2022-06-26 13:24:04.701890
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Build a dictionary for the function ZDFChannelIE._real_extract
    url = "https://www.zdf.de/dokumentation/planet-e"
    webpage = "ZDFChannelIE webpage"
    channel_id = "dokumentation/planet-e"
    player = "ZDFChannelIE player"
    channel = "ZDFChannelIE channel"
    module = "ZDFChannelIE module"
    teaser = "ZDFChannelIE teaser"
    t = "ZDFChannelIE t"
    sharing_url = "ZDFChannelIE sharing_url"
    resultsWithVideo = "ZDFChannelIE resultsWithVideo"
    filterRef = "ZDFChannelIE filterRef"
    web_page_dict = {'web_page': webpage}
    channel_id_dict = {'channel_id': channel_id}

# Generated at 2022-06-26 13:24:06.042190
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:24:17.791091
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():

    # assert check
    assert z_d_f_channel_i_e_0.url == 'https://www.zdf.de/sport/das-aktuelle-sportstudio', "Expected different attribute"
    assert z_d_f_channel_i_e_0._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\n', "Expected different attribute"
    assert z_d_f_channel_i_e_0.IE_DESC == 'ZDF', "Expected different attribute"
    assert z_d_f_channel_i_e_0.IE_NAME == 'ZDF', "Expected different attribute"
    assert z_d_f_channel_i_e_0.SUITABLE_

# Generated at 2022-06-26 13:24:29.998176
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()
    assert(z_d_f_channel_i_e_0.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')==True)
    assert(z_d_f_channel_i_e_0.suitable('https://www.zdf.de/dokumentation/planet-e/')==False)
    assert(z_d_f_channel_i_e_0.suitable('https://www.zdf.de/filme/taunuskrimi/')==False)
    assert(z_d_f_channel_i_e_0.suitable('https://www.zdf.de/dokumentation/planet-e')==False)
   

# Generated at 2022-06-26 13:24:31.374904
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_channel_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:24:32.381283
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    pass



# Generated at 2022-06-26 13:24:42.702810
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-26 13:25:10.276950
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-26 13:25:11.526381
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-26 13:25:15.583177
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    video = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    ZDFIE()._real_extract(video)



# Generated at 2022-06-26 13:25:22.035488
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test the constructor of class ZDFChannelIE
    #
    # Test case #1: Pass a valid URL to the constructor of class ZDFChannelIE
    #
    # Expectation: The object for class ZDFChannelIE created successfully.
    assert ZDFChannelIE(ZDFChannelIE._create_generic_ie(ZDFChannelIE.ie_key()), 'https://www.zdf.de/sport/das-aktuelle-sportstudio')


# Generated at 2022-06-26 13:25:28.076145
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """
    This function tests the constructor of the class ZDFBaseIE
    """

    zdf_base_ie = ZDFBaseIE(ZDFBaseIE.ie_key())
    assert isinstance(zdf_base_ie, ZDFBaseIE)
    assert zdf_base_ie.queries == {}
    assert zdf_base_ie.geo_countries == ['DE']
    assert zdf_base_ie.qualities == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-26 13:25:30.301984
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE(None)
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:25:35.722624
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    zdfie.has_geo_restriction
    zdfie.geo_countries
    assert(zdfie._GEO_COUNTRIES == ['DE'])
    assert(zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html')
    assert(zdfie.IE_DESC == 'ZDF')
    assert(zdfie.IE_NAME == 'zdf')

# Generated at 2022-06-26 13:25:36.470273
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()
    ZDFBaseIE()

########################################################################


# Generated at 2022-06-26 13:25:39.521543
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
    except:
        assert False, 'Instatiation of ZDFBaseIE failed.'


# Generated at 2022-06-26 13:25:43.960855
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    #check whether the new constructor is capable
    # of creating the same object as the old constructor would.
    def test_old_constructor(url):
        print("Testing old constructor ...")
        try:
            old_constructor = ZDFChannelIE(url)
        except Exception as e:
            print("Old constructor failed ...")
            print(e)
            assert(0)
        return old_constructor.playlist_result(
            old_constructor._entries, old_constructor._channel_id,
            old_constructor._channel_title)

    def test_new_constructor(url):
        print("Testing new constructor ...")
        try:
            new_constructor = ZDFChannelIE.url_result(url)
        except Exception as e:
            print("New constructor failed ...")
            print(e)


# Generated at 2022-06-26 13:26:38.516860
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Create class object
    instance = ZDFChannelIE()

    assert instance.ie_key() == "ZDFChannelIE"
    assert instance.IE_NAME == "zdf.de:channels"
    assert instance.IE_DESC == "zdf.de channels"
    assert instance.mobj is instance._VALID_URL_RE.search
    assert instance.valid_url('https://www.zdf.de/sport/das-aktuelle-sportstudio') is True
    assert instance.valid_url('https://www.zdf.de/sport/das-aktuelle-sportstudio.html') is False

# Generated at 2022-06-26 13:26:43.711733
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE('test')
    assert zdf_base._GEO_COUNTRIES == ['DE']
    assert zdf_base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-26 13:26:50.756428
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Without a mocker I had no idea to decouple
    # the interaction with the network from the testing process.
    zdfchannel_ie = ZDFChannelIE()
    zdfchannel_ie.downloader = object()
    zdfchannel_ie.dl = object()

    # We need to mock the _download_webpage method
    test_url = 'https://www.zdf.de/dokumentation/planet-e'
    with patch('youtube_dl.utils.webpage.extractor.ZDFChannelIE._download_webpage') as mock_download_webpage:
        with open(os.path.join(os.path.dirname(__file__), 'test_data', 'zdfchannels.html')) as mock_webpage:
            mock_download_webpage.return_value = mock_webpage.read

# Generated at 2022-06-26 13:26:55.514404
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE(None)
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:26:58.869405
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    "Make sure ZDFChannelIE object is created and instantiated"
    url = 'https://www.zdf.de/dokumentation/planet-e'
    a = ZDFChannelIE(url)
    assert a != None
    assert a.suitable(url)
    assert a.url_result(url, ie=ZDFChannelIE.ie_key())['url'] == url


# Generated at 2022-06-26 13:27:03.548797
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z = ZDFBaseIE(ZDFBaseIE.ie_key())
    assert z.ie_key() == 'zdf'
    assert z.GEO_COUNTRIES == ['DE']
    assert z.QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-26 13:27:04.524820
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

####################################################################################################

# Generated at 2022-06-26 13:27:08.001773
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    url = 'http://www.zdf.de/ZDFmediathek/hauptnavigation/startseite?flash=off'
    webpage = ie.download_webpage(url)
    ie._extract_player(webpage, 'theplayerjsb')


# Generated at 2022-06-26 13:27:16.619432
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    fields = ['_GEO_COUNTRIES', '_QUALITIES', '_call_api']
    for field in fields:
        assert getattr(zdf_base_ie, field) is not None
    assert zdf_base_ie._extract_subtitles(None) == {}
    assert zdf_base_ie._extract_player(None, 'test123') == {}



# Generated at 2022-06-26 13:27:21.317277
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie = ZDFChannelIE()
    ie.suitable(url)
    _ = ie._real_extract(url)



# Generated at 2022-06-26 13:29:22.738665
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-26 13:29:30.264423
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # when use non-ZDFBaseIE class
    zdf_base_ie = ZDFBaseIE('ZDF')
    assert zdf_base_ie._GEO_COUNTRIES == ['DE']
    assert zdf_base_ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert zdf_base_ie._call_api('http://zdf.de/api/', '1234', 'player', api_token='1234') == \
        ('http://zdf.de/api/', '1234', 'player', {'Api-Auth': 'Bearer 1234'}, None)
    subtitle = {'url': 'http://zdf.de/video/1234', 'language': 'deu'}

# Generated at 2022-06-26 13:29:34.324777
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test
    zdfbase = ZDFBaseIE()

    # Test
    assert zdfbase._GEO_COUNTRIES == ['DE']

    # Test
    assert zdfbase._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:29:35.970120
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE(None)
    assert zdfie != None


# Generated at 2022-06-26 13:29:37.774174
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.get_name() == "zdf"


# Generated at 2022-06-26 13:29:46.619128
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from io import BytesIO
    from json import loads
    from urllib.parse import urlencode

    class Response:
        def __init__(self, content):
            self.content = BytesIO(content)
            self.headers = {
                'Content-Type': 'application/json',
                'Content-Length': len(content)
            }

        def read(self):
            return self.content.read()

    url = 'https://www.zdf.de/dokumentation/planet-e'
    webpage = load_webpage(
        url, 'get', response=Response(b'{ "contentListPage": { "items": [] } }'))
    player = ZDFBaseIE._extract_player(webpage, url)
    channel_id = 'planet-e'


# Generated at 2022-06-26 13:29:50.223710
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'


# Generated at 2022-06-26 13:29:50.893167
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()



# Generated at 2022-06-26 13:29:51.587326
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-26 13:29:55.539224
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/100.html')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html')

