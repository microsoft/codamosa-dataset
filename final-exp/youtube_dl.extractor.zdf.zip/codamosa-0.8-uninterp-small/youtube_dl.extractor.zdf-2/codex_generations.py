

# Generated at 2022-06-26 13:23:52.792922
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:23:53.813442
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert issubclass(ZDFChannelIE, InfoExtractor)


# Generated at 2022-06-26 13:23:56.017436
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # This test case will try to build ZDFChannelIE with a unvalid string.
    try:
        temp_obj = ZDFChannelIE('Not Valid URL')
        assert(False)
    except AttributeError:
        assert(True)


# Generated at 2022-06-26 13:23:58.161904
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()

# Unit tests for methods of class ZDFBaseIE

# Generated at 2022-06-26 13:23:59.887378
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """ Unit test for constructor of class ZDFBaseIE """
    z_d_f_base_i_e_0 = ZDFBaseIE()



# Generated at 2022-06-26 13:24:02.203569
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:24:03.663752
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_1 = ZDFIE()


# Generated at 2022-06-26 13:24:04.531831
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert type(ZDFChannelIE()) == ZDFChannelIE


# Generated at 2022-06-26 13:24:08.964355
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Run
    z_d_f_base_i_e_0 = ZDFBaseIE()
    assert z_d_f_base_i_e_0._GEO_COUNTRIES.__len__() > 0
    assert z_d_f_base_i_e_0._QUALITIES.__len__() > 0


# Generated at 2022-06-26 13:24:10.199240
# Unit test for constructor of class ZDFIE
def test_ZDFIE():

    # Unit test with an instance of ZDFIE
    ZDFIE()



# Generated at 2022-06-26 13:24:55.918110
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert len(ZDFBaseIE._GEO_COUNTRIES) == 1
    assert len(ZDFBaseIE._QUALITIES) == 6


# Generated at 2022-06-26 13:24:57.162106
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:24:58.485439
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test the constructor
    z_d_f_channel_i_e_1 = ZDFChannelIE()


# Generated at 2022-06-26 13:24:59.187456
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()



# Generated at 2022-06-26 13:25:00.615519
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFIE()
    except NameError:
        assert False
    else:
        assert True


# Generated at 2022-06-26 13:25:01.669314
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()
    assert isinstance(zdf, ZDFChannelIE)


# Generated at 2022-06-26 13:25:02.851158
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL) == True


# Generated at 2022-06-26 13:25:03.761151
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-26 13:25:05.125524
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # test_ZDFBaseIE(self)
    assert True


# Generated at 2022-06-26 13:25:16.002645
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert_equal(ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'), True)
    assert_equal(ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e'), True)
    assert_equal(ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/'), True)
    assert_equal(ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'), False)

# Generated at 2022-06-26 13:26:05.055804
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()


# Generated at 2022-06-26 13:26:06.398860
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()


# Generated at 2022-06-26 13:26:08.102842
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert isinstance(ie, ZDFChannelIE), ie

# Generated at 2022-06-26 13:26:09.386570
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # pylint: disable=unused-variable
    ie = ZDFChannelIE(None)
    pass


# Generated at 2022-06-26 13:26:10.221447
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-26 13:26:23.492628
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zie = ZDFIE()
    assert zie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-26 13:26:31.482501
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('www.zdf.de')
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-26 13:26:32.692552
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE.ie_key() == 'ZDF'



# Generated at 2022-06-26 13:26:34.867785
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    obj = ZDFChannelIE()
    assert obj.suitable(url)
    obj._real_extract(url)
    return True


# Generated at 2022-06-26 13:26:41.095417
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    webpage = open(os.path.join(
        os.path.dirname(__file__), 'test', 'test.html')).read().encode('utf-8')

    channel_id = re.search(
        r'docId\s*:\s*(["\'])(?P<id>(?!\1).+?)\1', webpage,
        group='id').group('id')

    channel = ZDFChannelIE._call_api(
        'https://api.zdf.de/content/documents/%s.json' % channel_id,
        ZDFChannelIE._extract_player(webpage, None), None, channel_id)

    channel_title = channel.get('title')

    items = []

# Generated at 2022-06-26 13:28:33.089653
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Tests with a simple content
    test_object = ZDFChannelIE.suitable('https://www.zdf.de/')
    _assert_true(test_object)

    test_object = ZDFChannelIE.suitable('https://www.3sat.de/')
    _assert_true(test_object)

    test_object = ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e/')
    _assert_true(test_object)

    test_object = ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    _assert_true(test_object)

    # Tests on a ZDFIE video

# Generated at 2022-06-26 13:28:33.725640
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(InfoExtractor())


# Generated at 2022-06-26 13:28:43.987795
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE()
    obj = ie._real_extract(url)
    # Note that this is an instance of ZDFChannelIE
    assert isinstance(obj, Playlist)
    assert obj.channel_id == 'planet-e'
    assert len(obj.entries) == 50
    obj = obj.entries[0]
    # Note that this is an instance of ZDFIE
    assert obj.ie_key() == 'ZDF'
    obj = obj.entries[0]
    assert obj.id == 'Sekunden-bis-zum-Untergang-1'
    assert obj.title == 'Sekunden bis zum Untergang (1)'

# Generated at 2022-06-26 13:28:47.173315
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE.__name__ == 'ZDFBaseIE'
    instance = ZDFBaseIE()
    assert instance.__class__.__name__ == 'ZDFBaseIE'



# Generated at 2022-06-26 13:28:58.606056
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('https://www.zdf.de/filme/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert ie

# Check if the downloaded video has title and description
import os.path
from xml.etree.ElementTree import fromstring
path = os.path.realpath(__file__)
path = os.path.split(path)[0]
with open(os.path.join(path, 'Terra_X_-_Die_Magie_der_Farben_2.mp4'), 'rb') as f:
    tree = fromstring(f.read())

# Generated at 2022-06-26 13:29:05.786466
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('zdf_player')
# Test video: https://www.zdf.de/kinder/logo/wer-ist-wer-im-blickpunkt-100.html
    assert ie.extractor_key == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.http_headers['User-Agent'] == 'zdf-main-player/1.0.0'
    assert ie.http_headers['Accept'] == 'application/json, text/plain, */*'


# Generated at 2022-06-26 13:29:17.311759
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    test = ZDFChannelIE()
    assert test.suitable('https://zdf.de/filme/taunuskrimi')
    assert not test.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')
    assert not test.suitable('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html')
    assert not test.suitable('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')

# Generated at 2022-06-26 13:29:18.909369
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie
    assert ie._VALID_URL
    assert ie._TESTS


# Generated at 2022-06-26 13:29:27.754582
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test to make sure that items are not listed more than once
    url = 'https://www.zdf.de/filme/taunuskrimi'
    zdf_channel_ie = ZDFChannelIE()
    webpage = zdf_channel_ie._download_webpage(url, 'Taunuskrimi')
    channel_id = zdf_channel_ie._match_id(url)
    player = zdf_channel_ie._extract_player(webpage, channel_id)
    channel = zdf_channel_ie._call_api(
        'https://api.zdf.de/content/documents/%s.json' % channel_id,
        player, url, channel_id)
    items = []

# Generated at 2022-06-26 13:29:34.155605
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instZDFIE = ZDFIE('test_ZDFIE', 'http://www.zdf.de/test-url', {}, {})
    assert isinstance(instZDFIE, ZDFIE)
    assert isinstance(instZDFIE, InfoExtractor)
    assert instZDFIE.ie_key() == 'ZDF'
    assert instZDFIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
