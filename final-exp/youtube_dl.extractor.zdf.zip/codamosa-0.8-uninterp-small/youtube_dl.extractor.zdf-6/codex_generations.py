

# Generated at 2022-06-26 13:23:53.848838
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    class_z_d_f_channel_i_e = ZDFChannelIE()


# Generated at 2022-06-26 13:23:57.311374
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    with pytest.raises(Exception):
        z_d_f_i_e = ZDFIE('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')


# Generated at 2022-06-26 13:24:03.458304
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert callable(getattr(ZDFBaseIE, '_GEO_COUNTRIES', None))
    assert callable(getattr(ZDFBaseIE, '_QUALITIES', None))
    assert callable(getattr(ZDFBaseIE, '_call_api', None))
    assert callable(getattr(ZDFBaseIE, '_extract_subtitles', None))
    assert callable(getattr(ZDFBaseIE, '_extract_format', None))
    assert callable(getattr(ZDFBaseIE, '_extract_ptmd', None))
    assert callable(getattr(ZDFBaseIE, '_extract_player', None))

# Peformance test for _call_api

# Generated at 2022-06-26 13:24:04.341675
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_object = ZDFIE()
    pass



# Generated at 2022-06-26 13:24:06.043019
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:24:07.617974
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:24:08.625611
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert test_case_0() == 'test case 0'

# Generated at 2022-06-26 13:24:10.945559
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_i_e_0 = ZDFChannelIE()


# Generated at 2022-06-26 13:24:13.319107
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    print('Testing constructor')
    test_case_0()
    print('Constructor test pass')



# Generated at 2022-06-26 13:24:14.928582
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Unit test for stub constructor
    ZDFChannelIE()


# Generated at 2022-06-26 13:24:59.069060
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_case_0()
    return None


# Generated at 2022-06-26 13:24:59.921710
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zd_ch_IE = ZDFChannelIE()


# Generated at 2022-06-26 13:25:00.615322
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert not ZDFBaseIE
    pass



# Generated at 2022-06-26 13:25:01.551033
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:25:02.481772
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert(isinstance(ZDFChannelIE(),ZDFChannelIE))
    

# Generated at 2022-06-26 13:25:03.943209
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()


# Generated at 2022-06-26 13:25:13.249569
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_i_e_0 = ZDFBaseIE()
    assert hasattr(zdf_i_e_0, '_call_api')
    assert hasattr(zdf_i_e_0, '_extract_subtitles')
    assert hasattr(zdf_i_e_0, '_extract_format')
    assert hasattr(zdf_i_e_0, '_extract_ptmd')
    assert hasattr(zdf_i_e_0, '_extract_player')
    # self.assertTrue('ZDFBaseIE' in zdf_i_e_0.__class__.__name__)


# Generated at 2022-06-26 13:25:14.535470
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-26 13:25:15.454073
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_case_0()


# Generated at 2022-06-26 13:25:16.404766
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-26 13:26:07.050002
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:26:08.769835
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie.name == 'zdf'



# Generated at 2022-06-26 13:26:13.805369
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE(*["url"])
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-26 13:26:21.864678
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE()
    assert zdfChannelIE.IE_NAME == 'zdf.de:channel'
    assert zdfChannelIE.SUFFIX == 'sport/das-aktuelle-sportstudio'
    assert zdfChannelIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'



# Generated at 2022-06-26 13:26:27.709686
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # This test will fail if constructor changed
    test_class = type('test', (ZDFChannelIE,), {})
    assert not test_class.suitable('http://www.zdf.de/filme/taunuskrimi/folge-1-sommergewitter-100.html')
    assert test_class.suitable('http://www.zdf.de/filme/taunuskrimi/')

# Generated at 2022-06-26 13:26:30.143856
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-26 13:26:36.109633
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel = ZDFChannelIE()
    assert zdf_channel.suitable(
        'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert zdf_channel.suitable(
        'https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html')
    assert zdf_channel.suitable(
        'https://www.zdf.de/wissen/nano/nano-21-mai-2019-102.html')

# Generated at 2022-06-26 13:26:38.143245
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()



# Generated at 2022-06-26 13:26:42.829686
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-26 13:26:43.856896
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    f = ZDFIE()
    print(type(f))
    assert type(f) == ZDFIE



# Generated at 2022-06-26 13:28:30.609398
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert isinstance(ie, ZDFBaseIE)


# Generated at 2022-06-26 13:28:33.160575
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:28:34.356767
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base = ZDFBaseIE()
    assert base._GEO_COUNTRIES == ['DE']



# Generated at 2022-06-26 13:28:38.008716
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE('ZDF')
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-26 13:28:49.310355
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.tests import FakeYDL
    from youtube_dl.ZDFChannelIE import ZDFChannelIE
    ydl = FakeYDL()
    url = 'https://www.zdf.de/dokumentation/planet-e'
    with HttpFD(ydl, {url: open('tests/data/zdf.html', 'rb')}) as fd:
        result = ZDFChannelIE().extract(url)
        assert len(result['entries']) == 50
        assert 'dokumentation/ab-18/der-vergewaltiger-aus-berlin-wird-nicht-geschnappt-das-verbrechen-2-100.html' in result['entries'][0]['url']
       

# Generated at 2022-06-26 13:28:59.609999
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.suitable('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')
    assert ie.suitable('https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html')
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')

# Generated at 2022-06-26 13:29:03.856997
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/')
    ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-26 13:29:06.721955
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert isinstance(ie, ZDFChannelIE)
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, 'suitable')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_download_webpage')

# Generated at 2022-06-26 13:29:11.823155
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test for cases of empty data parameters
    ie = ZDFBaseIE('empty data', 'empty id', 'empty ie key', 'empty name')
    # Test for cases of valid data parameters
    ie = ZDFBaseIE('empty data', 'empty id', 'empty ie key', 'empty name')



# Generated at 2022-06-26 13:29:14.037598
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    suite = unittest.TestSuite()
    suite.addTest(TestZDFChannelIE('test_constructor'))
    return suite

