

# Generated at 2022-06-26 13:23:53.961358
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-26 13:23:54.988384
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e = ZDFChannelIE()


# Generated at 2022-06-26 13:23:57.754190
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    extractor = ZDFBaseIE()
    assert extractor.geo_verification_headers() == {'X-Country': 'DE'}


# Generated at 2022-06-26 13:23:58.984242
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e = ZDFIE()


# Generated at 2022-06-26 13:24:00.397538
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
	z_d_f_base_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:24:02.466740
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_test = ZDFIE()


# Generated at 2022-06-26 13:24:08.880409
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test with a valid url
    url = 'https://www.zdf.de/serien/frau-jordan-stellt-gleich/folge-7-100.html'
    z_d_f_base_i_e = ZDFBaseIE()
    z_d_f_base_i_e._match_id(url)
    # Test with a non valid url
    url = 'google.de'
    z_d_f_base_i_e._match_id(url)


# Generated at 2022-06-26 13:24:13.464135
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e = ZDFChannelIE()
    z_d_f_channel_i_e.suitable = False
    assert z_d_f_channel_i_e.suitable == False


# Generated at 2022-06-26 13:24:16.755675
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:24:18.931941
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    from .zdf import ZDFIE
    ZDFBaseIE(ZDFIE())


# Generated at 2022-06-26 13:25:03.977399
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfbaseie = ZDFBaseIE()


# Generated at 2022-06-26 13:25:06.687225
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        ZDFChannelIE()
    except Exception as e:
        assert(0)

    instance = ZDFChannelIE()
    return instance


# Generated at 2022-06-26 13:25:08.533759
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # class
    assert ZDFBaseIE
    # isinstance
    assert (isinstance(ZDFBaseIE, InfoExtractor))


# Generated at 2022-06-26 13:25:10.590936
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:25:13.151349
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    params = {"webpage": "", "player": [], "video_id": ""}
    ZDFIE(params)


# Generated at 2022-06-26 13:25:14.754953
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:25:24.134544
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'zdf'
    assert ZDFIE.ie_key()
    assert ZDFIE.title()
    assert ZDFIE.description()
    assert ZDFIE.thumbnail()
    assert ZDFIE.uploader()
    z_d_f_i_e_0 = ZDFIE.suitable('https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html')
    assert bool(z_d_f_i_e_0)
    assert hasattr(z_d_f_i_e_0, '_real_extract')


# Generated at 2022-06-26 13:25:25.369031
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:25:26.876671
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE
    assert ZDFBaseIE(None, None) is not None
    

# Generated at 2022-06-26 13:25:28.076631
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_1 = ZDFIE()


# Generated at 2022-06-26 13:27:01.587234
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_1 = ZDFChannelIE()
    test_case_0()


# Generated at 2022-06-26 13:27:11.652260
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # URL = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    URL = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    video_id = '151025_magie_farben2_tex'

# Generated at 2022-06-26 13:27:15.004287
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_ie = ZDFChannelIE()
    assert isinstance(z_d_f_channel_ie, ZDFChannelIE)


# Generated at 2022-06-26 13:27:16.661886
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:27:27.391240
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        print('Testing constructor')
        test_case_0()
    except:
        print('Exception in constructor')
    try:
        print('Testing instance')
        z_d_f_channel_i_e_0 = ZDFChannelIE()
        z_d_f_channel_i_e_0._call_api('http://zdf.de/json/all/', '', '')
        z_d_f_channel_i_e_0._extract_subtitles({})
        z_d_f_channel_i_e_0._extract_ptmd('http://zdf.de/json/all/', '', '', '')
        z_d_f_channel_i_e_0._extract_player('', '')
    except:
        print('Exception when testing instance')

# Generated at 2022-06-26 13:27:29.080837
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:27:30.445785
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print("constructor")
    test_case_0()


# Generated at 2022-06-26 13:27:34.075209
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert obj._downloader is not None
    assert obj._downloader.params.get('nocheckcertificate', False)
    assert obj.geo_countries == obj._GEO_COUNTRIES
    assert obj.ie_key() == 'ZDFBase'


# Generated at 2022-06-26 13:27:35.166484
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-26 13:27:38.895405
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = "https://www.zdf.de/dokumentation/planet-e/weltraum-terra-x"
    z_d_f_channel_i_e_0 = ZDFChannelIE()
    assert z_d_f_channel_i_e_0._match_id(url) == "planet-e", "Test Case 0 failed"


# Generated at 2022-06-26 13:31:21.617576
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Input Parameters
    url = 'https://www.zdf.de/filme/taunuskrimi/'
    test_case_0(url)

test_case_0()

# Generated at 2022-06-26 13:31:24.249360
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert z_d_f_channel_i_e_0.channel_id == 'das-aktuelle-sportstudio'


# Generated at 2022-06-26 13:31:26.305728
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    Test_ZDF_Base_IE = ZDFBaseIE()
    Test_ZDF_Base_IE._call_api


# Generated at 2022-06-26 13:31:27.733533
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-26 13:31:29.279992
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e = ZDFChannelIE()


# Generated at 2022-06-26 13:31:30.550980
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()



# Generated at 2022-06-26 13:31:31.232367
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    pass # print(ZDFChannelIE())

# Generated at 2022-06-26 13:31:32.098248
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE


# Generated at 2022-06-26 13:31:34.734160
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable(url) is True
    assert zdf_channel_ie.IE_NAME == 'zdf:channel'
    assert zdf_channel_ie.IE_DESC == 'ZDF - channels'
    assert zdf_channel_ie.test_cases

# Generated at 2022-06-26 13:31:35.676289
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()
