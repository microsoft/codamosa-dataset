

# Generated at 2022-06-26 13:23:46.056991
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    inst = ZDFBaseIE()
    assert inst != None


# Generated at 2022-06-26 13:23:52.770608
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()


# Generated at 2022-06-26 13:24:02.772920
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(ZDFIE.ie_key() == 'ZDF')
    assert(ZDFIE.ie_key() == 'ZDFMediathek')
    assert(ZDFIE.ie_key() == 'ZDFEinSternVonPekingsSilvesterAusblick')
    assert(ZDFIE.ie_key() == 'ZDFEinSternVonPekingsWeihnachtenAusblick')
    assert(ZDFIE.ie_key() == 'DasErsteVideotext')
    assert(ZDFIE.ie_key() == 'ZDFInfoVideotext')
    assert(ZDFIE.ie_key() == 'ZDFneoVideotext')
    assert(ZDFIE.ie_key() == 'ZDFkulturVideotext')
   

# Generated at 2022-06-26 13:24:07.411814
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e = ZDFBaseIE()
    assert z_d_f_base_i_e._GEO_COUNTRIES == ['DE']
    assert z_d_f_base_i_e._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:24:14.944409
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Same as https://www.phoenix.de/sendungen/ereignisse/corona-nachgehakt/wohin-fuehrt-der-protest-in-der-pandemie-a-2050630.html
    url_0 = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    # Same as https://www.3sat.de/film/ab-18/10-wochen-sommer-108.html
    url_1 = 'https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html'
    # Same as https://www.3sat.de/wiss

# Generated at 2022-06-26 13:24:26.969078
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from ytdl.YTDLHook import YTDLHook
    from ytdl.YTDLInfoExtractor import YTDLInfoExtractor
    from ytdl.socks import SocksiPyAdapter
    from ytdl.extractor.common import InfoExtractor

    _info_extractor = YTDLInfoExtractor(YTDLHook(), SocksiPyAdapter(), InfoExtractor)

    z_d_f_i_e = ZDFIE(_info_extractor)

    print(type(z_d_f_i_e))
    print(isinstance(z_d_f_i_e, ZDFBaseIE))


test_ZDFIE()

# Generated at 2022-06-26 13:24:32.678767
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert hasattr(ZDFBaseIE, '_call_api')
    assert hasattr(ZDFBaseIE, '_extract_subtitles')
    assert hasattr(ZDFBaseIE, '_extract_format')
    assert hasattr(ZDFBaseIE, '_extract_ptmd')
    assert hasattr(ZDFBaseIE, '_extract_player')

test_case_0()
test_ZDFBaseIE()



# Generated at 2022-06-26 13:24:34.857748
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_instance = ZDFChannelIE()


# Generated at 2022-06-26 13:24:37.461648
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL)
    assert not ZDFChannelIE.suitable(ZDFIE._VALID_URL)


# Generated at 2022-06-26 13:24:39.450215
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:25:25.411176
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    global z_d_f_channel_i_e_0
    z_d_f_channel_i_e_0 = ZDFChannelIE()


# Generated at 2022-06-26 13:25:26.122550
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert "ZDFChannelIE" in globals()


# Generated at 2022-06-26 13:25:27.027088
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    fixture = lambda: ZDFChannelIE()
    assert fixture() is not None


# Generated at 2022-06-26 13:25:28.179367
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e = ZDFIE()

# Generated at 2022-06-26 13:25:31.986379
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert z_d_f_base_i_e_0._GEO_COUNTRIES == ['DE'], z_d_f_base_i_e_0._GEO_COUNTRIES
    assert z_d_f_base_i_e_0._QUALITIES == ('auto', 'low', 'med', 'high',
        'veryhigh', 'hd'), z_d_f_base_i_e_0._QUALITIES


# Generated at 2022-06-26 13:25:32.769877
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    instance = ZDFIE()

# Test for method: _extract_player

# Generated at 2022-06-26 13:25:33.433234
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie_0 = ZDFIE()


# Generated at 2022-06-26 13:25:33.876700
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

# Generated at 2022-06-26 13:25:34.727604
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:25:36.738157
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'
    assert ZDFIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

test_case_0()
test_ZDFIE()

# Generated at 2022-06-26 13:26:26.545986
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfe = ZDFIE()

# Generated at 2022-06-26 13:26:27.357285
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'ZDF'


# Generated at 2022-06-26 13:26:29.560577
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/kultur/traumschiff'
    channel = ZDFChannelIE.new(url)
    channel._real_extract(url)



# Generated at 2022-06-26 13:26:30.202559
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE


# Generated at 2022-06-26 13:26:31.111356
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie = ZDFIE(None)


# Generated at 2022-06-26 13:26:32.300369
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
	zdfie = ZDFIE()
	assert isinstance(zdfie, ZDFBaseIE)

# Generated at 2022-06-26 13:26:33.259229
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE({})
    assert zdfie is not None



# Generated at 2022-06-26 13:26:46.444825
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-26 13:26:49.315110
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    s = ZDFChannelIE()
    assert(s.channel_id == None)
    assert(s.channel_url == None)
    assert(s.channel_entries == [])
    assert(s.channel_entries_mapping == {})


# Generated at 2022-06-26 13:26:53.647111
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .extractor.zdf import ZDFChannelIE
    assert ZDFChannelIE.suitable("https://www.zdf.de/")
    assert ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/planet-e")
    assert ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/planet-e/")
    assert ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/planet-e/100.html")
    assert ZDFChannelIE.suitable("https://www.zdf.de/dokumentation/planet-e/100")

# Generated at 2022-06-26 13:28:40.685921
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE().suitable(ZDFIE.suitable("https://www.zdf.de/filme/taunuskrimi/"))


# Generated at 2022-06-26 13:28:41.951241
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert isinstance(ZDFBaseIE(), InfoExtractor)


# Generated at 2022-06-26 13:28:53.585945
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Create a ZDFChannelIE instance
    instance = ZDFChannelIE()
    # Check the simple cases of "suitable" method
    assert instance.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert instance.suitable('https://www.zdf.de/dokumentation/planet-e/')
    # Check the simple cases of "suitable" method (negative)
    assert not instance.suitable('https://www.zdf.de/dokumentation/planet-e/blabla.html')
    assert not instance.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio/blabla.html')
    # Check the complex cases of "suitable" method

# Generated at 2022-06-26 13:28:57.322363
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert hasattr(ZDFBaseIE, '_GEO_COUNTRIES')
    assert hasattr(ZDFBaseIE, '_QUALITIES')
    assert hasattr(ZDFBaseIE, '_call_api')
    assert hasattr(ZDFBaseIE, '_extract_subtitles')
    assert hasattr(ZDFBaseIE, '_extract_format')
    assert hasattr(ZDFBaseIE, '_extract_ptmd')
    assert hasattr(ZDFBaseIE, '_extract_player')


# Generated at 2022-06-26 13:29:04.290484
# Unit test for constructor of class ZDFIE

# Generated at 2022-06-26 13:29:04.956341
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z = ZDFIE()
    assert z is not None

# Generated at 2022-06-26 13:29:06.090482
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return assertEqual(ZDFChannelIE.__bases__[0].__name__, 'InfoExtractor')


# Generated at 2022-06-26 13:29:08.617375
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE(None, None)


# Generated at 2022-06-26 13:29:11.828575
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Test two URLs
    test_urls = [
        'https://www.zdf.de/sport/das-aktuelle-sportstudio',
        'https://www.zdf.de/dokumentation/planet-e',
    ]
    for url in test_urls:
        zdf_channel_ie = ZDFChannelIE(url)
        assert zdf_channel_ie.suitable(url)
        assert zdf_channel_ie._VALID_URL == ZDFChannelIE._VALID_URL

# Generated at 2022-06-26 13:29:13.905105
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert(issubclass(ZDFChannelIE, InfoExtractor))
    assert(ZDFChannelIE.suitable("https://www.zdf.de/studio-fuer-politik-dialog"))


# Generated at 2022-06-26 13:33:09.539911
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from . import ZDFIE
    class TestZDFIE(ZDFIE):
        def _real_extract(self, url):
            return TestZDFIE._real_extract(url)
    TestZDFIE._VALID_URL = ZDFIE._VALID_URL
    TestZDFIE._TESTS = ZDFIE._TESTS

    test_ZDFIE = TestZDFIE()
    test_ZDFIE._downloader = None
    test_ZDFIE._print = lambda _: None
    return test_ZDFIE