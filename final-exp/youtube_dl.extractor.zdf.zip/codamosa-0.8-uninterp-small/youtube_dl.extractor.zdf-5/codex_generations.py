

# Generated at 2022-06-26 13:23:49.597723
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()



# Generated at 2022-06-26 13:23:53.874458
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()
    assert z_d_f_i_e_0._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-26 13:23:55.104861
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e = ZDFChannelIE()


# Generated at 2022-06-26 13:23:57.811948
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e = ZDFIE()
    z_d_f_i_e.ie_key()



# Generated at 2022-06-26 13:23:58.858200
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e = ZDFChannelIE()

# Generated at 2022-06-26 13:24:00.748832
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()

test_cases = [
    test_case_0
]

# Command line entry-point

# Generated at 2022-06-26 13:24:02.812119
# Unit test for constructor of class ZDFIE
def test_ZDFIE():

    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 13:24:03.956841
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_case_0()


# Generated at 2022-06-26 13:24:07.369275
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert_equal(z_d_f_i_e_0._match_id("https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html"), "der-hauptmann-112")


# Generated at 2022-06-26 13:24:08.668349
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    fake_zdf_base_ie = ZDFBaseIE()


# Generated at 2022-06-26 13:24:58.559208
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:24:59.711255
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e = ZDFBaseIE()


# Generated at 2022-06-26 13:25:00.800623
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert_raises(TypeError, test_case_0)

# Generated at 2022-06-26 13:25:02.698992
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert(ZDFBaseIE._GEO_COUNTRIES == ['DE'])
    assert(ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))



# Generated at 2022-06-26 13:25:06.351429
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    if not hasattr(test_ZDFIE, "zdf_ie"):
        test_ZDFIE.zdf_ie = ZDFIE()
    try:
        test_ZDFIE.zdf_ie
    except NameError:
        assert False


# Generated at 2022-06-26 13:25:10.277321
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # check string representation of class
    assert str(ZDFBaseIE.__doc__) is not None, (
        "Unit Test Failed: "
        "Instantiate class constructor :: %s" % str(ZDFBaseIE.__doc__)
    )



# Generated at 2022-06-26 13:25:11.526973
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()



# Generated at 2022-06-26 13:25:14.919427
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        z_d_f_channel_i_e_0 = ZDFChannelIE()
    except:
        print("Unable to create ZDFChannelIE object for test")
        return


# Generated at 2022-06-26 13:25:17.828461
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert(ZDFBaseIE._GEO_COUNTRIES == ['DE'])
    assert(ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))


# Generated at 2022-06-26 13:25:27.072219
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert str(ZDFBaseIE._QUALITIES) == "('auto', 'low', 'med', 'high', 'veryhigh', 'hd')"
    assert str(ZDFBaseIE._GEO_COUNTRIES) == "('DE')"
    assert ZDFBaseIE._call_api == None
    assert str(ZDFBaseIE._extract_subtitles) == "<function ZDFBaseIE._extract_subtitles at 0x1119e5510>"
    assert ZDFBaseIE._extract_format == None
    assert str(ZDFBaseIE._extract_ptmd) == "<function ZDFBaseIE._extract_ptmd at 0x1119e5598>"
    assert ZDFBaseIE._extract_player == None

# Generated at 2022-06-26 13:26:20.729397
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-26 13:26:23.887594
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Subclassing ZDFBaseIE, ZDFChannelIE should be able to handle this url.
    assert ZDFChannelIE._VALID_URL == ZDFIE._VALID_URL

# Generated at 2022-06-26 13:26:25.050651
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE("")

# Generated at 2022-06-26 13:26:26.661045
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(None, None)

# Unit tests for _extract_subtitles

# Generated at 2022-06-26 13:26:28.551701
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from youtube_dl.downloader.common import FileDownloader
    for e in FileDownloader._download_retry_counts.items():
        print(e)


# Generated at 2022-06-26 13:26:29.708300
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert(ie.ie_key() == 'ZDF')


# Generated at 2022-06-26 13:26:35.240705
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Simple unit tests
    player = ZDFBaseIE._extract_player('', '')
    assert player == {}
    player = ZDFBaseIE._extract_player('<div></div>', '')
    assert player == {}
    
    # Constructor ZDFBaseIE
    obj = ZDFBaseIE(None)
    assert obj._GEO_COUNTRIES == ['DE']
    assert obj._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-26 13:26:40.925472
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Args:
    #     (str) url:
    #         video url
    #     (bool) download:
    #         whether to download the video
    # Returns:
    #     a dict containing
    #     {
    #         '_type': 'url',
    #         'url': video url,
    #         'ie_key': 'ZDF'
    #     }
    zdf = ZDFBaseIE()
    url = 'https://www.zdf.de/comedy/neo-magazin-royale-mit-jan-boehm-100.html'
    download = True
    response = zdf._download_webpage(url, '', '', fatal=True)
    print(response)


# Generated at 2022-06-26 13:26:43.855281
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # test the constructor of class ZDFIE
    ie = ZDFIE("https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html",123)
    assert ie is not None, "Test for constructor failed"


# Generated at 2022-06-26 13:26:44.519205
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()



# Generated at 2022-06-26 13:28:37.192738
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE

# Generated at 2022-06-26 13:28:47.641100
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-26 13:28:58.939759
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    result = ZDFIE(None, {'ie_key': 'zdf', 'qualities': ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')})
    assert result.ie_key == 'ZDF'
    assert result._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-26 13:29:01.458840
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert repr(ie) == "ZDFChannelIE('zdf.de', 'ZDF', ['plugin_cmd_fetch_info', 'plugin_cmd_fetch_subtitles'])"


# Generated at 2022-06-26 13:29:06.209048
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE._parse_json('{"example": "data"}', '1234')
    ZDFBaseIE._GEO_COUNTRIES = ['DE']
    ZDFBaseIE._QUALITIES = ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:29:10.671921
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test constructor of class ZDFBaseIE"""
    assert ZDFBaseIE(None)._GEO_COUNTRIES and isinstance(ZDFBaseIE(None)._QUALITIES, list)



# Generated at 2022-06-26 13:29:12.806179
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE().suitable('https://www.zdf.de/filme/taunuskrimi/')



# Generated at 2022-06-26 13:29:18.570410
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try_url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE(try_url, None)
    assert ie._VALID_URL == ZDFChannelIE._VALID_URL
    assert ie.url == try_url
    assert ie.channels == [('https://www.zdf.de/dokumentation/planet-e', 'planet', 'e.')]
    assert ie._channel_info == {}

# Generated at 2022-06-26 13:29:22.296780
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf = ZDFChannelIE()
    assert zdf.suitable(
        url='https://www.zdf.de/nachrichten/heuteplus')
    assert not zdf.suitable(
        url='https://www.zdf.de/heuteplus/heute-im-sternenhimmel-pars-sternbild-100.html')


# Generated at 2022-06-26 13:29:26.150389
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # not gonna work without the ugly hack in youtube_dl/extractor/common.py
    # would be easy to fix though
    return
    zdf = ZDFChannelIE()
    zdf.suitable('https://www.zdf.de/politik/phoenix-sendungen')
    assert True