

# Generated at 2022-06-26 13:23:46.972976
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_case_0()


# Generated at 2022-06-26 13:23:53.969510
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    z_d_f_i_e_0 = ZDFIE()
    z_d_f_i_e_0._extract_regular(url)

## Unit test for constructor of class ZDFBaseIE
#def test_ZDFBaseIE():
#    video_id = '210222_phx_nachgehakt_corona_protest'
#    z_d_f_base_i_e_0 = ZDFBaseIE()
#    z_d_f_base_i_e_0._extract_mobile(video_id)



# Generated at 2022-06-26 13:23:58.755930
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert 'ZDFIE' == ZDFIE.ie_key()
    test_ZDFIE_instance = ZDFIE()
    expected_result = 'https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html'
    assert expected_result == test_ZDFIE_instance._VALID_URL


# Generated at 2022-06-26 13:23:59.844371
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zDFChannel = ZDFChannelIE()


# Generated at 2022-06-26 13:24:01.438821
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:24:02.625504
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()


# Generated at 2022-06-26 13:24:03.284205
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    obj = ZDFChannelIE()


# Generated at 2022-06-26 13:24:09.337746
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    global z_d_f_base_i_e_0
    assert replace_spaces(z_d_f_base_i_e_0.__class__.__name__) == 'ZDFBaseIE'
    assert z_d_f_base_i_e_0._GEO_COUNTRIES == ['DE']
    assert z_d_f_base_i_e_0._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:24:11.948086
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e = ZDFChannelIE()


# Generated at 2022-06-26 13:24:25.578966
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()
    z_d_f_base_i_e_0.check_ie_support()
    z_d_f_base_i_e_0.check_ie_support(ZDFBaseIE.ie_key())
    z_d_f_base_i_e_0.check_ie_support('ZDFBaseIE')
    z_d_f_base_i_e_0.check_ie_support('ZDFBaseIE')
    z_d_f_base_i_e_0.check_ie_support('ZDFBaseIE')
    z_d_f_base_i_e_0.check_ie_support('ZDFBaseIE')
    z_d_f_base_i_e_0.check_

# Generated at 2022-06-26 13:25:11.934400
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-26 13:25:13.391782
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert isinstance(ZDFBaseIE, object)


# Generated at 2022-06-26 13:25:14.071620
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert True

# Generated at 2022-06-26 13:25:15.650405
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    obj = ZDFChannelIE()
    assert obj.suitable(url) == True


# Generated at 2022-06-26 13:25:16.578631
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert test_case_0() == None


# Generated at 2022-06-26 13:25:17.869683
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_ie = ZDFChannelIE()


# Generated at 2022-06-26 13:25:24.451185
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Simple test case
    url = 'https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html'
    z_d_f_i_e_0 = ZDFIE()
    print(type(z_d_f_i_e_0))
    test_case_0()


if __name__ == '__main__':
    test_ZDFIE()

# Generated at 2022-06-26 13:25:29.000674
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channels = list(z_d_f_base_i_e_0.get_all_channels())
    if len(channels) > 0:
        z_d_f_channel_i_e = ZDFChannelIE()
        assert z_d_f_channel_i_e.suitable(channels[0])
    else:
        print('test_ZDFChannelIE unit test not performed')


# Generated at 2022-06-26 13:25:34.705994
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-26 13:25:35.733150
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()


# Generated at 2022-06-26 13:26:30.128716
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE().init()
    assert ie.name == 'ZDF'
    assert ie.ie_key() == 'ZDF'


# Generated at 2022-06-26 13:26:31.626834
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie is not None



# Generated at 2022-06-26 13:26:35.806512
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
	zdfIE = ZDFIE(None)
	assert isinstance(zdfIE, ZDFBaseIE)
	assert zdfIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
	assert len(zdfIE._TESTS) == 10 # 9 regular test cases and 1 constructor test case
	assert zdfIE.ie_key() == 'ZDF'
	return

test_ZDFIE()


# Generated at 2022-06-26 13:26:40.593926
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-26 13:26:47.829737
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE._download_webpage = lambda self, url, video_id: None
    ZDFChannelIE._extract_player = lambda self, webpage, url, fatal=False: None
    ZDFChannelIE._call_api = lambda self, api_url, player, referer, video_id: {}
    ZDFChannelIE.suitable = lambda self, url: None
    ZDFChannelIE.url_result = lambda self, url, ie, **kwargs: None
    ZDFChannelIE.playlist_result = lambda self, entries, playlist_id, playlist_title: None
    ZDFChannelIE._og_search_title = lambda self, webpage, fatal=False: None

    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'

    ie = ZDFChannelIE

# Generated at 2022-06-26 13:26:48.838307
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ce = ZDFIE()
    assert ce != None


# Generated at 2022-06-26 13:26:50.484187
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/politik/frontal-21'
    assert ZDFChannelIE._match_id(url) == 'frontal-21'

# Generated at 2022-06-26 13:26:54.780932
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    cls = type('TestZDFChannelIE', (ZDFChannelIE,), {'_VALID_URL': r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'})
    assert cls(cls.ie_key()).suitable("https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html")
    assert not cls(cls.ie_key()).suitable("http://www.3sat.de/wissen/nano/nano-21-mai-2019-102.html")



# Generated at 2022-06-26 13:26:55.747902
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert isinstance(ZDFChannelIE().suitable(ZDFChannelIE._VALID_URL), bool)



# Generated at 2022-06-26 13:27:05.414134
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
  ie = ZDFBaseIE.get_ie_for_url('http://www.zdf.de/ZDFmediathek/beitrag/video/2378642/Kessel-Buntes-Schlagerstar-Howard-Carpendale#/beitrag/video/2378642/Kessel-Buntes-Schlagerstar-Howard-Carpendale')
  assert ie.__class__ == ZDFIE
  assert ie._downloader is not None
  assert ie._WORKING == True
  assert ie._GEO_COUNTRIES == ['DE']
  assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-26 13:29:00.097972
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()

# Generated at 2022-06-26 13:29:00.940466
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE() # The constructor does not require any parameters

# Generated at 2022-06-26 13:29:01.934389
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    info_extractor = ZDFIE()


# Generated at 2022-06-26 13:29:03.770061
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    inst=ZDFIE()
    assert inst._VALID_URL == 'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-26 13:29:15.515203
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    plugin = ZDFBaseIE()

    # test ZDFBaseIE._call_api
    # _call_api returns a json object
    url = "https://api.zdf.de/content/documents/zdf/some12345/some/url"
    video_id = "some12345"
    item = "some-item"
    res = plugin._call_api(url, video_id, item)
    assert res == {"id": "zdf/some12345/some/url", "title": "Some Title"}
    # _call_api can handle api token
    api_token = "api12345"
    res = plugin._call_api(url, video_id, item, api_token)
    assert res == {"id": "zdf/some12345/some/url", "title": "Some Title"}
   

# Generated at 2022-06-26 13:29:23.042212
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    text = '{"priorityList":[{"formitaeten":[{"qualities":[{"audio":{"tracks":[{"isDefault":true,"language":"deu","uri":"https:\/\/cdnv-b21.zdf.de\/m\/PPZXMtxrQ3qk1B9gh\/master.m3u8"}]},"id":"m3u8","quality":"hls"}],"type":"hls"}],"id":"hls"}],"basename":"PPZXMtxrQ3qk1B9gh","attributes":{"duration":{"value":"555763000"}}}'
    try:
        r = ZDFBaseIE._call_api('', '', '', '', '')
    except:
        r = None
    assert r == None

    try:
        r = ZDFBaseIE._extract_format([], set(), text)
    except:
        r = None


# Generated at 2022-06-26 13:29:30.397946
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    a_object = {}
    a_object['test'] = 1

    a_entry ={}
    a_entry['description'] = "abc"
    a_entry['extractor_key'] = "abc"
    a_entry['duration'] = 1
    a_entry['formats'] = []
    a_entry['id'] = "abc"
    a_entry['title'] = "abc"
    a_entry['upload_date'] = "20170101"

    # Test _extract_entry
    assert ie._extract_entry(a_object, a_object, a_object, a_object) == a_entry
    a_entry['duration'] = -1
    assert ie._extract_entry(a_object, a_object, a_object, a_object) != a_

# Generated at 2022-06-26 13:29:38.656590
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_urls import TEST_URLS_ZDF_CHANNEL_IE
    for url_data in TEST_URLS_ZDF_CHANNEL_IE:
        url = url_data[0]
        video_id = url_data[1]
        video_name = url_data[2]
        assert url == ZDFChannelIE(url)._url
        assert url == ZDFChannelIE(url)._VALID_URL
        assert video_id == ZDFChannelIE(url)._match_id(url)
        assert video_name == ZDFChannelIE(url)._real_extract(url).get('_type')



# Generated at 2022-06-26 13:29:41.623123
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()

    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:29:47.326514
# Unit test for constructor of class ZDFIE
def test_ZDFIE():

    # Constructor of class ZDFIE
    zdfie = ZDFIE()

    # Instance variables of class ZDFIE
    assert zdfie._GEO_COUNTRIES == ['DE']
    assert zdfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

    # Check if variable api_token is empty
    assert zdfie.api_token == ""
    # Check if variable referrer is empty
    assert zdfie.referrer == ""
