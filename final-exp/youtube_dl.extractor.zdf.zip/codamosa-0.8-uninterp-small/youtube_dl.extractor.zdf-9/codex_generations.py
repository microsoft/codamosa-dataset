

# Generated at 2022-06-26 13:23:46.453592
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_ = ZDFBaseIE()


# Generated at 2022-06-26 13:23:53.165890
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel = ZDFChannelIE()

# Generated at 2022-06-26 13:23:54.713631
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from ytdl.ZDFChannelIE import ZDFChannelIE
    zdf_channel_ie = ZDFChannelIE()


# Generated at 2022-06-26 13:23:56.737089
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_case_0()

if __name__ == '__main__':
    test_ZDFIE()

# Generated at 2022-06-26 13:23:58.598651
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()
    pass


# Generated at 2022-06-26 13:24:00.257079
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_b_a_s_e_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:24:01.240789
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e = ZDFChannelIE()

# Generated at 2022-06-26 13:24:03.252803
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:24:04.120928
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()

# Generated at 2022-06-26 13:24:05.817961
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e = ZDFBaseIE()


# Generated at 2022-06-26 13:24:31.848559
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_i_e_1 = ZDFIE()



# Generated at 2022-06-26 13:24:33.178118
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(z_d_f_i_e_0 is not None)


# Generated at 2022-06-26 13:24:34.949542
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()


# Generated at 2022-06-26 13:24:36.337692
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE(zdf_base_ie_0)



# Generated at 2022-06-26 13:24:38.139968
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert test_case_0()

if __name__ == '__main__':
    test_ZDFIE()

# Generated at 2022-06-26 13:24:40.010720
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e = ZDFBaseIE()


# Generated at 2022-06-26 13:24:47.622954
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert hasattr(ZDFBaseIE, '_GEO_COUNTRIES'), 'Class does not have "ZDFBaseIE._GEO_COUNTRIES" attribute'
    assert hasattr(ZDFBaseIE, '_QUALITIES'), 'Class does not have "ZDFBaseIE._QUALITIES" attribute'
    # Checking ZDFBaseIE.__init__
    assert hasattr(ZDFBaseIE, '__init__')


# Generated at 2022-06-26 13:24:51.261284
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e = z_d_f_i_e_0
    assert z_d_f_i_e._GEO_COUNTRIES is not None
    assert z_d_f_i_e._QUALITIES is not None


# Generated at 2022-06-26 13:24:53.692176
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert hasattr(ZDFIE(), '_TESTS')


# Generated at 2022-06-26 13:24:54.891305
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # print("Inside testing of constructor")
    this_object = ZDFChannelIE()

test_case_0()
test_ZDFChannelIE()

# Generated at 2022-06-26 13:25:22.491761
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()

# Generated at 2022-06-26 13:25:24.183816
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """
    Test constructor of class ZDFChannelIE
    """
    assert ZDFChannelIE.suitable(ZDFChannelIE._VALID_URL)
    assert not ZDFChannelIE.suitable(ZDFIE._VALID_URL)

# Generated at 2022-06-26 13:25:26.758979
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Test if constructor raises expected exceptions"""
    assert_raises(ExtractorError, ZDFChannelIE, None)
    assert_raises(ExtractorError, ZDFChannelIE, {'url': None})


# Generated at 2022-06-26 13:25:29.001037
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE.ie_key() == 'zdf'
    assert ZDFIE.ie_key() == 'zdf:mobile'
    obj = ZDFIE()
    assert obj is not None


# Generated at 2022-06-26 13:25:30.030327
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('www.zdf.de').to_screen()

# Generated at 2022-06-26 13:25:31.904067
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    i = ZDFIE()
    assert i._GEO_COUNTRIES == ['DE']
    assert i._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')

# Generated at 2022-06-26 13:25:32.704897
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        ZDFBaseIE()
    except:
        assert False



# Generated at 2022-06-26 13:25:33.639445
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE._VALID_URL == ZDFIE._VALID_URL

# Generated at 2022-06-26 13:25:34.529091
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert_true(ie)


# Generated at 2022-06-26 13:25:39.648748
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        assert isinstance(ZDFBaseIE(), InfoExtractor)
    except AssertionError:
        raise AssertionError('\nConstructor of class `ZDFBaseIE` must return an instance of `InfoExtractor`.')


# Generated at 2022-06-26 13:26:37.867241
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE('ZDFBaseIE')
    assert ie.ie_key() == 'ZDFBaseIE'
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:26:43.774455
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    try:
        import IPython.core.ultratb
        sys.excepthook = IPython.core.ultratb.FormattedTB(call_pdb=True)
    except ImportError:
        pass

    url = 'https://www.zdf.de/filme/taunuskrimi/'
    webpage = YouTubeIE._download_webpage(url, 'channel_id', fatal=False)

    player = ZDFIE._extract_player(webpage, 'channel_id', fatal=False)

    channel_id = ZDFIE._search_regex(
        r'docId\s*:\s*(["\'])(?P<id>(?!\1).+?)\1', webpage,
        'channel id', group='id')


# Generated at 2022-06-26 13:26:45.418042
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE('https://www.zdf.de/', None, None)
    assert zdfie is not None


# Generated at 2022-06-26 13:26:52.036054
# Unit test for constructor of class ZDFChannelIE

# Generated at 2022-06-26 13:26:52.838833
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    inst = ZDFIE()
    assert inst.ie_key() == 'ZDF'

# Generated at 2022-06-26 13:26:58.395497
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():

    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert ZDFChannelIE.suitable(url)
    assert not ZDFChannelIE.ie_key() in extractors
    assert not ZDFChannelIE.ie_key() in gen_extractors

    # Call constructor of class ZDFBaseIE, which registers the class
    zdfie = ZDFChannelIE(url)
    assert zdfie.suitable(url)
    assert ZDFChannelIE.ie_key() in extractors
    assert ZDFChannelIE.ie_key() in gen_extractors
    assert zdfie == extractors[ZDFChannelIE.ie_key()](url)
    assert zdfie == gen_extractors[ZDFChannelIE.ie_key()](url)

# Generated at 2022-06-26 13:27:00.424537
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE().to_screen("https://www.zdf.de/politik/ausland/fuer-viele-maedchen-ist-eine-abtreibung-das-einzige-mittel-gegen-ehe-und-zwangsschwangerschaft-100.html")


# Generated at 2022-06-26 13:27:03.155434
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from zdf_dl.zdf_download import main

    sys.argv = ["zdf-dl", "https://www.zdf.de/nachrichten/heute/heute-17-3-2019-100.html"]
    main()

    sys.argv = ["zdf-dl", "https://www.zdf.de/sport/das-aktuelle-sportstudio"]
    main()

# Generated at 2022-06-26 13:27:06.214874
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(ZDFIE(InfoExtractor())._GEO_COUNTRIES == ['DE'])
    assert(ZDFIE(InfoExtractor())._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))



# Generated at 2022-06-26 13:27:18.276384
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    info = dict(ZDFChannelIE._TESTS[0])
    # Test only cases where ZDFChannelIE is suitable
    # and ZDFIE is not.
    info['url'] = 'https://www.zdf.de/dokumentation/planet-e'
    info.pop('info_dict')
    #print (ZDFIE.suitable(info['url']))
    #print (ZDFChannelIE.suitable(info['url']))
    #channel = ZDFChannelIE()
    #channel._real_extract(info['url'])
    ZDFChannelIE._real_extract(None, info['url'])
    #print (channel)
    #print (channel.playlist)

# Generated at 2022-06-26 13:29:14.215633
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Instantiate a class with a constructor
    ie = ZDFChannelIE()


# Generated at 2022-06-26 13:29:15.196046
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-26 13:29:18.696418
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = pafy.get_overlay("https://www.zdf.de/dokumentation/planet-e")
    assert ie.title() == 'planet e.' and ie.num_entries() == 50 and ie.playlistid() == 'planet-e'


# Generated at 2022-06-26 13:29:27.619802
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():

    # Constructor of class ZDFChannelIE
    pc_instance = ZDFChannelIE()

    # Extraction of the first item of '_TESTS' from ZDFChannelIE
    test = ZDFChannelIE._TESTS[0]

    # Extracting the 'url' from 'test'
    extract_url = test['url']

    # Extracting the 'id' of the video from 'extract_url'
    channel_id = pc_instance._match_id(extract_url)

    # Extracting page content of 'extract_url'
    webpage = pc_instance._download_webpage(extract_url, channel_id)
    print(webpage)

    # This regex returns all the URL's within the page content

# Generated at 2022-06-26 13:29:34.611572
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert(zdfIE.ie_key() == 'ZDF')
    assert(zdfIE.valid_urls == [
        'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'])


# Generated at 2022-06-26 13:29:38.655867
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE()
    assert zdfie._TESTS[1]['md5'] == '0aff3e7bc72c8813f5e0fae333316a1d'
    assert len(zdfie._TESTS) == 10


# Generated at 2022-06-26 13:29:40.449689
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    assert isinstance(instance, ZDFBaseIE)


# Generated at 2022-06-26 13:29:42.239050
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio')

# Generated at 2022-06-26 13:29:48.363409
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """ Unit test for constructor of class ZDFChannelIE. """

    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio') == True
    # The following URL should not be suitable because preferring the ZDFIE.
    assert zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') == False

# Generated at 2022-06-26 13:29:56.504659
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    for uri in ['https://www.zdf.de/nachrichten/heute/corona-hilfen-so-koennte-die-bundesregierung-noch-mehr-taten-statt-worte-sprechen-100.html?utm_source=standard',
                'https://zdf.de/filme/filme-sonstige/der-hauptmann-112.html']:
        obj = ZDFIE._build_url_result(uri)
        print(obj['_type'], obj['url'], obj['id'])
