

# Generated at 2022-06-26 13:23:51.388008
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert(ZDFChannelIE.__doc__)
    # assert(z_d_f_channel_i_e_0.__dict__)


# Generated at 2022-06-26 13:23:54.533372
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE._VALID_URL == ZDFBaseIE._VALID_URL
    assert ZDFIE._TESTS == ZDFBaseIE._TESTS

# Generated at 2022-06-26 13:24:04.534763
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    url = 'https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html'
    video_id = url.split('/')[-1].replace('.html', '')
    webpage = ZDFIE()._download_webpage(url, video_id, fatal=False)
    player = ZDFIE()._extract_player(webpage, video_id, fatal=False)
    content = ZDFIE()._call_api(player['content'], video_id, 'content', player['apiToken'], url)
    ZDFIE()._extract_entry(player['content'], player, content, video_id)
    # ex = ZDFIE()._extract_regular(url

# Generated at 2022-06-26 13:24:07.202168
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # check if it throws an AssertionError if geo_countries are set explicitly
    assert_raises(
        AssertionError, ZDFBaseIE, geo_countries=[]
    )
    return



# Generated at 2022-06-26 13:24:08.267116
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()


# Generated at 2022-06-26 13:24:10.903522
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # create an object
    test_case_ZDFIE = ZDFIE()


# Generated at 2022-06-26 13:24:13.319157
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()

# Generated at 2022-06-26 13:24:14.928173
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    unit_test_ZDFIE = ZDFIE()


# Generated at 2022-06-26 13:24:17.563862
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_object_ZDFBaseIE = ZDFBaseIE()



# Generated at 2022-06-26 13:24:24.831354
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from ytdl.zdfbaseie import ZDFBaseIE
    from ytdl.zdfie import ZDFIE
    from ytdl.extractor import SearchInfoExtractor
    assert issubclass(ZDFChannelIE, ZDFBaseIE)
    assert issubclass(ZDFChannelIE, SearchInfoExtractor)
    z_d_f_channel_i_e_0 = ZDFChannelIE()


# Generated at 2022-06-26 13:24:55.469733
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie.name == 'ZDF'
    assert ie.ie_key() == 'ZDF'
    assert ie.logo_url() == 'http://www.zdf-grafik.de/'
    assert ie._GEO_COUNTRIES == ('DE')
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:24:57.632663
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    constructor_test(
        ZDFChannelIE,
        [
            'https://www.zdf.de/dokumentation/planet-e',
            'https://www.zdf.de/dokumentation/planet-e.'
        ]
    )

# Generated at 2022-06-26 13:24:58.827007
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    assert zdf_ie

# Generated at 2022-06-26 13:25:00.953155
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/foo/bar')
    assert not zdf_channel_ie.suitable('https://www.zdf.de/foo/bar.html')



# Generated at 2022-06-26 13:25:02.673560
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    m = ZDFIE()
    assert m.name == 'zdf'
    assert m.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() == 'ZDF'


# Generated at 2022-06-26 13:25:04.758325
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .__main__ import ZDFBaseIE
    ZDFBaseIE()._call_api('http://tempuri.org/','','','','',True)

# Generated at 2022-06-26 13:25:08.926172
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import sys
    if sys.version_info < (3, 6):
        raise Exception('Python 3.6 or above is required')
    zdfie = ZDFChannelIE()
    zdfie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')


# Generated at 2022-06-26 13:25:20.275427
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test import get_testfile_content
    from .test import get_testcases_from_file
    from .test import get_testcode
    from .test import get_testcode_expected_results
    from .test import get_testcode_playlist_count
    from .test import get_testcode_playlist_result

    # Namespace for test cases
    testcases = {}

    # Get test files
    test_files = (
        'zdf_channel_1.txt',
    )

    # Fill test cases
    get_testcases_from_file(
        __name__,
        testcases,
        test_files,
        (ZDFChannelIE,)
    )

    # Create test code
    testcode = get_testcode(
        testcases
    )

    # Get expected results
    expected_

# Generated at 2022-06-26 13:25:29.128674
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # https://www.zdf.de/dokumentation/planet-e
    # https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html
    # https://www.zdf.de/wissen/nano/nano-21-mai-2019-102.html
    # https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html
    class FakeVideoInfo:
        def __init__(self, video_id):
            self.id = video_id

# Generated at 2022-06-26 13:25:34.776389
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base = ZDFBaseIE()
    zdf_base._GEO_COUNTRIES
    zdf_base._QUALITIES
    zdf_base._call_api('http://test.com/test.json', 'video_id', 'test.json')
    zdf_base._extract_format('video_id', [], [], {
        'url': 'http://test.com/test.json',
        'mimeType': 'text/html',
        'mimeCodec': 'test',
        'quality': 'test',
    })
    zdf_base._extract_ptmd('/test.json', 'video_id', 'api_token', 'referrer')
    zdf_base._extract_player('', 'video_id')
    return


# Generated at 2022-06-26 13:26:27.257995
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    obj = ZDFChannelIE("http://www.zdf.de/filme/taunuskrimi/")
    assert not obj.suitable("http://www.zdf.de/filme/taunuskrimi/")
    assert not obj.suitable("http://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html")



# Generated at 2022-06-26 13:26:33.557587
# Unit test for constructor of class ZDFBaseIE

# Generated at 2022-06-26 13:26:35.598451
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test for non-existing video
    ZDFIE()._real_extract('https://zdf.de/filme/filme-sonstige/hg-11.html')

# Unit tests for class ZDFBaseIE

# Generated at 2022-06-26 13:26:41.137058
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE("http://www.zdf.de/comedy/Das-groesste-Heimspiel-der-Welt-100.html")._GEO_COUNTRIES == ['DE']


# Generated at 2022-06-26 13:26:43.920220
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie = ZDFChannelIE(url)
    assert ie.suitable(url)
    assert ie.valid_url(url)
    assert ie.url_result(url)
    assert ie.entry_protocol() == 'https'


# Generated at 2022-06-26 13:26:44.841117
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfchannel = ZDFChannelIE()
    print(zdfchannel)


# Generated at 2022-06-26 13:26:46.251566
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Test constructor by creating the object
    ZDFIE()


# Generated at 2022-06-26 13:26:47.126579
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE(None)



# Generated at 2022-06-26 13:26:48.626099
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.geo_countries == ie._GEO_COUNTRIES


# Generated at 2022-06-26 13:26:50.918347
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIEInstance = ZDFIE()
    assert ZDFIEInstance._VALID_URL ==  r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'


# Generated at 2022-06-26 13:28:53.539117
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    info_extractor = ZDFIE()
    # test generate ptmd url which is not in tests by calling _extract_player()
    webpage = info_extractor._download_webpage(
        "https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html",
        "something")
    player = info_extractor._extract_player(webpage, "something")
    assert player['content'] == "https://api.zdf.de/content/documents/something"
    assert player['apiToken'] == "ZDF token"
    content = info_extractor._call_api(player['content'], "something", "content", player['apiToken'], "something")

# Generated at 2022-06-26 13:29:02.324756
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.suitable('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert ie.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')
    assert ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')

# Generated at 2022-06-26 13:29:08.676941
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = 'test'
    webpage = 'webpage'
    result = ZDFBaseIE(ZDFBaseIE.ie_key())._extract_player(webpage, video_id)
    assert result == dict()
# End of unit test for constructor of class ZDFBaseIE



# Generated at 2022-06-26 13:29:11.962574
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base = ZDFBaseIE()
    assert base._GEO_COUNTRIES == ['DE']
    assert base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:29:12.612384
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()

# Generated at 2022-06-26 13:29:14.774442
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert(ZDFBaseIE('http://www.zdf.de/')._GEO_COUNTRIES == ['DE'])


# Generated at 2022-06-26 13:29:22.827045
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE._VALID_URL == 'https?://www\\.zdf\\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\\.html'
    assert ZDFIE._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert ZDFIE._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'
    assert ZDFIE._TESTS[0]['info_dict']['id'] == '210222_phx_nachgehakt_corona_protest'
    assert ZDFIE._TESTS

# Generated at 2022-06-26 13:29:27.257843
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test with no arguments.
    ZDFBaseIE()
    # Test with regular arguments.
    ZDFBaseIE(url='http://zdftivi.de/')
    # Test with regular and language arguments.
    ZDFBaseIE(url='http://zdftivi.de/', ie='ZDFIE', default_language='en')



# Generated at 2022-06-26 13:29:36.449852
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    InfoExtractor()._call_api("http://www.zdf.de", "Test", "test")
    InfoExtractor()._extract_subtitles("{'captions': [{'language': 'deu', 'uri': 'http://www.zdf.com/captions.de'}]}")
    InfoExtractor()._extract_format("Video_ID", {}, {"http://www.zdf.de",}, {'url': "http://www.zdf.de", 'mimeCodec': "Codec", 'quality': "high"})
    ZDFBaseIE()._extract_ptmd("http://www.zdf.de/ptmd.json", "Video_ID", "api_token", "http://www.zdf.de/referrer")

# Generated at 2022-06-26 13:29:37.938917
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE(InfoExtractor())._type() == 'zdf'

