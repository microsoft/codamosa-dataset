

# Generated at 2022-06-26 13:23:54.613723
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = "https://www.zdf.de/dokumentation/planet-e"
    channel_id = "planet-e"

    # Test the web page download
    webpage = z_d_f_channel_i_e_0._download_webpage(url, channel_id)
    assert z_d_f_channel_i_e_0._og_search_title(webpage, fatal=False) is not None



# Generated at 2022-06-26 13:23:55.577643
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert_raises(RegexNotFoundError, test_case_0)


# Generated at 2022-06-26 13:23:57.392276
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert test_case_0() == None

# Generated at 2022-06-26 13:23:58.565862
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:23:59.343559
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-26 13:24:00.447705
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e = ZDFBaseIE()


# Generated at 2022-06-26 13:24:02.820740
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    print('Testing constructor of class ZDFChannelIE')
    z_d_f_channel_i_e_0 = ZDFChannelIE()
    assert z_d_f_channel_i_e_0.test_test() == 'test_test'


# Generated at 2022-06-26 13:24:05.730126
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e = ZDFBaseIE()
    assert z_d_f_base_i_e._GEO_COUNTRIES == ['DE']



# Generated at 2022-06-26 13:24:08.407341
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        z_d_f_base_i_e = ZDFBaseIE()
    except:
        assert False, 'Constructor of ZDFBaseIE class is not working'


# Generated at 2022-06-26 13:24:10.558214
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    return ZDFChannelIE()


# Generated at 2022-06-26 13:25:01.691285
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    try:
        # Check if NameError raised when vars_dict not given
        ZDFIE(re.compile(r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'), {}, 'ZDFIE', {})
    except Exception as e:
        if 'NameError' not in str(e):
            raise Exception('Unexpected Exception when vars_dict not given:{}, type:{}'.format(e, type(e)))


# Generated at 2022-06-26 13:25:03.025140
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e = ZDFBaseIE()
    test_case_0()


# Generated at 2022-06-26 13:25:07.405642
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # (class) ZDFBaseIE()
    assert (ZDFBaseIE()
        .ie_key() == 'ZDFBaseIE'
        ._GEO_COUNTRIES == ['DE']
        ._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
        )


# Generated at 2022-06-26 13:25:09.721068
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    z_d_f_base_i_e_0 = ZDFBaseIE()

# Unit tests for ZDFBaseIE.extract_info

# Generated at 2022-06-26 13:25:11.495170
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info_extractor = ZDFBaseIE()


# Generated at 2022-06-26 13:25:13.150908
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_ZDFBaseIE = ZDFBaseIE()

# Generated at 2022-06-26 13:25:14.800704
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert isinstance(ZDFIE, object)


# Generated at 2022-06-26 13:25:16.043211
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:25:17.309193
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:25:27.270444
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Set the testing URL to the website of ZDF
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    z_d_f_channel_i_e = ZDFChannelIE()
    z_d_f_channel_i_e._real_extract(url)
    # print(z_d_f_channel_i_e.suitable(url)) # Uncomment this line to test this function
    # print(z_d_f_channel_i_e.ie_key()) # Uncomment this line to test this function
    # print(z_d_f_channel_i_e.IE_NAME) # Uncomment this line to test this function
    # print(z_d_f_channel_i_e.IE_DESC) # Uncomment this

# Generated at 2022-06-26 13:26:59.243452
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()

# Generated at 2022-06-26 13:27:04.305418
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Case #0
    test_case_0()

    # Case #1
    # This test case raises an exception (cannot find the required regex)
    # TODO: Find a way to resolve this
    #z_d_f_base_i_e_1 = ZDFBaseIE()


# Generated at 2022-06-26 13:27:08.410426
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    video_id = 'kollegen'
    info_extractor = ZDFBaseIE(ZDFIE)

    assert info_extractor._downloader is not None
    assert info_extractor._TYPE == 'video'
    assert info_extractor._GEO_COUNTRIES is not None
    assert info_extractor._QUALITIES is not None


# Generated at 2022-06-26 13:27:11.006277
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:27:12.890730
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert(ZDFChannelIE)


# Generated at 2022-06-26 13:27:14.482226
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()


# Generated at 2022-06-26 13:27:15.809548
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    ie.ie_key()


# Generated at 2022-06-26 13:27:26.463715
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    u = ZDFIE._build_url_result(
        "https://www.zdf.de/nachrichten/heute-journal/heute-journal-vom-10-februar-2021-100.html")
    assert u['id'] == "210209_hjournal_2100"
    assert u['url'] == "https://www.zdf.de/nachrichten/heute-journal/heute-journal-vom-10-februar-2021-100.html"
    assert u['title'] == "Heute Journal Vom 10. Februar 2021"
    assert u['description'] == "Nachrichten, Wetter, Sport, Börse,Sondersendungen(z. B. ARD- und ZDF-Talkrunden) - Die" \
                              

# Generated at 2022-06-26 13:27:27.439435
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()


# Generated at 2022-06-26 13:27:31.196864
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e = ZDFChannelIE()
    assert z_d_f_channel_i_e.ie_key() == 'ZDFChannel'
    assert z_d_f_channel_i_e.playlist_result() == True


# Generated at 2022-06-26 13:29:23.653309
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        assert ZDFBaseIE
    except NameError:
        raise NameError('No class named ZDFBaseIE in zdf.py')


# Generated at 2022-06-26 13:29:26.603738
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE._GEO_COUNTRIES = ['AD']
    ZDFIE._QUALITIES = ['auto', 'low', 'med', 'high', 'veryhigh', 'hd']

test_ZDFIE()


# Generated at 2022-06-26 13:29:28.445456
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    channel = ZDFChannelIE().suitable(url)
    assert channel == True


# Generated at 2022-06-26 13:29:30.049202
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    IE = ZDFBaseIE()
    print("ZDFBaseIE instance created successfully")


# Generated at 2022-06-26 13:29:31.662929
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdfChannelIE = ZDFChannelIE()
    assert(zdfChannelIE is not None)



# Generated at 2022-06-26 13:29:34.112955
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE('https://www.zdf.de/sport/das-aktuelle-sportstudio', {})


# Generated at 2022-06-26 13:29:35.721389
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE("zdf", "www.zdf.de", {})


# Generated at 2022-06-26 13:29:39.929939
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    """Test the constructor of class ZDFBaseIE"""
    ie = ZDFBaseIE(None)
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:29:41.134256
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf is not None


# Generated at 2022-06-26 13:29:48.894610
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    url_1 = "http://www.zdf.de/ZDFmediathek/beitrag/video/2197154/Die-Massai---Von-den-W%C3%BCstenfuersten-zum-Weltvolk#/beitrag/video/2197154/Die-Massai---Von-den-W%C3%BCstenfuersten-zum-Weltvolk"
    url_2 = "http://between-us-der-film.zdf.de/"
    url_3 = "http://www.zdf.de/ZDFmediathek/kanaluebersicht/aktuellste/14246#xtor=CS3-63"