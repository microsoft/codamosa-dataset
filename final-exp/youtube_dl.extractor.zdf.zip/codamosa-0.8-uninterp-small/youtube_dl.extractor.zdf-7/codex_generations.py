

# Generated at 2022-06-26 13:23:49.678998
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()



# Generated at 2022-06-26 13:23:53.290669
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()

if __name__ == '__main__':
    test_case_0()
    test_ZDFChannelIE()

# Generated at 2022-06-26 13:23:54.300775
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_i_e_1 = ZDFChannelIE()

# Generated at 2022-06-26 13:23:55.772355
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Class testing for ZDFIE
    test_case_0()



# Generated at 2022-06-26 13:23:57.311423
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e = ZDFIE()


# Generated at 2022-06-26 13:23:58.532547
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:24:00.893843
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    print('Testing constructor.')

    try:
        ZDFBaseIE()
    except:
        print('Construction failed miserably!')

    print('Construction successful.\n')


# Generated at 2022-06-26 13:24:04.490051
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-26 13:24:07.160576
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE._GEO_COUNTRIES == ['DE']
    assert ZDFBaseIE._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:24:08.131547
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    test_case_0()


# Generated at 2022-06-26 13:24:42.821006
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    assert zdf._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdf._GEO_COUNTRIES == ['DE']

# Generated at 2022-06-26 13:24:45.266013
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf_base_ie = ZDFBaseIE()
    assert zdf_base_ie is not None


# Generated at 2022-06-26 13:24:46.527189
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE.suitable(ZDFIE.suitable(ZDFIE.suitable(None)))

# Generated at 2022-06-26 13:24:48.126758
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert isinstance(ZDFIE(ZDFBaseIE), ZDFBaseIE)


# Generated at 2022-06-26 13:24:57.417996
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE._VALID_URL == 'https?://www\\.zdf\\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\\.html'

# Generated at 2022-06-26 13:24:58.948816
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    zdf_ie.runTests()


# Generated at 2022-06-26 13:25:03.838165
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()._extract_regular('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html',
                             {'content': 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html',
                              'apiToken': 'aeb8fe52d15b4c63b125098b5f8c1f2f'},
                             'wohin-fuehrt-der-protest-in-der-pandemie-100')

# Generated at 2022-06-26 13:25:08.843504
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ydl = YoutubeDL({'noplaylist': True, 'nocheckcertificate': True})
    ie = ZDFChannelIE(ydl)
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e/')
    assert ie.suitable('https://www.zdf.de/dokumentation/planet-e/') is False



# Generated at 2022-06-26 13:25:11.613350
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf_ie = ZDFIE()
    zdf_ie.ie_key()


# Generated at 2022-06-26 13:25:13.966449
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE('https://www.zdf.de/nachrichten/politik/zdf-trendbarometer-100.html')

# Generated at 2022-06-26 13:26:06.830064
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    my_ZDFChannelIE = ZDFChannelIE('https://www.zdf.de/sport')
    assert my_ZDFChannelIE.suitable('https://www.zdf.de/')


# Generated at 2022-06-26 13:26:12.788369
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/politik/heute-show/heute-show-videos'
    ie = ZDFChannelIE(url)
    # ie should be instance of class ZDFChannelIE
    assert(isinstance(ie, ZDFChannelIE))
    # ie.channel_id should be set to not None and equal to 'heute-show-videos'
    assert(ie.channel_id is not None)
    assert(ie.channel_id == 'heute-show-videos')
    # ie.item_ids should be set to empty list
    assert(isinstance(ie.item_ids, list))
    assert(len(ie.item_ids) == 0)
    # ie.item_ids should not be None
    assert(ie.item_ids is not None)
    # url = 'https://

# Generated at 2022-06-26 13:26:25.976559
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/serien/das-adlon-eine-familiensaga'
    _url_test = 'https://www.zdf.de/serien/das-adlon-eine-familiensaga/das-adlon-eine-familiensaga-folge-3-100.html'
    _title_test = 'Das Adlon. Eine Familiensaga'

    assert ZDFChannelIE(url)._VALID_URL == ZDFChannelIE.VALID_URL
    assert ZDFChannelIE(url)._TESTS[0]['url'] == url
    assert ZDFChannelIE(url).suitable(url) == True
    assert ZDFChannelIE(url)._real_extract(url) is not None
    # assert ZDFChannel

# Generated at 2022-06-26 13:26:26.594992
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
  return ZDFIE()



# Generated at 2022-06-26 13:26:28.921754
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_url = 'https://www.zdf.de/dokumentation/planet-e'
    zdf_channel_ie = ZDFChannelIE(channel_url)
    assert zdf_channel_ie.is_suitable()



# Generated at 2022-06-26 13:26:33.486429
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    # Test URL that should return an instance of this class IE
    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert ie.suitable(url)
    # Test URL that should not return an instance of this class IE
    url = 'https://www.zdf.de/dokumentation/planet-e/planet-e-uebersichtsseite-weitere-dokumentationen-von-planet-e-100.html'
    assert not ie.suitable(url)

# Generated at 2022-06-26 13:26:37.817951
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test to create object ZDFBaseIE
    ZDFBaseIE = ZDFBaseIE(compat_str('test'))

    # Test if object is instance of InfoExtractor
    assert isinstance(ZDFBaseIE, InfoExtractor)

# Generated at 2022-06-26 13:26:40.004808
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE()
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)(\?(?:.+))?'


# Generated at 2022-06-26 13:26:44.935994
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE()
    instance._GEO_COUNTRIES
    instance._QUALITIES
    instance._call_api
    instance._extract_subtitles
    instance._extract_format
    instance._extract_ptmd
    instance._extract_player

test_ZDFBaseIE()

# Generated at 2022-06-26 13:26:49.167628
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'


# Generated at 2022-06-26 13:28:39.490463
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    result = ZDFIE()
    assert result.ie_key() == 'ZDF'
    assert result.ie_name() == 'zdf'
    assert result.ie_description() == 'Zweites Deutsches Fernsehen'

# Generated at 2022-06-26 13:28:44.031849
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    zdf_channel_ie.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio')
    zdf_channel_ie._real_extract('https://www.zdf.de/dokumentation/planet-e')



# Generated at 2022-06-26 13:28:46.107294
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdfBaseIE = ZDFBaseIE()
    assert zdfBaseIE is not None


# Generated at 2022-06-26 13:28:50.365563
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE('download', 'http://zdf.de/%s' % '123456789')
    ZDFBaseIE('download', 'http://zdf.de/%s' % '123456789', 'de', 'DE')



# Generated at 2022-06-26 13:28:51.192501
# Unit test for constructor of class ZDFIE
def test_ZDFIE():ZDFIE()


# Generated at 2022-06-26 13:28:57.009647
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    zdf.geo_countries = ['DE']
    zdf.qualities = orderedSet(('auto', 'low', 'med', 'high', 'veryhigh', 'hd'))
    zdf.thumbnailIds = [
        'url',
        'format_id',
        'width', 'height']
    zdf.extract('')



# Generated at 2022-06-26 13:29:04.101940
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    instance = ZDFChannelIE()
    assert instance._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 13:29:11.309782
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # test_ZDFBaseIE has no 'self' parameter
    # pylint:disable = E0213
    # The number of positional arguments for instance of class ZDFBaseIE are
    # correct.
    # pylint:disable = W0212
    # Instance of class ZDFBaseIE is created successfully.
    # pylint:disable = E1102
    ZDFBaseIE(None)



# Generated at 2022-06-26 13:29:13.063417
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert 'ZDFBaseIE' == ie.ie_key()


# Generated at 2022-06-26 13:29:14.448489
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    import doctest
    doctest.testmod()


