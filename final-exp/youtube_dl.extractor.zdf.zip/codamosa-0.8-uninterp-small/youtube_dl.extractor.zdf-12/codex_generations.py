

# Generated at 2022-06-26 13:23:52.848399
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-26 13:23:54.305655
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:23:55.723020
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE.__name__  == 'ZDFBaseIE'



# Generated at 2022-06-26 13:23:58.301756
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()


# Generated at 2022-06-26 13:23:59.643835
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    z_d_f_channel_i_e_0 = ZDFChannelIE()


# Generated at 2022-06-26 13:24:01.502326
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    """Unit test for ZDFChannelIE"""
    # Construct an instance of ZDFChannelIE
    z_d_f_channel_i_e = ZDFChannelIE()


# Generated at 2022-06-26 13:24:03.893341
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    # Instantiate an object of class ZDFIE
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:24:05.243778
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:24:06.554332
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e = ZDFIE()



# Generated at 2022-06-26 13:24:08.176319
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
        # zdfBaseIE = ZDFBaseIE()
    zdfBaseIE = ZDFBaseIE()


# Generated at 2022-06-26 13:24:42.118979
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE(ZDFIE._downloader, "https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html")
    ZDFIE(ZDFIE._downloader, "https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html")
    ZDFIE(ZDFIE._downloader, "https://www.zdf.de/wissen/nano/nano-21-mai-2019-102.html")
    ZDFIE(ZDFIE._downloader, "https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html")

# Generated at 2022-06-26 13:24:44.734620
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel_ie = ZDFChannelIE()
    channel_id = channel_ie._match_id(
        "https://www.zdf.de/dokumentation/planet-e")
    assert channel_id == 'planet-e'

# Generated at 2022-06-26 13:24:45.944370
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert(ZDFIE.ie_key() == 'ZDF')


# Generated at 2022-06-26 13:24:49.859233
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .tests import list_test_data
    from .zdf import ZDFBaseIE
    from .zdf import ZDFChannelIE
    
    # Test if ZDFChannelIE can be instantiated
    for test_url in list_test_data():
        if re.match(ZDFChannelIE._VALID_URL, test_url):
            print(test_url)
            try:
                ZDFChannelIE()(test_url)
            except Exception as err:
                print(err)
    return


# Generated at 2022-06-26 13:24:54.541496
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/dokumentation/planet-e'
    ie = ZDFChannelIE.suitable(url)

    assert ie.__class__ is ZDFChannelIE
    assert ie.SUITABLE is True
    assert ie.IE_NAME == 'zdf:channel'

    ie = ZDFChannelIE(url)
    entries = ie.extract('zdf-dokumentation-planet-e')

    assert entries['id'] == 'planet-e'
    assert entries['title'] == 'planet e.'
    assert len(entries['entries']) > 50

    url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie = ZDFChannelIE.suitable(url)

    assert ie.__class__ is Z

# Generated at 2022-06-26 13:24:59.874077
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from .test_ZDFIE import ZDFIE_TESTS

    for d in ZDFIE_TESTS:
        url = d.get('url')
        if not url:
            continue
        url = url.replace('media.zdf.de', 'www.zdf.de')
        url = url.replace('www.3sat.de', 'www.zdf.de')
        url = re.sub(r'/[^/]+-\d+\.html$', '', url)
        if not re.search(r'/(?:[^/]+/)*[^/?#&]+\.html$', url):
            url += '/%s.html' % d.get('id')
        ie = ZDFChannelIE()
        _, _, channel_id = ie._extract_url_result(url)
       

# Generated at 2022-06-26 13:25:04.883706
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Parameter 'p' is only a placeholder to test the constructor
    test = ZDFChannelIE(p)
    assert test.suitable('https://www.zdf.de/filme/taunuskrimi/') is False
    assert test.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') is True
    assert test.suitable('https://www.zdf.de/dokumentation/planet-e') is True


# Generated at 2022-06-26 13:25:11.092112
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    module = importlib.import_module(ZDFChannelIE.__module__)
    page = 'https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html'
    result = module.ZDFChannelIE._extract_player('', '', page)
    assert result['apiToken'] == 'f3e2d2f9c9'

# Generated at 2022-06-26 13:25:15.665925
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    assert type(ie) == ZDFBaseIE

test_ZDFBaseIE()


# Generated at 2022-06-26 13:25:19.982877
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/politik/frontal-21/sendung-vom-26-april-2016-100.html')

# Generated at 2022-06-26 13:26:12.606503
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')
    # assert ie._extract_subtitles()

# Generated at 2022-06-26 13:26:14.041659
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()


# Generated at 2022-06-26 13:26:15.496337
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE is not None

# test for _extract_ptmd

# Generated at 2022-06-26 13:26:27.900873
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    video_id = 'e8acb2cbebe549f69c63d0d39366a6bc'
    webpage = 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'

# Generated at 2022-06-26 13:26:34.059061
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url = 'https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html'
    ZDFChannelIE._download_webpage = lambda self, url, video_id: url
    ZDFChannelIE._extract_player = lambda self, url, video_id, fatal=True: url
    ZDFChannelIE.suitable = lambda cls, url: True
    ie = ZDFChannelIE()
    result = ie.url_result(url)
    assert result['_type'] == 'url', 'Extract URL of video'
    assert result['url'] == 'https://www.zdf.de/filme/taunuskrimi/', 'Extract URL of channel'



# Generated at 2022-06-26 13:26:34.753197
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    assert ZDFIE()


# Generated at 2022-06-26 13:26:40.925252
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfie = ZDFIE(ZDFIE.ie_key())
    assert zdfie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'

# Generated at 2022-06-26 13:26:45.075864
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base = ZDFBaseIE()
    assert base._GEO_COUNTRIES == ['DE']
    assert base._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-26 13:26:51.795370
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    url_1='https://www.zdf.de/sport/das-aktuelle-sportstudio'
    ie_1=ZDFChannelIE(url_1)
    assert ie_1._match_id(url_1)=='das-aktuelle-sportstudio'

# Generated at 2022-06-26 13:26:55.715921
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zdf = ZDFBaseIE()
    assert zdf is not None
    assert zdf._GEO_COUNTRIES == ['DE']
    assert zdf._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-26 13:29:00.134640
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.ie_key() == 'zdf'
    assert ie.ie_name() == 'ZDF'
    assert isinstance(ie.http_headers(), dict)
    assert isinstance(ie.host(), compat_str)
    assert isinstance(ie.extract_id(ie.test_url()), compat_str)
    assert isinstance(ie.get_urls(ie.test_url()), list)
    assert isinstance(ie._search_regex(ie.test_url()), tuple)
    assert isinstance(ie.suitable(ie.test_url()), bool)
    assert isinstance(ie._real_extract(ie.test_url()), dict)
    assert ie.IE_NAME == 'zdf'
    assert ie._VALID_URL == ie.VAL

# Generated at 2022-06-26 13:29:05.631149
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    zbfie = ZDFBaseIE()
    zbfie._init_column('_GEO_COUNTRIES')
    zbfie._init_column('_QUALITIES')
    assert zbfie._GEO_COUNTRIES == ['DE']
    assert zbfie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-26 13:29:10.853845
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    i = ZDFBaseIE()
    assert i._GEO_COUNTRIES == ['DE']
    assert i._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:29:12.553610
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert(ZDFBaseIE.__bases__[0] == InfoExtractor)


# Generated at 2022-06-26 13:29:14.354081
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    obj = ZDFBaseIE()
    assert isinstance(obj, InfoExtractor)


# Generated at 2022-06-26 13:29:22.593780
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    for url in [
        'https://www.zdf.de/sport/das-aktuelle-sportstudio',
        'https://www.zdf.de/dokumentation/planet-e',
        'https://www.zdf.de/politik/phoenix-sendungen/die-gesten-der-maechtigen-100.html',
        'https://www.zdf.de/filme/taunuskrimi/',
    ]:
        print('url: ', url)
        ie = ZDFChannelIE()
        test_items = ie._real_extract(url)
        if not test_items:
            print('ZDFChannelIE can not parse this url: ', url)
            continue
        print('ZDFChannelIE parse ok!')
        print(test_items)

# Generated at 2022-06-26 13:29:26.399466
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    info_extractor = ZDFBaseIE('http://nocookie.net/', {})
    assert info_extractor._GEO_COUNTRIES == ['DE']
    assert info_extractor._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-26 13:29:35.125283
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdfIE = ZDFIE()
    assert zdfIE._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)\.html'
    assert zdfIE.IE_NAME == 'zdf'
    assert zdfIE.ie_key() == 'ZDF'
    assert zdfIE._TESTS[0]['url'] == 'https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'
    assert zdfIE._TESTS[0]['md5'] == '34ec321e7eb34231fd88616c65c92db0'

# Generated at 2022-06-26 13:29:36.252429
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    unit = ZDFIE()
    assert unit


# Generated at 2022-06-26 13:29:38.065769
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    try:
        ZDFBaseIE()
    except Exception as e:
        return False
    return True
