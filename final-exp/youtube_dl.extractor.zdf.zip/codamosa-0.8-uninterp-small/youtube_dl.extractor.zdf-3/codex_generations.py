

# Generated at 2022-06-26 13:23:51.427123
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE()


# Generated at 2022-06-26 13:23:52.906253
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass


# Generated at 2022-06-26 13:24:02.855394
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert ZDFBaseIE()._GEO_COUNTRIES == ['DE'], \
        "Class ZDFBaseIE has failed test #0"
    assert ZDFBaseIE()._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd'), \
        "Class ZDFBaseIE has failed test #1"
    # Testing method call for _call_api(self, url, video_id, item, api_token=None, referrer=None)
    # of class ZDFBaseIE
    # TODO: build exception test
    # TODO: build exception test
    # TODO: validate return type
    # TODO: validate return type
    # Testing method call for _extract_subtitles(src)
    # of class ZDFBaseIE
    # TODO: build exception test
    # TOD

# Generated at 2022-06-26 13:24:03.957113
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    test_case_0()

# Generated at 2022-06-26 13:24:04.406371
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    pass

# Generated at 2022-06-26 13:24:13.510665
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from yturl import ZDFChannelIE
    assert ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'), 'https://www.zdf.de/sport/das-aktuelle-sportstudio is a valid youtube URL'
    assert ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/planet-e'), 'https://www.zdf.de/dokumentation/planet-e is a valid youtube URL'
    assert ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/'), 'https://www.zdf.de/filme/taunuskrimi/ is a valid youtube URL'

# Generated at 2022-06-26 13:24:19.565109
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    assert hasattr(ZDFBaseIE, '_GEO_COUNTRIES')
    assert hasattr(ZDFBaseIE, '_QUALITIES')
    assert isinstance(ZDFBaseIE._GEO_COUNTRIES, list)
    assert isinstance(ZDFBaseIE._QUALITIES, tuple)


# Generated at 2022-06-26 13:24:23.703110
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    print("Start unit test for ZDFBASEIE")
    z_d_f_base_i_e_0 = ZDFBaseIE()
    print("End unit test for ZDFBASEIE")

# Generated at 2022-06-26 13:24:25.572640
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e_0 = ZDFIE()


# Generated at 2022-06-26 13:24:27.015086
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    z_d_f_i_e = ZDFIE()


# Generated at 2022-06-26 13:24:54.698232
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE(None)
    assert ie.IE_NAME == 'zdf:channel'
    assert ie.ie_key() == 'ZDFChannel'
    assert ie.channel_code() == 'channel'



# Generated at 2022-06-26 13:25:00.017379
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from unittest.mock import patch

    test_url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    test_html = '<html><body></body></html>'

    with patch('youtube_dl.extractor.zdf.ZDFBaseIE.test.test_constructor.ZDFChannelIE.suitable') as mock_suitable:
        with patch('youtube_dl.extractor.zdf.ZDFBaseIE.test.test_constructor.ZDFChannelIE._download_webpage') as mock_download_webpage:
            with pytest.raises(ExtractorError) as err:
                ZDFChannelIE()(test_url)

    assert err.value.args[0] == 'URL is not a ZDF channel: %s' % test

# Generated at 2022-06-26 13:25:02.036666
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ie = ZDFBaseIE()
    assert ie._GEO_COUNTRIES == ['DE']
    assert ie._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:25:12.099388
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    from . import gen_extractor_test
    from .common import list_extractors

    def _extract_channel_id(page_url, page_text, expected_id):
        for ie_cls in list_extractors():
            if not issubclass(ie_cls, ZDFChannelIE):
                continue

            ie = ie_cls()
            extracted_id = ie._match_id(page_url)
            assert extracted_id == expected_id

    # downloader/http.py uses 'utf-8' as default encoding
    zdf_page = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    zdf_page_encoded = zdf_page.encode('utf-8')

# Generated at 2022-06-26 13:25:17.659286
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    from .test import get_testcases
    from .test import check_extractors
    from .test import list_extractors
    from . import ZDFIE
    testcases = get_testcases(ZDFIE)
    check_extractors(ZDFIE, testcases)
    list_extractors(ZDFIE)


# Create tesing tools for IE ZDFIE
# test_ZDFIE()

# Generated at 2022-06-26 13:25:19.547828
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Constructor of class ZDFBaseIE
    ZDFBaseIE()



# Generated at 2022-06-26 13:25:20.168146
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ZDFChannelIE()

# Generated at 2022-06-26 13:25:23.060164
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    x = ZDFBaseIE()
    assert x._extract_player(None, None) == {}
    assert len(x._QUALITIES) == 6


# Generated at 2022-06-26 13:25:27.942639
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/') is False
    assert zdf_channel_ie.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html') is True

# Generated at 2022-06-26 13:25:29.314627
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    base_ie_test = ZDFBaseIE(None)
    assert base_ie_test._GEO_COUNTRIES == ['DE']
    assert base_ie_test._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')



# Generated at 2022-06-26 13:26:21.516720
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    ZDFBaseIE()


# Generated at 2022-06-26 13:26:23.446552
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ZDFIE.suite(lambda : None)()


# Generated at 2022-06-26 13:26:24.611560
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()

# Generated at 2022-06-26 13:26:28.462355
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    instance = ZDFBaseIE('ZDFBaseIE', 'zdf.de')
    assert instance.ie_key() == 'ZDFBaseIE'
    assert instance._GEO_COUNTRIES == ['DE']
    assert instance._QUALITIES == ('auto', 'low', 'med', 'high', 'veryhigh', 'hd')


# Generated at 2022-06-26 13:26:28.939266
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    pass


# Generated at 2022-06-26 13:26:31.928900
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    channel = ZDFChannelIE("https://www.zdf.de/sport/das-aktuelle-sportstudio")
    assert channel.__class__ == ZDFChannelIE
    assert channel._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 13:26:33.137711
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    zdf = ZDFIE()
    zdf.test()

test_ZDFIE()

# Generated at 2022-06-26 13:26:36.821219
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    class random_subclass(ZDFIE):
        def __init__(self, *args, **kwargs):
            super(random_subclass, self).__init__(*args, **kwargs)

    assert random_subclass.__name__ == 'random_subclass'
    assert ZDFIE.__name__ == 'ZDFIE'
    assert random_subclass.ie_key() == 'ZDF'
    assert ZDFIE.ie_key() == 'ZDF'


# Generated at 2022-06-26 13:26:40.084371
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Test a basic construction of class ZDFBaseIE
    ZDFBaseIE()


# Generated at 2022-06-26 13:26:42.965972
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    IE = ZDFBaseIE
    assert IE._GEO_COUNTRIES.sort() == ['DE'].sort()
    assert isinstance(IE._QUALITIES, tuple)


# Generated at 2022-06-26 13:28:46.901148
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    ie = ZDFIE()
    assert ie.suitable('https://www.zdf.de/dokumentation/terra-x/die-magie-der-farben-von-koenigspurpur-und-jeansblau-100.html')
    assert ie.suitable('https://www.zdf.de/filme/filme-sonstige/der-hauptmann-112.html')
    assert ie.suitable('https://www.zdf.de/service-und-hilfe/die-neue-zdf-mediathek/zdfmediathek-trailer-100.html')
    assert ie.suitable('https://www.zdf.de/wissen/nano/nano-21-mai-2019-102.html')

# Generated at 2022-06-26 13:28:50.124573
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    assert ZDFChannelIE._VALID_URL
    assert ZDFChannelIE._TESTS
    assert ZDFBaseIE.suitable



# Generated at 2022-06-26 13:28:52.145481
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    # Just test if the constructor raises no exception
    ZDFBaseIE('ZDFBaseIE')


# Generated at 2022-06-26 13:29:01.394033
# Unit test for constructor of class ZDFBaseIE
def test_ZDFBaseIE():
    class TestZDFBaseIE(ZDFBaseIE):
        IE_NAME = 'test'
        _VALID_URL = r'https?://example\.com/path/to/%s'

# Generated at 2022-06-26 13:29:04.846823
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest
    from . import ie_tests

    class TestZDFChannelIE(ie_tests.ZDFIE):
        IE = ZDFChannelIE

        def test_url(self, url):
            if not url.endswith('.html'):
                return self.test_info_extraction(url)

    return unittest.TestLoader().loadTestsFromTestCase(TestZDFChannelIE)



# Generated at 2022-06-26 13:29:09.888569
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    # Testing a channel which contains items from both regular and mobile API
    # (https://www.zdf.de/sport/das-aktuelle-sportstudio)
    zdf_channel_ie = ZDFChannelIE()
    assert zdf_channel_ie.ie_key() == 'ZDFChannel'

    zdf_channel_ie_url = 'https://www.zdf.de/sport/das-aktuelle-sportstudio'
    assert zdf_channel_ie.suitable(zdf_channel_ie_url)
    assert zdf_channel_ie.extract(zdf_channel_ie_url)['playlist_mincount'] == 23

    # Testing a channel which contains items only from regular API
    # (https://www.zdf.de/dokumentation/planet

# Generated at 2022-06-26 13:29:16.176439
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    ie = ZDFChannelIE('https://www.zdf.de/filme/taunuskrimi/')
    assert ie._VALID_URL == r'https?://www\.zdf\.de/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'ZDF:channel'
    assert ie.IE_DESC == 'ZDF Mediathek'
    assert ie.ie_key() == 'ZDF:channel'



# Generated at 2022-06-26 13:29:24.384916
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    import unittest

    class TestZDFChannel(unittest.TestCase):
        def test_suitable(self):
            self.assertFalse(ZDFChannelIE.suitable('https://www.zdf.de/politik/phoenix-sendungen/wohin-fuehrt-der-protest-in-der-pandemie-100.html'))
            self.assertTrue(ZDFChannelIE.suitable('https://www.zdf.de/dokumentation/ab-18/10-wochen-sommer-102.html'))
            self.assertTrue(ZDFChannelIE.suitable('https://www.zdf.de/sport/das-aktuelle-sportstudio'))

# Generated at 2022-06-26 13:29:31.062280
# Unit test for constructor of class ZDFIE
def test_ZDFIE():
    class TestZDFIE(ZDFIE):
        def _real_extract(self, url):
            return self._extract_mobile("-test-")

    expected_info = {
        'id': '-test-',
        'ext': 'mp4',
        'title': '-test-',
        'description': '-test-',
        'duration': 0,
        'extractor_key': 'ZDF',
    }
    expected_formats = [{'url': '-test-', 'format_id': 'http-http', 'protocol': 'm3u8_native', 'ext': 'mp4'},
                        {'url': '-test-', 'format_id': 'http-http', 'ext': 'mp4'}]

# Generated at 2022-06-26 13:29:37.202287
# Unit test for constructor of class ZDFChannelIE
def test_ZDFChannelIE():
    global ZDFChannelIE
    ZDFChannelIE = ZDFChannelIE()
    assert ZDFChannelIE.suitable('http://www.zdf.de/sport/das-aktuelle-sportstudio')
    assert not ZDFChannelIE.suitable('https://www.zdf.de/filme/taunuskrimi/die-lebenden-und-die-toten-1---ein-taunuskrimi-100.html')