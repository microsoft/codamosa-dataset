

# Generated at 2022-06-21 02:05:53.809278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict(module='fail', args=dict(msg='foobarbaz'))),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert module._connection== dict()
    assert module._play_context== dict()
    assert module._loader == dict()
    assert module._templar == dict()
    assert module._shared_loader_obj == dict()

# Generated at 2022-06-21 02:05:58.760014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action = ActionModule()
    assert test_action.TRANSFERS_FILES == False
    assert test_action._VALID_ARGS == frozenset(('msg',))

# Generated at 2022-06-21 02:06:04.723825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(None, dict(), dict())
    assert actionModule.run() == dict(
        failed=True,
        msg='Failed as requested from task'
    )

    actionModule = ActionModule(None, dict(msg='message'), dict())
    assert actionModule.run() == dict(
        failed=True,
        msg='message'
    )

# Generated at 2022-06-21 02:06:05.989103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-21 02:06:08.515136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')
    assert isinstance(ActionModule.run, object)

# Generated at 2022-06-21 02:06:16.966917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action

    # create an instance of the action module, of class ActionModule
    action_module = action.ActionModule(None, None, None, None, None, None, False, None, None)

    # create an instance of the result class
    result = action.Result(None, None)

    # expected result of the unit test
    expected = {'failed': True, 'msg': "Failed as requested from task"}

    # call the method run of the action module, passing the result
    result = action_module.run(None, None)

    # test that the result is as expected
    assert result == expected

# Generated at 2022-06-21 02:06:18.755613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = ActionModule()
    t._task.args = {'msg':'Failed as requested'}
    t._connection = {}
    print(t.run())

# Generated at 2022-06-21 02:06:24.572558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    from io import StringIO

    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out

        action = ActionModule()
        
        out = out.getvalue().strip()
        assert out == 'Failed as requested from task'
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-21 02:06:28.608431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:06:34.254773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import types
    def test_tmp():
        return None
    def test_var():
        a_dict = dict()
        a_dict['ansible_os_family'] = 'RedHat'
        a_dict['ansible_distribution'] = 'CentOS'
        a_dict['ansible_distribution_version'] = '4'
        return a_dict
    obj = ActionModule()
    obj.run(tmp=test_tmp, task_vars=test_var())
    assert isinstance(obj, types.InstanceType)

# Generated at 2022-06-21 02:06:38.067589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	assert True

# Generated at 2022-06-21 02:06:44.387293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

    test_action_module = action_loader.get('debug',
                                           class_only=True)

    test_task_queue_manager = TaskQueueManager(None, None, module_name='test_module',
                                               module_args='test_module_args',
                                               connection=None,
                                               play_context=None,
                                               loader=None,
                                               shared_loader_obj=None,
                                               terms=None,
                                               stdout_callback=None,
                                               run_tree=False)

    test_task_queue_manager._final_q = None

    test_action_module(test_task_queue_manager)

    assert test_

# Generated at 2022-06-21 02:06:45.180760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:06:45.998185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:06:57.592846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    # Test action module with msg provided
    action_module = ActionModule()
    action_module._task = {'args': {'msg': 'test_message'}}
    result = action_module.run(task_vars=task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'test_message'

    # Test action module without msg
    action_module = ActionModule()
    action_module._task = {'args': {}}
    result = action_module.run(task_vars=task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'Failed as requested from task'

# Generated at 2022-06-21 02:07:08.002512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule.
    """
    class Task(object):
        def __init__(self):
            self.args = { 'module_setup': True, 'tmp': None, 'task_vars': None }

    class PlayContext(object):
        def __init__(self):
            self.check_mode = False

    class Connection(object):
        def __init__(self):
            self.transport = 'local'

    class Play(object):
        def __init__(self):
            self.connection = Connection()

    class PlayBook(object):
        def __init__(self):
            self.remote_user = 'root'

    class PlaybookExecutor(object):
        def __init__(self):
            self.playbook = PlayBook()


# Generated at 2022-06-21 02:07:08.795253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:07:13.164989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ ActionModule: run tests """

    module = ActionModule()  # Instantiate ActionModule object
    result = module.run(None, None)  # Run the run method
    assert result['failed']

# Generated at 2022-06-21 02:07:21.772416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n\n")
    print("This test is not working.")
    print("\n\n")

    # Import modules
    import mock
    import sys
    import types
    import unittest

    # Get module
    sys.path.append("../")
    import action_plugins.fail

    # Define class to be tested
    class ActionModule_class(action_plugins.fail.ActionModule):
        ''' Class to be tested '''
        def __init__(self, task, connection, play_context, loader, templar,
                     shared_loader_obj):
            ''' Constructor '''
            self._task = task
            self._task.args = dict()
            self._task.args['msg'] = 'Message to display'

    # Define test

# Generated at 2022-06-21 02:07:27.730183
# Unit test for constructor of class ActionModule
def test_ActionModule():
	try:
		import ansible.plugins.action
	except ImportError:
		print("Error in importing ansible.plugins.action")

	try:
		from ansible.plugins.action import ActionBase
	except ImportError:
		print("Error in importing ActionBase from ansible.plugins.action")

	try:
		import ansible.plugins.action
	except ImportError:
		print("Error in importing ActionModule from ansible.plugins.action")

	print("Success importing required modules")


#Unit test for function run

# Generated at 2022-06-21 02:07:39.747663
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This is not a real test. Merely an example of running the constructor
    # and capturing parameters.
    action = ActionModule(
        task=dict(args=dict(msg='NO'))
    )
   # action = ActionModule()
    print("Task %s" % action._task)
    print("Task args %s" % action._task.args)
    print("Message %s" % action._task.args['msg'])
    #assert action._task.args['msg'] == "NO"

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:07:49.260508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    from ansible.vars.hostvars import HostVars

    play_context = PlayContext()
    task_vars = dict()
    task = Task()

    # test empty constructor of class ActionModule
    action_module = ActionModule(task, play_context, task_vars, C.DEFAULT_TRANSPORT, C.DEFAULT_BECOME_METHOD, C.DEFAULT_BECOME_USER, C.DEFAULT_BECOME_PASS)
    assert not action_module.DISPATCHER_ARGS == {}
    assert not action_module.DEFAULT_ARGS == {}

    # test method run

# Generated at 2022-06-21 02:07:56.156707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = {
        'action': {
            'module': 'fail',
            'args': {'msg': 'Failed as requested from task'}
        }
    }

    mock_inject = {} # mocker.patch('ansible.plugins.action.ActionBase._configure_module')

    mock_task_vars = {} # mocker.patch('ansible.plugins.action.ActionBase.get_task_vars')

    action_mod = ActionModule(task, mock_inject)

    action_mod.run(mock_task_vars)
    

# Generated at 2022-06-21 02:07:57.490890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:08:00.895600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    action_module = ActionModule()
    action_module._task = { 'args': {'msg': 'Failed'} }
    result = action_module.run()
    assert(result['failed'] is True)
    assert(result['msg'] == 'Failed')


# Generated at 2022-06-21 02:08:03.504534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    parameterDict = {}
    actionModule.run(parameterDict)

# Generated at 2022-06-21 02:08:12.916703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class PlaybookExecutorMock(object):
        def __init__(self):
            self.inventory = InventoryManager(loader=DataLoader())
            self.loader = DataLoader()
            self.options = None
            self.variable_manager = None
            self.extra_vars = load_extra_vars(loader=self.loader, options=self.options)

       

# Generated at 2022-06-21 02:08:19.021904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock module_utils/basic.py AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

    # Create a class that will be used by the AnsibleModule
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return {'msg': 'TestMsg'}

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    result = TestActionModule(module).run(None, None)

    assert result['msg'] == 'TestMsg'

# Generated at 2022-06-21 02:08:27.986935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    ansible_return_dict = {'ansible_facts': {u'os_family': u'RedHat'}, 'ansible_version': {u'major': 2, u'minor': 2, u'micro': 0, u'string': u'2.2.0.0', u'full': u'2.2.0.0', u'revision': 0, u'binary_suffix': False}, 'ansible_python_version': {u'major': 2, u'minor': 7, u'micro': 0, u'string': u'2.7.0', u'full': u'2.7.0', u'revision': 0}, 'ansible_processor_cores': 1, 'changed': True}
    

# Generated at 2022-06-21 02:08:32.127739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )


# Generated at 2022-06-21 02:08:49.393552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    from ansible.plugins.action import ActionModule

    _task = json.loads(b'{"action": {"__ansible_module__": "fixture"}, "arguments": {}}')
    _play_context = json.loads(b'{"become": false, "become_method": "sudo", "become_user": "root", "connection": "local", "diff": false}')
    action_plugin = ActionModule(task=_task, play_context=_play_context, new_stdin=None)
    action_plugin._shared_loader_obj = None
    action_plugin._task = _task
    action_plugin._task_vars = {}
    action_plugin._tmp = None
    action_plugin._loader = None
    action_plugin._connection = None

# Generated at 2022-06-21 02:08:52.946041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule._VALID_ARGS == frozenset(('msg',))

# Generated at 2022-06-21 02:08:55.538313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:09:00.529883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule(ActionBase)
    assert test.TRANSFERS_FILES == False
    assert test._VALID_ARGS == frozenset(('msg',))
    assert test.__doc__ == " Fail with custom message "

# Generated at 2022-06-21 02:09:01.920443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    print(a.run())

# Generated at 2022-06-21 02:09:08.004264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_ActionModule = ActionModule()
    # Initialize task object
    my_task = {}
    my_task['args'] = {'msg':'my message'}
    # Set it for my_ActionModule object
    my_ActionModule._task = my_task
    # Run module
    result = my_ActionModule.run()
    # Compare results
    assert (result['failed']==True and result['msg']=='my message')

# Generated at 2022-06-21 02:09:10.686274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule({'msg': 'Passed as requested from unit test'})
    assert m.run() == {
        'failed': False,
        'msg': 'Passed as requested from unit test',
        'skipped': False
    }

# Generated at 2022-06-21 02:09:15.301143
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:09:19.626113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 02:09:27.906282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    # Instantiate task and action module
    task = Task()
    action_module = ActionModule(task, {})

    # Create a fake ansible to test method run
    import ansible.constants as C
    import ansible.plugins.action as action
    import ansible.utils.template as template
    import ansible.utils.vars as vars
    import ansible.utils.loader as loader
    import ansible.utils.unicode as unicode

    fake_ansible = {
        'constants': C,
        'plugins': {'action': action},
        'utils': {'template': template, 'vars': vars, 'loader': loader, 'unicode': unicode}
    }

    # Monkey-patch ActionModule.run with fake ansible

# Generated at 2022-06-21 02:09:49.689689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()

    assert(type(action._VALID_ARGS) is frozenset)
    assert(action.TRANSFERS_FILES is False)

# Generated at 2022-06-21 02:09:53.370720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule._VALID_ARGS == frozenset(('msg',))


# Generated at 2022-06-21 02:09:56.100164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test #1 - method run of class ActionModule
    assert ActionModule(dict(), dict(msg='msg')).run() == dict(failed=True, msg='msg')

    # Unit test #2 - method run of class ActionModule
    assert ActionModule(dict(), dict()).run() == dict(failed=True, msg='Failed as requested from task')

# Generated at 2022-06-21 02:10:03.871214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {}
    args['msg'] = "Your message"

    task = {'args': args}
    a = ActionModule(task, None)
    b = a.run(task_vars={})

    print("test_ActionModule_run result:", b)

    assert ( b['msg'] == args['msg'])
    assert ( b['failed'] == True)

# Generated at 2022-06-21 02:10:07.637880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = { 'msg': 'Failed as requested from task' }
    module.run(None, None)
    assert module._result['msg'] == 'Failed as requested from task'
    assert module._result['failed'] == True

# Generated at 2022-06-21 02:10:08.490725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:10:16.911538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = DummyConnection("test.example.com")
    loader = DummyLoader()
    shared_loader_obj = DummySharedPluginLoaderObj()
    templar = Templar(loader=loader, variables={})
    task = DummyTask(args=dict())
    action = ActionModule(task, connection=host, templar=templar, shared_loader_obj=shared_loader_obj)
    result = action.run(tmp=None, task_vars={})
    assert("Failed as requested from task" == result['msg'])


# Generated at 2022-06-21 02:10:24.741678
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule('path_to_ansible_module', 'module_name', 'module_args')
  assert am.runner_path == 'path_to_ansible_module'
  assert am._task.action == 'module_name'
  assert am._task.args == 'module_args'



# Generated at 2022-06-21 02:10:29.626955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    tk = 'tk'
    ds = 'ds'
    task_vars = 'task_vars'
    tmp = 'tmp'
    am = ActionModule(tk, ds, tmp, task_vars)
    assert am.task == tk
    assert am.datastore == ds
    assert am.tmp == tmp
    assert am.task_vars == task_vars
    assert am.in_data == None
    assert am.no_log == False
    assert am.validate_incl == None
    assert am.playbook_basedir == None

# Generated at 2022-06-21 02:10:34.518541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    instance = ActionModule()
    instance._shared_loader_obj = 'bla'
    assert(instance.run() == {'failed': True, 'msg': 'Failed as requested from task'})


# Generated at 2022-06-21 02:11:19.761907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    
    # Create ansible objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/nonexistent'])

# Generated at 2022-06-21 02:11:29.367384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    a = ActionModule("test")
    print("test_ActionModule")
    a.TRANSFERS_FILES = False
    a._VALID_ARGS = frozenset(('msg',))
    print("test_ActionModule")
    assert a.TRANSFERS_FILES == False
    print("test_ActionModule")
    assert a._VALID_ARGS == frozenset(('msg',))
    print("test_ActionModule")


# Generated at 2022-06-21 02:11:30.193440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:11:41.496156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import mock
    import sys

    from ansible.plugins.action import ActionModule

    testConfig = open('tests/fixtures/inventory/dummy_config').read()


# Generated at 2022-06-21 02:11:51.815080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Starting Ctor test of class ActionModule")
    print("Test case 1:If action_module_get is passed as parameter instanciation should be successful")
    check = ActionModule()
    check1= ActionModule()
    check.get_module = 'action_module_get'
    check1.run = 'action_module_run'
    if check.get_module == 'action_module_get':
        print("Test case passed")
    else:
        print("Test case failed")
    print("Test case 2:If action_module_run is passed as parameter instanciation should be successful")
    if check1.run == 'action_module_run':
        print("Test case passed")
    else:
        print("Test case failed")

# Generated at 2022-06-21 02:12:01.235371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    t = Task()
    t.args = dict()
    t.args['msg'] = 'Failed as requested from task'
    t.action = 'fail'
    t.dep_chain = None
    t.upstream_task_names = ['task1', 'task2', 'task3']

    p = PlayContext()

    pb = ActionModule(t, p)
    result = pb.run(None, {'ignore_errors': False})
    assert result['failed'] == True


# Generated at 2022-06-21 02:12:03.449648
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_vars = {'varname1':'val1','varname2':'val2'}

    test_action_module = ActionModule(task_vars)

    assert test_action_module.TRANSFERS_FILES == False


# Generated at 2022-06-21 02:12:09.861106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    current_res = {
        'failed': False,
        'changed': False,
    }

    task = {'args': {}}

    module = ActionModule(task, {}, current_res)
    result = module.run({}, {})

    assert result['failed']
    assert result['msg'] == 'Failed as requested from task'
    assert result['changed'] == False


# Generated at 2022-06-21 02:12:10.612349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

# Generated at 2022-06-21 02:12:17.772221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    inst = ActionModule()
    assert inst.TRANSFERS_FILES == False, "ActionModule.TRANSFERS_FILES should be False"
    assert inst._VALID_ARGS == frozenset(('msg',)), "ActionModule._VALID_ARGS should be frozenset('msg')"


# Generated at 2022-06-21 02:14:04.284773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(action_base=ActionBase())
    msg = 'Failed as requested from task'
    action_module._task = { 'args': {'msg': msg } }
    result = action_module.run(tmp=None, task_vars=None)
    assert result['failed'] == True
    assert result['msg'] == msg

# Generated at 2022-06-21 02:14:05.713903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None)
    assert(action_module != None)

# Generated at 2022-06-21 02:14:09.668307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('msg',))

# Generated at 2022-06-21 02:14:20.195478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    
    
    
    host = Host("myhost")

# Generated at 2022-06-21 02:14:28.525820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible import errors
    from ansible.playbook import task
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    task_ds = dict(action=dict(module='win_ping'))
    play_context = dict(win_ping=dict())
    t = TaskInclude(task_ds, play_context)
    assert isinstance(t, TaskInclude)
    t._task.action = 'win_ping'
    t._task.args = dict(msg='This is a custom message')
    am = ActionModule(t, task_vars=dict(win_ping=dict()))

# Generated at 2022-06-21 02:14:39.177387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_list = [{'hostname': 'localhost', 'port': 22}]
    task_vars = {'inventory_hostname': 'localhost'}
    module_name = 'setup'
    task_args = {}

    # This is a mock object of class TaskExecutor
    task_executor = type('', (), {})()
    task_executor.get_host_list.return_value = host_list
    task_executor.get_task_vars.return_value = task_vars
    action_plugins = {'setup': ActionModule}
    # This is a mock object of class DataLoader
    data_loader = type('', (), {})()
    # This is a mock object of class Task
    task = type('', (), {})()
    task.args = task_args

# Generated at 2022-06-21 02:14:44.130529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_data = dict( msg='Failed as requested from task')
    TaskModule1 = ActionModule(dict(), module_data)
    assert TaskModule1._task.args == module_data
    assert TaskModule1.run()['msg'] == 'Failed as requested from task'

# Generated at 2022-06-21 02:14:55.201586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_args = {'msg':'hello', 'play':'play1'}
    test_task = {'args': test_args, 'action': 'action1'}
    test_invent = {'host':'host1', 'vars':{}, 'groups':[{'hosts':['host1']}]}
    test_host = 'host1'
    test_task_vars = {'test':'test1'}
    res = ActionModule(test_task, test_invent, test_host, test_task_vars)
    assert res.play == 'play1', 'play not correct'
    assert res.args == test_args, 'args not correct'
    assert res.action == 'action1', 'action not correct'

# Generated at 2022-06-21 02:15:03.292531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    
    # instance
    test_instance = ActionModule()
    print(type(test_instance))
    print(vars(test_instance))
    
    print(test_instance.run())
    print(test_instance.run())
    print(test_instance.run())
    print(test_instance.run())
    print(test_instance.run())

# unit test for class ActionModule
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:15:05.385668
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert not action.TRANSFERS_FILES
    assert action.VALID_ARGS == 'msg'