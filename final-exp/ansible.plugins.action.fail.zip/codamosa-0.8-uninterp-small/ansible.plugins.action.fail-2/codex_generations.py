

# Generated at 2022-06-25 06:47:12.492229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 12
    float_0 = 4547.5406
    bool_0 = True
    dict_0 = None
    action_module_0 = ActionModule(int_0, float_0, bool_0, dict_0, dict_0, dict_0)
    tmp_2 = None
    task_vars_2 = None
    result_1 = action_module_0.run(tmp_2, task_vars_2)
    assert result_1['failed'] == True
    assert result_1['msg'] == 'Failed as requested from task'

# Generated at 2022-06-25 06:47:21.214677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -40
    float_0 = -50163.079494
    bool_0 = True
    dict_0 = None
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(int_0, float_0, bool_0, dict_0, dict_0, dict_0)
    action_module_0.run(tmp, task_vars)
    # test 2
    int_0 = 3
    float_0 = -6987.984
    bool_0 = True
    dict_0 = None
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(int_0, float_0, bool_0, dict_0, dict_0, dict_0)

# Generated at 2022-06-25 06:47:27.006175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 12
    float_0 = 4547.5406
    bool_0 = True
    dict_0 = None
    action_module_0 = ActionModule('/tmp/sample_tmp', dict_0, dict_0, dict_0, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 06:47:34.841336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 12
    float_0 = 4547.5406
    bool_0 = True
    dict_0 = None
    action_module_0 = ActionModule(int_0, float_0, bool_0, dict_0, dict_0, dict_0)
    action_module_0.module_vars = dict()
    tmp = None
    task_vars = dict()
    test_case_0()
    result = action_module_0.run(tmp, task_vars)
    assert result["failed"] is True
    assert result["msg"] == "Failed as requested from task"

# Generated at 2022-06-25 06:47:46.720630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 12
    float_0 = 4547.5406
    bool_0 = True
    dict_0 = None
    action_module_0 = ActionModule(int_0, float_0, bool_0, dict_0, dict_0, dict_0)
    arg_list_0 = ('msg',)
    arg_list_1 = ('msg',)
    str_0 = 'msg'
    str_1 = 'msg'
    str_2 = 'Failed as requested from task'
    str_3 = 'Failed as requested from task'
    str_4 = 'Failed as requested from task'
    str_5 = 'Failed as requested from task'
    str_6 = 'Failed as requested from task'
    str_7 = 'Failed as requested from task'

# Generated at 2022-06-25 06:47:54.121084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_1 = dict()
    dict_1['_ansible_parsed'] = False
    dict_0['task_vars'] = dict_1
    dict_2 = dict()
    dict_2['_ansible_parsed'] = False
    dict_0['task_vars'] = dict_2
    action_module_0 = ActionModule(None, None, None, None, None, dict_0)
    result = action_module_0.run(None, dict_0)
    assert result is not None


# Generated at 2022-06-25 06:48:01.443308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 32
    float_0 = 9763.4346
    bool_0 = True
    dict_0 = {'a': 'b'}
    action_module_1 = ActionModule(int_0, float_0, bool_0, dict_0, dict_0, dict_0)
    dict_0 = dict()
    dict_0['msg'] = 'failed'
    result = action_module_1.run(dict_0, dict_0)
    assert result['msg'] == 'failed'

# Generated at 2022-06-25 06:48:06.737176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 8241
    float_0 = 647373.938
    bool_0 = True
    dict_0 = {
        'msg': 0,
    }
    result = run(int_0, float_0, bool_0, dict_0, dict_0, dict_0)
    return result


# Generated at 2022-06-25 06:48:11.932376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 12
    float_0 = 4547.5406
    bool_0 = True
    dict_0 = None
    action_module_0 = ActionModule(int_0, float_0, bool_0, dict_0, dict_0, dict_0)
    result = action_module_0.run(dict_0)
    assert result['msg'] == 'Failed as requested from task'
    assert result['failed']

# Generated at 2022-06-25 06:48:18.694062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1
    float_0 = 8.83
    bool_0 = True
    dict_0 = {
        'default': 1,
        'snd': 12,
        'first': 25,
        'f': -59.0,
        'second': -14.690472979582597,
        'ninth': '',
        'thrd': '',
        'first_0': '',
        'sxth': -6.817791885695689,
        'fhth': 6.817791885695689
    }
    action_module_0 = ActionModule(int_0, float_0, bool_0, dict_0, dict_0, dict_0)
    tmp_0 = None

# Generated at 2022-06-25 06:48:27.103710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    action_module_0.action = 'action_module_0'
    # Possible exception: ValueError
    try:
        action_module_0.run()
    except ValueError:
        print('Possible exception')


# Generated at 2022-06-25 06:48:31.302880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_run_0 = dict()
    var_run_1 = dict()
    action_module_0 = ActionModule(var_run_0, var_run_1, var_run_0, var_run_0, var_run_1, var_run_1)
    var_run_0 = action_module_0.run(var_run_1, var_run_0)

# Generated at 2022-06-25 06:48:40.035906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_task_0 = dict()
    test_task_0['action'] = 'debug'
    test_task_0['keywords'] = dict()
    test_task_0['name'] = 'test_name'
    test_task_0['args'] = dict()
    # Initialize action_module_0
    action_module_0 = ActionModule(test_task_0, dict(), dict(), dict(), dict(), dict())
    # Run action module run with arguments:
    result = action_module_0.run(tmp=None, task_vars=dict())
    assert(result['_ansible_verbose_always'] is False)
    assert(result['_ansible_no_log'] is False)
    assert(result['changed'] is False)
    assert(result['_ansible_parsed'] is True)

# Generated at 2022-06-25 06:48:50.688837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    action_module_0.task = var_0
    action_module_0.sleep = var_0
    action_module_0.transport = var_0
    action_module_0.connection = var_0
    action_module_0.tmp = var_0
    action_module_0.become = var_0
    action_module_0.become_method = var_0
    action_module_0.become_user = var_0
    action_module_0.check_mode = var_0
    action_module_0.no_log = var_0

# Generated at 2022-06-25 06:48:59.579859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.network.base import _convert_hex_to_ip

    # test for non-exception path
    try:
        test_case_0()
    except Exception as exception:
        print("Caught exception: " + str(exception))
        assert False
    else:
        assert True

    # test for exception path
    try:
        test_case_0(var_0=None)
    except TypeError as exception:
        print("Caught exception: " + str(exception))
        assert True
    else:
        assert False


# Generated at 2022-06-25 06:49:01.010423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # var_0 = dict()
    # action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    # action_module_0.run()
    pass


# Generated at 2022-06-25 06:49:05.236315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = dict()
    var_1 = action_module_0.run(var_0, var_1)
    assert var_1['failed'] == True
    assert var_1['msg'] == 'Failed as requested from task'

# Generated at 2022-06-25 06:49:06.414113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True


# Generated at 2022-06-25 06:49:16.229939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data
    str_0 = "\"Failed as requested from task\""
    str_1 = "<type 'dict'>"
    str_2 = "\"msg\""
    str_3 = "<type 'dict'>"
    str_4 = "\"msg\""
    str_5 = "\"Failed as requested from task\""

    # Setup
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = None
    var_2 = None
    action_module_0._task.args = {str_2:str_0}
    action_module_0.run(var_1, var_2)

    # Assertion 1

# Generated at 2022-06-25 06:49:19.695688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = dict()
    var_1 = None
    var_2 = dict()
    action_module_1 = ActionModule(var_1, var_1, var_1, var_1, var_1, var_1)
    var_3 = action_module_1.run(tmp=var_1, task_vars=var_2)

# Generated at 2022-06-25 06:49:24.086906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()

# Generated at 2022-06-25 06:49:30.106266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = action_run(var_0)

# Generated at 2022-06-25 06:49:33.497831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_0 = var_1.run(var_0, var_0)
    var_1 = None

# Generated at 2022-06-25 06:49:37.633010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Class instance used by test method
    class_instance = ActionModule()
    # Method used by test method
    var_0 = action_run()
    arg_0 = {'failed': True, 'msg': 'Failed as requested from task'}
    assert var_0 == arg_0, \
        'Expected different return value %r than the returned value %r.' % (arg_0, var_0)

# Generated at 2022-06-25 06:49:43.960126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_2 = var_1.run(var_0)


# Generated at 2022-06-25 06:49:44.901234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert()

# Generated at 2022-06-25 06:49:55.032212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    method_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    var_6 = None
    var_7 = None
    var_8 = method_0.run(var_6, var_7)
    assert var_8['failed'] == True
    assert var_8['msg'] == 'Failed as requested from task'
    var_9 = dict()
    var_9.update(**{'key_0': 'task'})
    var_9.update(**{'key_1': 'args'})

# Generated at 2022-06-25 06:49:56.630903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:50:03.724183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 'Failed as requested from task'
    var_1 = "Test 'run' method of class ActionModule"
    print(var_1)
    var_2 = dict()
    var_3 = dict()
    var_4 = ActionModule(var_2, var_2, var_2, var_2, var_2, var_2)
    var_5 = var_4.run(var_3, var_3)
    assert var_5['failed']
    assert var_5['msg'] == var_0
    var_6 = dict(msg='BlaBlaBla')
    var_7 = ActionModule(var_2, var_2, var_2, var_2, var_2, var_6)
    var_8 = var_7.run(var_3, var_3)

# Generated at 2022-06-25 06:50:09.112830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_case_0():
        var_0 = dict()
        action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
        action_module_0.run()

    def test_case_1():
        var_0 = dict()
        action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
        tmp_0 = dict()
        task_vars_0 = dict()
        action_module_0.run(tmp_0, task_vars_0)
        tmp_1 = dict()
        task_vars_1 = dict()
        action_module_0.run(tmp_1, task_vars_1)

# Generated at 2022-06-25 06:50:20.560589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = dict()
    action_module_1 = ActionModule(var_2, var_2, var_2, var_2, var_2, var_2)
    if action_module_1.run() is not None:
        raise Exception('var_1 not None')
    var_3 = dict()
    action_module_2 = ActionModule(var_3, var_3, var_3, var_3, var_3, var_3)
    if action_module_2.run(None) is not None:
        raise Exception('var_2 not None')
    var_4 = dict()
    var_5 = dict()
    action_module_3 = ActionModule(var_4, var_5, var_5, var_5, var_5, var_5)

# Generated at 2022-06-25 06:50:30.975407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = 'Failed as requested from task'
    var_4 = {}
    var_4['failed'] = True
    var_4['msg'] = var_3
    var_5 = {'msg': 'Failed as requested from task'}
    var_6 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    if var_5 is None:
        var_7 = None
    else:
        var_7 = (var_5['msg'])
    var_8 = {'msg': var_3}

# Generated at 2022-06-25 06:50:34.444084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = action_module_0.run()


# Generated at 2022-06-25 06:50:35.352384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:50:40.048313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = dict()
    var_3 = dict()
    action_module_3 = ActionModule(var_3, var_3, var_3, var_3, var_3, var_3)

    # Call method run of ActionModule with parameters tmp=var_2 and task_vars=var_3
    return action_module_3.run(var_2, var_3)

# Generated at 2022-06-25 06:50:43.196770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)

    action_module_0.run()


# Generated at 2022-06-25 06:50:49.911178
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create vars
    var_0 = dict()

    # Create ActionModule
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)

    # Call method run of ActionModule
    var_1 = action_module_0.run()

    # Check variables value
    if var_1 != {'failed': True, 'msg': 'Failed as requested from task'}:
        raise Exception("Test case 0 failed: expected {'failed': True, 'msg': 'Failed as requested from task'}, got " + str(var_1))

# Generated at 2022-06-25 06:50:56.980371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = dict()
    action_module_1 = ActionModule(var_2, var_2, var_2, var_2, var_2, var_2)
    var_3 = dict()
    (var_1, var_2) = action_module_1.run(var_3)
    assert var_1 == var_1


# Generated at 2022-06-25 06:50:59.574349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_7 = dict()
    var_7 = dict()
    action_module_0 = ActionModule(var_7, var_7, var_7, var_7, var_7, var_7)
    action_module_0.run()

# Generated at 2022-06-25 06:51:09.318185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()
    var_7 = dict()
    var_8 = dict()
    var_9 = dict()
    var_10 = dict()
    var_11 = dict()
    var_12 = dict()
    var_13 = dict()
    var_14 = dict()
    var_15 = dict()
    var_16 = dict()
    var_17 = dict()
    var_18 = dict()
    var_19 = dict()
    var_20 = dict()
    var_21 = dict()
    var_22 = dict()
    var_23 = dict()
    assert var_2 == var_23.run(var_5, var_6)

# Generated at 2022-06-25 06:51:26.209233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = dict()
    var_3 = dict()
    action_module_1 = ActionModule(var_2, var_2, var_2, var_2, var_2, var_2)
    msg = 'Failed as requested from task'
    if self._task.args and 'msg' in self._task.args:
        msg = self._task.args.get('msg')
    
    var_4 = action_run()
    var_1 = var_4.get('failed')
    var_2 = var_4.get('msg')

    var_0 = (var_1 == True) and (var_2 == msg)
    return var_0

# Generated at 2022-06-25 06:51:32.651165
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # self.run(self, tmp=None, task_vars=dict())
    #         if task_vars is None:
    #             task_vars = dict()
    #
    #         result = super(ActionModule, self).run(tmp, task_vars)
    #         del tmp  # tmp no longer has any effect
    #
    #         msg = 'Failed as requested from task'
    #         if self._task.args and 'msg' in self._task.args:
    #             msg = self._task.args.get('msg')
    #
    #         result['failed'] = True
    #         result['msg'] = msg
    #         return result
    #
    pass


# Generated at 2022-06-25 06:51:36.382225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = action_run()
    var_3 = ActionModule()
    var_4 = var_3.run('/var/tmp/ansible-tmp-1439663488.99-244958290454594','ansible_play_hosts')


# Generated at 2022-06-25 06:51:39.236834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = dict()
    var_2 = var_0.run(var_1)
    return var_2

# Generated at 2022-06-25 06:51:44.814383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    msg = 'Failed as requested from task'
    assert(result['failed'] is True)
    assert(result['msg'] is msg)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 06:51:52.816053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()
    var_2 = ActionModule(var_0, var_1, var_1, var_0, var_0, var_0)
    var_3 = ActionBase(var_1, var_1, var_1, var_1, var_1)
    var_4 = var_3.run(var_1, var_1)
    assert var_3.run(var_1, var_1) == var_4
# END_TEST_CASE

# Generated at 2022-06-25 06:51:57.101137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_5 = dict()
    action_module_5 = ActionModule(var_5, var_5, var_5, var_5, var_5, var_5)
    var_6 = None
    var_7 = dict()
    var_8 = action_module_5.run(var_6, var_7)
    assert var_8 == 'Test Failed'

# Generated at 2022-06-25 06:52:03.932328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    action_module_0 = ActionModule(var_1, var_2, var_3, var_4, var_5, var_1)
    var_6 = True
    var_7 = True
    var_8 = True
    var_9 = True
    var_10 = True
    var_11 = True
    try:
        var_12 = action_run()
        assert var_12 is False
    except Exception:
        var_7 = False
    assert var_7
    assert var_8
    var_13 = True
    var_14 = True
    var_15 = True
    var_16 = True
    var_17 = True
   

# Generated at 2022-06-25 06:52:14.455941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = dict()
    # Assigning value to variable 'tmp'
    var_1['tmp'] = None
    # Assigning value to variable 'task_vars'
    var_1['task_vars'] = None
    var_2 = ActionModule(var_1, var_1, var_1, var_1, var_1, var_1)
    # Calling function run with arguments (dict, dict)
    var_3 = var_2._run(var_1, var_1)
    # Evaluating expression 'result'
    var_4 = 'failed'
    assert var_4 in var_3, 'result["failed"] is missing'
    assert var_3['failed'], 'result["failed"] was not true'
    # Evaluating expression 'result'
    var_4 = 'msg'
    assert var

# Generated at 2022-06-25 06:52:24.510345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = {'msg': 'Failed as requested from task'}
    var_2 = None
    var_3 = None
    var_0 = ActionModule(var_1, var_2, var_3)
    var_4 = var_0.run()
    assert var_4['failed']
    assert var_4['msg'] == 'Failed as requested from task'
    var_1 = {'msg': 'Failed as requested from task'}
    var_2 = ''
    var_3 = ''
    var_0 = ActionModule(var_1, var_2, var_3)
    var_4 = var_0.run()
    assert var_4['failed']
    assert var_4['msg'] == 'Failed as requested from task'

# Generated at 2022-06-25 06:52:48.963425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = dict()
    dict_0 = dict()
    dict_0['failed'] = True
    dict_0['msg'] = 'Failed as requested from task'
    var_1 = assert_equal(var_1, dict_0)

# Generated at 2022-06-25 06:52:50.304274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  var_1 = dict()
  var_2 = ActionModule(var_1, var_1, var_1, var_1, var_1, var_1)
  var_3 = action_run()


# Generated at 2022-06-25 06:52:54.480979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = dict()
    var_3 = 'tmp'
    var_4 = dict()
    var_5 = 'msg'
    action_module_run(var_2, var_3, var_4, var_5)



# Generated at 2022-06-25 06:52:57.423113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = ActionModule()
    assert var_2.run(None, None) == {"failed": True, "msg": "Failed as requested from task"}



# Generated at 2022-06-25 06:53:03.910433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    del var_0
    result_0 = action_module_run(None, var_1)
    assert result_0['failed'] == True
    assert result_0['msg'] == 'Failed as requested from task'

test_case_0()

# Generated at 2022-06-25 06:53:07.728873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_3 = dict()
    var_1 = ActionModule(var_3, var_3, var_3, var_3, var_3, var_3)
    var_2 = var_1.run()

# Generated at 2022-06-25 06:53:13.400464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=protected-access
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_0 = dict()
    var_1 = action_module_0.run(var_0, var_0)
    assert var_1['failed'] == True

# Generated at 2022-06-25 06:53:18.819953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = ActionModule(None, None, None, None, None, None)
    var_3 = None
    var_4 = None
    var_5 = var_2.run(var_3, var_4)
    var_6 = 'result' in var_5
    assert var_6 == False
    var_7 = 'msg' in var_5
    assert var_7 == False
    var_8 = 'failed' in var_5
    assert var_8 == False
    var_9 = '_ansible_no_log' in var_5
    assert var_9 == False

# Generated at 2022-06-25 06:53:23.754327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = dict()
    action_module_1 = ActionModule()
    var_3 = action_module_1.run()
    assert var_3

# Generated at 2022-06-25 06:53:27.322938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_2 = action_module_0.run(var_1, var_1)
    assert var_2 == var_1

# Generated at 2022-06-25 06:54:18.070212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict() # TODO: Create an instance of Dict or Refactor
    var_1 = dict() # TODO: Create an instance of Dict or Refactor
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_2 = action_module_0.run(tmp=var_0, task_vars=var_1)
    var_3 = "Failed as requested from task"
    assert var_2["msg"] == var_3

# Generated at 2022-06-25 06:54:21.637492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = action_run(var_0, var_1, var_2)


# Generated at 2022-06-25 06:54:25.394681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = dict()
    var_2 = dict()
    action_module_0 = ActionModule(var_1, var_1, var_1, var_1, var_1, var_1)
    var_3 = action_module_0.run(var_1, var_2)
    assert var_3 == dict(failed=True, msg='Failed as requested from task')


# Generated at 2022-06-25 06:54:29.885231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()
    action_module_1 = ActionModule(var_1, var_1, var_1, var_1, var_1, var_1)
    var_7 = action_module_1.run(var_2)
    assert var_7 == dict()

# Generated at 2022-06-25 06:54:31.594463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = action_run()
    return var_1

# Generated at 2022-06-25 06:54:33.823157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = action_module_0.run()
    assert var_1['failed'] == True
    assert var_1['msg'] == 'Failed as requested from task'


# Generated at 2022-06-25 06:54:38.644369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_0.run(None, None)
    # Python does not have switch but can use another IF...
    if tmp is None:
        if 1:
            return var_0
        else:
            return var_0



# Generated at 2022-06-25 06:54:41.749847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    assert var_1.run() == {'result': var_0, 'msg': var_0, 'failed': var_0}

# Generated at 2022-06-25 06:54:48.495055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = dict()
    var_2 = dict()
    action_module_0 = ActionModule(var_2, var_1, var_1, var_1, var_1, var_1)
    try:
        var_3 = action_module_0.run(var_2, var_2)
        var_3
    except Exception:
        raise Exception("Error occured in action module")

# Testing code
if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:54:52.537423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = action_module_0.run(var_0, var_0)
    assert var_1['msg'] == 'Failed as requested from task'


# Generated at 2022-06-25 06:56:40.680656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_2 = None
    var_3 = dict()
    var_4 = dict()
    var_4['_ansible_verbosity'] = 0
    var_4['_ansible_version'] = 20302
    var_4['_ansible_no_log'] = False
    var_4['_ansible_debug'] = False
    var_4['_ansible_selinux_special_fs'] = ('/selinux', '/sys/fs/selinux',)
    var_4['_ansible_diff'] = False
    var_4['_ansible_check_mode'] = False

# Generated at 2022-06-25 06:56:50.817383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = task_vars
    var_3 = dict()
    var_4 = dict()
    action_module_1 = ActionModule(var_3, var_4, var_4, var_4, var_4, var_4)
    var_5 = tmp
    var_5 = action_module_1.run(var_5, var_2)
    # If action module does not return a dictionary, raise an error
    # if not isinstance(var_5, dict):
    #     raise AssertionError()
    # Make sure that 'failed' key is returned
    # if 'failed' not in var_5:
    #     raise AssertionError()
    # 'failed' must be True
    # if not var_5['failed']:
    #     raise AssertionError()
    # 'msg

# Generated at 2022-06-25 06:56:54.977658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = None
    var_2 = None
    var_3 = action_module_0.run()
    assert var_3['failed'] == True
    assert var_3['msg'] == 'Failed as requested from task'


# Generated at 2022-06-25 06:56:59.258303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Setup
  var_0 = dict()
  var_1 = object()
  var_2 = None

  action_module_0 = ActionModule(var_0, var_1, var_2, var_2, var_0, var_2)

  # test
  action_module_0.run(var_1, var_2)

  # teardown

# Generated at 2022-06-25 06:57:05.443807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = dict()
    var_2 = None
    var_3 = dict()
    var_3 = None
    action_module_1 = ActionModule(var_2, var_2, var_2, var_2, var_2, var_2)
    ansible_runner_1 = action_module_1.run(var_3, var_3)
    assert ansible_runner_1['failed'] == True

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()