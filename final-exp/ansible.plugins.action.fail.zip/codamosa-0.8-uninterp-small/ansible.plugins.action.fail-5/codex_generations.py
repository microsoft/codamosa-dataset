

# Generated at 2022-06-25 06:47:15.511925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    set_0 = {list_0, list_0}
    str_0 = 'iZ"Kjw7'
    bytes_0 = b'Dy\x90\xbd\xb9\x14\xb1\x13\x91\x1c\xba\xba%\xcb\xb0\x955'
    int_0 = 3413
    action_module_0 = ActionModule(list_0, set_0, set_0, str_0, bytes_0, int_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'Failed as requested from task'
    tmp = None
    task_v

# Generated at 2022-06-25 06:47:22.729345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_results = {'failed': True, 'changed': False, 'msg': 'Failed as requested from task', 'diff': {}}
    module_return = {'contacted': {}, 'dark': {}}
    msg_0 = 'Failed as requested from task'
    module_name_0 = 'fail'
    display_name_0 = 'failing task'
    args_0 = {}
    module_args_0 = {}
    tmp_0 = None
    action_module_0 = ActionModule(module_name_0, display_name_0, args_0, module_args_0, tmp_0)
    task_vars_0 = {}
    result = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    assert result == task_results
    task

# Generated at 2022-06-25 06:47:33.438722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    list_1 = []
    list_2 = []
    set_0 = {list_1, list_2}
    str_0 = '5be?J0_9Xh[^f\x18\x0b'
    bytes_0 = b"\x1c\x9e\x9c3\xf3\x90\x12\t\x0b"
    int_0 = -90
    action_module_0 = ActionModule(list_0, set_0, set_0, str_0, bytes_0, int_0)
    action_module_1 = action_module_0
    str_1 = 'c\x16(\x0c\x0cp\x1fQ\x15\x12\x1en['

# Generated at 2022-06-25 06:47:41.472821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    set_0 = {list_0, list_0}
    str_0 = "r"
    bytes_0 = b'q\x15'
    int_0 = 0
    action_module_0 = ActionModule(list_0, set_0, set_0, str_0, bytes_0, int_0)
    str_1 = "ts08z`*]\x1d"
    dict_0 = dict()
    dict_0['msg'] = str_1
    dict_0['t'] = str_0
    dict_0['t'] = str_0
    dict_0['t'] = str_0
    dict_0['t'] = str_0
    dict_0['t'] = str_0
    dict_0['t'] = str_0
    dict_

# Generated at 2022-06-25 06:47:46.582499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up object
    list_0 = []
    set_0 = {list_0, list_0}
    str_0 = 'EX$Kom;x!X_@u7:l\x0c>F'
    bytes_0 = b"jif\x91\xf7h\xech\x97'b\x141`"
    int_0 = -688
    action_module_0 = ActionModule(list_0, set_0, set_0, str_0, bytes_0, int_0)
    # tmp has no type annotation
    # task_vars has no type annotation
    # test the run function
    action_module_0.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 06:47:56.395495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    set_0 = {list_0, list_0}
    str_0 = '%-7^'
    bytes_0 = b'b#NlrB\xa5\x0c"\x86\x1b\xa6\xef\x0c\\j'
    int_0 = -40
    action_module_0 = ActionModule(list_0, set_0, set_0, str_0, bytes_0, int_0)
    list_1 = []
    set_1 = {list_1, list_1}
    str_1 = 'd\x9f)p\x03\x87\x19\xabJ\xdb\xb1\x1f'

# Generated at 2022-06-25 06:48:01.111116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(dict(), dict())
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:48:06.982514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = 'tmp'
    action_module_0 = ActionModule(task_vars, tmp)
    task_vars_0 = action_module_0.run()
    assert task_vars_0.get('failed') == True
    assert task_vars_0.get('msg') == 'Failed as requested from task'

# Generated at 2022-06-25 06:48:15.997022
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:48:19.689719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = tempfile.NamedTemporaryFile()
    dict_0 = {"1": 1, "2": 2}
    test_case_ActionModule_run_0(tmp_0, dict_0)
    test_case_ActionModule_run_1(tmp_0, dict_0)
    test_case_ActionModule_run_2(tmp_0, dict_0)
    
# Run unit tests for method run of class ActionModule

# Generated at 2022-06-25 06:48:25.339839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0)
    var_1 = None
    action_run(action_module_0, var_1)

# Generated at 2022-06-25 06:48:32.931872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = dict()
    var_2 = ActionModule(var_1, var_1)
    var_3 = None
    var_4 = dict()
    var_5 = action_run(var_2, var_3, var_4)
    var_11 = var_5.get('failed') == True
    assert var_11


# Generated at 2022-06-25 06:48:35.355732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-25 06:48:38.726751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = dict(msg='Failed as requested from task')
    var_2 = None
    var_3 = ActionModule(var_1, var_2)
    var_4 = None
    var_5 = action_run(var_3, var_4)


# Generated at 2022-06-25 06:48:41.045926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_3 = ActionModule()
    var_4 = None
    var_5 = None
    var_6 = var_3.run(var_4, var_5)
    pass

# Generated at 2022-06-25 06:48:46.282294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0)
    var_1 = None
    var_2 = action_run(action_module_0, var_1)

# Generated at 2022-06-25 06:48:48.716907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0)
    var_1 = None
    assert False == action_module_0.run(var_1)
    assert var_1 is None

# Generated at 2022-06-25 06:48:50.204298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    # Check for method not implemented
    assert not hasattr(action_module_1, 'run')

# Generated at 2022-06-25 06:48:57.115686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_3 = dict()
    var_3["failed"] = True
    var_3["msg"] = "Failed as requested from task"
    var_4 = dict()
    var_5 = ActionModule(var_4, var_4)
    var_6 = None
    var_7 = var_5.run(var_6, var_4)
    assert var_7 == var_3

# Generated at 2022-06-25 06:48:59.608516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = None
    var_2 = dict()
    var_3 = None
    var_2 = action_run(var_1, var_2, var_3)

# Generated at 2022-06-25 06:49:12.237444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '!B'
    bytes_0 = b'\x0b\x8d\xc1\xe3?\xd5\xaa6\xd3\xc2\xe2\x14\xc7\x15\x83o\xa3\x1a\x18\x1f'
    int_0 = 261
    float_0 = -749.48
    dict_0 = {bytes_0: bytes_0, int_0: int_0, str_0: int_0, str_0: bytes_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)

# Generated at 2022-06-25 06:49:22.768705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ')_]'
    bytes_0 = b'\xb4\x8c\xcb"\x19j\xd6?\xd8\x9b\xbdM\x7f`\x8a\xac\x1a\xb6'
    int_0 = 831
    float_0 = -735.8
    dict_0 = {str_0: int_0, str_0: str_0, int_0: str_0, int_0: bytes_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_0 = action_run()
    var_1 = action_task_vars()


# Generated at 2022-06-25 06:49:32.370597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'a'
    bytes_0 = b'\x07\x01k\x01'
    int_0 = 9
    float_0 = 738.397
    dict_0 = {str_0: bytes_0, str_0: str_0, str_0: bytes_0, str_0: str_0}
    tuple_0 = (str_0, str_0, str_0, int_0, bytes_0)
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    action_module_0.run()


# Generated at 2022-06-25 06:49:39.431970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '#'
    bytes_0 = b'\x9e\xa2\xb7\xa8\x1c\x82\x92\xc9)Y\x19\xb7\xe6\x8c\xaa\xd7\x1b\x13\x8b'
    int_0 = -774
    float_0 = 0.12
    dict_0 = {int_0: int_0, str_0: str_0, int_0: bytes_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:49:40.469206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert False
    except:
        assert True


# Generated at 2022-06-25 06:49:46.446969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.fail
    from ansible.plugins.action.fail import ActionModule
    from ansible.module_utils._text import to_native

    action_module_0 = ActionModule.ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    result = action_module_0.run()
    # AssertionError: assert result['msg'] == msg
    var_0 = result['msg']
    var_1 = test_case_0.msg


# Generated at 2022-06-25 06:49:51.642820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Functions run
    str_0 = 'l:'
    bytes_0 = b'\x06\xf8\x8d\xac\xdf\x1a\x9a\xef\xf4\xfa\xed\x17\xde\x87V\xca'

# Generated at 2022-06-25 06:50:00.860125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'h~=\x1f2$\xf2\xbd\xb0\xef\xab\xea\x11'
    bytes_0 = b'\xac\xbe\x17\x1c\x91B\x14O'
    int_0 = 127
    float_0 = 519.1
    dict_0 = {int_0: int_0, str_0: bytes_0, str_0: float_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_0 = action_module_0.run()
    assert var_0['failed'] == True

# Generated at 2022-06-25 06:50:06.414449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arguments
    tmp = ansible.plugins.action.ActionBase.run(tmp, task_vars)
    result = ansible.plugins.action.ActionBase.run(tmp)
    # Return Value
    assert result['failed'] == True
    assert result['msg'] == msg

# Generated at 2022-06-25 06:50:10.853200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test: test_ActionModule_run')
    action_module_1 = ActionModule()
    var_1 = action_module_1.run()
    print('Output:', var_1)



# Generated at 2022-06-25 06:50:25.862955
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:50:29.461708
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:50:31.418728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule();
    var_0 = action_module_0.run();
    # assert var_0 == ;

# Generated at 2022-06-25 06:50:41.275425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'K<T\x82\x1b'
    bytes_0 = b'\x02\xf9\xae\x94!\xd0\x84\x0270\xa5\xa3\x82\xe2\x9c\x9f\xc2\x13;\x07\x81'
    int_0 = 543
    float_0 = -16.7
    dict_0 = {bytes_0: int_0, str_0: int_0, str_0: int_0, str_0: int_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:50:46.539892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '%2>3n#'
    bytes_0 = b'\x1e\xf5\xf2\x8b\x06\x9a\xc1>\x85\xb5F\x80\x0e\x84\xe5\x9c,\x9a\x82'
    int_0 = 55
    float_0 = -532.0
    dict_0 = {float_0: str_0, str_0: int_0, bytes_0: bytes_0, str_0: int_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    action_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 06:50:53.929315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_run_0 = ActionBase()
    str_0 = '!@'

# Generated at 2022-06-25 06:50:58.692684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '>)}'
    bytes_0 = b'\x0b\x8d\xc1\xe3?\xd5\xaa6\xd3\xc2\xe2\x14\xc7\x15\x83o\xa3\x1a\x18\x1f'
    int_0 = 261
    float_0 = -749.48
    dict_0 = {bytes_0: bytes_0, int_0: int_0, str_0: int_0, str_0: bytes_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:51:08.337457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = 'Mssq3r8Yd)b!'

# Generated at 2022-06-25 06:51:09.835162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module_0 = ActionModule('>)}')
  assert 1 == 1


# Generated at 2022-06-25 06:51:16.683914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize test variables
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    # AssertionError: Expected object of type '_sre.SRE_Pattern' but received type 'int'
    var_0 = ActionBase.run(int_0)



# Generated at 2022-06-25 06:51:32.959267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0b\x8d\xc1\xe3?\xd5\xaa6\xd3\xc2\xe2\x14\xc7\x15\x83o\xa3\x1a\x18\x1f'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    dict_1 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    tuple_0 = ()
    tuple_1 = ()
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, dict_0, tuple_0, dict_1, tuple_1)
   

# Generated at 2022-06-25 06:51:40.226056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '7'
    bytes_0 = b'\xbdJ\x8d\x89\xd7\x1e\x1a\x85\x9c3\xaa\x07\xa8z\x89'
    int_0 = -173
    float_0 = -934.87
    dict_0 = {int_0: bytes_0, int_0: str_0, str_0: bytes_0}
    tuple_0 = (int_0, str_0, bytes_0)
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:51:45.542909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:51:55.205044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '7'
    bytes_0 = b'\x87\xdaE\x8c\xb9\x9a\xd1\x97\x8b\xab\xbb\x0f\x00\xbf\x9f\x0b\xec'
    int_0 = 280
    float_0 = -513.33
    dict_0 = {bytes_0: bytes_0, int_0: int_0, str_0: bytes_0, str_0: int_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    #Test if 'action_module_0' is an instance of class ActionModule

# Generated at 2022-06-25 06:51:56.496642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert () == ()


# Generated at 2022-06-25 06:52:04.026890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    str_0 = '\x1d\x03\xfd\xbd\xfd\x95\xef\xed\x0a'
    int_0 = -1274154889
    float_0 = -817.09
    action_module_0 = ActionModule(str_0, dict_0, dict_0, float_0, int_0, dict_0)
    with pytest.raises(AssertionError):
        action_module_0.run(dict_0, dict_0)



# Generated at 2022-06-25 06:52:14.457114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'QU'
    bytes_0 = b'\x0e\x1a\x1e\xbf\xe3\x8c\x8e0\x9e\x1b\x8b\xd4\xd0\x1d\x890'
    int_0 = -906
    float_0 = 6.4
    dict_0 = {bytes_0: int_0, int_0: str_0, str_0: int_0, bytes_0: bytes_0}
    tuple_0 = (str_0, )
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:52:24.510065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:52:31.358295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'join'
    int_1 = -70
    float_1 = -826.10
    dict_1 = {'rc': '2', str_1: str_1, float_1: float_1, str_1: str_1, int_1: int_1}
    tuple_1 = ()
    action_module_0 = ActionModule(str_1, int_1, float_1, dict_1, tuple_1)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:52:33.136307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert run('Failed as requested from task', {('main',): {}})

# Function test_case_0 tests if the function works correctly

# Generated at 2022-06-25 06:53:02.151927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '8ca'
    bytes_0 = b'\x0b\x8d\xc1\xe3?\xd5\xaa6\xd3\xc2\xe2\x14\xc7\x15\x83o\xa3\x1a\x18\x1f'
    int_0 = 261
    float_0 = -778.95
    dict_0 = {bytes_0: float_0, float_0: int_0, str_0: str_0, str_0: str_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    tmp_0 = None
    task_vars_0 = None

# Generated at 2022-06-25 06:53:12.802137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '}C>'
    bytes_0 = b'w\xe7\x8d\x1b\xa1\x91\xed\xabZ\xac\xf4\xb5\x14\xc5\x88\x1b\x9f\xf9\x01'
    int_0 = 117
    float_0 = -827.7
    dict_0 = {bytes_0: int_0, bytes_0: bytes_0, str_0: int_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_1 = action_module_0.run()
    return var_1


var_0 = test_case_0()

# Generated at 2022-06-25 06:53:22.538166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'w'
    bytes_0 = b'\xec\xc6\xfb\xeb\xb0\xef\xf6\xdb\xd0\xb8\xc2\xfb\xe2\xe5\xe9\xa3\xb0\x9a\xde\xcb'
    int_0 = 35
    float_0 = -9.75
    dict_0 = {int_0: bytes_0, str_0: str_0, int_0: bytes_0}
    tuple_0 = (int_0, str_0, bytes_0)
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:53:31.076081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params_0 = {
        'msg': 'Failed as requested from task',
    }
    action_module_1 = ActionModule(str_0, bytes_0, int_0, float_0, params_0, tuple_0)
    try:
        var_1 = action_module_1.run()
        assert False
    except RuntimeError as exception_0:
        var_2 = '#ansible'
        message_0 = exception_0
        if str(message_0).find(var_2) != -1:
            assert True
        else:
            assert False

# Generated at 2022-06-25 06:53:40.201898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input data
    tmp = None
    task_vars = None

    # Setup
    str_0 = '>)}'
    bytes_0 = b'\x0b\x8d\xc1\xe3?\xd5\xaa6\xd3\xc2\xe2\x14\xc7\x15\x83o\xa3\x1a\x18\x1f'
    int_0 = 261
    float_0 = -749.48
    dict_0 = {bytes_0: bytes_0, int_0: int_0, str_0: int_0, str_0: bytes_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)

   

# Generated at 2022-06-25 06:53:48.277904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x0e'
    bytes_0 = bytearray({8})
    int_0 = -6
    float_0 = -513.9
    dict_0 = {bytes_0: int_0, str_0: bytes_0}
    tuple_0 = (dict_0,)
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_0 = action_module_0.run(bytes_0, dict_0)
    assert var_0 == dict_0

# Generated at 2022-06-25 06:53:51.684425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:53:58.305234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'a9Ns\x0b]\xa8\x0c\x0b\x15\xe2\x0c\xba\x10\xac\xce\xc1\xbe\x15\x04}R\xec?\x11\xba\xbe\x10\x13\xc5\xbf\x04\xbf\x0b\x89\x03\x9e\xf5\xc8'

# Generated at 2022-06-25 06:54:06.623674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  class Args(dict):
    def __init__(self):
      self.args = [("msg", "Failed as requested from task")]
      super(Args, self).__init__(self.args)
    def get(self, key):
      return self[key]

  action_module_0 = ActionModule("fail")
  action_module_0.run(task_vars={"hostvars": {}, "group_names":[]} )

# Generated at 2022-06-25 06:54:16.976485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'T>'
    bytes_0 = b'\x08\x01\xa9\x90\x0f\xb1?\x0c\x1c\x8f\x95\xc6\xd0\xf78\x1c'
    int_0 = 936
    float_0 = 905.4
    dict_0 = {'\x05': 966, b'\xec\xed\xb0\x835\xe38\xe2\t}J\xb3': 966, float_0: 966}
    tuple_0 = (bytes_0, )
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_0 = action_run()
    # print

# Generated at 2022-06-25 06:55:20.852422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'bL\xa4\x90\xef\x0e\x8a\xa6'
    bytes_0 = b'\xc6\xd2\xfb\x06\xfc\x12&}'
    int_0 = 889
    float_0 = -832.18
    dict_0 = {int_0: str_0, bytes_0: int_0, str_0: bytes_0, str_0: int_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_0 = action_run()
    return var_0



# Generated at 2022-06-25 06:55:27.402425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r.9'
    bytes_0 = b'\x1a'
    int_0 = 13
    float_0 = 584.62
    dict_0 = {int_0: float_0, str_0: int_0, bytes_0: float_0}
    tuple_0 = (float_0, bytes_0)
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    tmp_0 = 0
    task_vars_0 = {}
    assert action_module_0._run() == 'Failed as requested from task'

# Generated at 2022-06-25 06:55:31.523005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '{'
    bytes_0 = b'\x0b\x8d\xc1\xe3?\xd5\xaa6\xd3\xc2\xe2\x14\xc7\x15\x83o\xa3\x1a\x18\x1f'
    int_0 = 261
    float_0 = -749.48
    dict_0 = {bytes_0: bytes_0, int_0: int_0, str_0: int_0, str_0: bytes_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    action_module_0.run()

# Generated at 2022-06-25 06:55:40.559993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '|'
    bytes_0 = b'\x8c\xb2\x82\xff\\\xee\x8c\x1b\xb1\xf4\x82^'
    int_0 = 651
    float_0 = -837.67
    dict_0 = {int_0: float_0, str_0: int_0, int_0: str_0}
    tuple_0 = ('0', '$', '0', '$')
    action_module_var_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    action_module_var_0.run()

# Generated at 2022-06-25 06:55:51.758897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'iiR'

# Generated at 2022-06-25 06:55:54.835015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = test_case_0()

# Generated at 2022-06-25 06:56:00.988462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 't>f~!'
    bytes_0 = b'*\xf5\xfd\x8e\xbe\xcb\t:.\x80\x00\x06\xdc\xee\x83\xb8\xac\xcf\x1b\xb1\xf8'
    int_0 = -243
    float_0 = 852.22
    dict_0 = {int_0: int_0, int_0: str_0, str_0: int_0, int_0: str_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:56:09.651953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '$:'
    bytes_0 = b'\x17\x04\x0e^\x01\x1b\x04\x0e\xfaP\xfa\x16\x00\x00\x00\x01\x00\x00\x00'
    int_0 = 712
    float_0 = -25.6
    dict_0 = {int_0: int_0, str_0: bytes_0, str_0: int_0, bytes_0: bytes_0}
    tuple_0 = (bytes_0, int_0, float_0, dict_0, tuple_0)
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)

# Generated at 2022-06-25 06:56:16.317143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'e$'
    bytes_0 = b'kK\r\x05\x17\x04\xdc\x0f\x81\x1c\x04\xe0\x00\x15\x00\x80\x03'
    int_0 = 962
    float_0 = 916.1
    dict_0 = {str_0: bytes_0, str_0: int_0, bytes_0: bytes_0, int_0: int_0}
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, bytes_0, int_0, float_0, dict_0, tuple_0)
    action_module_0.run()


# Generated at 2022-06-25 06:56:19.634912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True
