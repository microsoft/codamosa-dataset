

# Generated at 2022-06-25 06:47:02.479551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule("a")
    result = action_module_0.run("task_vars", "msg")
    print("Result of running method run of class ActionModule: " + str(result))

# Testing of __init__ of class ActionModule

# Generated at 2022-06-25 06:47:11.467513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1015
    bytes_0 = b'\x13\xcdSg\x89b\x96\xc8\x8b\xdaZNm\xb4\xbb\x1d\x98\xe6'
    bool_0 = True
    list_0 = [bytes_0]
    action_module_0 = ActionModule(int_0, bytes_0, bool_0, bytes_0, list_0, list_0)

    # Call method run with parameters: list_0
    action_module_0.run(list_0)



# Generated at 2022-06-25 06:47:20.522026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1015
    bytes_0 = b'\x13\xcdSg\x89b\x96\xc8\x8b\xdaZNm\xb4\xbb\x1d\x98\xe6'
    bool_0 = True
    list_0 = [bytes_0]
    action_module_0 = ActionModule(int_0, bytes_0, bool_0, bytes_0, list_0, list_0)

    # Call run(bool)
    int_1 = 364
    bool_1 = bool_0
    bytes_1 = b'\xba\x1f\xf8\xcd\xd6\x9a\x86\xa8\x91\x0e[\xec\x1a\x95\x13\x16\xeb'

# Generated at 2022-06-25 06:47:29.688834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1015
    bytes_0 = b'\x13\xcdSg\x89b\x96\xc8\x8b\xdaZNm\xb4\xbb\x1d\x98\xe6'
    bool_0 = True
    list_0 = [bytes_0]
    action_module_0 = ActionModule(int_0, bytes_0, bool_0, bytes_0, list_0, list_0)
    action_module_0.run(bytes_0, bytes_0)


# Generated at 2022-06-25 06:47:36.843392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1837
    bytes_0 = b'\xbe\xff\x1e\xca\xa6\xe2\x1e\xdc\xb3\x9f\x19\xb9\xd3'
    bool_0 = True
    str_0 = 'v\x98\xcc\xee\xbbD\x14\x0f\x0c\xa5P\x90\x8d\xb3\x1fS\x11\xfc\x8c\xc4\x80\x1f'
    list_0 = [bytes_0]
    action_module_0 = ActionModule(int_0, bytes_0, bool_0, str_0, list_0, list_0)
    tmp = None
    task_vars = {}
    int_

# Generated at 2022-06-25 06:47:40.095152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    param_0 = {"msg": None}
    action_module_0 = ActionModule(param_0)
    res = action_module_0.run(param_0, param_0)
    json.dumps(res, ensure_ascii=False)

# Generated at 2022-06-25 06:47:49.577741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1015
    bytes_0 = b'\x13\xcdSg\x89b\x96\xc8\x8b\xdaZNm\xb4\xbb\x1d\x98\xe6'
    bool_0 = True
    list_0 = [bytes_0]
    action_module_0 = ActionModule(int_0, bytes_0, bool_0, bytes_0, list_0, list_0)
    assert action_module_0.run()['failed'] == True


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()
    print('Test is passed')

# Generated at 2022-06-25 06:47:58.250799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1331
    bytes_0 = b'\x15\xce\xe8\x86\xeb\xbe\x9f\xb8N\x0c\xdc\xab\x1d'
    bool_0 = True
    dict_0 = dict()
    dict_0['list_0'] = bytes_0
    dict_0['list_1'] = bytes_0
    dict_0['list_2'] = bytes_0
    dict_0['list_3'] = bytes_0
    dict_0['list_4'] = bytes_0
    dict_0['list_5'] = bytes_0
    dict_0['list_6'] = bytes_0
    dict_0['list_7'] = bytes_0
    dict_0['list_8'] = bytes_0
   

# Generated at 2022-06-25 06:48:04.222397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1015
    bytes_0 = b'\x13\xcdSg\x89b\x96\xc8\x8b\xdaZNm\xb4\xbb\x1d\x98\xe6'
    bool_0 = True
    list_0 = [bytes_0]
    action_module_0 = ActionModule(int_0, bytes_0, bool_0, bytes_0, list_0, list_0)
    action_module_0.run()

# Generated at 2022-06-25 06:48:12.414587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 5859
    bytes_0 = b'x\x07\xb7T\x90\x19\xb6\xc4\x9b\x9c}\x88\xbb\x14\xa5\x95\xb2'
    bool_0 = False
    list_0 = [5166, bytes_0]
    action_module_0 = ActionModule(int_0, bytes_0, bool_0, bytes_0, list_0, list_0)
    action_module_0.action_loader = None
    tmp_0 = None
    task_vars_0 = dict()

    action_module_0.run(tmp_0, task_vars_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:48:16.347381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # TODO: add unit test for ActionModule.run


# Generated at 2022-06-25 06:48:16.896486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:48:22.998457
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initialize class
    action_module = ActionModule()

    # Example of unit test
    # With module arguments
    var_0 = dict()
    action_module_result = action_module.run(var_0)
    assert(isinstance(action_module_result, dict))
    # Without module arguments
    action_module_result = action_module.run()
    assert(isinstance(action_module_result, dict))
    return



# Generated at 2022-06-25 06:48:30.075626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3833

# Generated at 2022-06-25 06:48:40.976620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import collections
    import random
    import sys
    # Define test inputs and expected outputs
    int_0 = 9783
    float_0 = 0.0
    bytes_0 = b'\xbd\xdc\xe0\x1d\x1f\x14T\x0b\x9b\xdeB'
    bool_0 = True
    chars_0 = 'AiNR\x17\xee\x9d\x10\xc5\x1c\xb8\x98\xd4'
    # Call the test function
    var_0 = ActionModule()
    try:
        var_0.run()
    except Exception as err:
        assert False



# Generated at 2022-06-25 06:48:46.871422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=None, connection=None, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    #TODO: do test here
    #assert len(test_result) == 0, "test run failed"


# Generated at 2022-06-25 06:48:59.444308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    result_dir = "bin/ansible/plugins/action/test_results"
    case_id = 100
    mod_name = "test_action_fail"
    ansible_vars = dict()
    ansible_vars['test_var'] = 0
    ansible_vars['test_list'] = [0]
    ansible_vars['test_dict'] = {}

    # Execute
    case_result = "failed"

# Generated at 2022-06-25 06:49:10.161294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task.args['msg'] = 'Failed as requested from task'
    action_module._task.args = 'Failed as requested from task'
    action_module._task.args = str(10840428)
    action_module._task.args = 'Failed as requested from task'
    action_module._task.args = b'\x15\xce\xe8\x86\xeb\xbe\x9f\xb8N\x0c\xdc\xab\x1d'
    action_module._task.args = ['Failed as requested from task', 'Failed as requested from task']
    action_module.run()

# Generated at 2022-06-25 06:49:15.169725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = dict()
    action_module_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    int_0 = -1830080662
    var_0 = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    assert (var_0['failed'] == bool_0)

# Generated at 2022-06-25 06:49:18.886940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_0 = ActionModule()
    runtime_obj_0 = obj_0.run(test_case_0())
    assert runtime_obj_0 == test_case_0()

# Generated at 2022-06-25 06:49:26.684645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '|'
    int_0 = 172
    list_0 = []
    set_0 = set()
    int_1 = 169
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)

    # setup
    tmp = ()
    task_vars = dict()
    
    # perform the action
    result = action_module_0.run(tmp, task_vars)

    # verify results
    assert result['failed'] == True
    assert result['msg'] == 'Failed as requested from task'

# Generated at 2022-06-25 06:49:28.364384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False



# Generated at 2022-06-25 06:49:33.239256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f[@(IyRdY'
    int_0 = 157
    list_0 = []
    set_0 = set()
    int_1 = 1124
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    var_0 = action_module_0.run(None)

# Generated at 2022-06-25 06:49:37.069175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '$P{G3q'
    int_0 = 4
    list_0 = []
    set_0 = set()
    int_1 = 9
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:49:40.578701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'e%L*}~J-2\t>'
    action_module_0 = ActionModule(str_0, str_0)
    list_0 = []
    int_0 = 905
    var_0 = action_module_0.run(list_0, int_0)
    assert (var_0['failed'] == True)

# Generated at 2022-06-25 06:49:41.403155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:49:47.180659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case description
    # Tested method: run
    # Tested module: action
    str_1 = 'e%L*}~J-2\t>'
    int_2 = 183
    list_1 = []
    set_1 = set()
    int_3 = 1176
    action_module_1 = ActionModule(str_1, int_2, list_1, set_1, int_3, str_1)
    tmp = None
    task_vars = dict()
    var_1 = action_module_1.run(tmp, task_vars)
    # Test case description
    # Tested method: run
    # Tested module: action
    str_2 = '8Vv*C[!_7]'
    int_4 = 30
    list_2 = []
    set_2

# Generated at 2022-06-25 06:49:51.646319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Mv[6c&/7'
    int_0 = 165
    list_0 = []
    set_0 = set()
    int_1 = 2336
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:49:55.331769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '/j%8`H'
    int_0 = 25
    list_0 = []
    set_0 = set()
    int_1 = 639
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:50:01.591171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'R^@"+@'
    int_0 = 524
    list_0 = [False, 1, True, '2', '3', '4']
    set_0 = set()
    int_1 = 466
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    task_vars = dict()
    var_0 = action_module_0.run('', task_vars)
    assert var_0 == dict()

# Generated at 2022-06-25 06:50:15.082545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'e%L*}~J-2\t>'
    int_0 = 183
    list_0 = []
    set_0 = set()
    int_1 = 1176
    # Create an instance of the class ActionModule
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    # Python variable tmp
    tmp = None
    # Python variable task_vars
    task_vars = None
    # Call method run
    result = action_module_0.run(tmp, task_vars)
    assert True

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 06:50:18.531413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:50:20.668262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_0 = ActionModule()
    var_0 = class_run()


# Generated at 2022-06-25 06:50:24.870382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Inspect the following action_module_0.run call
    assert False


# Generated at 2022-06-25 06:50:33.143077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'c$q^/0k0\t2\x0c'
    int_0 = 105
    list_0 = []
    set_0 = set()
    int_1 = 1144
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    action_run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:50:34.009951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:50:43.343206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '^9#4/Bkqs'
    int_0 = 1521
    list_0 = []
    set_0 = set()
    int_1 = 995
    int_2 = 637
    list_1 = []
    dict_0 = dict()
    dict_1 = dict()
    dict_0['msg'] = 'Failed as requested from task'
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    action_module_0.run(list_1, dict_0)
    dict_0['msg'] = 'custom message'
    action_module_0.run(dict_1, dict_0)


# Generated at 2022-06-25 06:50:51.224978
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'e%L*}~J-2\t>'
    int_0 = 183
    list_0 = []
    set_0 = set()
    int_1 = 1176
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    var_0 = action_module_0.run('test_param')
    # Tests to add
    # Make sure we can not override the fail message
    # Make sure we get the correct fail message
    # Make sure we can override the fail message
    # Make sure we can't override the fail message with the task.args
    # Make sure we can override the fail message with the task.args

# Generated at 2022-06-25 06:50:57.622240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = 'e%L*}~J-2\t>'
  int_0 = 183
  list_0 = []
  set_0 = set()
  int_1 = 1176
  action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
  var_0 = action_module_0.run()
  assert var_0 == 0

# Generated at 2022-06-25 06:50:59.053654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:51:12.163022
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:51:15.473754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    action_module_0 = ActionModule(var_0)
    var_0 = action_module_0.run()
    assert not (var_0)

# Generated at 2022-06-25 06:51:22.033757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '09S/VB\nY`'
    int_0 = 196
    list_0 = []
    set_0 = set()
    int_1 = 605
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:51:28.030970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'zunX-%2\x1d{'
    int_0 = 548
    list_0 = [
        'o',
        '\t',
        '|',
        'a',
        's',
        '\x13',
        'S',
        ']',
        'i',
        '%',
        '<',
        'i',
        '\r',
        '\r',
        '\x0e']
    set_0 = set()
    int_1 = 34
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:51:31.667023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'e%L*}~J-2\t>'
    int_0 = 183
    list_0 = []
    set_0 = set()
    int_1 = 1176
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    dict_0 = dict()
    dict_0 = action_module_0.run(dict_0)
    

# Generated at 2022-06-25 06:51:36.915986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'H0'
    int_0 = 175
    list_0 = []
    set_0 = set()
    int_1 = 1205
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    action_run()

# Generated at 2022-06-25 06:51:42.217250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'V?#I>K'
    int_0 = 590
    list_0 = []
    set_0 = set()
    int_1 = 1594
    dict_0 = dict()
    str_1 = 'xyLz,B9\rN'
    str_2 = 'bTdT'
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()

# Generated at 2022-06-25 06:51:46.489258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create instance of class
    action_module_0 = ActionModule()
    # create variable
    var_0 = str()

    # call method run
    result = action_module_0.run(var_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:51:50.258528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '4i4'
    int_0 = 880
    list_0 = []
    set_0 = set()
    int_1 = 1081
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    action_module_0.run(list_0, list_0)

# Generated at 2022-06-25 06:51:54.310666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule.run()')

    # Set up
    action_module_0 = ActionModule('', 0, [], set(), 0, '')

    # Positive tests
    action_module_0.run()

    # Negative tests

# Generated at 2022-06-25 06:52:16.183094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 06:52:17.866594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == "Failed as requested from task"

# Generated at 2022-06-25 06:52:22.011468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'T6]aO'
    int_0 = 578
    list_0 = []
    set_0 = {}
    int_1 = 64
    action_module_0 = ActionModule([], int_0, *set_0)
    var_0 = action_module_0.action_run()


# Generated at 2022-06-25 06:52:26.512907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'e%L*}~J-2\t>'
    int_0 = 183
    list_0 = []
    set_0 = set()
    int_1 = 1176
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    action_module_0.run()

# Generated at 2022-06-25 06:52:35.542704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'p'
    int_0 = 907
    list_0 = ['%#=y*-B89>', 'boJ|W2+DZ', '+.^=Ovj8', '-5]!y5%5O', '0(8*jWG)<', '%#=y*-B89>', '.q_I:+"0[']
    set_0 = {'dqb{jxF*', 'bEA_o+P:z', '-sK`;D^_', '7V(mj#l'}
    int_1 = 766
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:52:40.559462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'c=2e*"@)bM[9'
    int_0 = -80
    list_0 = []
    set_0 = set()
    int_1 = 1241
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    dict_0 = dict()
    dict_0['msg'] = "Failed as requested from task"
    var_0 = action_module_0.run(dict_0, dict_0)
    assert var_0['msg'] == "Failed as requested from task"

# Generated at 2022-06-25 06:52:51.698731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x1c\x03\x1a\x1a\x1f\x1a\x1d'
    int_0 = 1045
    list_0 = []
    set_0 = set()
    int_1 = 19
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_1['msg'] = 'Failed as requested from task'
    dict_0['msg'] = 'Failed as requested from task'
    dict_0['failed'] = True
    dict_1['failed'] = True
    assert dict_0 == action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 06:52:52.999290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:52:59.693649
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'gj$r'
    task_vars_0 = None
    int_0 = 836
    list_0 = []
    set_0 = set()
    int_1 = 639
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    result = action_module_0.run(task_vars_0)
    assert result == None

# Generated at 2022-06-25 06:53:03.508880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_1 = dict()
    result = action_module_0.run(dict_0, dict_1)
    str_0 = result['msg']
    result_0 = str_0 == 'Failed as requested from task'
    msg_0 = result_0
    msg_0 = result_0
    return msg_0

# Generated at 2022-06-25 06:53:46.756164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'S'
    int_0 = 0
    list_0 = []
    set_0 = set()
    int_1 = 0
    int_2 = 0
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, int_2)
    var_0 = action_run()

# Generated at 2022-06-25 06:53:50.011260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test data
    tmp = None
    task_vars = None

    action_module_0 = ActionModule(tmp, task_vars)
    # Test execution of run method
    action_module_0.run(tmp, task_vars)

test_case_0()

# Generated at 2022-06-25 06:53:50.469446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:53:54.149017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'I#o\t,p'
    int_0 = 24
    list_0 = []
    set_0 = set()
    int_1 = 1366
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    action_module_0.run(int, set)


# Generated at 2022-06-25 06:54:00.082426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'L#>e*2'
    int_0 = 1802
    list_0 = []
    set_0 = set()
    int_1 = 1176
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    var_0 = action_run()
    assert var_0 == 'Failed as requested from task'

# Generated at 2022-06-25 06:54:07.058375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x03]\x0bX\x0b\x06\x1a\n}\x17'
    int_0 = 627
    list_0 = []
    set_0 = set()
    int_1 = 705
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    dict_0 = dict()
    var_0 = action_module_0.run(dict_0)

# Generated at 2022-06-25 06:54:15.080366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = '#Jp%s=s4'
    float_0 = float(str_1)
    str_2 = 'e%L*}~J-2\t>'
    int_2 = 183
    list_1 = []
    set_1 = set()
    int_3 = 1176
    action_module_1 = ActionModule(str_2, int_2, list_1, set_1, int_3, str_2)
    result_1 = action_module_1.run(float_1)
    assert result_1 == expected_result_1

# Generated at 2022-06-25 06:54:20.154229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'K\\'
    int_0 = 1533
    list_0 = []
    set_0 = set()
    int_1 = 1447
    str_1 = '-b}&$'
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_1)
    action_module_0.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 06:54:22.981257
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Tests for method run, arg1 equals to tmp
    param_1 = None
    param_2 = None
    result_1 = ActionModule.run(param_1, param_2)

    return result_1 == None

# Generated at 2022-06-25 06:54:29.499114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test test_ActionModule_run')
    # Setup test data
    str_0 = 'TecT[B|'
    int_0 = 441
    list_0 = []
    set_0 = set()
    int_1 = 1163
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    # Invocation of method run
    result = action_module_0.run()
    assert(result == {
        'failed': True,
        'msg': 'Failed as requested from task'
    })
    print('Test test_ActionModule_run succeed')
    # Setup test data
    str_0 = 'q3|G=4\'.Uf.6'
    int_0 = 1051
    list_0

# Generated at 2022-06-25 06:56:08.480095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '7'
    int_0 = -24
    list_0 = []
    set_0 = set()
    int_1 = 16
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    dict_0 = dict()
    action_module_0.run(dict_0)

# Generated at 2022-06-25 06:56:15.354656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    str_0 = 'e%L*}~J-2\t>'
    int_0 = 183
    list_0 = []
    set_0 = set()
    int_1 = 1176
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    
    # Testing before
    assert(action_module_0 != None)
    
    # Testing main
    # var_0 = action_run()
    # assert(var_0 == "")

if __name__ == '__main__':
    test_case_0()    
    #test_ActionModule_run()

# Generated at 2022-06-25 06:56:19.518584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run of class action_module')
    str_0 = 'e%L*}~J-2\t>'
    int_0 = 183
    list_0 = []
    set_0 = set()
    int_1 = 1176
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:56:23.498101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'V<l2\t'
    int_0 = 136
    list_0 = []
    set_0 = set()
    int_1 = 1234
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    var_0 = action_module_0.run(str_0, set_0)

# Generated at 2022-06-25 06:56:27.724016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'E9?xW8p'
    int_0 = 166
    list_0 = []
    set_0 = set()
    int_1 = 1176
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    str_1 = ''
    dict_0 = dict()
    var_0 = action_module_0.run(str_1, dict_0)
    assert var_0 is None


# Generated at 2022-06-25 06:56:29.519659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    msg = {'failed': True, 'msg': 'Failed as requested from task'}

    assert msg == action_module_0.run()


# Generated at 2022-06-25 06:56:33.984811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    str_1 = 'Failed as requested from task'
    dict_0 = action_module_0.run(None, None)
    str_2 = dict_get(dict_0, 'msg')
    assert not str_cmp(str_1, str_2)



# Generated at 2022-06-25 06:56:40.062482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'e%L*}~J-2\t>'
    int_0 = 183
    list_0 = []
    set_0 = set()
    int_1 = 1176
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:56:49.750495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '=*Vub/u'
    int_0 = 358
    list_0 = []
    set_0 = set()
    int_1 = 1176
    action_module_0 = ActionModule(str_0, int_0, list_0, set_0, int_1, str_0)
    var_0 = action_run()
    str_1 = 'o.>|.%c$'
    var_1 = action_run(str_1)
    str_2 = '7]u-A4^V'
    var_2 = action_run(str_2, str_2)

# Generated at 2022-06-25 06:56:50.635154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True