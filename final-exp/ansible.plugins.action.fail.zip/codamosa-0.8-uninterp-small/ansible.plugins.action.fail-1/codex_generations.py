

# Generated at 2022-06-25 06:47:15.578858
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:47:19.344832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(set_0, int_0, bytes_0, '_task', int_0, set_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:47:31.320933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 9
    set_0 = set()
    bytes_0 = b'\xd0\xce\xab\x96\x8b\x89\xc3\x0c\x8d\xf2\xa4J\xab\x10\x94\xfd\x86'
    str_0 = '8'
    action_module_0 = ActionModule(int_0, set_0, int_0, bytes_0, str_0, int_0, set_0)
    dict_0 = dict()
    dict_0.setdefault(str_0, float())
    dict_0.setdefault('msg', 'f4\x1baG\x85\xac\x1b\x0c\x9d\x97\xce')

# Generated at 2022-06-25 06:47:40.716755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -7094
    tuple_0 = (True, True)
    float_0 = 3.0
    str_0 = 'l<K\x9c\x15\x98\x14\xd1\xcd\xe4f\xc6\x1c\xe5\x97\xd5\x98\xbc\x15\x96w\xc4\\'
    set_0 = {tuple_0, tuple_0, float_0}
    dict_0 = {tuple_0: str_0, str_0: set_0}
    action_module_0 = ActionModule(tuple_0, int_0, set_0, str_0, float_0, set_0)
    action_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 06:47:50.190595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 532
    str_0 = '\xf3\xbf\xf9\x9b\x19\x94\x90'
    str_1 = '\xdb\x80\xea\xc4\x9c\xbe\x1a\x8b\x1bN\xe0\x98@\x9d'
    action_module_0 = ActionModule(set(), int_0, b'', str_0, int_0, set())
    task_vars = dict()
    result = action_module_0.run(set(), task_vars)
    assert (result['msg'] == str_1)

# Generated at 2022-06-25 06:47:58.636908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3744
    set_0 = {int_0, int_0, int_0}
    dict_0 = dict()
    bytes_0 = b'C\xa7\x19\x95A\xb3m\xbf\x8c\x9d\x9e'
    str_0 = '|Z\xd6\x18\xdd\xd7F\x14\xab\xeb\x8a\x8e'
    action_module_0 = ActionModule(set_0, int_0, bytes_0, str_0, int_0, dict_0)
    int_0 = 1575
    dict_0 = {int_0: int_0, int_0: int_0}
    action_module_0.run(dict_0, int_0)



# Generated at 2022-06-25 06:48:09.393725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2717
    set_0 = {int_0, int_0, int_0}
    bytes_0 = b's\x97\x9b\xaf\xdb\xa0\xa8\xb0\x88\xcc\xce'
    str_0 = 'NXzs'
    action_module_0 = ActionModule(set_0, int_0, bytes_0, str_0, int_0, set_0)
    dict_0 = dict()
    dict_0['msg'] = 'jinj'
    action_module_0._task = dict_0
    tuple_0 = (b'u\xad\x7f\x18\x9c\xb0\x82l\xb8\xd2\xa0',)

# Generated at 2022-06-25 06:48:17.739633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3367
    set_0 = {int_0, int_0, int_0}
    bytes_0 = b'\xe7\xf7:\xe6\xd9\x8b\x18\xba8\xe2\xc2#'
    str_0 = 'ikf~]S5_4RAxaa'

# Generated at 2022-06-25 06:48:28.363090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    set_0 = {int_0}
    dict_0 = {}
    int_1 = -0x6e3d6bd
    str_0 = 'oE'
    action_module_0 = ActionModule(set_0, int_0, None, str_0, int_0, set_0)
    set_1 = {int_1}
    dict_1 = {}
    dict_2 = action_module_0.run(dict_0, dict_1)
    assert dict_2['failed'] == True

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:48:37.027390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1875
    str_0 = '\xe4\xa3\x05'
    set_0 = {int_0}
    bytes_0 = b'\x97\xf9\x0f\x06\x1d\x90\x0f\x0e\x8b\x11'
    dict_0 = dict()
    action_module_0 = ActionModule(set_0, int_0, bytes_0, str_0, int_0, set_0)

    # call the method
    action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 06:48:46.561584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '_task'
    str_1 = 'msg'
    str_2 = 'failed'
    str_3 = 'msg'
    str_4 = 'Failed as requested from task'
    str_5 = 'action'
    str_6 = 'module'
    str_7 = 'fail'
    str_8 = 'rescue'
    str_9 = 'always'
    str_10 = 'always_run'
    str_11 = 'any_errors_fatal'
    str_12 = 'changed_when'
    str_13 = 'register'
    str_14 = '_attributes'
    str_15 = '_role_name'
    str_16 = 'connection'
    str_17 = 'delegate_to'
    str_18 = 'delegate_facts'
   

# Generated at 2022-06-25 06:48:48.372516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run(None, None)


# Generated at 2022-06-25 06:48:57.293283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict(
        msg='Failed as requested from task'
    )
    obj = ActionModule(dict())
    obj._task = dict({'args': args}) if args else dict()
    assert(obj.run() == dict({'failed': True, 'msg': 'Failed as requested from task'}))

if __name__ == '__main__':
    for i in dir():
        if i.startswith('test_'):
            print('%s: %s' % (i, eval(i + '()')))

# Generated at 2022-06-25 06:49:03.427633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check that the run method works correctly
    a_action_module = ActionModule()
    a_action_module._task = {"args": {"msg": "Failed as requested from task"}, "module_name": "fail"}
    task_vars = {'Now Playing': {}}
    tmp = 'Hello, world!'
    result = a_action_module.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'Failed as requested from task'

# Generated at 2022-06-25 06:49:07.581972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 06:49:11.540625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize the class
    obj_0 = ActionModule()

    # Call the method
    # TODO: Add other parameters
    result_0 = obj_0.run()

# Generated at 2022-06-25 06:49:16.346990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    ActionModule.run(tmp, task_vars)

# Generated at 2022-06-25 06:49:22.751680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task=dict(
            args=dict(
                msg='msg',
            ),
            delegate_to='delegate_to'),
        connection=dict(
            host='host',
            port='port',
            user='user',
            password='password'),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    msg = 'msg'
    task_vars = 'task_vars'
    tmp = 'tmp'
    assert action_module.run(tmp, task_vars) == dict(
        failed=True,
        msg=msg)

# Generated at 2022-06-25 06:49:28.111899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    Task = test_case_0()

    # Initialize object
    Task._task = Task._task
    ActionModule_1 = ActionModule(Task)

    # Call method run
    ActionModule_1.run()

# Generated at 2022-06-25 06:49:33.240791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_0 = Ansible()

    ansible_0.setup_basedir()

    action_module_0 = ActionModule(ansible_0, {'ansible_directory': '.'})

    task_vars_0 = ansible_0.default_vars

    tmp_0 = ansible_0.tmpdir

    ansible_0.run_action(action_module_0, tmp_0, task_vars_0)



# Generated at 2022-06-25 06:49:43.009711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with args
    str_0 = '_task'
    str_1 = '_task'
    str_arg_0 = '_task'
    str_arg_1 = '_task'
    str_arg_2 = '_task'
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
   

# Generated at 2022-06-25 06:49:54.111449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '_task'
    str_1 = 'args'
    str_2 = 'msg'
    str_3 = 'Failed as requested from task'
    str_4 = 'failed'
    str_5 = 'msg'

    action_module = ActionModule()
    # TODO: Setup ActionBase mock
    # str_6 = 'ActionBase'
    # action_base = Mock()
    # str_7 = 'run'
    # action_module._task = action_base
    action_module._task = MagicMock()
    action_module._task.args = {str_2: str_3}
    # result = action_module.run()
    # assertEqual(result[str_5], str_3)
    # assertEqual(result[str_4], True)
    # str_

# Generated at 2022-06-25 06:50:03.354479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    action_module_obj_0 = ActionModule()
    # verify (expect) each of the following
    # <code object run at 0x7fe0d3f3c1f0, file "test/runner/action_plugins/test_fail.py", line 32>
    # <code object run at 0x7fe0d3f3c8f0, file "test/runner/action_plugins/test_fail.py", line 32>
    # <code object run at 0x7fe0d3f3c1f0, file "test/runner/action_plugins/test_fail.py", line 32>
    # <code object run at 0x7fe0d3f3c8f0, file "test/runner/action_plugins/test_fail.py", line 32

# Generated at 2022-06-25 06:50:12.062404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'tmp'
    str_1 = 'result'
    str_2 = 'msg'
    str_3 = 'Failed as requested from task'
    str_4 = 'msg'
    str_5 = '_task'
    str_6 = 'args'
    str_7 = 'task_vars'
    str_8 = 'dict'

    # Add your pre-setup code here.

    # Add your code here.
    # Create an instance of the class under test.
    test_instance_0 = ActionModule()

    # Create an instance of a dummy class where the class under test
    # will get the object passed in as a parameter.
    # This dummy class only needs to contain the methods that will
    # be called by the code under test.

# Generated at 2022-06-25 06:50:13.957798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:50:19.152054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_class = ActionModule()
    str_0 = 'result'
    str_1 = '_task'
    str_2 = '_task'
    str_3 = 'result'
    str_4 = 'failed'
    str_5 = 'Failed as requested from task'
    str_6 = 'msg'
    str_7 = 'result'
    str_8 = 'msg'
    str_9 = 'Failed as requested from task'
    str_10 = 'result'
    str_11 = 'failed'
    str_12 = 'msg'
    str_13 = 'Failed as requested from task'
    dict_0 = getattr(module_class, str_1)
    str_14 = 'result'
    str_15 = 'failed'
    str_16 = '_task'
    str

# Generated at 2022-06-25 06:50:22.960945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    a = ActionModule()
    tmp = None
    task_vars = dict()
    result = a.run(tmp, task_vars)
    assert result.get('failed') is True
    assert result.get('msg') == 'Failed as requested from task'


# Generated at 2022-06-25 06:50:32.101717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('TaskTestCase.test_ActionModule_run()')

    mock_self__task = mock.MagicMock(spec=ActionModule._task)
    mock_self__task.args = {'msg': 'Failed as requested from task'}
    mock_self__task.args.get.return_value = 'Failed as requested from task'
    mock_tmp = None
    mock_task_vars = {'msg': 'Failed as requested from task'}
    mock_ActionBase_run = mock.MagicMock()
    mock_ActionModule_run_result = {'failed': True, 'msg': 'Failed as requested from task'}
    mock_ActionBase_run.return_value = {'failed': True, 'msg': 'Failed as requested from task'}
    mock_ActionModule_run_expected_result

# Generated at 2022-06-25 06:50:35.754161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    task_vars = {}
    tmp = "task_vars"
    result = action_module._ActionModule__run(tmp, task_vars)
    assert result is None


# Generated at 2022-06-25 06:50:40.602230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test: method - ActionModule_run")

    str_0 = 'Failed as requested from task'
    str_1 = "msg"
    str_2 = '_task'

    action_mod = ActionModule()
    setattr(action_mod, str_2, "test_case_0")

    action_mod.run("test_case_0")

test_ActionModule_run()

# Generated at 2022-06-25 06:50:51.524133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = -1697.804
    bool_1 = False
    int_1 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    str_2 = 'Failed as requested from task'
    str_3 = 'when evaluation is False, skipping this task'
    dict_0 = {'msg': str_3}
    action_module_0._task.args = dict_0
    dict_1 = {'msg': str_2, 'failed': True}

# Generated at 2022-06-25 06:50:55.461525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2
    bool_0 = False
    str_0 = 'zIGZKkSXHGK}m@'
    str_1 = 'D_R'
    float_0 = 3662.0
    bool_1 = False
    int_1 = -6
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = action_module_0.run(int_0)
    assert (None is var_0)

# Generated at 2022-06-25 06:51:07.534040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 4043
    bool_0 = False
    str_0 = 'test case 0'
    str_1 = '1b:y:0,!#b@I),B4f|[(Dq3fY'
    float_0 = -3361.7023
    bool_1 = True
    int_1 = -1270
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = action_module_0.run(int_0)

    assert_equals(var_0, 'Failed as requested from task')
    assert_equals(action_module_0.msg, 'Failed as requested from task')

# Generated at 2022-06-25 06:51:14.296701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_1 = 2244
    bool_0 = False
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = -1697.804
    bool_1 = False
    int_2 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_2)
    int_1 = None
    action_module_0.run(int_1)

# Generated at 2022-06-25 06:51:14.795109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:51:24.207306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2244
    bool_0 = False
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = -1697.804
    bool_1 = False
    int_1 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    # Call this function using any argument, just to make sure that it is callable.
    action_module_0.run(int_0)

# Generated at 2022-06-25 06:51:31.515658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2244
    bool_0 = False
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = -1697.804
    bool_1 = False
    int_1 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    int_0 = action_module_0.run(int_0)

# Generated at 2022-06-25 06:51:38.634573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -9909
    bool_0 = False
    str_0 = 'be=z;/0eg'
    str_1 = '8du*mVl{u)Om|c7zWxHv'
    float_0 = -543.65
    bool_1 = True
    int_1 = -3271
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = action_run(int_0)

# Generated at 2022-06-25 06:51:41.455769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    bool_0 = False
    float_0 = -1697.804
    bool_1 = False
    int_0 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_0)
    int_0 = -2
    var_0 = action_module_0.run(int_0)


# Generated at 2022-06-25 06:51:45.020776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    location = "tmp"
    task_vars = dict()
    action_module_instance = ActionModule(location, task_vars)
    assert "failed" in action_module_instance.run()

# Generated at 2022-06-25 06:52:00.225345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = -213
    str_0 = 'hX&[)jxGhBeW'
    str_1 = '!T0e_AF8$0~V'
    float_0 = -7523.281
    bool_1 = True
    int_1 = -867
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    dict_0 = dict()
    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    var_0 = action_module_0.run(object_0, dict_0, object_1, object_2, object_3)
    return var_0



# Generated at 2022-06-25 06:52:05.322289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2244
    bool_0 = False
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = -1697.804
    bool_1 = False
    int_1 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = int_0
    var_1 = action_module_0.run(var_0)


# Generated at 2022-06-25 06:52:11.972663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2244
    bool_0 = False
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = -1697.804
    bool_1 = False
    int_1 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = action_run(int_0)

# Generated at 2022-06-25 06:52:18.785472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_1 = -2819
    bool_0 = True
    str_0 = ' this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_1 = 442.936
    bool_1 = True
    int_0 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_1, bool_1, int_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)
    # Default values for parameters
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:52:23.180331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_2 = ActionModule(tmp, task_vars)
    str_2 = 'D{io*7V8'
    str_3 = '!B{'
    float_1 = 2266.0
    bool_2 = False
    var_1 = action_run(str_2, str_3, float_1, bool_2)

# Generated at 2022-06-25 06:52:30.442664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3383
    bool_0 = False
    str_0 = 'skip_ansible_lint'
    str_1 = 'task'
    float_0 = 169.5970
    bool_1 = True
    int_1 = -4304
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    int_1 = -5454
    dict_0 = dict()
    var_0 = action_run(int_1, dict_0)


# Generated at 2022-06-25 06:52:36.742646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data and test environment
    int_0 = 991
    bool_0 = False
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = -1697.804
    bool_1 = False
    int_1 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    # Call function under test
    action_module_0.run(int_0)


# Generated at 2022-06-25 06:52:44.507520
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_2 = 4045
    bool_2 = False
    str_2 = 'when evaluation is False, skipping this task'
    str_3 = '@}e>c!)t9ymGoR'
    float_1 = -1697.804
    bool_3 = False
    int_3 = -5454
    action_module_1 = ActionModule(bool_2, str_2, str_3, float_1, bool_3, int_3)
    var_1 = action_run(int_2)
    assert var_1 == 'Failed as requested from task'

# Generated at 2022-06-25 06:52:52.631223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'dX(q3@Ij'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = -1697.804
    bool_1 = False
    int_0 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_0)
    action_run(int_0)


# Generated at 2022-06-25 06:52:58.739118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  var_0 = 'when evaluation is False, skipping this task'
  var_1 = '@}e>c!)t9ymGoR'
  var_2 = -1697.804
  var_3 = False
  var_4 = -5454
  action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4)
  var_5 = action_run(2244)

# Generated at 2022-06-25 06:53:12.738190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with pytest.raises(ImportError):
        from ansible.plugins import action_plugin
    result = action_run(0)
    assert False
    assert result is None



# Generated at 2022-06-25 06:53:21.101838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1130
    bool_0 = True
    str_0 = 'E'
    str_1 = 'dd'
    float_0 = -1382.58
    bool_1 = True
    int_1 = 349
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    result_0 = action_module_0.run(int_0)
    assert result_0 == 0


# Generated at 2022-06-25 06:53:29.499685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    bool_0 = False
    bool_1 = False
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    action_module_0.run(arg_0)


# Generated at 2022-06-25 06:53:37.056385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2244
    bool_0 = False
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = -1697.804
    bool_1 = False
    int_1 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = action_run(int_0)


# Generated at 2022-06-25 06:53:42.358325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'L"@lE'
    str_1 = '<d{'
    float_0 = -1496.9
    bool_1 = True
    int_0 = -6821
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_0)
    bool_2 = False
    str_2 = 'q#O:7'
    str_3 = '|o"m'
    float_1 = -1947.1
    bool_3 = False
    int_1 = -4865
    action_module_0.run(bool_2, str_2, str_3, float_1, bool_3, int_1)


# Generated at 2022-06-25 06:53:49.246305
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2244
    bool_0 = False
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = -1697.804
    bool_1 = False
    int_1 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = action_run(int_0)



# Generated at 2022-06-25 06:53:55.669110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -3002
    bool_0 = True
    str_0 = 'v0emquC_!D&l'
    str_1 = '*B/xS|\x0eP{'
    float_0 = -4226.62
    bool_1 = True
    int_1 = -7360
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    int_2 = -9474
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_1['msg'] = 'msg'
    dict_0['failed'] = True
    dict_0['msg'] = dict_1['msg']

# Generated at 2022-06-25 06:53:57.806624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r'
    int_0 = 0
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 06:54:07.120048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -7836
    bool_0 = False
    str_0 = 'testing method test_ActionModule_run'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = 7283.935
    bool_1 = False
    int_1 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = action_module_0.run(tmp=int_0)

# Generated at 2022-06-25 06:54:17.171913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 7528
    bool_0 = True
    str_0 = 'R0<lT-?S/s$t{A'
    str_1 = '3qOS;uF7P'
    float_0 = -1635.46173
    bool_1 = False
    int_1 = -797
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    tmp_0 = None
    task_vars_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)

if __name__ == '__main__':
    test_case_0()

    test_ActionModule_run()

# Generated at 2022-06-25 06:54:49.310171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 211
    str_0 = 'rm -f /home/michael/ansible/action_plugins/action_plugins_michael.pyc'
    str_1 = 'rm -f /home/michael/ansible/action_plugins/action_plugins_michael.pyc'
    float_0 = 1703.791
    bool_0 = True
    int_1 = 6879
    action_module_0 = ActionModule(str_0, str_1, float_0, bool_0, int_1)
    var_0 = action_run(int_0)


# Generated at 2022-06-25 06:54:58.833202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0_0 = 0
    bool_0_0 = False
    str_0_0 = '1E=`~>'
    float_0_0 = -429.6869
    bool_0_1 = True
    int_0_1 = -784
    action_module_0_0 = ActionModule(bool_0_0, str_0_0, str_0_0, float_0_0, bool_0_1, int_0_1)
    var_0_0 = action_module_0_0.run()
    print(var_0_0)
    bool_0_2 = True
    bool_0_3 = True
    int_0_2 = -3179

# Generated at 2022-06-25 06:55:02.912348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 7012
    bool_0 = True
    str_0 = '#'
    str_1 = 'c1(y&'
    float_0 = -28.6261477662
    bool_1 = True
    int_1 = -6623
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = action_run(int_0)


# Generated at 2022-06-25 06:55:08.804119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'vK?n{=8RV5)5c#hjeVz'
    int_0 = 8191
    str_1 = 'CASES=\n  - name: "test ansible-test -v"\n    args: { msg: "The quick brown fox jumps over the lazy dog" }\n  - name: "test ansible-test -vv"\n    args: { msg: "do not instantiate ActionModule" }\n  - name: "test ansible-test -vvv"\n    args: { msg: "do not instantiate ActionModule" }\n  - name: "test ansible-test -vvvv"\n    args: { msg: "do not instantiate ActionModule" }'
    int_1 = 1562

# Generated at 2022-06-25 06:55:12.488170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_run = ActionModule(msg='Failed as requested from task')

# unit test for method run of class ActionModule

# Generated at 2022-06-25 06:55:15.933731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2244
    bool_0 = False
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = -1697.804
    bool_1 = False
    int_1 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    tmp_0 = None
    task_vars_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:55:21.105960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2
    bool_0 = False
    str_0 = 'f!d88n"n#q3G5InL'
    str_1 = 'when evaluation is False, skipping this task'
    float_0 = -428.29
    bool_1 = True
    int_1 = -7
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = action_module_0.run(int_0)



# Generated at 2022-06-25 06:55:27.321140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 7
    bool_0 = False
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = 1449.2204698424498
    bool_1 = True
    int_1 = 5349
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = action_module_0.run(int_0)
    print(var_0.msg)


# Generated at 2022-06-25 06:55:34.859759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2408
    str_0 = 'n?#{PfXG>~,|hZCe'
    str_1 = ',k^"h[,p.f"%`:OeX'
    float_0 = -1172.533
    bool_0 = True
    int_1 = 8578
    int_2 = 3025
    action_module_0 = ActionModule(int_0, str_0, str_1, float_0, bool_0, int_1)
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['ansible_play_hosts'] = list()
    dict_1['playbook_dir'] = str_0
    dict_1['inventory_file'] = str_0
    dict_

# Generated at 2022-06-25 06:55:41.526539
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 7257
    bool_0 = False
    str_0 = 'when evaluation is False, skipping this task'
    str_1 = '@}e>c!)t9ymGoR'
    float_0 = -1697.804
    bool_1 = False
    int_1 = -5454
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    int_0 = 1
    str_2 = '3!KMUuE7XU>e6-L'
    str_3 = '7C#+n6-[z*WK'
    int_2 = -2
    var_0 = action_run(int_2)

# Generated at 2022-06-25 06:56:41.792020
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    tmp = int()
    task_vars = dict()
    task_vars['msg'] = 'Failed as requested from task'

    action_module_0 = ActionModule(tmp, task_vars)
    result = action_module_0.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == '${msg}'

# Generated at 2022-06-25 06:56:51.009144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2479
    bool_0 = True
    str_0 = 'Jy~b+-n'
    str_1 = 'expect to fail the assertion'
    float_0 = 1327.085
    bool_1 = True
    int_1 = -2439
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = action_run(int_0)
    int_2 = -1309
    str_2 = 'New:%0mJ]HKn'
    str_3 = 'g#z6'
    float_1 = -229.449
    bool_2 = True
    int_3 = -3173

# Generated at 2022-06-25 06:56:59.374423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2909
    bool_0 = False
    str_0 = '_g:`%c[Q0EY0_'
    str_1 = 'when evaluation is False, skipping this task'
    float_0 = -1106.216
    bool_1 = False
    int_1 = -2406
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    var_0 = action_run(int_0)


# Generated at 2022-06-25 06:57:05.290347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -4165
    bool_0 = True
    str_0 = 'S~'
    str_1 = 'tasks/main.yml'
    float_0 = -1953.7
    bool_1 = True
    int_1 = 4
    action_module_0 = ActionModule(bool_0, str_0, str_1, float_0, bool_1, int_1)
    action_module_0.run(int_0, bool_1)
