

# Generated at 2022-06-25 06:47:03.028659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('in test_run')
    dict_0 = dict()
    action_module_0 = ActionModule()
    result = action_module_0.run(None, dict_0)
    print(result)
    assert result['failed']
    assert result['msg'] == 'Failed as requested from task'



# Generated at 2022-06-25 06:47:08.131086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 429

# Generated at 2022-06-25 06:47:12.358523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_vars_0 = {'msg': 'task_vars_0'}
    action_module_0.run(action_module_0, task_vars_0)

# Generated at 2022-06-25 06:47:16.682036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1426

# Generated at 2022-06-25 06:47:21.128137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1328
    list_0 = []
    str_0 = 'h.9|uneEd:]t8*\x0c'
    action_module_0 = ActionModule(int_0, list_0, list_0, list_0, str_0, str_0)
    str_1 = 'h.9|uneEd:]t8*\x0c'
    action_module_0.run(str_1)



# Generated at 2022-06-25 06:47:30.351777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1082
    str_0 = '\x0c1,qe'
    str_1 = "(\ndy[t-\x1d9CK\x13\x0c"
    str_2 = '5;W'
    str_3 = '3'
    action_module_0 = ActionModule(int_0, str_0, str_1, str_2, str_3, str_0)
    action_module_0._task = None
    assert (action_module_0.run() and False)



# Generated at 2022-06-25 06:47:36.165318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -12987
    list_0 = []
    str_0 = '~.\x0cq>Y5M@+\x7f^\x0c'
    action_module_0 = ActionModule(int_0, list_0, list_0, list_0, str_0)
    value_0 = action_module_0.run()
    assert value_0['failed'] == True


# Generated at 2022-06-25 06:47:47.264459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_2 = 2810
    list_1 = ['']
    list_2 = []
    list_3 = ['']
    str_1 = '\x0ck5\x7fE\x0e\x7f\x08\x7fDu\x0c\x7f\x08c%V\x7f'
    str_2 = '\x0ck5\x7fE\x0e\x7f\x08\x7fDu\x0c\x7f\x08c%V\x7f'
    action_module_1 = ActionModule(int_2, list_1, list_2, list_3, str_1, str_2)
    dict_0 = dict()
    dict_1 = action_module_1.run(dict_0)




# Generated at 2022-06-25 06:47:53.507020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 125
    list_0 = []
    list_1 = []
    list_2 = []
    str_0 = 'H'
    str_1 = '|g'
    action_module_0 = ActionModule(int_0, list_0, list_1, list_2, str_0, str_1)
    dict_0 = {}
    action_module_0.run(dict_0, dict_0)

# Test of test_case_0

# Generated at 2022-06-25 06:48:00.967517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2047
    list_0 = []
    str_0 = '<'
    action_module_0 = ActionModule(int_0, list_0, list_0, list_0, str_0, str_0)
    tmp = None
    task_vars = dict()
    dict_0 = action_module_0.run(tmp, task_vars)
    for key in dict_0.keys():
        assert key in dict_0.keys()


# Generated at 2022-06-25 06:48:05.026292
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test case with one possible pass through.
    if test_case_0():
        pass



# Generated at 2022-06-25 06:48:07.423101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    obj = ActionModule(tmp, task_vars)

    res = obj.run(tmp, task_vars)



# Generated at 2022-06-25 06:48:12.445432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None

    tmp_ActionModule = ActionModule(task=task_vars, connection=tmp, play_context=tmp, loader=tmp, templar=tmp, shared_loader_obj=tmp)
    int_0 = 1
    result = tmp_ActionModule.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'Failed as requested from task'

# Generated at 2022-06-25 06:48:21.592929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = dict()
    params['msg'] = None
    params['action'] = dict()
    params['run_once'] = False
    params['action']['name'] = 'fail'
    params['remote_user'] = 'root'
    params['action']['delegate_to'] = 'localhost'
    params['action']['local_action'] = 'debug'
    params['playbook'] = dict()
    params['playbook_dir'] = '/Users/swu/git/Cinnamon-CI-Test/analyze/res'
    params['action']['args'] = dict()
    params['action']['args']['msg'] = 'Failed as requested from task'
    params['action']['args']['var'] = 'Failed as requested from task'

# Generated at 2022-06-25 06:48:25.794658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_obj_0 = ActionModule()
    ActionModule_obj_0.run()
    try:
        test_case_0()
    except:
        ActionModule_obj_0.run()

test_ActionModule_run()

# Generated at 2022-06-25 06:48:30.684895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    x = ActionModule()
    ret = x.run(tmp, task_vars)

# Generated at 2022-06-25 06:48:31.853900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 429


# Generated at 2022-06-25 06:48:33.563540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_input = get_input()
    result = ActionModule.run(test_input)
    assert result == output


# Generated at 2022-06-25 06:48:38.910381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Creating an object of class ActionModule
    action_module_obj_0 = ActionModule()

    # Testing if the object was created correctly
    if not isinstance(action_module_obj_0, ActionModule):
        raise Exception()

    # Testing if the instance can call the run method
    action_module_obj_0.run()

# Generated at 2022-06-25 06:48:46.249562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    int_0 = 429
    int_1 = 429
    int_2 = 429
    str_0 = 'value'
    int_3 = 429
    str_1 = 'ok'
    int_4 = 429
    int_5 = 429
    action_module._play_context = Mock(name='_play_context')
    action_module._task = Mock(name='_task')
    action_module._task._role = Mock(name='_task._role')
    action_module._task._role.get_vars = MagicMock(name='_task._role.get_vars')
    action_module._task._role.get_vars.return_value.__getitem__().__getitem__().__getitem__().__getitem__().__setitem__().__getitem

# Generated at 2022-06-25 06:48:59.844270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'w(4,CKj3q&%z*'
    int_0 = 757
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    action_module_0.run()

# Generated at 2022-06-25 06:49:11.356086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'yM]\x83\x7f\x83\xab\x9a\x14\xa3\xec\xbd\xc8\xe1\x1a\x10\x80\x9b\x90'
    int_0 = -537
    complex_0 = None
    bytes_0 = b'\xba?\x9b\t\xa83\x90\x92\x0e\xc0\xb2m\x8e\x80\x00\x1f\x93\xb0\xd2\xc3\xea\x7f\x9f\xfd\xa6'
    float_0 = -784.24
    tuple_0 = (int_0, int_0, int_0, complex_0, bytes_0)
    dict

# Generated at 2022-06-25 06:49:21.072596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '{'
    int_0 = -23
    complex_0 = complex()
    float_0 = None
    bytes_0 = bytearray(b'\xfd\x14\x00\x19\x8d\xfe')
    tuple_0 = (dict(), str_0, tuple(), int_0, dict(), str_0, bytearray(), str_0)
    dict_0 = {}
    str_1 = '<'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    action_module_0.run()


# Generated at 2022-06-25 06:49:27.848869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None
    
    print("\n\n\n**** UNIT TEST: class ActionModule. Method: run. ****\n\n\n")
    
    # Test 1
    print("Test 1: When no task_vars or tmp are specified and msg is not in self._task.args")
    action_module_0 = ActionModule(None, None, None, None, None, None)
    var_0 = action_module_0.run(tmp, task_vars)
    assert(var_0['msg'] == 'Failed as requested from task')
    assert(var_0['failed'] == True)
    
    # Test 2
    print("Test 2: When msg is in self._task.args")

# Generated at 2022-06-25 06:49:29.052541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test cases might be used later.
    pass


# Generated at 2022-06-25 06:49:37.556919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r(!,1B.xBwxNH\\84n=hj'
    int_0 = -587
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    tmp = None
    task_vars = None

# Generated at 2022-06-25 06:49:42.197661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = 'GQ!R)l|\\^+vhe8W\\"'
    var_2 = (False, False, False, False)
    var_3 = {}
    var_4 = {}
    var_5 = '.'
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    action_module_0.run()
    assert action_module_0._task.args == {}


# Generated at 2022-06-25 06:49:42.626196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return None

# Generated at 2022-06-25 06:49:48.106969
# Unit test for method run of class ActionModule
def test_ActionModule_run():    
    str_0 = 'r(!,1B.xBwxNH\\84n=hj'
    int_0 = -587
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    list_0 = [dict_0, bytes_0, tuple_0, int_0, tuple_0]
    str_1 = ')'

# Generated at 2022-06-25 06:49:52.100005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test cases
    assert True


# Generated at 2022-06-25 06:50:03.951704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = None
    str_1 = 'Bz\x9a\x02\x8c\xe6\x80\x89\x0b\xe8\xdd\x1f\x9a\xe3\x96\xe2\xbf\xa7\xbb\xa9\xf0\x9c\x13\xb3\x83\xe1\xad\x90\xb2v'
    int_2 = 1540
    complex_1 = None

# Generated at 2022-06-25 06:50:10.579510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '='
    int_0 = -0xe
    tuple_0 = ()
    dict_0 = {}
    dict_1 = {str_0: tuple_0}
    str_1 = '\x7f\x9c\x7f\x04\xb3\xd3\x1d\xd2H\x1f'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_1, str_1)
    var_0 = action_run()

# Utility method for tracing the module

# Generated at 2022-06-25 06:50:13.517099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:50:16.435894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ','
    int_0 = -1137
    tuple_0 = (str_0, )
    dict_0 = {}
    str_1 = 'o'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    action_module_0.run()


# Generated at 2022-06-25 06:50:25.912669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r(!,1B.xBwxNH\\84n=hj'
    int_0 = -587
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    tmp = None
    task_vars = None

# Generated at 2022-06-25 06:50:32.615306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '*=Z?$8#'
    int_0 = -4
    tuple_0 = (int_0, int_0, int_0, int_0)
    dict_0 = {}
    str_1 = 'X'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    var_0 = action_run()

# Generated at 2022-06-25 06:50:42.671021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r(!,1B.xBwxNH\\84n=hj'
    int_0 = -587
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    tmp_0 = None
    task_vars_0 = {}
    var_0 = action_

# Generated at 2022-06-25 06:50:50.930424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -268
    str_0 = 'r(!,1B.xBwxNH\\84n=hj'
    complex_0 = None
    float_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    var_0 = action_run()

# Generated at 2022-06-25 06:51:00.532566
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:51:06.234775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ''
    int_0 = -19
    tuple_0 = (None, None, None, None)
    dict_0 = {}
    dict_1 = {}
    str_1 = ''
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_1, str_1)
    var_0 = action_run()
    var_1 = action_run()

# Generated at 2022-06-25 06:51:22.236970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    int_0 = 4216
    list_0 = []
    tuple_0 = (int_0, list_0)
    dict_0 = {}
    str_0 = '1'
    action_module_0 = ActionModule(var_0, int_0, tuple_0, dict_0, dict_0, str_0)
    var_1 = action_module_0.run()



# Generated at 2022-06-25 06:51:28.226471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'H'
    int_0 = -581
    tuple_0 = (None, None)
    dict_0 = {}
    dict_1 = {}
    str_1 = 'a'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_1, str_1)
    complex_0 = None
    bytes_0 = b'\xaf"\x0e\xd4\x13\x0c\xd6\xe5\x99\x19\xb9\xbe\r\xa3\x8d\x8c\xcf'
    float_0 = 5.47
    tuple_1 = (complex_0, bytes_0, float_0, float_0)
    str_2 = '6'
    action_run

# Generated at 2022-06-25 06:51:30.837559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tmp = None
  task_vars = None
  action_module = ActionModule(tmp, task_vars)
  result = action_module.run()
  tmp = None
  task_vars = None
  action_module = ActionModule(tmp, task_vars)
  result = action_module.run()

# Generated at 2022-06-25 06:51:33.140337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:51:40.926830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = { 'hello': 'world'}
    str_0 = ')aGL3|\x1b'
    int_0 = -387
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (str_0, int_0, int_0, bytes_0, float_0)
    str_1 = 'wD'

# Generated at 2022-06-25 06:51:50.465705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'S(o,h6LwU6]aU6N4'
    int_0 = -84
    complex_0 = None
    bytes_0 = b'\x86\xac\xa8\x0e\x0f\x17\xdd\xf0\xaa\xb1\xfd\x85'
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {'msg': 'msg', 'task_vars': None}
    dict_1 = {}
    str_1 = '-'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_1, str_1)
    float_1 = float('inf')
    float

# Generated at 2022-06-25 06:51:56.248299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r(!,1B.xBwxNH\\84n=hj'
    int_0 = -587
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    var_0 = action_run()
    return

test_case_0()

# Generated at 2022-06-25 06:52:00.562189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Imports
    # Import statements come first
    ActionModule.run()
    print("Unit test for method run of class ActionModule")
    # Unit test code


# Generated at 2022-06-25 06:52:07.065619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '66\x1f\xb1\xbb\x8d'
    int_0 = -587
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)

# Generated at 2022-06-25 06:52:15.075518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '?=!h\xbe\x8d'
    int_0 = 1
    tuple_0 = (int_0,)
    dict_0 = {'tmp': int_0}
    str_1 = '4\xe4\x17\x7f\xcc\r6\x8f\xbbm\x96'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    var_0 = action_run('/', action_module_0)
    var_0 = action_run('K\x1e\x14x\xef\x0ew\x19(\x8b\x7f', action_module_0)

# Generated at 2022-06-25 06:52:36.805081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('msg=None')
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:52:41.015034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('', '', '', '', '', '')
    var_0 = action_run()


# Generated at 2022-06-25 06:52:51.768720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r(!,1B.xBwxNH\\84n=hj'
    int_0 = -587
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    var_0 = action_run()
    assert var_0.get('failed') is True
   

# Generated at 2022-06-25 06:53:02.081588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Unit test for method run of class ActionModule')
    # test function with two parameters
    str_0 = 'r(!,1B.xBwxNH\\84n=hj'
    int_0 = -587
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    int

# Generated at 2022-06-25 06:53:12.764690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'RPx,6o\x8f\x10>|U\x87\x0c'
    int_0 = None
    complex_0 = None
    bytes_0 = None
    float_0 = None
    tuple_0 = None
    dict_0 = {}
    str_1 = 'K'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    str_2 = '\xec71'
    int_1 = None
    complex_1 = None
    bytes_1 = None
    float_1 = None
    tuple_1 = None
    dict_1 = {}
    str_3 = '('

# Generated at 2022-06-25 06:53:19.967268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test data
    task_vars = {}
    result = {}
    # Execute the code to be tested
    action_module_0 = ActionModule('msg', result, task_vars)
    action_module_0.run()
    # Verify the results
    assert result == {'failed': True, 'msg': 'Failed as requested from task'}



# Generated at 2022-06-25 06:53:27.533243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'c:\\'
    int_0 = -87
    complex_0 = None
    bytes_0 = b''
    float_0 = None
    list_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ':'
    action_module_0 = ActionModule(str_0, int_0, list_0, dict_0, dict_0, str_1)
    var_0 = action_run()

# Generated at 2022-06-25 06:53:36.898197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'wjDr8'
    int_0 = -304
    complex_0 = None
    bytes_0 = b'\x1d+\x8a\x87\xe47\xdf\x95\x8f\x9a\xe6\x15\x94\x07\x01'
    float_0 = None
    tuple_0 = (float_0, bytes_0, float_0, float_0)
    dict_0 = {}
    str_1 = 'O'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    var_0 = run(float_0, tuple_0)

# Generated at 2022-06-25 06:53:37.653893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 06:53:41.516181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_2 = action_module_0.run(var_0, var_1)


# Generated at 2022-06-25 06:54:42.336172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '!7m!H?\xc8m%!,m!P\x9c'
    int_0 = 15766
    str_1 = '\x10\x1c\x8a\xbc\x9b:n'
    complex_0 = complex(int_0, -int_0)
    list_0 = [int_0, int_0]
    dict_0 = {'\x0b\x08\xd2\xed': int_0, ':': -int_0,
              'h\x02\x05': complex_0, '\x1d\x9a\xcd\xeb': complex_0,
              '\x1e\xcd\xe6\x03': complex_0, '\x11\x85': list_0}
    dict

# Generated at 2022-06-25 06:54:48.859862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r(!,1B.xBwxNH\\84n=hj'
    int_0 = -587
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:54:58.370257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'S)=;Jpy$:_#j+yM{D'
    int_0 = -967
    complex_0 = None
    bytes_0 = b'\x93\x12\xd3\xbcg\x9a|>\x95\x87\x07\xd8\x83\x98\x87\x1b\x1f\xab'
    float_0 = None
    tuple_0 = (float_0, complex_0, complex_0, bytes_0)
    dict_0 = {}
    str_1 = 'a'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)

# Generated at 2022-06-25 06:55:04.381295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r(!,1B.xBwxNH\\84n=hj'
    int_0 = -587
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    action_module_0.run()

# Generated at 2022-06-25 06:55:09.634838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ':'
    int_0 = -534
    action_module_0 = ActionModule(str_0, int_0)
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    result = action_run(action_module_0, tuple_0, dict_0, str_1)
    print(result)


# Generated at 2022-06-25 06:55:17.951974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '9*Vs$/>:T_f6Ew;s*s'
    int_0 = 6412
    complex_0 = None
    bytes_0 = b'O\xd7-\x02\xaf\\v\xe8\x1f\x9d\xc3\xfe\xcb\x02f\xaa\x08\xf3\x1b'
    float_0 = 4.7
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {2: 3, 1: 2, 0: 1}

# Generated at 2022-06-25 06:55:23.824059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:55:28.968756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r(!,1B.xBwxNH\\84n=hj'
    int_0 = -587
    complex_0 = None
    bytes_0 = b"\x9fU\xe4_\x1a\xf2E\x1a\xf2\x139\xb8'\xdc\x1c\x92\xb7\xd1"
    float_0 = None
    tuple_0 = (complex_0, bytes_0, complex_0, float_0)
    dict_0 = {}
    str_1 = ')'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_0, str_1)
    var_0 = action_run()


# Generated at 2022-06-25 06:55:39.645174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '1EQ(\x18\xd3\xab\x92\xbd:\xe0\x8a\xea\xcc\xe3f\x8e\xa0\x1b\xac\xc2\x8d\xec\x9c\x04\xd5'
    int_0 = -738
    complex_0 = None

# Generated at 2022-06-25 06:55:44.378404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'OcV7RfOyh-V7'
    int_0 = None
    tuple_0 = (int_0, int_0)
    dict_0 = {}
    dict_1 = {}
    str_1 = '<'
    action_module_0 = ActionModule(str_0, int_0, tuple_0, dict_0, dict_1, str_1)
    tmp_0 = None
    task_vars_0 = dict()
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    return str(var_0)
