

# Generated at 2022-06-25 06:47:05.268545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert (action_module.run(tmp=None, task_vars=None) == {'failed': True, 'msg': 'Failed as requested from task'})
    assert (action_module.run(tmp=None, task_vars=None) == {'failed': True, 'msg': 'Failed as requested from task'})
    assert (action_module.run(tmp=123, task_vars=None) == {'failed': True, 'msg': 'Failed as requested from task'})

# Generated at 2022-06-25 06:47:06.269070
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Shouldn't work
    test_case_0()

# Generated at 2022-06-25 06:47:11.296902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 528
    list_0 = [int_0]
    set_0 = {list_0, list_0, int_0}
    result = ActionModule(set_0, list_0).run(list_0, list_0)
    assert result['failed'] == True



# Generated at 2022-06-25 06:47:14.186163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = None
    task_vars = None
    
    result = action_module.run(tmp=tmp, task_vars=task_vars)


# Generated at 2022-06-25 06:47:15.639179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()


# Generated at 2022-06-25 06:47:17.617627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module = ActionModule()
  task_vars = dict()
  action_module.run(task_vars=task_vars)

# Generated at 2022-06-25 06:47:18.960051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    instance_0 = ()
    ActionModule.run(instance_0)


# Generated at 2022-06-25 06:47:19.776915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	assert ActionModule



# Generated at 2022-06-25 06:47:26.284320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = object()
    task.args = {}
    task_vars = {}
    tmp = 'tmp'

    action_module = ActionModule(task, {})
    result = action_module._execute_module(tmp, task_vars, tmp)
    assert result == {'failed': True, 'msg': 'Failed as requested from task'}


# Generated at 2022-06-25 06:47:28.574278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    list_0 = [action_module_0.run()]
    assert len(list_0) == 1

# Generated at 2022-06-25 06:47:37.344331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'T!\x1d\t\x1a\x81\xd9\x18\xfaP\xfa\xaf\x1f'
    set_0 = set()
    float_0 = -2.314974411662673e-06
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    float_1 = 0.6420574444444444
    int_0 = -1019
    bytes_0 = b'%\xce\x03\x8a\xfa+\xfa\xcc\xac\xfc\xd2\x7f\x1d'

# Generated at 2022-06-25 06:47:48.499724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '? \x0b+ay2X3_4kua(sK\t%m'
    set_0 = set()
    float_0 = -3444.4
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1019
    bytes_0 = b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)
    dict_0 = dict()
    dict_

# Generated at 2022-06-25 06:47:57.295975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = ')3m\xd4sqQ_e'
    set_0 = set()
    float_0 = 337.9463
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -48
    bytes_0 = b'n\x11#\x81\x83\x07+\x0c\x81\xd5\xfb\x17\xf6D'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:48:03.161113
# Unit test for method run of class ActionModule
def test_ActionModule_run():

  # Test case with good input
  action_module_0 = ActionModule()
  var_0 = action_module_0.run()
  assert var_0 == 'Passed'

  # Test case with bad input
  action_module_0 = ActionModule()
  var_1 = action_module_0.run()
  assert var_1 != 'Failed'

# Generated at 2022-06-25 06:48:09.924360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '!'
    set_0 = set()
    list_0 = [str_0]
    list_1 = [set_0]
    int_0 = -56
    bytes_0 = b'\x9f{z\x8b\x14\xbc\x12\xc3\xfb\x83\xeaYB\xa6\x9e'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_1, int_0, bytes_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:48:18.287801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None)
    assert isinstance(action_module_0, ActionModule)
    action_module_0.run()
    tuple_0 = ()
    str_0 = 'l$K\x1f\x9d\xc3'
    set_0 = set()
    dict_0 = dict()
    tuple_1 = (str_0, set_0, dict_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -71623
    bytes_0 = b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z'

# Generated at 2022-06-25 06:48:30.491241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'J\xdd\xa2\x03\x84\xc7\x1c\x04\xc6n\x0b\x00'
    set_0 = set()
    float_0 = -3444.4
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1019
    bytes_0 = b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z'

# Generated at 2022-06-25 06:48:39.397765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'w\x0b\xf8\x16\xd7L\xcf\x0e\x1f\x1a\x0e"\x04!\x9e>'
    set_0 = set()
    float_0 = 1.101651678
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -8604
    bytes_0 = b'\xce\xa1\x11\x07I\xee\x9b\x8a\x11\x0b\xc4\x8d\xaa\x04\xca\xd9\xe7\xc8z'
    action

# Generated at 2022-06-25 06:48:46.561422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'k\x80\xbd\xa5\x00'
    set_0 = set()
    float_0 = -3006.0
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = []
    int_0 = 0
    bytes_0 = b'\x1e\x9f'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)
    str_1 = 'Failed as requested from task'
    str_2 = 'msg'
    dict_0 = {str_2:str_1}
    action_module_0._task = dict_0

# Generated at 2022-06-25 06:48:48.012148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:49:03.067864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'X$[\x82\x0f\x82\x84\x14\xce\x18B\xa7\x93\xf5\xdd\x8c\x99\x93\xfa\x1f\x07\x10\xcc\xdd\x87\xc8\xa5_\xbf\x87\x1d\xb2\x1f\xdc\x87\xed\x0b\xd7\xbb\xbc\x8d\x9b\x84\xb9\x06\x03|\xc0\xbd'
    set_0 = set()
    float_0 = -3444.4
    tuple_1 = (str_0, set_0, float_0, tuple_0)

# Generated at 2022-06-25 06:49:13.556707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_1 = ()
    str_0 = 'y\x1b\x1bY\xc2\x1e\x8e\x0c\xdd\x14\xa3\x8e\x9d'
    dict_0 = {}
    float_0 = -11.3
    tuple_0 = (str_0, dict_0, float_0, tuple_1)
    list_0 = [tuple_0, tuple_0, tuple_0]
    int_0 = -1213
    bytes_0 = b'\x98\xa6\x1a\xd4\x97\xa9>\xac\xdc|\x1f\x94\x08\xa7\xcc\x97'

# Generated at 2022-06-25 06:49:18.654369
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:49:25.837828
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [(), (), ()]
    set_0 = set()
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, -1019, b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z')
    var_0 = action_run()


test_case_0()
# test_ActionModule_run()

# Generated at 2022-06-25 06:49:35.974980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = ';x\x1b\x9f\x0b\xd5\xf7\xa5\x00\xc5b\xec\xab0\xdf\x15\xbb\x99\x1a\x92\x13\x8a\xe2\xcc\xd6\x9b\xe8\xb4\x0b\x85\x89\x898\x0b\xad\x9f\xcc\xd3\x7f\xc6\xab\x1d\xc4N\x00\x12\xb3\x06\x9f\xb8\x0e\xf2\x1ft?\xd8D\xb7\x84\xe6'
    set_0 = set()
   

# Generated at 2022-06-25 06:49:43.135423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'I%'
    set_0 = set()
    float_0 = -917.7
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = 107
    bytes_0 = b'\x8b\x16\xba\x93\xe4\x8e\xcd\x17\xd1\x0e\xec\x14\xca\xf0A\x1e\xfd\x96\xe4\x17\xec\xdb\x81\xb6\xed\xf1\n\xf7\xe1\xb0\xe60\xc9'

# Generated at 2022-06-25 06:49:50.014968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = set()
    int_0 = 0
    bytes_0 = b'\x00'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:50:00.762060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = ' '
    set_0 = set()
    float_0 = -60.9
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -278
    bytes_0 = b'\x1d\x9a\xfd\x84\xbf,\xa4E\xfb\xb7\x8c\x12]\x9b\xf0'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)

# Generated at 2022-06-25 06:50:11.183138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '? \x0b+ay2X3_4kua(sK\t%m'
    set_0 = set()
    float_0 = -3444.4
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1019
    bytes_0 = b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)
    action_module_0.run()
   

# Generated at 2022-06-25 06:50:19.231313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'X\xba\xad\x16\xad\x1e\x0c\xa4\x94\x0b\x0f\x08'
    set_0 = set()
    float_0 = 0.364006915307
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -17250
    bytes_0 = b'\x1c\x0e\x0f\xbe\xe2'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)
    var_0 = action_module_0

# Generated at 2022-06-25 06:50:34.089874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ("\n\x12\t\n\t\n\t\n\t",)
    set_0 = {"\n\x12\t\n\t\n\t\n\t",}
    list_0 = [None, "\n\x12\t\n\t\n\t\n\t", set_0]
    list_1 = []
    dict_0 = {}
    list_2 = []
    str_0 = '\n\x12\t\n\t\n\t\n\t'
    bytes_0 = b'\x11.>\x0f\x93]o\x8b\xee\xdb\x85\xb9A\x8e>'

# Generated at 2022-06-25 06:50:43.676132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We just make sure the constructor doesn't fail
    tuple_0 = ()
    str_0 = '? \x0b+ay2X3_4kua(sK\t%m'
    set_0 = set()
    float_0 = -3444.4
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1019
    bytes_0 = b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)

# Generated at 2022-06-25 06:50:44.245429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:50:52.420575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'c\xb5\xbb\xa5\xf7\x94\x01\xfa'
    set_0 = set()
    float_0 = -6272.4
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -6070
    bytes_0 = b'\xbd\x03\x17\x8d\xa9\xbd\xbd\x9b\xab\xd0\xe1\xf1\x7f\x8f\x89\xdd\x93'

# Generated at 2022-06-25 06:50:57.432186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '/\x0c\x08\x06\x12\x04D'
    set_0 = {str_0}
    float_0 = -5.5
    list_0 = [set_0, str_0, str_0, set_0, set_0, float_0, set_0, set_0, float_0]
    list_1 = [str_0, str_0, set_0, str_0, str_0, set_0, set_0, set_0, set_0, str_0]
    dict_0 = {'msg': 'Failed as requested from task'}
    int_0 = 145
    bytes_0 = b'\x12\x03\xdc\xf2\xee\xf0\x06'


# Generated at 2022-06-25 06:51:04.278849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'os\x10\xd9\x02\xa5\xec*\xdc\x1d\xee\xfa\xc8\xd1\x9f\xa3\x97\x8f\xbdkb\x03'
    set_0 = set()
    float_0 = 0.1264339855
    tuple_1 = (set_0, set_0, str_0, float_0, set_0)
    list_0 = [tuple_0, tuple_1, tuple_1]
    int_0 = 19938
    bytes_0 = b'\x1a\x02\xa3\x0b{\x0b'

# Generated at 2022-06-25 06:51:13.759826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'q3s\x0b-|X9\x88e'
    set_0 = set()
    float_0 = -619.0
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1
    bytes_0 = b'\x07\xae\x9e\x9d\x07\xb5\x96\xd5\xf7\x1b\x0b\xe4\x9f\x9a\xee\xf3\xa2\x14\x94\xfa\x11\xfb\xef\xbb\xf1'

# Generated at 2022-06-25 06:51:15.753242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input variables

    # Local variables
    dict_0 = {}
    # ADD CODE HERE

    # Invoke method
    ActionModule(dict_0)
    # Output return values

# Generated at 2022-06-25 06:51:25.545381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '\x0b\x0bA\x13\x1f\r'
    set_0 = set()
    float_0 = 0.0049
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1019
    bytes_0 = b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)
    var_0 = action_run()



# Generated at 2022-06-25 06:51:32.924386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '? \x0b+ay2X3_4kua(sK\t%m'
    set_0 = set()
    float_0 = -3444.4
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1019
    bytes_0 = b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)
    
    assert action_module_0.run

# Generated at 2022-06-25 06:52:00.863007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'S\x0eZ\x1f\x03\x8c$\x1dI\xb4'
    str_1 = 'ar'
    str_2 = '\x03'
    str_3 = '\n\t'
    str_4 = '~'
    str_5 = '\x0b'
    str_6 = '@\x14\x0cX\x1fZ'
    str_7 = '$\x93\x16y\x1f\x1b'
    str_8 = '\x02\x03\x10\x13W\x19\x1d'
    str_9 = '\x03\n\n\x06\x16'

# Generated at 2022-06-25 06:52:07.281309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'hUU(6p0\x1e\x1aQ=\x1d\x14'
    str_1 = '\x10f\x06\n\x1c\x1f\x1e\x01\x15\x0b\x0b'
    set_0 = set()
    float_0 = -4149.4
    tuple_1 = (str_0, set_0, float_0, tuple_0, str_1)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -2032
    bytes_0 = b'\n\xb7\xda\x83\x14\x96\x1e\x18\x1e\x80\xf9'


# Generated at 2022-06-25 06:52:15.149601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'O|j+cu\x0c\\5\tP\x8dBi\x05\x1b]\xa3|\x8d'
    set_0 = set()
    float_0 = -3444.4
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1019
    bytes_0 = b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z'

# Generated at 2022-06-25 06:52:15.642426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-25 06:52:25.588337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '7\r\x1a\x94\x86\x1d\x1e\xc4\xba\x8e\xe2Sd\x87\x1f\x8c'
    set_0 = set()
    float_0 = -17.08
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1642
    bytes_0 = b'3\x17\x12\xab\x80\x95\x92\x04\x5f\x03\xa6\x90\xa0\xc5'

# Generated at 2022-06-25 06:52:34.900159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '? \x0b+ay2X3_4kua(sK\t%m'
    set_0 = set()
    float_0 = -3444.4
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1019
    bytes_0 = b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)

# Generated at 2022-06-25 06:52:36.057615
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert var_0 == None

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:52:46.909512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '{Q`\x0b\x17\x8c\xa9\x12\xbf\x1fF]\xf5C\xbc\x93'
    set_0 = set()
    float_0 = -1061.4924
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1060
    bytes_0 = b'\x1f_\xdd\x07\x12\x1a\xfe\x17\x81\x06\x94\xd4\xbc\xe4\x1d\xbd\xb8\x9a\x94M\xcb'
   

# Generated at 2022-06-25 06:52:56.773323
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = (False, None, None)
    dict_0 = dict()
    str_0 = ';.\x1e&\x1ef\x14\x073\x12\x0e\x0c\x0b\x06\x03\x1e\x0e'
    bytes_0 = b'\xdc\x93\x88\x9a\xaa\xaf\x88\xf5\x96\x88\xdc\x8c\xea\x89\xc0\xd2\x8b\x82\x8b\x94\x8b\x82\x9d\x82\xa7\x80\xb1\x80\xbb\x8b\xd8'

# Generated at 2022-06-25 06:53:04.893946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '\xccr\xde\xdd\xa1{zW\xe8\x7f'
    set_0 = set()
    float_0 = -13804.8
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1019
    bytes_0 = b't\xf8\x92\x9c\xd1\xaf\xec\x0c\\O\xed!\x07\x8c*\x1b'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)


# Generated at 2022-06-25 06:53:48.046263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_arg_0 = ['']
    file_path = str()
    result = action_module_0.run(task_vars=list_arg_0, tmp=file_path)

    # Test the results
    assert result == {'msg': 'Failed as requested from task', 'failed': True}

# Generated at 2022-06-25 06:53:50.286637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # setup
        setup()

        # test
        try:
            assert call_target_method(target_method_name) == "expected result"
        except AssertionError:
            raise
    finally:
        # cleanup
        cleanup()

# Generated at 2022-06-25 06:53:57.087620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '\xfe\x0e7\x9f\xc7\x1c\xeb\t\xe0\xab\xa6\xca1\x8f\x9b9!\x04\x84\t\xe6\xab[\xcb\xca\xd8r\x99\x9d\x9c\x08\x19\xde\x0b\xba\xc2\xcd\xe3\xed\xc6\xeb\xb8'
    set_1 = set()
    float_0 = -32.14e+11
    tuple_1 = (str_0, set_1, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]


# Generated at 2022-06-25 06:54:03.448649
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'vj|\x1c\x0f'
    set_0 = set()
    float_0 = -4270.972
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1019
    bytes_0 = b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)
    action_run(action_module_0)

# Generated at 2022-06-25 06:54:10.381862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '? \x0b+ay2X3_4kua(sK\t%m'
    set_0 = set()
    float_0 = -3444.4
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1019
    bytes_0 = b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)
    tmp = None

# Generated at 2022-06-25 06:54:19.974522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = ')}t'
    set_0 = set()
    float_0 = 1589.7
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1464
    bytes_0 = b'\x10\x1b\xc7f\x99\x1cV\x94\xe2\x9d\xb1\x87\x91\x90>'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:54:27.711811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '+\t\xae\x0f\xc5\t\xd7\x0e\x97\xeb\x8f\x0f\x9e3'
    set_0 = set()
    float_0 = 4.99
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1, tuple_1]
    int_0 = 358
    bytes_0 = b'\x0c\x02\xe4\xa9\x01\xa4\xea\xaf\x01\x0c\xeb\x98\x0f\x9e\xf7\xdc\x0c\x0f\xab'


# Generated at 2022-06-25 06:54:37.683491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '\x1e\x0f"\x06\x03\x0e\x1f\x1b\x08\x1a\x14\x1f`\x0e-'
    set_0 = {str_0}
    float_0 = -2451.5
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]

# Generated at 2022-06-25 06:54:45.360996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '<V\x0bA\x7f\x13\x7f\x1e'
    set_0 = set()
    float_0 = -1071.0
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = 75
    bytes_0 = b'q\xc3\x1f\x19\x02\xcc\x8a\xbf\x05\x9f\x95g'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:54:46.876589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()
    assert var_0 == None

# Generated at 2022-06-25 06:56:37.759924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = ','
    set_0 = set()
    int_0 = 7456
    list_0 = [str_0, str_0, set_0, set_0, int_0, int_0, int_0]
    float_0 = -1054.8
    list_1 = [float_0, float_0, float_0]
    dict_0 = dict()
    bytes_0 = b'\x15\xb0+\x92\x8d\xcd\x0f\x9e\x1dt'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_1, dict_0, bytes_0)
    action_module_0.run()


# Generated at 2022-06-25 06:56:44.263587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '\x1b+\n\t]\x1f\x15e#@\x12\x0e\x1a\t\x0c\xe9\x93\x04\x90\x13\x92'
    set_0 = set()
    float_0 = -826.9
    tuple_1 = (str_0, set_0, float_0, tuple_0)
    list_0 = [tuple_1, tuple_1, tuple_1]
    int_0 = -1019
    bytes_0 = b'\x17\x03\xea\xad\xa1\xe1r\x0f\x98\x7f~R\xd1z'

# Generated at 2022-06-25 06:56:47.344198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {
        'msg': 'Failed as requested from task'
    }
    assert ActionModule.run(args) == {
         'failed': True,
         'msg': 'Failed as requested from task'
    }



# Generated at 2022-06-25 06:56:57.411485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'Gv{8W|q3E\x07\x0c\x1f\x1d*\x0b\tx\x0b\x16\x12'
    set_0 = {str_0}
    float_0 = -5734.5
    list_0 = [str_0, set_0, float_0, tuple_0]

    int_0 = -70
    bytes_0 = b'\x9c\xff\x15\x8a\xab`\x93\x14\x1f\n\x03>\xf4\x9e\x91'
    action_module_0 = ActionModule(tuple_0, list_0, set_0, list_0, int_0, bytes_0)

    #