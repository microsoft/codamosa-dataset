

# Generated at 2022-06-25 06:47:08.849741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arguments
    tmp = None
    task_vars = None

    # Return value
    expected_result = None

    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    actual_result = action_module_0.run(tmp, task_vars)

    assert(actual_result == expected_result)

# Generated at 2022-06-25 06:47:15.093244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    int_0 = 998
    set_0 = {float_0, float_0}
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    del set_0
    del float_0
    del int_0
    del bool_0
    action_module_0.run()

# Generated at 2022-06-25 06:47:19.652466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 0.728898193359375
    set_0 = {str_0, float_0, int_0, float_0}
    int_0 = 1
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    dict_0 = {}
    result = action_modul

# Generated at 2022-06-25 06:47:29.280123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    msg = 'Failed as requested from task'
    if action_module_0._task.args and 'msg' in action_module_0._task.args:
        msg = action_module_0._task.args.get('msg')
    action_module_0.run(msg)


# Generated at 2022-06-25 06:47:34.847052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)

    dict_0 = dict()
    dict_0['msg'] = 'Custom message'
    dict_0['failed'] = True
    dict_1 = action_module_0.run(dict(), dict_0)
    assert dict_1 == dict_0

# Generated at 2022-06-25 06:47:43.292148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    # Set argument "tmp" in call to ActionModule.run
    tmp_2 = None
    # Set argument "task_vars" in call to ActionModule.run
    task_vars_2 = {"testcase": "test_ActionModule_run", "ansible_check_mode": "test_ActionModule_run"}
    assert action_module_1.run(tmp=tmp_2, task_vars=task_vars_2) == {"msg": "Failed as requested from task", "failed": True}

# Generated at 2022-06-25 06:47:49.220647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 721.0
    set_0 = set()
    set_1 = {float_0, 959.0}
    int_0 = 1002
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_1, int_0)
    action_module_0.run()


# Generated at 2022-06-25 06:47:54.999889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Test 1: Execute normal code
  bool_0 = True
  float_0 = 614.0
  set_0 = {float_0, float_0}
  int_0 = 2003
  action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
  result_0 = action_module_0.run(None, None)
  assert type(result_0) == dict


# Generated at 2022-06-25 06:47:59.190009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Constants for test run
    tmp_0 = {'int_0': 998}
    task_vars_0 = dict()

    action_module_0 = ActionModule(True, None, None, None, None, None)
    result_0 = action_module_0.run(tmp_0, task_vars_0)

    # AssertionError: dict() != dict()
    pass
    return result_0


# Generated at 2022-06-25 06:48:06.216080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)

    args = {'msg': 'Failed as requested from task'}
    action_module_0.run(task_args=args)

# Generated at 2022-06-25 06:48:11.589434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _ActionModule = ActionModule(task_vars=var_2)
    res = _ActionModule.run(var_0)
    assert res['failed'] == True, "Result: " + str(res)
    assert res['msg'] == "Failed as requested from task", "Result: " + str(res)

# Generated at 2022-06-25 06:48:15.408441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule()
    var_0 = None
    var_1 = None
    var_2 = None
    result = action_module_instance.run(var_0, var_1)
    assert result['failed'] == True
    assert result['msg'] == 'Failed as requested from task'


# Generated at 2022-06-25 06:48:21.508741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_plugin = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    arg_0 = action_plugin.run(tmp=None, task_vars=None)
    assert arg_0['failed'] == True
    assert arg_0['msg'] ==  'Failed as requested from task'




# Generated at 2022-06-25 06:48:24.829526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tests the run method of Class ActionModule for exception cases
    action_module = ActionModule(None, None, None, None)
    assert action_module.run(None, None) is not None

# Generated at 2022-06-25 06:48:29.928389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None
    actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    out_0 = None
    var_1 = out_0
    task_vars['ansible_systype'] = var_1
    out_1 = 'Failed as requested from task'
    var_2 = out_1
    out_2 = dict(failed=True, msg=var_2)
    var_0 = out_2
    return var_0


# Generated at 2022-06-25 06:48:31.035912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None


# Generated at 2022-06-25 06:48:33.666886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO - Add test cases for ActionModule.run()
    var_0 = ActionModule(var_0)
    var_1 = Dict()
    var_2 = Dict()
    test_case_0()

# Generated at 2022-06-25 06:48:42.995730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ret_val_0 = None

    # No input params
    ansible_0 = Base()
    ansible_0._task = test_case_0()
    action_module_0 = ActionModule(ansible_0)
    action_module_0.run()

    # Missing required param 'msg'
    ansible_0._task.args = {'msg': 'This is my message'}
    action_module_0 = ActionModule(ansible_0)
    action_module_0.run()

    # All params present
    ansible_0 = Base()
    ansible_0._task.args = {'msg': 'This is my message'}
    action_module_0 = ActionModule(ansible_0)
    action_module_0.run()

    return ret_val_0

# Generated at 2022-06-25 06:48:46.907006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_2 = None
    var_3 = None
    var_1 = var_0.run(tmp=var_1, task_vars=var_2)


# Test method ActionBase.run

# Generated at 2022-06-25 06:48:59.486486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture = 0
    var_0 = None
    var_1 = None
    action_module = ActionModule(task=var_1, connection=var_0, play_context=var_1, loader=var_1, templar=var_0, shared_loader_obj=var_0)
    var_2 = action_module.run(tmp=var_0, task_vars=var_0)
    var_3 = action_module.run(tmp=var_0, task_vars=var_1)
    var_4 = action_module.run(tmp=var_1, task_vars=var_0)
    var_5 = action_module.run(tmp=var_1, task_vars=var_1)
    var_6 = action_module.run()
    var_7 = action_

# Generated at 2022-06-25 06:49:03.368034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_2 = None
    var_0.run(var_1, var_2)

# Generated at 2022-06-25 06:49:08.660367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dummy_self = None
    dummy_tmp = None
    dummy_task_vars = None
    test_case_0()
    retval = None
    return retval

# Generated at 2022-06-25 06:49:12.115626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Execute Test')
    test_ActionModule = ActionModule('A string', 'A string')
    var_0 = None
    var_1 = None
    var_2 = None
    print(test_ActionModule.run(var_0, var_1))
    print('End Test')


# Generated at 2022-06-25 06:49:19.098672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = None
    tmp = None
    task_vars = None

    try:
        # Test case 0
        #
        # Testing case with the following parameters:
        #
        var_0 = None
        var_1 = None
        var_2 = None
        test_case_0()
    except Exception as err:
        print ("Test case 0 failed: " + str(err))
    return


# Generated at 2022-06-25 06:49:24.818011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = None
    kwargs_0 = None
    action_module_0 = ActionModule()
    ansible_module_0 = AnsibleModule()
    assert action_module_0.run(ansible_module_0) == 'Nothing to see here'
    test_case_0()


# Generated at 2022-06-25 06:49:34.609921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = ActionModule()
    # Calling the method run of class ActionModule
    # Variable tmp_4 is a local variable
    tmp_4 = None
    # Variable task_vars_5 is a local variable
    task_vars_5 = None
    # Calling the method run of class ActionBase
    # Variable result_6 is a local variable
    result_6 = ActionBase().run(tmp_4, task_vars_5)
    # Assigning to variable var_0 the attribute failed of variable result_6
    var_0 = result_6.failed
    # Assigning to variable var_1 the attribute msg of variable result_6
    var_1 = result_6.msg
    assert(var_1 == 'msg')


# Generated at 2022-06-25 06:49:36.313605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None

# Generated at 2022-06-25 06:49:39.484276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.task_vars = test_case_0.var_0
    action_module.tmp = test_case_0.var_1
    action_module.task = test_case_0.var_2
    assert action_module.run() == test_case_0.expected_1

# Generated at 2022-06-25 06:49:42.585367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_2 = ActionModule()
    var_1 = {'msg': 'my message'}
    var_3 = var_2.run(var_0, var_1)
    return var_3


# Generated at 2022-06-25 06:49:44.296822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None

if __name__ == '__main__':
    # Unit test
    test_ActionModule_run()

# Generated at 2022-06-25 06:49:49.563562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a task without an argument 'msg'.
    var_0 = ActionModule()
    var_1 = var_0.run()
    assert(var_1['failed'] == True)

# Test with a task with an argument 'msg'.
    var_2 = ActionModule()
    var_3 = var_2.run()
    assert(var_3['failed'] == True)

# Generated at 2022-06-25 06:49:52.924120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # HAIL MARY
    pass

# Generated at 2022-06-25 06:50:00.181462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Test case 'msg':
    action_module_0.run(msg="Action 'fail' failed as requested from task")
    # Test case 'msg':
    action_module_0.run(msg="Action 'fail' failed as requested from task", task_vars="test_case_0")
    # Test case 'msg':
    action_module_0.run(msg="Action 'fail' failed as requested from task")
    # Test case 'msg':
    action_module_0.run(msg="Action 'fail' failed as requested from task", task_vars="test_case_0")

# Generated at 2022-06-25 06:50:00.981789
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 06:50:02.383463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = action_run()

# Generated at 2022-06-25 06:50:06.414485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit test for method run of class ActionModule
    # arguments: tmp, task_vars=None
    # return value: (return value(s), error message(s))
    assert False

# Generated at 2022-06-25 06:50:08.811907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 06:50:09.410637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert true

# Generated at 2022-06-25 06:50:11.079266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:50:16.901801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    kwargs = {
        'msg': 'Failed as requested from task',
        '_task': {
            'args': {
                'msg': 'Failed as requested from task',
            },
        },
    }
    result = {
        'failed': True,
        'msg': 'Failed as requested from task',
    }
    assert ActionModule.run(**kwargs) == result

# Generated at 2022-06-25 06:50:21.259324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test type
    assert type(test_ActionModule_run()) == dict
    # Test return
    assert test_ActionModule_run()['failed'] == True

# Generated at 2022-06-25 06:50:28.009048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:50:32.292958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define the parameter 'msg'
    msg = 'Failed as requested from task'

    # Call the method run of class ActionModule with parameters: msg
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    var_0 = action_module_0.run(msg)


# Generated at 2022-06-25 06:50:38.285398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = 105.62
    dict_0 = dict()
    set_0 = {float_0, float_0}
    int_0 = 990
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    var_0 = action_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 06:50:39.101655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement test
    pass

# Generated at 2022-06-25 06:50:41.105968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if False:
        set_0 = {bool_0, float_0}
        action_module_0.run(set_0)

# Generated at 2022-06-25 06:50:48.563771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = 74116.6734294
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    int_0 = 500
    var_0 = action_module_0.run(int_0)

if __name__ == '__main__':
    start_0 = clock()
    var_1 = test_case_0()
    end_0 = clock()
    print(end_0-start_0)

# Generated at 2022-06-25 06:50:52.218187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 12.0
    set_0 = {float_0, float_0}
    int_0 = 699
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    action_module_0.run()


# Generated at 2022-06-25 06:50:57.186502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    action_module_0.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 06:51:02.506747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:51:12.461381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:51:15.609214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    result = action_module_0.run(None)
    assert result == expected

# Generated at 2022-06-25 06:51:21.592848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase as class_0
    # FIXME: Mock the required types
    # TODO: Add tests for different types
    # TODO: Fix the run() method
    action_module_0 = ActionModule(None, None, None, None, None, None)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:51:25.075983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    action_module_0.run()
    # Verify


# Generated at 2022-06-25 06:51:31.013750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = 176.0
    set_0 = {float_0, float_0}
    int_0 = 374
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    result = action_module_0.run()
    assert True == result['failed']
    assert 'Failed as requested from task' == result['msg']

# Generated at 2022-06-25 06:51:35.952147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = {}
    tmp_0 = None
    task_vars_0 = None
    obj_0 = ActionModule(args_0, tmp_0, task_vars_0)
    obj_0.run()

# Generated at 2022-06-25 06:51:39.640038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = 0.0
    set_0 = {float_0, float_0}
    int_0 = 999
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    var_0 = action_module_0.run()
    print(var_0)

# Generated at 2022-06-25 06:51:50.134991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test object for the method parameters
    task = {
        'action': 'fail',
        'args': {
            'msg': 'Failed as requested from task'
        }
    }
    # Create a test object for the class paramater
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)

    # Copy the test object to the method parameters
    tmp = None
    task_vars = dict()
    # Run the method under test
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:51:53.261023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_0 = AnsibleModule()
    result_0 = ansible_0.run()
    assert result_0 == "Expected result"

# Generated at 2022-06-25 06:51:58.372496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    var_0 = action_module_0.run()

if __name__ == '__builtin__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:52:17.618525
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test of run function with empty input
    answer = run()
    assert answer == {'failed': True, 'msg': 'Failed as requested from task'}

    # Test of run function with msg argument
    arg_msg = 'my custom failure message'
    answer = run(msg=arg_msg)
    assert answer == {'failed': True, 'msg': arg_msg}

    # Test of run function with invalid argument
    arg_msg = 'my custom failure message'
    answer = run(invalid=arg_msg)
    assert answer == {'failed': True, 'msg': 'Failed as requested from task', '_ansible_bad_arguments': ['invalid']}

# Generated at 2022-06-25 06:52:18.777771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_run() == {}


# Generated at 2022-06-25 06:52:22.906390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    action_module_0.run()


# Generated at 2022-06-25 06:52:28.144687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    assert isinstance(action_module_0.run(), dict)



# Generated at 2022-06-25 06:52:31.931226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert type(action_module_0.run()) is dict

# Generated at 2022-06-25 06:52:34.935916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    b = a.run()
    assert b == {'ansible_facts': {}, 'ansible_inve$tory_hostname': 'localhost', 'status': 'pending', 'failed': True, 'msg': 'Failed as requested from task'}

# Generated at 2022-06-25 06:52:39.455313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock object for instance action_run
    action_run = mock.Mock(return_value={'failed': True, 'msg': 'Failed as requested from task'})
    # Create mock object for class ActionModule
    action_module = mock.Mock(ActionModule)
    action_module.side_effect = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    action_module.run.side_effect = action_run
    # Create mock object for instance action_msg
    action_msg = mock.Mock(return_value='Failed as requested from task')
    # Create mock object for class ActionModule
    action_module = mock.Mock(ActionModule)

# Generated at 2022-06-25 06:52:39.948790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:52:45.304150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bool_1 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    set_1 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_1, float_0, set_0, set_1, int_0)
    var_0 = action_module_0.run()



# Generated at 2022-06-25 06:52:51.895912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with valid arguments
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_0['failed'] = True
    dict_0['msg'] = 'Failed as requested from task'
    dict_1['failed'] = True
    dict_1['msg'] = 'Failed as requested from task'
    assert dict_0 == dict_1

# Generated at 2022-06-25 06:53:14.164223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = action_run()
    var_2 = var_1.run()



# Generated at 2022-06-25 06:53:18.770427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    # test_case_1
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)

    # Call method run
    # test_case_1
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:53:25.835260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_run
    result = action_run()

    if result is not None:
        # set the result
        ansible_module.exit_json(ansible_facts=dict(action_run=action_run))
    else:
        # fail the module
        ansible_module.fail_json(msg='Bad things happened!')


# Generated at 2022-06-25 06:53:32.546222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    var_1 = tmp()
    var_2 = task_vars()
    var_3 = action_module_0.run(var_1, var_2)
    assert var_3 == 'Failed as requested from task'

# Generated at 2022-06-25 06:53:40.576220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 512.0
    bool_0 = True
    bool_1 = True
    dict_0 = {}
    int_0 = 998
    set_0 = {float_0, float_0}
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    action_run(d=dict_0)
    action_run(tmp=dict_0)
    action_run()
    action_run(bool_1)
    action_run(tmp=dict_0, d=dict_0)
    action_run(tmp=dict_0)
    action_run(d=dict_0)

# Generated at 2022-06-25 06:53:45.814630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        var_0 = ActionModule.run(0, 'test_value')
    except Exception as exception_0:
        var_1 = False
    else:
        var_1 = True
    assert var_1


# Generated at 2022-06-25 06:53:51.838269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 0.0625
    set_0 = {(float_0 * float_0) * (float_0 / float_0)}
    set_1 = {set_0}
    int_0 = 0
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_1, int_0)
    action_module_0.run(action_module_0.run())
    # Testing attribute run of class ActionModule
    assert len(action_module_0.run.__name__) == 4

# Generated at 2022-06-25 06:53:58.437804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # AssertionError raised when bool_0 is False
    bool_0 = True
    float_0 = 128.0
    set_0 = {float_0, bool_0}
    int_0 = 1031
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    try:
        action_module_0.run()
        assert False
    except AssertionError:
        assert True

    # AssertionError raised when float_0 is not None
    float_0 = 999.0
    set_0 = {float_0, float_0}
    int_0 = 1031
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)

# Generated at 2022-06-25 06:54:06.657967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    msg_0 = 'Failed as requested from task'
    var_0 = action_module_0.run(msg_0)
    print(var_0)

# Generated at 2022-06-25 06:54:07.539716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:55:08.803349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 996.0
    set_0 = {float_0}
    int_0 = 60
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:55:13.076199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Locals
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    arg_0 = action_get_arg_spec(action_module_0)
    assert arg_0 == str_0

# Generated at 2022-06-25 06:55:19.138136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:55:24.704576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock variables
    tmp = str()
    task_vars = dict()
    action_module_0 = ActionModule(tmp, tmp, task_vars)
    var_0 = action_run()

# Generated at 2022-06-25 06:55:26.972981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    arg_0 = None
    var_0 = action_module_0.run(arg_0)
    assert var_0

# Generated at 2022-06-25 06:55:31.797556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    var_0 = action_module_0.run(var_0)


# Generated at 2022-06-25 06:55:36.487114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(True, True, 512.0, {512.0, 512.0}, {512.0, 512.0}, 998)
    var_0 = action_run()
    assert var_0

variable_s = {
    'action': {
        'failed': True,
        'msg': 'Failed as requested from task',
    },
    'ansible_facts': {
        'discovered_interpreter_python': '/usr/bin/python',
    },
}

var_2 = {
    'action': {
        'failed': True,
        'msg': 'Failed as requested from task',
    },
    'ansible_facts': {
        'discovered_interpreter_python': '/usr/bin/python',
    },
}


# Generated at 2022-06-25 06:55:40.783873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module_0 = ActionModule()
    # Exercise
    result = action_module_0.run()
    # Verify
    verify(result == None)

# Generated at 2022-06-25 06:55:48.561815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_1 = True
    float_1 = 512.0
    set_1 = {float_1, float_1}
    int_1 = 998
    action_module_1 = ActionModule(bool_1, bool_1, float_1, set_1, set_1, int_1)
    action_module_1.run()

# Generated at 2022-06-25 06:55:55.631184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 512.0
    set_0 = {float_0, float_0}
    int_0 = 998
    action_module_0 = ActionModule(bool_0, bool_0, float_0, set_0, set_0, int_0)
    var_0 = action_run()

