

# Generated at 2022-06-25 06:47:10.939266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '@Bq3#'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    tmp_0 = None
    task_vars_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:47:16.542369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_module_run()
    

# Generated at 2022-06-25 06:47:20.551970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = "NvFQf'.9P-"
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:47:21.523058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, 'Not yet implemented'



# Generated at 2022-06-25 06:47:28.109199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:47:33.263459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert hasattr(ActionModule, 'run'), 'No method run in class ActionModule'
    assert isinstance(ActionModule.run, types.MethodType), 'Method run of class ActionModule is not a method'
    assert len(getargspec(ActionModule.run).args) == 3, 'Method run of class ActionModule takes not exactly 3 arguments (%d given)' % len(getargspec(ActionModule.run).args)

# Generated at 2022-06-25 06:47:38.884051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    bytes_0 = b''
    var_0 = action_module_0.run(bytes_0)
    assert not var_0

# Generated at 2022-06-25 06:47:39.476462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:47:50.671835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  
  # Initialization of local variables
  exp_0 = ()
  exp_1 = ()
  exp_2 = ()
  exp_3 = ()
  act_0 = ()
  act_1 = ()
  act_2 = ()
  act_3 = ()
  act_4 = ()
  bytes_0 = b''
  str_0 = '=6'
  tuple_0 = ()
  float_0 = 0.0
  
  # Tested method call
  action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
  act_0 = action_module_0.run(tmp, task_vars)
  
  # Assert cardinality

# Generated at 2022-06-25 06:47:58.948340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'t1': {'action': 'f1', 'args': {'msg': 'abc'}, 'deps': [], 'name': 't1', 'notify': []}, 't2': {'action': 'f1', 'args': {'msg': 'def'}, 'deps': ['t1'], 'name': 't2', 'notify': []}}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_run()
    var_0 = action_run()
    assert str_0 == '<<;jk41'

# Generated at 2022-06-25 06:48:04.492995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<jk41;'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 06:48:11.346966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = 'xQ+1`|n'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    int_0 = 0
    var_0 = test_case_0(int_0)

# Generated at 2022-06-25 06:48:13.523975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() is None


# Generated at 2022-06-25 06:48:15.766994
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # No output, should return None
    assert action_module_0.run() == None

    # Should print to stderr
    assert action_module_0.run(False) == None


# Test case:
# Test run method with default arguments

# Generated at 2022-06-25 06:48:21.526368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_run()
    dict_1 = {'<<;jk41': 1}
    dict_2 = {'<<;jk41': 1}
    dict_3 = {'<<;jk41': 1}
    dict_4 = {'a': dict_1, 'abd': dict_2, 'bc': dict_3}
    dict_5 = {'<<;jk41': 1}
    dict_6 = {'<<;jk41': 1}
   

# Generated at 2022-06-25 06:48:31.304582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '*'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    dict_0 = {}
    dict_0 = action_module_0.run(dict_0)
    assert dict_0 == {'failed' : True, 'msg' : 'Failed as requested from task'}
    dict_0 = {'msg' : 'Failed as requested from task'}
    dict_0 = action_module_0.run(dict_0)
    assert dict_0 == {'failed' : True, 'msg' : 'Failed as requested from task'}

# Generated at 2022-06-25 06:48:35.459591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = 'BWn<+D>ZJ'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    action_module_0.run()

# Generated at 2022-06-25 06:48:41.201797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = 'n\x84\x8c'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    dict_1 = {}
    var_0 = action_module_0.run(dict_1)
    assert isinstance(var_0, dict)
    assert var_0 == dict_1

# Generated at 2022-06-25 06:48:50.553150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_run(dict_0, dict_0)
    # var_0 is expected to be a dict
    assert type(var_0) is dict
    # From dict_0, get() param 'failed'
    assert var_0.get('failed') is True
    # From dict_0, get() param 'msg'
    str_1 = 'Failed as requested from task'
    assert var_0.get('msg') == str_1

# Generated at 2022-06-25 06:48:57.291390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b'#'
    str_0 = '{:}xqJX'
    tuple_0 = ()
    float_0 = 3.35
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_1 = action_run(action_module_0)

# Generated at 2022-06-25 06:49:05.916317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = 'f\/w_,m'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    assert isinstance(action_module_0.run(), dict)



# Generated at 2022-06-25 06:49:12.084010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = 'x^fuFbX'
    dict_1 = {}
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, dict_1, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:49:19.380147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    # Call the method test run
    if action_module_0.run() == None:
        throw_error()

# Generated at 2022-06-25 06:49:25.664169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '2FA'
    str_1 = 'hi!@'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    action_run(str_1)

# Generated at 2022-06-25 06:49:32.560895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_1 = {}
    bytes_1 = b''
    str_1 = '-{K>'
    tuple_1 = (bytes_1, bytes_1, bytes_1, str_1)
    float_1 = 0.0
    action_module_1 = ActionModule(dict_1, bytes_1, bytes_1, str_1, tuple_1, float_1)
    action_module_1.run()


# Generated at 2022-06-25 06:49:35.507094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = {'msg': 'Failed a'}
    action_module_0 = ActionModule(data, '', '', '', (), 0.0)
    assert action_module_0.run() == {'failed': True, 'msg': 'Failed a'}

# Generated at 2022-06-25 06:49:36.249356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:49:40.578419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '4p4'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_module_0.run()
    assert var_0 == {}, var_0

# Unit tests for class ActionModule

# Generated at 2022-06-25 06:49:47.063534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_0['foo'] = 'bar'
    dict_1 = {}
    dict_1['foo'] = 'baz'
    dict_3 = {}
    dict_3['__ansible_module__'] = 'foo'
    dict_2 = {}
    dict_2['module_args'] = dict_3
    dict_5 = {}
    dict_5['__ansible_module__'] = 'invalid_module'
    dict_4 = {}
    dict_4['module_args'] = dict_5
    dict_6 = {}
    dict_6['__ansible_module__'] = 'invalid_module'
    dict_6['__ansible_module__'] = 'invalid_module'
    dict_7 = {}
    dict_7['module_args'] = dict_6

# Generated at 2022-06-25 06:49:50.483338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_run()
    assert var_0['failed'] == True
    assert var_0['msg'] == 'Failed as requested from module'

# Generated at 2022-06-25 06:50:04.246923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = 'tyvx55b4'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_run()
    assert_equal(var_0 .get('failed'), True)
    eq(var_0 .get('msg'), 'Failed as requested from task')

# Generated at 2022-06-25 06:50:07.163787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    action_module_0.run()

# Generated at 2022-06-25 06:50:08.361536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = test_case_0()


# Generated at 2022-06-25 06:50:13.791356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_1 = {}
    bytes_1 = b''
    str_1 = '<<;jk41'
    tuple_1 = ()
    float_1 = 0.0
    action_module_1 = ActionModule(dict_1, bytes_1, bytes_1, str_1, tuple_1, float_1)
    task_vars_1 = {}
    var_1 = action_module_1.run(dict_1, task_vars_1)
    assert var_1 == dict_1


# Generated at 2022-06-25 06:50:17.503025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_run()
    assert var_0 == 0

# Generated at 2022-06-25 06:50:23.202041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_run(tuple_0, dict_0)


# Generated at 2022-06-25 06:50:24.009381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:50:27.350188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()



#############
# ActionBase
#############
from ansible.plugins.action import ActionBase


# Generated at 2022-06-25 06:50:37.222072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '4w`y+g'
    tuple_0 = ()
    float_0 = 3.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    action_module_0.run()
    str_1 = '\x1c\x98\x8d\xe9\x95\xab\x8c\xdc]'
    assert str_1 == '\x1c\x98\x8d\xe9\x95\xab\x8c\xdc]'
    str_2 = '\x0b\xed\x03\x00\xcc\x98\xa2\xfb'
    assert str_2

# Generated at 2022-06-25 06:50:38.401498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add tests for run
    pass

# Generated at 2022-06-25 06:50:58.875165
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:51:03.739849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:51:12.758938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import re
    from ansible.plugins.action import ActionBase
    reg_1 = re.compile('Failed as requested from task')
    charset_0 = 'UTF-8'
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    task_vars_0 = action_module_0.run(None, None)
    tmp_0 = task_vars_0
    tmp_1 = task_vars_0.get('failed')
    assert reg_1.match(tmp_1)
    del reg_1
    del charset_

# Generated at 2022-06-25 06:51:18.053077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = 'jkd0'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    for i in range(10000):
        try:
            var_0 = action_module_0.run()
        except:
            # We expect an exception here
            pass

# Generated at 2022-06-25 06:51:24.466959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '8s^wc%'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    result_0 = action_module_0.run(bytes_0)
    assert result_0 == None


# Generated at 2022-06-25 06:51:30.864152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = 'Y8RU'
    tuple_0 = ()
    float_0 = 0.0
    dict_1 = {2: dict_0, 3: dict_0, 4: dict_0, 5: dict_0, 6: dict_0, 7: dict_0, 8: dict_0, 9: dict_0, 10: dict_0, 11: dict_0, 12: dict_0, 13: dict_0, 14: dict_0, 15: dict_0, 16: dict_0, 17: dict_0, 18: dict_0, 19: dict_0, 20: dict_0, 21: dict_0, 22: dict_0}

# Generated at 2022-06-25 06:51:38.027385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #  Make sure we return a fail result when arguments are missing
    dict_0 = {}
    bytes_0 = b''
    str_0 = '\'}4l2'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    result = action_module_0.run()
    assert result['failed'] is True


# Generated at 2022-06-25 06:51:49.315339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {} # test_dict
    bytes_0 = b'' # test_bytes
    str_0 = '<<;jk41' # test_str
    tuple_0 = () # test_tuple
    float_0 = 0.0 # test_float
    action_module_1 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    assert isinstance(action_module_1, ActionModule)
    action_module_2 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    assert isinstance(action_module_2, ActionModule)
    str_1 = '<<;jk41' # test_str
    str_2 = '<<;jk41' # test_str


# Generated at 2022-06-25 06:51:55.106636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b'Y'
    str_0 = 'i0(2P'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    action_module_0.run()

# Generated at 2022-06-25 06:52:00.085965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '8Wod#'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_run()
    var_1 = asserts_equal(var_0, 0.0)

# Generated at 2022-06-25 06:52:47.052140
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:52:50.772665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_run()

    # test_case_0()

# Generated at 2022-06-25 06:53:01.899633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

# Generated at 2022-06-25 06:53:08.767780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '+}8&'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)

    value_0 = action_module_0.run()
    print(value_0)


# Generated at 2022-06-25 06:53:14.774976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    obj_0 = action_module_0.run()
    assert obj_0['msg'] == 'Failed as requested from task'
    assert obj_0['failed']
    assert obj_0['invocation'] is None
    assert obj_0['_ansible_parsed']

# Generated at 2022-06-25 06:53:18.541186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:53:24.897311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp_0 = None
    task_vars_0 = {'0': {'0': ''}, '1': '', '2': ''}
    var_0 = action_module_1.run(tmp_0, task_vars_0)
    

# Generated at 2022-06-25 06:53:33.563703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    __builtins__.__dict__.get('re').match = lambda str_0, str_1: None
    __builtins__.__dict__.get('re').search = lambda str_0, str_1: re.Match(None, None, None, None)

    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_module_0.run(None, None)

# Generated at 2022-06-25 06:53:37.309878
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:53:42.452080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_module_0.run(dict_0, dict_0)
    assert(var_0[1] == str_0);

# Generated at 2022-06-25 06:55:27.238544
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run), 'ActionModule.run is not callable'
    assert callable(ActionModule.run()), 'ActionModule.run() is not callable'
    assert callable(ActionModule.run(tmp=None)), 'ActionModule.run(tmp=None) is not callable'
    assert callable(ActionModule.run(task_vars=None)), 'ActionModule.run(task_vars=None) is not callable'
    assert callable(ActionModule.run(tmp=None, task_vars=None)), 'ActionModule.run(tmp=None, task_vars=None) is not callable'


# Generated at 2022-06-25 06:55:30.098300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = 'wmZ18_!&'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    assert type(action_module_0.run(dict_0, dict_0)) is dict

# Generated at 2022-06-25 06:55:38.387718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = 'Xgz;4'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    dict_0 = {}
    var_0 = action_module_0.run(dict_0)
    assert var_0 == {'msg': 'Failed as requested from task', 'failed': True}

# Generated at 2022-06-25 06:55:42.655678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = '@`&sU45}$U?Jn'
    tuple_0 = ()
    float_0 = 0.0
    action_module = ActionModule(dict_0, str_0, str_0, str_0, tuple_0, float_0)
    #assert action_module.run(None, None) == None
    #pass


# Generated at 2022-06-25 06:55:45.708270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run of class ActionModule")

    return



# Generated at 2022-06-25 06:55:49.063490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0

# Generated at 2022-06-25 06:55:55.593913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = '7V*;[?g'
    str_1 = '$i|'
    float_0 = 0.0
    int_0 = 0
    str_2 = 'Z'
    int_1 = 0
    str_3 = '+nP(^'
    bytes_0 = b'4B'
    action_module_0 = ActionModule(dict_0, str_0, str_1, str_2, str_3, float_0)
    result = action_run(int_0, int_1, bytes_0)
    assert result == None
    assert result == None
    assert result == None
    assert result == None
    assert result == None
    assert result == None
    assert result == None
    assert result == None

# Generated at 2022-06-25 06:56:02.669707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {}
    dict_1['msg'] = 'FAILED!'
    dict_1['_ansible_no_log'] = True
    dict_1['_ansible_verbosity'] = 0
    dict_0['action'] = dict_1
    dict_1 = {}
    dict_0['no_log'] = dict_1
    dict_1 = {}
    dict_1['msg'] = 'FAILED!'
    dict_0['tasks'] = dict_1
    dict_1 = {}
    dict_1['_ansible_verbose_always'] = False
    dict_1['_ansible_verbosity'] = False
    dict_0['verbose_always'] = dict_1
    dict_1 = {}

# Generated at 2022-06-25 06:56:06.252628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = 'DjQ1zI'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)


# test case for class ActionModule

# Generated at 2022-06-25 06:56:12.446530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bytes_0 = b''
    str_0 = '<<;jk41'
    tuple_0 = ()
    float_0 = 0.0
    action_module_0 = ActionModule(dict_0, bytes_0, bytes_0, str_0, tuple_0, float_0)
    var_0 = action_module_0.run(dict_0)
    test_var_0 = var_0
    assert test_var_0 == var_0
