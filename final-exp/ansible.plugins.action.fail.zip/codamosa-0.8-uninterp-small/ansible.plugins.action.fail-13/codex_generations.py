

# Generated at 2022-06-25 06:47:04.500897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x80\x15\xbe\xd2'
    set_0 = set()
    float_0 = -2319.3857283593543
    list_0 = []
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    str_0 = action_module_0.run(None, None)
    assert str_0 is not None


# Generated at 2022-06-25 06:47:09.223939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x80\x15\xbe\xd2'
    set_0 = set()
    float_0 = -2319.3857283593543
    list_0 = []
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    tmp_0 = None
    task_vars_0 = dict()
    ansible_facts_0 = dict()
    ansible_facts_0['ansible_service_mgr'] = 'upstart'
    ansible_facts_0['newest_vagrant_version'] = '1.8.1'
    ansible_facts_0['ansible_distribution_version'] = '14.04'

# Generated at 2022-06-25 06:47:15.477091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfc\xeb\xa3\xfc\xab'
    set_0 = set()
    float_0 = -18.971021
    list_0 = []
    list_1 = []
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_module_0.run(None, list_1)


# Generated at 2022-06-25 06:47:22.705742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'u\x16M\xde\x93W\x8c\xd6\x17\x88\xc8\x8e\xa6\xeb\xfd\xd9\xb8\x07\x12\x06\xc6'
    set_0 = set()
    float_0 = -9.773877551020408
    list_0 = []
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    tmp = None
    task_vars = dict()
    task_vars['msg'] = 'msg'
    result = action_module_0.run(tmp, task_vars)
    if not result['failed']:
        print("Failure")

# Generated at 2022-06-25 06:47:23.374286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:47:33.300453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x80\x15\xbe\xd2'
    set_0 = set()
    float_0 = -2319.3857283593543
    list_0 = []
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    dict_0 = dict()
    dict_1 = dict()
    action_module_0.run(dict_0, dict_1)
    action_module_0.run(dict_1, dict_0)
    dict_1 = dict()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:47:39.428826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x80\x15\xbe\xd2'
    set_0 = set()
    float_0 = -2319.3857283593543
    list_0 = []
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    action_module_0._task.args = {}
    action_module_0.TRANSFERS_FILES = True
    action_module_0.run({}, {})

# Generated at 2022-06-25 06:47:49.010370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0fw"\xf3\x8b\x9c\x84\x83\x1fk\x11\xea'
    set_0 = set()
    float_0 = -2319.3857283593543
    list_0 = []
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    tmp_0 = None
    task_vars_0 = {}
    dict_0 = action_module_0.run(tmp_0, task_vars_0)
    assert dict_0['failed'] == True

# Generated at 2022-06-25 06:47:53.418416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule("W\xdf\xdf\xf4\x90\xd4", "h\xb7", -0.94765, [], [], 2.87)
    assert action_module_1.run() == {'changed': False, 'failed': True, 'msg': 'Failed as requested from task'}

# Generated at 2022-06-25 06:47:59.069349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_1 = b'\x11\x80\x15\xbe\xd2'
    set_1 = set()
    float_1 = -2319.3857283593543
    list_1 = []
    action_module_1 = ActionModule(bytes_1, set_1, float_1, list_1, list_1, float_1)
    tmp_1 = tmp_2 = action_module_1.tmp
    task_vars_1 = {}
    action_module_1.run(tmp_1, task_vars_1)

# Generated at 2022-06-25 06:48:08.925033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    set_0 = set()
    float_0 = -3728.373962
    list_0 = [float_0, bytes_0, set_0, float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)

    # calls action_run
    var_0 = action_module_0.run()

# test_action_module.py
'''
Test module for ansible action plugins.
'''



# Generated at 2022-06-25 06:48:16.293503
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run()
    assert var_0 == 'not implemented', 'Value of var_0 is not "not implemented": ' + var_0


if __name__ == '__main__':
    test_case_0()  # comment this line
    # test_ActionModule_run()  # comment this line

# Generated at 2022-06-25 06:48:19.498879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x5f'
    set_0 = set()
    float_0 = 7571.87664
    list_0 = [1]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:48:20.918226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:48:27.294453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b's\xd6\x1d\x95!\xfa'
    set_0 = set()
    float_0 = -0.567256
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:48:33.873091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:48:39.351008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x12S\xd2\x9f\x92'
    set_0 = set()
    float_0 = -29.0
    list_0 = list()
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_module_0.run()
    assert isinstance(var_0, dict)
    assert var_0 == {}

# Generated at 2022-06-25 06:48:41.283368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = ActionModule.run()
    assert isinstance(result, dict)



# Generated at 2022-06-25 06:48:48.579420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        var_0 = b'\x11\x83\xfa\xbe\xc6'
        set_0 = set()
        float_0 = -2320.217684
        list_0 = [float_0]
        action_module_0 = ActionModule(var_0, set_0, float_0, list_0, list_0, float_0)
        action_module_0.run()
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-25 06:48:59.649210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = [1154]
    set_0 = set()
    list_1 = [list_0, set_0]
    set_1 = set(list_1)
    str_0 = 'b\x1be'
    float_0 = -2.839079978040465e-05
    list_2 = [str_0, float_0, float_0]
    int_0 = -449263727
    bytes_0 = b'\x10\xa6\xaf\x82\xb3'
    action_module_0 = ActionModule(bytes_0, set_1, int_0, list_2, [], float_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:49:06.830738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Invoke the correct method to create the instance var
    bytes_1 = b'\x8d\x99\xbf\x85\x9d'
    set_1 = set()
    float_1 = -6.77877
    list_1 = [float_1]
    action_module_1 = ActionModule(bytes_1, set_1, float_1, list_1, list_1, float_1)
    var_1 = action_run()

    assert var_1['failed'] and var_1['msg'] == 'Failed as requested from task'

# Generated at 2022-06-25 06:49:13.311729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run()

    # Test code



# Generated at 2022-06-25 06:49:20.255544
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0c\xa4\xc4\x8b\xf0'
    set_0 = set()
    float_0 = 0.12083833697901826
    list_0 = [bytes_0]
    list_1 = []
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_1, float_0)
    action_module_0.run()
    var_0 = action_module_0.action_write_locks


# Generated at 2022-06-25 06:49:27.020688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    float_1 = float_0
    str_0 = 'msg'
    dict_0 = {str_0: float_1}
    action_module_0.run(None, dict_0)
    bool_0 = bool()
    bool_1 = bool_0
    bool_2 = bool()
    bool_3 = bool_2
    return bool_1 and bool_3


# Generated at 2022-06-25 06:49:33.043022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:49:37.185556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x14\x81\xf4\xb1\xc6'
    set_0 = set()
    float_0 = -9377.5547647
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:49:43.364761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -4074.8149414
    bytes_0 = b'\x07\xfc\x07\x1c\xaa'
    set_0 = set()
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    set_0 = set()
    list_0 = [float_0]
    var_0 = action_module_0.run(set_0, list_0)
    dict_0 = dict()
    dict_0['failed'] = True
    dict_0['msg'] = 'Failed as requested from task'
    assert var_0 == dict_0


# Generated at 2022-06-25 06:49:52.082780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    float_0 = float_0
    action_module_1 = action_module_0.run(None, float_0)
    assert action_module_0.run() == action_module_1

# Generated at 2022-06-25 06:50:00.367290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    bytes_0 = b"\x94c!\xd6\x8b\x97"
    set_0 = set()
    set_1 = set()
    float_0 = -0.16777560483821844
    list_0 = [float_0]
    list_1 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_1, set_1)
    tmp = None
    task_vars = None

    # Action
    act = action_module_0.run(tmp, task_vars)
    # Confirm
    assert act['msg'] == 'Failed as requested from task'

# Generated at 2022-06-25 06:50:07.739824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_module_0.run(None, None)
    

# Generated at 2022-06-25 06:50:24.410502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    action_module_1 = ActionModule(set_0, None, set_0, None, set_0, set_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:50:32.230225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        bytes_0 = b'\x83\xd9\x94\xa2'
        set_0 = set()
        float_0 = .06026828
        list_0 = [bytes_0, bytes_0]
        list_1 = [float_0, bytes_0]
        action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_1, float_0)
        var_0 = action_module_0.run(bytes_0)
        print(f'Expected: {var_0}')
    except Exception as e:
        print(f'Exception: {e}')

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:50:39.200826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xa3\xef\x01'
    set_0 = set()
    float_0 = -2446.354964
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_module_0.run({}, {})
    assert len(var_0) >= 0
    assert len(var_0) >= 0


# Generated at 2022-06-25 06:50:48.447041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with arguments, variable value passes
    var_0 = b'\x11\x83\xfa\xbe\xc6'
    var_1 = set()
    var_2 = -2320.217684
    var_3 = [var_2]
    var_4 = var_3
    var_5 = var_2
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    action_module_0.run()
    # Test without arguments
    var_0 = b'\x11\x83\xfa\xbe\xc6'
    var_1 = set()
    var_2 = -2320.217684
    var_3 = [var_2]
    var_4 = var_3
   

# Generated at 2022-06-25 06:50:53.471769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_0 = Ansible()
    ansible_0.__init__(ansible_0)
    ansible_1 = Ansible()
    ansible_1.__init__(ansible_1)
    ansible_2 = Ansible()
    ansible_2.__init__(ansible_2)
    
    # Calling run(tmp, task_vars=None)
    # Getting the type of 'tmp' (line 37)
    tmp_0 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 37, 13), 'tmp')
    # Assigning a type to the variable 'tmp_0' (line 37)

# Generated at 2022-06-25 06:50:58.682238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x7f\x95\x87\xab\xc4\x7f\x87\x85\x8d'
    set_0 = set()
    float_0 = -1236.961828
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    action_run()



# Generated at 2022-06-25 06:50:59.253357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:51:04.841237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:51:09.480176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar
    args = {'msg': 'Failed as requested from task'}

    action = ActionBase(Templar(None, {}, {}, None), {})
    action.args = args

    assert action.run() == {'msg': 'Failed as requested from task', 'failed': True}

# Generated at 2022-06-25 06:51:15.057796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run()
    assert var_0 is not None


# Generated at 2022-06-25 06:51:37.846951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xa9\x0c\x9b'
    set_0 = set([214])
    float_0 = 24300.942109
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_module_0.run()
    pass

# Generated at 2022-06-25 06:51:39.240769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_run()


# Generated at 2022-06-25 06:51:48.723225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [0.0]
    float_0 = -18129.647258
    bytes_0 = b'\x9b'
    action_module_1 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    tmp_0 = None
    task_vars_0 = None
    var_0 = action_module_1.run(tmp_0, task_vars_0)
    assert (var_0['msg'] == 'Failed as requested from task')
    assert (var_0['failed'] == True)

# Generated at 2022-06-25 06:51:59.331007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe9\x82'
    set_0 = set()
    float_0 = -2954.501745
    list_0 = [(2.616173539102949E+17 + (1.140796246875119)), float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run()


# This tests the core of action plugin modules
# pylint: disable=W0212

# Generated at 2022-06-25 06:52:06.032360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    test_case_0()

if __name__ == '__main__':
    import logging
    logging.basicConfig(filename='debug.log',level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    
    logger.info('Unit Testing START')
    
    test_ActionModule_run()

    logger.info('Unit Testing END')
    exit()

# Generated at 2022-06-25 06:52:06.443794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:52:11.580523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:52:16.406742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x93\xdc\xb7\xfd\xc4'
    set_0 = set()
    float_0 = 0.717
    list_0 = [set_0]
    list_1 = []
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_1, float_0)

    assert_equal(action_module_0.run(), None)

# Generated at 2022-06-25 06:52:20.699551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    dict_1 = dict()
    dict_2 = {'msg': 'Failed as requested from task'}
    var_1 = action_module_0.run(dict_1, dict_2)
    print(var_1['msg'])


# Generated at 2022-06-25 06:52:28.944706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Get the parameters: 
    # bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    # set_0 = set()
    bool_0 = False
    str_0 = "i\x84"
    float_0 = -2320.217684
    # action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    # Run the method: 
    var_0 = action_run(bool_0, str_0, float_0)
    assert var_0 is None, "Returned an incorrect value"


# Generated at 2022-06-25 06:53:09.788417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:53:15.335426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Start test_ActionModule_run')
    action_module_0 = ActionModule(b'\x1b\xcc\xb8\xaf\x98\x96\x04', set(), 2836.0, [2836.0], [2836.0], 2836.0)
    var_0 = action_run()
    print('End test_ActionModule_run')

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:53:24.553761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_module_0.run(bytes_0)
    assert var_0['failed'] == True
    assert var_0['msg'] == 'Failed as requested from task'

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:53:25.588352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Method run for class ActionModule", end='')
    test_case_0()


# Generated at 2022-06-25 06:53:29.217144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    action_module_0 = ActionModule()
    var_0 = action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 06:53:37.589005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    action_module_0.run(1, 1)
    action_module_0.run(1, 1)
    action_module_0.run(1, 1)
    action_module_0.run(1, 1)
    action_module_0.run()
    action_module_0.run(1, 1)
    action_module_0.run(1, 1)
    action_module_0.run(1, 1)

# Generated at 2022-06-25 06:53:43.041046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run(action_module_0)
    assert var_0.get('msg') == 'Failed as requested from task'

# Generated at 2022-06-25 06:53:50.503888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = 23
    bytes_0 = b"\x05\x12\x12"
    task_vars_0 = 23
    ActionModule_0 = ActionModule(bytes_0, task_vars_0, task_vars_0, tmp_0, task_vars_0, task_vars_0)
    tmp_0 = 23
    task_vars_0 = 23
    var_0 = ActionModule_0.run(tmp_0, task_vars_0)
    assert var_0 is 'Failed as requested from action'

# Generated at 2022-06-25 06:53:52.904689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    try:
        action_module_0.run()
    except:
        assert False


# Generated at 2022-06-25 06:54:00.231958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xf0\xdb\x9a\xc9'
    set_0 = set()
    float_0 = 0.6055443
    list_0 = []
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_module_0.run()
    print(str(var_0))


# Generated at 2022-06-25 06:55:41.905609
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with bad arguments
    try:
        action_run(tmp=None, task_vars=None)
    except Exception:
        assert False
    # Test with good arguments
    try:
        action_run(tmp=None, task_vars=None)
    except Exception:
        assert False

# Generated at 2022-06-25 06:55:45.950379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == 'Failed as requested from task'


# Generated at 2022-06-25 06:55:52.336477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x04\x00'
    set_0 = set()
    float_0 = -1506.879326
    list_0 = []
    str_0 = ''
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    float_1 = -5.56618
    float_2 = 0.0
    str_1 = '\x9d\x82\xb8\xa7\x88\xd7\x0a'
    int_0 = action_module_0.run(float_0, float_1, float_2, str_1)
    assert int_0 < 0.0


# Generated at 2022-06-25 06:55:52.956657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert func(False) == 'True'

# Generated at 2022-06-25 06:55:57.069449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:56:03.740133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xa6\x83\xed\xb3\xda'
    set_0 = set()
    float_0 = 12419.740109
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)



# Generated at 2022-06-25 06:56:12.515758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = "127.0.0.1"
    modname = "fail"
    modargs = dict(msg="my message")
    task_vars = dict()

    fake_loader = DictDataLoader({hostname: dict(
        vars=dict(ansible_connection='local'),
        groups=dict(all=['test_group'])
    )})

    mock_connection = MagicMock()

    def get_connection(self, play_context):
        return mock_connection

    mock_task = MagicMock()

    def get_task_vars(self, play_context):
        return task_vars

    mock_loader = MagicMock()

    def get_loader(self):
        return fake_loader

    mock_templar = MagicMock()


# Generated at 2022-06-25 06:56:16.352213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x16\x15\xe4\x16\xdd'
    set_0 = set()
    float_0 = -1.8917342080767483e+306
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:56:24.942984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import time
    import json
    import shutil
    import sys
    import random
    import string
    import tempfile
    import unittest
    import ansible.parsing.dataloader
    import ansible.inventory
    import ansible.playbook
    import ansible.plugins.loader
    import ansible.vars

    class TestActionModule_run(unittest.TestCase):
        def setUp(self):
            self.loader = DictDataLoader({})
            self.inventory = Inventory(loader=self.loader, variable_manager=VariableManager(), host_list=['localhost'])
            self.variable_manager = VariableManager()
            self.loader = DataLoader()
            self.variable_manager.set_inventory(self.inventory)

# Generated at 2022-06-25 06:56:29.440956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x11\x83\xfa\xbe\xc6'
    set_0 = set()
    float_0 = -2320.217684
    list_0 = [float_0]
    action_module_0 = ActionModule(bytes_0, set_0, float_0, list_0, list_0, float_0)
    var_0 = action_run()