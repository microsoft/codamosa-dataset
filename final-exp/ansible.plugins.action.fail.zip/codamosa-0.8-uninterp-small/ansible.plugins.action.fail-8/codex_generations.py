

# Generated at 2022-06-25 06:47:13.545662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Alesha.'
    list_0 = [str_0, str_0]
    float_0 = 1.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)
    assert 'Ansible.' in result.keys()

# Generated at 2022-06-25 06:47:14.845384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:47:20.259685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    action_module_0.super()
    dict_0 = dict()
    dict_1 = action_module_0.run(None, dict_0)

# Generated at 2022-06-25 06:47:30.793276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    taskvars_0 = dict()
    try:
        taskvars_0 = action_module_0.run()
    except Exception:
        assert (False)
    else:
        assert (True)

if __name__ == '__main__':
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 06:47:37.343758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'z'
    list_0 = ['c', 'N', '-', str_0, 'n', 'T', '`', ';', '.', 'e']
    float_0 = -654.0
    set_0 = {'r', 'L', '&', 'o', '!', 'i', 'U', 'e', 'l', 'v'}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    str_1 = '`'
    action_module_0.task = {'args': {'msg': str_1}}
    dict_0 = {}
    dict_1 = action_module_0.run(dict_0)
    assert len(dict_1) == 2
    assert dict

# Generated at 2022-06-25 06:47:45.378336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0]
    float_0 = -453.0
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, dict(), set([]))

    tmp = None
    task_vars = None

    try:
        result = action_module_0.run(tmp, task_vars)
    except Exception:
        result = "An exception occurred in the test case.\n"

    assert result == "An exception occurred in the test case.\n"

# Generated at 2022-06-25 06:47:54.393430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    int_0 = -1
    list_0 = [str_0]
    list_1 = list(list_0)
    dict_0 = dict(zip(list_1, list_1))
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, dict_0, dict_0)
    result = action_module_0.run(tmp=dict_0)
    assert result['msg'] == 'Failed as requested from task'
    assert result['failed'] == True
    assert result['invocation'] == {'module_args': {}}
    assert result['module_name'] == 'fail'

# Generated at 2022-06-25 06:48:01.712972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'Ansible.'
    list_1 = [str_1, str_1]
    str_2 = 'Ansible.'
    list_2 = [str_2, str_2]
    float_1 = -453.0
    set_1 = {str_1}
    action_module_1 = ActionModule(str_1, list_1, float_1, list_2, set_1, set_1)
    action_module_1.run()
    assert True


# Generated at 2022-06-25 06:48:10.410913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    str_3 = 'Ansible.'
    str_1 = 'Failed as requested from task'
    str_2 = 'msg'
    dict_0 = {str_2: str_1}
    str_4 = 'task_vars'
    dict_1 = {str_4: dict_0}
    value_0 = action_module_0.run(dict_1, dict_0)
    assert value_0 == dict_0

# Generated at 2022-06-25 06:48:17.541099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -558.0
    list_0 = [-558.0, -558.0]
    set_0 = {}
    dict_0 = dict()
    int_0 = -558
    str_0 = 'MKKtVmr'
    action_module_0 = ActionModule(int_0, list_0, float_0, list_0, set_0, set_0)
    tmp = None
    task_vars = dict_0
    result = action_module_0.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == str_0


# Generated at 2022-06-25 06:48:26.914870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Failed as requested from task'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:48:31.741906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '2u'
    list_0 = ['h$', 'O`|', 'T', '<>']
    float_0 = -117.0
    set_0 = {'W'}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    run()
    action_module_0.run()
    test_case_0()

# Generated at 2022-06-25 06:48:39.035364
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Arguments'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -22.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:48:43.854190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = action_run(str_0, list_0)
    test_case_0()

# Generated at 2022-06-25 06:48:50.204957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters
    tmp = None
    task_vars = None

    # Check if method run alters its input parameters
    if tmp is not None:
        var_tmp = tmp
    if task_vars is not None:
        var_task_vars = task_vars
    # Run method
    ActionModule.run(tmp,task_vars)

    # Check if method run alters its input parameters
    try:
        assert tmp == var_tmp
        assert task_vars == var_task_vars
    except:
        raise Exception("Test failed because method run of class ActionModule alters its input parameters.")


# Generated at 2022-06-25 06:48:52.079780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:48:55.880546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize
    test_object = ActionModule()
    tmp, task_vars = 1, 1

    # Test call
    try:
        test_object.run(tmp, task_vars)
    except Exception as e:
        assert(False)

# Generated at 2022-06-25 06:49:03.787134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'Ansible.'
    list_1 = [str_1, str_1, str_1, str_1]
    float_1 = -453.0
    set_1 = {str_1}
    action_module_1 = ActionModule(str_1, list_1, float_1, list_1, set_1, set_1)
    action_run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:49:07.621022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No need to test. Should not be called.
    pass


# Generated at 2022-06-25 06:49:18.842850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Module did not specify a message'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -7.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = action_module_0.run()
    assert var_0['failed'] == True
    assert var_0['msg'] == str_0
    str_1 = '-7.0'
    list_1 = [str_1, str_1, str_1, str_1]
    float_1 = -7.0
    set_1 = {str_1}

# Generated at 2022-06-25 06:49:34.372941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test: test_ActionModule_run')
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = action_run(tmp=None, task_vars=None)
    print('Var_0: ' + var_0)
    str_1 = 'Ansible.'
    list_1 = [str_1, str_1, str_1]
    float_1 = -453.0
    set_1 = {str_1}

# Generated at 2022-06-25 06:49:42.322812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible is awesome!'
    list_0 = ['Ansible', 'is', 'awesome!']
    float_0 = 453.0
    float_1 = float_0
    set_0 = {'Ansible', 'is', 'awesome!'}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    tuple_0 = (str_0, list_0, float_0, list_0, set_0)
    list_1 = list(tuple_0)
    tuple_2 = (str_0, list_0, float_0, list_0, set_0)
    float_2 = float_0

# Generated at 2022-06-25 06:49:53.363890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'A'
    str_1 = 'b'
    ActionModule_0 = ActionModule(str_0, str_1)
    dict_0 = dict()
    dict_1 = dict()
    dict_1['failed'] = False
    result = ActionModule_0.run(tmp=dict_0, task_vars=dict_1)
    assert result['failed']
    assert len(result['msg']) == 'Failed as requested from task'.__len__()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

out_str = "./ansible/plugins/action/__init__.py {0}".format(str(__builtins__.__dict__['_']))
print(out_str)

# Generated at 2022-06-25 06:50:00.954662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    action_module_0.run(list_0, float_0)


# Generated at 2022-06-25 06:50:10.922382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    fixture_0 = '/'
    fixture_1 = {'msg': 'msg'}
    str_0 = set_0 = fixture_0
    result_0 = None
    str_1 = 'Ansible.'
    list_0 = [str_0, str_1, str_1, str_1]
    float_0 = -453.0
    set_1 = {str_1}
    dict_0 = {}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_1)
    result_0 = action_run(fixture_0, fixture_1)
    assert result_0 == dict_0

# Generated at 2022-06-25 06:50:18.864793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Failed as requested from task'
    list_0 = ['Failed as requested from task', 'Failed as requested from task', 'Failed as requested from task',
              'Failed as requested from task']
    float_0 = -453.0
    list_2 = ['Failed as requested from task', 'Failed as requested from task', 'Failed as requested from task',
              'Failed as requested from task']
    set_0 = {'Failed as requested from task'}
    set_2 = {'Failed as requested from task'}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_2, set_0, set_2)
    var_0 = action_run()

# Generated at 2022-06-25 06:50:24.379500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:50:31.554632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '6'
    list_0 = ['q{zxc9']
    float_0 = -1.0
    list_1 = [['4U(', 'j#']]
    set_0 = {'x'}
    set_1 = {'H!1j'}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_1, set_0, set_1)
    var_0 = action_run()
    print(var_0)
    print(var_0)
    print(var_0)
    print(var_0)


# Generated at 2022-06-25 06:50:41.801737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test variables
    if 'str_0' not in locals():
        str_0 = 'Ansible.'
    if 'list_0' not in locals():
        list_0 = [str_0, str_0, str_0, str_0]
    if 'float_0' not in locals():
        float_0 = -453.0
    if 'set_0' not in locals():
        set_0 = {str_0}
    if 'action_module_0' not in locals():
        action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    if 'var_0' not in locals():
        var_0 = action_module_0.run('tmp_0', 'task_vars_0')
    # code

# Generated at 2022-06-25 06:50:44.980492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    set_0 = {str_0}
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)

    var_0 = action_module_0.run()
    assert var_0 == {}, var_0

# Generated at 2022-06-25 06:50:55.560232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule(str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:50:58.585934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:51:08.193356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_1 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    str_1 = 'task.'
    str_2 = 'arg'
    str_3 = 'msg'
    dict_0 = {str_2: str_3}
    list_1 = [dict_0, str_1]

# Generated at 2022-06-25 06:51:09.993410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  try:
    # case0:
    # Setup
    test_case_0()
  except Exception as e:
    print(e)

# Generated at 2022-06-25 06:51:18.208392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    msg_0 = 'Failed as requested from task'
    list_1 = [msg_0, msg_0]
    tuple_1 = (msg_0, msg_0)
    set_1 = {list_1, tuple_1}
    str_0 = 'Failed as requested from task'
    list_2 = [str_0, str_0]
    tuple_1 = (float_0, float_0)

# Generated at 2022-06-25 06:51:18.941902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_run()


# Generated at 2022-06-25 06:51:24.861642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    set_0 = {-202.0, -241.0, -273.0}
    list_0 = [-202.0, -241.0, -273.0]
    str_0 = 'Ansible.'
    dict_0 = dict()

    dict_0 = action_module_0.run(list_0, dict_0)

# Generated at 2022-06-25 06:51:30.233388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert re.search(pattern_0, str_0)
    except NameError:
        raise NameError('NameError')
    except ValueError:
        raise ValueError('ValueError')
    except TypeError:
        raise TypeError('TypeError')
    finally:
        pass


# Generated at 2022-06-25 06:51:33.048979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:51:38.921331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)
    assert var_0 == 0

# Generated at 2022-06-25 06:52:03.481297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_1 = ActionBase
    str_0 = 'Ansible.'
    list_0 = ['d', 'b', 'e', 'e']
    float_0 = -17.0
    class_0 = ActionModule
    var_2 = action_run()
    class_0._run_checks()
    var_3 = action_run()
    var_3 = action_run(tmp=var_2, task_vars=var_3)
    class_0.run(tmp=var_2, task_vars=var_3)


# Generated at 2022-06-25 06:52:10.716374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:52:13.603182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for run
    # A base class for implementing action plugins
    try:
        print("Result of the test case for method run of class ActionModule:", end="")
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-25 06:52:16.932924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    action_module_0 = ActionModule()
    # This method is missing implementation
    assert False



# Generated at 2022-06-25 06:52:20.069466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '!'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = action_run()
    assert True



# Generated at 2022-06-25 06:52:25.441115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    tuple_0 = action_module_0.run()
    long_0 = long(tuple_0)
    assert long_0 == 25

# Generated at 2022-06-25 06:52:28.833628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # var_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = ActionModule(ActionBase)
    var_0.run()

# Generated at 2022-06-25 06:52:37.035463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansibe'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    action_module_0._compute_checksum_value_list(list_0)
    var_1 = action_module_0.run(list_0)
    var_2 = 'Ansible'.encode("utf-8")
    assert var_2 == var_1
    assert True

# Generated at 2022-06-25 06:52:40.122056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run
    assert str_1 == str_1

# Generated at 2022-06-25 06:52:46.909432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    dict_0 = dict()
    dict_1 = dict()
    var_0 = action_module_0.run(dict_0, dict_1)
    assert var_0 == dict_1

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:53:24.522783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    f = action_run()
    assert f == None


# Generated at 2022-06-25 06:53:25.949266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert var_0 == 'Failed as requested from task'

# Generated at 2022-06-25 06:53:27.602704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   actionModule = ActionModule()
   # Input parameters as class attributes and function buid as method of class
   actionModule.run(self, module_name, module_args, inject, complex_args)


# Generated at 2022-06-25 06:53:30.496949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    msg = 'Failed as requested from task'
    self = 'self'
    self.task_vars = {'msg': 'Failed as requested from task'}
    del msg  # msg no longer has any effect
    self.run(self.task_vars)

# Generated at 2022-06-25 06:53:33.773249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = action_module_0.run(None, None)


# Generated at 2022-06-25 06:53:38.032713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    input_0 = True
    input_1 = dict()
    var_0 = ActionModule.run(input_0, input_1)
    print(var_0)


# Generated at 2022-06-25 06:53:47.795274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    dict_0 = dict()
    dict_0['msg'] = 'Failed as requested from task'
    print(action_module_0.run(tmp=None, task_vars=dict_0))
    dict_0['msg'] = 'Fail'
    print(action_module_0.run(tmp=None, task_vars=dict_0))

if __name__ == '__main__':
    test_case_0()
    test

# Generated at 2022-06-25 06:53:55.547614
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:53:59.544197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    tmp_0 = None
    task_vars_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:54:06.449533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'sg'
    list_0 = [str_0]
    float_0 = -0.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = action_module_0._run(None, None)
    assert var_0 is not None


# Generated at 2022-06-25 06:55:52.357552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    str_1 = 'viva'
    str_2 = 'Elena'
    int_0 = 5
    list_1 = [str_1, str_2, str_2]
    long_0 = long(12)
    list_2 = [int_0, long_0, long_0]
    str_3 = 'Ivan'
    list_3 = [str_3, str_1]

# Generated at 2022-06-25 06:55:57.895844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = action_module_0.run()


if __name__ == '__main__':
    import sys
    sys.exit(0)

# Generated at 2022-06-25 06:56:02.741145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    action_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 06:56:06.055334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing Action.ActionModule.ActionModule_run")
    action_module_0 = ActionModule()
    with open(TEST_FILE) as tempfile:
        action_module_0._run_temporary_file = tempfile
        var_0 = action_module_0.run()
        assert var_0 == None


# Generated at 2022-06-25 06:56:11.844996
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)

    action_module_0.run()

# End of test_ActionModule_run

# Generated at 2022-06-25 06:56:16.595950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    str_1 = 'st'
    dict_0 = {str_1: list_0}
    dict_1 = action_module_0.run(dict_0)

# Generated at 2022-06-25 06:56:23.160685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Ansible.'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = action_module_0.run()
    assert var_0 == None, 'Failed at assert equal'

# Generated at 2022-06-25 06:56:24.349292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()


# Generated at 2022-06-25 06:56:26.695674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    dict_0 = dict()
    dict_0 = action_module_0.run(None, dict_0)
    assert dict_0['failed'] == True
    assert dict_0['msg'] == 'Failed as requested from task'

# Generated at 2022-06-25 06:56:30.114399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'yJx%c+$^r'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -453.0
    set_0 = {str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, list_0, set_0, set_0)
    var_0 = action_module_0.run()