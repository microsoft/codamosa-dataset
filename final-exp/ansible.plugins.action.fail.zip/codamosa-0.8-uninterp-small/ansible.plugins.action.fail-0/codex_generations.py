

# Generated at 2022-06-25 06:47:03.567132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    int_0 = -2359
    bool_1 = True
    action_module_0 = ActionModule(bool_0, set_0, bool_0, int_0, bool_1, set_0)
    dict_0 = dict()
    result = action_module_0.run(dict_0)
    assert(isinstance(result, dict))

# Generated at 2022-06-25 06:47:04.891550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: how can i initialize this one?
    assert False


# Generated at 2022-06-25 06:47:11.296737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    int_0 = -2359
    bool_1 = True
    action_module_0 = ActionModule(bool_0, set_0, bool_0, int_0, bool_1, set_0)
    bool_0 = False
    action_module_0.run(bool_0)

# Generated at 2022-06-25 06:47:16.843886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    int_0 = -2359
    bool_1 = True
    action_module_0 = ActionModule(bool_0, set_0, bool_0, int_0, bool_1, set_0)
    action_module_0.run({})


# Generated at 2022-06-25 06:47:21.658921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  task_vars_0 = dict()
  action_module_0 = ActionModule(False, None, False, None, False, None)
  action_module_0.__class__ = ActionModule
  action_module_0.action_safe_args = None
  action_module_0.__class__.run = ActionModule.run
  bool_0 = True
  tuple_0 = ()
  dict_0 = dict()
  action_module_0.run(tuple_0, dict_0)
  action_module_0.run()

# Generated at 2022-06-25 06:47:23.751780
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 06:47:29.840938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None
    action_module_0 = ActionModule(False, {}, False, -2359, True, {})

    result_0 = action_module_0.run(tmp, task_vars)
    assert result_0['failed'] == True
    assert result_0['msg'] == 'Failed as requested from task'

# Generated at 2022-06-25 06:47:35.904835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    int_0 = -2359
    bool_1 = True
    action_module_0 = ActionModule(bool_0, set_0, bool_0, int_0, bool_1, set_0)
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:47:47.108625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2847
    long_0 = long(3545)
    msg = 'Evaluate the logic of the testcase.'
    msg_1 = 'The testcase logic should be revised.'
    result_0 = {'failed': False, 'changed': False, 'msg': '', 'invocation': {}, 'ansible_facts': {'gather_subset': [], 'gather_timeout': 10, 'gather_facts': True}}

# Generated at 2022-06-25 06:47:48.748926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Test case for run

# Generated at 2022-06-25 06:48:00.896966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:48:10.490774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:48:18.824263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3.14
    str_0 = "E@l)"
    str_1 = "Ia\x15\x02\x16D\x01s"
    str_2 = 'x|\t\x17\x1bC\x03\x06'
    float_1 = -0.10109
    str_3 = ''
    float_2 = 1030.387
    float_3 = 1000.0
    set_0 = {str_3, float_2, float_3, str_3}
    str_4 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    tuple_0 = ()
    list_0 = [float_0, float_1]

# Generated at 2022-06-25 06:48:28.484105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 435.43
    str_0 = 'Failed as requested from task'
    set_0 = {float_0}
    str_1 = "Failed as requested from task"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_0, list_0)
    action_module_0.args = {'msg': str_0}
    dict_0 = action_module_0.run()
    assert dict_0 == {'failed': True, 'msg': str_0}


# Generated at 2022-06-25 06:48:32.695596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1636.1892
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:48:42.581954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 11.85881599
    str_0 = ')Ey'
    float_1 = 1031.0
    set_0 = {float_0, float_1, float_1, float_1}
    str_1 = '+'
    str_2 = '/6b2\x02\x13'
    list_0 = [float_1, str_1, float_1]
    tuple_0 = (float_0, float_0, float_0, float_0, float_1)
    action_module_0 = ActionModule(str_0, set_0, list_0, list_0, tuple_0, str_2)

# Generated at 2022-06-25 06:48:50.969761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:49:02.245031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:49:12.435295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -27.0
    str_0 = "^\x1a\x1a\x15\x15\x1a\x15\x15\x1a\x15l\r\rP"
    float_1 = -42.0
    set_0 = {float_0, str_0, float_1}
    str_1 = "m\x10\x15\x15\x1a\x15\x15\rJ\r\rP"
    list_0 = [str_1, str_1, str_0]
    tuple_0 = ()
    action_module_0 = ActionModule(float_1, str_1, set_0, list_0, tuple_0, float_1)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:49:15.735156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert (1025 == 1000)


# Generated at 2022-06-25 06:49:26.312309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1203.681
    str_0 = ''
    float_1 = 1089.39
    dict_0 = {float_0: float_0, str_0: float_0}
    list_0 = [float_0]
    action_module_0 = ActionModule(float_1, float_0, float_0, float_0, float_0, float_0)
    action_module_1 = ActionModule(float_1, float_0, float_0, action_module_0, float_0, float_0)
    var_0 = action_module_1.run(dict_0, list_0)



# Generated at 2022-06-25 06:49:29.523214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  result = True
  try:
    test_case_0()
  except:
    result = False
  assert result == True

# Generated at 2022-06-25 06:49:38.000899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	float_0 = 1030.387
	str_0 = ''
	float_1 = 1000.0
	set_0 = {str_0, float_0, float_1, str_0}
	str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
	list_0 = [set_0, float_0, float_0]
	tuple_0 = ()
	action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
	bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:49:39.817602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() == {'msg': 'Failed as requested from task', 'failed': True}

# Generated at 2022-06-25 06:49:45.868922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    action_module_1 = ActionModule(float_0, str_0, set_0, action_module_0, tuple_0, tuple_0)
    action_module_1.run()
    float_2 = 549.2325

# Generated at 2022-06-25 06:49:50.840650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:49:57.309009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 100
    str_0 = ''
    list_0 = [str_0, int_0]
    dict_0 = {'fr\xce' : int_0, '\x92\x82\x1a\xbe' : int_0, '\x9c\x82\x00\xf4' : -1}
    action_module_0 = ActionModule(dict_0, str_0, list_0, str_0, str_0, dict_0)
    action_module_0.run()
    tuple_0 = ()
    str_1 = 'y\x07\xbb\x06\x04l\x13\xab'
    str_2 = '1'

# Generated at 2022-06-25 06:50:04.045671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:50:09.466594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:50:16.825123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1000.0
    str_0 = ''
    float_1 = 2341.001239
    set_0 = {float_1, float_1, str_0, float_1}
    str_1 = "uPlD)SJ<\x16\x1f\x1d\n\x14\x08\x01"
    list_0 = [float_1, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x01\x1c\xb8\xed\xeb\xa6\x94'

# Generated at 2022-06-25 06:50:32.914446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    action_module_0 = ActionModule()
    float_0 = 1030.387
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {tuple_0, float_0, float_0}
    
    try:
        var_0 = action_module_0.run(list_0, dict_0)
        return var_0
    except:
        return None


# Generated at 2022-06-25 06:50:37.260886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Run the test_case
    test_case_0()

# Testing with coverage
# To run the test with coverage do:
#   coverage run --include=ansible/plugins/action/test.py test_action_plugin.py
# To report on the coverage do:
#   coverage report -m

# Generated at 2022-06-25 06:50:46.694810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:50:54.032727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'v^\x07\x7f\x1f\x1dR<\xb2\x1a', '\x0b\x1a\xf9\x11\x90\x94\x0c\xca\xfd\xb5\x1d', '\x16\x9a\x0b\xac\x95\x19\xc0\x1c', '\xfa\x11\x9f#\x1fB'}
    list_0 = [set_0]
    tuple_0 = (False, list_0)
    str_0 = '\x1d\x1c'
    float_0 = 1000.0
    str_1 = '\xfd\x0f\x8d\xfc\x91'
    float_

# Generated at 2022-06-25 06:50:56.064680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    msg = str()
    task_vars = dict()
    # Run method of class ActionModule with arguments msg, task_vars
    action_module_0 = ActionModule(msg, task_vars)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:51:04.581461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.16
    str_0 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_0, float_1}
    tuple_0 = ()
    list_0 = []
    action_module_0 = ActionModule(float_0, tuple_0, set_0, tuple_0, float_1, list_0)
    action_module_0.run()


# Generated at 2022-06-25 06:51:06.381731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()



# Generated at 2022-06-25 06:51:10.247397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:51:11.284902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:51:19.153164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = 1000.0
    float_2 = 1030.387
    float_0 = 1030.387
    set_1 = {'', float_0, float_2, ''}
    str_0 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_1 = [set_1, float_0, float_0]
    tuple_1 = ()
    action_module_1 = ActionModule(set_1, str_0, list_1, tuple_1, float_2, list_1)
    bytes_1 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:51:49.209976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = float((-0.0079))
    float_2 = float((-119.0))
    set_0 = {float_2, float_1}
    float_0 = float((-2.0))
    bytes_2 = b'\x02\x08\xb5v\xc2\xf4\xa7'
    str_0 = 'Q\x82\x80\x97\x0c\xde\xf1\x0f]\x1b\xe7'
    action_module_0 = ActionModule()
    action_module_0._VALID_ARGS = set_0
    action_module_0._task = type('', (object,), {'async_val': 0, 'args': {'msg': 'Failed as requested from task'}})

# Generated at 2022-06-25 06:51:55.696619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'
    action_module_0.run(action_module_0, action_module_0)

# Generated at 2022-06-25 06:52:03.409185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 940.5502
    str_0 = ''
    float_1 = 1358.0
    action_module_0 = ActionModule(float_0, str_0, str_0, str_0, str_0, str_0)
    dict_0 = dict()
    str_1 = '\x0bWU\x7f\x06\x0f\x11'
    dict_0[str_1] = str_0
    action_module_0.run(dict_0)

# Generated at 2022-06-25 06:52:14.425780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:52:24.474098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 500.237
    str_0 = "U5"
    set_0 = {str_0, float_0}
    str_1 = "i,\x1b\x1bL0\x1e$I\x17>3\x19"
    list_0 = [float_0, set_0, str_1, str_0]
    tuple_0 = (float_0,)
    float_1 = 1000.0
    action_module_0 = ActionModule(float_0, float_0, list_0, tuple_0, float_1, tuple_0)
    bytes_0 = b'\x11\n\xe3\x9c\x9e'

# Generated at 2022-06-25 06:52:33.516601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1332.59
    str_0 = ''
    dict_0 = {'z>h\x1b': False, str_0: True, 'hM\x03': True}
    list_0 = ['2:1\x1c', str_0, str_0, str_0, 'kN\x1c', 'E\x1e']
    tuple_0 = ('Uq', float_0, float_0)
    action_module_0 = ActionModule(list_0, dict_0, dict_0, dict_0, dict_0, tuple_0)
    var_0 = action_module_0.run()


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:52:40.371892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:52:47.737982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(list_0, set_0, float_0, float_1, list_0, action_module_1)
    float_0, float_1, float_2, float_3, float_4, float_5, float_6, float_7, float_8, float_9, float_10, float_11, float_12, float_13, float_14, float_15, float_16, float_17, float_18, float_19, float_20, float_21, float_22, float_23, float_24, float_25, float_26, float_27, float_28, float_29, float_30, float_31, float_32, float_33, float_34, float_35, float_36, float_37, float_38, float_39, float

# Generated at 2022-06-25 06:52:57.453618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.7
    str_0 = '7'
    str_1 = "n\x1b\x06\x1d,@C\x18\xe0\x07\xa6\x08\xd3\x10\x1e\x0e\x3f\xb4\x0f\x0f\x1d\x02$Z\x0f\x03\x1f\x0f\x1d,@C\x18\xe0\x07\xa6\x08\xd11"
    str_2 = '5'
    list_0 = [float_0, str_0, str_1, str_2]

# Generated at 2022-06-25 06:53:05.341429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    float_0 = 1030.387
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'
    action_module

# Generated at 2022-06-25 06:53:53.239543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 12.5
    str_0 = ''
    float_1 = 44637.007812
    set_0 = {'', float_0, float_1, ''}
    str_1 = "\x07@\x1b\x1a\x01\x0c\x1b"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:54:02.454349
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create new instance
    action_module_0 = ActionModule(float_0, str_0, set_0, action_module_1, tuple_0, bytes_0)

    # Test with float.
    float_2 = -90.29
    float_3 = -92.32
    float_4 = -88.93
    float_5 = -83.70
    float_6 = -95.59
    float_7 = -85.55
    float_8 = -91.80
    float_9 = -87.13
    float_10 = -96.23
    float_11 = -92.44
    float_12 = -87.87
    float_13 = -81.65
    float_14 = -92.84
    float_15 = -98.49
    float_16 = -97.64

# Generated at 2022-06-25 06:54:10.284665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:54:20.155109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1086.541165
    str_0 = "0"
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "L\xe8\xe6\xfb\xbfJ\x16\x8d\x14m\xfc\xc6\xb5#\x9a\x02\x1f\xb3\x86'\xaf\x86%"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)

# Generated at 2022-06-25 06:54:27.862015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:54:32.853625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 819.08
    str_0 = ''
    float_1 = 1000.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_1 = 'q\x14\x1e\x1b+&\x18\x0f\x15'
    list_0 = [float_1, str_1, set_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:54:33.430942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:54:43.627228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'
    set_0 = {str_0, float_0, str_1, str_0}
    float_1 = 1000.0
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)

# Generated at 2022-06-25 06:54:50.617448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:55:00.084375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:56:51.450152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1030.387
    str_0 = ''
    float_1 = 1000.0
    set_0 = {str_0, float_0, float_1, str_0}
    str_1 = "w{7;)<Z`\x0bQ'E\x0biI&h+G"
    list_0 = [set_0, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, str_1, list_0, tuple_0, float_1, list_0)
    str_2 = '5'
    bytes_0 = b'\x02\x08\xb5v\xc2\xf4\xa7'

# Generated at 2022-06-25 06:57:00.637054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1636.0
    dict_1 = {}
    float_1 = 0.0
    set_0 = {float_1, float_1, float_0, float_0}
    str_0 = "Y#\x0bB\x0e\r'\x18\x0c\x17\x0b"
    list_0 = [float_1, float_1, float_0, float_0]
    tuple_0 = ()
    action_module_0 = ActionModule(str_0, set_0, list_0, tuple_0, float_1, list_0)
    var_0 = action_module_0.run(dict_1)
    test_case_0()
