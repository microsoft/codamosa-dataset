

# Generated at 2022-06-25 06:47:11.253218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\xfe'
    str_0 = 'metadata_epire'
    float_0 = 656.6156965539915
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)

    # Call method run
    result = action_module_0.run()
    assert(type(result) == dict)

# Generated at 2022-06-25 06:47:17.762982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\xfe'
    str_0 = 'metadata_epire'
    float_0 = 656.6156965539915
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    action_module_0._task.args = {'msg': 'test_message'}

    action_module_0.run()


# Generated at 2022-06-25 06:47:22.079102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\xfe'
    str_0 = '$'
    float_0 = -960.0247780748
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    tmp = None
    task_vars = []
    assert isinstance(action_module_0.run(tmp, task_vars), dict)


# Generated at 2022-06-25 06:47:33.275680
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:47:34.959066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for ActionModule.run
    assert False, "Test not implemented."


# Generated at 2022-06-25 06:47:43.398856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bool_1 = True
    bytes_0 = b'\xfe'
    str_0 = 'metadata_epire'
    float_0 = 656.6156965539915
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, str_0, float_0, list_0)
    action_module_0.run()


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:47:45.377510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-25 06:47:49.525855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        tmp = None
        task_vars = None
        action_module_0 = ActionModule()
        action_module_0.run(tmp, task_vars)
    except:
        assert 0
    else:
        assert 1


# Generated at 2022-06-25 06:47:57.433112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b'\x1f\x88\xd3\xf8\xaf\xd9\x9a\x0c\x95\x88\x0b\xeb\x85\xe8\x15\x9f\x91\x81'
    str_0 = '\x04\x16\x11\t?\x81\n'
    float_0 = 1375.8
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)

    # Verify the result
    assert (action_module_0.run() == {})

# Generated at 2022-06-25 06:48:05.584192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\xfe'
    str_0 = 'key_coding'
    float_0 = 2
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    list_0 = []
    action_module_0.run(list_0)


# Generated at 2022-06-25 06:48:16.426588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # fail without argument
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_1 = dict()
    dict_1 = dict()
    var_0 = action_module_0.run(dict_0, dict_1)
    # fail with argument
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = Action

# Generated at 2022-06-25 06:48:19.608877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    action_module_0.run(None, None)

# Generated at 2022-06-25 06:48:20.600231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:48:23.342934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    test_case_0(tmp, task_vars)

# Generated at 2022-06-25 06:48:26.305180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    str_0 = '1'
    var_0 = action_module_0.run(str_0)

# Generated at 2022-06-25 06:48:27.433670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = action_run()
    assert var_0 == None
    assert True

# Generated at 2022-06-25 06:48:37.397274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b'fail_from_task'
    str_0 = 'metadata_expire'
    float_0 = 417.7
    list_0 = []
    action_module_0 = ActionModule(True, bool_0, bytes_0, str_0, float_0, list_0)
    dict_0 = dict({b'failed': True, b'msg': u'Failed as requested from task'})
    var_0 = action_module_0.run(None, dict_0)
    dict_0 = dict({b'failed': True, b'msg': u'Failed as requested from task'})
    assert(var_0 == dict_0)


# Generated at 2022-06-25 06:48:38.005912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:48:39.454679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()


# Generated at 2022-06-25 06:48:42.274261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule({})
    tmp_0 = None
    task_vars_0 = {}
    tmp_1 = action_module_0.run(tmp_0, task_vars_0)



# Generated at 2022-06-25 06:48:55.415822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    var_0 = action_run()
    assert var_0['failed']
    assert var_0['msg'] == 'Failed as requested from task'


# Generated at 2022-06-25 06:49:01.694409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    result = action_module_0.run()
    assert result == 'Failed as requested from task'

# Generated at 2022-06-25 06:49:04.449463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # It should set the module_args to the given values
    assert action_module_0.run() == dict()


if __name__ == "__main__":
    try:
        test_case_0()
    except TypeError:
        print("Caught TypeError")

# Generated at 2022-06-25 06:49:11.247918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:49:13.858598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile

    temp_file = tempfile.mkstemp()
    action_module_0 = ActionModule(None, None, None, None, None, None)
    var_0 = action_module_0.run()
    assert var_0 == True

# Generated at 2022-06-25 06:49:18.444533
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Harsh testing:
    var1 = ActionModule.run(tmp=None, task_vars=None)
    assert var1['failed']
    assert var1['msg'] == 'Failed as requested from task'

    # A more detailed test, that checks the parameters of the function/method:
    # TBD

# Generated at 2022-06-25 06:49:25.531040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b'V'
    str_0 = 'x28c%C?B'
    float_0 = -1.5
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    var_0 = action_module_0.run()
    assert var_0['msg'] == 'Failed as requested from task'

# Generated at 2022-06-25 06:49:32.521595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
     # Create an instance of ActionModule
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    # Call the method
    action_module_0.run()

# Generated at 2022-06-25 06:49:39.264009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 959.440044
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    action_module_0.get_action_args(False, 740.369229, 'ec3acd4c-058f-4ca4-a3b4-5762daa8e996', 'Failed as requested from task', 'delegate_to', 'invocation')
    action_module_0.run(bool_0, 'a'*761)

# Generated at 2022-06-25 06:49:43.556399
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:49:57.650386
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:50:01.345546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:50:09.695160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    tmp = None
    task_vars = None
    # Call method
    result = action_module_0.run(tmp, task_vars)
    # Verify results
    assert result['failed'] == True


# Generated at 2022-06-25 06:50:14.022169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 06:50:17.794466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b'A'
    str_0 = 't'
    float_0 = 0.5671222247037885
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    dict_0 = dict()
    dict_0['msg'] = 'metadata_expire'
    var_0 = action_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 06:50:26.031667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = False
    bytes_0 = b'2\xd3%'

# Generated at 2022-06-25 06:50:28.316380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:50:31.418811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Class instance
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

    # Method testing

# Generated at 2022-06-25 06:50:41.274659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    float_0 = -273.15
    int_0 = -133754894
    list_0 = []
    str_0 = 'O57i.qmEo7bh{'
    dict_1 = dict()
    dict_1['msg'] = str_0
    dict_2 = dict()
    dict_2['failed'] = bool_0
    dict_2['msg'] = str_0
    dict_2['rc'] = int_0
    dict_3 = dict()
    dict_3['msg'] = str_0
    dict_3['rc'] = int_0
    dict_4 = dict()
    dict_4['failed'] = bool_0
    dict_4['msg'] = str_0
    dict_4['rc'] = int_0
    dict_5

# Generated at 2022-06-25 06:50:50.210412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    action_run = action_module_0.run(None, None)
    assert action_run == 'Failed as requested from task'


# Test arguments and test cases
# Test case args: {}
# Test case args: {'msg': 'Failed as requested from task'}
# Test case args: {'fail_when': 'False'}
# Test case args: {'msg': 'Failed as requested from task', 'fail_when': 'True'}
# Test case args: {'msg':

# Generated at 2022-06-25 06:51:08.242354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing method run of class ActionModule
    assert callable(ActionModule.run)

# Generated at 2022-06-25 06:51:12.420138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)

    assert True



# Generated at 2022-06-25 06:51:15.569262
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test parameters passed by instantiation
    action_module_0 = ActionModule(action_name, variable_manager, loader,
                                   task, task_vars, standard_lookup_variables)
    action_module_0.run()


# Generated at 2022-06-25 06:51:20.096235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _result = ""
    _result = ActionModule.run(ActionModule(), (), ())
    assert _result is not None

# Generated at 2022-06-25 06:51:26.760420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    str_1 = 'metadata_expire'
    var_0 = action_module_0.run(list_0, list_0, str_1)



# Generated at 2022-06-25 06:51:32.976642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'R\xaa\xe8\xda\x1a\xdf\x0e\x8en\x0f\xe1\x97\x16\x1a\x11'
    str_0 = 'msg'
    float_0 = 4.032374230284765e+34

# Generated at 2022-06-25 06:51:38.336404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b''
    str_0 = 'rpm_qf'
    float_0 = 481.63389556
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)

    # Call method run
    # parameter tmp is type str
    # parameter task_vars is type dict
    action_run()


# Generated at 2022-06-25 06:51:40.849063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    str_1 = action_module_0.run(str_0)
    print(str_1)
    print("Done")

# Generated at 2022-06-25 06:51:44.642942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    msg = 'Failed as requested from task'
    action_run()
    action_module_0 = ActionModule()
    var_0 = action_run()


# Generated at 2022-06-25 06:51:47.828413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0()

# Generated at 2022-06-25 06:52:33.909678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'L\xedP\x80\x8b\xc4\x0b\x13s\x8a\xbd\xbe\x0c\x1f\x9d'
    str_0 = 'm\x19\x15'
    float_0 = 843.546113
    list_0 = [bool_0, bool_0, bool_0]
    ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    var_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    var_0.run()

# Generated at 2022-06-25 06:52:37.520903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:52:43.512750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'y2Mjb'
    str_0 = 'jcXHgZ'
    float_0 = 491.0885
    list_0 = [False, False, False, False, False, False, False]
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    action_module_0.run()

# Generated at 2022-06-25 06:52:51.923060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    bytes_0 = b'\x08\x1a\x15\x1c\x0b\x05\x03\x17\x18'
    str_0 = 'O\x0b\x00\x08\x1a\x15\x1c\x0b\x05\x03\x17\x18'
    float_0 = 4.723732285956224e-32
    list_0 = [False, True, bytes_0, str_0, float_0]
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, str_0, float_0, list_0)
    var_0 = action_run()



# Generated at 2022-06-25 06:52:57.369935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    action_module_0.run()


# Generated at 2022-06-25 06:53:03.118444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:53:11.096799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b'{RVD aLJzR}n(bssD\x19\x10\x19n\x7fF  \x1fr\x1aL\x01'
    str_0 = '#$%Y'
    float_0 = 622.88064
    list_0 = ['0', '\x0e']
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:53:12.285264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    result = False
    result = True
    assert result


# Generated at 2022-06-25 06:53:16.713591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    str_1 = 'msg'
    action_module_0.run(str_1)

# Generated at 2022-06-25 06:53:17.459204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    None



# Generated at 2022-06-25 06:54:45.561427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    action_module_0 = ActionModule()
    dict_0 = action_run(var_0, var_1)
    var_2 = dict_0.get('failed')
    var_3 = dict_0.get('msg')


# Generated at 2022-06-25 06:54:47.774842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    action_module_0 = ActionModule(list_0, list_0, list_0, list_0, list_0, list_0)
    action_module_0.run()



# Generated at 2022-06-25 06:54:51.097187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:54:58.017701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    var_0 = list_0
    var_1 = var_0
    action_module_0.run(var_0, var_1)

# Generated at 2022-06-25 06:55:03.873339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    str_1 = action_run()
    assert str_1 is None

# unit test for class ActionModule

# Generated at 2022-06-25 06:55:11.435240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	bool_0 = False
	bytes_0 = b''
	str_0 = 'metadata_expire'
	float_0 = 656.029478
	list_0 = []
	action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
	var_0 = action_run()

# Generated at 2022-06-25 06:55:19.643599
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_7 = False
    bytes_2 = b''
    str_7 = 'metadata_expire'
    float_4 = 656.029478
    list_3 = []
    action_module_1 = ActionModule(bool_7, bool_7, bytes_2, str_7, float_4, list_3)
    dict_5 = dict()
    str_2 = action_module_1.run(None, dict_5)
    assert str_2 == 'Failed as requested from task'


# Generated at 2022-06-25 06:55:25.856413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    result = action_module_0.run()
    assert type(result) is dict


# Generated at 2022-06-25 06:55:34.682175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    bool_1 = True
    str_1 = 'rename'
    float_1 = 320.7
    list_1 = [bool_1, bool_0, bool_0, bool_1]
    var_0 = action_run()
    bool_2 = False
    bytes_1 = b''
    str_2 = 'G'
    float_2 = 419.62
    list_2 = [str_1, str_2, str_2, str_0]
    action_module

# Generated at 2022-06-25 06:55:41.270920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 'failed'
    var_1 = 'msg'
    var_2 = 'Failed as requested from task'
    dict_0 = {
        var_0: True,
        var_1: var_2
    }
    bool_0 = False
    bytes_0 = b''
    str_0 = 'metadata_expire'
    float_0 = 656.029478
    list_0 = []
    action_module_0 = ActionModule(bool_0, bool_0, bytes_0, str_0, float_0, list_0)
    var_3 = action_run()
    # Verifying equality of var_3 and dict_0
    assert var_3 == dict_0