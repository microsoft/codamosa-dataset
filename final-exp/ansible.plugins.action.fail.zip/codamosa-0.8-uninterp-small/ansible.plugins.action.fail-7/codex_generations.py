

# Generated at 2022-06-25 06:47:03.366162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dummy variables
    task_vars     = dict()
    tmp           = None

    # Call the run method of class ActionModule
    action_module_1 = ActionModule(action=None, task_vars=task_vars, tmp=tmp, task_include=None, play_context=None, loader=None)
    action_module_1.run(tmp=tmp, task_vars=task_vars)

# Generated at 2022-06-25 06:47:03.985422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:47:04.577610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:47:15.858711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module, args, task_vars, inject = [None]*4
  action_module_0 = ActionModule(module, args, task_vars, inject)
  tmp, task_vars = [None]*2
  result_0 = action_module_0.run(tmp, task_vars)
  assert result_0 == {'failed':True, 'msg':'Failed as requested from task'}, "Expected ::{'failed':True, 'msg':'Failed as requested from task'}, but got ::{actual}".format(actual=result_0)
  tmp, task_vars = [['list'], {'dict': 'dict'}]
  result_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:47:21.384314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0]
    float_0 = 113.79867
    dict_0 = {}
    action_module_0 = None
    action_module_1 = ActionModule(list_0, float_0, set_0, dict_0, action_module_0, list_0)
    tmp = None
    task_vars = {}
    action_module_1._task.args = {}
    action_module_1.run(tmp, task_vars)
    return action_module_1

# Generated at 2022-06-25 06:47:30.987555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    set_0 = set()
    action_module_0 = ActionModule(list_0, 113.79867, set_0, {}, None, list_0)
    action_module_1 = action_module_0
    action_module_0.run({}, {})
    action_module_1.run({}, {})
    float_0 = float
    list_0 = list
    float_0(list_0)
    int_0 = int
    int_0(float_0(float_0))
    action_module_0.run({}, {})

# Generated at 2022-06-25 06:47:38.319988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_1 = [None]
    set_0 = set()
    list_2 = [set_0, set_0]
    dict_0 = {}
    action_module_0 = None
    action_module_1 = ActionModule(list_1, 1.0, set_0, dict_0, action_module_0, list_2)
    result_0 = action_module_1.run()
    assert result_0 == {'changed': False, 'failed': True, 'msg': 'Failed as requested from task'}

# Generated at 2022-06-25 06:47:45.532831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0]
    float_0 = 113.79867
    dict_0 = {}
    action_module_0 = None
    action_module_1 = ActionModule(list_0, float_0, set_0, dict_0, action_module_0, list_0)
    tmp = None
    task_vars = None
    action_module_1.run(tmp, task_vars)


# Generated at 2022-06-25 06:47:55.555905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0]
    float_0 = 113.79867
    dict_0 = {}
    action_module_0 = None
    action_module_1 = ActionModule(list_0, float_0, set_0, dict_0, action_module_0, list_0)
    type_str_0 = type("str")
    str_0 = "str"
    type_0 = type(set_0)
    list_1 = list()

    # test 1 - run.
    float_1 = -1.56526
    result_dict_0 = action_module_1.run(float_1)
    assert result_dict_0["failed"] == True


if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-25 06:48:02.022548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0]
    float_0 = 113.79867
    dict_0 = {}
    action_module_0 = None
    action_module_1 = ActionModule(list_0, float_0, set_0, dict_0, action_module_0, list_0)
    action_module_1.run()

# Generated at 2022-06-25 06:48:06.852444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0)
    var_1 = action_run(var_0, var_0)

# Generated at 2022-06-25 06:48:11.452079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = {'ANSIBLE_MODULE_ARGS': {'msg': 'Failed as requested from task'}}
    task_vars = {'ansible_os_family': 'RedHat'}
    result = {'failed': True, 'msg': 'Failed as requested from task'}
    assert ActionModule._execute_module(module, task_vars) == result

# Generated at 2022-06-25 06:48:13.511880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0 = ActionModule(var_0, var_0)
    var_1 = dict()
    var_2 = var_0.run(var_1, var_1)

# Generated at 2022-06-25 06:48:22.661442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = TaskV2(
        action=dict(
            module='fail',
            args=dict(
                msg='failed as requested'
            )
        )
    )
    var_2 = None
    var_3 = {
        'msg': 'failed as requested'
    }
    action_module_0 = ActionModule(var_1, var_2)
    assert action_module_0._task == var_1
    assert action_module_0._connection == var_2
    assert action_module_0._play_context == var_2
    assert action_module_0._loader == var_2
    assert action_module_0._templar == var_2
    assert action_module_0._shared_loader_obj == var_2
    assert action_module_0._action == 'fail'

# Generated at 2022-06-25 06:48:31.508677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize mock objects
    test_case_0_tmp_0 = None
    test_case_0_task_vars_0 = None
    test_case_0_result_0 = dict()
    test_case_0_msg_0 = 'Failed as requested from task'  # This is the expected output
    test_case_0_task_args_0 = dict()
    test_case_0_task_args_0['msg'] = 'Failed as requested from task'
    test_case_0_task_0 = dict()
    test_case_0_task_0['args'] = test_case_0_task_args_0
    test_case_0_action_module_0 = ActionModule(test_case_0_tmp_0, test_case_0_task_0)

    # Call the

# Generated at 2022-06-25 06:48:38.720945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()
    var_2 = ActionModule(var_0, var_0)
    var_3 = var_2.run(var_1, var_0)
    assert var_3[0] == True
    assert var_3[1] == 'Failed as requested from task'
    return 0


# Generated at 2022-06-25 06:48:42.479623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0)
    var_1 = dict()
    var_1 = action_module_0.run(var_0, var_1)

    assert (var_1.get('msg') == 'Failed as requested from task')



# Generated at 2022-06-25 06:48:50.970109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0['ansible_job_id'] = '2017052202350942079'
    var_0['ansible_facts'] = { }
    var_0['ansible_play_batch'] = ["129.local"]
    var_0['ansible_play_hosts'] = ["129.local"]
    var_0['ansible_version'] = {
        'full': '2.4.1.0',
        'major': 2,
        'minor': 4,
        'revision': 1,
        'string': '2.4.1.0',
        'timestamp': 'Tue May  9 15:38:40 BST 2017',
        'version': (2, 4, 1)
    }

# Generated at 2022-06-25 06:48:52.402714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_run()


# Generated at 2022-06-25 06:49:00.449662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()
    action_module_2 = ActionModule(var_0, var_1)
    try:
        var_2 = action_module_2.run(var_0)
        assert var_2.failed
    except Exception:
        pass
    var_3 = dict()
    var_3['msg'] = 'Failed as requested from task'
    action_module_2 = ActionModule(var_0, var_3)
    var_2 = action_module_2.run(var_0, var_3)
    assert var_2.failed

# Generated at 2022-06-25 06:49:10.209420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var0 = dict()
    action_module_0 = ActionModule(var0, var0)
    arg0 = None
    arg1 = dict()
    try:
        var1 = action_module_0.run(arg0, arg1)
    except:
        pass

# Generated at 2022-06-25 06:49:14.960645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0['args'] = {'msg': 'Failed as requested from task'}
    action_module_0 = ActionModule(var_0, var_0)
    var_0 = dict()
    var_0['failed'] = True
    var_0['msg'] = 'Failed as requested from task'
    assert action_module_0.run(var_0) == var_0


# Generated at 2022-06-25 06:49:23.190428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0['action_plugin_load_on_demand'] = var_0
    var_0['inventory_hostname'] = 'foo'
    var_0['ansible_version'] = dict()
    var_0['ansible_version']['string'] = 'foo'
    var_0['ansible_version']['full'] = 'foo'
    var_0['ansible_version']['major'] = 'foo'
    var_0['ansible_version']['minor'] = 'foo'
    var_0['ansible_facts_cacheable'] = list()
    var_0['ansible_facts'] = dict()
    var_0['_ansible_verbosity'] = 5
    var_0['ansible_verbosity'] = 5

# Generated at 2022-06-25 06:49:34.235932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = dict()
    action_module_1 = ActionModule(var_1, var_1)
    var_2 = {
        u'ansible_job_id': u'530496534662.1893',
        u'ansible_facts': {},
        u'changed': False,
        u'_ansible_no_log': False,
        u'invocation': {
            u'module_args': {
                u'msg': 'Failed as requested from task',
            },
            u'module_name': u'fail',
        },
        u'_ansible_parsed': True,
    }

# Generated at 2022-06-25 06:49:40.396484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()
    var_2 = None
    var_3 = None

    var_0['task_vars'] = var_1
    var_0['tmp'] = var_2
    action_module_0 = ActionModule(var_0, var_3)

    action_module_1 = action_module_0.run(var_2, var_1)
    assert 'failed' in action_module_1 and action_module_1['failed'] == True
    assert 'msg' in action_module_1
    assert action_module_1['changed'] == False

# Generated at 2022-06-25 06:49:46.906586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0['msg'] = 'Failed as requested from task'
    var_1 = dict()
    var_2 = dict()
    var_2['failed'] = True
    var_2['msg'] = 'Failed as requested from task'
    var_1['ansible_job_id'] = '4285282267.3'
    var_1['ansible_facts'] = dict()
    var_1['ansible_facts']['playbook_dir'] = '/Users/curtis/Documents/Projects/tisdk-migration-dashboard'
    var_1['_ansible_verbosity'] = 0
    var_1['ansible_version'] = dict()
    var_1['ansible_version']['full'] = '2.9.9'
   

# Generated at 2022-06-25 06:49:48.937658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()
    action_module_0 = ActionModule(var_0, var_0)
    result = action_module_0.run(None, var_1)

    print(result)

# Generated at 2022-06-25 06:49:56.754683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run()")

    # #######################################################
    # 1. Setup
    # #######################################################
    action_module_0 = ActionModule({}, {})

    # #######################################################
    # 2. Run
    # #######################################################
    # Test# 1
    var_0 = action_module_0.run()
    print(var_0)
    print("DONE")

# Generated at 2022-06-25 06:50:00.358851
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    var_1 = dict()
    action_module_1 = ActionModule(var_1, var_1)
    var_2 = None
    var_3 = dict()
    assert action_module_1.run(var_2, var_3) == dict(failed= True, msg= 'Failed as requested from task')

# Generated at 2022-06-25 06:50:09.452145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0['msg'] = 'Failed as requested from task'
    action_module_0 = ActionModule(var_0, var_0)
    var_1 = action_module_0.run()
    assert var_1['msg'] == 'Failed as requested from task'
    assert var_1['failed'] == True
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0)
    var_1 = action_module_0.run()
    assert var_1['msg'] == 'Failed as requested from task'
    assert var_1['failed'] == True

# Generated at 2022-06-25 06:50:19.262592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()
    var_2 = None
    var_3 = ActionModule()
    var_4 = ActionModule()
    var_5 = ActionModule()
    var_6 = ActionModule()
    var_7 = ActionModule()
    var_8 = ActionModule()
    var_9 = ActionModule()
    var_10 = None
    var_11 = None
    var_12 = dict()
    var_13 = dict()
    var_14 = dict()
    var_15 = dict()
    var_16 = dict()
    var_17 = dict()
    var_18 = dict()
    var_19 = dict()
    var_20 = dict()
    var_21 = dict()
    var_22 = dict()
    var_23 = dict()
    var_

# Generated at 2022-06-25 06:50:25.244378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    gen_obj_arg_0 = __import__('ansible.plugins.action.fail', None, None, (None,)).ActionModule()
    gen_obj_arg_1 = None
    gen_obj_arg_2 = dict()
    try:
        gen_obj_arg_0.run(gen_obj_arg_1, gen_obj_arg_2)
    except (NotImplementedError, Exception) as gen_obj_err:
        gen_obj_err = gen_obj_err
    else:
        gen_obj_err = None
    assert gen_obj_err is None


# Generated at 2022-06-25 06:50:33.814354
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an instance of our class
    # This seemingly useless line is necessary so that the variables
    # from the setup function are retained by the other methods
    var_1 = globals()
    var_1 = ActionModule()

    # Invoke method run with correct arguments
    result = var_1.run(tmp = None, task_vars = dict())
    assert type(result) == dict
    assert result == {'msg': 'Failed as requested from task', 'failed': True, '_ansible_verbose_always': True}


# Generated at 2022-06-25 06:50:36.855855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a ActionModule object
    my_obj = ActionModule()

    # Check that the method returns the correct result
    assert my_obj.run(tmp=None, task_vars=None), True

# Generated at 2022-06-25 06:50:43.713647
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    print('BEGIN TEST')
#   _task = None
#   _connection = None
#   _play_context = None
#   _loader = None
#   _templar = None
#   _shared_loader_obj = None
    var_0 = None
    var_1 = None
    test_module = ActionModule(var_0, var_1)
    var_2 = None
    var_3 = None
    test_result = test_module.run(var_2, var_3)
    print(test_result)
    print('END TEST')


# Generated at 2022-06-25 06:50:47.928752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_23 = dict()
    var_23["failed"] = True
    var_23["msg"] = "Failed as requested from task"
    assert ActionModule(task=var_0, connection=var_0, play_context=var_0).run(tmp=var_0, task_vars=var_0) == var_23

# Generated at 2022-06-25 06:50:48.314209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:50:49.148082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:50:53.652388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    var_0 = dict()
    task_vars = var_0
    tmp = None
    self = ActionModule(self._connection, self._play_context, self._loader, self._templar, self._shared_loader_obj)

    # Invocation
    try:
        self.run(tmp, task_vars)
    except Exception:
        fail("Exception expected")

    # Test cases


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 06:50:54.788187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = None
    var_2 = ActionModule()


# Generated at 2022-06-25 06:50:58.733432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:51:08.420443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ANSIBLE_TIMEOUT/timeout set'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = '^0DebjBAF;\x0b;Ih\\it'
    bytes_0 = b"@)x;'\xa7-\xa0\x8f1"
    int_0 = -1668
    float_0 = 3083.7578
    list_0 = []
    action_module_0 = ActionModule(dict_0, str_1, bytes_0, int_0, float_0, list_0)
    var_0 = action_module_0.run()
    str_2 = 'ANSIBLE_ROLES_PATH/roles_path set'
    dict_1

# Generated at 2022-06-25 06:51:08.948759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:51:17.395614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run(self, tmp=None, task_vars=None)
    msg = 'Failed as requested from task'
    result = {'failed': True, 'msg': msg}
    str_0 = 'ANSIBLE_TIMEOUT/timeout set'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = '^0DebjBAF;\x0b;Ih\\it'
    bytes_0 = b"@)x;'\xa7-\xa0\x8f1"
    int_0 = -1668
    float_0 = 3083.7578
    list_0 = []

# Generated at 2022-06-25 06:51:25.620867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ANSIBLE_TIMEOUT/timeout set'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = '^0DebjBAF;\x0b;Ih\\it'
    bytes_0 = b"@)x;'\xa7-\xa0\x8f1"
    int_0 = -1668
    float_0 = 3083.7578
    list_0 = []
    action_module_0 = ActionModule(dict_0, str_1, bytes_0, int_0, float_0, list_0)
    var_0 = action_run()
    assert var_0 == None

# Generated at 2022-06-25 06:51:28.317415
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:51:29.116954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:51:33.588460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:51:34.981994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('In method test_ActionModule_run')


# Generated at 2022-06-25 06:51:36.614631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = test_case_0()



# Generated at 2022-06-25 06:51:50.513461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'tDjQVmC?Oz=7Y'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = "Kx$'_#\x13\x17\x07\x0f\x04\t7^"
    bytes_0 = b'\x10\xc7\x1e\x1c\x9c\x17\x06\x1f\x1c\xa2\xd7\xc8\x1a\xa6\x91\xdf\x8e\x1f\x1d'
    int_0 = -329
    float_0 = -6.43887
    list_

# Generated at 2022-06-25 06:51:56.288824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1803
    str_0 = '\x1b7<\x1e!\xb1\x14\xc7\x8c'
    str_1 = '\x94\x8e\xa6'
    float_0 = 3487.9727
    list_0 = []
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bytes_0 = b"iy\xf8\x0e\xd5\xfa\xdc\x14"
    action_module_0 = ActionModule(dict_0, str_1, bytes_0, int_0, float_0, list_0)
    var_0 = action_run()
    assert isinstance(var_0, dict) == True
    assert var

# Generated at 2022-06-25 06:52:01.643693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init var
    dict_0 = dict()
    dict_1 = dict()
    # Call method
    action_module_0 = ActionModule(dict_0)
    var_0 = action_module_0.run(dict_1)
    assert var_0 == dict()


# Generated at 2022-06-25 06:52:07.806802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from action_plugins import ActionModule

    tmp = None
    task_vars = None
    # Initialize class
    obj = ActionModule(tmp, task_vars)

    # Test action plugin path
    result = obj.run(tmp, task_vars)
    assert obj._action_plugin_path() == 'action_plugins/ActionModule.py'

    # Test _load_name_to_path
    action_paths = ['action_plugins/test_module_path.py']
    action_name_to_path = obj._load_name_to_path(action_paths)

# Generated at 2022-06-25 06:52:11.153106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:52:18.634773
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:52:28.100691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\\p\\\x1d\x1c\x14\xc9\x87\xfe\xed\xd0\xe1\xa2\x93\x03\x9e\xc9X\'\x04r\x12g\xfa\xe0[\xc1'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = '=\x98\r\x93\x03\x8e\xdcX\xc9\xd5\x07'

# Generated at 2022-06-25 06:52:31.408772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:52:38.808827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'jx'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = 'WVqo4'

# Generated at 2022-06-25 06:52:40.340385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 06:53:01.078985
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '9P\x06\x18=\x0c\x10'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = '^0DebjBAF;\x0b;Ih\\it'
    bytes_0 = b"@)x;'\xa7-\xa0\x8f1"
    int_0 = -1668
    float_0 = 3083.7578
    list_0 = []
    action_module_0 = ActionModule(dict_1, str_1, bytes_0, int_0, float_0, list_0)
    var_0 = action_run()


if __name__ == '__main__':
    test_case_0()
    test

# Generated at 2022-06-25 06:53:03.783902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:53:05.841456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


from struct import pack
from ansible.plugins.action.normal import ActionModule as ActionModule_0


# Generated at 2022-06-25 06:53:15.680823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print()
    print('run():')
    float_0 = float('-2.5077')
    float_1 = float('-0.283203125')
    float_2 = float('-0.283203125')
    float_3 = float('-0.283203125')
    float_4 = float('-0.283203125')
    float_5 = float('-0.283203125')
    float_6 = float('-0.283203125')
    float_7 = float('-0.283203125')
    float_8 = float('-0.283203125')
    float_9 = float('-0.283203125')
    float_10 = float('-0.283203125')

# Generated at 2022-06-25 06:53:21.761478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    str_0 = 'ANSIBLE_TIMEOUT/timeout set'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = '^0DebjBAF;\x0b;Ih\\it'
    bytes_0 = b"@)x;'\xa7-\xa0\x8f1"
    int_0 = -1668
    float_0 = 3083.7578
    list_0 = []
    action_module_0 = ActionModule(dict_0, str_1, bytes_0, int_0, float_0, list_0)

    # Setup
    str_0 = 'ANSIBLE_TIMEOUT/timeout set'

# Generated at 2022-06-25 06:53:31.007733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 's'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = ':h'
    bytes_0 = b'\xb5\x9c\xd8'
    int_0 = -1643
    float_0 = 3058.8938
    list_0 = []
    action_module_0 = ActionModule(dict_0, str_1, bytes_0, int_0, float_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:53:32.195587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert var_0 is None


# Generated at 2022-06-25 06:53:40.713712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0[None] = None
    dict_0[None] = None
    dict_0[None] = None
    str_0 = 'Jq$=s]js\\4\\'
    bytes_0 = b'{\x17\x07\t\x1e'
    int_0 = -1664
    float_0 = -1110.5153
    list_0 = []
    list_0.append(None)
    list_0.append(None)
    list_0.append(None)
    action_module_0 = ActionModule(dict_0, str_0, bytes_0, int_0, float_0, list_0)
    action_module_0.run(None, dict_0)


# Generated at 2022-06-25 06:53:49.272475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    exception = None
    try:
        str_0 = 'ANSIBLE_TIMEOUT/timeout set'
        dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
        str_1 = '^0DebjBAF;\x0b;Ih\\it'
        bytes_0 = b"@)x;'\xa7-\xa0\x8f1"
        int_0 = -1668
        float_0 = 3083.7578
        list_0 = []
        action_module_0 = ActionModule(dict_0, str_1, bytes_0, int_0, float_0, list_0)
        var_0 = action_module_0.run()
    except Exception as e:
        exception = e
    assert exception is None

# Generated at 2022-06-25 06:53:49.695674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:54:24.620111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    msg = 'Failed as requested from task'
    dict_0 = dict()
    dict_1 = {'Failed as requested from task': msg, 'Failed as requested from task': msg, 'Failed as requested from task': msg}
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_2 = dict()
    dict_

# Generated at 2022-06-25 06:54:31.015499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ANSIBLE_TIMEOUT/timeout set'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = '^0DebjBAF;\x0b;Ih\\it'
    bytes_0 = b"@)x;'\xa7-\xa0\x8f1"
    int_0 = -1668
    float_0 = 3083.7578
    list_0 = []
    action_module_0 = ActionModule(dict_0, str_1, bytes_0, int_0, float_0, list_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:54:32.951247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()



# Generated at 2022-06-25 06:54:36.839329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:54:44.822933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\\X\x9dS\\\x03'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = 'Bh[\x0e\x13o^'
    bytes_0 = b'f\xf1\x1e\xeae\xf2S\x95\xc8\x0c'
    int_0 = -1608
    float_0 = -4781.0923
    list_0 = [-4781.0923, -4781.0923, -4781.0923]

# Generated at 2022-06-25 06:54:46.458906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a ActionModule instance
    action_module_0 = ActionModule()
    assert action_module_0.run() == None


# Generated at 2022-06-25 06:54:48.555422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Example: simple test using assert_equals
    #assert_equals(3,3)
    return True


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:54:48.980813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:54:49.691435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_run()


# Generated at 2022-06-25 06:54:53.340535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Call method run of class ActionModule
    try:
        action_module_0 = ActionModule()
        action_module_0.run()
    except Exception as e:
        print("\n Exception caught during ActionModule.run()")
        print("\n", e)


# Generated at 2022-06-25 06:55:54.588689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    tmp = 'tmp'
    task_vars = 'task_vars'
    assert obj.run(tmp, task_vars) == 'msg'


# Generated at 2022-06-25 06:55:59.360775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ANSIBLE_CONFIG/ansible_config_file'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = '\x17\x08\x1e\x00\x10\x1d\x0c\x00\x0bBS\x03\x06\x00\x0b'
    bytes_0 = b'\x04\x13\x1et\x1c'
    int_0 = -1221
    float_0 = -766.071
    list_0 = []
    action_module_0 = ActionModule(dict_0, str_1, bytes_0, int_0, float_0, list_0)

# Generated at 2022-06-25 06:56:07.877307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ANSIBLE_TIMEOUT/timeout set'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = '^0DebjBAF;\x0b;Ih\\it'
    bytes_0 = b"@)x;'\xa7-\xa0\x8f1"
    int_0 = -1668
    float_0 = 3083.7578
    list_0 = []
    action_module_0 = ActionModule(dict_0, str_1, bytes_0, int_0, float_0, list_0)
    result_0 = action_module_0.run()



# Generated at 2022-06-25 06:56:14.535958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ANSIBLE_TIMEOUT/timeout set'
    dict_0 = {str_0: str_0, str_0: str_0}
    str_1 = '^0DebjBAF;\x0b;Ih\\it'
    bytes_0 = b"@)x;'\xa7-\xa0\x8f1"
    int_0 = -1668
    float_0 = 3083.7578
    list_0 = []
    action_module_0 = ActionModule(dict_0, str_1, bytes_0, int_0, float_0, list_0)
    action_module_0.run()

# Generated at 2022-06-25 06:56:15.489490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_ActionModule_run() == False


# Generated at 2022-06-25 06:56:21.324567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'oJ!8\x05\x83'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = 'c%*\x1a\xe5\x15\xed'
    bytes_0 = b"@)x;'\xa7-\xa0\x8f1"
    int_0 = -1668
    float_0 = 3083.7578
    list_0 = []
    action_module_0 = ActionModule(dict_0, str_1, bytes_0, int_0, float_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:56:31.855828
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ANSIBLE_TIMEOUT/timeout set'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = '^0DebjBAF;\x0b;Ih\\it'
    bytes_0 = b"@)x;'\xa7-\xa0\x8f1"
    int_0 = -1668
    float_0 = 3083.7578
    list_0 = []
    action_module_0 = ActionModule(dict_0, str_1, bytes_0, int_0, float_0, list_0)
    str_2 = 'q'
    int_1 = -2824
    dict_1 = action_module_0.action_loader()
    dict_2 = action

# Generated at 2022-06-25 06:56:40.062203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_2 = 'x0N\xec\x91\x1c'
    int_1 = -1045011436
    float_1 = 0.00172080394
    bytes_1 = b'-\xcb\xee\xc6j'
    str_3 = 'Pb;5\xcfkf\x8d'
    list_1 = []
    action_module_1 = ActionModule(str_2, int_1, float_1, bytes_1, str_3, list_1)
    var_1 = action_run()


# Generated at 2022-06-25 06:56:42.271021
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:56:51.062119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -3130
    str_0 = 'Nz=Lw\x07n\x1c\x5c!\x7f\xa9\x07'
    int_1 = -4970
    bytes_0 = b'|\xc8\x19\xe9\x1b\x13\xba\x16\x84'
    float_0 = -176.909
    list_0 = []
    action_module_0 = ActionModule(int_0, str_0, int_1, bytes_0, float_0, list_0)
    str_1 = '\n'
    str_2 = '\\U-\x0e\x05\x7f'
    var_0 = action_run(str_1, str_2)