

# Generated at 2022-06-25 06:47:03.826489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:47:04.836528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
    # assert True

# Generated at 2022-06-25 06:47:06.128682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No unit test available
    pass

# Generated at 2022-06-25 06:47:17.201483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '0Qa'
    set_0 = {str_0, str_0, str_0}
    tuple_0 = (set_0, str_0)
    int_0 = 910
    action_module_0 = ActionModule(str_0, str_0, tuple_0, tuple_0, int_0, int_0)
    str_0 = '0Qa'
    set_0 = {str_0, str_0, str_0}
    tuple_0 = (set_0, str_0)
    int_0 = 910
    action_module_0 = ActionModule(str_0, str_0, tuple_0, tuple_0, int_0, int_0)
    dict_0 = dict()
    dict_1 = dict()

# Generated at 2022-06-25 06:47:26.757873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Jy'
    set_0 = {str_0, str_0, str_0}
    tuple_0 = (set_0, str_0)
    int_0 = 830
    action_module_0 = ActionModule(str_0, str_0, tuple_0, tuple_0, int_0, int_0)
    dict_0 = {"eX3"}
    list_0 = [str_0]
    action_module_0.run(list_0, dict_0)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:47:32.272748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '^X&'
    dict_0 = dict()
    tuple_0 = (dict_0, str_0)
    int_0 = 899
    action_module_0 = ActionModule(str_0, str_0, tuple_0, tuple_0, int_0, int_0)
    action_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 06:47:41.048387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('We are at %s' % __name__)

    # Create an instance of class ActionModule
    action_module_0 = ActionModule('0Qa', '0Qa', (set(),), (set(),), 809, 809)

    # Call method run with parameters tmp=None, task_vars=None
    action_module_0.run(None, None)

    # Create an instance of class ActionModule
    action_module_1 = ActionModule('0Qa', '0Qa', (set(),), (set(),), 809, 809)

    # Call method run with parameters tmp=None, task_vars=dict()
    action_module_1.run(None, dict())

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:47:46.956405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    for arg_0 in range(2):
        str_0 = 'jxs'
        set_0 = {str_0, str_0, str_0}
        tuple_0 = (set_0, str_0)
        int_0 = 791
        action_module_0 = ActionModule(str_0, str_0, tuple_0, tuple_0, int_0, int_0)


# Generated at 2022-06-25 06:47:56.627888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '}[i'
    int_0 = -812
    int_1 = 861
    tuple_0 = (int_0, int_0)
    action_module_0 = ActionModule(str_0, str_0, tuple_0, tuple_0, int_1, int_0)
    dict_0 = dict()
    dict_0 = action_module_0.run(int_0, dict_0)
    long_0 = 5333611654065852375
    int_2 = 84518
    str_0 = '!{U'
    dict_0 = dict()
    dict_0 = action_module_0.run(int_2, dict_0)
    dict_0 = action_module_0.run(long_0)
    dict_0 = action_

# Generated at 2022-06-25 06:48:05.403928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '*'
    str_1 = '^'
    str_2 = 'x'
    list_0 = [str_0, str_1, str_2]
    tuple_0 = (str_0, str_1)
    dict_0 = dict()
    dict_0[str_0] = list_0
    dict_0[str_1] = list_0
    tuple_1 = (dict_0, )
    int_0 = 0
    int_1 = 0
    action_module_0 = ActionModule(str_0, str_1, tuple_0, tuple_1, int_0, int_1)
    str_3 = 'o;W'
    str_4 = 'sU'
    dict_1 = dict()
    dict_1[str_3] = str_

# Generated at 2022-06-25 06:48:16.425489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Function run with all arguments.
    #
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
   

# Generated at 2022-06-25 06:48:24.394537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xea(\x83\x9f\x8d\xf3\x18\xd3\x03\x87\xdf\xc7'
    list_0 = ['\x1b\x9e\xb4\x00\xd0', '\xd3\xc3\x82\x1c\x8d\x84']
    int_0 = 43
    str_0 = 'y6UQ'
    dict_0 = {bytes_0: str_0, str_0: str_0, int_0: bytes_0}
    float_0 = 0.42398389033373783

# Generated at 2022-06-25 06:48:27.181334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for function run of class ActionModule
    class_0 = ActionModule({}, {}, int(), '', [], b'')
    var_0 = class_0.run()
    assert var_0 is None

# Generated at 2022-06-25 06:48:38.069186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 965

# Generated at 2022-06-25 06:48:38.948418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('FAILED')


# Generated at 2022-06-25 06:48:44.563039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'\x00\x00\x00'}
    dict_0 = {'\x00': set_0}
    int_0 = 990
    str_0 = chr(252)
    list_0 = [chr(252), chr(252), chr(252)]
    bytes_0 = b'\x04'
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    assert not (action_module_0.run())



# Generated at 2022-06-25 06:48:50.162825
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:49:01.743535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Path of execution
    # /home/ansible/UNIT/unit_tester.py:9: in test_case_0
    # ./lib/ansible/plugins/action/meta.py:71: in <module>
    # ./lib/ansible/plugins/action/meta.py:71: in run
    # ./lib/ansible/module_utils/basic.py:813: in fail_json
    # ./lib/ansible/module_utils/basic.py:788: in fail_json
    # ./lib/ansible/module_utils/basic.py:813: in fail_json
    # ./lib/ansible/module_utils/basic.py:788: in fail_json

    assert True, "Test 1"



# Generated at 2022-06-25 06:49:11.892415
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0)
    var_0 = action_run(list_0, list_0)
    str_1 = 'Failed as requested from task'
    assert str_1 == str_0
    assert not var_0

# Generated at 2022-06-25 06:49:22.733536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xef\x84\x9cU'
    set_0 = {bytes_0, bytes_0, bytes_0}
    bytes_1 = b'\xb4\xdb\x7fU\x96\xbd\xf4\x94\xbb:\xc1\xa3'
    set_1 = {bytes_1, bytes_1, bytes_1}
    dict_0 = {bytes_0 : set_0, bytes_1 : set_1}
    int_0 = -492
    str_0 = 'z\x8a\x0e\x19\x9d'

# Generated at 2022-06-25 06:49:28.204362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    result = obj.run()

# Generated at 2022-06-25 06:49:36.879821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xc5\x8d\xd2\x1f\x9e\xfe\x0b\xed\xc4\x81\x1c\xce\x9e\xd7\x10\xef\xf7\xda\x93\x86\x95'
    dict_0 = {}
    dict_1 = {}
    dict_1['<'] = '_'
    dict_1['cy'] = '}'
    dict_1['B;'] = '\x0c'
    dict_1['0\x1e\x09'] = '\x14\x1c\x0c'
    dict_1['Ga\n'] = ','
    dict_1[';\x0b\x0c'] = '\x18\x0b'

# Generated at 2022-06-25 06:49:43.590445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    y_0 = y
    y_1 = y_0
    y_2 = y_1
    if y_2:
        y_2 = y_2
    else:
        y_2 = y_2
    if y_2:
        y_2 = y_2
    else:
        y_2 = y_2
    if y_2:
        y_2 = y_2
    else:
        y_2 = y_2
    if y_2:
        y_2 = y_2
    else:
        y_2 = y_2
    if y_2:
        y_2 = y_2
    else:
        y_2 = y_2
    if y_2:
        y_2 = y_2
    else:
        y_2 = y_2


# Generated at 2022-06-25 06:49:53.152681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    do_0 = action_run()


# Generated at 2022-06-25 06:49:56.542841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test not yet implemented')
    assert False

# Generated at 2022-06-25 06:50:03.678406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    bytes_1 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'

# Generated at 2022-06-25 06:50:05.102764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(dict_0, set_0, int_0, str_0, bytes_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:50:15.712865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook import PlaybookFile

    PlaybookFile.load_file('')

# Generated at 2022-06-25 06:50:20.623458
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup test variables
    tmp = None
    task_vars = None

    ActionModule(tmp, task_vars)

    return 0

# Generated at 2022-06-25 06:50:30.970031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    sha1sum_0 = '0a0057f67a1b7ca2b8a36b7e1b94c918c8ac8d19'.encode()
    dict_0 = {sha1sum_0: '7bd4a26e9b7ee50d8c7fa447fd67fd700b7a459b.yml'.encode('utf-8')}
    str_0 = ''
    int_0 = 1050
    action_module_0 = ActionModule(dict_0, task_vars, str_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 06:50:47.341945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    action_module_0.run()

# Generated at 2022-06-25 06:50:48.643607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 06:50:55.518091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9a\xf8\x056\xdb\x80g\x98*\x8d\xb2\x0b%\xe9'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    dict_1 = {set_0, dict_0, int_0, str_0, list_0}
    dict_2 = {bytes_0: dict_1}
    var_0 = action_

# Generated at 2022-06-25 06:51:07.581401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    var_0 = action_run()
    set_0.add(bytes_0)
    assert set_0 == set_0
    assert var_0 == var_0
    assert dict_0 == dict_0

# Generated at 2022-06-25 06:51:09.154196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_run_0 = ActionModule.run(ActionModule, 'I\xea%\x00')


# Generated at 2022-06-25 06:51:09.991208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:51:17.202916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:51:25.483833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    action_module_0.run()


# Generated at 2022-06-25 06:51:32.112718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    list_0 = []
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:51:40.712865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 257
    str_0 = 'O\x1aZOi\x10z'
    str_1 = '\xeb\xf5\x1d\xfe\x00\x8a\xb2\xbe\x95\x0f\x841\x1a\xa6\x0c\x99\xd1\x7e\xce\x9dV\x9a'

# Generated at 2022-06-25 06:52:07.064519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = frozenset()
    dict_0 = {}
    int_0 = 888
    str_0 = ';\x1d'
    list_0 = []
    bytes_0 = b'\xc2\x84\xec\x15\n\x1c\xe9\x98\x0c\x8b\xbd\x1f\xf5\xa2\xd5\xbf\x9e\xa9\x1a\xa0'
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    tmp_0 = None
    task_vars_0 = {}
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# Unit

# Generated at 2022-06-25 06:52:07.916968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert false


# Generated at 2022-06-25 06:52:18.083763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3', '\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3', '\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'}
    dict_0 = {'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3': set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0

# Generated at 2022-06-25 06:52:25.904791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    action_module_0.run(None, None)

# Generated at 2022-06-25 06:52:35.119116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    action_module_0._task.args = frozenset(('msg',))
    action_module_0._task.args = {'msg': 'Failed as requested from task'}
    action_module_0

# Generated at 2022-06-25 06:52:40.479356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    action_module_0.run()

# Generated at 2022-06-25 06:52:47.455690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfb\x90\t\x04\xb9\xba\xe4d\x00\xd1\x08\x15\xab\x0f\xa9\x9cg'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    action_module_0.run()


# Generated at 2022-06-25 06:52:55.136721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:53:04.272841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x1d\x94\x9f\xc0$\xa6\x80\xcd8\xd3\x1c\xa6\xa0\x93\x81\xf4\xd2\x92\x8f'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    dict_1 = dict()
    var_0 = action_module_0.run(set_0, dict_1)

# Generated at 2022-06-25 06:53:14.302599
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x1b\xbb\x9b\x9e\tr\x0f\xb6'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 836
    str_0 = '<4C\x1b\xb3\x1b\x0c;\xa3\xc4\x82\nQ4\x9a\xce'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    action_module_0.run()
    action_module_0.run()

# Generated at 2022-06-25 06:54:01.897616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    var_0 = action_run()
    var_0 = action_run()

# Generated at 2022-06-25 06:54:04.494736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:54:10.333427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    task_vars_0 = None
    tmp_0 = None

    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:54:20.187415
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfa\xf8\x86\xd6\xa7\xca\xe3\x93\xde\x1c\x88\xadT\x9f\xcb\x13\xd2Q\xda\n\x84\x06\xa1\x1b\x9c\x83D\x9c\xea\x8b3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []

# Generated at 2022-06-25 06:54:27.157414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'"\x84\xd5\x02\xccI\n\x9d\xaf\x8a\x80\x00'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 527
    str_0 = 'h3UJ\x8fQ\xba\x0e'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    var_0 = action_run(action_module_0)


# Generated at 2022-06-25 06:54:36.109021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    var_0 = action_run()
    assert var_0 == None

test_case_0()

# Generated at 2022-06-25 06:54:42.670152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:54:49.070749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)
    param_0 = -1
    param_1 = {str_0: set_0}
    var_0 = action_module_0.run(param_1, param_0)
    assert True

# Generated at 2022-06-25 06:54:52.095536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(0, 0, 0, '', 0, b'')
    bytes_0 = b''
    dict_0 = {}
    str_0 = action_module_0.run(bytes_0, dict_0)

# Generated at 2022-06-25 06:54:54.010778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # result = action_module_0.run()
    # assert(result == None)

    assert(True)


# Generated at 2022-06-25 06:56:39.466664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_run()


# Generated at 2022-06-25 06:56:49.939794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x18\xab4\x95o1\xc1N\xa1\x82t\x1b&,4\xd3'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 965
    str_0 = ']g \nCu2{bm[WF7k'
    list_0 = []
    action_module_0 = ActionModule(set_0, dict_0, int_0, str_0, list_0, bytes_0)

    action_module_0.run()


# Generated at 2022-06-25 06:56:51.240942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False # implement your test here


# Generated at 2022-06-25 06:57:01.004856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'?\x93\r\xe8\xe6\xce\\\x99\xde\x9e\x8a\xb6\xc0\xa0\xf7\x1a\xae\x1aZ'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    int_0 = 691