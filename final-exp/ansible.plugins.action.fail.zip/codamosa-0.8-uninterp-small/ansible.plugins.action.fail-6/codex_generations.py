

# Generated at 2022-06-25 06:47:05.565590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = '{"1'
    int_0 = 50
    list_0 = ['O', 1.0, 0]
    str_2 = '!}0Hp'
    str_3 = "thC"
    list_1 = [str_3, 1.0, 0]
    action_module_0 = ActionModule(list_1, str_2, str_1, list_0, int_0, str_3)
    action_module_1 = ActionModule(list_1, str_2, str_1, list_0, int_0, str_3)

    list_2 = [str_2, str_2]
    str_4 = "Cm0"
    str_5 = "X_\x7f"
    list_3 = [str_3, str_3]
    int

# Generated at 2022-06-25 06:47:16.731449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule({'failed': False, 'stdout': '', 'rc': 0, 'stdout_lines': ['']}, __name__, None, {'host_list': ['j8.n4.v2'], 'inventory_file': '/etc/ansible/hosts', 'inventory_directory': '/etc/ansible', 'inventory_basedir': '/etc/ansible'}, '/usr/lib64/python2.7/site-packages/ansible/playbook/play_context.pyc', 'ansible.plugins.action.debug', 'action_debug')

# Generated at 2022-06-25 06:47:23.180960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "postfix/postdrop[1295]: warning: unable to look up public/pickup: No such file or directory"
    int_0 = 3
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    str_1 = 'msg'
    str_2 = 'hello'
    dict_0 = {str_1:str_2}
    list_1 = [dict_0, dict_0, dict_0]
    action_module_0.args = list_1
    result = action_module_0.run({}, {})
    assert result['failed'] == True

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 06:47:33.438394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'T-3qD'
    int_0 = 83
    list_0 = [str_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)

    # Call method run of action_module_0
    result = action_module_0.run()
    assert isinstance(result, dict)
    assert result == {'failed': True, 'msg': 'Failed as requested from task'}

    # Call method run of action_module_0
    result = action_module_0.run()
    assert isinstance(result, dict)
    assert result == {'failed': True, 'msg': 'Failed as requested from task'}

# Generated at 2022-06-25 06:47:35.785438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule.run()


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:47:47.058343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '!^A7VY}F/j'
    str_1 = 'JjHpyb'
    list_0 = [str_1, str_1]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int(), str_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_0['JjHpyb'] = dict_1
    dict_1['JjHpyb'] = dict_1
    dict_2 = dict()
    dict_0['JjHpyb']['JjHpyb']['JjHpyb'] = dict_2

# Generated at 2022-06-25 06:47:51.472941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'A*Sm]/u'
    int_0 = 46
    list_0 = [int_0]

# Generated at 2022-06-25 06:47:55.640182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'WXRn+[hQjGd!l5r'
    dict_0 = dict()
    tmp = None

    action_module_0 = ActionModule(dict_0, str_0, str_0, dict_0, str_0, str_0)
    action_module_0.run(tmp, dict_0)

# Generated at 2022-06-25 06:48:04.956121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = ['G', ')', 'X', 'K', 'Y', 'm', 'G', ')', 'X', 'K', 'Y', 'm', 'G', ')', 'X', 'K', 'Y', 'm', 'G', ')', 'X', 'K', 'Y', 'm']
    str_0 = ''
    str_1 = 'a'
    list_1 = [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, True, False, False, False, False, False]
    action_module_0

# Generated at 2022-06-25 06:48:10.226691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f4D5>t;|p5}1S:ZTL'
    int_0 = 80
    action_module_0 = ActionModule(None, None, str_0, None, int_0, None)

# End of test of class ActionModule


# Generated at 2022-06-25 06:48:13.810839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    # Test method run of class ActionModule
    out = ActionModule.run(tmp, task_vars)

# Generated at 2022-06-25 06:48:21.125549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = None
    # Test case where self._task.args is None
    str_0 = '4P^i'
    test_case_0()
    # Test case where self._task.args is not None
    str_1 = 'tjA*D'
    test_case_1()
    # Test case where self._task.args is not None and self._task.args['msg'] is None
    str_2 = 'f9G-'
    str_3 = 'c'
    test_case_2()


# Generated at 2022-06-25 06:48:23.390131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    f = ActionModule()

# Generated at 2022-06-25 06:48:31.835981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0['a'] = 18
    dict_0['b'] = 73
    dict_0['c'] = 83
    dict_0['d'] = 91
    dict_0['e'] = 3
    dict_0['f'] = 44
    dict_0['g'] = 79
    dict_0['h'] = 5
    dict_0['i'] = 43
    dict_0['j'] = 98
    dict_0['k'] = 7
    dict_0['l'] = 51
    dict_0['m'] = 61
    dict_0['n'] = 51
    dict_0['o'] = 58
    dict_0['p'] = 45
    dict_0['q'] = 57
    dict_0['r'] = 23
    dict_0['s'] = 48
   

# Generated at 2022-06-25 06:48:34.876336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = 'A*Sm]/u'
    int_0 = 46
    int_1 = [int_0]
    result = action_module_0.run() # expected exception
    assert result == None

# Generated at 2022-06-25 06:48:43.069036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()

    a._task = {}
    a._task.args = {}
    a._task.args['msg'] = 'Failed as requested from task'
    a._task.action = 'debug'
    a._task_vars = {}
    a._task_vars['ansible_ssh_user'] = 'vagrant'
    a._task_vars['ansible_check_mode'] = False
    a._task_vars['ansible_playbook_python'] = '/usr/bin/python2'
    a._task_vars['ansible_connection'] = 'ssh'
    a._task_vars['ansible_user_id'] = 'root'
    a._task_vars['ansible_ssh_host'] = 'localhost'

# Generated at 2022-06-25 06:48:44.594551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Get instance of ActionModule
    obj = ActionModule(namespace, values)

    # Apply run method
    obj.run(tmp, task_vars)

# Generated at 2022-06-25 06:48:48.881093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = list()
    action_module_0 = ActionModule(list_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_1['msg'] = ''
    dict_1['tm*o'] = dict_0
    dict_1['task_vars'] = dict_0
    dict_2 = action_module_0.run(task_vars=dict_1)


# Generated at 2022-06-25 06:48:54.066801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = (tmp_0, task_vars_0)
    bool_0 = True
    str_0 = str_1 = 'Q[xNf'
    bool_1 = bool_0
    int_0 = 0

    # Operation
    result_0 = ActionModule.run(*args_0)

    # Evaluation
    assert result_0 == result_1

    # Operation
    result_0 = ActionModule.run(*args_0)

    # Evaluation
    assert result_0 == result_1

    # Operation
    result_0 = ActionModule.run(*args_0)

    # Evaluation
    assert result_0 == result_1

    # Operation
    result_0 = ActionModule.run(*args_0)

    # Evaluation
    assert result_0 == result_1

    # Operation

# Generated at 2022-06-25 06:48:57.832820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(complex_args=complex_0)
    str_0 = 'msg'
    str_1 = 'msg'
    dict_0 = {'msg': str_1}
    action_module_0.run(task_vars=dict_0)


# Generated at 2022-06-25 06:49:03.190027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:49:11.139109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_0 = ActionModule()
    tmp = None
    task_vars = dict()
    assert isinstance(action_module_run_0.run(tmp, task_vars), dict)
    tmp = None
    task_vars = dict()
    assert isinstance(action_module_run_0.run(tmp, task_vars), dict)


# Generated at 2022-06-25 06:49:14.748586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = "tmp"
    task_vars = {}
    expected_result = {
        'failed': True,
        'msg': 'Failed as requested from task'
    }
    actual_result = action_module.run(tmp, task_vars)
    assert actual_result == expected_result


# Generated at 2022-06-25 06:49:16.348067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 06:49:22.547969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_tmp = None
    var_task_vars = dict()

    # Assign parameters passed from mock
    # This method returns a tuple
    # Assign result of this method to mock_call
    mock_call = (var_tmp, var_task_vars)

    with patch.object(ActionModule, "run", return_value=mock_call):
        result_run = action_module_0.run(var_tmp, var_task_vars)

        # Check the result of calling run()
        assert (result_run == mock_call)

# Generated at 2022-06-25 06:49:28.457162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:49:29.229963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:49:30.281704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:49:31.287688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

test_ActionModule_run()

# Generated at 2022-06-25 06:49:33.828879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict()
    action_module = ActionModule()
    assert action_module.run(task) == {'msg': 'Failed as requested from task', 'failed': True}


# Generated at 2022-06-25 06:49:43.073918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)

# Generated at 2022-06-25 06:49:54.204972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    var_0 = action_module_0.run(str_0)
# Testing whether the parameter "int_0" is equal to "68", expecting the results to be equal.
test_case_0()
# Testing the

# Generated at 2022-06-25 06:50:02.913958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    var_0 = action_module_0.run(str_0, str_0)
    assert (var_0 == False)

# Generated at 2022-06-25 06:50:07.580921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, var_0, var_0, list_0, int_0, var_0)
    var_1 = action_run(var_0)

# Generated at 2022-06-25 06:50:13.649175
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Declarations
    str_0 = "FAILED!"
    bool_1 = False
    str_1 = "msg"
    bool_0 = True
    action_module_0 = ActionModule(str_0)
    tmp = None
    task_vars = None

    # Assignments
    action_module_0.flags['action_always_append_flags'] = False
    action_module_0.flags['action_never_append_flags'] = False
    action_module_0.flags['action_append_no_log'] = None
    action_module_0.flags['action_binary_args'] = None
    action_module_0.flags['action_default_args'] = None
    action_module_0.flags['action_delegate_to'] = None

# Generated at 2022-06-25 06:50:19.501465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    var_0 = action_run(str_0)
    assert var_0 == 1

# Generated at 2022-06-25 06:50:20.759203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Nothing to be tested here
    pass

# Generated at 2022-06-25 06:50:23.683063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:50:26.099569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule()
    action_module_instance._remove_tmp_path()


# Generated at 2022-06-25 06:50:37.103907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = ['']
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, 68, str_0)
    #Test case file "test/units/plugins/action/__init__.py" line 10
    #Test case line 15
    #Test case line 18
    #Test case line 24
    #Test case line 28
    #Test case line 25

# Generated at 2022-06-25 06:50:42.687967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    msg = 'Failed as requested from task'
    print(msg)
    pass

# Generated at 2022-06-25 06:50:43.563972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:50:51.922420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    var_1 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '

# Generated at 2022-06-25 06:50:59.995564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = [0]
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    str_1 = 'Failed as requested from task'
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    var_0 = action_run(str_0)
    assert var_0 == str_1

# Generated at 2022-06-25 06:51:05.024434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    action_module_0.run()



# Generated at 2022-06-25 06:51:10.569418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters tests
    tmp_0 = None
    task_vars_0 = None  # Type: dict
    action_module_0 = ActionModule()
    result = action_module_0.run(tmp_0, task_vars_0)

    tmp_1 = None
    task_vars_1 = dict()
    action_module_1 = ActionModule()
    result = action_module_1.run(tmp_1, task_vars_1)

# Generated at 2022-06-25 06:51:15.844120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO:
    #assert func(action_module_0, action_module_0, action_module_0, action_module_0, action_module_0) == action_module_0

    raise Exception("Test not implemented")

# Generated at 2022-06-25 06:51:18.851204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:51:19.598965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:51:20.859799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:51:36.149692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0._task.args.get('msg') == 'Failed as requested from task'
    assert action_module_0.run(action_module_0._task.args.get('msg'), dict())['msg'] == 'Failed as requested from task'
    return

# Generated at 2022-06-25 06:51:41.581790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 06:51:50.576005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    assert action_module_0.run(str_0)
    action_module_0.run(str_0)
    action_module_0.run(str_0)

# Generated at 2022-06-25 06:51:56.307050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    arg_1 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '

# Generated at 2022-06-25 06:52:05.627971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_1 = 68
    list_1 = [int_1, int_1]
    action_module_1 = ActionModule(list_1, str_1, str_1, list_1, int_1, str_1)
    str_2 = '            This action produces no diff\n        '
    action_module_1.run(str_2)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:52:06.279301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO:
    pass


# Generated at 2022-06-25 06:52:15.000399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)

# Generated at 2022-06-25 06:52:25.015189
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_1 = ActionModule(None, None, None, None, None, None)
    action_module_1.self = action_module_0

    # Execute the method being tested
    list_0 = [action_module_1.self, None]
    int_0 = 68
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    list_1 = [int_0, int_0]


# Generated at 2022-06-25 06:52:34.105242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    var_0 = action_run(str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:52:38.552246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = 68
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    dict_0 = dict()
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    var_0 = action_module_0.run(int_0, dict_0)



# Generated at 2022-06-25 06:52:58.206027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(test_case_0.__doc__)
    test_ActionModule_run()

# Generated at 2022-06-25 06:53:01.261065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Call method ActionModule.run of class ActionModule

    # AssertionError: 'Failed as requested from task' != 'not implemented'
    raise AssertionError('This assertion was not implemented')


# Generated at 2022-06-25 06:53:03.487675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')


# Generated at 2022-06-25 06:53:10.437881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'y\x0b'
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    var_0 = action_run(str_0)
    assert var_0.msg == 'Failed as requested from task'
    assert var_0.failed == True


# Generated at 2022-06-25 06:53:18.424938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_3 = '\n                            Change active host/group. You can use hosts patterns as well eg.:\n                            cd webservers\n                            cd webservers:dbservers\n                            cd webservers:!phoenix\n                            cd webservers:&staging\n                            cd webservers:dbservers:&staging:!phoenix\n                        '
    int_3 = 68
    list_3 = [int_3, int_3]
    action_module_3 = ActionModule(list_3, str_3, str_3, list_3, int_3, str_3)

# Generated at 2022-06-25 06:53:19.276445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:53:28.657834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    var_0 = action_run(str_0)
    assert var_0 == None

# Generated at 2022-06-25 06:53:32.954916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # TODO


# Generated at 2022-06-25 06:53:42.267517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    str_1 = 'Failed as requested from task'
    int_1 = 2
    dict_0 = dict()
    dict_0[str_1] = int_1
    dict_0[str_1]

# Generated at 2022-06-25 06:53:43.308606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test for run
    print(ActionModule.run())


# Generated at 2022-06-25 06:54:31.329135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 06:54:32.469098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = [action_module_0, run, msg_0, failed]
    var_0 = action_run(dict())
    var_0 = action_run(var_0)

# Generated at 2022-06-25 06:54:42.547802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    method_0 = action_module_0.run
    class_0 = dict
    dict_0 = dict()
    dict_0['msg'] = 'Run failed as requested from test'

# Generated at 2022-06-25 06:54:49.035494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)

# Generated at 2022-06-25 06:54:52.613973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = 'tmp'
    str_1 = 'task_vars'
    list_0 = ['tmp', 'task_vars']
    var_0 = action_module_0.run(str_0, str_1)


# Generated at 2022-06-25 06:55:00.114077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 06:55:03.185961
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0._task.args['msg'] == 'Failed as requested from task'

test_ActionModule_run()

# Generated at 2022-06-25 06:55:09.047364
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    str_1 = 'cd webservers'
    dict_0 = action_module_0.run(str_1)
    int_1 = 1
    int_2 = 1
    bool_0 = int_1

# Generated at 2022-06-25 06:55:13.575871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'A'
    str_1 = 'D'
    str_2 = 'CF'
    str_3 = 'BF'
    str_4 = 'BF'
    str_5 = 'F'
    str_6 = 'F'
    str_7 = 'F'
    list_0 = [str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7]
    list_1 = ['A', 'D', 'CF', 'BF', 'BF', 'F', 'F', 'F']
    str_8 = 'BF'
    str_9 = 'BF'
    str_10 = 'F'
    str_11 = 'F'
    str_12 = 'F'
    str_13 = 'F'
    str_14

# Generated at 2022-06-25 06:55:21.768358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n            Change active host/group. You can use hosts patterns as well eg.:\n            cd webservers\n            cd webservers:dbservers\n            cd webservers:!phoenix\n            cd webservers:&staging\n            cd webservers:dbservers:&staging:!phoenix\n        '
    int_0 = 68
    list_0 = [int_0, int_0]
    str_1 = '!'
    action_module_0 = ActionModule(list_0, str_0, str_0, list_0, int_0, str_0)
    var_0 = action_run(str_1)