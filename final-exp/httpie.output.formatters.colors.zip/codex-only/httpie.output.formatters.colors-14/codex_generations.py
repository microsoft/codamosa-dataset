

# Generated at 2022-06-23 19:19:27.663740
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins import builtin

    config = Config(color=True)
    env = Environment(config=config)

    plugin_manager = builtin.BuiltinPluginManager()
    plugin_manager.add_plugin(ColorFormatter(env))
    plugin_manager.add_plugin(ColorFormatter(env, color_scheme='solarized'))
    plugin_manager.add_plugin(ColorFormatter(env, color_scheme='fruity'))

# Generated at 2022-06-23 19:19:33.603118
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    test_string = '''GET / HTTP/1.1
User-Agent: curl/7.16.3 libcurl/7.16.3 OpenSSL/0.9.7l zlib/1.2.3
Host: 0.0.0.0=5000
Accept-Language: en, mi
 
'''
    lexer = SimplifiedHTTPLexer()

    from pprint import pprint
    pprint(list(lexer.get_tokens(test_string)))

# Generated at 2022-06-23 19:19:44.866580
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie.plugins
    env = httpie.plugins.Environment()
    env.colors = '256'
    env.stdout_isatty = True
    formatter = ColorFormatter(env)

    def _test(mime: str, body: str) -> bool:
        lexer = formatter.get_lexer_for_body(mime, body)
        return lexer and isinstance(lexer, pygments.lexers.JsonLexer)

    assert _test('application/json', '')
    assert _test('application/json', '{}')
    assert _test('application/json', '{"a":1}')
    assert not _test('application/json', '{"a":1')
    assert not _test('application/json', '{"a":1]')

# Generated at 2022-06-23 19:19:46.230292
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style().styles

# Generated at 2022-06-23 19:19:53.303450
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    http_lexer = SimplifiedHTTPLexer()
    formatter = TerminalFormatter()
    assert ColorFormatter(Environment(colors=1)).http_lexer is http_lexer
    assert ColorFormatter(Environment(colors=1)).formatter == formatter
    #assert ColorFormatter(Environment(colors=256)).http_lexer is http_lexer
    assert ColorFormatter(Environment(colors=256)).formatter == formatter

# Generated at 2022-06-23 19:20:01.435616
# Unit test for function get_lexer
def test_get_lexer():
    l = get_lexer(
        mime='application/json',
        explicit_json=False,
        body='{}'
    )
    assert isinstance(l, pygments.lexers.JsonLexer)

    l = get_lexer(
        mime='application/json',
        explicit_json=False,
        body='<html></html>'
    )
    assert isinstance(l, pygments.lexers.HtmlLexer)

    l = get_lexer(
        mime='application/json',
        explicit_json=True,
        body='<html></html>'
    )
    assert isinstance(l, pygments.lexers.JsonLexer)


# Generated at 2022-06-23 19:20:12.595610
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # GIVEN a ColorFormatter instance
    env = Environment()
    formatter = ColorFormatter(env, explicit_json=False)

    # WHEN formatting the body of an HTML document
    html_body = """
        <html>
            <body>
                <h1>Hello, World!</h1>
            </body>
        </html>
    """

    # THEN the result should contain the syntax highlighting
    html_syntax_highlight = """
        <html>
            <body>
                <h1>Hello, World!</h1>
            </body>
        </html>
    """
    assert formatter.format_body(html_body, "text/html") == html_syntax_highlight

    # WHEN formatting the body of a JSON document

# Generated at 2022-06-23 19:20:20.065677
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # A simple test to make sure the color formatter doesn't
    # break the headers formatting.

    from httpie.core import is_windows
    from httpie.plugins import builtin

    # On Windows, the test should pass anyway
    # as colorama will make sure that ANSI sequences
    # are not output to the terminal.
    env = Environment(colors=256)

    processor = ColorFormatter(
        env=env,
        color_scheme=SOLARIZED_STYLE,
    )
    reformatter = builtin.Reformatter()

    # Example taken from the Internet Engineering Task Force (IETF)
    # standard document "Hypertext Transfer Protocol -- HTTP/1.1":
    # https://tools.ietf.org/html/rfc2616#section-5.1
    formatted_headers = processor.format

# Generated at 2022-06-23 19:20:31.178679
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert not get_lexer('application/json', True, '')
    assert not get_lexer('not/json', True, '')
    assert get_lexer('application/json', True, '{}')
    assert get_lexer('application/unknown+json', False, '{}')
    assert get_lexer('application/unknown+json', True, '{}')
    assert not get_lexer('application/unknown+json', False, '')
    assert get_lexer('application/unknown+json', True, '')
    assert get_lexer('application/unknown+json', True, 'json')
    assert get_lexer('application/unknown+json', False, 'json')
    assert not get_lexer('application/unknown+xml', True, 'json')

# Generated at 2022-06-23 19:20:32.432884
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer() is not None

# Generated at 2022-06-23 19:20:33.365558
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert style

# Generated at 2022-06-23 19:20:36.831534
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s256 = Solarized256Style()  # type: Solarized256Style

if is_windows:
    # Colors on Windows via colorama don't look that
    # great so we disable the default Solarized
    # color scheme.
    del AVAILABLE_STYLES[SOLARIZED_STYLE]

# Generated at 2022-06-23 19:20:38.404169
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    ColorFormatter(Environment(), False)

# Generated at 2022-06-23 19:20:44.089756
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer('text/html'), pygments.lexers.HtmlLexer)
    assert isinstance(get_lexer('application/json'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/json+foo'), pygments.lexers.JsonLexer)
    assert get_lexer('text/foo') is None

# Generated at 2022-06-23 19:20:47.311227
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert style.background_color == "#1c1c1c"
    assert style.styles[pygments.token.Name.Attribute] == "#8a8a8a"

# Generated at 2022-06-23 19:20:57.066259
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer('text/html'), pygments.lexers.HtmlLexer)
    assert isinstance(get_lexer('text/html+jinja'), pygments.lexers.HtmlLexer)
    assert isinstance(get_lexer('application/json'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/json+foo'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/json+foo', body='{}'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/json', body='{}', explicit_json=True), pygments.lexers.JsonLexer)
    assert get_lexer('application/foo') is None
    assert get_lexer

# Generated at 2022-06-23 19:20:58.341820
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    try:
        Solarized256Style()
    except Exception:
        assert False

# Generated at 2022-06-23 19:21:05.623254
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(output_options={"colors"})
    Color = ColorFormatter(env)
    print(Color.get_lexer_for_body("application/json", "{"))
    print(Color.get_lexer_for_body("application/json", "{'name': 'david'}"))
    print(Color.get_lexer_for_body("application/json", "{'name': 'david'}\n"))
    print(Color.get_lexer_for_body("application/json", "{'name': 'david'}\n{"))
    print(Color.get_lexer_for_body("application/json", "["))

# Generated at 2022-06-23 19:21:16.991970
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    http_lexer = SimplifiedHTTPLexer()
    formatter = TerminalFormatter()

    # HTTP request
    test_input = (
        'GET / HTTP/1.1\r\n'
        'Accept: */*\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Connection: keep-alive\r\n'
        'Content-Length: 0\r\n'
        'Host: jkbrzt.github.io\r\n'
        'User-Agent: HTTPie/1.0.2\r\n'
        '\r\n'
    )


# Generated at 2022-06-23 19:21:25.274503
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import httpie.plugins
    httpie.plugins.load()

    def format_headers(headers, color_scheme):
        env = Environment(colors=True)
        return ColorFormatter(env, color_scheme=color_scheme).format_headers(headers)


# Generated at 2022-06-23 19:21:35.266925
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pprint
    import re

    class MockEnvironment(object):
        colors = 256
        styles = set(pygments.styles.get_all_styles())
        style = 'solarized256'

    class MockParser(object):
        options = {
            'style': 'solarized256',
            'color': True,
        }

    class MockEnvironment(object):
        colors = 256
        styles = set(pygments.styles.get_all_styles())
        style = 'solarized256'

    class MockParser(object):
        options = {
            'style': 'solarized256',
            'color': True,
        }

    class MockEnvironment(object):
        colors = 256
        styles = set(pygments.styles.get_all_styles())
        style = 'solarized256'


# Generated at 2022-06-23 19:21:41.787347
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()


# Generated at 2022-06-23 19:21:51.048539
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class TestEnv:
        colors = 256
    class TestColorFormatter(ColorFormatter):
        pass
    env = TestEnv()
    obj = TestColorFormatter(env)

    mime = 'application/json'
    explicit_json = False
    body = 'null'  # any valid JSON value.

    lexer = pygments.lexers.get_lexer_by_name('json')
    assert obj.get_lexer_for_body(mime, body) == lexer

    mime = 'application/ld+json'
    lexer = pygments.lexers.get_lexer_for_mimetype('application/ld+json')
    assert obj.get_lexer_for_body(mime, body) == lexer

    mime = 'application/xml'
    lexer = None

# Generated at 2022-06-23 19:22:00.794693
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter()
    assert get_lexer('application/xml') == pygments.lexers.get_lexer_by_name('xml')
    # assert get_lexer('text/xml') == pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    # assert get_lexer('text/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('text/plain') == pygments.lexers.get_lexer_by_name('txt')
    assert get_lexer('text/markdown') == pygments.lexers.get_lexer_by_name('markdown')

# Generated at 2022-06-23 19:22:11.484943
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    text = 'HTTP/1.1 200 OK\r\nHeader: Value\r\n'

# Generated at 2022-06-23 19:22:22.287153
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class FakeEnv:
        colors = True

    headers = (
        'GET / HTTP/1.1\r\n'
        'Host: example.org\r\n'
        'User-Agent: HTTPie/0.9.3\r\n'
        'Accept-Encoding: gzip, deflate, compress\r\n'
        'Accept: */*\r\n'
        'Connection: keep-alive\r\n'
        '\r\n'
    )
    color_formatter = ColorFormatter(env=FakeEnv())
    result = color_formatter.format_headers(headers)

# Generated at 2022-06-23 19:22:32.546834
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('application/json')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer('application/vnd.api+json')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer('text/html')
    assert lexer == pygments.lexers.get_lexer_by_name('html')

    lexer = get_lexer('text/html+jinja')
    assert lexer == pygments.lexers.get_lexer_by_name('django')

    lexer = get_lexer('text/html+jinja', body='[')

# Generated at 2022-06-23 19:22:33.390016
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()

# Generated at 2022-06-23 19:22:38.656164
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment = Environment()
    environment.colors = 256
    color_formatter = ColorFormatter(environment, color_scheme=SOLARIZED_STYLE)
    style_class = color_formatter.get_style_class(SOLARIZED_STYLE)
    import httpie.output.formatters.colors
    assert style_class == httpie.output.formatters.colors.Solarized256Style
    style_class = color_formatter.get_style_class("not exit")
    assert style_class == httpie.output.formatters.colors.Solarized256Style

# Generated at 2022-06-23 19:22:42.213747
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    c = ColorFormatter()
    c.explicit_json = False
    test_mime1 = 'application/json'
    test_mime2 = 'text/html'
    result1 = c.format_body('{"name": "Jackson"}', test_mime1)
    assert '{' in result1, "expected result1 to contain '{'"
    result2 = c.format_body('{"name": "Jackson"}', test_mime2)
    assert '{' not in result2, "expected result2 to not contain '{'"

# Generated at 2022-06-23 19:22:50.814791
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.cli import environment
    from httpie.downloads import Downloader
    from httpie.plugins import builtin
    from httpie.output.streams import Stream

    env = environment.Environment(
        stdout=Stream(None),
        color=True,
        downloader=Downloader(),
        output_options=builtin.DEFAULT_OUTPUT_OPTIONS_PRESET,
        stdin=None,
        vars=builtin.DEFAULT_VARS_PRESET,
        colormode=False
    )
    colorFormatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    colorFormatter.body = "Some body"
    colorFormatter.mime = "text/html"
    colorFormatter.format_body()

# Generated at 2022-06-23 19:22:52.841292
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    f = ColorFormatter(env=None)
    assert f is not None

# Generated at 2022-06-23 19:22:56.705378
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert 'Token' in style.styles
    assert isinstance(style.styles['Token'], str)
    assert len(style.styles['Token']) == 7

# Generated at 2022-06-23 19:22:57.866695
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter is not None

# Generated at 2022-06-23 19:22:58.871406
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    # should not throw an exception
    Solarized256Style()

# Generated at 2022-06-23 19:23:02.141299
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('foo/bar') == None
    assert get_lexer('text/html') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/x-c') == pygments.lexers.get_lexer_by_name('c')

# Generated at 2022-06-23 19:23:04.809844
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) == pygments.styles.get_style_by_name(DEFAULT_STYLE)

# Generated at 2022-06-23 19:23:08.646278
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment(colors=256, default_options=None)
    color_formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert color_formatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-23 19:23:15.388897
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.core import main
    from httpie.cli.parser import parser
    args = parser.parse_args("--colors=256 --color=solarized".split())
    class Test_environment(object):
        def __init__(self, col):
            self.colors = col
    env = Test_environment(256)
    # color and col
    colorf = ColorFormatter(env, args.color_mode, color_scheme=args.color_scheme)
    assert colorf.formatter.style == Solarized256Style
    # test with different args
    colorf = ColorFormatter(env, args.color_mode, color_scheme="default")
    assert colorf.formatter.style == Solarized256Style

# Generated at 2022-06-23 19:23:20.328565
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

    # TODO: test all tokens
    # TODO: test if the tokens are translated correctly

    text = 'GET /somefile HTTP/1.1\r\n' \
          + 'Host: example.org\r\n' \
          + '\r\n'
    result = pygments.highlight(text, lexer, formatter)

    # TODO: more extensive tests

    assert True

# Generated at 2022-06-23 19:23:21.737760
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()

# Generated at 2022-06-23 19:23:32.229357
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import unittest
    import httpie.core
    from httpie.core import output_options
    from httpie.core import _ExitStatus
    from httpie.core import main
    from httpie.core import CLIFactory
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import lmap
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.compat import bytes
    from json import dumps
    from pygments.style import Style
    from pygments.formatters import TerminalFormatter
    from pygments.lexer import RegexLexer
    from pygments.lexers import get_lex

# Generated at 2022-06-23 19:23:40.107992
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    mime = "http/2.0"
    explicit_json = False
    body = """
    GET / HTTP/1.1
    Host: localhost:8080
    User-Agent: curl/7.43.0
    Accept: */*

    """

    assert get_lexer(mime, explicit_json, body) is SimplifiedHTTPLexer

    mime = "application/json"
    explicit_json = False
    body = """
    {
      "foo": "bar"
    }
    """

    assert get_lexer(mime, explicit_json, body) is pygments.lexers.get_lexer_by_name("json")

# Generated at 2022-06-23 19:23:49.290048
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Test Setup
    import pdb
    cf = ColorFormatter(env=Environment(colors=256),)
    #cf = ColorFormatter(env=Environment(colors=256),)
    #pdb.set_trace()
    # Test case execution
    output = cf.format_headers('Content-Type: application/json\nCache-control: no-cache\n')
    # Test assertions
    assert output == '\x1b[38;5;45mContent-Type\x1b[0m: \x1b[38;5;63mapplication/json\x1b[0m\n\x1b[38;5;45mCache-control\x1b[0m: \x1b[38;5;63mno-cache\x1b[0m\n'

# Generated at 2022-06-23 19:23:50.672668
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style().styles[pygments.token.Token.Other] == '#afd700'

# Generated at 2022-06-23 19:23:52.617683
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'

# Generated at 2022-06-23 19:24:03.015668
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(
        env = Environment(colors=256, output_options={'colors' : 'true','style': 'auto'}),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    assert type(formatter.get_lexer_for_body('text/html', '<html></html>')) == type(pygments.lexers.HtmlLexer())
    assert type(formatter.get_lexer_for_body('text/plain', 'Hi')) == type(pygments.lexers.TextLexer())
    assert type(formatter.get_lexer_for_body('application/json', '{}')) == type(pygments.lexers.JsonLexer())

# Generated at 2022-06-23 19:24:11.826539
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import io
    env = Environment()
    f = ColorFormatter(env)
    headers = '''Content-Length: 0
Content-Type: application/json
Date: Mon, 08 Jul 2019 20:06:59 GMT
server: TornadoServer/6.0.3
X-Content-Type-Options: nosniff
'''

# Generated at 2022-06-23 19:24:16.566576
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.core import main
    from httpie.plugins import builtin
    from os.path import join, dirname
    import tempfile
    import json
    lexer = ColorFormatter(None).get_lexer_for_body('application/json', '{}')
    assert lexer is not None
    assert not isinstance(lexer, TextLexer)

    formatter = ColorFormatter(None)
    body_plain = formatter.format_body('abc', 'text/html')
    assert body_plain == 'abc'
    body_highlight = formatter.format_body(json.dumps({}), 'application/json')
    filename = join(dirname(__file__), 'data', 'body_highlight.txt')
    with open(filename, 'r') as file_obj:
        expected_body

# Generated at 2022-06-23 19:24:26.510763
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(Environment())

    assert color_formatter.format_body("{}", "application/json") == '{}'
    assert color_formatter.format_body("{}", "text/plain") == '{}'

    assert color_formatter.format_body(r'{"key": "value"}', "application/json") == '\x1b[38;5;10m{\x1b[39;49;00m\n  \x1b[38;5;11m"key"\x1b[39;49;00m: \x1b[38;5;14m"value"\x1b[39;49;00m\n\x1b[38;5;10m}\x1b[39;49;00m'

# Generated at 2022-06-23 19:24:27.398400
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style()

# Generated at 2022-06-23 19:24:30.346527
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment())
    assert formatter.formatter


# Generated at 2022-06-23 19:24:33.283728
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(None)
    result = formatter.get_lexer_for_body('application/json', '{"hello": 1}')
    assert result is pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:24:35.196176
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    print(lexer)



# Generated at 2022-06-23 19:24:45.903936
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env=env)
    style = formatter.formatter.style

    original = '''\
HTTP/1.1 200 OK
Content-Length: 542
Content-Type: text/html; charset=utf-8
Date: Sun, 07 Apr 2019 20:54:00 GMT
Server: Development/2.0.0'''


# Generated at 2022-06-23 19:24:58.320499
# Unit test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-23 19:25:02.671229
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer(
        mime='application/json',
        body='{\n\t"a": 1,\n\t"b": 2\n}\n'
    ) is pygments.lexers.get_lexer_by_name('json')



# Generated at 2022-06-23 19:25:04.969126
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    c = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)

# Generated at 2022-06-23 19:25:12.015732
# Unit test for function get_lexer
def test_get_lexer():
    # type: () -> None
    """Unit test for function get_lexer"""
    assert get_lexer('application/json')
    assert not get_lexer('application/json-patch+json')
    assert get_lexer('application/json-patch+json; charset=UTF-8')
    assert get_lexer('text/plain')
    assert get_lexer('text/xml; charset=UTF-8', True, '<xml>')

# Generated at 2022-06-23 19:25:18.617053
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html')
    assert get_lexer('text/x-html')
    assert get_lexer('application/json')
    assert get_lexer('application/x-json')
    assert get_lexer('application/vnd.api+json')
    assert get_lexer('application/vnd.api-v1+json')
    assert get_lexer('application/vnd.api_v1+json')
    assert get_lexer('application/x-javascript')
    assert get_lexer('application/javascript')
    assert get_lexer('text/javascript')
    assert get_lexer('text/plain')

# Generated at 2022-06-23 19:25:22.096847
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexers import get_lexer_by_name
    for name in SimplifiedHTTPLexer.aliases:
        assert SimplifiedHTTPLexer() == get_lexer_by_name(name)

# Generated at 2022-06-23 19:25:25.293656
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    ColorFormatter(env=Environment(colors=1), color_scheme=DEFAULT_STYLE).format_headers(headers=b'''POST / HTTP/1.1
Host: www.example.com
Content-Type: application/json
Content-Length: 18
Connection: keep-alive
Accept: */*
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate
Accept-Language: en

'''.decode('utf-8'))

# Generated at 2022-06-23 19:25:36.129229
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.formatter import ColorFormatter

    httpie_formatter = ColorFormatter(None, True, None)
    # Test case with mimetype application/json
    assert httpie_formatter.get_lexer_for_body('application/json', '{ "hello": "world" }') == pygments.lexers.get_lexer_by_name('json')
    # Test case with mimetype text/json without data
    assert httpie_formatter.get_lexer_for_body('text/json', '') is None
    # Test case with mimetype text/json with data
    assert httpie_formatter.get_lexer_for_body('text/json', '{ "hello": "world" }') == pygments.lexers.get_lexer_by_name('json')
    # Test

# Generated at 2022-06-23 19:25:46.898815
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()

# Generated at 2022-06-23 19:25:58.395943
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexer import RegexLexer
    from pygments.token import Token
    from pygments.util import ClassNotFound

    try:
        lexer = pygments.lexers.get_lexer_by_name('http')
    except ClassNotFound:
        pass

    assert issubclass(SimplifiedHTTPLexer, RegexLexer)
    assert isinstance(SimplifiedHTTPLexer.tokens, dict)

    for k, v in SimplifiedHTTPLexer.tokens.items():
        assert isinstance(k, Token)
        assert isinstance(v, list)
        assert len(v) > 0
        for item in v:
            assert len(item) == 6  # (regex, *groups)
            assert isinstance(item[0], str)
           

# Generated at 2022-06-23 19:26:09.548746
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-23 19:26:18.740810
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexer import include

    lexer = SimplifiedHTTPLexer()
    lexer.add_filter("Whitespace", require=[Token.Name.Attribute])

    tokens = list(lexer.get_tokens("GET /path HTTP/1.1\nHost: example.com\n"))

# Generated at 2022-06-23 19:26:20.597812
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()
    assert isinstance(s, pygments.style.Style)

# Generated at 2022-06-23 19:26:21.349858
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style()

# Generated at 2022-06-23 19:26:31.264577
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    """ ColorFormatter.get_lexer_for_body() """
    colorFormatter = ColorFormatter(Environment())
    # default
    assert isinstance(colorFormatter.get_lexer_for_body('application/json'), pygments.lexers.JsonLexer)
    assert isinstance(colorFormatter.get_lexer_for_body('image/png'), pygments.lexers.ImageLexer)
    assert colorFormatter.get_lexer_for_body('application/foo') is None
    assert colorFormatter.get_lexer_for_body('application/octet-stream') is None
    assert colorFormatter.get_lexer_for_body('text/plain') is None
    # explicit json option

# Generated at 2022-06-23 19:26:37.433940
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256, stdout_isatty=True)
    color_formatter = ColorFormatter(env, compact=False, pretty=False)
    headers = '''Content-Type: text/html; charset=UTF-8
Location: http://www.baidu.com/
Content-Length: 145
Date: Sun, 01 Dec 2019 13:14:57 GMT
Hp-Header: Hp-Iamge
'''

# Generated at 2022-06-23 19:26:46.908764
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    import unittest

    class TestSolarized256Style(unittest.TestCase):
        def test_Solarized256Style(self):
            style = Solarized256Style()
            self.assertEqual(style.styles.get(pygments.token.Keyword),
                             Solarized256Style.GREEN)
            self.assertEqual(style.styles.get(pygments.token.Keyword.Constant),
                             Solarized256Style.ORANGE)
            self.assertEqual(style.styles.get(pygments.token.Keyword.Declaration),
                             Solarized256Style.BLUE)
            self.assertEqual(style.styles.get(pygments.token.Keyword.Namespace),
                             Solarized256Style.ORANGE)

# Generated at 2022-06-23 19:26:47.806201
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:26:58.509607
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    """
    Test that the ColorFormatter.format_headers() method returns the same
    result as what a third party like https://mholt.github.io/curl-to-python/
    returns:
    """
    # Given
    env = Environment(colors=False)
    formatter = ColorFormatter(env, color_scheme='solarized')
    # When

# Generated at 2022-06-23 19:27:04.438348
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.output.streams import UnsupportedOperation

    class ColorFormatter_format_body(ColorFormatter):

        def get_lexer_for_body(self, mime : str, body : str) -> Optional[Type[Lexer]]:
            return pygments.lexers.get_lexer_by_name('bash')

    env = Environment(colors=True, stdout_isatty=True)
    formatter = ColorFormatter_format_body(env, stream=None)
    assert formatter.format_body(body='date', mime='text/plain') == 'date'

    try:
        formatter.format_body(body='echo you too', mime='text/plain')
    except UnsupportedOperation:
        pass
    else:
        raise Exception("Exception expected")

# Generated at 2022-06-23 19:27:06.036792
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter()
    assert formatter.enabled

# Generated at 2022-06-23 19:27:15.321442
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Test for request_prefix
    prefix_test_cases = [
        ("GET /demo.jpg HTTP/1.1", "GET",  "/demo.jpg", "HTTP", "1.1"),
        ("POST /demo.jpg HTTP/2.0", "POST",  "/demo.jpg", "HTTP", "2.0"),
        ("DELETE /demo.html HTTP/3.0", "DELETE",  "/demo.html", "HTTP", "3.0"),
        ("PUT /demo.html HTTP/3.0", "PUT",  "/demo.html", "HTTP", "3.0"),
    ]

    # Test for header

# Generated at 2022-06-23 19:27:23.907077
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Sample request
    # :method :url :http-version
    # :header
    #
    # :body

    # Will create an instance of ColorFormatter
    from httpie.plugins import builtin
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.output import get_writer
    from null import NullStream

    env = Environment(
        stdin=NullStream(),
        stdout=NullStream(),
        stdout_isatty=False,
        stderr=NullStream(),
        stderr_isatty=False,
        colors=256,
        config=Config(),
        output_options=['colors', 'format', 'stream'],
        plugins=builtin,
    )

    output_file = NullStream()


# Generated at 2022-06-23 19:27:35.325223
# Unit test for function get_lexer
def test_get_lexer():
    def assert_lexer(mime, explicit_json, body, expected):
        actual = get_lexer(mime, explicit_json, body)
        assert actual is not None
        assert actual.name == expected

    assert_lexer('application/json', False, '', 'JSON')
    assert_lexer('application/json', True, '', 'JSON')
    assert_lexer('application/json', False, '{}', 'JSON')
    assert_lexer('application/json', True, '{}', 'JSON')
    assert_lexer('application/vnd.company+json', False, '', 'JSON')
    assert_lexer('application/vnd.company+json', True, '', 'JSON')
    assert_lexer('application/vnd.company+json', False, '{}', 'JSON')


# Generated at 2022-06-23 19:27:40.100866
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie.output.formatters
    # with json body content type
    mime = 'application/json'
    body = '[1,2,3,4,5]'
    color_formatter = httpie.output.formatters.get_formatter('colors')
    assert color_formatter.get_lexer_for_body(mime, body) is not None

# Generated at 2022-06-23 19:27:48.408987
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.colors import ColorFormatter
    from httpie.plugins import plugin_manager
    plugin_manager.load_installed_plugins()

    # list the mock class for the same method
    def test(self, mime: str, body: str)->str:
        return get_lexer(mime=mime, explicit_json=self.explicit_json, body=body)

    # set the mock function to the class
    setattr(ColorFormatter, 'get_lexer_for_body', test)

    # test_case class
    class t():
        def __init__(self, mime: str, body: str):
            self.mime=mime
            self.body=body

    # list the test cases

# Generated at 2022-06-23 19:27:51.293840
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment())
    assert formatter.name == 'colors'

# Generated at 2022-06-23 19:27:52.685668
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(None)
    assert formatter.explicit_json

# Generated at 2022-06-23 19:27:53.627820
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    pass

# Generated at 2022-06-23 19:28:01.108396
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie import ExitStatus
    from httpie.context import Environment
    from httpie.cli import Session
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    class Plugin(FormatterPlugin):
        def format_body(self, body: str, mime: str) -> str:
            pass

        def format_headers(self, headers: str) -> str:
            pass

    class StreamStub:
        def __init__(self):
            self.written_bytes = b''

        def write(self, content: bytes):
            self.written_bytes += content
            return len(content)

    # Use code to construct
    cf = ColorFormatter(None, color_scheme='solarized')

# Generated at 2022-06-23 19:28:07.356165
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE

    color_formatter = ColorFormatter(env, explicit_json, color_scheme)
    assert color_formatter.enabled
    assert color_formatter.explicit_json == False
    assert color_formatter.formatter
    assert color_formatter.http_lexer

# Generated at 2022-06-23 19:28:09.587458
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    """
    >>> ColorFormatter.get_style_class('solarized')
    <class 'httpie.plugins.colors.Solarized256Style'>
    """
    pass

# Generated at 2022-06-23 19:28:11.209420
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(AUTO_STYLE) == Solarized256Style

# Generated at 2022-06-23 19:28:16.212496
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(style=Solarized256Style)

    print(pygments.highlight(
        code='GET / HTTP/1.1\r\nFoo: Bar\r\n\r\n',
        lexer=http_lexer,
        formatter=formatter,
    ).strip())

    print(pygments.highlight(
        code='HTTP/1.1 200 OK\r\nFoo: Bar\r\n\r\n',
        lexer=http_lexer,
        formatter=formatter,
    ).strip())

# Generated at 2022-06-23 19:28:27.706914
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    rtn = get_lexer('text/plain')
    assert isinstance(rtn, TextLexer)
    rtn = get_lexer('text/plain', body='ThIs iS Not jSoN')
    assert isinstance(rtn, TextLexer)
    rtn = get_lexer('text/plain', body='{"This": "is"}')
    assert isinstance(rtn, pygments.lexers.JsonLexer)
    rtn = get_lexer('text/plain', body='This is not json')
    assert isinstance(rtn, pygments.lexers.TextLexer)
    rtn = get_lexer('text/plain', body='This is json', explicit_json=True)
    assert isinstance(rtn, pygments.lexers.JsonLexer)
    rtn = get

# Generated at 2022-06-23 19:28:29.954647
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter()
    assert color_formatter.format_body("test", "text/html") == "test"

# Generated at 2022-06-23 19:28:33.571697
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('abcdef') == pygments.styles.get_style_by_name('abcdef')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-23 19:28:39.491743
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    #ColorFormatter.get_lexer_for_body('a+b')  # TODO
    assert get_lexer('application/json').name == 'JSON'
    assert get_lexer('text/plain').name == 'Text only'
    assert get_lexer('text/html').name == 'HTML'
    assert get_lexer('text/css').name == 'CSS'
    assert get_lexer('text/xml').name == 'XML'
    assert get_lexer('application/xml').name == 'XML'
    assert get_lexer('application/x-yaml').name == 'YAML'
    assert get_lexer('application/yaml').name == 'YAML'
    assert get_lexer('text/yaml').name == 'YAML'

# Generated at 2022-06-23 19:28:44.672322
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    headers = """
    HTTP/1.1 200 OK
    Server: nginx/1.5.9
    Date: Thu, 4 Apr 2019 07:49:29 GMT
    Content-Type: text/html
    Content-Length: 90
    Connection: close

    """.strip()
    body = '<html>Hello world</html>'
    headers_colored = ColorFormatter.format_headers(headers)
    body_colored = ColorFormatter.format_body(body, "text/html")
    body_colored_colored = ColorFormatter.format_body(body_colored, "text/html")
    assert body != body_colored
    assert body != body_colored_colored
    assert body_colored != body_colored_colored
    assert headers == ColorFormatter.format_headers(headers_colored)

# Generated at 2022-06-23 19:28:55.971668
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    tok = lexer.get_tokens_unprocessed("GET http://example.com HTTP/1.1")
    assert next(tok) == (pygments.token.Name.Function, 'GET')
    assert next(tok) == (pygments.token.Text, ' ')
    assert next(tok)[0] == pygments.token.Name.Namespace
    assert next(tok) == (pygments.token.Text, ' ')
    assert next(tok)[0] == pygments.token.Keyword.Reserved
    assert list(tok) == [(pygments.token.Operator, '/')] + list(lexer.get_tokens_unprocessed("1.1"))

# Generated at 2022-06-23 19:29:05.500927
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class TestEnvironment:
        colors = 256

    class TestColorFormatter(ColorFormatter):
        get_lexer_for_body = ColorFormatter.get_lexer_for_body
    color_formatter = TestColorFormatter(
        env=TestEnvironment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )

    code = 'HTTP/1.1 200 OK\r\n' \
           'Content-Length: 4\r\n' \
           'Content-Type: text/plain; charset=UTF-8\r\n' \
           'Server: gunicorn/19.6.0\r\n' \
           'Connection: close\r\n' \
           '\r\n'

    headers = color_formatter.format_headers(code)

# Generated at 2022-06-23 19:29:14.956780
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-23 19:29:16.250684
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style(None)


# Generated at 2022-06-23 19:29:24.027907
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    import os, sys
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from httpie.output.colors import ColorFormatter
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('nonexist') == None