

# Generated at 2022-06-23 19:19:28.523944
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    """Unit test for constructor of class SimplifiedHTTPLexer"""

# Generated at 2022-06-23 19:19:40.092429
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.output.streams import StdoutBytesIO
    from httpie.plugins import FormatterPlugin

    # Mock an environment object for the ColorFormatter object
    class MockEnv:
        def __init__(self, colors):
            self.colors = colors

    # Mock the Response object
    class MockR:
        def __init__(self, mime, body):
            self.mime = mime
            self.body = body

    # Create the formatter, set the environment and response
    f = ColorFormatter(environment=MockEnv(256))
    f.env.response = MockR('application/json', '{"a": "b"}')
    f.env.stdout = StdoutBytesIO(encoding=None)

    # test a known mime type that should be formatted

# Generated at 2022-06-23 19:19:40.757619
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert True

# Generated at 2022-06-23 19:19:43.229848
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Test for the creation of a ColorFormatter object
    colorF = ColorFormatter(True, False)
    assert(colorF == "ColorFormatter")



# Generated at 2022-06-23 19:19:54.994644
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.input import SEP_CREDENTIALS
    from tests import http

    args = parser.parse_args([
        '--headers', 'foo:bar', 'baz: qux',
        '--auth-type', 'basic',
        '--auth', 'username' + SEP_CREDENTIALS + 'password',
        'GET', 'http://httpbin.org/headers'
    ])
    args.output_options = parser.parse_args([])[0]

    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        should_stream=False,
        colors=256,
        output_options=args.output_options,
    )

    output_file = http

# Generated at 2022-06-23 19:20:02.838452
# Unit test for function get_lexer
def test_get_lexer():
    l = get_lexer('text/html')
    assert l.name == 'HTML'

    l = get_lexer('application/x-web-app-manifest+json')
    assert l.name == 'JSON'
    l = get_lexer('application/json')
    assert l.name == 'JSON'

    l = get_lexer('application/x-web-app-manifest+xml')
    assert l.name == 'XML'

    l = get_lexer('application/vnd.google-earth.kml+xml')
    assert l.name == 'XML'

    l = get_lexer('application/vnd.google-earth.kml+json')
    assert l.name == 'JSON'

    l = get_lexer('application/vnd.google-earth.kmz')


# Generated at 2022-06-23 19:20:13.676865
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class FakeEnvironment:
        def __init__(self):
            self.colors = 256

    sample_headers = """HTTP/1.1 200 OK
Connection: close
Content-Length: 15
Content-Type: text/plain
Date: Sun, 01 Jan 2017 05:56:29 GMT
Server: Python/2.7 aiohttp/0.22.2

"""
    color_formatter = ColorFormatter(env=FakeEnvironment())


# Generated at 2022-06-23 19:20:24.984527
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    """Test ColorFormatter."""
    env = Environment()
    env.color = True
    colorFormatter = ColorFormatter(env)
    assert colorFormatter.group_name == 'colors'
    assert colorFormatter.formatter == TerminalFormatter()
    assert colorFormatter.http_lexer == PygmentsHttpLexer()
    assert colorFormatter.get_style_class('solarized') == Solarized256Style
    assert colorFormatter.get_lexer_for_body('application/json') == pygments.lexers.get_lexer_for_mimetype('application/json')
    assert colorFormatter.get_lexer_for_body('application/json', '{"a":1}') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:20:25.841126
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    # type: (...) -> None
    Solarized256Style()

# Generated at 2022-06-23 19:20:34.057744
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer('text/html'), pygments.lexers.WebLexer)
    assert isinstance(get_lexer('application/json'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/vnd.api+json'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/vnd.api+json', body='{}'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/vnd.api+json', explicit_json=True), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/vnd.api+json', body='garbage'), pygments.lexers.TextLexer)

# Generated at 2022-06-23 19:20:35.091342
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()

# Generated at 2022-06-23 19:20:39.141276
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    cf = ColorFormatter(Environment())
    assert type(cf.get_style_class(SOLARIZED_STYLE)) == type(Solarized256Style)

# Generated at 2022-06-23 19:20:40.850750
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter('explicit_json', '')
    assert formatter

# Generated at 2022-06-23 19:20:42.076690
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert type(Solarized256Style.styles) is dict

# Generated at 2022-06-23 19:20:44.002054
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import pytest
    assert pytest.raises(TypeError, SimplifiedHTTPLexer()) == None

# Generated at 2022-06-23 19:20:54.181444
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer(u'application/json')
    assert lexer == pygments.lexers.get_lexer_by_name('json')
    assert lexer.name == 'JSON'

    lexer = get_lexer(u'application/x-www-form-urlencoded')
    assert lexer is None

    lexer = get_lexer(u'application/xhtml-xml')
    assert lexer.name == 'HTML+XML'

    lexer = get_lexer(u'application/xhtml+xml')
    assert lexer.name == 'HTML+XML'

    lexer = get_lexer(u'application/xhtml+xml', body=b'foo')
    assert lexer is None


# Generated at 2022-06-23 19:21:02.769884
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') is not None
    assert get_lexer('application/json') is not None
    assert get_lexer('text/plain') is not None
    assert get_lexer('text/html') is not None
    assert get_lexer('text/x-python') is not None
    assert get_lexer('text/css') is not None
    assert get_lexer('application/javascript') is not None
    assert get_lexer('text/javascript') is not None
    assert get_lexer('image/svg+xml') is not None
    assert get_lexer('text/vcard') is not None
    assert get_lexer('application/vnd.google-earth.kml+xml') is not None

# Generated at 2022-06-23 19:21:08.453575
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('mime-type', body=json.dumps({"test": "json"}))
    assert lexer is not None
    assert lexer.name == 'JSON'

    lexer = get_lexer('application/json', body=json.dumps({"test": "json"}))
    assert lexer is not None
    assert lexer.name == 'JSON'

    lexer = get_lexer('application/json', body='html')
    assert lexer is None

    class TestJSONLexer(pygments.lexer.RegexLexer):
        name = 'JSON'
        aliases = ['json']
        filenames = ['*.json']

# Generated at 2022-06-23 19:21:11.948071
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    colorFormatter = ColorFormatter(
        env=None,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    assert colorFormatter is not None

# Generated at 2022-06-23 19:21:22.851309
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    color_formatter = ColorFormatter(env=env)
    # Test when the body content is json, and json is treated as default
    body = '''
    {
        "url" : "xxx",
        "method" : "POST",
        "headers" : {
            "Content-Type": "application/json"
        },
        "body" : "xxx"
    }
    '''
    mime = 'text/plain'
    json_lexer = pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body(mime, body) == json_lexer

    # Test when the body content is json, but json is explictly set by --json

# Generated at 2022-06-23 19:21:32.743267
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    #a dummy Environment
    env = Environment()
    env.colors = 16
    #Construct a ColorFormatter
    formatter = ColorFormatter(env)
    assert formatter.http_lexer.name == 'HTTP'
    assert formatter.formatter.get_style_defs()[:10] == '\n.hll {'

    #a dummy Environment
    env.colors = auto
    #Construct a ColorFormatter
    formatter = ColorFormatter(env)
    assert formatter.http_lexer.name == 'simplifiedHTTP'
    assert formatter.formatter.get_style_defs()[:10] == '\n.hll {'

# Generated at 2022-06-23 19:21:34.349207
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import sys

# Generated at 2022-06-23 19:21:39.196003
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
        style=Solarized256Style
    )

    test_header = "Header-Name: Header-Value\n"
    test_header_colors = pygments.highlight(
        code=test_header,
        lexer=http_lexer,
        formatter=formatter,
    )
    assert test_header_colors == "\x1b[38;5;8mHeader-Name\x1b[39m\x1b[38;5;240m:\x1b[39m\x1b[38;5;81mHeader-Value\x1b[39m\x1b[38;5;250m\n\x1b[39m", "http header colors were not as expected"

    test

# Generated at 2022-06-23 19:21:49.620324
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment, EnvironmentConfig
    from pygments.style import Style
    from pygments.formatters.terminal import TerminalFormatter
    from pygments.token import Token, Tokens

    class MockStyle(Style):
        styles = {
            Token.Generic.Error: '#ff0000',
            Token.Generic.Traceback: '#00ff00',
            Token.Generic.Output: '#00ffff'
        }

    style = MockStyle
    formatter = TerminalFormatter(style=style)
    env = Environment(EnvironmentConfig())
    env.colors = True
    color_formatter = ColorFormatter(env)
    color_formatter.formatter = formatter
    color_formatter.http_lexer = MockHTTPLexer

# Generated at 2022-06-23 19:21:51.678471
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()


if __name__ == '__main__':
    test_SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:22:01.279201
# Unit test for function get_lexer
def test_get_lexer():
    from httpie.output.json import CONTENT_TYPE_JSON
    from httpie.output.formats.tabs import CONTENT_TYPES_TABS

    for content_type in CONTENT_TYPES_TABS:
        lexer = get_lexer(content_type)
        assert lexer is None

    lexer = get_lexer(CONTENT_TYPE_JSON, explicit_json=False)
    assert lexer is None

    lexer = get_lexer(CONTENT_TYPE_JSON, explicit_json=True)
    assert lexer.name == 'JSON'

    lexer = get_lexer('foo/bar')
    assert lexer.name == 'Text only'

    lexer = get_lexer('foo/bar', '{"foo": "bar"}')
    assert lexer.name == 'JSON'

# Generated at 2022-06-23 19:22:04.912883
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    solarized256 = ColorFormatter.get_style_class('solarized256')
    assert solarized256 is Solarized256Style

# Generated at 2022-06-23 19:22:05.615553
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:22:07.606906
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    from pygments.styles import get_all_styles
    assert Solarized256Style.__name__ in get_all_styles()

# Generated at 2022-06-23 19:22:14.354065
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    headers = 'Content-Type: application/json'
    expected_output = '\x1b[38;5;65mContent-Type\x1b[39m:\x1b[90m application/json\x1b[39m'
    assert formatter.format_headers(headers) == expected_output

# Generated at 2022-06-23 19:22:23.804298
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class FakeEnv:
        colors = True

    env = FakeEnv()

    colorFormatter = ColorFormatter(
        env,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )

    headers = """HTTP/1.1 200 OK
Date: Sun, 20 Mar 2016 07:20:04 GMT
Server: Apache/2.4.6 (CentOS) OpenSSL/1.0.1e-fips PHP/5.4.16
X-Powered-By: PHP/5.4.16
Content-Length: 22
Connection: close
Content-Type: application/json; charset=UTF-8"""

# Generated at 2022-06-23 19:22:26.218584
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment(), False, DEFAULT_STYLE)
    assert formatter.enabled

# Generated at 2022-06-23 19:22:35.398581
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # The case when there is no lexer returned
    ColorFormatter.get_lexer_for_body('image/jpeg', 'test body') == None

    # The case when HTTP is returned
    ColorFormatter.get_lexer_for_body('text/http', 'test body') == \
    SimplifiedHTTPLexer

    # The case when there is no lexer for the mime type, but the body can
    # be parsed as JSON
    ColorFormatter.get_lexer_for_body(
        'text/plain',
        '{"data": "test body"}'
    ) == pygments.lexers.get_lexer_by_name('json')

    # The case when there is a lexer for the mime

# Generated at 2022-06-23 19:22:47.937675
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    cf = ColorFormatter(Environment(), explicit_json=False)
    lexer = cf.get_lexer_for_body('application/json', '{"id": 1}')
    assert lexer == pygments.lexers.get_lexer_by_name('json')
    lexer = cf.get_lexer_for_body('application/json', '{"id": 1}')
    assert lexer == pygments.lexers.get_lexer_by_name('json')
    lexer = cf.get_lexer_for_body('application/json', '')
    assert lexer == pygments.lexers.get_lexer_by_name('json')
    lexer = cf.get_lexer_for_body('application/json', '{')
    assert lexer is None
    lexer = cf.get_

# Generated at 2022-06-23 19:22:59.255933
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import re
    import pygments.util
    from pygments.lexer import RegexLexer

    class SimplifiedHTTPLexer(RegexLexer):
        name = 'HTTP'
        aliases = ['http']
        filenames = ['*.http']

# Generated at 2022-06-23 19:23:09.736765
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/xml')
    assert get_lexer('application/xml', '<foo></foo')
    assert get_lexer('application/xml', '<foo></foo', body=False)
    assert get_lexer('application/foo', '<foo></foo') is None
    assert get_lexer('application/foo', '<foo></foo', body=False) is None
    assert get_lexer('application/foo+xml', '<foo></foo')

    assert get_lexer('application/json', '{"foo": "bar"}')
    assert get_lexer('application/json', '{"foo": "bar"}', body=False)
    assert get_lexer('application/foo', '{"foo": "bar"}') is None

# Generated at 2022-06-23 19:23:19.606153
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Setup
    f = ColorFormatter()

    # Body is empty
    body = ""
    mime = "text/html"
    f.format_body(body, mime)
    # the function format_body should not cause any side effect
    assert body == ""

    # Body is in the expected mimetype
    body = "<!DOCTYPE html><html><body><h1>My First Heading</h1></body></html>"
    mime = "text/html"
    f.format_body(body, mime)
    # the function format_body should not cause any side effect
    assert body == "<!DOCTYPE html><html><body><h1>My First Heading</h1></body></html>"

    # Body is in the unexpected mimetype

# Generated at 2022-06-23 19:23:24.338281
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = [256]
    formatter = ColorFormatter(env, explicit_json=False)
    assert formatter.explicit_json == False
    assert formatter.formatter == Terminal256Formatter
    assert formatter.http_lexer == SimplifiedHTTPLexer


# Generated at 2022-06-23 19:23:35.426388
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.formatter import get_prettifier
    import httpie.plugins
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPGzip, HTTPOptions
    from httpie.plugins.builtin import HTTPTrace
    from httpie.plugins.builtin import (BasicAuth, Gzip, Trace, Options)
    plugins = [
        HTTPBasicAuth(),
        HTTPGzip(),
        HTTPOptions(),
        HTTPTrace(),
        BasicAuth,
        Gzip,
        Trace,
        Options,
    ]

    env = Environment(plugins=plugins,
                      stdin=None,
                      stdout=None,
                      stderr=None)
    color_formatter = ColorFormatter(env, color_scheme='solarized')

# Generated at 2022-06-23 19:23:46.135817
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:23:55.491231
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie import ExitStatus
    environment = Environment()
    color_formatter = ColorFormatter(
        env=environment,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
        output_file=None,
        sessions=[],
    )
    assert color_formatter.group_name == 'colors'

    assert 'linux' in os.name
    assert color_formatter.enabled is True
    assert color_formatter.explicit_json is False
    assert color_formatter.formatter is not None
    assert color_formatter.http_lexer is not None



# Generated at 2022-06-23 19:23:56.983352
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    assert ColorFormatter.format_headers("foo: bar\n", None) == "foo: bar\n"

# Generated at 2022-06-23 19:24:05.654194
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class TestEnv(Environment):
        def __init__(self, colors=True):
            super().__init__()
            self.colors = colors
    env = TestEnv()
    lexer = SimplifiedHTTPLexer()

    formatter = TerminalFormatter()
    formatter_256 = Terminal256Formatter(style=Solarized256Style)

    headers = """\
GET / HTTP/1.1
Host: dummy.domain
Accept-Encoding: gzip
User-agent: HTTPie
"""

    assert ColorFormatter(env, color_scheme=DEFAULT_STYLE).format_headers(headers) == \
           pygments.highlight(
               code=headers,
               lexer=lexer,
               formatter=formatter,
           ).strip()


# Generated at 2022-06-23 19:24:12.276739
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

    code = 'GET / HTTP/1.1\n'
    assert lexer.get_tokens(code), [(
        (pygments.token.Name.Function, 'GET'),
        (pygments.token.Text, ' '),
        (pygments.token.Name.Namespace, '/'),
        (pygments.token.Text, ' '),
        (pygments.token.Keyword.Reserved, 'HTTP'),
        (pygments.token.Operator, '/'),
        (pygments.token.Number, '1.1'),
    )]


# Generated at 2022-06-23 19:24:17.945647
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.core import main as httpie

    # Test that HTTPie doesn't throw an exception with POST data on
    # standard input.
    httpie("-f", "POST", "http://echo.jefftk.com", "lines=a", "lines=b")

    # Test a basic call to the API.
    httpie("http://echo.jefftk.com", "lines=a", "lines=b")

# Generated at 2022-06-23 19:24:23.736357
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') is None
    assert get_lexer('application/json') is pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('text/x-python') is pygments.lexers.get_lexer_by_name('python')

# Generated at 2022-06-23 19:24:32.953721
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import unicode
    from httpie.plugins import FormatterPlugin
    from httpie.utils import get_content_type

    class MockEnvironment:
        body_color_mapping = None
        colors = True

    class ColorFormatterUnderTest(ColorFormatter):
        """
        A version of ColorFormatter that returns the object of type
        pygments.lexer.Lexer found by get_lexer_for_body instead of
        highlighting the body.

        """
        def get_lexer_for_body(self, mime: str, body: str) -> Optional[Lexer]:
            return get_lexer(mime=mime, body=body)


# Generated at 2022-06-23 19:24:35.542184
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    try:
        from pygments.styles.solarized import Solarized256Style
    except ImportError:
        import unittest

        unittest.TestCase()
        raise

# Generated at 2022-06-23 19:24:38.743473
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins.colors import ColorFormatter

    style_class = ColorFormatter.get_style_class('solarized')
    assert style_class is Solarized256Style

# Generated at 2022-06-23 19:24:48.045771
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.client import Request
    from httpie.plugins.formatter.colors import ColorFormatter
    from httpie import ExitStatus

# Generated at 2022-06-23 19:24:50.427800
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    cf = ColorFormatter(Environment())
    print(cf.format_body("<html></html>","text/html"))

# Generated at 2022-06-23 19:24:58.169490
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from httpie.input import ParseError, KeyValue
    assert SimplifiedHTTPLexer is not None

    line = KeyValue('User-Agent', 'Mozilla/5.0')
    assert line.key == 'User-Agent'
    assert line.value == 'Mozilla/5.0'

    try:
        line = KeyValue('User Agent', 'Mozilla/5.0')
        assert line.key == 'User Agent'
        assert line.value == 'Mozilla/5.0'
    except ParseError:
        assert True

# Generated at 2022-06-23 19:25:05.823709
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import unittest
    from httpie.context import Environment
    from httpie.plugins import BuiltinPluginManager
    from httpie.output.streams import UnstderrStream

    env = Environment()
    pm = BuiltinPluginManager(env=env)
    cf = ColorFormatter(env=env, out_stream=UnstderrStream(env))
    class_ = cf.get_style_class('solarized256')
    # TODO: check result
    cf.format_body(body="", mime="")
    assert True

# Generated at 2022-06-23 19:25:16.273819
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment(colors=True, stdout_isatty=True)
    cf = ColorFormatter(env=env)
    cf.formatter = TerminalFormatter()
    cf.http_lexer = SimplifiedHTTPLexer()


# Generated at 2022-06-23 19:25:19.919625
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(
        colors=256
    )
    formatter = ColorFormatter(env=env).format_headers("")
    assert formatter

# Generated at 2022-06-23 19:25:24.232411
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    if not env.colors:
        assert color_formatter.enabled is False
    else:
        assert color_formatter.enabled is True



# Generated at 2022-06-23 19:25:35.597490
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment = Environment()

    formatter = ColorFormatter(env=environment)
    assert formatter.get_lexer_for_body('application/json', '{"foo": "bar"}') \
           == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json+foo', '["foo", "bar"]') \
           == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/foo', 'foo') is None
    assert formatter.get_lexer_for_body('application/json', 'foo') is None
    assert formatter.get_lexer_for_body('application/foo', '{"foo": "bar"}') \
           == pygments.lex

# Generated at 2022-06-23 19:25:37.026256
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    pass

# Generated at 2022-06-23 19:25:47.357110
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=AUTO_STYLE)

# Generated at 2022-06-23 19:25:55.494832
# Unit test for function get_lexer
def test_get_lexer():
    for mime, lexer_name in [
        ('image/svg+xml', 'xml'),
        ('application/json', 'json'),
        ('application/vnd.github.v3+json', 'json'),
        ('application/javascript', 'javascript'),
        ('application/x-javascript', 'javascript'),
        ('text/plain', 'text'),
        ('text/plain; charset=utf-8', 'text'),
    ]:
        assert get_lexer(mime).name == lexer_name

# Generated at 2022-06-23 19:26:00.815382
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Arrange
    lexer = pygments.lexers.get_lexer_by_name('javascript')
    target = ColorFormatter({'colors': '256', 'style': 'solarized'})
    mime = 'application/json'
    body = '{"type":"json"}'

    # Act
    result = target.get_lexer_for_body(mime, body)

    # Assert
    assert isinstance(result, type(lexer))



# Generated at 2022-06-23 19:26:03.994953
# Unit test for function get_lexer
def test_get_lexer():
    assert not get_lexer('text/plain')
    assert not get_lexer('text/plain', explicit_json=True, body='<html>')
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert isinstance(
        get_lexer('application/json', explicit_json=True, body='<html>'),
        TextLexer
    )



# Generated at 2022-06-23 19:26:04.810702
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:26:12.964759
# Unit test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-23 19:26:18.824716
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert not ColorFormatter(mock.MagicMock()).enabled
    assert ColorFormatter(
        mock.MagicMock(colors=True)
    ).enabled
    assert ColorFormatter(
        mock.MagicMock(colors=256)
    ).enabled
    assert not ColorFormatter(
        mock.MagicMock(colors=True),
        solarized=True
    ).enabled

# Generated at 2022-06-23 19:26:20.498331
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) is not Solarized256Style

# Generated at 2022-06-23 19:26:21.129564
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:26:30.755201
# Unit test for function get_lexer
def test_get_lexer():
    import json
    assert get_lexer(mime='application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(mime='application/json', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')
    assert not get_lexer(mime='text/plain')
    assert not get_lexer(mime='application/json', body='a')
    assert get_lexer(mime='application/json', explicit_json=True, body='a') == pygments.lexers.get_lexer_by_name('json')
    assert json.loads(get_lexer(mime='text/plain', explicit_json=True, body='{}').__doc__) == {}

# Generated at 2022-06-23 19:26:37.112852
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.output.streams import StdoutStream
    from httpie.input import ParseError
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PythonURLEncodedParser
    from httpie.plugins.builtin import HTTPEquivParser
    from httpie.formatter.formatters import Formatter, BaseFormatter
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import HeadersFormatter, BodyFormatter
    from httpie.plugins.builtin import AuthPlugin, AuthCredentials
    from httpie.plugins.builtin import BasicAuthPlugin, DigestAuthPlugin
    import os
    import sys


# Generated at 2022-06-23 19:26:41.993286
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPMETHODS
    from httpie.context import Environment

    f = ColorFormatter(env=Environment(colors=256))
    for method in HTTPMETHODS:
        assert f.format_headers(method.upper() + " / HTTP/1.1\r\n\r\n")

# Generated at 2022-06-23 19:26:42.667057
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:26:49.664554
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Request-Line
    assert (list(SimplifiedHTTPLexer().get_tokens("GET / HTTP/1.1"))[-1][-1] == 
            pygments.lexer.bygroups(
                 pygments.token.Name.Function,
                 pygments.token.Text,
                 pygments.token.Name.Namespace,
                 pygments.token.Text,
                 pygments.token.Keyword.Reserved,
                 pygments.token.Operator,
                 pygments.token.Number
             )
    )
    # Response Status-Line

# Generated at 2022-06-23 19:26:59.717003
# Unit test for function get_lexer
def test_get_lexer():
    def assert_lexer(mime, explicit_json, body, lexer):
        assert get_lexer(mime, explicit_json, body) == lexer

    # Test non-JSON mime types
    assert_lexer('text/plain', False, '', pygments.lexers.get_lexer_by_name('text'))
    assert_lexer('application/json', False, '', pygments.lexers.get_lexer_by_name('json'))
    assert_lexer('application/javascript', False, '', pygments.lexers.get_lexer_by_name('javascript'))
    assert_lexer('application/x-javascript', False, '', pygments.lexers.get_lexer_by_name('javascript'))

    # Test JSON mime type

# Generated at 2022-06-23 19:27:00.336261
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style.styles

# Generated at 2022-06-23 19:27:09.506505
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.core import main
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager

    if is_windows:
        args_list = [
            ['--style', 'default'],
            ['--style', 'fruity'],
        ]
    else:
        args_list = [
            None,
            ['--style', 'default'],
            ['--style', 'fruity'],
            ['--style', 'solarized'],
        ]

    plugin_manager.load_installed_plugins()

    for args in args_list:
        if args:
            main(args)
        else:
            main([])

# Generated at 2022-06-23 19:27:11.010985
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer is not None

# Check type of token

# Generated at 2022-06-23 19:27:16.560940
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.utils import JSON_TYPES
    from httpie.output.convert import MIME_TEXT_PLAIN
    le = ColorFormatter.get_lexer_for_body(JSON_TYPES[0], '')
    assert le == pygments.lexers.get_lexer_by_name('json')
    le = ColorFormatter.get_lexer_for_body(MIME_TEXT_PLAIN, '')
    assert le == None

# Generated at 2022-06-23 19:27:26.772549
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter(): 
    from httpie.context import Environment
    formatter = ColorFormatter(Environment(colors=256))
    assert formatter is not None
    formatter = ColorFormatter(Environment(colors=256), color_scheme=SOLARIZED_STYLE)
    assert formatter is not None
    formatter = ColorFormatter(Environment(colors=256), color_scheme='abc')
    assert formatter is not None
    formatter = ColorFormatter(Environment(colors=256), color_scheme='fruity')
    assert formatter is not None
    formatter = ColorFormatter(Environment(colors=256), color_scheme='dark')
    assert formatter is not None
    formatter = ColorFormatter(Environment(colors=256), color_scheme='ibm')
    assert formatter is not None

# Generated at 2022-06-23 19:27:30.861275
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    """Test the constructor of ColorFormatter."""
    env = {
        'colors': True,
    }
    c = ColorFormatter(env, explicit_json=True, color_scheme=DEFAULT_STYLE)
    assert isinstance(c, ColorFormatter)

# Generated at 2022-06-23 19:27:40.780370
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import PluginConfig
    from requests.structures import CaseInsensitiveDict
    import os

    # Create a mock environment
    env = Environment()

    # Create a mock formatter
    cf = ColorFormatter(env, explicit_json=False, color_scheme='fruity')
    cf.output_stream = os.devnull

    # Create a mock auth plugin

# Generated at 2022-06-23 19:27:48.870279
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.cli.argtypes import ColorScheme
    from httpie.plugins import FormatterPlugin
    env = Environment(colors=256)
    formatter = FormatterPlugin(env)
    style_class = formatter.get_style_class('solarized')
    assert style_class is Solarized256Style
    style_class = formatter.get_style_class('solarized256')
    assert style_class is Solarized256Style
    style_class = formatter.get_style_class(AUTO_STYLE)
    assert style_class is Solarized256Style
    env = Environment(colors=8)
    formatter = FormatterPlugin(env)
    style_class = formatter.get_style_class('solarized')
    assert style_class is Solarized256Style
    style_class = form

# Generated at 2022-06-23 19:27:52.508088
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class("monokai")
    assert style_class == pygments.styles.get_style_by_name("monokai")

# Generated at 2022-06-23 19:28:02.686687
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.streams import ColorStream

    def read_file(filename):
        file = open(filename, "r")
        contents = file.read()
        return contents

    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
        style=Solarized256Style
    )
    mime = 'text/html'

    body = str(read_file('./test_files/index.html'))
    expected = 'index.html'
    c = ColorFormatter(Environment(), explicit_json=False, color_scheme=SOLARIZED_STYLE)
    assert c.get_lexer_for_body(mime, body).name == expected

    body = str(read_file('./test_files/page_json.json'))
    expected

# Generated at 2022-06-23 19:28:08.863987
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    st = Solarized256Style()
    assert st.BASE02 == '#262626'
    assert st.RED == '#af0000'
    assert st.blue == '#0087ff'
    assert st.styles[pygments.token.Comment.Special] == '#5faf00'
    assert st.styles[pygments.token.Generic.Subheading] == '#d75f00'
    assert st.styles[pygments.token.Operator] == '#8a8a8a'
    assert st.styles[pygments.token.String.Char] == '#00afaf'

# Generated at 2022-06-23 19:28:15.143362
# Unit test for function get_lexer
def test_get_lexer():
    # Mime based
    assert get_lexer(u'application/json')
    assert get_lexer(u'application/json; charset=UTF-8')

    assert get_lexer(u'application/xml')
    assert get_lexer(u'application/xml; charset=UTF-8')

    # Extension based
    assert get_lexer(u'application/json+hal')
    assert get_lexer(u'application/vnd.collection+json')

    # Special cases
    assert not get_lexer(u'text/plain')
    assert not get_lexer(u'application/javascript')

    assert not get_lexer(u'')
    assert not get_lexer(u'x')
    assert not get_lexer(u'x/y')

# Generated at 2022-06-23 19:28:20.701449
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, DEFAULT_STYLE)
    assert formatter.get_style_class(DEFAULT_STYLE) == Solarized256Style

    env = Environment(colors=256)
    formatter = ColorFormatter(env, DEFAULT_STYLE)
    assert formatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

    env = Environment(colors=256)
    formatter = ColorFormatter(env, DEFAULT_STYLE)
    assert formatter.get_style_class('tango') == pygments.styles.get_style_by_name('tango')

    env = Environment(colors=256)

# Generated at 2022-06-23 19:28:30.215147
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from httpie.plugins import FormatterPlugin
    from httpie.utils import get_content_type

    class MockColorFormatter(FormatterPlugin):
        def __init__(self):
            super().__init__(color_scheme=SOLARIZED_STYLE)
        def format_headers(self, headers: str) -> str:
            pass
        def format_body(self, body: str, mime: str) -> str:
            pass
        def get_lexer_for_body(self, mime: str, body: str):
            return ColorFormatter.get_lexer_for_body(self, mime, body)


# Generated at 2022-06-23 19:28:36.411938
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:28:45.243326
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json', body='{"x": 1}')
    assert get_lexer('application/json', body='ok') is None
    assert get_lexer('application/x-www-form-urlencoded')
    assert get_lexer('application/x-yaml')
    assert get_lexer('image/png')
    assert get_lexer('text/html')
    assert get_lexer('text/plain')
    assert get_lexer('text/plain', explicit_json=True,
                     body='{"x": 1}')
    assert get_lexer('text/plain', explicit_json=True, body='ok') is None
    assert get_lexer('text/x-markdown')
    assert get_lexer('text/x-rst')

# Generated at 2022-06-23 19:28:48.115741
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    instance = Solarized256Style()
    assert isinstance(instance, pygments.style.Style)

# Generated at 2022-06-23 19:28:54.080658
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    c = ColorFormatter(None, False, False)
    assert c.get_lexer_for_body('application/json', '')
    assert not c.get_lexer_for_body('application/json', 'a')
    assert c.get_lexer_for_body('application/x-ldjson', '')
    assert not c.get_lexer_for_body('application/x-ldjson', 'a')

# Generated at 2022-06-23 19:28:57.073929
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    c = ColorFormatter(Environment(), False)
    assert c.format_headers("Header: value []") == 'Header: value []'
    assert c.format_headers("Header: value [\r\n]") == 'Header: value [\r\n]'

# Generated at 2022-06-23 19:29:06.371907
# Unit test for constructor of class Solarized256Style

# Generated at 2022-06-23 19:29:10.552548
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') is not None
    assert get_lexer('application/json',
                     explicit_json=True,
                     body='[1, 2, 3]') is not None
    assert not get_lexer('application/json',
                         explicit_json=True,
                         body='{"json": "Hello World"}')



# Generated at 2022-06-23 19:29:16.712949
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class MockEnvironment:
        colors = True

    class MockFormater:
        def __init__(self):
            self.format_headers_calls = 0

        def format_headers(self, headers):
            self.format_headers_calls += 1
            return headers

    mock_formater = MockFormater()
    environment = MockEnvironment()
    colorFormatter = ColorFormatter(environment)
    colorFormatter.formatter = mock_formater
    colorFormatter.format_headers("headers1")
    colorFormatter.format_headers("headers2")
    assert mock_formater.format_headers_calls == 2

# Generated at 2022-06-23 19:29:19.658713
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()