

# Generated at 2022-06-23 19:19:28.608013
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain').__name__ == 'Text only'
    assert get_lexer('application/javascript').__name__ == 'JavaScript'
    assert get_lexer('application/json').__name__ == 'JSON'
    assert get_lexer('application/json', explicit_json=True).__name__ == 'JSON'
    assert get_lexer('text/plain', explicit_json=True) is None
    assert get_lexer('application/json', explicit_json=True,
                     body='{"foo": "bar"}').__name__ == 'JSON'
    assert get_lexer('text/plain', explicit_json=True,
                     body='{"foo": "bar"}') is None

# Generated at 2022-06-23 19:19:40.241990
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import logging
    import httpie.compat
    import httpie.core
    from httpie.output.streams import MockStdoutStream


    logging.basicConfig(level=logging.DEBUG)

    env = httpie.core.Environment()
    # Set colors
    env.colors = 256
    env.stream = MockStdoutStream()
    explicit_json = False
    color_scheme = 'solarized'
    formatter = ColorFormatter(env=env, explicit_json=explicit_json, color_scheme=color_scheme)

    body = json.dumps({'key': 'value'})
    mime = 'application/json'
    lexer = formatter.format_body(body, mime)
    print(lexer)
    # assert lexer == 'json', 'lexer

# Generated at 2022-06-23 19:19:47.032678
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    color_formatter = ColorFormatter(env=env)
    mime = 'application/json'
    body = '{"message": "not well-formed"}'
    format_body = color_formatter.format_body(mime=mime, body=body)
    assert format_body == '{   \n' \
                          '    "message": "not well-formed"   \n' \
                          '    '

# Generated at 2022-06-23 19:19:56.913420
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie._vendor.mock import Mock
    env = Mock()
    env.colors = True
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.get_lexer_for_body("application/json", '{"key": "value"}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body("application/json", '"key": "value"') == None
    assert color_formatter.get_lexer_for_body("application/json", '"key": "value"') == None
    assert color_formatter.get_lexer_for_body("application/json", '"key": "value"') == None
   

# Generated at 2022-06-23 19:19:58.569328
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("fruity") == pygments.styles.get_style_by_name("fruity")
    assert ColorFormatter.get_style_class("abc") == Solarized256Style

# Generated at 2022-06-23 19:20:11.176469
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from unittest import TestCase
    from httpie.plugins import FormatterPlugin
    
    class Environment:
        pass

    class TestColorFormatter(ColorFormatter):
        group_name = 'colors'

        def __init__(self, env: Environment, explicit_json=False, color_scheme=DEFAULT_STYLE, **kwargs):
            super().__init__(**kwargs)

            self.env = env
            self.explicit_json = explicit_json  # --json
            self.color_scheme = color_scheme

        def format_headers(self, headers: str) -> str:
            pass

        def format_body(self, body: str, mime: str) -> str:
            pass

    # test case 1:
    # Content-Type: application/json
    #
   

# Generated at 2022-06-23 19:20:14.051316
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.input import PygmentsLexer
    assert isinstance(
        get_lexer(mime='application/json', body='{}', explicit_json=True),
        PygmentsLexer
    )

# Generated at 2022-06-23 19:20:20.912554
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie import ExitStatus

    env = Environment(colors=256, stdin_isatty=False,
                      stdout_isatty=True,
                      output_stream=None, error_stream=None,
                      merge_cookies=False, default_options=[],
                      output_options=[], config_dir=None, config_file=None,
                      __main__=None)

    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    origin_body = '{\n    "status": "success",\n    "key": "value"\n}'
    expect_body = '{\n    "status": "success",\n    "key": "value"\n}'
    assert color_formatter.format_body

# Generated at 2022-06-23 19:20:29.908741
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import json
    import os
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme='solarized')

    headers = '''\
HTTP/1.1 200 OK
Date: Tue, 14 Mar 2017 01:29:29 GMT
Content-Type: application/json; charset=utf-8
Server: AmazonEC2
Content-Length: 1024'''
    print(formatter.format_headers(headers))

    body = '''\
{
  "name": "value"
}'''
    print(formatter.format_body(body, 'application/json'))

# Generated at 2022-06-23 19:20:32.018474
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert isinstance(SimplifiedHTTPLexer(), pygments.lexer.RegexLexer)

# Generated at 2022-06-23 19:20:39.817326
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    # Test list of mime types
    assert get_lexer('application/json') is not None
    assert get_lexer('application/yaml') is not None
    assert get_lexer('text/html') is not None

    # Test lexers with fallback
    assert get_lexer('text/x-python') is not None
    assert get_lexer('text/x-php') is not None
    assert get_lexer('application/xml') is not None
    assert get_lexer('application/x-sh') is not None

    # Test when body is empty
    assert get_lexer('text/plain', '') is None

    # Test when body is not empty
    assert get_lexer('text/plain', 'foo') is not None

    # Test when body content is json

# Generated at 2022-06-23 19:20:51.057326
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import Stream
    env = Environment(stdin=Stream(), stdout=Stream(), stderr=Stream())
    formatted_headers = ColorFormatter(env).format_headers("""\
HTTP/1.1 302 Found
Content-Type: text/html; charset=utf-8
Server: gunicorn/19.6.0
Date: Thu, 25 Jul 2019 17:53:27 GMT
Connection: close
Vary: Cookie
Allow: GET, HEAD, OPTIONS
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
Content-Length: 0
Location: https://httpbin.org/get""")


# Generated at 2022-06-23 19:21:00.206747
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment()
    env.colors = True

    colorFormatter = ColorFormatter(env)

    assert colorFormatter.get_lexer_for_body('text/plain', '') is None
    assert colorFormatter.get_lexer_for_body('text/html', '<title>HTML</title>') is None
    assert colorFormatter.get_lexer_for_body('application/json', '{}') is None
    assert colorFormatter.get_lexer_for_body('application/x-www-form-urlencoded', 'foo') is None

    assert colorFormatter.get_lexer_for_body('json', '{}')
    assert colorFormatter.get_lexer_for_body('json', '<title>JSON</title>')

    assert colorFormatter.get_lexer

# Generated at 2022-06-23 19:21:03.822385
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('application/json')
    assert lexer.name == 'JSON'



# Generated at 2022-06-23 19:21:11.683745
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Test get_lexer_for_body with mime 'text/plain'
    assert get_lexer(mime='text/plain') == pygments.lexers.TextLexer

    # Test get_lexer_for_body with mime 'text/plain' and explicit_json
    assert get_lexer(mime='text/plain', explicit_json=True) == pygments.lexers.TextLexer

    # Test get_lexer_for_body with mime 'text/plain' and explicit_json and body
    assert get_lexer(mime='text/plain', explicit_json=True, body='') == pygments.lexers.TextLexer

    # Test get_lexer_for_body with mime 'text/plain' and explicit_json and invalid json body

# Generated at 2022-06-23 19:21:19.644239
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-23 19:21:24.520705
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPMethodColors
    from httpie.context import Environment
    from httpie.color import ColorControl
    from httpie.output.streams import get_stream
    from httpie.compat import is_windows
    color_control = ColorControl(always=True, never=False, force_terminal=True)
    env = Environment(stdout=get_stream('stdout'),
                      stderr=get_stream('stderr'),
                      stdin=get_stream('stdin'),
                      is_windows=is_windows)
    plugins = [
        ColorFormatter(env, color_scheme=DEFAULT_STYLE),
        HTTPMethodColors()
    ]
    formatter = env.get_formatter('colors')
    assert formatter.format_

# Generated at 2022-06-23 19:21:34.781414
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.context import Environment

# Generated at 2022-06-23 19:21:35.881495
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    ColorFormatter()

# Generated at 2022-06-23 19:21:41.033544
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # the function should find the lexer for "application/json"
    c = ColorFormatter(Environment())
    mime = "application/json"
    assert c.get_lexer_for_body(mime, '') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:21:50.713698
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 16
    formatter = ColorFormatter(env)

# Generated at 2022-06-23 19:21:52.414215
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    from pygments.styles import get_style_by_name
    get_style_by_name('solarized256')

# Generated at 2022-06-23 19:22:01.896137
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    env.colors = 256
    cf = ColorFormatter(env, color_scheme='solarized', explicit_json=False)

# Generated at 2022-06-23 19:22:07.837563
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment(colors=256, stdout_isatty=True)
    formatter = ColorFormatter(env)
    body = "{\n  \"key\": \"value\"\n}\n"
    mime = "application/json"
    body_ = formatter.format_body(body, mime)

# Generated at 2022-06-23 19:22:08.684065
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:22:10.225535
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style
    assert isinstance(s, pygments.style.Style)

# Generated at 2022-06-23 19:22:11.360138
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    ColorFormatter(Environment({}))

# Generated at 2022-06-23 19:22:12.404307
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:22:22.719439
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """
    Test if the processing of format_body works well.
    """
    from httpie.compat import is_windows
    env = Environment(colors=256)
    formatter = ColorFormatter(env, explicit_json=False,
                              color_scheme=DEFAULT_STYLE)

    # Processing with known MIME type
    body = r"""[
    {
        "a":1,
        "b":2
    }
]"""
    parsed_body = formatter.format_body(body=body, mime='application/json')

    if is_windows:
        # Use '\r\n' in Windows environments
        parsed_body = parsed_body.replace('\n', '\r\n')

    print(parsed_body)  # Print the result just in case
    assert parsed_

# Generated at 2022-06-23 19:22:32.875825
# Unit test for function get_lexer

# Generated at 2022-06-23 19:22:39.558439
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-23 19:22:48.854484
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    # List of (mime_type, is_json, expected_lexer)
    test_set = [
        ('application/json', False, pygments.lexers.get_lexer_by_name('json')),
        ('application/json', True, pygments.lexers.get_lexer_by_name('json')),
        ('application/json', False, pygments.lexers.get_lexer_by_name('json')),
    ]

    for mime, is_json, expected_lexer in test_set:
        lexer = ColorFormatter.get_lexer_for_body(mime, json if is_json else 'text')
        assert lexer == expected_lexer

# Generated at 2022-06-23 19:23:00.077612
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('application/json')
    assert lexer == pygments.lexers.get_lexer_by_name('JSON')

    lexer = get_lexer(mime='application/json; charset=utf-8')
    assert lexer == pygments.lexers.get_lexer_by_name('JSON')

    lexer = get_lexer(mime='text/html')
    assert lexer == pygments.lexers.get_lexer_by_name('HTML')

    lexer = get_lexer(mime='text/html; charset=utf-8')
    assert lexer == pygments.lexers.get_lexer_by_name('HTML')

    lexer = get_lexer(mime='text/xml')

# Generated at 2022-06-23 19:23:05.511408
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(
        mime = 'application/json',
        explicit_json = True,
        body = '{"foo":"bar"}'
    ) == pygments.lexers.get_lexer_by_name('json')

    assert get_lexer(
        mime = 'text/plain',
        explicit_json = False,
        body = '{"foo":"bar"}'
    ) == None

# Generated at 2022-06-23 19:23:16.511340
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from httpie.compat import bytes

    lexer = pygments.lexers.get_lexer_by_name('http')

    http_request = bytes('GET / HTTP/1.1\nHost: localhost\nConnection: close\n', 'utf-8')
    http_response = bytes('HTTP/1.1 200 OK\nContent-Type: text/plain\nConnection: close\n\nHello World\n', 'utf-8')

    assert pygments.highlight(code=http_request, lexer=lexer, formatter=Terminal256Formatter(), outfile=None) == \
           pygments.highlight(code=http_request, lexer=SimplifiedHTTPLexer(), formatter=Terminal256Formatter(), outfile=None)

# Generated at 2022-06-23 19:23:24.555812
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class _TestEnvironment(object):
        colors = True

    # Happy path
    formatter = ColorFormatter(
        env=_TestEnvironment(),
        color_scheme=DEFAULT_STYLE,
        is_terminal=True,
        stream=None,
    )
    headers = 'HTTP/1.1 200 OK\n' \
              'Content-Type: application/json\n' \
              'connection: keep-alive\n' \
              'Transfer-Encoding: chunked\n' \
              'Server: nginx\n' \
              'Vary: Accept-Encoding\n' \
              'Content-Encoding: gzip\n'

    headers_formatted = formatter.format_headers(headers)


# Generated at 2022-06-23 19:23:35.563052
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie import ExitStatus
    from httpie.compat import isatty
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.cli import parser
    from httpie.plugins import FormatterPluginDispatcher
    from httpie.context import Environment
    from httpie.plugins import builtin_plugins

    args = parser.parse_args(args=[])
    args.output_options = ['link_errors']

    env = Environment(args, isatty=isatty(2))
    env.colors = True
    env.stdout = BINARY_SUPPRESSED_NOTICE.encode('utf8')

    # Instantiate the formatter with the environment,
    formatter = ColorFormatter(env=env, error_status=ExitStatus.ERROR)

# Generated at 2022-06-23 19:23:46.171883
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # TODO: later
    print("Test start.")
    from httpie.core import BaseEnvironment, main
    env = BaseEnvironment()
    headers_text = '''GET / HTTP/1.1\r'''
    print(headers_text)
    color_formatter = ColorFormatter(env=env,
                                     explicit_json=False,
                                     color_scheme='solarized')
    print(color_formatter.format_headers(headers_text))
    test_text = '''{
        "x": "y"
    }'''
    color_formatter = ColorFormatter(env=env,
                                     explicit_json=False,
                                     color_scheme='solarized')
    print(color_formatter.format_body(test_text, ''))

# Generated at 2022-06-23 19:23:57.111722
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import unittest
    import sys

    class TestColorFormatter(unittest.TestCase):
        def test_format_headers(self):
            from httpie.plugins import FormatterPlugin
            from httpie.context import Environment
            from httpie.plugins.builtin import HTTPHeadersProcessor
            from httpie.plugins.builtin import PrettyOptions
            from httpie.plugins.colors import ColorFormatter
            from httpie.plugins.colors import get_lexer

            env = Environment()

# Generated at 2022-06-23 19:24:04.153745
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json-home')
    assert get_lexer('application/ld+json')
    assert get_lexer('application/x-web-app-manifest+json')
    assert get_lexer('application/x-javascript')
    assert get_lexer('text/plain')
    assert get_lexer('application/octet-stream')
    assert get_lexer('application/x-yaml')
    assert get_lexer('text/x-python-script')
    assert get_lexer('text/x-python-script')

# Generated at 2022-06-23 19:24:10.197721
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from pygments.styles.default import DefaultStyle
    from pygments.styles.borland import BorlandStyle
    from pygments.styles.colorful import ColorfulStyle
    from pygments.styles.autumn import AutumnStyle
    from pygments.styles.fruity import FruityStyle
    from pygments.styles.manni import ManniStyle
    from pygments.styles.native import NativeStyle
    from pygments.styles.perldoc import PerlDocStyle
    from pygments.styles.tango import TangoStyle
    from pygments.styles.trac import TracStyle
    from pygments.styles.vim import VimStyle
    assert (ColorFormatter.get_style_class('default') == DefaultStyle)
    assert (ColorFormatter.get_style_class('borland') == BorlandStyle)

# Generated at 2022-06-23 19:24:19.970101
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.output.streams import UnicodeStreamWriter
    env = Environment(colors=256, stdin=None, stdout=UnicodeStreamWriter(), stderr=UnicodeStreamWriter())
    cf = ColorFormatter(env)
    output = cf.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n')


# Generated at 2022-06-23 19:24:23.633595
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.cli.argtypes import Style
    style = Style(SOLARIZED_STYLE)
    style_class = ColorFormatter.get_style_class(style)
    assert style_class == Solarized256Style

# Generated at 2022-06-23 19:24:32.877371
# Unit test for function get_lexer

# Generated at 2022-06-23 19:24:38.797826
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = pygments.lexers.get_lexer_by_name('http')
    tokens = lexer.get_tokens(
        'GET / HTTP/1.1\r\nHost: example.com\r\nAccept: */*'
    )
    token = next(tokens)
    assert token[1] == 'GET '

# Generated at 2022-06-23 19:24:41.366722
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment())
    assert formatter.explicit_json is False
    assert formatter.color_scheme == DEFAULT_STYLE

# Generated at 2022-06-23 19:24:43.889425
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    c = ColorFormatter(None, None, None)
    assert c.formatter
    assert c.http_lexer
    assert not c.explicit_json

# Generated at 2022-06-23 19:24:51.378011
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain')
    assert get_lexer('text/plain') == get_lexer('text/plain', body='n/a')
    assert get_lexer('text/plain', explicit_json=True) == get_lexer(
        'text/plain', explicit_json=True, body='n/a')
    assert get_lexer('text/html')
    assert get_lexer('text/html') == get_lexer('text/html', body='n/a')
    assert get_lexer('text/html', explicit_json=True) == get_lexer(
        'text/html', explicit_json=True, body='n/a')
    assert get_lexer('application/json') is not None

# Generated at 2022-06-23 19:25:01.008415
# Unit test for function get_lexer
def test_get_lexer():
    from httpie.plugins import FormatterPlugin

    class FakeEnvironment(Environment):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

            # Disable colors for all ColorFormatter tests.
            self.colors = 0

    # We're not interested in HTTP-specific lexers.
    FakeEnvironment.colors = 0


# Generated at 2022-06-23 19:25:12.501994
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.client import utils

    # test for HTML
    lexer = ColorFormatter(Environment(), False, None, None).get_lexer_for_body(
        mime=utils.guess_response_mimetype(None, b'<!DOCTYPE html>'),
        body=b'<!DOCTYPE html>'
    )
    assert lexer.aliases == ['html']
    assert lexer.name == 'HTML'

    # test for JSON
    lexer = ColorFormatter(Environment(), False, None, None).get_lexer_for_body(
        mime=utils.guess_response_mimetype(None, b'{}'),
        body=b'{}'
    )
    assert lexer.aliases == ['json']
    assert lexer.name

# Generated at 2022-06-23 19:25:16.919017
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.core import main as httpie_main
    from httpie.core import parser as httpie_parser
    from httpie.core.program import Program

    from httpie.input import ParseError
    from httpie.streams import get_response_data_stream
    from httpie.output.options import get_output_options
    from httpie.output.streams import get_output_stream
    from httpie.output.formatter import get_formatter

    from httpie.plugins import FormatterPlugin

    program = Program()
    args = httpie_parser.parse_args(['-c', 'solarized256'])
    env = program.parse_env(args)


# Generated at 2022-06-23 19:25:26.928094
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import os
    import re
    import linecache
    import traceback
    import sys
    import io
    import httpie
    import httpie.core
    import httpie.cli
    import httpie.input
    import httpie.output
    import requests.exceptions
    import argparse
    import json
    import pygments
    import pygments.lexer
    import pygments.lexers
    import pygments.style
    import pygments.styles
    import pygments.token
    from pygments.formatters.terminal import TerminalFormatter
    from pygments.formatters.terminal256 import Terminal256Formatter
    from pygments.lexer import Lexer
    from pygments.lexers.special import TextLexer
    from pygments.lexers.text import HttpLexer as PygmentsHttpLexer

# Generated at 2022-06-23 19:25:28.735477
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert style.styles[pygments.token.Name.Builtin] == style.BLUE

# Generated at 2022-06-23 19:25:29.628132
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()

# Generated at 2022-06-23 19:25:38.651811
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import os
    import sys
    sys.path.append(os.path.dirname('__file__'))

    from httpie import cli
    args = cli.parser.parse_args(args=[
        '--json',
        '--print', 'B',
        '--pretty', 'colors'
    ])
    env = cli.get_environment(args)

    cf = ColorFormatter(env, explicit_json=args.json)

    assert not cf.get_lexer_for_body('text/html', '<!DOCTYPE html>')
    assert not cf.get_lexer_for_body('text/html', '<html><head></head><body></body></html>')

# Generated at 2022-06-23 19:25:48.477626
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    formatter = ColorFormatter(env)
    assert formatter.format_body('<p>hello world</p>', 'application/html') == '<p>hello world</p>'
    assert formatter.format_body('<p>hello world</p>', 'text/html') == '<p>hello world</p>'
    assert formatter.format_body('{"msg": "hello world"}', 'application/xml') == '{"msg": "hello world"}'
    assert formatter.format_body('{"msg": "hello world"}', 'text/xml') == '{"msg": "hello world"}'
    assert formatter.format_body('{"msg": "hello world"}', 'application/json') == '{\n    "msg": "hello world"\n}'

test_ColorFormatter_

# Generated at 2022-06-23 19:25:59.662038
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert (SimplifiedHTTPLexer.name == 'HTTP')
    assert (SimplifiedHTTPLexer.aliases == ['http'])
    assert (SimplifiedHTTPLexer.filenames == ['*.http'])

# Generated at 2022-06-23 19:26:10.514504
# Unit test for function get_lexer
def test_get_lexer():
    from httpie.plugins.json import JSONFormatter, is_json
    from httpie.plugins.pretty import PrettyFormatter
    from httpie.plugins.raw import RawFormatter

    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='{"a": 1}') == pygments.lexers.get_lexer_by_name('json')
    assert not get_lexer('application/json', explicit_json=True, body='{"a": 1')

# Generated at 2022-06-23 19:26:15.162925
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    text = """
GET /foo HTTP/1.1
Host: example.com
Content-Length: 27

testing httpie
"""
    lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter()
    print(pygments.highlight(code=text, lexer=lexer, formatter=formatter))

# Generated at 2022-06-23 19:26:16.275086
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style({})


# Generated at 2022-06-23 19:26:26.776850
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    """Unit test for method get_lexer_for_body of class ColorFormatter
    """
    from httpie.compat import is_windows
    import sys
    import pytest
    
    env = Environment(colors=256)
    if is_windows:
        color_scheme = 'fruity'
    else:
        color_scheme = 'solarized'
    
    # Test for invalid parameters
    # pytest.raises(TypeError, ColorFormatter(None, None))
    # pytest.raises(TypeError, ColorFormatter(env, color_scheme, None, None))

    # Test for valid parameters
    sut = ColorFormatter(env, color_scheme)

# Generated at 2022-06-23 19:26:34.698293
# Unit test for function get_lexer
def test_get_lexer():
    # The lexer for Content-Type: text/html should be
    # the same regardless of the body content.
    html = '<html><body><h1>Hi!</h1></body></html>'
    assert get_lexer(mime='text/html', body=html) is not None

    # The lexer for Content-Type: text/html with the body
    # of, say, JSON, should be a text lexer.
    json_txt = '{"foo": "bar"}'
    assert isinstance(
        get_lexer(mime='text/html', body=json_txt),
        TextLexer
    )

    # The lexer for an unrecognized Content-Type should
    # always be a text lexer.

# Generated at 2022-06-23 19:26:44.598484
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    color_scheme = 'auto'
    formatter = TerminalFormatter()
    http_lexer = PygmentsHttpLexer()

    headers = """\
POST /post HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, compress
Content-Length: 72
Content-Type: application/x-www-form-urlencoded
Host: httpbin.org
User-Agent: HTTPie/0.9.2

foo=bar&baz=baz&c%3A%3D=c%3D&dashing=-foo-bar-baz&key space=value"""

    print(pygments.highlight(
        code=headers,
        lexer=http_lexer,
        formatter=formatter,
    ).strip())

# Generated at 2022-06-23 19:26:52.346926
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
        style=Solarized256Style
    )

    explicit_json=False
    color_scheme=SOLARIZED_STYLE

    assert explicit_json == False
    assert color_scheme == 'solarized'
    assert Solarized256Style == Solarized256Style
    assert http_lexer == http_lexer
    assert formatter == formatter

# Generated at 2022-06-23 19:26:53.556671
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:27:02.751959
# Unit test for function get_lexer
def test_get_lexer():
    # 1. No mime type specified
    assert get_lexer(mime=None, body='') is None

    # 2. Text mime type specified
    assert get_lexer(mime='text/plain', body='') is TextLexer
    assert get_lexer(mime='text/plain', body='foo') is TextLexer

    # 3. Mime type with subtype
    assert get_lexer(mime='text/x-foo', body='') is TextLexer
    assert get_lexer(mime='text/markdown', body='') is TextLexer

    # 4. Mime type with suffix
    assert get_lexer(mime='application/json', body='{"foo": "bar"}') is None

# Generated at 2022-06-23 19:27:04.627387
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
        formatter = ColorFormatter("", None)
        assert formatter.get_style_class("solarized") == Solarized256Style

# Generated at 2022-06-23 19:27:05.272379
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:27:14.788417
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.plugins
    import httpie.input
    import httpie.cli
    import httpie.context
    import httpie.compat

    # Build a plugin for testing
    class TestColorFormatter(ColorFormatter):

        def format_body(self, body: str, mime: str) -> str:
            return self.get_lexer_for_body(mime, body)
    httpie.plugins.registry.register(TestColorFormatter)

    # Start the tests

# Generated at 2022-06-23 19:27:19.677178
# Unit test for function get_lexer
def test_get_lexer():
    case = [('application/json', '{}', 'json')]
    for (mime, body, name) in case:
        print(mime)
        print(body)
        print(name)
        print(get_lexer(mime, body=body).__class__.__name__)
        print('*****************')


if __name__ == '__main__':
    test_get_lexer()

# Generated at 2022-06-23 19:27:28.024388
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='application/json')
    assert get_lexer(mime='application/json', body='')
    assert get_lexer(mime='application/json', body='[]')
    assert not get_lexer(mime='application/json', body='{')
    assert not get_lexer(mime='application/json', body='[]', explicit_json=True)
    assert get_lexer(mime='application/json', body='{}', explicit_json=True)
    assert get_lexer(mime='application/json+foo', body='{}')
    assert get_lexer(mime='application/foo+json', body='{}')
    assert not get_lexer(mime='application/json-foobar')

# Generated at 2022-06-23 19:27:31.314188
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    from pygments.styles import get_style_by_name
    style = get_style_by_name('solarized256')


if __name__ == '__main__':
    test_Solarized256Style()

# Generated at 2022-06-23 19:27:35.701102
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

    assert(type(lexer.name) is str)
    assert(type(lexer.filenames) is list)
    assert(type(lexer.aliases) is list)
    assert(type(lexer.tokens) is dict)

# Generated at 2022-06-23 19:27:42.746667
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer
    assert lexer.get_tokens(
        "Content-Type: application/json; charset=utf-8"
    ) == [(
        pygments.Token.Name.Attribute,
        'Content-Type',
    ), (
        pygments.Token.Text,
        '',
    ), (
        pygments.Token.Operator,
        ':',
    ), (
        pygments.Token.Text,
        ' ',
    ), (
        pygments.Token.String,
        'application/json; charset=utf-8',
    )]

# Generated at 2022-06-23 19:27:46.413097
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment.null(), 'fruity')
    assert formatter.formatter.style.__class__.__name__ == 'FruityStyle'
    formatter = ColorFormatter(Environment.null(), 'solarized')
    assert formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

# Generated at 2022-06-23 19:27:57.676835
# Unit test for function get_lexer
def test_get_lexer():
    # Note: The HTTP lexer is not capable of handling the
    # `:status:` pseudo-header.

    # No lexer will pick up the mimetype.
    assert not get_lexer(
        'application/x-foo-bar',
        explicit_json=True,
        body='foo bar'
    )

    # The JSON lexer has been chosen because of the `application/json`
    # mimetype.
    assert isinstance(
        get_lexer('application/json', explicit_json=True, body='{}'),
        pygments.lexers.JsonLexer
    )

    # The JSON lexer has been chosen because of the `application/json`
    # mimetype and because the body contains only JSON.

# Generated at 2022-06-23 19:28:03.857260
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
        style=Solarized256Style
    )


# Generated at 2022-06-23 19:28:11.200700
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-23 19:28:12.923535
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    try:
        Solarized256Style()
    except RuntimeError:
        pass


# Generated at 2022-06-23 19:28:17.456414
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') is not None
    assert get_lexer('application/json', explicit_json=True,
                     body='{"foo": "bar"}') is not None
    assert get_lexer('application/json', explicit_json=True,
                     body='{"foo": "bar') is None
    assert get_lexer('messed/up') is not None
    assert get_lexer('text/plain') is not None
    assert get_lexer('unknown/unknown') is None
    print('get_lexer unit test ok')


# Generated at 2022-06-23 19:28:28.252520
# Unit test for constructor of class ColorFormatter

# Generated at 2022-06-23 19:28:39.868410
# Unit test for function get_lexer
def test_get_lexer():
    from httpie.compat import to_unicode
    from httpie.plugins import FormatterPlugin
    import pygments
    formatter = FormatterPlugin(None, None)
    get_lexer = formatter.get_lexer_for_body
    get_lexer.__code__ = pygments.lexers.get_lexer_by_name.__code__
    get_lexer = to_unicode(get_lexer)
    assert get_lexer('application/json') == pygments.lexers.JsonLexer
    assert get_lexer('application/json; charset=UTF-8') == pygments.lexers.JsonLexer
    assert get_lexer('application/javascript') == pygments.lexers.JavascriptLexer
    assert get_lexer('text/javascript') == pygments.lexers

# Generated at 2022-06-23 19:28:47.726893
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexers import guess_lexer
    from pygments.lexers.special import HttpLexer as PygmentsHttpLexer
    lexer = SimplifiedHTTPLexer()
    lexer1 = PygmentsHttpLexer()

# Generated at 2022-06-23 19:28:57.482856
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie.plugins
    import os
    import mimetypes
    import json
    from httpie.core import main
    from httpie import ExitStatus
    from tools import http, HTTP_OK

    def json_obj(**kwargs):
        return json.dumps(kwargs)

    env = Environment()
    args = ['--traceback', '--print=HBhb', '--pretty=colors']
    config = main.parse_args(args, env)
    config.output_options.pretty = True
    plugins = httpie.plugins.load_installed_plugins(config)
    color_formatter = [
        p for p in plugins if isinstance(p, ColorFormatter)][0]
    color_formatter.explicit_json = False
    color_formatter.formatter = TerminalFormatter()
    color

# Generated at 2022-06-23 19:29:04.550254
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import Plugin
    from httpie.plugins import FormatterPlugin
    class SampleFormatter(FormatterPlugin):
        def format_body(self, body: str, mime: str) -> str:
            return body.title()
    class SamplePlugin(Plugin):
        def __init__(self):
            self.fmt = SampleFormatter()

    env = Environment(plugins=[SamplePlugin()])
    cf = ColorFormatter(env=env)
    assert cf.format_body('hello', 'text/html') == 'Hello'

# Generated at 2022-06-23 19:29:06.036141
# Unit test for function get_lexer
def test_get_lexer():
    assert pygments.lexers.get_lexer_for_mimetype('text/html')

# Generated at 2022-06-23 19:29:09.525909
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    color = ColorFormatter(env)
    mime = 'text/html'
    body = '<html><body><div>test body</div></body></html>'
    assert color.format_body(body, mime) is not None

# Generated at 2022-06-23 19:29:17.170567
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from httpie.utils import get_raw_request_from_file
    from httpie.context import Environment
    from httpie.compat import is_windows

    color_formatter = ColorFormatter(Environment(
        colors=256 if is_windows else True,
        stdout=None
    ))
    formatter = color_formatter.formatter
    http_lexer = color_formatter.http_lexer
    try:
        code = get_raw_request_from_file('./test/fixtures/headers.txt')
        result = pygments.highlight(
            code,
            lexer=http_lexer,
            formatter=formatter
        ).strip()
        assert result
    except Exception as e:
        import traceback
        traceback.print_exc()

# Generated at 2022-06-23 19:29:25.407329
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.config import Config
    from httpie.core import main

    # Test default
    assert ColorFormatter(Config(env=Environment())).get_style_class(DEFAULT_STYLE) == Solarized256Style

    # Test style that is not the default
    assert ColorFormatter(Config(env=Environment())).get_style_class(SOLARIZED_STYLE) == Solarized256Style

    # Test bad style
    try:
        ColorFormatter(Config(env=Environment())).get_style_class("bad_style")
    except ClassNotFound:
        pass
    else:
        assert False