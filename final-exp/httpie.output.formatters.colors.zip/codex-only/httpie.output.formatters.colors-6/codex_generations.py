

# Generated at 2022-06-23 19:19:20.157726
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    pass

# Generated at 2022-06-23 19:19:30.269248
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

    # Request-Line
    tokens = lexer.get_tokens('GET /foo HTTP/1.1\n')
    assert tokens[0][1] == pygments.token.Name.Function
    assert tokens[2][1] == pygments.token.Name.Namespace
    assert tokens[4][1] == pygments.token.Keyword.Reserved
    assert tokens[6][1] == pygments.token.Number

    # Response Status-Line
    tokens = lexer.get_tokens('HTTP/1.1 200 OK\n')
    assert tokens[0][1] == pygments.token.Keyword.Reserved
    assert tokens[2][1] == pygments.token.Number
    assert tokens[4][1] == pygments.token.Number
   

# Generated at 2022-06-23 19:19:39.733622
# Unit test for function get_lexer
def test_get_lexer():
    # Check that the function's name matches the one imported
    # from Pygments.
    assert get_lexer.__name__ == pygments.lexers.get_lexer_for_mimetype.__name__

    lexer = get_lexer('foo/bar')
    assert isinstance(lexer, TextLexer)

    assert get_lexer('application/json') is not None
    assert get_lexer('application/javascript') is not None
    assert get_lexer('application/xml') is not None
    assert get_lexer('text/xml') is not None
    assert get_lexer('text/html') is not None

# Generated at 2022-06-23 19:19:43.399720
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    lexer.get_tokens("""GET / HTTP/1.1
Host: www.example.com
Accept-Encoding: gzip
Accept: text/html,application/xhtml+xml
    """)

# Generated at 2022-06-23 19:19:46.123214
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.core import main
    from httpie.core import parser

    args = parser.parse_args(args=['--color'])
    exit_status = main(args=args)
    assert exit_status == 0

# Generated at 2022-06-23 19:19:58.071351
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie.plugins
    httpie.plugins.load()
    class MockEnvironment(object):
        def __init__(self, colors=None):
            self.colors = colors
            self.style = DEFAULT_STYLE
        def _is_windows(self):
            return is_windows

    env = MockEnvironment()
    c = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert c.get_lexer_for_body('application/json', '') is None
    assert c.get_lexer_for_body('application/json', '[1]') is None
    assert c.get_lexer_for_body('text/plain', '<>') is None
    assert c.get_lexer_for_body('text/plain', '[1]')

# Generated at 2022-06-23 19:20:10.354581
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import unittest
    from io import BytesIO
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.outstream import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.formatter.colors import ColorFormatter
    if is_windows:
        import colorama
        colorama.init()
    def get_env(**kwargs):
        env = Environment()
        env.stdout = BytesIO()
        env.stderr = BytesIO()
        env.colors = 256
        env.is_windows = is_windows
        if isinstance(kwargs, dict):
            env.__dict__.update(kwargs)
        return env


# Generated at 2022-06-23 19:20:21.219344
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.utils import write_headers
    from httpie.compat import URL

    url = URL('http://curl.haxx.se')
    headers = (
        ('Vary', '*'),
        ('Content-Type', 'text/html;charset=UTF-8'),
        ('X-XSS-Protection', '1; mode=block'),
        ('X-Content-Type-Options', 'nosniff'),
        ('Transfer-Encoding', 'chunked'),
        ('Date', 'Tue, 28 Mar 2017 10:27:14 GMT'),
        ('Server', 'nginx'),
        ('Connection', 'keep-alive'),
        (':status', '200')
    )


# Generated at 2022-06-23 19:20:29.295892
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    content_type = 'application/json'
    body = '{"x": "y"}'
    color_formatter = ColorFormatter(None)
    assert color_formatter.enabled
    assert color_formatter.format_body(body, content_type) == '{\n' \
                                                '    \x1b[34m"x"\x1b[39;49;00m: \x1b[33m"y"\x1b[39;49;00m\n' \
                                                '}\n'



# Generated at 2022-06-23 19:20:34.291414
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') is None
    assert get_lexer('application/json') is not None
    assert get_lexer('application/vnd.api+json') is not None

    assert get_lexer('invalid/type') is None
    assert get_lexer('invalid/type-json') is not None

# Generated at 2022-06-23 19:20:44.821111
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer('text/plain'), TextLexer)
    assert isinstance(
        get_lexer('application/json'),
        pygments.lexers.JsonLexer
    )
    assert get_lexer('application/json') is not None
    assert get_lexer('application/octet-stream') is None

    assert isinstance(
        get_lexer('text/plain', explicit_json=True, body='{}'),
        pygments.lexers.JsonLexer
    )
    assert isinstance(
        get_lexer('text/plain', explicit_json=True, body='foo bar'),
        TextLexer
    )

# Generated at 2022-06-23 19:20:49.551905
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    formatter = Terminal256Formatter(
        style=Solarized256Style
    )
    lexer = SimplifiedHTTPLexer()

    print(pygments.highlight(
        code="GET / HTTP/1.1\r\nHost: example.com\r\nHeader: Value\r\n",
        lexer=lexer,
        formatter=formatter,
    ).strip())

# Generated at 2022-06-23 19:20:58.996875
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main
    from httpie.input import SEP_CREDENTIALS
    from httpie.input import SEP_HEADERS
    from httpie.output.streams import get_err_stream

    args = main.parser.parse_args([
        '--verbose',
        '--debug',
        '--headers', 'foo:bar',
        '--auth-type', 'basic',
        '--auth', 'test' + SEP_CREDENTIALS + '123',
        'https://httpbin.org/headers'
    ])
    env = main.Environment(args,
                           stdin=None,
                           stdout=None,
                           stderr=get_err_stream(args),
                           is_windows=False)
    cf = ColorFormatter(env)

   

# Generated at 2022-06-23 19:21:06.111359
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class fake_Environment():
        def __init__(self):
            self.stdout_isatty = True
            self.stderr_isatty = True
            self.colors = 256

    env = fake_Environment()
    color_formatter = ColorFormatter(env)


# Generated at 2022-06-23 19:21:06.729154
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert True

# Generated at 2022-06-23 19:21:09.858943
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert ColorFormatter.format_body(ColorFormatter, "body", "mime") == "body"

# Generated at 2022-06-23 19:21:17.525785
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert pygments.highlight('GET / HTTP/1.0\nHost: example.com', SimplifiedHTTPLexer(), Terminal256Formatter(style=Solarized256Style)).strip() == '\x1b[38;5;208mGET \x1b[38;5;185m/ \x1b[38;5;238mHTTP/1.0\n\x1b[38;5;208mHost\x1b[38;5;185m:\x1b[38;5;185m \x1b[38;5;81mexample.com\x1b[0m'

# Generated at 2022-06-23 19:21:20.138892
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style



# Generated at 2022-06-23 19:21:28.908259
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def assertLexer(mime, body, lexer_name, explicit_json=False):
        lexer = ColorFormatter(None).get_lexer_for_body(mime, body)
        assert lexer.name == lexer_name

    # Default behavior:
    assertLexer('text/html', '', 'html')
    assertLexer('text/plain', '', 'text')
    assertLexer('application/json', '', 'json')
    assertLexer('application/xml', '', 'xml')

    # Explicit --json
    assertLexer('text/plain', '', 'json', explicit_json=True)
    assertLexer('application/json', '', 'json', explicit_json=True)
    assertLexer('application/xml', '', 'json', explicit_json=True)

    # Replies

# Generated at 2022-06-23 19:21:38.309278
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    env = Environment(colors=256)
    formatter = ColorFormatter(env)

    # Test a few common mime types
    assert formatter.get_lexer_for_body('text/html', b'') is not None
    assert formatter.get_lexer_for_body('text/css', b'') is not None
    assert formatter.get_lexer_for_body('application/javascript', b'') is not None
    assert formatter.get_lexer_for_body('application/json', b'') is not None
    assert formatter.get_lexer_for_body('application/json-patch+json', b'') is not None

# Generated at 2022-06-23 19:21:49.387378
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class MockEnvironment:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    class MockProcessor(ColorFormatter):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)


# Generated at 2022-06-23 19:21:59.186508
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import pytest
    from httpie.output.lexers import SimplifiedHTTPLexer

    assert isinstance(SimplifiedHTTPLexer, type)
    assert isinstance(SimplifiedHTTPLexer(), SimplifiedHTTPLexer)


# Generated at 2022-06-23 19:22:00.025692
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style()

# Generated at 2022-06-23 19:22:01.238946
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    style.styles[pygments.token.Comment]

# Generated at 2022-06-23 19:22:11.787056
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-23 19:22:12.670291
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:22:13.406575
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:22:19.331813
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    tokens = lexer.get_tokens_unprocessed('X-Fake-Header: fake-value')
    assert next(tokens)[1] == pygments.token.Name.Attribute
    assert next(tokens)[1] == pygments.token.Operator
    assert next(tokens)[1] == pygments.token.String

# Generated at 2022-06-23 19:22:26.275300
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import requests, os, json
    s = requests.Session()

# Generated at 2022-06-23 19:22:35.052612
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    # Create a mock environment for testing
    class MockEnv(object):
        pass

    env = MockEnv()

    env.colors = 256
    env.is_terminal = True

    # Use the class to be tested
    import httpie.output.formatters
    httpie.output.formatters.ColorFormatter = ColorFormatter

    # Import the class to be tested
    from httpie.output.formatters import ColorFormatter

    # Create an instance of the class to be tested
    color_formatter = ColorFormatter(env)

    # Test JSON response with an incorrect Content-Type
    assert(color_formatter.get_lexer_for_body('text/html', '{"foo": "bar"}') is not None)

# Generated at 2022-06-23 19:22:42.087060
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class('solarized256')
    assert style == Solarized256Style
    style = ColorFormatter.get_style_class('solarized')
    assert style == Solarized256Style
    style = ColorFormatter.get_style_class('both')
    assert style != Solarized256Style


# Generated at 2022-06-23 19:22:47.033046
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter()
    body = b'{"a": 1, "b": "2"}'
    mime = 'application/json'
    lexer = formatter.get_lexer_for_body(mime, body)
    assert lexer == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:22:58.710223
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-23 19:23:09.697478
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(Environment())

# Generated at 2022-06-23 19:23:15.904768
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(None)
    text = "GET / HTTP/1.1"
    result = formatter.format_headers(text)
    assert text == result, "expected {}, got {}".format(text, result)

    text = "Content-Type: text/plain"
    result = formatter.format_headers(text)
    assert text == result, "expected {}, got {}".format(text, result)

    text = "HTTP/1.1 200 OK"
    result = formatter.format_headers(text)
    assert text == result, "expected {}, got {}".format(text, result)

    text = "HTTP/1.1 500 Internal Server Error"
    result = formatter.format_headers(text)
    assert text == result, "expected {}, got {}".format(text, result)

# Generated at 2022-06-23 19:23:25.359881
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import re
    import pytest

    class TestEnv(object):
        def __init__(self):
            self.colors=256

    env = TestEnv()
    explicit_json = False
    color_scheme = 'solarized'
    formatter = ColorFormatter(env, explicit_json, color_scheme)

    testcases = {
        'application/json': '{\n    "httpie": "HTTPie"\n}',
        'application/x-www-form-urlencoded': 'foo=bar',
    }

    for mime, expected in testcases.items():
        body = """
<html>
<head>
<title>Welcome</title>
</head>
<body>
<p>some text</p>
</body>
</html>
""".strip()
       

# Generated at 2022-06-23 19:23:28.886938
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    color_formatter = ColorFormatter(env, None)

    assert color_formatter.format_headers('Content-Type: application/json') == \
        'Content-Type: application/json'



# Generated at 2022-06-23 19:23:32.075206
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter(Environment())
    assert(cf.formatter is not None)
    assert(cf.http_lexer is not None)
    assert(cf.explicit_json is False)

# Generated at 2022-06-23 19:23:38.185713
# Unit test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-23 19:23:47.834928
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():  # noqa
    env = Environment()

    cf = ColorFormatter(env)

    # Test when mime is None, empty
    assert not cf.get_lexer_for_body(mime=None, body='body')
    assert not cf.get_lexer_for_body(mime='', body='body')

    # Test when mime is text/plain, text/html
    assert not cf.get_lexer_for_body(mime='text/plain', body='body')
    assert not cf.get_lexer_for_body(mime='text/html', body='body')

    # Test when mime is application/json and body is None, empty
    assert get_lexer(mime='application/json', body=None)
    assert get_lexer(mime='application/json', body='')

# Generated at 2022-06-23 19:23:57.753493
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # To test, run 'python3.6 -m unittest' in httpie directory
    try:
        from unittest import mock
    except:
        import mock
    import httpie.formatter

    # Instantiate
    env = mock.Mock()
    env.colors = True
    cf = httpie.formatter.ColorFormatter(env)
    
    # Test data
    mime_pass_1 = 'application/json'
    mime_fail_1 = 'application/xml'
    mime_fail_2 = 'text/html'
    body_pass_1 = '{"a": "b"}'
    body_fail = b'{"a": "b"}'
    body_fail_2 = '<a>b</a>'

    # Tests

# Generated at 2022-06-23 19:24:08.840195
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    def request_lexer(mime: str,
                      body: str) -> Optional[Type[Lexer]]:
        # build candidate mime type and lexer names.
        mime_types, lexer_names = [mime], []
        type_, subtype = mime.split('/', 1)
        if '+' not in subtype:
            lexer_names.append(subtype)
        else:
            subtype_name, subtype_suffix = subtype.split('+', 1)
            lexer_names.extend([subtype_name, subtype_suffix])
            mime_types.extend([
                '%s/%s' % (type_, subtype_name),
                '%s/%s' % (type_, subtype_suffix)
            ])

        #

# Generated at 2022-06-23 19:24:15.814981
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert get_lexer(mime='text/plain') == None
    assert get_lexer(mime='text/plain', explicit_json=True) == None
    assert get_lexer(mime='text/plain', body='{"key": "value"}') != None
    assert get_lexer(mime='text/plain', body='{"key": "value"}', explicit_json=True) != None


# Generated at 2022-06-23 19:24:21.438624
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') == pygments.lexers.JsonLexer
    assert get_lexer('application/json; charset=utf-8') == pygments.lexers.JsonLexer
    assert get_lexer('application/xml') == pygments.lexers.XmlLexer

# Generated at 2022-06-23 19:24:22.877537
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style


# Generated at 2022-06-23 19:24:23.939065
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:24:27.391331
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    c = ColorFormatter(Environment(None, None, None, None))
    print(c.formatter)
    print(c.http_lexer)
    print(c.format_body("{test:test2,test4:test5,}","application/json"))

# Generated at 2022-06-23 19:24:37.412575
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # TODO: test require user input
    print('ColorFormatter.get_lexer_for_body() test')
    print('mime: text/html:')
    lexer = ColorFormatter.get_lexer_for_body(mime='text/html', body='<html></html>')
    print('lexer: ' + lexer.name)
    print('mime: text/plain')
    lexer = ColorFormatter.get_lexer_for_body(mime='text/plain', body='test')
    print('lexer: ' + lexer.name)
    print('mime: application/json')
    lexer = ColorFormatter.get_lexer_for_body(mime='application/json', body='{"test": "test"}')

# Generated at 2022-06-23 19:24:37.895335
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    pass

# Generated at 2022-06-23 19:24:47.693029
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    content_type_list=["application/xml","application/soap+xml", "text/xml",
                       "application/json","application/soap+json", "text/json",
                       "application/javascript","application/soap+javascript", "text/javascript"]
    content_type_text_list=["text/plain","text/html","text/cfm","text/css","text/csv","text/calendar"]
    all_content_type=content_type_list+content_type_text_list
    ColorFormatterObj = ColorFormatter()
    for content_type in all_content_type:
        if content_type in content_type_list:
            body = ColorFormatterObj.format_body('{"test":"test"}', content_type)
            assert '{' in body and '}' in body

# Generated at 2022-06-23 19:24:49.685308
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style().styles['Name.Function'] == "#0087ff"

# Generated at 2022-06-23 19:24:53.492331
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class TestEnv:
        colors = True

    class TestColorFormatter(ColorFormatter):
        def __init__(self):
            super().__init__(
                env=TestEnv,
                explicit_json=False,
                color_scheme=DEFAULT_STYLE,
            )

    c = TestColorFormatter()
    body = '{"foo": "bar"}'
    mime = 'application/json'
    lexer = c.get_lexer_for_body(body, mime)
    assert lexer is not None, 'Unable to get lexer for body'

# Generated at 2022-06-23 19:24:55.829558
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(None)
    assert(color_formatter.formatter != None)
    assert(color_formatter.http_lexer != None)

# Generated at 2022-06-23 19:25:04.180775
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-23 19:25:08.480172
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == "HTTP"
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-23 19:25:13.743960
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Arrange
    from pygments.token import Token
    simplified_http_lexer = SimplifiedHTTPLexer()

    # Act
    tokens = simplified_http_lexer.get_tokens("GET / HTTP/1.1")

    # Assert
    assert next(tokens) == (Token.Name.Function, "GET")
    assert next(tokens) == (Token.Text, " ")
    assert next(tokens) == (Token.Name.Namespace, "/")
    assert next(tokens) == (Token.Text, " ")
    assert next(tokens) == (Token.Keyword.Reserved, "HTTP")
    assert next(tokens) == (Token.Operator, "/")

# Generated at 2022-06-23 19:25:25.168786
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    # Request
    text = 'GET / HTTP/1.1\r\nUser-Agent: httpie\r\nHost: example.com\r\n\r\n'
    tokens = list(lexer.get_tokens(text))
    assert tokens[0][0] == pygments.token.Name.Function
    assert tokens[0][1] == 'GET'
    assert tokens[1][0] == pygments.token.Text
    assert tokens[1][1] == ' '
    assert tokens[2][0] == pygments.token.Name.Namespace
    assert tokens[2][1] == '/'
    assert tokens[3][0] == pygments.token.Text
    assert tokens[3][1] == ' '

# Generated at 2022-06-23 19:25:36.129574
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_lexer = SimplifiedHTTPLexer()

    test_text = """
HTTP/1.1 200 OK
Cache-control: max-age=3600
Date: Wed, 21 Oct 2015 07:28:00 GMT
content-type: application/json; charset=utf-8
content-length: 194
expires: Wed, 21 Oct 2015 08:28:00 GMT

{
  "origin":"139.36.117.229",
  "url":"https://httpbin.org/get"
}
"""

# Generated at 2022-06-23 19:25:46.198326
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='text/html') is not None
    assert get_lexer(mime='text/css') is not None
    assert get_lexer(mime='application/json') is not None
    assert get_lexer(mime='application/javascript') is not None
    assert get_lexer(mime='text/javascript') is not None

    assert get_lexer(mime='foo/unknown') is None
    assert get_lexer(mime='application/unknown') is None
    assert get_lexer(mime='application/unknown', body='<html></html>') is not None
    assert get_lexer(mime='application/unknown', body='{"foo": "bar"}') is not None

# Generated at 2022-06-23 19:25:58.224498
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from io import StringIO
    import pygments
    color_formatter = ColorFormatter(Environment(), explicit_json=False, color_scheme="auto")

# Generated at 2022-06-23 19:26:05.729866
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/vnd.example+json')
    assert get_lexer('application/vnd.example+json', body='{}')
    assert get_lexer('application/vnd.example+json', body='{') is None
    assert get_lexer('application/json') is not None
    assert get_lexer('application/vnd.example+json') is not None



# Generated at 2022-06-23 19:26:13.476079
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()

    # Request-Line
    formatted_code_1 = pygments.highlight("GET / HTTP/1.1",
                                          http_lexer,
                                          Solarized256Style())
    assert "GET / HTTP/1.1" == formatted_code_1.strip()

    # Response Status-Line
    formatted_code_2 = pygments.highlight("HTTP/1.1 200 OK",
                                          http_lexer,
                                          Solarized256Style())
    assert "HTTP/1.1 200 OK" == formatted_code_2.strip()

    # Header
    formatted_code_3 = pygments.highlight("Accept-Encoding: gzip, deflate, br",
                                          http_lexer,
                                          Solarized256Style())


# Generated at 2022-06-23 19:26:23.780427
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-23 19:26:33.092378
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexer import include
    from pygments.lexers.agile import PythonConsoleLexer
    from pygments.lexers.agile import PythonLexer
    from pygments.lexers.compiled import JavaLexer
    from pygments.lexers.configs import ApacheConfLexer
    from pygments.lexers.configs import NginxConfLexer
    from pygments.lexers.data import JsonLexer
    from pygments.lexers.data import YamlLexer
    from pygments.lexers.dotnet import CSharpLexer
    from pygments.lexers.dotnet import FSharpLexer
    from pygments.lexers.functional import ScalaLexer
    from pygments.lexers.html import HtmlLexer
    from pygments.lexers.html import XmlLexer

# Generated at 2022-06-23 19:26:44.242865
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import httpie.output.streams
    class TestEnvironment(Environment):
        stdout = httpie.output.streams.UnicodeStreamWriter

        def __init__(self,colors):
            super().__init__(colors)

    env = TestEnvironment(256)

# Generated at 2022-06-23 19:26:56.006560
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.input import ParseError
    from httpie.cli.parser import parse
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPTokenAuth

    class TestFormatter(ColorFormatter):
        def format_headers(self, headers: str) -> str:
            return 'headers'

        def format_body(self, body: str, mime: str) -> str:
            return super().format_body(body, mime)

    class TestBasicAuth(HTTPBasicAuth):
        def get_auth() -> str:
            return 'Basic ' + 'YWRtaW46YWRtaW4='

    class TestTokenAuth(HTTPTokenAuth):
        def get_auth() -> str:
            return 'AAA...'

    args = ['-fformat=test', 'http://localhost/headers?name=value']


# Generated at 2022-06-23 19:27:05.895897
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.plugins.builtin
    import httpie.core
    import httpie.cli
    from httpie.plugins.formatter.colors import ColorFormatter
    import json

    env = httpie.core.Environment(stdin=object(),
                                  stdout=object(),
                                  stderr=object())

    f = ColorFormatter(env,
                       color_scheme='solarized')

    class r():
        status_code = 200
        raw = None
        reason = 'OK'
        url = 'http://127.0.0.1:5000/'
        headers = {'Content-Type': 'text/plain'}
    class req():
        method = 'GET'
        url = 'http://127.0.0.1:5000/'


# Generated at 2022-06-23 19:27:06.493843
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:27:08.327709
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:27:12.238289
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(env=None)
    assert color_formatter.enabled is False
    assert color_formatter.explicit_json is False
    assert color_formatter.formatter is not None
    assert color_formatter.http_lexer is not None


# Generated at 2022-06-23 19:27:22.609807
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    from pygments.formatters import Terminal256Formatter
    from pygments.styles import get_style_by_name

    style = Solarized256Style
    assert style.__name__ == 'Solarized256Style'
    assert style.__doc__ == '\nsolarized256\n------------\n\nA Pygments style inspired by Solarized\'s 256 color mode.\n\n:copyright: (c) 2011 by Hank Gay, (c) 2012 by John Mastro.\n:license: BSD, see LICENSE for more details.\n\n'
    # the style is registered
    assert style == get_style_by_name('solarized256') or style == get_style_by_name('solarized256')
    # all class members are used to format the style
    formatter = Terminal256Formatter(style=style)


# Generated at 2022-06-23 19:27:24.521016
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    cf = ColorFormatter(Environment(colors=True))
    mime = 'application/json; charset=utf-8'
    body = '{"name":"egg","color":"#fff"}'
    assert cf.get_lexer_for_body(mime,body).__name__ == "Javascript (JSON)"

# Generated at 2022-06-23 19:27:36.095606
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') == pygments.lexers.HtmlLexer
    assert get_lexer('text/html; foo=bar') == pygments.lexers.HtmlLexer
    assert get_lexer('text/html; charset=utf-8') == pygments.lexers.HtmlLexer
    assert get_lexer('application/json') == pygments.lexers.JsonLexer
    assert get_lexer('application/json-rpc') == pygments.lexers.JsonLexer
    assert get_lexer('application/vnd.api+json') == pygments.lexers.JsonLexer
    assert get_lexer('application/hal+json') == pygments.lexers.JsonLexer

# Generated at 2022-06-23 19:27:44.438929
# Unit test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-23 19:27:45.484185
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()

# Generated at 2022-06-23 19:27:57.071848
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from requests import Response
    from httpie.output.streams import Streams
    from httpie.core import main
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR


    env = Environment()
    env.config = Config(config_dir=DEFAULT_CONFIG_DIR)
    env.stream = Streams(stdout=Streams.DEFAULT_STDOUT_STREAM)

    formatter = ColorFormatter(env)

    req = Response()
    req.headers = {
        'a': 'b',
        'x' : 'y'
    }

    http_lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:28:06.092238
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-23 19:28:07.892883
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    solarized = Solarized256Style()
    assert isinstance(solarized, pygments.style.Style)

# Generated at 2022-06-23 19:28:15.555285
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert isinstance(ColorFormatter.get_style_class(SOLARIZED_STYLE), pygments.style.Style)
    assert isinstance(ColorFormatter.get_style_class(DEFAULT_STYLE), pygments.style.Style)
    assert isinstance(ColorFormatter.get_style_class(AUTO_STYLE), pygments.style.Style)
    assert isinstance(ColorFormatter.get_style_class('fruity'), pygments.style.Style)
    assert isinstance(ColorFormatter.get_style_class('paraiso-dark'), pygments.style.Style)
    assert isinstance(ColorFormatter.get_style_class(''), type(None))
    assert isinstance(ColorFormatter.get_style_class(123), type(None))


# Generated at 2022-06-23 19:28:25.266268
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Request-Line
    assert SimplifiedHTTPLexer().get_tokens('GET / HTTP/1.1')[0] == (
        pygments.token.Name.Function,
        'GET',
        0,
        0
    )
    assert SimplifiedHTTPLexer().get_tokens('GET / HTTP/1.1')[3] == (
        pygments.token.Text, ' ', 0, 3
    )
    assert SimplifiedHTTPLexer().get_tokens('GET / HTTP/1.1')[5] == (
        pygments.token.Name.Namespace,
        '/',
        0,
        5
    )

# Generated at 2022-06-23 19:28:33.376044
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main
    from httpie.plugins import plugin_manager
    from httpie.output.streams import COLOR_PALETTE

    # Format with colored headers
    # Note: I/O streams are replaced with in/out lists during initialization
    # of class Environment
    env = main.Environment()
    plugin_manager.load_installed_plugins()
    env.set_color_palette(COLOR_PALETTE)

    text = 'GET / HTTP/1.1\r\n'
    text += 'Host: www.example.com\r\n'
    text += 'Connection: close\r\n'
    text += '\r\n'
    assert ColorFormatter(env).format_headers(text) == text

    text = 'HTTP/1.1 200 OK\r\n'
   

# Generated at 2022-06-23 19:28:43.740178
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    def check_tokens(input, tokens):
        output = lexer.get_tokens(input)
        assert tuple(output) == tokens
    check_tokens('GET /index.html HTTP/1.1',
                 [(1, 'GET', 1, 0),
                  (2, ' ', 1, 3),
                  (3, '/index.html', 1, 4),
                  (2, ' ', 1, 14),
                  (4, 'HTTP', 1, 15),
                  (5, '/', 1, 20),
                  (6, '1.1', 1, 21)])

# Generated at 2022-06-23 19:28:47.443801
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/javascript') is not None
    assert get_lexer('text/json') is not None


# Generated at 2022-06-23 19:28:56.482568
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Given
    from httpie.formatters.utils import get_preferred_mime_type
    expected_str = '<html>\n    <head>\n        <title>Test of ColorFormatter</title>\n    </head>\n    <body>\n        <h1>Test of ColorFormatter</h1>\n    </body>\n</html>'
    # When
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env)
    html_str = color_formatter.format_body(expected_str, get_preferred_mime_type('html'))
    # Then
    assert html_str == expected_str

# Generated at 2022-06-23 19:28:59.172353
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('abcd') is Solarized256Style

# Generated at 2022-06-23 19:29:07.010313
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatted_body = ColorFormatter(Environment(), explicit_json=False, color_scheme="solarized").format_body(
        '{"name": "樂高人偶"}', "application/json"
    )
    assert formatted_body == '\x1b[38;5;118m{\x1b[39m\x1b[38;5;118m"name"\x1b[39m\x1b[38;5;118m:\x1b[39m\x1b[38;5;118m "樂高人偶"\x1b[39m\x1b[38;5;118m}\x1b[39m'

# Generated at 2022-06-23 19:29:08.662461
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    """Unit test for constructor of class SimplifiedHTTPLexer."""
    assert SimplifiedHTTPLexer

# Generated at 2022-06-23 19:29:11.039913
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    lexer.get_tokens("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n")

# Generated at 2022-06-23 19:29:17.524908
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-23 19:29:21.620731
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    instance = ColorFormatter(Environment())
    assert instance.get_style_class('solarized') == Solarized256Style
    assert instance.get_style_class('default') != Solarized256Style