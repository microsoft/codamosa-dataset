

# Generated at 2022-06-23 19:19:25.483030
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print("Test ColorFormatter")
    cf1 = ColorFormatter(Environment())
    cf2 = ColorFormatter(Environment(), False)
    assert isinstance(cf1, cf2.__class__)

# Generated at 2022-06-23 19:19:27.348295
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    ColorFormatter('test', color_scheme = 'test')

# Generated at 2022-06-23 19:19:29.073201
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    styles = ColorFormatter.get_style_class(SOLARIZED_STYLE)
    print(styles)

# Generated at 2022-06-23 19:19:30.016283
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert True

# Generated at 2022-06-23 19:19:41.723759
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Setup
    from httpie.compat import get_encoding_info
    from httpie.output.formatters import PrettyHttpBodyOutputFormatter
    from httpie.output.streams import StdoutBytesIO
    from httpie.utils import get_binary_stream
    from httpie.models import Request, Response
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.formatters import PrettyHttpBodyOutputFormatter
    from httpie.context import Environment
    from httpie.config import DEFAULTS
    from httpie.config import Config
    from httpie.config import merge_config
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.formatters import PrettyHttpBodyOutputFormatter
    from httpie.context import Environment

# Generated at 2022-06-23 19:19:42.705444
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(True)

# Generated at 2022-06-23 19:19:54.292778
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import os
    import json
    import re

    cwd = os.path.dirname(os.path.realpath(__file__))
    test_path = os.path.join(cwd, 'test_data.json')
    with open(test_path, encoding='utf-8') as json_file:
        test_data = json.load(json_file)

    formatter = ColorFormatter(Environment())

    for test in test_data:
        mime = test['mime']
        body = test['body']
        if 'lexer' in test:
            lexer_name = test['lexer']
        else:
            lexer_name = ''
        print()
        print('Testing ' + mime + '...')

# Generated at 2022-06-23 19:20:02.483801
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.formatters import Terminal256Formatter
    from pygments.token import Keyword, Comment, Punctuation, Name, Text
    from pygments.lexers import get_token_class_by_name

    # Dummy file-like object.
    class DummyFileLike(object):
        def __init__(self):
            self._data = ''

        def write(self, data):
            self._data += data

        def getvalue(self):
            return self._data

    lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter()

    out = DummyFileLike()
    data = "GET /foo HTTP/1.1\r\nHost: example.com\r\n\r\n"
    pygments.highlight(data, lexer, formatter, out)

   

# Generated at 2022-06-23 19:20:06.069257
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert style.background_color == '#1c1c1c'
    assert style.styles[pygments.token.Keyword] == '#5f8700'

# Generated at 2022-06-23 19:20:08.281378
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    style.styles[pygments.token.Keyword]



# Generated at 2022-06-23 19:20:08.796157
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment())

# Generated at 2022-06-23 19:20:13.649965
# Unit test for function get_lexer
def test_get_lexer():
    def assert_lexer(body, mimetype, expected_lexer_name):
        assert pygments.lexers.get_lexer_for_mimetype(mimetype) == expected_lexer_name
        assert get_lexer(mimetype, body) == expected_lexer_name
        assert get_lexer(mimetype, explicit_json=True, body=body) == expected_lexer_name

    assert_lexer(body='', mimetype='text/html', expected_lexer_name='html')
    # Should not deduce lexer from the body for `text/plain`
    assert_lexer(body='<html>', mimetype='text/plain', expected_lexer_name='text')

# Generated at 2022-06-23 19:20:16.103424
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('default') == TerminalFormatter.style
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) == Solarized256Style

# Generated at 2022-06-23 19:20:28.289246
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment())
    assert formatter.get_lexer_for_body('application/json', None) == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/javascript', None) == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/vnd.api+json', None) == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/javascript', None) == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:20:38.260947
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    """
    Check that ColorFormatter is created properly with an enabled environment
    Check that ColorFormatter is created properly with a disabled environment
    """
    import os
    import shutil

    try:
        os.environ['HTTPIE_COLORS'] = '1'
        env = Environment()
        assert env.colors is True

        color_formatter = ColorFormatter(env, False)
        assert color_formatter.enabled is True
        assert color_formatter.http_lexer is not None
        assert color_formatter.formatter is not None
    finally:
        os.environ.pop('HTTPIE_COLORS', None)


# Generated at 2022-06-23 19:20:50.033059
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class DummyEnv(object):
        pass
    env = DummyEnv()
    c = ColorFormatter(env)
    assert get_lexer("text/html")
    assert get_lexer("text/html", body="<html>")
    assert get_lexer("text/html", body="<html")
    assert not get_lexer("text/html", body="bla")

    assert get_lexer("application/json", body='{"key": "value"}')
    assert get_lexer("application/json", body='bla')

    assert not get_lexer("image/png", body='bla')

    assert not get_lexer("xxx/xxx")

    assert not get_lexer("application/json")
    assert get_lexer("application/json", body='{"key": "value"}')

# Generated at 2022-06-23 19:20:59.406209
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from pygments.formatters import Terminal256Formatter

    env = Environment(colors=256)
    formatter = ColorFormatter(env=env)

    # Without content-encoding
    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Date: Sat, 04 Apr 2020 13:29:02 GMT

'''.strip()

# Generated at 2022-06-23 19:21:03.815710
# Unit test for function get_lexer
def test_get_lexer():

    tests = (
        ('application/json', 'json'),
        ('application/json+zip', 'json'),
        ('application/zip', 'zip'),
        ('application/gzip', 'gzip'),
        ('text/html+xml', 'html'),
        ('foo/bar', None),
    )

    for mimetype, lexername in tests:
        assert get_lexer(mimetype).name.lower() == lexername

# Generated at 2022-06-23 19:21:16.380277
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class DummyEnv:
        def __init__(self, colors):
            self.colors = colors

    class DummyColorsArgs:
        def __init__(self, color_scheme):
            self.color_scheme = color_scheme

    color_formatter = ColorFormatter(
        env=DummyEnv(colors=256),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE
    )

# Generated at 2022-06-23 19:21:17.508331
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    color = ColorFormatter(env)
    assert color.enabled

# Generated at 2022-06-23 19:21:19.582471
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    lexer = ColorFormatter(None).get_lexer_for_body('application/json', '{}')
    assert lexer is not None
    assert str(lexer) == 'JSON (application/json)'

# Generated at 2022-06-23 19:21:28.598199
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from . import COLOR_FORMATTER
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.prettyjson import PrettyJSONPlugin
    import pygments.lexers

    # Plain text
    logger.debug(COLOR_FORMATTER.get_lexer_for_body('text/plain', ''))
    assert isinstance(
        COLOR_FORMATTER.get_lexer_for_body('text/plain', ''),
        pygments.lexers.TextLexer
    )

    # JSON
    assert isinstance(
        COLOR_FORMATTER.get_lexer_for_body('application/json', ''),
        pygments.lexers.JsonLexer
    )

# Generated at 2022-06-23 19:21:30.900725
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) is Solarized256Style

# Generated at 2022-06-23 19:21:32.871705
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style.styles[pygments.token.Number] == '#00afaf'

# Generated at 2022-06-23 19:21:36.109627
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(Environment('auto'), color_scheme='solarized')
    style = color_formatter.get_style_class(color_formatter.color_scheme)
    assert style.__name__ == 'Solarized256Style'

# Generated at 2022-06-23 19:21:41.352296
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    print("Testing ColorFormatter.format_body")
    from httpie.context import Environment
    from httpie.output.streams import Stream
    from pprint import pprint
    env = Environment()
    env.stdout = Stream.get_by_name(env, 'stdout')
    env.stdout.isatty = lambda : True
    env.colors = 256
    f = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    pprint(f.format_body("[0, 1, 2]", "application/json"))
    print("\n")



# Generated at 2022-06-23 19:21:45.434968
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    text = """POST / HTTP/1.1
Host: example.org
Te:    trailers"""
    for token, content in lexer.get_tokens(text):
        print(content)

# Generated at 2022-06-23 19:21:55.167142
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Test enabled == True and enabled == False
    color_formatter = ColorFormatter(env=None, **{'enabled': True})
    assert(color_formatter.enabled == True)

    color_formatter = ColorFormatter(env=None, **{'enabled': False})
    assert(color_formatter.enabled == False)

    # Test color_scheme == AUTO_STYLE and color_scheme == SOLARIZED_STYLE
    color_formatter = ColorFormatter(env=None, **{'color_scheme': AUTO_STYLE})
    assert(color_formatter.get_style_class(AUTO_STYLE) == None)

    color_formatter = ColorFormatter(env=None, **{'color_scheme': SOLARIZED_STYLE})

# Generated at 2022-06-23 19:22:03.887201
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.context import Environment

    env = Environment()
    auth = HTTPBasicAuth(env=env)
    formatter = ColorFormatter(env=env)

    def assert_body(response, expected_body):
        assert formatter.format_body(
            body=response.body,
            mime=response.headers['content-type'],
        ) == expected_body


# Generated at 2022-06-23 19:22:09.530594
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPHeader
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import ProxyAuthPlugin
    from httpie.plugins.builtin import PromptPasswordAuthPlugin
    from httpie.plugins.builtin import Formatter
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONOptionsPlugin
    from httpie import ExitStatus
    from httpie.input import SEP_CREDENTIALS
    from httpie.input import AuthCredentials
    import os
    from requests.structures import CaseInsensitiveDict
   

# Generated at 2022-06-23 19:22:19.156594
# Unit test for function get_lexer
def test_get_lexer():
    assert not get_lexer('text/foo')
    assert not get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', body='{}')
    assert not get_lexer('application/json', body='blah')
    assert get_lexer('application/json-rpc')
    assert get_lexer('text/x-python') == pygments.lexers.PythonLexer
    assert get_lexer('foo/bar+json') == pygments.lexers.JsonLexer
    assert get_lexer('application/vnd.github.v3.diff')

# Generated at 2022-06-23 19:22:26.192782
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    datas = [
        (
            "application/json",
            True,
            '{}',
            pygments.lexers.get_lexer_by_name('json'),
        ),
        (
            "application/json",
            True,
            '{haha}',
            pygments.lexers.get_lexer_by_name('json'),
        ),
        (
            "application/json",
            False,
            '{}',
            None,
        ),
        (
            "application/json",
            False,
            '{haha}',
            None,
        ),
    ]


# Generated at 2022-06-23 19:22:35.364536
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter(None, False, DEFAULT_STYLE)
    assert cf.formatter
    assert cf.http_lexer
    assert cf.explicit_json == False

    cf = ColorFormatter(None, True, DEFAULT_STYLE)
    assert cf.http_lexer
    assert cf.explicit_json == True

    cf = ColorFormatter(None, False, SOLARIZED_STYLE)
    assert cf.formatter
    assert cf.http_lexer
    assert cf.explicit_json == False

    cf = ColorFormatter(None, False, AUTO_STYLE)
    assert cf.formatter
    assert cf.http_lexer
    assert cf.explicit_json == False

    cf = ColorFormatter(None, True, AUTO_STYLE)
   

# Generated at 2022-06-23 19:22:47.625813
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from test.http import assert_output, http
    from httpie.output.formatters.colors import ColorFormatter
    from httpie import ExitStatus

    env = Environment(stdout=True)
    ColorFormatter(env).get_lexer_for_body('text/plain', 'body')

    # unrecognized mime type
    env.colors = True
    assert_output(http('--json -I', 'https://httpbin.org/post'),
                  stderr='',
                  stdout_contains='body')

    # unrecognized mime type but --json
    env.colors = True
    assert_output(http('--json -I', 'https://httpbin.org/post'),
                  stderr='',
                  stdout_contains='body')



# Generated at 2022-06-23 19:22:50.293049
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import pytest
    env = Environment()
    ColorFormatter(env)
    with pytest.raises(ValueError):
        get_lexer(mime='', explicit_json=False, body='')

# Generated at 2022-06-23 19:23:01.333974
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class FakeEnvironment(Environment):
        def __init__(self, colors):
            self.colors = colors
            self.stdout_isatty = True
            self.is_windows = False
            self.prefer_ipv6 = False
            self.use_ansi_output = True
            self.debug = False
            self.verify = False
            self.verify_certs = False
            self.ignore_stdin = False
            self.default_options = []
            self.session = None
            self.config_dir = None
            self.config_path = None
            self.config = None

    class Fakehighlight():
        @staticmethod
        def highlight(code, lexer, formatter):
            return lexer.name + ':' + formatter.__class__.__name__

    # Env

# Generated at 2022-06-23 19:23:03.991926
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    pass
    # TODO: write a test, see also tests/test_plugins.test_colors
    #assert SimplifiedHTTPLexer().name == 'HTTP'

# Generated at 2022-06-23 19:23:12.626406
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from simplifiedhttp import SimplifiedHTTPLexer
    from pygments.formatters import Terminal256Formatter
    from pygments.styles import get_style_by_name
    from pygments.lexers import get_lexer_by_name
    from pygments.styles.default import DefaultStyle
    from pygments.util import ClassNotFound

    import io
    import os
    import sys

    show = sys.stdout.write

    def get_token_type(tokens, text):
        """get_token_type(tokens, text) -> string"""
        for t, v in tokens:
            if v.strip() == text:
                return t[1]

    def display_tokens(tokens):
        """display_tokens(tokens) -> None"""

# Generated at 2022-06-23 19:23:21.161566
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    print(lexer.tokens)
    # assert lexer.tokens['root'][0] == (r'([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)',)
    #                                                                             pygments.lexer.bygroups(
    #                                                                                 pygments.token.Name.Function,
    #                                                                                 pygments.token.Text,
    #                                                                                 pygments.token.Name.Namespace,
    #                                                                                 pygments.token.Text,
    #                                                                                 pygments.token.Keyword.Reserved,
    #                                                                                 pygments.token.Operator,
    #                                                                                 pygments.

# Generated at 2022-06-23 19:23:26.743196
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    styles = [
        'solarized256',    # Custom style
        'solarized',       # Built-in pygments style
        'fruity',          # Built-in pygments style
        'monokai',         # Built-in pygments style
        'borland',         # Built-in pygments style
    ]
    for color_scheme in styles:
        assert ColorFormatter.get_style_class(color_scheme)

# Generated at 2022-06-23 19:23:35.125353
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer("javascript/javascript") == pygments.lexers.get_lexer_by_name("js")
    assert get_lexer("application/json") == pygments.lexers.get_lexer_by_name("json")
    assert get_lexer("application/xml") == pygments.lexers.get_lexer_by_name("xml")
    assert get_lexer("application/xml") == pygments.lexers.get_lexer_by_name("xml")

if __name__ == '__main__':
    test_ColorFormatter_get_lexer_for_body()

# Generated at 2022-06-23 19:23:36.142766
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    pygments.styles.get_style_by_name("solarized256")

# Generated at 2022-06-23 19:23:41.079946
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    env = Environment()
    FormatterPlugin.__init__(env, **{'group_name': 'colors'})
    ColorFormatter.__init__(env, **{'group_name': 'colors'})
    headers = ColorFormatter().format_headers(
        headers="HTTP/1.1 200 OK\nContent-Type: text/html"
    )
    if headers == '\x1b[1mHTTP/1.1 200 OK\x1b[0m\n\x1b[1mContent-Type: text/html\x1b[0m':
        print('OK')
    else:
        print('Error: {}'.format(headers))


# Generated at 2022-06-23 19:23:49.511767
# Unit test for function get_lexer
def test_get_lexer():
    # type: () -> None
    def check(mime, body, correct_lexer_name):
        # type: (str, str, str) -> None
        lexer = get_lexer(mime, body=body)
        assert lexer is not None, 'failed to find any lexer for %s' % mime
        assert lexer.name == correct_lexer_name, 'failed to get correct lexer %s for %s' % (correct_lexer_name, mime)

    check('text/plain', '', 'Text only')

    check('text/html', '<h1>html</h1>', 'HTML')
    check('text/html', '<h1>html</h1><script>alert(1);</script>', 'HTML+Javascript')

# Generated at 2022-06-23 19:23:59.749410
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env=Environment()
    color_formatter = ColorFormatter(env)
    #assert color_formatter.format_headers() == ""
    assert color_formatter.format_headers("HTTP/1.1 200 OK") == """\
\x1b[38;5;28mHTTP\x1b[39m\x1b[38;5;24m/\x1b[39m\x1b[38;5;31m1.1\x1b[39m \x1b[38;5;28m200 OK\x1b[39m"""

# Generated at 2022-06-23 19:24:02.771444
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    ColorFormatter(Environment()).get_style_class(SOLARIZED_STYLE)

# Generated at 2022-06-23 19:24:07.539664
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class Style(pygments.style.Style):
        background_color = '#ffffff'
        styles = {
            pygments.token.Token: '#000000',
        }

    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style

    # The value of the color_scheme option is 'monokai256.Style'
    assert ColorFormatter.get_style_class('monokai256.Style') == Style

# Generated at 2022-06-23 19:24:08.140569
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert True

# Generated at 2022-06-23 19:24:11.483926
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    obj = Solarized256Style()
    assert obj.background_color == "#1c1c1c"

# Generated at 2022-06-23 19:24:20.770756
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    text = '''GET / HTTP/1.0
Host: example.com

HTTP/1.1 200 OK
Server: Apache

'''

# Generated at 2022-06-23 19:24:21.316341
# Unit test for function get_lexer
def test_get_lexer():
    get_lexer('application/json')

# Generated at 2022-06-23 19:24:30.974219
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(None, explicit_json=False, color_scheme=DEFAULT_STYLE)

    # docs: https://pygments.org/docs/lexers/
    # assertions are based on the docs and https://pygments.org/demo/

    # css
    lexer_css = color_formatter.get_lexer_for_body(
        mime='text/css',
        body=''
    )
    assert lexer_css == pygments.lexers.get_lexer_by_name('css')

    # css with charset
    lexer_css = color_formatter.get_lexer_for_body(
        mime='text/css; charset=utf-8',
        body=''
    )

# Generated at 2022-06-23 19:24:36.169538
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    http_lexer = SimplifiedHTTPLexer()
    formatter = TerminalFormatter()

    color_formatter = ColorFormatter(Environment(), False, 'auto')
    res = color_formatter.format_headers("GET /test HTTP/1.1\n")
    assert res == pygments.highlight(
        code="GET /test HTTP/1.1\n",
        lexer=http_lexer,
        formatter=formatter,
    ).strip()


# Generated at 2022-06-23 19:24:45.097551
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    tokens = list(SimplifiedHTTPLexer().get_tokens('HTTP/1.1 200 OK...'))
    assert tokens[0][0] == pygments.token.Keyword.Reserved
    assert tokens[0][1] == 'HTTP'
    assert tokens[2][0] == pygments.token.Number
    assert tokens[2][1] == '1.1'
    assert tokens[4][0] == pygments.token.Number
    assert tokens[4][1] == '200'
    assert tokens[6][0] == pygments.token.Name.Exception
    assert tokens[6][1] == 'OK'
    assert len(tokens) == 7

# Generated at 2022-06-23 19:24:52.053217
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import unittest
    class TestColorFormatter(unittest.TestCase):
        def runTest(self):
            headers_string = 'HTTP/1.1 200 OK\r\n' \
                             'Content-Length: 10\r\n' \
                             'Content-Type: text/html\r\n' \
                             '\r\n'
            cf = ColorFormatter(None)
            headers_string_formatted = cf.format_headers(headers_string)
            self.assertEqual(headers_string_formatted[0:3],
                             '\x1b[38;5;39m')  # START
            self.assertEqual(headers_string_formatted[-1],
                             '\x1b[0m')  # END

# Generated at 2022-06-23 19:25:01.461704
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from io import StringIO
    from datetime import date
    from httpie.compat import is_windows
    from httpie.compat import unicode

    headers = StringIO('HTTP/1.0 200 OK\r\n'
                       'Content-Type: some/mime\r\n'
                       '\r\n')

    body = StringIO('{"foo": {"bar": "baz"}}')

    env = Environment(colors=True, stdin_isatty=True)
    formatter = ColorFormatter(env)

    expected_result = '{\n  "foo": {\n    "bar": "baz"\n  }\n}\n'


# Generated at 2022-06-23 19:25:11.072909
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    body = 'I am a successful body'
    mime = 'text/plain'
    test_cf = ColorFormatter(None)

    assert test_cf.format_body(body, mime) == body
    assert test_cf.format_body(body, 'text/html') == body

    mime_types = [
        'application/json',
        'application/vnd.api+json',
        'application/x-json'
    ]
    for mime_type in mime_types:
        with pytest.raises(TypeError):
            # Pygments doesn't support json mimetypes
            test_cf.format_body(body, mime_type)



# Generated at 2022-06-23 19:25:19.359662
# Unit test for function get_lexer
def test_get_lexer():
    from httpie.plugins.builtin import HTTP_HEADERS

    def do_test(mime, content='', explicit_json=False,
                expected_lexer_name=None):
        lexer = get_lexer(
            mime=mime,
            explicit_json=explicit_json,
            body=content
        )
        lexer_name = lexer.name if lexer else None
        assert lexer_name == expected_lexer_name, \
            '%r -> %r (expected: %r)' % (mime, lexer_name, expected_lexer_name)

    # From builtin lexers (try lexers for the most common mime types first)

# Generated at 2022-06-23 19:25:23.521452
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import httpie.plugins
    httpie.plugins.__all__.append('ColorFormatter')
    from httpie.core import MainParser
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins import FormatterPlugin
    parser = MainParser()
    env = Environment(colors=256)
    ColorFormatter(env)

# Generated at 2022-06-23 19:25:27.891666
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_format = ColorFormatter(None)
    headers = ""
    actual = color_format.format_headers(headers)
    expected = ""
    assert actual == expected


# Generated at 2022-06-23 19:25:37.300100
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import urlunparse
    import re

    class MockResponse:
        def __init__(self, status_code=200, headers=None, text='', url=None):
            if headers is None:
                headers = {}

            url = url or urlunparse(('http', 'mydomain.com', '', '', '', ''))
            self.url = url
            self.status_code = status_code
            self.headers = headers
            # Extract the mime type if specified.
            self.headers = {
                k.lower(): v for k, v in headers.items()
            }
            self.text = text
            self.raw = text

    # Test, that "json", "js" and "javascript" are recognized as json.

# Generated at 2022-06-23 19:25:47.550345
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie import ExitStatus
    from httpie.context import Environment
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    from tests.constants import UNICODE

    env = Environment()
    env.stdout = env.stderr = open('tests/results/output/formatters/headers-text.txt', 'wb')
    formatter = ColorFormatter(env=env)

    args = ['--verbose']

    # Test request headers

# Generated at 2022-06-23 19:25:59.094379
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from httpie.compat import str

    lexer = SimplifiedHTTPLexer()


# Generated at 2022-06-23 19:26:10.122587
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import sys
    import os
    sys.path.append(os.path.realpath('.'))
    sys.path.append(os.path.realpath('..'))
    from httpie.output.streams import ColorFormatter
    F = ColorFormatter(
        Environment(colors=256)
    )
    print(F.get_lexer_for_body('json/json', '{}'))
    print(F.get_lexer_for_body('json/json', '{}'))
    print(F.get_lexer_for_body('xml/xml', '{}'))
    print(F.get_lexer_for_body('junk/junk', '{}'))
    print(F.get_lexer_for_body('junk/json', '{}'))

# Generated at 2022-06-23 19:26:12.904050
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(
        Environment(colors=True)
    )
    assert formatter != None
    assert formatter.enabled
    assert formatter.group_name == 'colors'


# Generated at 2022-06-23 19:26:23.409081
# Unit test for function get_lexer
def test_get_lexer():
    mime_type = 'application/json'
    exp_json = True
    body = '{"name": "test_get_lexer"}'
    lexer = get_lexer(mime=mime_type, explicit_json=exp_json, body=body)
    assert lexer.name == 'JSON'
    mime_type = 'text/plain'
    exp_json = False
    body = 'invalid json {"name": "test_get_lexer"}'
    lexer = get_lexer(mime=mime_type, explicit_json=exp_json, body=body)
    assert isinstance(lexer, TextLexer)
    exp_json = True
    body = '{"name": "test_get_lexer"}'

# Generated at 2022-06-23 19:26:32.879712
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    text = 'GET /api/ HTTP/1.1\nHost: httpbin.org\nConnection: close\n'
    lexer = SimplifiedHTTPLexer()
    tokens = lexer.get_tokens(text)
    # check tokens

# Generated at 2022-06-23 19:26:40.943848
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    ColorFormatter(Environment(colors=8, colors_force=True))
    ColorFormatter(Environment(colors=256, colors_force=True))
    ColorFormatter(
        Environment(colors=256, colors_force=True),
        color_scheme=SOLARIZED_STYLE
    )

    try:
        ColorFormatter(
            Environment(colors=256, colors_force=True),
            color_scheme='invalid'
        )
    except ClassNotFound:
        pass
    else:
        self.fail('expect ClassNotFound exception')

# Generated at 2022-06-23 19:26:49.005175
# Unit test for function get_lexer

# Generated at 2022-06-23 19:26:59.232374
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import unittest
    import unittest.mock
    from httpie.context import Environment

    json_dict = {
        'answerToTheUltimateQuestionOfLifeTheUniverseAndEverything': 42
    }
    json_str = json.dumps(json_dict)
    response_body = json_str
    response_mime = 'application/json'

    class MockClientResponse:
        @property
        def headers(self):
            return {
                'Content-Type': response_mime
            }

        def json(self):
            return json_dict

    class MockEnvironment(Environment):
        @property
        def stdout_isatty(self):
            return True

        @property
        def colors(self):
            return 256


# Generated at 2022-06-23 19:27:07.068106
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env=Environment(colors=256)
    s=env.session()
    formatter = ColorFormatter(env=env, color_scheme=SOLARIZED_STYLE)
    body = formatter.format_body('[{"a":1}]', 'application/json')

# Generated at 2022-06-23 19:27:15.373829
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter()
    assert formatter.get_lexer_for_body('text/html; charset=foo', '<html>')
    assert not formatter.get_lexer_for_body('text/plain', '<html>')
    assert formatter.get_lexer_for_body(
        'text/plain', '{}', explicit_json=True
    )
    assert not formatter.get_lexer_for_body('application/json', '{')
    assert not formatter.get_lexer_for_body('text/html', '{}')
    assert not formatter.get_lexer_for_body(
        'text/html', '{}', explicit_json=True
    )

# Generated at 2022-06-23 19:27:20.245908
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter = ColorFormatter(Environment())
    assert color_formatter.format_headers('content-type: application/json\r\n') == '\x1b[38;5;33mcontent-type\x1b[0m\x1b[38;5;27m: \x1b[0m\x1b[38;5;33mapplication/json\x1b[0m'

# Generated at 2022-06-23 19:27:28.152720
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    headers = '''GET / HTTP/1.1
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate, compress
Accept: */*
Connection: keep-alive

'''

# Generated at 2022-06-23 19:27:38.691889
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style.background_color == '#1c1c1c'

# Generated at 2022-06-23 19:27:45.108130
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin

    class FormatterPluginTest(FormatterPlugin):
        def __init__(self, **kwargs):
            FormatterPlugin.__init__(self, **kwargs)
        def format_headers(self, headers):
            return headers
        def format_body(self, body, mime):
            return body
    # Test 1
    color = FormatterPluginTest()
    assert(color.format_body("test", "text") == "test")
    # Test 2
    color = FormatterPluginTest()
    assert(color.format_body("test", "text/html") == "test")

# Generated at 2022-06-23 19:27:56.490700
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print("Testing the ColorFormatter")
    class TestFormatter(ColorFormatter):
        def format_headers(self, headers: str) -> str:
            print("Got headers:", headers)
            return super().format_headers(headers)
        def format_body(self, body: str, mime: str) -> str:
            print("Got body:", body)
            return super().format_body(body, mime)
    ColorFormatter(env=None)
    TestFormatter(env=None)
    TestFormatter(env=None, explicit_json=True)
    TestFormatter(env=None, explicit_json=True, color_scheme="monokai")
    TestFormatter(env=None, explicit_json=True, color_scheme="solarized")


# Generated at 2022-06-23 19:28:05.644679
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers = """\
GET / HTTP/1.1
Host: localhost
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
"""

# Generated at 2022-06-23 19:28:12.651980
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # type: () -> None
    from httpie.client import Environment
    env = Environment()
    cf = ColorFormatter(env=env)

    # known mime type
    lexer = cf.get_lexer_for_body("text/html", "htmlbody")
    assert isinstance(lexer, pygments.lexers.special.TextLexer)

    # unknown mime type
    lexer = cf.get_lexer_for_body("text/foo", "foobody")
    assert lexer == None

    # known mime type, unknown subtype
    lexer = cf.get_lexer_for_body("application/foo", "foobody")
    assert lexer == None

    # json body

# Generated at 2022-06-23 19:28:14.333958
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert(ColorFormatter.get_style_class('autumn') == pygments.styles.get_style_by_name('autumn'))



# Generated at 2022-06-23 19:28:23.694902
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer(
        mime='application/json',
        explicit_json=True,
        body='{"foo": "bar"}'
    ).__name__ == 'JSON'

    # https://github.com/jakubroztocil/httpie/issues/61
    assert get_lexer(
        mime='application/json',
        explicit_json=True,
        body=''
    ).__name__ == 'JSON'

    assert get_lexer(
        mime='application/x-www-form-urlencoded',
        explicit_json=True,
        body=''
    ).__name__ == 'URLEncoded'


# Generated at 2022-06-23 19:28:26.141713
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert '{0}'.format(style.style_for_token(pygments.token.String)) == '#00afaf'




# Generated at 2022-06-23 19:28:33.732759
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins import BuiltinPluginManager
    from httpie.main import main
    from httpie.compat import HTTP_CLIENT_MAP

    parser, args = main(['--debug', '--json', '--headers', '--style=fruity'],
                        env=Environment(),
                        stdout=None, stdin=None,
                        builtin_plugins=BuiltinPluginManager)

    from httpie.client import HTTPClient

# Generated at 2022-06-23 19:28:36.738212
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    formatter = ColorFormatter(Environment(colors=True))
    formatter.get_style_class('fruity')



# Generated at 2022-06-23 19:28:42.991200
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('devel') == pygments.styles.get_style_by_name('tango')
    assert ColorFormatter.get_style_class('SOLARIZED_STYLE') == Solarized256Style
    assert ColorFormatter.get_style_class('AUTO_STYLE') == pygments.styles.get_style_by_name('tango')
    assert ColorFormatter.get_style_class('non-existing-style') == Solarized256Style

# Generated at 2022-06-23 19:28:48.277528
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') is None
    assert get_lexer('application/json') is not None
    assert get_lexer('application/json') is not None
    assert get_lexer('application/json', body='{"a": 1}') is not None
    assert get_lexer('application/json', body='\n\n') is not None
    assert get_lexer('application/json+quoted-printable', body='~p~') is not None
    assert get_lexer('application/json+quoted-printable', body='\n\n') is not None
    assert get_lexer('application/xml', body='\n\n') is not None
    assert get_lexer('application/xml+json', body='\n\n') is not None

# Generated at 2022-06-23 19:28:49.304590
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer('')

# Generated at 2022-06-23 19:28:58.612704
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # pylint: disable=protected-access
    formatter = ColorFormatter(None)

    #
    # Case 1: Mime Type: application/ld+json
    #
    mime = 'application/ld+json'
    expected_result = pygments.lexers.get_lexer_by_name('json')

    result = formatter._get_lexer_for_body(mime)
    assert result == expected_result

    #
    # Case 2: Mime Type: application/schema+json
    #
    mime = 'application/schema+json'
    expected_result = pygments.lexers.get_lexer_by_name('json')

    result = formatter._get_lexer_for_body(mime)
    assert result == expected_result

    #
    # Case 3:

# Generated at 2022-06-23 19:29:07.511875
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

    # Request-Line
    assert lexer.get_tokens('GET /foo HTTP/1.1') == [
        (pygments.token.Name.Function, 'GET'),
        (pygments.token.Text, ' '),
        (pygments.token.Name.Namespace, '/foo'),
        (pygments.token.Text, ' '),
        (pygments.token.Keyword.Reserved, 'HTTP'),
        (pygments.token.Operator, '/'),
        (pygments.token.Number, '1.1')
    ]

    # Response Status-Line

# Generated at 2022-06-23 19:29:16.140533
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import os
    import unittest
    from httpie.context import Environment
    from httpie.context import Environment

    json_text = '{"time_spent":11,"num_purchases":2,"customer_id":11}'
    env = Environment()
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='dark-mode')


# Generated at 2022-06-23 19:29:26.151404
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json').name == 'JSON'
    assert get_lexer('application/json; charset=UTF-8').name == 'JSON'
    assert get_lexer('application/javascript').name == 'JavaScript'
    assert get_lexer('text/javascript').name == 'JavaScript'
    assert get_lexer('application/x-javascript').name == 'JavaScript'
    assert get_lexer('application/xml').name == 'XML'
    assert get_lexer('text/xml').name == 'XML'
    assert get_lexer('text/x-markdown').name == 'Markdown'
    assert get_lexer('text/yaml').name == 'YAML'
    assert get_lexer('application/x-yaml').name == 'YAML'
    assert get