

# Generated at 2022-06-23 19:19:20.223279
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    return style.styles

# Generated at 2022-06-23 19:19:22.023830
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:19:25.386767
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('foo') == pygments.styles.get_style_by_name('foo')
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-23 19:19:34.511429
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment()
    env.stdout_isatty = True
    env.colors = True
    cf = ColorFormatter(env=env)
    assert cf.get_lexer_for_body('text/html') == pygments.lexers.HtmlLexer
    assert cf.get_lexer_for_body('text/xml') == pygments.lexers.XmlLexer
    assert cf.get_lexer_for_body('application/json') == pygments.lexers.JsonLexer
    assert cf.get_lexer_for_body('text/plain') == pygments.lexers.TextLexer
    assert cf.get_lexer_for_body('application/octet-stream') == pygments.lexers.TextLexer

# Generated at 2022-06-23 19:19:45.302587
# Unit test for function get_lexer
def test_get_lexer():
    json_body = '{foo: "bar"}'
    text_body = 'text'
    binary_body = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    http_mime = 'http/1.1'
    json_mime = 'application/json'
    html_mime = 'application/html'
    binary_mime = 'application/octet-stream'
    text_mime = 'text/plain'

    assert get_lexer(http_mime) is None
    assert get_lexer(json_mime) is None
    assert get_lexer(binary_mime) is None

    assert get_lexer(http_mime, explicit_json=True, body=json_body) is None

# Generated at 2022-06-23 19:19:56.632439
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # http.
    assert get_lexer('text/html') is pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/css') is pygments.lexers.get_lexer_by_name('css')
    assert get_lexer('application/javascript') is pygments.lexers.get_lexer_by_name('javascript')

    # https.
    assert get_lexer('application/xml') is pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('application/xml-dtd') is pygments.lexers.get_lexer_by_name('xml')

# Generated at 2022-06-23 19:20:03.661221
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class DummyColorFormatter(ColorFormatter):
        def __init__(self):
            self.explicit_json = False
            self.formatter = None
            self.http_lexer = None

    f = DummyColorFormatter()
    assert f.get_lexer_for_body("text/plain", "") == TextLexer
    assert f.get_lexer_for_body("text/html", "") == pygments.lexers.get_lexer_by_name("html")
    assert f.get_lexer_for_body("application/json", "") == pygments.lexers.get_lexer_by_name("json")
    assert f.get_lexer_for_body("application/json", "") == pygments.lexers.get_lexer_by_name("json")
   

# Generated at 2022-06-23 19:20:07.932303
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import codecs
    import pytest
    from io import TextIOWrapper
    from httpie.compat import urlopen

    url = 'https://github.com/jakubroztocil/httpie'
    request = urlopen(url)
    response = request.read()
    file_ = TextIOWrapper(request, encoding='utf8')
    mime = file_.headers.get_content_charset()
    color_formatter = ColorFormatter(None, False)
    result = color_formatter.format_body(str(response, encoding=mime), mime)
    print (result)
    assert(isinstance(result, str))


# Generated at 2022-06-23 19:20:16.949879
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter()
    body = "Hi!"
    mime = 'application/random'
    assert formatter.format_body(body, mime) == body
    body = "Hi!"
    mime = 'image/png'
    assert formatter.format_body(body, mime) == body
    body = "Hi!"
    mime = 'application/json'
    assert formatter.format_body(body, mime) == body
    body = "Hi!"
    mime = 'application/json; charset=utf-8'
    assert formatter.format_body(body, mime) == body

    body = "array(int) [ 1, 2, 3 ]"
    mime = 'text/x-php'
    assert formatter.format_body(body, mime) == body
   

# Generated at 2022-06-23 19:20:23.863573
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(AUTO_STYLE) is None
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) is None
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) is Solarized256Style
    assert ColorFormatter.get_style_class('boring') is None

# Generated at 2022-06-23 19:20:24.989265
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    pass

# Generated at 2022-06-23 19:20:33.659431
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    """Unit test for method get_lexer_for_body of class ColorFormatter."""
    c1 = ColorFormatter(Environment())
    lexer = c1.get_lexer_for_body('application/json', '{}')  # pygments.lexers.JsonLexer
    assert str(type(lexer)) == "<class 'pygments.lexers.data.JsonLexer'>"

    c2 = ColorFormatter(Environment())
    lexer = c2.get_lexer_for_body('application/json; charset=utf-8', '{}')  # pygments.lexers.JsonLexer
    assert str(type(lexer)) == "<class 'pygments.lexers.data.JsonLexer'>"

    c3 = ColorFormatter(Environment())

# Generated at 2022-06-23 19:20:37.590869
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    f = ColorFormatter(env=env, color_scheme=SOLARIZED_STYLE)
    assert f.formatter.style

# Generated at 2022-06-23 19:20:39.191338
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s256 = Solarized256Style()
    print(s256.styles)

# Generated at 2022-06-23 19:20:44.383528
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']
    assert 'root' in lexer.tokens
    assert 'tokens' in type(lexer).__dict__

# Generated at 2022-06-23 19:20:47.024602
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Test for constructor of class ColorFormatter
    class DummyEnvironment(object):
        colors = 256
    assert isinstance(ColorFormatter(DummyEnvironment), FormatterPlugin)

# Generated at 2022-06-23 19:20:52.584578
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    assert http_lexer.name == 'HTTP'
    assert http_lexer.aliases == ['http']
    assert http_lexer.filenames == ['*.http']
    # lexer = pygments.lexers.get_lexer_by_name('http')
    # assert http_lexer.tokens == lexer.tokens



# Generated at 2022-06-23 19:20:55.880582
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("monokai") == pygments.styles.get_style_by_name("monokai")
    assert ColorFormatter.get_style_class("solarized256") == Solarized256Style

# Generated at 2022-06-23 19:20:58.427979
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    c = ColorFormatter(Environment(), color_scheme=SOLARIZED_STYLE)
    assert c.formatter.color_scheme['Name.Attribute'] == '#8a8a8a'

# Generated at 2022-06-23 19:21:00.565607
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) is not None
    assert ColorFormatter.get_style_class('non-existent') is None


# Generated at 2022-06-23 19:21:01.701191
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    pass

# Generated at 2022-06-23 19:21:03.746494
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:21:11.683880
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():

    class DummyEnv(object):
        colors = True

    class DummyFormatterPlugin(ColorFormatter):
        pass

    plugin = DummyFormatterPlugin(env=DummyEnv(), **{'enabled': True})

    assert DEFAULT_STYLE != SOLARIZED_STYLE

    style_classes = {}
    for style in AVAILABLE_STYLES:
        style_classes[style] = plugin.get_style_class(style)

    # Verify that style option `default` returns the default style class
    # not the default style value
    assert style_classes[DEFAULT_STYLE] == style_classes[AUTO_STYLE]

    # Verify the style option `solarized` returns Solarized256Style
    assert style_classes[SOLARIZED_STYLE] == Solarized256

# Generated at 2022-06-23 19:21:13.080401
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    print(lexer)

# Generated at 2022-06-23 19:21:13.985475
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:21:24.599679
# Unit test for function get_lexer
def test_get_lexer():
    # Fallback to plain text
    assert isinstance(
        get_lexer('x-foo/bar', explicit_json=True),
        pygments.lexers.text.TextLexer
    )
    assert isinstance(
        get_lexer('x-foo/bar', explicit_json=False),
        pygments.lexers.text.TextLexer
    )

    # Explicit JSON overrides everything
    assert not isinstance(
        get_lexer('x-foo/bar', explicit_json=True),
        pygments.lexers.text.TextLexer
    )
    assert isinstance(
        get_lexer('', explicit_json=True),
        pygments.lexers.text.TextLexer
    )

# Generated at 2022-06-23 19:21:34.823249
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-23 19:21:43.967609
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='application/json') == pygments.lexers.JsonLexer
    assert get_lexer(mime='application/ld+json') == pygments.lexers.JsonLexer
    assert get_lexer(mime='application/xml') == pygments.lexers.XmlLexer
    assert get_lexer(explicit_json=True, body='') is None
    assert get_lexer(explicit_json=True, body='{}') == pygments.lexers.JsonLexer

# Generated at 2022-06-23 19:21:51.252562
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer('application/json', False) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', True) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('text/json', True) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('text/json', True, '{"wrong":json}') is None
    assert get_lexer('text/xml', False) == pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('text/xml', False, '{"wrong":xml}') is None

# Generated at 2022-06-23 19:21:52.650612
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()

    assert style.background_color == Solarized256S

# Generated at 2022-06-23 19:22:02.082776
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import Formatter

    # Default expected results
    expected_result = 'httpie.plugins.builtin.JSONFormatter'
    expected_result_no_body = 'pygments.lexers.text.HttpLexer'

    # Create a colorformatter with explicit_json = True
    color_formatter = ColorFormatter(env=None, explicit_json=True)
    # Run get_lexer_for_body with a mimetype that is not JSON and no body
    result = str(type(color_formatter.get_lexer_for_body('text/html', '')))
    assert result == expected_result_no_body  # Must be HTTP lexer
    # Run get_lexer_for_body with a mimetype that is

# Generated at 2022-06-23 19:22:05.910144
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    expected = pygments.token.Token
    assert SimplifiedHTTPLexer.tokens['root'][0][1][0] == expected

# Generated at 2022-06-23 19:22:07.288560
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    f = ColorFormatter(0, False, 'solarized')

# Generated at 2022-06-23 19:22:18.847042
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():

    def test(mime, body, explicit_json, expected_lexer):
        color_formatter = ColorFormatter(
            Environment(colors=256),
            explicit_json=explicit_json
        )
        result = color_formatter.format_body(body, mime)
        actual_lexer = color_formatter.get_lexer_for_body(mime, body)
        assert (actual_lexer == expected_lexer),\
            "mime: %s, body: %s" % (mime, body)
        return result

    assert test('application/json', '{}', False,
                pygments.lexers.json.JsonLexer)
    assert test('application/json', '', False, None)

# Generated at 2022-06-23 19:22:20.818210
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-23 19:22:31.416756
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('text/plain').__name__ == 'Text only'
    assert get_lexer('text/csv').__name__ == 'CSV'
    assert get_lexer('text/csv', body='one,two\nthree,four').__name__ == 'CSV'
    assert get_lexer('text/csv', body='one=two\nthree=four').__name__ == 'Text only'
    assert get_lexer('text/csv', explicit_json=True, body='{"a": 1}').__name__ == 'JSON'
    assert get_lexer('image/svg+xml').__name__ == 'SVG'
    assert get_lexer('application/vnd.github.v3+json; charset=utf-8').__name__

# Generated at 2022-06-23 19:22:37.928868
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style_class = Solarized256Style
    style_color_dict = style_class.styles

# Generated at 2022-06-23 19:22:42.712702
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # When the color scheme is fufilled in
    ColorFormatter.get_style_class('fruity')

    # When the color scheme is invalid
    assert ColorFormatter.get_style_class('color_scheme') == Solarized256Style

# Generated at 2022-06-23 19:22:47.209925
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    try:
        style = pygments.styles.get_style_by_name('solarized256')
    except ClassNotFound:
        pygments.styles.register_style(Solarized256Style)
        style = pygments.styles.get_style_by_name('solarized256')
    assert style

# Generated at 2022-06-23 19:22:58.829868
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.colors import ColorFormatter
    import httpie.input
    import httpie.output
    env = httpie.Environment()
    # Note: here we use a mocked output for the default environment.
    # Otherwise it would also be necessary to mock terminal dimensions
    # (i.e., width=80, height=24)
    formatter = ColorFormatter(env, httpie.output.get_output(env, False))
    headers = "\r\n".join([
        "GET /test HTTP/1.1",
        "Accept: */*",
        "Accept-Encoding: gzip, deflate",
        "Connection: keep-alive",
        "Host: httpbin.org",
        "User-Agent: HTTPie/0.9.4-dev",
        ""
    ])

# Generated at 2022-06-23 19:23:09.696164
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import json
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter

    env = Environment(colors=True)
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_lexer_for_body(mime='text/plain', body='') == None
    assert color_formatter.get_lexer_for_body(mime='text/html', body='') == pygments.lexers.HtmlLexer
    assert color_formatter.get_lexer_for_body(mime='application/json', body='') == pygments.lexers.JsonLexer
    assert color_formatter.get_lexer_for_body(mime='text/plain', body='{"a": "a"}') == pygments.lexers.J

# Generated at 2022-06-23 19:23:11.221913
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert isinstance(Solarized256Style, pygments.style.Style)
    assert "GREEN" in dir(Solarized256Style)

# Generated at 2022-06-23 19:23:20.269487
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    def test(input_text, expected_output):
        from httpie.formatter import get_parser
        from httpie import ExitStatus
        args = get_parser().parse_args(args=[])
        args.stream_output_header = True
        cf = ColorFormatter(
            env=Environment(),
            args=args,
        )
        actual_output = cf.format_headers(input_text)
        assert actual_output == expected_output


# Generated at 2022-06-23 19:23:30.345011
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-23 19:23:35.994103
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    from httpie.plugins import Plugin

    env = Environment(stdout=None)
    explicit_json = False
    color_scheme = 'solarized'

    plugins = [Plugin(env=env), ColorFormatter(env=env, explicit_json=explicit_json, color_scheme=color_scheme)]
    env.formatter = plugins[1]

# Generated at 2022-06-23 19:23:37.884239
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    colorizer = ColorFormatter(
        env=env,
    )
    colorizer.format_headers([])

# Generated at 2022-06-23 19:23:47.586596
# Unit test for function get_lexer
def test_get_lexer():
    assert pygments.lexers.get_lexer_for_mimetype('text/vnd.sql') == pygments.lexers.get_lexer_for_mimetype('text/x-sql')
    assert pygments.lexers.get_lexer_for_mimetype('text/x-sql') == pygments.lexers.get_lexer_for_mimetype('text/x-plsql')
    assert pygments.lexers.get_lexer_by_name('sql') == pygments.lexers.get_lexer_by_name('plsql')
    assert get_lexer('text/vnd.sql') == pygments.lexers.get_lexer_for_mimetype('text/x-sql')

# Generated at 2022-06-23 19:23:50.444839
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    formatter = ColorFormatter(env)
    print(formatter)
    assert(True)

test_ColorFormatter()

# Generated at 2022-06-23 19:23:52.003565
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    ColorFormatter.get_style_class(DEFAULT_STYLE)

# Generated at 2022-06-23 19:24:02.770809
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class MockedEnvironment:
        def __init__(self, colors: int, debug=False, verbose=False):
            self.colors = colors
            self.debug = debug
            self.verbose = verbose
        def is_windows(self):
            return is_windows()

    debug = True
    for verbose in [True, False]:
        for colors in [0, 1, 256]:
            env = MockedEnvironment(colors, debug, verbose)
            assert ColorFormatter(env, False, DEFAULT_STYLE, None)

    assert ColorFormatter(MockedEnvironment(256, True, True), False, DEFAULT_STYLE, None)
    assert ColorFormatter(MockedEnvironment(256, False, False), False, DEFAULT_STYLE, None)


# Generated at 2022-06-23 19:24:11.573175
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # type: () -> None
    from httpie.formatter import _get_lexer_for_body
    from httpie.output.colors import ColorFormatter

    assert isinstance(_get_lexer_for_body('application/json'),Lexer)
    assert isinstance(_get_lexer_for_body('application/yaml'),Lexer)
    assert isinstance(_get_lexer_for_body('text/html'),Lexer)
    assert isinstance(_get_lexer_for_body('text/xml'),Lexer)
    assert _get_lexer_for_body('text/plain') is None
    assert _get_lexer_for_body('text/abc') is None
    assert _get_lexer_for_body('application/abc') is None

# Generated at 2022-06-23 19:24:16.625038
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    """
    Test constructor of class ColorFormatter

    :return:
    """
    cf = ColorFormatter(Environment(colors=True))
    assert cf.enabled
    assert cf.explicit_json == False
    assert cf.group_name == 'colors'
    assert repr(cf) == '<ColorFormatter enabled>'


# Generated at 2022-06-23 19:24:26.551390
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter = ColorFormatter(
        env=Environment(),
        explicit_json=False,
        color_scheme='monokai'
    )

# Generated at 2022-06-23 19:24:27.109425
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter

# Generated at 2022-06-23 19:24:32.373372
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.enabled
    assert not formatter.explicit_json
    assert formatter.formatter
    assert formatter.http_lexer
    assert formatter.group_name == 'colors'

# Generated at 2022-06-23 19:24:35.659741
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/vnd.siren+json') is None
    assert get_lexer('application/vnd.siren+json', explicit_json=True)

# Generated at 2022-06-23 19:24:46.120047
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(None, None)
    data = """HTTP/1.1 200 Ok
Content-Type: text/plain
Test: test

"""

# Generated at 2022-06-23 19:24:56.865604
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(None)

    lexer = formatter.get_lexer_for_body(
        mime='application/json',
        body='{"hello": "world"}'
    )
    assert lexer.name == 'JSON'

    lexer = formatter.get_lexer_for_body(
        mime='application/json',
        body='{"hello": "world"}'
    )
    assert lexer.name == 'JSON'

    lexer = formatter.get_lexer_for_body(
        mime='application/json',
        body='{"hello": "world"}'
    )
    assert lexer.name == 'JSON'

# Generated at 2022-06-23 19:25:00.549879
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.context import Environment
    env = Environment(colors=256, style='solarized', stdin_isatty=False)
    color_formatter = ColorFormatter(env=env, explicit_json=False)
    assert get_lexer(mime='application/json', explicit_json=False, body='{}') is pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body(mime='text/plain', body='{}') == SimplifiedHTTPLexer

# Generated at 2022-06-23 19:25:04.092873
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment()
    color_formatter = ColorFormatter(env)

    # JSONContent
    json_content = '{"key": "value"}'
    mime = 'application/json'
    assert isinstance(color_formatter.get_lexer_for_body(mime, json_content),
                      pygments.lexers.get_lexer_by_name('json'))

# Generated at 2022-06-23 19:25:15.324613
# Unit test for constructor of class ColorFormatter

# Generated at 2022-06-23 19:25:25.970514
# Unit test for function get_lexer
def test_get_lexer():
    def check(mime, body, should_be_json_lexer):
        lexer = get_lexer(mime, explicit_json=False, body=body)
        assert bool(lexer) == bool(should_be_json_lexer)
        if should_be_json_lexer:
            assert lexer == pygments.lexers.get_lexer_by_name('json')

    check('application/json', '{"a": "b"}', True)
    check('application/json', '{"a": "b}', True)
    check('application/json', '{"a": "b', False)
    check('application/json', '{a: b}', False)
    check('application/json', 'a": "b"}', False)

# Generated at 2022-06-23 19:25:29.713104
# Unit test for function get_lexer
def test_get_lexer():
    import doctest

    doctest.run_docstring_examples(
        get_lexer,
        globals(),
        name='get_lexer',
        optionflags=doctest.ELLIPSIS,
        verbose=True
    )

# Generated at 2022-06-23 19:25:32.075209
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    Style = ColorFormatter.get_style_class('solarized')
    assert Style is Solarized256Style

# Generated at 2022-06-23 19:25:32.675804
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    pass

# Generated at 2022-06-23 19:25:40.782702
# Unit test for function get_lexer
def test_get_lexer():
    # pygments includes HTTP lexer by default
    assert get_lexer('text/plain') is None
    assert get_lexer('text/x-http') is not None

    # pygments includes JavaScript lexer by default
    assert get_lexer('application/javascript') is not None
    assert get_lexer('application/x-javascript') is not None

    # JSON lexer is used only when explicitly specified or if the content
    # type is missing and the response body contains 'json'
    assert get_lexer('application/json') is not None
    assert get_lexer('application/json', explicit_json=True) is not None
    assert get_lexer('application/x-json') is None
    assert get_lexer('application/x-json', explicit_json=False, body='json') is not None

    # Atom is a

# Generated at 2022-06-23 19:25:49.785780
# Unit test for function get_lexer
def test_get_lexer():
    def detect_lexer(mime, expected_lexer, body=None):
        lexer = get_lexer(mime=mime, body=body)
        assert lexer == expected_lexer, \
            '%r != %r' % (lexer, expected_lexer)

    detect_lexer(
        mime='application/json',
        expected_lexer=pygments.lexers.get_lexer_by_name('json'),
        body='{"foo": "bar"}'
    )
    detect_lexer(
        mime='application/json',
        expected_lexer=pygments.lexers.get_lexer_by_name('javascript'),
        body='<!DOCTYPE html>'
    )

# Generated at 2022-06-23 19:25:52.118445
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == "HTTP"

# Generated at 2022-06-23 19:26:01.471757
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    """
    Check if output of ColorFormatter.format_headers
    is what we expect
    """

    # Dummy output
    original_headers_output = '''\
POST / HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate, compress
Accept: */*
User-Agent: python-requests/2.6.1
Content-Length: 19
Content-Type: application/x-www-form-urlencoded\
'''
    # Dummy input

# Generated at 2022-06-23 19:26:11.053023
# Unit test for function get_lexer
def test_get_lexer():
    get_lexer('application/json') == pygments.lexers.JsonLexer
    get_lexer('application/json', body='{}') == pygments.lexers.JsonLexer
    get_lexer('text/json', body='{}') == pygments.lexers.JsonLexer
    get_lexer('text/javascript', body='{}') == pygments.lexers.JsonLexer
    get_lexer('text/x-javascript', body='{}') == pygments.lexers.JsonLexer
    get_lexer('text/x-json', body='{}') == pygments.lexers.JsonLexer
    get_lexer('application/javascript', body='{}') == pygments.lexers.JsonLexer

# Generated at 2022-06-23 19:26:13.311821
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    ColorFormatter(
        Environment(),
        explicit_json=False,
        color_scheme="default"
    )


# Generated at 2022-06-23 19:26:20.297181
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Arrange
    formatter = ColorFormatter(
        Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    mime = 'application/json'
    body = '{"name": "kim", "sex": "female',
    expect = pygments.lexers.JsonLexer

    # Act
    actual = formatter.get_lexer_for_body(mime, body)

    # Assert
    assert actual == expect


# Generated at 2022-06-23 19:26:24.482251
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer(mime='text/plain')
    assert lexer is None
    lexer = get_lexer(mime='application/json')
    assert lexer is None
    lexer = get_lexer(mime='application/json', explicit_json=True)
    assert isinstance(lexer, pygments.lexers.JsonLexer)
    lexer = get_lexer(mime='application/json', explicit_json=True, body='{}')
    assert isinstance(lexer, pygments.lexers.JsonLexer)

# Generated at 2022-06-23 19:26:33.483503
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import httpie.formatters
    from httpie.formatters import (
        _colors,
        DEFAULT_OPTIONS,
        DEFAULT_OPTIONS
    )
    from httpie.core import main
    from httpie.utils import str_to_ui
    from httpie.utils import StdStream
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin

    from httpie.context import Environment
    from httpie.formatters import BaseFormatter
    if not is_windows:
        from httpie.plugins import Colored
    from httpie.compat import is_py26

    colors_style = 'solarized'
    env = Environment(is_windows=True, colors=256)

# Generated at 2022-06-23 19:26:44.481827
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import get_formatter
    parser = get_formatter('colors')
    formatter = parser('', False)
    assert formatter.get_lexer_for_body("text/plain", "") == TextLexer
    assert formatter.get_lexer_for_body("text/html", "") == pygments.lexers.get_lexer_by_name("html")
    assert formatter.get_lexer_for_body("application/javascript", "") == pygments.lexers.get_lexer_by_name("javascript")
    assert formatter.get_lexer_for_body("application/json", "") == pygments.lexers.get_lexer_by_name("json")
    assert formatter.get_lexer_for_body("application/json", None) == pygments

# Generated at 2022-06-23 19:26:54.456221
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    """

    unit test for class :class:`httpie.plugins.colors.SimplifiedHTTPLexer`

    :return:
    """
    lexer = SimplifiedHTTPLexer()
    tokens = lexer.get_tokens(u"GET /demo.html HTTP/1.1\nContent-Type: text/html\nServer: gunicorn/0.17.4\nDate: Tue, 12 Feb 2013 06:12:11 GMT\nContent-Length: 678")
    for index, item in enumerate(list(tokens)):
        print("token [{}]: {}".format(index, item))

# Generated at 2022-06-23 19:27:02.222840
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_pygments_supported
    from httpie.output.streams import WriteBaseStream
    from httpie.plugins.colors import ColorFormatter
    import os

    if not is_pygments_supported:
        return

    mime = 'text/html'
    body = '<html>blah</html>'

    color_formatter = ColorFormatter(None, True)
    formatted_body = color_formatter.format_body(body, mime)
    assert (formatted_body == body)

    color_formatter = ColorFormatter(None, False)
    formatted_body = color_formatter.format_body(body, mime)
    assert (formatted_body == body)

    mime = 'text/plain'

# Generated at 2022-06-23 19:27:05.478928
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    def assert_style_class(style_name, expected_style_class):
        style_class = ColorFormatter.get_style_class(style_name)
        assert style_class == expected_style_class

    assert_style_class(style_name='auto', expected_style_class=None)
    assert_style_class(style_name='solarized', expected_style_class=Solarized256Style)
    assert_style_class(style_name='solarized256', expected_style_class=Solarized256Style)

# Generated at 2022-06-23 19:27:06.443467
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()  # for pyflakes

# Generated at 2022-06-23 19:27:12.370203
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class DummyColorFormatter(ColorFormatter):
        def __init__(self):
            self.get_style_class = ColorFormatter.get_style_class
    assert isinstance(DummyColorFormatter().get_style_class("nonexistent"), Solarized256Style)
    assert isinstance(DummyColorFormatter().get_style_class("default"), Solarized256Style)

# Generated at 2022-06-23 19:27:22.609521
# Unit test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-23 19:27:29.249022
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    ff = ColorFormatter('env')
    ff.enabled = True
    ff.explicit_json = False
    ff.formatter = TerminalFormatter()
    ff.http_lexer = SimplifiedHTTPLexer()

    # With a json body, the method should return a syntax-highlighted body
    body = '{"a":1, "b":2}'
    mime = 'application/json'
    res = ff.format_body(body, mime)

# Generated at 2022-06-23 19:27:39.520786
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class TestEnv:
        def __init__(self):
            self.colors = 256

    class TestFormatterPlugin(ColorFormatter):
        def __init__(self, explicit_json=False):
            self.explicit_json = explicit_json

    class TestLexer(pygments.lexer.RegexLexer):
        name = 'test_lexer'
        tokens = {'root': [(r'(a)', pygments.lexer.bygroups(pygments.token.Text))]}

    # Test for explicit json
    formatter = TestFormatterPlugin(explicit_json=True)
    expected = pygments.highlight(
        code='a',
        lexer=pygments.lexers.get_lexer_by_name('json'),
        formatter=formatter.formatter
    )
   

# Generated at 2022-06-23 19:27:44.318103
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    headers = '''GET / HTTP/1.1\r\n'''
    fp = ColorFormatter(explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert fp.format_body(body='', mime='application/json') == ''



# Generated at 2022-06-23 19:27:55.910771
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body(): #type: () -> None
    assert ColorFormatter(Environment(), enable_colors=True).format_body('abc', 'text/html') == 'abc'
    assert ColorFormatter(Environment(), enable_colors=False).format_body('abc', 'text/html') == 'abc'

    assert ColorFormatter(Environment(), enable_colors=True, explicit_json=True).format_body('abc', 'text/html') == 'abc'

# Generated at 2022-06-23 19:28:00.446770
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    formatter = ColorFormatter(Environment())
    assert formatter.get_style_class('default') == pygments.styles.get_style_by_name('default')
    assert formatter.get_style_class('solarized') == Solarized256Style
    assert formatter.get_style_class('auto') == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-23 19:28:11.004525
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.core import main
    from httpie.compat import urlopen

    import os
    import tempfile

    rendered_body_file, rendered_body_path = tempfile.mkstemp()

# Generated at 2022-06-23 19:28:12.713459
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins.colors.utils import ColorFormatter
    style_class = ColorFormatter.get_style_class('solarized')
    assert style_class == Solarized256Style

# Generated at 2022-06-23 19:28:13.669602
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-23 19:28:16.697258
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert isinstance(lexer, pygments.lexer.RegexLexer)
    assert lexer.aliases[0] == 'http'
    assert lexer.name == 'HTTP'

# Generated at 2022-06-23 19:28:21.532010
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Solarized256Style should be registered
    assert Solarized256Style in pygments.styles.STYLE_MAP.values()
    # ColorFormatter.get_style_class should return Solarized256Style
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-23 19:28:31.071014
# Unit test for function get_lexer
def test_get_lexer():
    # No matching mime type or lexer name
    assert get_lexer('foo/bar') is None

    # Matches mime type
    lexer = get_lexer('application/json')
    assert lexer.name == 'JSON'

    # Matches lexer name
    lexer = get_lexer('foo/bar', body='{"foo": "bar"}')
    assert lexer.name == 'JSON'

    # Matches mime type and lexer name
    lexer = get_lexer('application/json', body='{"foo": "bar"}')
    assert lexer.name == 'JSON'

    # Matches only lexer name
    lexer = get_lexer('foo/bar+baz', body='{"foo": "bar"}')
    assert lexer.name == 'JSON'

    # Matches mime

# Generated at 2022-06-23 19:28:31.853729
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:28:42.914104
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.streams import StdoutStream
    from httpie.plugins import plugin_manager

    color_formatter = ColorFormatter(
        environment=plugin_manager.env,
        stream=StdoutStream()
    )

    assert color_formatter.get_lexer_for_body('application/json', r'''
{
    "test": true
}''') == pygments.lexers.get_lexer_by_name('json')

    assert not color_formatter.get_lexer_for_body(
        'image/jpeg', open('tests/fixtures/sample.jpg', 'rb').read()
    )


# Generated at 2022-06-23 19:28:47.145986
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class MockColorFormatter(ColorFormatter):
        def get_lexer_for_body(self, mime: str, body: str):
            return False

    test_dict = {
        ('text/html', '<html>', '<html>'),
        ('application/json', '{"hello":"world"}', '{"hello":"world"}'),
    }

    for mime, body, res in test_dict:
        env = Environment(colors=256)
        cf = MockColorFormatter(env)
        assert cf.format_body(body, mime) == res


# Generated at 2022-06-23 19:28:48.766406
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment())
    assert formatter is not None

# Generated at 2022-06-23 19:28:58.232144
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_pygments_installed, is_windows

    from httpie import ExitStatus
    from httpie.core import http
    from httpie.plugins import plugin_manager

    def get_type(content_type):
        ct = content_type.lower()
        if ct.startswith('application/'):
            return 'application'
        if ct.startswith('text/'):
            return 'text'

    def get_lexer(
        mime: str,
        explicit_json=False,
        body=''
    ) -> Optional[Type[Lexer]]:
        return ColorFormatter.get_lexer_for_body(mime, body)

    plugin_manager.load_builtin_plugins()
    env = Environment()
    env.colors = 256

    Color

# Generated at 2022-06-23 19:29:05.518375
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    def init_mock(self, env: Environment, explicit_json: bool = False, color_scheme: str = "auto", **kwargs):
        self.formatter = FormatterPlugin(**kwargs)
        self.http_lexer = SimplifiedHTTPLexer()
        self.explicit_json = explicit_json
        self.color_scheme = color_scheme
        self.enabled = True
        self.is_windows = is_windows

    print(ColorFormatter.init_mock.__name__)

# Generated at 2022-06-23 19:29:07.652578
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-23 19:29:16.237904
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from io import StringIO
    from httpie import __version__
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin, get_formatter
    from httpie.plugins.builtin import HTTPHeadersFormat
    from httpie.plugins.colors import ColorFormatter

# Generated at 2022-06-23 19:29:26.224370
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class Env:
        def __init__(self, v):
            self.colors = v

    class Request:
        def __init__(self, color_scheme, explicit_json):
            self.color_scheme = color_scheme
            self.explicit_json = explicit_json

    formatter = ColorFormatter(env=Env(True), request=Request(DEFAULT_STYLE, False))
    assert formatter.color_scheme == DEFAULT_STYLE
    assert formatter.explicit_json == False
    assert formatter.enabled == True

    formatter = ColorFormatter(env=Env(True), request=Request(None, True))
    assert formatter.color_scheme == AUTO_STYLE
    assert formatter.explicit_json == True
    assert formatter.enabled