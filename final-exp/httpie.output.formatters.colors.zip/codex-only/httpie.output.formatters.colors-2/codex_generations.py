

# Generated at 2022-06-23 19:19:31.985237
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(None)
    lexer = formatter.get_lexer_for_body('text/plain', '')
    assert lexer.name == 'Text only'
    lexer = formatter.get_lexer_for_body('text/plain', '{"test": 123}')
    assert lexer.name == 'JSON'
    lexer = formatter.get_lexer_for_body('application/json', '{"test": 123}')
    assert lexer.name == 'JSON'
    lexer = formatter.get_lexer_for_body('application/json', 'test')
    assert lexer.name == 'Text only'
    lexer = formatter.get_lexer_for_body('application/json', 'test', True)
    assert lexer.name == 'JSON'
    lex

# Generated at 2022-06-23 19:19:38.467987
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class Response():
        status_code = 200
        headers = {'Content-Type': 'application/json'}
        def iter_content(self, chunk_size):
            yield b'{}'
    res = Response()
    color_formatter = ColorFormatter(Environment())
    assert(color_formatter.get_lexer_for_body(res.headers['Content-Type'], res.content))

# Generated at 2022-06-23 19:19:47.020258
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.output

    env = httpie.output.get_default_output().env
    cf = ColorFormatter(env)

    import pytest
    from httpie.plugins import FormatterPlugin
    from httpie.output import get_default_output

    # Get the default output and its environment.
    old_output = get_default_output()
    cf_env = old_output.env

    # Add a new output with a color formatter with the `explicit_json`
    # option and get its environment.
    new_output = httpie.output.Output(
        name=old_output.name,
        env=old_output.env
    )
    new_output.env = cf_env._replace(explicit_json=True)
    new_output.formatter = ColorFormatter(new_output.env)

# Generated at 2022-06-23 19:19:47.961442
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style()

# Generated at 2022-06-23 19:19:53.548522
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) is Solarized256Style
    assert ColorFormatter.get_style_class(AUTO_STYLE) is not Solarized256Style
    assert ColorFormatter.get_style_class('manni') is pygments.styles.get_style_by_name('manni')

# Generated at 2022-06-23 19:19:58.482589
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(
        'text/html'
    ).__name__ == 'HtmlLexer'
    assert get_lexer(
        'text/plain'
    ).__name__ == 'TextLexer'
    assert get_lexer(
        'application/json'
    ).__name__ == 'JsonLexer'

# Generated at 2022-06-23 19:20:10.704883
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class Cluster:
        pass
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == pygments.styles.get_style_by_name('default')
    assert ColorFormatter.get_style_class('') == pygments.styles.get_style_by_name('default')
    assert ColorFormatter.get_style_class(None) == pygments.styles.get_style_by_name('default')
    assert ColorFormatter.get_style_class(Cluster) == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-23 19:20:11.270780
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    pass

# Generated at 2022-06-23 19:20:19.388816
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    example = '''GET /demo HTTP/1.1
Host: httpbin.org
Accept-Encoding: identity
Accept: */*
User-Agent: HTTPie/0.9.2


HTTP/1.1 200 OK
Access-Control-Allow-Credentials: true
Access-Control-Allow-Origin: *
Connection: keep-alive
Content-Length: 2
Content-Type: application/json
Date: Thu, 31 Aug 2017 14:34:57 GMT
Referrer-Policy: no-referrer-when-downgrade
Server: nginx
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block

{}
'''

# Generated at 2022-06-23 19:20:22.245815
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print(ColorFormatter())
    print(ColorFormatter(env=Environment(colors=256)))

# Generated at 2022-06-23 19:20:31.808415
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Simple constructor test
    from httpie.plugins import BuiltinPluginManager
    from contextlib import redirect_stdout
    from io import StringIO
    import sys

    env = Environment(colors=True, stdout=StringIO())
    pm = BuiltinPluginManager()

    fp = ColorFormatter(env, pm)

    assert fp.env is env
    assert fp.explicit_json == False
    assert fp.enabled
    assert fp.output_stream == sys.stdout

    # Check if lexer is initialised
    assert isinstance(fp.formatter, Terminal256Formatter)
    assert fp.formatter.style == Solarized256Style

    assert isinstance(fp.http_lexer, SimplifiedHTTPLexer)

# Generated at 2022-06-23 19:20:39.032848
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    formatter = Terminal256Formatter(
                style=Solarized256Style
            )
    print(pygments.highlight("""
    // An HTTP GET request to https://api.github.com/repos/jakubroztocil/httpie
    GET /repos/jakubroztocil/httpie HTTP/1.1
    Accept: */*
    Accept-Encoding: gzip, deflate
    Connection: keep-alive
    Host: api.github.com
    User-Agent: HTTPie/0.9.2
    """
        ,
        lexer=SimplifiedHTTPLexer(),
        formatter=formatter,
    ))

# Generated at 2022-06-23 19:20:45.539922
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter(None, color_scheme=None)
    assert cf.explicit_json == False
    assert cf.enabled == True
    assert cf.formatter.__class__.__name__ == "TerminalFormatter"
    assert cf.http_lexer.__class__.__name__ == "SimplifiedHTTPLexer"
    assert cf.get_style_class(SOLARIZED_STYLE).__name__ == "Solarized256Style"

# Generated at 2022-06-23 19:20:49.892749
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')
    assert ColorFormatter.get_style_class('solarized') == solarized256.Solarized256Style
    assert ColorFormatter.get_style_class('auto') == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-23 19:20:50.869284
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    print(SimplifiedHTTPLexer())

# Generated at 2022-06-23 19:20:54.843781
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins.colors import ColorFormatter
    assert ColorFormatter.get_style_class("monokai") == pygments.styles.get_style_by_name("monokai")
    assert ColorFormatter.get_style_class("solarized") == Solarized256Style

# Generated at 2022-06-23 19:21:02.983387
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter = ColorFormatter(Environment(), False)

# Generated at 2022-06-23 19:21:09.063900
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class TestEnvironment():
        def __init__(self):
            self.colors = True
    def test(mime, body, expect):
        colorFormatter = ColorFormatter(TestEnvironment())
        lexer = colorFormatter.get_lexer_for_body(mime, body)
        assert str(lexer) == expect
    test('application/json', '{"title": "json"}', 'JSONLexer')
    test('application/json', '{title: "json"}', 'JSONLexer')
    test('application/json', '{"title": json}', 'TextLexer')
    test('application/json', '{title: json}', 'TextLexer')
    test('application/json', '', 'TextLexer')
    test('application/json', 'a', 'TextLexer')

# Generated at 2022-06-23 19:21:20.183924
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.compat import is_windows
    class env:
        colors = None
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_style_class('default') == pygments.styles.get_style_by_name('default')
    assert color_formatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert color_formatter.get_style_class('none') == pygments.styles.get_style_by_name('none')
    assert color_formatter.get_style_class('bw') == pygments.styles.get_style_by_name('bw')

# Generated at 2022-06-23 19:21:21.966461
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style.background_color == "#1c1c1c"

# Generated at 2022-06-23 19:21:30.794271
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment()
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    result = formatter.get_lexer_for_body('application/json', '{"id":1}')
    assert isinstance(result, type(pygments.lexers.JsonLexer()))
    result = formatter.get_lexer_for_body('application/json', '[]')
    assert isinstance(result, type(pygments.lexers.JsonLexer()))
    result = formatter.get_lexer_for_body('application/json', '""')
    assert isinstance(result, type(pygments.lexers.JsonLexer()))
    result = formatter.get_lexer_for_body('application/json', '"{"')
   

# Generated at 2022-06-23 19:21:33.857241
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.core import main
    argv = ['--json', 'httpbin.org/get']
    env = main(argv=argv, env=Environment())
    ColorFormatter(env)

# Generated at 2022-06-23 19:21:35.424842
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(Environment({}))
    assert color_formatter.enabled is False

# Generated at 2022-06-23 19:21:46.104864
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    formatter = ColorFormatter(None)
    assert isinstance(formatter, FormatterPlugin)
    assert formatter.get_lexer_for_body('text/plain', '') == None
    assert formatter.get_lexer_for_body('application/json', '') == None
    assert formatter.get_lexer_for_body('application/json', '{}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('text/html', '<!DOCTYPE html>') == pygments.lexers.get_lexer_by_name('html')

# Generated at 2022-06-23 19:21:55.729521
# Unit test for function get_lexer
def test_get_lexer():
    # Parameter mime can be None
    assert get_lexer(None) is None

    # Parameter mime can be an unknown value
    mime = 'qwerty/qwerty'
    assert get_lexer(mime) is None

    # Parameter mime can be a known value
    mime = 'text/html'
    lexer = get_lexer(mime)
    assert lexer is not None

    # Parameter mime can be a known value, with a suffix
    mime = 'text/html+django'
    lexer = get_lexer(mime)
    assert lexer is not None

    # Parameter mime can be a known value, with a suffix
    # containing an alias (this is the case of Werkzeug)
    mime = 'text/html+jinja'

# Generated at 2022-06-23 19:22:04.342251
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-23 19:22:10.487305
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    # Solarized256Style defines class BASE0, BASE1 and so on,
    # for that reason use class attributes
    for c in ['BASE0', 'BASE1', 'BASE2', 'BASE3', 'YELLOW', 'ORANGE', 'RED',
              'MAGENTA', 'VIOLET', 'BLUE', 'CYAN', 'GREEN']:
        solarized256style = Solarized256Style()
        getattr(solarized256style, c)

# Generated at 2022-06-23 19:22:21.551534
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class DummyEnv:
        colors = True

    class DummyFormatter:
        def __init__(self, env):
            self.env = env

    formatter = DummyFormatter(DummyEnv)
    assert ColorFormatter.get_lexer_for_body(formatter, 'text/html', '')\
        == pygments.lexers.get_lexer_by_name('html')
    assert ColorFormatter.get_lexer_for_body(formatter,
                                             'text/html; charset=utf-8', '')\
        == pygments.lexers.get_lexer_by_name('html')
    assert ColorFormatter.get_lexer_for_body(formatter, 'text/plain', '')\
        == pygments.lexers.get_lexer_by_name

# Generated at 2022-06-23 19:22:27.469790
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    test_case1 = ['GET http://127.0.0.1:5000/path', 'Host: 127.0.0.1:5000', 'User-Agent: curl/7.54.0', 'Accept: */*', '\n']

# Generated at 2022-06-23 19:22:33.900590
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    class MockObject(object):
        def __init__(self):
            self.Style = Solarized256Style

    mock_object = MockObject()

    class MockEnvironment(object):
        def __init__(self):
            self.colors = 256

    color_formatter = ColorFormatter(
        env=MockEnvironment(),
        explicit_json=False,
        color_scheme=SOLARIZED_STYLE,
        style=mock_object.Style
    )

    assert isinstance(color_formatter, FormatterPlugin)

# Generated at 2022-06-23 19:22:39.663681
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Test JSON detection
    mime = 'text/plain'
    body = '{"a": 1}'
    formatter = ColorFormatter()

    lexer = formatter.get_lexer_for_body(mime, body)
    assert lexer.__name__ == 'ascii'
    assert lexer.name == 'Text only'

    lexer = formatter.get_lexer_for_body(mime, body, explicit_json=True)
    assert lexer.__name__ == 'json'
    assert lexer.name == 'JSON'

    # Test that content type is not JSON when it shouldn't be
    mime = 'text/plain'
    body = '{a: 1}'
    lexer = formatter.get_lexer_for_body(mime, body)
    assert lexer

# Generated at 2022-06-23 19:22:41.539961
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True)
    ColorFormatter(env)

# Generated at 2022-06-23 19:22:50.504343
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('application/json')
    assert lexer.name == 'JSON'

    lexer = get_lexer('application/xml')
    assert lexer.name == 'XML'

    lexer = get_lexer('application/vnd.foobar+json')
    assert lexer.name == 'JSON'

    lexer = get_lexer('application/vnd.foobar+xml')
    assert lexer.name == 'XML'

    lexer = get_lexer('application/vnd.foobar+zip')
    assert lexer is None

    lexer = get_lexer('application/x-foobar')
    assert lexer is None  # TODO: Fix me

    lexer = get_lexer('text/plain')
    assert lexer.name == 'Text only'
   

# Generated at 2022-06-23 19:23:01.522528
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import os
    import sys
    import httpie.context
    env = httpie.context.Environment(os.environ, sys.stdin, sys.stdout)
    formatter = ColorFormatter(env)

# Generated at 2022-06-23 19:23:10.975988
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    # Example 1:
    # No lexer found
    assert ColorFormatter(Environment(), color_scheme=None).format_body(
        body='{}', mime='text/html') == '{}'
    # Example 2:
    # Lexer json found
    assert ColorFormatter(Environment(), color_scheme=None).format_body(
        body='{}', mime='application/json') == '{\n    }'
    # Example 3:
    # Lexer json not found
    assert ColorFormatter(Environment(), color_scheme=None).format_body(
        body='[', mime='application/json') == '[\n'

# Generated at 2022-06-23 19:23:15.616519
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin

    env = Environment()
    formatter = ColorFormatter(env=env, explicit_json=False, color_scheme='solarized256')
    assert formatter.get_style_class('solarized256') == Solarized256Style

# Generated at 2022-06-23 19:23:16.509374
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    return Solarized256Style()

# Generated at 2022-06-23 19:23:20.292023
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert [x.name for x in SimplifiedHTTPLexer._tokens['root'][0]] == ['Name.Function', 'Text', 'Name.Namespace', 'Text', 'Keyword.Reserved', 'Operator', 'Number']

if __name__ == '__main__':
    test_SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:23:30.341518
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import sys
    import os
    import io
    import time
    import inspect
    import textwrap
    import pygments.formatters.terminal256

    from httpie.compat import is_windows

    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output import BINARY_SUPPRESSED_HEADERS

    __location__ = os.path.join(os.getcwd(), os.path.dirname(
        inspect.getfile(inspect.currentframe())))

    _env = Environment()

    def _print(message, **kwargs):
        print(message, file=kwargs.get('file', sys.stderr))

    def test_format_colors():
        headers

# Generated at 2022-06-23 19:23:40.032583
# Unit test for function get_lexer
def test_get_lexer():
    from httpie.compat import is_windows
    from httpie import ExitStatus
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import StdoutStream
    import json
    import sys
    import pygments
    import pygments.lexer
    import pygments.lexers
    import pygments.style
    import pygments.styles
    import pygments.token
    from pygments.formatters.terminal import TerminalFormatter
    from pygments.formatters.terminal256 import Terminal256Formatter
    from pygments.lexer import Lexer
    from pygments.lexers.special import TextLexer
    from pygments.lexers.text import HttpLexer as PygmentsHttpLexer
    from pygments.util import ClassNotFound

    from httpie.context import Environment

# Generated at 2022-06-23 19:23:43.869889
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    try:
        import pytest
    except ImportError:
        return
    with pytest.raises(ClassNotFound):
        ColorFormatter.get_style_class('error')

# Generated at 2022-06-23 19:23:45.357687
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    colorFormatter_ins = ColorFormatter(env=Environment(colors=256))

# Generated at 2022-06-23 19:23:49.201927
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    formatter = ColorFormatter('', '')
    style_class = formatter.get_style_class(SOLARIZED_STYLE)
    assert style_class == Solarized256Style

# Generated at 2022-06-23 19:23:51.680551
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class(SOLARIZED_STYLE)
    assert style_class == Solarized256Style

# Generated at 2022-06-23 19:23:55.273406
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style()
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.MonokaiStyle

# Generated at 2022-06-23 19:23:58.571346
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    str_ = 'GET /index.html HTTP/1.1'
    lexer = SimplifiedHTTPLexer()
    assert lexer.get_tokens(str_)


# Generated at 2022-06-23 19:24:09.358447
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class EnvironmentMock(object):
        colors = True
    env = EnvironmentMock()

    # Test with an undefinded mime type
    class ColorFormatterMock(ColorFormatter):
        def __init__(self):
            super().__init__(env, explicit_json=False, color_scheme=DEFAULT_STYLE)

        def get_lexer(self, mime, explicit_json, body):
            self.get_lexer_mime = mime
            self.get_lexer_explicit_json = explicit_json
            self.get_lexer_body = body

            return None

    cf = ColorFormatterMock()
    assert cf.get_lexer_for_body('mime', 'body') is None
    assert cf.get_lexer_mime == 'mime'

# Generated at 2022-06-23 19:24:19.765669
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from io import StringIO
    from httpie import __version__ as httpie_version
    from httpie.cli.context import Environment
    from httpie.config import Config
    from httpie.constants import DEFAULT_UA
    from httpie.plugins.builtin import BuiltinPlugin

    class MockEnvironment(Environment):
        stdin = StringIO('')
        stdout = StringIO()
        stdout_isatty = True

    def create_config(args) -> Config:
        return Config(env=MockEnvironment(),
                      version=httpie_version,
                      config_dir=None,
                      config_paths=None,
                      plugins=[BuiltinPlugin()],
                      cli_args=args)


# Generated at 2022-06-23 19:24:20.825251
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style(Solarized256Style)

# Generated at 2022-06-23 19:24:30.593750
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Tests for lexer
    assert get_lexer(mime='application/json')
    assert get_lexer(mime='text/html')
    assert get_lexer(mime='text/x-python')
    assert get_lexer(mime='text/x-python', explicit_json=True)
    assert get_lexer(mime='', explicit_json=True)
    assert not get_lexer(mime='text/unknown')

    # Tests for json
    assert get_lexer(mime='application/json', body='{"key": "value"}')
    assert not get_lexer(mime='application/json', body='<html></html>')
    assert get_lexer(mime='text/x-python', body='{"key": "value"}')

# Generated at 2022-06-23 19:24:34.419095
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter(None).get_style_class('solarized') == Solarized256Style
    assert ColorFormatter(None).get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter(None, color_scheme='solarized').get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-23 19:24:36.763659
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(env=Environment(), explicit_json=False, color_scheme='solarized256')
    assert formatter.enabled == True

# Generated at 2022-06-23 19:24:46.980380
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.helpers import str_to_bytes

# Generated at 2022-06-23 19:24:49.217484
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()

# Generated at 2022-06-23 19:24:49.660022
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-23 19:24:56.166777
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter.group_name
    import httpie.context
    env = httpie.context.Environment(colors=True)
    ColorFormatter(env=env, explicit_json=False, color_scheme='solarized')
    ColorFormatter(env=env, explicit_json=False, color_scheme='fruity')
    ColorFormatter(env=env, explicit_json=False, color_scheme='auto')



# Generated at 2022-06-23 19:25:04.265163
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from pygments.styles import get_style_by_name
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE

    # Test cases
    test_cases = ['', 'httpie', 'default', 'fruity', 'solarized']

    # Iterate over test cases
    for _ in test_cases:
        _style_class = ColorFormatter.get_style_class(_)
        # Check if the returned class is valid
        assert isinstance(_style_class, type(get_style_by_name(DEFAULT_STYLE)))

    # Test usage of DEFAULT_STYLE when a non-existent style is requested
    _style_class = ColorFormatter.get_style_class('azertyuiop')

# Generated at 2022-06-23 19:25:15.078786
# Unit test for function get_lexer
def test_get_lexer():
    assert not get_lexer(mime=None)
    assert not get_lexer(mime='unknown/unknown')
    assert get_lexer(mime='application/json')
    assert get_lexer(mime='application/json', explicit_json=True)
    assert get_lexer(mime='application/json', explicit_json=True, body='{}')
    assert get_lexer(mime='application/unknown+json', explicit_json=True)
    assert get_lexer(mime='text/plain', explicit_json=True)
    assert get_lexer(mime='text/plain', explicit_json=True, body='{}')
    assert get_lexer(mime='text/html', explicit_json=True, body='{}')

# Generated at 2022-06-23 19:25:19.057960
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print("")
    ColorFormatter(True)
    print("")

if __name__ == '__main__':
    test_ColorFormatter()

# Generated at 2022-06-23 19:25:19.808426
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()

# Generated at 2022-06-23 19:25:28.422391
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import os
    import sys
    from httpie.cli.main import main
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows

    args = [
        '--formatter', 'colors', '--print',
        'GET', 'https://httpie.org'
    ]
    if not is_windows:
        if sys.stdout.fileno() != 1:
            args.insert(0, '--output-file=%s' % os.ttyname(sys.stdout.fileno()))
    env = Environment()
    env.colors = None
    exit_status, output = main(args=args, env=env)

# Generated at 2022-06-23 19:25:29.002491
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    pass

# Generated at 2022-06-23 19:25:34.589638
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    text = """\
GET / HTTP/1.1
Host: example.com
Content-Length: 0

"""

# Generated at 2022-06-23 19:25:40.730927
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie import input

    env = input.Environment()
    color_formatter = ColorFormatter(env)
    # Test 1
    mime_type = 'text/html'
    body = ''
    assert color_formatter.get_lexer_for_body(mime_type, body) is None
    # Test 2
    mime_type = 'text/html'
    body = '<html><head><title>haha</title></head><body><p>haha</p></body></html>'
    assert color_formatter.get_lexer_for_body(mime_type, body).__name__ == 'HTMLLexer'
    # Test 3
    mime_type = 'application/json'
    body = '{"username": "a"}'
    assert color_formatter.get_

# Generated at 2022-06-23 19:25:43.019836
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(
        env= Environment()
    )
    assert formatter.group_name == 'colors'

# Generated at 2022-06-23 19:25:43.696032
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    pass

# Generated at 2022-06-23 19:25:51.279339
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer(mime='application/octet-stream'), TextLexer)
    assert isinstance(get_lexer(mime='application/json'), TextLexer)
    assert isinstance(get_lexer(mime='application/json', explicit_json=True), TextLexer)
    assert isinstance(get_lexer(mime='application/json', explicit_json=True, body='abc'), TextLexer)
    assert isinstance(get_lexer(mime='application/json', explicit_json=True, body='[]'), TextLexer)
    assert isinstance(get_lexer(mime='application/json', explicit_json=True, body='{}'), TextLexer)
    assert isinstance(get_lexer(mime='application/json', body='{}'), TextLexer)


# Generated at 2022-06-23 19:25:53.534132
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style().styles[pygments.token.Name.Class] == "#0087ff"  # blue

# Generated at 2022-06-23 19:26:02.390896
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import is_windows
    from httpie import ExitStatus

    class MockEnvironment(object):
        def __init__(self):
            self.version = '0.0.0'
            self.output_options = 'foo'
            self.timeout = 0
            self.verify = False
            self.stream = False
            self.allow_redirects = True
            self.max_redirects = 10
            self.follow_redirects = True
            self.download = False
            self.download_resume = False
            self.download_insecure = False
            self.download_output = ''
            self.download_disable_progress = False
            self.output_options = 'bar'
            self.output_options = 'baz'
            self.output = None  # type: typing.Optional

# Generated at 2022-06-23 19:26:11.617799
# Unit test for function get_lexer
def test_get_lexer():
    # Get lexer for correct MIME
    lexer = get_lexer(mime='text/html')
    assert lexer.name == 'HTML'

    # Get lexer for incorrect MIME
    lexer = get_lexer(mime='text/something')
    assert not lexer

    # Don't get lexer for JSON when it's only a substring
    lexer = get_lexer(mime='text/html')
    assert lexer.name != 'JSON'

    # Get lexer for JSON when its MIME type is incorrect
    lexer = get_lexer(mime='text/html', explicit_json=True, body='{}')
    assert lexer.name == 'JSON'

    # Don't get lexer for JSON when "--json" is not specified

# Generated at 2022-06-23 19:26:22.010038
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer('application/json'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/foo+json'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/foo+json', explicit_json=True), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/yaml'), pygments.lexers.YamlLexer)
    assert isinstance(get_lexer('application/vnd.foo+yaml'), pygments.lexers.YamlLexer)
    assert isinstance(get_lexer('application/vnd.foo+yaml', explicit_json=True), pygments.lexers.YamlLexer)

# Generated at 2022-06-23 19:26:32.613070
# Unit test for function get_lexer
def test_get_lexer():
    """
    Test that get_lexer maps the right mimetypes and types to the right lexers.
    """

    # Test some well-known mime types.
    lexer = get_lexer('application/json')
    assert lexer == pygments.lexers.data.JsonLexer
    lexer = get_lexer('application/javascript')
    assert lexer == pygments.lexers.data.JavascriptLexer
    lexer = get_lexer('image/svg+xml')
    assert lexer == pygments.lexers.markup.SvgLexer
    lexer = get_lexer('text/plain')
    assert lexer == pygments.lexers.text.TextLexer
    lexer = get_lexer('text/html')
    assert lexer == pygments.lexers.html.H

# Generated at 2022-06-23 19:26:43.817877
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    style = ColorFormatter(None).get_lexer_for_body("application/json",
                                                    '{"hello": "world"}')
    assert style.name == "JSON"
    style = ColorFormatter(None).get_lexer_for_body("application/json",
                                                    '{"hello": "world"}')
    assert style.name == "JSON"
    style = ColorFormatter(None).get_lexer_for_body("application/json",
                                                    '{"hello": "world"}')
    assert style.name == "JSON"
    style = ColorFormatter(None).get_lexer_for_body("application/json",
                                                    '{"hello": "world"}')
    assert style.name == "JSON"
    style = ColorFormatter(None, explicit_json=True).get_lexer

# Generated at 2022-06-23 19:26:44.458952
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:26:50.581486
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    env = Environment(verbose=True)
    formatter = ColorFormatter(env, color_scheme='solarized')

    from httpie.response import Response
    http_lexer = SimplifiedHTTPLexer()
    lexer_html = pygments.lexers.get_lexer_by_name('html')
    text = """\
HTTP/1.1 302 Found
Server: nginx
Date: Mon, 29 Sep 2014 20:23:35 GMT
Content-Length: 0
Connection: keep-alive
Cache-Control: private, must-revalidate
Location: http://www.google.com/
X-XSS-Protection: 1; mode=block
"""
    response = Response(headers=text)
    text_http = formatter.format_headers(text)
    text_html = pygments.highlight

# Generated at 2022-06-23 19:27:00.198306
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from .utils import httpbin
    from . import basics
    from . import json
    from . import xml
    from . import css
    from . import html
    from . import json, json_pretty, json_stream
    from . import js
    from . import text
    from . import http
    from . import http_stream
    from . import default
    from . import redirect
    from . import error
    from . import form
    from . import auth_basic
    from . import auth_digest
    from . import auth_plugin
    from . import session
    from . import https
    from . import websocket

    print("\n\n")
    print("Testing method format_body of class ColorFormatter")
    print("\n")

    env = Environment(colors=True, stdin_isatty=False)
   

# Generated at 2022-06-23 19:27:05.991302
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # given
    environment = Environment(colors=256)
    color_formatter = ColorFormatter(env=environment)

    # when
    lexer = color_formatter.get_lexer_for_body(
        mime='text/plain',
        body='',
    )

    # then
    assert lexer is None

# Generated at 2022-06-23 19:27:15.286960
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    json_body = '{\n    "test_key": "Test value"\n}'
    plain_text_body = 'text'
    html_body = '<!DOCTYPE html>\n<html>\n<body>\n\n<h2>HTML Links</h2>\n<p><a href="http://www.w3schools.com">This is a link</a></p>\n\n</body>\n</html>'

    # Test with json mime
    json_color_formatter = ColorFormatter(None, False)
    assert json_color_formatter.format_body(json_body) == json_body

    # Test with plain text mime
    plain_color_formatter = ColorFormatter(None, False)
    assert plain_color_formatter.format_body

# Generated at 2022-06-23 19:27:23.874889
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-23 19:27:30.407618
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='text/plain') == pygments.lexers.get_lexer_by_name('text')
    assert get_lexer(mime='text/html') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer(mime='application/json') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:27:39.806158
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    supported_styles = set()
    for style in pygments.styles.STYLE_MAP:
        supported_styles.add(style)

    color_formatter = ColorFormatter(Environment())

    for style in supported_styles:
        color_formatter.get_style_class(style)

    last_style = 'AtelierSulphurpoolLight'
    assert color_formatter.get_style_class(last_style) is not None
    assert color_formatter.get_style_class(last_style.upper()) is not None
    assert color_formatter.get_style_class(last_style.lower()) is not None

    assert color_formatter.get_style_class('non_exists') is None

# Generated at 2022-06-23 19:27:40.573682
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:27:47.021537
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    import pygments.styles.solarized
    assert ColorFormatter.get_style_class('solarized') == pygments.styles.solarized.SolarizedStyle
    assert ColorFormatter.get_style_class('solarized256') == pygments.styles.solarized.SolarizedStyle
    assert ColorFormatter.get_style_class('badstyle') == Solarized256Style

# Generated at 2022-06-23 19:27:57.596499
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formater = ColorFormatter(Environment({"colors": True}))
    assert isinstance(formater.formatter, TerminalFormatter)
    assert isinstance(formater.http_lexer, PygmentsHttpLexer)

    formater = ColorFormatter(Environment({"colors": True}),
                              color_scheme="monokai")
    assert isinstance(formater.formatter, TerminalFormatter)
    assert isinstance(formater.http_lexer, PygmentsHttpLexer)

    formater = ColorFormatter(Environment({"colors": 256}))
    assert isinstance(formater.formatter, Terminal256Formatter)
    assert isinstance(formater.http_lexer, SimplifiedHTTPLexer)

# Generated at 2022-06-23 19:28:01.398758
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    body = 'Foo: xxx\nBar: yyy'

    env = Environment()
    env.colors = True
    c = ColorFormatter(env=env)

    assert c.format_headers(body) == (
        '\x1b[90mFoo\x1b[39m: xxx\n\x1b[90mBar\x1b[39m: yyy'
    )

# Generated at 2022-06-23 19:28:11.998374
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import sys
    import os
    # set explicit_json
    explicit_json = False
    
    # set ColorFormatter's output
    color_format = ColorFormatter(
        env = Environment(is_windows = False, colors = 256),
        explicit_json = explicit_json,
        color_scheme = DEFAULT_STYLE,
    )

    # set header
    header = 'Access-Control-Allow-Credentials: true\n'
    header += 'Access-Control-Allow-Origin: http://localhost:8080\n'
    header += 'Content-Type: application/json\n'
    header += 'Date: Wed, 04 Dec 2019 02:48:15 GMT\n'

# Generated at 2022-06-23 19:28:18.727570
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter=ColorFormatter(Environment(colors=True,style=None))
    assert formatter.formatter.__class__.__name__=='Terminal256Formatter'
    assert formatter.explicit_json==None
    formatter=ColorFormatter(Environment(colors=True,style='solarized'),color_scheme='solarized',explicit_json=True)
    assert formatter.explicit_json==True
    formatter=ColorFormatter(Environment(colors=True,style=None))
    assert formatter.formatter.__class__.__name__=='Terminal256Formatter'

# Generated at 2022-06-23 19:28:28.959918
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import io
    from httpie.context import Environment
    init_stdout_and_stderr = io.StringIO()
    env = Environment(stdout=init_stdout_and_stderr)
    assert env.colors is True
    assert env.stdout == init_stdout_and_stderr

    init_stdout_and_stderr = io.StringIO()
    env = Environment(stdout=init_stdout_and_stderr)
    assert env.colors is True
    assert env.stdout == init_stdout_and_stderr

    init_stdout_and_stderr = io.StringIO()
    env = Environment(stdout=init_stdout_and_stderr)
    assert env.colors is True
    assert env.stdout == init_

# Generated at 2022-06-23 19:28:32.603755
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment(colors=True)
    color_formatter = ColorFormatter(env)

    body = '{"name":"test"}'
    assert color_formatter.format_body(body, 'application/json')

# Generated at 2022-06-23 19:28:43.197673
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from utils import TestEnvironment
    env = TestEnvironment()
    assert ColorFormatter(env, color_scheme='solarized')
    assert ColorFormatter(env, color_scheme='monokai')
    assert ColorFormatter(env, color_scheme='default')
    assert ColorFormatter(env, color_scheme='solarized').formatter
    assert ColorFormatter(env, color_scheme='monokai').formatter
    assert ColorFormatter(env, color_scheme='default').formatter
    assert ColorFormatter(env, color_scheme='solarized').http_lexer
    assert ColorFormatter(env, color_scheme='monokai').http_lexer
    assert ColorFormatter(env, color_scheme='default').http_lexer


# Generated at 2022-06-23 19:28:54.902037
# Unit test for method format_body of class ColorFormatter

# Generated at 2022-06-23 19:29:04.061426
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.client import http
    from httpie.compat import urlunparse
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.output.streams import STREAM_CONSOLE_SIMPLE
    base_url = 'http://localhost:9999/get'
    args = ['-j']
    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        stdout_isatty=True,
        stdin_isatty=True,
        color=True,
    )
    content_type = "application/json"

# Generated at 2022-06-23 19:29:14.187156
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import os, sys
    os.environ["HTTPIE_COLORS"] = "256"
    sys.modules["httpie.plugins"] = FormatterPlugin
    sys.modules["httpie.context"] = Environment
    color_formatter = ColorFormatter('HTTP/1.1', "201", None, None, None, None)
    assert color_formatter.enabled
    color_formatter2 = ColorFormatter('HTTP/1.1', "201", None, None, None, None, color_scheme="fruity")
    assert color_formatter2.enabled
    color_formatter3 = ColorFormatter('HTTP/1.1', "201", None, None, None, None, color_scheme="solarized")
    assert color_formatter3.enabled

# Generated at 2022-06-23 19:29:25.509921
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from datetime import datetime
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.formatter import get_preferred_set_plugin
    from httpie.plugins.colors import ColorFormatter
    env = Environment()
    plugin = ColorFormatter(env=env)
    body = '''{ 
        "name": "apple", 
        "price": 1.5, 
        "stock": 5,
        "expire": "2020-09-10 00:00:00"
    }'''
    body = plugin.format_body(body, 'application/json')
    # print(body)