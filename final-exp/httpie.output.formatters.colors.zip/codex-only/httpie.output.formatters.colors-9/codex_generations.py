

# Generated at 2022-06-23 19:19:28.887769
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import sys
    import datetime
    import time
    import json
    json_recieved = '{"s": 1, "d": {"p1": [1,2], "p2": "v2"} }'
    json_expected = '{\n    "s": 1,\n    "d": {\n        "p1": [\n            1,\n            2\n        ],\n        "p2": "v2"\n    }\n}'
    print(json_recieved)
    print(json_expected)
    assert(json_expected == json.dumps(json_recieved, sort_keys=True, indent=4, separators=(',', ': ')))
    assert(json_recieved == json.loads(json_expected))

test_ColorFormatter_format_body()

# Generated at 2022-06-23 19:19:33.603124
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class("solarized")
    assert style == Solarized256Style
    style = ColorFormatter.get_style_class("no_such_style")
    assert style == pygments.styles.get_style_by_name("default")

# Generated at 2022-06-23 19:19:38.195791
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()
    assert s.background_color == "#1c1c1c"
    assert s.styles[pygments.token.Token.Other] == "#d75f00"

# Generated at 2022-06-23 19:19:39.285049
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    r = SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:19:47.451786
# Unit test for function get_lexer
def test_get_lexer():
    def check_lexer_attribution(mime, body, expected_lexer):
        assert get_lexer(mime=mime, body=body).__name__ == expected_lexer.__name__
    check_lexer_attribution('application/json', '', pygments.lexers.get_lexer_by_name('json'))
    check_lexer_attribution('application/javascript', '', pygments.lexers.get_lexer_by_name('javascript'))
    check_lexer_attribution('application/json', '1', pygments.lexers.get_lexer_by_name('json'))
    check_lexer_attribution('application/javascript', '1', pygments.lexers.get_lexer_by_name('javascript'))

# Generated at 2022-06-23 19:19:49.408175
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    #To-Do: write test
    return True


# Generated at 2022-06-23 19:19:55.131410
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    print(pygments.highlight(
        'GET /foo HTTP/1.1\n'
        'Content-Type: application/json\n'
        'Authorization: Bearer 123...\n'
        '\n'
        '{}',
        SimplifiedHTTPLexer(),
        Terminal256Formatter(
            style=Solarized256Style
        )
    ))



# Generated at 2022-06-23 19:19:55.606196
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    pass



# Generated at 2022-06-23 19:19:56.703370
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    l = SimplifiedHTTPLexer()
    assert isinstance(l, SimplifiedHTTPLexer)

# Generated at 2022-06-23 19:19:58.937036
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('default') == Terminal256Formatter.style

# Generated at 2022-06-23 19:20:00.637389
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    """
    Solarized256Style should have the proper attributes.
    """
    assert str(Solarized256Style).find("Solarized256Style") >= 0

# Generated at 2022-06-23 19:20:02.860431
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers = '''Content-Type: application/json\r\nContent-Length: 514\r\nHost: 127.0.0.1:5000\r\nX-Powered-By: Express\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\n\r\n'''
    assert True

# Generated at 2022-06-23 19:20:09.950390
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    tokens = lexer.get_tokens('GET /demo HTTP/1.1\r\n'
        'Host: httpbin.org\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Accept: */*\r\n'
        'User-Agent: HTTPie/1.0.2\r\n'
        '\r\n'
    )
    assert tokens

# Generated at 2022-06-23 19:20:18.434816
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    formatter = ColorFormatter(
        env=Environment(colors=256),
        color_scheme='solarized',
        explicit_json=False,
    )
    headers = """\
GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: python-requests/2.21.0
"""

# Generated at 2022-06-23 19:20:24.933725
# Unit test for function get_lexer
def test_get_lexer():
    assert not get_lexer('text/plain')
    assert not get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('text/x-json')
    assert get_lexer('text/x-json', explicit_json=True)

# Generated at 2022-06-23 19:20:34.335460
# Unit test for function get_lexer
def test_get_lexer():
    class JSONLexer(TextLexer):
        name = 'json'
        mimetypes = ['application/json']

    class JsonLexer(TextLexer):
        name = 'json'
        mimetypes = ['application/json']

    class XJSONLexer(TextLexer):
        name = 'XJSON'
        mimetypes = ['application/xjson']

    class JsonDataLexer(TextLexer):
        name = 'JSONData'
        mimetypes = ['text/jsondata']

    def get_lexer(mime, explicit_json=False, body=''):
        return get_lexer(mime, explicit_json, body)

    assert get_lexer('application/json') is JSONLexer
    assert get_lexer('application/json', explicit_json=True) is JSONLex

# Generated at 2022-06-23 19:20:46.170054
# Unit test for function get_lexer
def test_get_lexer():
    def check_lexer_name(mime, body, expected):
        assert get_lexer(mime, False, body).name == expected

    # Custom
    check_lexer_name('application/vnd.httpie.test', '', 'Text only')
    check_lexer_name('application/vnd.httpie.test+xml', '', 'XML')
    check_lexer_name('application/vnd.httpie.test+json', '', 'JSON')
    check_lexer_name('application/vnd.httpie+json', '', 'JSON')
    check_lexer_name('application/vnd.httpie+json-seq', '', 'JSON')
    check_lexer_name('application/vnd.httpie+msgpack', '', 'Text only')

    # HTTP
    check

# Generated at 2022-06-23 19:20:48.821368
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style().background_color == "#1c1c1c"
    assert Solarized256Style().styles[pygments.token.Token.Other] == "#af8700"



# Generated at 2022-06-23 19:20:53.037189
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    """
    Tests the constructor of the SimplifiedHTTPLexer class.
    """
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-23 19:20:54.085614
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    print(Solarized256Style)

# Generated at 2022-06-23 19:21:01.978576
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env=env, color_scheme='solarized')

# Generated at 2022-06-23 19:21:06.867293
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True)
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter
    assert color_formatter.http_lexer
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, color_scheme='256')
    assert color_formatter.formatter
    assert color_formatter.http_lexer



# Generated at 2022-06-23 19:21:18.064290
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()

    def run_format_body(mime, body, *args, **kwargs):
        return ColorFormatter(env=env, *args, **kwargs).format_body(body, mime)

    # Unknown mime
    assert run_format_body('application/unknown', '123') == '123'

    # Everything should be html-escaped
    assert run_format_body('text/plain', '<>&') == '&lt;&gt;&amp;'

    # No HTML tag => no escaping
    assert run_format_body('text/html', '123') == '123'

    # Unknown json mime
    assert run_format_body('application/unknown', '{}') == '{}'

    # Unknown html mime

# Generated at 2022-06-23 19:21:23.984882
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('text/plain')
    assert isinstance(lexer, type)

    lexer = get_lexer('application/json')
    assert isinstance(lexer, type)

    lexer = get_lexer('application/json', explicit_json=True, body='{}')
    assert lexer.name == 'JSON'

# Generated at 2022-06-23 19:21:26.221939
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class('solarized')
    assert style_class == Solarized256Style

# Generated at 2022-06-23 19:21:28.048383
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('text/x-foo')
    assert lexer == pygments.lexers.get_lexer_by_name('text')

# Generated at 2022-06-23 19:21:33.228381
# Unit test for function get_lexer
def test_get_lexer():
    get_lexer('application/json')  # Doesn't raise
    get_lexer('application/python-json')  # Doesn't raise
    get_lexer('application/xml')  # Doesn't raise
    get_lexer('something/weird')  # Doesn't raise
    assert get_lexer('unknown/unknown') is None

# Generated at 2022-06-23 19:21:40.555250
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') is not None
    assert get_lexer('application/json', explicit_json=True) is not None
    assert get_lexer('application/json', body='{"a": 1}') is not None
    assert get_lexer('application/json', explicit_json=True, body='{"a": 1}') is not None

    assert get_lexer('application/json', body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None

    assert get_lexer('application/problem+json') is not None
    assert get_lexer('application/problem+json', explicit_json=True) is not None
    assert get_lexer('application/problem+json', body='{"a": 1}') is not None
    assert get_

# Generated at 2022-06-23 19:21:43.553571
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    colorformatter = ColorFormatter(Environment(), color_scheme='256')
    assert isinstance(colorformatter.formatter, Terminal256Formatter)

# Generated at 2022-06-23 19:21:50.526680
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins import builtin

    color_formatter = builtin.ColorFormatter(
        color_scheme='monokai',
        explicit_json=False,
        env=None,
    )

    style = color_formatter.get_style_class('monokai')
    assert style.__name__ == 'MonokaiStyle'

    style = color_formatter.get_style_class('Solarized256Style')
    assert style.__name__ == 'Solarized256Style'

    style = color_formatter.get_style_class('not_existed_style')
    assert style.__name__ == 'MonokaiStyle'

# Generated at 2022-06-23 19:21:52.979296
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    """
    This function tests the constructor of class Solarized256Style.
    """
    style = Solarized256Style()
    assert isinstance(style, Solarized256Style)

# Generated at 2022-06-23 19:21:56.599176
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    colorFormatter = ColorFormatter(env)
    assert colorFormatter.enabled is True
    env.colors = False
    colorFormatter = ColorFormatter(env)
    assert colorFormatter.enabled is False

# Generated at 2022-06-23 19:21:59.048972
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    assert ColorFormatter(env, explicit_json, color_scheme)

# Generated at 2022-06-23 19:22:01.197554
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    try:
        style = Solarized256Style()
    except Exception as e:
        assert False, "Exception occurred %s" % e

# Generated at 2022-06-23 19:22:07.838208
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    """Unit test for constructor of class SimplifiedHTTPLexer."""
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-23 19:22:10.714590
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True)
    f = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    return f

# Generated at 2022-06-23 19:22:21.787301
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.core import main

    env = Environment(stdout=None, stdin=None)
    formatter = ColorFormatter(env)
    http_response = b"""HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Type: text/plain

"""
    assert isinstance(formatter.get_lexer_for_body(
        mime='text/plain', body=http_response.decode('utf-8')
    ), type(pygments.lexers.get_lexer_by_name('text')))


# Generated at 2022-06-23 19:22:23.381174
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer is not None

# Generated at 2022-06-23 19:22:26.400093
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # TODO: this test is broken and doesn't test anything.
    assert ColorFormatter.get_style_class(None) == pygments.styles.get_style_by_name(None)

# Generated at 2022-06-23 19:22:31.516789
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') is None
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/ld+json') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:22:36.946230
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert(color_formatter.formatter.__str__() == '<Terminal256Formatter style=<class \'httpie.plugins.colors.Solarized256Style\'>>')

    env.colors = 16
    color_formatter = ColorFormatter(env)
    assert(color_formatter.formatter.__str__() == '<TerminalFormatter>')

    env.colors = False
    color_formatter = ColorFormatter(env)
    assert(color_formatter.formatter == None)


# Generated at 2022-06-23 19:22:42.660748
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='application/json')
    assert get_lexer(mime='application/json+utf8')
    assert get_lexer(mime='application/json', explicit_json=True)
    assert get_lexer(mime='application/javascript')

# Generated at 2022-06-23 19:22:46.928828
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import logging
    import tempfile
    import httpie
    import os
    import shutil

    logger = logging.getLogger('httpie')
    logger.setLevel(logging.DEBUG)
    fh = logging.FileHandler(tempfile.mktemp())
    fh.setLevel(logging.DEBUG)
    logger.addHandler(fh)

    env = httpie.Environment()
    for kw in [
        'explicit_json',
        'color_scheme',
    ]:
        setattr(env, kw, getattr(kw))

    ColorFormatter(env)
    logger.removeHandler(fh)
    fh.close()
    shutil.rmtree(os.path.dirname(fh.baseFilename), ignore_errors=True)

# Generated at 2022-06-23 19:22:58.563787
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style.__name__ == "Solarized256Style"
    assert Solarized256Style.background_color == Solarized256Style.BASE03

# Generated at 2022-06-23 19:23:06.014798
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from . import colors

    colors.init()
    env = colors.Environment(colors=256)
    formatter = ColorFormatter(env)
    assert formatter.http_lexer.__class__.__name__ == "SimplifiedHTTPLexer"
    assert formatter.formatter.__class__.__name__ == "Terminal256Formatter"
    assert formatter.formatter.style.__name__ == "Solarized256Style"

# Generated at 2022-06-23 19:23:16.597053
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPluginManager
    from httpie.compat import irange

    env = Environment(stdin=None,
                      stdout=None,
                      stderr=None,
                      colors=256,
                      style=['solarized256'],
                      download_rate_limit=None,
                      max_fields=None,
                      max_content_length=None)

    manager = FormatterPluginManager(env)
    plugin = manager._plugin_group_names['colors'][3]


# Generated at 2022-06-23 19:23:17.742501
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style

# Generated at 2022-06-23 19:23:27.454904
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class CustomStyle(pygments.style.Style):
        ...

    class FakeLexer(object):
        """Fake Lexer Class

        Represents a lexer class to test the code branch which checks
        if given style class is subclass of `pygments.style.Style`.
        """
        ...

    style_cls = ColorFormatter.get_style_class('fruity')
    assert issubclass(style_cls, pygments.style.Style)

    style_cls = ColorFormatter.get_style_class('fruity')
    assert issubclass(style_cls, pygments.style.Style)

    style_cls = ColorFormatter.get_style_class('solarized')
    assert issubclass(style_cls, pygments.style.Style)

    style_cls = ColorFormatter

# Generated at 2022-06-23 19:23:29.128767
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style

# Generated at 2022-06-23 19:23:39.114001
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import bytes
    from httpie.context import Environment

    env = Environment(colors=256)
    color_formatter = ColorFormatter(
        explicit_json=False,
        env=env,
        color_scheme=DEFAULT_STYLE,
    )

    # Testtexts:
    json_txt = bytes('{\n\n    "test": "this is a test"\n}', 'utf-8')
    json_txt_wrong_ct = bytes('[1, 2, 3]', 'utf-8')
    ndjson_txt = bytes('{"this": "is", "an": "ndjson"}\n{"test": true}\n', 'utf-8')

    # Check for correct lexer for json and json-like mime types.

# Generated at 2022-06-23 19:23:45.436489
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(
        env=Environment(colors=False),
        explicit_json=False,
        color_scheme='auto',
    )
    assert color_formatter.get_lexer_for_body(
        mime='text/plain'
    ) is None
    assert color_formatter.get_lexer_for_body(
        mime='text/html'
    ) is pygments.lexers.get_lexer_by_name('html')
    assert color_formatter.get_lexer_for_body(
        mime='text/xml'
    ) is pygments.lexers.get_lexer_by_name('xml')

# Generated at 2022-06-23 19:23:47.593703
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('native') == pygments.styles.native

# Generated at 2022-06-23 19:23:56.116769
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    color_formatter = ColorFormatter(env)
    if not env.colors:
        assert color_formatter.enabled == False
        return
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True
    assert color_formatter.formatter.get_style_defs() == ""
    assert color_formatter.http_lexer.name == "HTTP"
    assert color_formatter.name == "colors"
    assert color_formatter.group_name == "colors"


# Generated at 2022-06-23 19:23:57.783212
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style
    assert style.background_color == "#1c1c1c"
    assert style.styles[pygments.token.Keyword] == "#5f8700"

# Generated at 2022-06-23 19:24:05.409673
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(
        Environment(
            colors=256,
            isatty=True
        ),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    json_string = '{"key":"value"}'
    lexer = color_formatter.get_lexer_for_body(
        'application/json',
        json_string,
    )
    assert lexer is not None

# Generated at 2022-06-23 19:24:13.411331
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import re
    import unittest

    from .colors import ColorFormatter

    headers_str = '''GET / HTTP/1.1
Host: localhost:5000
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.8


'''

    # Create formatter with default parameters for attributes
    cformatter = ColorFormatter(None, None)
    res = cformatter.format_headers(headers_str)

    # Check some headers keywords
    assert re.search('\x1b\[33mGET', res)
    assert re.search('\x1b\[32m\x1b\[1mHTTP\/1.1', res)
    assert re.search('\x1b\[32mHost', res)


# Generated at 2022-06-23 19:24:14.587098
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    clf = ColorFormatter(Environment(colors=True))

    assert clf.get_lexer_for_body('text/plain','') == TextLexer

# Generated at 2022-06-23 19:24:20.802103
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    for code in [
        ('POST / HTTP/1.1\n'
         'Host: example.org\n'
         'Content-Length: 7\n'
         '\n'
         'foo=123'),
        ('HTTP/1.1 200 OK\n'
         'Content-Length: 7\n'
         '\n'
         'foo=123'),
    ]:
        assert code == pygments.highlight(
            code,
            lexer=SimplifiedHTTPLexer(),
            formatter=Terminal256Formatter(
                style=Solarized256Style
            )
        )

# Generated at 2022-06-23 19:24:30.557206
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import os
    import tempfile

    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin

    class Response:
        headers = {
            "content-type": "application/json"
        }
        text = ""
        status_code = 200

    class Request:
        pass

    class Session():
        pass

    class ExitStatus:
        ok = 0

    class Counter:
        def __init__(self):
            self.value = 0
        def inc(self, x=1):
            self.value += x

    def get_base_dir():
        return os.path.join(os.path.dirname(__file__), '..')

    def get_config_dir():
        return DEFAULT_CONFIG_DIR

   

# Generated at 2022-06-23 19:24:38.396811
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import Output, DummyOutput
    import httpie.plugins
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    output = Output(DummyOutput(), env)
    formatter.set_output(output)

# Generated at 2022-06-23 19:24:39.874070
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()  # pragma: no cover

# Generated at 2022-06-23 19:24:40.477130
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-23 19:24:49.239856
# Unit test for function get_lexer
def test_get_lexer():
    def test_lexer_for_mimetype(mime, expected_lexer):
        mime_types, lexer_names = [mime], []
        type_, subtype = mime.split('/', 1)
        if '+' not in subtype:
            lexer_names.append(subtype)
        else:
            subtype_name, subtype_suffix = subtype.split('+', 1)
            lexer_names.extend([subtype_name, subtype_suffix])
            mime_types.extend([
                '%s/%s' % (type_, subtype_name),
                '%s/%s' % (type_, subtype_suffix)
            ])
        assert get_lexer(mime) == pygments.lexers.get_lex

# Generated at 2022-06-23 19:24:59.489482
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    """Test ColorFormatter.format_headers."""
    from .utils import MockEnvironment, MockResponse
    from httpie.compat import urlopen
    from io import BytesIO

    env = MockEnvironment(colors=256, stdout_isatty=True)
    request_data = {
        'method': 'GET',
        'url': 'http://httpbin.org/',
        'headers': {'Accept': 'application/json'},
        'data': None,
        'json': None,
        'files': None,
        'auth': None,
        'auth_type': None,
        'allow_redirects': True,
        'verify': False,
        'timeout': None,
        'max_redirects': 10
    }
    # Formatted headers

# Generated at 2022-06-23 19:25:06.594311
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    fe = ColorFormatter()
    headers = 'GET / HTTP/1.1\nHost: www.example.com\nCache-Control: no-cache'
    expected = '\x1b[32mGET\x1b[39m \x1b[34m/\x1b[39m ' + \
               '\x1b[32mHTTP\x1b[39m/\x1b[32m1.1\x1b[39m\n' + \
               '\x1b[34mHost\x1b[39m: \x1b[33mwww.example.com\x1b[39m\n' +\
               '\x1b[34mCache-Control\x1b[39m: \x1b[33mno-cache\x1b[39m'

# Generated at 2022-06-23 19:25:16.721301
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie import ExitStatus
    from httpie.__main__ import get_exit_status
    from httpie.core import main
    from httpie.plugins import plugin_manager
    from httpie.input import SEP_CREDENTIALS
    from tests import http, HTTP_OK
    import pytest
    from pprint import pprint


# Generated at 2022-06-23 19:25:26.795158
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-23 19:25:31.827468
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    colorFormatter = ColorFormatter(env=Environment())
    assert colorFormatter.formatter == TerminalFormatter()
    assert colorFormatter.http_lexer == PygmentsHttpLexer()

    colorFormatter = ColorFormatter(env=Environment(colors=256))
    assert colorFormatter.formatter == Terminal256Formatter(
        style=Solarized256Style)
    assert colorFormatter.http_lexer == SimplifiedHTTPLexer()

    colorFormatter = ColorFormatter(
        env=Environment(colors=256), color_scheme='solarized')
    assert colorFormatter.formatter == Terminal256Formatter(
        style=Solarized256Style)

    colorFormatter = ColorFormatter(
        env=Environment(colors=256), color_scheme='colorful')
    assert colorFormatter.form

# Generated at 2022-06-23 19:25:39.688307
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment

    class ColorFormatter(FormatterPlugin):
        @staticmethod
        def get_style_class(color_scheme: str) -> Type[pygments.style.Style]:
            try:
                return pygments.styles.get_style_by_name(color_scheme)
            except ClassNotFound:
                return Solarized256Style

    # when use_auto_style or not has_256_colors
    test_color_scheme1 = 'monokai'
    has_256_colors = True
    if is_windows:
        has_256_colors = False
    assert ColorFormatter.get_style_class(test_color_scheme1) == pygments.styles.get

# Generated at 2022-06-23 19:25:48.036533
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class TestFormatter:
        pass

    test_formatter = TestFormatter()

    test_formatter.color_scheme = 'solarized'
    assert ColorFormatter.get_style_class(test_formatter) == Solarized256Style

    test_formatter.color_scheme = 'fruity'
    assert ColorFormatter.get_style_class(test_formatter) == pygments.styles.get_style_by_name('fruity')

    test_formatter.color_scheme = 'auto'
    assert ColorFormatter.get_style_class(test_formatter) == pygments.styles.get_style_by_name('native')

# Generated at 2022-06-23 19:25:51.751872
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class DummyColorFormatter(ColorFormatter):
        pass
    assert DummyColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-23 19:25:58.090012
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers_str = b"""
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 7

abc=123
"""
    expected_headers_str = headers_str.decode().strip()

    # noinspection PyTypeChecker
    res = ColorFormatter(env=None).format_headers(headers_str.decode())

    assert res == expected_headers_str

# Generated at 2022-06-23 19:26:09.483688
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter = ColorFormatter(Environment())
    import sys
    import io
    sys.stderr = io.StringIO()

# Generated at 2022-06-23 19:26:18.688722
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('').__name__ == 'NoStyle'
    assert ColorFormatter.get_style_class('solarized').__name__ == 'Solarized256Style'
    assert ColorFormatter.get_style_class('Solarized256Style').__name__ == 'Solarized256Style'

    assert ColorFormatter.get_style_class('auto').__name__ == 'Solarized256Style'
    assert ColorFormatter.get_style_class('fruity').__name__ == 'Fruity'
    assert ColorFormatter.get_style_class('monokai').__name__ == 'Monokai'
    assert ColorFormatter.get_style_class('vim').__name__ == 'Vim'

# Generated at 2022-06-23 19:26:29.027372
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Test JSON body
    env = Environment(colors=256)
    formatter = ColorFormatter(env, None)
    body = '{"foo":"bar"}'
    assert formatter.get_lexer_for_body(mime="text/html", body=body) == pygments.lexers.get_lexer_by_name("json")

    # Test non-JSON body
    body = '<foo>bar</foo>'
    assert formatter.get_lexer_for_body(mime="text/html", body=body) == pygments.lexers.get_lexer_by_name("html")

    # Test non existing mimetype
    body = "<html><body><h1>Hello World!</h1></body></html>"

# Generated at 2022-06-23 19:26:35.470867
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main as core_main

    def run_test(args: str, expected_output: str) -> None:
        out = core_main(args=args.split(' '))
        assert expected_output in out
        assert expected_output == out.strip()

    instance = ColorFormatter(env=None)

    # Normal HTTP headers
    run_test(args='echo -H "Accept: text/plain"',
             expected_output='<35>Accept<39>: <36>text/plain<39>')

    # Status line: request line
    run_test(args='echo -H "GET / HTTP/1.1"',
             expected_output='<33>GET<39> <37>/<39> <33>HTTP<39>/<36>1.1<39>')

    # Status line

# Generated at 2022-06-23 19:26:40.577891
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

    assert 'root' in lexer.tokens

if __name__ == "__main__":
    # test for the class constructor
    test_SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:26:43.988860
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('vim') == pygments.styles.get_style_by_name('vim')
    assert ColorFormatter.get_style_class('none') == None

# Generated at 2022-06-23 19:26:54.317766
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') is None
    assert get_lexer('text/html+json') is None
    assert get_lexer('application/json')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='<html>') is None
    assert get_lexer('application/json+xml') is None
    assert get_lexer('application/json+xml', body='{"a":1}') is None
    assert get_lexer('application/json+xml', body='<html>') is None
    assert get_lexer('application/json+xml', explicit_json=True, body='{}')

# Generated at 2022-06-23 19:26:57.531981
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    h = """\nGET / HTTP/1.1""".split('\n')
    for t in SimplifiedHTTPLexer().get_tokens('\n'.join(h)):
        print(t)



# Generated at 2022-06-23 19:26:59.195343
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/xml')
    assert get_lexer('text/markdown')
    assert get_lexer('image/jpeg')
    assert not get_lexer('image/unknown')

# Generated at 2022-06-23 19:27:07.045871
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class EnvStub:
        def __init__(self):
            self.colors = 256

    class FormatterStub(ColorFormatter):
        def get_style_class(self, color_scheme):
            return pygments.styles.get_style_by_name

    env = EnvStub()

    body = """
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Test theme</title>
</head>
<body>
<h1>Hello World!</h1>
<p>This is a test theme.</p>
<p>This is a <a href="https://example.com/">link</a></p>
</body>
</html>
"""

# Generated at 2022-06-23 19:27:09.841776
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']
    assert lexer.tokens

# Generated at 2022-06-23 19:27:21.118636
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    text = """HTTP/1.1 200 OK\r\nDate: Wed, 08 Jan 2020 15:34:05 GMT\r\nContent-Type: application/json\r\n\r\n{\r\n    "data": {\r\n        "auth_status": "success"\r\n    },\r\n    "message": "Authentication successful"\r\n}"""
    from httpie.output.formatters import JSONFormatter
    json_formatter = JSONFormatter(
        indent=4
    )
    from httpie.cli.shell import Shell
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment

    class MockConsole(object):
        def __init__(self):
            self.output_encoding = 'utf8'
            self.is_a_tty = True


# Generated at 2022-06-23 19:27:28.426542
# Unit test for function get_lexer
def test_get_lexer():

    assert isinstance(get_lexer(
        'text/plain'), pygments.lexers.TextLexer)

    assert isinstance(get_lexer(
        'text/html'), pygments.lexers.HtmlLexer)

    assert isinstance(get_lexer(
        'application/javascript'), pygments.lexers.JavascriptLexer)

    assert isinstance(get_lexer(
        'application/json'), pygments.lexers.JsonLexer)

    assert isinstance(get_lexer(
        'image/jpeg', explicit_json=True,
        body='{"foo": "bar"}'), pygments.lexers.JsonLexer)


# Generated at 2022-06-23 19:27:38.825414
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    colorFormatter = ColorFormatter()
    mimetype = "text/html"
    body = '<html></html>'
    assert colorFormatter.get_lexer_for_body(mime=mimetype, body=body).__name__ == "HtmlLexer"

    mimetype = "application/json"
    body = '{"text":"data"}'
    assert colorFormatter.get_lexer_for_body(mime=mimetype, body=body).__name__ == "JsonLexer"

    mimetype = "text/xml"
    body = '<xml></xml>'
    assert colorFormatter.get_lexer_for_body(mime=mimetype, body=body).__name__ == 'XmlLexer'


# Generated at 2022-06-23 19:27:48.295573
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # "application/json" -> "json", "application/json" -> "json"
    color_formatter = ColorFormatter(None, False)
    assert color_formatter.get_lexer_for_body(
        mime="application/json", body="{}"
    ).name == "json"
    assert color_formatter.get_lexer_for_body(
        mime="application/json", body="{}"
    ).mimetypes == ("application/json",)

    # "application/json" -> "json", "application/json+json" -> "json"
    color_formatter = ColorFormatter(None, False)
    assert color_formatter.get_lexer_for_body(
        mime="application/json", body="{}"
    ).name == "json"
    assert color_form

# Generated at 2022-06-23 19:27:51.076865
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    """Test Solarized256Style for a constructor"""
    Solarized256Style()

# Generated at 2022-06-23 19:27:52.092196
# Unit test for function get_lexer

# Generated at 2022-06-23 19:27:55.800002
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    t = SimplifiedHTTPLexer()
    assert t.name == 'HTTP'
    assert t.aliases == ['http']
    assert t.filenames == ['*.http']

# Generated at 2022-06-23 19:27:57.919270
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class('solarized256')
    assert style_class == Solarized256Style

# Generated at 2022-06-23 19:28:03.950640
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    # Request-Line

# Generated at 2022-06-23 19:28:11.275903
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from . import colors
    env = colors.Environment()
    f = colors.ColorFormatter(env)

    # test if colorformatter returns the right lexer
    assert not f.get_lexer_for_body('image/png', '')
    assert f.get_lexer_for_body('application/json', '')
    assert f.get_lexer_for_body('application/json', 'asdf')
    assert f.get_lexer_for_body('application/json', '{"key": "value"}')
    assert f.get_lexer_for_body('application/javascript', '{"key": "value"}')
    assert f.get_lexer_for_body('application/javascript', 'asdf')

    # test if explicit json overrides mimetype
    assert f.get_lexer_for_

# Generated at 2022-06-23 19:28:19.892571
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    json_obj = {}
    json_obj["a"] = 1
    json_obj["b"] = []
    json_obj["b"].append(1)
    json_obj["b"].append(2)
    json_obj["b"].append(3)
    json_obj["c"] = {}
    json_obj["c"]["0"] = 1
    json_obj["c"]["1"] = 2
    json_obj["c"]["2"] = 3
    json_str = json.dumps(json_obj, indent=4)

    cf = ColorFormatter(None, False, "default")
    assert cf.format_body(json_str, "application/json") == json_str

    cf = ColorFormatter(None, False, "solarized")

# Generated at 2022-06-23 19:28:27.985785
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    lexers = {
        'html': pygments.lexers.HtmlLexer(),
        'json': pygments.lexers.JsonLexer(),
        'python': pygments.lexers.PythonLexer(),
        'xml': pygments.lexers.XmlLexer(),
        'unknown': pygments.lexers.TextLexer(),
    }
    for mime, lexer in lexers.items():
        assert ColorFormatter(None).get_lexer_for_body(mime, '') == lexer, (
            'lexer did not match for mime {}'.format(mime)
        )

# Generated at 2022-06-23 19:28:33.571991
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Arrange
    formatter = ColorFormatter(Environment(colors=False))
    formatter.explicit_json = False

    # Act
    actual = formatter.get_lexer_for_body("application/json", "")

    # Assert
    assert actual == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:28:35.349507
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json', body='{}')

# Generated at 2022-06-23 19:28:40.050080
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    string = b"""HTTP/1.1 200 OK
Content-Type: text/plain
Date: Fri, 28 Oct 2016 19:13:58 GMT
Transfer-Encoding: chunked

Hello World!
"""
    assert lexer.get_tokens(string)

# Generated at 2022-06-23 19:28:46.681528
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter(env={'colors': 256}, explicit_json=False, color_scheme='solarized')
    assert cf.enabled == True
    assert type(cf.formatter) == Terminal256Formatter
    assert type(cf.http_lexer) == SimplifiedHTTPLexer
    assert type(cf.get_style_class('solarized')) == Solarized256Style
    assert type(cf.get_lexer_for_body('application/json', '{}')) == pygments.lexers.JsonLexer

# Generated at 2022-06-23 19:28:52.373302
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    import pytest
    from httpie.plugins.formatters.colors import ColorFormatter

    for scheme in AVAILABLE_STYLES:
        assert ColorFormatter.get_style_class(scheme)

    for scheme in ('foo', 'bar', 'baz'):
        with pytest.raises(ClassNotFound):
            ColorFormatter.get_style_class(scheme)

# Generated at 2022-06-23 19:29:01.461671
# Unit test for function get_lexer
def test_get_lexer():
    # pylint: disable=missing-class-docstring,missing-function-docstring
    class CustomLexer(pygments.lexer.RegexLexer):
        name = 'Custom'
        aliases = ['custom']
        filenames = ['*.custom']

    def get_custom_lexer():
        return CustomLexer()

    def get_custom_lexer_with_priority():
        return CustomLexer, 0.5

    pygments.lexers.get_lexer_for_mimetype = get_custom_lexer
    pygments.lexers.get_lexer_by_name = get_custom_lexer_with_priority

# Generated at 2022-06-23 19:29:06.576077
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(Environment())
    assert color_formatter.get_lexer_for_body('application/json', '{}') == pygments.lexers.JsonLexer
    assert color_formatter.get_lexer_for_body('application/json', '[{},{}]') == pygments.lexers.JsonLexer
    assert color_formatter.get_lexer_for_body('application/json', '{"a":"b"}') == pygments.lexers.JsonLexer
    assert color_formatter.get_lexer_for_body('application/json', '{"a":42}') == pygments.lexers.JsonLexer
    assert color_formatter.get_lexer_for_body('application/json', '{"a":3.1415926}') == py

# Generated at 2022-06-23 19:29:15.430319
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment

    # Case 1 -- No colors
    env = Environment(colors=False)

    # Case 1a -- No explicit_json
    http_lexer = PygmentsHttpLexer()
    formatter = TerminalFormatter()

    color_formatter = ColorFormatter(
        formatter=formatter,
        http_lexer=http_lexer,
        env=env,
        explicit_json=False,
    )

    json_body = b'{\n  "content_type": "application/json"\n}\n'

# Generated at 2022-06-23 19:29:25.668092
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # construction
    import os
    import sys
    sys.path.append(os.path.abspath('.'))
    from httpie.processors import JSONProcessor, JSONOptions

    # get object
    color_formatter = ColorFormatter(
        env=Environment(),
        explicit_json=False,
        color_scheme='default'
    )

    # do test
    print('\n')
    print('ColorFormatter: format_body()')
    print('\n')