

# Generated at 2022-06-23 19:19:31.882252
# Unit test for function get_lexer
def test_get_lexer():
    # AssertionError if value passed to get_lexer_for_mimetype
    # is not a valid mime, even if it would pass a test for valid
    # lexer name via get_lexer_by_name.
    assert get_lexer('unknown/mime') is None
    # Try to get lexer via mime type
    assert get_lexer('application/json')
    # If mime mapping failed, try to get lexer by the name.
    assert get_lexer('unknown/lexer') is None
    assert get_lexer('text/xml')
    # In some cases lexer might not be found by lexer name,
    # but it might be a JSON response regardless.
    assert get_lexer('application/octet-stream', True, b'{}')

# Generated at 2022-06-23 19:19:37.055983
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins import plugin_manager
    color_formatter = plugin_manager.instantiate(ColorFormatter)
    # By default, solarized256 will be used for 256-color terminals
    import os
    from unittest import mock
    with mock.patch.dict(os.environ, {'COLORTERM': '256color'}):
        style_class = color_formatter.get_style_class('solarized')
        assert style_class == Solarized256Style
        # If $COLORTERM is not set to 256color, the default SolarizedStyle will
        # be used
    with mock.patch.dict(os.environ, {'COLORTERM': 'non-256color'}):
        style_class = color_formatter.get_style_class('solarized')
        assert style_class == py

# Generated at 2022-06-23 19:19:46.403320
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.token import Keyword
    from pygments.token import Name
    from pygments.token import String
    from pygments.token import Number
    from pygments.token import Whitespace
    from pygments.token import Operator
    from pygments.token import Token


    simplified_http_lexer = SimplifiedHTTPLexer()

    # Test for Pygments version 3.2.1.
    #
    # https://pygments.org/docs/tokens/
    #
    #   Token                   Example
    #   --------                --------
    #   Whitespace              ' '
    #   Comment                 '# not this'
    #   String                  '"double quotes"'
    #   Number                  '42'
    #   Operator                '+'
    #   Name.Attribute          '

# Generated at 2022-06-23 19:19:57.527553
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin.colors import ColorFormatter
    class S:
        headers = ''
        env = Environment(
            stdout_isatty=True,
            colors=256,
            color_scheme=DEFAULT_STYLE
        )
    s = S()
    c = ColorFormatter(env=s.env)
    body, mime = '', 'application/json'
    assert c.format_body(body, mime) == '\x1b[38;5;124m\x1b[1m' + body + '\x1b[0m'

# Generated at 2022-06-23 19:19:59.009656
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert isinstance(lexer, SimplifiedHTTPLexer)

# Generated at 2022-06-23 19:20:11.264260
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from . import http
    env = http.Environment()
    processor = ColorFormatter(env)
    headers = '''\
GET / HTTP/1.1
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.7.2
'''

# Generated at 2022-06-23 19:20:14.560119
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('none') == None
    # FIXME: do we have to set self.env.colors to 256 for this call to work?
    # assert ColorFormatter.get_style_class('256') == Terminal256Formatter

# Generated at 2022-06-23 19:20:17.564468
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class MockEnvironment():
        colors = '256'
    class MockWriter():
        pass
    formatter = ColorFormatter(MockEnvironment(), MockWriter())
    assert formatter.formatter.style.__class__ == Solarized256Style

# Generated at 2022-06-23 19:20:30.230877
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    lexer = pygments.lexers.get_lexer_by_name('json')
    formatter = Solarized256Style()
    json_string = json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}])
    http_string = "GET /index.html HTTP/1.1\nContent-Type: text/html\n\n"

# Generated at 2022-06-23 19:20:34.417933
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class('fruity')
    assert style is pygments.styles.get_style_by_name('fruity'), style
    style = ColorFormatter.get_style_class(SOLARIZED_STYLE)
    assert style is Solarized256Style, style

# Generated at 2022-06-23 19:20:38.836106
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('application/json')
    assert lexer.name == 'JSON'

    lexer = get_lexer('application/javascript')
    assert lexer.name == 'JavaScript'

# Generated at 2022-06-23 19:20:41.592064
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')



# Generated at 2022-06-23 19:20:48.744668
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Test auto mode
    assert ColorFormatter.get_style_class('auto').__name__ == 'default'
    # Test solarized mode
    assert ColorFormatter.get_style_class('solarized').__name__ == 'Solarized256Style'
    # Test other modes
    assert ColorFormatter.get_style_class('monokai').__name__ == 'Monokai'
    # Test non-existing mode
    assert ColorFormatter.get_style_class('non-existing').__name__ == 'default'

# Generated at 2022-06-23 19:20:51.146264
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    cf = ColorFormatter(None, color_scheme=SOLARIZED_STYLE)
    assert isinstance(cf.formatter.style, Solarized256Style)

# Generated at 2022-06-23 19:20:57.221456
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    """
    Checks if all the colors defined in Solarized256Style are valid.
    """
    for name in dir(Solarized256Style):
        if name.isupper():
            color_value = getattr(Solarized256Style, name)
            assert color_value.startswith('#'), \
                '%s does not start with a #' % color_value
            assert len(color_value) == 7, \
                '%s is not 7 characters long' % color_value

# Generated at 2022-06-23 19:21:04.648082
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.output.streams import VERBOSITY_LEVEL_NORMAL
    from httpie.context import Environment
    # Environment attributes not really valid, but not relevant for the test
    env = Environment(output_options={"style": AUTO_STYLE}, colors=256,
                      is_terminal=True, verbose=VERBOSITY_LEVEL_NORMAL)

    cf = ColorFormatter(env)
    assert cf.get_style_class(AUTO_STYLE) == Solarized256Style

    env.colors = 8
    cf = ColorFormatter(env)
    assert cf.get_style_class(AUTO_STYLE) == pygments.styles.get_style_by_name(
        'monokai')

# Generated at 2022-06-23 19:21:11.461909
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style

# Generated at 2022-06-23 19:21:12.168241
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
	pass

# Generated at 2022-06-23 19:21:23.074653
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    c = ColorFormatter(Environment())
    assert(type(c.http_lexer) == SimplifiedHTTPLexer)
    assert(type(c.formatter) == Terminal256Formatter)
    assert(type(c.formatter.style) == Solarized256Style)

    c = ColorFormatter(Environment(colors=256))
    assert(type(c.http_lexer) == SimplifiedHTTPLexer)
    assert(type(c.formatter) == Terminal256Formatter)
    assert(type(c.formatter.style) == Solarized256Style)

    c = ColorFormatter(Environment(colors=16))
    assert(type(c.http_lexer) == PygmentsHttpLexer)
    assert(type(c.formatter) == TerminalFormatter)


# Generated at 2022-06-23 19:21:25.814858
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-23 19:21:35.739835
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    request_line = "GET /foo/bar HTTP/1.0"
    status_line = "HTTP/1.0 200 OK"
    headers = "Content-Type: application/json"
    assert pygments.highlight(
        code=request_line,
        lexer=SimplifiedHTTPLexer(),
        formatter=TerminalFormatter()
    ).strip() == '[32mGET[39m  [36m/foo/bar[39m  [34mHTTP[39m/[33m1.0[39m'

# Generated at 2022-06-23 19:21:42.060866
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class ColorFormatter:
        def __init__(self, **kwargs):
            self.explicit_json = False
            self.formatter = None
            self.http_lexer = None
            super().__init__(**kwargs)

    g = ColorFormatter()


# Generated at 2022-06-23 19:21:51.135213
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.colors import pygments
    from httpie.cli import Style
    from httpie.colors import Solarized256Style
    from httpie.colors import ColorFormatter

    class style_1(pygments.style.Style):
        styles = {pygments.token.Generic.Inserted: GREEN}

    class style_2(pygments.style.Style):
        styles = {pygments.token.Generic.Inserted: GREEN}

    class style_3(pygments.style.Style):
        styles = {pygments.token.Generic.Inserted: GREEN}

    style = Style(color_scheme="style_1")
    assert ColorFormatter.get_style_class(style.color_scheme) is style_1

    style = Style(color_scheme="style_2")
    assert ColorFormatter.get

# Generated at 2022-06-23 19:21:55.613727
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(Environment(), color_scheme='solarized')
    style_class = color_formatter.get_style_class('solarized')

    assert style_class == Solarized256Style, \
           "ColorFormatter.get_style_class('solarized') should return Solarized256Style"

# Generated at 2022-06-23 19:21:57.584765
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    try:
        Solarized256Style()
    except Exception as e:
        print("Unexpected error:", e)
        assert False

# Generated at 2022-06-23 19:21:59.613520
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'



# Generated at 2022-06-23 19:22:02.376321
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body(): 
    color_formatter = ColorFormatter(None)
    lexer = color_formatter.get_lexer_for_body(
        mime="application/json",
        body="{}"
    )
    assert lexer is not None

# Generated at 2022-06-23 19:22:12.557838
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class MyStyle(pygments.style.Style):
        pass

    class MyFormatter(FormatterPlugin):
        def get_style_class(self, color_scheme):
            return MyStyle

    my_formatter = MyFormatter()
    assert my_formatter.get_style_class('my_style') == MyStyle
    assert my_formatter.get_style_class('my style') == MyStyle
    assert my_formatter.get_style_class('my-style') == MyStyle
    assert my_formatter.get_style_class('my_style123') == MyStyle

    assert my_formatter.get_style_class('my_style_') is None
    assert my_formatter.get_style_class('my style ') is None

# Generated at 2022-06-23 19:22:13.473909
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    pass

# Generated at 2022-06-23 19:22:19.377891
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Test with a valid color_scheme
    style_class = ColorFormatter.get_style_class('solarized')
    assert style_class == Solarized256Style
    # Test with an invalid color_scheme, the returned class must be Solarized256Style
    style_class = ColorFormatter.get_style_class('invalid_colors_chosen_by_user')
    assert style_class == Solarized256Style

# Generated at 2022-06-23 19:22:24.155430
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie.plugins  # noqa
    import httpie.core  # noqa
    env = Environment()
    formatter = ColorFormatter(env, color_scheme=DEFAULT_STYLE)
    lexer = formatter.get_lexer_for_body(
        mime='application/json',
        body='{"key": "value"}'
    )
    if type(lexer).__name__ == 'JsonLexer':
        return
    assert False

# Generated at 2022-06-23 19:22:27.433409
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    query = '{"method":"get"}'
    color_formatter = ColorFormatter(Environment(), explicit_json=False, color_scheme='vim')
    print(color_formatter.get_lexer_for_body('application/json', body=query))

# Generated at 2022-06-23 19:22:32.742008
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    try:
        Solarized256Style()
        print('\x1b[32m' + 'OK' + '\x1b[0m')
    except Exception as e:
        print('\x1b[31m' + 'Failed' + '\x1b[0m')
        print(e)

if __name__ == '__main__':
    test_Solarized256Style()

# Generated at 2022-06-23 19:22:34.343268
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.enabled

# Generated at 2022-06-23 19:22:35.544445
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'

# Generated at 2022-06-23 19:22:48.046774
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    colorFormatter = ColorFormatter(env)
    httpResponse = '''HTTP/1.1 200 OK
Date: Fri, 06 Feb 2015 00:42:40 GMT
Server: Apache/2.2.3 (CentOS)
Last-Modified: Thu, 05 Feb 2015 20:33:32 GMT
ETag: "23e1d-1b2-508bc2a7aa820"
Accept-Ranges: bytes
Content-Length: 434
Content-Type: text/html; charset=UTF-8

'''

# Generated at 2022-06-23 19:22:59.337683
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    colorFormatter = ColorFormatter(env=env, color_scheme='solarized')

# Generated at 2022-06-23 19:23:00.522072
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:23:02.472981
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style().styles[pygments.token.Token] == \
        Solarized256Style.BASE1

# Generated at 2022-06-23 19:23:05.417581
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    try:
        pygments.lexers.get_lexer_by_name('http')
    except ClassNotFound:
        pass
    else:
        raise Exception("HTTP lexer is parameterized and should not be found")

# Generated at 2022-06-23 19:23:11.799854
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins.builtin import Colors
    from httpie.context import Environment
    get_style_class = ColorFormatter(Environment(colors=256)).get_style_class
    # Style: solarized256
    assert get_style_class("solarized256") == Solarized256Style
    # Style: solarized
    assert get_style_class("solarized") == Solarized256Style
    # Style: native
    assert get_style_class("native") == Solarized256Style
    # Style: other
    assert get_style_class("other") == Solarized256Style

# Generated at 2022-06-23 19:23:12.693011
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized256') is Solarized256Style

# Generated at 2022-06-23 19:23:21.213665
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    f = ColorFormatter(env=Environment(), color_scheme="solarized")
    with open("http_headers.txt", "r") as file:
        headers = file.read()

# Generated at 2022-06-23 19:23:31.377577
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import pytest
    formatter = ColorFormatter(None)
    lexers = [
        (
            "text/html",
            "<!DOCTYPE html>",
            pygments.lexers.get_lexer_by_name("html"),
            "html",
            False
        ),
        (
            "application/json",
            "null",
            pygments.lexers.get_lexer_by_name("json"),
            "json",
            True
        )
    ]
    for mime, body, expected, expected_name, explicit_json in lexers:
        assert expected == formatter.get_lexer_for_body(mime, body)
        if explicit_json:
            assert expected_name == formatter.get_lexer_for_body("text/html", body).name

# Generated at 2022-06-23 19:23:40.827610
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    env = Environment(colors=True, stdin=None, stdout=None, stderr=None)
    fm = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    headers_processor = HTTPHeadersProcessor(
        force_colors=None,
        body_not_formatted_if_terminal=None,
        body_not_formatted_if_not_terminal=None,
        style=None,
        color_scheme=None,
        force_formatted=None,
    )
    headers = headers_processor.format_headers({'header1': 'value1'})
    result = fm.format_headers(headers)

# Generated at 2022-06-23 19:23:44.576277
# Unit test for function get_lexer
def test_get_lexer():
    result = get_lexer("text/html")
    assert result is not None

    result = get_lexer("text/json")
    assert result is not None

    result = get_lexer("unknown/type")
    assert result is None

    result = get_lexer("text/json", body='{"x": "y"}')
    assert result is not None

    result = get_lexer("text/json", body='{"x": "y]')
    assert result is None

# Generated at 2022-06-23 19:23:46.657403
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class('solarized')
    assert style == Solarized256Style

# Generated at 2022-06-23 19:23:51.177921
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('monokai') is pygments.styles.get_style_by_name('monokai')
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style

# Generated at 2022-06-23 19:23:53.120178
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class('solarized')
    assert style == Solarized256Style

# Generated at 2022-06-23 19:23:57.259800
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class MockEnvironment:
        def __init__(self, colors):
            self.colors = colors
    assert ColorFormatter(MockEnvironment(256)).get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-23 19:24:01.313236
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Given
    body_string = "testing"
    mime_type = "text/html"
    color_formatter = ColorFormatter(None)

    # When
    result = color_formatter.format_body(body_string, mime_type)

    # Then
    assert result == body_string

# Generated at 2022-06-23 19:24:05.751741
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.cli.args import Arguments
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    env = Environment()
    args = Arguments(color_scheme=DEFAULT_STYLE, env=env)
    color_formatter = ColorFormatter(args, env)
    assert color_formatter.get_style_class(DEFAULT_STYLE) == Solarized256Style

# Generated at 2022-06-23 19:24:06.661473
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:24:13.315973
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    code = 'GET / HTTP/1.0\r\n'
    tokens = [
        (pygments.token.Name.Function, 'GET'),
        (pygments.token.Text, ' '),
        (pygments.token.Name.Namespace, '/'),
        (pygments.token.Text, ' '),
        (pygments.token.Keyword.Reserved, 'HTTP'),
        (pygments.token.Operator, '/'),
        (pygments.token.Number, '1.0')
    ]
    assert SimplifiedHTTPLexer().get_tokens(code) == tokens


code = '{"abc": "def"}'


# Generated at 2022-06-23 19:24:22.744765
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # default json lexer
    lexer = ColorFormatter(Environment(colors=True, is_windows=False)).get_lexer_for_body(
        "application/json", "{}")
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    # default http lexer
    lexer = ColorFormatter(Environment(colors=True, is_windows=False)).get_lexer_for_body(
        "application/http", "HTTP/1.1 200 OK")
    assert lexer == pygments.lexers.get_lexer_by_name('http')

    # default javascript lexer
    lexer = ColorFormatter(Environment(colors=True, is_windows=False)).get_lexer_for_body(
        "application/javascript", "function hello() {}")


# Generated at 2022-06-23 19:24:32.165814
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin

    class MockEnvironment:
        colors = True

    # JSON
    env = MockEnvironment()
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert '\x1b[32m{\x1b[39m\n    \x1b[32m"message"\x1b[39m: \x1b[34m"Hello World!"\x1b[39m\n\x1b[32m}\x1b[39m' == color_formatter.format_body('{\n    "message": "Hello World!"\n}', "application/json")

# Generated at 2022-06-23 19:24:36.990197
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class MockEnvironment:
        def __init__(self):
            self.colors = 256

    env = MockEnvironment()
    formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized', **{})
    assert formatter.formatter.__class__ == Terminal256Formatter
    assert formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert formatter.get_style_class('solarized') == Solarized256Style

test_ColorFormatter()

# Generated at 2022-06-23 19:24:47.210846
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import ColorFormatter
    env = Environment()
    color_formatter = ColorFormatter(env)

    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nServer: meinheld/0.6.1'

# Generated at 2022-06-23 19:24:50.219288
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('monokai') is pygments.styles.MonokaiStyle

# Generated at 2022-06-23 19:24:58.786602
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert ColorFormatter.format_body(ColorFormatter, body="hi", mime="application/json") == pygments.highlight(
                code="hi",
                lexer=pygments.lexers.get_lexer_by_name('json'),
                formatter=TerminalFormatter()
    )

    assert ColorFormatter.format_body(ColorFormatter, body="hi", mime="text/html") == pygments.highlight(
                code="hi",
                lexer=pygments.lexers.get_lexer_for_mimetype('text/html'),
                formatter=TerminalFormatter()
    )

# Generated at 2022-06-23 19:25:10.511975
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print('ColorFormatter tests start')
    # Test with 'auto' style and 256 colors
    color_formatter1 = ColorFormatter(
        env={'colors': 256},
        color_scheme='auto',
        explicit_json=False
    )
    assert color_formatter1.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter1.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

    # Test with 'auto' style and no 256 colors
    color_formatter2 = ColorFormatter(
        env={'colors': 16},
        color_scheme='auto',
        explicit_json=False
    )

# Generated at 2022-06-23 19:25:14.870278
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(
        'application/json'
    ) is pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(
        'application/vnd.api+json'
    ) is pygments.lexers.get_lexer_by_name('json')



# Generated at 2022-06-23 19:25:17.509832
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import pygments.lexers as lexers
    lexer = lexers.get_lexer_by_name('http')
    # Ensure that the class we specified replaces the default from Pygments.
    assert isinstance(lexer, SimplifiedHTTPLexer)

# Generated at 2022-06-23 19:25:27.088982
# Unit test for function get_lexer
def test_get_lexer():
    def check_lexer(mime, body, expected):
        result = get_lexer(mime, body=body)
        if expected:
            assert isinstance(result, expected)
        else:
            assert result is None

    check_lexer("application/json", "", pygments.lexers.JsonLexer)
    check_lexer("application/javascript", "", pygments.lexers.JavascriptLexer)
    check_lexer("application/xml",
                # http://stackoverflow.com/questions/6797984/what-is-the-shortest-valid-xml-document
                "<a/>",
                pygments.lexers.XmlLexer)
    check_lexer("application/xml", "", None)
    check_lexer("application/xml", "not an XML string", None)

# Generated at 2022-06-23 19:25:33.215300
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.core import main
    from httpie.plugins.builtin import HTTPBasicAuth

    env = Environment()
    httpie.env.COLORS = 256
    assert env.colors == 256
    assert env.style == 'auto'
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__ == Terminal256Formatter

if __name__ == '__main__':
    test_ColorFormatter()

# Generated at 2022-06-23 19:25:41.126762
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    lexer_http = PygmentsHttpLexer()
    code = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 0
'''
    assert lexer.get_tokens("HTTP/1.1 200 OK") != lexer_http.get_tokens("HTTP/1.1 200 OK")

# Generated at 2022-06-23 19:25:46.084642
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    document = (
        b'GET / HTTP/1.1\r\n'
        b'Host: localhost:8080\r\n'
        b'User-Agent: HTTPie/0.9.9\r\n'
    )
    expected = (
        '\x1b[38;5;248mGET / HTTP/1.1\x1b[39m\n'
        '\x1b[38;5;33mHost: localhost:8080\x1b[39m\n'
        '\x1b[38;5;33mUser-Agent: HTTPie/0.9.9\x1b[39m\n'
    )
    color_formatter = ColorFormatter()
    assert color_formatter.format_headers(document) == expected

# Generated at 2022-06-23 19:25:57.955561
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    try:
        import pygments.styles.tango
        s = pygments.styles.tango.TangoStyle
    except ImportError:
        s = Solarized256Style
    fmt = Terminal256Formatter(style=s)
    lx = SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:26:06.654425
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    default_style_class = (pygments.styles.get_style_by_name
                           (DEFAULT_STYLE))
    assert (ColorFormatter.get_style_class
            (color_scheme=DEFAULT_STYLE) is default_style_class)
    assert (ColorFormatter.get_style_class
            (color_scheme=SOLARIZED_STYLE) is Solarized256Style)
    assert (ColorFormatter.get_style_class
            (color_scheme=AUTO_STYLE) is default_style_class)

# Generated at 2022-06-23 19:26:08.347419
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert isinstance(lexer, SimplifiedHTTPLexer)

# Generated at 2022-06-23 19:26:14.846866
# Unit test for function get_lexer

# Generated at 2022-06-23 19:26:25.319666
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    headers = 'HTTP/1.1 301 Moved Permanently\r\nLocation: https://httpbin.org/\r\nServer: nginx\r\nContent-Type: application/json\r\nContent-Length: 195\r\nConnection: keep-alive\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Credentials: true\r\nVia: 1.1 vegur\r\n\r\n'
    colorFormatter = ColorFormatter(Environment({'colors': True, 'style': 'fruity'}, None))

# Generated at 2022-06-23 19:26:33.918292
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(None, explicit_json=False)

    # Supported mime types and their associated lexers
    supported_mime_types = {
        'application/json': pygments.lexers.get_lexer_by_name('json'),
        'application/yaml': pygments.lexers.get_lexer_by_name('yaml'),
        'application/javascript': pygments.lexers.get_lexer_by_name('javascript'),
        'application/php': pygments.lexers.get_lexer_by_name('php'),
        'application/xml': pygments.lexers.get_lexer_by_name('xml')
    }


# Generated at 2022-06-23 19:26:35.831073
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter()
    assert formatter.group_name == 'colors'

# Generated at 2022-06-23 19:26:45.731617
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():

    # The formatter object, has a mapping for the keys and values in http_lexer
    color_formatter = ColorFormatter(Environment())

    # A lexer object, to parse the request
    lexer = color_formatter.http_lexer

    # We have to generate the tokens first
    # unpack the tokens
    tokens = list(lexer.get_tokens('Date: Sat, 1 May 2020 21:53:15 GMT'))
    # Use the index of the tokens we want to change
    tokens[6] = (pygments.token.Name.Attribute, 'Date')
    tokens[7] = (pygments.token.Text, ':')
    tokens[8] = (pygments.token.String, 'Sat, 1 May 2020 21:53:15 GMT')

    # Replace the header color in the formatter using tokens


# Generated at 2022-06-23 19:26:55.738087
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.output.formatters.colors import ColorFormatter
    import json
    env: Environment
    cf = ColorFormatter(env=env, explicit_json=False)
    resp_body = "[1,2,3,4,5]"
    mime = "text/plain"
    lexer = cf.get_lexer_for_body(mime, resp_body)
    assert lexer == pygments.lexers.get_lexer_by_name('json')
    resp_body = "[1,2,3,4,5]"
    mime = "text/html"
    lexer = cf.get_lexer_for_body(mime, resp_body)
    assert lexer == None

# Generated at 2022-06-23 19:26:59.784866
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from tempfile import NamedTemporaryFile
    with NamedTemporaryFile('w') as f:
        with open(f.name, 'w') as f:
            formatter = ColorFormatter(None)


# Generated at 2022-06-23 19:27:04.555966
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    expected = """\
GET / HTTP/1.1
Accept: application/json; indent=4
"""
    headers = """\
GET / HTTP/1.1
Accept: application/json; indent=4
"""
    color_formatter = ColorFormatter(Environment(),
                                     explicit_json=False,
                                     color_scheme=DEFAULT_STYLE)
    actual = color_formatter.format_headers(headers)
    assert actual == expected

# Generated at 2022-06-23 19:27:10.731824
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('application/json')
    assert lexer.__name__ == 'JSONLexer'

    lexer = get_lexer('application/json', explicit_json=True, body='{}')
    assert lexer.__name__ == 'JSONLexer'

    lexer = get_lexer('application/json', explicit_json=True, body='42')
    assert lexer is None

    lexer = get_lexer('application/foo')
    assert lexer is None

# Generated at 2022-06-23 19:27:13.608826
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == Solarized256Style


# Generated at 2022-06-23 19:27:21.865040
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():

    class FakeEnvironment:
        colors = True

    formatter = ColorFormatter(FakeEnvironment(), False)
    actual = formatter.format_headers("""
    POST / HTTP/1.1
    Host: fb.com
    content-type: application/json
    accept: application/json
    content-length: 14
    Accept-Encoding: gzip, deflate
    Connection: keep-alive

    """)
    expected = """
    POST / HTTP/1.1
    Host: fb.com
    content-type: application/json
    accept: application/json
    content-length: 14
    Accept-Encoding: gzip, deflate
    Connection: keep-alive
    """
    assert actual == expected

# Generated at 2022-06-23 19:27:28.883443
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-23 19:27:29.551718
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:27:31.010855
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

test_Solarized256Style()

# Generated at 2022-06-23 19:27:37.046823
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(color_scheme=SOLARIZED_STYLE)\
        == Solarized256Style
    assert ColorFormatter.get_style_class(color_scheme=AUTO_STYLE)\
        == TerminalFormatter
    assert ColorFormatter.get_style_class(color_scheme=DEFAULT_STYLE)\
        == TerminalFormatter

# Generated at 2022-06-23 19:27:38.426064
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("solarized") == Solarized256Style

# Generated at 2022-06-23 19:27:42.118516
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    tokens = SimplifiedHTTPLexer().get_tokens_unprocessed('GET /foo/bar HTTP/1.1')

    for (token_type, value) in tokens:
        assert token_type == pygments.token.Token.Text, \
            'expected Text, got {0!s}'.format(token_type)

# Generated at 2022-06-23 19:27:43.494867
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True, colors_256=256)
    c = ColorFormatter(env)

# Generated at 2022-06-23 19:27:53.528703
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(is_valid=True)

    assert '\x1b[1;31m2\x1b[0m' == color_formatter.format_body(
        '2',
        mime='application/json'
    )
    assert '2' == color_formatter.format_body(
        '2',
        mime='application/javascript'
    )
    assert '2' == color_formatter.format_body(
        '2',
        mime='text/html'
    )
    assert '2' == color_formatter.format_body(
        '2',
        mime='text/plain'
    )


# Generated at 2022-06-23 19:27:58.583931
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    colorFormatter = ColorFormatter(env, explicit_json, color_scheme)

    assert colorFormatter.group_name == 'colors', \
        'failed to construct class ColorFormatter, group_name is %s' \
        % colorFormatter.group_name

# Generated at 2022-06-23 19:28:00.508250
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(None)
    assert color_formatter.get_style_class(SOLARIZED_STYLE) is Solarized256Style

# Generated at 2022-06-23 19:28:11.130706
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.cli.environment import Environment
    import os
    import tempfile
    
    env = Environment()
    env.colors = 256
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(style=Solarized256Style)

    temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False)

    temp_file.write('Hello World!\n') 
    temp_file.close()


# Generated at 2022-06-23 19:28:11.711495
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:28:15.406833
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity').__name__ == "FruityStyle"
    assert ColorFormatter.get_style_class('solarized').__name__ == "Solarized256Style"
    assert ColorFormatter.get_style_class('auto').__name__ == "TerminalStyle"
    assert ColorFormatter.get_style_class('default').__name__ == "TerminalStyle"

# Generated at 2022-06-23 19:28:20.330863
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment(colors=256)
    fmt = ColorFormatter(env)
    body = "test"
    mime = "text/html"
    assert fmt.format_body(body, mime) == body
    body = "test"
    mime = "application/json"
    assert fmt.format_body(body, mime) == body
    body = '{"title": "test"}'
    mime = "text/html"
    assert fmt.format_body(body, mime) == body
    fmt.explicit_json = True
    assert fmt.format_body(body, mime) != body
    assert fmt.format_body(body, mime) == fmt.http_lexer

# Generated at 2022-06-23 19:28:22.237368
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment(colors=False), False, False)
    formatter.format_headers('test')


# Generated at 2022-06-23 19:28:23.138608
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:28:27.580724
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter(None).get_style_class('fruity') is pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter(None).get_style_class('solarized') is Solarized256Style


# Generated at 2022-06-23 19:28:38.937382
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import httpie.cli

    args = httpie.cli.parser.parse_args(args=[
        '--print=hB',
        'https://httpbin.org/headers', 'Accept:'
    ])
    colors = httpie.cli.get_colors(args)
    formatter = ColorFormatter(args.__dict__, colors=colors)

# Generated at 2022-06-23 19:28:43.795833
# Unit test for function get_lexer
def test_get_lexer():
    g_lexer = get_lexer('application/json')
    assert g_lexer is pygments.lexers.get_lexer_by_name('json')

    g_lexer = get_lexer('application/json', explicit_json=True, body='test')
    assert g_lexer is pygments.lexers.get_lexer_by_name('json')

    g_lexer = get_lexer('application/json', explicit_json=False, body='test')
    assert g_lexer is pygments.lexers.get_lexer_by_name('json')

    g_lexer = get_lexer('application/unknown', body='test')
    assert g_lexer is None

# Generated at 2022-06-23 19:28:48.866905
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) == pygments.styles.get_style_by_name(DEFAULT_STYLE)
    assert ColorFormatter.get_style_class('test') == None

# Generated at 2022-06-23 19:28:57.369486
# Unit test for function get_lexer
def test_get_lexer():
    def get_lexer_name(lexer):
        if lexer:
            return lexer.name
        return ''

    def get_mime_and_body(explicit_json):
        mime = 'text/plain'
        body = 'foo = %s' % json.dumps({'lorem': 'ipsum'})
        if explicit_json:
            mime = 'application/json'
        return mime, body

    assert get_lexer_name(get_lexer(mime='text/html')) == 'HTML'
    assert get_lexer_name(get_lexer(mime='application/xhtml+xml')) == 'HTML'
    assert get_lexer_name(get_lexer(mime='application/vnd.wap.xhtml+xml')) == 'HTML'


# Generated at 2022-06-23 19:29:01.507502
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import httpie.core
    env=Environment()
    env.colors = 256
    color_scheme = 'fruity'
    formatter = ColorFormatter(env, color_scheme)
    formatter.format_headers("test")
    formatter.format_body("test",mime="application/json")

# Generated at 2022-06-23 19:29:06.618654
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import builtin
    from httpie import ExitStatus
    from httpie.context import Environment

# Generated at 2022-06-23 19:29:07.121764
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:29:15.845682
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(Environment())
    # Mimetype application/json
    assert(color_formatter.get_lexer_for_body(
        mime='application/json',
        body='{"foo":"bar"}'))
    # Mimetype application/json with invalid body
    assert(not color_formatter.get_lexer_for_body(
        mime='application/json',
        body='foo'))
    # Mimetype application/json with explicit_json
    assert(color_formatter.get_lexer_for_body(
        mime='text/html',
        explicit_json=True,
        body='{"foo":"bar"}'))
    # Mimetype application/json with explicit_json and invalid body

# Generated at 2022-06-23 19:29:21.936850
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # pylint: disable=protected-access
    assert ColorFormatter._get_lexer_for_body, 'get_lexer_for_body()'
    _ColorFormatter = ColorFormatter(None)
    assert isinstance(_ColorFormatter._get_lexer_for_body,
                      staticmethod), '_get_lexer_for_body()'

# Generated at 2022-06-23 19:29:27.518895
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers = 'HTTP/1.1 200 OK\x0d\x0acontent-type:image/png\x0d\x0a' \
              'content-length:512'
    formatter = ColorFormatter(Environment())
    assert headers == formatter.format_headers(headers)


if __name__ == '__main__':
    import sys
    from httpie.cli import main

    sys.exit(main())