

# Generated at 2022-06-23 19:19:28.887318
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import str

    class Arg(object):
        pass

    class Response(object):
        headers = {'Content-Type': 'application/json'}

    class Environment(object):
        colors = 256

    headers_str = 'Content-Type: application/json\r\n'

    http = PygmentsHttpLexer()
    formatter = Terminal256Formatter(
        style=Solarized256Style
    )

    result = pygments.highlight(
        code=headers_str,
        lexer=http,
        formatter=formatter,
    )
    assert result == '\x1b[38;5;226mContent-Type: application/json\r\n\x1b[39m'

# Generated at 2022-06-23 19:19:35.215383
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie import ExitStatus
    output_file = open('output_file.txt','w')

# Generated at 2022-06-23 19:19:45.793748
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.streams import get_encoded_stream

    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    import json

    env = Environment()

    class Plug(FormatterPlugin):
        def format_body(self, body: str, mime: str) -> str:
            lexer = self.get_lexer_for_body(mime, body)
            if lexer:
                body = pygments.highlight(
                    code=body,
                    lexer=lexer,
                    formatter=TerminalFormatter(),
                )
            return body

    # Base case
    formatter = Plug(env=env)
    body = '{"hello":"world"}'
    assert formatter.format_body(body, 'application/json') == json.loads(body)
    assert form

# Generated at 2022-06-23 19:19:46.762912
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()  # type: ignore

# Generated at 2022-06-23 19:19:57.782504
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.input import ParseError
    import httpie.plugins.builtin
    import io


# Generated at 2022-06-23 19:19:58.721932
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter()
    assert cf.__class__.__name__ == 'ColorFormatter'

# Generated at 2022-06-23 19:20:11.217462
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from unittest.mock import MagicMock
    from httpie.compat import is_windows

    env = MagicMock()
    env.colors = True
    env.__getattribute__.return_value = True
    env.__dict__ = {'colors': True}

    ColorFormatter(env)

    env.colors = False
    ColorFormatter(env)

    env.colors = 256
    env.__dict__ = {'colors': 256}
    formatter = ColorFormatter(env)
    if is_windows:
        assert formatter.formatter.__dict__['style'] == pygments.styles.get_style_by_name('fruity')
    else:
        assert formatter.formatter.__dict__['style'] == Solarized256Style

    env.colors = True

# Generated at 2022-06-23 19:20:18.332764
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins import Plugin
    from httpie.compat import str
    from httpie.output import get_formatter
    from httpie.plugins.colors import ColorFormatter

    cf = ColorFormatter(
        env=None,
        color_scheme=SOLARIZED_STYLE,
        explicit_json=True,
        **Plugin.create_default_settings(None)
    )
    assert cf.get_style_class(SOLARIZED_STYLE) == Solarized256Style
    assert cf.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')



# Generated at 2022-06-23 19:20:30.966142
# Unit test for method format_body of class ColorFormatter

# Generated at 2022-06-23 19:20:39.486168
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    # print(lexer)

# Generated at 2022-06-23 19:20:50.828857
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Create a ColorFormatter object
    # Note: the environment object will be used by the ColorFormatter object
    # to determine if color support is available in the terminal, and if so
    # what kind of color support. This can be overridden by setting the
    # environmental variable TERM (i.e. TERM=xterm-256color)
    # Here we'll use a 64 color environment
    env = Environment(colors=64)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)

    # Test format_body with a body that is valid json.
    # The Valid json body will be formatted as a JSON string
    body = '{"key1": "value1"}'
    mime = 'application/json'
    # Confirm the valid json body is formatted as a

# Generated at 2022-06-23 19:21:00.039937
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    tok = lexer.get_tokens_unprocessed('FOO /BAR HTTP/1.1\r\nHost: aa:bb\r\n')

# Generated at 2022-06-23 19:21:04.084856
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie.cli
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    class MockEnvironment(Environment):

        def __init__(self):
            super().__init__(
                colors=256,
                stdin=None,
                stdin_isatty=False,
                stdout=None,
                stdout_isatty=False,
                output_options=httpie.cli.OutputOptions(),
                styles=httpie.cli.Style(),
                format=['colors'],
            )

    def get_lexer(self, mime, body):
        return self.get_lexer_for_body(mime=mime, body=body)

    FormatterPlugin.get_lex

# Generated at 2022-06-23 19:21:15.386571
# Unit test for function get_lexer
def test_get_lexer():
    tests = [
        ('text/foo', None),
        ('text/x-foo', pygments.lexers.get_lexer_by_name('foo')),
        ('text/html+x-bar',
         pygments.lexers.get_lexer_by_name('html', encoding='bar')),
        ('text/x-bar+html',
         pygments.lexers.get_lexer_by_name('html', encoding='bar')),
        ('application/x-foo',
         pygments.lexers.get_lexer_by_name('foo', encoding='bar'))
    ]
    for mimetype, expected in tests:
        assert get_lexer(mimetype) == expected

# Generated at 2022-06-23 19:21:18.447161
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    obj = ColorFormatter()
    assert obj.group_name == 'colors'
    assert obj.enabled == False
    assert obj.formatter == None
    assert obj.http_lexer == None
    assert obj.explicit_json == False


# Generated at 2022-06-23 19:21:28.104955
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.output.formatters.colors import ColorFormatter
    from httpie.context import Environment


    args = parser.parse_args([])
    env = Environment(vars(args))
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)

    def get_lexer_for_body(mime: str, body: str) -> Optional[Type[Lexer]]:
        return formatter.get_lexer_for_body(mime, body)

    assert get_lexer_for_body('application/json', '{}') is not None
    assert get_lexer_for_body('application/json', '[]') is not None
    assert get_lexer_for_

# Generated at 2022-06-23 19:21:37.719630
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('text/html')
    assert get_lexer('text/xml')
    assert get_lexer('text/html; charset=UTF-8')
    assert get_lexer('text/plain')
    assert get_lexer('text/x-php')
    assert get_lexer('application/protobuf')
    assert get_lexer('text/markdown')
    assert get_lexer('application/javascript')
    assert get_lexer('application/javascript; charset=UTF-8')
    # custom mime type
    assert get_lexer('application/vnd.api+json')
    # should not pass
    assert get_lexer('application/not-pass-mime-type') is None
    assert get_lexer('')

# Generated at 2022-06-23 19:21:49.286851
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    code = """\
GET / HTTP/1.1
Host: localhost:5000
User-Agent: HTTPie/0.9.5
Connection: keep-alive
Accept-Encoding: gzip, deflate, compress
Accept: */*
"""
    tokens = list(lexer.get_tokens(code))

# Generated at 2022-06-23 19:21:50.564691
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    pass


# Generated at 2022-06-23 19:22:00.286984
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    f = ColorFormatter(Environment(colors=True))

    # JSON
    mime = "application/json"
    json_data = '{ "status": "pass", "duration": 67}'
    assert (f.format_body(json_data, mime)) == pygments.highlight(json_data, get_lexer(mime), f.formatter).strip()

    # XML
    mime = "application/xml"

# Generated at 2022-06-23 19:22:07.300989
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    formatter = TerminalFormatter()
    headers = '''\
        HTTP/1.1 200 OK
        Date: Mon, 23 May 2005 22:38:34 GMT
        Content-Type: text/html; charset=UTF-8
        Content-Encoding: UTF-8
        Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
        Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
        ETag: "3f80f-1b6-3e1cb03b"
        Content-Length: 138
        Accept-Ranges: bytes
        Connection: close
        Content-Language: en'''

# Generated at 2022-06-23 19:22:11.388339
# Unit test for function get_lexer
def test_get_lexer():
    from httpie.plugins.formatter.colors import get_lexer
    lexer = get_lexer('application/json')
    assert lexer.name == 'JSON'
    lexer = get_lexer('application/doesnotexist')
    assert lexer is None

# Generated at 2022-06-23 19:22:22.211509
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.input import ParseError
    from httpie.plugins import FormatterPlugin
    from httpie.output import OutputOptions
    from httpie.context import Environment
    from httpie.plugins import BuiltinPlugin

    class TestPlugin(BuiltinPlugin):
        name = 'test_plugin'
        def get_output_options(self):
            return {}


        def get_output_stream(self):
            return None


        def get_formatter(self, *args, **kwargs):
            return ColorFormatter(*args, **kwargs)


    class TestEnv(Environment):
        color = 256
        colors = True
        json = True
        stream = None

    env = TestEnv()
    tplg = TestPlugin()

# Generated at 2022-06-23 19:22:32.546818
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/html', explicit_json=True) == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('text/plain') == pygments.lexers.TextLexer
    assert get_lexer('text/plain', explicit_json=True) == pygments.lexers.TextLexer

# Generated at 2022-06-23 19:22:45.011522
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    xenv = Environment()
    xenv.colors = "256"
    xenv.color_scheme = SOLARIZED_STYLE
    xformatter = ColorFormatter(xenv)
    body = b'''
    {
        "name": "John Doe",
        "address": "123 Main St.",
        "city": "Anytown",
        "state": "CA",
        "postal_code": "98765-4321",
        "amount_tendered": "$1,000,000.00",
        "amount_received": "$1,000,000.00",
        "remainder": "$0.00"
    }
    '''
    # FIXME: The colorized string does not match the original string
    # The first two lines should be in red
    # assert(body == xformatter.

# Generated at 2022-06-23 19:22:49.448918
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import pytest
    from httpie.context import Environment

    env = Environment(colors=256)
    formatter = ColorFormatter(env, explicit_json=False, color_scheme='fruity')
    assert formatter is not None

# Generated at 2022-06-23 19:22:59.050649
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Test case
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8;
Content-Length: 26

'''
    # Configuration
    env = Environment()
    env.colors = True
    color_format = ColorFormatter(env)
    # Expected result
    expected_result = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8;
Content-Length: 26

'''
    # Result
    result = color_format.format_headers(headers)
    # Assertion
    assert result == expected_result

# Generated at 2022-06-23 19:23:05.861670
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.formatters.colors import ColorFormatter
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.formatters import JSONFormatter
    import httpie.plugins
    import httpie.formatter
    import pygments.style
    class Env(Environment):
        def __init__(self):
            self.colors = 16
            self.stdout_isatty = True
            self.is_windows = is_windows
            self.config = {}
    class Plugin(FormatterPlugin):
        name = 'json'
        default_format = 'json'

    class Lexer(pygments.lexer.RegexLexer):
        name = 'http'
        aliases = ['http']

# Generated at 2022-06-23 19:23:13.779903
# Unit test for function get_lexer
def test_get_lexer():
    def run(mime, body, expected_lexer):
        if isinstance(expected_lexer, str):
            expected_lexer = pygments.lexers.get_lexer_by_name(expected_lexer)
        actual_lexer = get_lexer(mime, explicit_json=True, body=body)
        assert actual_lexer is expected_lexer

    run('text/plain', '', None)
    run('text/plain', '[]', pygments.lexers.get_lexer_by_name('json'))
    run('text/plain', '{}', pygments.lexers.get_lexer_by_name('json'))
    run('text/plain', '', pygments.lexers.get_lexer_by_name('json'))

# Generated at 2022-06-23 19:23:16.514410
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    test_object = Solarized256Style()
    assert test_object

# Generated at 2022-06-23 19:23:24.556024
# Unit test for function get_lexer
def test_get_lexer():

    def test(mime, explicit_json, body, lexer):
        assert get_lexer(mime, explicit_json, body) is lexer

    def test_json_and_body(*args):
        # test the case where mime is not json but we supply a json body
        # so that the json lexer should be returned
        args = list(args)
        args[1] = True
        args[2] = '{"foo": ["bar", "baz"]}'
        test(*args)

    test_json_and_body('application/xml', False, '', pygments.lexers.XmlLexer)

    test('application/json', False, '', pygments.lexers.JsonLexer)
    test('application/javascript', False, '', pygments.lexers.JavascriptLexer)
    test

# Generated at 2022-06-23 19:23:31.966762
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(None)
    assert formatter.get_lexer_for_body('application/json', '{"name":"test"}')
    assert not formatter.get_lexer_for_body(
        'text/plain',
        '{"name":"test"}'
    )
    assert not formatter.get_lexer_for_body(
        'text/plain',
        '{"name":"test"}\n'
    )
    assert not formatter.get_lexer_for_body(
        'text/plain',
        '{"name":"test"}\r'
    )

# Generated at 2022-06-23 19:23:41.067291
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from pygments.formatters.terminal import TerminalFormatter
    from pygments.lexers import HttpLexer
    from httpie.compat import is_windows, is_py3

    # Inject mock interface into environment
    import httpie.compat
    httpie.compat.is_windows = True

    cf = ColorFormatter(env=None, explicit_json=False)
    cf.formatter = TerminalFormatter()
    cf.http_lexer = HttpLexer()


# Generated at 2022-06-23 19:23:49.485605
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import jupyter_kernel_test
    import jupyter_client
    import json
    import httpie

    # Test 1 - request should match to Pygments:
    #
    # HTTP request
    # GET / HTTP/1.1

    # HTTP response
    # HTTP/1.0 200 OK
    # Content-Type: text/html

    target_format = '{\n  "header": [\n    "GET / HTTP/1.1"\n  ]\n}\n'

    # define a test for the KernelManager
    def test():
        km = jupyter_client.KernelManager()
        km.start_kernel(stderr=open(os.devnull, 'w'))

# Generated at 2022-06-23 19:23:59.749007
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    """ColorFormatter.get_lexer_for_body() should
    return the right lexer depending of mimetype and body
    """
    mime = "text/plain"
    body = "I am a simple body"
    assert get_lexer(mime, False, body) == pygments.lexers.get_lexer_by_name("text")
    assert get_lexer(mime, True, body) == pygments.lexers.get_lexer_by_name("json")
    body2 = "I am a json-like body"
    assert get_lexer(mime, True, body2) == pygments.lexers.get_lexer_by_name("json")
    body3 = '{"hello":"world"}'
    assert get_lexer(mime, True, body3) == pygments

# Generated at 2022-06-23 19:24:03.984772
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    from httpie.formatter import iter_formatters
    formatter = iter_formatters(Environment())
    assert type(formatter)==list


# Generated at 2022-06-23 19:24:05.067701
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("default")

# Generated at 2022-06-23 19:24:10.900325
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    def format_body(mime: str, body: str) -> str:
        from httpie.plugins import plugin_manager
        env = Environment()
        plugin = plugin_manager.instantiate(
            name='colors',
            env=env,
            explicit_json=False,
            color_scheme=DEFAULT_STYLE,
        )
        return plugin.format_body(mime=mime, body=body)
    assert format_body(mime='text/html', body='<html><body>') == '<html><body>'

# Generated at 2022-06-23 19:24:16.372925
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers = '\r\n'.join([
        'GET / HTTP/1.1',
        'Connection: Keep-Alive',
        'Content-Type: application/json',
        'Transfer-Encoding: chunked'
    ])
    formatter = ColorFormatter(env=Environment(colors=None))
    assert formatter.format_headers(headers) == headers

# Generated at 2022-06-23 19:24:26.304360
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import httpie.cli.formatters
    env = httpie.cli.formatters.Environment()
    env.stdout_isatty = True
    formatter = httpie.cli.formatters.get_formatter('colors', env)

# Generated at 2022-06-23 19:24:27.528684
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-23 19:24:37.508357
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.utils import JSON_CONTENT_TYPES

    response_body = '{"response":"ok"}'
    formatter_object = FormatterPlugin.get('colors')

    # print("ColorFormatter.format_body(\"{0}\", \"{1}\") == \"{2}\"".format(response_body, "application/json", formatter_object.format_body(response_body, "application/json")))
    # print("ColorFormatter.format_body(\"{0}\", \"{1}\") == \"{2}\"".format(response_body, "application/hal+json", formatter_object.format_body(response_body, "application/hal+json")))
    # print("ColorFormatter.format_body(\"{0}\", \"{

# Generated at 2022-06-23 19:24:43.033615
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(None)
    body = "HelloWorld"
    mime = "text/plain"
    result = formatter.format_body(body, mime)
    assert pygments.highlight(code=body, lexer=pygments.lexers.get_lexer_by_name('text'), formatter=TerminalFormatter()).strip() == result

# Generated at 2022-06-23 19:24:45.148829
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    env = Environment(colors=256)
    assert ColorFormatter(env)

test_SimplifiedHTTPLexer.func_annotations = {}

# Generated at 2022-06-23 19:24:46.411334
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-23 19:24:58.702780
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(env=None, verbose=False, color_scheme="fruity", display_status=True)
    body = "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n    <meta charset=\"UTF-8\">\n    <title>Title</title>\n</head>\n<body>\n\n</body>\n</html>"
    mime = "text/html"

# Generated at 2022-06-23 19:25:02.217924
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    return http_lexer
    
if __name__ == "__main__":
    print(test_SimplifiedHTTPLexer())

# Generated at 2022-06-23 19:25:13.489782
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    formatter = ColorFormatter(Environment(colors=256))
    result = formatter.format_body(json.dumps({'some': 'json'}), 'application/json')
    assert result == '\x1b[38;5;99m{\x1b[39m\x1b[38;5;99m"some"\x1b[39m\x1b[38;5;99m:\x1b[39m\x1b[38;5;99m"json"\x1b[39m\x1b[38;5;99m}\x1b[39m'
    result = formatter.format_body(json.dumps({'some': 'json'}), 'text/plain')
    assert result == json.dumps({'some': 'json'})

# Generated at 2022-06-23 19:25:21.999750
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment(colors=True))
    assert hasattr(formatter, 'formatter')
    assert hasattr(formatter, 'http_lexer')
    assert hasattr(formatter, 'explicit_json')
    assert hasattr(formatter, 'format_body')
    assert hasattr(formatter, 'format_headers')
    assert hasattr(formatter, 'get_lexer_for_body')
    assert hasattr(formatter, 'get_style_class')


# Generated at 2022-06-23 19:25:26.148396
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    mime = 'application/json; charset=utf-8'
    body = r'{"id":1,"name":"hello"}'
    cf = ColorFormatter(None, False)
    result = cf.format_body(body, mime)
    assert '\x1b[34m' in result
    assert '\x1b[39m' in result

# Generated at 2022-06-23 19:25:27.937600
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main
    from httpie.context import Environment
    from httpie.compat import str

    env = Environment()
    env.colors = 256
    assert main(args=['GET', '--headers'], env=env) is None

# Generated at 2022-06-23 19:25:28.960934
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    solarized256_style = Solarized256Style()
    assert solarized256_style

# Generated at 2022-06-23 19:25:38.139334
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # type: () -> None
    import os
    import sys

    import pygments
    import pytest

    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows

    # Define whether the current platform is Windows.
    # Different testing data are needed.
    if is_windows:
        os.environ['ANSICON'] = '1'
        os.environ["TERM"] = "ansi"

    def get_style_class(color_scheme):  # type: (str) -> Type[pygments.style.Style]
        try:
            return pygments.styles.get_style_by_name(color_scheme)
        except ClassNotFound:
            return Solarized256Style

    # Create a ColorFormatter
    formatter = Color

# Generated at 2022-06-23 19:25:45.694184
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(env=Environment(), explicit_json=True)
    lexer = formatter.get_lexer_for_body(mime='text/plain', body='test')
    assert isinstance(lexer, TextLexer)

    lexer = formatter.get_lexer_for_body(mime='application/json', body='test')
    assert lexer is None

    lexer = formatter.get_lexer_for_body(mime='application/json', body='{"a": 1}')
    assert not isinstance(lexer, TextLexer)

# Generated at 2022-06-23 19:25:49.374747
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins.colors import ColorFormatter
    color_formatter = ColorFormatter(None)
    assert color_formatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style
    assert color_formatter.get_style_class(DEFAULT_STYLE) != Solarized256Style

# Generated at 2022-06-23 19:25:51.855747
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style


# Generated at 2022-06-23 19:25:56.404478
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/javascript')
    assert get_lexer('application/vnd.api+json')
    assert get_lexer('application/vnd.api+json', explicit_json=True)
    assert get_lexer('application/vnd.api+json', body='"foo"')
    assert get_lexer('application/vnd.api+json', explicit_json=True, body='"foo"')
    assert get_lexer('application/javascript', body='{"foo": "bar"}')
    assert get_lexer('application/javascript', explicit_json=True, body='{"foo": "bar"}')

# Generated at 2022-06-23 19:26:08.169232
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexers import get_lexer_by_name
    from pygments.formatters.terminal256 import Terminal256Formatter


# Generated at 2022-06-23 19:26:16.943432
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.context
    import json

    def is_json(mime, body):
        lexer = get_lexer(mime=mime, body=body)
        return lexer == pygments.lexers.get_lexer_by_name('json')

    class FakeEnv(object):
        def __init__(self, colors=256):
            self.colors = colors

    # Test get_lexer - JSON response with an incorrect Content-Type?
    env = FakeEnv()
    assert get_lexer(
        mime="application/octet-stream",
        explicit_json=False,
        body=json.dumps({"a": 1})
    ) is None


# Generated at 2022-06-23 19:26:27.480991
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    import json
    import os
    import pygments.styles
    styles_dict = pygments.styles.get_all_styles()
    for style in styles_dict:
        style_class = eval(style)
        text = 'from pygments.style import Style\nclass {}(Style):\n'.format(style)
        for name, color in style_class.styles.items():
            if color == '#000000' and name == 'Text':
                continue
            if color == '#000000' and name == 'Generic.Output':
                continue
            if color == '#000000' and name == 'Generic.Traceback':
                continue
            if color == '#000000' and name == 'Prompt':
                continue
            if color == '#000000' and name == 'Name.Namespace':
                continue

# Generated at 2022-06-23 19:26:34.987621
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class FakeResponse(object):
        headers = {'Content-Type': 'text/html'}

    class FakeEnvironment(object):
        colors = True
        style = 'auto'
        v = 1
        debug = False
        pretty = True
        stream = False
        traceback = False
        verbose = 1

    class FakeSession(object):
        env = FakeEnvironment()
        request = object()
        response = FakeResponse()
        state = object()
        request_history = []

    class FakeHTTPie():
        color_formatter = ColorFormatter(env=FakeEnvironment())
        stdout_isatty = True

    httpie = FakeHTTPie()


# Generated at 2022-06-23 19:26:45.063049
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    """
    Unit test for method format_headers of class ColorFormatter
    """
    def _do_test(self, m_print, m_fmt, m_env, m_color, headers:str, color_scheme:str):
        m_env.colors = 3
        m_env.color_scheme = color_scheme

        headers1 = f"HTTP/1.1 200 OK\r\n" \
                   f"Connection: keep-alive\r\n" \
                   f"Content-Length: 56\r\n" \
                   f"Content-Type: application/json; charset=utf-8\r\n" \
                   f"Date: Tue, 13 Oct 2020 09:57:12 GMT\r\n" \
                   f"\r\n"

# Generated at 2022-06-23 19:26:56.447738
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    from httpie.cli import get_content_type
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.compat import basestring
    from httpie.compat import is_bytes
    from httpie.compat import is_py3

    """
    Define the lexer for all pygments lexers,
    for now TextLexer will be used on dafault
    """
    def _get_lexer_for_body(mime: str, content: str,
                            fp: FormatterPlugin) -> Type[Lexer]:
        return get_lexer(
            mime=mime,
            explicit_json=fp.explicit_json,
            body=content
        )


# Generated at 2022-06-23 19:27:05.481319
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from .test_format import httpbin, assert_formatted_output

    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    colorized = formatter.format_headers('HTTP/1.1 200 OK\r\nfoo: bar\r\n')
    assert_formatted_output(
        httpbin('get'),
        colorized,
        'GET /get HTTP/1.1',
        'Accept: */*',
        'Accept-Encoding: gzip, deflate',
        'Connection: keep-alive',
        'Host: httpbin.org',
        'User-Agent: HTTPie/0.9.9',
        '',
        colorized
    )

# Generated at 2022-06-23 19:27:06.718458
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    ColorFormatter(None, SOLARIZED_STYLE)
    ColorFormatter(None, 'manni')

# Generated at 2022-06-23 19:27:11.317293
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    e = Environment(headers=True, style=DEFAULT_STYLE, colors=True)
    f = ColorFormatter(env=e)
    print(f.format_body('{"status": "success"}', 'application/json'))

# Generated at 2022-06-23 19:27:12.633518
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()

# Generated at 2022-06-23 19:27:18.657229
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(env=None)
    assert formatter.format_headers('Content-Type: text/plain') == '\x1b[1m\x1b[94mContent-Type\x1b[0m: \x1b[0m\x1b[93mtext/plain\x1b[0m\n'

test_ColorFormatter_format_headers()

# Generated at 2022-06-23 19:27:24.489523
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie import ExitStatus
    import pytest
    httpie_args = ['--print', 'Bh', 'https://httpbin.org/headers', 'X-Foo:bar']
    result = http(*httpie_args, env=Environment())
    assert result.exit_status == ExitStatus.OK
    assert '\x1b[38;5;10m' in result.stderr




# Generated at 2022-06-23 19:27:29.440537
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('default') != Solarized256Style

# Generated at 2022-06-23 19:27:39.689476
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    from httpie.compat import urljoin
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.downloads import (
        ALL_CONTENT_TYPES,
        CONTENT_TYPES_TO_LEXERS,
        CONTENT_TYPES_TO_LEXERS_LOCAL,
        CONTENT_TYPE_JSON,
        CONTENT_TYPE_XML,
    )


# Generated at 2022-06-23 19:27:44.650095
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.cli import parser
    args = parser.parse_args(args=[], env=Environment())
    args.json = True
    cf = ColorFormatter(env=args.__dict__)
    body = "{\n  \"a\": \"b\"\n}"
    assert cf.format_body(body, mime="application/json") == body

# Generated at 2022-06-23 19:27:49.440660
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # no lexer
    lexer = get_lexer("test/test")
    assert lexer == None
    # with lexer
    lexer = get_lexer("application/json")
    assert lexer == pygments.lexers.get_lexer_by_name('json')


# Generated at 2022-06-23 19:27:50.619966
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert style._name == 'solarized256'
    assert style._style['Token.Other'] == '#d75f00'



# Generated at 2022-06-23 19:28:00.241078
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer(
        mime="text/plain",
        explicit_json=False,
        body="some text"
    ) is None

    assert get_lexer(
        mime="text/plain",
        explicit_json=False,
        body='{"some_field": "value"}'
    ) is None

    assert get_lexer(
        mime="text/plain",
        explicit_json=True,
        body='{"some_field": "value"}'
    ).name == 'JSON'

    assert get_lexer(
        mime="application/json",
        explicit_json=False,
        body="some text"
    ) is None


# Generated at 2022-06-23 19:28:10.828940
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie import cli
    from httpie import core

    env = core.Environment()
    cli.get_parser(env).parse_args(argv=[])
    env.colors = True

    color_formatter = ColorFormatter(env)
    body = '{"Name": "Jay"}'
    mime = 'application/json'
    body = color_formatter.format_body(body, mime)


# Generated at 2022-06-23 19:28:15.676670
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer.tokens['root'][0] == \
        (r'([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)',
         pygments.lexer.bygroups(pygments.token.Name.Function,
                                 pygments.token.Text,
                                 pygments.token.Name.Namespace,
                                 pygments.token.Text,
                                 pygments.token.Keyword.Reserved,
                                 pygments.token.Operator,
                                 pygments.token.Number)
         )

# Generated at 2022-06-23 19:28:23.693794
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexers.text import HttpLexer
    text = """\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>"""

    z = SimplifiedHTTPLexer()
    y = HttpLexer()
    assert z.get_tokens(text) == y.get_tokens(text)

# Generated at 2022-06-23 19:28:32.495059
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import json

    # test json
    body = json.dumps({'foo': 'bar'})

    lexer = ColorFormatter({}).get_lexer_for_body(
        'text/plain', body
    )
    assert lexer is None

    lexer = ColorFormatter({}).get_lexer_for_body(
        'application/json', body
    )
    assert lexer is not None

    lexer = ColorFormatter({}).get_lexer_for_body(
        'application/javascript', body
    )
    assert lexer is not None

    lexer = ColorFormatter({}).get_lexer_for_body(
        'text/javascript', body
    )
    assert lexer is None


    # test xml

# Generated at 2022-06-23 19:28:37.592923
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256, style=DEFAULT_STYLE)
    formatter = ColorFormatter(env, explicit_json=True, color_scheme=SOLARIZED_STYLE)
    assert formatter.get_format_attributes() == ['color']


# Generated at 2022-06-23 19:28:46.473863
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    file_name = './test_ColorFormatter.py'
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
        style=Solarized256Style
    )
    formatter_plugin = ColorFormatter(
        file_name,
        explicit_json=False,
        color_scheme=SOLARIZED_STYLE,
        **{}
    )
    html_mime = 'text/html'
    json_mime = 'application/json'
    body1 = '<html>'
    body2 = '{"a": 1}'
    body3 = '{}'
    lexer1 = formatter_plugin.get_lexer_for_body(html_mime, body1)
    lexer2 = formatter_plugin.get_lexer

# Generated at 2022-06-23 19:28:56.603511
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import textwrap

    # Request
    text = textwrap.dedent("""\
    POST / HTTP/1.1
    Host: localhost
    User-Agent: httpie/0.9.3
    Accept-Encoding: gzip, deflate
    Accept: application/json
    Content-Length: 11
    Content-Type: application/json; charset=utf-8

    {
    """)

    # Colors should not be escaped, i.e.:
    # "\x1b[93m" should be "[93m"

# Generated at 2022-06-23 19:28:57.734332
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Local Variables:
# End:

# Generated at 2022-06-23 19:29:06.906030
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment(colors='auto')
    cf = ColorFormatter(env, explicit_json=False, color_scheme='solarized')

    def assert_body_parsing_for(mime: str, body: str, expected: Optional[Type[Lexer]]):
        lexer = cf.get_lexer_for_body(mime, body)
        assert lexer is expected, f"{lexer} is not expected {expected} for {mime}/{body}"

    assert_body_parsing_for(mime='text/html', body='', expected=None)
    assert_body_parsing_for(mime='text/html', body=' ', expected=None)
    assert_body_parsing_for(mime='text/html', body='<', expected=None)

# Generated at 2022-06-23 19:29:07.826491
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    pass


# Generated at 2022-06-23 19:29:16.360297
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import httpie
    import re
    import httpie.plugins
    import httpie.context

    # Setup
    env = httpie.context.Environment(
        colors=True,
        stdin=None,
        stdout=None,
        stderr=None
    )
    color_formatter = httpie.plugins.ColorFormatter(env, explicit_json=True, color_scheme=SOLARIZED_STYLE)
    headers = [
        "HTTP/1.1 200 OK",
        "Date: Wed, 31 Aug 2016 00:00:00 GMT",
        "Server: Apache",
        "Content-Type: text/html; charset=utf-8"
        "Cache-Control: no-cache, no-store, max-age=0, must-revalidate",
    ]

    # Test


# Generated at 2022-06-23 19:29:26.294211
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', True)
    assert not get_lexer('application/json', True, '{')
    assert not get_lexer('application/json', False, '{')

    assert get_lexer('text/html')
    assert get_lexer('text/html', True)
    assert get_lexer('text/html', True, '<html>')
    assert get_lexer('text/html', False, '<html>')

    assert get_lexer('text/plain+abc')
    assert get_lexer('text/plain+abc', True)
    assert get_lexer('text/plain+abc', True, 'abc')
    assert get_lexer('text/plain+abc', False, 'abc')