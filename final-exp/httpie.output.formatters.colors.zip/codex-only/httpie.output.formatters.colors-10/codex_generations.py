

# Generated at 2022-06-23 19:19:23.953103
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-23 19:19:25.151356
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style(Solarized256Style)

# Generated at 2022-06-23 19:19:33.602942
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    from httpie.config import UNSET
    from httpie.plugins.builtin import HTTPBasicAuth
    env = Environment(stdin=UNSET,
                      stdout=UNSET,
                      stderr=UNSET,
                      stdin_isatty=True,
                      stdout_isatty=True,
                      stderr_isatty=True,
                      output_options={"pretty": UNSET, "colors": True},
                      config_dir=None,
                      config_file=None,
                      env=None,
                      session=None)
    http_auth = HTTPBasicAuth()
    col = ColorFormatter(env, http_auth.auth)
    assert col.formatter.style == Solarized256Style
    assert col.formatter.style == Solarized256Style
    assert col

# Generated at 2022-06-23 19:19:44.941886
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.utils import get_binary_stream
    from httpie.context import Environment
    from httpie.compat import isatty
    from httpie.plugins import FormatterPlugin


    class AssertColorFormatter(ColorFormatter):
        def format_headers(self, headers: str) -> str:
            result = super().format_headers(headers)
            assert isinstance(result, str)
            assert isatty(get_binary_stream("stdout"))

    headers = """POST /post HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 5
Content-Type: application/json
User-Agent: HTTPie/1.0.2

{
    "key": "val"
}"""

# Generated at 2022-06-23 19:19:52.551247
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True
    assert type(color_formatter.formatter) == Terminal256Formatter
    assert color_formatter.formatter.style == Solarized256Style
    assert type(color_formatter.http_lexer) == SimplifiedHTTPLexer

# Generated at 2022-06-23 19:19:53.575172
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    solarized256Style = Solarized256Style()

# Generated at 2022-06-23 19:20:02.121841
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter(
        env=Environment(colors=256, pp=None, stdin=None, isatty=True),
        color_scheme='solarized',
        error_formatter=None,
        explicit_json=False
    )
    assert cf.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert cf.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert cf.explicit_json == False
    from httpie.cli import get_lexer
    lexer = get_lexer(mime='application/json', explicit_json=False, body='')
    assert lexer.__class__.__name__, 'JsonLexer'

# Generated at 2022-06-23 19:20:12.923178
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Arrange
    from httpie.context import Environment
    from httpie.compat import is_windows, is_py38
    from httpie.formatter.colors import get_lexer, ColorFormatter
    from httpie import ExitStatus

    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        colors=256,
        configure_logging=False,
        config=None,
        defaults=None,
        output_options=None,
    )

    color_formatter = ColorFormatter(env, color_scheme="solarized")

    # Act

# Generated at 2022-06-23 19:20:24.359380
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(style=Solarized256Style)

    headers = b'GET / HTTP/1.1\r\nHost: example.com\r\n\r\n'


# Generated at 2022-06-23 19:20:33.310309
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    result = formatter.format_headers(
        'Content-Type: text/html\r\n'
        'Content-Length: 1234\r\n'
        'Set-Cookie: foo=bar\r\n'
        'Set-Cookie: baz=qux\r\n\r\n'
    )

# Generated at 2022-06-23 19:20:40.582733
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class Environment:
        def __init__(self,colors):
            self.colors = colors
    json_response = '{"id" : 12, "name" : "string", "color" : "red"}'
    plain_response = "This is not json"
    formatters = [ColorFormatter(Environment(256))]
    assert isinstance(formatters[0].get_lexer_for_body("application/json",json_response),type(pygments.lexers.get_lexer_by_name("json")))
    assert isinstance(formatters[0].get_lexer_for_body("application/json",plain_response),type(pygments.lexers.get_lexer_by_name("json")))

# Generated at 2022-06-23 19:20:51.302253
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from mock import Mock

    class FakeStream:
        def __init__(self, content):
            self.content = content

        def read(self, size=-1):
            return self.content

    class FakeEnvironment:
        def __init__(self, colors):
            self.colors = colors

    def test(content, expected_tokens, expected_texts, expected_styles):
        tokens = []
        texts_ = []
        styles_ = []
        def get_tokens_unhighlighted(stream):
            assert stream == stream_
            return iter(tokens.pop(0))
        stream_ = None

# Generated at 2022-06-23 19:20:53.751878
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class('solarized')
    assert style.__name__ == 'Solarized256Style'


# Generated at 2022-06-23 19:20:55.997651
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    StyleClass = ColorFormatter.get_style_class("solarized")
    assert(StyleClass is Solarized256Style)

# Generated at 2022-06-23 19:20:57.291935
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert 1 == 1
    assert 2 == 2
    assert 3 == 3


# Generated at 2022-06-23 19:21:04.942632
# Unit test for function get_lexer
def test_get_lexer():

    mimes = [
        'application/javascript',
        'text/javascript',
        'text/js',
        'text/vbscript',
        'application/xml',
        'text/xml',
        'application/atom+xml',
        'text/css',
    ]

    for mime in mimes:
        lexer = get_lexer(mime)
        assert lexer, mime

    assert get_lexer('application/xml') == pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('text/xml') == pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('text/css') == pygments.lexers.get_lexer_by_name('css')


# Generated at 2022-06-23 19:21:08.848649
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(color_scheme=SOLARIZED_STYLE) == Solarized256Style
    assert ColorFormatter.get_style_class(color_scheme='monokai') == pygments.styles.get_style_by_name('monokai')
    assert ColorFormatter.get_style_class(color_scheme='unknown') == pygments.styles.get_style_by_name('default')
    assert ColorFormatter.get_style_class(color_scheme=AUTO_STYLE) == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-23 19:21:10.207748
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()

# Generated at 2022-06-23 19:21:19.086271
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.output.streams import stdout, stderr
    from httpie.output.stream import Stream

    env = Environment(stdout=stdout, stderr=stderr, colors=True)
    formatter = ColorFormatter(env)

    body = '{"key": "value"}'
    mime = 'application/json'
    result = formatter.format_body(body, mime)
    assert isinstance(result, str)  # result is a string

    body = 'blablabla'
    mime = 'text/html'
    result = formatter.format_body(body, mime)
    assert isinstance(result, str)  # result is a string

# Generated at 2022-06-23 19:21:23.946456
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.colors import ColorFormatter
    assert ColorFormatter.get_style_class('nocolor') is None
    assert ColorFormatter.get_style_class('fruity') is not None
    assert ColorFormatter.get_style_class('solarized') is not None



# Generated at 2022-06-23 19:21:29.035788
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, explicit_json=True, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter is not None
    assert formatter.formatter.__class__ == Terminal256Formatter
    assert formatter.http_lexer.__class__ == SimplifiedHTTPLexer

# Generated at 2022-06-23 19:21:36.999630
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    colorFormatter = ColorFormatter(Environment(0, True, ""), False, AUTO_STYLE)
    text = False
    json = False
    html = False
    xml = False
    body = "test"
    assert colorFormatter.get_lexer_for_body("text/plain", body) or text
    assert colorFormatter.get_lexer_for_body("application/json", body) or json
    assert colorFormatter.get_lexer_for_body("text/html", body) or html
    assert colorFormatter.get_lexer_for_body("text/xml", body) or xml

# Generated at 2022-06-23 19:21:44.608992
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # It should colorize headers with a stronger contrast
    # for values than the original Pygments HTTP lexer.
    from httpie.plugins.builtin import HTTPHeadersPlugin
    env = Environment()
    headers = HTTPHeadersPlugin().format_headers(
        headers={'Foo': 'bar'},
        env=env,
    )
    assert '\x1b' in headers  # ANSI color is present


# Generated at 2022-06-23 19:21:46.428049
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():  # pragma: no cover
    pygments.styles.get_style_by_name('solarized256')

# Generated at 2022-06-23 19:21:50.231088
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # The style solarized256 is defined above
    style = ColorFormatter.get_style_class('solarized256')
    assert style == Solarized256Style

# Generated at 2022-06-23 19:21:59.994105
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.output.streams import Unbuffered

    f = ColorFormatter(None, color_scheme='terminal256')
    body = {'a': 1, 'b': 2}
    mime = 'application/json'
    # body = '[]'
    # mime = 'application/json'
    # body = '<a>b</a>'
    # mime = 'text/xml'
    mime = 'text/json'
    body = ''
    body = '<a>b</a>'
    stream = Unbuffered(mode='w+')
    stream.write(f.format_body(json.dumps(body), mime))
    stream.seek(0)
    print(stream.read())


if __name__ == '__main__':
    test_ColorFormatter

# Generated at 2022-06-23 19:22:05.735680
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.input import ParseError
    from httpie.plugins import PluginError
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)
    resp = 'Hello world'
    res = formatter.format_body(body=resp, mime='application/json')
    assert res == resp

    resp = '{ "name" : "John Doe}'
    try:
        res = formatter.format_body(body=resp, mime='application/json')
        assert res == resp
    except ParseError:
        assert True
    except PluginError:
        assert True

# Generated at 2022-06-23 19:22:13.653311
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    import unittest

    class TestSolarized256Style(unittest.TestCase):
        def setUp(self):
            self.test_style = Solarized256Style

        def test_BASE03_attribute(self):
            self.assertEqual(self.test_style.BASE03, "#1c1c1c")

        def test_BASE01_attribute(self):
            self.assertEqual(self.test_style.BASE01, "#4e4e4e")

        def test_BASE00_attribute(self):
            self.assertEqual(self.test_style.BASE00, "#585858")

        def test_BASE0_attribute(self):
            self.assertEqual(self.test_style.BASE0, "#808080")


# Generated at 2022-06-23 19:22:16.916501
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class(SOLARIZED_STYLE)
    assert issubclass(style_class, pygments.style.Style)
    assert style_class is Solarized256Style

# Generated at 2022-06-23 19:22:20.079561
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']


# Generated at 2022-06-23 19:22:30.939472
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # test case: only use color, 256 color, and color scheme
    class Env256(object):
        def __init__(self):
            self.colors = 256
    env256 = Env256()

    class Env(object):
        def __init__(self):
            self.colors = True
    env = Env()

    cf_256_auto = ColorFormatter(env256, False, 'auto')
    assert cf_256_auto.formatter.style == Solarized256Style
    assert cf_256_auto.http_lexer == SimplifiedHTTPLexer

    cf_256_solarized = ColorFormatter(env256, False, 'solarized')
    assert cf_256_solarized.formatter.style == Solarized256Style
    assert cf_256_solarized.http_lex

# Generated at 2022-06-23 19:22:33.376472
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    tokens = list(lexer.get_tokens('GET / HTTP/1.1'))
    assert tokens[0][0] == pygments.token.Name.Function
    assert tokens[0][1] == 'GET'


# Generated at 2022-06-23 19:22:36.711912
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.console
    from httpie.context import Environment
    env = Environment()
    # Commented because of the following error:
    # ValueError: Attempted relative import in non-package
    # color = Color(env.colors)
    env.stdout = httpie.console.SourceCodeConsole(env.stdout, color)

# Generated at 2022-06-23 19:22:42.610477
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style
    assert ColorFormatter.get_style_class('manni') is pygments.styles.manni
    assert ColorFormatter.get_style_class('default') is pygments.styles.default

# Generated at 2022-06-23 19:22:44.291609
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(None, None)
    assert color_formatter is not None

# Generated at 2022-06-23 19:22:51.828130
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') is not None
    assert get_lexer('application/json', body='{}') is not None
    assert get_lexer(mime='application/json', explicit_json=True) is not None
    assert get_lexer(mime='application/json', explicit_json=True, body='{}') is not None
    assert get_lexer('application/bogus', body='{}') is not None
    assert get_lexer(mime='application/bogus', explicit_json=True, body='{}') is not None
    assert get_lexer(mime='application/bogus', explicit_json=True, body='hello') is None
    assert get_lexer('application/xml') is not None

# Generated at 2022-06-23 19:22:58.122137
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json=False
    color_scheme=DEFAULT_STYLE
    formatter = ColorFormatter(env, explicit_json, color_scheme)
    assert formatter.explicit_json == False
    assert formatter.formatter == TerminalFormatter()
    assert formatter.http_lexer == PygmentsHttpLexer()


# Generated at 2022-06-23 19:23:05.299927
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class ColorFormatter(object):
        def format_body(self, body: str, mime: str) -> str:
            lexer = self.get_lexer_for_body(mime, body)
            if lexer:
                body = pygments.highlight(
                    code=body,
                    lexer=lexer,
                    formatter=self.formatter,
                )
            return body

    test = ColorFormatter()

    # Check if the mime type is supported

# Generated at 2022-06-23 19:23:09.089408
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from pygments.formatters.terminal256 import Terminal256Formatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import Solarized256Style

    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style



# Generated at 2022-06-23 19:23:19.374833
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    env = Environment()
    formatter = ColorFormatter(env=env, color_scheme="auto")
    assert formatter.get_lexer_for_body("text/plain",
                                        "Hello HTTPie") is None
    assert formatter.get_lexer_for_body("text/plain",
                                        "Hello HTTPie",) is None
    assert formatter.get_lexer_for_body("application/json",
                                        "{'a':'b'}") is pygments.lexers.get_lexer_by_name("json")

# Generated at 2022-06-23 19:23:22.172102
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment(colors=True)
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled

# Generated at 2022-06-23 19:23:23.165787
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()



# Generated at 2022-06-23 19:23:34.002215
# Unit test for function get_lexer

# Generated at 2022-06-23 19:23:37.508480
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():

    env = Environment()
    env.colors = 256
    color_scheme = 'solarized'

    cf = ColorFormatter(env=env, color_scheme=color_scheme)

    assert cf.get_style_class(color_scheme) == Solarized256Style

# Generated at 2022-06-23 19:23:41.713608
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    """Test the method ColorFormatter.format_body.

    If the MIME type is json, json lexer should be used.
    """
    lexer = get_lexer('application/json')
    assert lexer.alias == ['json']
    assert lexer.name == 'JSON'

# Generated at 2022-06-23 19:23:44.589290
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter()
    style = color_formatter.get_style_class('solarized')
    assert(isinstance(style, Solarized256Style))

# Generated at 2022-06-23 19:23:56.117367
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # httpie should work without Pygments
    # ImportError: No module named 'pygments'
    from httpie.output.formatters import JsonFormatter, get_formatter

    fmt = get_formatter('json')
    assert isinstance(fmt, JsonFormatter)

    fmt = get_formatter('Colors')
    assert isinstance(fmt, ColorFormatter)

    fmt_headers = fmt.format_headers(
        'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nAllow: GET\r\n\r\n'
    )

# Generated at 2022-06-23 19:23:58.253122
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    styles = ['emacs', 'solarized', 'none']
    for style in styles:
        assert ColorFormatter.get_style_class(style)

# Generated at 2022-06-23 19:24:07.053650
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(
        environment=None,
        explicit_json=False,
        color_scheme='monokai'
    )
    style = color_formatter.get_style_class('monokai')
    assert style.__name__ == 'MonokaiStyle'

    color_formatter = ColorFormatter(
        environment=None,
        explicit_json=False,
        color_scheme='solarized'
    )
    style = color_formatter.get_style_class('solarized')
    assert style.__name__ == 'Solarized256Style'

# Generated at 2022-06-23 19:24:08.064517
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    solarized256Style = Solarized256Style()
    pass

# Generated at 2022-06-23 19:24:15.215483
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def t(mime, body, expected_lexer_name=None):
        env = Environment()
        env.colors = 256
        cf = ColorFormatter(env)
        lexer = cf.get_lexer_for_body(mime, body)
        result = None
        if lexer:
            result = lexer.name
        assert (result == expected_lexer_name)

    t('text/html', '_', 'html')
    t('text/html', '<style type="text/css">p:before { content: "hello" }</style>', 'html')
    t('text/html', '<script>alert("hello");</script>', 'html')
    t('text/html', '<script type="text/javascript">alert("hello");</script>', 'html')

# Generated at 2022-06-23 19:24:20.673017
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True)
    color_formatter = ColorFormatter(env)

    assert color_formatter.explicit_json == False
    assert color_formatter.http_lexer.name == 'HTTP'
    assert color_formatter.formatter.name == 'Terminal'

# Generated at 2022-06-23 19:24:21.345270
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:24:22.583293
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(None, None)

# Generated at 2022-06-23 19:24:25.964151
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    check_ColorFormatter = ColorFormatter(
        env=Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    assert check_ColorFormatter is not None


# Generated at 2022-06-23 19:24:36.262948
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    fm = ColorFormatter(None)
    assert 'Python' == fm.get_lexer_for_body('text/x-python',
        'def hello():\n\tprint("Hello World!")\n') \
        .__class__.__name__

    assert 'Python' == fm.get_lexer_for_body('application/python',
        'def hello():\n\tprint("Hello World!")\n') \
        .__class__.__name__


# Generated at 2022-06-23 19:24:46.535682
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    _env = Environment()
    _env.colors = True
    _env.colors_force = True

    formatter = ColorFormatter(_env)

    result = formatter.format_headers(
        '\r\n'.join([
            'GET / HTTP/1.1',
            'Host: example.org',
            'User-Agent: HTTPie/0.9.2',
            'Accept-Encoding: gzip, deflate',
            'Accept: */*',
            'Connection: keep-alive',
            '',
            ''
        ])
    )


# Generated at 2022-06-23 19:24:48.562424
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:24:49.685519
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:24:55.046704
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.formatters.terminal256 import Terminal256Formatter
    from httpie.utils import strip_ws
    formatter = Terminal256Formatter(style=None)
    lexer = SimplifiedHTTPLexer()
    lines = [
        "GET / HTTP/1.1",
        "X-Auth: hankgao",
        "",
        "HTTP/1.1 200 ok",
        "Content-Type: application/json",
        "",
    ]
    code = '\n'.join(lines)
    print(pygments.highlight(code, lexer, formatter).rstrip())

# Generated at 2022-06-23 19:25:03.667476
# Unit test for function get_lexer
def test_get_lexer():
    assert type(get_lexer('application/json')) is pygments.lexers.JsonLexer
    assert type(get_lexer('application/json;charset=UTF-8')) is pygments.lexers.JsonLexer
    assert type(get_lexer('application/vnd.api+json')) is pygments.lexers.JsonLexer
    assert type(get_lexer('application/vnd.api+json;charset=UTF-8')) is pygments.lexers.JsonLexer
    assert type(get_lexer('application/json-p')) is pygments.lexers.JsonLexer
    assert type(get_lexer('application/x-json')) is pygments.lexers.JsonLexer

# Generated at 2022-06-23 19:25:04.746734
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    solarized256 = Solarized256Style()

# Generated at 2022-06-23 19:25:15.675424
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''GET / HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: Python-Requests
'''
    result = color_formatter.format_headers(headers)

# Generated at 2022-06-23 19:25:23.767259
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import core

    formatter = ColorFormatter(
        env=core.Environment(),
        explicit_json=False,
        color_scheme=SOLARIZED_STYLE,
        is_tty=True,
    )

    headers = "GET http://example.org/ HTTP/1.1 \r\nContent-Type: text/html; charset=utf-8\r\n\r\n"

    result = formatter.format_headers(headers)

    assert result.count('\n') == 4

# Generated at 2022-06-23 19:25:35.436732
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert(SimplifiedHTTPLexer.tokens)
    # Request-Line
    match_string = r'([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)'
    match_string_test = r'GET /test HTTP/1.1'
    import re
    match_result = re.match(match_string, match_string_test)
    assert(match_result.groups())
    # Response Status-Line
    match_string = r'(HTTP)(/)(\d+\.\d+)( +)(\d{3})( +)(.+)'
    match_string_test = r'HTTP/1.1 200 OK'
    match_result = re.match(match_string, match_string_test)
    assert(match_result.groups())

# Generated at 2022-06-23 19:25:44.575842
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    token = getattr(pygments.token, 'Token')
    assert SimplifiedHTTPLexer.tokens['root'][1] == (
        r'(HTTP)(/)(\d+\.\d+)( +)(\d{3})( +)(.+)',
        [
            token.Keyword.Reserved,  # 'HTTP'
            token.Operator,  # '/'
            token.Number,  # Version
            token.Text,
            token.Number,  # Status code
            token.Text,
            token.Name.Exception,  # Reason
        ]
    )

# Generated at 2022-06-23 19:25:50.554397
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main
    from httpie.output.streams import DEFAULT_STREAMS
    args = ['color']
    kwargs = {"argv": ["--debug", "--headers", "ColorFormatter.py"], "method": "GET", "env": Environment({}), "streams": DEFAULT_STREAMS}
    exit_status, output_bytes, session = main(args, **kwargs)
    output_text = output_bytes.decode('utf8')
    assert output_text.startswith('HTTP/1.1 200 OK\n')
    assert 'color' in output_text

# Generated at 2022-06-23 19:26:00.784674
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class FakeEnvironment(Environment):
        def __init__(self):
            super().__init__()
            self.colors = True

    colorformatter = ColorFormatter(FakeEnvironment())
    assert colorformatter.format_body('this is a test', 'text/plain') == '\x1b[38;5;254mthis is a test\x1b[39m'
    assert colorformatter.format_body('this is a test', 'text/html') == '\x1b[38;5;254mthis is a test\x1b[39m'

# Generated at 2022-06-23 19:26:03.582662
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    cf = ColorFormatter(Environment(), False)
    assert cf.format_body('abc', '').strip() == 'abc'


# Generated at 2022-06-23 19:26:12.358506
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import datetime
    ColorFormatter = ColorFormatter(env = Environment())

# Generated at 2022-06-23 19:26:17.911325
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) != Solarized256Style
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-23 19:26:18.971443
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    c = ColorFormatter()

# Generated at 2022-06-23 19:26:20.843525
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    f = ColorFormatter(False, [])
    assert 'True' == str(f.enabled)

# Generated at 2022-06-23 19:26:30.835762
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.core import main
    from httpie.formatter import JSONFormatter
    from httpie.output.streams import NoopStream
    from pygments.formatters.terminal import TerminalFormatter
    import json
    import os
    import sys

    class PrintStream(NoopStream):

        def __init__(self):
            self.text = ''

        def write(self, text):
            self.text += text

    # Create an environment with color turned on
    env = Environment(colors=256)

    # Create an instance of ColorFormatter with environment

# Generated at 2022-06-23 19:26:32.552709
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Verify that style class is found by get_style_class()
    assert ColorFormatter.get_style_class(color_scheme=DEFAULT_STYLE)

# Generated at 2022-06-23 19:26:33.103345
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:26:44.243178
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    env = Environment(stdout=None, colors=256)
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    http_response_headers = (
        'HTTP/1.1 200 OK\r\n'
        'Connection: keep-alive\r\n'
        'Content-Length: 15\r\n'
        '\r\n'
        '{}\r\n'
    ).format(BINARY_SUPPRESSED_NOTICE)


# Generated at 2022-06-23 19:26:50.456448
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Test 'application/json' with valid JSON
    assert ColorFormatter(env=Environment(color=True)).get_lexer_for_body(
        mime="application/json",
        body="[{'a':1}]") == pygments.lexers.get_lexer_by_name('json')

    # Test 'application/json' with invalid JSON
    assert ColorFormatter(env=Environment(color=True)).get_lexer_for_body(
        mime="application/json",
        body="{") is None

    # Test 'application/json' with invalid JSON and --json

# Generated at 2022-06-23 19:26:55.150574
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class(SOLARIZED_STYLE)
    assert style_class == Solarized256Style

    style_class = ColorFormatter.get_style_class('monokai')
    assert style_class.__name__ == 'MonokaiStyle'

# Generated at 2022-06-23 19:27:02.614154
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer(startinline=True)
    tokens = lexer.get_tokens_unprocessed(
        "GET / HTTP/1.1\r\n"
        "Host: foo.bar\r\n"
        "Foo: Bar\r\n"
        "Baz: Qux\r\n"
        "\r\n")

# Generated at 2022-06-23 19:27:12.238031
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color = ColorFormatter(env = env,
                           explicit_json = True,
                           color_scheme = 'solarized')
    assert color.formatter.__class__ == Terminal256Formatter
    assert color.http_lexer.__class__ == SimplifiedHTTPLexer
    assert color.explicit_json == True

    env.colors = 16
    color = ColorFormatter(env = env,
                           explicit_json = True,
                           color_scheme = 'auto')
    assert color.formatter.__class__ == TerminalFormatter
    assert color.http_lexer.__class__ == PygmentsHttpLexer
    assert color.explicit_json == True


# Generated at 2022-06-23 19:27:22.608929
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Use a simplified version of the body of a response
    body = "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">\n<html><head>\n<title>400 Bad Request</title>\n</head><body>\n<h1>Bad Request</h1>\n<p>Your browser sent a request that this server could not understand.<br />\n</p>\n</body></html>\n"
    # Use the ColorFormatter class to format the body
    color_formatter = ColorFormatter(Environment())
    body = color_formatter.format_body(body, "text/html")
    # Check the color formatting is correct

# Generated at 2022-06-23 19:27:24.311020
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplifiedhttp_lexer = SimplifiedHTTPLexer()
    assert simplifiedhttp_lexer is not None

# Generated at 2022-06-23 19:27:25.250496
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()

# Generated at 2022-06-23 19:27:26.838996
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-23 19:27:37.518721
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:27:39.063953
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('vs') is pygments.styles.get_style_by_name('vs')



# Generated at 2022-06-23 19:27:41.019892
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter(Environment())
    assert cf.enabled, 'Expected formatter to be enabled'

    explicit_json = False
    cf = ColorFormatter(Environment(), explicit_json=explicit_json)
    assert not cf.explicit_json

# Generated at 2022-06-23 19:27:49.046262
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    colorFormatter = ColorFormatter(Environment(colors=False))
    content_types_json = {
        'application/json',
        'text/javascript',
        'application/javascript',
        'application/x-javascript',
        'text/x-javascript',
        'text/x-json',
        'application/x-json'
    }

    for content_type in content_types_json:
        assert isinstance(colorFormatter.get_lexer_for_body(content_type, '--json'), pygments.lexers.get_lexer_by_name('json'))
        assert isinstance(colorFormatter.get_lexer_for_body(content_type, '--form'), pygments.lexers.get_lexer_by_name('json'))

# Generated at 2022-06-23 19:27:59.730527
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert pygments.lexers.JsonLexer == get_lexer_for_body(
        'application/json', '')
    assert pygments.lexers.JsonLexer == get_lexer_for_body(
        'application/json; charset=UTF-8', '')
    assert pygments.lexers.JsonLexer == get_lexer_for_body(
        'application/json', '{}')
    assert pygments.lexers.JsonLexer == get_lexer_for_body(
        'application/json; charset=UTF-8', '{}')
    assert pygments.lexers.DiffLexer == get_lexer_for_body(
        'text/x-diff', '')
    assert pygments.lexers.DiffLexer == get_lexer_for_body

# Generated at 2022-06-23 19:28:08.273847
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    env = Environment(colors=256)
    a = ColorFormatter(env=env, color_scheme='solarized')

    assert a.get_lexer_for_body("text/plain", "") == None
    assert a.get_lexer_for_body("text/plain", "test") == None

    assert a.get_lexer_for_body("application/json", "") == pygments.lexers.JSONLexer
    assert a.get_lexer_for_body("application/json", "test") == pygments.lexers.JSONLexer
   

# Generated at 2022-06-23 19:28:14.903617
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime="text/html") == pygments.lexers.get_lexer_by_name("html")
    assert get_lexer(mime="application/json") == pygments.lexers.get_lexer_by_name("json")
    assert get_lexer(mime="application/javascript") == pygments.lexers.get_lexer_by_name("javascript")
    assert get_lexer(mime="text/plain") == pygments.lexers.get_lexer_by_name("text")
    assert get_lexer(mime="text/plain") == pygments.lexers.get_lexer_by_name("text")

# Generated at 2022-06-23 19:28:25.032522
# Unit test for function get_lexer

# Generated at 2022-06-23 19:28:26.032548
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    pass

# Generated at 2022-06-23 19:28:28.185007
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    assert isinstance(ColorFormatter(env), ColorFormatter)


# Generated at 2022-06-23 19:28:29.439967
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(None)

# Generated at 2022-06-23 19:28:40.781892
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    formatter = ColorFormatter(Environment())
    assert formatter.get_lexer_for_body('application/json', '') is not None
    assert formatter.get_lexer_for_body('application/x-javascript', '') is not None
    assert formatter.get_lexer_for_body('application/vnd.api+json', '') is not None
    assert formatter.get_lexer_for_body('application/vnd.json', '') is not None
    assert formatter.get_lexer_for_body('application/json;charset=UTF-8', '') is not None
    assert formatter.get_lexer_for_body('application/x-javascript;charset=UTF-8', '') is not None

# Generated at 2022-06-23 19:28:51.004465
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    http = """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.3
"""

# Generated at 2022-06-23 19:28:52.626019
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer is not None

# Generated at 2022-06-23 19:29:00.712365
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body='{}')

    assert get_lexer('application/vnd.api+json', explicit_json=True)
    assert get_lexer('application/vnd.api+json', explicit_json=False)
    assert get_lexer('application/vnd.api+json', explicit_json=True, body='{}')
    assert get_lexer('application/vnd.api+json', explicit_json=False, body='{}')

    assert get_lexer('application/vnd.api+json')

# Generated at 2022-06-23 19:29:10.643078
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class MockEnvironment:
        def __init__(self):
            self.colors = True

    mime = 'application/json'
    body = '''
    {
        "key1": "value1",
        "key2": "value2"
    }
    '''

# Generated at 2022-06-23 19:29:17.184708
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import PluginManager

    try:
        from mock import patch
    except ImportError as e:
        import unittest.mock as patch

    # noinspection PyUnresolvedReferences
    import httpie.output.defaults

    pm = PluginManager('httpie.plugins.core',
                       'httpie.plugins.pretty.colors')
    pm.load_installed()

    formatter = ColorFormatter(env=Environment())
    with patch('httpie.compat.is_windows', new=lambda: True):
        with open('tests/fixtures/responses.http') as f:
            code = f.read()
            # no syntax highlighting
            assert formatter.format_body(code, 'text/html') == code

            # syntax highlighting

# Generated at 2022-06-23 19:29:25.129937
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    print("\n### START OF TEST ###\n")
    input_mime = "text/html"
    input_body = "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<title>Unit test</title>"
    output = get_lexer(input_mime, False, input_body)
    expected_output = pygments.lexers.get_lexer_for_mimetype("text/html")
    assert output == expected_output
    print("### END OF TEST ###\n")