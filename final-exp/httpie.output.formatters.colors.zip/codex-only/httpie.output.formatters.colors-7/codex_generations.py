

# Generated at 2022-06-23 19:19:29.858079
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments import highlight
    from pygments.lexers import get_lexer_by_name
    from pygments.formatters import Terminal256Formatter

    lexer = get_lexer_by_name('http')
    lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(style=Solarized256Style)

    request_line = 'GET / HTTP/1.1'
    status_line = 'HTTP/1.1 200 OK'
    header = 'Content-Type: application/json'

    print(highlight(request_line, lexer, formatter))
    print(highlight(status_line, lexer, formatter))
    print(highlight(header, lexer, formatter))


# Generated at 2022-06-23 19:19:39.625679
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-23 19:19:47.892850
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    http_lexer = PygmentsHttpLexer()
    formatter = TerminalFormatter()
    color_scheme = DEFAULT_STYLE
    formatter2 = Terminal256Formatter(
                style=Solarized256Style
            )
    c = ColorFormatter(0, True, 'fruity')
    assert c.enabled == False
    c = ColorFormatter(0, True, 'auto')
    assert c.enabled == False
    c = ColorFormatter(1, True, 'auto')
    assert c.enabled == True
    assert c.explicit_json == True
    assert c.formatter == formatter
    assert c.http_lexer == http_lexer
    c = ColorFormatter(256, True, 'auto')
    assert c.enabled == True
    assert c.explicit_json == True

# Generated at 2022-06-23 19:19:51.893002
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.util import ClassNotFound
    try:
        SimplifiedHTTPLexer()
    except ClassNotFound:
        assert False, "SimplifiedHTTPLexer should not raise ClassNotFound"

# Generated at 2022-06-23 19:20:01.060159
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from pygments.token import Token
    from pygments.styles import get_style_by_name

    from httpie.plugins.builtin import BuiltinPlugin
    from httpie.compat import is_windows

    if is_windows:
        style_name = 'fruity'
    else:
        style_name = 'solarized-dark'
    style = get_style_by_name(style_name)
    formatter = Terminal256Formatter(style=style)
    text = "hello world"
    text_lexer = pygments.lexers.get_lexer_by_name('text')
    text_formatted = pygments.highlight(text, text_lexer, formatter)
    assert isinstance(text_formatted, type(''))
    assert text_formatted == 'hello world'

    json

# Generated at 2022-06-23 19:20:12.005431
# Unit test for function get_lexer
def test_get_lexer():
    import pytest
    from httpie.formatter import get_lexer

    # Test None
    assert get_lexer('text/none').name == 'Text only'

    # Test explicit JSON
    assert get_lexer('text/whatever', explicit_json=True, body='123').name == 'JSON'
    assert get_lexer('text/whatever', explicit_json=True, body='{}').name == 'JSON'

    # Test JSON by mime-type
    assert get_lexer('application/json').name == 'JSON'
    assert get_lexer('application/json-rpc').name == 'JSON-RPC'
    assert get_lexer('text/x-json').name == 'JSON'
    assert get_lexer('text/x-json-rpc').name == 'JSON-RPC'

    # Test

# Generated at 2022-06-23 19:20:22.959090
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie import ExitStatus

    args = {
        '--print': 'B', '--print-headers': '',
    }

# Generated at 2022-06-23 19:20:30.914523
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('foo/bar') is None
    assert isinstance(get_lexer('text/x-python'),
                      pygments.lexers.python.Python3Lexer)
    assert isinstance(get_lexer('application/json'),
                      pygments.lexers.data.JsonLexer)
    assert get_lexer('application/json', explicit_json=True,
                     body='{"a": 1}') is None
    assert isinstance(get_lexer('application/json', explicit_json=True,
                                body='{"a": 1'),
                      pygments.lexers.data.JsonLexer)

# Generated at 2022-06-23 19:20:39.351550
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-23 19:20:50.735311
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie import ExitStatus
    from httpie.input import SEP_CREDENTIALS
    from tests.conftest import http

    # GET because httpbin 500s with binary POST data
    r = http('--print=BHB', 'GET', '--auth=username:password',
             'http://httpbin.org/headers', 'Foo:Bar')
    assert r.exit_status == ExitStatus.OK
    assert 'HTTP/1.1 200' not in r.stderr

    r = http('--print=HB', 'GET', '--auth=username:password',
             'http://httpbin.org/headers')
    assert r.exit_status == ExitStatus.OK
    assert 'HTTP/1.1 200' not in r.stderr
    # Proxy auth headers should be hidden regardless of --print flag.


# Generated at 2022-06-23 19:20:52.739141
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) is Solarized256Style

# Generated at 2022-06-23 19:20:57.066507
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment(colors=True))
    assert formatter.enabled == True
    formatter = ColorFormatter(Environment(colors=256))
    assert formatter.enabled == True
    formatter = ColorFormatter(Environment(colors=False))
    assert formatter.enabled == False


# Generated at 2022-06-23 19:21:04.349200
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import httpie.context

    httpie.context.Environment.colors = '256'
    fmtr = ColorFormatter(httpie.context.Environment)
    assert isinstance(fmtr, ColorFormatter)
    assert fmtr.formatter is not None

    httpie.context.Environment.colors = '16'
    fmtr = ColorFormatter(httpie.context.Environment)
    assert isinstance(fmtr, ColorFormatter)
    assert fmtr.formatter is not None

    httpie.context.Environment.colors = '0'
    fmtr = ColorFormatter(httpie.context.Environment)
    assert isinstance(fmtr, ColorFormatter)
    assert fmtr.formatter is None

# Generated at 2022-06-23 19:21:05.769996
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:21:17.117703
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie import exit_status
    import pytest
    import os

    # Set up all input values that should pass
    os.environ['HTTPIE_COLOR'] = '1'
    formatter = ColorFormatter(Environment({}), False, 'auto')

# Generated at 2022-06-23 19:21:19.243080
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    test1 = Solarized256Style()
    assert hasattr(test1, 'BASE03')
    assert hasattr(test1, 'GREEN')
    assert hasattr(test1, 'Token')

# Generated at 2022-06-23 19:21:20.501023
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    assert False

# Generated at 2022-06-23 19:21:22.276307
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    # type: () -> None
    style = Solarized256Style()

# Generated at 2022-06-23 19:21:31.022385
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import stdout

    formatter = ColorFormatter(stdout, Environment())
    if is_windows:
        assert formatter.formatter.style.styles[
                   pygments.token.Name.Attribute] == '#3b7ad9'
        assert formatter.formatter.style.styles[
                   pygments.token.Operator.Word] == '#3b7ad9'
        assert formatter.formatter.style.styles[
                   pygments.token.Name.Tag] == '#3b7ad9'
    else:
        assert formatter.formatter.style.styles[
                   pygments.token.Name.Attribute] == '#268bd2'
        assert formatter.formatter.style

# Generated at 2022-06-23 19:21:40.066681
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
  from tempfile import TemporaryFile
  from httpie import CLIFormatter
  from httpie.plugins.formatting.colors import ColorFormatter
  from httpie.context import Environment

  # Init CLIFormatter object with color mode set
  env = Environment(colors=256, stdin=TemporaryFile(), stdout=TemporaryFile(), stderr=TemporaryFile())
  colorFormatter = ColorFormatter(env, headers=False, body=False, verbose=False, json=False, style=None,
                                           prettify=False, stream=False,
                                           implicit_json=False, explicit_json=False)
  cliFormatter = CLIFormatter(env, color = colorFormatter)

  # Determine expected result based on color mode

# Generated at 2022-06-23 19:21:47.711255
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class1 = ColorFormatter.get_style_class('solarized')
    class2 = ColorFormatter.get_style_class('monokai')
    # noinspection PyUnresolvedReferences
    assert isinstance(class1, type(pygments.styles.get_style_by_name('solarized')))
    # noinspection PyUnresolvedReferences
    assert isinstance(class2, type(pygments.styles.get_style_by_name('monokai')))
    assert class1 != class2

# Generated at 2022-06-23 19:21:58.968811
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    code = '''\
POST /post/ HTTP/1.1
Host: httpbin.org
Accept: application/json
Content-Type: application/x-www-form-urlencoded

foo=bar&baz=qux
'''
    tokens = list(lexer.get_tokens(code))

# Generated at 2022-06-23 19:22:06.642612
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """Unit test for method format_body of class ColorFormatter."""
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.output import OutputOptions
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.cli import parser
    from httpie import ExitStatus
    from httpie import __version__
    from tests.compat import MockEnvironment, MockRequest
    import pytest
    import os
    import time

    # Create a mock environment
    env = MockEnvironment()

    # Create a mock request object
    request = MockRequest()
    request.method = 'GET'
    request.url = 'http://httpbin.org/get'
    request.headers = {'Content-Type' : 'application/json'}

# Generated at 2022-06-23 19:22:18.107852
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import PluginManager
    from httpie.main import get_response
    from pygments.formatters.terminal256 import Terminal256Formatter
    import pygments.lexers
    import os
    import time


# Generated at 2022-06-23 19:22:21.466338
# Unit test for function get_lexer
def test_get_lexer():
    if not is_windows:
        assert get_lexer('text/xml')
    assert get_lexer('application/xml')
    assert get_lexer('application/json')
    assert get_lexer('application/vnd.github.v3+json')

# Generated at 2022-06-23 19:22:24.209361
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    r = lexer.analyse_text('')
    assert r == 0.5

# Generated at 2022-06-23 19:22:34.608797
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-23 19:22:47.784867
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import http_client, is_py26
    from httpie.plugins import registry
    registry.clear()

    # Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env=env, color_scheme=SOLARIZED_STYLE)

    # Request
    request = http_client.HTTPConnection('example.com')
    request.putrequest('GET', '/')
    request.putheader('Accept', '*/*')
    request.putheader('Connection', 'keep-alive')
    request.putheader('Accept-Encoding', 'gzip, deflate')
    request.putheader('User-Agent', 'HTTPie/0.9.2')
    request.endheaders()

    # Check

# Generated at 2022-06-23 19:22:50.075238
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    """Verifies that Solarized256Style doesn't break due to Pygments
    deprecation of old style classes.
    """
    a = Solarized256Style()
    del a

# Generated at 2022-06-23 19:22:56.852064
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Request-Line
    run_parsing_test(
        SimplifiedHTTPLexer,
        'GET / HTTP/1.1',
        [
            (pygments.token.Name.Function, 'GET'),
            (pygments.token.Text, ' '),
            (pygments.token.Name.Namespace, '/'),
            (pygments.token.Text, ' '),
            (pygments.token.Keyword.Reserved, 'HTTP'),
            (pygments.token.Operator, '/'),
            (pygments.token.Number, '1.1'),
            (pygments.token.Text, '\n')
        ]
    )

    # Response Status-Line

# Generated at 2022-06-23 19:22:58.033034
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()


# Generated at 2022-06-23 19:23:01.769844
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert not get_lexer('text/html')
    assert get_lexer('foo/bar+json')
    assert get_lexer('foo/json+bar')
    assert get_lexer('text/plain', explicit_json=True,
                     body='{"foo": "bar"}')

# Generated at 2022-06-23 19:23:11.196016
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_pygments_256_installed

    def new_ColorFormatter(color_scheme):
        return ColorFormatter(
            Environment(colors=256 if is_pygments_256_installed else None),
            color_scheme=color_scheme,
        )

    # When color_scheme is not specified and Pygments doesn't support
    # 256 colors, the color formatter is not enabled.
    formatter = ColorFormatter(Environment(), None)
    assert not formatter.enabled

    # When color_scheme is not specified and Pygments supports 256 colors,
    # the default 256 color scheme is used.
    formatter = new_ColorFormatter(None)
    assert formatter.enabled
    assert formatter.formatter.style.__class__.__name__ == 'Default256Style'

   

# Generated at 2022-06-23 19:23:14.658144
# Unit test for function get_lexer
def test_get_lexer():
    # This will raise pygments.util.ClassNotFound if something is wrong
    get_lexer('text/plain')
    get_lexer('text/plain', explicit_json=True, body='{}')

# Generated at 2022-06-23 19:23:22.640228
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():

    env = Environment(colors = 256)
    cf = ColorFormatter(env)
    assert cf.formatter == Terminal256Formatter()

    env = Environment(colors = 0)
    cf = ColorFormatter(env)
    assert cf.enabled == False

    env = Environment(colors = 256)
    cf = ColorFormatter(env, color_scheme = "solarized256")
    assert cf.formatter == Terminal256Formatter()

    env = Environment(colors = 256)
    cf = ColorFormatter(env, color_scheme = "fruity")
    assert cf.formatter == Terminal256Formatter()
    



# Generated at 2022-06-23 19:23:31.997598
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    cf = ColorFormatter(env, explicit_json=False, color_scheme='fruity')
    assert cf.formatter.__class__ == Terminal256Formatter
    assert cf.formatter.style == cf.get_style_class('fruity')

    cf = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert cf.formatter.__class__ == Terminal256Formatter
    assert cf.formatter.style == cf.get_style_class('solarized')

    cf = ColorFormatter(env, explicit_json=False, color_scheme='auto')
    assert cf.formatter.__class__ == TerminalFormatter
    assert cf.formatter.style == None

    env = Environment(colors=16)
    cf

# Generated at 2022-06-23 19:23:34.318733
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    for color_scheme in AVAILABLE_STYLES:
        ColorFormatter.get_style_class(color_scheme)

# Generated at 2022-06-23 19:23:37.124559
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert isinstance(style, pygments.style.Style)
    assert hasattr(style, 'background_color')
    assert hasattr(style, 'styles')

# Generated at 2022-06-23 19:23:38.654717
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("solarized") == Solarized256Style

# Generated at 2022-06-23 19:23:40.793081
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    c = ColorFormatter(Environment(colors=True))
    style = c.get_style_class('solarized')
    assert style == Solarized256Style

# Generated at 2022-06-23 19:23:46.615006
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    print(pygments.highlight(
        code="""
HTTP/1.1 201 Created
Connection: keep-alive
Content-Length: 0
Content-Type: application/json
Date: Wed, 28 Aug 2019 15:41:56 GMT
Server: nginx/1.17.0
        """,
        lexer=SimplifiedHTTPLexer(),
        formatter=Terminal256Formatter(
            style=Solarized256Style
        ),
    ))


# Generated at 2022-06-23 19:23:54.396139
# Unit test for function get_lexer
def test_get_lexer():
    assert not get_lexer('text/plain')

    assert not get_lexer('application/json', body='fuu')
    assert get_lexer('application/json', body='""')
    assert get_lexer('application/json', body='""', explicit_json=True)

    assert isinstance(get_lexer('text/x-json'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/json+custom'),
                      pygments.lexers.JsonLexer)

# Generated at 2022-06-23 19:24:04.132562
# Unit test for function get_lexer
def test_get_lexer():
    json_lexer = pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json') == json_lexer
    assert get_lexer('application/json+foo') == json_lexer
    assert get_lexer('application/json-foo') == json_lexer
    assert get_lexer('application/foo+json') == json_lexer
    assert get_lexer('application/foo-json') == json_lexer
    assert not get_lexer('application/xml')
    assert not get_lexer('application/json-xml')

    broken_content_type = "application/json-xml"
    assert not get_lexer(broken_content_type, body='{"key": "val"}')

# Generated at 2022-06-23 19:24:06.882861
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') is not None
    assert get_lexer('application/unknown') is not None
    assert get_lexer('application/unknown', body='{}') is not None

# Generated at 2022-06-23 19:24:14.443697
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import UnsupportedBrowser

    class FakeEnvironment:
        def __init__(self):
            self.colors = 256

    class FakeStream:
        def __init__(self, isatty=True, supported_browser=False):
            self.isatty = isatty
            self.supported_browser = supported_browser

    color_formatter = ColorFormatter(FakeEnvironment())

    headers = '''GET /example HTTP/1.1
Host: example.com
Connection: keep-alive
User-Agent: Mozilla/5.0
'''

    # run on a fake terminal
    color_formatter.output_stream = FakeStream()

# Generated at 2022-06-23 19:24:15.420833
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()
    assert True

# Generated at 2022-06-23 19:24:26.884250
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    print(ColorFormatter.format_body(
        '<html><head><title>Hi</title></head><body>Bla</body></html>',
        mime='text/html'
    ))
    print(ColorFormatter.format_body(
        '<html><head><title>Hi</title></head><body>Bla</body></html>',
        mime='text/html'
    ))
    print(ColorFormatter.format_body(
        '{"name": "whiskers", "age": 12}',
        mime='application/json'
    ))
    print(ColorFormatter.format_body(
        '{"name": "whiskers", "age": 12}',
        mime='application/json'
    ))

# Generated at 2022-06-23 19:24:37.019869
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    def assertFormatter(
        color_scheme = 'auto', has_256_colors = True,
        expected_http_lexer = None, expected_formatter = None
    ):
        # Constructor
        formatter = ColorFormatter(Environment(
            colors = 256 if has_256_colors else 0,
            defaults = {}
        ), color_scheme = color_scheme)
        # Assertions
        assert isinstance(formatter.http_lexer, type(expected_http_lexer))
        assert isinstance(formatter.formatter, type(expected_formatter))
    # Various cases
    assertFormatter(expected_http_lexer = PygmentsHttpLexer,
        expected_formatter = TerminalFormatter)

# Generated at 2022-06-23 19:24:39.459181
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    # As the Solarized256Style is defined in-line above, it may be
    # necessary to first import that style before getting it,
    # otherwise it will fail with a ClassNotFound error.
    pygments.styles.get_style_by_name('Solarized256Style')

# Generated at 2022-06-23 19:24:45.771811
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.core import main
    from httpie.compat import urlopen
    assert urlopen
    url = 'http://httpbin.org/headers'
    assert main([url]) == 0, 'call http main() failed'
    assert ColorFormatter('')
    assert ColorFormatter.get_style_class(ColorFormatter.DEFAULT_STYLE)


if __name__ == '__main__':
    # Unit test for constructor of class ColorFormatter
    test_ColorFormatter()

# Generated at 2022-06-23 19:24:48.923218
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('colorful')

# Generated at 2022-06-23 19:24:59.303517
# Unit test for function get_lexer
def test_get_lexer():
    # TODO: this is a fragile way to test
    assert get_lexer('application/json').name == 'JSON'
    assert get_lexer('text/x-json').name == 'JSON'
    assert get_lexer('text/json').name == 'JSON'
    assert get_lexer('application/json-rpc').name == 'JSON'
    assert get_lexer('application/vnd.api+json').name == 'JSON'
    assert get_lexer('application/hal+json').name == 'JSON'

    assert get_lexer('text/javascript').name == 'JavaScript'
    assert get_lexer('application/javascript').name == 'JavaScript'
    assert get_lexer('application/x-javascript').name == 'JavaScript'

# Generated at 2022-06-23 19:25:06.452240
# Unit test for function get_lexer

# Generated at 2022-06-23 19:25:08.530775
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()


# Generated at 2022-06-23 19:25:10.773244
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import str
    import httpie
    json_str = "{'a': 1}"
    content_type = 'application/json'
    formatter = ColorFormatter(httpie.Environment())
    assert isinstance(
        formatter.format_body(json_str, content_type), str) is True

# Generated at 2022-06-23 19:25:11.484970
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
   Solarized256Style()

# Generated at 2022-06-23 19:25:11.891007
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    pass

# Generated at 2022-06-23 19:25:19.830676
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from .utils import MockEnvironment, httpie
    env = MockEnvironment()
    formatter = ColorFormatter(env, color_scheme='solarized')
    http_headers_string = (
        'HTTP/1.1 200 OK\r\n'
        'Connection: keep-alive\r\n'
        'Content-Length: 0\r\n'
        'Content-Type: application/octet-stream\r\n'
        'Date: Wed, 23 Jul 2014 07:07:16 GMT\r\n'
        'Server: TornadoServer/3.1\r\n'
        '\r\n'
    )
    output = httpie.parse_items(formatter.format_headers(http_headers_string))


# Generated at 2022-06-23 19:25:21.955564
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(Environment())
    headers = '''GET / HTTP/1.1
Host: httpbin.org'''
    assert formatter.format_headers(headers) == '''GET / HTTP/1.1
Host: httpbin.org'''



# Generated at 2022-06-23 19:25:27.124702
# Unit test for function get_lexer
def test_get_lexer():
    def t(mime, body, explicit_json, expected_lexer):
        lexer = get_lexer(mime, explicit_json, body)
        assert lexer is expected_lexer, (
            'For mime="%s" and body=\n"""\n%s\n"""\n'
            'expected %s, got %s' %
            (mime, body, expected_lexer, lexer)
        )

    from pygments.lexers.javascript import JavascriptLexer
    from pygments.lexers.html import HtmlLexer
    from pygments.lexers.data import JsonLexer

    t('application/x-javascript', '', False, JavascriptLexer)
    t('application/x-javascript', '{}', False, JavascriptLexer)

# Generated at 2022-06-23 19:25:33.180741
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.compat import is_windows
    env=Environment()
    color_formatter1= ColorFormatter(env=env, color_scheme='fruity')
    assert color_formatter1.formatter.__class__.__name__=='TerminalFormatter'
    color_formatter2= ColorFormatter(env=env,color_scheme= 'solarized')
    
    if is_windows:
        assert color_formatter2.formatter.__class__.__name__=='TerminalFormatter'
    else:
        assert color_formatter2.formatter.__class__.__name__=='Terminal256Formatter'
    color_formatter3= ColorFormatter(env=env)

# Generated at 2022-06-23 19:25:41.101709
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Arrange
    env = Environment(colors=True)
    formatter = ColorFormatter(env=env)
    headers = (
        'Connection: keep-alive\n'
        'Date: Mon, 16 Jul 2018 02:03:41 GMT\n'
        'Server: nginx/1.12.2\n'
        'Content-Type: application/json\n'
        'Content-Length: 2\n'
        'Connection: close'
    )

    # Act
    result = formatter.format_headers(headers)

    # Assert

# Generated at 2022-06-23 19:25:49.994170
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    import sys
    import os

    # Skip the unit test on Windows.
    if sys.platform == 'win32':
        return

    # For some reason, the exit code is zero on Python 3.6 but not on Python 3.5.
    # Nevertheless, the test will pass on both of these.
    cmd = sys.executable + ' <<EOF\n' \
          'from pygments.style import Style\n' \
          'class MyStyle(Style):\n' \
          '    background_color = \'#1c1c1c\'\n' \
          '    styles = {pygments.token.Token: \'#1c1c1c\'}\n' \
          '    _Dummy: int\n' \
          'MyStyle()\n' \
          'EOF'

# Generated at 2022-06-23 19:25:51.855503
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-23 19:25:53.037920
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()



# Generated at 2022-06-23 19:26:02.097053
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import json
    import httpie.formatter
    import httpie.plugins
    import httpie.compat

    # From httpie.plugins.builtin.__init__.py:
    #
    # ...
    # @parser_type(
    #     input_type="color",
    #     output_type=("pretty",)
    # )
    # class ColorFormatter(FormatterPlugin):
    #     ...
    #
    # Plugins are associated with the input type they handle
    # through the parser_type decorator.
    # This decorator adds the attribute 'input_type' to the
    # object 'ColorFormatter'.
    # ColorFormatter will be used for handling color as its
    # input_type is in ('color', 'json')
    #
    # Note that this test case is only for method get_

# Generated at 2022-06-23 19:26:04.933065
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import types
    assert isinstance(SimplifiedHTTPLexer, types.FunctionType), \
        'SimplifiedHTTPLexer must be a function'

# Generated at 2022-06-23 19:26:08.484201
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_scheme = 'dark'
    assert ColorFormatter.get_style_class(color_scheme).name == color_scheme
    color_scheme = 'dummy'
    assert ColorFormatter.get_style_class(color_scheme).name == 'xcode'

# Generated at 2022-06-23 19:26:14.914299
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    import httpie
    import json
    body = [{'color': 'red'}]
    myenv = Environment()

    formatter_plugin_manager = FormatterPluginManager(myenv)
    # I have no idea how to get the set of registered plugins
    formatter_name = 'color'

    formatter_cls = formatter_plugin_manager.get(formatter_name)

    formatter = formatter_cls(myenv, color_scheme='solarized')
    # create a json response
    b = json.dumps(body)
    # if the body is in json, return a pygments lexer
    lexer = formatter.get_lexer_for_body('application/json', body=b)

# Generated at 2022-06-23 19:26:18.409289
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class env(object):
        colors = 256
    color_scheme = 'solarized'
    color = ColorFormatter(env,color_scheme)
    assert color.formatter._style.__class__.__name__ == "Solarized256Style"

# Generated at 2022-06-23 19:26:19.041247
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:26:29.342222
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import pprint
    lexer = SimplifiedHTTPLexer()
    lexer.add_filter('uncolor')

# Generated at 2022-06-23 19:26:32.235849
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import io
    import httpie.core
    env = Environment(colors='256')
    result = httpie.core.main(['--print=HB', '--headers', '--output=formatting', '--pretty=colors', '--pretty-print=all', 'https://httpbin.org/headers'], env=env)
    assert result == 0
    assert env.stdout.getvalue() != ''

# Generated at 2022-06-23 19:26:33.132910
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(None) is not None

# Generated at 2022-06-23 19:26:34.381551
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:26:35.319416
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-23 19:26:37.825220
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('boring') != Solarized256Style

# Generated at 2022-06-23 19:26:47.158137
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(
        mime='text/plain',
        body=''
    ) is None
    assert get_lexer(
        mime='text/html',
        body=''
    ) is pygments.lexers.get_lexer_by_name('html')
    assert get_lexer(
        mime='application/json',
        body=''
    ) is pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(
        mime='image/jpeg',
        body=''
    ) is None
    assert get_lexer(
        mime='image/jpeg; application/json',
        body=''
    ) is pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:26:58.145362
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pygments
    # Code taken from http://pygments.org/docs/quickstart/#highlighting-an-entire-document-from-the-command-line
    # with minor modification
    lexer = pygments.lexers.get_lexer_by_name('http')
    formatter = pygments.formatters.Terminal256Formatter(style='solarized')
    # Add test code

# Generated at 2022-06-23 19:27:00.133659
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('emacs') != Solarized256Style

# Generated at 2022-06-23 19:27:07.516659
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='foo/bar') is None
    assert get_lexer(mime='foo/json').name == 'JSON'
    assert get_lexer(mime='foo/x-www-form-urlencoded', explicit_json=True).name == 'JSON'
    assert get_lexer(mime='foo/x-www-form-urlencoded').name == 'JSON'
    assert get_lexer(mime='foo/x-www-form-urlencoded', body='foo').name == 'JSON'
    assert get_lexer(mime='application/json').name == 'JSON'
    assert get_lexer(mime='application/json', body='foo').name == 'JSON'
    assert get_lexer(mime='application/x-javascript').name == 'JSON'

# Generated at 2022-06-23 19:27:10.468529
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class_ = ColorFormatter.get_style_class(SOLARIZED_STYLE)
    assert class_ == Solarized256Style

# Generated at 2022-06-23 19:27:15.741135
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') is not None
    assert get_lexer('application/x-json') is not None
    assert get_lexer('application/ld+json') is not None
    assert get_lexer('application/hal+json') is not None
    assert get_lexer('application/csp-report') is None
    assert get_lexer('application/csp-report', explicit_json=True) is not None

# Generated at 2022-06-23 19:27:24.186671
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_bytes

    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
            style=Solarized256Style
        )
    

# Generated at 2022-06-23 19:27:35.701109
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') is not None
    assert get_lexer('text/html', body='<html></html>') is not None
    assert get_lexer('text/html', explicit_json=True) is None
    assert get_lexer('text/html', body='<html></html>', explicit_json=True) is None
    assert get_lexer('application/octet-stream') is None
    assert get_lexer('application/octet-stream', body='\n') is None
    assert get_lexer('application/octet-stream', explicit_json=True) is None
    assert get_lexer('application/octet-stream', body='\n', explicit_json=True) is None
    assert get_lexer('image/png') is None

# Generated at 2022-06-23 19:27:37.892500
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    """A Pygments style inspired by Solarized's 256 color mode."""
    solarized256_style = Solarized256Style()
    assert solarized256_style() == True

# Generated at 2022-06-23 19:27:44.557862
# Unit test for method format_body of class ColorFormatter

# Generated at 2022-06-23 19:27:55.911340
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from textwrap import dedent

# Generated at 2022-06-23 19:28:05.125098
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Built request-line
    assert pygments.highlight(
        code="GET / HTTP/1.1",
        lexer=SimplifiedHTTPLexer(),
        formatter=pygments.formatters.TerminalFormatter()
    ).strip() == \
    "\x1b[32mGET\x1b[39;49m\x1b[37m  \x1b[39;49m\x1b[36m/\x1b[39;49m\x1b[37m  \x1b[39;49m\x1b[33mHTTP\x1b[39;49m\x1b[37m/\x1b[39;49m\x1b[32m1.1\x1b[39;49m"


# Generated at 2022-06-23 19:28:08.970395
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity') is pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('solarized256') is Solarized256Style
    assert ColorFormatter.get_style_class('auto') is Solarized256Style

# Generated at 2022-06-23 19:28:09.719719
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()
    return

# Generated at 2022-06-23 19:28:11.231557
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import sys
    env = Environment(colors=256, stdout=sys.stdout)
    assert ColorFormatter(env, None, 'solarized')

# Generated at 2022-06-23 19:28:11.632506
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-23 19:28:12.550397
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:28:20.718071
# Unit test for function get_lexer
def test_get_lexer():
    from httpie.core import json
    from httpie.core import FORM

    lexer = get_lexer('text/html')
    assert lexer == pygments.lexers.get_lexer_by_name('html')

    lexer = get_lexer('text/plain')
    assert lexer == pygments.lexers.get_lexer_by_name('text')

    lexer = get_lexer('application/json')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer('application/vnd.api+json')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer('application/json', explicit_json=True)

# Generated at 2022-06-23 19:28:30.215318
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    try:
        from pygments.lexers.text import HttpLexer
    except ImportError:
        pygments_version = [int(x) for x in pygments.__version__.split('.')]
        if pygments_version < [2, 1, 0]:
            return
        else:
            raise

    lexer = HttpLexer(ensurenl=False)
    SimplifiedHTTPLexer.ensurenl = False

# Generated at 2022-06-23 19:28:41.510921
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    mime = 'application/json'
    body = """
    [
      {
        "id": 1,
        "name": "Leanne Graham"
      },
      {
        "id": 2,
        "name": "Ervin Howell"
      }
    ]
    """

    cf = ColorFormatter(
        Environment(colors=256),
        explicit_json=False,
        color_scheme=SOLARIZED_STYLE,
    )
    assert isinstance(cf.get_lexer_for_body(mime, body), pygments.lexers.get_lexer_by_name('json'))

    cf = ColorFormatter(
        Environment(colors=256),
        explicit_json=True,
        color_scheme=SOLARIZED_STYLE,
    )

# Generated at 2022-06-23 19:28:46.294147
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class MockLexer(lexer.RegexLexer):
        pass
    class MockEnv:
        colors = True
    mock_env = MockEnv()
    cf = ColorFormatter(mock_env, explicit_json=False, color_scheme='auto')
    assert cf.format_body('{}', 'application/json') == '{}'
    assert cf.format_body('{}', 'application/json') == '{}'

# Generated at 2022-06-23 19:28:56.495369
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    print('unit test for method format_body of class ColorFormatter')

    test_cases = [
        # test data: (body, mime, lexer_name)
        ('{}', 'application/json', 'JSON'),
        ('1 < 2', 'text/html', 'HTML'),
        ('print "hello, world"', 'text/x-python', 'Python'),
        ('a=1', 'text/x-c', 'C'),
        ('a=1', 'text/plain', 'Text only'),
        ('a=1', 'a/b', 'Text only'),
    ]

    from httpie.compat import is_windows

# Generated at 2022-06-23 19:29:03.859738
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # test case 1
    request_line = "GET / HTTP/1.1"
    lexer = SimplifiedHTTPLexer()
    tokens = [(tokentype, value) for tokentype, value in lexer.get_tokens(request_line)]
    assert tokens[0] == (pygments.token.Name.Function, 'GET')
    assert tokens[1] == (pygments.token.Text, ' ')
    assert tokens[2] == (pygments.token.Name.Namespace, '/')
    assert tokens[3] == (pygments.token.Text, ' ')
    assert tokens[4] == (pygments.token.Keyword.Reserved, 'HTTP')
    assert tokens[5] == (pygments.token.Operator, '/')

# Generated at 2022-06-23 19:29:12.615125
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    test_cases = [
        ('paren', 'pygments.styles.default.DefaultStyle'),
        ('monokai', 'pygments.styles.monokai.MonokaiStyle'),
        ('fruity', 'pygments.styles.fruity.FruityStyle'),
        ('solarized', 'httpie.plugins.formatter.colors.Solarized256Style'),
        ('auto', 'pygments.formatters.terminal256.Terminal256Formatter')
    ]
    for input_, expected in test_cases:
        output = ColorFormatter.get_style_class(input_)
        assert str(output) == expected

# Generated at 2022-06-23 19:29:14.388264
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("solarized") == Solarized256Style


# Generated at 2022-06-23 19:29:23.749293
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(
        colors=256,
        style=AUTO_STYLE,
        stdout_isatty=True,
        stdin_isatty=False,
        vt100_support=False,
        version=None,
    )
    color_formatter = ColorFormatter(
        env=env,
        explicit_json=False,
        color_scheme=AUTO_STYLE
    )
    assert color_formatter.formatter.__class__ is Terminal256Formatter
    assert color_formatter.http_lexer.__class__ is SimplifiedHTTPLexer