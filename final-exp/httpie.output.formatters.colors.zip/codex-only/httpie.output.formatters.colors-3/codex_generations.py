

# Generated at 2022-06-23 19:19:27.129787
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('text/html')
    assert not get_lexer('application/octet-stream')
    assert not get_lexer('application/octet')

# Generated at 2022-06-23 19:19:34.716899
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import io
    import json
    import os

    status_code = '200'
    headers_dict = {
        'User-Agent': 'HTTPie/0.9.1',
        'Accept-Encoding': 'gzip, deflate',
        'Host': '127.0.0.1:8080',
        'Accept': '*/*',
        'Content-Length': '11'
    }

# Generated at 2022-06-23 19:19:45.151149
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    input = b"""
    HTTP/1.1 200 OK
    Date: Mon, 27 Jul 2009 12:28:53 GMT
    Server: Apache/2.2.14 (Win32)
    Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
    Content-Length: 88
    Content-Type: text/html
    Connection: Closed
    """
    expected_output = """\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed
"""
    assert ColorFormatter(None, None).format_headers(input) == (expected_output)

# Generated at 2022-06-23 19:19:49.457469
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    #Arrange
    class TestEnv(object):
        color = True
    from httpie.plugins import plugin_manager
    plugin_manager.register(ColorFormatter)
    #Act
    ColorFormatter(env=TestEnv())

# Generated at 2022-06-23 19:19:58.825044
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=True, stdout_isatty=True, stderr_isatty=True)
    color_formatter = ColorFormatter(env)
    headers = 'Content-Type: application/json\nX-Header: foo'
    output = color_formatter.format_headers(headers)
    assert output == '\x1b[38;5;4mContent-Type\x1b[39;49;00m: \x1b[38;5;250mapplication/json\n\x1b[38;5;4mX-Header\x1b[39;49;00m: \x1b[38;5;250mfoo\x1b[39;49;00m'

# Generated at 2022-06-23 19:20:05.568519
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment(colors=True)
    cf = ColorFormatter(env)
    lexer = cf.get_lexer_for_body(
        mime='application/json',
        body='{"a":true}',
    )
    assert lexer == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:20:08.534808
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_scheme = 'solarized'
    result = ColorFormatter.get_style_class(color_scheme)
    assert result is Solarized256Style

# Generated at 2022-06-23 19:20:15.299788
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # test with known and unknown mime type
    assert isinstance(ColorFormatter.get_lexer_for_body('application/json', ''), pygments.lexers.JsonLexer)
    assert isinstance(ColorFormatter.get_lexer_for_body('application/unknow', ''), pygments.lexers.TextLexer)
    # test with known and unknown mime type, but with --json argument
    assert isinstance(ColorFormatter.get_lexer_for_body('application/unknow', '', True), pygments.lexers.JsonLexer)

# Generated at 2022-06-23 19:20:17.418502
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    formatter = ColorFormatter(Environment())
    assert formatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-23 19:20:30.065848
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(None)
    print(formatter.format_body('{"a": 1}', 'application/json'))
    print(formatter.format_body('', 'application/json'))
    print(formatter.format_body('a{}', 'application/json'))
    print(formatter.format_body('<html>', 'text/html'))
    print(formatter.format_body('html', 'text/html'))
    print(formatter.format_body('', 'text/html'))
    print(formatter.format_body('<xml>', 'text/xml'))
    print(formatter.format_body('xml', 'text/xml'))
    print(formatter.format_body('', 'text/xml'))

# Generated at 2022-06-23 19:20:38.812776
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class TestEnv:
        colors = 256
    colorFormatter = ColorFormatter(TestEnv(), color_scheme='solarized')
    assert colorFormatter.color_scheme == 'solarized'

# Generated at 2022-06-23 19:20:40.964974
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert style.background_color == "#1c1c1c"
    assert style.styles[pygments.token.Name.Builtin] == "#0087ff"



# Generated at 2022-06-23 19:20:43.485482
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()

    assert style.styles[pygments.token.Name.Function] == '#0087ff'

# Generated at 2022-06-23 19:20:49.204572
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class ColorFormatter(FormatterPlugin):
        @staticmethod
        def get_style_class(color_scheme: str) -> Type[pygments.style.Style]:
            return Solarized256Style

    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style

    try:
        assert ColorFormatter.get_style_class('not_available')
    except AssertionError:
        pass

# Generated at 2022-06-23 19:20:52.220639
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie
    c = httpie.plugins.builtin.colors.ColorFormatter(
        env=httpie.utils.get_environment(),
        color_scheme='auto',
    )

# Generated at 2022-06-23 19:20:53.284198
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    p = SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:21:02.214814
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins.colors import ColorFormatter
    from httpie import ExitStatus
    exit_status = ExitStatus()

# Generated at 2022-06-23 19:21:02.828863
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:21:08.371893
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') is None
    assert get_lexer('application/json') is pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/javascript') is pygments.lexers.get_lexer_by_name('javascript')
    assert get_lexer('application/json', explicit_json=True, body='{"foo":"bar"}') is pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/javascript', explicit_json=True, body='{"foo":"bar"}') is pygments.lexers.get_lexer_by_name('javascript')

# Generated at 2022-06-23 19:21:13.079992
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class MyColorFormatter(ColorFormatter):
        def __init__(self):
            pass

    myColorFormatter = MyColorFormatter()
    style_class = myColorFormatter.get_style_class('solarized')
    assert(isinstance(style_class, type))



# Generated at 2022-06-23 19:21:17.806178
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    """
    Unit test for constructor of class SimplifiedHTTPLexer.
    """
    simHTTPLexer = SimplifiedHTTPLexer()
    assert simHTTPLexer.name == 'HTTP'
    assert simHTTPLexer.aliases == ['http']
    assert simHTTPLexer.filenames == ['*.http']

# Generated at 2022-06-23 19:21:23.075626
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert ColorFormatter.format_body('{"key":"value"}', "application/json") == '{<span class="n">\n  <span class="s2">"key"</span><span class="p">:</span><span class="s2">"value"</span>\n</span>}'

# Generated at 2022-06-23 19:21:34.218114
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    """Test for method format_headers in class ColorFormatter."""
    colorFormatter = ColorFormatter(Environment(colors=256))
    headers = 'HTTP/1.1 200 OK\n' \
              'Content-Type: application/json; charset=UTF-8\n' \
              'Content-Encoding: gzip\n' \
              'Cache-Control: no-cache'
    result = colorFormatter.format_headers(headers)

# Generated at 2022-06-23 19:21:36.628605
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.filenames == ['*.http']
    assert lexer.aliases == ['http']

# Generated at 2022-06-23 19:21:48.391191
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(None, None)

    assert formatter.format_headers("") == ""

    assert formatter.format_headers("Host: localhost:8000\r\n") ==\
        "\x1b[38;5;245mHost\x1b[39;00m:\x1b[39;00m \x1b[34mlocalhost\x1b[39;00m:\x1b[39;00m\x1b[34m8000\x1b[39;00m\x1b[39;00m"


# Generated at 2022-06-23 19:21:53.533162
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') is Solarized256Style
    assert ColorFormatter.get_style_class('autumn') is pygments.styles.get_style_by_name('autumn')

# Generated at 2022-06-23 19:21:55.494548
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:21:58.650575
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    # Excercise the constructor so we can verify that it parses correctly
    s = Solarized256Style()
    # Fixme - It would be better to check the actual values, but I don't see a good way to do that.
    assert s is not None

# Generated at 2022-06-23 19:21:59.432360
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-23 19:22:10.521272
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    
    c = ColorFormatter(env='1', explicit_json='2', color_scheme='default_style')
    assert c.group_name == 'colors'
    assert c.enabled == True
    assert c.explicit_json == '2'
    # c.formatter is an instance of class Terminal256Formatter
    assert c.formatter.style.__name__ == 'Solarized256Style'
    assert c.http_lexer.name == 'HTTP'
    assert c.http_lexer.aliases == ['http']
    assert c.http_lexer.filenames == ['*.http']

    c.format_headers('test_headers')
    c.format_body('test_body', 'test_mime')

# Generated at 2022-06-23 19:22:21.590787
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    # test that missing mimetype returns None
    cformatter = ColorFormatter(Environment())

    assert cformatter.get_lexer_for_body("text/plain", None) == None
    assert cformatter.get_lexer_for_body("text/plain", "") == None

    # test that text/plain returns None
    assert cformatter.get_lexer_for_body("text/plain", "hello world") == None

    # test that unrecognized mimetype returns None
    assert cformatter.get_lexer_for_body("application/blah", "") == None

    # test that text/* returns TextLexer
    assert cformatter.get_lexer_for_body("text/foo", "") == TextLexer

    # test that application/explicit json mimetype returns JSON lexer
   

# Generated at 2022-06-23 19:22:28.100387
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class FakeEnv(object):
        def __init__(self, colors=False):
            self.colors = colors

    headers = 'HTTP/1.1 200 OK\n\n'
    formatter = ColorFormatter(FakeEnv(colors=True))
    result = formatter.format_headers(headers)
    assert 'HTTP/1' in result
    assert '\x1b[35m' in result
    assert '\x1b[39m' in result

    assert formatter.format_headers(headers) == headers

# Generated at 2022-06-23 19:22:30.598813
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """
    ...
    """
    import httpie
    cf = httpie.plugins.formatter.colors.ColorFormatter(httpie.Environment())

# Generated at 2022-06-23 19:22:35.759603
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    a = ColorFormatter()
    assert getattr(a, 'enabled')['colors'] == False
    assert a.format_headers('test') == 'test'
    assert a.format_body('test', 'text/plain') == 'test'
    assert a.get_lexer_for_body('test', 'test') == None
    assert a.get_style_class('test') == Solarized256Style
    assert a.get_lexer_for_body('application/json', 'test') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:22:48.224984
# Unit test for function get_lexer

# Generated at 2022-06-23 19:22:59.499464
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    requestline_token = (
        pygments.token.Name.Function,
        pygments.token.Text,
        pygments.token.Name.Namespace,
        pygments.token.Text,
        pygments.token.Keyword.Reserved,
        pygments.token.Operator,
        pygments.token.Number
    )
    statusline_token = (
        pygments.token.Keyword.Reserved,  # 'HTTP'
        pygments.token.Operator,  # '/'
        pygments.token.Number,  # Version
        pygments.token.Text,
        pygments.token.Number,  # Status code
        pygments.token.Text,
        pygments.token.Name.Exception,  # Reason
    )

# Generated at 2022-06-23 19:23:03.464784
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style()

# Generated at 2022-06-23 19:23:04.440678
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()


# Generated at 2022-06-23 19:23:12.929966
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from io import StringIO
    from httpie.output.streams import Streams
    from httpie.context import Environment

    env = Environment(colors=256)
    stdout = StringIO()
    stderr = StringIO()
    streams = Streams(stdout=stdout, stderr=stderr)
    formatter = ColorFormatter(env, streams)

    # Request with Error
    formatter.format_headers('''GET / HTTP/1.1
Host: localhost
Connection: close
Content-Length: 5

GET / HTTP/1.1
Host: localhost
Connection: close
Content-Length: 5

''')

# Generated at 2022-06-23 19:23:15.834591
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')



# Generated at 2022-06-23 19:23:19.692603
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.formatter import ColorFormatter
    
    # Using the default style
    style = ColorFormatter.get_style_class('')
    assert style == Terminal256Formatter.style
    
    # Using a specified style
    style = ColorFormatter.get_style_class('solarized')
    assert style == Solarized256Style

# Generated at 2022-06-23 19:23:30.033814
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter()
    test_string = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 0\r\n\r\n"

# Generated at 2022-06-23 19:23:39.813408
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='text/plain') is not None
    assert get_lexer(mime='text/css') is not None
    assert get_lexer(mime='text/csv') is not None
    assert get_lexer(mime='application/octet-stream') is None
    assert get_lexer(mime='text/html') is not None
    assert get_lexer(mime='application/json', body='{}') is not None
    assert get_lexer(mime='application/json') is None
    assert get_lexer(mime='text/x-unknown') is None
    assert get_lexer(mime='text/x-unknown', explicit_json=True, body='{}') is not None

# Generated at 2022-06-23 19:23:49.098574
# Unit test for function get_lexer

# Generated at 2022-06-23 19:23:58.208433
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def test(mime, body, expected_lexer_name):
        returned_lexer_name = ColorFormatter(None, explicit_json=False).get_lexer_for_body(mime, body).name
        assert returned_lexer_name == expected_lexer_name, \
            'For {} and {}, expected {} but got {}'.format(mime, repr(body), expected_lexer_name, returned_lexer_name)

    test('text/plain', '', 'Text only')
    test('text/plain', 'hello world', 'Text only')
    test('text/plain', '{"a": {"b": "c"} }', 'Text only')

    test('application/json', '', 'JSON')
    test('application/json', 'hello world', 'JSON')

# Generated at 2022-06-23 19:24:07.310690
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(Environment())
    text = "this is a test!"

    output = formatter.format_body(text, 'text/plain')
    assert text == output
    output = formatter.format_body('{"a":1,"b":"c"}', 'text/plain')
    assert '{\n  "a": 1,\n  "b": "c"\n}\n' == output
    output = formatter.format_body('{"a":1,"b":"c"}', 'application/json')
    assert '{\n  "a": 1,\n  "b": "c"\n}\n' == output



# Generated at 2022-06-23 19:24:18.807210
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert isinstance(ColorFormatter(None).get_lexer_for_body('text/plain', ''), TextLexer)
    assert isinstance(ColorFormatter(None).get_lexer_for_body('text/html', ''), pygments.lexers.HtmlLexer)
    assert isinstance(ColorFormatter(None).get_lexer_for_body('application/json', ''), pygments.lexers.JsonLexer)
    assert isinstance(ColorFormatter(None).get_lexer_for_body('text/plain; charset=utf-8', ''), TextLexer)
    assert isinstance(ColorFormatter(None).get_lexer_for_body('text/plain;whatever', ''), TextLexer)

# Generated at 2022-06-23 19:24:29.458342
# Unit test for function get_lexer
def test_get_lexer():
    def is_lexer(lexer, expected_lexer_name):
        return lexer and lexer.name == expected_lexer_name

    # HTML.
    assert is_lexer(get_lexer('text/html'), 'HTML')
    assert is_lexer(get_lexer('application/xhtml+xml'), 'HTML')
    assert is_lexer(get_lexer('application/xml'), 'XML')
    assert is_lexer(get_lexer('text/xml'), 'XML')

    # JSON.
    assert is_lexer(get_lexer('application/json', explicit_json=True), 'JSON')
    assert get_lexer('application/json') == None
    assert get_lexer('application/json', explicit_json=True, body='{}') == None

    # JavaScript.

# Generated at 2022-06-23 19:24:30.268595
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter

# Generated at 2022-06-23 19:24:38.599852
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.core import main as test

    if is_windows:
        # Colors on Windows via colorama don't look that
        # great and fruity seems to give the best result there.
        color_scheme = 'fruity'
    else:
        color_scheme = 'solarized'


# Generated at 2022-06-23 19:24:42.731850
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Sanity check:
    assert pygments.lexers.get_lexer_for_mimetype('application/json')

    assert not get_lexer(mime='application/json', body='{}')
    assert get_lexer(mime='application/json', body='{}', explicit_json=True)

# Generated at 2022-06-23 19:24:50.696877
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie import ExitStatus
    from httpie.compat import str
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from utils import http, HTTP_OK
    json_data = '{"a": 1, "c": "foo"}'
    mime = 'application/json; charset=utf8'
    env = Environment(stdout=None, colors=256)
    c = ColorFormatter(env=env)
    c.formatter = Terminal256Formatter(style=Solarized256Style)
    lexer = c.get_lexer_for_body(mime=mime, body=json_data)
    assert lexer
    req_data = '/* comment */\n' + json_data

# Generated at 2022-06-23 19:24:54.279189
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    formatter = ColorFormatter("")
    assert formatter
    assert formatter.get_lexer_for_body("application/json", "")

    assert formatter.get_lexer_for_body("text/javascript", "")

# Generated at 2022-06-23 19:24:57.042724
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    assert ColorFormatter(env, explicit_json=False, color_scheme=AUTO_STYLE)

# Generated at 2022-06-23 19:25:01.735795
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    actual = ColorFormatter.format_headers('HTTP/1.0 200 OK\r\nheader1: value1\r\nheader2: value2')
    expected = '\x1b[38;5;105mHTTP/1.0 200 OK\x1b[0m\r\n\x1b[38;5;33mheader1: value1\x1b[0m\r\n\x1b[38;5;33mheader2: value2\x1b[0m'
    assert actual == expected



# Generated at 2022-06-23 19:25:13.007281
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    # Request-Line
    # >>> lexer.get_tokens("GET / HTTP/1.1")
    # [(Token.Name.Function, 'GET', (1, 0)),
    #  (Token.Text, ' ', (1, 3)),
    #  (Token.Name.Namespace, '/', (1, 4)),
    #  (Token.Text, ' ', (1, 5)),
    #  (Token.Keyword.Reserved, 'HTTP', (1, 6)),
    #  (Token.Operator, '/', (1, 10)),
    #  (Token.Number, '1.1', (1, 11))]
    # >>> for item in http_lexer.get_tokens("GET / HTTP/1.1"):
    # ...

# Generated at 2022-06-23 19:25:23.069428
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexers import HttpLexer
    http_lexer = HttpLexer()
    simplified_http_lexer = SimplifiedHTTPLexer()
    http_lexer_tokens = list(http_lexer.get_tokens('GET /pypi/httpie/json HTTP/1.1'))[1][0]
    simplified_http_lexer_tokens = list(simplified_http_lexer.get_tokens('GET /pypi/httpie/json HTTP/1.1'))[1][0]
    assert simplified_http_lexer_tokens == pygments.token.Name.Function

# Generated at 2022-06-23 19:25:30.430053
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie import ExitStatus
    from httpie.output.streams import ColorizedStream
    from httpie.cli.helpers import get_color_style_definition
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.compat import is_osx
    import sys

    if is_osx:
        print('Test requires env var TERM=xterm-256color')
        sys.exit(ExitStatus.PLUGIN_ERROR)

    if 'TERM' not in os.environ or os.environ['TERM'] != 'xterm-256color':
        print('Test requires env var TERM=xterm-256color')
        sys.exit(ExitStatus.PLUGIN_ERROR)

    headers = 'content-type: text/html; charset=utf-8'

# Generated at 2022-06-23 19:25:36.092209
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    for text in [
        'GET / HTTP/1.1',
        'Host: example.com',
        'User-Agent: Mozilla/5.0',
    ]:
        assert (
            lexer.get_tokens_unprocessed(text) ==
            [(x, y) for x, y in lexer.get_tokens(text)]
        )

# Generated at 2022-06-23 19:25:37.104560
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert True

# Generated at 2022-06-23 19:25:38.327169
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style.__init__('test')

# Generated at 2022-06-23 19:25:39.714261
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='application/json', explicit_json=True)

# Generated at 2022-06-23 19:25:41.460162
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter(None).get_style_class('solarized') == Solarized256Style
    assert ColorFormatter(None).get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-23 19:25:50.192890
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    ColorFormatter = ColorFormatter(
        env = Environment(),
        explicit_json = False,
        color_scheme = 'solarized'
    )

    assert ColorFormatter.get_lexer_for_body(
        mime = 'text/html',
        body = '''
        <!DOCTYPE html>
        <html>
            <head>
                <title>Test</title>
            </head>
            <body>
                <p>Hello World</p>
            </body>
        </html>
        '''
    ) == pygments.lexers.get_lexer_by_name('html')

    assert ColorFormatter.get_lexer_for_body(
        mime = 'text/plain',
        body = 'Hello World'
    ) == pygments.lexers.get

# Generated at 2022-06-23 19:25:59.770899
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import requests
    import time
    import httpie.plugins.builtin

    formatter = httpie.plugins.builtin.colors.ColorFormatter(env=None)
    r = requests.get("http://httpbin.org/get")
    headers = r.headers

    print("Method format_headers of class ColorFormatter")
    result = formatter.format_headers("\n".join("{}: {}".format(k, v) for k, v in headers.items()))
    print("=>", result)
    assert result[:4] == "\x1b[0;36m"
    assert result[-3:] == "\x1b[0m"
    print("\n")


# Generated at 2022-06-23 19:26:06.375603
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # 1. environment colors is False
    env = Environment(colors=False)
    colorFormatter = ColorFormatter(env)
    assert(colorFormatter.enabled == False)
    # 2. enviroment colors is True
    env = Environment(colors=True)
    colorFormatter = ColorFormatter(env)
    assert(colorFormatter.enabled == True)


# Generated at 2022-06-23 19:26:12.800252
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class FakeEnvironment:
        def __init__(self):
            self.colors = True
    class FakeOptions:
        def __init__(self):
            self.explicit_json = True
            self.colors = 'auto'
    env = FakeEnvironment()
    opt = FakeOptions()
    obj = ColorFormatter(env,
    obj.format_headers("a1: b1"
        "\na2: b2\na2: b2\na2:"
        "\na2: b2\na2: b2\na2:\n"
        "a2: b2\na2: b2\na2\n")
    )

# Generated at 2022-06-23 19:26:14.106648
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style  # silence pyflakes

# Generated at 2022-06-23 19:26:15.559543
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-23 19:26:18.630652
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(explicit_json=False, color_scheme='fruity')
    assert color_formatter.explicit_json==False
    assert color_formatter.enabled == True

# Generated at 2022-06-23 19:26:22.059776
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert type(ColorFormatter(Environment(), False, 'monokai').formatter) == TerminalFormatter
    assert type(ColorFormatter(Environment(256), False, 'monokai').formatter) == Terminal256Formatter

# Generated at 2022-06-23 19:26:32.641120
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from pygments.lexers import HttpLexer
    from pygments.formatters import TerminalFormatter
    import tempfile

    env = Environment()
    # Save pygments.format.TerminalFormatter.__init__ arguments
    old_args = TerminalFormatter.__init__.__defaults__
    # Set arguments background_color and style to None to test
    TerminalFormatter.__init__.__defaults__ = (None, None)
    formatter = TerminalFormatter()
    # Reset pygments.format.TerminalFormatter.__init__ arguments
    TerminalFormatter.__init__.__defaults__ = old_args
    fd, path = tempfile.mkstemp()

# Generated at 2022-06-23 19:26:36.155983
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style.background_color == "#1c1c1c"
    assert Solarized256Style.styles[pygments.token.String] == "#00afaf"

# Generated at 2022-06-23 19:26:43.349802
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import httpie.plugins
    httpie.plugins.load_internal_plugins()
    httpie.plugins.load_builtin_plugins()
    formatter = ColorFormatter(
        env = httpie.compat.get_environ(),
        color_scheme = DEFAULT_STYLE
    )
    headers = formatter.format_headers('''\
GET / HTTP/1.1
Host: www.google.com
User-Agent: httpie/0.9.9
Accept-Encoding: gzip, deflate, compress
Accept: */*
Connection: keep-alive''')

# Generated at 2022-06-23 19:26:51.629634
# Unit test for function get_lexer
def test_get_lexer():
    get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    get_lexer('application/json', body='{}') == pygments.lexers.get_lexer_by_name('json')
    get_lexer('text/plain', body='{}') is None
    get_lexer('text/plain', body='{}', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:27:00.673624
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.utils import MimeType, get_valid_json
    import base64
    from cryptography.fernet import Fernet
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.fernet import InvalidToken
    method = ColorFormatter.format_body

    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env=env)
    assert formatter.enabled is True

    # plain text
    assert method(formatter, 'foo', MimeType('text/plain')) == 'foo'
    # json

# Generated at 2022-06-23 19:27:04.821877
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    f = ColorFormatter()
    body = f.format_body("{'name': 'yuexi'}", 'application/json')
    assert body == "{'name': 'yuexi'}"



# Generated at 2022-06-23 19:27:11.519755
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # has_256_colors = False
    # use_auto_style = True
    # color_scheme = 'auto'
    # http_lexer = PygmentsHttpLexer()
    # formatter = TerminalFormatter()
    cf = ColorFormatter(Environment(colors=8, debug=False, default_options=[]),
                        explicit_json=False,
                        color_scheme='auto',
                        is_terminal=False)
    assert "class 'httpie.plugins.format.pygments_.ColorFormatter'" == repr(cf)

# Generated at 2022-06-23 19:27:12.302481
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:27:22.608860
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.context import Environment
    from httpie import output

    env = Environment()

    # set for httpie coloring
    env.colors = 256  # or True

    # set for ColorFormatter color scheme
    color_scheme = 'solarized'  # solarized or fruity (if is_windows)

    # set for ColorFormatter.format_headers()
    explicit_json = False
    kwargs = {}

    color_formatter = ColorFormatter(env, explicit_json, color_scheme, **kwargs)

    # create built-in processor
    http_headers_processor = HTTPHeadersProcessor(env=env)

    # create string with http headers

# Generated at 2022-06-23 19:27:29.249257
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import unittest

    class ColorFormatterTestCase(unittest.TestCase):

        """
            class ColorFormatterTestCase
        """

        def setUp(self):
            self.formatter = ColorFormatter(explicit_json=False, color_scheme=DEFAULT_STYLE)
        def test_colorformatter_color_scheme(self):
            """test_colorformatter_color_scheme
            """
            self.assertEqual(self.formatter.color_scheme, DEFAULT_STYLE)

        def test_colorformatter_format_headers(self):
            """test_colorformatter_format_headers
            """
            headers = "an header"
            actual = self.formatter.format_headers(headers)
            self.assertIn(actual, headers)

    unittest

# Generated at 2022-06-23 19:27:30.149177
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cFormatter = ColorFormatter()
    assert cFormatter != None
    cFormatter = None

# Generated at 2022-06-23 19:27:32.014132
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-23 19:27:33.429396
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # TODO: Add test cases
    assert True

# Generated at 2022-06-23 19:27:35.380949
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    ColorFormatter.get_lexer_for_body('text/html', '<h1>hello</h1>')

# Generated at 2022-06-23 19:27:36.887492
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-23 19:27:44.921110
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    #Test setup
    colorFormatter = ColorFormatter(None)

# Generated at 2022-06-23 19:27:56.429039
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256, stdout_isatty=True, stderr_isatty=True)
    formatter = ColorFormatter(env, color_scheme='solarized')
    assert type(formatter) == ColorFormatter
    headers = "Content-Type: application/json; charset=UTF-8\r\n" \
              "Date: Mon, 18 Jul 2016 18:37:59 GMT\r\n" \
              "Server: Apache/2.4.6 (CentOS)\r\n" \
              "X-Powered-By: PHP/5.6.18\r\n" \
              "Content-Length: 77\r\n" \
              "Connection: close\r\n\r\n"
    headers = formatter.format_headers(headers)

# Generated at 2022-06-23 19:28:05.608098
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json', explicit_json=True, body='')
    assert get_lexer('application/json', body='') is None
    assert get_lexer('text/plain', body='') is None
    assert get_lexer('text/plain') is None
    assert get_lexer('text/plain', body='{}') is None
    assert get_lexer('text/plain', explicit_json=True) is None

# Generated at 2022-06-23 19:28:11.489981
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # type: () -> None

    from httpie.core import Response

    # Configuring the environment and the formatter
    env = Environment(colors=True)
    cf = ColorFormatter(env)
    # Configuring a basic response with a simple header
    response = Response(headers={"Content-Type": "application/json"})
    # Testing format_headers
    assert cf.format_headers(response.headers) == "\x1b[32mContent-Type\x1b[39m: application/json"

# Generated at 2022-06-23 19:28:16.739929
# Unit test for function get_lexer
def test_get_lexer():
    """Unit test for ColorFormatter.get_lexer()."""
    assert get_lexer('application/json')
    assert get_lexer('application/javascript')
    assert get_lexer('application/octet-stream')
    assert get_lexer('image/svg+xml')
    assert get_lexer('image/svg+xml+oops')
    assert get_lexer('image/svg')

# Generated at 2022-06-23 19:28:17.850724
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:28:28.540743
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(False, DEFAULT_STYLE)
    assert color_formatter.get_lexer_for_body(
        'text/html', '<html>\n<body>\n<b>Hello World!</b>\n</body>\n</html>'
    )
    assert color_formatter.get_lexer_for_body(
        'application/json', '{"Hello":"World!"}'
    )
    assert color_formatter.get_lexer_for_body(
        'text/plain', 'Hello World!'
    )
    assert color_formatter.get_lexer_for_body(
        'text/plain', '"Hello World!"'
    )

# Generated at 2022-06-23 19:28:35.758101
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') == TextLexer
    assert get_lexer('application/json', body='[]') == \
           pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json') == TextLexer
    assert get_lexer('application/json', explicit_json=True, body='[]') == \
           pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:28:45.152841
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import sys
    import httpie.plugins

    sys.modules['httpie.plugins'] = httpie.plugins
    from httpie.formatters import ColorFormatter
    from httpie.compat import is_windows
    from httpie import ExitStatus
    from httpie.core import main

    def run_http(args):
        args += ['--pretty=colors']
        exit_status, _, _ = main(args)
        return exit_status

    def run_http_with_plugins(args, explicit_json=False):
        args += ['--pretty=colors', '--stream']
        if explicit_json:
            args += ['--json']
        environment = Environment(stdout=None,
            stdin=open(os.devnull, 'r'),
            stderr=open(os.devnull, 'r'))

# Generated at 2022-06-23 19:28:56.403552
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(stdin=None, stdout=None,
                      vars=None, config=None, colors=256)
    ColorFormatter(env=env, color_scheme='solarized')
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json;charset=utf-8\r\nContent-Length: 0\r\n"
    result = ColorFormatter(env=env, color_scheme='solarized').format_headers(headers)

# Generated at 2022-06-23 19:29:05.962130
# Unit test for function get_lexer
def test_get_lexer():
    # Unit tests for function get_lexer

    # Success
    assert get_lexer('application/json')
    assert get_lexer('application/vnd.api+json')
    assert get_lexer('application/vnd.api+json', False, '')
    assert get_lexer('application/vnd.api+json', True, '')
    assert get_lexer('application/vnd.api+json', True, '""')
    assert get_lexer('application/vnd.api+json', False, '""')

    # Error
    assert get_lexer('application/vnd.api+xml', False, '""') == None
    assert get_lexer('application/vnd.api+xml', True, '"<tag></tag>"') == None

# Generated at 2022-06-23 19:29:15.000602
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin

    from httpie.plugins.colors import ColorFormatter

    body = '''GET / HTTP/1.1\r
Host: api.github.com\r
User-Agent: HTTPie/0.9.2\r
Accept: application/vnd.github.v3+json\r
Accept-Encoding: gzip, deflate\r
Connection: keep-alive\r
\r
'''

# Generated at 2022-06-23 19:29:15.975903
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-23 19:29:18.238780
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') is None
    assert get_lexer('application/json') is not None

# Generated at 2022-06-23 19:29:24.458248
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html')
    assert not get_lexer('text/html-xxx')
    assert not get_lexer('xxx/html')
    assert get_lexer('application/json')
    assert get_lexer('application/json-xxx')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json-xxx', body='{}')
    assert not get_lexer('application/json', body='x')