

# Generated at 2022-06-23 19:19:28.888144
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # On a default import, the default theme should be used.
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) == pygments.styles.get_style_by_name(DEFAULT_STYLE)

    # On a default import, the default theme should be used.
    # Until we add support for detecting the theme, we use 'auto'
    assert ColorFormatter.get_style_class('auto') == pygments.styles.get_style_by_name(DEFAULT_STYLE)

    # On a default import, the default theme should be used.
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

    # On a default import, the default theme should be used.
    assert ColorFormatter.get_style_class('pygments') == pygments.styles.get_

# Generated at 2022-06-23 19:19:40.850527
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import str
    from httpie.formatter import get_parser
    from httpie.input import ParseException

    env = Environment()
    env.stdout = str()
    env.stdout_isatty = False

    # Create a preset with "json" so that JSON lexer is tried as a fallback
    parser = get_parser()
    parser.add_argument(
        '--json', action='store_true', env='HTTPIE_JSON',
        help='JSON pretty print. Use with --print=BODY'
    )
    args = parser.parse_args([
        '--json'
    ])
    formatter = ColorFormatter(
        env=env,
        parsed_args=args
    )


# Generated at 2022-06-23 19:19:48.894345
# Unit test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-23 19:19:58.973597
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    import pytest
    # Test ColorFormatter.format_body. (Properly colorize response body)
    class TestEnv:
        def __init__(self):
            self.colors = 256

    class TestFormat:
        def __init__(self):
            self.enabled = True
            self.colors = 256

    env = TestEnv()
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    body = '{"_text":"\\u738b\\u9759\\u9510","balance":99,"email":"fq0923@im.csie.ncku.edu.tw","id":2,"nickname":"\\u9759\\u9510","password":"0923","username":"fq0923"}'
    mime

# Generated at 2022-06-23 19:20:11.257862
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Python 2: `assertRaises` context manager is not available
    import contextlib
    try:
        from contextlib import ExitStack
    except ImportError:
        from contextlib2 import ExitStack

    with ExitStack() as stack:
        env = stack.enter_context(Environment())
        stack.enter_context(env.set_colors(256))

        # construction
        formatter = ColorFormatter(env)
        assert formatter.enabled

        # `get_style_class`
        style = ColorFormatter.get_style_class(SOLARIZED_STYLE)
        assert style is Solarized256Style
        style = ColorFormatter.get_style_class(pygments.styles.get_style_by_name('default'))

# Generated at 2022-06-23 19:20:19.389053
# Unit test for function get_lexer
def test_get_lexer():
    body = 'foo'
    assert get_lexer('text/plain') is None
    assert get_lexer('application/json') \
        is pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(
        'application/x-javascript',
        explicit_json=True,
        body='{}'
    ) is pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/x-javascript') \
        is pygments.lexers.get_lexer_by_name('javascript')
    assert get_lexer('application/vnd.api+json') \
        is pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-23 19:20:31.081806
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.core import DEFAULT_UA
    from httpie.core import main as httpie
    from httpie.core import main_put as httpie_put

    def _check_lexer(mime: str, body: str, expected=(None, None), method=httpie):
        headers = {
            'Content-Type': mime,
            'User-Agent': DEFAULT_UA,
        }
        env = Environment(
            colors=256,
            stdin=None,
            stdout=None,
            stderr=None,
            is_windows=False,
        )
        color_formatter = ColorFormatter(env=env)
        assert color_formatter.get_lexer_for_body(mime, body) == expected


# Generated at 2022-06-23 19:20:38.968284
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class Mock:
        colors = True
    env = Mock()

    explicit_json = False
    color_formatter = ColorFormatter(env, explicit_json)

    assert color_formatter.get_lexer_for_body("text/plain", "") is None
    assert color_formatter.get_lexer_for_body("application/json", "")\
        == pygments.lexers.get_lexer_by_name("json")

    explicit_json = True
    color_formatter = ColorFormatter(env, explicit_json)

    assert color_formatter.get_lexer_for_body("application/json", "")\
        == pygments.lexers.get_lexer_by_name("json")

# Generated at 2022-06-23 19:20:41.151481
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    try:
        cf = ColorFormatter(Environment())
    except:
        assert(False)



# Generated at 2022-06-23 19:20:47.731801
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer("application/json"), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer("application/javascript"), pygments.lexers.JavascriptLexer)
    assert isinstance(get_lexer("application/xml"), pygments.lexers.XmlLexer)
    assert isinstance(get_lexer("text/xml"), pygments.lexers.XmlLexer)
    assert isinstance(get_lexer("application/x-sh"), pygments.lexers.BashLexer)

# Generated at 2022-06-23 19:20:51.293302
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    headers = {
        'Content-Type': 'image/png',
        'Content-Length': 0,
    }

    formatter = ColorFormatter(None)
    assert formatter.get_lexer_for_body(headers['Content-Type'], 'data') is None

# Generated at 2022-06-23 19:21:00.406491
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexers.text import JsonLexer
    from pygments.lexers import get_lexer_by_name
    from pygments.lexers import get_lexer_for_mimetype
    import re

    lexer = SimplifiedHTTPLexer()

    # Test Request-Line
    data = [u'GET / HTTP/1.1']
    expected = [
        (Token.Name.Function, u'GET'),
        (Token.Text, u' '),
        (Token.Name.Namespace, u'/'),
        (Token.Text, u' '),
        (Token.Keyword.Reserved, u'HTTP'),
        (Token.Operator, u'/'),
        (Token.Number, u'1.1')
    ]

# Generated at 2022-06-23 19:21:03.822406
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style.__name__ == 'Solarized256Style'
    style = Solarized256Style()

# Generated at 2022-06-23 19:21:11.684140
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from collections import OrderedDict
    env = FormatterPlugin.get_default_env()

    cf = ColorFormatter(env)
    test_headers = "\r\n".join([
        "HTTP/1.1 200 OK",
        "Content-type: application/json",
        "Content-length: 20",
        "Date: Wed, 28 Mar 2018 15:18:09 GMT",
        "Connection: close"
    ])
    assert len(cf.format_headers(test_headers).split("\n")) == 6
    cf = ColorFormatter(env, headers_redact={'Authorization'})

# Generated at 2022-06-23 19:21:22.675350
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """
    Ensure format_body() formats JSON or other types as expected
    """
    json_body = '{"key":"value","name":"httpie"}'
    json_mime = 'application/json'
    txt_body = 'This is a text body'
    txt_mime = 'text/plain'
    html_body = "<html><head><title>Test</title></head></html>"
    html_mime = 'text/html'
    env = Environment()

    formatter = ColorFormatter(env, explicit_json=False)
    formatter_json = ColorFormatter(env, explicit_json=True)
    assert formatter.format_body(json_body, json_mime) == json_body
    assert formatter_json.format_body(json_body, json_mime) == json_body

# Generated at 2022-06-23 19:21:25.452826
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-23 19:21:33.396424
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Same as ColorFormatter.format_body() but uses an explicit
    # color_scheme to ensure consistent output.
    COLOR_SCHEME = 'fruity'
    body = """<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <h1>Hello <em>world</em> !</h1>
    <p>Je suis un paragraphe</p>
</body>
</html>
"""
    explicit_json = False
    # explicit_json is not used for HTML.
    if explicit_json:
        lexer = pygments.lexers.get_lexer_by_name('json')
    else:
        lexer = pygments

# Generated at 2022-06-23 19:21:39.299290
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.config import Config
    from httpie.plugins import FormatterPlugin
    Config.env = Environment()
    Config.env._stdout_isatty = True
    Config.env._stderr_isatty = True
    formatter = ColorFormatter(
        env=Config.env,
        code=ExitStatus.OK,
        config=parser.get_config(),
        error=None,
        **parser.get_kwargs()
    )
    assert isinstance(formatter, FormatterPlugin)
    return formatter

# Generated at 2022-06-23 19:21:40.521544
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert 1==1


# Generated at 2022-06-23 19:21:41.132673
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    pass

# Generated at 2022-06-23 19:21:50.776571
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    Lexer = SimplifiedHTTPLexer()
    text = "POST / HTTP/1.1\r\nHost: localhost:5000\r\nconnection: keep-alive\r\naccept: */*\r\nuser-agent: HTTPie/1.0.0\r\ncontent-type: application/json\r\ncontent-length: 12\r\n\r\n{\"key1\": 3}"
    print(text)
    text = "HTTP/1.1 200 OK\r\nDate: Wed, 25 Sep 2019 16:29:50 GMT\r\nServer: Apache/2\r\nContent-Length: 31\r\nContent-Type: application/json\r\n\r\n{\"key1\": \"value1\", \"key2\": 3}"
    print(text)
    text

# Generated at 2022-06-23 19:21:54.906470
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    test_lexer = SimplifiedHTTPLexer()
    assert test_lexer.name == "HTTP"
    assert test_lexer.aliases == ["http"]
    assert test_lexer.filenames == ["*.http"]
    assert len(test_lexer.tokens) > 0



# Generated at 2022-06-23 19:21:55.458354
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style(): pass

# Generated at 2022-06-23 19:22:04.130692
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Example headers
    request_headers = 'GET / HTTP/1.1\n\nHost: 127.0.0.1\nUser-Agent: ' \
                      'curl/7.63.0\nAccept: */*\nCookie: ' \
                      'session=b67a6b66-cd0c-4a3a-b9e9-d0f59823a53c\n' \
                      'Accept-Language: en-us\nContent-Length: ' \
                      '28\nContent-Type: application/json\n'
    response_headers = 'HTTP/1.1 200 OK\n\nContent-Length: 2\n\n'

    # Create a lexer object
    lexer = SimplifiedHTTPLexer()

    # Initialize tokens
    token_list1 = []


# Generated at 2022-06-23 19:22:12.901223
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment()

    # Body is not JSON
    body = "string"
    mime = "text/plain"
    formatter1 = ColorFormatter(env=env)
    lexer1 = formatter1.get_lexer_for_body(body=body, mime=mime)
    assert (lexer1 is None)

    # MIME type is not JSON
    body = '{"key": "value"}'
    mime = "text/plain"
    formatter2 = ColorFormatter(env=env)
    lexer2 = formatter2.get_lexer_for_body(body=body, mime=mime)
    assert (not isinstance(lexer2, type(TextLexer)))

    # JSON is detected as MIME
    body = '{"key": "value"}'
    mime

# Generated at 2022-06-23 19:22:19.540410
# Unit test for function get_lexer
def test_get_lexer():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters import JsonFormatter

    class MockPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers

        def format_body(self, body, mime):
            return body

    def assert_lexer(mime, expected_lexer):
        mime, expected_lexer = mime.lower(), expected_lexer.lower()
        if 'json' in expected_lexer:
            json_formatter = JsonFormatter()
            json_formatter.configure(env=None)

# Generated at 2022-06-23 19:22:30.222980
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import unittest
    from unittest import mock
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.formatters.colors import ColorFormatter
    from httpie.config import Config
    import sys

    class FormatterTest(unittest.TestCase):
        def setUp(self):
            # mock configuration
            sys.stdout = StdoutBytesIO()
            self.config = Config()
            self.formatter = ColorFormatter(self.config)
    
        def test_format_body_html(self):
            html = "<html><h1>Hello world</h1></html>"
            self.formatter.format_body(body=html, mime='text/html')
    
    unittest.main()

# Generated at 2022-06-23 19:22:37.700272
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer(mime='text/html') == pygments.lexers.HtmlLexer
    assert get_lexer(mime='application/json') == pygments.lexers.JsonLexer
    assert get_lexer(mime='application/javascript') == pygments.lexers.JavascriptLexer
    assert get_lexer(mime='application/xml') == pygments.lexers.XmlLexer
    assert get_lexer(mime='image/gif') is None
    assert get_lexer(mime='text/plain', explicit_json=True, body='{}') == pygments.lexers.JsonLexer
    assert get_lexer(mime='text/plain', explicit_json=True, body='{') is None

# Generated at 2022-06-23 19:22:48.955396
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.writers.streams import StreamOutputWriter
    from httpie.core import main

    environment = Environment(
        colors=256,
        output_file=StreamOutputWriter(),
        stdin=None,
        stdout=None,
        stderr=None,
    )
    formatter = ColorFormatter(
        env=environment,
        color_scheme='default',
    )
    formatted_headers = formatter.format_headers("""HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 17

""")

# Generated at 2022-06-23 19:22:52.841292
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    print(pygments.highlight(
        code="",
        lexer=SimplifiedHTTPLexer(),
        formatter=Terminal256Formatter(
            style=Solarized256Style
        )
    ).strip())

# Generated at 2022-06-23 19:22:54.140343
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    ColorFormatter(None, {})

# Generated at 2022-06-23 19:23:03.392183
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie import ExitStatus
    from httpie.client import parse_mime_type
    from httpie.output.streams import get_default_stdout
    from httpie.context import Environment
    from httpie.plugins import plugin_manager

    #
    # Setup
    #

    # Disable stdout log output during unit tests
    env = Environment(stdout=get_default_stdout(), stderr=get_default_stdout())
    for plugin in plugin_manager.enabled_plugins:
        plugin.set_environment(env)

    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)

    #
    # Tests
    #
    # Explicit --json
    mime = parse_mime_type('text/plain')
    assert formatter.get_lexer_for

# Generated at 2022-06-23 19:23:05.124218
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class('solarized')
    assert style_class == Solarized256Style

# Generated at 2022-06-23 19:23:13.337030
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment

    env = Environment(stdout=None, colors=256, is_windows=False)
    color = ColorFormatter(env=env)
    assert color.format_body(
        "<html></html>", 'text/html') == "\x1b[38;5;183m<html>\x1b[39m\x1b[38;5;183m</html>\x1b[39m\n"
    assert color.format_body(
        "<html></html>", 'text/xml') == "\x1b[38;5;183m<html>\x1b[39m\x1b[38;5;183m</html>\x1b[39m\n"
    assert color.format_body(
        "<html></html>", 'application/xml')

# Generated at 2022-06-23 19:23:18.785076
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():

    env = Environment(colors=16)
    F = ColorFormatter(env, color_scheme=DEFAULT_STYLE)

    assert F.get_style_class('solarized') == Solarized256Style
    assert F.get_style_class('solarized256') == Solarized256Style
    assert F.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-23 19:23:29.079343
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(Environment(colors=256), explicit_json=False)
    assert color_formatter.get_lexer_for_body("application/json", "") is not None
    assert color_formatter.get_lexer_for_body("application/json; charset=utf8", "") is not None
    assert color_formatter.get_lexer_for_body("application/json; charset=utf8", "{}") is not None
    assert color_formatter.get_lexer_for_body("application/json; charset=utf8", "") is not None
    assert color_formatter.get_lexer_for_body("application/hal+json; charset=utf8", "") is not None

# Generated at 2022-06-23 19:23:29.729804
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert True

# Generated at 2022-06-23 19:23:30.376967
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    pass

# Generated at 2022-06-23 19:23:31.377327
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style is not None

# Generated at 2022-06-23 19:23:40.828785
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter('environ')
    assert formatter.get_lexer_for_body('application/json','{}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json','{"hello": "world"}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json','blah') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('text/plain','blah') == pygments.lexers.get_lexer_by_name('text')
    assert formatter.get_lexer_for_body('application/xml','blah') == py

# Generated at 2022-06-23 19:23:49.344512
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    config = {'colors': 'true'}
    env = Environment(config=config)
    color_formatter = ColorFormatter(env=env)

    config_256 = {'colors': '256'}
    env_256 = Environment(config=config_256)
    color_256_formatter = ColorFormatter(env=env_256)

    config_auto = {'colors': '256', 'style': 'auto'}
    env_auto = Environment(config=config_auto)
    auto_color_formatter = ColorFormatter(env=env_auto)
    assert auto_color_formatter.formatter == color_256_formatter.formatter

    config_style = {'colors': '256', 'style': 'solarized'}
    env_style = Environment(config=config_style)


# Generated at 2022-06-23 19:23:59.663041
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class MockLexer:
        name = 'HTTP'
        aliases = ['http']
        filenames = ['*.http']

# Generated at 2022-06-23 19:24:07.450784
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    formatter = ColorFormatter(env=env)

    # Respones with Content-Type: application/json
    mime = 'application/json'
    body = '{"json": "body"}'
    assert formatter.format_body(body, mime) == '{\n  "json": "body"\n}\n'
    body = "{\"json\": \"body\"}"
    assert formatter.format_body(body, mime) == '{\n  "json": "body"\n}\n'

    # Respones with Content-Type: text/html; charset=utf-8
    mime = 'text/html; charset=utf-8'

# Generated at 2022-06-23 19:24:14.813451
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json; charset=utf-8') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json-rpc') == pygments.lexers.get_lexer_by_name('javascript')
    assert get_lexer('application/javascript') == pygments.lexers.get_lexer_by_name('javascript')
    assert get_lexer('text/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('text/javascript') == pygments.lexers.get_lexer_by_name('javascript')

# Generated at 2022-06-23 19:24:26.563041
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPluginRegistry
    from httpie.context import Environment
    from httpie.core import main
    from httpie.cli import parser
    from httpie.compat import str

    expected_lexer_name = 'python'
    expected_mime_content = 'text/x-python'
    expected_content = 'print "Hello, World!"'

    args = parser.parse_args(
        args=['--print', 'b'],
        env=Environment(),
        stdin=None,
        stdout=None,
        stderr=None,
        plugins=FormatterPluginRegistry(),
    )
    output_stream = main(args)
    output = output_stream.getvalue()
    output_stream.close()
    output = str(output, 'utf8')

# Generated at 2022-06-23 19:24:29.782417
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter(
        env=Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE
    )

# Generated at 2022-06-23 19:24:31.274017
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class env:
        colors = None
    formatter = ColorFormatter(env)
    assert not formatter.enabled

# Generated at 2022-06-23 19:24:39.091125
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    print("test get_lexer_for_body() of class ColorFormatter")
    f = ColorFormatter({'colors': 256})
    print("test with Content-Type 'text/x-xml' and body '<xml>hello</xml>', expecting xml")
    print("result: "+str(f.get_lexer_for_body("text/x-xml","<xml>hello</xml>")))
    print("test with Content-Type 'text/x-xml' and body '<xml>hello</xml>', expecting xml")
    print("result: "+str(f.get_lexer_for_body("text/plain","<xml>hello</xml>")))
    print("test with Content-Type 'text/x-xml' and body '<xml>hello</xml>', expecting xml")

# Generated at 2022-06-23 19:24:46.162352
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class MockEnvironment(object):
        def __init__(self, colors):
            self.colors = colors

    def assert_style(color_scheme, expected_style_class):
        env = MockEnvironment(256)
        style_class = ColorFormatter(env, color_scheme=color_scheme).get_style_class(color_scheme)
        assert style_class == expected_style_class

    assert_style('monokai', pygments.styles.get_style_by_name('monokai'))
    assert_style('solarized', Solarized256Style)

# Generated at 2022-06-23 19:24:50.803044
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert(style.background_color == "#1c1c1c")
    assert(len(style.styles.items()) == 51)

# Generated at 2022-06-23 19:25:00.619976
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', body='{"a": "b"}')
    assert get_lexer('application/json', explicit_json=True, body='{"a": "b"}')
    assert not get_lexer('application/json', explicit_json=True, body='{a: "b"}')
    assert not get_lexer('application/json', explicit_json=True, body='foo')
    assert not get_lexer('application/json', explicit_json=True)
    assert get_lexer('text/plain')
    assert get_lexer('text/plain', body='foo') is None
    assert get_lexer('text/x-json')
    assert get_lexer('text/x-json', body='foo') is None
    assert get_lex

# Generated at 2022-06-23 19:25:03.606213
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    '''
    test_Solarized256Style tests for error in the class Solarized256Style
    which is a class to be inherited by Pygments.
    '''
    assert Solarized256Style  # unit test passed

# Generated at 2022-06-23 19:25:09.593908
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment(colors=256, is_windows=False)
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    body = "{{\"message\": \"Hello World\"}}"
    mime = "application/json"
    assert color_formatter.format_body(body, mime) == body

# Generated at 2022-06-23 19:25:11.071810
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style

# Generated at 2022-06-23 19:25:11.480928
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:25:19.585152
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment, EnvironmentBase, merge_env_config
    from httpie.output.streams import STDOUT
    env = EnvironmentBase(
        stream=STDOUT,
        colors=True,
        stdin=None,
        stdin_isatty=False,
    )
    env = merge_env_config(env, env.config['colors'])
    env.colors = True
    color_formatter = ColorFormatter(env)
    headers = """\
HTTP/1.1 200 OK
Content-Encoding: gzip
Server: nginx/1.10.2
Connection: keep-alive
Content-Type: application/json
Date: Fri, 15 Sep 2017 19:47:43 GMT
Content-Length: 1581
{ 'key1': 'value1' }"""
    headers = color_form

# Generated at 2022-06-23 19:25:20.088892
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:25:28.639721
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class DummyColorFormatter(ColorFormatter):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.explicit_json = False

        def get_lexer_for_body(self, mime: str, body: str) -> Optional[Type[Lexer]]:
            return self._get_lexer_for_body(mime, body)

    env = Environment()
    formatter = DummyColorFormatter(env, explicit_json=False)

    lexer = formatter.get_lexer_for_body('application/json', '{}')
    assert lexer is not None
    assert lexer.name == 'JSON'
    assert lexer.aliases == ['json']

# Generated at 2022-06-23 19:25:34.227368
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    cf = ColorFormatter(None)
    cf.formatter = MockFormatter()
    body = '{"code": 0, "data": "success"}'
    mime = 'application/json'
    assert cf.format_body('', 'text/json') == ''
    assert cf.format_body(body, mime) == '{"code": 0, "data": "success"}'


# Generated at 2022-06-23 19:25:35.139709
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style()

# Generated at 2022-06-23 19:25:40.582285
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # type: () -> None
    '''
    Test case for the constructor of SimplifiedHTTPLexer
    '''
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filename == ['*.http']

# Generated at 2022-06-23 19:25:46.018445
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    texter = SimplifiedHTTPLexer()
    tokens = texter.get_tokens('GET /uri HTTP/1.1\r\n'
                        'Host: example.com\r\n'
                        'Accept: application/json\r\n'
                        'Accept: application/xml\r\n'
                        'Content-Type: text/html')
    print(tokens)

# Generated at 2022-06-23 19:25:47.509955
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    l = SimplifiedHTTPLexer()
    assert l

# Generated at 2022-06-23 19:25:48.706834
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer()

# Generated at 2022-06-23 19:25:51.749576
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("monokai") == pygments.styles.get_style_by_name("monokai")

# Generated at 2022-06-23 19:25:56.308440
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    ######################################################################
    # basic
    ######################################################################
    # This one gets detected as a JSON response
    mime = 'application/json'
    assert ColorFormatter(Environment(), explicit_json=False).get_lexer_for_body(mime, '{}\n') == pygments.lexers.get_lexer_by_name('json')

    # And this one doesn't, because the JSON is invalid
    mime = 'application/json'
    assert ColorFormatter(Environment(), explicit_json=False).get_lexer_for_body(mime, '{') is None

    # Not text, so no lexer
    mime = 'image/png'

# Generated at 2022-06-23 19:25:56.962886
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:26:08.801589
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.context import Environment
    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        stdout_isatty=True,
        stdin_isatty=True,
        stderr_isatty=True,
    )
    color_formatter = ColorFormatter(explicit_json=False, env=env)

    # Text/plain
    lexer = color_formatter.get_lexer_for_body(
        mime='text/plain',
        body='',
    )
    assert isinstance(lexer, TextLexer)

    # Text/html
    lexer = color_formatter.get_lexer_for_body(
        mime='text/html',
        body='',
    )

# Generated at 2022-06-23 19:26:18.091037
# Unit test for function get_lexer
def test_get_lexer():
    # http://en.wikipedia.org/wiki/JSON#Example
    sample_json = '''
    {
        "firstName": "John",
        "lastName": "Smith",
        "address": {
            "streetAddress": "21 2nd Street",
            "city": "New York",
            "state": "NY",
            "postalCode": 10021
        },
        "phoneNumbers": [
            "212 732-1234",
            "646 123-4567"
        ]
    }
    '''

    # http://www.tutorialspoint.com/cplusplus/cpp_data_types.htm

# Generated at 2022-06-23 19:26:22.181417
# Unit test for function get_lexer
def test_get_lexer():
    # XML
    assert get_lexer('application/xml').aliases == ['xml']
    # HTML
    assert get_lexer('text/html').aliases == ['html', 'htm', 'xhtml']
    # JSON
    assert get_lexer('application/json').aliases == ['json']

# Generated at 2022-06-23 19:26:24.635157
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    try:
        _ = Solarized256Style()
    except AttributeError as e:
        pygments.util.ClassNotFound(e)

# Generated at 2022-06-23 19:26:26.542399
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_scheme = 'default'
    assert not ColorFormatter.get_style_class(color_scheme)

# Generated at 2022-06-23 19:26:28.679356
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter  # Always be true for test


# Generated at 2022-06-23 19:26:31.427076
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer().name == 'HTTP'
    assert SimplifiedHTTPLexer().aliases == ['http']
    assert SimplifiedHTTPLexer().filenames == ['*.http']

# Generated at 2022-06-23 19:26:43.045093
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pygments.token
    import pprint
    # case 1. headers_line = ''
    headers_line = ''
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(style=Solarized256Style)
    result = ColorFormatter.format_headers(headers_line, http_lexer, formatter)
    assert result is headers_line
    # case 2. headers_line = 'HTTP/1.1 200 OK'
    headers_line = 'HTTP/1.1 200 OK'
    result = ColorFormatter.format_headers(headers_line, http_lexer, formatter)
    assert result == '\x1b[38;5;33;48;5;234mHTTP/1.1 200 OK'
    # case 3. headers_line = 'G' * 1003 +

# Generated at 2022-06-23 19:26:45.574190
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    formatter = ColorFormatter(env)
    formatter.format_headers('test')

# Generated at 2022-06-23 19:26:56.745920
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', body='{}')
    assert not get_lexer('application/javascript')
    assert not get_lexer('application/javascript', body='{}')
    assert get_lexer('text/html')
    assert get_lexer('text/html', explicit_json=True, body='<!DOCTYPE html>')
    assert not get_lexer('text/html', body='{}')
    assert get_lexer('text/x-css')
    assert get_lexer('text/x-json')
    assert get_lexer('application/vnd.org.w3.uvv.message+json')

# Generated at 2022-06-23 19:27:06.293783
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from .base import BaseFormat

    class ColorFormatter(BaseFormat):
        def format_body(self, body: str, mime: str) -> str:
            return "~~ " + body + " ~~"

        def format_headers(self, headers: str) -> str:
            return "## " + headers + " ##"

    # Check that body is wrapped with marker
    color_formatter = ColorFormatter()
    body = "This is the body"
    expected = "~~ This is the body ~~"
    assert color_formatter.format_body(body=body, mime="text/plain") == expected

    # Check that body is empty
    color_formatter = ColorFormatter()
    body = ""
    expected = ""

# Generated at 2022-06-23 19:27:15.039615
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    f = ColorFormatter(
        env=Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
        **kwargs
    )
    none = ""
    assert f.format_headers(headers="") == none
    assert f.format_body(body="", mime="") == none
    assert f.get_lexer_for_body(mime="", body="") == none
    assert f.get_style_class(color_scheme=DEFAULT_STYLE) == none
    assert get_lexer(mime=DEFAULT_STYLE, explicit_json=False, body=none) == none
    assert get_lexer(mime=DEFAULT_STYLE, explicit_json=True, body=none) == none

# Generated at 2022-06-23 19:27:16.814404
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-23 19:27:17.397143
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-23 19:27:27.035973
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True)
    color_formatter = ColorFormatter(env=env, color_scheme=DEFAULT_STYLE)
    assert color_formatter.explicit_json == False
    assert isinstance(color_formatter.formatter, TerminalFormatter)
    assert isinstance(color_formatter.http_lexer, PygmentsHttpLexer)
    assert color_formatter.enabled == True

    color_formatter = ColorFormatter(env=env, color_scheme='fruity')
    assert color_formatter.explicit_json == False
    assert isinstance(color_formatter.formatter, Terminal256Formatter)
    assert isinstance(color_formatter.http_lexer, SimplifiedHTTPLexer)
    assert color_formatter.enabled == True

    color_form

# Generated at 2022-06-23 19:27:28.685000
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    solarized256 = Solarized256Style()
    return solarized256


# Generated at 2022-06-23 19:27:39.036741
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    cf = ColorFormatter(env, explicit_json=True, color_scheme=True)

    text = 'hello httpie'
    assert cf.format_body(text, 'text/plain') == 'hello httpie'
    assert cf.format_body(text, 'text/plain; charset=UTF-8') == 'hello httpie'

    if not is_windows:
        text = '{"name": "httpie", "age": 1}'
        assert (cf.format_body(text, 'text/plain') == '{"name": "httpie", "age": 1}')
        assert (cf.format_body(text, 'text/plain; charset=UTF-8') == '{"name": "httpie", "age": 1}')

# Generated at 2022-06-23 19:27:39.551977
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter

# Generated at 2022-06-23 19:27:48.324585
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():

    class MockEnvironment(object):
        def __init__(self, colors: int, json: bool):
            self.colors = colors
            self.json = json
            pass

    env1 = MockEnvironment(256, False)
    env2 = MockEnvironment(256, True)
    env3 = MockEnvironment(8, False)
    env4 = MockEnvironment(8, True)
    env5 = MockEnvironment(-1, False)
    env6 = MockEnvironment(-1, True)

    try:
        color_formatter1 = ColorFormatter(env1, False, AUTO_STYLE)
        assert(isinstance(color_formatter1.formatter, Terminal256Formatter))
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-23 19:27:59.556953
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style.BASE03 == "#1c1c1c"
    assert Solarized256Style.BASE02 == "#262626"
    assert Solarized256Style.BASE01 == "#4e4e4e"
    assert Solarized256Style.BASE00 == "#585858"
    assert Solarized256Style.BASE0 == "#808080"
    assert Solarized256Style.BASE1 == "#8a8a8a"
    assert Solarized256Style.BASE2 == "#d7d7af"
    assert Solarized256Style.BASE3 == "#ffffd7"
    assert Solarized256Style.YELLOW == "#af8700"
    assert Solarized256Style.ORANGE == "#d75f00"
    assert Solarized256Style.RED == "#af0000"
    assert Solarized

# Generated at 2022-06-23 19:28:04.682130
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style.__name__ == 'Solarized256Style'
    assert Solarized256Style.__doc__.splitlines()[0] == 'solarized256'
    assert Solarized256Style.__doc__.splitlines()[1] == '------------'

# Generated at 2022-06-23 19:28:11.610121
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    try:
        input_string = """
        GET / HTTP/1.1
        X-header: value
        """
        lexer = SimplifiedHTTPLexer()
    except pygments.util.ClassNotFound:
        assert False, "Lexer is not found"
    result = pygments.highlight(
        code=input_string,
        lexer=lexer,
        formatter=Terminal256Formatter(
            style=pygments.styles.get_style_by_name('solarized')
        ),
    )
    assert input_string in result



# Generated at 2022-06-23 19:28:13.020426
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    f = ColorFormatter()
# Coverage test for constructor of class ColorFormatter
test_ColorFormatter()

# Generated at 2022-06-23 19:28:21.933424
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

    def assert_token(token, expected_token_type, expected_value):  # type: ignore
        assert token[0] == expected_token_type
        assert token[1] == expected_value

    # Request-Line
    tokens = list(lexer.get_tokens('GET / HTTP/1.1\n'))
    assert_token(tokens[0], pygments.token.Name.Function, 'GET')
    assert_token(tokens[1], pygments.token.Text, ' ')
    assert_token(tokens[2], pygments.token.Name.Namespace, '/')
    assert_token(tokens[3], pygments.token.Text, ' ')

# Generated at 2022-06-23 19:28:25.379140
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    #this function tests to find the lexer for the body
    lexer = ColorFormatter(Environment()).get_lexer_for_body("application/json", '{ "hello": "world" }')
    assert lexer is not None

# Generated at 2022-06-23 19:28:34.696273
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.input import ParseError
    from httpie.output.streams import get_default_output_stream
    from httpie.plugins.builtin import HTTPHeadersProcessor

    fake_env = Environment(
        stdin=None,
        stdout=get_default_output_stream('stdout'),
        stderr=get_default_output_stream('stderr'),
        stdin_isatty=False,
        stdout_isatty=True,
        v2=False,
        colors=256,
        defaults=dict(
            style='solarized256',
        )
    )
    processor = ColorFormatter(
        env=fake_env
    )

# Generated at 2022-06-23 19:28:36.844254
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    # noinspection PyTypeChecker
    _ = Solarized256Style()

# Generated at 2022-06-23 19:28:42.040537
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class FormatterPlugin(object):
        def __init__(self, **kwargs):
            self.enabled = True
    formatter_plugin = FormatterPlugin()
    environment = Environment()
    environment.colors = True
    color_formatter = ColorFormatter(environment, formatter_plugin, True)
    assert color_formatter.explicit_json is True

test_ColorFormatter()

# Generated at 2022-06-23 19:28:47.507425
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    # Request-Line
    assert [
        (pygments.token.Name.Function, u'GET'),
        (pygments.token.Text, u' '),
        (pygments.token.Name.Namespace, u'/'),
        (pygments.token.Text, u' '),
        (pygments.token.Keyword.Reserved, u'HTTP'),
        (pygments.token.Operator, u'/'),
        (pygments.token.Number, u'1.1'),
    ] == list(lexer.get_tokens('GET / HTTP/1.1'))
    # Response Status-Line

# Generated at 2022-06-23 19:28:56.522990
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    tokens = lexer.get_tokens_unprocessed('GET / HTTP/1.1')
    assert list(tokens) == [(0, pygments.token.Token, 'GET'),
                            (2, pygments.token.Text, ' '),
                            (4, pygments.token.Token, '/'),
                            (5, pygments.token.Text, ' '),
                            (7, pygments.token.Keyword.Reserved, 'HTTP'),
                            (11, pygments.token.Operator, '/'),
                            (12, pygments.token.Number, '1.1')]



# Generated at 2022-06-23 19:28:59.965517
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Test with wrong parameter
    style_class = ColorFormatter.get_style_class('abc')
    assert style_class is Solarized256Style

    # Test with existing style name
    style_class = ColorFormatter.get_style_class('fruity')
    assert style_class == pygments.styles.get_style_by_name('fruity')

    # Test with auto style name
    style_class = ColorFormatter.get_style_class('auto')
    assert style_class is TerminalFormatter

    # Test with solarized style name
    style_class = ColorFormatter.get_style_class('solarized')
    assert style_class is Solarized256Style

# Generated at 2022-06-23 19:29:02.501125
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    c = ColorFormatter(None)
    assert c.explicit_json == False
    assert c.color_scheme == 'auto'
    assert c.enabled == False

# Generated at 2022-06-23 19:29:09.124566
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(None)
    result = color_formatter.format_body(
        body='''<html>
                <head>
                <title>HTTPie test</title>
                </head>
                <body>
                <h1>This is a test!</h1>
                </body>
                </html>''',
        mime="text/html"
    )
    print(result)

# Generated at 2022-06-23 19:29:15.889716
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    def get_style_class(color_scheme: str) -> Type[pygments.style.Style]:
        return ColorFormatter.get_style_class(color_scheme)

    result = get_style_class(SOLARIZED_STYLE)
    assert isinstance(result, pygments.style.Style)

    result = get_style_class(DEFAULT_STYLE)
    assert isinstance(result, pygments.style.Style)

    result = get_style_class('solarized')
    assert isinstance(result, pygments.style.Style)

    result = get_style_class('default')
    assert isinstance(result, pygments.style.Style)

    try:
        result = get_style_class('not_exist')
        assert result is None
    except:
        pass

# Generated at 2022-06-23 19:29:19.900042
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=True)
    formatter = ColorFormatter(env)
    headers = 'HTTP/1.1 200 OK\nContent-Type: application/json'
    formatter.format_headers(headers)