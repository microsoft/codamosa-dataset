

# Generated at 2022-06-11 23:37:52.840994
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class('monokai')
    assert style == pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-11 23:38:05.284672
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie import ExitStatus  # To avoid circular imports
    from httpie.output.streams import BaseOutputStream
    from httpie.output.streams import ColorizedOutputStream
    from httpie.output.streams import OutputStream
    from httpie.core import main as httpie, parse_items
    color_formatter_class = ColorFormatter.new(env=None, **{})
    color_formatter = color_formatter_class(env=None, **{})
    ## Test with ColorizedOutputStream
    class ColorizedOutputStream(OutputStream):
        def __setattr__(self, name, value):
            return
        def __init__(self, write=None):
            self.write = write
    output_stream = ColorizedOutputStream()
    color_formatter.write_headers = color_formatter.write

# Generated at 2022-06-11 23:38:18.087805
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from . import config
    from httpie.plugins import default_style
    from httpie.plugins import get_colors
    from httpie.ui import get_theme_manager

    env = Environment(color=256, colors=256,
                      styles=[dict(class_name=default_style, name=default_style)])

    assert ColorFormatter(env).get_style_class(default_style).__name__ == default_style
    # Call config.load_config to register style colorscheme-solarized
    config.load_config(env)
    assert ColorFormatter(env).get_style_class(default_style).__name__ == default_style
    # Call get_colors() to register style colorscheme-solarized
    get_colors(env)
    assert ColorFormatter(env).get_style_class

# Generated at 2022-06-11 23:38:20.180789
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style



# Generated at 2022-06-11 23:38:26.296146
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('pygments.styles.fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('pygments.styles.solarized') == Solarized256Style

# Generated at 2022-06-11 23:38:37.492006
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pygments
    from httpie.context import Environment
    from pygments.formatter import NullFormatter

    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='default')
    lexer = color_formatter.get_lexer_for_body('image/jpeg', '')
    assert lexer is None
    lexer = color_formatter.get_lexer_for_body('application/json', '')
    assert lexer is None
    lexer = color_formatter.get_lexer_for_body('application/json', '{}')
    assert lexer is not None
    assert isinstance(lexer, pygments.lexers.JsonLexer)

# Generated at 2022-06-11 23:38:42.167782
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment())
    assert isinstance(
        formatter.get_lexer_for_body('image/png', ''),
        pygments.lexers.image.ImageLexer
    )
    assert formatter.get_lexer_for_body(
        'random/nonexistent', ''
    ) is None

# Generated at 2022-06-11 23:38:43.363128
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    colorFormatter = ColorFormatter()

# Generated at 2022-06-11 23:38:52.923842
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.utils import DateTime, CaseInsensitiveDict
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_response_streams
    from httpie.output.formatted_stream import FormattedStreamHandler
    env = Environment(colors=256, underline_headers=True)
    env.stdout = get_response_streams(env.stdout)
    env.stderr = get_response_streams(env.stderr)
    env.stdout.auto_label = False
    env.stderr.auto_label = False
    env.request.headers = 'A: b'
    env.request.url = 'test'

# Generated at 2022-06-11 23:38:56.174884
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin

    if not is_windows:
        #Only run it on Windows
        return

    env = Environment()
    env.colors = True
    env.color_scheme = 'fruity'

    #Only send the unit test case when we have a color formatter
    if isinstance(FormatterPlugin.get_instance(env=env), ColorFormatter):
        test_ColorFormatter_format_body_cases()

# Generated at 2022-06-11 23:39:05.748433
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    assert http_lexer
    assert pygments.highlight(  # nosec
        code='POST / HTTP/1.1\nContent-Type: application/json',
        lexer=SimplifiedHTTPLexer(),
        formatter=Terminal256Formatter(
            style=Solarized256Style
        )
    )

# Generated at 2022-06-11 23:39:17.596403
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.bodies import get_data_detector, data_detectors

    class DummyPseudoStream(object):
        def __init__(self, content):
            self._content = content
            self._idx = 0

        def read(self, num_bytes=None):
            if num_bytes is not None:
                if self._idx + num_bytes >= len(self._content):
                    content = self._content[self._idx:]
                    self._idx = len(self._content)
                    return content
                else:
                    content = self._content[self._idx:self._idx + num_bytes]
                    self._idx += num_bytes
                    return content
            else:
                return self._content[self._idx:]

       

# Generated at 2022-06-11 23:39:23.094046
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import Plugin
    from httpie.compat import str

    env = Environment()
    plugin = Plugin(env)
    colorFormatter = ColorFormatter(env)
    raw_headers = str('GET /path HTTP/1.1\r\n'
                      'Host: example.com\r\n'
                      'Connection: close\r\n'
                      'Accept-Encoding: gzip, deflate\r\n'
                      'User-Agent: HTTPie/0.9.2\r\n'
                      'Accept: */*\r\n\r\n')
    assert colorFormatter.format_headers(raw_headers) == __get_formatted_headers()



# Generated at 2022-06-11 23:39:26.768922
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(Environment())
    body = formatter.format_body('{"a":"b"}', 'application/json')
    assert '\x1b[38;5;28m{\x1b[39m' in body

# Generated at 2022-06-11 23:39:30.638635
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Test for style auto
    ColorFormatter.get_style_class(AUTO_STYLE)
    # Test for available style
    for style in AVAILABLE_STYLES:
        ColorFormatter.get_style_class(style)

# Generated at 2022-06-11 23:39:33.574496
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(None, True)
    assert color_formatter.explicit_json == True

# Generated at 2022-06-11 23:39:44.149404
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    from httpie.plugins import PluginManager

# Generated at 2022-06-11 23:39:47.242347
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert type(lexer.get_tokens_unprocessed('')) == list


# Generated at 2022-06-11 23:39:56.532098
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins import FormatterPlugin
    from httpie.exitstatus import ExitStatus
    import os

    class FakePlugin(FormatterPlugin):
        name = 'foo'
        group_name = 'bar'

        def __init__(self):
            pass

        def format_headers(self, headers: str) -> str:
            return headers

        def format_body(self, body: str, mime: str) -> str:
            return body

    plugin = FakePlugin()
    assert plugin.get_style_class('solarized') == Solarized256Style

    os.environ['HTTPIE_COLORS'] = '0'
    plugin = FakePlugin()
    assert plugin.get_style_class('solarized') == Solarized256Style

    os.environ['HTTPIE_COLORS'] = '1'
    plugin

# Generated at 2022-06-11 23:40:02.848478
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    ColorFormatter.get_style_class("fruity") == pygments.styles.get_style_by_name("fruity")
    ColorFormatter.get_style_class("solarized") == pygments.styles.get_style_by_name("solarized")
    ColorFormatter.get_style_class("auto") == Solarized256Style()



# Generated at 2022-06-11 23:40:10.034614
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    lexer.test('PUT /test/test HTTP/1.1\nContent-Type: application/json')

# Generated at 2022-06-11 23:40:21.342519
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    # set up fake environment(env)
    env = Environment()
    env.stdout_isatty = 'True'
    env.stdin_isatty = 'True'
    # set up fake manager(manager)
    manager = FormatterPluginManager('response', env)
    # instantiate ColorFormatter(fp)
    fp = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    # add fp to manager
    manager.add_plugin(fp)
    # set up fake data(data)
    data = type('', (), {})()
    # data.match_info = {'headers': ''}

# Generated at 2022-06-11 23:40:30.076987
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import HTTPBasicAuth

    class TestColorFormatter(ColorFormatter):

        def get_lexer_for_body(
            self, mime: str,
            body: str
        ) -> Optional[Type[Lexer]]:
            return Lexer

    formatter = TestColorFormatter(
        env=Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE
    )

    body = formatter.format_body('test', 'text/html')
    assert body == 'test'

# Generated at 2022-06-11 23:40:35.452800
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(None, explicit_json=False, color_scheme='solarized')
    body = '{"a":"b"}'
    assert color_formatter.format_body(body, mime='application/json') == body
    assert color_formatter.format_body(body, mime='application/xml') == body

# Generated at 2022-06-11 23:40:41.082141
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins.builtin import ColorFormatter
    import pygments.styles
    color_formatter = ColorFormatter(None, color_scheme='monokai')
    assert color_formatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')
    assert color_formatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-11 23:40:45.066729
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    print("test ColorFormatter_format_body")
    httpie = ColorFormatter()
    mime = "application/json"
    body = '{"results":[{"name":"chr21","file":"file1.bam","length":48129895,"url":"http://lhc.dp/ftp/Illumina/Examples/BAM/HCC1954_P6_chr21.bam"},{"name":"chrY","file":"file2.bam","length":59373566,"url":"http://lhc.dp/ftp/Illumina/Examples/BAM/HCC1954_P6_chrY.bam"}]}'
    print(httpie.format_body(body, mime))
    return



# Generated at 2022-06-11 23:40:49.092223
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = 'auto'
    cf = ColorFormatter(env, explicit_json=explicit_json, color_scheme=color_scheme)

# Generated at 2022-06-11 23:40:50.567669
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity')

# Generated at 2022-06-11 23:40:56.749868
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    colorFormatter = ColorFormatter(
        Environment(),
        explicit_json=False,
        color_scheme='fruity',
    )
    print(colorFormatter.format_body('hello,world', 'text/plain'))
    print(colorFormatter.format_body(
        '{"hello":"world"}', 'application/json'))



# Generated at 2022-06-11 23:41:07.361854
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest

# Generated at 2022-06-11 23:41:24.163960
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    uut = ColorFormatter(Environment(colors=256))
    actual = uut.format_headers(headers='''HTTP/1.1 200 OK\r
Content-Type: application/json\r
Content-Length: 60\r
Connection: keep-alive\r
Server: gunicorn/19.9.0\r
Date: Mon, 18 Mar 2019 09:33:20 GMT\r
Strict-Transport-Security: max-age=31536000\r\r
''')

# Generated at 2022-06-11 23:41:29.465495
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    color = ColorFormatter(Environment(), None)
    body = "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n{\"foo\": 1, \"bar\": 2}"
    assert color.format_headers(body)
    assert not color.format_body(body, 'text/html')

# Generated at 2022-06-11 23:41:39.954966
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import itertools

    # Prepare input
    env = Environment()
    formatter = ColorFormatter(env, color_scheme=DEFAULT_STYLE)

    mime_type = 'text/html'
    body = '<html>\n <head>\n  <title>Page</title>\n </head>\n <body>\n  Hello\n </body>\n</html>\n'

    # Get expected output

# Generated at 2022-06-11 23:41:48.187382
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import JSONMatcher
    from httpie.compat import is_pygments_installed
    from httpie.context import Environment
    from httpie.plugins import BuiltinPlugin

    Environment(colors=True)
    class testColorFormatter(ColorFormatter):
        def __init__(self):
            BuiltinPlugin()
            self.mime = 'application/json'
            self.body = '{"hello": "world"}'
            self.explicit_json = False
            self.formatter = None

    test_instance = testColorFormatter()
    test_instance.format_body(test_instance.body, test_instance.mime)
    if not is_pygments_installed:
        assert test_instance.body == '{"hello": "world"}'
    else:
        assert test_

# Generated at 2022-06-11 23:41:58.925907
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import os
    import zipfile
    import shutil
    import httpie.config
    import httpie.plugins
    dirpath = 'httpie'
    shutil.rmtree(dirpath, ignore_errors=True)
    zip_ref = zipfile.ZipFile('httpie.zip', 'r')
    zip_ref.extractall(dirpath)
    zip_ref.close()
    os.rename(dirpath+'/httpie-master', dirpath+'/httpie')
    cf = httpie.config.Config(env={
        'COLOR_SCHEME': 'solarized'
        })
    cf.__setattr__('colors', 256)
    formatter = ColorFormatter(cf)
    assert(isinstance(formatter, ColorFormatter))
    formater.format_headers("")


# Generated at 2022-06-11 23:42:10.166433
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Impossible to test with a real environment
    # so we will create a dummy one.
    env = Environment(colors=True, style='solarized256')
    color_formatter = ColorFormatter(env, False)

    # HTML test
    lexer = color_formatter.get_lexer_for_body(
        'text/html',
        '<html><body>yo</body></html>'
    )
    assert lexer.name == 'HTML'

    # JSON test
    lexer = color_formatter.get_lexer_for_body(
        'application/json',
        '{"foo":"bar"}'
    )
    assert lexer.name == 'JSON'

    # JSON test

# Generated at 2022-06-11 23:42:18.957080
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    parsed = lexer.get_tokens('GET / HTTP/1.1\r\nHost: www.google.com\r\n\r\n')

# Generated at 2022-06-11 23:42:28.723008
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main

    env = main.get_environment(colors=True,
                               style=DEFAULT_STYLE)

    f = ColorFormatter(env).format_headers
    assert f('{}') == '\x1b[37m{\x1b[39m\x1b[37m}\x1b[39m'

# Generated at 2022-06-11 23:42:32.241187
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    env.stdout_isatty = True
    formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')

    assert formatter.name == 'solarized'
    assert formatter.enabled
    assert formatter.formatter.style is Solarized256Style
    assert formatter.http_lexer is SimplifiedHTTPLexer

# Generated at 2022-06-11 23:42:42.880556
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class TransparentColorFormatter(ColorFormatter):
        def format_body(self, body, mime):
            return (
                super(TransparentColorFormatter, self).format_body(body, mime)
            )

    from httpie.plugins import Plugin
    from httpie.config import DEFAULT_CONFIG
    from httpie.client import CLIENT_DEFAULTS
    from httpie.cli.parser import parse_args, parser
    from httpie.plugins.manager import get_plugins
    from httpie.compat import is_windows

    config = dict(
        config_dir=DEFAULT_CONFIG,
        config_file=DEFAULT_CONFIG,
        env=dict(),
    )

# Generated at 2022-06-11 23:43:00.816388
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(None)

# Generated at 2022-06-11 23:43:05.908495
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(Environment())
    assert color_formatter.get_lexer_for_body('application/json', '{}')
    assert color_formatter.get_lexer_for_body('application/xml', '<xml></xml>')
    assert color_formatter.get_lexer_for_body('application/javascript', 'var i = 0')
    assert color_formatter.get_lexer_for_body('application/octet-stream', '\uFEFF')
    assert color_formatter.get_lexer_for_body('unknown/unknown', '{"json": "but unknown"}')

# Generated at 2022-06-11 23:43:16.933354
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pygments.token
    c_e = ColorFormatter(env=Environment(), color_scheme='solarized')
    formatter = c_e.formatter
    http_lexer = c_e.http_lexer
    assert type(http_lexer) == pygments.lexer.RegexLexer
    assert type(formatter) == pygments.formatters.terminal.TerminalFormatter
    assert c_e.format_headers("GET /index.html HTTP/1.0\n") == \
        pygments.highlight("GET /index.html HTTP/1.0\n", http_lexer, formatter)
    assert c_e.format_headers("Accept-Language: en\n") == \
        pygments.highlight("Accept-Language: en\n", http_lexer, formatter)

# Generated at 2022-06-11 23:43:27.833306
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer('text/html') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/xml') == pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/xml') == pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('app/xml') == pygments.lexers.get_lexer_by_name('text')
    assert get_lexer('xml', body='{"key": "val"}') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-11 23:43:35.267116
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # TODO: create a case of
    #   * headers not in list
    #   * headers not in dict
    #   * headers in dict
    #   * headers in dict with a list

    # prepare a http response
    headers = """
HTTP/1.1 200 OK
Transfer-Encoding: chunked
Content-Type: text/html; charset=utf-8
Server: Werkzeug/0.12.1 Python/3.6.0
Date: Sun, 27 Aug 2017 18:35:38 GMT
"""

    # remove empty lines and trailing spaces.
    headers = "\n".join([h.strip() for h in headers.split("\n")])

    # prepare the formatter
    from httpie.context import Environment
    env = Environment()
    env.colors = True

# Generated at 2022-06-11 23:43:46.573710
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.cli import parser
    from httpie.context import Environment
    env = Environment(stdin=None,
                      stdout=None,
                      stderr=None,
                      stdin_isatty=False,
                      stdout_isatty=False,
                      color=False,
                      config_dir=None,
                      config_path=None,
                      config_file_paths=[],
                      style=None,
                      defaults=None,
                      stdout_bytes_written=0,
                      request_counter=0,
                      trusted_hosts=set(),
                      output_options=parser.output_options)
    color_formatter = ColorFormatter(
        env, color_scheme="solarized", explicit_json=True,
    )

    lexer = color_formatter.get_lexer_for_

# Generated at 2022-06-11 23:43:51.796868
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    try:
        # For both Python 2 and Python 3
        import StringIO as io
    except ImportError:
        import io
    import sys
    buf = io.StringIO()
    lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter()
    pygments.highlight(code="hello world", lexer=lexer, formatter=formatter, outfile=buf)

# Generated at 2022-06-11 23:43:57.864214
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(Environment(), False, 'monokai')

    output = formatter.format_headers('GET / HTTP/1.1')
    assert output == (
        '\x1b[38;5;145mGET\x1b[0m \x1b[38;5;242m/\x1b[0m '
        '\x1b[38;5;145mHTTP/1.1\x1b[0m'
    )



# Generated at 2022-06-11 23:44:04.783133
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest

    headers = u"""\
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/1.0.2
"""
    color_formatter = ColorFormatter(Environment(colors=256))
    assert color_formatter.format_headers(headers).strip() == u"""\
[38;5;33mAccept-Encoding[39m: [38;5;33mgzip, deflate[39m
[38;5;33mAccept[39m: [38;5;33m*/*[39m
[38;5;33mUser-Agent[39m: [38;5;33mHTTPie/1.0.2[39m"""

# Generated at 2022-06-11 23:44:11.533698
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class EnvironmentForTest(Environment):
        colors = True
        colors_256 = True
        explicit_json = False
    env = EnvironmentForTest()
    color_formatter = ColorFormatter(env)
    assert color_formatter.explicit_json == env.explicit_json
    assert isinstance(color_formatter.formatter, Terminal256Formatter)
    assert isinstance(color_formatter.http_lexer, SimplifiedHTTPLexer)


# Generated at 2022-06-11 23:44:35.555927
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    toks = lexer.get_tokens_unprocessed(
        'GET /foo HTTP/1.1\n'
        'User-Agent: HTTPie\n'
        'Accept-Encoding: gzip, deflate\n'
    )
    for tok in toks:
        print(tok)


# Generated at 2022-06-11 23:44:37.946703
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer_for_body('text/plain') == None
    assert get_lexer_for_body('application/javascript') == None

# Generated at 2022-06-11 23:44:48.612977
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import HTTP_FORMATS
    from httpie.plugins import FormatterPlugin

    # httpie.output.streams.get_formatted_response_body
    # depends on httpie.context.Environment requires argv
    env = Environment(
        argv=[],
        colors=256,
        stdin=object(),
        stdin_isatty=False,
        stdout=object(),
        stdout_isatty=False,
        output_options=HTTP_FORMATS,
        output_options_default=HTTP_FORMATS[0],
        formatter_options={},
        formatter_options_default=FormatterPlugin.DEFAULT_FORMAT,
    )
    environment = env

# Generated at 2022-06-11 23:44:56.469115
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class FakeEnv(object):
        def __init__(self):
            self.colors = 256
    env = FakeEnv()

    class FakeResponse(object):
        def __init__(self, mime, body):
            self.mime = mime
            self.body = body

    color_formatter = ColorFormatter(env)

    response = FakeResponse("application/json", '{"foo": "bar"}')
    assert color_formatter.format_body(response.body, response.mime)
    assert len(color_formatter.format_body(response.body, response.mime))

    response = FakeResponse("text/html", '<html></html>')
    assert color_formatter.format_body(response.body, response.mime)

# Generated at 2022-06-11 23:45:04.444989
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    formatter = ColorFormatter(Environment(),
                               explicit_json=False,
                               color_scheme=SOLARIZED_STYLE,
                               style=None,
                               colors=True,
                               streams=None,
                               stdout=None,
                               stderr=None)
    style_class = formatter.get_style_class(color_scheme=AVAILABLE_STYLES.pop())
    assert style_class
    assert type(style_class) == type(Solarized256Style)

# Generated at 2022-06-11 23:45:05.808572
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-11 23:45:16.313061
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    class Mock():
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    lexer = SimplifiedHTTPLexer()

    def assert_formatted(string, tokens):
        formatted = lexer.get_tokens(string)
        assert len(formatted) == 1
        assert formatted[0] == next(tokens)

    def assert_equal(tokens):
        for token_tuple, token_code in tokens:
            yield Mock(token=token_code), token_tuple

    # Request-Line

# Generated at 2022-06-11 23:45:20.921379
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('tango') == pygments.styles.TangoStyle
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == Solarized256Style


# Generated at 2022-06-11 23:45:32.152888
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # TODO: test when responsive to a mime type that is not json
    # TODO: test when responsive to a mime type that is json, but not --json
    # TODO: test when json but neither responsive to mime type nor --json

    from httpie.compat import str
    from httpie.plugins import FormatterPlugin

    class MockColorFormatter(ColorFormatter):
        def format_headers(self, headers):
            headers_only_formatted = super(MockColorFormatter, self).format_headers(headers)
            return headers + '\r\n' + headers_only_formatted

        def format_body(self, body, mime):
            return super(MockColorFormatter, self).format_body(body, mime)
    from httpie.context import Environment

    # TODO: Add tests for

# Generated at 2022-06-11 23:45:39.712456
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer(mimetypes=[])
    assert lexer.tokens['root'][0][0] == r'([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)'
    assert lexer.tokens['root'][1][0] == r'(HTTP)(/)(\d+\.\d+)( +)(\d{3})( +)(.+)'
    assert lexer.tokens['root'][2][0] == r'(.*?)( *)(:)( *)(.+)'



# Generated at 2022-06-11 23:46:06.886867
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexers import get_lexer_by_name
    from pygments.token import Token
    from httpie.compat import bytes
    lexer = get_lexer_by_name('http', stripnl=False)
    assert isinstance(lexer, SimplifiedHTTPLexer)

    content = b'GET / HTTP/1.1\r\n' \
              b'Host: localhost\r\n' \
              b'Accept-Encoding: identity\r\n' \
              b'User-Agent: HTTPie/0.9.2\r\n' \
              b'\r\n' \
              b'{"foo": "bar"}\n'
    tokens = list(lexer.get_tokens(bytes(content)))
    assert tokens[0][0] == Token.Name

# Generated at 2022-06-11 23:46:16.365335
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer(startinlinetokens="")

    # Request-Line, Status-Line
    text = r'GET http://binfalse.de/index.html HTTP/1.1\nHTTP/1.1 200 OK'
    tokens = list(lexer.get_tokens(text))
    assert len(tokens) == 12, "request line and status line should be ok"
    assert tokens[0][0] == pygments.token.Name.Function
    assert tokens[2][0] == pygments.token.Name.Namespace
    assert tokens[4][0] == pygments.token.Keyword.Reserved
    assert tokens[7][0] == pygments.token.Number
    assert tokens[7][1] == "1.1"

# Generated at 2022-06-11 23:46:18.524645
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    #type: () -> None
    assert ColorFormatter.format_body('{}', 'application/json') == '{}'

# Generated at 2022-06-11 23:46:25.115532
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.structures import Response
    color_formatter = ColorFormatter(None)
    r = Response(
        'HTTP/1.1 200 OK\r\nfoo: bar\r\nbaz: quux\r\n'
        '\r\n'
        '{hello: [[world]]}\n'
    )

# Generated at 2022-06-11 23:46:34.753480
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    json_str = '{"name": "hong", "age": 33}'
    xml_str = """<?xml version="1.0" encoding="utf-8"?>
                <employees>
                    <employee id="111">
                        <name>hong</name>
                        <age>25</age>
                    </employee>
                </employees>"""
    html_str = """<!DOCTYPE html>
                <html>
                    <head>
                        <title>Title of the document</title>
                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                    </head>
                    <body>
                        <p>This is my first paragraph.</p>
                    </body>
                </html>"""

    c = ColorFormatter(Environment())

# Generated at 2022-06-11 23:46:42.516549
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import unittest
    import os
    print (os.getcwd())
    class TestColorFormatter(unittest.TestCase):

        def assert_header(self, expected_formatted_msg, expected_headers, expected_body, msg):
            http_msg = msg
            #self.assertEqual(expected_headers, msg.headers)
            #self.assertEqual(expected_body, msg.body)
            cf = ColorFormatter(
                explicit_json=False,
                env=None,
                color_scheme='solarized',
                style='solarized'
            )
            self.assertEqual(expected_formatted_msg, cf.format_headers(http_msg))
            return

# Generated at 2022-06-11 23:46:53.262560
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    '''
    get_style_class: get pygments colors style, 
                     default is solarized256.
    '''
    import sys
    import os
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.color import AUTO_STYLE, SOLARIZED_STYLE
    from httpie.output.colors import ColorFormatter

    env = Environment()
    env.colors = True
    if is_windows:
        assert ColorFormatter(env).get_style_class('auto') == pygments.styles.get_style_by_name('fruity')
    else:
        assert ColorFormatter(env).get_style_class('auto') == Solarized256Style
    assert ColorFormatter(env).get_style_class('solarized') == Solar

# Generated at 2022-06-11 23:46:55.029266
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class('solarized256')
    assert style_class == Solarized256Style

# Generated at 2022-06-11 23:47:05.728769
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.streams import Stream
    stream = Stream(isatty=True, encoding='utf8', errors='replace')

    formatter = ColorFormatter(stream.env, explicit_json=False, color_scheme=AUTO_STYLE)
    assert formatter.get_lexer_for_body('text/plain') == TextLexer
    assert formatter.get_lexer_for_body('application/json') == PygmentsHttpLexer
    assert formatter.get_lexer_for_body('application/unknown') == TextLexer

    formatter = ColorFormatter(stream.env, explicit_json=False, color_scheme=SOLARIZED_STYLE)
    assert formatter.get_lexer_for_body('text/plain') == TextLexer
    assert formatter.get_

# Generated at 2022-06-11 23:47:08.470826
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    colorFormatter = ColorFormatter(env)
    assert colorFormatter

