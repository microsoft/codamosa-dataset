

# Generated at 2022-06-11 23:38:04.674827
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import default_environment
    from httpie.plugins import builtin_plugins
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter

    env = default_environment.copy()
    # Force 256 colors in colorama
    env.colors = 256
    plugin_manager = FormatterPlugin.PluginManager(
        env, builtin_plugins, ColorFormatter
    )
    # plugin_manager = builtin_plugins(env, ColorFormatter)

    instance = ColorFormatter(
        env,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )

# Generated at 2022-06-11 23:38:08.947461
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style
    assert ColorFormatter.get_style_class('abc') is not Solarized256Style

# Generated at 2022-06-11 23:38:19.612563
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.input import ParseError
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    import os
    import httpie.plugins
    env = Environment(colors=256, stdin=os.fdopen(0, "rb"), stdout=os.fdopen(1, "wb"))
    httpie.plugins.load_builtin_plugins()
    plugins = FormatterPlugin.get_enabled(env)
    formatter = plugins[0]
    assert isinstance(formatter, ColorFormatter)
    assert formatter.group_name == 'colors'

# Generated at 2022-06-11 23:38:21.950618
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/xml')
    assert get_lexer('application/x-www-form-urlencoded')

# Generated at 2022-06-11 23:38:30.414838
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class EnvironmentMock:
        @property
        def colors(self) -> int:
            return True

    class ColorFormatterMock(ColorFormatter):
        def __init__(self, **kwargs):
            self.env = EnvironmentMock()
            super().__init__(self.env, **kwargs)

    formatter = ColorFormatterMock()
    assert formatter.get_lexer_for_body("application/json", '{"key": "value"}') == pygments.lexers.get_lexer_by_name("json")
    assert formatter.get_lexer_for_body("text/plain", "str") == pygments.lexers.get_lexer_by_name("text")

# Generated at 2022-06-11 23:38:41.577470
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    """
    Test format_headers() for the following conditions:
      1) HTTP response with request line, headers, and empty body
      2) HTTP response with request line, headers, and body
      3) No HTTP response, with just a body
    """
    import httpie
    color_env = Environment(colors=256)
    color_formatter = ColorFormatter(
        env=color_env,
        color_scheme=SOLARIZED_STYLE
    )

# Generated at 2022-06-11 23:38:51.010465
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    """Verify that the ``get_style_class`` provides a valid ``Style``

    Given:
        - ``get_style_class`` from the ``ColorFormatter`` class
        - ``fruity`` string
    When:
        - ``get_style_class`` is called with ``fruity``
    Then:
        - The returned style class should be a valid ``pygment.style.Style`` class
        - The returned style class should be a class named ``FruityStyle``
    """
    # Arrange
    cf = ColorFormatter(Environment())
    style_name = 'fruity'
    # Act
    style_class = cf.get_style_class(style_name)
    # Assert
    assert style_class.__name__ == 'FruityStyle'

# Generated at 2022-06-11 23:38:53.099103
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(env=Environment)
    assert formatter.group_name == 'colors'

# Generated at 2022-06-11 23:38:53.824691
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert False

# Generated at 2022-06-11 23:39:05.417860
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(Environment()) # env.colors = 256, env.colors = True
    test_data = [
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: application/json\r\n\r\n"
        '{"status": true, "message": "Success"}',

        "HTTP/1.1 200 OK\r\n"
        "Content-Type: application/pdf\r\n\r\n"
        "%PDF-1.4\n%\xa7\xa4\xa6\n",
    ]

# Generated at 2022-06-11 23:39:18.034992
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    text = """\
POST /api/ HTTP/1.1
Accept: application/json
Content-Length: 28
Content-Type: application/json
Host: www.example.com
User-Agent: HTTPie/1.0.2

{
    "hello": "world"
}"""
    print(pygments.highlight(
        code=text,
        lexer=lexer,
        formatter=Terminal256Formatter(style=Solarized256Style),
    ))

# Generated at 2022-06-11 23:39:20.015733
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(None)
    assert color_formatter.format_body('{}', 'application/json') == '{\n    \n}'

# Generated at 2022-06-11 23:39:23.966552
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class ExampleStyle(pygments.style.Style):
        pass

    assert ColorFormatter.get_style_class('example') == ExampleStyle

# Generated at 2022-06-11 23:39:25.062906
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter


# Generated at 2022-06-11 23:39:30.218243
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    test_str = (
        'HTTP/1.1 200 OK\n'
        'Content-Type: text/html\n'
    )
    for tk, val in SimplifiedHTTPLexer(test_str):
        print(tk, val)

# Generated at 2022-06-11 23:39:42.497910
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    color_formatter = ColorFormatter(env=env)

    # color_formatter.format_body(body, mime)
    # body: str
    # mime: str
    # Return type: str
    body = "&lt;html&gt;&lt;head&gt;&lt;title&gt;Hello&lt; /title&gt;&lt;/head&gt;&lt;body&gt;World&lt;/body&gt;&lt;/html&gt;"
    mime = "text/html"

# Generated at 2022-06-11 23:39:51.336588
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # follow below format
    # Lexer().test(test_string)
    # #test_string is string for SimplifiedHTTPLexer
    # do not change the content of test_string

    test_string = """\
GET / HTTP/1.1
Accept: text/plain, text/html
Accept-Charset: ISO-8859-1

HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 12
Connection: close

<!doctype html>
"""
    SimplifiedHTTPLexer().test(test_string)

# Generated at 2022-06-11 23:40:04.227961
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert ColorFormatter(Environment()).format_body('{"foo":"bar"}',
                                                     'text/html') == '{"foo":"bar"}'
    assert ColorFormatter(Environment()).format_body('{"foo":"bar"}',
                                                     'application/json') != '{"foo":"bar"}'
    assert ColorFormatter(Environment()).format_body('<status>200</status>', 'text/xml') != '<status>200</status>'
    assert ColorFormatter(Environment()).format_body('{"foo":"bar"}',
                                                     'application/javascript') == '{"foo":"bar"}'
    assert ColorFormatter(Environment()).format_body('{"foo":"bar"}',
                                                     'application/javascript',
                                                     explicit_json=True) != '{"foo":"bar"}'

# Generated at 2022-06-11 23:40:13.821886
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie import ExitStatus
    from fixtures import (
        FILE_PATH_ARG, FILE_PATH, FILE_CONTENT, JSON_FILE_CONTENT,
        JSON_FILE_PATH_ARG, JSON_FILE_PATH,
    )
    from utils import http, HTTP_OK
    env = Environment()
    env.config['colors'] = 256
    env.config['style'] = 'fruity'
    r = http('GET', HTTP_OK, '--check-status', env=env)
    assert r.exit_status == ExitStatus.OK
    assert 'GET /' in r.json
    assert 'HTTP/1.1 200 OK' in r.json
    r = http('GET', HTTP_OK, '--check-status', '--print=h', env=env)

# Generated at 2022-06-11 23:40:22.287170
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class TestFormatter(ColorFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.test_style1 = self.get_style_class(SOLARIZED_STYLE)
            self.test_style2 = self.get_style_class('default')

    test_formatter = TestFormatter()
    assert test_formatter.test_style1 == Solarized256Style, \
        'ColorFormatter.get_style_class should return the Solarized256Style class'
    assert test_formatter.test_style2 == TerminalFormatter.style, \
        'ColorFormatter.get_style_class should return the default class'

# Generated at 2022-06-11 23:40:36.948888
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    text = '''\
POST /post HTTP/1.1
Host: www.example.org
Content-Type: text/plain; charset=utf-8
Content-Length: 13

hello, world!'''
    for i, token, value in lexer.get_tokens(text):
        assert isinstance(token, pygments.token.Token), 'No Token class'

# Generated at 2022-06-11 23:40:44.383847
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment.create()
    explicit_json = False
    color_scheme = DEFAULT_STYLE

    colorFormatter = ColorFormatter(env, explicit_json=explicit_json, color_scheme=color_scheme)
    colorFormatter.format_headers(headers="")
    colorFormatter.format_body(body="", mime="")
    colorFormatter.get_lexer(mime="", explicit_json=explicit_json, body="")

# Generated at 2022-06-11 23:40:54.863475
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import os
    import sys
    import json
    from httpie.core import main
    from httpie.compat import is_windows, urlopen

    if is_windows:
        sys.stdout.write("\x1b[1;31m")
        sys.stdout.write("This test requires POSIX-compatible operating systems.\n")
        sys.stdout.write("\x1b[0m")
        sys.exit(1)
    elif 'pygments' not in os.environ.get('PYTHONPATH', ''):
        sys.stdout.write("\x1b[1;31m")
        sys.stdout.write("This test requires Pygments to be installed where python could find it.\n")
        sys.stdout.write("\x1b[0m")

# Generated at 2022-06-11 23:40:59.229035
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    test = ColorFormatter([], "solarized")
    print(test)
    assert callable(test.format_headers())
    assert callable(test.format_body())
    assert callable(test.get_style_class())

# Generated at 2022-06-11 23:41:02.792816
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(
        None,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
        **{}
    )

# Generated at 2022-06-11 23:41:10.297980
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # 1. argument: mime: str
    # 2. argument: explicit_json=False
    # 3. argument: body=''
    # return: Optional[Type[Lexer]]
    #
    # Note that the code body is not tested, as it is a term of Pygments
    formatter = ColorFormatter(Environment())
    mime_json = 'application/json'
    mime_plain = 'text/plain'

    # Parameter mime_json
    # 1. argument: mime: str
    # 2. argument: explicit_json=False
    # 3. argument: body=''
    # return: Optional[Type[Lexer]]
    result = formatter.get_lexer_for_body(mime=mime_json, body='', explicit_json=False)

# Generated at 2022-06-11 23:41:20.661515
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import is_windows
    from httpie.context import Environment

    empty_env = Environment()

    def run_test(mime, body, expected_lexer):
        actual_lexer = ColorFormatter(
            env=empty_env,
            color_scheme=None,
            explicit_json=False
        ).get_lexer_for_body(mime, body)

        assert isinstance(actual_lexer, expected_lexer)

    # Nonexistent mime type
    run_test('application/foo', '', TextLexer)

    # Application/json
    run_test('application/json', '', pygments.lexers.get_lexer_by_name('json'))

    # Cannot be JSON, but the mime type is application/json

# Generated at 2022-06-11 23:41:22.954424
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    if __name__ == '__main__':
        env = Environment()


test = test_ColorFormatter()

if __name__ == '__main__':
    print("test finished")

# Generated at 2022-06-11 23:41:29.060779
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    def test_cases():
        yield 'base16-google-dark', 'Base16Style'
        yield 'monokai', 'MonokaiStyle'
        yield 'vim', 'VimStyle'
        yield SOLARIZED_STYLE, 'Solarized256Style'

    f = ColorFormatter(None)
    for style_name, class_name in test_cases():
        assert f.get_style_class(style_name).__name__ == class_name

# Generated at 2022-06-11 23:41:33.591222
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    cf = ColorFormatter(
        color_scheme=SOLARIZED_STYLE,
        env=Environment(),
    )
    assert cf.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-11 23:42:00.700305
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    import os
    import colorama
    colorama.init(autoreset = True)
    env = Environment(stdin=None,stdout=None,stderr=None,
        colors=colorama.Fore.BLUE,
        is_windows=is_windows)
    color_formatter = ColorFormatter(
        env=env,
        color_scheme=SOLARIZED_STYLE,
    )
    headers = '''POST /post HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate, compress
Accept: */*
User-Agent: HTTPie/0.9.9'''.strip()

# Generated at 2022-06-11 23:42:07.482790
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # color_scheme not in AVAILABLE_STYLES
    style = ColorFormatter.get_style_class('test2')
    assert 'Solarized256Style' == style.__name__

    # color_scheme in AVAILABLE_STYLES
    style = ColorFormatter.get_style_class('monokai')
    assert 'MonokaiStyle' == style.__name__

# Generated at 2022-06-11 23:42:12.850879
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    colfmt = ColorFormatter(
        env=Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    # json
    assert colfmt.format_body(
        body='{"http": "1.1"}',
        mime='application/json'
    )
    # js
    assert colfmt.format_body(
        body='var http = 1.1',
        mime='application/javascript'
    )
    # css
    assert colfmt.format_body(
        body='* { http: 1.1 }',
        mime='text/css'
    )
    # html

# Generated at 2022-06-11 23:42:14.088983
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter

# Generated at 2022-06-11 23:42:16.010407
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("autumn") is pygments.styles.get_style_by_name("autumn")

# Generated at 2022-06-11 23:42:25.941064
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment()
    color_formatter = ColorFormatter(env, color_scheme='fruity')
    assert color_formatter.get_style_class('fruity') == \
        pygments.styles.get_style_by_name('fruity')
    assert color_formatter.get_style_class('abcde') == \
        Solarized256Style
    assert color_formatter.get_style_class(AUTO_STYLE) == Solarized256Style
    color_formatter = ColorFormatter(env, color_scheme=None)
    assert color_formatter.get_style_class('fruity') == \
        pygments.styles.get_style_by_name('fruity')
    assert color_formatter.get_style_class('abcde') == \
        pygments

# Generated at 2022-06-11 23:42:30.263816
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from io import StringIO
    from httpie import ExitStatus
    from httpie.core import main

    env = Environment(stdin=StringIO(), stdout=StringIO(), stderr=StringIO())
    args = [
        '--style=solarized256',
    ]
    r = main(args, env=env)
    assert ExitStatus.OK == r

# Generated at 2022-06-11 23:42:36.414905
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    # Request-Line
    matched = lexer.analyse('POST /foo HTTP/1.1')
    assert matched
    assert lexer.get_tokens('POST /foo HTTP/1.1')
    # Response Status-Line
    matched = lexer.analyse('HTTP/1.1 200 OK')
    assert matched
    assert lexer.get_tokens('HTTP/1.1 200 OK')
    # Header
    matched = lexer.analyse('Content-Type: text/html')
    assert matched
    assert lexer.get_tokens('Content-Type: text/html')

# Generated at 2022-06-11 23:42:46.560382
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    key = 'HTTP/1.1 200 OK\nContent-Type: application/json'
    value = pygments.highlight(
        code=key,
        lexer=SimplifiedHTTPLexer(),
        formatter=TerminalFormatter()
    ).strip()
    compare = '\x1b[32m\x1b[1mHTTP\x1b[22m\x1b[39m/\x1b[34m1.1\x1b[39m 200 OK\nContent-Type:\x1b[39m \x1b[31m\x1b[1mapplication\x1b[22m\x1b[39m/\x1b[31m\x1b[1mjson\x1b[22m\x1b[39m'

# Generated at 2022-06-11 23:42:49.501578
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    out = ColorFormatter.get_style_class('solarized')
    assert out == Solarized256Style
    out = ColorFormatter.get_style_class('auto')
    assert out == Solarized256Style


# Generated at 2022-06-11 23:43:44.718708
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter


# Generated at 2022-06-11 23:43:46.845135
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class(AUTO_STYLE)
    assert style is None



# Generated at 2022-06-11 23:43:56.485224
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie.cli
    parser = httpie.cli.parser
    env = httpie.cli.Environment(config_dir=None, stdin=httpie.cli.DEFAULT_STDIN)
    color_formatter = ColorFormatter(env=env, **vars(parser.parse_args([])))

    assert get_lexer(
        mime='application/json',
        explicit_json=False,
        body='{"foo": "bar"}',
    ) is pygments.lexers.get_lexer_by_name('JSON')

    assert get_lexer(
        mime='application/vnd.api+json',
        explicit_json=False,
        body='{"foo": "bar"}',
    ) is pygments.lexers.get_lexer_by_name('JSON')

    assert get_lex

# Generated at 2022-06-11 23:44:04.173823
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import httpie.plugins as plugins
    plugins._load_disabled()

    formatter = ColorFormatter(env=Environment(colors=256), color_scheme=SOLARIZED_STYLE)
    

# Generated at 2022-06-11 23:44:14.384849
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    """
    Tests for the constructor of class SimplifiedHTTPLexer.
    """
    # To get the token type for each token
    # (imported from pygments.token)
    from pygments.token import Token
    # To get the value for each token
    from pygments.util import get_token_values
    # To construct the lexer
    lexer = SimplifiedHTTPLexer()

    # Create and test regex of lexer
    regex = lexer.build_rules()
    # For token, the first one is Keyword.Reserved,
    # the second one is Keyword.Reserved (Operator in pygments.token),
    # the third one is Keyword.Reserved, the fourth one is Name.Namespace,
    # and the last one is Number.
    # The Value of the first one is HTTP,

# Generated at 2022-06-11 23:44:23.525336
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.formatter import get_lexer
    class FakeEnv():
        def __init__(self, json=False, colors=False):
            self.json = json
            self.colors = colors

    env = FakeEnv(colors=256)

    json_body = """
[
  {
    "string": "3",
    "number": 3,
    "array": [
      3
    ],
    "object": {
      "number": 3
    }
  },
  {
    "string": "3",
    "number": 3,
    "array": [
      3
    ],
    "object": {
      "number": 3
    }
  }
]
        """
    json_body = json_body.strip()
    mime = "application/json"

    #

# Generated at 2022-06-11 23:44:30.762312
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    import unittest
    from unittest.mock import Mock
    class Test(unittest.TestCase):
        def setUp(self):
            self.cf = ColorFormatter(Mock(colors=256))
        def test_get_style_class(self):
            self.assertEqual(self.cf.get_style_class('solarized'), Solarized256Style)
            self.assertEqual(self.cf.get_style_class('vim'), pygments.styles.VimStyle)
            self.assertNotEqual(self.cf.get_style_class('vim'), Solarized256Style)
    unittest.main()

# Generated at 2022-06-11 23:44:42.246437
# Unit test for method format_body of class ColorFormatter

# Generated at 2022-06-11 23:44:51.961059
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class TestEnv:
        colors = True

    def _(env, text, expected):
        return ColorFormatter(env, **{}).format_headers(text) \
            == expected.encode('utf-8')

    assert _(TestEnv(),
             '''\
HTTP/1.1 200 OK
Host: docs.python.org
Connection: close
Access-Control-Allow-Origin: *

''',
             '''\
HTTP/1.1 200 OK
Host: docs.python.org
Connection: close
Access-Control-Allow-Origin: *

''')

# Generated at 2022-06-11 23:45:01.491906
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.colors import get_lexer
    _body1 = """<html>
    <body>
        <h1>Some thing</h1>
        <p>test_ColorFormatter_format_body</p>
    </body>
    </html>"""
    _body2 = "test_ColorFormatter_format_body"

    class test:
        def __init__(self):
            pass

        def format_headers(self, headers: str) -> str:
            pass

        def format_body(self, body: str, mime: str) -> str:
            pass
