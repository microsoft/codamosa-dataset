

# Generated at 2022-06-11 23:37:55.108116
# Unit test for function get_lexer
def test_get_lexer():
    """Verify that we can get the right lexer for MIME types."""
    assert type(get_lexer('text/plain')) is PygmentsHttpLexer
    assert type(get_lexer('foo/bar')) is TextLexer
    assert type(get_lexer('json')) is TextLexer
    assert type(get_lexer('application/json')) is pygments.lexers.JsonLexer
    assert type(get_lexer('application/javascript')) is pygments.lexers.JavascriptLexer
    assert type(get_lexer('text/x-json')) is pygments.lexers.JsonLexer
    assert type(get_lexer('text/css')) is pygments.lexers.CssLexer
    assert type(get_lexer('application/xml')) is pygments

# Generated at 2022-06-11 23:38:06.710055
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie import ExitStatus
    from httpie.cli import parser
    from tests.utils import http

    args = parser.parse_args([
        '--json',
        '--colors',
        'GET',
        '--style',
        'solarized256',
        'http://httpbin.org/get',
        'a=httpie',
    ])
    env = http('--print=B', env=Environment(args), error_exit_ok=True)
    assert env.lines == HEADER_LINES



# Generated at 2022-06-11 23:38:18.751808
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import builtin

    env = builtin.Environment()
    formatter = ColorFormatter(env)

    valid_header_response = (
        'HTTP/1.1 200 OK\r\n'
        'Date: Fri, 03 Feb 2017 11:13:33 GMT\r\n'
        'Server: Apache/2.4.7 (Ubuntu)\r\n'
        'X-Powered-By: PHP/5.5.9-1ubuntu4.21\r\n'
        'Content-Length: 20879\r\n'
        'Connection: keep-alive\r\n'
        'Content-Type: text/html\r\n'
        '\r\n'
    )


# Generated at 2022-06-11 23:38:24.188309
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Setup
    color_scheme = 'solarized'
    cf = ColorFormatter(Environment(), True, color_scheme)
    # Assert
    if cf.enabled:
        assert cf.formatter.__class__ is Terminal256Formatter
        assert cf.formatter.style.__class__ is Solarized256Style
    else:
        assert cf.formatter.__class__ is TerminalFormatter

# Generated at 2022-06-11 23:38:34.915319
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment(color=True)
    assert isinstance(ColorFormatter(env, color_scheme='solarized256').formatter,
                      Terminal256Formatter)
    assert isinstance(ColorFormatter(env, color_scheme='solarized').formatter,
                      TerminalFormatter)
    assert isinstance(ColorFormatter(env, color_scheme='auto').formatter,
                      TerminalFormatter)
    env.color256 = True
    assert isinstance(ColorFormatter(env, color_scheme='solarized256').formatter,
                      Terminal256Formatter)
    assert isinstance(ColorFormatter(env, color_scheme='solarized').formatter,
                      Terminal256Formatter)
    assert isinstance(ColorFormatter(env, color_scheme='auto').formatter,
                      Terminal256Formatter)

# Generated at 2022-06-11 23:38:41.784653
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment(colors=0, stdin=True, isatty=True)
    formatter = ColorFormatter(env, False)
    assert formatter.format_body('<html><body>hello</body></html>', 'text/html') == '<html><body>hello</body></html>'
    assert formatter.format_body('{"a": 1, "b": 2}', 'application/json') == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-11 23:38:51.167347
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.formatters.colors import ColorFormatter
    from httpie.context import Environment
    env = Environment(stdout=None, colors=256)
    cf = ColorFormatter(env)

    result = cf.get_lexer_for_body(
        mime='text/xml',
        body='<foo>bar</foo>'
    )
    assert result.__name__ == 'XmlLexer'

    result = cf.get_lexer_for_body(
        mime='text/xml',
        body='<html></html>'
    )
    assert result.__name__ == 'XmlLexer'

    result = cf.get_lexer_for_body(
        mime='text/html',
        body='<html></html>'
    )
    assert result.__

# Generated at 2022-06-11 23:38:56.861536
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.cli import parser
    import os
    env = Environment(stdin=None, stdout=None, stderr=None,
                      is_windows=False,
                      colors=256,
                      encoding=None,
                      verify=None,
                      config_dir=None,
                      config_file=None,
                      options=parser.parse_args([]))

    color_formatter = ColorFormatter(env, explicit_json=False,
                                     color_scheme="solarized")

    # test for no headers
    assert color_formatter.format_headers('') == ''

    # test for one header

# Generated at 2022-06-11 23:39:02.233882
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(Environment(colors=True))
    assert formatter.format_headers(
        headers='GET / HTTP/1.1\r\nFoo: Bar'
    ) == '\x1b[2mHTTP/1.1 \x1b[32m200\x1b[39m OK\x1b[23m'

# Generated at 2022-06-11 23:39:14.500881
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(colors=1, stdout_isatty=False)).enabled == False
    assert ColorFormatter(Environment(colors=256, stdout_isatty=True)).enabled == True
    assert ColorFormatter(Environment(colors=256, stdout_isatty=True), color_scheme='solarized').formatter.__class__ == Terminal256Formatter
    assert ColorFormatter(Environment(colors=256, stdout_isatty=True), color_scheme='fruity').formatter.__class__ == TerminalFormatter
    assert ColorFormatter(Environment(colors=256, stdout_isatty=True), color_scheme='fruity').formatter.__class__ == TerminalFormatter

# Generated at 2022-06-11 23:39:32.594024
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie.cli

    args = httpie.cli.parser.parse_args(args=[])
    httpie.cli.environment = Environment(args)

    formatter = ColorFormatter(httpie.cli.environment)

    def test(mime: str, lexer_name: str) -> None:
        lexer = formatter.get_lexer_for_body(mime=mime, body='{}')
        if not lexer: return
        assert lexer.name == lexer_name

    # Application
    test('application/json', 'JSON')
    test('application/vnd.apple.mpegurl', 'M3U')
    test('application/vnd.api+json', 'JSON')

    # Audio
    test('audio/webm', 'WebM')

# Generated at 2022-06-11 23:39:39.739514
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    from httpie.plugins import PluginManager
    pm = PluginManager()
    pm.load_installed_plugins()
    env = Environment(colors=1, stdin=None,
                      stdout=None,
                      stderr=None,
                      configure_dir=None,
                      plugins=pm)
    ColorFormatter(env, explicit_json=False, color_scheme='solarized')

# Generated at 2022-06-11 23:39:41.979979
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins.colors.solarized import Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style

# Generated at 2022-06-11 23:39:52.281215
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    if not formatter.enabled:
        return
    assert formatter.format_headers("""\
GET / HTTP/1.1
Host: example.com
Accept: */*
""") == """\
[38;5;33mGET [38;5;69m/ [38;5;243mHTTP/1.1
[38;5;33mHost[38;5;69m: [38;5;69mexample.com[0m
[38;5;33mAccept[38;5;69m: [38;5;69m*/*[0m"""



# Generated at 2022-06-11 23:40:05.106393
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import pytest

    # Preparation
    lexer = SimplifiedHTTPLexer()

    # Test functions
    get_tokens = lexer.get_tokens
    test_text = """\
GET / HTTP/1.1
Host: www.example.org

"""

# Generated at 2022-06-11 23:40:06.997243
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer is not None


# Generated at 2022-06-11 23:40:15.513854
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-11 23:40:23.789858
# Unit test for function get_lexer
def test_get_lexer():
    def assert_lexer(mime, body, explicit_json, lexer_name):
        lexer = get_lexer(mime, explicit_json=explicit_json, body=body)
        assert lexer.name == lexer_name

    # Match by MIME type
    assert_lexer('application/json', '{}', False, 'JSON')
    assert_lexer('application/x-yaml', 'x: 1', False, 'YAML')
    assert_lexer('text/html', '<html>', False, 'HTML')

    # Guess based on the content type suffix
    assert_lexer('application/vnd.org.w3.something+xml', '<xml>', False, 'XML')

# Generated at 2022-06-11 23:40:34.461751
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.cli.argtypes import KeyValueArgType

    env = Environment()
    args = KeyValueArgType()
    color_scheme = 'auto'
    explicit_json = False
    color_formatter = ColorFormatter(env, explicit_json, color_scheme)
    assert color_formatter.group_name == 'colors'
    assert color_formatter.format_headers('foo')
    assert color_formatter.format_body('foo', 'foo')
    assert color_formatter.get_style_class('foo')
    assert color_formatter.get_lexer_for_body('foo', 'foo') == None



# Generated at 2022-06-11 23:40:40.231620
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    print('Test ColorFormatter_format_body')
    # create formatter
    formatter = ColorFormatter(
        env=Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )

    # verify with correct parameter
    assert formatter.format_body(body='Test 123', mime='plain/text') == 'Test 123'

# Generated at 2022-06-11 23:40:59.075913
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    cf = ColorFormatter(Environment(), color_scheme='monokai', output_file=None)
    assert cf.get_lexer_for_body('text/plain', 'some text') is None
    assert cf.get_lexer_for_body('application/json', 'some text') is None
    assert cf.get_lexer_for_body('application/json', '{}') is not None
    assert cf.get_lexer_for_body('application/json', '') is not None
    assert cf.get_lexer_for_body('application/json', '{}', explicit_json=True) is not None

    cf = ColorFormatter(Environment(), color_scheme='monokai', output_file=None, explicit_json=True)

# Generated at 2022-06-11 23:41:03.867564
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    formatter = ColorFormatter(Environment(colors=True))
    assert formatter.get_style_class('solarized') == Solarized256Style
    assert formatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')

# Generated at 2022-06-11 23:41:15.563958
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.plugins.formatter.colors import ColorFormatter

    env = Environment()
    args = parser.parse_args(args=[
        '--style=solarized',
        '--body=raw',
    ], env=env)
    color_formatter = ColorFormatter(env=env, args=args)

    assert get_lexer('text/plain') == TextLexer
    assert get_lexer('text/html') is not TextLexer

    assert color_formatter.get_lexer_for_body('text/plain', '') == TextLexer
    assert color_formatter.get_lexer_for_body('text/html', '') is not TextLexer


# Generated at 2022-06-11 23:41:24.047286
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('image/png')
    assert get_lexer('text/plain')
    assert get_lexer('text/html')
    assert get_lexer('text/html')
    assert get_lexer('application/vnd.github.v3+json')
    assert get_lexer('application/vnd.github.v3.raw+json') is None
    assert get_lexer('application/vnd.github.VERSION.raw+json') is None
    assert get_lexer('application/vnd+json') is None
    assert get_lexer('foo/bar') is None
    assert get_lexer('foo+bar') is None
    assert get_lexer('application/json', explicit_json=True)

# Generated at 2022-06-11 23:41:35.583080
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import logging
    import requests
    from requests.models import Response
    from httpie.compat import str
    from httpie.context import Environment
    from httpie.client import JSON_ACCEPT
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.default import DefaultPrettyPrinter
    from httpie.output.streams import UnsupportedStyles
    from httpie.output.streams import ColorizedStreamWriter
    from httpie.plugins import FormatterPlugin
    from httpie.input import URL
    from httpie.output.streams import get_response_stream
    from httpie.output.writers.streams import StreamWriter

    class Origin(FormatterPlugin):
        def format_body(self, body, mime, response):
            return str(body)


# Generated at 2022-06-11 23:41:42.861365
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers = '''\
GET /v1/accounts/ HTTP/1.1
Host: rest.sandbox.paypal.com
Content-Type: application/json
Connection: close
Accept-Encoding: gzip, deflate
User-Agent: httpie/0.9.2'''

# Generated at 2022-06-11 23:41:44.864738
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    c = ColorFormatter(Environment(), explicit_json=False, color_scheme='solarized')
    assert c.enabled == True

# Generated at 2022-06-11 23:41:56.246816
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    test_env = Environment(colors=256)
    test_cf = ColorFormatter(test_env)
    test_headers = '''HTTP/1.1 204 No Content
Server: GitHub.com
Date: Tue, 24 Jan 2017 20:31:15 GMT
Content-Type: text/html; charset=utf-8
Status: 204 No Content
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 58
X-RateLimit-Reset: 1485364335
X-OAuthScopes: repo, user
Cache-Control: no-cache
X-Frame-Options: deny
X-Content-Type-Options: nosniff
X-XSS-Protection: 1'''


# Generated at 2022-06-11 23:42:07.489199
# Unit test for method get_style_class of class ColorFormatter

# Generated at 2022-06-11 23:42:09.846808
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    c = ColorFormatter(
        env=Environment(),
        color_scheme=SOLARIZED_STYLE
    )
    assert c.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-11 23:42:24.585980
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.output.writers import OutputWriter
    env = Environment(colors=256)
    OutputWriter(env).write_line('foo')

# Generated at 2022-06-11 23:42:26.552754
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(env=Environment())
    assert formatter.group_name == 'colors'

# Generated at 2022-06-11 23:42:34.986972
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    expected = '\x1b[38;5;39mGET / HTTP/1.1\r\nHost: 127.0.0.1:5000\r\nContent-Type: application/json\r\nAccept: application/json, */*\r\nContent-Length: 13\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\n\x1b[39m\x1b[39m'

# Generated at 2022-06-11 23:42:45.691293
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class Params(object):
        style = DEFAULT_STYLE
        json = False
    env = Environment()
    formatter = ColorFormatter(env, **vars(Params()))
    mime = 'application/json'

# Generated at 2022-06-11 23:42:56.241920
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows

    if not is_windows:
        color_formatter = FormatterPluginManager(Environment()).instantiate(
            'color'
        )
        assert isinstance(color_formatter, ColorFormatter)
        assert color_formatter.get_lexer_for_body(
            mime='application/json',
            body='test'
        ), pygments.lexers.get_lexer_by_name('json')
        assert color_formatter.get_lexer_for_body(
            mime='application/x-www-form-urlencoded',
            body='test'
        ), pygments.lexers.get_lexer_by_name('url')
        assert color_

# Generated at 2022-06-11 23:43:08.921273
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    import httpie.context
    import httpie.plugins
    import httpie.colors
    import httpie.output.formatters.colors
    import httpie.plugins.colors
    import httpie.plugins.colors.solarized
    import pygments.formatter
    import pygments.lexers
    import pygments.styles
    import pygments.util

    import os
    import sys
    import unittest

    class TestColorFormatter(unittest.TestCase):
        def setUp(self):
            super(TestColorFormatter, self).setUp()
            self.formatter = httpie.colors.Auto0Formatter()
            self.formatter.env = httpie.context.Environment()

# Generated at 2022-06-11 23:43:19.454239
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.cli import parser

    args = parser.parse_args(['--style', 'solarized', 'GET', 'httpbin.org'])
    env = Environment(args, stdout=None, stdin=None, vars=None)

    style_class = ColorFormatter(
        env,
        explicit_json=False,
        color_scheme='solarized'
    ).get_style_class('solarized')
    assert style_class == Solarized256Style

    style_class = ColorFormatter(
        env,
        explicit_json=False,
        color_scheme='auto'
    ).get_style_class('auto')
    assert style_class == TerminalFormatter().style_class


# Generated at 2022-06-11 23:43:21.134602
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(Environment())
    assert color_formatter.group_name == 'colors'

# Generated at 2022-06-11 23:43:31.623433
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from pygments.lexers import PythonConsoleLexer
    from pygments.lexers import PythonTracebackLexer

    code = '''
    GET /ajax HTTP/1.1
    User-Agent: curl/7.54.0
    Host: httpie.org
    Accept: */*
    Cookie: foo=bar; bar=baz
    '''
    headers = code.strip().splitlines()
    headers_str = '\n'.join(headers)


# Generated at 2022-06-11 23:43:42.134816
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    globals = {}
    locals = {}

# Generated at 2022-06-11 23:44:02.523680
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/javascript') == pygments.lexers.get_lexer_by_name('js')
    assert get_lexer('text/plain') == pygments.lexers.get_lexer_by_name('text')
    assert get_lexer('application/unknown') == pygments.lexers.get_lexer_by_name('text')
    assert get_lexer('application/json', explicit_json=True, body='[1,2,3]') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('text/plain', explicit_json=True, body='[1,2,3]') == pygments.lexers

# Generated at 2022-06-11 23:44:13.650126
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.context import Environment
    class MockResponse:
        def __init__(self, headers, body):
            self.headers = headers
            self.text = body

    env = Environment(False, False, False, None, None, None, False)
    color_formatter = ColorFormatter(env)

# Generated at 2022-06-11 23:44:15.668205
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    assert formatter.formatter == Terminal256Formatter(style=Solarized256Style)


# Test that the color schemes are available

# Generated at 2022-06-11 23:44:19.049873
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert isinstance(ColorFormatter.get_style_class('monokai'), type(pygments.styles.get_style_by_name('monokai')))

    assert isinstance(ColorFormatter.get_style_class('nonexistent'), type(Solarized256Style))

# Generated at 2022-06-11 23:44:22.778504
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class DummyEnvironment:
        colors = True
        style = DEFAULT_STYLE

    color_formatter = ColorFormatter(env=DummyEnvironment(), explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert(color_formatter.enabled)

# Generated at 2022-06-11 23:44:31.620257
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.cli import parser

    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        stdout_isatty=True,
        stdin_isatty=True,
        colors=256,
        config_dir=None,
        config_file=None,
        session_file=None,
        auto_output_flushed=True,
        verify_ssl=True,
    )
    args = parser.parse_args([])

    formatter = ColorFormatter(
        env=env,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )


# Generated at 2022-06-11 23:44:39.035251
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    ansi_escaped_str = chr(27) + "[0m"
    str1 = "User-Agent: HTTPie/0.1.0"
    expected_str = chr(27) + "[32mUser-Agent:" + ansi_escaped_str + " " + chr(27) + "[0mHTTPie/0.1.0"
    result = ColorFormatter(Environment(colors=256)).format_headers(str1)
    assert result == expected_str



# Generated at 2022-06-11 23:44:40.797230
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('foobar') is None

# Generated at 2022-06-11 23:44:51.315784
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class TestEnv(object):
        def __init__(self):
            self.colors = 256

    env = TestEnv()
    formatter = ColorFormatter(env)


# Generated at 2022-06-11 23:44:52.289678
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
  from httpie.core import main
  import os
  os.system("http -" 
  )

# Generated at 2022-06-11 23:45:10.376022
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.main import test_main
    env = Environment(colors=True, colors_256=True, colors_16m=False)
    color_formatter = ColorFormatter(env, color_scheme="solarized")
    assert issubclass(color_formatter.get_style_class("solarized"), Solarized256Style)

# Generated at 2022-06-11 23:45:18.517422
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie import ExitStatus
    from httpie.context import Environment
    from httpie.output.streams import Streams
    from httpie.plugins import BuiltinPluginManager
    from httpie.output.writers import Writer

    class MockEnvironment(Environment):
        colors = 256

    environment = MockEnvironment()

    output_stream = Streams(stdout=Writer(stream=None))

    ColorFormatter(
        env=environment,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
        output_stream=output_stream,
        error_stream=output_stream,
        exit_status=ExitStatus(),
        config=None,
        additional_colors={}
    )

# Generated at 2022-06-11 23:45:21.047616
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized256') is Solarized256Style
    assert ColorFormatter.get_style_class('256') is None

# Generated at 2022-06-11 23:45:23.216713
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style

# Generated at 2022-06-11 23:45:30.422387
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    f = ColorFormatter(Environment(), color_scheme=DEFAULT_STYLE)
    headers = 'Content-Length: 159\nContent-Type: text/plain; charset=UTF-8'
    result = f.format_headers(headers)
    expected = '\x1b[1;37mContent-Length\x1b[0m: 159 ' + \
            '\x1b[1;35mContent-Type\x1b[0m: text/plain; charset=UTF-8'
    assert result == expected

# Generated at 2022-06-11 23:45:40.396927
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-11 23:45:51.615816
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class MockEnv:
        def __init__(self):
            self.colors = True
    env = MockEnv()
    formatter = ColorFormatter(env=env)
    headers = '''HTTP/1.1 200 OK
Server: nginx/1.6.2
Date: Fri, 06 Mar 2015 06:56:49 GMT
Content-Type: application/json
Content-Length: 2
Connection: close
ETag: "5610cef7-2"
Access-Control-Allow-Origin: *
Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept

'''
    print(formatter.format_headers(headers=headers))
    return


if __name__ == '__main__':
    test_ColorFormatter_format_headers()

# Generated at 2022-06-11 23:45:55.921959
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    import pygments
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import ColorFormatter

    class MockFormatter:

        def __init__(self):
            self.test_lexer = None
            self.test_highlight = None

        def highlight(self, code, lexer, formatter):
            self.test_lexer = lexer
            self.test_highlight = pygments.highlight(
                code=code,
                lexer=lexer,
                formatter=formatter,
            )
            return 'test_highlight'

    mock_formatter = MockFormatter()


# Generated at 2022-06-11 23:45:59.284014
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter(None, True, 'Solarized-dark')
    assert cf.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert cf.formatter.style.__class__.__name__ == "Solarized256Style"
    assert isinstance(cf.http_lexer, SimplifiedHTTPLexer)

# Generated at 2022-06-11 23:46:09.542786
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():

    # Test for html/text
    env = Environment(colors=256, is_windows=False)
    formatter = ColorFormatter(env)
    assert formatter.format_body("<html>\n<p>text</p>\n</html>", "text/html") == '<html>\n<p>text</p>\n</html>'
    assert formatter.format_body("hello world", "text/plain") == 'hello world'

    # Test for json
    assert formatter.format_body("{\"a\": 1}", "application/json") == "{\"a\": 1}"

    # Test for xml
    assert formatter.format_body("<hello>world</hello>", "application/xml") == "<hello>world</hello>"

# Generated at 2022-06-11 23:46:50.126613
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # response with a json mime type
    assert isinstance(
        ColorFormatter(Environment(stdin=None, stdout=None,
                                   vars=None, color=256,
                                   config_dir=None, cache_dir=None,
                                   config_path=None, config_prefix=None,
                                   config_base_name=None,
                                   output_file=None,
                                   is_windows=False,
                                   is_a_tty=False,
                                   stdout_isatty=False,
                                   stdin_isatty=False)).get_lexer_for_body(
                                       "application/json", "{}"),
        pygments.lexers.get_lexer_by_name('json')
    )
    # response with a text mime type

# Generated at 2022-06-11 23:46:57.128783
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import registry
    color_formatter = registry.get_default(
        'formatter',
        name='colors'
    )

    # $ http --print=hB --headers example.org
    headers_in = (
        "GET / HTTP/1.1\n"
        "Accept-Encoding: gzip, deflate\n"
        "Accept: */*\n"
        "User-Agent: HTTPie/0.9.2\n"
        "Host: example.org\n"
    )

# Generated at 2022-06-11 23:47:08.170723
# Unit test for method get_style_class of class ColorFormatter

# Generated at 2022-06-11 23:47:17.244769
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.plugins.colors import ColorFormatter
    from httpie.context import Environment

    env = Environment()
    env.colors = 128
    formatter = ColorFormatter(env)
    http_lexer = formatter.http_lexer
    formatter = formatter.formatter

    headers = '''\
HTTP/1.1 200 OK
'''

# Generated at 2022-06-11 23:47:27.281862
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from io import BytesIO
    from httpie.cli.environment import Environment
    from httpie.input import ParseError
    from httpie.plugins import FormatterPlugin
    from httpie.response import Response
    from pygments.util import ClassNotFound
    
    env=Environment()
    env.stdin=BytesIO()
    env.colors=True
    env.color_scheme='auto'

    class ColorFormatter(FormatterPlugin):
        """
        Colorize using Pygments

        This processor that applies syntax highlighting to the headers,
        and also to the body if its content type is recognized.

        """
        group_name = 'colors'


# Generated at 2022-06-11 23:47:32.743559
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.compat import is_windows
    from httpie.context import Environment
    env = Environment(colors=256)
    cf = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    expected = Solarized256Style
    if is_windows:
        expected = pygments.styles.get_style_by_name('fruity')
    assert cf.get_style_class(SOLARIZED_STYLE) == expected