

# Generated at 2022-06-11 23:37:52.731806
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    my_env = Environment()
    my_env.colors = 32

    my_lexer_1 = SimplifiedHTTPLexer()
    my_formatter_1 = TerminalFormatter()
    my_lexer_2 = PygmentsHttpLexer()
    my_formatter_2 = Terminal256Formatter(
        style=Solarized256Style
    )

    # testing whether the function get_lexer can get the correct lexer for the body
    # with terminal=True and 256 colors

# Generated at 2022-06-11 23:37:57.010289
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    # test if environment variables were successfully passed
    assert formatter.formatter.__class__.__name__ == 'TerminalFormatter'

# Generated at 2022-06-11 23:38:07.732249
# Unit test for function get_lexer

# Generated at 2022-06-11 23:38:11.946825
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    example_http_request = (
        "POST /api/v1/data HTTP/1.1\n"
        "Host: example.org\n\n"
    )

    formatter = Terminal256Formatter(style=Solarized256Style)
    pygments.highlight(
        code=example_http_request,
        lexer=lexer,
        formatter=formatter,
    ).strip()



# Generated at 2022-06-11 23:38:20.030803
# Unit test for function get_lexer
def test_get_lexer():
    # assert get_lexer('text/css') == pygments.lexers.get_lexer_by_name('css')
    assert get_lexer('text/html') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/javascript') == pygments.lexers.get_lexer_by_name('javascript')
    assert get_lexer('application/json+no_lexer_for_this_suffix') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-11 23:38:24.967099
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='application/json') is not None
    assert get_lexer(mime='application/json', explicit_json=True) is not None
    assert get_lexer(mime='application/json', explicit_json=True,
                     body='{}') is not None
    assert get_lexer(mime='text/html', body='{}') is None

# Generated at 2022-06-11 23:38:35.845186
# Unit test for function get_lexer
def test_get_lexer():
    # A few test cases for get_lexer().

    # JSON
    assert pygments.lexers.get_lexer_by_name('json') == get_lexer('application/json')
    assert pygments.lexers.get_lexer_by_name('json') == get_lexer('application/json; charset=utf-8')
    assert pygments.lexers.get_lexer_by_name('json') == get_lexer('application/json+foo')
    assert pygments.lexers.get_lexer_by_name('json') == get_lexer('application/x-json')
    assert pygments.lexers.get_lexer_by_name('json') == get_lexer('application/x-javascript')
    assert pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-11 23:38:45.163462
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    env.colors = True
    env.style = "solarized"
    body = """
    [{"id": 1, "title": "httpie 0.9.2 released"},
     {"id": 2, "title": "httpie 0.9.0 released"}]
    """


# Generated at 2022-06-11 23:38:50.764377
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import mock
    env = mock.Mock(colors=16,
                    is_windows=True,
                    unicode_output=False,
                    stdout_isatty=True)
    colorFormatter = ColorFormatter(env)
    assert colorFormatter.enabled == True
    assert str(colorFormatter.formatter) == '<TerminalFormatter>'
    env.stdout_isatty = False
    colorFormatter = ColorFormatter(env)
    assert colorFormatter.enabled == False

# Generated at 2022-06-11 23:39:03.018436
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # save terminal colors
    saved_terminal_colors = is_windows

    from httpie import ExitStatus

    from httpie.compat import str
    from httpie.downloads import (
        parse_content_range, filename_from_content_disposition
    )
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.status import ExitStatus
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.utils import get_response_text
    raw_body = open('/Users/mohammad/Desktop/httpie_tests/tests.txt','rb')
    from httpie.compat import is_windows

# Generated at 2022-06-11 23:39:13.122030
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    assert http_lexer.name == 'HTTP'
    assert http_lexer.aliases == ['http']
    assert http_lexer.filenames == ['*.http']

# Generated at 2022-06-11 23:39:14.453990
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-11 23:39:17.551076
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE

    ColorFormatter(env, explicit_json, color_scheme)

# Generated at 2022-06-11 23:39:19.254906
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter()
    print(color_formatter.format_body('{"test": "test"}', 'application/json'))

# Generated at 2022-06-11 23:39:30.820073
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment = Environment(colors=256)
    color_formatter = ColorFormatter(environment, explicit_json=False, color_scheme='solarized')
    assert color_formatter.get_lexer_for_body(mime='application/json', body='{"key": "value"}') \
        is pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body(mime='text/html', body='<h1></h1>') \
        is pygments.lexers.get_lexer_by_name('html')
    assert color_formatter.get_lexer_for_body(mime='text/plain', body='text') \
        is pygments.lexers.get_lexer_by_name('text')

# Generated at 2022-06-11 23:39:42.937919
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import ColorizedStream
    from httpie.core import main
    from httpie.plugins import FormatterPlugin, HelpPlugin
    from httpie.context import Environment
    from httpie.plugins import PluginManager

    old_env = Environment()
    old_env.colors = 256

    new_env = Environment()
    new_env.colors = 256
    new_env.stream = ColorizedStream(old_env.stdout)
    new_env.config_dir = old_env.config_dir
    new_env.config_path = old_env.config_path
    new_env.config = old_env.config

    pm = PluginManager(env=new_env, plugin_classes=[
                       HelpPlugin, FormatterPlugin])

# Generated at 2022-06-11 23:39:44.418469
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    pass
# end of test_SimplifiedHTTPLexer

# Generated at 2022-06-11 23:39:55.027291
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.core import main
    from httpie.compat import is_windows
    from httpie.utils import STDOUT
    from httpie.context import Environment
    from httpie.cli.constants import DEFAULT_UA
    from httpie.output.streams import DefaultEnvironmentStreams
    from httpie.output.streams import DefaultStreams


# Generated at 2022-06-11 23:40:07.517682
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']

# Generated at 2022-06-11 23:40:12.636132
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # mock Environment instance
    class Env:
        def __init__(self):
            self.colors = 256

    formatter = ColorFormatter(Env())
    assert formatter.enabled
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-11 23:40:24.063616
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import sys
    from StringIO import StringIO
    from httpie import ExitStatus
    from httpie.cli import parse_args
    from httpie.output.streams import (
        BINARY_SUPPRESSED_NOTICE,
        BINARY_RESPONSE_NOTICE
    )
    from httpie.plugins import plugin_manager

    # This would normally come from parsing the command line
    args = [
        '--headers',
        'get',
        'https://httpie.org/headers'
    ]

    def mock_args(args):
        stdin = StringIO('')
        stdout = StringIO()
        stderr = StringIO('solarized')
        environ = {
            'COLORS': '256',
            'HTTPIE_STYLE': 'solarized'
            }


# Generated at 2022-06-11 23:40:31.008476
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.main import parser
    from httpie.context import Environment
    from httpie.output.formatters.colors import ColorFormatter
    env = Environment(colors=256)
    args = parser.parse_args(['--print', 'bB'])
    formatter = ColorFormatter(env, args)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'

# Generated at 2022-06-11 23:40:43.021903
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    from httpie.plugins import PluginManager
    from pygments.formatters import Terminal256Formatter
    from pygments.styles import get_style_by_name
    from pygments.styles import Solarized256Style

    env = Environment(colors=256, stdin=None, stdout=None,
                      stdout_isatty=True, stdin_isatty=False,
                      output_options=None, output=None,
                      plugins=PluginManager(),
                      colors_force=False, verify_ssl=True,
                      style='solarized', format='colors')

    colorFormatter = ColorFormatter(env, explicit_json=False,
                                    color_scheme='solarized')

    assert colorFormatter.enabled is True

# Generated at 2022-06-11 23:40:54.221344
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from io import StringIO
    from pygments.lexers.html import HtmlLexer
    c = ColorFormatter(
        Environment(colors=256),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )

    with StringIO() as s:
        c.formatter.format(
            tokensource=HtmlLexer().get_tokens("<html><p>foo</p><p>bar</p></html>"),
            outfile=s
        )

# Generated at 2022-06-11 23:40:58.701268
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment(color=1, colors=256)
    colorFormatter = ColorFormatter(env, color_scheme='solarized')
    assert colorFormatter.get_style_class('solarized') is Solarized256Style



# Generated at 2022-06-11 23:41:08.500552
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    f = pygments.formatters.TerminalFormatter()
    def highlight(string):
        return pygments.highlight(string, lexer, f)
    def assert_output(input, output):
        assert highlight(input) == '\x1b[38;5;11m%s\x1b[0m' % output
    assert_output('GET / HTTP/1.1', 'GET / HTTP/1.1')
    assert_output('Host: example.com:8080', 'Host  :  example.com:8080')
    assert_output('User-Agent: httpie', 'User-Agent: httpie')
    assert_output('HTTP/1.1 200 OK', 'HTTP/1.1 200 OK')

# Generated at 2022-06-11 23:41:19.828893
# Unit test for function get_lexer
def test_get_lexer():
    # Verify that get_lexer returns the expected lexer class
    lexer = get_lexer(mime='text/plain', explicit_json=False, body='')
    assert lexer == pygments.lexers.get_lexer_by_name('text')
    lexer = get_lexer(mime='text/html', explicit_json=False, body='')
    assert lexer == pygments.lexers.get_lexer_by_name('html')
    lexer = get_lexer(mime='application/json', explicit_json=False, body='')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    # TextLexer is used when no other lexer feels responsible
    # for tokens of a particular mimetype or the mimetype is
    #

# Generated at 2022-06-11 23:41:27.182042
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    print("Testing ColorFormatter.get_lexer_for_body")

    env = None

    formatter = ColorFormatter(env=env)

    test_get_lexer_for_body = lambda mime, explicit_json, body, expected: \
        print("\ttest_get_lexer_for_body(\'" + \
              mime + "\', " + str(explicit_json) + ", \'" + body + "\', " + str(expected) + ")")

    # test_get_lexer_for_body(mime, explicit_json, body, expected)
    test_get_lexer_for_body("text/plain", True, "", None)

# Generated at 2022-06-11 23:41:38.426231
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    """
    Test get_style_class method of class ColorFormatter
    """
    color_scheme = "solarized"
    assert ColorFormatter.get_style_class(color_scheme) == Solarized256Style

    color_scheme = "monokai"
    assert ColorFormatter.get_style_class(color_scheme) == Solarized256Style

    color_scheme = "default"
    assert ColorFormatter.get_style_class(color_scheme) == Solarized256Style

    color_scheme = "solarized"
    assert ColorFormatter.get_style_class(color_scheme) == Solarized256Style

    color_scheme = "none"
    assert ColorFormatter.get_style_class(color_scheme) == Solarized256Style


# Generated at 2022-06-11 23:41:47.626196
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Given
    input_str = '''
    GET /foo/bar HTTP/1.1
    Host: example.com

    HTTP/1.1 200 OK
    Content-Length: 1
    Content-Type: application/json
    '''

    # When
    tokens = list(SimplifiedHTTPLexer().get_tokens(input_str))

    # Then

# Generated at 2022-06-11 23:42:07.400797
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.formatters.colors import ColorFormatter

    def get_lexer(
        mime, body,
        explicit_json=False,
        env=Environment(colors=256)
    ) -> Optional[Type[Lexer]]:
        cf = ColorFormatter(env, explicit_json=explicit_json)
        return cf.get_lexer_for_body(mime, body)

    if is_windows:
        return

    assert get_lexer('text/plain', 'foo') == pygments.lexers.TextLexer

    assert get_lexer('application/json', '[]') == \
        pygments.lexers.get_lexer_by_name('json')


# Generated at 2022-06-11 23:42:11.439816
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.output.formatters.colors import ColorFormatter
    color = FormatterPluginManager.get_plugin(section_name='colors', class_name='ColorFormatter')
    color.enabled = True
    color.format_headers('abc')

# Generated at 2022-06-11 23:42:16.244203
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin.formatter.colors import ColorFormatter
    assert ColorFormatter.get_lexer_for_body('json','') is None
    assert ColorFormatter.get_lexer_for_body(
        'application/json',
        '{"k1":"v1"}'
        ) is not None

# Generated at 2022-06-11 23:42:26.379624
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    """
    :return:
    """
    def get_tokens_unprocessed(text):
        lexer = SimplifiedHTTPLexer()
        return [token for token in lexer.get_tokens_unprocessed(text)]
    # Request-Line

# Generated at 2022-06-11 23:42:29.340754
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    cf = ColorFormatter(None, color_scheme=SOLARIZED_STYLE)
    style = cf.get_style_class(SOLARIZED_STYLE)
    assert style is Solarized256Style

# Generated at 2022-06-11 23:42:32.024497
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    data = b'{"foo": "bar"}'
    env = Environment()
    env.colors = True

    json_color = ColorFormatter(env).format_body(data, 'application/json')
    assert 'foo' in json_color
    assert 'bar' in json_color



# Generated at 2022-06-11 23:42:42.622303
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert ColorFormatter.format_body('', '') == ''
    assert ColorFormatter.format_body('text/plain', '') == ''
    assert ColorFormatter.format_body('text/html', '') == ''
    assert ColorFormatter.format_body('text/html', '<html></html>') == '<html></html>'
    assert ColorFormatter.format_body('application/json', '') == ''
    assert ColorFormatter.format_body('application/json', '{}') == '{}'
    assert ColorFormatter.format_body('application/json', '{"key":"value"}') == '{"key":"value"}'
    assert ColorFormatter.format_body('application/json', '{"key":"value","key2":"value2"}') == '{"key":"value","key2":"value2"}'


# Generated at 2022-06-11 23:42:49.265770
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    try:
        from pygments.unistring import unichr
    except ImportError:
        import unichr     # type: ignore

    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-11 23:42:57.855197
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import JSONCompactFormatter

    formatter = ColorFormatter(Environment(colors=256))
    body = r'{"hello": "world"}'
    mime = 'application/json'
    # JSON response
    assert formatter(body, mime, body=False) == body
    assert formatter(body, mime) == JSONCompactFormatter(Environment(colors=256))(body, mime)
    # Text response
    mime = 'text/plain'
    assert formatter(body, mime, body=False) == body
    assert formatter(body, mime) == body

# Generated at 2022-06-11 23:43:00.594616
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.config import Config
    env = Config(colors = 256).env
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__ == Terminal256Formatter

# Generated at 2022-06-11 23:43:34.528637
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    '''
    Verifying that the method format_body of class ColorFormatter
    in module httpie.plugins.colors
    '''
    #####################################################################
    # The first test verifies that method format_body of class
    # ColorFormatter formats the body with Pygments if the content
    # type is recognized by Pygments.
    #####################################################################
    # Create a ColorFormatter object.
    formatter_plugin = ColorFormatter(
        env=None,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    # Create the corresponding formatter.
    formatter = formatter_plugin.formatter
    # Retrieve the HTML lexer.
    html_lexer = pygments.lexers.get_lexer_by_name('html')
    # Create an HTML body

# Generated at 2022-06-11 23:43:46.258109
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from ansicolor import AnsiColor
    from httpie.context import Environment

    env = Environment(colors=256)
    explicit_json = True
    color_scheme = "fruity"

    formatter = ColorFormatter(
        env, explicit_json=explicit_json, color_scheme=color_scheme
    )

    #
    # Test with type application/json
    #
    mime = "application/json"
    body = '{"hello":"world","key":[1, true, false, null]}'
    lexer = formatter.get_lexer_for_body(mime, body)
    assert lexer

    body = '{"hello":"world","key":[1, true, false, null]}'
    ansicolor = AnsiColor()
    ansicolor.process(body)

    body

# Generated at 2022-06-11 23:43:50.580701
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(Environment())
    assert color_formatter.http_lexer.name == 'HTTP'
    assert isinstance(color_formatter.http_lexer, SimplifiedHTTPLexer)
    assert color_formatter.formatter.__class__.__name__ == 'TerminalFormatter'

# Generated at 2022-06-11 23:43:59.978316
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class MyMocked(object):
        """ A mocked object"""
        pass

    mocked_env = MyMocked()
    mocked_env.colors = 256
    color_formatter = ColorFormatter(env=mocked_env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    body = '{"key" : "value"}'
    mime = 'application/json'

    result = color_formatter.format_body(body, mime)

    # Expected colorized json

# Generated at 2022-06-11 23:44:10.135609
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(
        env=Environment(colors=256),
        color_scheme=DEFAULT_STYLE,
    ) is not None
    assert ColorFormatter(
        env=Environment(colors=True),
        color_scheme=DEFAULT_STYLE,
    ) is not None

# Generated at 2022-06-11 23:44:15.539978
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.cli import parser
    body = '<!DOCTYPE html>'
    mime = 'text/html'

    args = parser.parse_args(args=[])
    env = Environment()
    formatter = ColorFormatter(env=env, color_scheme=DEFAULT_STYLE, **args)

    assert formatter.format_body(body=body, mime=mime).strip() == body
    assert True

# Generated at 2022-06-11 23:44:24.102577
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    # Accepts content type parameters:
    assert get_lexer('application/json; charset=UTF-8')
    assert get_lexer('application/json+foo')
    assert get_lexer('application/foo+json')
    # Falls back to "json" lexer if JSON content type is not recognized:
    assert get_lexer('text/plain')
    # Falls back to "text" lexer
    # if neither the main type or subtype are recognized:
    assert get_lexer('application/x-foo')
    # Falls back to "text" lexer
    # if subtype is not recognized:
    assert get_lexer('application/json-foo')

# Generated at 2022-06-11 23:44:32.403016
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    style = Solarized256Style
    # create a new style object
    new_style = ColorFormatter(None, color_scheme=style)
    # create a color formatter that uses the style object
    color_formatter = new_style.get_style_class(style)
    # create a string containing the source code in microprocessor and pass it to format_body
    source_code = "start: mov ax,4C00h int 21h end start"
    mime_type = "text/x-asm"
    assert new_style.get_lexer_for_body(lexer=color_formatter.style, mime=mime_type) == pygments.lexers.get_lexer_for_mimetype(mime_type)

# Generated at 2022-06-11 23:44:35.604673
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print("\n---- test_ColorFormatter ----")
    env=Environment()
    mycolor=ColorFormatter(env)
    print("mycolor:",mycolor)

# Generated at 2022-06-11 23:44:46.661495
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie import ExitStatus
    from httpie.plugins import Plugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPBasicAuth
    env = Environment(colors=256, stdin=None, stdout=None, stderr=None)
    if not is_windows:        # will not work in Windows as solarized256Style is not supported
        colorFormatter = ColorFormatter(
            env, explicit_json=False, color_scheme=SOLARIZED_STYLE)
        colorFormatter1 = ColorFormatter(
            env, explicit_json=False, color_scheme=DEFAULT_STYLE)

# Generated at 2022-06-11 23:45:27.599804
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    assert ColorFormatter(env).http_lexer == SimplifiedHTTPLexer
    assert ColorFormatter(env, color_scheme='solarized').http_lexer == PygmentsHttpLexer

# Generated at 2022-06-11 23:45:36.737430
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    import pygments.lexers.data
    import pygments.lexers.markup
    import pygments.lexers.special
    import pygments.lexers.text
    import pygments.lexers.web

    c = ColorFormatter("","","",True)
    body = "Outdated vim version. Try vim-7.4 or higher version."
    mime = "text/plain; charset=utf-8"
    
    # base case, text/plain; charset=utf-8 body.expected: body
    expected = body
    assert expected == c.format_body(body, mime)

    # text/json; charset=utf-8 body.expected: body
    mime = "text/json; charset=utf-8"
    expected = body

# Generated at 2022-06-11 23:45:44.318049
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html')
    assert isinstance(get_lexer('text/html'), pygments.lexers.HtmlLexer)
    assert get_lexer('application/json')
    assert isinstance(get_lexer('application/json'), pygments.lexers.JsonLexer)
    assert get_lexer('text/plain') is None  # Fallback to TextLexer
    assert isinstance(get_lexer('text/plain'), pygments.lexers.TextLexer)

# Generated at 2022-06-11 23:45:55.514911
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter_plugin = ColorFormatter(Environment(), False, "default")

    # MIME type, body, expected

# Generated at 2022-06-11 23:45:57.387505
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    output = ColorFormatter(
        Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE
    )

# Generated at 2022-06-11 23:46:07.393632
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    headers = """HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
ETag: "3f80f-1b6-3e1cb03b"
Content-Type: text/html; charset=UTF-8
Content-Length: 131
Accept-Ranges: bytes
Connection: close

<html>
<head>
  <title>An Example Page</title>
</head>
<body>
  Hello World, this is a very simple HTML document.
</body>
</html>
"""
    formatter = ColorFormatter({'colors': True})
    expected = """"""

# Generated at 2022-06-11 23:46:09.750199
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class Env:
        pass
    env = Env()
    env.colors = True
    ColorFormatter(env)

# Generated at 2022-06-11 23:46:15.285027
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import os
    import tempfile
    import json
    with tempfile.NamedTemporaryFile(mode="w+",delete=False) as f:
        json.dump(json.load(open(os.path.join(os.path.dirname(__file__),'test.json'))))
        f.flush()
        cf = ColorFormatter(None,False)
        assert cf.format_body(f.read(),'application/json')
        os.remove(f.name)

# Generated at 2022-06-11 23:46:23.400848
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.core import main
    from httpie.plugins import FormatterPlugin
    from httpie.input import SEP_CREDENTIALS
    from httpie.input import SEP_GROUP
    from httpie.input import SEP_HEADERS
    from httpie.input import SEP_QUERY
    from httpie.input import SEP_DATA
    from httpie.input import SEP_DATA_RAW_JSON
    from httpie.input import AuthCredentials


# Generated at 2022-06-11 23:46:30.169321
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    x = ColorFormatter(
        env=Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
        **kwargs
    )
    assert x.enabled is True
    assert x.group_name == 'colors'

    y = ColorFormatter(
        env=Environment(colors=False),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
        **kwargs
    )
    assert y.enabled is False
    assert y.group_name == 'colors'

# Generated at 2022-06-11 23:47:29.402634
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    if is_windows:
        color_scheme = 'fruity'
    else:
        color_scheme = automatic
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=color_scheme)
    assert color_formatter.__class__ == ColorFormatter
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True
    assert type(color_formatter.formatter) == TerminalFormatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert color_formatter.group_name == 'colors'


# Generated at 2022-06-11 23:47:31.654601
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(colors=True), explicit_json=False, color_scheme="auto").explicit_json is False


# Generated at 2022-06-11 23:47:34.008606
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env=Environment()
    color_scheme = DEFAULT_STYLE
    color_formatter=ColorFormatter(env, explicit_json=False, color_scheme=color_scheme)
    return color_formatter