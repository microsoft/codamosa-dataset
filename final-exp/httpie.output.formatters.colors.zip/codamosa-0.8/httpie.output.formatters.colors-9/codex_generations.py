

# Generated at 2022-06-11 23:37:52.399501
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # create dummy mime and body
    mime = "application/json"
    body = '{"test":"test"}'

    # instantiate a color formatter object
    formatter = ColorFormatter(None)

    # get the body using the format_body function
    body = formatter.format_body(body, mime)

    # check if the body contains the color codes (31 is the escape code for CYAN)
    assert "\x1b[31m" in body

# Generated at 2022-06-11 23:37:58.201932
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Arrange
    env = Environment()
    c = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    if not env.colors:
        return
    headers = '\nContent-Encoding: gzip\nVia: 1.1 www1 (kong/1.37.0)\nX-Test: 1.37.1\n'
    expected = pygments.highlight(
        code=headers,
        lexer=c.http_lexer,
        formatter=c.formatter,
    ).strip()
    # Act
    actual = c.format_headers(headers)
    # Assert
    assert actual == expected


test_ColorFormatter_format_headers()



# Generated at 2022-06-11 23:38:08.635334
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    obj = SimplifiedHTTPLexer()
    assert obj.name == 'HTTP'
    assert obj.aliases == ['http']
    assert obj.filenames == ['*.http']
    assert obj.tokens['root'][0] == (
            r'([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)',
            (
                pygments.token.Name.Function,
                pygments.token.Text,
                pygments.token.Name.Namespace,
                pygments.token.Text,
                pygments.token.Keyword.Reserved,
                pygments.token.Operator,
                pygments.token.Number
            ))

# Generated at 2022-06-11 23:38:19.450172
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Arrange
    from textwrap import dedent

    headers = dedent("""\
        Date: Sat, 16 Sep 2017 14:15:49 GMT
        Content-Type: text/plain; charset=UTF-8
        Content-Length: 24
        Connection: close
        Server: SimpleHTTP/0.6 Python/2.7.12
    """)

    formatter = ColorFormatter(None)

    # Act
    headers_formatted = formatter.format_headers(headers)

    # Assert

# Generated at 2022-06-11 23:38:23.027676
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('monokai').__name__ == \
        'MonokaiStyle'
    assert ColorFormatter.get_style_class('Solarized256').__name__ == \
        'Solarized256Style'

# Generated at 2022-06-11 23:38:27.780486
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(AUTO_STYLE).__name__ == 'TerminalFormatter'
    assert ColorFormatter.get_style_class(DEFAULT_STYLE).__name__ == 'TerminalFormatter'
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE).__name__ == 'Solarized256Style'
    assert ColorFormatter.get_style_class('teststyle').__name__ == 'ClassNotFound'

# Generated at 2022-06-11 23:38:34.226928
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(AUTO_STYLE) == pygments.styles.get_style_by_name(AUTO_STYLE)
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style



# Generated at 2022-06-11 23:38:44.161337
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import sys, os
    os.environ['HTTPIE_CONFIG_DIR'] = './httpie'
    os.environ['HTTPIE_ENV'] = 'test'
    from httpie.core import main
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.context import Environment
    from httpie.config import DEFAULTS
    from httpie.plugins import FormatterPlugin
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPHeadersProcessor


# Generated at 2022-06-11 23:38:52.883823
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    http_headers = """
    GET / HTTP/1.1
    Host: example.com
    User-Agent: cURL
    Accept: */*
    Accept-Encoding: gzip,deflate
    Accept-Language: en-US,en;q=0.5
    Accept-Charset: utf-8,ISO-8859-1;q=0.7

    {}
    """
    formatter = Terminal256Formatter(
        style=ColorFormatter.get_style_class(SOLARIZED_STYLE)
    )
    tokens = list(lexer.get_tokens(http_headers))
    print(formatter.format(tokens))

# Generated at 2022-06-11 23:39:00.323392
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment()
    mime_type = 'application/javascript'
    body = '{"test":1}'
    color_formatter = ColorFormatter(env, explicit_json=True, color_scheme='monokai')
    lexer = color_formatter.get_lexer_for_body(mime_type, body)
    assert lexer == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-11 23:39:17.597096
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import traceback
    # FIXME: we should add a real http.client.HTTPResponse to this test
    class FakeResponse:
        def __init__(self):
            self.msg = None
            self.status = 200
            self.version = 11
            self.reason = 'OK'
            self.headers = []
            self.raw_headers = []
            self.chunked = 0
            self.strict = 0
            self.length = 0
            self.will_close = 0
            self.body = '{"key": "value"}'
            self.debuglevel = 0
            self.url = 'http://127.0.0.1:8080/'
        def read(self, amt=-1):
            return self.body
        def getheader(self, name, default=None):
            return

# Generated at 2022-06-11 23:39:28.913874
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class DummyEnvironment:
        def __init__(self, colors: int):
            self.colors = colors
    color_formatter = ColorFormatter(
        env=DummyEnvironment(256),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    assert (
        color_formatter
        .get_lexer_for_body(
            mime='application/json',
            body='{ "foo" : "bar" }',
        )
        == pygments.lexers.get_lexer_by_name('json')
    ), 'JSON response should return json lexer'

# Generated at 2022-06-11 23:39:40.834917
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import os
    import unittest
    from httpie.context import Environment

    class TestColorFormatter(unittest.TestCase):
        def setUp(self):
            # init a context where we could get a ColorFormatter
            env = Environment(
                colors=256,
                stdin=None,
                stdout=None,
                isatty=True,
                stdout_isatty=True
            )
            self.ColorFormatter = ColorFormatter(env)

        def test_format_body(self):
            testcase = (
                ("text", {"text/plain"}, "This is a test string"),
                ("json", {"application/json"}, '{"example":"json"}')
            )
            for t, mimes, body in testcase:
                for mime in mimes:
                    r = self.Color

# Generated at 2022-06-11 23:39:51.807398
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment()
    formatter = ColorFormatter(env=env)

    lexer = formatter.get_lexer_for_body(mime='application/json',
                                          body=json.dumps({'foo': 'bar'}))
    assert(isinstance(lexer, type(pygments.lexers.JsonLexer())))

    lexer = formatter.get_lexer_for_body(mime='application/yaml',
                                          body='{foo: bar}')
    assert(isinstance(lexer, type(pygments.lexers.JsonLexer())))

    lexer = formatter.get_lexer_for_body(mime='application/vnd.api+json',
                                          body=json.dumps({'foo': 'bar'}))

# Generated at 2022-06-11 23:39:56.845449
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    request = 'GET / HTTP/1.1'
    tokens = list(lexer.get_tokens(request))
    assert tokens[0] == (
        pygments.token.Name.Function,  # 'GET'
        'GET'
    )

# Generated at 2022-06-11 23:40:00.829456
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('application/json')
    assert lexer is pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer('application/json', explicit_json=True)
    assert lexer is pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer('application/json', explicit_json=True, body='{}')
    assert lexer is pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer('text/plain', explicit_json=True, body='{}')
    assert lexer is None

    lexer = get_lexer('application/javascript')
    assert lexer is pygments.lexers.get_lexer_by_name('js')

    lex

# Generated at 2022-06-11 23:40:11.928843
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from . import format_http_response, format_http_request
    from .formatters import ColoredFormatter

    # Note that the following code is executed by nosetests with
    # the "-s" option, so any print statement will be printed to stdout.
    # We bear that in mind when we write assertions such as
    # "assert printed == ''".
    # We also call sys.stdout.flush() to ensure that all prints are
    # flushed before any assertion.

    import sys

    print('Testing ColorFormatter.format_headers')
    env = Environment(colors=256)
    formatter = ColoredFormatter(env)
    assert formatter.color_scheme == 'auto', formatter.color_scheme
    assert env.colors == 256, env.colors

    # HEADERS

# Generated at 2022-06-11 23:40:15.641383
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    output = ColorFormatter(None).format_headers("SOME")
    assert output == "\x1b[1;34mSOME\x1b[0m"



# Generated at 2022-06-11 23:40:23.867510
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()

    formatter = ColorFormatter(env=env, 
                               explicit_json=False, 
                               color_scheme=DEFAULT_STYLE, 
                               **{})
    # Test header with 2 values separated by comma
    headers = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0,Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"

# Generated at 2022-06-11 23:40:36.406575
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def check(body: str, mime: str, exp_lexer_cls: Type[Lexer]):
        assert get_lexer(body, mime) == exp_lexer_cls

    check('{}', 'application/json', pygments.lexers.JsonLexer)
    check('{}', 'application/json+foo', pygments.lexers.JsonLexer)
    check('{}', 'application/foo+json', pygments.lexers.JsonLexer)
    check('{}', 'application/foo+json+bar', pygments.lexers.JsonLexer)
    check('{}', 'application/json-foo', pygments.lexers.JsonLexer)
    check('{}', 'application/foo-json', pygments.lexers.JsonLexer)


# Generated at 2022-06-11 23:40:53.287854
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import unittest
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    from httpie.colors import ColorFormatter
    from httpie.context import Environment
    from httpie.plugins.builtin import JSONBody
    from httpie.output import JSONOutput

    class FakePrettifiedJSONBody(JSONBody):
        """
        A fake implementation of the JSONBody plugin just to trick the
        Output class into thinking we have a prettified json body.
        """

        def transform_body(self, body):
            return body

    class FakeOutput(JSONOutput):
        """
        A fake implementation of the JSONOutput class just to trick the
        ColorFormatter class into thinking we are on a prettified json
        output.
        """


# Generated at 2022-06-11 23:40:58.086205
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    css = ColorFormatter.get_style_class('solarized')
    assert css == Solarized256Style

    css = ColorFormatter.get_style_class('fruity')
    assert css == pygments.styles.get_style_by_name('fruity')

# Generated at 2022-06-11 23:40:59.230547
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-11 23:41:00.943074
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style

# Generated at 2022-06-11 23:41:09.626634
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    response = '''HTTP/1.0 200 OK
Content-Type: text/html

<html>
  <head><title>Hello!</title></head>
  <body><h1>Hello, World!</h1></body>
</html>
'''
    response1 = '''HTTP/1.0 200 OK
Content-Type: text/html; charset=utf-8

<html>
  <head><title>Hello!</title></head>
  <body><h1>Hello, World!</h1></body>
</html>
'''
    response2 = '''HTTP/1.0 200 OK

{"hello":123}
'''

    env = Environment(colors=256)
    color_formatter = ColorFormatter(env)

# Generated at 2022-06-11 23:41:12.401365
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.formatters.colors import ColorFormatter
    ColorFormatter(None).format_headers('HTTP/1.1 200 OK')

# Generated at 2022-06-11 23:41:14.799851
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(
        auto_envvar_prefix='HTTPIE_',
        # --colors option:
        colors=True,
        # --style option:
        style=DEFAULT_STYLE,
        # HTTPIE_STYLE env:
        style_env=None,
    )
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled is True

# Generated at 2022-06-11 23:41:23.553013
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Request-Line
    toks = list(SimplifiedHTTPLexer().get_tokens(
        'GET http://example.org/ HTTP/1.1\n'
        'Content-Type: application/json\n'
    ))

    assert len(toks) == 12  # 6 pairs of tokens
    assert toks[0] == (pygments.token.Name.Function, 'GET')
    assert toks[2] == (pygments.token.Name.Namespace, 'http://example.org/')
    assert toks[4] == (pygments.token.Keyword.Reserved, 'HTTP')
    assert toks[6] == (pygments.token.Number, '1.1')

    assert toks[8] == (pygments.token.Name.Attribute, 'Content-Type')
   

# Generated at 2022-06-11 23:41:31.651122
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer('text/plain', body='') is None
    lexer = get_lexer('text/plain', explicit_json=True, body='')
    assert isinstance(lexer, pygments.lexers.JsonLexer)
    lexer = get_lexer('text/plain', explicit_json=True, body='{"a": "b"}')
    assert isinstance(lexer, pygments.lexers.JsonLexer)
    assert get_lexer('text/html') is pygments.lexers.HtmlLexer

# Generated at 2022-06-11 23:41:39.045549
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import str

    class ColorFormatterTest(ColorFormatter):
        def __init__(self):
            import httpie.compat
            from httpie.context import Environment
            super(ColorFormatterTest, self).__init__(
                env=Environment(colors=256)
            )

        @staticmethod
        def get_style_class(color_scheme: str) -> Type[pygments.style.Style]:
            return pygments.styles.get_style_by_name(color_scheme)

    test = ColorFormatterTest()
    format_headers = test.format_headers

    # The correct colored output string

# Generated at 2022-06-11 23:41:59.816764
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.client import JSON_ACCEPT
    from httpie.context import Environment
    from httpie.plugins import plugin_manager

# Generated at 2022-06-11 23:42:11.041396
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins.builtin import BasicAuthPlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONPlugin
    from httpie.plugins.builtin import NetrcAuthPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import OAuth1Plugin
    from httpie.plugins.builtin import OAuth2Plugin
    from httpie.plugins.builtin import GZipPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AskConfirmPlugin
    from httpie.plugins.builtin import AutomaticOptionsPlugin
    from httpie.plugins.builtin import LinuxDistroDetectorPlugin
    from httpie.plugins.builtin import WindowsTerminalDetectorPlugin


# Generated at 2022-06-11 23:42:18.123602
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    test_http_lexer = SimplifiedHTTPLexer()
    test_formatter = Terminal256Formatter(
        style=Solarized256Style().__class__
    )
    test_env = Environment()
    test_env.colors = 256
    formatter = ColorFormatter(
        env=test_env,
        explicit_json=True,
        color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter == test_formatter
    assert formatter.http_lexer == test_http_lexer
    assert formatter.explicit_json == True

# Generated at 2022-06-11 23:42:20.868891
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    c = ColorFormatter(None)
    print(c.formatter)
    print(c.http_lexer)

if __name__ == '__main__':
    test_ColorFormatter()

# Generated at 2022-06-11 23:42:30.062293
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class TestEnv:
        def __init__(self, colors = True):
            self.colors = colors

    env = TestEnv(True)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme="solarized")
    mime = "text/html"
    assert color_formatter.get_lexer_for_body(mime, "") == None
    mime = "application/json"
    assert color_formatter.get_lexer_for_body(mime, "") == pygments.lexers.get_lexer_by_name('json')
    mime = "application/json"
    assert color_formatter.get_lexer_for_body(mime, "This is not a JSON") == None

# Generated at 2022-06-11 23:42:37.324892
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer(
        mime='Event-Stream',
        explicit_json=False,
        body=''
    ) == pygments.lexers.get_lexer_by_name('JavaScript')

    assert get_lexer(
        mime='text/html',
        explicit_json=False,
        body=''
    ) == pygments.lexers.get_lexer_by_name('html')

    assert get_lexer(
        mime='application/json',
        explicit_json=False,
        body=''
    ) == pygments.lexers.get_lexer_by_name('json')

    assert get_lexer(
        mime='text/json',
        explicit_json=False,
        body=''
    ) == pygments.lexers.get_lexer_by

# Generated at 2022-06-11 23:42:39.583808
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    ColorFormatter('', explicit_json=True, color_scheme='solarized')

# Generated at 2022-06-11 23:42:47.433779
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class TestEnvironment():
        def __init__(self, colors=256):
            self.colors = colors
            self.styles = AVAILABLE_STYLES

    mime = 'application/json'
    body = '{"username": "foo", "password": "bar"}'
    json_format = ColorFormatter(TestEnvironment(), True).format_body(body, mime)
    not_json_format = ColorFormatter(TestEnvironment(), False).format_body(body, mime)

    assert False
    # TODO: Compare the result of json_format and not_json_format to sample
    #       files. Do not forget to use encoding='utf-8' when writing the
    #       sample files.

# Generated at 2022-06-11 23:42:57.981798
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment(colors=256)
    for color_scheme in DEFAULT_STYLE, SOLARIZED_STYLE:
        style_class = ColorFormatter(env, color_scheme=color_scheme).get_style_class(
            color_scheme
        )
        assert style_class is not None
        assert style_class is not ColorFormatter.get_style_class(color_scheme)

    for color_scheme in AVAILABLE_STYLES:
        style_class = ColorFormatter(env, color_scheme).get_style_class(color_scheme)
        assert style_class is not None
        assert style_class is not ColorFormatter.get_style_class(color_scheme)

    assert ColorFormatter(env, None).get_style_class(None)

# Generated at 2022-06-11 23:43:05.322427
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexers import get_lexer_by_name, get_lexer_for_mimetype
    from pygments.formatters import Terminal256Formatter
    import sys

    def _p(s, lexer):
        print(s, end='')
        [print(' %s%s%s' % (
            Terminal256Formatter().style['token'][ttype],
            s,
            Terminal256Formatter().style['token'][Token.Text]
        )) for ttype, s in lexer.get_tokens(s)]


# Generated at 2022-06-11 23:43:33.718779
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.formatters.colors import ColorFormatter
    from httpie.context import Environment
    import os
    import re

    os.environ['COLORTERM'] = 'truecolor'
    os.environ['COLORTERM'] = '256color'
    env = Environment(colors=256)

    color_formatter = ColorFormatter(env=env)

# Generated at 2022-06-11 23:43:45.464765
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.colors import ColorFormatter
    from httpie.compat import is_windows
    if is_windows:
        color_formatter = ColorFormatter(None, is_tty=True, color_scheme='fruity')
    else:
        color_formatter = ColorFormatter(None, is_tty=True, color_scheme='solarized')

    assert color_formatter.get_lexer_for_body('text/html', '<html>')
    assert color_formatter.get_lexer_for_body('application/json', '{"hello":"world"}') is None
    assert color_formatter.get_lexer_for_body('application/json+hal', '{"hello":"world"}') is None

# Generated at 2022-06-11 23:43:55.221916
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    http_request = "GET /resource HTTP/1.1\r\nHost: example.com\r\n\r\n"

    tokens = list(lexer.get_tokens(http_request))
    assert len(tokens) == 7

    # GET /resource HTTP/1.1
    assert tokens[0][0] == pygments.token.Name.Function
    assert tokens[0][1] == 'GET'
    assert tokens[1][0] == pygments.token.Text
    assert tokens[1][1] == ' '
    assert tokens[2][0] == pygments.token.Name.Namespace
    assert tokens[2][1] == '/resource'
    assert tokens[3][0] == pygments.token.Text

# Generated at 2022-06-11 23:44:02.361432
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # arrange
    env = Environment(
        colors=False,
        style=DEFAULT_STYLE,
    )
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)

    mime = 'text/html'
    body = '<!DOCTYPE html><html><head><title>I am a title</title></head></html>'

    # act
    actual = formatter.format_body(body, mime)

    # assert
    expected = '<!DOCTYPE html><html><head><title>I am a title</title></head></html>'
    assert actual == expected



# Generated at 2022-06-11 23:44:06.639022
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    toks = list(lexer.get_tokens("GET / HTTP/1.1"))
    assert toks
    assert 'GET' not in str(toks[0][0])

# Generated at 2022-06-11 23:44:15.984565
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    request = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org'''
    response = '''HTTP/1.1 200 OK
Access-Control-Allow-Credentials: true
Access-Control-Allow-Origin: *
Connection: keep-alive
Content-Length: 498
Content-Type: application/json
Date: Sun, 01 Oct 2017 23:01:04 GMT
Server: gunicorn/19.8.1
Via: 1.1 vegur'''
    lexer = SimplifiedHTTPLexer()
    assert pygments.lex(request, lexer=lexer) == pygments.lex(request, lexer=PygmentsHttpLexer())
    assert pygments.lex(response, lexer=lexer)

# Generated at 2022-06-11 23:44:25.356282
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(None, color_scheme='test') == ColorFormatter(None, color_scheme='test')
    assert not (ColorFormatter(None, color_scheme='test') != ColorFormatter(None, color_scheme='test'))
    assert ColorFormatter(None, color_scheme='test') is not None
    assert ColorFormatter(None, color_scheme='test') is not object()  # noqa
    assert ColorFormatter(None, color_scheme='test') is not 'test'
    assert not (ColorFormatter(None, color_scheme='test') == object())
    assert not (ColorFormatter(None, color_scheme='test') == 'test')
    assert (ColorFormatter(None, color_scheme='test') != object())

# Generated at 2022-06-11 23:44:27.477121
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) \
        == Solarized256Style

# Generated at 2022-06-11 23:44:38.153807
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme=None, explicit_json=False)
    assert color_formatter.formatter == Terminal256Formatter()
    color_formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE, explicit_json=False)
    assert color_formatter.formatter == Terminal256Formatter(style=Solarized256Style)
    color_formatter = ColorFormatter(env, color_scheme=DEFAULT_STYLE, explicit_json=False)
    assert color_formatter.formatter == Terminal256Formatter(style=Solarized256Style)
    env.colors = None

# Generated at 2022-06-11 23:44:48.747194
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-11 23:45:29.364890
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class('sunburst')
    assert isinstance(pygments.styles.get_style_by_name('sunburst'), style_class)
    assert style_class is not ColorFormatter.get_style_class('solarized')

# Generated at 2022-06-11 23:45:39.568994
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.core import main as httpie

    env = httpie.Environment()
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('image/svg+xml', '<svg></svg>')
    assert formatter.get_lexer_for_body('image/svg', '<svg></svg>')
    assert formatter.get_lexer_for_body('xxx/svg+xml', '<svg></svg>')
    assert formatter.get_lexer_for_body('xxx/svg', '<svg></svg>')
    assert not formatter.get_lexer_for_body('image/svg', '<svg')


# Generated at 2022-06-11 23:45:50.209474
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Test environment
    env = Environment()

    # Build instance of ColorFormatter
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    color_formatter = ColorFormatter(env, explicit_json=explicit_json, color_scheme=color_scheme)
    headers = """GET / HTTP/1.1
Host: google.com
Content-Type: text/html; charset=utf-8
User-Agent: HTTPie/2.0.0
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive"""

    # Test method format_headers of class ColorFormatter
    out = color_formatter.format_headers(headers)
    assert out is not None

# Generated at 2022-06-11 23:45:59.080146
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # type: () -> None

    class Env(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    from httpie.plugins import builtin
    from httpie.plugins import formatter
    builtin.load_all()
    formatter.load_all()

    import json
    import base64
    env = Env(colors=256)


    # Case 1: Format request headers
    # Arrange
    input_headers = '''\
GET / HTTP/1.1
Host: localhost:5000
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/1.0.2

'''

# Generated at 2022-06-11 23:46:01.224591
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter()
    assert cf.formatter.style

# Generated at 2022-06-11 23:46:10.924904
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-11 23:46:13.349229
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    c = ColorFormatter(env, color_scheme="solarized",explicit_json=False)


# Generated at 2022-06-11 23:46:22.046142
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    env = Environment(colors=256, is_windows=is_windows)
    def get_lexer_for_body(mime: str, body: str) -> Optional[Type[Lexer]]:
        cf = ColorFormatter(env=env)
        lexer = cf.get_lexer_for_body(mime=mime, body=body)
        return lexer

    nb_body = '{"a":1}'
    assert get_lexer_for_body('text/plain', nb_body) is None
    assert get_lexer_for_body('application/json', nb_body) is not None

# Generated at 2022-06-11 23:46:31.618462
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import ExitStatus
    from httpie.plugins.builtin import HTTPPlugin
    from httpie.output.streams import get_output_stream
    from httpie.output.streams import write_in_chunks

    def test_output_stream(**kwargs):
        """Write a string to a file"""
        stream = get_output_stream(**kwargs)
        write_in_chunks(b'GET / HTTP/1.1\r\nHost: example.org\r\n\r\n', stream)

    class MockEnvironment:
        colors = None
        stdin = None
        stdout = test_output_stream
        stderr = test_output_stream
        isatty = True
        output_options = None
        output_stream = None


# Generated at 2022-06-11 23:46:40.447039
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.colors import ColorFormatter
    cf = ColorFormatter(Environment())
    print(cf.get_lexer_for_body('text/html', '<html></html>'))  # returns HtmlLexer
    print(cf.get_lexer_for_body('text/css', 'body {margin: 0;}'))  # returns CssLexer
    print(cf.get_lexer_for_body('application/xml', '<?xml version="1.0"?><root></root>'))  # returns XmlLexer
    print(cf.get_lexer_for_body('application/json', '{"a": 1, "b": 2}'))  # returns JsonLexer