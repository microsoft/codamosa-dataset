

# Generated at 2022-06-11 23:37:57.576284
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import sys
    import io

    class MockEnv:
        def __init__(self, colors=False):
            self.colors = colors

    # Pygments imports
    from pygments.lexer import RegexLexer
    from pygments.lexers.compiled import CythonLexer
    from pygments.token import Token
    from pygments.styles import get_style_by_name, Style
    from pygments.formatters import TerminalFormatter
    from pygments.formatters.terminal import TerminalFormatter
    from pygments.util import ClassNotFound


# Generated at 2022-06-11 23:38:03.582683
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='application/json') is not None
    assert get_lexer(mime='application/json', explicit_json=True) is not None
    assert get_lexer(mime='application/json', body='{}') is not None
    assert get_lexer(mime='text/plain', body='{}') is None

# Generated at 2022-06-11 23:38:11.296497
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import io
    from .style import get_style
    from .style import get_all_styles
    from .style import DEFAULT_STYLE, AVAILABLE_STYLES
    from .style import build_style_map

    style_map = build_style_map(DEFAULT_STYLE)
    style_json_response = style_map.get('json')
    style_json_response_raw = style_map.get('json-raw')
    style_http_headers = style_map.get('http-headers')
    style_http_headers_raw = style_map.get('http-headers-raw')

    all_styles = get_all_styles()
    if len(all_styles) == 0:
        return

    for style in all_styles:
        # Test headers with explicit json value
        test_

# Generated at 2022-06-11 23:38:12.407120
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color = ColorFormatter(None)
    color.format_headers('HTTP/1.1 200 OK\n')

# Generated at 2022-06-11 23:38:21.612193
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class TestEnv(object):
        def __init__(self, colors=16):
            self.colors = colors

    env = TestEnv(8)
    formatter = ColorFormatter(env=env, color_scheme=None)
    assert formatter.enabled == False
    assert formatter.explicit_json == False
    assert formatter.formatter._style is None
    assert formatter.http_lexer is SimplifiedHTTPLexer

    env.colors = 16
    formatter = ColorFormatter(env=env, color_scheme='solarized')
    assert formatter.enabled == True
    assert formatter.explicit_json == False
    assert formatter.formatter._style is TerminalFormatter
    assert formatter.http_lexer is PygmentsHttpLexer

    env.colors = 256

# Generated at 2022-06-11 23:38:24.878663
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-11 23:38:31.519885
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # - Create a dummy class of type ColorFormatter
    dummy_formatter = ColorFormatter()
    # - Create a test string to play with
    test_body = 'test'
    # - Create a dummy mime type to run the method
    test_mime = 'text/plain'
    # - Run the method
    test_res = dummy_formatter.format_body(body=test_body, mime=test_mime)

    # - Verify that the method is working
    assert test_res == 'test'

# Generated at 2022-06-11 23:38:39.912117
# Unit test for function get_lexer
def test_get_lexer():
    assert (get_lexer('application/json') ==
            pygments.lexers.get_lexer_by_name('json'))
    assert get_lexer('application/javascript') is not None
    assert get_lexer('text/html') is not None
    assert get_lexer('text/javascript') is not None
    assert get_lexer('text/x-python') is not None
    assert get_lexer('image/png') is None
    assert get_lexer('image/png', body='{"a": 1}') is not None



# Generated at 2022-06-11 23:38:44.258585
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from_solarized = ColorFormatter.get_style_class('solarized')
    from_solarized256 = ColorFormatter.get_style_class('solarized256')

    assert from_solarized is from_solarized256

# Generated at 2022-06-11 23:38:53.482699
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from textwrap import dedent
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.colors import ColorFormatter
    import httpie.cli.parser
    from httpie.compat import is_windows

    auth = HTTPBasicAuth()
    auth._getpass = lambda x: 'test'
    http = httpie.cli.parser.HTTPie()
    config = httpie.cli.parser.Config(default_options=[]).parse([])
    env = httpie.Environment(stdin_isatty=lambda: True,
                             stdout_isatty=lambda: True,
                             colors=256 if is_windows else 88,
                             config=config)

# Generated at 2022-06-11 23:39:00.379178
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter is not None

# Generated at 2022-06-11 23:39:08.562434
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.streams import get_console_stream

    console_stream = get_console_stream(isatty=True, colors=256)
    stream = console_stream(False, False)
    env = Environment(
        colors=256,
        is_windows=False,
        stdin=None,
        stdout=stream,
        stderr=stream,
    )
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)

    # Parameters to the test
    mime = ''
    explicit_json = False
    body = ''
    # Expectations of the test
    expected_lexer = None

    actual_lexer = formatter.get_lexer_for_body(mime, explicit_json, body)
    assert actual_lexer == expected_

# Generated at 2022-06-11 23:39:20.005885
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    data = b"""GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.2

"""
    import io
    from httpie.plugins import FormatterPlugin
    from httpie.core import main
    from httpie import ExitStatus
    from pygments.lexers.data import JsonLexer

    class CustomColorFormatter(ColorFormatter):
        def get_lexer_for_body(
                self, mime: str,
                body: str
        ) -> Optional[Type[Lexer]]:
            if mime == 'application/json':
                return JsonLexer()
            else:
                return None


# Generated at 2022-06-11 23:39:31.909072
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.output.streams import STDOUT_ENCODING

    body = b"""
    <h1>Hello World</h1>
    <table>
    <tr><td>Cell</td></tr>
    </table>
    """
    mime = 'text/html'
    style = 'monokai'
    # other choices for style: 'monokai', 'manni', 'igor', 'xcode', 'vim'
    enc = STDOUT_ENCODING
    actual = ColorFormatter(Environment(colors=True), style=style, color_scheme=style,
                            stdout_isatty=True).format_body(body.decode(enc), mime)

# Generated at 2022-06-11 23:39:35.381159
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.core import main
    env = main.get_environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled == True

# Generated at 2022-06-11 23:39:42.373267
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class FakeEnv:
        def __init__(self, colors=True):
            self.colors = colors

    # mock the body
    mime = 'application/json'
    body = '''
        {
            "name": "lala",
            "age": 20
        }
    '''
    # format_body
    body2 = ColorFormatter(FakeEnv()).format_body(body, mime)

    # check
    assert body == body2

# Generated at 2022-06-11 23:39:53.454183
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    req = 'GET /api/repos/kennethreitz/requests/issues?page=2&state=closed HTTP/1.1'
    res = 'HTTP/1.1 200 OK'
    header = 'Link: <http://localhost:9999/api/repos/kennethreitz/requests/issues?page=1&state=closed>; rel="prev", <http://localhost:9999/api/repos/kennethreitz/requests/issues?page=3&state=closed>; rel="next"'

    expected_req = ('GET', '/api/repos/kennethreitz/requests/issues?page=2&state=closed', 'HTTP/1.1')
    expected_res = ('HTTP/1.1', '200', 'OK')

# Generated at 2022-06-11 23:40:06.199224
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    ce_env = Environment(colors=1)
    ce_env.style = None
    cf_formatter = ColorFormatter(env=ce_env)

    def assert_format_body(assert_mime, assert_body, expect, explicit_json=False):
        actual = cf_formatter.format_body(body=assert_body, mime=assert_mime)
        assert actual == expect

    assert_format_body(
        assert_mime='application/json',
        assert_body='{"a":1, "b":2}\n',
        expect='{\n    "a": 1,\n    "b": 2\n}\n'
    )


# Generated at 2022-06-11 23:40:15.082170
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import os

    try:
        os.environ["XDG_CONFIG_HOME"] = "/home/guille/dev/httpie"
    except KeyError:
        print("Variable XDG_CONFIG_HOME not set")

    from httpie.config import Environment
    from httpie.plugins.colors import ColorFormatter

    # Environment definition
    env = Environment(
        colors=256,
        stdin=None,
        stdin_isatty=True,
        stdout=None,
        stdout_isatty=True,
        colored_headers=True,
    )

    # Test definition
    color_formatter = ColorFormatter(env=env)

# Generated at 2022-06-11 23:40:19.217045
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor

    headers = dict(HTTPHeadersProcessor().transform_headers(None, dict(h1='v1', h2='v2')))
    assert ColorFormatter(Environment()).format_headers(headers)

# Generated at 2022-06-11 23:40:34.412279
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_output = ColorFormatter(None, None)
    assert color_output.enabled

# Generated at 2022-06-11 23:40:47.118147
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from .formatter import JSONFormatter
    from .formatter import RawFormatter
    from .formatter import StreamFormatter
    from .formatter import get_formatter
    from httpie.config import Config, merge_config
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import plugin_manager, FormatterPlugin
    from httpie.server import Server
    from httpie.status import ExitStatus
    import pytest
    #import pdb
    #pdb.set_trace()
    class TestEnvironment:

        colors = 256

    formatter_plugin_manager = plugin_manager.get_formatter_plugin_manager()
    formatters = {
        'json': JSONFormatter,
        'raw': RawFormatter,
        'stream': StreamFormatter
    }


# Generated at 2022-06-11 23:40:50.800027
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == "HTTP"
    assert lexer.aliases == ["http"]
    assert lexer.filenames == ["*.http"]
    assert lexer.tokens



# Generated at 2022-06-11 23:41:03.303137
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert type(formatter.get_lexer_for_body('text/plain', 'my plain text')) == pygments.lexers.TextLexer

    assert type(formatter.get_lexer_for_body('application/json', '"application/json"')) == pygments.lexers.JsonLexer
    assert type(formatter.get_lexer_for_body('application/javascript', '"application/javascript"')) == pygments.lexers.JavascriptLexer
    assert type(formatter.get_lexer_for_body('application/xml', '"application/xml"')) == pygments.lexers.XmlLexer

# Generated at 2022-06-11 23:41:10.611472
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    assert get_lexer('application/json') == pygments.lexers.JsonLexer
    assert get_lexer('application/json', explicit_json=True) == pygments.lexers.JsonLexer
    assert get_lexer('application/json', body='{"test":true}') == pygments.lexers.JsonLexer
    assert get_lexer('application/vnd.api+json') == pygments.lexers.JsonLexer
    assert get_lexer('application/vnd.api+json', explicit_json=True) == pygments.lexers.JsonLexer
    assert get_lexer('application/vnd.api+json', body='{"test":true}') == pygments.lexers.JsonLexer


# Generated at 2022-06-11 23:41:20.895167
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import io
    import pytest

    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    from .testing import humanize_body

    env = Environment(colors=256)
    config = Config(env=env)
    plugin_manager = PluginManager(env=env, config=config)
    plugin_manager.add_plugin(HTTPBasicAuth())

    # Disable self.formatter
    plugin = ColorFormatter(env=env, config=config)
    plugin.enabled = False
    plugin.env = env
    plugin.config = config

    input_result = """HTTP/1.1 200 OK\r
\r
"""
    result

# Generated at 2022-06-11 23:41:23.033408
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Test that simplified http works
    formatter = ColorFormatter(None)
    assert formatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-11 23:41:34.301696
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter = ColorFormatter(None, 'fruity')

# Generated at 2022-06-11 23:41:41.065443
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == ColorFormatter.get_style_class(DEFAULT_STYLE)
    assert ColorFormatter.get_style_class('123') == ColorFormatter.get_style_class(DEFAULT_STYLE)
    assert ColorFormatter.get_style_class('default') == ColorFormatter.get_style_class(DEFAULT_STYLE)

# Generated at 2022-06-11 23:41:48.775481
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.formatter.colors import ColorFormatter
    import os

    test_inputs = (
        ('application/json', '{"key": "value"}'),
        ('application/x-yaml', '{key: value}'),
    )
    json_lexer = pygments.lexers.get_lexer_by_name('json')
    yaml_lexer = pygments.lexers.get_lexer_by_name('yaml')

# Generated at 2022-06-11 23:42:23.442074
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class DummyEnv(object):
        def __init__(self, colors):
            self.colors = colors

    cf = ColorFormatter(DummyEnv(256))
    assert isinstance(cf.formatter, Terminal256Formatter)
    assert isinstance(cf.http_lexer, SimplifiedHTTPLexer)

    cf = ColorFormatter(DummyEnv(16))
    assert isinstance(cf.formatter, TerminalFormatter)
    assert isinstance(cf.http_lexer, PygmentsHttpLexer)

# Generated at 2022-06-11 23:42:33.004560
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    request_line = u'GET /foo HTTP/1.1'
    assert list(SimplifiedHTTPLexer().get_tokens_unprocessed(request_line)) == [
        (pygments.token.Name.Function, u'GET'),
        (pygments.token.Text, u' '),
        (pygments.token.Name.Namespace, u'/foo'),
        (pygments.token.Text, u' '),
        (pygments.token.Keyword.Reserved, u'HTTP'),
        (pygments.token.Operator, u'/'),
        (pygments.token.Number, u'1.1'),
    ]
    status_line = u'HTTP/1.1 200 OK'

# Generated at 2022-06-11 23:42:43.763690
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment(colors=True)
    color_formatter = ColorFormatter(env=env)

    _test_ColorFormatter_format_body(
        color_formatter,
        body="<html><body>hello world!</body></html>",
        mime="text/html",
        expected="""<html><body>hello <span style="color: #00afaf">\
world</span>!</body>
</html>""")


# Generated at 2022-06-11 23:42:47.188891
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(Environment())
    
    #Testing the constructor
    assert color_formatter.formatter
    assert color_formatter.http_lexer

# Generated at 2022-06-11 23:42:57.756661
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # type: () -> None
    import pytest
    from httpie.context import Environment

    env = Environment()
    env.colors = 256
    cf = ColorFormatter(env)
    h = "Accept-Language: en-us,en;q=0.5\n"
    h += "Accept-Encoding: gzip, deflate\n"
    h += "Referer: http://httpbin.org/\n"
    h += "Cookie: uppity_session_name=0123456789ABCDEF\n"
    h += "Pragma: no-cache\n"
    h += "Cache-Control: no-cache,no-store,must-revalidate,max-age=0\n"

    oh = cf.format_headers(h)


# Generated at 2022-06-11 23:43:00.141500
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_scheme = 'monokai'
    ColorFormatter(env, explicit_json=False, color_scheme=color_scheme)

# Generated at 2022-06-11 23:43:02.783446
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplifiedHTTPLexer = SimplifiedHTTPLexer()
    assert simplifiedHTTPLexer is not None


# Generated at 2022-06-11 23:43:15.079692
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class dummy_env_class:
        colors = True

    dummy_env = dummy_env_class()

    dummy_mime = "application/json"
    dummy_body = "{\"name\":\"value\"}"
    dummy_formatter = ColorFormatter(
        env = dummy_env,
        explicit_json = False,
        color_scheme = 'solarized'
    )
    test_result = dummy_formatter.format_body(dummy_body, dummy_mime)
    expected_result = "{\"name\":\"value\"}"
    assert(test_result == expected_result)

    dummy_mime = "application/xml"
    dummy_body = "<test>test</test>"

# Generated at 2022-06-11 23:43:25.041033
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import os, sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from httpie.compat import is_windows

    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment

    class ColorFormatter(FormatterPlugin):
        """
        Colorize using Pygments

        This processor that applies syntax highlighting to the headers,
        and also to the body if its content type is recognized.

        """
        group_name = 'colors'

        def __init__(
            self,
            env: Environment,
            explicit_json=False,
            color_scheme=DEFAULT_STYLE,
            **kwargs
        ):
            super().__init__(**kwargs)


# Generated at 2022-06-11 23:43:34.343506
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import filecmp
    import os
    import tempfile

    env = Environment()

    input_filename = os.path.join(os.path.dirname(__file__),'test',  'test_ColorFormatter_format_body.txt')
    output_filename = tempfile.mkstemp()[1]
    color_formatter = ColorFormatter(env,"solarized")

    # The color formatter is not supposed to change the body of a message
    with open(input_filename, 'r') as input_file:
        with open(output_filename, 'w') as output_file:
            output_file.write(color_formatter.format_body(input_file.read(),"text/html"))
    assert filecmp.cmp(input_filename, output_filename)

    # The color formatter is not supposed to change

# Generated at 2022-06-11 23:44:15.168518
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    raw_raw = """GET / HTTP/1.1
Host: www.example.com
User-Agent: httpie/0.0
Accept: */*"""
    colored_raw = pygments.highlight(
        code=raw_raw,
        lexer=lexer,
        formatter=pygments.formatters.TerminalFormatter()
    ).strip()

# Generated at 2022-06-11 23:44:19.597785
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class Response(object):
        "fake Response object"
        headers = {}

    class MockEnvironment:
        "fake Environment object"
        colors = True

    formatter = ColorFormatter(MockEnvironment())
    assert formatter.group_name == 'colors'
    assert formatter.format_headers(Response()) == ''
    assert formatter.format_body(Response()) == ''

# Generated at 2022-06-11 23:44:25.889585
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import pytest
    from httpie.context import Environment
    from httpie.formatter.colors import ColorFormatter

    env = Environment(styles=[], colors=256)
    colorFormatter = ColorFormatter(env, False, "solarized256")

    assert colorFormatter.explicit_json == False
    assert colorFormatter.formatter.__class__.__name__ == "Terminal256Formatter"
    assert colorFormatter.http_lexer.name == "HTTP"



# Generated at 2022-06-11 23:44:33.178824
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    """
    unit test for ColorFormatter
    :return: None
    """
    env = Environment()
    explicit_json = False
    color_scheme = 'solarized'
    test_formatter = ColorFormatter(env, explicit_json, color_scheme)

    set_explicit_json = False
    set_color_scheme = 'solarized'
    if test_formatter.explicit_json == set_explicit_json \
            and test_formatter.formatter._style.__class__.__name__ == set_color_scheme\
            and test_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer':
        print(True)
    else:
        print(False)

# Generated at 2022-06-11 23:44:44.723408
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main_cli
    class TestColorFormatter(ColorFormatter):
        def format_headers(self, headers: str) -> str:
            return self.format_headers_old(headers)
    args, env = main_cli.build_args_env(["http","--verbose","--headers","--pretty","all"])
    ColorFormatter.format_headers_old = ColorFormatter.format_headers
    ColorFormatter.format_headers = TestColorFormatter.format_headers
    color_formatter = ColorFormatter(env)

# Generated at 2022-06-11 23:44:49.001912
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']
    assert 'root' in lexer.tokens
    assert len(lexer.tokens['root']) == 3


# Generated at 2022-06-11 23:44:56.708749
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    try:
        from pygments.lexers import JSONLexer
    except ImportError:
        from pygments.lexers import JsonLexer as JSONLexer

    from httpie.plugins.builtin import FormatterPlugin
    from httpie.output.streams import DummyOutputStream

    f = ColorFormatter(
        env=None,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
        stream=DummyOutputStream(),
        color=True,
    )

    # HTML
    assert f.get_lexer_for_body(mime='text/html', body='<html></html>') is not None

    # JSON
    assert f.get_lexer_for_body(mime='application/json', body='{"key": "value"}') == JSONLexer

    # Unknown

# Generated at 2022-06-11 23:44:58.002506
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert True

# Generated at 2022-06-11 23:45:00.584954
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    import pygments.styles
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-11 23:45:07.634360
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('solarized') == pygments.styles.get_style_by_name('solarized')
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-11 23:46:23.441428
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    f = ColorFormatter(
        env=Environment(
            stdin=None,
            stdout=None,
            stdout_isatty=True,
            stderr=None,
            stderr_isatty=False,
            colors=True,
            color_scheme=DEFAULT_STYLE,
            verify=True,
            timeout=None,
            auth=('', ''),
            debug=False,
            config_dir=None,
            config_file=None,
            headers=None,
            output_options=None,
            compression=False,
            kwargs={}
        ),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )


# Generated at 2022-06-11 23:46:25.965528
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    import pygments.styles
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')


# Generated at 2022-06-11 23:46:29.393754
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors=True
    c=ColorFormatter(env)
    assert c.enabled==True
    env.colors=False
    c=ColorFormatter(env)
    assert c.enabled==False

# Generated at 2022-06-11 23:46:38.580269
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = """\
GET / HTTP/1.1
Host: httpbin.org
User-Agent: HTTPie/0.9.6
Accept-Encoding: gzip, deflate, compress
Accept: */*
Connection: keep-alive
Content-Type: application/json
Content-Type: application/json; charset=utf-8
Content-Length: 79

"""
    headers = formatter.format_headers(headers)

# Generated at 2022-06-11 23:46:41.204262
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) is Solarized256Style


if __name__ == '__main__':  # pragma: no cover
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 23:46:52.088209
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    style = Solarized256Style
    lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(style=style)
    cf1 = ColorFormatter(Environment(colors=256),'false')
    cf2 = ColorFormatter(Environment(colors=256),'true',color_scheme='solarized')

# Generated at 2022-06-11 23:46:58.212438
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.utils import get_binary_stream

    color_formatter = ColorFormatter(color_scheme='solarized')
    request = "GET / HTTP/1.1\r\nAccept:*/*\r\nContent-Type:text/html\r\n\r\n"
    response = b'''<html>
    <head>
        <title>
            test
        </title>
    </head>
    <body>
        <div>
            <h1>title</h1>
            <p>
                <b>bold text</b>
            </p>
            <p>
                <a href="https://www.baidu.com/">link</a>
            </p>
        </div>
    </body>
</html>'''
    lexer = get

# Generated at 2022-06-11 23:47:09.415259
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import HTTPBasicAuth
    env = Environment()
    env.colors = True
    env.auth = [HTTPBasicAuth('user', 'pass')]
    formatter = ColorFormatter(env, color_scheme='fruity')

    print(formatter.format_body(
        """{
            "id": 1,
            "main": true,
            "name": "Sample",
            "ports": [
                {
                    "id": 1,
                    "name": "HTTP",
                    "number": 80
                },
                {
                    "id": 2,
                    "name": "HTTPS",
                    "number": 443
                }
            ]
        }""",
        mime='application/json'
    ))


if __name__ == "__main__":
    test_Color

# Generated at 2022-06-11 23:47:17.657057
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexer import Lexer
    from pygments.util import ClassNotFound

    assert issubclass(SimplifiedHTTPLexer, Lexer)

    try:
        lexer = pygments.lexers.get_lexer_by_name('http')
        assert lexer is None
    except ClassNotFound:
        pass

    lexer = pygments.lexers.get_lexer_by_name('Simplified-HTTP')
    assert issubclass(type(lexer), SimplifiedHTTPLexer)

    lexer = pygments.lexers.get_lexer_for_mimetype('text/x-http')
    assert issubclass(type(lexer), SimplifiedHTTPLexer)

# Generated at 2022-06-11 23:47:18.882792
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style