

# Generated at 2022-06-11 23:38:04.422506
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    # Test initializing with default settings
    formatter_plugin = ColorFormatter(env)
    assert formatter_plugin.formatter.__class__ == TerminalFormatter
    assert formatter_plugin.http_lexer.__class__ == PygmentsHttpLexer
    # Test initializing with 256 color option
    formatter_plugin = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter_plugin.enabled == True
    assert formatter_plugin.formatter.__class__ == Terminal256Formatter
    assert formatter_plugin.http_lexer.__class__ == SimplifiedHTTPLexer

# Generated at 2022-06-11 23:38:12.313685
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie import ExitStatus
    from utils import http, HTTP_OK

    env = Environment(colors=256)
    r = http('GET', HTTP_OK, color_scheme=SOLARIZED_STYLE, env=env)
    c = ColorFormatter(env)
    assert r == c.format_headers(http.headers)


# Generated at 2022-06-11 23:38:21.585864
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.input import ParseError
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import WriteStream
    import io
    import sys
    import unittest
    import unittest.mock
    from httpie.compat import is_windows

    class MockEnvironment(object):
        def __init__(self):
            self.colors = 256

    class MockWriteStream(WriteStream):
        def __init__(self, out_file):
            self.out_file = out_file
            self.isatty = self.out_file.isatty()

        def is_output_redirected(self):
            return not self.isatty

        def write_line(self, line, **kwargs):
            self.out_file.write(line)

# Generated at 2022-06-11 23:38:29.090588
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment())
    assert(formatter.get_lexer_for_body('application/json', '') == pygments.lexers.get_lexer_by_name('json'))
    assert(formatter.get_lexer_for_body('json', '') == pygments.lexers.get_lexer_by_name('json'))
    assert(formatter.get_lexer_for_body('application/json; charset=utf-8', '') == pygments.lexers.get_lexer_by_name('json'))
    assert(formatter.get_lexer_for_body('application/json+hal', '') == pygments.lexers.get_lexer_by_name('json'))

# Generated at 2022-06-11 23:38:38.838282
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    test_str = 'HTTP/1.1 200 OK'.split(' ')
    for token, content in lexer.get_tokens_unprocessed(test_str):
        assert token == pygments.token.Keyword.Reserved
    assert content == test_str[0]
    test_str = 'transfer-encoding : chunked'.split(' ')
    for token, content in lexer.get_tokens_unprocessed(test_str):
        if token == pygments.token.Operator:
            assert content == ':'
        else:
            assert token == pygments.token.Name.Attribute, token

# Generated at 2022-06-11 23:38:42.366261
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexers import get_lexer_by_name
    from pygments.lexers.special import TextLexer

    SimplifiedHTTPLexer = get_lexer_by_name('http')
    assert SimplifiedHTTPLexer != TextLexer

# Generated at 2022-06-11 23:38:44.412223
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized').__name__ == 'Solarized256Style'

# Generated at 2022-06-11 23:38:53.511426
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    env = Environment(colors=256)
    cf = ColorFormatter(env)
    ln1 = 'HTTP/1.1 200 OK'
    ln2 = 'Date: Mon, 23 May 2005 22:38:34 GMT'
    ln3 = 'Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)'
    ln4 = 'Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT'
    ln5 = 'Etag: "3f80f-1b6-3e1cb03b" Content-Type: text/html; charset=UTF-8'
    ln6 = 'Content-Encoding: gzip'
    ln7 = 'Content-Length: 648'

# Generated at 2022-06-11 23:39:05.230614
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Test for style "fruity"
    color_scheme = "fruity"
    style_class_returned = ColorFormatter.get_style_class(color_scheme)
    style_class_expected = pygments.styles.get_style_by_name(color_scheme)
    assert style_class_returned == style_class_expected

    # Test for style "solarized"
    color_scheme = "solarized"
    style_class_returned = ColorFormatter.get_style_class(color_scheme)
    style_class_expected = Solarized256Style
    assert style_class_returned == style_class_expected

    # Test for "auto" color_scheme
    color_scheme = "auto"
    style_class_returned = ColorFormatter.get_style

# Generated at 2022-06-11 23:39:17.327737
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-11 23:39:23.250081
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-11 23:39:32.867068
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.plugins

    # Loading plugin class is required when testing the method
    httpie.plugins.load_plugins()
    formatter = ColorFormatter(Environment())
    lexer = get_lexer("application/json")
    mime_type_lexer = formatter.get_lexer_for_body("application/json", "")
    assert isinstance(mime_type_lexer, type(lexer)) == True
    assert isinstance(formatter.get_lexer_for_body("application/x-yml", ""), type(None)) == True

# Generated at 2022-06-11 23:39:43.757048
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():

    from pygments.token import Name, Text, Keyword, Name, Name, String, Number, Operator, Comment

    assert list(SimplifiedHTTPLexer().get_tokens("GET / HTTP1.1\n")) \
        == [(Name.Function, 'GET'), (Text, ' '), (Name.Namespace, '/'), (Text, ' '), (Keyword.Reserved, 'HTTP'), (Operator, '1'), (Operator, '.'), (Number, '1'), (Text, '\n')]


# Generated at 2022-06-11 23:39:54.688182
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    style = Solarized256Style
    formatter = Terminal256Formatter(style=style)
    http_lexer = PygmentsHttpLexer()


# Generated at 2022-06-11 23:39:59.169504
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer.name == 'HTTP'
    assert SimplifiedHTTPLexer.aliases == ['http']
    assert SimplifiedHTTPLexer.filenames == ['*.http']


# Generated at 2022-06-11 23:40:04.081922
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.color = True
    c = ColorFormatter(env)
    assert isinstance(c, FormatterPlugin)
    assert c.format_headers("a:b")

# Generated at 2022-06-11 23:40:13.750290
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from pygments.token import Token
    from pygments.lexers.text import HttpLexer

    # Create the lexer for the purpose of unit test.
    l = SimplifiedHTTPLexer()
    l.init()
    # Create a standard Pygments lexer.
    l_std = HttpLexer()
    l_std.init()

    # Request-Line
    input = 'GET /test HTTP/1.1'
    tokens = list(l.get_tokens(input))
    assert tokens != []

    # Response Status-Line
    input = 'HTTP/1.1 200 OK'
    tokens = list(l.get_tokens(input))
    assert tokens != []

    # Header

# Generated at 2022-06-11 23:40:22.949591
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main
    from httpie.core import CONTENT_TYPE_HEADER
    from httpie.core import HTTP_HEADER
    from httpie.compat import is_windows
    env = main.Environment()
    if not is_windows:
        assert env.colors == 256
    formatter = ColorFormatter(env=env)
    request_line = '%s %s %s' % (HTTP_HEADER, '/', HTTP_HEADER)
    status_line = '%s/1.1 200 %s' % (HTTP_HEADER, CONTENT_TYPE_HEADER)
    headers = '%s: %s' % (CONTENT_TYPE_HEADER, CONTENT_TYPE_HEADER)
    text_content_type = 'text/plain;charset=utf-8'

# Generated at 2022-06-11 23:40:27.253705
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme='solarized')
    assert formatter.get_style_class('solarized') is Solarized256Style

# Generated at 2022-06-11 23:40:38.626683
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    """
    Test that ColorFormatter.format_headers returns 'xxx' when
    headers = 'yyy'
    """
    env = Environment()


# Generated at 2022-06-11 23:41:04.997543
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    global ColorFormatter
    colorFormatter = ColorFormatter(Environment(colors=1))
    result = colorFormatter.get_lexer_for_body('application/json', '{}')
    assert result == pygments.lexers.get_lexer_by_name('json')
    assert colorFormatter.get_lexer_for_body('text/plain', '') == pygments.lexers.get_lexer_by_name('text')

# Generated at 2022-06-11 23:41:16.673265
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import re
    import unittest

    from .http_lexer_tester import HttpLexerTester

    class TestSimplifiedHTTPLexer(HttpLexerTester):
        """Verifies that the request/response tokens are split as expected.

        This is just a quick sanity test to ensure this lexer does what it is
        intended to do. The tokenization is almost identical to that of the
        original HTTP lexer bundled with Pygments. The only difference is that
        the colon (':') separating each header name and value is considered an
        operator when the latter is a tokenized, whereas the original HTTP
        lexer considers it to be a text token.
        """
        lexer = SimplifiedHTTPLexer()


# Generated at 2022-06-11 23:41:25.093834
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie import ExitStatus
    from httpie.client import Environment
    from httpie.downloads import FileDownloader
    from httpie.plugins import FormatterPlugin
    from httpie.compat import is_windows
    from httpie.core import main as httpie
    from pygments import lexers as utils_lexers
    from httpie.plugins.builtin import JSONFormatter

    #
    # Setup
    #
    env = Environment()
    env.stdout = FileDownloader(env, is_tty=True)
    env.stderr = FileDownloader(env, is_tty=True)
    env.stdin = FileDownloader(env, is_tty=True)

    default_formatter_name = 'colors' if is_windows else 'colors256'
    default_format = env.default_options

# Generated at 2022-06-11 23:41:26.569417
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    colorFormatter = ColorFormatter(Environment())



# Generated at 2022-06-11 23:41:37.817039
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    tokens = lexer.get_tokens_unprocessed('GET / HTTP/1.1\nHost: localhost')
    assert 'HTTP' == next(tokens)[1]
    assert ' ' == next(tokens)[1]
    assert '/' == next(tokens)[1]
    assert ' ' == next(tokens)[1]
    assert 'HTTP' == next(tokens)[1]
    assert '/' == next(tokens)[1]
    assert '1.1' == next(tokens)[1]
    assert 'Host' == next(tokens)[1]
    assert ' ' == next(tokens)[1]
    assert ':' == next(tokens)[1]

# Generated at 2022-06-11 23:41:39.918455
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert ColorFormatter(Environment()).format_body('{"data": "value"}', 'application/json') == \
        '{\n    "data": "value"\n}\n'

# Generated at 2022-06-11 23:41:42.881350
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == "HTTP"
    assert lexer.aliases == ["http"]
    assert lexer.filenames == ["*.http"]

# Generated at 2022-06-11 23:41:53.968480
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import PluginManager
    env = Environment()
    env.colors = 256
    pm = PluginManager(env=env)
    color_formatter = ColorFormatter(env=env, color_scheme=SOLARIZED_STYLE)
    assert color_formatter.format_body(r'3.14', 'text/html') == r'3.14'
    assert color_formatter.format_body(r'3.14', 'application/json') == \
        '\x1b[38;5;45m\x1b[1m"3.14"\x1b[0m'
    assert color_formatter.format_body(r'<html></html>', 'text/html') == \
        '<html></html>'


# Generated at 2022-06-11 23:42:01.396998
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_py26
    from httpie.cli import parser

    env = Environment()
    env.colors = 256
    f = ColorFormatter(env)

    args = parser.parse_args(args=[], env=env)
    args.style = 'solarized'

    if is_py26:
        headers = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, compress
Host: httpbin.org
User-Agent: HTTPie/0.8.0

'''

# Generated at 2022-06-11 23:42:11.613098
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    from fixtures import COLOR, CRLF, JSON_PROFILE
    from httpie.compat import urlopen

    env = Environment(colors=256)
    env.config['style'] = 'solarized256'
    json_content_type = 'application/json'
    rq = http('--print=BhH', 'GET', httpbin.url + '/headers',
              env=env, error_exit_ok=True)
    assert HTTP_OK in rq
    assert rq.exit_status == ExitStatus.OK
    assert CRLF not in rq
    assert COLOR in rq



# Generated at 2022-06-11 23:42:31.081221
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    pass


# Generated at 2022-06-11 23:42:37.787157
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from . import http as pygments_http_lexer
    from . import http_parser

    # Testing SimplifiedHTTPLexer with a full HTTP request
    http_lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-11 23:42:47.319697
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    cf = ColorFormatter(env=None)
    assert cf.format_body(body="this is a test", mime="text/plain") == "this is a test"
    assert cf.format_body(body="this is a test\n", mime="text/plain") == "this is a test\n"
    assert cf.format_body(body="this is a test\nthis is a test", mime="text/plain") == "this is a test\nthis is a test"
    assert cf.format_body(body="this is a test\nthis is a test\n", mime="text/plain") == "this is a test\nthis is a test\n"

# Generated at 2022-06-11 23:42:57.087036
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # 1. test the base case
    DUMMY_ENV = Environment()
    DUMMY_ENV.colors = True
    formatter = ColorFormatter(DUMMY_ENV)
    if formatter.enabled:
        assert formatter.format_headers("") == ""
        # 2. test the format of the returned string
        headers = "Content-Type: text/html; charset=UTF-8\n\n"
        assert "\x1b" in formatter.format_headers(headers)
    else:
        assert formatter.format_headers("") == ""
        headers = "Content-Type: text/html; charset=UTF-8\n\n"
        assert formatter.format_headers(headers) == headers

# Generated at 2022-06-11 23:43:04.004209
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.definition import OutputOptions
    from httpie.output import get_output_options
    from httpie.output.streams import Stream
    from httpie import ExitStatus
    from httpie.plugins import FormatterPlugin
    from httpie.config import DEFAULT_OPTIONS


    class EFormatterPlugin(FormatterPlugin):
        group_name = 'colors'

        def format_headers(self, headers: str) -> str:
            return headers

        def format_body(self, body: str, mime: str) -> str:
            return body

    class EStream(Stream):
        def write(self, *args, **kwargs):
            pass

        def flush(self):
            pass

    # These data is used to test the method format_headers()
    exit_status = ExitStatus.OK
   

# Generated at 2022-06-11 23:43:05.460622
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-11 23:43:16.579841
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class TestEnv:
        colors = 256

    body = ('Accept: text/plain\n'
            'Accept-Encoding: gzip, deflate\n'
            'Connection: keep-alive\n'
            'Host: httpbin.org\n'
            'User-Agent: HTTPie/0.9.2')
    env = TestEnv()
    test_case = ColorFormatter(env)

# Generated at 2022-06-11 23:43:17.595134
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter.group_name == 'colors'

# Generated at 2022-06-11 23:43:22.658540
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == None
    assert ColorFormatter.get_style_class('nonexistent_color_scheme') == None

# Generated at 2022-06-11 23:43:27.030450
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import unittest
    from mock import patch

    # Patch the get_lexer_for_body method

# Generated at 2022-06-11 23:44:06.739761
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('Solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('nonexistent') is None

# Generated at 2022-06-11 23:44:11.895823
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment = Environment(colors=True)
    formatter = ColorFormatter(env=environment)
    output = formatter.format_headers('GET / HTTP/1.1\nHost: example.com')
    assert 'GET / HTTP/1.1' in output
    assert 'Host: example.com' in output



# Generated at 2022-06-11 23:44:13.785363
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']


# Generated at 2022-06-11 23:44:22.609612
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.input import ParseError
    from httpie.output.streams import StdoutBytesStream, StdoutUnicodeStream
    from httpie.plugins import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.context import Environment
    from httpie.core import main as httpie_main

    env = Environment()
    env.colors = 256
    env.stdout = StdoutBytesStream()
    env.stdin = StdoutBytesStream()
    plugin_manager = PluginManager(env=env)
    http_basic_auth = HTTPBasicAuth()
    plugin_manager.add_plugins([http_basic_auth])
    color_formatter = ColorFormatter(env=env, color_scheme=SOLARIZED_STYLE)
    args = parser.parse

# Generated at 2022-06-11 23:44:31.501641
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments import highlight as pygments_highlight

    request = """\
GET https://api.github.com/repos/b4b4r07/dotfiles/git/blobs/7253386c4eae93d7cd6e069ad1a488ac9187f91a
Host: api.github.com
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate, compress
Accept: */*
Connection: keep-alive

"""

# Generated at 2022-06-11 23:44:43.009307
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from pygments.lexers import HttpLexer
    from pygments.lexers.text import JavascriptLexer
    from pygments.lexers.text import HtmlLexer
    from pygments.lexers.web import XmlLexer
    env = Environment()
    color_formatter = ColorFormatter(env)
    headers = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Encoding: gzip
Content-Type: text/html; charset=utf-8
Date: Sun, 15 Oct 2017 11:56:02 GMT
Transfer-Encoding: chunked
'''
    res = pygments.highlight(
        headers,
        HttpLexer(),
        color_formatter.formatter
    ).strip()
    assert color_formatter.format_headers(headers) == res

    body

# Generated at 2022-06-11 23:44:52.575805
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie import ExitStatus
    from httpie.core import parser_JSON, parser_cURL
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import builtin
    from httpie.plugins import FormatterPlugin
    from httpie.formatter.colors import ColorFormatter
    from httpie.output.streams import Streams
    # FIXME: trick to get colored output
    #        when running unit tests
    import builtins
    builtins.__dict__['_'] = lambda x: x

    def assert_format_body_called(**kwargs):
        def encode_to_bytes(string):
            return string.encode('utf-8')
        fp = urlopen('http://httpbin.org/get')


# Generated at 2022-06-11 23:44:55.001445
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    """
    [X] Test get_style_class() of class ColorFormatter
    """
    cf = ColorFormatter(None)
    assert(cf.get_style_class('solarized') == Solarized256Style)

# Generated at 2022-06-11 23:45:01.235784
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main as http

    args = [
        '--pretty', 'colors',
        'https://httpie.org',
    ]
    env = Environment(stdin_isatty=True,
                      stdout_isatty=True,
                      color=256)
    output = http(*args, env=env)
    assert output.startswith('\x1b[38;5;202mHTTP')

# Generated at 2022-06-11 23:45:03.919935
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # type: (str) -> str
    """

    For string 'ok', return 'ok'.

    """
    pass



# Generated at 2022-06-11 23:45:55.998435
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import re
    import StringIO
    from httpie.formatter import get_formatter
    from httpie.compat import is_windows

    def check_formatted(data, expected):
        output_stream = StringIO.StringIO()
        formatter = get_formatter('colors', output_stream)
        data = formatter.format_headers(data)
        if is_windows:
            # Different Pygments versions on Windows return
            # different number of empty lines at the top
            lines = data.splitlines()
            lines = [line for line in lines if line.strip()]
            data = '\n'.join(lines)
        assert data == expected

    # Request line
    headers = 'GET / HTTP/1.1'

# Generated at 2022-06-11 23:45:58.369910
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(Environment())
    color_formatter.enabled = True
    print(color_formatter.format_body('{ "hello": "world" }', 'application/json'))

# Generated at 2022-06-11 23:46:09.256005
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.output.streams import AllBytesBinaryOutputStream

    env = Environment(colors=True)
    explicit_json = True
    color_scheme = DEFAULT_STYLE

    cf = ColorFormatter(
        env=env,
        explicit_json=explicit_json,
        color_scheme=color_scheme,
        stream=AllBytesBinaryOutputStream(),
    )


# Generated at 2022-06-11 23:46:18.524831
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class DummyLexer(pygments.lexer.RegexLexer):
        tokens = {'root': [(r'\w+', pygments.token.Token),
                           (r'\s+', pygments.token.Text)
                           ]}

    class DummyEnvironment():
        def __init__(self):
            self.colors = 256

    class DummyColorFormatter(ColorFormatter):
        def get_lexer_for_body(
            self, mime: str,
            body: str
        ) -> Optional[Type[Lexer]]:
            return DummyLexer()

    env = DummyEnvironment()
    color_formatter = DummyColorFormatter(env)

    body = 'blabla'
    mime = 'application/json; charset=utf8'
    lexer = color

# Generated at 2022-06-11 23:46:21.156690
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexers._mapping import LEXERS
    if 'http' in LEXERS:
        del LEXERS['http']
    lexer = SimplifiedHTTPLexer()
    assert lexer.aliases == ['http']

# Generated at 2022-06-11 23:46:30.463850
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import pygments.util
    env = Environment()
    formatter = ColorFormatter(env, explicit_json=False)
    env.colors = 256
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/JSON') == pygments.lexers.get_lexer_by_name('json')
    # As a last resort, if no lexer feels responsible, and
    # the subtype contains 'json', take the JSON lexer
    assert get_lexer('application/json+bad') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json+bad', body='{}') == pygments.lexers.get_lexer_by_name('json')
   

# Generated at 2022-06-11 23:46:31.813217
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import os
    import json


# Generated at 2022-06-11 23:46:39.386376
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment(colors=256, is_tty=True))

    lexer = formatter.get_lexer_for_body('image/png', '')
    assert lexer == None

    lexer = formatter.get_lexer_for_body('application/json', '')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    assert formatter.get_lexer_for_body('application/pdf', '') == None
    assert formatter.get_lexer_for_body('application/pdf', '{ "hello": 1 }') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-11 23:46:50.039459
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    code1 = "GET / HTTP/1.1"
    code2 = "Host: github.com"
    code3 = "Referer: http://google.com"
    code4 = """\
HTTP/1.1 200 OK\
"""
    code5 = """\
HTTP/1.1 301 Moved Permanently\
"""
    code6 = """\
HTTP/1.1 204 No Content\
"""
    code7 = """\
HTTP/1.1 501 Not Implemented\
"""

# Generated at 2022-06-11 23:46:57.036795
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # To parse the headers.
    lexer = SimplifiedHTTPLexer()
    # Request-Line
    request_line = 'GET /hello HTTP/1.1'
    tokens = pygments.lex(request_line, lexer)
    assert (tokens[0][0] == pygments.token.Name.Function
            and tokens[0][1] == 'GET')
    assert (tokens[2][0] == pygments.token.Name.Namespace
            and tokens[2][1] == '/hello')
    assert (tokens[4][0] == pygments.token.Keyword.Reserved
            and tokens[4][1] == 'HTTP')
    assert (tokens[5][0] == pygments.token.Operator
            and tokens[5][1] == '/')