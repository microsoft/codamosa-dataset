

# Generated at 2022-06-11 23:37:45.005302
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert True

# Generated at 2022-06-11 23:37:53.218880
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import sys
    import pygments.formatter
    from httpie.compat import BytesIO

    stream = BytesIO()

    formatter = ColorFormatter(env={
        'colors': 256,
        'isatty': True
    }, out_file=stream)

    # from httpie.plugins.builtin import FormatterPlugin
    # imp.reload(FormatterPlugin)
    # from httpie.plugins.builtin import FormatterPlugin

    formatter.format_headers(headers=u'Accept: application/json')

# Generated at 2022-06-11 23:38:00.801252
# Unit test for function get_lexer
def test_get_lexer():

    print(get_lexer('application/x-yaml'))
    print(get_lexer('application/yaml'))
    print(get_lexer('application/xml'))
    print(get_lexer('text/css'))
    print(get_lexer('text/css', explicit_json=True))
    print(get_lexer('text/css', explicit_json=True, body=''))

# Generated at 2022-06-11 23:38:03.469914
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():

    # Test for both color scheme is not valid and color scheme is valid
    assert ColorFormatter.get_style_class('not_exists') is Solarized256Style
    assert ColorFormatter.get_style_class('fruity') is pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style
    assert ColorFormatter.get_style_class('auto') is pygments.styles.get_style_by_name('auto')

# Generated at 2022-06-11 23:38:06.488470
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color = ColorFormatter()
    assert color.format_headers('Content-Length: 100') == '\x1b[38;5;8m\x1b[48;5;235mContent-Length: 100\x1b[0m'

# Generated at 2022-06-11 23:38:18.631943
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.compat import is_py26
    from httpie.compat import is_py27
    from httpie.compat import is_py32
    from httpie.compat import is_py33
    from httpie.compat import is_py34
    from httpie.core import main

    # -------------------------------------------------------------------------
    # Python 2.6
    # -------------------------------------------------------------------------


# Generated at 2022-06-11 23:38:19.246898
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter

# Generated at 2022-06-11 23:38:25.002485
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style

    # Make sure we get exception for an invalid style
    try:
        assert ColorFormatter.get_style_class('invalid-style') is None
        assert False, 'Should have thrown ClassNotFound exception.'
    except ClassNotFound:
        pass

# Generated at 2022-06-11 23:38:35.900441
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-11 23:38:45.195900
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-11 23:39:01.896436
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.output.streams import DEFAULT_STREAMS
    from httpie.context import Environment

    import pytest

    # Setup the environment and the plugins
    env = Environment(stdin=None,
                      stdout=DEFAULT_STREAMS.stdout,
                      stderr=DEFAULT_STREAMS.stderr,
                      stdout_isatty=True,
                      color=True,
                      colors=True,
                      style=DEFAULT_STYLE)

    plugins = FormatterPluginManager(env=env)

    # Setup the ColorFormatter
    formatter = ColorFormatter(env=env)
    formatter.enabled = True

    # Make sure it is enabled
    assert formatter.enabled == True
    # Make sure it is loaded in the plugin manager

# Generated at 2022-06-11 23:39:09.175531
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class.__name__ == 'get_style_class'
    assert ColorFormatter.get_style_class('abc') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == Solarized256Style
    assert ColorFormatter.get_style_class('native') == Solarized256Style
    assert ColorFormatter.get_style_class('default') == Solarized256Style
    assert ColorFormatter.get_style_class('colorful') == Solarized256Style
    assert ColorFormatter.get_style_class('abc') == Solarized256Style

# Generated at 2022-06-11 23:39:20.202261
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    request = """\
GET /foo HTTP/1.1
Foo: Bar
Baz: Qux
"""

# Generated at 2022-06-11 23:39:31.664174
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import str
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    # If no lexer is found, but the response body seems
    # to be JSON, use the JSON lexer.
    fmt = ColorFormatter(Environment(colors=256, stdout_isatty=True))

# Generated at 2022-06-11 23:39:37.172487
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    c = ColorFormatter(None)
    assert c.formatter.style == Solarized256Style
    c = ColorFormatter(None, color_scheme='monokai')
    assert c.formatter.style == pygments.styles.get_style_by_name('monokai')



# Generated at 2022-06-11 23:39:38.357344
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
	pass


# Generated at 2022-06-11 23:39:40.585063
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("fruity") is pygments.styles.get_style_by_name("fruity")

# Generated at 2022-06-11 23:39:51.390700
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.colors import COLOR_SCHEMES
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    env = {"colors": "256" if is_windows else "true"}
    formatter = ColorFormatter(env=env, color_scheme=COLOR_SCHEMES[0])
    assert ColorFormatter.format_headers(formatter, "") == ""
    assert ColorFormatter.format_headers(formatter, "Hello") == "Hello"
    assert ColorFormatter.format_headers(formatter, "Hello World") == "Hello World"
    assert ColorFormatter.format_headers(formatter, "Hello\n") == "Hello\n"

# Generated at 2022-06-11 23:40:04.281021
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    tokens = lexer.get_tokens_unprocessed(
        'POST /some/url HTTP/1.1\r\n'
        'Host: some.domain.com\r\n'
        'Content-Type: application/json\r\n'
        'Content-Length: 42\r\n'
        'User-Agent: HTTPie/0.9.9\r\n'
        'Accept: */*\r\n'
        '\r\n'
    )
    # Validate that the POST request-line is properly tokenized.
    request_line_tokens = list(tokens)[0:5]
    assert request_line_tokens[0][0] == pygments.token.Name.Function
    assert request_line

# Generated at 2022-06-11 23:40:13.859093
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class Env:
        ansi_colors = True

    class ColorFormatter(ColorFormatter):
        def __init__(self):
            pass

    env = Env()
    colorformatter = ColorFormatter(env)

    input = ('GET / HTTP/1.1\r\n'
             'Accept-Encoding: gzip, deflate\r\n'
             'Accept: */*\r\n'
             'User-Agent: HTTPie/0.9.3\r\n')

# Generated at 2022-06-11 23:40:28.507878
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    """
    >>> http_lexer = SimplifiedHTTPLexer()
    >>> http_lexer.get_tokens_unprocessed('''PUT /echo HTTP/1.1
    ... Content-Type: text/plain
    ...
    ... body
    ... ''')  # doctest: +ELLIPSIS +NORMALIZE_WHITESPACE
    <generator object ...>
    """

# Generated at 2022-06-11 23:40:36.948066
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins.colors import ColorFormatter
    assert ColorFormatter.get_style_class('auto') == pygments.styles.get_style_by_name('auto')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    if (is_windows):
        assert ColorFormatter.get_style_class('auto') == pygments.styles.get_style_by_name('fruity')
    else:
        assert ColorFormatter.get_style_class('auto') == pygments.styles.get_style_by_name('native')

# Generated at 2022-06-11 23:40:41.760082
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.formatter import format_options
    from httpie.plugins import builtin
    from httpie import ExitStatus
    from httpie.context import Environment

    env = Environment()
    env.stdout = open('/tmp/httpie_temp','w')
    env.stdout.close()
    color_formatter = ColorFormatter(env, verbose=True, explicit_json=False,
                                     color_scheme=DEFAULT_STYLE, indent=0)
    color_formatter.enabled = True

    response = {
        'headers': {
            'Content-Type': 'application/json'
        },
        'body': '{"key": "value"}'
    }

    formatted = color_formatter.format_body(response['body'], response['headers'].get('Content-Type'))
   

# Generated at 2022-06-11 23:40:53.329932
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import pytest
    env = Environment()
    formatter = ColorFormatter(env=env, color_scheme=DEFAULT_STYLE)

    headers = '''\
GET / HTTP/1.1
Host: httpbin.org
User-Agent: simple_request
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive'''


# Generated at 2022-06-11 23:40:56.859934
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    correct_class = ColorFormatter.get_style_class('native')
    assert correct_class == pygments.styles.get_style_by_name('native')

# Generated at 2022-06-11 23:41:07.429467
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='application/json') == \
        pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(mime='application/json; charset=UTF-8') == \
        pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(mime='application/vnd.api+json') == \
        pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(mime='application/hal+json') == \
        pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(mime='application/problem+json') == \
        pygments.lexers.get_lexer_by_name('json')
    assert get

# Generated at 2022-06-11 23:41:19.094811
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class Test(ColorFormatter):
        def __init__(self):
            super().__init__(env=Environment())

    c = Test()

    print('UNIT TEST: ' + c.get_style_class.__name__)
    print('  get_style_class:')
    print('  Result:', c.get_style_class('monokai'))
    print('  Expected:', pygments.styles.get_style_by_name('monokai'))

    print('  get_style_class:')
    print('  Result:', c.get_style_class('solarized'))
    print('  Expected:', pygments.styles.get_style_by_name('solarized'))

    print('  get_style_class:')

# Generated at 2022-06-11 23:41:20.201612
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    pass


# Generated at 2022-06-11 23:41:22.492814
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    formatter = ColorFormatter(env)
    assert formatter.formatter is not None
    assert formatter.http_lexer is not None

# Generated at 2022-06-11 23:41:33.381261
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.core import main
    from httpie.context import Environment
    from httpie.plugins import plugin_manager

    plugin_manager.load_internal_plugins()
    env = Environment(
        colors=256
    )
    color_formatter = ColorFormatter(env=env)
    assert hasattr(color_formatter, 'enabled')
    assert hasattr(color_formatter, 'explicit_json')
    assert hasattr(color_formatter, 'formatter')
    assert hasattr(color_formatter, 'http_lexer')
    assert color_formatter.enabled == True
    assert hasattr(color_formatter, 'format_headers')
    assert hasattr(color_formatter, 'format_body')
    assert hasattr(color_formatter, 'get_lexer_for_body')

# Generated at 2022-06-11 23:41:43.360222
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment()).enabled == False
    assert ColorFormatter(Environment(colors=True)).enabled == True
    assert ColorFormatter(Environment(colors=256)).enabled == True

# Generated at 2022-06-11 23:41:54.327101
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins import default_options
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.formatter import Colors
    env = Environment(colors=Colors.ON, stdout_isatty=True,
                      stdin_isatty=True,
                      stdin=default_options.stdin,
                      stdout=default_options.stdout,
                      is_windows=is_windows)

    assert ColorFormatter.get_style_class(color_scheme='monokai') is pygments.styles.get_style_by_name('monokai')

    assert ColorFormatter.get_style_class(color_scheme='solarized') is Solarized256Style
    assert ColorFormatter.get_style_class(color_scheme='auto') is pygments

# Generated at 2022-06-11 23:42:01.530669
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class FakeColorFormatter(ColorFormatter):
        def __init__(self, mime, body):
            super().__init__(Environment(), None, None)
            self.mime = mime
            self.body = body

        def get_lexer_for_body(self, mime, body):
            assert mime == self.mime
            assert body == self.body
            return get_lexer(mime, body)

    # Body is empty
    formatter = FakeColorFormatter('application/json', '')
    assert formatter.format_body(formatter.body, formatter.mime) == ''

    # Body is not empty and MIME type is 'application/json'
    formatter = FakeColorFormatter('application/json', '{}')

# Generated at 2022-06-11 23:42:12.793179
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():

    class TestEnvironment(Environment):
        colors = True

    color_formatter = ColorFormatter(TestEnvironment())

    headers = "GET / HTTP/1.1\r\nUser-Agent: I am User agent\r\nHost: localhost:3020\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\n\r\n";

# Generated at 2022-06-11 23:42:15.489468
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer('text/html') is not None
    assert get_lexer('application/octet-stream') is None

# Generated at 2022-06-11 23:42:24.838358
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie.plugins.builtin
    import pygments.lexers

    for mimetype in [
        'application/json', 'application/json; charset=UTF-8',
        'text/plain', 'text/plain; charset=UTF-8'
    ]:
        for explicit_json in [False, True]:
            for body in ['', '{}', '"abc"']:
                color_formatter = ColorFormatter(
                    httpie.plugins.builtin.Environment(),
                    explicit_json=explicit_json,
                    color_scheme='bugnasty',
                )
                # The check below is needed as we have to make sure
                # we have the right lexer but the lexer is produced dynamically

# Generated at 2022-06-11 23:42:27.258034
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class('solarized')
    assert style.__name__ == 'Solarized256Style'

# Generated at 2022-06-11 23:42:30.499227
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(None)
    # mime not in supported list, should be text
    mime = 'text/plain'
    assert color_formatter.format_body("this is a test", mime) == "this is a test"

# unit test for method format_header of class ColorFormatter

# Generated at 2022-06-11 23:42:36.121971
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_classes = (
        ColorFormatter.get_style_class("borland"),
        ColorFormatter.get_style_class("manni"),
        ColorFormatter.get_style_class("monokai"),
        ColorFormatter.get_style_class("perldoc"),
        ColorFormatter.get_style_class("solarized"),
    )
    for style_class in style_classes:
        min_len = min((len(t) for t in style_class.styles.values()))
        assert min_len == 1, "The keys in the dictionary should be single character."

# Generated at 2022-06-11 23:42:45.354936
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer('text/http'), SimplifiedHTTPLexer)
    assert isinstance(get_lexer('text/html'), pygments.lexers.html.HtmlLexer)
    assert isinstance(get_lexer('application/json'),
                      pygments.lexers.special.JsonLexer)
    assert isinstance(get_lexer('application/x-javascript'),
                      pygments.lexers.special.JsonLexer)
    assert isinstance(get_lexer('application/atom+xml'),
                      pygments.lexers.special.XmlLexer)
    assert get_lexer('application/xml') is None  # No matching lexer found

# Generated at 2022-06-11 23:43:08.043192
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')

    # Solarized256Style is a subclass of the builtin style
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style
    assert issubclass(ColorFormatter.get_style_class(SOLARIZED_STYLE), pygments.style.Style)

# Generated at 2022-06-11 23:43:18.946739
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # type: () -> None
    assert isinstance(ColorFormatter.get_style_class('auto'),
                      pygments.styles.get_style_by_name('monokai'))
    assert isinstance(ColorFormatter.get_style_class('default'),
                      pygments.styles.get_style_by_name('monokai'))
    assert isinstance(ColorFormatter.get_style_class('monokai'),
                      pygments.styles.get_style_by_name('monokai'))
    assert isinstance(ColorFormatter.get_style_class('manni'),
                      pygments.styles.get_style_by_name('manni'))
    assert isinstance(ColorFormatter.get_style_class('igor'),
                      pygments.styles.get_style_by_name('igor'))
   

# Generated at 2022-06-11 23:43:29.762380
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Just format HTTP requests and responses, nothing else
    # Test with text-mode (no colors)
    f = ColorFormatter(Environment(colors=False))
    assert f.format_headers('GET / HTTP/1.1\nHost: localhost\n\n') == 'GET / HTTP/1.1\nHost: localhost\n\n'
    assert f.format_headers('HTTP/1.1 200 OK\nContent-Type: text/html\n\nHello, world') == 'HTTP/1.1 200 OK\nContent-Type: text/html\n\nHello, world'
    # Test with color mode
    f = ColorFormatter(Environment(colors=True))

# Generated at 2022-06-11 23:43:39.641925
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():

    def dummy_env():
        env = Environment()
        env.colors = 8  # use 8-color palette
        return env

    class TestColorFormatter(ColorFormatter):
        def __init__(self, env: Environment, **kwargs):
            super().__init__(
                env=env,
                explicit_json=False,
                color_scheme='solarized'
            )

    test_solarized = TestColorFormatter(dummy_env())
    assert issubclass(
        test_solarized.get_style_class('solarized'),
        pygments.styles.get_style_by_name('solarized')
    )
    assert test_solarized.get_style_class('solarized') != Solarized256Style

    test_solarized_256 = TestColorFormatter

# Generated at 2022-06-11 23:43:45.684107
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from unittest.mock import Mock
    env = Mock()
    color_formatter = ColorFormatter(env)
    style = color_formatter.get_style_class('fruity')
    assert style == pygments.styles.get_style_by_name('fruity')
    style = color_formatter.get_style_class('solarized')
    assert style == Solarized256Style

# Generated at 2022-06-11 23:43:55.435468
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.core import main
    from httpie.context import Environment

    # given
    env = Environment()
    env.stdout_isatty = True
    env.colors = True
    color = ColorFormatter(env)
    body = '{"key":"value"}'
    # when
    formated = color.format_body(body, "application/json")
    # then
    assert formated == '\x1b[90m{\x1b[39;49;00m\x1b[34m"key"\x1b[39;49;00m\x1b[90m:\x1b[39;49;00m\x1b[34m"value"\x1b[39;49;00m\x1b[90m}\x1b[39;49;00m'

# Generated at 2022-06-11 23:43:57.467348
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(colors=256), color_scheme='solarized').__class__.__name__ == 'ColorFormatter'

# Generated at 2022-06-11 23:43:59.767897
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    current_env = Environment(colors=256, less_colors=False)
    ColorFormatter(env=current_env, color_scheme="solarized")

# Generated at 2022-06-11 23:44:05.993016
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexer import RegexLexer
    #from pygments.formatter import Formatter
    #from pygments.style import Style

    lexer = SimplifiedHTTPLexer()

    # print(get_lexer(mime="text/html", body=''))
    # print(dir(pygments))
    # print(dir(pygments.util))
    # print(dir(pygments.styles))
    # print(dir(pygments.styles.get_style_by_name('native')))
    # print(dir(pygments.lexer))
    # print(dir(pygments.lexer.RegexLexer))
    # print(dir(pygments.lexer.RegexLexer.__dict__))
    # print(pygments.lexers.get

# Generated at 2022-06-11 23:44:15.661765
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    formatter = ColorFormatter(env, color_scheme='solarized')

    body = '{"key": "value"}'
    mime = 'application/json'
    formatted_body = formatter.format_body(body, mime)

# Generated at 2022-06-11 23:44:53.802009
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from io import StringIO
    from httpie.cli import environment
    from httpie import ExitStatus
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    env = environment.Environment()
    env.colors = 256
    input_stream = StringIO('GET http://example.org/ HTTP/1.1\nHost: example.org\nContent-Type: text/html;charset=UTF-8')
    output_stream = StringIO()
    error_stream = StringIO()
    args = {}
    exit_status = ExitStatus.OK
    color_formatter = None
    try:
        color_formatter = ColorFormatter(env, **args)
    except:
        pass
    color_formatter.stream = output_stream

# Generated at 2022-06-11 23:45:04.365296
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    def assert_format_headers(
        headers: str,
        expected: str
    ):
        assert ColorFormatter.format_headers(
            None,
            headers=headers
        ) == expected

    # default color scheme
    assert_format_headers(
        headers='GET / HTTP/1.1\nHost: example.org',
        expected='\x1b[34mGET\x1b[39m \x1b[32m/\x1b[39m \x1b[36mHTTP/1.1\x1b[39m\n\x1b[34mHost\x1b[39m: \x1b[32mexample.org\x1b[39m'
    )
    # solarized color scheme

# Generated at 2022-06-11 23:45:05.102049
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer



# Generated at 2022-06-11 23:45:07.993603
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) == pygments.styles.get_style_by_name(DEFAULT_STYLE)

# Generated at 2022-06-11 23:45:15.716302
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(
        env=Environment(colors=True),
        explicit_json=True,
        color_scheme=AUTO_STYLE,
        **{}
    )
    body = "[1,2]"
    mime = "text/x-json"
    lexer = formatter.get_lexer_for_body(mime, body)
    assert lexer is None
    body = "[1,2]"
    mime = "text/x-json"
    lexer = formatter.get_lexer_for_body(mime, body)
    assert lexer is not None

# Generated at 2022-06-11 23:45:26.853029
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import io
    import httpie.formatters
    import httpie.formatters.colors

    def format_body(body_bytes, mime_type):
        formatters_manager = httpie.formatters.get_manager()
        env = Environment(colors=256)
        body_stream = io.BytesIO(body_bytes)
        formatter = httpie.formatters.colors.ColorFormatter(
            env=env,
            explicit_json=False,
            color_scheme='solarized',
        )
        formatters_manager.register_formatter(formatter)
        return formatters_manager.format_body(
            response=None,
            mime=mime_type,
            body_stream=body_stream,
        )

    # test for html

# Generated at 2022-06-11 23:45:36.102477
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.utils import Version

    input_headers = (
        'GET / HTTP/1.1\r\nHost: example.org\r\n'
        'Connection: close\r\nAccept: */*\r\nUser-Agent: '
        'HTTPie/%s\r\n\r\n' % Version)

# Generated at 2022-06-11 23:45:48.545572
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(Environment())
    formatted_headers = formatter.format_headers(
        'GET / HTTP/1.1\n'
        'Accept-Encoding: gzip, deflate\n'
        'Accept: */*\n'
        'Connection: keep-alive\n'
    )

# Generated at 2022-06-11 23:45:53.589110
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplfied_http_lexer = SimplifiedHTTPLexer()
    assert simplfied_http_lexer.name == 'HTTP'
    assert simplfied_http_lexer.aliases == ['http']
    assert simplfied_http_lexer.filenames == ['*.http']
    assert type(simplfied_http_lexer.tokens) == dict

# Generated at 2022-06-11 23:45:56.874580
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    """Unit test for constructor of class SimplifiedHTTPLexer"""
    if not isinstance(SimplifiedHTTPLexer(), pygments.lexer.RegexLexer):
        raise TypeError('SimplifiedHTTPLexer is not a RegexLexer')



# Generated at 2022-06-11 23:47:13.972230
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class DummyEnvironment:
        colors = True

    formatter = ColorFormatter(DummyEnvironment())

# Generated at 2022-06-11 23:47:22.856232
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    tokens = lexer.get_tokens('GET http://example.com HTTP/1.1')
    assert tokens == [(0, 3, 'Name.Function'), (3, 4, 'Text'), (4, 17, 'Name.Namespace'), (17, 18, 'Text'), (18, 23, 'Keyword.Reserved'), (23, 24, 'Operator'), (24, 29, 'Number')]
    tokens = lexer.get_tokens('HTTP/1.1 200 OK')
    assert tokens == [(0, 5, 'Keyword.Reserved'), (5, 6, 'Operator'), (6, 11, 'Number'), (11, 12, 'Text'), (12, 15, 'Number'), (15, 16, 'Text'), (16, 19, 'Name.Exception')]

# Generated at 2022-06-11 23:47:29.326843
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit = True
    color_scheme = 'fruity'
    color_formatter = ColorFormatter(env, explicit, color_scheme)
    assert color_formatter.explicit_json == explicit
    assert color_formatter.formatter.style == pygments.styles.get_style_by_name(color_scheme)


if __name__ == '__main__':
    test_ColorFormatter()

# Generated at 2022-06-11 23:47:37.619481
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Arrange
    import builtins
    from httpie.compat import is_windows
    from httpie.output.definition import OutputFile
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.config import Config, DEFAULT_CONFIG_DIR
    from httpie.plugins import PluginManager
    from httpie.context import Environment
    import os

    headers = builtins.__dict__['headers'] = HTTPHeaders([('A', 'a'), ('B', 'b')])

    config_dir = DEFAULT_CONFIG_DIR
    httpie_config_path = os.path.join(config_dir, 'config.json')
    config_dict = {}