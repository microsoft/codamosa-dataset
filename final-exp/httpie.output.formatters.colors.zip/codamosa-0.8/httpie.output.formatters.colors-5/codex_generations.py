

# Generated at 2022-06-11 23:37:56.545297
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # type: () -> pygments.lexer.RegexLexer
    """Test procedure for SimplifiedHTTPLexer."""
    return SimplifiedHTTPLexer()

# Generated at 2022-06-11 23:38:00.726764
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexers import get_lexer_by_name
    SimplifiedHTTPLexer = get_lexer_by_name('http')
    assert SimplifiedHTTPLexer

# Generated at 2022-06-11 23:38:02.318505
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) is not None

# Generated at 2022-06-11 23:38:04.894411
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    ColorFormatter.__init__(
        Environment(colors=256),
        explicit_json=False,
        color_scheme='solarized'
    )

# Generated at 2022-06-11 23:38:17.938741
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class demo:
        def __init__(self):
            self._json_body = "{\"key\": \"value\"}"
            self._text_body = "This is a simple text."
            self._html_body = "<html><head><title>Hello</title></head></html>"
            self._xml_body = "<xml><root><string>Hello</string></root></xml>"
            self._css_body = "body {background: red;} h1 {color: blue;}"
            self._js_body = "function greet() {console.log(\"hello\")}"

        def assertEqual(self, actual, expected):
            if not (actual == expected):
                print(
                    "Failed: actual: {}, expected: {}".format(actual, expected)
                )
                raise AssertionError

    # Unit test for mimety

# Generated at 2022-06-11 23:38:27.116509
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Test case from the HTTP spec:
    # https://tools.ietf.org/html/rfc2616#section-4.2
    headers = (
        'Cache-Control: no-cache\n'
        'Pragma: no-cache\n'
        'Trailer: Expires\n'
        'Upgrade: HTTP/2.0, SHTTP/1.3, IRC/6.9, RTA/x11\n'
        'Via: 1.0 fred, 1.1 example.com (Apache/1.1)\n'
        'Warning: 199 Miscellaneous warning\n'
    )

# Generated at 2022-06-11 23:38:38.398374
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(
        env=Environment(),
        color_scheme='tango',
        explicit_json=False,
    )

    class FormatterTest:
        def __init__(self):
            self.response = None
            self.request = None

        def get_lexer(self):
            return formatter.get_lexer_for_body(
                mime=self.response.headers.get('Content-Type', ''),
                body=self.response.content,
            )


# Generated at 2022-06-11 23:38:47.019199
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    lines = []
    def print(*args, **kwargs):
        lines.append(' '.join(str(x) for x in args))
    env = Environment()
    env.print = print
    env.colors = 256
    cf = ColorFormatter(env, False, 'solarized')
    mime = 'application/json'
    body = '[{"id":1,"name":"Name","values":[1,2,3]}]'
    cf.format_body(body, mime)
    assert lines[0] == '\x1b[38;5;198m[\x1b[38;5;39m\x1b[38;5;39m\x1b[38;5;39m'

# Generated at 2022-06-11 23:38:59.757849
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin as plugin
    from httpie.output.base import StreamOutput as stream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.formatters.colors import ColorFormatter
    from httpie.core import Response
    from httpie.utils import get_formatter

# Generated at 2022-06-11 23:39:04.269068
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Given
    from httpie import main
    env = main.build_environment()
    c = ColorFormatter(env, False, color_scheme="solarized")
    # When
    style = c.get_style_class("solarized")
    # Then
    assert(style == Solarized256Style)

# Generated at 2022-06-11 23:39:17.945445
# Unit test for function get_lexer
def test_get_lexer():
    expected = [
        ('text/plain', None),
        ('text/cheese', TextLexer),
        ('text/javascript', None),
        ('application/javascript', PygmentsHttpLexer),
        ('application/json', PygmentsHttpLexer),
        ('application/json+cheese', PygmentsHttpLexer),
        ('application/json+cheese', PygmentsHttpLexer),
        ('application/json+cheese', PygmentsHttpLexer),
    ]
    for mime, lexer in expected:
        assert get_lexer(mime) == lexer

# Generated at 2022-06-11 23:39:29.359482
# Unit test for function get_lexer
def test_get_lexer():
    # JSON
    assert get_lexer(mime='application/json').__name__ == 'JSONLexer'
    assert get_lexer(explicit_json=True, body='{}').__name__ == 'JSONLexer'
    assert get_lexer(explicit_json=True, body='<html></html>') is None
    assert get_lexer(explicit_json=True, body='') is None
    assert get_lexer(mime='application/javascript').__name__ == 'JavascriptLexer'
    assert get_lexer(mime='text/javascript').__name__ == 'JavascriptLexer'
    assert get_lexer(mime='text/json').__name__ == 'JSONLexer'

# Generated at 2022-06-11 23:39:41.553120
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-11 23:39:52.512420
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import unittest
    import unittest.mock

    class ColorFormatterTest(unittest.TestCase):

        def setUp(self):
            self.env = unittest.mock.MagicMock()
            self.env.colors = True
            self.formatter = ColorFormatter(
                self.env,
                color_scheme='solarized',
                extensions=(),
            )

        def test_format_headers(self):
            headers = self.formatter.format_headers('foo: one\nbar: two\n')
            self.assertIn(pygments.token.Name.Attribute, headers)
            self.assertIn(pygments.token.String, headers)
            self.assertNotIn(pygments.token.Text, headers)

    return unittest.TestCase

# Unit

# Generated at 2022-06-11 23:39:53.691832
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # TODO
    pass


# Generated at 2022-06-11 23:39:56.038546
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-11 23:40:08.312001
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.output.streams import ColorStdoutStderrStream
    from httpie.context import Environment
    import json

    stdout_stderr_stream = ColorStdoutStderrStream()
    env = Environment(stdout=stdout_stderr_stream, stderr=stdout_stderr_stream)
    formatter  = ColorFormatter(env=env, color_scheme='native')

    # Testing with mime type application/json
    body = json.dumps({"name":"John Doe"})
    mime = "application/json"
    color_body = formatter.format_body(body=body, mime=mime)
    assert body == color_body

    # Testing with mime type text/plain
    body = "Hello"
    mime = "text/plain"

# Generated at 2022-06-11 23:40:16.114258
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(None, False, 'auto')

    body = {
        "message": "Any data",
        "author": "Tesd1"
    }
    mime = "application/json"


# Generated at 2022-06-11 23:40:18.957927
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert issubclass(ColorFormatter.get_style_class(SOLARIZED_STYLE),
                      pygments.styles.Style)



# Generated at 2022-06-11 23:40:31.703185
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    normal_types = (
        'text/html',
        'application/javascript',
        'application/json',
        'text/css',
        'image/gif',
    )
    lexer_types = (
        'text/html',
        'application/javascript',
        'application/json',
        'text/css',
    )

    formatter = ColorFormatter(None)
    for content_type, expected_lexer in zip(normal_types, lexer_types):
        assert formatter.get_lexer_for_body(content_type, '').name == \
               expected_lexer

    assert not formatter.get_lexer_for_body('text/plain', '')
    assert not formatter.get_lexer_for_body('application/octet-stream', '')
    assert formatter

# Generated at 2022-06-11 23:40:52.124683
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie
    from httpie.compat import urlopen
    from httpie.plugins import FormatterPlugin
    from httpie.input import ParseError
    from httpie.core import main
    from httpie.plugins import builtin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import (
        JSONFormatter,
        HTTPiePlugin,
        HeadersValidator,
        HTTPHeaderDict,
        JSONDumper,
        JSONCalcTool,
        AuthPlugin,
        AuthCredentials,
        HTTPBasicAuth,
        HTTPTokenAuth,
        Downloader,
        HTTPCompress,
        SessionPlugin,
        HTTPMultipart,
        RedirectSessionPlugin,
        HTTPSession,
    )
    from httpie.plugins import FormatterPlugin

# Generated at 2022-06-11 23:41:04.369294
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    for text in [
        'GET / HTTP/1.1\n',
        'GET / HTTP/2.0\n',
        'GET / HTTP/2.0-dev\n',
        'GET / HTTP/2\n',
        'GET / HTTP/2-dev\n',
        'GET / HTTP/9999999999999.9999999999999\n',
        'GET / HTTP/0\n',
        'GET / HTTP/0.0\n',
        'GET / HTTP/0.9\n',
        'RANDOM / HTTP/1.1\n',
        'GET /\n',
        'GET / HTTP/\n',
        'Host: example.com\n',
    ]:
        tokens = list(SimplifiedHTTPLexer().get_tokens(text))
       

# Generated at 2022-06-11 23:41:14.240143
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    samples = [
        'POST / HTTP/1.1',
        'Host: httpbin.org',
        'User-Agent: awesome-httpie/0.9.9',
        'Accept-Encoding: gzip, deflate',
        'Accept: application/json',
        'Content-Type: application/json',
        'Content-Length: 348',
        '',
        '{"foo": "bar", "baz": [1, 2, null, true, false]}'
    ]
    for sample in samples:
        for token, content in lexer.get_tokens(sample):
            pass

# Generated at 2022-06-11 23:41:23.226085
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(None, True)
    body = "hello world"
    mime = "text/plain"
    output = color_formatter.format_body(body, mime)
    assert(output == u'hello world')

    body = "{\"message\":\"ok\"}"
    mime = "text/plain"
    output = color_formatter.format_body(body, mime)
    assert(output == u'{' + '\u001b[32m' + u'"message"' + '\u001b[39m' + u':' + '\u001b[32m' + u'"ok"' + '\u001b[39m' + u'}')

    body = "{\"message\":\"ok\"}"
    mime = "application/json"
    output = color_form

# Generated at 2022-06-11 23:41:26.469650
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter.enabled == True
    color_formatter = ColorFormatter()
    assert color_formatter.foreground_color == True
    assert color_formatter.background_color == True
    assert color_formatter.enabled == True

# Generated at 2022-06-11 23:41:37.425202
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
                style=Solarized256Style
            )

    class SampleEnv(Environment):
        colors = 256
    sample_env = SampleEnv()

    c = ColorFormatter(
        env=sample_env,
        explicit_json=False,
        color_scheme=AUTO_STYLE,
    )

    c.http_lexer = http_lexer
    c.formatter = formatter

    sample_mime = 'application/json'
    sample_body = '{"result":"success"}'

    lex = c.get_lexer_for_body(sample_mime, sample_body)

    assert isinstance(lex, pygments.lexers.JsonLexer)

# Generated at 2022-06-11 23:41:47.401932
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.output.formatters.colors import get_lexer, get_lexer_for_body

    # Empty response
    lexer = get_lexer(mime='', body='')
    assert lexer is None
    lexer = get_lexer_for_body('', '')
    assert lexer is None

    # HTML
    lexer = get_lexer(mime='text/html', body="")
    assert lexer is pygments.lexers.get_lexer_by_name('html')
    lexer = get_lexer_for_body('text/html', "")
    assert lexer is pygments.lexers.get_lexer_by_name('html')

    # HTML subtype

# Generated at 2022-06-11 23:41:51.197608
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    c = ColorFormatter(Environment())
    r = c.format_body('<html></html>', 'text/html')
    assert r.startswith('<div class="highlight">')
    assert r.endswith('</div>')

# Generated at 2022-06-11 23:42:00.628924
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import io

    environment = Environment(options={'--style': 'solarized'})
    color_formatter = ColorFormatter(env=environment, output_file=io.StringIO(), output_encoding='utf8')
    color_mime = 'text/css'
    color_body = '''
    * {
       font-size: small;
       padding: 0.2em;
    }

    body {
       font-family: sans-serif;
    }

    pre {
       margin-left: 1em;
       margin-right: 1em;
    }
    '''
    color_body = color_formatter.format_body(body=color_body, mime=color_mime)
    assert len(color_body) > 0
    assert '\x1b[' not in color_body


# Generated at 2022-06-11 23:42:11.942262
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    try:
        from httpie.utils import get_from_module
        ColorFormatter.get_style_class = get_from_module
    except ImportError:
        # Unit test on Windows
        pass
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('default') == Solarized256Style
    assert ColorFormatter.get_style_class('none') == Solarized256Style
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')
    assert ColorFormatter.get_style_class('Fruity') == pygments.styles.get_style_by_name

# Generated at 2022-06-11 23:42:29.913865
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Case: json-explicit
    assert get_lexer(
        mime='application/json',
        body='{"a":[1,2,3]}',
        explicit_json=True,
    ) == pygments.lexers.get_lexer_by_name('json')

    # Case: json-auto
    assert get_lexer(
        mime='text/html',
        body='{"a":[1,2,3]}',
        explicit_json=False,
    ) == pygments.lexers.get_lexer_by_name('json')

    # Case: html

# Generated at 2022-06-11 23:42:32.185010
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(colors=256),
                          explicit_json=True,
                          color_scheme='fruity')

# Generated at 2022-06-11 23:42:38.534192
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert pygments.highlight(
        '\r\n'.join([
            'GET / HTTP/1.1',
            'Host: httpbin.org',
            'Accept: */*',
            'Accept-Encoding: gzip, deflate',
            'Connection: keep-alive',
            'User-Agent: HTTPie/0.9.8'
        ]),
        lexer,
        Terminal256Formatter(style=Solarized256Style)
    )

# Generated at 2022-06-11 23:42:47.692512
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Mock Environment to simulate colors = 256
    class EnvironmentMock:
        colors = 256
    env = EnvironmentMock()

    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    # Test for 'application/json'
    result = color_formatter.format_body(body='{"firstName":"John","lastName":"Doe","age":50}', mime='application/json')

# Generated at 2022-06-11 23:42:49.894575
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert not ColorFormatter(Environment(colors=256))
    assert ColorFormatter(Environment(colors=256), color_scheme="solarized256")

# Generated at 2022-06-11 23:43:01.266778
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # By default choose TerminalFormatter if terminal supports 256 colors
    color_scheme = DEFAULT_STYLE
    assert ColorFormatter.get_style_class(color_scheme) == Solarized256Style
    # We can use Solarized256Style only if terminal supports 256 colors
    color_scheme = SOLARIZED_STYLE
    assert ColorFormatter.get_style_class(color_scheme) == Solarized256Style
    # We use TerminalFormatter for style auto (which follows ANSI colors)
    color_scheme = AUTO_STYLE
    assert ColorFormatter.get_style_class(color_scheme) != Solarized256Style
    # We use TerminalFormatter for style fruity on Windows
    color_scheme = 'fruity'

# Generated at 2022-06-11 23:43:07.099137
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # simulated JSON response
    assert(ColorFormatter.get_lexer_for_body('application/json', '{}') == pygments.lexers.get_lexer_by_name('json'))
    # simulated JSON response with explicit JSON parameter
    assert (ColorFormatter.get_lexer_for_body('application/json', '{}', explicit_json=True) == pygments.lexers.get_lexer_by_name('json'))
    # simulated JSON response with wrong MIME type
    assert (ColorFormatter.get_lexer_for_body('text/plain', '{}', explicit_json=True) == pygments.lexers.get_lexer_by_name('json'))
    # simulated text response

# Generated at 2022-06-11 23:43:18.091779
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    expected_style = Solarized256Style
    class MockEnvironment():
        def __init__(self, colors=256):
            self.colors = colors
    env = MockEnvironment(256)

    color_formatter = ColorFormatter(env, AUTO_STYLE)
    assert isinstance(color_formatter.formatter, Terminal256Formatter)
    assert color_formatter.formatter.style == expected_style
    env.colors = 0
    color_formatter = ColorFormatter(env, AUTO_STYLE)
    assert not isinstance(color_formatter.formatter, Terminal256Formatter)
    color_formatter = ColorFormatter(env, SOLARIZED_STYLE)
    assert isinstance(color_formatter.formatter, Terminal256Formatter)
    assert color_formatter.formatter

# Generated at 2022-06-11 23:43:28.917248
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token

    lexer = SimplifiedHTTPLexer()
    # Request-Line
    tokens = list(lexer.get_tokens('GET / HTTP/1.1'))
    assert [(Token.Name.Function, 'GET'),
            (Token.Text, ' '),
            (Token.Name.Namespace, '/'),
            (Token.Text, ' '),
            (Token.Keyword.Reserved, 'HTTP'),
            (Token.Operator, '/'),
            (Token.Number, '1.1')] == tokens
    # Response Status-Line
    tokens = list(lexer.get_tokens('HTTP/1.1 200 OK'))

# Generated at 2022-06-11 23:43:38.205017
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import io
    import httpie.input
    import httpie.output

    body = """\
    {
        "name": "John Doe",
        "age": 43,
        "children": [
            {
                "name": "Jane Doe",
                "age": 12
            },
            {
                "name": "Jim Doe",
                "age": 10
            }
        ]
    }
    """

# Generated at 2022-06-11 23:43:49.438841
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.formatters import JSONFormatter
    ColorFormatter.format_headers()

# Generated at 2022-06-11 23:43:59.046043
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color = ColorFormatter(
        Environment(
            color_scheme=SOLARIZED_STYLE,
            colors=256,
        ),
        explicit_json='True',
        color_scheme=SOLARIZED_STYLE,
    )
    mime_json = 'application/json'
    mime_js = 'application/javascript'
    mime_html = 'text/html'
    mime_plain = 'text/plain'
    body_json = '{"title": "some JSON"}'
    body_js = 'var x = {"title": "some JS"};'
    body_html = '<html><title>a title</title>some body</html>'
    body_plain = 'some plain text'

# Generated at 2022-06-11 23:44:05.307148
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(None) is Solarized256Style
    assert ColorFormatter.get_style_class("") is Solarized256Style
    assert ColorFormatter.get_style_class("solarized") is Solarized256Style
    assert ColorFormatter.get_style_class("xterm") is pygments.styles.xterm
    assert ColorFormatter.get_style_class("not-existent") is Solarized256Style
    assert ColorFormatter.get_style_class("auto") is Solarized256Style

# Generated at 2022-06-11 23:44:15.204610
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Arrange 
    from httpie.output.streams import CustomBytesIO
    env = Environment()
    env.stdout = CustomBytesIO()
    env.stdout_isatty = True
    env.colors = 256
    color = ColorFormatter(env)
    # Act
    actualResult = color.format_body('[1, 2, 3]', 'application/json')
    # Assert

# Generated at 2022-06-11 23:44:15.676548
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    pass

# Generated at 2022-06-11 23:44:25.138116
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style
    assert ColorFormatter.get_style_class('monokai') is pygments.styles.get_style_by_name('monokai')
    assert ColorFormatter.get_style_class('fruity') is pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('auto') is pygments.styles.get_style_by_name('monokai')
    env = Environment(colors=256)
    formatter = ColorFormatter(env=env, color_scheme=DEFAULT_STYLE)
    assert isinstance(formatter.formatter, Terminal256Formatter)
    assert formatter.formatter.style is pygments.styles.get_style_by_

# Generated at 2022-06-11 23:44:27.305095
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(color_scheme='solarized') == Solarized256Style

# Generated at 2022-06-11 23:44:37.897184
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import re
    import pygments.token

    # Request-Line
    pattern = re.compile(r'([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)')
    match = pattern.match('GET / HTTP/1.1')
    assert match[0] == 'GET / HTTP/1.1'
    assert match[1] == match[5] == 'HTTP'
    assert match[7] == '1.1'
    assert ' '.join(match.groups()) == 'GET / HTTP/1.1'
    assert pygments.token.Name.Function in match.groupdict()

    # Response Status-Line
    pattern = re.compile(r'(HTTP)(/)(\d+\.\d+)( +)(\d{3})( +)(.+)')


# Generated at 2022-06-11 23:44:40.265809
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class FakeEnv():
        colors = 256
        style = 'solarized'

    env = FakeEnv()
    color = ColorFormatter(env)

# Generated at 2022-06-11 23:44:50.802005
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from io import StringIO
    inputs = [
        ('application/json', '{"a":1}'),
        ('text/plain', 'plain text\n'),
        ('text/vnd.foo', 'bar bar\n'),
        ('text/vnd.foo+json', '{"b":2}\n'),
        ('', '{"c":3}\n'),
        ('text/vnd.foo+json', '<html><body>Content</body></html>'),
        ('application/hal+json', """\
{
    "_links": {
        "self": {
            "href": "http://example.com/"
        }
    },
    "foo": "bar"
}
"""),
    ]

# Generated at 2022-06-11 23:45:16.680853
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert ColorFormatter.get_lexer_for_body('text/html', None) is not None
    assert ColorFormatter.get_lexer_for_body('text/html+django', None) is not None
    assert ColorFormatter.get_lexer_for_body('foo/html+django', None) is not None
    assert ColorFormatter.get_lexer_for_body('application/json', None) is not None
    assert ColorFormatter.get_lexer_for_body('foo/bar', None) is None


# Generated at 2022-06-11 23:45:20.920999
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import requests
    content_type, r = requests.get('https://httpie.org/')
    class env:
        colors = True
    cf = ColorFormatter(env=env,explicit_json=False,color_scheme='solarized')
    print(cf.format_body(r.text,content_type))

# Generated at 2022-06-11 23:45:32.151620
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(None)
    mime = 'text/html'
    body = '<html>\n  <head>\n    <title>Test</title>\n  </head>\n</html>'
    result = color_formatter.format_body(body, mime)

# Generated at 2022-06-11 23:45:39.347994
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import sys
    sys.path.append("../")
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.core import main as httpie
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.compat import is_windows
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.builtin import JSONFormatter
    #sys.argv = ["http","post","localhost:8000","Content-Type:application/json",'{"name": "john", "age": 23}']
    #httpie()

# Generated at 2022-06-11 23:45:42.155744
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    formatter = ColorFormatter(env=env)
    assert formatter.explicit_json is False
    assert formatter.color_scheme is DEFAULT_STYLE

# Generated at 2022-06-11 23:45:53.895460
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import json
    import pygments.lexers
    import httpie.formatter.colors

    def test_mime(mime, body, lexer):
        lexer = lexer or pygments.lexers.TextLexer
        actual = httpie.formatter.colors.get_lexer_for_body(mime, body)
        assert isinstance(actual, lexer)

    # Body is empty
    test_mime('text/plain', '', pygments.lexers.TextLexer)

    # Content-Type is unknown
    test_mime('text/unknown', '', pygments.lexers.TextLexer)

    # Content-Type is plain/text or text/unknown, but body is JSON

# Generated at 2022-06-11 23:46:01.017739
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    class HttpLexer(SimplifiedHTTPLexer):
        # a simplified version of pygment http lexer
        # only use one kind of tokens
        tokens = {'root': []}


    lexer = HttpLexer()
    formatter = Terminal256Formatter()

# Generated at 2022-06-11 23:46:04.400744
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment({
        'colors': 'auto'
    })
    _ = ColorFormatter(env, explicit_json=False, color_scheme='auto')

# Unit tests for get_lexer_for_body(self, mime: str, body: str)

# Generated at 2022-06-11 23:46:14.304773
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.formatter.colors import ColorFormatter
    from httpie.compat import is_windows
    if is_windows:
        solarized_style = 'fruity'
    else:
        solarized_style = 'solarized'

    cf = ColorFormatter(
        env=Environment(),
        color_scheme=solarized_style
    )
    text = '{"a":1}'

    # json
    assert cf.format_body(mime='application/json', body=text)
    assert cf.format_body(mime='text/json', body=text)

    # xml
    assert cf.format_body(mime='application/xml', body='<a>1</a>')

# Generated at 2022-06-11 23:46:22.724748
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    formatterPluginManager = FormatterPluginManager()
    formatterPluginManager.read_config()
    colorFormatter = ColorFormatter(env=formatterPluginManager.env)
    headers = colorFormatter.format_headers(headers="""
    GET / HTTP/1.1
    Host: httpbin.org
    Accept-Encoding: gzip, deflate, compress
    Accept: */*
    User-Agent: HTTPie/0.9.9
    Accept-Encoding: gzip
    """)