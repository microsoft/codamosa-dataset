

# Generated at 2022-06-11 23:37:56.979811
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', True) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('text/plain', True, body='{}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('text/plain', True, body='foo bar baz') is None

# Generated at 2022-06-11 23:38:07.730879
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class MockEnvironment:
        colors = 256
        style = SOLARIZED_STYLE

    from httpie.output.streams import StdoutBytesIO
    from httpie.output.formatter import format_headers
    from httpie.compat import str


# Generated at 2022-06-11 23:38:16.873567
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest

    f = ColorFormatter(Environment(), color_scheme=DEFAULT_STYLE)

    # no lexer for application/json
    body = '{"foo": "bar"}'
    mime = 'application/json'
    result = f.format_body(body, mime)
    assert result == body
    # json (explicit)
    body = '{"foo": "bar"}'
    mime = 'application/something'
    result = f.format_body(body, mime)
    assert result == body

# Generated at 2022-06-11 23:38:26.372781
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert list(SimplifiedHTTPLexer().get_tokens('GET / HTTP/1.1')) == [
        (pygments.token.Name.Function, 'GET'),
        (pygments.token.Text, ' '),
        (pygments.token.Name.Namespace, '/'),
        (pygments.token.Text, ' '),
        (pygments.token.Keyword.Reserved, 'HTTP'),
        (pygments.token.Operator, '/'),
        (pygments.token.Number, '1.1'),
        (pygments.token.Text, '\n')
    ]


# Generated at 2022-06-11 23:38:37.583688
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.context import Environment
    from httpie.plugins import PluginManager

    env = Environment(colors=256)
    pm = PluginManager(env)
    formatter = ColorFormatter(env)

    # --form=colors
    pm.init_formatters()
    assert formatter.should_enable_for_output_mode('cli') == True
    assert formatter.should_enable_for_output_mode('json') == False

    # --form=colors --json
    env.formatter = 'colors'
    env.explicit_json = True
    pm.init_formatters()

    assert formatter.should_enable_for_output_mode('cli') == False
    assert formatter.should_enable_for_output_mode('json')

# Generated at 2022-06-11 23:38:44.906083
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("nonexisting").__name__ == pygments.styles.get_style_by_name("default").__name__
    assert ColorFormatter.get_style_class("default").__name__ == pygments.styles.get_style_by_name("default").__name__
    assert ColorFormatter.get_style_class("solarized").__name__ == pygments.styles.get_style_by_name("solarized").__name__
    assert ColorFormatter.get_style_class("auto").__name__ == pygments.styles.get_style_by_name("default").__name__

# Generated at 2022-06-11 23:38:53.764881
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(
        'text/plain',
        False,
    ) is None

    assert get_lexer(
        'text/html',
        False,
    ) == pygments.lexers.HtmlLexer

    assert get_lexer(
        'application/json',
        False,
        body='{}',
    ) == pygments.lexers.JsonLexer

    assert get_lexer(
        'text/plain',
        True,
        body='{}',
    ) == pygments.lexers.JsonLexer

    assert get_lexer(
        'application/javascript',
        False,
    ) == pygments.lexers.JavascriptLexer

    assert get_lexer(
        'application/x-javascript',
        False,
    ) == pygments.lexers

# Generated at 2022-06-11 23:39:04.761056
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.cli.argtypes import s_mime_type
    from httpie.context import Environment
    from httpie.plugins import PluginManager

    text = '''
    {
        "string": "string",
        "number": 1, // comment
        "boolean": true,
        "null": null
    }
    '''
    color_formatter = ColorFormatter(
        explicit_json = False,
        color_scheme = 'solarized',
        env = Environment(colors = 256, plugins = PluginManager()),
    )

    assert len(color_formatter.format_body(
        body = text, mime = s_mime_type.validate('application/json')
    )) > len(text)

# Generated at 2022-06-11 23:39:17.294184
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment())
    assert formatter.get_lexer_for_body("application/json", "") is None
    assert formatter.get_lexer_for_body("application/json", '{"key": "value"}').__name__ == "JSONLexer"
    assert formatter.get_lexer_for_body("application/geo+json", '{"key": "value"}').__name__ == "JSONLexer"
    assert formatter.get_lexer_for_body("application/geo+json+html", '{"key": "value"}').__name__ == "JSONLexer"
    assert formatter.get_lexer_for_body("application/postscript", "ps").__name__ == "PostScriptLexer"

# Generated at 2022-06-11 23:39:22.242235
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie import ExitStatus
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from utils import http, HTTP_OK
    env = Environment()
    r = http('--print=H', '--headers', env=env, error_exit_ok=True)
    assert r.exit_status == ExitStatus.OK
    assert HTTP_OK in r
    assert BINARY_SUPPRESSED_NOTICE.decode() not in r

# Generated at 2022-06-11 23:39:33.859329
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) is Solarized256Style

# Generated at 2022-06-11 23:39:44.274207
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    from httpie.compat import is_py38

    env = Environment(
        colors=256,
        stdin=None,
        stdin_isatty=False,
        stdout=None,
        stdout_isatty=True,
    )

    # not a json
    body = "hello world"
    mime = "text/html"
    color_formatter = ColorFormatter(env=env, explicit_json=False)
    assert color_formatter.format_body(
        body=body, mime=mime) == "hello world"

    # text/html but is a json
    body = '{"hello world": "sentence"}'
    mime = "text/html"
    color_formatter = ColorFormatter(env=env, explicit_json=False)
   

# Generated at 2022-06-11 23:39:54.688458
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import os
    import sys
    import pytest
    env = Environment()
    cf = ColorFormatter(env)
    if sys.platform == 'win32':
        assert cf.formatter.__class__.__name__ == 'TerminalFormatter'
    else:
        assert cf.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert cf.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    #assert cf.get_lexer_for_body('foo/bar', 'response body') is None
    with pytest.raises(ClassNotFound):
        assert cf.get_style_class('foo')
    assert cf.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-11 23:40:07.271855
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import urlparse
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPBasicAuth

    import os.path

    from pygments.lexers import get_lexer_for_mimetype

    import tempfile

    environment = {
        'colors': 256,
        'format': 'colors'
    }
    input_dir_path = os.path.dirname(os.path.realpath(__file__)) + os.path.sep
    input_file_name = 'input.txt'
    input_file_path = input_dir_path + input_file_name


# Generated at 2022-06-11 23:40:09.262703
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

test_SimplifiedHTTPLexer()

# Generated at 2022-06-11 23:40:20.773582
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import io
    import sys

    # check_env.python_implementation
    # check_env.is_windows
    class env:
        colors = True

    class test_color_formatter(ColorFormatter):
        def __init__(self, env):
            self.env = env

        def format_headers(self, headers: str) -> str:
            return headers

    lf = test_color_formatter(env)
    headers = lf.format_headers('HTTP/1.1 200 OK\r\nConnection: close\r\nContent-Length: 0\r\n')

    if sys.version_info < (3, 2):
        headers = headers.decode('utf-8')


# Generated at 2022-06-11 23:40:33.015625
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=True)
    color_formatter = ColorFormatter(env=env)
    headers = '''\
HTTP/1.1 200 OK
content-type: application/json
content-length: 155
connection: keep-alive
date: Mon, 25 Dec 2017 11:12:31 GMT
etag: "b6ccec6bcd1e41846e25cc9c19dcfbd5"
last-modified: Thu, 14 Dec 2017 12:13:03 GMT
server: nginx/1.9.9
x-powered-by: PHP/5.5.9-1ubuntu4.23'''

# Generated at 2022-06-11 23:40:34.900278
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    mock = Environment(colors=256)
    color_formatter = ColorFormatter(mock, body='')
    assert color_formatter.format_body('{"foo":"bar"}', "application/json")

# Generated at 2022-06-11 23:40:47.555899
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(Environment(), explicit_json=False, color_scheme='solarized')
    headers = '''foo: bar\r
:\r
baz: qux\r
'''

    headers_out = formatter.format_headers(headers)
    assert headers_out == '\x1b[33;1mfoo\x1b[39;22m\x1b[37m: \x1b[39m\x1b[36mbar\x1b[39m\r\n\x1b[37m:\r\n\x1b[33;1mbaz\x1b[39;22m\x1b[37m: \x1b[39m\x1b[36mqux\x1b[39m\r\n'

# Generated at 2022-06-11 23:40:58.982399
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(style=Solarized256Style)

# Generated at 2022-06-11 23:41:13.977441
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    env = Environment()
    assert(ColorFormatter(env).enabled)

    env = Environment(colors=False)
    assert(not ColorFormatter(env).enabled)

    env = Environment(colors=256)
    assert(isinstance(ColorFormatter(env).http_lexer,SimplifiedHTTPLexer))

# Generated at 2022-06-11 23:41:21.315996
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class DummyEnvironment(object):
        def __init__(self, colors):
            self.colors = colors
    env = DummyEnvironment(True)
    # create ColorFormatter with default arguments
    cf = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    headers = 'GET / HTTP/1.1\r\nHost: www.google.com\r\n'
    payload = cf.format_headers(headers)
    assert '\x1b[35m' in payload


if __name__ == '__main__':
    test_ColorFormatter()

# Generated at 2022-06-11 23:41:25.082088
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    """
    assert that if color_scheme is not auto
    and we have enough colors, then style is
    set to 256.
    """
    color_scheme = 'monokai'
    style = ColorFormatter(Environment(),
                           color_scheme=color_scheme).get_style_class(color_scheme)
    assert style == pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-11 23:41:28.402248
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']


# Generated at 2022-06-11 23:41:32.340327
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert isinstance(formatter, ColorFormatter)

# Generated at 2022-06-11 23:41:41.156179
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    try:
        import pytest
    except ImportError:
        raise ImportError(
            "The pytest-httpie unit test requires pytest. "
            "See https://github.com/pytest-dev/pytest"
        )
    from pytest_httpie.plugin import parse_items

    source = """\
GET / HTTP/1.1
Host: example.org
Accept: */*

HTTP/1.1 200 OK
Content-Type: text/plain
Content-Length: 13

Hello, world!
""".splitlines(keepends=True)

    http_lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-11 23:41:48.813905
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    c = ColorFormatter(Environment(), color_scheme=AUTO_STYLE)
    assert c.color_scheme == AUTO_STYLE
    assert c.formatter.__class__ == TerminalFormatter
    assert c.http_lexer.__class__ == PygmentsHttpLexer

    c = ColorFormatter(Environment(colors=256), color_scheme=AUTO_STYLE)
    assert c.color_scheme == AUTO_STYLE
    assert c.formatter.__class__ == Terminal256Formatter
    assert c.http_lexer.__class__ == SimplifiedHTTPLexer

    c = ColorFormatter(Environment(), color_scheme=SOLARIZED_STYLE)
    assert c.color_scheme == SOLARIZED_STYLE

# Generated at 2022-06-11 23:41:55.978536
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    lexer = ColorFormatter.get_lexer_for_body("image/jpeg", "binary data")
    assert lexer == None
    lexer = ColorFormatter.get_lexer_for_body("application/json", "binary data")
    assert lexer.name == "JSON"
    lexer = ColorFormatter.get_lexer_for_body("application/javascript", "binary data")
    assert lexer.name == "JavaScript"

# Generated at 2022-06-11 23:42:06.905775
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie import ExitStatus

    session = {
        'auto_auth': False,
        'exit_status': ExitStatus.OK,
        'follow_redirects': True,
        'headers': {},
        'history': [],
        'iter_content': None,
        'iter_lines': None,
        'json': None,
        'method': 'GET',
        'stream': None,
        'url': 'http://example.org',
        'verify': True,
    }

    def http(method=None, url=None):
        return session

    env = Environment(colors=256)

    formatter = ColorFormatter(env=env, explicit_json=False, color_scheme='solarized')

    assert formatter.explicit_json is False

# Generated at 2022-06-11 23:42:17.026735
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimHTTPLexer = SimplifiedHTTPLexer()
    assert SimHTTPLexer.name == 'HTTP'
    assert SimHTTPLexer.aliases == ['http']
    assert SimHTTPLexer.filenames == ['*.http']

# Generated at 2022-06-11 23:42:46.235715
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Type: (FormatterPlugin) -> None
    """ Test for format_headers in class ColorFormatter"""
    from httpie.formatters import JSONFormatter, BaseFormatter
    from httpie.formatters.colors import ColorFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins import Plugin
    import pytest
    import json
    
    env = Environment()
    lexer = ColorFormatter(env, explicit_json=False, color_scheme='fruity')
    env.stdout = pytest.stdout = open("httpie_help.txt", "w") 
    assert(lexer.format_headers("200 OK") == "200 OK")
    
    env.stdout = pytest.stdout

# Generated at 2022-06-11 23:42:56.797850
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    """Test lexer resolution for various mime types."""

# Generated at 2022-06-11 23:42:57.849716
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():                                            # noqa
    assert True

# Generated at 2022-06-11 23:42:59.696323
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class(SOLARIZED_STYLE)
    assert style is Solarized256Style

# Generated at 2022-06-11 23:43:11.116218
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    content = '''
    HTTP/1.0 200 OK\r
    cache-control: no-cache, private\r
    content-type: application/json; charset=UTF-8\r
    date: Sun, 20 Nov 2016 00:18:29 GMT\r
    server: webfs/1.21\r
    status: 200\r
    transfer-encoding: Identity\r
    \r
    { "id": 1, "name": "A green door", "price": 12.50, "tags": ["home", "green"] }\r
    '''
    print(pygments.highlight(code=content, lexer=SimplifiedHTTPLexer(), formatter=TerminalFormatter()))

# Generated at 2022-06-11 23:43:21.418905
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin, get_plugin_manager
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.utils import get_response_info_and_headers, \
        get_response_headers
    from httpie.context import Environment
    from PyInquirer import style_from_dict, Token
    import pygments.lexers.special
    import pygments.lexers as lexers

    def convert_style_to_pygments(style_dict):
        """
        Converts style_dict format to pygments format.
        """
        pygments_style_dict = {}
        for token, value in style_dict.items():
            if isinstance(value, dict):
                value = convert_style_to_pygments(value)

# Generated at 2022-06-11 23:43:31.883616
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)
    body = '{"name": "Foo", "age": 18}'
    assert color_formatter.get_lexer_for_body('text/html', body) is None
    assert color_formatter.get_lexer_for_body('application/json', body).name == 'JSON'
    assert color_formatter.get_lexer_for_body('text/x-java', body) is None
    assert color_formatter.get_lexer_for_body('text/x-java', body) is None
    assert color_formatter.get_lexer_for_body('text/javascript', body).name == 'JSON'
    assert color_formatter.get_lexer_for_body

# Generated at 2022-06-11 23:43:37.520628
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Test for method format_body of class ColorFormatter
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    env = Environment()
    env.colors = 256
    color_scheme = 'solarized'
    ColorFormatter(env, color_scheme)
    assert ColorFormatter.format_body(ColorFormatter, '', 'application/json') == ''

# Generated at 2022-06-11 23:43:47.156962
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie import output
    import pygments.lexers.text
    output.formats['terminal'] = output.TerminalFormatter()
    output.colors = 256 if not is_windows else True
    output.colors = True

    env = Environment()
    env.colors = True
    #  env.stream = sys.stdout

    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    # formatter.format_body("test", "text/plain")
    formatter.formatter.format("test", pygments.lexers.text.TextLexer())

# Generated at 2022-06-11 23:43:49.183568
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter({}, 'solarized')
    assert color_formatter.formatter == Terminal256Formatter(solarized256)

# Generated at 2022-06-11 23:44:15.573771
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    from fixtures import (
        COLOR, JSON_HEADERS
    )
    example_headers = open(JSON_HEADERS).read()
    #headers = b'GET / HTTP/1.1\r\nContent-Type: application/json\r\n\r\n'
    env = Environment(colors=256)
    r = http('--pretty=all', 'GET', COLOR, env=env, error_exit_ok=True)
    assert HTTP_OK in r
    assert '[31m' not in r
    assert r.exit_status == ExitStatus.OK

# Generated at 2022-06-11 23:44:25.137282
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment, EnvironmentType
    from httpie.formatter import Formatter, CONTENT_TYPE_JSON

    # Set up HTTPie environment

# Generated at 2022-06-11 23:44:33.024342
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    expected = '\x1b[38;5;245mGET / HTTP/1.1\r\n\x1b[39m\x1b[38;5;145mHost: localhost\r\n\x1b[39m\x1b[38;5;145mUser-Agent: HTTPie/0.9.2\r\n\x1b[39m\x1b[38;5;145mAccept-Encoding: gzip, deflate\r\n\x1b[39m\x1b[38;5;145mAccept: application/json\r\n\x1b[39m\x1b[38;5;145mConnection: keep-alive\r\n\x1b[39m\x1b[38;5;145m\x1b[39m'

# Generated at 2022-06-11 23:44:39.260365
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    # Test constructor call
    s = ColorFormatter(env=Environment(), color_scheme='solarized')
    assert s.enabled == True

    # Test fails due to not valid color_scheme
    try:
        s = ColorFormatter(env=Environment(), color_scheme='blabla')
        assert False
    except:
        assert True


# Generated at 2022-06-11 23:44:44.767171
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    result = ColorFormatter.get_style_class('manni')
    assert result == pygments.styles.get_style_by_name('manni')
    assert result != pygments.styles.get_style_by_name('solarized')
    assert result != pygments.styles.get_style_by_name(AUTO_STYLE)
    assert result != Solarized256Style

# Generated at 2022-06-11 23:44:53.766977
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import os
    import sys
    import pygments
    from httpie.output.formatters import BaseFormatter
    from . import mock

    env = mock.Environment()
    formatter = BaseFormatter(env=env)
    color_formatter = ColorFormatter(env=env)
    text_lexer = pygments.lexers.get_lexer_by_name('text')
    text_formatter = pygments.formatters.Terminal256Formatter(
        style=pygments.styles.get_style_by_name('solarized')
    )
    os.environ["HTTPIE_COLORS"] = "1"


# Generated at 2022-06-11 23:45:04.326106
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin import BuiltinPlugin


# Generated at 2022-06-11 23:45:14.498715
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.core import DEFAULT_UA
    from httpie.context import Environment
    from httpie.output.streams import output_stream
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.core import main as httpie_core_main
    from httpie._main import main as httpie_main
    import inspect
    import sys

    def get_compact_json_formatter(output_stream=None):
        env = Environment(colors=256)
        
        if (not is_windows) and output_stream is None:
            output_stream = sys.stdout

        # Required to avoid error msg in method format_body of class FormatterBase, 
        #   which is called by ColorFormatter.

# Generated at 2022-06-11 23:45:21.503347
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    env.colors = 1
    color_formatter = ColorFormatter(env)
    headers = color_formatter.format_headers("""GET /api/v1/users/ HTTP/1.1
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: 127.0.0.1:8000
Referer: http://127.0.0.1:8000/api/v1/
User-Agent: HTTPie/0.9.3

""")

# Generated at 2022-06-11 23:45:32.529940
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from httpie.plugins.colors.formatter import SimplifiedHTTPLexer
    lexer = SimplifiedHTTPLexer()
    tokens = lexer.get_tokens("GET / HTTP/1.1")
    assert len(tokens) == 11
    # Function
    assert tokens[0][0] == Token.Name.Function
    assert tokens[0][1] == 'GET'
    # Text
    assert tokens[1][0] == Token.Text
    assert tokens[1][1] == ' '
    # Namespace
    assert tokens[2][0] == Token.Name.Namespace
    assert tokens[2][1] == '/'
    # Text
    assert tokens[3][0] == Token.Text
    assert tokens[3][1] == ' '
   

# Generated at 2022-06-11 23:46:19.824848
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(explicit_json=True, color_scheme='solarized')
    assert color_formatter.explicit_json == True
    assert color_formatter.formatter.style == Solarized256Style
    assert color_formatter.http_lexer == SimplifiedHTTPLexer

# Generated at 2022-06-11 23:46:22.276426
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # style is valid
    assert ColorFormatter.get_style_class('monokai')
    # style is invalid, Solarized256Style should be returned
    assert ColorFormatter.get_style_class('invalid') == Solarized256Style

# Generated at 2022-06-11 23:46:28.896092
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_name = 'monokai'
    assert(ColorFormatter.get_style_class(style_name)
           == pygments.styles.get_style_by_name(style_name))
    style_name = 'solarized'
    assert(ColorFormatter.get_style_class(style_name)
           == Solarized256Style)
    style_name = 'auto'
    assert(ColorFormatter.get_style_class(style_name)
           == pygments.styles.get_style_by_name(style_name))

# Generated at 2022-06-11 23:46:38.068020
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.input import SEP_CREDENTIALS
    from httpie.plugins import plugin_manager
    from httpie.compat import urlparse
    from httpie.context import Environment
    from httpie.output.streams import less_styled_writer
    from httpie.streams import UnsupportedResponseEncoding
    from httpie.utils import get_unicode

    class Response(object):
        def __init__(self, headers=None, content=None, encoding=None):
            self.headers = headers or {}
            self.raw = content or ''
            self.encoding = encoding

        @property
        def url(self):
            return urlparse(self.url_str)

        @property
        def content(self):
            if self.encoding is None:
                return self.raw

# Generated at 2022-06-11 23:46:48.423826
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-11 23:46:50.164181
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity') is pygments.styles.FruityStyle

# Generated at 2022-06-11 23:46:51.649406
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    if lexer == None:
        return False
    return True

# Generated at 2022-06-11 23:46:58.004717
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    electric_test_case_template = '\r''\n\r\n\r\n\r\n'
    electric_test_case_template += '\x1b[38;5;201m'
    electric_test_case_template += 'a b c d e f\n'
    electric_test_case_template += 'g h i j k l\n'
    electric_test_case_template += 'm n o p q r\n'
    electric_test_case_template += 's t u v w x\n'
    electric_test_case_template += '\x1b[39m'

    formatter = ColorFormatter(Environment(colors=256))

# Generated at 2022-06-11 23:47:00.616751
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter('\x1b[39m') == '\x1b[39m'
    
test_ColorFormatter()

# Generated at 2022-06-11 23:47:04.796098
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(None, None, None)
    formatter.enabled = False
    formatter.explicit_json = False
    formatter.formatter = TerminalFormatter()
    formatter.http_lexer = SimplifiedHTTPLexer()
    return formatter