

# Generated at 2022-06-11 23:37:47.891058
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.core import main
    main(['--style=auto'])

# Generated at 2022-06-11 23:37:49.784832
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('manni') == pygments.styles.get_style_by_name('manni')

# Generated at 2022-06-11 23:37:54.439113
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter(None, color_scheme="solarized256").get_style_class("solarized256") == Solarized256Style
    assert ColorFormatter(None, color_scheme="auto").get_style_class("auto") == Solarized256Style
    assert ColorFormatter(None, color_scheme="abc").get_style_class("abc") == Solarized256Style

# Generated at 2022-06-11 23:38:06.153352
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie import ExitStatus
    from utils import TestEnvironment, http
    ColorFormatter.group_name = 'test_ColorFormatter_format_headers'

    env = TestEnvironment(colors=256, stdin_isatty=True)
    r = http('--print=H', env=env)
    assert r.exit_status == ExitStatus.OK
    assert 'HTTP/1.1' in r
    assert '\x1b[1;44mGET' in r
    assert '\x1b[1;44mAccept:' in r
    assert '\x1b[1;44mAccept-Encoding:' in r
    assert '\x1b[1;44mContent-Length:' not in r
    assert '\x1b[1;44mContent-Type:' not in r


# Generated at 2022-06-11 23:38:11.354316
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=1)
    formatter = ColorFormatter(env)
    text = "HTTP/1.0 200 Ok\r\n\r\n"
    result = "[1m[34mHTTP/[0m[1m[34m1.0[0m[0m [1m[34m200[0m[0m [1m[32mOk[0m\r\n"
    assert result == formatter.format_headers(text)


# Generated at 2022-06-11 23:38:19.004654
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from unittest import mock
    import httpie.formatters.colors as colors
    from httpie.context import Environment
    import pygments.formatters
    import pygments.lexers
    import pygments.styles

    formatter = colors.ColorFormatter(
        env=Environment(stdout_isatty=True, colors=256)
    )

    with mock.patch.object(
        pygments.lexers, 'get_lexer_for_mimetype',
        return_value=pygments.lexers.get_lexer_by_name('json')
    ):
        body = """
        {
            name: "httpie"
        }
        """
        httpie_body = formatter.format_body(body, 'application/json')
        assert httpie_body == body

# Generated at 2022-06-11 23:38:27.868578
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    def check(mime, body, expected):
        actual = ColorFormatter(
            Environment(colors=256),
            color_scheme='test',
            explicit_json=False,
        ).format_body(body, mime)
        if actual != expected:
            raise Exception(f'\n{actual}{expected}')

    # Test with mime type and body, expected result
    check('application/json', '{}', '{}')
    check('application/json', '{"a": 1}', '{\033[38;5;28;01m"a"\033[39;00m: 1}')
    check('application/json+yaml', '- a', '- \033[38;5;28;01m"a"\033[39;00m')

# Generated at 2022-06-11 23:38:39.250578
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.formatter import get_lexer_for_body
    from pygments.lexers import get_lexer_by_name
    from httpie.compat import is_windows

    # tests cases

# Generated at 2022-06-11 23:38:45.109461
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main
    from httpie import ExitStatus

    args = ['-p', 'hb', 'httpbin.org/headers']
    env = Environment()
    r = main(args=args, env=env)
    assert r.exit_status == ExitStatus.OK
    assert r.format

# Generated at 2022-06-11 23:38:53.866824
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(None)

    # TODO: BODY is a string, not bytes (http://github.com/jkbrzt/httpie/issues#issue/2)
    body = "mystring"
    response_json_mime_type = 'application/json'

    lexer = color_formatter.get_lexer_for_body(response_json_mime_type, body)
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    response_csv_mime_type = 'text/csv'

    lexer = color_formatter.get_lexer_for_body(response_csv_mime_type, body)
    assert lexer == pygments.lexers.get_lexer_by_name('text')

    response_csv

# Generated at 2022-06-11 23:39:04.560621
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
  class Env:
      colors = 256
  env = Env()
  cf = ColorFormatter(env, explicit_json=False, color_scheme=SOLARIZED_STYLE)

# Generated at 2022-06-11 23:39:16.825590
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    code = 'GET / HTTP/1.1'
    assert pygments.highlight(code, lexer, Terminal256Formatter()).strip() == '\x1b[38;5;111mGET\x1b[39m\x1b[38;5;111m \x1b[39m\x1b[38;5;102m/\x1b[39m\x1b[38;5;111m \x1b[39m\x1b[38;5;114mHTTP\x1b[39m\x1b[38;5;114m/\x1b[39m\x1b[38;5;111m1.1\x1b[39m\x1b[39m'

# Generated at 2022-06-11 23:39:18.558916
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')

# Generated at 2022-06-11 23:39:30.087483
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_preferred_encoding
    from httpie.compat import is_windows

    env = FormatterPlugin.create_environment(stdin=None, stdout=None, stderr=None,
                                             is_windows=False, stdout_isatty=True,
                                             stderr_isatty=True)

    # Test --style solarized
    processor = ColorFormatter(env=env, color_scheme='solarized')
    style_class = processor.get_style_class('solarized')
    assert issubclass(style_class, pygments.style.Style)
    assert style_class.__name__ == 'Solarized256Style'

    # Test --style auto

# Generated at 2022-06-11 23:39:42.329844
# Unit test for function get_lexer
def test_get_lexer():
    # Test: returns None for unknown mime.
    assert get_lexer('application/x-httpie') is None
    # Test: returns None for unknown mime with unknown lexer.
    assert get_lexer('application/x-httpie') is None
    assert get_lexer('application/x-httpie2') is None
    # Test: returns None for text/plain.
    assert get_lexer('text/plain') is None
    # Test: returns json lexer.
    assert get_lexer('application/json') is not None
    assert 'json' in get_lexer('application/json').aliases
    # Test: returns json lexer even when application/x-json.
    assert get_lexer('application/x-json') is not None

# Generated at 2022-06-11 23:39:53.412005
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment, EnvironmentConfig
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    config = EnvironmentConfig()
    config.default_options['--print'] = 'hb'
    config.default_options['--style'] = 'solarized'
    config.default_options['--headers'] = ''
    env = Environment(config=config)

# Generated at 2022-06-11 23:39:54.661010
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert isinstance( '', str )

# Generated at 2022-06-11 23:40:07.226947
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    text = '''\
HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Content-Type: text/html; charset=UTF-8
Content-Length: 138
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
ETag: "3f80f-1b6-3e1cb03b"
Accept-Ranges: bytes
Connection: close

<html>
<head>
  <title>An Example Page</title>
</head>
<body>
  Hello World, this is a very simple HTML document.
</body>
</html>\
    '''
    tokens = lexer.get_tokens

# Generated at 2022-06-11 23:40:15.643490
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-11 23:40:23.834230
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.compat import is_windows

    env = Environment(None)
    color_formatter = ColorFormatter(env)

    # Test the default mode
    # Test the edge case of an empty body
    assert color_formatter.format_body('', 'text/plain') == ''
    # A body with type 'text/plain' should be colored
    assert color_formatter.format_body('{}', 'text/plain') == '{}'

    # Test the case where the explicit-json option is used
    color_formatter.explicit_json = True
    # A body with type 'text/plain' should NOT be colored
    assert color_formatter.format_body('{}', 'text/plain') == '{}'

    # Test the case where 'json' is part

# Generated at 2022-06-11 23:40:42.519920
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class FakeEnvironment(object):
        def __init__(self, colors=None):
            self.colors = colors

    class FakeWriter(object):
        pass

    class FakeWriterIsTTY(object):
        def isatty(self):
            return True

    # Testing with 256 colors (no `--style` option)
    env = FakeEnvironment(256)
    writer = FakeWriter()
    color_formatter = ColorFormatter(env, writer)
    assert color_formatter.formatter.__class__ == Terminal256Formatter

    # Testing with 256 colors and `--style=auto` option
    env = FakeEnvironment(256)
    writer = FakeWriter()
    color_formatter = ColorFormatter(env, writer, color_scheme=AUTO_STYLE)
    assert color_formatter.formatter.__class

# Generated at 2022-06-11 23:40:53.847200
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import urlopen
    from httpie.plugins import FormatterPlugin
    from httpie.compat import is_windows
    import pygments.lexers.imap
    import pygments.lexers.text
    import pygments.lexers.special
    import pygments.lexers.data
    import pygments.lexers.agile
    import pygments.lexers.bash
    import pygments.lexers.c_cpp
    import pygments.lexers.csharp
    import pygments.lexers.python
    import pygments.lexers.sql
    import pygments.lexers.go
    import pygments.lexers.ruby
    import pygments.lexers.haskell
    import pygments.lexers.xml
    import pygments.lexers.html
    import pygments.lexers.javascript

# Generated at 2022-06-11 23:41:05.925409
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    cf = ColorFormatter(env=Environment(colors=256), color_scheme="default", force_colors=False)
    assert "class=\"highlight\"" in cf.format_body(
        body='''<html>
        <head><title>test</title></head>
        <body>
        hello world
        </body>
        </html>''',
        mime="text/html"
    )
    assert "class=\"highlight\"" in cf.format_body(body='{"key": "hello world"}', mime="application/json")
    assert "class=\"highlight\"" not in cf.format_body(body="hello world", mime="text/plain")
    assert "class=\"highlight\"" in cf.format_body(body="hello world", mime="application/javascript")

# Generated at 2022-06-11 23:41:16.209342
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.core import main
    from httpie.plugins import builtin
    from httpie.context import Environment
    env = Environment()
    main.load_plugins(env)
    color_formatter = next(
        (f for f in builtin.plugin_manager.get_enabled(FormatterPlugin)
             if f.group_name == 'colors'),
        None
    )
    assert color_formatter is not None
    assert color_formatter.get_style_class('solarized') == Solarized256Style
    assert color_formatter.get_style_class('monokai') == \
        pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-11 23:41:24.830266
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Given
    raw_headers = [
        'HTTP/1.1 200 OK',
        'Content-Type: application/json',
        'Date: Thu, 11 Oct 2018 13:51:08 GMT',
        'Server: BaseHTTP/0.6 Python/3.7.2',
        'Content-Length: 2'
    ]
    # When
    headers = '\n'.join(raw_headers)
    body = '{}'
    response = [headers, body]
    # Then
    actual = ColorFormatter(Environment(colors=256)).format_body(body, response[0].split('\n')[1].split(' ')[1].split(':')[1].strip())

# Generated at 2022-06-11 23:41:29.717356
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == pygments.styles.solarized.SolarizedStyle
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.monokai.MonokaiStyle
    assert ColorFormatter.get_style_class(AUTO_STYLE) != Solarized256Style

# Generated at 2022-06-11 23:41:38.624822
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    tokens = list(lexer.get_tokens_unprocessed('GET / HTTP/1.1'))
    assert tokens == [
        (pygments.token.Name.Function, 'GET'),
        (pygments.token.Text, ' '),
        (pygments.token.Name.Namespace, '/'),
        (pygments.token.Text, ' '),
        (pygments.token.Keyword.Reserved, 'HTTP'),
        (pygments.token.Operator, '/'),
        (pygments.token.Number, '1.1')
    ]



# Generated at 2022-06-11 23:41:44.518719
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class TestColorFormatter(ColorFormatter):
        pass

    env = Environment()
    color_formatter = TestColorFormatter(env)
    assert color_formatter.format_headers("Content-Type: text/plain") == \
        '\x1b[1m\x1b[34mContent-Type\x1b[39;49;00m: \x1b[34mtext/plain\x1b[39;49;00m'

# Generated at 2022-06-11 23:41:54.182035
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert ColorFormatter.get_lexer_for_body(
        mime='application/json', explicit_json=False, body=''
    ) is None
    assert ColorFormatter.get_lexer_for_body(
        mime='application/json', explicit_json=False, body='{}'
    ) is not None
    assert ColorFormatter.get_lexer_for_body(
        mime='text/plain', explicit_json=False, body='{}'
    ) is None
    assert ColorFormatter.get_lexer_for_body(
        mime='text/plain', explicit_json=True, body='{}'
    ) is not None

# Generated at 2022-06-11 23:41:55.693260
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    ColorFormatter(Environment())

# Generated at 2022-06-11 23:42:07.482765
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('test_style') is None
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) is Solarized256Style

# Generated at 2022-06-11 23:42:16.129376
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def run(mime, body, lexer):
        formatter = ColorFormatter(Environment())
        assert formatter.get_lexer_for_body(mime, body) == lexer

    run('application/json', '', pygments.lexers.get_lexer_by_name('json'))
    run('application/json', '{}', pygments.lexers.get_lexer_by_name('json'))
    run('application/json+test', '{}', pygments.lexers.get_lexer_by_name('json'))
    run('application/json', '{}', pygments.lexers.get_lexer_by_name('json'))

# Generated at 2022-06-11 23:42:26.140890
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """
        It would be better if we test the lexer part directly
        but it's hard to do this because Pygments is very complicated.
        Then we just test the easy part here.
    """
    # Pygments HTML lexer support
    result = ColorFormatter.format_body(
        body='<html>body</html>',
        mime='text/html'
    )
    assert result == '<div class="highlight"><pre><span class="nt">&lt;html&gt;</span>body<span class="nt">&lt;/html&gt;</span>\n</pre></div>'
    # Pygments Markdown lexer support
    result = ColorFormatter.format_body(
        body='# title',
        mime='text/markdown'
    )

# Generated at 2022-06-11 23:42:34.736789
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    assert ColorFormatter(env).enabled == True

    assert ColorFormatter(env, colors=True).enabled == True
    assert ColorFormatter(env, colors=False).enabled == False
    assert ColorFormatter(env, colors=0).enabled == False
    assert ColorFormatter(env, colors=1).enabled == True

    env.colors = True
    assert ColorFormatter(env).enabled == True
    assert ColorFormatter(env, colors=True).enabled == True
    assert ColorFormatter(env, colors=False).enabled == False
    assert ColorFormatter(env, colors=0).enabled == False
    assert ColorFormatter(env, colors=1).enabled == True

    env.colors = False
    assert ColorFormatter(env).enabled == False
    assert ColorFormatter(env, colors=True).enabled

# Generated at 2022-06-11 23:42:36.784956
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(Environment(), False)
    assert color_formatter.enabled == True

# Generated at 2022-06-11 23:42:46.781255
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    testData = [
        # mime, body, result
        ('text/xml', '<root/>', 'XML'),
        ('image/jpg', '', None),
        ('text/xml', 'NOT XML', None),
        ('text/plain', 'NOT XML', 'Text only'),
        ('text/plain', '{"a": 1}', 'JSON'),
        ('text/plain', '{"a": 1}', 'JSON')
     ]
    for mime, body, result in testData:
        if result == 'JSON':
            assert get_lexer(mime, True, body) is not None

# Generated at 2022-06-11 23:42:57.342233
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter = ColorFormatter(Environment(True))
    input_headers = """\
HTTP/1.1 200 OK
Date: Wed, 20 Apr 2016 14:01:47 GMT
Server: Apache/2.4.7 (Ubuntu)
X-Powered-By: PHP/5.5.9-1ubuntu4.20
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true
Vary: Accept-Encoding
Content-Encoding: gzip
Content-Length: 153
Keep-Alive: timeout=5, max=100
Connection: Keep-Alive
Content-Type: text/html

"""

# Generated at 2022-06-11 23:43:04.523790
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # arrange
    env = Environment()
    env.colors = 256
    colFormatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)

    expected_result = '\x1b[38;5;51mHTTP123\x1b[0m\x1b[38;5;251m \x1b[0m\x1b[38;5;246mGET\x1b[0m\x1b[38;5;251m /xxx/xxx \x1b[0m\x1b[38;5;69mHTTP/1.1\x1b[0m'

    # act
    result = colFormatter.format_headers('HTTP123 GET /xxx/xxx HTTP/1.1')

    # assert
    assert expected_result == result

# Unit

# Generated at 2022-06-11 23:43:09.493307
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    lexer = pygments.lexers.get_lexer_by_name('http')
    formatter = pygments.formatters.Terminal256Formatter(
        style = pygments.styles.get_style_by_name('monokai'),
        bg = '#000000')

    code = 'GET / HTTP/1.1\r\nAccept: text/html\r\n\r\n'
    result = pygments.highlight(code, lexer, formatter).strip()

# Generated at 2022-06-11 23:43:19.811929
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

    assert lexer.name == "HTTP"
    assert lexer.aliases == ["http"]
    assert lexer.filenames == ["*.http"]
    assert lexer.tokens["root"][0] == (
        r'([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)',
        (
            pygments.token.Name.Function,
            pygments.token.Text,
            pygments.token.Name.Namespace,
            pygments.token.Text,
            pygments.token.Keyword.Reserved,
            pygments.token.Operator,
            pygments.token.Number
        )
    )

# Generated at 2022-06-11 23:43:53.191567
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Text content
    class FakeEnv:
        def __init__(self, colors=256):
            self.colors = colors

    color_formatter = ColorFormatter(FakeEnv(), False, False, False)
    # mime_type, body, should_be

# Generated at 2022-06-11 23:43:59.429617
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = True
    color_scheme = 'solarized'
    formatter = ColorFormatter(
        env, explicit_json, color_scheme
    )

    formatter.test_var = "test"

    assert formatter.explicit_json == explicit_json
    assert formatter.color_scheme == color_scheme

    assert repr(formatter) is not None
    assert str(formatter) is not None
    assert formatter.test_var == "test"



# Generated at 2022-06-11 23:44:05.847206
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import httpie.plugins
    httpie.plugins.colors.DEFAULT_STYLE = 'colorful'
    httpie.plugins.colors.Solarized256Style = Solarized256Style
    httpie.plugins.colors.PygmentsHttpLexer = SimplifiedHTTPLexer
    assert httpie.plugins.colors.ColorFormatter(None).format_headers('')
    assert httpie.plugins.colors.ColorFormatter(None).format_headers('\n')
    assert httpie.plugins.colors.ColorFormatter(None).format_headers('\n\n')
    assert httpie.plugins.colors.ColorFormatter(None).format_headers('  \n  \n  ')
    assert httpie.plugins.colors.ColorFormatter(None).format_headers('a: b\n')

# Generated at 2022-06-11 23:44:09.582679
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment.null()
    cf = ColorFormatter(env, DEFAULT_STYLE)
    assert pygments.styles.get_style_by_name(DEFAULT_STYLE) == cf.get_style_class(DEFAULT_STYLE)

# Generated at 2022-06-11 23:44:17.515124
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    from httpie.formatter import format_body
    from httpie.context import Environment
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    env = Environment()
    mime = 'text/plain'
    test_data = [
        ('foo', 'foo'),
        ('\n', '\n'),
        ('\t', '\t'),
        ('\x7f', '\x7f'),
        ('\x80', '\x80'),
        ('\xff', '\xff'),
        ('\u0100', '\u0100'),
        ('\uffff', '\uffff'),
    ]

    for text, expected in test_data:
        body = format_body(text, mime, env, color_scheme='solarized')

# Generated at 2022-06-11 23:44:22.309404
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class TestEnvironment:
        colors = 256
    env = TestEnvironment()
    test_formatter = ColorFormatter(env)
    assert test_formatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style
    assert test_formatter.get_style_class('monokai') == pygments.styles.Monokai


# Generated at 2022-06-11 23:44:31.282668
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    c = ColorFormatter(Environment(colors=256), color_scheme='monokai')
    # will not apply format if there is no lexer
    assert c.format_body("<html></html>", mime="application/html") == "<html></html>"
    # json
    assert c.format_body("{\"a\": \"b\"}", mime="application/json") == "\x1b[38;5;145m{\x1b[39m\x1b[38;5;33m\"a\"\x1b[39m\x1b[38;5;33m:\x1b[39m \x1b[38;5;50m\"b\"\x1b[39m\x1b[38;5;145m}\x1b[39m"
    # html
    assert c

# Generated at 2022-06-11 23:44:42.822884
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie import ExitStatus
    from httpie.input import SEP_CREDENTIALS
    from tests import http, HTTP_OK, COLOR, CRLF
    from tests.test_formatter import TestFormatter
    class Dummy:
        json = False
        pretty_json = False
        colors = 256
        style = None
        stream = None
        style_override = None
        verbose = False
        formatter = 'colors'
        stdin_isatty = True
        is_windows = False
    from httpie.plugins import FormatterPlugin
    from httpie.formatter import get_preferred_formatter

    style = http('--auth=noah:password', 'GET', httpbin.url + '/basic-auth/noah/password')

# Generated at 2022-06-11 23:44:52.424326
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class TestColorFormatter(ColorFormatter):
        explicit_json = False

        def __init__(self, color_scheme=DEFAULT_STYLE):
            formatter = Terminal256Formatter(
                style=self.get_style_class(color_scheme)
            )
            self.formatter = formatter

    formatter = TestColorFormatter()
    headers = 'Content-Type: application/json\n' \
              'content-length: 10\n' \
              'User-Agent: abc/1.2.3\n'
    output = formatter.format_headers(headers)

# Generated at 2022-06-11 23:45:02.279189
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    formatter = TerminalFormatter()
    # Request-Line

# Generated at 2022-06-11 23:45:56.537687
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(None, 'auto') is not None
    assert ColorFormatter(None, 'solarized') is not None
    assert ColorFormatter(None, 'fruity') is not None
    assert ColorFormatter(None, 'monokai') is not None

    assert ColorFormatter(None, 'fruity') is not None

# Generated at 2022-06-11 23:46:07.062723
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    '''
    测试 ColorFormatter
    :return:
    '''
    import os
    env = Environment()
    env.merge({
        'debug': False,
        'verbose': False,
        'headers': ['Accept: application/json'],
        'style': None,
        'colors': 256
    })
    explicit_json = False
    color_scheme = 'solarized'

    c = ColorFormatter(env, explicit_json, color_scheme)
    # print(c.env)

# Generated at 2022-06-11 23:46:16.524408
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class Environment(object):
        colors = 256
    env = Environment()
    color_formatter = ColorFormatter(env, color_scheme="solarized")
    assert isinstance(color_formatter.formatter, Terminal256Formatter)
    assert isinstance(color_formatter.formatter.style, Solarized256Style)
    color_formatter = ColorFormatter(env, color_scheme="monokai")
    assert isinstance(color_formatter.formatter, Terminal256Formatter)
    assert isinstance(color_formatter.formatter.style, pygments.styles.get_style_by_name["monokai"])
    color_formatter = ColorFormatter(env, color_scheme="auto")
    assert isinstance(color_formatter.formatter, TerminalFormatter)

# Generated at 2022-06-11 23:46:23.874677
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(
        {
            'colors': True,
            'style': DEFAULT_STYLE,
            'is_windows': False
        }
    )
    lexer = color_formatter.get_lexer_for_body('application/json', '{"foo": "bar"}')
    assert lexer.__name__ == 'JsonLexer'

    lexer = color_formatter.get_lexer_for_body('application/yaml', 'foo: bar')
    assert lexer.__name__ == 'YamlLexer'

    lexer = color_formatter.get_lexer_for_body('application/xml', '<foo>bar</foo>')
    assert lexer.__name__ == 'XmlLexer'



# Generated at 2022-06-11 23:46:25.347122
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-11 23:46:34.624843
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_py26
    if not is_py26:
        import httpie.cli
        env = httpie.cli.Environment()
        formatter = ColorFormatter(env)

        # case of HTML body
        mime = "text/html"
        body = """<!doctype html>\n<html>\n  <head>\n    <title>Hello Httpie</title>""";
        parsed_body = formatter.format_body(body, mime)
        assert body != parsed_body

        # case of non HTML body
        mime = "text/plain"
        body = """Hello Httpie!""";
        parsed_body = formatter.format_body(body, mime)
        assert body == parsed_body

# Generated at 2022-06-11 23:46:42.440722
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    #
    # A valid JSON body
    #
    body = """
    {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3"
    }
    """
    lexer = get_lexer(
        mime='application/json',
        body=body,
    )

    assert lexer == pygments.lexers.get_lexer_by_name('json')

    #
    # A non-JSON body
    #
    body = """
    <html>
       <user-details>
          <first-name>John</first-name>
          <last-name>Doe</last-name>
          <age>42</age>
       </user-details>
    </html>
    """

# Generated at 2022-06-11 23:46:46.647796
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    assert http_lexer.name == 'HTTP'
    assert http_lexer.aliases == ['http']
    assert http_lexer.filenames == ['*.http']


# Generated at 2022-06-11 23:46:55.450853
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import unittest
    from httpie.context import Environment

    class TestCase(unittest.TestCase):

        def setUp(self):
            self.env = Environment()
            self.env.colors = 256

    t = TestCase()

    # when body is json format
    body = '{"hello" : "world"}'
    mime = 'application/json'
    formatter = ColorFormatter(
        env=t.env,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    lexer = formatter.get_lexer_for_body(mime, body)
    assert lexer.name == 'JSON'

    # when body is not json format
    body = 'hello world'
    mime = 'text/html'
    lexer = form

# Generated at 2022-06-11 23:47:05.921183
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main
    import tempfile
    import os
    # simple case
    env = main.Environment(colors=256)
    formatter = ColorFormatter(env)
    input = '''Accept-Encoding: gzip,deflate
Cache-Control: max-age=259200
Content-Length: 0
Content-Type: text/html; charset=utf-8
Date: Mon, 17 Aug 2020 12:52:52 GMT
ETag: W/"cbd1-J0X+kQjKgD39yhggaJDA"
Expires: Thu, 20 Aug 2020 12:52:52 GMT
Last-Modified: Fri, 14 Aug 2020 00:11:06 GMT
Server: ECS (dcb/742D)
'''