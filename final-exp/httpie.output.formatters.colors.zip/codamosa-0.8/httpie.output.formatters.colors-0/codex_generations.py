

# Generated at 2022-06-11 23:37:51.837936
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='application/json')
    assert get_lexer(mime='application/json', body='{}')
    assert get_lexer(mime='application/json', explicit_json=True, body='{}')
    assert get_lexer(mime='application/javascript')
    assert get_lexer(mime='application/javascript', body='{}')
    assert get_lexer(mime='application/javascript', explicit_json=True, body='{}')
    assert get_lexer(mime='application/javascript', explicit_json=True, body='-')
    assert not get_lexer(mime='application/json', body='-')

# Generated at 2022-06-11 23:37:58.284679
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():

    import os
    import sys

    def do_test(headers, expected):
        cf = ColorFormatter(Environment(colors=256))

        # Make sure if we are called from interactive python session then use
        # 256 color mode, otherwise use non-256 color mode.
        if not sys.stdout.isatty():
            cf.formatter = TerminalFormatter()

        # colr, the Windows terminal supports only 8 basic colors
        if os.name == 'nt':
            cf.formatter = TerminalFormatter()

        actual = cf.format_headers(headers)
        assert actual == expected

    # Ensure that the response from server is highlighted and colored in
    # Solarized256Style

# Generated at 2022-06-11 23:38:03.936942
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    import httpie.plugins.builtin.colors
    style_class = httpie.plugins.builtin.colors.ColorFormatter.get_style_class(color_scheme=DEFAULT_STYLE)
    print('{}, {}'.format(style_class.__name__, style_class))
    assert style_class == Solarized256Style

# Generated at 2022-06-11 23:38:06.410113
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter(None).get_style_class(AUTO_STYLE) == Solarized256Style
    assert ColorFormatter(None).get_style_class("monokai") == pygments.styles.get_style_by_name("monokai")
    assert ColorFormatter(None).get_style_class("invalid style name") == Solarized256Style
    assert ColorFormatter(None).get_style_class(AUTO_STYLE) == Solarized256Style

# Generated at 2022-06-11 23:38:18.569812
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexer import Lexer
    print(SimplifiedHTTPLexer(startinline=True).get_tokens_unprocessed('test'))
    print(isinstance(SimplifiedHTTPLexer(startinline=True), Lexer))
    print(issubclass(SimplifiedHTTPLexer, Lexer))
    print(issubclass(SimplifiedHTTPLexer, lexer))
    print(issubclass(SimplifiedHTTPLexer, pygments.lexer.RegexLexer))
    print(issubclass(SimplifiedHTTPLexer, pygments.lexer.RegexLexer))
    print(SimplifiedHTTPLexer().tokenize('test'))

# Generated at 2022-06-11 23:38:25.358505
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    s = ColorFormatter.get_style_class(color_scheme=AUTO_STYLE)
    assert s == pygments.styles.get_style_by_name('default')

    s = ColorFormatter.get_style_class(color_scheme=SOLARIZED_STYLE)
    assert s == Solarized256Style

    s = ColorFormatter.get_style_class(color_scheme='monokai')
    assert s == pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-11 23:38:26.239323
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # FIXME
    pass

# Generated at 2022-06-11 23:38:37.391239
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    env = Environment(stdout=None, colors=0)
    color_formatter = ColorFormatter(env)

    # text
    assert BINARY_SUPPRESSED_NOTICE == color_formatter.format_body("hello", "text/plain")

    # image
    assert BINARY_SUPPRESSED_NOTICE == color_formatter.format_body("hello", "image/jpeg")

    # json
    assert ('<span style="'
            'color:#008000;'
            'font-weight:bold;'
            '">"</span>'
            '<span style="color:#008000;">hello</span>'
            '<span style="color:#008000;font-weight:bold;">"</span>') == color

# Generated at 2022-06-11 23:38:46.391945
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    cf = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    headers = u'GET / HTTP/1.1\nContent-Type: application/json; charset=utf-8\nGreeting: Hello\nAccept: */*\nAuthorization: Basic dXNlcm5hbWU6cGFzc3dvcmQ=\n'

# Generated at 2022-06-11 23:38:58.914832
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.core import main
    from httpie.core import Message

    def run_httpie(
        json_arg: str,
        mime: str,
        body: str,
        expected_lexer_name: str
    ) -> None:
        args = [
            'http',
            '--print=H',
            json_arg
        ]

        message = Message(
            content_type=mime,
            body=body
        )

        plugins = [
            JSONFormatter,
            ColorFormatter
        ]
        main(args=args, plugins=plugins, message=message)


# Generated at 2022-06-11 23:39:17.945041
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class ColorFormatter(object):
        def format_body(self, body: str, mime: str) -> str:
            lexer = self.get_lexer_for_body(mime, body)
            return pygments.highlight(
                code=body,
                lexer=lexer,
                formatter=pygments.formatters.TerminalFormatter(),
            )

        def get_lexer_for_body(
            self, mime: str,
            body: str
        ) -> Optional[Type[Lexer]]:
            return get_lexer(
                mime=mime,
                explicit_json=False,
                body=body,
            )

    color_formatter = ColorFormatter()
    # test 1: print the lexer name and return
    return_body = color_formatter.format

# Generated at 2022-06-11 23:39:23.384421
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert isinstance(ColorFormatter(None).get_lexer_for_body('image/png', ''), type(None))
    assert isinstance(ColorFormatter(None).get_lexer_for_body('image/png', 'asdf'), type(None))
    assert isinstance(ColorFormatter(None).get_lexer_for_body('application/json', ''), pygments.lexers.JsonLexer)
    assert isinstance(ColorFormatter(None).get_lexer_for_body('application/json', 'asdf'), pygments.lexers.JsonLexer)
    assert isinstance(ColorFormatter(None).get_lexer_for_body('application/notjson', '{"key": "value"}'), type(None))

# Generated at 2022-06-11 23:39:32.929677
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    output = pygments.highlight(
        code=b'''POST /post HTTP/1.1
Host: hello.world.com
Content-Type: application/x-www-form-urlencoded
Content-Length: 10

abc''',
        lexer=http_lexer,
        formatter=Terminal256Formatter(style=Solarized256Style),
    ).strip()


# Generated at 2022-06-11 23:39:43.789994
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            def test(actual, expected):
                self.assertTrue(
                    actual is expected,
                    'get_lexer_for_body(%s, %s) -> %s, but not %s' %
                    (mime, body, actual, expected)
                )

            test(
                ColorFormatter.get_lexer_for_body('application/json', ''),
                pygments.lexers.get_lexer_by_name('json')
            )
            test(
                ColorFormatter.get_lexer_for_body('application/json', 'foo'),
                pygments.lexers.get_lexer_by_name('json')
            )

# Generated at 2022-06-11 23:39:46.992635
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert ColorFormatter(Environment()).format_body(
        body='this is json',
        mime='text/json'
    ) == 'this is json'



# Generated at 2022-06-11 23:39:54.574960
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.output.colors import ColorFormatter
    options = {"color_scheme": "solarized"}
    cf = ColorFormatter(None, **options)
    assert (cf.get_style_class("solarized") == Solarized256Style)
    options["color_scheme"] = "nonexistant"
    assert (cf.get_style_class("solarized") == Solarized256Style)
    options["color_scheme"] = "vim"
    assert (cf.get_style_class("solarized") != Solarized256Style)

# Generated at 2022-06-11 23:39:59.532942
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    """
    Test the get_style_class method of the ColorFormatter class.
    This test is important because this method is static and it is
    difficult to properly test static methods.
    """
    ColorFormatter.get_style_class(SOLARIZED_STYLE)

# Generated at 2022-06-11 23:40:01.679014
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-11 23:40:09.775293
# Unit test for function get_lexer
def test_get_lexer():
    body = '{"foo": "bar"}'
    lexer = get_lexer(mime='application/unknown', body=body)
    assert lexer is None

    lexer = get_lexer(mime='application/json', body=body)
    assert issubclass(lexer, pygments.lexers.JsonLexer)

    lexer = get_lexer(mime='application/unknown', body=body,
                      explicit_json=True)
    assert issubclass(lexer, pygments.lexers.JsonLexer)

# Generated at 2022-06-11 23:40:21.230684
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # The original Pygments HTTP Lexer treats the ':' in
    # `Basic realm="..."` as part of the value.
    original_http_lexer = PygmentsHttpLexer()
    basic_auth_original = pygments.highlight(
        code='Authorization: Basic realm="..."',
        lexer=original_http_lexer,
        formatter=pygments.formatters.TerminalFormatter()
    )
    print(basic_auth_original)

    # The simplified HTTP Lexer treats the ':' as the separator
    # between the name and value.
    simplified_http_lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-11 23:40:47.231086
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Always use light green and a bold font
    assert ColorFormatter(Environment(colors=True)).format_headers('''\
HTTP/1.1 200 OK
foo: bar
''') == '\x1b[32;1mHTTP/1.1 200 OK\x1b[39;22m\n\x1b[32;1mfoo: bar\x1b[39;22'

    # Use black text on a red background.

# Generated at 2022-06-11 23:40:58.698923
# Unit test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-11 23:41:02.739831
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    c = ColorFormatter(Environment(colors=True))
    assert c.format_body('<h1>Lorem</h1>', 'text/html') == '<h1>Lorem</h1>'

# Generated at 2022-06-11 23:41:06.537280
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    stream = SimplifiedHTTPLexer()

    assert str(stream.name) == 'HTTP'
    assert str(stream.aliases) == "['http']"
    #assert str(stream.filenames) == "['*.http']"
    #assert str(stream.tokens) == ""

# Generated at 2022-06-11 23:41:18.250232
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import to_unicode

    printable_print_ascii = "ab\ncd\nef\n"
    printable_print_unicode = to_unicode("żółć\nżółć\nżółć\n")
    unprintable_print_ascii = "ab\x00cd\x00ef\x00"
    unprintable_print_unicode = to_unicode("żółć\x00żółć\x00żółć\x00")

    formatter = ColorFormatter(Environment(no_colors=True))
    assert formatter.format_body(printable_print_ascii, 'text/plain') == \
           "ab\ncd\nef\n"
    assert form

# Generated at 2022-06-11 23:41:26.649155
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Initialize the lexer
    lexer = SimplifiedHTTPLexer()

    # Try to lex a string of HTTP request
    # From http://en.wikipedia.org/w/index.php?title=Hypertext_Transfer_Protocol&action=edit

# Generated at 2022-06-11 23:41:37.897650
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.cli import get_parser
    from httpie.context import Environment
    from httpie.plugins import load_plugins
    from httpie.compat import is_windows
    # Retrieve all the available formatters
    parser = get_parser()
    args = parser.parse_args()
    args.colors = None
    env = Environment(args, STDOUT=False)
    plugins = load_plugins(env)
    formatters = [
        p for p in plugins
        if p.group_name == 'format'
    ]

    # Retrieve the first formatter of type 'ColorFormatter'
    formatter = None
    for plugin in formatters:
        if (
            plugin.__class__.__name__ == 'ColorFormatter' and
            plugin.group_name == 'colors'
        ):
            form

# Generated at 2022-06-11 23:41:44.028957
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import *
    http_lexer = SimplifiedHTTPLexer()
    request_line = 'GET / HTTP/1.0'
    headers = '''\
Host: localhost:8080\r
User-Agent: HTTPie/0.9.8\r
Accept-Encoding: gzip, deflate, compress\r
Accept: */*\r
Connection: keep-alive\r
Content-Length: 6\r
Content-Type: application/x-www-form-urlencoded\r
'''
    status_line = 'HTTP/1.0 200 OK'

# Generated at 2022-06-11 23:41:51.552221
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import os
    import sys
    import json
    from contextlib import contextmanager

    from httpie.context import Environment

    from httpie.compat import is_windows
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    assert formatter.group_name == 'colors'
    assert formatter.group_index is not None
    assert formatter.enabled == True
    assert isinstance(formatter.formatter, Terminal256Formatter)
    assert formatter.formatter.style == formatter.get_style_class(
        DEFAULT_STYLE)



# Generated at 2022-06-11 23:42:00.827353
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-11 23:42:13.866997
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter(Environment(colors=256), False, 'default')
    assert not cf.explicit_json
    assert cf.formatter is not None
    assert cf.http_lexer is not None

# Generated at 2022-06-11 23:42:15.531725
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('acme') is not None



# Generated at 2022-06-11 23:42:24.885561
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def assert_lexer(mime, body, lexer):
        http_lexer = SimplifiedHTTPLexer()
        formatter = Terminal256Formatter(
            style=Solarized256Style
        )
        color_formatter = ColorFormatter(
            env=http_lexer,
            explicit_json=False,
            color_scheme='solarized',
        )
        assert color_formatter.get_lexer_for_body(mime=mime, body=body).__name__ == lexer

    assert_lexer('application/json', '{"type":{"id":"string"}}', 'JSONLexer')
    assert_lexer('application/json', '{"type":{"id":"string"', 'TextLexer')

# Generated at 2022-06-11 23:42:27.305785
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter()
    assert '<html>' in formatter.format_body('<html>', 'text/html')


# Generated at 2022-06-11 23:42:32.239100
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
  env = Environment()
  env.colors = True
  test_1 = ColorFormatter(env, True, DEFAULT_STYLE)
  test_2 = ColorFormatter(env, False, SOLARIZED_STYLE)
  assert test_1.explicit_json == True
  assert test_2.explicit_json == False
  assert test_1.color_scheme == DEFAULT_STYLE
  assert test_2.color_scheme == SOLARIZED_STYLE


if __name__ == "__main__":
  test_ColorFormatter()

# Generated at 2022-06-11 23:42:34.485139
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('fruity') != Solarized256Style

# Generated at 2022-06-11 23:42:38.534810
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("fruity") == pygments.styles.get_style_by_name("fruity")
    assert ColorFormatter.get_style_class("tango") == pygments.styles.get_style_by_name("tango")

# Generated at 2022-06-11 23:42:39.303957
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()


# Generated at 2022-06-11 23:42:40.403800
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter()
    assert formatter

# Generated at 2022-06-11 23:42:48.396401
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-11 23:43:18.000723
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class FormatterFake(ColorFormatter):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.formatter = None
            self.http_lexer = None

    class EnvironmentFake:
        def __init__(self, colors):
            self.colors = colors

    # format_body not called if response headers not present
    formatter_1 = FormatterFake(
        env=EnvironmentFake(256),
        explicit_json=False,
        color_scheme='fruity'
    )
    assert formatter_1.get_lexer_for_body(
        mime='text/html',
        body='an html body'
    ) is None

    # format_body not called if response body not present
    formatter_2 = Formatter

# Generated at 2022-06-11 23:43:28.817372
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    # On Windows, the default locale causes pygments to not render
    # escape sequences.
    if is_windows:
        import locale
        locale.setlocale(locale.LC_CTYPE, 'C')

    # Formatter
    cf = ColorFormatter(Environment(colors='256'), explicit_json=False, color_scheme=SOLARIZED_STYLE)


# Generated at 2022-06-11 23:43:30.923728
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    import pytest

    # Raise error when input style does not exist
    with pytest.raises(ClassNotFound):
        ColorFormatter.get_style_class('NonExistStyle')



# Generated at 2022-06-11 23:43:41.331512
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    text = '''GET / HTTP/1.1
Host: example.com
User-Agent: curl/7.54.0
Accept: */*'''

    tokens = list(SimplifiedHTTPLexer().get_tokens(text))

    assert tokens[0] == (pygments.token.Name.Function, 'GET')
    assert tokens[1] == (pygments.token.Text, ' ')  # Space
    assert tokens[2] == (pygments.token.Name.Namespace, '/')
    assert tokens[3] == (pygments.token.Text, ' ')  # Space
    assert tokens[4] == (pygments.token.Keyword.Reserved, 'HTTP')
    assert tokens[5] == (pygments.token.Operator, '/')

# Generated at 2022-06-11 23:43:51.884938
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Tested on macOS

    # Text
    assert isinstance(get_lexer('text/plain'), pygments.lexers.TextLexer)

    # JSON (nothing fancy here, cf. utils.py:guess_json_encoding)
    assert isinstance(get_lexer('application/json'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('test/json'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/json; charset=utf-8'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/json; encoding=utf-8'), pygments.lexers.JsonLexer)
    # JSON with explicit --json

# Generated at 2022-06-11 23:43:53.685864
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert isinstance(ColorFormatter(Environment(pretty=True, colors=True, style=None)), ColorFormatter)

# Generated at 2022-06-11 23:44:02.294909
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
        style=Solarized256Style
    )
    sample_http_request = 'GET http://httpbin.org/ HTTP/1.1\nHost: httpbin.org\nUser-Agent: HTTPie/0.9.8\nAccept-Encoding: gzip, deflate\nAccept: application/json\nConnection: keep-alive\n\n'
    result = pygments.highlight(
        code=sample_http_request,
        lexer=simplified_http_lexer,
        formatter=formatter,
    )

# Generated at 2022-06-11 23:44:09.275130
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import json
    import httpie.output.formatters.colors  # noqa
    type_ = 'application/json'
    assert json.loads(httpie.output.formatters.colors.get_lexer_for_body(type_, '{}')) is not None
    type_ = 'text/plain'
    assert httpie.output.formatters.colors.get_lexer_for_body(type_, '') is None

# Generated at 2022-06-11 23:44:17.377535
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.formatters.colors import ColorFormatter
    from io import BytesIO
    from unittest.mock import patch, call

    def get_set_environment_mock(is_tty):
        with patch('httpie.output.formatters.colors.Environment') as env_mock:
            env_mock.colors = 256 if is_tty else 0
            return env_mock

    env_mock1 = get_set_environment_mock(True)
    env_mock2 = get_set_environment_mock(False)
    if not (is_windows):
        env_mock3 = get_set_environment_mock(False)

# Generated at 2022-06-11 23:44:27.347822
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    cf = ColorFormatter(
        env=Environment(colors=1),
        explicit_json=False,
        color_scheme="solarized",
    )

# Generated at 2022-06-11 23:45:06.779680
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert "GET / HTTP/1.1" == SimplifiedHTTPLexer().get_tokens_unprocessed(
        "GET / HTTP/1.1"
    )[0][1]

# Generated at 2022-06-11 23:45:17.192707
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    """
    Test for SimplifiedHTTPLexer
    """
    lexc = SimplifiedHTTPLexer()
    lexc.get_tokens('HTTP/1.1 200 OK\n')
    lexc.get_tokens('HTTP/1.1 200 OK\nConnection:close\n')
    lexc.get_tokens('HTTP/2.0 200 OK\nCache-Control:max-age=0\n')
    lexc.get_tokens('HTTP/2.0 200 OK\nCache-Control:max-age=0\n\n')
    lexc.get_tokens('HTTP/2.0 200 OK\nCache-Control:max-age=0\n\n{}')

# Generated at 2022-06-11 23:45:27.958425
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    l = SimplifiedHTTPLexer()
    # The following input could be a real life example of an HTTP request.
    # It is a request to the root path of httpbin.org/get.
    input = (
        r'GET / HTTP/1.1\n'
        r'Host: httpbin.org\n'
        r'Accept-Encoding: identity\n'
        r'Accept: */*\n'
        r'User-Agent: HTTPie/1.0.2\n'
        r'\n'
    )
    # output of httpie --print=BH --stream example.org/get
    # (including timestamps which are not checked by unit test)

# Generated at 2022-06-11 23:45:37.108862
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments import highlight
    from pygments.lexers import HttpLexer
    from pygments.lexers.text import HttpLexer as PygmentsHttpLexer
    from pygments.formatters import Terminal256Formatter
    from pygments.styles import get_style_by_name
    from httpie.styles import Solarized256Style

    http_lexer = PygmentsHttpLexer()
    simplified_http_lexer = SimplifiedHTTPLexer()
    http_sample = (
        "POST /post HTTP/1.1\r\n\r\n"
        "Content-Type: text/plain; charset=utf-8\r\n"
        "Content-Length: 3\r\n\r\n"
        "foo"
    )

# Generated at 2022-06-11 23:45:41.799972
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True, styles=True, force_colors=False,
        force_styles=False)
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter is not None

# Generated at 2022-06-11 23:45:53.546109
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class TestEnvironment:
        def __init__(self, colors):
            self.colors = colors

    class TestFormatter(ColorFormatter):
        def __init__(self, env):
            self.env = env

    def test_format_headers(headers, color_scheme, colors, expected):
        env = TestEnvironment(colors)
        formatter = TestFormatter(env)
        result = formatter.format_headers(headers)
        assert expected == result


# Generated at 2022-06-11 23:45:57.414326
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class FakeEnvironment:
        def __init__(self, colors):
            self.colors = colors
    env = FakeEnvironment(256)
    formatter = ColorFormatter(env)
    assert formatter.format_body("<h1>Hello</h1>", 'text/html') == '<h1>Hello</h1>'

# Generated at 2022-06-11 23:46:05.919873
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.output.streams import OutStreams
    from httpie.context import Environment

    env = Environment(stdout=OutStreams(stdout=None))
    fmt = FormatterPluginManager.instantiate(env=env, format="colors")
    input_headers = """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.8

"""
    result = fmt.format_headers(input_headers)
    assert result == input_headers

# Generated at 2022-06-11 23:46:15.357431
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(Environment())

    # response contains non-printable characters
    result = formatter.format_body(
        '\x01\x02\x03\x04\x05\x06\x07\x08\r\n\x0b\x0c\r\n\x0e\x0f\x10\x11\x12\x13\x14\x15\x16',
        'text/html'
    )
    assert result == '\x01\x02\x03\x04\x05\x06\x07\x08\r\n\x0b\x0c\r\n\x0e\x0f\x10\x11\x12\x13\x14\x15\x16'

    # response contains printable characters


# Generated at 2022-06-11 23:46:23.456602
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert (SimplifiedHTTPLexer.name == 'HTTP')
    assert (SimplifiedHTTPLexer.aliases == ['http'])
    assert (SimplifiedHTTPLexer.filenames == ['*.http'])