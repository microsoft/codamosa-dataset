

# Generated at 2022-06-11 23:37:53.142977
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter = ColorFormatter(None)
    headers = '''
POST / HTTP/1.1
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 9
Content-Type: application/json

'''
    expected_output = '''
POST / HTTP/1.1
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 9
Content-Type: application/json

'''
    output = color_formatter.format_headers(headers)
    assert expected_output == output

# Generated at 2022-06-11 23:38:05.572648
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import sys
    import mock
    import os
    import pathlib
    import contextlib

    sys.path.append(
        os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    )

    import httpie
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from tools import http, HTTP_OK
    from httpie.plugins import plugin_manager

    httpie.StatusCodes = mock.MagicMock()
    httpie.StatusCodes.__getitem__ = mock.MagicMock(return_value='201 Created')
    httpie.exit = mock.MagicMock()


# Generated at 2022-06-11 23:38:18.268288
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert str(formatter.formatter.__class__) == "<class 'pygments.formatters.terminal.TerminalFormatter'>"
    assert str(formatter.http_lexer.__class__) == "<class 'httpie.plugins.colors.SimplifiedHTTPLexer'>"
    assert formatter.enabled == True

    env.colors = 256
    formatter = ColorFormatter(env, color_scheme="solarized")
    assert str(formatter.formatter.__class__) == "<class 'httpie.plugins.colors.Solarized256Style'>"

# Generated at 2022-06-11 23:38:23.326633
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment(), False, DEFAULT_STYLE)
    assert formatter.explicit_json == False
    assert formatter.formatter == (TerminalFormatter() if is_windows else Terminal256Formatter())
    assert isinstance(formatter.http_lexer, PygmentsHttpLexer if is_windows else SimplifiedHTTPLexer)

# Generated at 2022-06-11 23:38:28.275084
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    explicit_json = False
    color_scheme = 'solarized'
    formatter = ColorFormatter(env=env, explicit_json=explicit_json, color_scheme=color_scheme)
    text = 'text'
    assert formatter.format_body(text, '') == text
    assert formatter.format_headers(text) == text

# Generated at 2022-06-11 23:38:37.441418
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Tests that the constructor of formatter ColorFormatter is idempotent
    # (that is, the output of the constructor is the same object as the input)
    formatter = ColorFormatter(env=None, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.formatter is formatter.__init__(env=None, explicit_json=False, color_scheme=DEFAULT_STYLE)

    # Tests that it fails when a wrong color scheme is used
    from pytest import raises
    with raises(ClassNotFound):
        ColorFormatter(env=None, color_scheme='wrong scheme')

# Generated at 2022-06-11 23:38:46.427922
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.plugins.download import DownloadPlugin
    from httpie.plugins.auth.basic import HTTPBasicAuth
    environment = Environment(colors=True)
    downloader = Downloader(environment)
    basic_auth = HTTPBasicAuth(environment, downloader)
    download_plugin = DownloadPlugin(environment, downloader, basic_auth)
    environment.plugins.add(download_plugin)
    formatter = ColorFormatter(environment)
    headers = formatter.format_headers('Content-Type: application/json; charset=utf-8\ncontent-length: 100\nx-header: value')

# Generated at 2022-06-11 23:38:49.698196
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins.colors import DEFAULT_STYLE, ColorFormatter
    assert ColorFormatter.get_style_class("solarized") is Solarized256Style

# Generated at 2022-06-11 23:39:01.896457
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import pygments.lexers
    import pygments.token

    lexer = pygments.lexers.get_lexer_by_name("http")
    lexer.analyse('ABC 123')
    print(lexer.analyse('ABC 123'))  # (0.1, 0.0, 0.0)

    mylexer = SimplifiedHTTPLexer()
    print(mylexer.analyse('ABC 123'))
    print([(tokentype, value) for (tokentype, value) in mylexer.get_tokens('ABC 123')])
    print([(tokentype, value) for (tokentype, value) in mylexer.get_tokens('GET /apis/apps/v1/namespaces/ HTTP/1.1\r\n')])
   

# Generated at 2022-06-11 23:39:03.845360
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) == Solarized256Style

# Generated at 2022-06-11 23:39:20.356829
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.presenters import Presenter
    presenter = Presenter(None, None)
    presenter.formatters = [ColorFormatter(None)]
    # 1. test python lexer when Content-Type is text/python
    script = "print('Hello World')"
    lexer = presenter.format_body(script, 'text/python')
    assert lexer == "\x1b[0m\x1b[38;5;28mprint\x1b[0m\x1b[38;5;137m(\x1b[0m\x1b[38;5;220m'Hello World'\x1b[0m\x1b[38;5;137m)\x1b[0m"
    # 2. test text lexer when Content-Type is text/html

# Generated at 2022-06-11 23:39:21.373632
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-11 23:39:24.068466
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = pygments.lexers.get_lexer_by_name('http')
    assert issubclass(SimplifiedHTTPLexer, lexer.__class__)

# Generated at 2022-06-11 23:39:30.786047
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import httpie
    args = httpie.cli.parser.parse_args(args=['httpie', '--colors=on', '--json', '--style=auto'], env=Environment())
    assert isinstance(ColorFormatter(args.env,
                                     explicit_json=args.json,
                                     color_scheme=args.style), FormatterPlugin)



# Generated at 2022-06-11 23:39:42.937264
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from . import __file__ as package_root_filepath
    from os.path import dirname
    from httpie.plugins.builtin import Formatter
    from httpie.context import Environment

    environment = Environment()
    environment.colors = True
    formatter = Formatter(environment,)
    color_formatter = ColorFormatter(environment, True)
    color_formatter.is_final = True

    try:
        color_formatter.format_body(
            body="<xml></xml>",
            mime="text/xml"
        )
    except Exception as exception:
        print(exception.__class__.__name__)
        print(exception)
        assert False


# Generated at 2022-06-11 23:39:52.967809
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from pygments.formatters.terminal import TerminalFormatter
    from httpie.plugins import FormatterPlugin

    do_format = FormatterPlugin(explicit_json=False, indent=None,
                                color_scheme=DEFAULT_STYLE)
    colored_headers = do_format.format_headers(
        b'HTTP/1.1 200 OK\r\n'
        b'Content-Type: application/json\r\n'
        b'Server: ApiGateway\r\n'
        b'\r\n'
    )
    assert colored_headers == pygments.highlight(
        headers,
        pygments.lexers.text.HttpLexer(),
        TerminalFormatter())

# Generated at 2022-06-11 23:40:05.795894
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class FakeEnvironment:
        def __init__(self):
            self.colors = None

    fake_env = FakeEnvironment()


# Generated at 2022-06-11 23:40:08.113267
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    solarized256 = ColorFormatter.get_style_class('solarized256')
    assert solarized256 is Solarized256Style

# Generated at 2022-06-11 23:40:16.028507
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin

    formatter = FormatterPlugin()
    color_formatter = ColorFormatter(env=None)
    # Test for {'Content-Type': 'text/plain'}
    assert color_formatter.get_lexer_for_body(
        mime='text/plain',
        body=''
    ) is None

    # Test for {'Content-Type': 'text/html'}
    assert color_formatter.get_lexer_for_body(
        mime='text/html',
        body=''
    ) is None

    # Test for {'Content-Type': 'application/json'}
    assert color_formatter.get_lexer_for_body(
        mime='application/json',
        body=''
    ) is pygments.lexers.get

# Generated at 2022-06-11 23:40:16.757966
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter

# Generated at 2022-06-11 23:40:36.462501
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import requests
    import os
    import sys
    from httpie.core import main
    from httpie.plugins import FormatterPlugin
    from httpie import ExitStatus
    from utils import TestEnvironment, http, HTTP_OK
    from fixtures import (
        BIN_DIRECTORY,
        TEST_ROOT,
        FUNC_TIMEOUT,
        UNICODE,
        COLOR,
    )
    from httpie.compat import is_windows
    from tempfile import gettempdir
    os.chdir(BIN_DIRECTORY)
    env = TestEnvironment()
    env.colors = 255
    env.stdout_isatty = True
    env.other_formatter = None

# Generated at 2022-06-11 23:40:48.987623
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    ff = ColorFormatter(None)
    # normal cases
    assert ff.get_lexer_for_body('application/json', '') == pygments.lexers.JsonLexer
    assert ff.get_lexer_for_body('text/json', '') == pygments.lexers.JsonLexer
    assert ff.get_lexer_for_body('application/vnd.api+json', '') == pygments.lexers.JsonLexer
    assert ff.get_lexer_for_body('text/html', '') == pygments.lexers.HtmlLexer
    assert ff.get_lexer_for_body('text/plain', '') == pygments.lexers.TextLexer
    assert ff.get_lexer_for_body('application/xml', '') == pygments.lexers

# Generated at 2022-06-11 23:40:50.934161
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(env = Environment(), explicit_json = False, color_scheme = DEFAULT_STYLE)

# Generated at 2022-06-11 23:40:54.444142
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter_obj = ColorFormatter(env=None,explicit_json=False, color_scheme='monokai')
    assert(color_formatter_obj.get_style_class('solarized')==Solarized256Style)

# Generated at 2022-06-11 23:41:06.311515
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import re
    import os
    import sys
    import glob

    #
    # 1. Read files with MIME and Body
    #
    data = {}
    with open("./resources/catalog.txt", "r") as f:
        for l in f:
            l = l.strip()
            if not l: continue
            if l.startswith("#"): continue
            l = re.sub(r"\s+", "\t", l)
            tokens = l.split("\t")
            data[tokens[0].strip()] = tokens[1].strip()

    #
    # 2. Iterate - verify adherence to test data
    #
    environment = Environment()
    color_formatter = ColorFormatter(environment)

    for k,v in data.items():
        assert None != color_

# Generated at 2022-06-11 23:41:18.115386
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from datetime import datetime
    from httpie.input import ParseResult

    class Request():
        def __init__(self):
            self.headers = {'name':'value'}
            self.method = 'GET'
            self.path = '/'
            self.body = None
            self.url = 'http://localhost:8080/'

    class Response():
        def __init__(self):
            self.headers = {'name':'value'}
            self.status_code = 200
            self.content = '{}'

    now = datetime.now()
    request = Request()
    response = Response()

    class Environment():
        def __init__(self):
            self.colors = True
            self.style = None
            self.headers = True
            self.body = 'text'


# Generated at 2022-06-11 23:41:26.505267
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pygments.lexers
    FormatterPlugin.lexers = {}
    for lexer in pygments.lexers.__all__:
        lexer = lexer.replace('Lexer', '')
        if lexer != PygmentsHttpLexer:
            FormatterPlugin.lexers[lexer] = getattr(pygments.lexers, lexer)()

    fake_env = Environment(colors=False, pygmentize=False, colors_256=False, debug=False)    
    fake_env2 = Environment(colors=True, pygmentize=False, colors_256=False, debug=False)
    fake_env3 = Environment(colors=True, pygmentize=False, colors_256=True, debug=False)

# Generated at 2022-06-11 23:41:37.773274
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows

    def mock_format(body: str, mime: str) -> str:
        plugin = ColorFormatter(
            env=Environment(colors=256)
        )
        return plugin.format_body(body, mime)

    def run(data, expectation, mime):
        output = mock_format(data, mime)
        print(data)
        print(output)
        assert output == expectation, output

    # Only test 256-color output if terminal is actually capable
    # of it.
    import sys
    if sys.platform == 'win32':
        return
    print(sys.platform)
    print(is_windows)
    assert not is_windows

    # Simulate a body

# Generated at 2022-06-11 23:41:42.285407
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.token import STANDARD_TYPES

    L = SimplifiedHTTPLexer()
    for item in L.tokens['root']:
        token = item[0]
        L.get_tokens_unprocessed(token)
        assert L.current_state() == []
        for token_type, value in L.get_tokens_unprocessed(token):
            assert token_type == STANDARD_TYPES[type(value)]

# Generated at 2022-06-11 23:41:44.371266
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) is Solarized256Style

# Generated at 2022-06-11 23:41:54.445595
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(None)
    assert formatter.formatter is not None

# Generated at 2022-06-11 23:42:00.876052
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Given a ColorFormatter instance
    color_formatter = ColorFormatter(Environment(colors=256), True, 'solarized')

    # When I apply it to a raw HTTP header
    raw_header = 'HTTP/1.1 200 OK\nContent-Type: text/plain\n\n'
    header = color_formatter.format_headers(raw_header)

    # Then I get a colored header
    assert header == '\x1b[38;5;10mHTTP/1.1 200 OK\x1b[0m\n\x1b[38;5;254mContent-Type: text/plain\x1b[0m\n\n'

# Generated at 2022-06-11 23:42:12.199430
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class ColorFormatterClass(ColorFormatter):
        def get_lexer_for_body(self, mime: str, body: str) -> Optional[Type[Lexer]]:
            return get_lexer(
                mime=mime,
                explicit_json=self.explicit_json,
                body=body,
            )

    color_formatter = ColorFormatterClass(Environment(colors=True), explicit_json=False, color_scheme=SOLARIZED_STYLE)


# Generated at 2022-06-11 23:42:14.996136
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class('default')
    assert style_class.__name__ == 'DefaultStyle'

# Generated at 2022-06-11 23:42:22.890702
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie import ExitStatus
    from httpie.core import main
    from tests.mocking import http

    for body, expected_output in (
        ('', ''),
        ('foo', 'foo'),
        ('{}', '{\n    \n}'),
        ('[]', '[\n    \n]'),
        ('', ''),
        ('{"a":1}', '{\n    "a": 1\n}'),  # FIXME: lexer=PygmentsJSONLexer()
    ):
        http('GET', http.url('/', headers={'content-type': 'text/plain'}))
        assert http.response.body == expected_output
        assert http.exit_status == ExitStatus.SUCCESS

# Generated at 2022-06-11 23:42:24.737384
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    id = ColorFormatter.get_style_class('solarized')
    assert id == Solarized256Style

# Generated at 2022-06-11 23:42:25.941557
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(object())

# Generated at 2022-06-11 23:42:34.605079
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.cli.parser import Parser
    from httpie.core import main as core_main
    from httpie.context import Environment
    from httpie.plugins import plugin_manager

    args = Parser().parse_args(args=[
        '--body', '{"a": "b"}',
        "http://foo.bar",
        "-p", "f",
    ])

# Generated at 2022-06-11 23:42:40.289565
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins import registry
    registry.clear()
    registry.load_builtin_plugins()
    registry.register(optional=True, plugin=ColorFormatter)

    env = Environment(colors=True)
    color_formatter = registry.get_color_formatter(env)
    assert color_formatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-11 23:42:44.912968
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.compat import is_windows
    from httpie.context import Environment
    env = Environment(colors=True)
    if is_windows:
        color_formatter = ColorFormatter(env, None, 'fruity')
    else:
        color_formatter = ColorFormatter(env)
    assert color_formatter

# Generated at 2022-06-11 23:43:28.459233
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    def test(input_, expected):
        simplified_http_lexer = SimplifiedHTTPLexer()
        result = pygments.highlight(
            input_, 
            simplified_http_lexer,
            pygments.formatters.Terminal256Formatter(style=Solarized256Style),
        )
        assert result == expected
    
    test(
        input_='GET / HTTP/1.1',
        expected='\x1b[38;5;68mGET\x1b[39m \x1b[38;5;112m/\x1b[39m \x1b[38;5;33mHTTP\x1b[39m/\x1b[38;5;111m1.1\x1b[39m',
    )
    

# Generated at 2022-06-11 23:43:33.939758
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Arrange
    expected_lexer = pygments.lexers.get_lexer_by_name('json')
    explicit_json = True
    body = '{"body": "key"}'
    mime = 'application/json'

    # Act
    colorFormatter = ColorFormatter(
        Environment(),
        color_scheme='auto',
        explicit_json=explicit_json,
    )
    actual_lexer = colorFormatter.get_lexer_for_body(mime, body)

    # Assert
    assert actual_lexer == expected_lexer

# Generated at 2022-06-11 23:43:45.683532
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import os
    env = Environment()
    formatter = ColorFormatter(env, explicit_json = False, color_scheme = 'solarized')
    file_path = os.path.dirname(os.path.realpath(__file__))
    with open(os.path.join(file_path, "test_ColorFormatter_format_headers.txt"), "r") as f:
        input_headers = f.read()
    output_headers = formatter.format_headers(input_headers)

# Generated at 2022-06-11 23:43:55.438009
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.colors import DEFAULT_STYLE
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter, SOLARIZED_STYLE, AVAILABLE_STYLES

    # Choose a available style which is not the default style or the solarized style
    for style in (S for S in AVAILABLE_STYLES if S not in [DEFAULT_STYLE, SOLARIZED_STYLE]):
        # If style is given, it should apply
        formatter = ColorFormatter(Environment(colors=256), color_scheme=style) # type: FormatterPlugin
        formatter.formatter.__class__.__name__ == "Terminal256Formatter"

# Generated at 2022-06-11 23:44:03.498757
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager

    fm = FormatterPluginManager()
    cf = fm.instantiate_active_plugins(
        env=Environment(
            colors=256,
        )
    )[0]

    not_json_or_xml = (
        'no color',
        'application/not-json',
        'application/not-json+json'
    )

    assert (
        cf.format_body(body=not_json_or_xml[0], mime=not_json_or_xml[1])
        == not_json_or_xml[0]
    )

    with open('tests/requests/BODY_NOT_JSON_OR_XML.json') as file:
        xml_body = file.read()


# Generated at 2022-06-11 23:44:04.885799
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("solarized256") == Solarized256Style

# Generated at 2022-06-11 23:44:14.308919
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class TestEnvironment(object):
        colors = 256

    class TestColorFormatter(ColorFormatter):
        def __init__(self, env, **kwargs):
            super().__init__(env, **kwargs)

    fmtr = TestColorFormatter(TestEnvironment())

    # Default style with 256 colors
    assert fmtr.get_style_class(DEFAULT_STYLE) == Solarized256Style

    # Bundled style
    assert fmtr.get_style_class(SOLARIZED_STYLE) == Solarized256Style

    # Unrecognized style.
    try:
        assert fmtr.get_style_class('non-existent')
        assert False
    except pygments.util.ClassNotFound:
        pass

# Generated at 2022-06-11 23:44:19.464243
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    step_list = [
        ("auto", Solarized256Style),
        (SOLARIZED_STYLE, Solarized256Style),
        ("monokai", pygments.styles.get_style_by_name(SOLARIZED_STYLE)),
    ]
    for color_scheme, assert_class in step_list:
        style = ColorFormatter.get_style_class(color_scheme)
        assert isinstance(style, assert_class)

# Generated at 2022-06-11 23:44:28.601596
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    """
    ColorFormatter.get_style_class
    ------------------------------

    Verify ColorFormatter.get_style_class return a class based on
    Solarized256Style when the style argument is "solarized256"
    """
    from httpie.cli import Environment
    from httpie.output.streams import DefaultStreams

    env = Environment(colors=True)

    color_formatter = ColorFormatter(
        env,
        color_scheme="solarized256",
        stdout=DefaultStreams.stdout,
        stderr=DefaultStreams.stderr,
    )

    assert isinstance(
        color_formatter.get_style_class("solarized256"),
        Solarized256Style,
    )

# Generated at 2022-06-11 23:44:39.815140
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from httpie import __version__
    from httpie.plugins.builtin import HTTPHeadersProcessor

    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Encoding: gzip\r\n'
        'Content-Length: 5\r\n'
        'Date: Fri, 08 May 2015 05:41:13 GMT\r\n'
        'Server: httpbin.org\r\n'
    )
    lexer = SimplifiedHTTPLexer()
    formatter = ColorFormatter(
        env=Environment(
            colors=256,
            styles=True,
        ),
        color_scheme=SOLARIZED_STYLE
    )
    headers = HTTPHeadersProcessor().process_headers(headers)
    assert headers == formatter.format_headers

# Generated at 2022-06-11 23:45:16.722790
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():

    from httpie.core import main
    from httpie.context import Environment

    env = Environment()
    args = main.parse_args(args=[], env=env)
    formatter = ColorFormatter(env, **args.__dict__)
    assert formatter.__dict__.has_key("explicit_json")
    assert formatter.__dict__.has_key("formatter")
    assert formatter.__dict__.has_key("http_lexer")

# Generated at 2022-06-11 23:45:27.551083
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments import highlight
    from pygments.token import *
    from pygments.lexers.text import HttpLexer
    from pygments.lexers.text import TextLexer

    def assert_highlighted(lexer, source, expected_tokens):
        tokens = [(ttype, value) for (ttype, value, start, end, line) in lexer.get_tokens(source)]
        assert tokens[:len(expected_tokens)] == expected_tokens

    def assert_highlighting(lexer, source, expected_fragments):
        assert highlight(source, lexer, formatter) == ''.join(expected_fragments)

    formatter = 'terminal'

    assert isinstance(SimplifiedHTTPLexer(formatter), HttpLexer)

# Generated at 2022-06-11 23:45:30.157372
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(env=Env(colors=256), explicit_json=False, color_scheme=SOLARIZED_STYLE) is not None


# Generated at 2022-06-11 23:45:31.367611
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    #TODO
    pass


# Generated at 2022-06-11 23:45:35.185352
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    try:
        import pytest
        pytest.importorskip('pygments')
    except ImportError:
        return
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.FruityStyle


# Unit tests for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-11 23:45:41.394084
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-11 23:45:44.694882
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter()
    assert formatter.is_enabled()
    assert formatter.fmt_headers == 'colors'
    assert formatter.fmt_body == 'colors'

# Generated at 2022-06-11 23:45:55.716786
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    from httpie import input
    from httpie.plugins import FormatterPlugin
    from httpie.compat import is_windows

    env = Environment()
    env.stdout_isatty = True
    env.colors = 256 if not is_windows else False
    color_scheme = color_scheme = 'fruity' if env.colors else 'auto'
    console_input = input.FileInput(
        stdin=input.get_binary_stream(env.stdin, '-', None),
        stdin_isatty=env.stdin_isatty
    )

# Generated at 2022-06-11 23:46:02.098734
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-11 23:46:03.010745
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') is not None

# Generated at 2022-06-11 23:46:42.533108
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer(pygments.lexer.RegexLexer)

# Generated at 2022-06-11 23:46:50.686176
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    text = 'GET /foo/bar HTTP/1.1\nContent-Type: text/html;charset=utf8\n' \
           '\n<html>\n<body>Hello World</body>\n'
    lexer = SimplifiedHTTPLexer()
    assert isinstance(lexer, Type)

    formatter = Terminal256Formatter(style=Solarized256Style)
    result = pygments.highlight(code=text, lexer=lexer, formatter=formatter)
    assert isinstance(result, str)

# Generated at 2022-06-11 23:46:55.074926
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment(colors=256))
    assert formatter.get_lexer_for_body('application/json', b'{"test": "test"}')
    assert formatter.get_lexer_for_body('application/json; charset=utf-8', b'{}') is None
    assert formatter.get_lexer_for_body('text/plain', b'{"test": "test"}')

# Generated at 2022-06-11 23:47:05.807295
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-11 23:47:06.773077
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    ColorFormatter(Environment(colors=256))

# Generated at 2022-06-11 23:47:16.303036
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Setup
    from httpie.core import http
    from httpie.core import main as httpie_core
    from httpie.core import MainRequestDumper
    from httpie.core import Message

    class FakeEnvironment:
        def __init__(self, colors_=True):
            self.colors = colors_

    env = FakeEnvironment()
    stream = main_request_dumper = MainRequestDumper(env)
    main_request_dumper.write = lambda x: None
    request = httpie_core.Request(env, stream, http)
    request.headers.update(
        {
            'content-type': 'text/html; charset=utf-8',
            'host': '127.0.0.1'
        }
    )

    # Act

# Generated at 2022-06-11 23:47:26.453803
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(None)
    lexer = formatter.get_lexer_for_body('application/json', '{}')
    assert lexer.name == 'JSON'
    lexer = formatter.get_lexer_for_body(
        'application/json', '{}', explicit_json=True
    )
    assert lexer.name == 'JSON'
    lexer = formatter.get_lexer_for_body('application/yaml', '{}')
    assert lexer.name == 'YAML'
    lexer = formatter.get_lexer_for_body('application/xml', '{}')
    assert lexer.name == 'XML'
    lexer = formatter.get_lexer_for_body('text/html', '{}')
    assert lexer

# Generated at 2022-06-11 23:47:35.237654
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    import httpie.context
    import httpie.plugins
    from httpie.compat import is_windows

    pygments_json_lexer = pygments.lexers.get_lexer_by_name('json')
    json_body = json.dumps({"a": 1, "b": 2})

    if is_windows:  # colors on Windows via colorama don't look that great
        formatter = ColorFormatter(
            Environment(colors=True), color_scheme='fruity'
        )
    else:
        formatter = ColorFormatter(
            Environment(colors=True), color_scheme='auto'
        )
    lexer = formatter.format_body(
        body=json_body, mime='application/json'
    )

    # Check that the lexer is a