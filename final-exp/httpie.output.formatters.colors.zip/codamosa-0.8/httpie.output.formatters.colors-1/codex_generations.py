

# Generated at 2022-06-11 23:37:57.772936
# Unit test for function get_lexer
def test_get_lexer():

    mime = 'text/html'
    lexer = get_lexer(mime, explicit_json=False)
    assert lexer.name == 'HTML'

    mime = 'application/json'
    lexer = get_lexer(mime, explicit_json=False)
    assert lexer.name == 'JSON'

    mime = 'application/foo+json'
    lexer = get_lexer(mime, explicit_json=False)
    assert lexer.name == 'JSON'

    mime = 'application/foo+json'
    lexer = get_lexer(mime, explicit_json=False, body='{"x": 1}')
    assert lexer.name == 'JSON'

    mime = 'application/foo+json'

# Generated at 2022-06-11 23:38:08.132243
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class MockColorFormatter:
        def __init__(self, env, explicit_json=False, color_scheme=DEFAULT_STYLE, **kwargs):
            self.explicit_json = explicit_json  # --json
            self.http_lexer = SimplifiedHTTPLexer()
            self.formatter = TerminalFormatter()
    formatter = MockColorFormatter(None)
    data = """Content-Type: application/json;charset=UTF-8
Cache-Control: no-cache

[
    {
        "test": "1"
    }
]
"""
    def get_lexer_for_body(mime, body):
        return formatter.get_lexer_for_body(mime, body)
    print(formatter.format_headers(data))

# Generated at 2022-06-11 23:38:19.363928
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Success case
    lexer = get_lexer(
        mime='application/json',
        explicit_json=False,
        body=''
    )
    assert isinstance(
        lexer,
        pygments.lexers.JsonLexer
    )

    # Failure case
    lexer = get_lexer(
        mime='application/json',
        explicit_json=False,
        body='{"a":[1,2,3]}'
    )
    assert not isinstance(
        lexer,
        pygments.lexers.JsonLexer
    )

    # Failure case (explicit_json=True)
    lexer = get_lexer(
        mime='application/json',
        explicit_json=True,
        body='{"a":[1,2,3]}'
    )


# Generated at 2022-06-11 23:38:28.059509
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    unittest.main()


if __name__ == '__main__':
    import unittest


    class SimplifiedHTTPLexerTestCase(unittest.TestCase):
        def setUp(self):
            self.lexer = SimplifiedHTTPLexer()

        def test_http_request_line(self):
            fragment = 'GET / HTTP/1.1'

# Generated at 2022-06-11 23:38:30.361962
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert pygments.lexers.get_lexer_for_mimetype('application/json') == pygments.lexers.JSONLexer

# Generated at 2022-06-11 23:38:41.532955
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """测试ColorFormatter格式化body"""
    from httpie.core import main
    import os
    from pyperclip import copy
    from httpie import __version__ as version
    from httpie.compat import is_windows

    format = 'colors'
    env = Environment(colors=256)
    data = [
        {'Content-Type': 'application/json'},
        {'server.version': version},
        {'os.name': os.name},
        {'is_windows': is_windows},
        {'ENABLE_COLOR': True}
    ]
    body = {'data': data}
    body = json.dumps(body, ensure_ascii=False)

# Generated at 2022-06-11 23:38:45.695907
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class _Env(object):
        colors = 0
    env = _Env()
    colorFormatter = ColorFormatter(env, color_scheme='solarized')
    style = colorFormatter.get_style_class('solarized')
    assert style == Solarized256Style

# Generated at 2022-06-11 23:38:50.925188
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.cli import parser

    args = parser.parse_args(args=[])
    env = Environment(args)
    cf = ColorFormatter(env)
    assert cf.format_body(body='{"data": "value"}',
                          mime='application/x.www.form.urlencoded') is not None



# Generated at 2022-06-11 23:38:55.655963
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(
        _env=Environment(
            colors=256,
            style=SOLARIZED_STYLE,
            explicit_json=True,
        ),
    )
    assert formatter.explicit_json == True
    assert formatter.is_enabled() == True

# Generated at 2022-06-11 23:39:06.551106
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.compat import is_windows
    import pygments
    import pygments.lexers
    import pygments.lexers.special
    import pygments.lexers.text
    import pygments.lexers.data
    import json
    env = Environment()

    if not is_windows:
        env.colors = 256
    else:
        env.colors = 16
    # Test 1
    formatter = ColorFormatter(env, True)
    test_string = '{"foo":null}'
    assert formatter.format_body(test_string, 'application/json') == pygments.highlight(
        code=test_string, lexer=pygments.lexers.get_lexer_by_name('json'), formatter=formatter.formatter)

    # Test

# Generated at 2022-06-11 23:39:20.538000
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.color = True
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    if is_windows:
        assert color_formatter.formatter.style_name == DEFAULT_STYLE
    else:
        assert color_formatter.formatter.style_name == AUTO_STYLE
    assert color_formatter.explicit_json is False
    assert isinstance(color_formatter.http_lexer, pygments.lexer.RegexLexer)

# Generated at 2022-06-11 23:39:31.661781
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = {'colors': 256}
    formatter = ColorFormatter(env, explicit_json=False)
    formatter_json = ColorFormatter(env, explicit_json=True)

    assert formatter.format_body("","text/plain") == ""
    assert formatter.format_body("aaa", "text/plain") == "aaa"
    assert formatter.format_body("bbb","text/html") == "bbb"
    assert formatter.format_body("ccc","text/html; charset=UTF-8") == "ccc"
    assert formatter_json.format_body("{}","text/plain") == "\x1b[36m{}\x1b[0m\x1b(B\x1b[m"



# Generated at 2022-06-11 23:39:34.334010
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("fruity") == pygments.styles.get_style_by_name("fruity")

# Generated at 2022-06-11 23:39:44.516888
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(Environment())
    body = formatter.format_body('{"name":"value"}', 'application/json')
    assert '\x1b[0m\x1b[34m{\x1b[0m\x1b[0m\x1b[0m\n' in body

# Generated at 2022-06-11 23:39:53.240784
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    print(SimplifiedHTTPLexer)
    print(http_lexer)

    test_string = """
HTTP/1.1 200 OK\r
Date: Wed, 23 Mar 2016 11:15:58 GMT\r
\r
"""

    t = http_lexer.get_tokens(test_string)
    print(list(t))
    import pygments.formatters.terminal256
    print(pygments.formatters.terminal256.Terminal256Formatter(style=Solarized256Style).get_style_defs())

# Generated at 2022-06-11 23:40:06.004576
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # As per http://tools.ietf.org/html/rfc2397
    #    dataurl    := "data:" [ mediatype ] [ ";base64" ] "," data
    mime = 'text/html'
    body = '<html><head><title>hello world</title></head></html>'
    lexer = get_lexer(mime, body)
    assert lexer is not None
    assert lexer.name == 'HTML'

    mime = 'text/html;charset=utf-8'
    lexer = get_lexer(mime, body)
    assert lexer is not None
    assert lexer.name == 'HTML'

    mime = 'text/html;charset=utf-8;truncated'

# Generated at 2022-06-11 23:40:14.991929
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Test set
    env_colors_none = Environment(colors=None)
    env_colors_16 = Environment(colors=16)
    env_colors_256 = Environment(colors=256)

    # Expected results

# Generated at 2022-06-11 23:40:17.415030
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from .response import get_style_class
    assert get_style_class('solarized') == Solarized256Style



# Generated at 2022-06-11 23:40:29.919037
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie import ExitStatus


    class TestEnvironment(Environment):
        def __init__(self, color_scheme, colors):
            super().__init__()
            self.stdout_isatty = True
            self.color_scheme = color_scheme
            self.colors = colors

    # Test whether the right lexer and formatter are used
    # in every case.
    def test():
        env = TestEnvironment(finish_color_scheme, finish_num_colors)
        color_formatter = ColorFormatter(env, False, color_scheme)
        if has_256_colors:
            assert isinstance(color_formatter.formatter, Terminal256Formatter)

# Generated at 2022-06-11 23:40:31.703449
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    colorFormatter = ColorFormatter(Environment())
    assert colorFormatter

# Generated at 2022-06-11 23:40:38.576436
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class('nonexistent')
    assert style == Solarized256Style



# Generated at 2022-06-11 23:40:51.193390
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # get_lexer_by_name() is called in constructor of SimplifiedHTTPLexer
    # This function is mocked in this test to avoid doing unnecessary
    # expensive operations like loading lexers from disk.
    # get_lexer_by_name() is also used in get_lexer_for_body() and is
    # already tested in test_get_lexer().
    from mock import patch
    with patch("httpie.plugins.builtin.colors.pygments.lexers.get_lexer_by_name") as get_lexer_by_name:
        get_lexer_by_name.return_value = None
        l = SimplifiedHTTPLexer()
        tokens = l.get_tokens("Content-Type: application/xml +xml")
        assert tokens

# Generated at 2022-06-11 23:40:53.000746
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'

# Generated at 2022-06-11 23:40:57.779156
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    splex=SimplifiedHTTPLexer()
    assert splex.name == "HTTP"
    assert splex.aliases == ['http']
    assert splex.filenames == ['*.http']
    assert isinstance(splex.tokens, dict)

# Generated at 2022-06-11 23:41:01.538668
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    body = ''
    body = lexer.get_tokens(body)
    next(body)
    body = lexer.get_tokens_unprocessed(body)

# Generated at 2022-06-11 23:41:05.215324
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class('solarized')
    assert isinstance(style, type)
    assert issubclass(style, pygments.style.Style)
    assert style is Solarized256Style

# Generated at 2022-06-11 23:41:08.027806
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():

    formatter = ColorFormatter(Environment(colors=True))
    formatter.format_body('{"key":"value"}', mime="application/json")
    assert True



# Generated at 2022-06-11 23:41:17.233681
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    http_lexer = SimplifiedHTTPLexer()
    formatter = TerminalFormatter()
    headers = """\
HTTP/1.1 200 OK
content-length: 96

"""
    assert(pygments.highlight(
            code=headers,
            lexer=http_lexer,
            formatter=formatter,
        ).strip() == "\x1b[38;5;250mHTTP/1.1 200 OK\n\x1b[38;5;238mcontent-length"
                ": 96\n\n\x1b[39m\x1b[39m")


# Generated at 2022-06-11 23:41:20.329952
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.output.formatter import ColorFormatter
    color_style = ColorFormatter.get_style_class('fruity')
    assert(color_style == pygments.styles.FruityStyle)

# Generated at 2022-06-11 23:41:27.433683
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment = Environment()
    environment.colors = False
    color_formatter = ColorFormatter(environment)
    assert not color_formatter.enabled
    assert color_formatter.formatter is None
    assert color_formatter.http_lexer is None
    environment.colors = 256
    color_formatter = ColorFormatter(environment)
    assert color_formatter.enabled
    assert isinstance(color_formatter.formatter, Terminal256Formatter)
    assert isinstance(color_formatter.http_lexer, SimplifiedHTTPLexer)
    environment.colors = True
    color_formatter = ColorFormatter(environment)
    assert color_formatter.enabled
    assert isinstance(color_formatter.formatter, TerminalFormatter)

# Generated at 2022-06-11 23:41:38.818856
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment())

# Generated at 2022-06-11 23:41:47.773635
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import plugin_manager

    plugin_manager.load_installed_plugins()
    httpie = plugin_manager.instantiate(
        'HTTPie',
        ['http'] + [
            '--json' if is_windows else '--pretty=all',
            '--print=b'
        ]
    )
    httpie.stdin_isatty = True
    httpie.output = httpie.get_output_instance()
    httpie.environment = Environment(colors=256)
    httpie.formatter = plugin_manager.instantiate(
        'ColorFormatter',
        env=httpie.environment,
        explicit_json=True
    )


# Generated at 2022-06-11 23:41:49.182630
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(True, 256, True)
    ColorFormatter(env)

# Generated at 2022-06-11 23:41:51.612595
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer.name == 'HTTP'
    assert SimplifiedHTTPLexer.aliases == ['http']

# Generated at 2022-06-11 23:41:54.180858
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-11 23:41:59.168938
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(# pylint: disable=unused-variable
        env=Environment(colors=True,
                        stdout_isatty=True,
                        is_windows=is_windows),
        explicit_json=False,
        color_scheme='solarized')
    assert formatter.get_lexer_for_body(
        mime='application/json',
        body='{"foo": "bar"}'
    )

# Generated at 2022-06-11 23:42:10.314925
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    global AUTO_STYLE
    global DEFAULT_STYLE
    global AVAILABLE_STYLES
    global SOLARIZED_STYLE
    global is_windows

    is_windows = False
    DEFAULT_STYLE = AUTO_STYLE

    print("[*] Testing ColorFormatter...")
    test_env = Environment()
    test_env.colors = 256

    test_color_formatter = ColorFormatter(test_env, False, DEFAULT_STYLE)

    print("[x] Testing get_style_class() ...")
    print("[*] Default:")
    if test_color_formatter.get_style_class(DEFAULT_STYLE) == Solarized256Style:
        print("[+] PASS")

# Generated at 2022-06-11 23:42:18.998154
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    """
    This test is meant to test ColorFormatter's constructor
    """
    # Multiple style colors for different platforms
    import platform
    env_vars = {'LC_ALL': '', 'LANG': ''}
    env_windows = {'LC_ALL': '', 'LANG': 'en_US.UTF-8'}
    env_linux = {'LC_ALL': '', 'LANG': 'en_US.utf8'}

    s = ColorFormatter(Environment(env_vars, 256))
    assert(s.enabled)

    s1 = ColorFormatter(Environment(env_windows, 256))
    assert(s1.enabled)

    s2 = ColorFormatter(Environment(env_linux, 256))
    assert(s2.enabled)


# Generated at 2022-06-11 23:42:22.839360
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(AUTO_STYLE) is None
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE)\
           is Solarized256Style
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) is None

# Generated at 2022-06-11 23:42:32.505853
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import os
    import pprint
    import io
    import unittest
    import sys
    import signal

    pp = pprint.PrettyPrinter(indent=4)

    # Test ColorFormatter.get_style_class()
    def test_get_style_class(self):
        self.assertEqual(ColorFormatter.get_style_class('fruity'),
                         pygments.styles.get_style_by_name('fruity'))
        self.assertEqual(ColorFormatter.get_style_class('solarized'),
                         Solarized256Style)
        self.assertEqual(ColorFormatter.get_style_class('auto'),
                         pygments.styles.get_style_by_name(DEFAULT_STYLE))


# Generated at 2022-06-11 23:42:57.710469
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.context import Environment
    from httpie.plugins import PluginManager

    environment = Environment()
    plugin_manager = PluginManager(environment=environment)
    plugin_manager.load_installed_plugins()
    c = ColorFormatter(env=environment, plugin_manager=plugin_manager)

    mime = 'text/html'
    body = """<html>
    <div>
        <p>Test</p>
    </div>
    </html>"""

    assert c.get_lexer_for_body(mime, body).__name__ == 'HTMLLexer'

# Generated at 2022-06-11 23:43:05.361331
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.context
    httpie.context.env = httpie.context.Environment()
    httpie.context.env.colors = 256

    colorFormatter = ColorFormatter(httpie.context.env)
    body = '{"key": "value"}'
    mime = 'application/json'

    lexer = colorFormatter.get_lexer_for_body(mime, body)
    assert lexer is not None

# Generated at 2022-06-11 23:43:14.256073
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    manager = FormatterPluginManager()
    color_formatter = manager.instantiate(
        name='colors',
        explicit_json=False,
        color_scheme='auto'
    )
    from io import StringIO
    stream = StringIO()
    color_formatter.stream = stream
    headers = 'GET / HTTP/1.1\r\nHost: www.baidu.com\r\n'
    color_formatter.format_headers(headers=headers)
    print(stream.getvalue())


# Generated at 2022-06-11 23:43:24.036740
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-11 23:43:33.811091
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    # Check the headers
    assert (lexer.get_tokens_unprocessed('GET / HTTP/1.1\n')
            == [(1, pygments.token.Name.Function, 'GET'),
                (1, pygments.token.Text, ' '),
                (1, pygments.token.Name.Namespace, '/'),
                (1, pygments.token.Text, ' '),
                (1, pygments.token.Keyword.Reserved, 'HTTP'),
                (1, pygments.token.Operator, '/'),
                (1, pygments.token.Number, '1.1')])

# Generated at 2022-06-11 23:43:37.207417
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("solarized") == Solarized256Style
    assert ColorFormatter.get_style_class("solarized256") == Solarized256Style

# Generated at 2022-06-11 23:43:47.996471
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import pygments.lexers.text
    
    # Copy formatter of original HttpLexer
    formatter = pygments.lexers.text.HttpLexer.formatter
    
    # Replace HttpLexer with SimplifiedHTTPLexer
    with pygments.lexers.text.HttpLexer as pygments.lexers.text.HttpLexer:
        pygments.lexers.text.HttpLexer = SimplifiedHTTPLexer
        pygments.lexers.text.HttpLexer.formatter = formatter

    # Assert http_lexer name
    assert pygments.lexers.text.HttpLexer.name == 'HTTP'

    # Assert http_lexer aliases
    assert pygments.lexers.text.HttpLexer.aliases == ['http']

    # Assert http_lexer filen

# Generated at 2022-06-11 23:43:49.273376
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert 'HTTP' in SimplifiedHTTPLexer.tokens['root']

# Generated at 2022-06-11 23:43:50.711662
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer


# Generated at 2022-06-11 23:44:00.097771
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env)
    headers = '''GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.2


'''


# Generated at 2022-06-11 23:44:40.972536
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    try:
        pygments.styles.get_style_by_name('non_existent_style')
    except ClassNotFound:
        pass  # Expected, as we are testing that
    else:
        raise AssertionError('The non_existent_style should not exist')
    assert not ColorFormatter.get_style_class('non_existent_style')
    assert ColorFormatter.get_style_class('default')

# Generated at 2022-06-11 23:44:51.399179
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    sample_headers = ('GET / HTTP/1.1\r\n'
                      'Content-Type: text/html; charset=UTF-8\r\n\r\n')
    output = pygments.highlight(
        code=sample_headers,
        lexer=http_lexer,
        formatter=Terminal256Formatter(
            style=Solarized256Style
        )
    ).strip()

# Generated at 2022-06-11 23:44:52.158561
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized')

# Generated at 2022-06-11 23:44:53.502345
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(AUTO_STYLE).__name__ == 'SolarizedStyle'

# Generated at 2022-06-11 23:45:04.081128
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-11 23:45:14.421866
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # type: () -> None
    c = ColorFormatter(Environment(), explicit_json=False)
    assert get_lexer(
        c.http_lexer,
        mime='application/json',
        explicit_json=False,
        body='{"json_test": "success"}'
    ) is not None
    assert get_lexer(
        mime='application/x-javascript',
        explicit_json=False,
        body='{}'
    ) is not None
    assert get_lexer(
        mime='text/plain',
        explicit_json=False,
        body='{}'
    ) is None
    assert get_lexer(
        mime='text/plain',
        explicit_json=True,
        body='{}'
    ) is not None


test = test_ColorForm

# Generated at 2022-06-11 23:45:21.476976
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import sys
    import httpie.cli
    class FakeEnvironment:
        colors = True
        def __init__(self):
            self.style_errors = True
            self.colors = '256'
            self.stdout = sys.stdout
    env = FakeEnvironment()
    formatter = ColorFormatter(env=env)

# Generated at 2022-06-11 23:45:32.529159
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pygments.lexer

    class MockLexer(pygments.lexer.RegexLexer):
        name = 'Mock'

    class mock:
        pass

    env = mock()
    env.colors = True
    color_formatter = ColorFormatter(env)
    color_formatter.get_lexer_for_body = mock()
    exp_format_body = '<pygments.format.Format object at 0x7f5adbdb5c70>'
    color_formatter.format_body = lambda body, mime: exp_format_body

    color_formatter.get_lexer_for_body.return_value = MockLexer
    fmt_body = color_formatter.format_body('mock body', 'application/test')
    assert fmt_body == exp_format_body



# Generated at 2022-06-11 23:45:33.694804
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-11 23:45:35.482364
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.enabled

# Generated at 2022-06-11 23:46:57.368505
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    lexer.get_tokens_unprocessed(
        "GET / HTTP/1.1\r\nHeader: value\r\n")

# Generated at 2022-06-11 23:47:08.430399
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import unittest
    import textwrap
    from httpie.context import Environment
    from httpie.plugins.colors.auto import ColorFormatter
    from httpie.plugins.colors.auto import test_SimplifiedHTTPLexer as test_SimplifiedHTTPLexer
    class TestSimplifiedHTTPLexer(unittest.TestCase):
        def setUp(self):
            self.env = Environment(colors=True)
            self.formatter = ColorFormatter(env=self.env)
            self.lexer = self.formatter.http_lexer  # type: pygments.lexer.RegexLexer


# Generated at 2022-06-11 23:47:17.473744
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import BytesIO, is_bytes
    from httpie.output.streams import get_default_stream

    color_formatter = ColorFormatter(
        env = None,
        explicit_json = False,
        color_scheme = DEFAULT_STYLE
    )

    # 1. Console: httpie.output.streams.StdoutBytesIO
    # 2. File: httpie.compat.BytesIO
    # 3. Pipe: httpie.output.streams.StdoutBytesIO

    #### 1. Write result in console
    # write result to httpie.output.streams.StdoutBytesIO
    stream = get_default_stream('stdout')
    # for console, environment.is_stdout is True

# Generated at 2022-06-11 23:47:27.539446
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    import unittest
    import unittest.mock as mock

    class TestCase(unittest.TestCase):
        @mock.patch('pygments.styles.get_style_by_name',
                    new_callable=mock.Mock)
        def test_get_style_class_when_style_is_in_available_styles(
                self,
                mocked_pygments_styles_get_style_by_name,
        ):
            test_style_name = 'testStyle'
            mocked_pygments_styles_get_style_by_name.return_value = \
                test_style_name

            output = ColorFormatter.get_style_class(test_style_name)


# Generated at 2022-06-11 23:47:28.481815
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # TODO: write a unit test
    pass

# Generated at 2022-06-11 23:47:31.074293
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env=Environment()
    color_scheme='solarized'
    ColorFormatter(env=env, explicit_json=True, color_scheme=color_scheme)

# Generated at 2022-06-11 23:47:39.460795
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import str

    class MockEnvironment(object):
        def __init__(self):
            self.colors = 256
