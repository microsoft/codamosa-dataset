

# Generated at 2022-06-17 20:25:14.352368
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:25:23.065823
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style

# Generated at 2022-06-17 20:25:34.763871
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_SimplifiedHTTPLexer

# Generated at 2022-06-17 20:25:46.318940
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.output.streams import UnsupportedEnvironment

    env = Environment(
        stdin=UnsupportedEnvironment,
        stdout=UnsupportedEnvironment,
        stderr=UnsupportedEnvironment,
        colors=256,
        is_windows=False,
        stdout_isatty=True,
        stdin_isatty=True,
        output_options={},
        config={},
    )
    manager = FormatterPluginManager(env=env)
    formatter = manager.get('colors')

# Generated at 2022-06-17 20:26:00.327750
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:10.712378
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter

    env = Environment(colors=256)
    formatter = ColorFormatter(env)

    # Test for HTTP request
    headers = '''GET / HTTP/1.1
Host: localhost:8080
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive

'''

# Generated at 2022-06-17 20:26:21.516484
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:27.270502
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:26:28.683943
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:39.326493
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_

# Generated at 2022-06-17 20:26:49.629132
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True

# Generated at 2022-06-17 20:27:01.963346
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:14.372124
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:22.841339
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import format_headers
    from httpie.plugins.colors import format_body
    from httpie.plugins.colors import get_style_class

# Generated at 2022-06-17 20:27:34.583375
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pygments.lexers
    import pygments.lexers.special
    import pygments.lexers.text
    import pygments.lexers.web
    import pygments.lexers.data
    import pygments.lexers.python
    import pygments.lexers.compiled
    import pygments.lexers.markup
    import pygments.lexers.shell
    import pygments.lexers.agile
    import pygments.lexers.net
    import pygments.lexers.configs
    import pygments.lexers.dotnet
    import pygments.lexers.parsers
    import pygments.lexers.functional
    import pygments.lexers.crypto
    import pygments.lexers.asm
    import pygments.lexers.perl
    import pygments.lexers.ruby

# Generated at 2022-06-17 20:27:45.363836
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:48.226419
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:50.745989
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Test for constructor of class ColorFormatter
    env = Environment()
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter is not None
    assert color_formatter.http_lexer is not None
    assert color_formatter.explicit_json is False
    assert color_formatter.enabled is True
    assert color_formatter.group_name == 'colors'


# Generated at 2022-06-17 20:27:51.619026
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-17 20:28:02.695139
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import SyntaxHighlightPlugin

    # Test with JSONFormatterPlugin
    json_formatter = JSONFormatterPlugin()
    json_formatter.enabled = True
    stream_formatter = StreamFormatterPlugin()
    stream_formatter.enabled = True
    pretty_options = PrettyOptionsPlugin()
    pretty_options.enabled = True
    syntax_highlight = SyntaxHighlightPlugin()
    syntax_highlight.enabled = True


# Generated at 2022-06-17 20:28:19.870948
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:28:21.728667
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:23.250939
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:33.311426
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    env = Environment(colors=256)
    manager = FormatterPluginManager(env=env)
    formatter = manager.instantiate(
        name='colors',
        color_scheme='solarized'
    )
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Connection: Closed

'''

# Generated at 2022-06-17 20:28:43.678190
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer

# Generated at 2022-06-17 20:28:55.946114
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieArgumentParser
    from httpie.plugins.builtin import HTTPieStatusExits


# Generated at 2022-06-17 20:28:57.142505
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:03.031040
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme="solarized")
    assert color_formatter.formatter.__class__.__name__ == "Terminal256Formatter"
    assert color_formatter.http_lexer.__class__.__name__ == "SimplifiedHTTPLexer"
    assert color_formatter.get_style_class("solarized").__name__ == "Solarized256Style"

# Generated at 2022-06-17 20:29:13.688067
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import UnixSocketPlugin
    from httpie.plugins.builtin import WindowsPlugin
    from httpie.plugins.builtin import WINDOWS
    from httpie.plugins.builtin import UNIX
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 20:29:18.169908
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexers import get_lexer_by_name
    from pygments.lexers.text import HttpLexer as PygmentsHttpLexer

    # Test request line
    lexer = SimplifiedHTTPLexer()
    tokens = list(lexer.get_tokens('GET / HTTP/1.1'))
    assert tokens == [
        (Token.Name.Function, 'GET'),
        (Token.Text, ' '),
        (Token.Name.Namespace, '/'),
        (Token.Text, ' '),
        (Token.Keyword.Reserved, 'HTTP'),
        (Token.Operator, '/'),
        (Token.Number, '1.1')
    ]

    # Test response line
    lexer = SimplifiedHTTPLexer()
   

# Generated at 2022-06-17 20:29:33.431802
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:44.010238
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:29:54.707295
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:30:05.920208
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(Environment(colors=256))
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True

    color_formatter = ColorFormatter(Environment(colors=256), explicit_json=True)
    assert color_formatter.explicit_json == True

    color_formatter = ColorFormatter(Environment(colors=256), color_scheme='solarized')
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

    color_formatter = Color

# Generated at 2022-06-17 20:30:13.790447
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.format_body('{"a":1}', 'application/json') == '\x1b[38;5;45m{\x1b[39m\x1b[38;5;45m"a"\x1b[39m\x1b[38;5;45m:\x1b[39m\x1b[38;5;45m1\x1b[39m\x1b[38;5;45m}\x1b[39m'

# Generated at 2022-06-17 20:30:15.242090
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:23.921183
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import get_default_streams
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import get_default_streams
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import get_default_stream

# Generated at 2022-06-17 20:30:25.578319
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:34.719796
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import UnixSocketPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieOptionsPlugin
    from httpie.plugins.builtin import HTTPieEnvironmentPlugin
    from httpie.plugins.builtin import HTTPieColorsPlugin
    from httpie.plugins.builtin import HTTPieConfigPlugin

# Generated at 2022-06-17 20:30:42.579190
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import Stream
    from httpie.output.streams import UncolorizedStream
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import Plugin
    from httpie.plugins import View
    from httpie.plugins import ViewPlugin
    from httpie.plugins import builtin_plugins
    from httpie.plugins import builtin_views
    from httpie.plugins import get_view_class
    from httpie.plugins import plugin_manager
    from httpie.plugins import view_registry
    from httpie.plugins import view_registry
    from httpie.plugins import view_registry
    from httpie.plugins import view_registry
    from httpie.plugins import view_registry
    from httpie.plugins import view_registry

# Generated at 2022-06-17 20:31:11.203612
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:31:17.989505
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPGzip
    from httpie.plugins.builtin import HTTPJson
    from httpie.plugins.builtin import HTTPPretty
    from httpie.plugins.builtin import HTTPPrintHooks
    from httpie.plugins.builtin import HTTPPrint0
    from httpie.plugins.builtin import HTTPStream
    from httpie.plugins.builtin import HTTPTrace
    from httpie.plugins.builtin import HTTPVerbose
    from httpie.plugins.builtin import HTTPVersion

# Generated at 2022-06-17 20:31:23.801949
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:31:35.819455
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor

# Generated at 2022-06-17 20:31:45.996012
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_test

# Generated at 2022-06-17 20:31:53.117026
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_SimplifiedHTTPLexer
    from httpie.plugins.colors import SimplifiedHTTPLexer

# Generated at 2022-06-17 20:31:58.749802
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:08.713529
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') is None
    assert get_lexer('text/plain', body='{"foo": "bar"}') is None
    assert get_lexer('text/plain', explicit_json=True, body='{"foo": "bar"}')
    assert get_lexer('application/json')
    assert get_lexer('application/json', body='{"foo": "bar"}')
    assert get_lexer('application/json', body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo')

# Generated at 2022-06-17 20:32:15.750570
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256-light') == Solarized256Style

# Generated at 2022-06-17 20:32:24.716790
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''

# Generated at 2022-06-17 20:33:02.017682
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_stream
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeadersPlugin
    from httpie.plugins.builtin import HTTPBodyPlugin
    from httpie.plugins.builtin import HTTPTracebackPlugin
    from httpie.plugins.builtin import HTTPErrorPlugin
    from httpie.plugins.builtin import HTTPStatsPlugin
    from httpie.plugins.builtin import HTTPPrettyPlugin
    from httpie.plugins.builtin import HTTPFormatterPlugin
    from httpie.plugins.builtin import HTTPPathProcessorPlugin
    from httpie.plugins.builtin import HTTPPathFilterPlugin

# Generated at 2022-06-17 20:33:09.068614
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_error_stream
   

# Generated at 2022-06-17 20:33:17.983696
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class

# Generated at 2022-06-17 20:33:25.834213
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:33:32.600418
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials

    env = Environment(colors=256, stdin=None, stdout=None,
                      stdin_isatty=True, stdout_isatty=True)
    fpm = FormatterPluginManager(env=env)
    fpm.add_plugin(PrettyOptionsPlugin(env=env))
    fpm.add_plugin

# Generated at 2022-06-17 20:33:41.845541
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_get_lexer_for_body_json
    from httpie.plugins.colors import test_get_lexer_for_body_json_explicit

# Generated at 2022-06-17 20:33:52.847607
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:34:01.509043
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:34:12.232235
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPIgnoreStdin
    from httpie.plugins.builtin import HTTPFollowRedirects
    from httpie.plugins.builtin import HTTPVerbose
    from httpie.plugins.builtin import HTTPStream
    from httpie.plugins.builtin import HTTPOutputOptions
    from httpie.plugins.builtin import HTTPPrettyOptions
    from httpie.plugins.builtin import HTTPOptions

# Generated at 2022-06-17 20:34:21.668099
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solar