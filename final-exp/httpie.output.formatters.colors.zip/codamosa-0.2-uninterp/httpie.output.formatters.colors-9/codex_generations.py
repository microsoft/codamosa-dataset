

# Generated at 2022-06-17 20:25:04.238615
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/html+jinja') == pygments.lexers.get_lexer_by_name('html+jinja')
    assert get_lexer('text/html+jinja2') == pygments.lexers.get_lexer_by_name('html+jinja2')
    assert get_lexer('text/html+jinja2', explicit_json=True, body='{}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('text/html+jinja2', explicit_json=True, body='{') == pygments.lexers.get_lexer_by_name('html+jinja2')

# Generated at 2022-06-17 20:25:16.681883
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json', explicit_json=True, body='{') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None

# Generated at 2022-06-17 20:25:18.011364
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:25:29.258788
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter

    env = Environment(colors=True)
    formatter = ColorFormatter(env)
    assert isinstance(formatter, FormatterPlugin)
    assert formatter.enabled

# Generated at 2022-06-17 20:25:37.690361
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
   

# Generated at 2022-06-17 20:25:47.717221
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams


# Generated at 2022-06-17 20:26:00.531995
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_

# Generated at 2022-06-17 20:26:01.977046
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:11.838869
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    color_formatter = ColorFormatter(env)

# Generated at 2022-06-17 20:26:22.094376
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''

# Generated at 2022-06-17 20:26:33.553785
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer


# Generated at 2022-06-17 20:26:43.688220
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows

# Generated at 2022-06-17 20:26:52.315331
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthPlugin
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPPassAuthPlugin
    from httpie.plugins.builtin import HTTPNtlmAuth
    from httpie.plugins.builtin import HTTPNtlmAuthPlugin
    from httpie.plugins.builtin import HTTPNegotiateAuth
    from httpie.plugins.builtin import HTTPNegotiateAuthPlugin

# Generated at 2022-06-17 20:26:57.443548
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:02.543059
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import Stream
    from httpie.output.streams import write_to_stream
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_

# Generated at 2022-06-17 20:27:15.168044
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import str
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_ColorFormatter_format_headers_solarized
    from httpie.plugins.colors import test_ColorFormatter_format_headers_solarized_256

# Generated at 2022-06-17 20:27:23.343140
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:34.833174
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_streams
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream_colored
    from httpie.output.streams import write_to_output_stream_plain
    from httpie.output.streams import write_to_output_stream_raw
    from httpie.output.streams import write_to_output_stream_verbose
    from httpie.output.streams import write_to_output_stream_debug

# Generated at 2022-06-17 20:27:45.627364
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    env = Environment()
    env.stdout = open('/dev/null', 'w')
    env.stderr = open('/dev/null', 'w')
    env.stdin = open('/dev/null', 'r')
    env.colors = 256
    if is_windows:
        env.is_windows = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.format_body('{"a":1}', 'application/json') == '{\n    "a": 1\n}'

# Generated at 2022-06-17 20:27:52.591619
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light256') == Solarized256Style

# Generated at 2022-06-17 20:28:02.983657
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_format_headers
    from httpie.plugins.colors import test_format_

# Generated at 2022-06-17 20:28:07.688654
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:28:09.699662
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment(colors=256))
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:28:20.327696
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_lexer_for_body_json
    from httpie.plugins.colors import test_get_lexer_for_body_json_explicit
    from httpie.plugins.colors import test_get_lexer_for_body_json_explicit_fail

# Generated at 2022-06-17 20:28:27.907935
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_stream
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer

# Generated at 2022-06-17 20:28:29.736592
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:40.588907
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:28:45.241302
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:28:56.595953
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    from httpie.plugins.colors import ColorFormatter
    import pygments.lexers
    import pygments.lexers.special
    import pygments.lexers.text
    import pygments.lexers.web
    import pygments.lexers.data
    import pygments.lexers.compiled
    import pygments.lexers.agile
    import pygments.lexers.functional
    import pygments.lexers.markup
    import pygments.lexers.misc
    import pygments.lexers.python
    import pygments.lexers.dotnet
    import pygments.lexers.java


# Generated at 2022-06-17 20:29:03.870619
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.enabled == True
    assert formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.group_name == 'colors'
    assert formatter.name == 'colors'
    assert formatter.version == '1.0'
    assert formatter.description == 'Colorize using Pygments'
    assert formatter.help == 'Colorize using Pygments'
    assert formatter.args == []
    assert formatter.args_options == []
    assert formatter.options == []
    assert form

# Generated at 2022-06-17 20:29:21.718243
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPGzip
    from httpie.plugins.builtin import HTTPJson
    from httpie.plugins.builtin import HTTPTrace
    from httpie.plugins.builtin import HTTPX11Auth
    from httpie.plugins.builtin import HTTPXAuth
    from httpie.plugins.builtin import HTTPXFile
    from httpie.plugins.builtin import HTTPXFileField
    from httpie.plugins.builtin import HTTPXFileFields
    from httpie.plugins.builtin import HTTPXFileFields
    from httpie.plugins.builtin import HTTPXFileFields

# Generated at 2022-06-17 20:29:24.396542
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer

# Generated at 2022-06-17 20:29:27.431103
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    formatter = ColorFormatter(env)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:29:38.314300
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:29:50.248645
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    headers = """GET / HTTP/1.1
Host: example.com
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.2

"""

# Generated at 2022-06-17 20:29:52.257059
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:58.978550
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:30:10.066249
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_Solarized256Style_background_color
   

# Generated at 2022-06-17 20:30:21.256519
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style

# Generated at 2022-06-17 20:30:31.836727
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:31:01.250534
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''

# Generated at 2022-06-17 20:31:04.757910
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:31:14.159859
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{"a": 1}') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a": 1}') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a": 1}') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a": 1}') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a": 1}') is not None
    assert formatter.get_lexer_for_

# Generated at 2022-06-17 20:31:21.899498
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.get_lexer_for_body('application/json', '{"foo": "bar"}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body('application/json', '{"foo": "bar"}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body('application/json', '{"foo": "bar"}') == pygments.lexers.get_lexer_

# Generated at 2022-06-17 20:31:33.790095
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.stdout_isatty = True
    env.colors = 256
    env.color_scheme = 'solarized'
    formatter = ColorFormatter(env)
    body = formatter.format_body('{"hello": "world"}', 'application/json')

# Generated at 2022-06-17 20:31:41.951139
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:31:50.160632
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')

# Generated at 2022-06-17 20:31:56.509225
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:01.103677
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import JSONPlugin
    from httpie.plugins.builtin import PrettyPlugin
    from httpie.plugins.builtin import ColorsPlugin
    from httpie.plugins.builtin import HTTPieColorsPlugin
    from httpie.plugins.builtin import HTTPiePrettyPlugin
    from httpie.plugins.builtin import HTTPieJSONPlugin
    from httpie.plugins.builtin import HTTPieFormatterPlugin
    from httpie.plugins.builtin import HTTPieColorsFormatterPlugin
    from httpie.plugins.builtin import HTTPiePrettyFormatterPlugin
    from httpie.plugins.builtin import HTTPieJSONFormatterPlugin
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 20:32:12.428008
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    import pygments.lexers
    import pygments.lexers.special
    import pygments.lexers.text
    import pygments.lexers.data
    import pygments.lexers.html
    import pygments.lexers.markup
    import pygments.lexers.agile
    import pygments.lexers.dotnet
    import pygments.lexers.functional
    import pygments.lexers.jvm
    import pygments.lexers.misc
    import pygments.lexers.net
    import pygments.lexers.python
    import pygments.lexers.scripting
    import pygments.lexers.templates
    import pygments.lexers.web
    import py

# Generated at 2022-06-17 20:32:58.070901
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_streams
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream

# Generated at 2022-06-17 20:33:07.928526
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.core import main
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPProxyPassAuth
    from httpie.plugins.builtin import HTTPTrace
    from httpie.plugins.builtin import HTTPOptions
    from httpie.plugins.builtin import HTTPHead

# Generated at 2022-06-17 20:33:13.084579
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.enabled == True
    assert formatter.formatter is not None
    assert formatter.http_lexer is not None
    assert formatter.explicit_json == False
    assert formatter.group_name == 'colors'

# Generated at 2022-06-17 20:33:19.964238
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.enabled == True

    env = Environment(colors=True)
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.formatter.__class__.__name__ == 'TerminalFormatter'

# Generated at 2022-06-17 20:33:23.580108
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter is not None
    assert color_formatter.http_lexer is not None

# Generated at 2022-06-17 20:33:30.746855
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    cf = ColorFormatter(env)
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Connection: Closed

'''

# Generated at 2022-06-17 20:33:32.870463
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:33:42.066731
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_

# Generated at 2022-06-17 20:33:43.699146
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-17 20:33:54.462609
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import UnixTimestampsPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import ColorsPlugin
    from httpie.plugins.builtin import ImplicitContentTypePlugin
    from httpie.plugins.builtin import ImplicitHTTPMethodPlugin
