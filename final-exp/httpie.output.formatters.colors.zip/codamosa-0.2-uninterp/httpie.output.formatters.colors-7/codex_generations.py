

# Generated at 2022-06-17 20:25:11.722705
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import os
    import sys
    from httpie.context import Environment

# Generated at 2022-06-17 20:25:17.206953
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('auto') == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-17 20:25:24.296678
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solar

# Generated at 2022-06-17 20:25:35.233979
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.colors import ColorFormatter
    import pygments.lexers.text
    import pygments.lexers.data
    import pygments.lexers.html
    import pygments.lexers.javascript
    import pygments.lexers.python
    import pygments.lexers.ruby
    import pygments.lexers.sql
    import pygments.lexers.xml
    import pygments.lexers.yaml
    import pygments.lexers.json
    import pygments.lexers.css
    import pygments.lexers.diff
    import pygments.lexers.http
   

# Generated at 2022-06-17 20:25:46.720751
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body

# Generated at 2022-06-17 20:25:55.753750
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer

# Generated at 2022-06-17 20:26:02.187146
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import DigestAuth
    from httpie.plugins.builtin import WSAuthPlugin
    from httpie.plugins.builtin import WSAuth
    from httpie.plugins.builtin import HTTPGzipProcessor
    from httpie.plugins.builtin import HTTPPrettyPrintProcessor

# Generated at 2022-06-17 20:26:11.974302
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:13.540583
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:15.454677
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:39.885842
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_test

# Generated at 2022-06-17 20:26:41.284472
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:51.063968
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme='solarized')
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer

    formatter = ColorFormatter(env, color_scheme='auto')
    assert formatter.formatter.style == pygments.styles.get_style_by_name('monokai')
    assert formatter.http_lexer == PygmentsHttpLexer

    formatter = ColorFormatter(env, color_scheme='fruity')
    assert formatter.formatter.style == pygments.styles.get_style_by_name('fruity')
    assert formatter.http_lexer == PygmentsHttpLexer

# Generated at 2022-06-17 20:27:02.408549
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.stdout_isatty = True
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.get_lexer_for_body('application/json', '{"a": 1}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body('application/json', '{"a": 1}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body('application/json', '{"a": 1}') == pygments.lexers

# Generated at 2022-06-17 20:27:15.039565
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:23.250564
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.plugins
    import httpie.context
    import httpie.compat
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.formatters.colors
    import httpie.output.formatters.colors.Solarized256Style
    import httpie.output.formatters.colors.ColorFormatter
    import httpie.output.formatters.colors.SimplifiedHTTPLexer
    import httpie.output.formatters.colors.get_lexer
    import httpie.output.formatters.colors.get_lexer_for_body
    import httpie.output.formatters.colors.get_style_class
    import httpie.output.formatters.colors.test_ColorFormatter_format_body

# Generated at 2022-06-17 20:27:34.788648
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Setup
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    headers = '''GET / HTTP/1.1
Host: www.google.com
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Upgrade-Insecure-Requests: 1
Cache-Control: max-age=0'''

    # Exercise
    result = color_formatter.format_headers(headers)



# Generated at 2022-06-17 20:27:45.584090
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:52.569936
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:54.934697
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.formatter.__class__ == Terminal256Formatter
    assert formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert formatter.explicit_json == False

# Generated at 2022-06-17 20:28:19.453905
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:28:27.262482
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_SimplifiedHTTPLexer

# Generated at 2022-06-17 20:28:38.409982
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream

# Generated at 2022-06-17 20:28:47.081567
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_

# Generated at 2022-06-17 20:28:57.853062
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import get_preferred_output_options
    from httpie.plugins.builtin import get_preferred_output_stream
    from httpie.plugins.builtin import get_response_stream
    from httpie.plugins.builtin import get_response_stream_for_redirects
    from httpie.plugins.builtin import get_response_stream_for_request
    from httpie.plugins.builtin import get_response_stream_for_stream

# Generated at 2022-06-17 20:29:00.005673
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:29:06.029734
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_SimplifiedHTTPLexer

# Generated at 2022-06-17 20:29:12.962712
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    env.style = 'solarized'
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:29:15.987046
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:20.479058
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:29:49.086443
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:57.123348
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.format import JSONFormatter
    from httpie.plugins.format import RawJSONFormatter
    from httpie.plugins.format import PrettyJSONFormatter
    from httpie.plugins.format import StreamFormatter
    from httpie.plugins.format import StreamJSONFormatter
    from httpie.plugins.format import StreamPrettyJSONFormatter
    from httpie.plugins.format import StreamRawJSONFormatter
    from httpie.plugins.format import StreamUnicodeFormatter
    from httpie.plugins.format import UnicodeFormatter
    from httpie.plugins.format import URLEncodedFormatter

# Generated at 2022-06-17 20:30:03.779092
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 12
Connection: keep-alive
Date: Mon, 11 Nov 2019 18:55:50 GMT
Server: nginx/1.14.0 (Ubuntu)

'''

# Generated at 2022-06-17 20:30:12.399801
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import ColorizedStdoutStream
    from httpie.output.streams import ColorizedStderrStream
    from httpie.output.streams import StdoutStream
    from httpie.output.streams import StderrStream
    from httpie.output.streams import RawStdoutStream
    from httpie.output.streams import RawStderrStream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_HINT
    from httpie.output.streams import isatty
    from httpie.compat import is_windows
    from httpie.context import Environment

# Generated at 2022-06-17 20:30:22.644167
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:30:25.858969
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.get_style_class(DEFAULT_STYLE).__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:30:32.996257
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment

    env = Environment(colors=256)
    fpm = FormatterPluginManager(env=env)
    fpm.load_builtin_plugins()
    fpm.load_plugin_classes()
    fpm.load_plugin_instances()
    fpm.enable_plugin_instances()

    cf = ColorFormatter(env=env)
    body = '{"a": 1}'
    mime = 'application/json'
    assert cf.format_body(body, mime) == body

# Generated at 2022-06-17 20:30:41.628429
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import os
    env = Environment(
        colors=256,
        stdin=open(os.devnull),
        stdout=open(os.devnull),
        stderr=open(os.devnull),
    )
    manager = FormatterPluginManager(env=env)
    formatter = manager.instantiate(
        name='colors',
        color_scheme='solarized',
    )
    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

"""

# Generated at 2022-06-17 20:30:47.005028
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    import pygments.lexers
    import pygments.lexers.text
    import pygments.lexers.special
    import pygments.lexers.data
    import pygments.lexers.web
    import pygments.lexers.templates
    import pygments.lexers.python
    import pygments.lexers.dotnet
    import pygments.lexers.java
    import pygments.lexers.c_cpp
    import pygments.lexers.haskell
    import pygments.lexers.go
    import pygments.lexers.bash
    import pygments.lexers.ruby
    import pygments.lexers.perl
    import pygments.lexers.php
    import pygments.lexers.javascript
    import pygments.lexers.json
    import pygments

# Generated at 2022-06-17 20:30:52.973621
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_get_lexer_for_body

# Generated at 2022-06-17 20:32:01.292293
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:12.564985
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:23.194977
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import SimplifiedHTT

# Generated at 2022-06-17 20:32:24.017731
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:32:28.206586
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer

# Generated at 2022-06-17 20:32:38.339866
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    class ColorFormatter(FormatterPlugin):
        """
        Colorize using Pygments

        This processor that applies syntax highlighting to the headers,
        and also to the body if its content type is recognized.

        """
        group_name = 'colors'

        def __init__(
            self,
            env: Environment,
            explicit_json=False,
            color_scheme=DEFAULT_STYLE,
            **kwargs
        ):
            super().__init__(**kwargs)

            if not env.colors:
                self.enabled = False
                return

            use_auto_style = color

# Generated at 2022-06-17 20:32:48.931910
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.explicit_json == False
    assert color_formatter.formatter.style == Solarized256Style
    assert color_formatter.http_lexer.name == 'HTTP'
    assert color_formatter.http_lexer.aliases == ['http']
    assert color_formatter.http_lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:57.065541
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:58.185664
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:33:08.016107
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(Environment())
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{') is None
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{') is None
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{') is None
    assert color_formatter.get_lexer_for_body('application/json', '{}')