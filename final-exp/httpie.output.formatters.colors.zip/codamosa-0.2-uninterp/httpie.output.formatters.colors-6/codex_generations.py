

# Generated at 2022-06-17 20:25:19.240589
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{') is None
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{') is None
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None

# Generated at 2022-06-17 20:25:26.949983
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:25:31.822356
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager

    manager = FormatterPluginManager()
    manager.load_installed_plugins()
    formatter = manager.get('colors')
    assert formatter.format_body('{"a": "b"}', 'application/json') == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:25:39.139623
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPGzip
    from httpie.plugins.builtin import HTTPJson
    from httpie.plugins.builtin import HTTPPrettyPrint
    from httpie.plugins.builtin import HTTPTrace
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieSession
    from httpie.plugins.builtin import HTTPieSession
    from httpie.plugins.builtin import HTTPieSession
    from httpie.plugins.builtin import HTTPieSession
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 20:25:48.078022
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.enabled == True
    assert color_formatter.explicit_json == False
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.group_name == 'colors'
    assert color_formatter.get_style_class(color_scheme=DEFAULT_STYLE).__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:26:00.673913
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:07.758871
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:26:09.060113
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:20.709602
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_

# Generated at 2022-06-17 20:26:32.190386
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}')
    assert color_formatter.get_lexer_

# Generated at 2022-06-17 20:26:40.133002
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-17 20:26:47.716351
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:53.090979
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.enabled == True
    assert formatter.group_name == 'colors'
    assert formatter.name == 'colors'
    assert formatter.kwargs == {}
    assert formatter.get_style_class('solarized').__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:26:58.406593
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class

# Generated at 2022-06-17 20:27:05.334039
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_lexer_for_body_with_explicit_json
    from httpie.plugins.colors import test_get_lexer_for_body_with_explicit_json_and_body

# Generated at 2022-06-17 20:27:17.849838
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream_no_colors
    from httpie.output.streams import write_to_error_stream_no_colors
    from httpie.output.streams import write_to_output_stream_no_colors
    from httpie.output.streams import write_to_error_stream_no_colors
    from httpie.output.streams import write_to_output_stream_no_col

# Generated at 2022-06-17 20:27:30.587805
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_test_

# Generated at 2022-06-17 20:27:39.633018
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.colors import ColorFormatter

    env = Environment(colors=256)
    formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    body = '{"key": "value"}'
    mime = 'application/json'

# Generated at 2022-06-17 20:27:43.899793
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:51.666317
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:28:15.216653
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Arrange
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''

    # Act
    formatter = ColorFormatter(env, explicit_json, color_scheme)
    result = formatter.format_headers(headers)

    # Assert

# Generated at 2022-06-17 20:28:27.598506
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') is not None
    assert get_lexer('application/json', explicit_json=True) is not None
    assert get_lexer('application/json', explicit_json=True, body='{}') is not None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='{') is None
    assert get_lexer('application/json', explicit_json=True, body='[') is None
    assert get_lexer('application/json', explicit_json=True, body='[]') is not None
    assert get_lexer('application/json', explicit_json=True, body='[1]') is not None

# Generated at 2022-06-17 20:28:38.821577
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    explicit_json = False
    color_scheme = 'solarized'
    formatter = ColorFormatter(env, explicit_json, color_scheme)
    assert formatter.enabled == True
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.get_style_class('solarized').__name__ == 'Solarized256Style'
    assert formatter.get_lexer_for_body('application/json', '{}').__name__ == 'JsonLexer'

# Generated at 2022-06-17 20:28:47.355552
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 2
Connection: keep-alive
Date: Mon, 16 Jul 2018 16:07:21 GMT
Server: gunicorn/19.9.0
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:28:52.006351
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__ == Terminal256Formatter
    assert formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert formatter.formatter.style.__class__ == Solarized256Style

# Generated at 2022-06-17 20:29:01.526694
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_Solarized256Style_

# Generated at 2022-06-17 20:29:08.225702
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.enabled == True
    assert formatter.explicit_json == False
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer


# Generated at 2022-06-17 20:29:15.996233
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body

# Generated at 2022-06-17 20:29:25.896469
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:29:36.766283
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import SyntaxHighlight

    class MockEnvironment:
        colors = 256

    class MockJSONFormatter(JSONFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = True

    class MockStreamFormatter(StreamFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.enabled = True

    class MockSyntaxHighlight(SyntaxHighlight):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

# Generated at 2022-06-17 20:29:55.656778
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('auto') == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-17 20:29:56.623119
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:08.042508
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.output.streams import get_output_stream

    args = parser.parse_args([])
    env = Environment(args, stdout=get_output_stream('stdout'),
                      stderr=get_output_stream('stderr'))
    plugin_manager.load_installed_plugins()
    formatter = ColorFormatter(env)

    # Test for JSON
    assert formatter.get_lexer_for_body('application/json', '{"key": "value"}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{"key": "value"}') == pygments.lexers

# Generated at 2022-06-17 20:30:20.663499
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_get_style_class_exception
    from httpie.plugins.colors import test_get_style_class_exception_2


# Generated at 2022-06-17 20:30:31.343080
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.pretty import PrettyFormatter
    from httpie.plugins.syntax import SyntaxFormatter

    env = Environment()
    env.stdout_isatty = True
    env.colors = 256
    env.color_scheme = 'solarized'
    env.prettify = True
    env.syntax = True
    env.explicit_json = True
    env.stream = False
    env.headers = True
    env.style = 'solarized'
    env.style_error = 'solarized'
    env.style_info = 'solarized'
    env.style_

# Generated at 2022-06-17 20:30:41.005898
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_SimplifiedHTTPLexer
    from httpie.plugins.colors import test_Solarized256Style

# Generated at 2022-06-17 20:30:50.549512
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONStreams
    from httpie.plugins.builtin import JSONPointer
    from httpie.plugins.builtin import JSONQuerystringAuth
    from httpie.plugins.builtin import JSONQuerystringArray
    from httpie.plugins.builtin import JSONQuerystring
    from httpie.plugins.builtin import JSONItems
    from httpie.plugins.builtin import JSONLines
    from httpie.plugins.builtin import JSONPretty
    from httpie.plugins.builtin import JSONStream
    from httpie.plugins.builtin import JSON
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials

# Generated at 2022-06-17 20:31:00.349378
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled == True
    assert color_formatter.explicit_json == False
    assert color_formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.group_name == 'colors'
    assert color_formatter.get_style_class('solarized').__name__ == 'Solarized256Style'
    assert color_formatter.get_style_class('auto').__name__ == 'TerminalFormatter'

# Generated at 2022-06-17 20:31:11.416490
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{') is None
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{') is None
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None

# Generated at 2022-06-17 20:31:15.373006
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:31:44.053953
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json', explicit_json=True, body='{') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='[]')
    assert get_lexer('application/json', explicit_json=True, body='[') is None
    assert get_lexer('application/json', explicit_json=True, body='null')
    assert get_lexer('application/json', explicit_json=True, body='nul') is None
    assert get_lex

# Generated at 2022-06-17 20:31:51.943230
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body

# Generated at 2022-06-17 20:31:57.784866
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:10.678244
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:22.615748
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:27.230222
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import UnixTimestampsPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import BrowserPlugin
    from httpie.plugins.builtin import DownloadPlugin

# Generated at 2022-06-17 20:32:38.125515
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:42.491864
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:32:53.563203
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{') is None
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{') is None
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None

# Generated at 2022-06-17 20:33:02.225027
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    env = Environment(colors=256)
    formatter = ColorFormatter(env=env)
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Mon, 01 Oct 2018 16:16:41 GMT

'''

# Generated at 2022-06-17 20:34:00.950431
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_

# Generated at 2022-06-17 20:34:11.933113
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:34:21.609749
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:34:31.480204
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_streams
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream_with_colors
    from httpie.output.streams import write_to_output_stream_without_colors
    from httpie.output.streams import write_to_output_stream_with_colors_256
    from httpie.output.streams import write_to_output_stream_without_colors_256
    from httpie.output.streams import write

# Generated at 2022-06-17 20:34:41.987261
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:34:49.387120
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']