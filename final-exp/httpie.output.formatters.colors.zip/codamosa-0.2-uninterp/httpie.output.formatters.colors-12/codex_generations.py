

# Generated at 2022-06-17 20:25:04.484777
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    body = '{"key": "value"}'
    mime = 'application/json'

# Generated at 2022-06-17 20:25:17.050716
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_Solarized256Style_background_color
    from httpie.plugins.colors import test_Solarized256Style_styles

# Generated at 2022-06-17 20:25:24.234376
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_pygments_highlight

# Generated at 2022-06-17 20:25:35.244060
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:25:46.720932
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:25:55.753339
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_

# Generated at 2022-06-17 20:25:57.823706
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:03.047226
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.enabled == True
    assert formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.group_name == 'colors'
    assert formatter.kwargs == {}
    assert formatter.name == 'colors'
    assert formatter.priority == 0
    assert formatter.version == '0.1'


# Generated at 2022-06-17 20:26:12.559914
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.compat import is_windows
    from httpie.plugins.colors import ColorFormatter
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    Date: Sun, 07 Jul 2019 12:43:12 GMT
    Server: Apache/2.4.18 (Ubuntu)
    Transfer-Encoding: chunked
    '''
    result = formatter.format_headers(headers)

# Generated at 2022-06-17 20:26:22.636728
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json', body='{') is None
    assert get_lexer('application/json', explicit_json=True, body='{')
    assert get_lexer('application/json', body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo')
    assert get_lexer('application/json', body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo')

# Generated at 2022-06-17 20:26:37.695339
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True)
    formatter = ColorFormatter(env)
    assert formatter.enabled
    assert formatter.formatter
    assert formatter.http_lexer
    assert formatter.explicit_json == False
    assert formatter.group_name == 'colors'

# Generated at 2022-06-17 20:26:46.420453
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_

# Generated at 2022-06-17 20:26:48.770889
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:01.586401
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class

# Generated at 2022-06-17 20:27:13.747123
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import str
    from httpie.output.streams import get_default_streams
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment

    env = Environment(
        stdin=None,
        stdout=get_default_streams().stdout,
        stderr=get_default_streams().stderr,
        colors=256,
    )
    formatter = FormatterPluginManager(env=env).instantiate(
        name='colors',
        kwargs={'color_scheme': 'solarized'},
    )
    headers = str('Content-Type: application/json\n')
    headers += str('Content-Length: 42\n')
    headers += str('Connection: keep-alive\n')

# Generated at 2022-06-17 20:27:22.407220
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main
    from httpie.plugins import FormatterPlugin
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import SimplifiedHTTPLexer

# Generated at 2022-06-17 20:27:34.333043
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:45.072735
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import JSONStreams
    from httpie.plugins.builtin import JSONPointers
    from httpie.plugins.builtin import JSONQuerystringArgs
    from httpie.plugins.builtin import JSONQuerystringAuth
    from httpie.plugins.builtin import JSONQuerystringAuth
    from httpie.plugins.builtin import JSONQuerystringItems
    from httpie.plugins.builtin import JSONQuerystringKeys
    from httpie.plugins.builtin import JSONQuerystringValues
    from httpie.plugins.builtin import JSONQuerystring
    from httpie.plugins.builtin import JSONItems

# Generated at 2022-06-17 20:27:48.591579
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-17 20:27:52.755111
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme='solarized')
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:28:15.173454
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    body = '{"name":"httpie","version":"0.9.9"}'
    mime = 'application/json'

# Generated at 2022-06-17 20:28:27.554993
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_lexer

# Generated at 2022-06-17 20:28:28.848314
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:33.988820
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import get_default_stream
    from httpie.output.streams import get_default_stream_for_stdout
    from httpie.output.streams import get_default_stream_for_stderr
    from httpie.output.streams import get_default_stream_for_stdin
    from httpie.output.streams import get_default_stream_for_stdin_binary
    from httpie.output.streams import get_default_stream_for_stdin_json
    from httpie.output.streams import get_default_stream_for_stdin_form
    from httpie.output.streams import get_default_stream_for_stdin_files
    from httpie.output.streams import get_default_stream_for_stdin_args

# Generated at 2022-06-17 20:28:44.117025
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_SimplifiedHTTPLexer

# Generated at 2022-06-17 20:28:47.714316
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Test case 1:
    #   mime = 'application/json'
    #   body = '{"key": "value"}'
    #   expected = pygments.lexers.get_lexer_by_name('json')
    #   result = ColorFormatter.get_lexer_for_body(mime, body)
    #   assert result == expected
    pass

# Generated at 2022-06-17 20:28:58.188980
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.context import Environment
    from httpie.compat import is_windows
    env = Environment(colors=256)
    formatter = JSONFormatter(env)
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}', explicit_json=True)
    assert not color_formatter.get_lexer_for_body('application/json', '{"a":1}', explicit_json=False)

# Generated at 2022-06-17 20:29:10.158121
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:29:22.928905
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_output_stream
    from httpie.output.streams import get_response_stream
    from httpie.output.streams import get_error_stream
    from httpie.output.streams import get_request_stream
    from httpie.output.streams import get_debug_stream
    from httpie.output.streams import get_info_stream
    from httpie.output.streams import get_warning_stream
    from httpie.output.streams import get_traceback_stream
    from httpie.output.streams import get_verbose_stream
    from httpie.output.streams import get_progress_stream
    from httpie.output.streams import get_color_stream
   

# Generated at 2022-06-17 20:29:34.382739
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:30:02.694878
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import SOLARIZED_ST

# Generated at 2022-06-17 20:30:04.299064
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:05.817140
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:07.253878
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:18.358658
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    color_formatter = ColorFormatter(env)
    assert color_formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n') == '\x1b[38;5;10mHTTP/1.1 200 OK\x1b[39m\n\x1b[38;5;10mContent-Type: text/html\x1b[39m\n'

# Generated at 2022-06-17 20:30:26.107361
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light256') == Solarized256Style

# Generated at 2022-06-17 20:30:31.017713
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_lexer_for_body_explicit_json
    from httpie.plugins.colors import test_get_lexer_for_body_json

# Generated at 2022-06-17 20:30:33.386783
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:39.755670
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == Solarized256Style
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-17 20:30:49.765896
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:31:38.836664
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor

    env = Environment(colors=256)
    fpm = FormatterPluginManager(env)
    fpm.add_plugin(ColorFormatter)
    fpm.add_plugin(HTTPHeadersProcessor)
    fpm.enable_plugin_by_name('colors')
    fpm.enable_plugin_by_name('HTTPHeadersProcessor')
    fpm.set_enabled(True)

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Server: gunicorn/19.9.0
Date: Tue, 28 May 2019 14:48:52 GMT

'''
    expected

# Generated at 2022-06-17 20:31:48.901853
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    formatter = ColorFormatter(env)
    assert formatter.formatter.style == Solarized256Style
    env.color_scheme = 'auto'
    formatter = ColorFormatter(env)
    assert formatter.formatter.style == Solarized256Style
    env.color_scheme = 'fruity'
    formatter = ColorFormatter(env)
    assert formatter.formatter.style == pygments.styles.get_style_by_name('fruity')
    env.colors = 256
    env.color_scheme = 'solarized'
    formatter = ColorFormatter(env)
    assert formatter.formatter.style == Solarized256Style
    env.color_sche

# Generated at 2022-06-17 20:32:00.937227
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import SyntaxHighlightPlugin

    class TestColorFormatter(ColorFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    class TestJSONFormatterPlugin(JSONFormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    class TestPrettyOptionsPlugin(PrettyOptionsPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)


# Generated at 2022-06-17 20:32:12.325054
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:23.160776
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256-light') == Solarized256Style

# Generated at 2022-06-17 20:32:23.990021
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:32:29.940173
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'
    assert color_formatter.explicit_json == False

# Generated at 2022-06-17 20:32:39.209453
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import ImplicitContentTypePlugin
    from httpie.plugins.builtin import ImplicitHTTPMethodPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerAuth

# Generated at 2022-06-17 20:32:42.967087
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer

# Generated at 2022-06-17 20:32:53.937868
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    env = Environment(colors=256)
    formatter = ColorFormatter(env)

# Generated at 2022-06-17 20:34:32.987158
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPError
    from httpie.plugins.builtin import HTTPWarningProcessor
    from httpie.plugins.builtin import HTTPWarning
    from httpie.plugins.builtin import HTTPInfoProcessor
    from httpie.plugins.builtin import HTTPInfo


# Generated at 2022-06-17 20:34:36.770012
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:34:44.267597
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class