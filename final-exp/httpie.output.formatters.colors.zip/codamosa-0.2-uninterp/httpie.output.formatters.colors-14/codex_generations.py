

# Generated at 2022-06-17 20:25:08.332625
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:25:17.955555
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Server: gunicorn/19.9.0
Date: Sun, 10 Feb 2019 10:35:37 GMT

'''
    headers = color_formatter.format_headers(headers)

# Generated at 2022-06-17 20:25:24.910867
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') == TextLexer
    assert get_lexer('text/plain', body='{"a": 1}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('text/plain', explicit_json=True, body='{"a": 1}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('text/plain', explicit_json=True, body='{"a": 1}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', body='{"a": 1}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', body='{"a": 1}')

# Generated at 2022-06-17 20:25:35.800540
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive

'''
    headers = color_formatter.format_headers(headers)

# Generated at 2022-06-17 20:25:46.945141
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.output.streams import get_default_streams


# Generated at 2022-06-17 20:26:00.357606
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:06.364570
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import ArgumentsProcessor
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import AuthPlugin

# Generated at 2022-06-17 20:26:14.049907
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexers import get_lexer_by_name
    from pygments.lexers.special import TextLexer
    from pygments.lexers.text import HttpLexer
    from pygments.lexers.web import PhpLexer
    from pygments.lexers.data import JsonLexer

    # Request-Line
    assert SimplifiedHTTPLexer().get_tokens('GET / HTTP/1.1') == \
        [(Token.Name.Function, 'GET'),
         (Token.Text, ' '),
         (Token.Name.Namespace, '/'),
         (Token.Text, ' '),
         (Token.Keyword.Reserved, 'HTTP'),
         (Token.Operator, '/'),
         (Token.Number, '1.1')]



# Generated at 2022-06-17 20:26:23.691500
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONStreams
    from httpie.plugins.builtin import JSONPointer
    from httpie.plugins.builtin import JSONPath
    from httpie.plugins.builtin import Form
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import MultipartFormData
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import AutoJSON
    from httpie.plugins.builtin import AutoHeaders
    from httpie.plugins.builtin import AutoReferer
    from httpie.plugins.builtin import HttpiePlugin

# Generated at 2022-06-17 20:26:26.984275
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import DEFAULT_STYLE

    color_formatter = ColorFormatter(FormatterPlugin.Environment())
    assert color_formatter.get_style_class(DEFAULT_STYLE) == Solarized256Style

# Generated at 2022-06-17 20:26:44.709097
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style

# Generated at 2022-06-17 20:26:52.985547
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_lexer_for_body_explicit_json
    from httpie.plugins.colors import test_get_lexer_for_body_json
    from httpie.plugins.colors import test_

# Generated at 2022-06-17 20:27:03.004936
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:15.644205
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPMethodOverridePlugin
    from httpie.plugins.builtin import HTTPPassAuthPlugin
    from httpie.plugins.builtin import HTTPRedirectPlugin
    from httpie.plugins.builtin import HTTPBasicAuthPlugin
   

# Generated at 2022-06-17 20:27:23.636003
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

'''

# Generated at 2022-06-17 20:27:34.909578
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_

# Generated at 2022-06-17 20:27:40.444427
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert color_formatter.formatter.style.__class__ == Solarized256Style

# Generated at 2022-06-17 20:27:50.182223
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:28:02.088282
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import ColorizedStdoutStream
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import ColorizedStdoutStream
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import ColorizedStdoutStream
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import ColorizedStdoutStream
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows

# Generated at 2022-06-17 20:28:13.548075
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    env.style = 'solarized'
    formatter = FormatterPlugin(env)
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}') != pygments.lexers.get_lexer_by_name('text')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}') != pygments.lexers.get_lexer

# Generated at 2022-06-17 20:28:42.738682
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment

    env = Environment(colors=256)
    fpm = FormatterPluginManager(env=env)
    color_formatter = fpm.instantiate(
        name='colors',
        kwargs={'color_scheme': 'solarized'}
    )

    # Test for JSON
    assert color_formatter.get_lexer_for_body(
        mime='application/json',
        body='{"key": "value"}'
    ) == pygments.lexers.get_lexer_by_name('json')

    # Test for JSON with incorrect Content-Type

# Generated at 2022-06-17 20:28:45.900124
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:55.642418
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True


# Generated at 2022-06-17 20:29:03.214878
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:29:05.379435
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:14.750977
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPWarningProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import DownloadPlugin


# Generated at 2022-06-17 20:29:23.061574
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = '''GET / HTTP/1.1
Host: www.google.com
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate, compress
Accept: */*
Connection: keep-alive'''

# Generated at 2022-06-17 20:29:25.565183
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-17 20:29:36.388566
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexers import get_lexer_by_name
    from pygments.lexers.special import TextLexer
    from pygments.lexers.text import HttpLexer as PygmentsHttpLexer

    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:29:47.969204
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPHeadersPlugin
    from httpie.plugins.builtin import HTTPBodyPlugin
    from httpie.plugins.builtin import HTTPTracebackPlugin
    from httpie.plugins.builtin import HTTPError
    from httpie.plugins.builtin import HTTPWarning
    from httpie.plugins.builtin import HTTPInfo
    from httpie.plugins.builtin import HTTPCookiesPlugin
    from httpie.plugins.builtin import HTTPOptionsPlugin
    from httpie.plugins.builtin import HTTPBasicAuthPlugin
    from httpie.plugins.builtin import HTTPDigestAuthPlugin
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 20:30:20.249913
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') != Terminal256Formatter
    assert ColorFormatter.get_style_class('solarized') != Terminal256Formatter
    assert ColorFormatter.get_style_class('solarized') != TerminalFormatter
    assert ColorFormatter.get_style_class('solarized256') != TerminalFormatter
    assert ColorFormatter.get_style_class('solarized256') != Solarized256Style
    assert ColorFormatter.get_style_class('solarized') != Solarized256Style

# Generated at 2022-06-17 20:30:26.862451
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.explicit_json == False
    assert formatter.formatter.__class__.__name__ == "TerminalFormatter"
    assert formatter.http_lexer.__class__.__name__ == "SimplifiedHTTPLexer"


# Generated at 2022-06-17 20:30:29.440333
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') != Terminal256Formatter

# Generated at 2022-06-17 20:30:40.017482
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPError
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin

# Generated at 2022-06-17 20:30:49.886118
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_streams


# Generated at 2022-06-17 20:30:59.679806
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import AVAILABLE_STYLES
   

# Generated at 2022-06-17 20:31:06.824857
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:31:16.761268
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import get_default_stream
    from httpie.context import Environment
    env = Environment(colors=256, stdout=get_default_stream('stdout'),
                      stderr=get_default_stream('stderr'))
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Server: gunicorn/19.9.0
Date: Wed, 25 Sep 2019 11:43:47 GMT

'''
    formatter = ColorFormatter(env, color_scheme='solarized')

# Generated at 2022-06-17 20:31:22.030513
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Test with default color scheme
    color_formatter = ColorFormatter(Environment(colors=256))
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.formatter.style.__class__ == Solarized256Style

    # Test with auto color scheme
    color_formatter = ColorFormatter(Environment(colors=256), color_scheme=AUTO_STYLE)
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.formatter.style.__class__ == Solarized256Style

    # Test with non-auto color scheme
    color_formatter = ColorFormatter(Environment(colors=256), color_scheme='monokai')
    assert color_formatter.formatter.__class__ == Terminal256Formatter

# Generated at 2022-06-17 20:31:33.965957
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:23.011595
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.style == Solarized256Style
    assert color_formatter.http_lexer == SimplifiedHTTPLexer
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True


# Generated at 2022-06-17 20:32:25.433694
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('auto') == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-17 20:32:33.854062
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import test_ColorFormatter_format

# Generated at 2022-06-17 20:32:42.901086
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONStreams
    from httpie.plugins.builtin import JSONData
    from httpie.plugins.builtin import FormData
    from httpie.plugins.builtin import Arguments
    from httpie.plugins.builtin import Files
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import Session
    from httpie.plugins.builtin import Auth
    from httpie.plugins.builtin import Debug
    from httpie.plugins.builtin import Download
    from httpie.plugins.builtin import ImplicitHTTPMethod
    from httpie.plugins.builtin import HTTPie
    from httpie.plugins.builtin import AutoJSON
   

# Generated at 2022-06-17 20:32:53.874151
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:33:04.920550
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:33:17.064390
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:33:20.646304
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:33:26.054437
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=SOLARIZED_STYLE)
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert color_formatter.formatter.style.__class__ == Solarized256Style


# Generated at 2022-06-17 20:33:32.754295
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_stream
    from httpie.output.streams import write_exception
    from httpie.output.streams import write_headers
    from httpie.output.streams import write_response
    from httpie.output.streams import write_request
    from httpie.output.streams import write_error
    from httpie.output.streams import write_debug
    from httpie.output.streams import write_info
    from httpie.output.streams import write_warning
    from httpie.output.streams import write_binary_response
    from httpie.output.streams import write_binary_request
   