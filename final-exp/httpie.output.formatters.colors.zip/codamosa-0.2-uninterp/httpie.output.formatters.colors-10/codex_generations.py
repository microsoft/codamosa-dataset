

# Generated at 2022-06-17 20:25:04.431368
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_output_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin

# Generated at 2022-06-17 20:25:05.423313
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:25:14.394453
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE


# Generated at 2022-06-17 20:25:23.090634
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') == TextLexer
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='{"foo": "bar"}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='foo') == TextLexer
    assert get_lexer('application/json', explicit_json=False, body='{"foo": "bar"}') == TextLexer

# Generated at 2022-06-17 20:25:34.763987
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_Solarized256Style_background_color
   

# Generated at 2022-06-17 20:25:38.166203
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:25:48.018145
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:25:58.156147
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.enabled == True

    env.colors = 0
    formatter = ColorFormatter(env)
    assert formatter.enabled == False

# Generated at 2022-06-17 20:26:10.464760
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPError
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import ImplicitContentTypePlugin

# Generated at 2022-06-17 20:26:12.694418
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-17 20:26:36.137099
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:45.375702
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:54.207617
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-17 20:26:58.384182
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    env.style = 'solarized'
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{"key":"value"}')
    assert formatter.get_lexer_for_body('application/json', '{"key":"value"}')
    assert formatter.get_lexer_for_body('application/json', '{"key":"value"}')
    assert formatter.get_lexer_for_body('application/json', '{"key":"value"}')
    assert formatter.get_lexer_for_body('application/json', '{"key":"value"}')
    assert formatter.get_lexer_for_body

# Generated at 2022-06-17 20:27:05.292580
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:17.806427
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor

# Generated at 2022-06-17 20:27:30.491753
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:31.886489
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:33.120796
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:34.375926
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:48.225261
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:01.109997
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_output_stream

    env = Environment(
        colors=True,
        stdin=None,
        stdout=get_output_stream('stdout'),
        stderr=get_output_stream('stderr'),
        stdout_isatty=True,
        stderr_isatty=True,
        format='colors',
        output_options={},
        config=None,
    )

    formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')

    body = '{"foo": "bar"}'
    mime = 'application/json'

# Generated at 2022-06-17 20:28:12.340510
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{}') == pygments.lexers.get_

# Generated at 2022-06-17 20:28:19.336232
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams

# Generated at 2022-06-17 20:28:24.844179
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled == True
    assert color_formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.group_name == 'colors'


# Generated at 2022-06-17 20:28:31.219733
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-17 20:28:32.802799
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:43.259777
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:28:55.902273
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''

# Generated at 2022-06-17 20:29:03.368683
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''

# Generated at 2022-06-17 20:29:34.017307
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_streams
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_streams
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_streams
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_

# Generated at 2022-06-17 20:29:40.224860
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPCookie
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import JSONStream
    from httpie.plugins.builtin import HTTPFollowRedirects
    from httpie.plugins.builtin import HTTPIgnoreStdin
    from httpie.plugins.builtin import HTTPVerbose
    from httpie.plugins.builtin import HTTPTraceback
    from httpie.plugins.builtin import HTTPWarnings

# Generated at 2022-06-17 20:29:51.721348
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled == True
    assert color_formatter.formatter.style == Solarized256Style
    assert color_formatter.http_lexer == SimplifiedHTTPLexer
    assert color_formatter.explicit_json == False
    assert color_formatter.group_name == 'colors'
    assert color_formatter.name == 'colors'
    assert color_formatter.description == 'Colorize using Pygments'
    assert color_formatter.help == 'Colorize using Pygments'
    assert color_formatter.version == '1.0.0'

# Generated at 2022-06-17 20:30:00.149959
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:30:10.714083
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPMethodOverridePlugin
    from httpie.plugins.builtin import HTTPieArgumentParser
    from httpie.plugins.builtin import OptionsPlugin
    from httpie.plugins.builtin import EnvironmentDefaultsPlugin

# Generated at 2022-06-17 20:30:21.963283
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:30:23.450372
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:33.417131
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env=env)
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is not None
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is not None
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is not None

# Generated at 2022-06-17 20:30:41.952818
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_stdout
    from httpie.output.streams import write_to_stderr
    from httpie.output.streams import write_to_stdout_and_stderr
    from httpie.output.streams import write_to_file
    from httpie.output.streams import write_to_path
    from httpie.output.streams import write_to_path_and_stdout
    from httpie.output.streams import write_to_path_and_stderr
    from httpie.output.streams import write_to_path_and

# Generated at 2022-06-17 20:30:42.781006
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style

# Generated at 2022-06-17 20:31:34.012711
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import UnixSocketPlugin
    from httpie.plugins.builtin import WindowsPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieColors
    from httpie.plugins.builtin import HTTPieColors256
    from httpie.plugins.builtin import HTTPieColorsSolarized

# Generated at 2022-06-17 20:31:45.342219
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_output_stream
    from httpie.output.streams import get_output_stream_encoder
    from httpie.output.streams import get_output_stream_encoding
    from httpie.output.streams import get_output_stream_errors
    from httpie.output.streams import get_output_stream_isatty
    from httpie.output.streams import get_output_stream_line_buffered
    from httpie.output.streams import get_output_stream_raw
    from httpie.output.streams import get_output_stream_writable
    from httpie.output.streams import is_output_stream_encoding_utf8

# Generated at 2022-06-17 20:31:58.686598
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeaders

    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = HTTPHeaders(env, formatter)
    headers.start_format()
    headers.format_headers({'Content-Type': 'application/json'})
    headers.finish_format()
    assert headers.get_result() == '\x1b[38;5;33mContent-Type\x1b[39m: \x1b[38;5;39mapplication/json\x1b[39m'

# Generated at 2022-06-17 20:32:03.557826
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer

# Generated at 2022-06-17 20:32:13.852525
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.enabled == True
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.get_style_class('solarized').__name__ == 'Solarized256Style'
    assert color_formatter.get_lexer_for_body('application/json', '{"key":"value"}').__name__ == 'JsonLexer'


# Generated at 2022-06-17 20:32:19.937252
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    formatter = ColorFormatter(env)
    assert formatter.enabled
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer
    assert formatter.explicit_json == False

# Generated at 2022-06-17 20:32:25.754586
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:34.107126
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:35.336093
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:32:45.357129
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_stream
    from httpie.context import Environment
    env = Environment(colors=256, stdout=get_default_stream('stdout'))
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None
    assert formatter.get_lexer_for_body('application/json', '') is None
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None

# Generated at 2022-06-17 20:34:30.560968
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:34:41.560053
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import stream
    from httpie.plugins.builtin import JSONStream
    from httpie.plugins.builtin import JSON
    from httpie.plugins.builtin import Pretty
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import JSONStream
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import stream
    from httpie.plugins.builtin import JSON

# Generated at 2022-06-17 20:34:49.185071
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']