

# Generated at 2022-06-17 20:25:03.574672
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:25:11.746496
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.enabled == True
    assert color_formatter.explicit_json == False
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.group_name == 'colors'

# Generated at 2022-06-17 20:25:17.954944
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True

# Generated at 2022-06-17 20:25:19.839696
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:25:22.272101
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:25:34.162164
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPluginManager
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPError
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyJSONProcessor
    from httpie.plugins.builtin import KeyValueProcessor
    from httpie.plugins.builtin import URLE

# Generated at 2022-06-17 20:25:45.812110
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:25:55.433431
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.stdout_isatty = True
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer

# Generated at 2022-06-17 20:26:01.932851
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body

# Generated at 2022-06-17 20:26:11.812658
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:25.101435
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasic

# Generated at 2022-06-17 20:26:27.100424
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:28.515748
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:39.150381
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import FormattedStreamFormatter
    from httpie.plugins.builtin import FormattedFormatter
    from httpie.plugins.builtin import RawStreamFormatter
    from httpie.plugins.builtin import RawFormatter
    from httpie.plugins.builtin import HeadersFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import MultipartFormatter
    from httpie.plugins.builtin import FileMultipartFormatter
    from httpie.plugins.builtin import FileURLEncoded

# Generated at 2022-06-17 20:26:40.786838
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:45.230020
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:27:00.379173
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPFollowRedirectsPlugin
    from httpie.plugins.builtin import HTTPIgnore

# Generated at 2022-06-17 20:27:03.386473
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('auto') == Solarized256Style

# Generated at 2022-06-17 20:27:04.778009
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:17.336138
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style

# Generated at 2022-06-17 20:27:36.779402
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:47.666161
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:53.599603
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import test_ColorFormatter_format

# Generated at 2022-06-17 20:27:54.348919
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:58.896754
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_streams
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream_with_colors
    from httpie.output.streams import write_to_output_stream_without_colors
    from httpie.output.streams import write_to_output_stream_with_colors_256

# Generated at 2022-06-17 20:28:07.635546
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    import os
    import sys
    import tempfile
    import unittest


# Generated at 2022-06-17 20:28:16.823150
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_text_stream
    from httpie.output.streams import write_binary_stream
    from httpie.output.streams import write_text_stream
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import get_formatter
    from httpie.plugins import get_parser
    from httpie.plugins import get_prettifier
    from httpie.plugins import get_style
    from httpie.plugins import get_validator
    from httpie.plugins import Plugin
    from httpie.plugins import PluginManager
    from httpie.plugins import ValidatorPlugin
    from httpie.plugins import ValidatorPluginManager
    from httpie.plugins import ValidatorPluginManager
    from httpie.plugins import ValidatorPluginManager

# Generated at 2022-06-17 20:28:24.981570
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{"foo": "bar"}')
    assert formatter.get_lexer_for_body('application/json', '{"foo": "bar"}')
    assert formatter.get_lexer_for_body('application/json', '{"foo": "bar"}')
    assert formatter.get_lexer_for_body('application/json', '{"foo": "bar"}')
    assert formatter.get_lexer_for_body('application/json', '{"foo": "bar"}')

# Generated at 2022-06-17 20:28:31.317444
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:28:42.087879
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:29:15.986607
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:18.380056
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(colors=256), color_scheme=SOLARIZED_STYLE)

# Generated at 2022-06-17 20:29:26.551511
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.enabled == True
    assert formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.group_name == 'colors'
    assert formatter.name == 'colors'
    assert formatter.description == 'Colorize using Pygments'
    assert formatter.help == 'Colorize using Pygments'
    assert formatter.help_group == 'colors'
    assert formatter.help_group_name == 'colors'
    assert formatter.help_options == []
    assert formatter

# Generated at 2022-06-17 20:29:32.557935
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.enabled == True

# Generated at 2022-06-17 20:29:43.152322
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:29:51.641266
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:30:01.344871
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_SimplifiedHTTPLexer

# Generated at 2022-06-17 20:30:08.217990
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    env.explicit_json = True
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == True
    assert formatter.enabled == True

# Generated at 2022-06-17 20:30:20.769987
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.core import main
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPError
    from httpie.plugins.builtin import HTTPWarningProcessor
    from httpie.plugins.builtin import HTTPWarning
    from httpie.plugins.builtin import HTTPResponseHeadersProcessor

# Generated at 2022-06-17 20:30:31.426847
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPHeadersPlugin
    from httpie.plugins.builtin import HTTPBodyPlugin
    from httpie.plugins.builtin import HTTPTracebackPlugin
    from httpie.plugins.builtin import HTTPError
    from httpie.plugins.builtin import HTTPWarning
    from httpie.plugins.builtin import HTTPResponseHeaders
    from httpie.plugins.builtin import HTTPResponse
    from httpie.plugins.builtin import HTTPRequest
    from httpie.plugins.builtin import HTTPInfo
    from httpie.plugins.builtin import HTTPInfoRequest

# Generated at 2022-06-17 20:31:17.106107
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark-256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light256') == Solarized256Style

# Generated at 2022-06-17 20:31:22.221967
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import UnixTimestampToDatetimeProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPWarningProcessor
    from httpie.plugins.builtin import OptionsPlugin


# Generated at 2022-06-17 20:31:23.576776
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:31:31.822858
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True


# Generated at 2022-06-17 20:31:40.642698
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPluginManager
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import Solarized256Style

    env = Environment(colors=256)
    fpm = FormatterPluginManager(env)
    fpm.register(ColorFormatter)
    fpm.register(HTTPHeadersProcessor)
    fpm.get_first_plugin_of_type(ColorFormatter).formatter.style = Solarized256Style


# Generated at 2022-06-17 20:31:50.026326
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPGSSAPIAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPNtlmAuth
    from httpie.plugins.builtin import HTTPNegotiateAuth
    from httpie.plugins.builtin import HTTPOAuth1
    from httpie.plugins.builtin import HTTPOAuth2
    from httpie.plugins.builtin import HTTPPassDigestAuth
    from httpie.plugins.builtin import HTTPPassBasic

# Generated at 2022-06-17 20:32:01.381328
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:12.633463
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.output.streams import get_default_streams

# Generated at 2022-06-17 20:32:23.193002
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_stdout, write_to_stderr
    from httpie.output.streams import write_to_stdout_and_stderr
    from httpie.output.streams import write_to_file
    from httpie.output.streams import write_to_file_and_stdout
    from httpie.output.streams import write_to_file_and_stderr
    from httpie.output.streams import write_to_file_and_stdout_and_stderr
    from httpie.output.streams import write_to_stdout

# Generated at 2022-06-17 20:32:24.121716
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:34:49.184418
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPrettyPrinter
    from httpie.plugins.builtin import HTTPFormatter
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPWarningProcess