

# Generated at 2022-06-17 20:25:06.896106
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    import pygments.lexers
    import pygments.lexers.special
    import pygments.lexers.text
    import pygments.lexers.data
    import pygments.lexers.markup
    import pygments.lexers.python
    import pygments.lexers.javascript
    import pygments.lexers.html
    import pygments.lexers.xml
    import pygments.lexers.css
    import pygments.lexers.json
    import pygments.lexers.bash
    import pygments.lexers.sql
    import pygments.lexers.perl
    import pygments.lexers.ruby
    import pygments.lexers.php
    import pygments.lexers.java
    import pygments.lexers.c_cpp
    import pygments.lex

# Generated at 2022-06-17 20:25:09.477859
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:25:20.413198
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor

# Generated at 2022-06-17 20:25:33.363995
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_lexer_for_body_explicit_json

# Generated at 2022-06-17 20:25:45.073421
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    import pygments.lexers
    import pygments.lexers.special
    import pygments.lexers.text
    import pygments.lexers.data
    import pygments.lexers.html
    import pygments.lexers.markup
    import pygments.lexers.python
    import pygments.lexers.shell
    import pygments.lexers.sql
    import pygments.lexers.javascript
    import pygments.lexers.css
    import pygments.lexers.php
    import pygments.lexers.ruby
    import pygments.lexers.java
    import pygments.lexers.c_cpp
    import pygments.lexers.haskell

# Generated at 2022-06-17 20:25:55.080387
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import UnsupportedEnvironment
    from httpie.output.streams import get_default_stream
    from httpie.output.streams import get_response_stream
    from httpie.output.streams import get_request_stream
    from httpie.output.streams import get_error_stream
    from httpie.output.streams import get_output_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_isatty
    from httpie.output.streams import is_terminal
    from httpie.output.streams import is_true_color
    from httpie.output.streams import is_windows

# Generated at 2022-06-17 20:25:57.302576
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:26:09.316474
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light256') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == Solarized256Style
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
   

# Generated at 2022-06-17 20:26:20.749658
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:28.224633
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.enabled == True
    assert formatter.explicit_json == False
    assert formatter.color_scheme == DEFAULT_STYLE
    assert formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'


# Generated at 2022-06-17 20:26:43.727064
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-256-dark') == Solarized256Style

# Generated at 2022-06-17 20:26:52.332156
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_lexer_for_mime
    from httpie.plugins.colors import get_lexer_for_name
    from httpie.plugins.colors import get_lexer_for_mime_and_body
    from httpie.plugins.colors import get_lexer_for_mime_and_name
    from httpie.plugins.colors import get_lexer_for_mime_and_name_and_body
    from httpie.plugins.colors import get_lexer_for

# Generated at 2022-06-17 20:27:02.824684
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:15.514721
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import ColorizedStdoutStream
    from httpie.output.streams import ColorizedStderrStream
    from httpie.output.streams import ColorizedStdinStream
    from httpie.output.streams import ColorizedStdinfoStream
    from httpie.output.streams import ColorizedBinaryStdoutStream
    from httpie.output.streams import ColorizedBinaryStderrStream
    from httpie.output.streams import ColorizedBinaryStdinStream
    from httpie.output.streams import ColorizedBinaryStdinfoStream
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE

# Generated at 2022-06-17 20:27:16.809251
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:29.374466
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html')
    assert get_lexer('text/html', explicit_json=True)
    assert get_lexer('text/html', explicit_json=True, body='{}')
    assert get_lexer('text/html', explicit_json=True, body='{') is None
    assert get_lexer('text/html', body='{}') is None
    assert get_lexer('text/html', body='{') is None
    assert get_lexer('text/html', explicit_json=True)
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body='{}')

# Generated at 2022-06-17 20:27:32.523471
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:27:34.120840
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-17 20:27:38.422039
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}', explicit_json=True)
    assert get_lexer('application/json', body='foo')
    assert get_lexer('application/json', body='foo', explicit_json=True)
    assert get_lexer('application/json', body='foo', explicit_json=True)
    assert get_lexer('application/json', body='foo', explicit_json=True)
    assert get_lexer('application/json', body='foo', explicit_json=True)
    assert get_lexer('application/json', body='foo', explicit_json=True)
    assert get_lexer('application/json', body='foo', explicit_json=True)

# Generated at 2022-06-17 20:27:49.457232
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}', explicit_json=True)
    assert get_lexer('application/json', body='foo') is None
    assert get_lexer('application/json', body='foo', explicit_json=True)
    assert get_lexer('application/json+foo')
    assert get_lexer('application/json+foo', explicit_json=True)
    assert get_lexer('application/json+foo', body='{}')
    assert get_lexer('application/json+foo', body='{}', explicit_json=True)

# Generated at 2022-06-17 20:27:58.030438
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:05.384955
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    import os
    import sys
    import tempfile
    import unittest


# Generated at 2022-06-17 20:28:16.125457
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_SimplifiedHTTPLexer

# Generated at 2022-06-17 20:28:24.389514
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_

# Generated at 2022-06-17 20:28:28.804574
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    env.style = 'solarized'
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__ == Terminal256Formatter
    assert formatter.formatter.style.__class__ == Solarized256Style
    assert formatter.http_lexer.__class__ == SimplifiedHTTPLexer

# Generated at 2022-06-17 20:28:40.175114
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''

# Generated at 2022-06-17 20:28:45.804615
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:28:56.946779
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    env.stdout_isatty = True
    env.stdin_isatty = True
    env.is_windows = False
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.get_lexer_for_body('application/json', '{"hello":"world"}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{"hello":"world"}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{"hello":"world"}') is not None


# Generated at 2022-06-17 20:29:04.092791
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONStreams
    from httpie.plugins.builtin import JSONPointer
    from httpie.plugins.builtin import JSONQuerystringAuth
    from httpie.plugins.builtin import JSONQuerystringArray
    from httpie.plugins.builtin import JSONQuerystring
    from httpie.plugins.builtin import JSONItems
    from httpie.plugins.builtin import JSONLines
    from httpie.plugins.builtin import JSONPretty
    from httpie.plugins.builtin import JSONStream
    from httpie.plugins.builtin import JSONSyntax
    from httpie.plugins.builtin import JSON
    from httpie.plugins.builtin import AuthPlugin

# Generated at 2022-06-17 20:29:14.056960
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.output.streams import ColorizedStdoutStream
    from httpie.output.streams import ColorizedStderrStream


# Generated at 2022-06-17 20:29:26.040020
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:36.985533
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:29:48.406221
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:29:54.534140
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_ColorFormatter_format_headers_solarized
    from httpie.plugins.colors import test_ColorFormatter_format_headers_solarized_256
   

# Generated at 2022-06-17 20:29:55.982410
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:56.772053
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(colors=256))

# Generated at 2022-06-17 20:29:57.984641
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:09.412034
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_exception
    from httpie.output.streams import write_to_error
    from httpie.output.streams import write_to_output
    from httpie.output.streams import write_to_stdout
    from httpie.output.streams import write_to_stderr
    from httpie.output.streams import write_to_stdin
    from httpie.output.streams import write_to_stdout_and_stderr

# Generated at 2022-06-17 20:30:17.946149
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.explicit_json == False
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'


# Generated at 2022-06-17 20:30:19.237641
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:50.393262
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True)
    formatter = ColorFormatter(env)
    assert formatter.enabled
    assert formatter.explicit_json == False
    assert formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.get_style_class(DEFAULT_STYLE).__name__ == 'Solarized256Style'
    assert formatter.get_lexer_for_body('application/json', '{}').__class__.__name__ == 'JsonLexer'
    assert formatter.get_lexer_for_body('application/json', '{}').__class__.__name__ == 'JsonLexer'
    assert form

# Generated at 2022-06-17 20:31:00.194483
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env=env)

# Generated at 2022-06-17 20:31:07.246326
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    class MockColorFormatter(ColorFormatter):
        def __init__(self, env: Environment, explicit_json=False, color_scheme=DEFAULT_STYLE, **kwargs):
            super().__init__(env, explicit_json, color_scheme, **kwargs)
            self.enabled = True

        def get_lexer_for_body(self, mime: str, body: str) -> Optional[Type[Lexer]]:
            return get_lexer(mime, self.explicit_json, body)


# Generated at 2022-06-17 20:31:15.287357
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme='solarized')

# Generated at 2022-06-17 20:31:22.202128
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''

# Generated at 2022-06-17 20:31:30.744971
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:31:39.877740
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None

# Generated at 2022-06-17 20:31:49.870281
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:31:56.366022
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import UnixSocketPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieOptionsPlugin
    from httpie.plugins.builtin import SessionPlugin
    from httpie.plugins.builtin import DownloadPlugin
    from httpie.plugins.builtin import WgetPlugin

# Generated at 2022-06-17 20:31:57.142486
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:32:52.310906
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert ColorFormatter.get_lexer_for_body('application/json', '') == pygments.lexers.get_lexer_by_name('json')
    assert ColorFormatter.get_lexer_for_body('application/json', '{}') == pygments.lexers.get_lexer_by_name('json')
    assert ColorFormatter.get_lexer_for_body('application/json', '{') is None
    assert ColorFormatter.get_lexer_for_body('application/json', '{}', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-17 20:33:01.683850
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import StdoutStream
    from httpie.output.streams import StderrStream
    from httpie.output.streams import StdoutBytesStream
    from httpie.output.streams import StderrBytesStream
    from httpie.output.streams import StdinBytesStream
    from httpie.output.streams import StdinStream
    from httpie.output.streams import OutputStream
    from httpie.output.streams import OutputBytesStream
    from httpie.output.streams import StdoutStream
    from httpie.output.streams import StderrStream
    from httpie.output.streams import StdoutBytesStream

# Generated at 2022-06-17 20:33:09.022695
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPieJSONFormatter
    from httpie.plugins.builtin import HTTPiePrettyFormatter
    from httpie.plugins.builtin import HTTPieTableFormatter
    from httpie.plugins.builtin import HTTPieURLEncodedFormatter
    from httpie.plugins.builtin import HTTPieColorsFormatter
    from httpie.plugins.builtin import HTTPieFormattedJSONFormatter
    from httpie.plugins.builtin import HTTPieFormattedFormatter
    from httpie.plugins.builtin import HTTPieFormattedURLEncodedFormatter
    from httpie.plugins.builtin import HTTPieFormattedTableFormatter
    from httpie.plugins.builtin import HTTPieFormattedColorsFormatter
   

# Generated at 2022-06-17 20:33:17.982687
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import SyntaxHighlight
    from httpie.plugins.builtin import UnicodeFormatter
    from httpie.plugins.builtin import VerboseFormatter
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import get_formatter
    from httpie.plugins.builtin import get_prettifier
    from httpie.plugins.builtin import get_style
    from httpie.plugins.builtin import get_unicode_writer
    from httpie.plugins.builtin import is_json
   

# Generated at 2022-06-17 20:33:26.991371
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_

# Generated at 2022-06-17 20:33:33.343470
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''

# Generated at 2022-06-17 20:33:42.397066
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import ColorizedStdoutStream
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPError
    from httpie.plugins.builtin import HTTPWarningProcessor
    from httpie.plugins.builtin import HTT

# Generated at 2022-06-17 20:33:53.412130
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPBody

# Generated at 2022-06-17 20:33:56.008613
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-17 20:33:59.618946
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'