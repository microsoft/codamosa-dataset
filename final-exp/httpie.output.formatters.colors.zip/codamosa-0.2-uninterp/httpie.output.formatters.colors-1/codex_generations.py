

# Generated at 2022-06-17 20:24:50.466568
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:24:55.177651
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer

# Generated at 2022-06-17 20:25:01.013984
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.enabled == True


# Generated at 2022-06-17 20:25:07.032036
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials

    env = Environment(colors=256)
    fpm = FormatterPluginManager(env=env)
    fpm.add_plugin(ColorFormatter)
    fpm.add_plugin(PrettyOptionsPlugin)
    fpm.add_plugin(AuthPlugin)
    fpm.add_plugin(HTTPHeadersProcessor)
    fpm.add_plugin(HTTPBodyProcessor)

# Generated at 2022-06-17 20:25:19.410712
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import PrettyOptionsFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import RawOptionsFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import VerboseFormatter
    from httpie.plugins.builtin import XMLEncodedFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import XMLPrettyFormatter
    from httpie.plugins.builtin import XMLRawFormatter
    from httpie.plugins.builtin import XMLVerboseFormatter
    from httpie.plugins.builtin import YAMLForm

# Generated at 2022-06-17 20:25:32.576635
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONStreams
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import Session
    from httpie.plugins.builtin import W3CValidator
    from httpie.plugins.builtin import WindowsCRLF
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import BuiltinPlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import Help
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin

# Generated at 2022-06-17 20:25:39.808651
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:25:48.826436
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.output.streams import ColorizedStdoutStream
    from httpie.output.streams import ColorizedStderrStream
    from httpie.output.streams import StdoutStream
    from httpie.output.streams import StderrStream


# Generated at 2022-06-17 20:26:00.908631
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:02.269942
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:14.846412
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__ == Terminal256Formatter
    assert formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert formatter.formatter.style.__class__ == Solarized256Style
    assert formatter.formatter.style.styles == Solarized256Style.styles
    assert formatter.formatter.style.background_color == Solarized256Style.background_color

# Generated at 2022-06-17 20:26:15.621437
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:20.061530
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') == TextLexer
    assert get_lexer('text/plain', explicit_json=True) == TextLexer
    assert get_lexer('text/plain', body='{}') == TextLexer
    assert get_lexer('text/plain', explicit_json=True, body='{}') is not TextLexer

# Generated at 2022-06-17 20:26:21.271237
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:22.382665
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:28.463781
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import get_default_streams
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import ColorFormatter

# Generated at 2022-06-17 20:26:39.104794
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''\
GET / HTTP/1.1
Host: localhost:5000
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9
'''
    headers = color_formatter.format_headers(headers)

# Generated at 2022-06-17 20:26:50.060261
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:02.108083
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer
    assert formatter.explicit_json == False

    formatter = ColorFormatter(env, explicit_json=True, color_scheme='solarized')
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer
    assert formatter.explicit_json == True

    env.colors = False
    formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')


# Generated at 2022-06-17 20:27:14.555015
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import SOLARIZED_

# Generated at 2022-06-17 20:27:25.141935
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:27.492617
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:36.742552
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPFormProcessor
    from httpie.plugins.builtin import HTTPJSONProcessor
    from httpie.plugins.builtin import HTTPURLEncodedProcessor
    from httpie.plugins.builtin import HTTPMultipartProcessor
    from httpie.plugins.builtin import HTTPFileUploadProcessor
    from httpie.plugins.builtin import HTTPFileDownloadProcessor
    from httpie.plugins.builtin import HTTPVerboseProcessor
    from httpie.plugins.builtin import HTTPColorsProcessor

# Generated at 2022-06-17 20:27:47.670887
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.core import main
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.compat import is_windows
    import pytest
    import os
    import sys
    import io
    import json
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.plugins.builtin
    import httpie.plugins.formatter.colors
    import httpie.plugins.formatter.json
    import httpie.plugins.formatter.pretty
    import httpie.plugins.formatter.colors
    import httpie.plugins.formatter.format
    import httpie.plugins.formatter.headers
    import httpie.plugins.formatter.colors
    import httpie.plugins.form

# Generated at 2022-06-17 20:28:00.848265
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:28:11.870612
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') == pygments.lexers.get_lexer_by_name('text')
    assert get_lexer('text/html') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/html+jinja') == pygments.lexers.get_lexer_by_name('jinja')
    assert get_lexer('text/html+jinja2') == pygments.lexers.get_lexer_by_name('jinja')
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json+foo') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-17 20:28:21.395593
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import UnixSocketPlugin
    from httpie.plugins.builtin import WindowsPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import SessionPlugin
    from httpie.plugins.builtin import WgetPlugin
    from httpie.plugins.builtin import Cur

# Generated at 2022-06-17 20:28:31.436065
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256, stdout_isatty=True)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True
    assert color_formatter.group_name == 'colors'
    assert color_formatter.get_style_class(color_scheme=DEFAULT_STYLE).__name__ == 'Solarized256Style'
    assert color_formatter.get_lexer_for_

# Generated at 2022-06-17 20:28:42.216939
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') is not None
    assert formatter.get_lexer

# Generated at 2022-06-17 20:28:47.824103
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    formatter = ColorFormatter(env)
    assert formatter.enabled
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.formatter.style.__class__.__name__ == 'Solarized256Style'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False

# Generated at 2022-06-17 20:28:53.980629
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:58.764530
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer

# Generated at 2022-06-17 20:29:05.277180
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_test_get

# Generated at 2022-06-17 20:29:14.644494
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert color_formatter.get_lexer_for_body('text/html', '<html></html>') == pygments.lexers.get_lexer_by_name('html')
    assert color_formatter.get_lexer_for_body('text/html', '<html></html>') != pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-17 20:29:24.762440
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    Content-Length: 2
    '''

# Generated at 2022-06-17 20:29:32.252293
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPrettyPrinter
    from httpie.plugins.builtin import HTTPFormatter
    from httpie.plugins.builtin import HTTPConsoleStdout
    from httpie.plugins.builtin import HTTPConsoleStderr
    from httpie.plugins.builtin import HTTPOptions
    from httpie.plugins.builtin import HTTPBasicAuth
   

# Generated at 2022-06-17 20:29:36.817076
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled == True
    assert color_formatter.group_name == 'colors'
    assert color_formatter.explicit_json == False
    assert color_formatter.color_scheme == DEFAULT_STYLE
    assert color_formatter.formatter.__class__ == TerminalFormatter
    assert color_formatter.http_lexer.__class__ == PygmentsHttpLexer

# Generated at 2022-06-17 20:29:48.235489
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONStreams
    from httpie.plugins.builtin import JSONPointer
    from httpie.plugins.builtin import JSONPath
    from httpie.plugins.builtin import Form
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import MultipartFormData
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSON
    from httpie.plugins.builtin import AutoHeaders
    from httpie.plugins.builtin import HttpiePlugin
    from httpie.plugins.builtin import ArgPlugin
    from httpie.plugins.builtin import Download

# Generated at 2022-06-17 20:29:59.762895
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    env = Environment(colors=256)
    manager = FormatterPluginManager(env=env)
    formatter = manager.get('colors')
    assert formatter.get_lexer_for_body('application/json', '{}')
    assert formatter.get_lexer_for_body('application/json', '{"a":1}')
    assert not formatter.get_lexer_for_body('application/json', '{a:1}')
    assert not formatter.get_lexer_for_body('application/json', 'a')
    assert not formatter.get_lexer_for_body('application/json', '1')

# Generated at 2022-06-17 20:30:10.540276
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter

    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    json_formatter = JSONFormatter(env)

    # Test that the body is not formatted if the content type is not recognized
    body = '{"key": "value"}'
    mime = 'application/unknown'
    assert formatter.format_body(body, mime) == body

    # Test that the body is not formatted if the content type is not recognized
    # even if the body is valid JSON
    body = '{"key": "value"}'
    mime = 'application/unknown'
    assert formatter.format_body(body, mime) == body

    # Test that the body is not

# Generated at 2022-06-17 20:30:21.120463
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:28.549527
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:30:29.731338
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:32.600417
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:41.345290
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.colors import ColorFormatter
    import pygments.lexers
    import pygments.lexers.special
    import pygments.lexers.text
    import pygments.lexers.web
    import pygments.lexers.data
    import pygments.lexers.compiled
    import pygments.lexers.agile
    import pygments.lexers.functional
    import pygments.lexers.markup
    import pygments.lexers.misc
    import pygments.lexers.python
    import pygments.lexers.dotnet
    import pygments.lexers.java
    import pygments.lexers.c_cpp
    import pygments.lexers.has

# Generated at 2022-06-17 20:30:50.778905
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_ColorFormatter_format_headers_256_colors
    from httpie.plugins.colors import test_ColorFormatter_format_headers_auto_style
    from httpie.plugins.colors import test_ColorFormatter_format_headers_s

# Generated at 2022-06-17 20:31:00.576316
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''GET / HTTP/1.1
Host: example.com
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
User-Agent: HTTPie/0.9.9

'''

# Generated at 2022-06-17 20:31:11.530589
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    headers = '''\
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 13
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Tue, 01 Jan 2019 01:01:01 GMT

'''

# Generated at 2022-06-17 20:31:14.279770
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:31:20.272698
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    env = Environment(colors=256, stdout_isatty=True)
    if is_windows:
        env.colors = 256
    else:
        env.colors = 256
    manager = FormatterPluginManager(env=env)
    manager.get_enabled_plugins()
    formatter = manager.get_formatter()

# Generated at 2022-06-17 20:31:50.135751
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPGSSNEGOAuth
    from httpie.plugins.builtin import HTTPGSSAPIKeyAuth
    from httpie.plugins.builtin import HTTPAWSAuth

# Generated at 2022-06-17 20:32:01.394624
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{}')
    assert formatter.get_lexer_for_body('application/json', '{}')
    assert formatter.get_lexer_for_body('application/json', '{}')
    assert formatter.get_lexer_for_body('application/json', '{}')
    assert formatter.get_lexer_for_body('application/json', '{}')
    assert formatter.get_lexer_for_body('application/json', '{}')

# Generated at 2022-06-17 20:32:12.632864
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.enabled == True
    assert color_formatter.explicit_json == False
    assert color_formatter.formatter.__class__.__name__ == "Terminal256Formatter"
    assert color_formatter.http_lexer.__class__.__name__ == "SimplifiedHTTPLexer"
    assert color_formatter.group_name == "colors"
    assert color_formatter.get_style_class("solarized").__name__ == "Solarized256Style"

# Generated at 2022-06-17 20:32:23.194144
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor

# Generated at 2022-06-17 20:32:28.007556
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None
    assert formatter

# Generated at 2022-06-17 20:32:38.218647
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexers import get_lexer_by_name

    # Request-Line
    tokens = SimplifiedHTTPLexer().get_tokens('GET / HTTP/1.1')
    assert tokens[0] == (Token.Name.Function, 'GET')
    assert tokens[1] == (Token.Text, ' ')
    assert tokens[2] == (Token.Name.Namespace, '/')
    assert tokens[3] == (Token.Text, ' ')
    assert tokens[4] == (Token.Keyword.Reserved, 'HTTP')
    assert tokens[5] == (Token.Operator, '/')
    assert tokens[6] == (Token.Number, '1.1')

    # Response Status-Line
    tokens = SimplifiedHTTPLexer().get

# Generated at 2022-06-17 20:32:39.404898
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:32:40.682534
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:32:52.420518
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPFormProcessor
    from httpie.plugins.builtin import HTTPJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPStreamProcessor
    from httpie.plugins.builtin import HTTPPrintHeadersProcessor
    from httpie.plugins.builtin import HTTPPrintBodyProcessor
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 20:33:01.713397
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:34:02.683459
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:34:12.610670
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True
    assert color_formatter.group_name == 'colors'

# Generated at 2022-06-17 20:34:21.857196
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPrettyPrinter
    from httpie.plugins.builtin import HTTPFormatter
    from httpie.plugins.builtin import HTTPConsolePrettyPrinter
    from httpie.plugins.builtin import HTTPConsoleFormatter
    from httpie.plugins.builtin import HTTPConsoleStdoutStream
    from httpie.plugins.builtin import HTTPConsole

# Generated at 2022-06-17 20:34:31.517324
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPFormProcessor
    from httpie.plugins.builtin import HTTPJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPStreamProcessor
    from httpie.plugins.builtin import HTTPPrintHeadersProcessor
    from httpie.plugins.builtin import HTTPPrintBodyProcessor
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 20:34:41.987809
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.output.streams import Stream
