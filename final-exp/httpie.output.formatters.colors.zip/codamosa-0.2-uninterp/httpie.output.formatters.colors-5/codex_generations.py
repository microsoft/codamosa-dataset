

# Generated at 2022-06-17 20:25:11.582469
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:25:16.885501
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') != pygments.styles.get_style_by_name('solarized')

# Generated at 2022-06-17 20:25:24.142214
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:25:35.148073
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import StdoutBytesIO
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPWarningProcessor
    from httpie.plugins.builtin import HTTPInfoProcessor
    from httpie.plugins.builtin import HTTPCookieProcessor
    from httpie.plugins.builtin import HTTPOptionsProcessor

# Generated at 2022-06-17 20:25:46.649450
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)

# Generated at 2022-06-17 20:26:00.326976
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import ImplicitContentTypePlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import StreamingJSONPlugin
    from httpie.plugins.builtin import Stream
    from httpie.plugins.builtin import DownloadPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin

# Generated at 2022-06-17 20:26:05.626382
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter == TerminalFormatter()
    assert color_formatter.http_lexer == PygmentsHttpLexer()
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True

    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter == Terminal256Formatter(style=Solarized256Style)
    assert color_formatter.http_lexer == SimplifiedHTTPLexer()
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True

    env.colors = False
    color_formatter = ColorFormatter(env)

# Generated at 2022-06-17 20:26:10.667406
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:26:21.479748
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:22.985126
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:31.693191
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:42.156725
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:51.923721
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env=env)
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{') is None
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None
    assert color_formatter.get_lexer_for_body('application/json', '{') is None
    assert color_formatter.get_lexer_for_body('application/json', '{}') is not None
    assert color_formatter.get_lexer_for_

# Generated at 2022-06-17 20:27:02.701365
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import UnixSocketPlugin
    from httpie.plugins.builtin import WindowsPlugin
    from httpie.plugins.builtin import HelpPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieColors

# Generated at 2022-06-17 20:27:15.340900
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:23.461574
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_streams
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream

# Generated at 2022-06-17 20:27:28.446044
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:29.088158
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:37.746542
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import UnixSocketPlugin
    from httpie.plugins.builtin import WindowsPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieColors
    from httpie.plugins.builtin import HTTPieSession
    from httpie.plugins.builtin import HTTPieStream

# Generated at 2022-06-17 20:27:39.324474
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:01.832560
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.core import main
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import SyntaxHighlight
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import get_formatter
    from httpie.plugins.builtin import get_parser
    from httpie.plugins.builtin import parser_options
    from httpie.plugins.builtin import stream
    from httpie.plugins.builtin import stream_options
    from httpie.plugins.builtin import syntax_options
    from httpie.plugins.builtin import verbose_options
    from httpie.plugins.builtin import verb

# Generated at 2022-06-17 20:28:13.202876
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/html; charset=utf-8') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json; charset=utf-8') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json; charset=utf-8', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-17 20:28:14.424451
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:15.722353
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:28.038594
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Server: gunicorn/19.9.0
Date: Thu, 18 Oct 2018 16:12:39 GMT

'''

# Generated at 2022-06-17 20:28:30.219621
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:41.138451
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:28:48.574550
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Test for JSON
    assert get_lexer('application/json') is not None
    assert get_lexer('application/json', explicit_json=True) is not None
    assert get_lexer('application/json', explicit_json=True, body='{}') is not None
    assert get_lexer('application/json', explicit_json=True, body='{') is None
    assert get_lexer('application/json', explicit_json=True, body='{}') is not None
    assert get_lexer('application/json', explicit_json=True, body='{') is None
    assert get_lexer('application/json', explicit_json=True, body='{}') is not None
    assert get_lexer('application/json', explicit_json=True, body='{') is None

# Generated at 2022-06-17 20:29:00.796425
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json', explicit_json=True, body='{') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='') is None
    assert get_lexer('application/json', explicit_json=False, body='{}') is None
    assert get_lexer('application/json', explicit_json=False, body='{') is None
   

# Generated at 2022-06-17 20:29:12.910856
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    env.stdout_isatty = True
    env.stdout_raw = False
    env.is_windows = False
    env.color_scheme = 'auto'
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') is not None

# Generated at 2022-06-17 20:29:25.516890
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(colors=256, stdout_isatty=True))

# Generated at 2022-06-17 20:29:36.348500
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPStatsProcessor
    from httpie.plugins.builtin import HTTPPrettyPrinter
    from httpie.plugins.builtin import HTTPFormatter
    from httpie.plugins.builtin import HTTPCLI

# Generated at 2022-06-17 20:29:47.920257
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None
    assert formatter.get_lexer_for_body('application/json', '{}') is not None
    assert formatter.get_lexer_for_body('application/json', '{') is None
    assert formatter

# Generated at 2022-06-17 20:29:59.590677
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # type: () -> None
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import SyntaxHighlightPlugin

    env = Environment(colors=256, stdin=None, stdout=None,
                      stdout_isatty=True, stdin_isatty=True)
    plugins = [
        PrettyOptionsPlugin,
        SyntaxHighlightPlugin,
        JSONFormatterPlugin,
        StreamFormatterPlugin,
    ]
    formatter = FormatterPlugin.get_instance(env, plugins)
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_lexer_for

# Generated at 2022-06-17 20:30:10.504486
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')

# Generated at 2022-06-17 20:30:21.511184
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONOptionsPlugin
    from httpie.plugins.builtin import HTTPOptionsPlugin
    from httpie.plugins.builtin import ImplicitHTTPMethodOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentialsPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import AutoContentTypePlugin
    from httpie.plugins.builtin import HttpBinPlugin
    from httpie.plugins.builtin import HttpBinSSLPlugin
    from httpie.plugins.builtin import HttpBinAuthPlugin
    from httpie.plugins.builtin import HttpBinCook

# Generated at 2022-06-17 20:30:29.624789
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True

# Generated at 2022-06-17 20:30:36.904432
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import UnsupportedOutputStream

    env = Environment()
    env.stdout = UnsupportedOutputStream()
    env.stderr = UnsupportedOutputStream()
    env.stdin = UnsupportedOutputStream()
    env.stdout_isatty = True
    env.stderr_isatty = True
    env.stdin_isatty = True
    env.colors = 256
    env.color_scheme = 'solarized'
    env.explicit_json = False
    env.prettify = False
    env.prettify_all = False
    env.stream = False
    env.verbose = False
   

# Generated at 2022-06-17 20:30:48.479277
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:30:49.765031
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:31:34.010871
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.enabled
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.get_style_class(DEFAULT_STYLE).__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:31:42.107590
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') == TextLexer
    assert get_lexer('text/plain', explicit_json=True, body='{"foo": "bar"}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='{"foo": "bar"}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='{"foo": "bar"') is None
    assert get_lexer('application/json', explicit_json=True, body='{"foo": "bar"') is None
    assert get_lex

# Generated at 2022-06-17 20:31:46.400098
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    assert color_formatter.formatter.style == Solarized256Style
    color_formatter = ColorFormatter(env, color_scheme='auto')
    assert color_formatter.formatter.style == Terminal256Formatter.style

# Generated at 2022-06-17 20:31:50.859191
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:31:57.015174
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    env.style = 'solarized'
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:32:06.238065
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class MockEnvironment:
        def __init__(self, colors):
            self.colors = colors

    env = MockEnvironment(256)
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__ == Terminal256Formatter
    assert formatter.http_lexer.__class__ == SimplifiedHTTPLexer

    env = MockEnvironment(8)
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__ == TerminalFormatter
    assert formatter.http_lexer.__class__ == PygmentsHttpLexer

# Generated at 2022-06-17 20:32:10.327893
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert color_formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:32:15.266598
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme='solarized')
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:32:24.456075
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json', explicit_json=True, body='{')
    assert get_lexer('application/json', explicit_json=True, body='foo')
    assert get_lexer('application/json', explicit_json=True, body='')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{')
    assert get_lexer('application/json', body='foo')

# Generated at 2022-06-17 20:32:33.104128
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.__class__ == TerminalFormatter
    assert color_formatter.http_lexer.__class__ == PygmentsHttpLexer
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True

    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True


# Generated at 2022-06-17 20:33:00.058288
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json', explicit_json=True, body='{') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None
    assert get_lexer('application/json', explicit_json=True, body='foo') is None

# Generated at 2022-06-17 20:33:01.911481
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    assert color_formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:33:07.191757
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.formatter.style.__class__ == Solarized256Style
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True

    env.colors = 8
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.__class__ == TerminalFormatter
    assert color_formatter.http_lexer.__class

# Generated at 2022-06-17 20:33:17.189989
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled == True
    assert color_formatter.formatter.__class__ == TerminalFormatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert color_formatter.explicit_json == False
    assert color_formatter.group_name == 'colors'

    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled == True
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert color_formatter.explicit_json == False


# Generated at 2022-06-17 20:33:19.604765
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(colors=256), color_scheme=SOLARIZED_STYLE)

# Generated at 2022-06-17 20:33:20.531578
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(colors=256))

# Generated at 2022-06-17 20:33:21.450255
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(colors=256))

# Generated at 2022-06-17 20:33:26.539547
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.style == Solarized256Style
    assert color_formatter.http_lexer == SimplifiedHTTPLexer
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True

# Generated at 2022-06-17 20:33:28.432300
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter is not None
    assert color_formatter.http_lexer is not None

# Generated at 2022-06-17 20:33:38.507776
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.enabled == True
    assert color_formatter.explicit_json == False
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.get_style_class(DEFAULT_STYLE).__name__ == 'Solarized256Style'


# Generated at 2022-06-17 20:34:21.959231
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html')
    assert get_lexer('text/html; charset=utf-8')
    assert get_lexer('text/html; charset=utf-8', body='<!doctype html>')
    assert get_lexer('text/html; charset=utf-8', body='<!DOCTYPE html>')
    assert get_lexer('text/html; charset=utf-8', body='<html></html>')
    assert get_lexer('text/html; charset=utf-8', body='<html/>')
    assert get_lexer('text/html; charset=utf-8', body='<html>')
    assert get_lexer('text/html; charset=utf-8', body='<html>\n')
    assert get_lex

# Generated at 2022-06-17 20:34:25.960529
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled == True
    assert color_formatter.formatter is not None
    assert color_formatter.http_lexer is not None


# Generated at 2022-06-17 20:34:30.478015
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.enabled == True
    assert formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'


# Generated at 2022-06-17 20:34:35.505970
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env=env, color_scheme='solarized')
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer

# Generated at 2022-06-17 20:34:40.115035
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme=DEFAULT_STYLE)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:34:49.064380
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled == True
    assert color_formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.get_style_class('solarized') == Solarized256Style
    assert color_formatter.get_style_class('auto') == Solarized256Style
    assert color_formatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert color_formatter.get_style_