

# Generated at 2022-06-17 20:25:11.687759
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)

    assert formatter.get_lexer_for_body('application/json', '{}')
    assert formatter.get_lexer_for_body('application/json', '[]')
    assert formatter.get_lexer_for_body('application/json', '["foo"]')
    assert formatter.get_lexer_for_body('application/json', '{"foo": "bar"}')
    assert formatter.get_lexer_for_body('application/json', '{"foo": "bar"}')
    assert formatter.get_lexer_for_body('application/json', '{"foo": "bar"}')

# Generated at 2022-06-17 20:25:21.796971
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('text/html', '<html></html>') == pygments.lexers.get_lexer_by_name('html')
    assert formatter.get_lexer_for_body('text/plain', '<html></html>') == pygments.lexers.get_lexer_by_name('text')
    assert formatter.get_lexer_for_body('text/plain', '{"key":"value"}') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-17 20:25:33.862837
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor


# Generated at 2022-06-17 20:25:39.654051
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer

# Generated at 2022-06-17 20:25:42.048978
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:25:49.389189
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_lexer_for_body_explicit_json

# Generated at 2022-06-17 20:25:58.197270
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:10.465414
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_lexer

# Generated at 2022-06-17 20:26:16.102797
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:26:24.502117
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # type: () -> None
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_stdout
    from httpie.plugins import FormatterPluginManager
    from httpie.plugins import plugin_manager

    # Setup
    env = Environment(
        colors=256,
        stdin=None,
        stdout=get_default_streams().stdout,
        stderr=get_default_streams().stderr,
        stdout_isatty=True,
        stdin_isatty=False,
        output_options=None,
        output_file=None,
        options=None,
        config=None,
        plugins=FormatterPluginManager(plugin_manager),
    )
    color_formatter = ColorFormatter(env)



# Generated at 2022-06-17 20:26:33.508989
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:26:43.650256
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPGSSNEGOAuth
    from httpie.plugins.builtin import HTTPAWSAuthPlugin
    from httpie.plugins.builtin import HTTPM

# Generated at 2022-06-17 20:26:52.278135
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''

# Generated at 2022-06-17 20:26:55.155593
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-17 20:27:03.532388
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''

# Generated at 2022-06-17 20:27:04.861829
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:06.959818
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:16.162389
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light256') == Solarized256Style

# Generated at 2022-06-17 20:27:28.426262
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:37.249024
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LEN
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_COLOR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_COLOR_LEN
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class

# Generated at 2022-06-17 20:28:01.535108
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{"foo": "bar"}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{"foo": "bar"}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{"foo": "bar"}') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-17 20:28:12.834054
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_

# Generated at 2022-06-17 20:28:19.562267
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('text/html', '<html></html>') == pygments.lexers.get_lexer_by_name('html')
    assert formatter.get_lexer_for_body('text/plain', 'hello') == pygments.lexers.get_lexer_by_name('text')

# Generated at 2022-06-17 20:28:27.355672
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_pygments_highlight

# Generated at 2022-06-17 20:28:38.512282
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:28:47.144220
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    env.style = 'solarized'
    formatter = ColorFormatter(env)
    headers = '''GET / HTTP/1.1
Host: localhost:8080
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate, compress
Accept: */*
Connection: keep-alive'''

# Generated at 2022-06-17 20:28:57.886773
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_SimplifiedHTTPLexer

# Generated at 2022-06-17 20:29:04.705721
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    assert formatter.format_headers("GET / HTTP/1.1\r\nHost: example.com\r\n\r\n") == "\x1b[38;5;245mGET / HTTP/1.1\x1b[39m\r\n\x1b[38;5;245mHost: example.com\x1b[39m\r\n\r\n"

# Generated at 2022-06-17 20:29:14.241049
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import ColorStdoutStream
    from httpie.output.streams import ColorStderrStream
    from httpie.output.streams import ColorFileStream
    from httpie.output.streams import ColorBytesStream
    from httpie.output.streams import ColorStringStream
    from httpie.output.streams import ColorStream
    from httpie.output.streams import ColorStreamBase
    from httpie.output.streams import ColorStreamBase
    from httpie.output.streams import ColorStreamBase
    from httpie.output.streams import ColorStreamBase
    from httpie.output.streams import ColorStreamBase
    from httpie.output.streams import ColorStreamBase

# Generated at 2022-06-17 20:29:16.048971
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:31.885904
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:33.613752
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:35.043699
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:45.911358
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.compat import is_windows
    from httpie.output.streams import get_default_streams
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import get_default_streams

# Generated at 2022-06-17 20:29:50.254882
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    assert color_formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:29:57.863221
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    env.explicit_json = True
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled == True
    assert color_formatter.explicit_json == True
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.get_style_class('solarized').__name__ == 'Solarized256Style'
    assert color_formatter.get_lexer_for_body('application/json', '{"key": "value"}').__name__ == 'JsonLexer'

# Generated at 2022-06-17 20:30:09.326778
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Test the case of a JSON response with an incorrect Content-Type
    assert get_lexer(mime='text/html', body='{"foo": "bar"}') == pygments.lexers.get_lexer_by_name('json')

    # Test the case of a JSON response with a correct Content-Type
    assert get_lexer(mime='application/json', body='{"foo": "bar"}') == pygments.lexers.get_lexer_by_name('json')

    # Test the case of a JSON response with a correct Content-Type and an explicit --json
    assert get_lexer(mime='application/json', body='{"foo": "bar"}', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')

    # Test the case of a JSON response with an incorrect Content-

# Generated at 2022-06-17 20:30:12.626374
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:22.743949
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('text/html', '<html>') is not None
    assert formatter.get_lexer_for_body('text/html', '<html>') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') is not None
    assert formatter.get_lexer_for_body('application/json', '{"a":1}') is not None
    assert formatter.get_lexer_for_body

# Generated at 2022-06-17 20:30:32.959257
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256')

# Generated at 2022-06-17 20:30:50.549903
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:31:00.348143
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer

    env = Environment(colors=256)
    json_formatter = JSONFormatter(env=env)
    color_formatter = ColorFormatter(env=env)

    # Test 1: JSON
    mime = 'application/json'
    body = '{"key": "value"}'
    lexer = get_lexer(mime=mime, explicit_json=False, body=body)
    assert lexer == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-17 20:31:11.416968
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = FormatterPlugin(env=env)
    color_formatter = ColorFormatter(env=env)
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}')


# Generated at 2022-06-17 20:31:18.166715
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.core import main
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream

# Generated at 2022-06-17 20:31:23.450587
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(Environment(colors=256), color_scheme='solarized')
    assert color_formatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:31:35.515406
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPError
    from httpie.plugins.builtin import HTTPWarningProcessor
    from httpie.plugins.builtin import HTTPWarning
    from httpie.plugins.builtin import HTTPResponseHeadersProcessor

# Generated at 2022-06-17 20:31:45.958980
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import SimplifiedHTTPLexer

# Generated at 2022-06-17 20:31:53.067072
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter

    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Sun, 20 Jan 2019 16:26:22 GMT

'''

# Generated at 2022-06-17 20:31:58.168493
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:32:10.935536
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:52.346946
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPMethodOverridePlugin
    from httpie.plugins.builtin import HTTPieCookiePlugin
    from httpie.plugins.builtin import HTTPieSessionPlugin
    from httpie.plugins.builtin import HTTPieStreamPlugin

# Generated at 2022-06-17 20:32:58.413842
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_error_stream
   

# Generated at 2022-06-17 20:33:08.153492
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import get_default_streams
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPGzip
    from httpie.plugins.builtin import HTTPPrettyPrint
    from httpie.plugins.builtin import HTTPPrintHooks
    from httpie.plugins.builtin import HTTPStream
    from httpie.plugins.builtin import HTTPTrace
    from httpie.plugins.builtin import HTTPVerbose
    from httpie.plugins.builtin import HTTPVersion

# Generated at 2022-06-17 20:33:17.459320
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 20:33:24.844014
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:33:36.006146
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:33:40.000641
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:33:45.534313
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.enabled == True
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert color_formatter.explicit_json == False
    assert color_formatter.group_name == 'colors'
    assert color_formatter.kwargs == {}


# Generated at 2022-06-17 20:33:49.314226
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:33:51.336528
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style