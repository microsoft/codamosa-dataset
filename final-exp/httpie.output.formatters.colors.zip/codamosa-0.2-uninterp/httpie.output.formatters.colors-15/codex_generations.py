

# Generated at 2022-06-17 20:25:03.568919
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.output.streams import get_default_streams

# Generated at 2022-06-17 20:25:12.763020
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_lexer_for_body('application/json', '{"key": "value"}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body('application/json', '{"key": "value"}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body('application/json', '{"key": "value"}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer

# Generated at 2022-06-17 20:25:22.191544
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.colors import ColorFormatter
    import pygments.lexers
    import pygments.lexers.special
    import pygments.lexers.text
    import pygments.lexers.web
    import pygments.lexers.data
    import pygments.lexers.templates
    import pygments.lexers.compiled
    import pygments.lexers.python
    import pygments.lexers.dotnet
    import pygments.lexers.java
    import pygments.lexers.javascript
    import pygments.lexers.c_cpp
    import pygments.lexers.go

# Generated at 2022-06-17 20:25:30.432289
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    env.style = 'auto'
    formatter = ColorFormatter(env)
    assert formatter.enabled == True
    assert formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False

# Generated at 2022-06-17 20:25:38.554498
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import SyntaxHighlightPlugin
    from httpie.plugins.builtin import UnicodeDisplayPlugin
    from httpie.plugins.builtin import VerboseFormatterPlugin
    from httpie.plugins.builtin import WindowsConsoleStdoutPlugin
    from httpie.plugins.builtin import get_builtin_plugins

    env = Environment(colors=256)
    plugins = get_builtin_plugins()

# Generated at 2022-06-17 20:25:48.220563
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_lexer_for_body_explicit_json
    from httpie.plugins.colors import test_get_lexer_for_body_json
    from httpie.plugins.colors import test_get_lexer_for_

# Generated at 2022-06-17 20:26:00.725252
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    formatter = ColorFormatter(env)
    assert formatter.enabled == True
    assert formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False

    formatter = ColorFormatter(env, explicit_json=True)
    assert formatter.enabled == True
    assert formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == True

    env.colors = 256

# Generated at 2022-06-17 20:26:02.095517
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:26:11.941180
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_Solarized256Style
    from httpie.plugins.colors import test_test

# Generated at 2022-06-17 20:26:20.194815
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True

# Generated at 2022-06-17 20:26:36.341354
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:45.517144
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light256') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == Solarized256Style
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
   

# Generated at 2022-06-17 20:27:00.418202
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_SimplifiedHTTPLexer

# Generated at 2022-06-17 20:27:11.408579
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.enabled == True
    assert formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.get_style_class(DEFAULT_STYLE).__name__ == 'Solarized256Style'
    assert formatter.get_lexer_for_body('application/json', '{}').__name__ == 'JsonLexer'
    assert formatter.get_lexer_for_body('application/json', '{').__name__ == 'TextLexer'
    assert formatter.get_lex

# Generated at 2022-06-17 20:27:16.302534
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True)
    formatter = ColorFormatter(env)
    assert formatter.enabled == True
    assert formatter.formatter.__class__ == TerminalFormatter
    assert formatter.http_lexer.__class__ == PygmentsHttpLexer
    assert formatter.explicit_json == False

    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.enabled == True
    assert formatter.formatter.__class__ == Terminal256Formatter
    assert formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert formatter.explicit_json == False

    env = Environment(colors=256)

# Generated at 2022-06-17 20:27:28.609421
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)
    assert formatter.get_lexer_for_body('application/json', '{"key": "value"}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{"key": "value"}') != pygments.lexers.get_lexer_by_name('xml')
    assert formatter.get_lexer_for_body('application/json', '{"key": "value"}') != pygments.lexers.get_lexer_by_name('html')

# Generated at 2022-06-17 20:27:37.390460
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 17
Connection: keep-alive

'''

# Generated at 2022-06-17 20:27:39.246534
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:27:44.848393
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.explicit_json == False
    assert color_formatter.formatter != None
    assert color_formatter.http_lexer != None

# Generated at 2022-06-17 20:27:52.187577
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:28:17.552104
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_headers
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_SimplifiedHTTPLexer

# Generated at 2022-06-17 20:28:28.605939
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    env = Environment(colors=256)
    fpm = FormatterPluginManager(env=env)
    fpm.load_builtin_plugins()
    color_formatter = fpm.get('colors')

# Generated at 2022-06-17 20:28:39.947327
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:28:47.956343
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment

    env = Environment(colors=256)
    formatter = ColorFormatter(env)

    # Test for JSON
    mime = 'application/json'
    body = '{"foo": "bar"}'
    lexer = formatter.get_lexer_for_body(mime, body)
    assert lexer.name == 'JSON'

    # Test for XML
    mime = 'application/xml'
    body = '<foo>bar</foo>'
    lexer = formatter.get_lexer_for_body(mime, body)
    assert lexer.name == 'XML'

    # Test for HTML
    mime = 'text/html'

# Generated at 2022-06-17 20:29:00.600356
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:29:02.932986
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:29:13.634225
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class

# Generated at 2022-06-17 20:29:18.109965
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_streams
    from httpie.output.streams import write_to_output_streams_with_colors
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import get_colors
    from httpie.plugins import get_formatter
    from httpie.plugins import get_parser
    from httpie.plugins import get_prettifier
    from httpie.plugins import get_style
    from httpie.plugins import get_unicode
    from httpie.plugins import get_verbose
    from httpie.plugins import get_warnings
   

# Generated at 2022-06-17 20:29:29.466983
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache
Vary: Accept-Encoding

'''

# Generated at 2022-06-17 20:29:40.859758
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    env = Environment()
    env.stdout_isatty = True
    env.colors = 256
    env.color_scheme = 'solarized'
    manager = FormatterPluginManager(env=env)
    formatter = manager.get('colors')

# Generated at 2022-06-17 20:30:03.688609
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import Simpl

# Generated at 2022-06-17 20:30:12.330451
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style

# Generated at 2022-06-17 20:30:22.610888
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPFormProcessor
    from httpie.plugins.builtin import HTTPJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPStreamProcessor
    from httpie.plugins.builtin import HTTPPrintHeadersProcessor
    from httpie.plugins.builtin import HTTPPrintBodyProcessor
    from httpie.plugins.builtin import HTTPPrintBinaryProcessor

# Generated at 2022-06-17 20:30:32.843349
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 2
Connection: keep-alive
Date: Tue, 11 Sep 2018 10:30:19 GMT
Server: gunicorn/19.9.0
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true
Via: 1.1 vegur

'''

# Generated at 2022-06-17 20:30:41.537577
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Test for JSON
    assert get_lexer(mime='application/json', body='{"a":1}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(mime='application/json', body='{"a":1}', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(mime='application/json', body='{"a":1}', explicit_json=False) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(mime='application/json', body='{"a":1}', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-17 20:30:50.885545
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:31:00.575992
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.get_lexer_for_body('application/json', '{}') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json', '{') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-17 20:31:11.530639
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    env.style = 'solarized'
    formatter = ColorFormatter(env)
    body = '{"name":"value"}'
    mime = 'application/json'

# Generated at 2022-06-17 20:31:18.280879
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']
    assert lexer.tokens['root'][0][0] == (
        r'([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)'
    )

# Generated at 2022-06-17 20:31:28.137766
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream

# Generated at 2022-06-17 20:32:09.860831
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/html', explicit_json=True) == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/html', explicit_json=True, body='{}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-17 20:32:17.935860
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.formatter.__class__ == Terminal256Formatter
    assert formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert formatter.explicit_json == False
    assert formatter.enabled == True

# Generated at 2022-06-17 20:32:22.193013
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    formatter = ColorFormatter(env)
    assert formatter.enabled
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer

# Generated at 2022-06-17 20:32:29.580334
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.explicit_json == False
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'


# Generated at 2022-06-17 20:32:38.760317
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}')

# Generated at 2022-06-17 20:32:49.917081
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='{}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='{') is None
    assert get_lexer('application/json', explicit_json=True, body='{}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='{') is None
    assert get

# Generated at 2022-06-17 20:32:55.325486
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=True, color_scheme='solarized')
    assert color_formatter.formatter.__class__ == Terminal256Formatter
    assert color_formatter.formatter.style.__class__ == Solarized256Style
    assert color_formatter.http_lexer.__class__ == SimplifiedHTTPLexer
    assert color_formatter.explicit_json == True

# Generated at 2022-06-17 20:32:57.329379
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(colors=256), color_scheme='solarized')

# Generated at 2022-06-17 20:33:02.067298
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True
    assert color_formatter.group_name == 'colors'

# Generated at 2022-06-17 20:33:07.306041
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html')
    assert get_lexer('text/html; charset=utf-8')
    assert get_lexer('application/json')
    assert get_lexer('application/json; charset=utf-8')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json; charset=utf-8', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json; charset=utf-8', explicit_json=True, body='{}')
    assert get_lexer('application/json', explicit_json=True, body='{') is None

# Generated at 2022-06-17 20:33:29.385777
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:33:40.445260
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json', explicit_json=True, body='{') is None
    assert get_lexer('application/json', explicit_json=True, body='') is None
    assert get_lexer('application/json', explicit_json=True) is None
    assert get_lexer('application/json', body='{') is None
    assert get_lexer('application/json', body='') is None
    assert get_lexer('application/json')
    assert get_lexer('application/json', body='{}')

# Generated at 2022-06-17 20:33:45.093711
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme='solarized')
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer

    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme='auto')
    assert formatter.formatter.style == Solarized256Style
    assert formatter.http_lexer == SimplifiedHTTPLexer

    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme='fruity')
    assert formatter.formatter.style == pygments.styles.get_style_by_name('fruity')
    assert formatter.http_lexer == PygmentsHttpLex

# Generated at 2022-06-17 20:33:54.140181
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.explicit_json == False
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'
    assert color_formatter.enabled == True

# Generated at 2022-06-17 20:34:00.213036
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:34:03.908580
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    assert color_formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:34:08.927938
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:34:12.717833
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:34:21.883450
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body='{}')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{') is None
    assert get_lexer('application/json', body='foo') is None
    assert get_lexer('application/json', body='foo', explicit_json=True)
    assert get_lexer('application/json', body='foo', explicit_json=True)
    assert get_lexer('application/json', body='foo', explicit_json=False) is None
    assert get_lexer('application/json', body='foo', explicit_json=False) is None
   

# Generated at 2022-06-17 20:34:24.920645
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    formatter = ColorFormatter(env)
    assert formatter.enabled