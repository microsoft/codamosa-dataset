

# Generated at 2022-06-17 20:25:09.434610
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json', body='{}')
    assert get_lexer('application/json', body='{}', explicit_json=True)
    assert get_lexer('application/json', body='{', explicit_json=True) is None
    assert get_lexer('application/json', body='{', explicit_json=False) is None
    assert get_lexer('application/json', body='{}', explicit_json=False)
    assert get_lexer('application/json', body='foo') is None
    assert get_lexer('application/json', body='foo', explicit_json=True) is None
    assert get_lexer('application/json', body='foo', explicit_json=False) is None

# Generated at 2022-06-17 20:25:20.375665
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.output.streams import get_default_streams
    from httpie.output.streams import write_to_output_streams
    from httpie.output.streams import write_to_error_stream
    from httpie.output.streams import write_to_output_stream
    from httpie.output.streams import write_to_output_stream_no_color
    from httpie.output.streams import write_to_output_stream_color
    from httpie.output.streams import write_to_output_stream_color_256
    from httpie.output.streams import write_to_output_stream_color_auto
    from httpie.output.streams import write_to_output_stream_color_

# Generated at 2022-06-17 20:25:32.972441
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    formatter = ColorFormatter(env)
    assert formatter.enabled == True
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.get_style_class('solarized').__name__ == 'Solarized256Style'
    assert formatter.get_style_class('auto').__name__ == 'TerminalFormatter'
    assert formatter.get_style_class('fruity').__name__ == 'FruityFormatter'

# Generated at 2022-06-17 20:25:35.796276
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:25:44.779410
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.formatter.style.__class__.__name__ == 'Solarized256Style'
    assert formatter.explicit_json == False
    assert formatter.enabled == True

# Generated at 2022-06-17 20:25:55.050039
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexers import get_lexer_by_name
    from pygments.lexers.text import HttpLexer as PygmentsHttpLexer

    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:01.645524
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_pygments_highlight

# Generated at 2022-06-17 20:26:11.555395
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:26:21.891197
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import main
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.format import JSONFormatter
    from httpie.plugins.format import PrettyJSONFormatter
    from httpie.plugins.format import StreamFormatter
    from httpie.plugins.format import StreamFormatterV2
    from httpie.plugins.format import get_formatter
    from httpie.plugins.format import get_parser
    from httpie.plugins.format import get_validator
    from httpie.plugins.format import parser
    from httpie.plugins.format import validator

# Generated at 2022-06-17 20:26:32.644714
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_response_stream
    from httpie.output.streams import get_request_item_stream
    from httpie.output.streams import get_response_item_stream
    from httpie.output.streams import get_request_stream
    from httpie.output.streams import get_response_stream
    from httpie.output.streams import get_stream

    env = Environment()
    env.stdout = get_binary_stream('stdout')
    env.st

# Generated at 2022-06-17 20:26:42.155490
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = DEFAULT_STYLE
    formatter = ColorFormatter(env)
    assert formatter.enabled == True

# Generated at 2022-06-17 20:26:47.669016
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:27:01.210365
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='{}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='{') is None
    assert get_lexer('application/json', explicit_json=True, body='{}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='{}') == pygments.lex

# Generated at 2022-06-17 20:27:03.471858
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized'
    formatter = ColorFormatter(env)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:27:16.111511
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPBearerAuth


# Generated at 2022-06-17 20:27:23.943261
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solar

# Generated at 2022-06-17 20:27:28.742590
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:27:34.670371
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:27:38.935299
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:27:45.100540
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import StdoutBytesIO
    from httpie.output.streams import StderrBytesIO
    from httpie.output.streams import StdoutUnicodeIO
    from httpie.output.streams import StderrUnicodeIO
    from httpie.output.streams import StdoutBytes
    from httpie.output.streams import StderrBytes
    from httpie.output.streams import StdoutUnicode
    from httpie.output.streams import StderrUnicode
    from httpie.output.streams import StdoutString
    from httpie.output.streams import StderrString
    from httpie.output.streams import StdoutStringIO
    from httpie.output.streams import StderrStringIO

# Generated at 2022-06-17 20:28:02.882807
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.style == Solarized256Style
    assert color_formatter.http_lexer == SimplifiedHTTPLexer
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True

# Generated at 2022-06-17 20:28:03.886311
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:12.249855
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env=env)
    assert formatter.format_headers("GET / HTTP/1.1\nHost: example.com\n") == "\x1b[38;5;245mGET / HTTP/1.1\n\x1b[38;5;245mHost: example.com\n\x1b[0m"

# Generated at 2022-06-17 20:28:17.482562
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-17 20:28:28.605493
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.compat import is_windows
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import Simpl

# Generated at 2022-06-17 20:28:33.799907
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import SimplifiedHTTPLexer

# Generated at 2022-06-17 20:28:43.963388
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    import pygments.lexers
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body

# Generated at 2022-06-17 20:28:46.077966
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:28:57.200288
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_style_class
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import test_ColorFormatter_format_body
    from httpie.plugins.colors import test_get_lexer
    from httpie.plugins.colors import test_get_lexer_for_body
    from httpie.plugins.colors import test_get_style_class
    from httpie.plugins.colors import test_

# Generated at 2022-06-17 20:29:04.204428
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_lexer_for_body('application/json', '{"a": 1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a": 1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a": 1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a": 1}')
    assert color_formatter.get_lexer_for_body('application/json', '{"a": 1}')
    assert color_formatter.get_lexer_for_body

# Generated at 2022-06-17 20:29:39.134889
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPPrettyPrinter
    from httpie.plugins.builtin import HTTPFormatter
    from httpie.plugins.builtin import HTTPOptions
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerToken
   

# Generated at 2022-06-17 20:29:50.920708
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPrettyPrinter
    from httpie.plugins.builtin import HTTPFormatter
    from httpie.plugins.builtin import HTTPStatusProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPWarningProcessor

# Generated at 2022-06-17 20:29:58.286356
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:30:09.568583
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuerystringProcessor
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPPathProcessor
    from httpie.plugins.builtin import HTTPQuery

# Generated at 2022-06-17 20:30:19.364258
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'
    assert color_formatter.explicit_json == False
    assert color_formatter.enabled == True

# Generated at 2022-06-17 20:30:30.296631
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}') != pygments.lexers.get_lexer_by_name('html')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}') != pygments.lexers.get_lexer_by_name('xml')
    assert color_formatter.get_lexer_for_

# Generated at 2022-06-17 20:30:33.068937
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:30:41.688781
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.plugins.builtin
    import httpie.plugins.formatter.colors
    import httpie.plugins.formatter.json
    import httpie.plugins.formatter.pretty
    import httpie.plugins.formatter.table
    import httpie.plugins.formatter.utils
    import httpie.plugins.formatter.verbose
    import httpie.plugins.formatter.format
    import httpie.plugins.formatter.headers
    import httpie.plugins.formatter.stream
    import httpie.plugins.formatter.colors
    import httpie.plugins.formatter.colors
    import httpie.plugins.formatter.colors
    import httpie.plugins.formatter.colors
    import httpie.plugins.formatter.colors
    import httpie.plugins.formatter.colors
   

# Generated at 2022-06-17 20:30:47.030995
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:30:53.032360
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import SyntaxHighlightPlugin
    from httpie.plugins.builtin import UnicodeDisplayPlugin
    from httpie.plugins.builtin import VerboseFormatterPlugin
    from httpie.plugins.builtin import WindowsConsoleWorkaroundPlugin
    from httpie.plugins.builtin import default_options
    from httpie.plugins.builtin import default_plugins
    from httpie.plugins.manager import PluginManager
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.output.streams import get_output_streams

# Generated at 2022-06-17 20:31:19.723400
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    env.style = 'solarized'
    formatter = ColorFormatter(env)
    assert formatter.formatter.style.styles[pygments.token.Keyword] == '#5f8700'

# Generated at 2022-06-17 20:31:28.414386
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer_for_body
    from httpie.plugins.colors import get_

# Generated at 2022-06-17 20:31:38.337577
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import stream
    from httpie.plugins.builtin import syntax
    from httpie.plugins.builtin import traceback
    from httpie.plugins.builtin import verbose
    from httpie.plugins.builtin import warnings


# Generated at 2022-06-17 20:31:44.906069
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import DEFAULT_STYLE
   

# Generated at 2022-06-17 20:31:59.404202
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:11.922236
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = True
    env.style = 'auto'
    env.colors = 256
    formatter = ColorFormatter(env)
    assert formatter.enabled == True
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False
    assert formatter.get_style_class('solarized') == Solarized256Style
    assert formatter.get_style_class('auto') == Solarized256Style
    assert formatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')


# Generated at 2022-06-17 20:32:23.016864
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:32:30.020013
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert color_formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert color_formatter.formatter.style.__class__.__name__ == 'Solarized256Style'

# Generated at 2022-06-17 20:32:37.179552
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert formatter.formatter.style.__class__.__name__ == 'Solarized256Style'
    assert formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'
    assert formatter.explicit_json == False

# Generated at 2022-06-17 20:32:45.317309
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.output.streams import ColorizedStdoutStream
    from httpie.output.streams import ColorizedStderrStream
    from httpie.output.streams import ColorizedStdinStream
    from httpie.output.streams import ColorizedStdinfoStream
    from httpie.output.streams import ColorizedBinaryStdoutStream
    from httpie.output.streams import ColorizedBinaryStderrStream
    from httpie.output.streams import ColorizedBinaryStdinStream
    from httpie.output.streams import ColorizedBinaryStdinfoStream
    from httpie.output.streams import ColorizedBinaryStdwarnStream
    from httpie.output.streams import ColorizedBinaryStdlog

# Generated at 2022-06-17 20:33:45.709476
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import get_lexer
    from httpie.plugins.colors import DEFAULT_STYLE
    from httpie.plugins.colors import AVAILABLE_STYLES
    from httpie.plugins.colors import AUTO_STYLE
    from httpie.plugins.colors import SOLARIZED_STYLE
    from httpie.plugins.colors import Solarized256Style
    from httpie.plugins.colors import SimplifiedHTTPLexer
    from httpie.plugins.colors import TerminalFormatter
    from httpie.plugins.colors import Terminal256Formatter

# Generated at 2022-06-17 20:33:51.694813
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    assert color_formatter.formatter.style == Solarized256Style

# Generated at 2022-06-17 20:34:01.170212
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme='solarized')

# Generated at 2022-06-17 20:34:12.102559
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-17 20:34:21.641841
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)

# Generated at 2022-06-17 20:34:23.550053
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-17 20:34:32.401906
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.output.streams import ColorizedStdoutStream

    env = Environment(
        stdout=ColorizedStdoutStream(),
        colors=256,
        stdin=None,
        stdin_isatty=False,
        output_options=None,
        output_file=None,
        options=None,
        config=None,
        plugins=FormatterPluginManager(),
        env=None,
        is_windows=False,
        stdout_isatty=True,
        output_encoding='utf8',
        stdin_encoding='utf8',
        output_file_encoding=None,
        stdout_raw=False,
    )

# Generated at 2022-06-17 20:34:42.472580
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env)
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}') == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}') != pygments.lexers.get_lexer_by_name('text')
    assert color_formatter.get_lexer_for_body('application/json', '{"a":1}') != pygments.lexers.get_lexer_by_name('html')
    assert color_formatter.get_lexer_for_