

# Generated at 2022-06-25 18:39:07.550644
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    if __name__ == '__main__':
        test_case_0()

# vim: set tabstop=4 softtabstop=4 expandtab :

# Generated at 2022-06-25 18:39:10.832581
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    env = Environment('', '')
    color_formatter_0 = ColorFormatter(env, True)
    color_formatter_0 = ColorFormatter(env, False)
    color_formatter_0 = ColorFormatter(env, not True)


# Generated at 2022-06-25 18:39:22.641561
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    simplified_h_t_t_p_lexer_1 = SimplifiedHTTPLexer()
    terminal_256_formatter_1 = Terminal256Formatter(style=Solarized256Style)
    color_formatter_0 = ColorFormatter(env=Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)
    color_formatter_1 = ColorFormatter(env=Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)
    color_formatter_2 = ColorFormatter(env=Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)
    color_formatter_1.http_lexer = simplified_h_t_t_p_lexer_1
    color_formatter_1.formatter = terminal_256_formatter_

# Generated at 2022-06-25 18:39:24.819471
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplifiedHTTPLexer_constructor = SimplifiedHTTPLexer()
    return simplifiedHTTPLexer_constructor


# Generated at 2022-06-25 18:39:31.410712
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Test with both httpie.cli.Environment's color mode and
    # the explicit --color argument.
    for color_arg in (True, False):
        env = Environment(
            colors=256,
            stdin=None,
            stdout=None,
            stderr=None,
            stdout_isatty=True,
            stdin_isatty=False,
            color=color_arg,
        )
        formatter = ColorFormatter(
            env=env,
            explicit_json=False,
            color_scheme=DEFAULT_STYLE,
            **{}
        )

        assert formatter.get_lexer_for_body(mime="text/plain", body="") is None

# Generated at 2022-06-25 18:39:37.245404
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    color_formatter_0 = ColorFormatter(None)
    color_formatter_0.formatter = TerminalFormatter()
    color_formatter_0.http_lexer = simplified_h_t_t_p_lexer_0
    str_0 = 'OK'
    str_1 = 'HTTP/1.1 200 OK'
    str_2 = 'HTTP/1.1 200 OK'
    str_3 = 'HTTP/1.1 200 OK'
    str_4 = 'HTTP/1.1 200 OK'
    str_5 = 'HTTP/1.1 200 OK'
    str_6 = 'HTTP/1.1 200 OK'
    str_7 = 'HTTP/1.1 200 OK'
   

# Generated at 2022-06-25 18:39:40.798118
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()

    color_formatter = ColorFormatter(env)

    mime = 'application/json'
    body = '{"foo": 1, "bar": "baz"}'

    result = color_formatter.format_body(body, mime)

    assert result == body


# Generated at 2022-06-25 18:39:43.115309
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter_0 = ColorFormatter(Environment({}))
    color_formatter_0.format_body(str(), str())


# Generated at 2022-06-25 18:39:47.564056
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    ColorFormatter(env=env, explicit_json=explicit_json, color_scheme=color_scheme)


# Generated at 2022-06-25 18:39:49.333323
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplifiedHTTPLexer=SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:39:59.989408
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter_0 = ColorFormatter(None)
    assert color_formatter_0.format_headers("") == ''


# Generated at 2022-06-25 18:40:04.580606
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter_0 = ColorFormatter({})
    color_formatter_0.format_headers('GET /get HTTP/1.1')
    color_formatter_0.format_headers('HTTP/1.1 200 OK')
    color_formatter_0.format_headers('Accept')


# Generated at 2022-06-25 18:40:07.659814
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter_0 = ColorFormatter(
        env = Environment(),
        explicit_json = False,
        color_scheme = DEFAULT_STYLE
    )

test_case_0()
test_ColorFormatter()

# Generated at 2022-06-25 18:40:14.312456
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    assert 'HTTP' == simplified_h_t_t_p_lexer_0.name
    assert ['http'] == simplified_h_t_t_p_lexer_0.aliases
    assert '*.http' == simplified_h_t_t_p_lexer_0.filenames
    assert "([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)" == simplified_h_t_t_p_lexer_0.tokens['root'][0]
    assert '(HTTP)(/)(\d+\.\d+)( +)(\d{3})( +)(.+)' == simplified_h_t_t_p_lexer_0.t

# Generated at 2022-06-25 18:40:18.905108
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    simplified_h_t_t_p_lexer_0.name
    assert simplified_h_t_t_p_lexer_0.name == 'HTTP'


# Generated at 2022-06-25 18:40:23.693189
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    test_env = Environment(
        colors=256
    )
    test_formatter = ColorFormatter(
        env=test_env,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
        **{}
    )


# Generated at 2022-06-25 18:40:25.550040
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:40:31.194312
# Unit test for function get_lexer
def test_get_lexer():
    from httpie.compat import urlopen
    from httpie.plugins import FormatterPlugin
    class FakeEnvironment():
        def __init__(self):
            self.colors = 256
    env = FakeEnvironment()
    formatter = FormatterPlugin(env, explicit_json=True)
    response = urlopen('https://cdn.httpie.org/')
    lexer = formatter.get_lexer_for_body(mime=response.headers['Content-Type'], body=response.read().decode('utf-8'))
    assert lexer is not None

if __name__ == '__main__':
    test_case_0()
    test_get_lexer()

# Generated at 2022-06-25 18:40:35.150439
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # TODO: mock color scheme
    # TODO: mock style class
    # color_scheme_0 = ''
    # style_class_0 = ColorFormatter.get_style_class(color_scheme_0)
    pass

# Generated at 2022-06-25 18:40:46.252777
# Unit test for function get_lexer
def test_get_lexer():
    # Case 0
    
    mime = 'application/json'
    
    explicit_json = False
    
    body = '{'
    
    ret_val_0 = get_lexer(mime, explicit_json, body)
    
    ret_val_0_name = ret_val_0.__class__.__name__
    assert 'JsonLexer' == ret_val_0_name
    
    # Case 1
    
    mime = 'application/javascript'
    
    explicit_json = False
    
    body = '{'
    
    ret_val_1 = get_lexer(mime, explicit_json, body)
    
    ret_val_1_name = ret_val_1.__class__.__name__
    assert 'JavascriptLexer' == ret_val

# Generated at 2022-06-25 18:40:58.248613
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    return


# Generated at 2022-06-25 18:41:09.019167
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplifiedHTTPLexer_0 = SimplifiedHTTPLexer()
    # TODO: Add tests for other properties of class SimplifiedHTTPLexer
    assert simplifiedHTTPLexer_0.name == 'HTTP'
    assert simplifiedHTTPLexer_0.aliases == ['http']
    assert simplifiedHTTPLexer_0.filenames == ['*.http']

# Generated at 2022-06-25 18:41:13.583879
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    result = color_formatter_0.format_headers("kECbqyKXFm")
    assert result == "kECbqyKXFm"


# Generated at 2022-06-25 18:41:17.296885
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.get_style_class("solarized") == Solarized256Style


# Generated at 2022-06-25 18:41:22.477435
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    str_0 = ''
    str_1 = ''
    str_2 = color_formatter_0.format_body(str_0, str_1)
    assert str_2 is not None


# Generated at 2022-06-25 18:41:28.238083
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime_0 = None
    body_0 = None
    color_formatter_0.get_lexer_for_body(mime_0, body_0)


# Generated at 2022-06-25 18:41:39.371480
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    str0 = 'svg+xml'
    str1 = 'svg'
    str2 = 'json'
    str3 = 'xml'
    str4 = 'application/svg+xml'
    str5 = 'application/json'
    str6 = 'application/xml'
    assert color_formatter_0.get_lexer_for_body(str4, str0) is None
    assert color_formatter_0.get_lexer_for_body(str5, str2) is None
    assert color_formatter_0.get_lexer_for_body(str6, str3) is None


# Generated at 2022-06-25 18:41:43.928380
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime = ''
    body = ''
    result = color_formatter_0.format_body(body, mime)
    assert result == '\n'


# Generated at 2022-06-25 18:41:49.557550
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    header_0 = 'foo'
    header_1 = 'bar'
    header_2 = 'baz'
    headers_0 = 'HTTP/1.1 200 OK\n{0}: {1}\n{2}: {3}\n\n'.format(header_0, header_1, header_2, header_2)
    result_0 = color_formatter_0.format_headers(headers_0)
    assert result_0 is not None


# Generated at 2022-06-25 18:41:51.723446
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Test for method __init__

    test_case_0()

# Generated at 2022-06-25 18:42:10.361057
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Arrange
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime = 'text/foobar'
    body = ''
    
    # Act
    result = color_formatter_0.get_lexer_for_body(mime, body)
    # Assert
    assert result is None


# Generated at 2022-06-25 18:42:14.419847
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = 'asdf'
    pygments_style_1 = color_formatter_0.get_style_class(color_scheme_0)
    assert pygments_style_1 == Solarized256Style



# Generated at 2022-06-25 18:42:21.922182
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)
    mime_0 = "text/plain"
    body_0 = ""
    ColorFormatterTest_format_body_out_1 = color_formatter_1.format_body(mime_0, body_0)
    mime_1 = "application/json"
    body_1 = """{
    ""foo"": ""bar"",
    ""baz"": ""qux""
}"""
    ColorFormatterTest_format_body_out_2 = color_formatter_1.format_body(mime_1, body_1)
    color_formatter_1.explicit_json = True
    ColorFormatterTest_format_body_out_3 = color_formatter_1.format

# Generated at 2022-06-25 18:42:26.036306
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    # SimplifiedHTTPLexer: constructor
    # Issue #270 - ensure that the "root" token name exists
    assert ("root" in color_formatter_0.http_lexer.tokens) == True


# Generated at 2022-06-25 18:42:29.197309
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    result = ColorFormatter.get_style_class(color_scheme)
    assert Solarized256Style == result


# Generated at 2022-06-25 18:42:35.681749
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme = ""
    try:
        var_0 = color_formatter_0.get_style_class(color_scheme)
    except:
        pass

    try:
        var_0 = color_formatter_0.get_style_class(color_scheme)
    except:
        pass
    try:
        var_0 = color_formatter_0.get_style_class(color_scheme)
    except:
        pass
    try:
        var_0 = color_formatter_0.get_style_class(color_scheme)
    except:
        pass


# Generated at 2022-06-25 18:42:38.445056
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():


    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)



# Generated at 2022-06-25 18:42:49.047995
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Python 2/3 compatibility
    try:
        from StringIO import StringIO as BytesIO
    except ImportError:
        from io import BytesIO

    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin

    environment_0 = Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = 'headers_0'
    # Test with types
    output_file_0 = BytesIO()
    color_formatter_0.output_file = output_file_0
    color_formatter_0.format_headers(headers_0)
    expected_output = None
    if not is_windows:
        expected_output = b'headers_0\n'
    assert output_file_0.getvalue()

# Generated at 2022-06-25 18:42:59.377442
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = "fruity"
    color_scheme_1 = "fruity"
    color_scheme_2 = "fruity"
    assert (
        isinstance(
            color_formatter_0.get_style_class(color_scheme_0),
            pygments.styles.FruityStyle
        )
    )
    assert (
        isinstance(
            color_formatter_0.get_style_class(color_scheme_1),
            pygments.styles.FruityStyle
        )
    )

# Generated at 2022-06-25 18:43:01.650113
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():

    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.format_headers(headers)


# Generated at 2022-06-25 18:43:50.190258
# Unit test for function get_lexer
def test_get_lexer():
    # Environment
    environment_0 = module_0.Environment()
    assert environment_0.colors == 256

    # Initialise a ColorFormatter
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.explicit_json == False
    assert color_formatter_0.formatter != None
    assert color_formatter_0.http_lexer != None

    # Test get_lexer
    assert color_formatter_0.get_lexer_for_body('application/xml', '<foo></foo>') != None
    assert color_formatter_0.get_lexer_for_body('application/xml', '<foo></bar>') != None

# Generated at 2022-06-25 18:43:53.751421
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(None) == None
    assert get_lexer(None, None) == None
    assert get_lexer(None, None, None) == None


# Generated at 2022-06-25 18:44:00.390292
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_0)
    assert color_formatter_1.formatter is not None
    assert color_formatter_1.http_lexer is not None
    assert color_formatter_1.explicit_json is False
    assert color_formatter_1.formatter is not None
    assert color_formatter_1.http_lexer is not None
    assert color_formatter_1.explicit_json is False
    environment_1 = module_0.Environment()
    color_formatter_2 = ColorFormatter(environment_1)
    assert color_formatter_2.formatter is not None
    assert color_formatter_2.http_lexer is not None
    assert color_formatter_2.explicit_json

# Generated at 2022-06-25 18:44:04.902895
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.formatter is not None

if (__name__ == '__main__'):
    test_case_0()

# Generated at 2022-06-25 18:44:07.237356
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)


# Generated at 2022-06-25 18:44:10.020680
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

# Generated at 2022-06-25 18:44:19.121071
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():

    mock_parser_0 = mock.Mock()
    mock_parser_0.__contains__.return_value = False
    mock_parser_0.__getitem__.return_value = False
    mock_parser_0.__setitem__.return_value = 0
    mock_parser_0.add_argument.return_value = 0
    mock_parser_0.parse_args.return_value = 0
    mock_parser_0.set_defaults.return_value = 0
    mock_kwargs_0 = {u'option_strings': u'hi', u'dest': u'hi', u'default': u'hi', u'help': u'hi', u'action': u'store_true'}
    mock_kwargs_1 = {}

# Generated at 2022-06-25 18:44:21.477872
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)


# Generated at 2022-06-25 18:44:30.198654
# Unit test for function get_lexer
def test_get_lexer():
    # Setup
    mime = "application/json"
    explicit_json = True
    body = "{ \"glossary\": { \"title\": \"example glossary\", \"GlossDiv\": { \"title\": \"S\", \"GlossList\": { \"GlossEntry\": { \"ID\": \"SGML\", \"SortAs\": \"SGML\", \"GlossTerm\": \"Standard Generalized Markup Language\", \"Acronym\": \"SGML\", \"Abbrev\": \"ISO 8879:1986\", \"GlossDef\": { \"para\": \"A meta-markup language, used to create markup languages such as DocBook.\", \"GlossSeeAlso\": [\"GML\", \"XML\"] } } } } }"


# Generated at 2022-06-25 18:44:32.491816
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)


# Generated at 2022-06-25 18:45:30.599132
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

import httpie.context as module_0


# Generated at 2022-06-25 18:45:40.177890
# Unit test for function get_lexer
def test_get_lexer():
    mime = "application/json"
    explicit_json = False
    body = ""
    assert get_lexer(mime, explicit_json, body) is None
    
    mime = "test"
    explicit_json = False
    body = ""
    assert get_lexer(mime, explicit_json, body) is None
    
    mime = "application/json+test"
    explicit_json = False
    body = ""
    assert get_lexer(mime, explicit_json, body) is None
    
    mime = "html"
    explicit_json = False
    body = ""
    assert get_lexer(mime, explicit_json, body) is None
    
    mime = "application/json+test"
    explicit_json = False
    body = "test"
    assert get

# Generated at 2022-06-25 18:45:44.236812
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter = ColorFormatter(environment_0)
    global environment_0
    global color_formatter_0
color_formatter_0 = None
environment_0 = None

# Generated at 2022-06-25 18:45:53.375879
# Unit test for function get_lexer
def test_get_lexer():
    # Check that a Content-Type with a charset returns the right lexer.
    assert 'JSON' == get_lexer('application/json; charset=UTF-8').name
    # Check that a Content-Type without a charset returns the right lexer.
    assert 'JSON' == get_lexer('application/json').name
    # Check that 'subtype' is taken into account when finding the right lexer.
    assert 'JSON' == get_lexer('application/ld+json').name
    # Check that 'subtype+suffix' is taken into account when finding the right lexer.
    assert 'JSON' == get_lexer('application/json-p').name
    # Check that 'type' is taken into account when finding the right lexer.
    assert 'JSON' == get_lexer('foo/json').name
    # Check

# Generated at 2022-06-25 18:45:56.667089
# Unit test for function get_lexer
def test_get_lexer():
    mime_0 = str()
    explicit_json_0 = bool()
    body_0 = str()
    result = get_lexer(mime_0, explicit_json=explicit_json_0, body=body_0)


# Generated at 2022-06-25 18:45:58.232909
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # simple test
    # assertion(s)
    assert(test_case_0())


test_ColorFormatter()

# Generated at 2022-06-25 18:46:00.496805
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

# Generated at 2022-06-25 18:46:11.211592
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_1 = 'headers'
    color_formatter_0.format_headers(headers_1)
    body_2 = 'body'
    mime_2 = 'mime'
    color_formatter_0.format_body(body_2, mime_2)
    color_scheme_3 = 'color_scheme'
    color_formatter_0.get_style_class(color_scheme_3)
    mime_4 = 'mime'
    body_4 = 'body'
    get_lexer(mime_4, explicit_json=False, body=body_4)
    # More tests for color_scheme='auto'

# Generated at 2022-06-25 18:46:13.173886
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer(mime="application/vnd.api+json", explicit_json=False, body="")
    assert(True)

# Generated at 2022-06-25 18:46:16.563877
# Unit test for function get_lexer
def test_get_lexer():
    mime_options_0 = ['foo/bar']
    body_options_0 = ''
    explicit_json_options_0 = False
    output = get_lexer(mime_options_0, explicit_json_options_0, body_options_0)
    assert output == None