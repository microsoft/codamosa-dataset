

# Generated at 2022-06-25 18:39:21.127392
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie import ExitStatus
    input_headers = """HTTP/1.1 200 OK
Cache-Control: private
Content-Type: text/html; charset=utf-8
Server: Microsoft-IIS/8.5
x-aspnet-version: 4.0.30319
x-powered-by: ASP.NET
Date: Mon, 01 Jan 2018 16:55:49 GMT
Content-Length: 47674
"""

# Generated at 2022-06-25 18:39:26.489526
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Test with json
    assert ColorFormatter.format_body(
        '{fixture_name: "post"}',
        'application/json'
    ) == '{fixture_name: "post"}'

    # Test with html
    assert ColorFormatter.format_body(
        '<title>This is a title</title>',
        'text/html'
    ) == '<title>This is a title</title>'



# Generated at 2022-06-25 18:39:34.720743
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():  # Assert #0
    """Test format_headers.

    This method tests the 'format_headers' method of the
    ColorFormatter class.

    """
    test_env = Environment(colors=0)
    test_color_formatter = ColorFormatter(test_env, explicit_json=False, color_scheme=DEFAULT_STYLE)

    # Test #0
    test_headers = '''\
Accept-Encoding: identity
Host: httpbin.org
User-Agent: HTTPie/1.0.0
\
'''
    assert test_color_formatter.format_headers(test_headers) == '''\
Accept-Encoding: identity
Host: httpbin.org
User-Agent: HTTPie/1.0.0
\
'''


# Generated at 2022-06-25 18:39:42.259972
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert True
    # Test 1
    color_formatter_1 = ColorFormatter(Environment())
    body_1 = ''
    mime_1 = 'application/json'
    assert color_formatter_1.format_body(body_1, mime_1) == ''
    # Test 2
    color_formatter_2 = ColorFormatter(Environment())
    body_2 = ''
    mime_2 = 'application/json'
    assert color_formatter_2.format_body(body_2, mime_2) == ''
    # Test 3
    color_formatter_3 = ColorFormatter(Environment())
    body_3 = ''
    mime_3 = 'application/json'
    assert color_formatter_3.format_body(body_3, mime_3) == ''

# Unit

# Generated at 2022-06-25 18:39:53.289487
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    print('Test start')
    color_formatter_0 = ColorFormatter(Environment())
    color_formatter_0.format_body('', '')
    color_formatter_0.format_body('', '')
    color_formatter_0.format_body('', '')
    color_formatter_0.format_body('', '')
    color_formatter_0.format_body('', '')
    color_formatter_0.format_body('', '')
    color_formatter_0.format_body('', '')
    color_formatter_0.format_body('', '')
    color_formatter_0.format_body('', '')
    color_formatter_0.format_body('', '')
    color_formatter_0.format_body('', '')
   

# Generated at 2022-06-25 18:40:02.544465
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    env = Environment()
    color_formatter_0 = ColorFormatter(env, )
    output_0 = color_formatter_0.format_headers('') # expected output: ''
    output_1 = color_formatter_0.format_body('', '') # expected output: ''
    color_formatter_1 = ColorFormatter(env, )
    output_2 = color_formatter_1.format_headers('') # expected output: ''
    output_3 = color_formatter_1.format_body('', '') # expected output: ''
    assert output_0 == ''
    assert output_1 == ''
    assert output_2 == ''
    assert output_3 == ''


# Generated at 2022-06-25 18:40:07.496461
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    color_formatter = ColorFormatter(
        env, explicit_json=explicit_json, color_scheme=color_scheme, **kwargs
    )
    headers = ''
    # Add assertion here
    # assert color_formatter.format_headers(headers) ==


# Generated at 2022-06-25 18:40:14.958379
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter_0 = ColorFormatter()

# Generated at 2022-06-25 18:40:26.533971
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    c = ColorFormatter(Environment())
    print('get_lexer_for_body...')
    assert c.get_lexer_for_body('unknown', '') is None
    assert c.get_lexer_for_body('application/json', '{"a":1') == \
        pygments.lexers.get_lexer_by_name('json')
    assert c.get_lexer_for_body('application/unknown+json', '{}') is None
    assert c.get_lexer_for_body('application/javascript', '') == \
        pygments.lexers.get_lexer_by_name('javascript')
    assert c.get_lexer_for_body('application/unknown+javascript', '') is None
    assert c.get_lexer_for_body('application/json', '')

# Generated at 2022-06-25 18:40:35.305638
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer = SimplifiedHTTPLexer()
    assert simplified_h_t_t_p_lexer.name == 'HTTP'
    assert simplified_h_t_t_p_lexer.aliases == ['http']
    assert simplified_h_t_t_p_lexer.filenames == ['*.http']

# Generated at 2022-06-25 18:40:49.353655
# Unit test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-25 18:40:53.034334
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    e = Environment()
    e.colors = 256
    c_f = ColorFormatter(
        env=e,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
        **{}
    )
    body = c_f.format_body(body='asd', mime='application/json')


# Generated at 2022-06-25 18:40:55.716362
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter_0 = ColorFormatter(
        None
    )


# Generated at 2022-06-25 18:41:03.839443
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter_0 = ColorFormatter(
        Environment({}),
        False,
        'auto'
    )
    string_var_0 = color_formatter_0.get_lexer_for_body(
        'image/jpeg',
        'iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg=='
    )


# Generated at 2022-06-25 18:41:06.731565
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert(isinstance(SimplifiedHTTPLexer(), pygments.lexer.Lexer))
    assert(isinstance(SimplifiedHTTPLexer(), SimplifiedHTTPLexer))


# Generated at 2022-06-25 18:41:09.173892
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter_0 = ColorFormatter(env=Environment(colors=True,),)
    assert color_formatter_0 != None

# Generated at 2022-06-25 18:41:14.048583
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env_0 = Environment()
    env_0.colors = 256
    test_case_0 = ColorFormatter(env=env_0, explicit_json=False, color_scheme='solarized256')
    assert test_case_0.get_style_class('solarized256') is Solarized256Style


# Generated at 2022-06-25 18:41:24.667684
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    color_formatter_0 = ColorFormatter(None, False, DEFAULT_STYLE)
    color_formatter_0.http_lexer = simplified_h_t_t_p_lexer_0
    pygments_highlight_0 = pygments.highlight
    def pygments_highlight_mock(code, lexer, formatter):
        if (code == "X-Foo: 1234\n"):
            return "pygments_highlight_0"
    pygments_highlight_0 = pygments.highlight = pygments_highlight_mock
    assert color_formatter_0.format_headers("X-Foo: 1234\n") == "pygments_highlight_0"

# Generated at 2022-06-25 18:41:36.566690
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
  # Create an instance of Environment
  environment_0 = Environment()
  # Create an instance of ColorFormatter
  color_formatter_0 = ColorFormatter(env=environment_0)
  body_0 = ''
  mime_0 = ''
  try:
    # Invoke method format_body with arguments body_0, mime_0
    assert color_formatter_0.format_body(body_0, mime_0) is None
  except TypeError as raised_exception_0:
    # The expected TypeError exception was raised
    assert str(raised_exception_0) == "format() argument 2 must be str, not None"
  else:
    raise AssertionError("No exception was raised")

# Generated at 2022-06-25 18:41:38.060614
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    json.dumps(test_ColorFormatter_format_headers())

# Generated at 2022-06-25 18:41:45.980276
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from pkg_resources import load_entry_point
    env = Environment(colors=True)
    color_formatter = ColorFormatter(env)

# Generated at 2022-06-25 18:41:55.478671
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # default
    assert ColorFormatter is not None
    # default
    assert ColorFormatter(Environment()).enabled is True
    # default
    assert ColorFormatter(Environment(colors=False)).enabled is False
    # default
    assert ColorFormatter(Environment(colors=256)).enabled is True
    # default
    assert ColorFormatter(Environment(colors=256)).formatter.__class__.__name__ == 'Terminal256Formatter'
    assert ColorFormatter(Environment(colors=256)).http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'


# Generated at 2022-06-25 18:42:06.264558
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    c1 = ColorFormatter(
        env,
        explicit_json,
        color_scheme
    )
    c2 = ColorFormatter(
        env
    )
    assert c1.enabled != c2.enabled
    assert c1.formatter != None and c2.formatter != None
    assert c1.http_lexer != None and c2.http_lexer != None
    assert c1.formatter != c2.formatter
    assert c1.http_lexer != c2.http_lexer
    assert c1.get_style_class(color_scheme).__name__ == "Solarized256Style"


# Generated at 2022-06-25 18:42:06.800366
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    pass

# Generated at 2022-06-25 18:42:09.569939
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter_0 = ColorFormatter(
        env='env_0',
        explicit_json='explicit_json_0',
        color_scheme=DEFAULT_STYLE
    )


# Generated at 2022-06-25 18:42:12.437385
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers = ''
    color_formatter_0 = ColorFormatter(env=Environment(colors=True,
                                                        default_options=DefaultOptions()))
    color_formatter_0.format_headers(headers=headers)


# Generated at 2022-06-25 18:42:15.647936
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter_0 = ColorFormatter(
        env = {'colors':256},
        explicit_json = False,
        color_scheme = 'fruity',
    )
    color_formatter_0.format_headers("")


# Generated at 2022-06-25 18:42:22.414691
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Test case with style = 'default'
    style = 'default' 
    color_formatter = ColorFormatter(None)
    assert color_formatter.get_style_class(style) == Solarized256Style

    # Test case with style = 'solarized256'
    style = 'solarized256' 
    color_formatter = ColorFormatter(None)
    assert color_formatter.get_style_class(style) == Solarized256Style

    # Test case with style = 'solarized' 
    style = 'solarized'
    color_formatter = ColorFormatter(None)
    assert color_formatter.get_style_class(style) == Solarized256Style

    # Test case with style = 'auto'
    style = 'auto'
    color_formatter = ColorFormatter(None)

# Generated at 2022-06-25 18:42:25.086670
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    with Environment() as env:
        colorFormatter = ColorFormatter(env)
        assert colorFormatter.explicit_json ==  False
        assert colorFormatter.color_scheme == 'auto'


# Generated at 2022-06-25 18:42:26.875951
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:42:37.836221
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer()
    # Return True if the MTIME of the specified source file is newer than
    # the MTIME of the destination, or if the destination does not exist.
    # Return False otherwise.
    # Returns False for remote files.
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 18:42:48.545535
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from httpie.formatters import solarized_0
    from httpie.plugins import colors_1
    # create a instance of class SimplifiedHTTPLexer
    class_0 = solarized_0.SimplifiedHTTPLexer()
    class_0 = colors_1.SimplifiedHTTPLexer()
    # Test fields
    assert(class_0.name == 'HTTP')
    assert(class_0.aliases == ['http'])
    assert(class_0.filenames == ['*.http'])

# Generated at 2022-06-25 18:42:56.179412
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.formatter.format_unencoded
    color_formatter_0.formatter.format_unencoded
    color_formatter_0.formatter.format_unencoded
    color_formatter_0.formatter.format_unencoded
    color_formatter_0.formatter.format_unencoded
    color_formatter_0.formatter.format_unencoded


# Generated at 2022-06-25 18:43:04.410077
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = "nN/%c=\'p63:E\\B*\\^]|2<+$D`>DK@RnN/%c=\'p63:E\\B*\\^]|2<+$D`>DK@R"
    mime_0 = "application/json"


# Generated at 2022-06-25 18:43:09.931733
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = 'fruity'
    try:
        color_formatter_0.get_style_class(color_scheme_0)
    except pygments.util.ClassNotFound:
        assert True
    else:
        assert False


# Generated at 2022-06-25 18:43:10.591370
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    pass

# Generated at 2022-06-25 18:43:20.711355
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    test_body_0 = """{\n  "phone": "1-(770)974-9491",\n  "address": "129 Riverview Drive",\n  "friends": [\n    {\n      "id": 0,\n      "name": "Eve Nichols"\n    },\n    {\n      "id": 1,\n      "name": "Rhodes Mccall"\n    },\n    {\n      "id": 2,\n      "name": "Webster Hodge"\n    }\n  ],\n  "greeting": "Hello, Morgan! You have 6 unread messages.",\n  "favoriteFruit": "banana"\n}"""
    body_

# Generated at 2022-06-25 18:43:23.648819
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.get_style_class('solarized256') == Solarized256Style


# Generated at 2022-06-25 18:43:30.133841
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime = 'text/plain'
    body = '{'
    lexer = color_formatter_0.get_lexer_for_body(mime,body)
    assert lexer == pygments.lexers.get_lexer_by_name('json')


# Generated at 2022-06-25 18:43:32.207349
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)


# Generated at 2022-06-25 18:43:45.798261
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

    body_0 = "{"
    mime_0 = "application/json"
    assert(color_formatter_0.format_body(body_0, mime_0))



# Generated at 2022-06-25 18:43:49.974252
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime = "mime"
    body = "body"
    actual = color_formatter_0.get_lexer_for_body(mime, body)
    assert actual is None

# Generated at 2022-06-25 18:43:57.201540
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n"
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.format_body("foo", "text/plain") == "foo"
    assert color_formatter_0.format_body("foo", "text/html") == "foo"
    assert color_formatter_0.format_body("foo", "application/json") == "foo"


# Generated at 2022-06-25 18:44:03.380334
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

    color_scheme_0 = DEFAULT_STYLE
    t_0 = color_formatter_0.get_style_class(color_scheme_0)


# Generated at 2022-06-25 18:44:05.110735
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

# Generated at 2022-06-25 18:44:10.585821
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers = ""
    mime = ""
    body = ""
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.format_headers(headers) == ""
    
        

# Generated at 2022-06-25 18:44:14.173209
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    string_0 = 'solarized256'
    assert color_formatter_0.get_style_class(string_0) == Solarized256Style


# Generated at 2022-06-25 18:44:19.765307
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    string_test_0 = {'User-Agent': 'python-requests/2.18.4', 'Content-Length': '0', 'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*', 'Connection': 'keep-alive'}
    string_test_0 = string_test_0
    assert color_formatter_0.format_headers(string_test_0)


# Generated at 2022-06-25 18:44:29.052363
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Given
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(style=Solarized256Style)

    # When
    headers_code = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'
    headers = pygments.highlight(code=headers_code, lexer=http_lexer, formatter=formatter).strip()

    # Then

# Generated at 2022-06-25 18:44:34.813705
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime_string_0 = 'string'
    body_string_0 = 'string'

    # Call get_lexer_for_body of ColorFormatter.
    color_formatter_0.get_lexer_for_body(mime_string_0, body_string_0)


# Generated at 2022-06-25 18:44:54.383926
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    result_0 = color_formatter_0.get_style_class('solarized')
    assert result_0 == Solarized256Style


# Generated at 2022-06-25 18:45:05.362388
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    _SimplifiedHTTPLexer = SimplifiedHTTPLexer()
    assert _SimplifiedHTTPLexer.name == 'HTTP'
    assert _SimplifiedHTTPLexer.aliases == ['http']
    assert _SimplifiedHTTPLexer.filenames == ['*.http']

# Generated at 2022-06-25 18:45:09.688944
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)
    default_body_0 = '{}'
    default_mime_0 = 'application/json'
    # Exception thrown, because the input is not correct
    try:
        assert color_formatter_1.format_body(default_body_0, default_mime_0)
    except AssertionError:
        pass


# Generated at 2022-06-25 18:45:14.201055
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    print('\n=======================================================')
    print('UNIT TEST - test_SimplifiedHTTPLexer')
    print('=======================================================')

    simplified_http_lexer = SimplifiedHTTPLexer()
    assert simplified_http_lexer is not None, "The constructor of class SimplifiedHTTPLexer is changed!"


# Generated at 2022-06-25 18:45:22.028498
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    str_0 = 'text/plain'
    str_1 = ''
    if color_formatter_0.get_lexer_for_body(str_0, str_1):
        raise Exception(
            'AssertionError: expected none, got %r' % (color_formatter_0.get_lexer_for_body(
                str_0, str_1),))

test_case_0()
test_ColorFormatter_get_lexer_for_body()

# Generated at 2022-06-25 18:45:25.723684
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment(colors=256)
    color_formatter_0 = ColorFormatter(environment_0)
# End of test suite for constructor of class ColorFormatter


# Generated at 2022-06-25 18:45:33.348381
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body = '{"a":[1,2,3], "b":{"c":"d"}}'
    mime = 'application/json'
    try:
        fmt_body = color_formatter_0.format_body(body=body, mime=mime)
    except NotImplementedError as exc:
        print(exc)


# Generated at 2022-06-25 18:45:36.056540
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

    # Test case 1:
    assert color_formatter_0.get_lexer_for_body('Content-Type', '') == None


# Generated at 2022-06-25 18:45:40.228306
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    explicit_json = False
    color_scheme = "auto"
    color_formatter_0 = ColorFormatter(environment_0, explicit_json, color_scheme)


# Test if constructor can handle certain arguments

# Generated at 2022-06-25 18:45:50.905873
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = ''
    headers_1 = color_formatter_0.format_headers(headers_0)  # expected_output: ''
    headers_0 = ''
    headers_1 = color_formatter_0.format_headers(headers_0)  # expected_output: ''
    headers_0 = ''
    headers_1 = color_formatter_0.format_headers(headers_0)  # expected_output: ''
    headers_0 = ''
    headers_1 = color_formatter_0.format_headers(headers_0)  # expected_output: ''
    headers_0 = ''
    headers_1 = color_formatter_0.format_headers(headers_0)  # expected

# Generated at 2022-06-25 18:46:33.116595
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

    # Fixture with body
    body_0 = '''\
{
    "foo": "bar"
}
'''

    # Fixture with unexpected json body
    body_1 = '''\
<html>
</html>
'''

    # Fixture with mime
    mime_0 = 'text/html'

    mime_1 = 'application/json'

    expected_0 = '''\
{
    "foo": "bar"
}
'''
    actual_0 = color_formatter_0.format_body(body_0, mime_0)


# Generated at 2022-06-25 18:46:41.487968
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.get_lexer_for_body("application/json", "") is not None
    assert color_formatter_0.get_lexer_for_body("application/json", "") is not None
    assert color_formatter_0.get_lexer_for_body("application/json", "") is not None
    assert color_formatter_0.get_lexer_for_body("application/json", "") is not None
    assert color_formatter_0.get_lexer_for_body("application/json", "") is not None
    assert color_formatter_0.get_lexer_for_body("application/json", "") is not None

# Generated at 2022-06-25 18:46:44.661439
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    str_0 = "0"
    str_1 = "1"
    str_2 = color_formatter_0.format_body(str_0, str_1)


# Generated at 2022-06-25 18:46:48.609517
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body = "body"
    mime = "mime"
    result = color_formatter_0.format_body(body,mime)
    assert type(result) is str


# Generated at 2022-06-25 18:46:53.710586
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body = "test_value"
    mime = "test_value"
    try:
        color_formatter_0.format_body(body, mime)
        test_failed()
    except ValueError:
        pass



# Generated at 2022-06-25 18:47:01.152582
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)
    mime_0 = 'text/html; charset=utf-8'
    body_0 = '<!doctype html><html><head></head></html>'
    assert color_formatter_1.format_body(body_0, mime_0) == '<!doctype html><html><head></head></html>'


if __name__ == '__main__':
    test_case_0()
    test_ColorFormatter_format_body()

# Generated at 2022-06-25 18:47:07.160938
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    # Assuming body is not empty,
    # Assuming mime is not empty,
    try:
        color_formatter_0.format_body(body, mime)
    except Exception as e:
        print(e)
        print(sys.exc_info()[0])
        raise AssertionError()
    # AssertionError if the returned str is empty



# Generated at 2022-06-25 18:47:11.058862
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime = "text/html"
    body = "{}"
    color_formatter_0.get_lexer_for_body(mime, body)




# Generated at 2022-06-25 18:47:14.094580
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    lexer_0 = color_formatter_0.get_lexer_for_body("application/json", "")

# Generated at 2022-06-25 18:47:15.493245
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class_0 = ColorFormatter.get_style_class('auto')
