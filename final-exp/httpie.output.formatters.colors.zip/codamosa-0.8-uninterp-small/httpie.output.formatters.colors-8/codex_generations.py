

# Generated at 2022-06-25 18:39:19.111579
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter = ColorFormatter(
        None, False, "default_style", **{'header': None, 'compact': False, 'verify': True, 'method': None, 'data': None})
    headers = ''
    mime = ''
    assert color_formatter.format_headers(headers)


# Generated at 2022-06-25 18:39:19.474953
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    pass

# Generated at 2022-06-25 18:39:24.614768
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter_0 = ColorFormatter(Environment(colors=256, debug=False,
        output_options={'stdout_isatty': True},
        stdin_isatty=True, stdout_isatty=True,
        stderr_isatty=True, stdin=None, stdout=None, stderr=None))

# Generated at 2022-06-25 18:39:31.317706
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    formatter = ColorFormatter(env)

    headers = "HTTP/1.1 200 OK\nContent-Type: text/html"

# Generated at 2022-06-25 18:39:37.051630
# Unit test for function get_lexer
def test_get_lexer():
    # Test 1
    mime = 'application/json'
    lexer = get_lexer(mime)
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    # Test 2
    mime = 'application/json'
    lexer = get_lexer(mime, explicit_json=False, body='{"a": 1}')
    assert lexer == pygments.lexers.get_lexer_by_name('json')
    # Test 3
    mime = 'application/json'
    lexer = get_lexer(mime, explicit_json=True, body='{"a": 1}')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-25 18:39:43.115326
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    cf = ColorFormatter(None, None)
    if cf.get_style_class(SOLARIZED_STYLE) == Solarized256Style:
        solarized256_style_1 = Solarized256Style()
        solarized256_style_2 = cf.get_style_class(SOLARIZED_STYLE)
        if  solarized256_style_1 == solarized256_style_2:
            return True
        else:
            return False
    else:
        return False


# Generated at 2022-06-25 18:39:45.635969
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(Environment(colors=True))
    assert color_formatter.format_body("<html>", "text/html")


# Generated at 2022-06-25 18:39:56.631461
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    json_body = """
{
  "firstName": "John",
  "lastName": "Smith",
  "isAlive": true,
  "age": 27,
  "address": {
    "streetAddress": "21 2nd Street",
    "city": "New York",
    "state": "NY",
    "postalCode": "10021-3100"
  },
  "phoneNumbers": [
    {
      "type": "home",
      "number": "212 555-1234"
    },
    {
      "type": "office",
      "number": "646 555-4567"
    }
  ],
  "children": [],
  "spouse": null
}
"""
    cf = ColorFormatter(Environment(), False)

# Generated at 2022-06-25 18:40:06.837230
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=False, stdin=None, stdout=None, stderr=None)
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    headers = '''GET / HTTP/1.1
Host: httpbin.org
User-Agent: HTTPie/1.0.0
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive'''

    cf = ColorFormatter(
        env=env,
        explicit_json=explicit_json,
        color_scheme=color_scheme
    )
    headers = cf.format_headers(headers)

    assert isinstance(headers, str)

# Generated at 2022-06-25 18:40:10.005506
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Init ColorFormatter object
    color_formatter = ColorFormatter(None, False, False)
    headers = "Content-Length: 10"
    headers_formatted = color_formatter.format_headers(headers)
    assert headers_formatted == "Content-Length: 10"

# Generated at 2022-06-25 18:40:25.216028
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    str_0 = '0-7p*}0lu^U'
    color_formatter = ColorFormatter(str_0)
    str_1 = '*hD3zv;Ls'
    optional_0 = color_formatter.format_headers(str_1)


# Generated at 2022-06-25 18:40:29.828159
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(color=3, colors=3,
                      style='solarized')
    explicit_json = True
    color_scheme = 'solarized'
    colorFormatter = ColorFormatter(env, explicit_json, color_scheme)
    assert colorFormatter.enabled is True
    assert colorFormatter.explicit_json is True
    assert colorFormatter.formatter is not None
    assert colorFormatter.http_lexer is not None


# Generated at 2022-06-25 18:40:35.649186
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = True
    color_scheme = DEFAULT_STYLE
    kwargs = {}

    test_0 = ColorFormatter(env, explicit_json, color_scheme, **kwargs)
    test_1 = ColorFormatter(env, explicit_json, color_scheme)
    test_2 = ColorFormatter(env, explicit_json)


# Generated at 2022-06-25 18:40:38.299599
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer_0 = SimplifiedHTTPLexer()
    assert isinstance(SimplifiedHTTPLexer(), SimplifiedHTTPLexer)


# Generated at 2022-06-25 18:40:42.958368
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    str_0 = 'Cigb8W+[&3q^]O'
    str_1 = '`OaI'
    optional_0 = ColorFormatter({}, False).get_lexer_for_body(str_0, str_1)


# Generated at 2022-06-25 18:40:44.425881
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    test_0 = SimplifiedHTTPLexer()



# Generated at 2022-06-25 18:40:52.761873
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import io
    import httpie.output
    import httpie.input
    import contextlib
    import httpie.cli
    import requests
    import httpie.cliloggingprinter
    import httpie.downloads

    @contextlib.contextmanager
    def stdin_as_string(string):
        old_stdin = sys.stdin
        sys.stdin = io.StringIO(string)
        yield
        sys.stdin = old_stdin

    @contextlib.contextmanager
    def capture_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr

# Generated at 2022-06-25 18:41:04.255900
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env_0 = Environment()
    explicit_json_0 = False
    color_scheme_0 = 'solarized'
    kwargs_0 = {}
    retval_0 = ColorFormatter(env_0, explicit_json_0, color_scheme_0, **kwargs_0)
    assert retval_0 is not None
    str_0 = 'x*p+Z'
    str_1 = 'U*l6U'
    retval_1 = retval_0.format_headers(str_0)
    assert retval_1 is not None
    retval_2 = retval_0.format_body(str_1, str_1)
    assert retval_2 is not None
    mime_0 = 'vI+'
    str_2 = 'C}Z'
    ret

# Generated at 2022-06-25 18:41:07.736685
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_scheme = DEFAULT_STYLE
    color_scheme = AUTO_STYLE
    color_scheme = SOLARIZED_STYLE
    color_scheme = 'test string'


# Generated at 2022-06-25 18:41:13.250870
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    kwargs = {}
    color = ColorFormatter(env, explicit_json, color_scheme, **kwargs)
    assert (color.group_name == 'colors')
    assert (color.explicit_json == False)



# Generated at 2022-06-25 18:41:36.616291
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment()
    color_formatter = ColorFormatter(env)
    color_scheme = 'solarized'
    # Testing when color_scheme is valid
    # Expected OUTPUT: Style
    assert color_formatter.get_style_class(color_scheme) != None

# Generated at 2022-06-25 18:41:41.197370
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    format_body_1 = ColorFormatter(None, False, DEFAULT_STYLE)
    input_1 = "/"
    type = "text/html"
    pygments_formatter_3 = format_body_1.format_body(input_1, type)


# Generated at 2022-06-25 18:41:49.660187
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    colorFormatter_0 = ColorFormatter(None)
    str_0 = 'X2<e1J"/1LF}/'
    str_1 = 'E)6PmT?b[>Jgu9'
    str_2 = 'Mk+jR6U`w6U"19'
    str_3 = 'v^Y$y<8x?"?kh'
    str_4 = 'wj3q'
    str_5 = 'yO]ug'
    str_6 = 'B'
    str_7 = 'I'
    str_8 = '_-'
    str_9 = 'o'
    str_10 = 'e'
    str_11 = 'e'
    str_12 = 'y'
    str_13 = 'x'

    # Exception raised in try block

# Generated at 2022-06-25 18:41:53.947400
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    try:
        class_0 = pygments.styles.get_style_by_name('default')
    except ClassNotFound:
        class_0 = TextLexer
    assert ColorFormatter.get_style_class('default') == class_0

# Generated at 2022-06-25 18:42:05.793122
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Case 1
    str_1 = 'C'
    str_2 = 'RhYXAgbW9kdWxl'
    mime = 'javascri/json'
    try:
        ColorFormatter.format_body(str_1, mime, str_2)
    except TypeError:
        pass
    else:
        assert False

    # Case 2
    str_3 = 'JwMzc2VudA=='
    str_4 = 'YnVsbGV0cw=='
    mime = 'json/json'
    try:
        ColorFormatter.format_body(str_3, mime, str_4)
    except TypeError:
        pass
    else:
        assert False

    # Case 3

# Generated at 2022-06-25 18:42:14.384201
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    enum_0 = Environment(color=True, style=DEFAULT_STYLE)
    obj_0 = ColorFormatter(enum_0)
    str_0 = 'appicaYton/son'
    str_1 = 'application/json'
    str_2 = 'application/xml'
    str_3 = 'application/javascript'
    str_4 = 'application/ecmascript'
    str_5 = 'application/bson'
    str_6 = 'application/vnd.api+json'
    str_7 = 'application/vnd.api+xml'
    str_8 = 'application/vnd.api+javascript'
    str_9 = 'application/vnd.api+ecmascript'
    str_10 = 'application/vnd.api+bson'

# Generated at 2022-06-25 18:42:15.535692
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Just a test
    class_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:42:21.111873
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter()
    string_0 = 'application/vnd.example.v2+json'
    string_1 = 'applicaYton/son'
    string_2 = '{'
    lexer_0 = color_formatter.get_lexer_for_body(string_0, string_0)
    lexer_1 = color_formatter.get_lexer_for_body(string_1, string_1)
    lexer_2 = color_formatter.get_lexer_for_body(string_2, string_2)


# Generated at 2022-06-25 18:42:23.008304
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from pygments import token
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style


# Generated at 2022-06-25 18:42:26.087448
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    str_0 = 'znT`C^H,@[dlJ6A&QK9M#v-r#>'
    assert ColorFormatter.format_headers(str_0) is not None
    test_case_0()


# Generated at 2022-06-25 18:42:46.083451
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    str_0 = 'a+b/c'
    optional_0 = get_lexer(str_0, str_0, str_0)

# Generated at 2022-06-25 18:42:53.490031
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    explicit_json = False  # type: bool
    color_scheme = DEFAULT_STYLE  # type: str
    kwargs = {}  # type: dict
    formatter = ColorFormatter(env, explicit_json, color_scheme, **kwargs)
    formatter.enabled = True

    mime = 'a/b'  # type: str
    body = 'some text'  # type: str
    assert formatter.format_body(body, mime) == body



# Generated at 2022-06-25 18:42:57.528005
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.base import Stream

    stream = Stream()
    string = 'some string'
    formatter = ColorFormatter(stream)
    mime = 'mime string'
    result = formatter.get_lexer_for_body(mime, string)

    assert result is None

# Generated at 2022-06-25 18:43:00.601927
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    filtered = filter(lambda k: not k.startswith('_'), dir(SimplifiedHTTPLexer))
    assert sorted(filtered) == sorted(['aliases', 'filenames', 'name', 'tokens'])


# Generated at 2022-06-25 18:43:02.152961
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    obj_0 = SimplifiedHTTPLexer()
    assert isinstance(obj_0, SimplifiedHTTPLexer)


# Generated at 2022-06-25 18:43:06.157471
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    arg_0 = None
    arg_1 = None
    test = ColorFormatter(arg_0, arg_1)
    arg_2 = None
    str_0 = 'appicaYton/son'
    optional_0 = get_lexer(str_0, str_0, str_0)


# Generated at 2022-06-25 18:43:07.945253
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert isinstance(SimplifiedHTTPLexer, pygments.lexer.RegexLexer)


# Generated at 2022-06-25 18:43:17.375781
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    token_type = pygments.token.Keyword.Reserved  # 'HTTP'
    token_type_0 = pygments.token.Operator  # '/'
    token_type_1 = pygments.token.Number  # Version
    token_type_2 = pygments.token.Text
    token_type_3 = pygments.token.Number  # Status code
    token_type_4 = pygments.token.Text
    token_type_5 = pygments.token.Name.Exception  # Reason
    name = 'HTTP'
    aliases = ['http']
    filenames = ['*.http']

# Generated at 2022-06-25 18:43:23.076580
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env_0 = Environment()
    env_0.colors = 256
    color_formatter_0 = ColorFormatter(env_0)
    str_0 = 'appicaYton/son'
    str_1 = 'appicaYton/son'
    tmp_0 = color_formatter_0.format_body(str_1, str_0)
    assert tmp_0 == str_1


# Generated at 2022-06-25 18:43:24.855702
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(Environment())
    color_formatter.format_body('this is a test', 'text/html')


# Generated at 2022-06-25 18:43:43.345276
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    colorFormatter = ColorFormatter(None)
    str_0 = 'appicoAte'
    optional_0 = colorFormatter.format_headers(str_0)


# Generated at 2022-06-25 18:43:50.317544
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    style_0 = Solarized256Style()
    name_0 = ('HTTP', style_0)
    formatter_0 = Terminal256Formatter(name_0)
    lexer_0 = SimplifiedHTTPLexer()
    str_1 = 'HTTP/1.1 500 Internal Server Error'
    str_2 = 'Content-Type: text/html; charset=utf-8'
    str_3 = 'Date: Sun, 23 Feb 2020 15:50:18 GMT'
    str_4 = 'Server: Werkzeug/1.0.1 Python/3.7.6'
    str_5 = 'Content-Length: 369'

# Generated at 2022-06-25 18:43:53.133863
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'

# Generated at 2022-06-25 18:43:59.464504
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Test case 0
    str_0 = 'appicaYton/son'
    _0 = ColorFormatter(str_0, str_0)
    str_1 = 'appicaYton/son'
    _0._format_headers(str_1)

    # Test case 1
    #str_0 = 'appicaYton/son'
    #_0 = ColorFormatter(str_0, str_0)
    #str_1 = 'appicaYton/son'
    #headers = _0._format_headers(str_1)
    #str_2 = 'appicaYton/son'
    #_0._format_headers(str_2)


# Generated at 2022-06-25 18:44:08.139809
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    str_0 = 'hY'
    str_1 = 'nY'
    obj = ColorFormatter(str_0, str_0)
    # Assert: AssertionError: 'nY' not in set(['colorful', 'emacs', 'friendly', 'fruity', 'manni', 'monokai', 'murphy', 'native', 'paraiso-dark', 'paraiso-light', 'pastie', 'perldoc', 'rrt', 'tango', 'trac', 'vim', 'xcode', 'solarized'])
    res = obj.get_style_class(str_1)


# Generated at 2022-06-25 18:44:12.033376
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    print("Testing format_body...")
    str_0 = 'appicaYton/son'
    class_0 = ColorFormatter(
        str_0, str_0, str_0
    )
    optional_0 = class_0.format_body(str_0, str_0)


# Generated at 2022-06-25 18:44:13.855409
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    try:
        SimplifiedHTTPLexer()
    except:
        assert False


# Generated at 2022-06-25 18:44:21.301137
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Test for invalid type mime
    cls_instance_0 = ColorFormatter(Environment(), True)
    str_1 = 'appicaYton/son'
    str_0 = 'appicaYton/son'
    optional_0 = cls_instance_0.get_lexer_for_body(str_1 , str_0)
    assert optional_0 == None

    # Test for invalid type body
    cls_instance_0 = ColorFormatter(Environment(), True)
    str_1 = 'appicaYton/son'
    str_0 = 'appicaYton/son'
    optional_0 = cls_instance_0.get_lexer_for_body(str_1 , str_0)
    assert optional_0 == None

    # Test for invalid type explicit_json
    cls_instance_

# Generated at 2022-06-25 18:44:26.267245
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # This test case is incomplete (only a single assertion)
    # because either the tested method is incomplete or
    # this test case is incorrect.
    formatter = ColorFormatter()
    #str_0 = 'appicaYton/son'
    #ret_0 = formatter.format_headers(str_0)
    #assert ret_0 == 'appicaYton/son', ret_0


# Generated at 2022-06-25 18:44:28.207520
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(Environment(colors=True))
    formatter.format_body('', 'text/html')


# Generated at 2022-06-25 18:45:06.304586
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_name = 'solarized'

    style_class = ColorFormatter.get_style_class(style_name)
    assert style_class is Solarized256Style


# Generated at 2022-06-25 18:45:17.164814
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer.__module__ == 'httpie.plugins.builtin.colors'
    assert SimplifiedHTTPLexer.__qualname__ == 'SimplifiedHTTPLexer'
    assert SimplifiedHTTPLexer.name == 'HTTP'
    assert SimplifiedHTTPLexer.aliases == ['http']
    assert SimplifiedHTTPLexer.filenames == ['*.http']

# Generated at 2022-06-25 18:45:27.285712
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():

    str_0 = 'appicaYton/son'
    str_1 = 'appicaYton/son'
    str_2 = 'appicaYton/son'
    str_3 = 'appicaYton/son'
    str_4 = 'appicaYton/son'
    str_5 = 'appicaYton/son'
    str_6 = 'appicaYton/son'
    str_7 = 'appicaYton/son'
    str_8 = 'appicaYton/son'
    str_9 = 'appicaYton/son'
    str_10 = 'appicaYton/son'
    str_11 = 'appicaYton/son'
    str_12 = 'appicaYton/son'
    str_13 = 'appicaYton/son'
    str_

# Generated at 2022-06-25 18:45:30.726497
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie
    c = httpie.plugins.formatter.colors.ColorFormatter(
        explicit_json=True,
        color_scheme='solarized',
        group_name='colors',
    )
    assert c.get_lexer_for_body('application/json', 'foo') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-25 18:45:35.193409
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_http_lexer_0 = SimplifiedHTTPLexer()
    name_0 = simplified_http_lexer_0.name
    aliases_0 = simplified_http_lexer_0.aliases
    filenames_0 = simplified_http_lexer_0.filenames
    tokens_0 = simplified_http_lexer_0.tokens


# Generated at 2022-06-25 18:45:36.927229
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    str_0 = 'johndoe@example.com'
    simplifiedHTTPLexer_0 = SimplifiedHTTPLexer(str_0, str_0)


# Generated at 2022-06-25 18:45:48.170785
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.compat import is_windows
    from httpie.plugins import builtin_plugins
    from httpie.output.streams import get_binary_stream
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    kwargs = {}
    kwargs['stdin_isatty'] = False
    kwargs['stdout_isatty'] = False
    kwargs['output_options'] = None
    kwargs['output_file'] = get_binary_stream('stdout')
    kwargs['combine_output_streams'] = False
    kwargs['env'] = env

# Generated at 2022-06-25 18:45:51.246422
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(Environment())
    mime = 'text/plain'
    body = 'body'
    result = formatter.format_body(body, mime)
    assert result == 'body'


# Generated at 2022-06-25 18:45:53.204157
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    str_0 = 'appicaYton/son'
    optional_0 = get_lexer(str_0, str_0, str_0)


# Generated at 2022-06-25 18:45:58.775284
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    request_class_0 = ColorFormatter
    # test against a None mime type
    # test against a None body
    # test against a None kwargs
    # test against a None explicit_json
    # test against a None body
    # test against a None http_lexer
    # test against a None self
    # test against a None body
    # test against a None explicit_json
    # test against a None mime


# Generated at 2022-06-25 18:46:47.733612
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Initialize objects with attributes
    str_0 = 'appicaYton/son'
    optional_0 = get_lexer(str_0, str_0, str_0)
    str_1 = 'appicaYton/son'
    optional_1 = get_lexer(str_1, str_1, str_1)
    str_2 = 'appicaYton/son'
    optional_2 = get_lexer(str_2, str_2, str_2)
    str_3 = 'appicaYton/son'
    optional_3 = get_lexer(str_3, str_3, str_3)
    colorFormatter_0 = ColorFormatter(str_0, str_1, str_2, str_3)
    colorFormatter_0.explicit_json = True
   

# Generated at 2022-06-25 18:46:58.307114
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    str_0 = 'appicaYton/son'
    str_1 = 'appicaYton/son'
    str_2 = 'appicaYton/son'
    str_3 = 'appicaYton/son'
    str_4 = 'appicaYton/son'
    str_5 = 'appicaYton/son'
    str_6 = 'appicaYton/son'
    str_7 = 'appicaYton/son'
    str_8 = 'appicaYton/son'
    str_9 = 'appicaYton/son'
    str_10 = 'appicaYton/son'
    str_11 = 'appicaYton/son'
    str_12 = 'appicaYton/son'
    str_13 = 'appicaYton/son'
    str_

# Generated at 2022-06-25 18:47:01.348592
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    str_0 = 'appicaYton/son'
    env_0 = Environment()
    color_formatter_0 = ColorFormatter(env_0, True, str_0)
    optional_0 = color_formatter_0.format_headers(str_0)


# Generated at 2022-06-25 18:47:04.234140
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = Environment(headers=[], output_file=None, stderr=None, stdin=None, stdout=None)
    color_formatter_0 = ColorFormatter(environment_0, True)


# Generated at 2022-06-25 18:47:06.635609
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env_0 = Environment()
    str_0 = 'appicaYton/son'
    ColorFormatter(env_0, 1, str_0)


# Generated at 2022-06-25 18:47:11.255915
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter_var = ColorFormatter(None, False, 'auto')
    str_0 = 'appicaYton/son'
    str_1 = 'canals'
    expected_result = None
    actual_result = color_formatter_var.format_body(str_0, str_1)
    assert actual_result == expected_result


# Generated at 2022-06-25 18:47:20.153520
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # setup
    str_1 = 'appicaYton/son'
    str_2 = 'quo vadis'
    lexer_1 = get_lexer(
        mime='application/json',
        explicit_json=False,
        body='[{"e": "mc\u00b2", "pi": 3.141592653589793, "phi": 1.618033988749895}]'
    )
    pygments_1 = pygments.formatter.Terminal256Formatter(style=Solarized256Style())
    pygments_2 = pygments.lexers.get_lexer_for_mimetype(mime_type=str_2)
    pygments_3 = pygments.highlight(code=str_1, lexer=lexer_1, formatter=pygments_1)


# Generated at 2022-06-25 18:47:25.188657
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = 'appicaYton/son'
    formatter_0 = ColorFormatter(str_0, str_0, str_0, 'solarized', 'solarized')
    str_1 = 'appicaYton/son'
    str_2 = 'appicaYton/son'
    str_3 = formatter_0.format_body(str_1, str_2)


# Generated at 2022-06-25 18:47:28.942561
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simp_http_lexer = SimplifiedHTTPLexer()
    assert simp_http_lexer.name == 'HTTP'
    assert pygments.lexers.get_lexer_by_name('http') == simp_http_lexer


# Generated at 2022-06-25 18:47:33.403072
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_scheme = 'solarized'
    class_0 = ColorFormatter.get_style_class(color_scheme)
    assert str(class_0) == '<class \'httpie.plugins.builtin.colors.Solarized256Style\'>'


# Generated at 2022-06-25 18:49:02.096810
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_http_lexer = SimplifiedHTTPLexer()
    assert simplified_http_lexer.name == "HTTP"
    assert simplified_http_lexer.aliases == ["http"]
    assert simplified_http_lexer.filenames == ["*.http"]