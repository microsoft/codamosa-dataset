

# Generated at 2022-06-25 18:39:12.531161
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    body = {
        "name": "john",
        "age":30,
        "city": "beijing"
    }
    print(body)
    mime = "application/json"
    print(json.dumps(body,indent=4))
    assert formatter.format_body(json.dumps(body, indent=4), mime) == json.dumps(body,indent=4)

# Generated at 2022-06-25 18:39:19.974666
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=True)
    color_formatter = ColorFormatter(env, color_scheme='solarized')
    assert color_formatter.format_headers('Content-Type: text/plain\r\n') == "\x1b[38;5;32mContent-Type\x1b[39m: \x1b[38;5;83mtext/plain\x1b[39m"  # noqa: E501


# Generated at 2022-06-25 18:39:28.641807
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment(
        colors=True,
        stdin=False,
        stdout=True,
        isatty=True,
        output_options=('format', 'format_options'),
        log_level='debug',
    )
    formatter = ColorFormatter(env)
    response = lambda mime, body: formatter.get_lexer_for_body(mime, body)

    # If a lexer exists for the given MIME type, it should be returned.
    assert response('foo/bar', 'baz') == pygments.lexers.get_lexer_by_name('bar')

    # If a lexer exists for a parent type of the given MIME type, it should be
    # returned.
    assert response('foo/bar-baz', 'qux') == pygments.lexers.get_

# Generated at 2022-06-25 18:39:36.737637
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # test for JSON type
    c = ColorFormatter(None)
    body = c.format_body("{'a': 'test'}", mimetype = 'application/json')
    assert body == "{\x1b[38;5;41m'a'\x1b[39m\x1b[38;5;45m:\x1b[39m \x1b[38;5;41m'test'\x1b[39m}"

    # test for HTML type
    body = c.format_body("<html></html>", mimetype = 'text/html')

# Generated at 2022-06-25 18:39:39.601505
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    cf = ColorFormatter(None)
    mime = 'application/json'
    body = ''
    lexer = cf.get_lexer_for_body(mime,body)
    assert lexer.name == 'JSON'


# Generated at 2022-06-25 18:39:47.658508
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') is None
    assert get_lexer('text/plain', True) is None
    assert get_lexer('text/plain', True, '{}') is None
    assert get_lexer('text/plain', False, '{}') is None
    assert get_lexer('text/x-python') is not None
    assert get_lexer('application/json') is not None
    assert get_lexer('text/html') is not None
    assert get_lexer('text/javascript') is not None

# Generated at 2022-06-25 18:39:57.577894
# Unit test for function get_lexer
def test_get_lexer():
    # This function is concerned with the case where the lexer
    # has not yet been specified in the HTTPie config. Any
    # configured lexer will be handled by its own unit tests.
    #
    # Note that the Solarized256Style is used to provide additional
    # color contrast for testing.

    def _test_case_0():
        # Example: a normal text document
        mime = 'application/json'
        body = '"message": "Hello, world!"'
        lexer = get_lexer(mime, body)
        assert isinstance(lexer, pygments.lexers.get_lexer_by_name('json'))

# Generated at 2022-06-25 18:40:05.625188
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # ColorFormatter.get_style_class(solarized)
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    # ColorFormatter.get_style_class(auto)
    assert ColorFormatter.get_style_class('auto') == Solarized256Style
    # ColorFormatter.get_style_class(Default)
    assert ColorFormatter.get_style_class('Default') == Solarized256Style
    # ColorFormatter.get_style_class(Default on windows)
    assert ColorFormatter.get_style_class('fruity') == Solarized256Style

# Generated at 2022-06-25 18:40:13.193510
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    global formatter
    global http_lexer

    # Test the case where body is a JSON object
    formatter = Terminal256Formatter()
    http_lexer = SimplifiedHTTPLexer()
    body = '[{"city": "Washington"},{"city": "New York"},{"city": "Los Angeles"}]'
    mime = 'application/json'
    expected_result = pygments.highlight(
        code=body,
        lexer=lexer,
        formatter=formatter,
    )
    result = ColorFormatter.format_body(body, mime)
    assert result.equals(expected_result)

    # Test the case where body is an HTML file
    formatter = Terminal256Formatter()
    http_lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-25 18:40:25.468609
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer(mime="application/json", explicit_json=False, body=""), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer(mime="text/html", explicit_json=False, body=""), pygments.lexers.HtmlLexer)
    assert isinstance(get_lexer(mime="text/plain", explicit_json=False, body=""), pygments.lexers.TextLexer)
    assert isinstance(get_lexer(mime="application/json", explicit_json=False, body='{"a": "b"}'), pygments.lexers.JsonLexer)

# Generated at 2022-06-25 18:40:47.650384
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = '7a'
    str_1 = 'H~w<BE'
    str_2 = "v*4'Z"
    optional_0 = get_lexer(str_0, str_1)
    color_formatter_0 = ColorFormatter(Environment())
    color_formatter_0.get_lexer_for_body(str_0, str_2)
    str_3 = '_Y'
    str_4 = '<K]h'
    color_formatter_0.format_body(str_3, str_4)

# Generated at 2022-06-25 18:40:51.683741
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class_0 = ColorFormatter
    str_0 = "r{HE%#`" # random header value
    optional_0 = class_0.format_headers(str_0)
    str_1 = "M(VEX}V-" # random header value
    optional_1 = class_0.format_headers(str_1)
    str_2 = "9B;!K8\W" # random header value
    optional_2 = class_0.format_headers(str_2)
    str_3 = "67=WZ`s?" # random header value
    optional_3 = class_0.format_headers(str_3)
    str_4 = "^p\qT`T`" # random header value
    optional_4 = class_0.format_headers(str_4)

# Generated at 2022-06-25 18:40:54.752796
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = "R"
    str_1 = '\x13'
    str_2 = '.E,H'
    color_formatter_0 = ColorFormatter()
    str_3 = color_formatter_0.format_body(str_2, str_0)
    str_4 = color_formatter_0.format_body(str_2, str_1)


# Generated at 2022-06-25 18:41:00.417024
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    str_0 = "Wt*;@68>d"
    optional_0 = get_lexer(str_0, str_0)
    str_1 = 'Si;1H"K'
    optional_1 = get_lexer(str_0, optional_0)
    str_2 = 'AuEub'
    optional_2 = get_lexer(str_0, str_1, optional_1)
    str_3 = 'E3q^'
    optional_3 = get_lexer(str_0, str_1, optional_1, optional_2)
    str_4 = 's^m_}'
    optional_4 = get_lexer(str_0, str_1, optional_1, optional_2, optional_3)
    str_5 = '=!GZ'
   

# Generated at 2022-06-25 18:41:01.712307
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    str_0 = "em/yU'H"
    optional_0 = SimplifiedHTTPLexer(str_0, str_0)


# Generated at 2022-06-25 18:41:11.970793
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = 'N9!l1'
    str_1 = 'application/x-www-form-urlencoded'
    str_2 = ';a"Lk/'
    optional_0 = get_lexer(str_0, str_0)
    if not isinstance(optional_0, pygments.lexers.text.TextLexer):
        str_0 = 'N9!l1'
        str_1 = 'application/x-www-form-urlencoded'
        str_2 = ';a"Lk/'
        optional_0 = get_lexer(str_0, str_0)
        if not isinstance(optional_0, pygments.lexers.text.TextLexer):
            str_0 = 'N9!l1'

# Generated at 2022-06-25 18:41:15.340933
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    arg_0 = "gl5-nZ"
    formatter_1: ColorFormatter = ColorFormatter(arg_0, arg_0)
    formatter_1.format_headers(arg_0)


# Generated at 2022-06-25 18:41:22.523211
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Environment
    env = None
    # bool
    explicit_json = False
    # str
    color_scheme = 'auto'

    obj = ColorFormatter(env, explicit_json, color_scheme)
    obj.format_headers("text")
    obj.format_body("text", "text")
    obj.get_lexer_for_body("text", "text")
    obj.get_style_class("test")
    obj.get_lexer("test", False, "test")


# Generated at 2022-06-25 18:41:35.319328
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # This function should not be called directly.
    str_0 = '4@J0'
    str_1 = '1">5'
    str_2 = '3DR:'
    str_3 = '2Q9D'
    optional_0 = get_lexer(str_0, str_1)
    optional_1 = get_lexer(str_2, str_3)
    str_4 = "1g\'`"
    str_5 = '2W0V'
    str_6 = '3R0A'
    str_7 = '0U6M'
    optional_2 = get_lexer(str_4, str_5)
    optional_3 = get_lexer(str_6, str_7)
    str_8 = '1E;*'

# Generated at 2022-06-25 18:41:40.738059
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = 'T@N6`'
    str_1 = 'i}'
    'nWl'
    ColorFormatter(str_0, bool_0=True).format_body(str_1, str_0)

if (__name__ == '__main__'):
    test_case_0()

# Generated at 2022-06-25 18:41:58.942902
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    global str_0
    str_0 = "HQ_;S"
    global str_1
    str_1 = "http"
    global str_2
    str_2 = ";]@'9' (Te"
    global str_3
    str_3 = "`2:]"
    global str_4
    str_4 = "/"
    global str_5
    str_5 = "j"
    global str_6
    str_6 = 'X'
    global str_7
    str_7 = 't'
    global str_8
    str_8 = 'r'
    global str_9
    str_9 = 'e'
    global str_10
    str_10 = 'a'
    global str_11
    str_11 = 'm'
    global optional_0
    optional

# Generated at 2022-06-25 18:42:09.569645
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    str_0 = '2'
    str_1 = '\x7f'
    str_2 = 'FxJ'
    str_3 = 'Z-:CC'

    obj_0 = ColorFormatter(str_0, str_1, str_2, str_3)
    str_4 = 'oB'
    str_5 = 'M5'
    str_6 = 'I'
    str_7 = '\x7f'

    obj_1 = ColorFormatter(str_4, str_5, str_6, str_7)
    obj_2 = ColorFormatter(str_6, str_6, str_6, str_6)
    str_8 = 'q'
    str_9 = 'U1'
    str_10 = 'E'

# Generated at 2022-06-25 18:42:15.921204
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Create an instance of ColorFormatter
    #
    # Arguments of constructor
    # - env: Environment
    # -- kwargs:
    #
    # Return value of constructor
    color_formatter_0 = ColorFormatter(Environment(), False, DEFAULT_STYLE)

    # Call format_body
    #
    # Arguments
    # - body: str
    # - mime: str
    #
    # Return value
    return_value_0 = color_formatter_0.format_body("", "")

    # Check return value
    assert return_value_0 == ""


# Generated at 2022-06-25 18:42:23.608215
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    str_2 = "19WV:"
    str_3 = "ICj"
    optional_1 = get_lexer(str_3, str_3)
    str_4 = '3G4SB'
    optional_2 = get_lexer(str_4, str_4)
    num_0 = 0
    boolean_0 = False
    str_5 = 'e0~'
    str_6 = 'D'
    optional_3 = get_lexer(str_6, str_6)
    str_7 = 'SvfP'
    optional_4 = get_lexer(str_7, str_7)
    str_8 = 'Kr'
    optional_5 = get_lexer(str_8, str_8)
    num_1 = 2
    boolean_1 = True
   

# Generated at 2022-06-25 18:42:25.988393
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter = ColorFormatter(1)
    color_formatter.format_headers('HTTP/1.1 200 OK\r\n\r\n')


# Generated at 2022-06-25 18:42:33.902064
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    from . import _test_colors

    str_0 = 'HJU9'
    str_1 = 'G'
    str_2 = 'v'
    str_3 = 'QlZ'
    str_4 = ('_!q3' + str_3)
    str_5 = "\tqB"
    str_6 = ("m'r" + str_2 + str_1)
    str_7 = (str_6 + 'G_')
    str_8 = (str_7 + '@')
    str_9 = (str_8 + str_3 + 'x')
    str_10 = ((str_3 + '>') + (str_9 + str_5))

# Generated at 2022-06-25 18:42:35.762935
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    x = ColorFormatter()
    if x.format_body('PQr'):
        pass



# Generated at 2022-06-25 18:42:38.547559
# Unit test for function get_lexer
def test_get_lexer():
    str_0 = "t9*Y5"
    optional_0 = get_lexer(str_0, str_0)

# Generated at 2022-06-25 18:42:49.129662
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    this = ColorFormatter(None)
    headers = 'headers'
    pygments.lexers.get_lexer_by_name = lambda str_1: 'str'
    pygments.lexers.get_lexer_for_mimetype = lambda str_2: 'str'
    pygments.lexers.get_lexer_for_filename = lambda str_3, str_4: 'str'
    pygments.lexers.guess_lexer = lambda str_5: 'str'
    pygments.lexer.RegexLexer.mimetypes = ['mimetypes']
    pygments.lexer.RegexLexer.aliases = ['aliases']
    pygments.lexer.RegexLexer.filenames = ['filenames']

# Generated at 2022-06-25 18:42:51.790781
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class_0 = ColorFormatter()
    str_0 = 'DpGE@$'
    str_1 = class_0.format_headers(str_0)


# Generated at 2022-06-25 18:43:15.426657
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    try:
        Environment()
    except:
        assert False
    try:
        color_scheme = 'solarized'
    except:
        assert False
    try:
        color_formatter = ColorFormatter(Environment(), color_scheme)
    except:
        assert False
    assert color_formatter.formatter.style == Solarized256Style


# Generated at 2022-06-25 18:43:19.019509
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # http --colors=on
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    obj = ColorFormatter(explicit_json, color_scheme)


# Generated at 2022-06-25 18:43:26.248493
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(
        color=True
    )
    explicit_json = True
    color_scheme = "http"
    c = ColorFormatter(
        env,
        explicit_json,
        color_scheme
    )
    assert c.formatter.__class__.__name__ == "TerminalFormatter"
    assert c.http_lexer.__class__.__name__ == "PygmentsHttpLexer"
    assert c.get_style_class("solarized").__name__ == "Solarized256Style"
    assert c.get_lexer_for_body("foo/bar", "Hello").__class__.__name__ == "TextLexer"

# Generated at 2022-06-25 18:43:36.849607
# Unit test for function get_lexer
def test_get_lexer():
    str_0 = "em/yU'H"
    optional_0 = get_lexer(str_0)
    str_1 = "N8:@'K<N=\\]J"
    optional_1 = get_lexer(str_1)
    str_2 = ":o6U]O(~2S[C"
    optional_2 = get_lexer(str_2)
    str_3 = "c%+n3(F_^2`"
    optional_3 = get_lexer(str_3)
    str_4 = "U>YDg@s+sT"
    optional_4 = get_lexer(str_4)
    str_5 = "WD-gD#-"
    optional_5 = get_lexer(str_5)

# Generated at 2022-06-25 18:43:47.110950
# Unit test for function get_lexer
def test_get_lexer():

    input_1 = 'application/json'
    output_1 = pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(input_1) == output_1

    input_2 = 'text/plain'
    output_2 = pygments.lexers.get_lexer_for_mimetype('text/plain')
    assert get_lexer(input_2) == output_2

    input_3 = 'text/html'
    output_3 = pygments.lexers.get_lexer_by_name('html')
    assert get_lexer(input_3) == output_3

    input_4 = 'application/xml'
    output_4 = pygments.lexers.get_lexer_by_name('xml')

# Generated at 2022-06-25 18:43:55.892932
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    optional_0 = get_lexer(str_0)
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    kwargs = {}
    obj = ColorFormatter( optional_0, explicit_json=False, color_scheme=DEFAULT_STYLE, **kwargs)
    assert isinstance(obj, ColorFormatter)
    assert obj.group_name == 'colors'
    assert_isinstance(obj.explicit_json, bool)
    assert_isinstance(obj.formatter, TerminalFormatter)
    assert_isinstance(obj.http_lexer, SimplifiedHTTPLexer)


# Generated at 2022-06-25 18:44:07.652390
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')   
    assert get_lexer('application/json', explicit_json=True)   
    assert get_lexer('application/json', False)   
    assert get_lexer('application/json', body='')   
    assert get_lexer('return/json', explicit_json=True)   
    assert get_lexer('return/json', False)   
    assert get_lexer('return/json', body='')   
    assert get_lexer('a/json', False)   
    assert get_lexer('a/json', body='')   
    assert get_lexer('application/xml', explicit_json=True)   
    assert get_lexer('application/xml', False)   
    assert get_lexer('application/xml', body='')   
   

# Generated at 2022-06-25 18:44:11.475588
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    explicit_json= True
    color_scheme= SOLARIZED_STYLE
    instance_0 = ColorFormatter(env, explicit_json, color_scheme)


# Generated at 2022-06-25 18:44:13.110326
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print(1)
    optional_0: ColorFormatter = ColorFormatter(Environment())


# Generated at 2022-06-25 18:44:20.965014
# Unit test for function get_lexer
def test_get_lexer():
    str_0 = ":>v)pN.V"
    optional_0 = get_lexer(str_0)
    expect_0 = None
    assert optional_0 == expect_0

    str_1 = "d10eX9?r"
    optional_1 = get_lexer(str_1)
    expect_1 = None
    assert optional_1 == expect_1

    str_2 = ":VvO<>`W"
    optional_2 = get_lexer(str_2)
    expect_2 = None
    assert optional_2 == expect_2

    str_3 = "?E5vd5l5"
    optional_3 = get_lexer(str_3)
    expect_3 = None
    assert optional_3 == expect_3


# Generated at 2022-06-25 18:44:52.646909
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    result = ColorFormatter("httpie", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ")
    try:
        assert result
    except AssertionError:
        print("Failed")
        # raise


# Generated at 2022-06-25 18:45:03.678198
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    str_1 = 'application/json'
    str_2 = 'KeJW'
    str_3 = 'application/x-www-form-urlencoded'
    str_4 = 'lh/p'
    str_5 = 'http/2'
    str_6 = 'application/octet-stream'
    str_7 = ""
    str_8 = "Q4(44d,Z'4(N!w[8W'Y,gGd["
    int_3 = -872177776
    str_9 = '74"\'6b!U\'K!g#<"U,}I;RX'
    str_10 = '"'
    str_11 = 'application/json'
    str_12 = 'application/x-www-form-urlencoded'

# Generated at 2022-06-25 18:45:10.003444
# Unit test for function get_lexer
def test_get_lexer():
    str_0 = "N0G'vu"
    str_1 = 'H2"{#'
    str_2 = '6"h#7'
    str_3 = 'jK#-U*'
    bool_0 = True
    optional_0 = get_lexer(str_0, bool_0, str_2)
    assert (optional_0 == None)
    optional_1 = get_lexer(str_0, bool_0)
    assert (optional_1 == None)
    optional_2 = get_lexer(str_0)
    assert (optional_2 == None)


# test_case_2 to test_case_11

# Generated at 2022-06-25 18:45:19.068621
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():

    # Create a new object of class ColorFormatter with no parameters
    # ColorFormatter_inst = ColorFormatter()
    # ColorFormatter_inst = ColorFormatter(None)
    # ColorFormatter_inst = ColorFormatter(ColorFormatter)

    # Create a new object of class ColorFormatter with one parameter
    ColorFormatter_inst = ColorFormatter("\x14k")

    # Create a new object of class ColorFormatter with two parameters
    ColorFormatter_inst = ColorFormatter("\x14k", "\x06K")

    # Create a new object of class ColorFormatter with three parameters
    # ColorFormatter_inst = ColorFormatter("\x14k", "\x06K", "\x06K")



# Generated at 2022-06-25 18:45:26.172262
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env_0 = Environment(colors=256)
    explicit_json_0 = False
    color_scheme_0 = 'fruity'
    colorFormatter_0 = ColorFormatter(env_0, explicit_json_0, color_scheme_0)
    explicit_json_1 = True
    color_scheme_1 = 'fruity'
    colorFormatter_1 = ColorFormatter(env_0, explicit_json_1, color_scheme_1)


# Generated at 2022-06-25 18:45:32.400903
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class TestEnvironment:
        pass
    testEnvironment = TestEnvironment()
    testEnvironment.colors = 256
    test_colorFormatter = ColorFormatter(
        testEnvironment,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE
    )
    assert isinstance(test_colorFormatter, ColorFormatter)


# Generated at 2022-06-25 18:45:35.461441
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(
        colors=True,
        colors_force=True,
        colors_256=True
    )
    obj_0 = ColorFormatter(env)
    assert(str(type(obj_0)).find('ColorFormatter') != -1)


# Generated at 2022-06-25 18:45:46.475631
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    instance_0 = ColorFormatter(Environment())
    str_0 = "em/yU'H"
    optional_0 = get_lexer(str_0)
    optional_1 = instance_0.get_lexer_for_body(str_0, optional_0)
    optional_2 = instance_0.format_body(optional_1, str_0)
    optional_3 = instance_0.format_headers(optional_2)

# Generated at 2022-06-25 18:45:48.064306
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    p = ColorFormatter(None, False, "auto")

# Generated at 2022-06-25 18:45:52.060290
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Arguments:
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    kwargs = ''
    color_formatter = ColorFormatter(env, explicit_json, color_scheme, kwargs)
    assert isinstance(color_formatter, ColorFormatter)


# Generated at 2022-06-25 18:46:56.701732
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    arg_0 = get_lexer("^B:")
# Asserts that the two given arguments are equal.
    assert arg_0 == arg_0


# Generated at 2022-06-25 18:47:04.748461
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    mock_env_0 = mock.Mock(spec=Environment)
    mock_env_0.colors = True
    mock_env_0.colors = 256
    mock_env_0.colors = False
    int_0 = 256
    mock_env_0.colors = int_0

    explicit_json_0 = mock.Mock(spec=bool)
    color_scheme_0 = mock.Mock(spec=str)
    kwargs_0 = mock.Mock(spec=dict)
    kwargs_0['color_scheme'] = 'solarized'
    mock_kwargs_0 = mock.Mock(spec=dict)
    mock_kwargs_0['color_scheme'] = 'solarized'

# Generated at 2022-06-25 18:47:05.823552
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter()

# Generated at 2022-06-25 18:47:08.658929
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(None, False, None)
    formatter.__init__(None, False, None)
    assert formatter.__init__(None, False, None) == None


# Generated at 2022-06-25 18:47:13.222744
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print("> Unit test: ColorFormatter constructor")
    import httpie.context
    env = httpie.context.Environment()
    is_stream_output = False
    color_scheme = "auto"
    color_formatter = ColorFormatter(env, is_stream_output, color_scheme)
    print("< Unit test: ColorFormatter constructor")


# Generated at 2022-06-25 18:47:15.308972
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('foo/bar') is None
    assert get_lexer('text/html') is None
    assert get_lexer('application/json') is not None

# Generated at 2022-06-25 18:47:18.783733
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Environment
    environment = Environment(colors=True)
    # Boolean
    explicit_json = False
    # String
    color_scheme = "test"
    formatter = ColorFormatter(
        environment, explicit_json, color_scheme
    )


# Generated at 2022-06-25 18:47:24.923357
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env_0 = Environment(colors=256)
    explicit_json_0 = False
    color_scheme_0 = 'fruity'
    obj_0 = ColorFormatter(env_0, explicit_json_0, color_scheme_0)
    headers_0 = 'GET / HTTP/1.1\r\nAccept: */*\r\nX-Foo: Bar\r\n\r\n'
    obj_0.format_headers(headers_0)


# Generated at 2022-06-25 18:47:26.472218
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    str_0 = "2YSKUZ}c"
    optional_0 = get_lexer(str_0)

# Generated at 2022-06-25 18:47:37.030223
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    str_1 = "0123456789"
    str_2 = "0123456789"
    str_3 = "0123456789"
    str_4 = "0123456789"
    str_5 = "0123456789"
    str_6 = "0123456789"
    str_7 = "0123456789"
    str_8 = "0123456789"
    str_9 = "0123456789"
    str_10 = "0123456789"
    str_11 = "0123456789"
    str_12 = "0123456789"
    str_13 = "0123456789"
    str_14 = "0123456789"
    str_15 = "0123456789"
    str_16