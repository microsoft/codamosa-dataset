

# Generated at 2022-06-25 18:39:19.111393
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    colorFormatter = ColorFormatter(Environment())
    assert getattr(colorFormatter, 'enabled') == False
    return

# Generated at 2022-06-25 18:39:24.613640
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    assert simplified_h_t_t_p_lexer_0.name == 'HTTP'
    assert simplified_h_t_t_p_lexer_0.aliases == ['http']
    assert simplified_h_t_t_p_lexer_0.filenames == ['*.http']


# Generated at 2022-06-25 18:39:28.087553
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    colorFormatter_instance = ColorFormatter()
    colorFormatter_instance.get_style_class(color_scheme="solarized")


# Generated at 2022-06-25 18:39:34.548652
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter_0 = ColorFormatter()
    mime = 'text/html'
    body = '<html><head><title>Test</title></head><body>Test</body></html>'
    get_lexer_for_body_result = color_formatter_0.get_lexer_for_body(mime, body)
    assert isinstance(get_lexer_for_body_result, pygments.lexers.html.HtmlLexer)
    assert not isinstance(get_lexer_for_body_result, pygments.lexer.TextLexer)


# Generated at 2022-06-25 18:39:38.442227
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class('nonsense')
    assert style_class == Solarized256Style
    style_class = ColorFormatter.get_style_class('solarized')
    assert style_class == Solarized256Style
    style_class = ColorFormatter.get_style_class('solarized256')
    assert style_class == Solarized256Style

# Generated at 2022-06-25 18:39:41.314814
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter_obj_0 = ColorFormatter()
    color_scheme = ''
    pygments_style = color_formatter_obj_0.get_style_class(color_scheme)


# Generated at 2022-06-25 18:39:43.528842
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(None, None, None)
    assert color_formatter is not None


# Generated at 2022-06-25 18:39:53.782871
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(
        env = Environment(),
        explicit_json = False,
        color_scheme = DEFAULT_STYLE,
    )
    formatter_1 = ColorFormatter(
        env = Environment(),
        explicit_json = False,
        color_scheme = DEFAULT_STYLE,
    )
    assert formatter is not formatter_1
    assert formatter.env is not formatter_1.env
    assert formatter.formatter is not formatter_1.formatter
    assert formatter.http_lexer is not formatter_1.http_lexer
    assert formatter.enabled == formatter_1.enabled
    assert formatter.explicit_json == formatter_1.explicit_json



# Generated at 2022-06-25 18:40:04.250924
# Unit test for function get_lexer

# Generated at 2022-06-25 18:40:12.340430
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
        style=Solarized256Style
    )

    headers = 'POST / HTTP/1.1\nHost: httpbin.org\nContent-Type: text/plain\n\n'


# Generated at 2022-06-25 18:40:33.007220
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    value1 = 'foo'
    value2 = 'bar'
    expected = 'foo'
    actual1 = ColorFormatter.format_body(value1, value2)
    assert actual1 == expected



# Generated at 2022-06-25 18:40:44.475362
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    assert simplified_h_t_t_p_lexer_0.name == 'HTTP'
    assert simplified_h_t_t_p_lexer_0._tokens == None
    assert simplified_h_t_t_p_lexer_0.aliases == ['http']
    assert simplified_h_t_t_p_lexer_0.filenames == ['*.http']

# Generated at 2022-06-25 18:40:46.253008
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert isinstance(SimplifiedHTTPLexer(), SimplifiedHTTPLexer)


# Generated at 2022-06-25 18:40:48.835542
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter_instance = ColorFormatter()
    exception = None
    try:
        formatter_instance.format_headers()
    except Exception as e:
        exception = e
    assert exception is not None


# Generated at 2022-06-25 18:40:54.177771
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import json
    import pygments.lexers.text
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie import ExitStatus
    from utils import TestEnvironment, http, HTTP_OK
    env = TestEnvironment(
        stdin_isatty=True,
        stdout_isatty=False,
        stdout_encoding='utf8',
    )
    http('--print=B', 'GET', 'http://example.org/JSON',
         env=env,
         headers={'Content-Type': 'application/json'},
         error_exit_ok=True)

# Generated at 2022-06-25 18:40:56.336664
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment())

    lexer = formatter.get_lexer_for_body(
        mime='application/json',
        body='',
    )
    assert lexer is None



# Generated at 2022-06-25 18:41:06.731808
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert isinstance(SimplifiedHTTPLexer(), pygments.lexer.RegexLexer)
    assert SimplifiedHTTPLexer.name == 'HTTP'
    assert SimplifiedHTTPLexer.aliases == ['http']
    assert SimplifiedHTTPLexer.filenames == ['*.http']
    assert isinstance(SimplifiedHTTPLexer.tokens, dict)
    assert isinstance(SimplifiedHTTPLexer.tokens['root'], list)
    assert isinstance(SimplifiedHTTPLexer.tokens['root'][0], tuple)
    assert isinstance(SimplifiedHTTPLexer.tokens['root'][1], tuple)

# Generated at 2022-06-25 18:41:13.488800
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    env.colors = 256
    # 1 parameter
    color_formatter_0 = ColorFormatter(env)
    # 2 parameters
    color_formatter_1 = ColorFormatter(env, True)
    # 3 parameters
    color_formatter_2 = ColorFormatter(env, False, 'solarized')
    # 4 parameters
    color_formatter_3 = ColorFormatter(env, True, 'solarized', True)


# Generated at 2022-06-25 18:41:16.410824
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer = SimplifiedHTTPLexer()
    assert simplified_h_t_t_p_lexer


# Generated at 2022-06-25 18:41:26.335819
# Unit test for method format_body of class ColorFormatter

# Generated at 2022-06-25 18:41:50.510885
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    print("Testing get_lexer_for_body of ColorFormatter")
    assert get_lexer_for_body(
        "text/html",
        "<!DOCTYPE html>\n<html lang=en>\n"
        "<head>\n<title>Test</title>\n</head>\n<body>\n</body>\n</html>\n"
        ) == pygments.lexers.get_lexer_by_name("html")


# Generated at 2022-06-25 18:41:56.163969
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():

    # Store argument which would be passed to the ColorFormatter format_headers method
    ColorFormatter_format_headers_headers = None

    # Create an instance of the ColorFormatter class
    ColorFormatterObj = ColorFormatter(None)

    # Call the method format_headers of the ColorFormatter object with the above argument
    output = ColorFormatterObj.format_headers(ColorFormatter_format_headers_headers)
    assert output is not None


# Generated at 2022-06-25 18:42:02.446210
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Construct an instance of ColorFormatter
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    color_formatter = ColorFormatter(
        env=env,
        explicit_json=explicit_json,
        color_scheme=color_scheme,
    )


# Generated at 2022-06-25 18:42:03.625400
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    color_formatter = ColorFormatter(env)


# Generated at 2022-06-25 18:42:07.389009
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Initialize the environment.
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env, explicit_json=0, color_scheme='test')
    # Assert that the constructor of this class works.
    assert(isinstance(color_formatter.http_lexer, SimplifiedHTTPLexer))


# Generated at 2022-06-25 18:42:13.918752
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter_0 = ColorFormatter(env=Environment(colors=True))
    color_formatter_0.format_body(body='\n', mime='text/plain')


# Generated at 2022-06-25 18:42:21.303558
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    #test case 0
    env = Environment(colors=True)
    explicit_json=True
    color_scheme="auto"
    cf = ColorFormatter(env, explicit_json, color_scheme)
    body = "body"
    mime = "mime"
    assert(cf.format_body(body, mime)=="<span class=\"err\"></span>")
    #test case 2
    env = Environment(colors=False)
    explicit_json=False
    color_scheme=AUTO_STYLE
    cf = ColorFormatter(env, explicit_json, color_scheme)
    body = "body"
    mime = "mime"
    assert(cf.format_body(body, mime)=="<span class=\"err\"></span>")
    #test case 3

# Generated at 2022-06-25 18:42:22.882749
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()

# Generated at 2022-06-25 18:42:25.999848
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    color_formatter_0 = ColorFormatter(Environment())
    color_formatter_0.get_lexer_for_body(
        "application/json",
        "{\"hello\": \"world\"}")


# Generated at 2022-06-25 18:42:31.514769
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    headers = (
        "POST /post HTTP/1.1\n"
        "Accept: */*\n"
        "Accept-Encoding: gzip, deflate\n"
        "Connection: keep-alive\n"
        "Content-Length: 18\n"
        "Content-Type: application/x-www-form-urlencoded\n"
        "Host: httpbin.org\n"
        "User-Agent: HTTPie/0.9.2\n"
    )
    assert ColorFormatter(env).format_headers(headers) == headers


# Generated at 2022-06-25 18:42:53.835916
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    Solarized256Style_0 = ColorFormatter.get_style_class('solarized')
    print(Solarized256Style_0)


# Generated at 2022-06-25 18:42:57.045327
# Unit test for function get_lexer
def test_get_lexer():
    input0 = 'foo/bar'
    expected_output = pygments.lexers.get_lexer_by_name('text')
    actual_output = get_lexer(input0)
    assert actual_output == expected_output
    

# Generated at 2022-06-25 18:43:04.980788
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    tmp = ColorFormatter(
        env = Environment(),
        explicit_json = False,
        color_scheme = DEFAULT_STYLE,
    )
    headers = '''
GET / HTTP/1.1
Host: example.org
Accept: */*
'''

# Generated at 2022-06-25 18:43:14.039781
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import mock
    import pygments.lexers

    color_formatter = ColorFormatter(mock.Mock())
    color_formatter.format_body('', 'text/plain')
    color_formatter.get_lexer_for_body('text/plain', '')

    # Patch get_lexer_for_body so that it won't raise an exception,
    # which would cause the test to fail with AssertionError
    lexer_type = type(pygments.lexers.get_lexer_for_mimetype('text/plain'))
    color_formatter.get_lexer_for_body = mock.Mock(return_value=lexer_type)
    color_formatter.format_body('', 'text/plain')

# Generated at 2022-06-25 18:43:20.711532
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Setup input parameters for method format_body of class ColorFormatter
    mime = "text/plain"
    env = Environment()

    # Setup expected results for method format_body of class ColorFormatter
    expected = ""
    expected = ""

    # Execute method format_body of class ColorFormatter
    actual = ColorFormatter(env).format_body(mime)

    # Verify expected vs actual results of method format_body of class ColorFormatter
    assert expected == actual

# Generated at 2022-06-25 18:43:22.696898
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter_0 = ColorFormatter(env= Environment(colors=256), explicit_json=False, color_scheme='solarized')
    color_formatter_0.format_headers('headers')
    assert True == True


# Generated at 2022-06-25 18:43:25.441814
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:43:30.507322
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    c = [(u'text/html', u'html'), (u'text/html', u'json')]
    try:
        for i in c:
            ColorFormatter.format_headers(i[0])
            raise Exception('AssertionError expected')
    except AssertionError:
        pass



# Generated at 2022-06-25 18:43:41.747405
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    pass
    # Test case 0:
    expected_result_0 = None
    color_formatter_instance_0 = ColorFormatter(
        explicit_json=False,
            color_scheme=DEFAULT_STYLE,
        env=Environment(),
    )
    result_0 = color_formatter_instance_0.get_style_class(
        color_scheme=DEFAULT_STYLE,
        )
    assert  result_0 == expected_result_0

    # Test case 1:
    expected_result_1 = None
    color_formatter_instance_1 = ColorFormatter(
        explicit_json=False,
            color_scheme=DEFAULT_STYLE,
        env=Environment(),
    )

# Generated at 2022-06-25 18:43:43.678408
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:44:07.269499
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment()
    color_scheme=DEFAULT_STYLE
    formatterobj = ColorFormatter(
        env=env,
        explicit_json=False,
        color_scheme=color_scheme,
    )
    formatterobj.get_style_class(color_scheme)
    return

# Generated at 2022-06-25 18:44:15.404744
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(
        env = Environment(
            auto_env = True,
            colors = 256,
            default_options = {
                'pretty': 'all',
                'style': 'solarized'
            },
            format = 'colors',
            ignore_stdin = False,
            is_windows = False,
            output_file = None,
            stdin = None,
            stdin_isatty = False,
            stdout = None,
            stdout_isatty = True
        ),
        explicit_json = False,
        color_scheme = DEFAULT_STYLE
    )

# Generated at 2022-06-25 18:44:21.912271
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(
        env = Environment(colors=256),
        explicit_json=False,
        color_scheme='solarized'
    )
    #Test case 1
    body_1 = '''[
    {
        "foo": "bar"
    },
    {
        "baz": "qux"
    }
]'''
    mime_1 = 'application/json'
    print('test case 1')
    print(color_formatter.format_body(body=body_1, mime=mime_1))
    #Test case 2

# Generated at 2022-06-25 18:44:25.893457
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """Test formatter with a simple HTML document."""
    import pkg_resources

    body = pkg_resources.resource_string('httpie.tests.data', 'file.html')
    formatter = ColorFormatter(None)
    assert formatter.format_body(body, 'text/html')



# Generated at 2022-06-25 18:44:33.055934
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    test_case_0()
    test_ColorFormatter_get_lexer_for_body_0()
    test_ColorFormatter_get_lexer_for_body_1()
    test_ColorFormatter_get_lexer_for_body_2()
    test_ColorFormatter_get_lexer_for_body_3()
    test_ColorFormatter_get_lexer_for_body_4()
    test_ColorFormatter_get_lexer_for_body_5()
    test_ColorFormatter_get_lexer_for_body_6()
    test_ColorFormatter_get_lexer_for_body_7()
    test_ColorFormatter_get_lexer_for_body_8()
    test_ColorFormatter_get_lexer_for_body_9()
   

# Generated at 2022-06-25 18:44:39.413408
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter_0 = ColorFormatter()
    color_formatter_0.get_lexer_for_body("text/plain", "")
    color_formatter_0.get_lexer_for_body("text/html", "")
    color_formatter_0.get_lexer_for_body("text/css", "")
    color_formatter_0.get_lexer_for_body("application/json", "")

# Generated at 2022-06-25 18:44:50.241643
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-25 18:44:51.414435
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
	# TODO: implement test
	pass


# Generated at 2022-06-25 18:44:52.567280
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter_0 = ColorFormatter(
        env=None
    )

# Generated at 2022-06-25 18:44:55.288971
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    cf = ColorFormatter()
    assert pygments.lexers.get_lexer_by_name('json') == cf.get_lexer_for_body('application/json','{"test":"test"}')

# Generated at 2022-06-25 18:45:29.991122
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
   color_formatter = ColorFormatter(None)
   optional_0 = color_formatter.format_body("application/json", "application/json")
   assert optional_0 is None


# Generated at 2022-06-25 18:45:32.996356
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    str_0 = 'text/html'
    str_1 = '<html><body>Test</body></html>'
    optional_0 = get_lexer(str_0, str_1)

# Generated at 2022-06-25 18:45:34.617764
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    str_0 = ')R9'
    str_1 = 'Nb'
    optional_0 = ColorFormatter.get_lexer_for_body(str_0, str_1)


# Generated at 2022-06-25 18:45:37.357556
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Test case 0
    str_0 = 'W'
    str_1 = 'M'
    optional_0 = get_lexer(str_0, str_1)


# Generated at 2022-06-25 18:45:41.857479
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment(colors='auto')
    color_scheme = 'auto'
    explicit_json=False
    obj = ColorFormatter(env, explicit_json, color_scheme)
    obj.get_style_class(color_scheme)


# Generated at 2022-06-25 18:45:51.799914
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']

# Generated at 2022-06-25 18:45:56.440885
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    env.colors = 256
    body = '{\n    "aaa": "bbb"\n}\n'
    kwargs = {
        'explicit_json': False,
        'color_scheme': DEFAULT_STYLE
    }
    color_formatter_obj = ColorFormatter(env, **kwargs)
    str_0 = '{\n    "aaa": "bbb"\n}\n'
    optional_0 = color_formatter_obj.format_body(body, str_0)


# Generated at 2022-06-25 18:46:06.455916
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Test 0
    str_0 = 'HTTP/'
    str_1 = 'application/json'
    str_2 = '{'
    str_3 = '}'
    str_4 = '0'
    str_5 = 'c'
    str_6 = 'p'
    str_7 = '['
    str_8 = 'X'
    str_9 = ':'
    str_10 = ','
    str_11 = '3'
    str_12 = '+'
    str_13 = '}'
    str_14 = '['
    str_15 = ']'
    str_16 = '&'
    str_17 = 'O'
    str_18 = '5'
    str_19 = '/'
    str_20 = '?'
    str_21 = '"'
   

# Generated at 2022-06-25 18:46:09.588279
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    arg_0 = DEFAULT_STYLE
    ret_0 = ColorFormatter.get_style_class(arg_0)
    assert ret_0 is None


# Generated at 2022-06-25 18:46:11.056337
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    str_0 = ')R9'
    optional_0 = get_lexer(str_0)

# Generated at 2022-06-25 18:46:37.605939
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Instance of class ColorFormatter
    color_formatter_0 = ColorFormatter(
                            arg_1=Environment(colors=256),
                            arg_2=False,
                            arg_3='solarized',
                            arg_4=None,
                            arg_5=None
                        )
    str_0 = 'Md)J%cNz_'
    # Call method format_headers of class ColorFormatter
    out_0 = color_formatter_0.format_headers(str_0)
    # AssertionError: AssertionError('assert str == typer.t.formatted_headers',)
    assert out_0 == str_0


# Generated at 2022-06-25 18:46:40.358942
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    optional_0 = SimplifiedHTTPLexer('101010101010101010101010101010101010101010101010101010101010101010')
    assert optional_0 != None


# Generated at 2022-06-25 18:46:48.977210
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    response_headers: str = '''\
HTTP/1.1 200 OK
Server: github.com
Content-Type: text/html; charset=utf-8
Last-Modified: Sat, 23 Sep 2017 03:49:11 GMT
ETag: "5a66b86a-2f54"
Access-Control-Allow-Origin: *
Expires: Sat, 23 Sep 2017 11:01:14 GMT
Cache-Control: max-age=600
X-GitHub-Request-Id: 7D91:1E92:31D1A:54EE6:59C6BC23'''


# Generated at 2022-06-25 18:46:52.261178
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    str_1 = ')R9'
    str_2 = 'o'
    str_3 = 'D#'
    print("ColorFormatter.format_headers()")


# Generated at 2022-06-25 18:46:58.568156
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    c_1 = ColorFormatter('{"foo": "bar"}', 'application/json')
    assert c_1.formatter.__class__ == Terminal256Formatter
    assert c_1.http_lexer.__class__ == SimplifiedHTTPLexer
    assert c_1.get_lexer_for_body('application/json', '{"foo": "bar"}') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-25 18:47:01.268765
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Test case for httpie.output.formatters.colors.ColorFormatter.__init__
    str_0 = ';8'
    optional_0 = get_lexer(str_0)
    assert optional_0 == None


# Generated at 2022-06-25 18:47:02.522744
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    str_0 = '\\'
    optional_0 = get_lexer(str_0)


# Generated at 2022-06-25 18:47:04.485607
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    str_0 = ')R9'
    optional_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:47:13.820079
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    arg2 = 3
    arg6_0 = 9
    arg6_1 = 9
    arg6_2 = 9
    # arg6_2 = 9
    arg6_3 = 9
    arg6_4 = 9
    arg6_5 = 9
    arg6_6 = 9
    arg6_7 = 9
    arg6_8 = 9
    arg6_9 = 9
    arg6_10 = 9
    arg6_11 = 9
    arg6_12 = 9
    arg6_13 = 9
    arg6_14 = 9
    arg6_15 = 9
    arg6_16 = 9
    arg6_17 = 9
    arg6_18 = 9
    arg6_19 = 9
    arg6_20 = 9
    arg6_21 = 9
    arg6_22 = 9


# Generated at 2022-06-25 18:47:16.217814
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    str_0 = 'GET /foo/bar HTTP/1.1\r\nHost: example.org\r\n\r\n'
    optional_0 = get_lexer(str_0)


# Generated at 2022-06-25 18:47:42.529645
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # The following inputs to constructor were used:
    #     env = Environment(colors=256,
    #                       style=Colors.NONE,
    #                       stdin_isatty=True,
    #                       stdout_isatty=True,
    #                       vcdiff=False)
    #     explicit_json = False
    #     color_scheme = 'fruity'
    color_formatter = ColorFormatter(
        env=Environment(
            colors=256,
            style=Colors.NONE,
            stdin_isatty=True,
            stdout_isatty=True,
            vcdiff=False
        ),
        explicit_json=False,
        color_scheme='fruity'
    )
    # The following inputs to method were used:
    #     arg_0

# Generated at 2022-06-25 18:47:54.042322
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from httpie.compat import get_headers

    body = '{}'
    sizeof = len

# Generated at 2022-06-25 18:47:56.851393
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    str_0 = 'r@'
    optional_0 = ColorFormatter(Environment.default).get_lexer_for_body(str_0, )


# Generated at 2022-06-25 18:48:09.212940
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    bool_0 = bool()
    bool_1 = bool(0)
    str_0 = str()
    Environment_0 = Environment(bool_0, bool_1, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    ColorFormatter_0 = ColorFormatter(Environment_0, bool_0, str_0)
    ColorFormatter_0 = ColorFormatter(Environment_0, bool_1, str_0)
    ColorFormatter_0 = ColorFormatter(Environment_0, bool_0, str_0)
    ColorFormatter_0 = ColorFormatter(Environment_0, bool_1, str_0)
    ColorFormatter_

# Generated at 2022-06-25 18:48:18.129420
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    fmt_0 = ColorFormatter('kQ4', False, False, False)
    # Exception raised: TypeError
    try:
        fmt_0.format_body()
    except TypeError as raised_exception:
        # Arg count: 2
        assert 2 == len(raised_exception.args)
        # Arg 0: Argument passed by position
        assert 'body' == raised_exception.args[0]
        # Arg 1: Argument passed by position
        assert 'mime' == raised_exception.args[1]


# Generated at 2022-06-25 18:48:20.641373
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # No header (yet)
    json_0 = ['a']
    optional_0 = ColorFormatter.format_headers(json_0)


# Generated at 2022-06-25 18:48:21.472588
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    test_case_0()



# Generated at 2022-06-25 18:48:33.444564
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Case #0
    in_0 = 'GET / HTTP/1.1\r\n'
    in_1 = 'Accept: */*\r\n'
    in_2 = 'Accept-Encoding: gzip, deflate\r\n'
    in_3 = 'Connection: keep-alive\r\n'
    in_4 = 'Host: httpbin.org\r\n'
    in_5 = 'User-Agent: HTTPie/0.9.8\r\n'
    in_6 = '\r\n'

# Generated at 2022-06-25 18:48:41.559359
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    str_0 = '}Bz'
    str_1 = '`ZB'
    str_2 = '?R)'
    str_3 = '#'
    optional_0 = ColorFormatter.get_lexer_for_body(str_0, str_1)
    optional_1 = ColorFormatter.get_lexer_for_body(str_1, str_0)
    optional_2 = ColorFormatter.get_lexer_for_body(str_1, str_2)
    optional_3 = ColorFormatter.get_lexer_for_body(str_1, str_3)


# Generated at 2022-06-25 18:48:45.059026
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    ColorFormatter(Environment(), color_scheme='solarized')
    #Variables
    ColorFormatter.format_headers(self, headers=str())
    #Function call
    test_case_0()
