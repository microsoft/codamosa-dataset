

# Generated at 2022-06-25 18:39:11.558490
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # w/ arg
    color_formatter_0 = ColorFormatter(Environment())
    optional_0 = color_formatter_0.get_style_class('fruity')


# Generated at 2022-06-25 18:39:14.430369
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Assert #0
    str_0 = 's'
    optional_0 = get_lexer(str_0)
    return None


# Generated at 2022-06-25 18:39:17.268122
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    method = ColorFormatter.format_body
    # TODO implement this method
    raise NotImplementedError()


# Generated at 2022-06-25 18:39:22.190262
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    this = ColorFormatter(Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)
    str_1 = 's'
    returned_0 = this.get_style_class(str_1)
    assert not isinstance(returned_0, Solarized256Style)


# Generated at 2022-06-25 18:39:29.922134
# Unit test for function get_lexer

# Generated at 2022-06-25 18:39:32.068837
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    obj = ColorFormatter()
    body = 's'
    mime = 's'
    assert obj.format_body(body, mime) is not None


# Generated at 2022-06-25 18:39:34.083212
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    str_0 = 's'
    str_1 = 'x'
    optional_0 = ColorFormatter.get_lexer_for_body(str_0, str_1)

# Generated at 2022-06-25 18:39:35.375526
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplifiedHTTPLexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:39:40.120977
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    str_0 = 'N'
    str_1 = 'b'
    color_formatter_instance = ColorFormatter(None, False, 'solarized')
    return_value_0 = color_formatter_instance.format_headers(str_0)
    return_value_1 = color_formatter_instance.format_headers(str_1)
    assert return_value_0 == 'N'
    assert return_value_1 == 'b'



# Generated at 2022-06-25 18:39:43.294181
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
  sol_formatter = ColorFormatter(true, true, true)
  if sol_formatter is null:
    raise TestFailException('ColorFormatter test failed')
  else:
    pass


# Generated at 2022-06-25 18:39:57.796006
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    var_0 = ColorFormatter()
    var_1 = 0
    assert var_0.get_style_class(var_1) == NotImplementedError()

# Generated at 2022-06-25 18:39:59.207991
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    with pytest.raises(NotImplementedError):
        test_case_0()

# Generated at 2022-06-25 18:40:00.294181
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    var_0 = NotImplementedError()

# Generated at 2022-06-25 18:40:02.593277
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie import ExitStatus

    var_0 = NotImplementedError()


# Generated at 2022-06-25 18:40:05.384776
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = None
    explicit_json = False
    color_scheme = 'auto'
    formatter = ColorFormatter(env, explicit_json, color_scheme)
    body = 'test'
    mime = 'test'

    # Call the method
    assert formatter.format_body(body, mime) is None


# Generated at 2022-06-25 18:40:07.782334
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    try:
        ColorFormatter.get_style_class('hello')
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-25 18:40:14.353147
# Unit test for function get_lexer
def test_get_lexer():

    # Test case 0
    # Inputs:
    #   mime = 'text/x-python'
    #   explicit_json = 'true'
    #   body = 'class Foo:\x20\ndef\x20bar(self):\x20\n\x20\x20\x20\x20pass'
    # Expected Outputs:
    #   lexer = <class 'pygments.lexers.python.Python3Lexer'>
    #   lexer.name = 'Python 3'
    var_0 = NotImplementedError()
    test_0_actual_output  = {"lexer": var_0}

# Generated at 2022-06-25 18:40:21.621695
# Unit test for function get_lexer
def test_get_lexer():
    args = {}
    # mime: str = 'application/json'
    args['mime'] = 'application/json'
    # explicit_json: bool = False
    args['explicit_json'] = False
    # body: str = ''
    args['body'] = ''

    ret = get_lexer(**args)
    assert ret == pygments.lexers.get_lexer_by_name('json')


# Generated at 2022-06-25 18:40:26.909338
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Setup fixture(s)

    # Exercise SUT
    from httpie.output.formatters.colors import ColorFormatter
    c = ColorFormatter(Environment())


    # Assert results
    assert(c.get_style_class('solarized') is Solarized256Style)
    assert(c.get_style_class('default') is Terminal256Formatter.DEFAULT_STYLE)



# Generated at 2022-06-25 18:40:29.500686
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    var_0 = ColorFormatter(Environment(colors=256))
    var_1 = var_0.format_headers('random string')
    assert(var_1 == '\x1b[38;5;246mrandom string\x1b[39m')


# Generated at 2022-06-25 18:40:52.437489
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    var_0 = ColorFormatter(
        env=Environment(
            colors=256,
            colors_force=False,
            default_options=[
                '--style',
                'auto',
            ],
            isatty=True,
            stdin=None,
            stdout=None,
            stderr=None,
        ),
        explicit_json=False,
        color_scheme='auto',
        pygments_json_lexer=None,
    )
    var_1 = None
    try:
        var_1 = var_0.format_headers(headers=None)
    except Exception:
        var_2 = True
    else:
        var_2 = False
    assert var_2


# Generated at 2022-06-25 18:40:55.296945
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_1 = ColorFormatter()
    var_2 = ColorFormatter()
    var_3 = ColorFormatter()
    var_4 = ColorFormatter()
    var_5 = NotImplementedError()


# Generated at 2022-06-25 18:41:05.532319
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    cls = ColorFormatter
    method = cls.get_lexer_for_body
    obj = cls(None, explicit_json=True, color_scheme='solarized', verbose=False)
    assert isinstance(obj, cls)

    # Case 1
    mime = 'application/json'

# Generated at 2022-06-25 18:41:08.481494
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter('env', 'color_scheme')
    assert color_formatter.get_style_class('color_scheme')


# Generated at 2022-06-25 18:41:10.320320
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(Environment())
    test_case_0()


# Generated at 2022-06-25 18:41:12.941961
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    foo = ColorFormatter('foo')
    assert foo.format_body('bar', 'baz') == 'bar'


# Generated at 2022-06-25 18:41:23.849027
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    if True:
        var_0 = ColorFormatter()
        var_1 = 'example.com'
        var_2 = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'
        try:
            var_0.format_headers(var_1)
        except Exception as var_3:
            var_4 = var_3
        else:
            var_4 = None
        finally:
            assert var_4 == None
    if True:
        var_5 = ColorFormatter()
        var_6 = 'example.com'
        var_7 = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'

# Generated at 2022-06-25 18:41:25.311750
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    var_0 = NotImplementedError()


# Generated at 2022-06-25 18:41:38.385522
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.utils import COLOR_SCHEMES
    from pygments.formatters.terminal import TerminalFormatter
    from pygments.formatters.terminal256 import Terminal256Formatter
    from pygments.lexer import Lexer
    from pygments.lexers import get_lexer_by_name
    from pygments.lexers.text import HttpLexer
    from pygments.style import Style
    from pygments.styles import get_style_by_name

    env = Environment()
    explicit_json = False
    color_scheme = 'auto'
    kwargs = {}

    # Test case with args
    arg_0 = env
    arg_1 = explicit_json
    arg_2 = color_scheme
   

# Generated at 2022-06-25 18:41:42.155910
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    var_1 = ColorFormatter()
    var_2 = 'python'
    var_3 = 'foo'
    var_1.format_body(var_2, var_3)


# Generated at 2022-06-25 18:41:53.656603
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    with pytest.raises(NotImplementedError):
        SimplifiedHTTPLexer(var_0)

# Generated at 2022-06-25 18:41:56.786444
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    var_0 = SimplifiedHTTPLexer()
    var_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:42:07.296535
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    lexer = pygments.lexers.TextLexer()
    formatter = pygments.formatters.TerminalFormatter()
    formatter.__init__()    
    clr_frmt = ColorFormatter(None, explicit_json=False, color_scheme=None, env=None)
    clr_frmt.__init__(None, False, None, env=None)
    clr_frmt.formatter = formatter
    clr_frmt.http_lexer = lexer
    try:
        clr_frmt.get_lexer_for_body('test', 'test')
    except AttributeError:
        # This happens because the json.loads() in method format_body
        # of class ColorFormatter throws an AttributeError exception
        print("Attribute error expected")

# Generated at 2022-06-25 18:42:19.471980
# Unit test for function get_lexer
def test_get_lexer():
    var_0 = SimplifiedHTTPLexer()
    var_1 = Solarized256Style()
    var_2 = SimplifiedHTTPLexer()
    var_2.name = "HTTP"
    var_2.aliases = ["http"]
    var_2.filenames = ["*.http"]

# Generated at 2022-06-25 18:42:21.486936
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Explicit instance of class SimplifiedHTTPLexer
    var_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:42:25.128578
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(
        Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    var_1 = formatter.format_body("whatever", "mime")
    assert (var_1 == "whatever")


# Generated at 2022-06-25 18:42:27.997384
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    arg_0 = NotImplemented
    try:
        var_0 = ColorFormatter.get_style_class(arg_0)
    except Exception as e:
        var_0 = e


# Generated at 2022-06-25 18:42:30.566048
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    obj = ColorFormatter("env")
    color_scheme = "solarized"
    result = obj.get_style_class(color_scheme)
    assert result == Solarized256Style


# Generated at 2022-06-25 18:42:38.497230
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    formatter = ColorFormatter()
    assert formatter.get_style_class('default') == pygments.styles.get_style_by_name('default')

# Mock module pygments.util if it is not installed
try:
    from unittest.mock import MagicMock
    mock_pygments_util = MagicMock()
except ImportError:
    from mock import MagicMock
    mock_pygments_util = MagicMock()

# Mock class ClassNotFound of module pygments.util

# Generated at 2022-06-25 18:42:43.185557
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(Environment())

    assert color_formatter.get_style_class(color_scheme = AUTO_STYLE) == TerminalFormatter
    assert color_formatter.get_style_class(color_scheme = DEFAULT_STYLE) == TerminalFormatter


# Generated at 2022-06-25 18:43:06.366512
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Set up object
    formatter = ColorFormatter(
        environment = Environment(),
        color_scheme = DEFAULT_STYLE,
    )
    formatter.enabled = True
    formatter.formatter = None
    formatter.http_lexer = None

    # Invocation
    result = formatter.format_headers(
        headers = 'headers',
    )

    # Check
    assert result is not None


# Generated at 2022-06-25 18:43:10.288261
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(Environment(colors=True, stdout_isatty=True))
    body = formatter.format_body("{\n  \"foo\": \"bar\"\n}", "application/json")
    print(body)


# Generated at 2022-06-25 18:43:12.351392
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    instance = ColorFormatter(environment_obj)
    instance._test_case_1()
    instance._test_case_2()


# Generated at 2022-06-25 18:43:15.276689
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    var_1 = ColorFormatter(str())
    var_2 = '''GET / HTTP/1.1
Host: example.org'''
    var_3 = var_1.format_headers(var_2)


# Generated at 2022-06-25 18:43:24.632879
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    print("\n\n## Testing function get_lexer_for_body of")
    print("class ColorFormatter")

    to_be_tested = ColorFormatter
    test_data_list = []
    (mime, body, expected) = test_data_list.pop()
    try:
        result = to_be_tested.get_lexer_for_body(mime, body)
    except Exception as e:
        result = e

    if not (result == expected):
        print("!!! WRONG RETURN VALUE !!!")
        print("Expected: " + str(expected))
        print("Result:   " + str(result))
    else:
        print("Test passed\n")


# Generated at 2022-06-25 18:43:35.874411
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    instance = ColorFormatter()
    var_0 = instance.http_lexer
    var_1 = instance.formatter
    var_2 = instance.format_headers('NONE')

# Generated at 2022-06-25 18:43:42.276941
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    var_1 = ColorFormatter(Environment(colors=True), True, 'fruity')
    var_2 = var_1.get_style_class('fruity')
    print('var_2 -->')
    if isinstance(var_2, type) and issubclass(var_2, pygments.style.Style):
        print('PASS')
    else:
        print('FAIL')


# Generated at 2022-06-25 18:43:48.283614
# Unit test for function get_lexer
def test_get_lexer():
    mime = 'text/html'
    explicit_json = True
    body = '<!doctype html>'
    assert get_lexer(mime, explici_json, body)
    mime = 'application/json'
    assert get_lexer(mime, explicit_json, body)
    body = ''
    assert get_lexer(mime, explicit_json, body)
    mime = 'text/html'
    body = '<!doctype html>'
    assert get_lexer(mime, explicit_json, body)

# Generated at 2022-06-25 18:43:58.001109
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Line 1:
    # Line 2: 
    var_1 = None
    var_2 = None
    var_3 = None
    # Line 3:     name = 'HTTP'
    var_3 = 'HTTP'
    # Line 4:     aliases = ['http']
    var_1 = ['http']
    # Line 8:     tokens = {
    var_2 = {}
    # Line 10:         'root': [
    var_2['root'] = []
    # Line 11:             # Request-Line
    # Line 12:             (r'([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)',
    # Line 14:                  pygments.lexer.bygroups(
    # Line 15:                      pygments.token.Name.Function,
    # Line 16:

# Generated at 2022-06-25 18:43:59.768400
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    var_2 = ColorFormatter.get_style_class()


# Generated at 2022-06-25 18:44:19.291136
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Setup
    headers = 'HEADERS'
    var_1 = ColorFormatter(Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)

    # Invocation
    var_return = var_1.format_headers(headers)

    # Check type of arg
    assert isinstance(headers, str)

    # Check return type
    assert isinstance(var_return, str)


# Generated at 2022-06-25 18:44:24.244226
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    var_1 = ColorFormatter()
    var_2 = 'blah'
    var_3 = 'image/png'
    var_4 = var_1.format_body(var_2, var_3)
    assert val_equal(var_4, 'blah'), "mismatch: var_4 = {}".format(var_4)

# Generated at 2022-06-25 18:44:27.560826
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    arg_0 = 'auto'
    var_0 = ColorFormatter.get_style_class(arg_0)
    assert type(var_0) == type
    assert str(var_0) == "<class \'Pygments.Lexers.http.HttpLexer\'>"


# Generated at 2022-06-25 18:44:33.966683
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Initilialize environment
    env = Environment()
    env.colors = True
    env.config = Config()
    env.config.colors = True


    # Create instance of class
    obj = ColorFormatter(env=env, explicit_json=False, color_scheme=DEFAULT_STYLE)


    # Actual test code
    # obj.format_headers(headers: str)
    # obj.format_body(body: str, mime: str)
    # obj.get_lexer_for_body(mime: str, body: str) -> Optional[Type[Lexer]]
    # obj.get_style_class(color_scheme: str) -> Type[pygments.style.Style]


    # Note: Calls to format_headers, format_body, get_lexer_for_body, and

# Generated at 2022-06-25 18:44:42.941748
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    var_0 = ColorFormatter(env=ColorFormatter())
    var_1 = str()
    var_2 = str()
    try:
        var_3 = var_0.get_lexer_for_body(mime=var_1,body=var_2)
    except Exception:
        var_4 = NotImplementedError()
    else:
        var_4 = var_3
    finally:
        var_5 = var_4
    try:
        var_6 = isinstance(var_5,(int, float, complex))
    except Exception:
        var_7 = NotImplementedError()
    else:
        var_7 = var_6
    assert var_7

# Generated at 2022-06-25 18:44:45.957732
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    var_0 = ColorFormatter(None)
    print(var_0.format_headers(None))


# Generated at 2022-06-25 18:44:51.056950
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    var_0 = ColorFormatter()

    assert isinstance(var_0, ColorFormatter)

    assert var_0.get_style_class(SOLARIZED_STYLE) is Solarized256Style

    assert var_0.get_style_class(DEFAULT_STYLE) is Solarized256Style


# Generated at 2022-06-25 18:45:00.195414
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    HttpLexer = pygments.lexers.HttpLexer
    assert ColorFormatter.format_body(
        body = "",
        mime = "",
        # FormatterPlugin = FormatterPlugin,
        # explicit_json = False,
        # color_scheme = "auto",
    ) == ""
    assert ColorFormatter.format_body(
        body = "",
        mime = "text/plain",
        # FormatterPlugin = FormatterPlugin,
        # explicit_json = False,
        # color_scheme = "auto",
    ) == ""
    assert ColorFormatter.format_body(
        body = "",
        mime = "text/plain",
        # FormatterPlugin = FormatterPlugin,
        # explicit_json = False,
        # color_scheme = "auto",
    )

# Generated at 2022-06-25 18:45:04.995110
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    var_0 = ColorFormatter
    var_1 = string()
    var_2 = string()
    var_3 = var_0.format_body(var_1, var_2)
    assert var_3 is None


# Generated at 2022-06-25 18:45:05.861011
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    var_0 = ColorFormatter()


# Generated at 2022-06-25 18:45:22.267800
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    var_0 = ColorFormatter()


# Generated at 2022-06-25 18:45:25.211669
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    print ("type(ColorFormatter().format_headers)")
    assert isinstance(ColorFormatter().format_headers, lambda x: x)


# Generated at 2022-06-25 18:45:30.955093
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    obj_0 = ColorFormatter(Environment())
    assert isinstance(obj_0, ColorFormatter) == True
    assert obj_0.explicit_json == False
    assert obj_0.formatter != None
    assert obj_0.http_lexer != None


# Generated at 2022-06-25 18:45:35.983975
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    var_1 = 'application/json'
    var_2 = '{"a": "b", "c": "d"}'
    var_3 = Environment(color=True)
    var_4 = ColorFormatter(var_3)
    var_5 = var_4.get_lexer_for_body(var_1, var_2)
    assert var_5 == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-25 18:45:41.105500
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    var_0 = ColorFormatter(env=None, explicit_json=False, color_scheme=DEFAULT_STYLE, **kwargs)
    var_1 = str()
    var_2 = var_0.format_headers(headers=var_1)
    assert var_2 == "", str(var_2)


# Generated at 2022-06-25 18:45:42.453044
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert True


# Generated at 2022-06-25 18:45:52.247626
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    arg_0 = ColorFormatter()
    arg_1 = ColorFormatter()
    arg_2 = ColorFormatter()
    arg_3 = ColorFormatter()
    arg_4 = ColorFormatter()
    arg_5 = ColorFormatter()
    arg_6 = ColorFormatter()
    arg_7 = ColorFormatter()
    arg_8 = ColorFormatter()
    arg_9 = ColorFormatter()
    arg_10 = ColorFormatter()
    arg_11 = ColorFormatter()
    arg_12 = ColorFormatter()
    arg_13 = ColorFormatter()
    arg_14 = ColorFormatter()
    arg_15 = ColorFormatter()
    arg_16 = ColorFormatter()
    arg_17 = ColorFormatter()
    arg_18 = ColorFormatter()
    arg_19 = ColorFormatter()

# Generated at 2022-06-25 18:45:57.944149
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # ???
    # ???: ValueError
    # Input:
    var_0 = ColorFormatter(env=NotImplementedError(), explicit_json=NotImplementedError(), color_scheme=NotImplementedError())
    var_1 = NotImplementedError()
    var_2 = NotImplementedError()

    assert isinstance(var_0.get_lexer_for_body(var_1, var_2), Optional[Type[Lexer]])


# Generated at 2022-06-25 18:46:01.967143
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    x = ColorFormatter()
    color_scheme = "auto"
    var_return = ColorFormatter.get_style_class(x, color_scheme)
    var_expected = pygments.styles.get_style_by_name("auto")
    assert var_return == var_expected
    raise NotImplementedError()


# Generated at 2022-06-25 18:46:12.653057
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    var_1 = ColorFormatter(
        env=Environment(colors=256),
        explicit_json=False,
        color_scheme='fruity',
    )
    #
    # Test #0
    #
    var_2 = test_case_0()
    try:
        var_1.get_lexer_for_body(mime='text/plain; charset=utf-8')
    except NotImplementedError as var_3:
        var_0 = var_3
    #
    # Test #1
    #
    try:
        var_1.get_lexer_for_body(mime='text/plain')
    except NotImplementedError as var_4:
        var_0 = var_4
    #
    # Test #2
    #

# Generated at 2022-06-25 18:46:33.040260
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    s = SimplifiedHTTPLexer(mimetype="GET/200")
    assert(s.tokens['root'][0][0] == "(.*?)( *)(:)( *)(.+)")

# Generated at 2022-06-25 18:46:41.451360
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Create an environment
    env = Environment()
    # Create a ColorFormatter
    formatter = ColorFormatter(env)
    # 'HTTPie'
    str_0 = 'HTTPie'
    # 'HTTPie'
    str_1 = formatter.format_headers(str_0)
    assert str_1 == 'HTTPie'
    # 'eV((C?~zktor'
    str_2 = formatter.format_headers('\r/eV((C?~zktor\nU>1')
    assert str_2 == 'eV((C?~zktor'
    # '{\n "response": {\n  "version": version,\n  "status": "ok",\n  "headers": {\n   "content-type": "application/json; charset=utf-8",\n

# Generated at 2022-06-25 18:46:43.740881
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Arrange
    color_formatter = ColorFormatter()

    # Act
    actual_result = color_formatter.get_lexer_for_body()

    # Assert
    assert actual_result is None

# Generated at 2022-06-25 18:46:53.434630
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    # Setup test variables
    c = ColorFormatter(Environment())
    color_formatter = None
    body_mime = None
    body_content = None

    body_mime = "application/json"
    body_content = """{
    "name": "John Doe",
    "age": 28,
    "skills": [
        "Python",
        "Git"
    ]
}
"""
    optional_1 = get_lexer(body_mime, False, body_content)
    assert optional_1 == None

    color_formatter = c
    optional_2 = color_formatter.get_lexer_for_body(body_mime, body_content)
    assert optional_2 != None

    body_mime = "text/html"
    body_content = ""

# Generated at 2022-06-25 18:47:00.297932
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    str_0 = '\r/eV((C?~zktor\nU>1'
    str_1 = 'ProtocolException'
    obj_0 = ColorFormatter(str_1)
    str_2 = 'HV&n\r$]8dR{5n'
    str_3 = 'h.g1+:2=\n'
    obj_1 = obj_0.get_lexer_for_body(str_0, str_2)
    assert (obj_1 == obj_1)



# Generated at 2022-06-25 18:47:02.625321
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    str_0 = '\r/eV((C?~zktor\nU>1'
    optional_0 = ColorFormatter.get_style_class(str_0)


# Generated at 2022-06-25 18:47:06.011638
# Unit test for function get_lexer
def test_get_lexer():
    # Test case 0
    str_0 = '\r/eV((C?~zktor\nU>1'
    optional_0 = get_lexer(str_0)
    assert optional_0 is not None


# Generated at 2022-06-25 18:47:12.450585
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    str_0 = '\r/eV((C?~zktor\nU>1'
    optional_0 = get_lexer(str_0)
    str_1 = '*'
    optional_1 = get_lexer(str_1)
    str_2 = '\r/eV((C?~zktor\nU>1'
    optional_2 = get_lexer(str_2)
    str_3 = '*'
    optional_3 = get_lexer(str_3)


# Generated at 2022-06-25 18:47:15.272077
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = '\r/eV((C?~zktor\nU>1'
    optional_0 = get_lexer(str_0)
    optional_0.format(str_0)


# Generated at 2022-06-25 18:47:19.871490
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter()
    color_scheme = DEFAULT_STYLE
    color_formatter = ColorFormatter(
        http_lexer=http_lexer,
        formatter=formatter,
        color_scheme=color_scheme
    )



# Generated at 2022-06-25 18:47:39.495233
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplifiedHTTPLexer = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:47:44.234630
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = "default"
    color_formatter = ColorFormatter(env, explicit_json, color_scheme)
    assert color_formatter.explicit_json == False
    assert color_formatter.formatter != None
    assert color_formatter.http_lexer != None
    assert color_formatter.enabled == True
    

# Generated at 2022-06-25 18:47:45.911570
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = 'XF:=\x1e'
    str_1 = '^N)'


# Generated at 2022-06-25 18:47:50.895192
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter_instance = ColorFormatter(
        "mime"
    )
    method_return_value_0 = color_formatter_instance.format_headers(
        "arg_0"
    )
    assert method_return_value_0 == "return_0"


# Generated at 2022-06-25 18:47:52.632216
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Test with: color_scheme=DEFAULT_STYLE
    ColorFormatter.get_style_class('auto')

# Generated at 2022-06-25 18:47:59.987051
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    f = ColorFormatter(Environment(), False, 'solarized')
    # Test 1
    str_0 = '\r/eV((C?~zktor\nU>1'
    optional_0 = f.format_headers(str_0)
    assert(optional_0 == '\x1b[1m\x1b[38;2;130;128;128m\r/eV((C?~zktor\n\x1b[39m\x1b[0m\x1b[1m\x1b[38;2;130;128;128mU>1\x1b[39m\x1b[0m')


# Generated at 2022-06-25 18:48:09.325799
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = '\r/eV((C?~zktor\nU>1'
    lexer_0 = get_lexer(str_0)
    bool_0 = isinstance(lexer_0, TextLexer)
    if bool_0:
        str_0 = '\r/eV((C?~zktor\nU>1'
        body_0 = '\r/eV((C?~zktor\nU>1'
        optional_0 = get_lexer(str_0, body=body_0)
        bool_0 = isinstance(optional_0, TextLexer)
    else:
        str_0 = '\r/eV((C?~zktor\nU>1'

# Generated at 2022-06-25 18:48:11.794597
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    obj = SimplifiedHTTPLexer( )
    assert type(obj) == SimplifiedHTTPLexer


# Generated at 2022-06-25 18:48:22.277449
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Instance of ColorFormatter
    color_formatter_1 = ColorFormatter(mime='application/xhtml+xml')
    # Instance of ColorFormatter
    color_formatter_0 = ColorFormatter(mime='message/http')
    # Test 1
    str_1 = '\r/eV((C?~zktor\nU>1'
    optional_1 = color_formatter_0.get_lexer_for_body(str_1, str_1)

    # Test 2
    str_2 = '\r/eV((C?~zktor\nU>1'
    optional_2 = color_formatter_1.get_lexer_for_body(str_2, str_2)



# Generated at 2022-06-25 18:48:28.875757
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors='256', stdout_isatty=True)
    explicit_json=True
    color_scheme='auto'
    colorFormatter = ColorFormatter(env, explicit_json, color_scheme)
    if not colorFormatter.enabled:
        return

    colorFormatter.get_style_class(color_scheme)

test_case_0()
test_ColorFormatter()