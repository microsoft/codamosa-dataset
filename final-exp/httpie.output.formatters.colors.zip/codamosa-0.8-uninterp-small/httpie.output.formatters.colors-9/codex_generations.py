

# Generated at 2022-06-25 18:39:10.953798
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(
        color_scheme=None,
        env=None,
        explicit_json=False
    )
    body = 'b79e03bbe7a8e664f59b977f0f1c07a3'
    mime = 'application/x-gzip'
    # Call tested method
    assert formatter.get_lexer_for_body(body=body, mime=mime) == None
    # Call tested method
    assert formatter.get_lexer_for_body(body=body, mime=mime) == None
    body = 'apples are not oranges'
    # Call tested method
    assert formatter.get_lexer_for_body(body=body, mime=mime) == None
    # Call tested method

# Generated at 2022-06-25 18:39:17.658591
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # arrange
    color_formatter = ColorFormatter(env = Environment(0, 0, []))
    color_scheme = 'solarized'
    expected_result = pygments.styles.get_style_by_name(color_scheme)
    # act
    actual_result = color_formatter.get_style_class(color_scheme)
    # assert
    assert actual_result == expected_result


# Generated at 2022-06-25 18:39:20.419210
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    c_f_0 = ColorFormatter(Environment())
    assert c_f_0.format_headers('') == ''


# Generated at 2022-06-25 18:39:21.474446
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    colorFormatter = ColorFormatter(Environment)

# Generated at 2022-06-25 18:39:27.308274
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(Environment(vars={}),
                                     color_scheme=DEFAULT_STYLE)
    color_scheme = DEFAULT_STYLE
    assert color_scheme in AVAILABLE_STYLES, \
        'Cannot test color scheme "%s" - not available' % color_scheme
    assert isinstance(color_formatter.get_style_class(color_scheme), type), \
        'Color scheme class is not a type'

# Generated at 2022-06-25 18:39:31.163482
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Input arguments to the method
    color_formatter_obj = ColorFormatter()
    mime = "application/json"
    body = """{
"name":"John"
}"""
    assert color_formatter_obj.get_lexer_for_body(mime, body).aliases == ['json']

# Generated at 2022-06-25 18:39:33.496888
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    tCase = ColorFormatter({}, '')
    headers = "HTTP/1.1 200 OK\r\nContent-Length: 500"
    print(tCase.format_headers(headers))


# Generated at 2022-06-25 18:39:36.401554
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter_0 = ColorFormatter(env=Environment(colors=True))
    color_formatter_0.get_lexer_for_body(mime='application/json', body=None)
    assert 1


# Generated at 2022-06-25 18:39:46.949492
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    assert simplified_h_t_t_p_lexer_0 == SimplifiedHTTPLexer()
    assert simplified_h_t_t_p_lexer_0 is not SimplifiedHTTPLexer()
    assert len(simplified_h_t_t_p_lexer_0) == 0
    from httpie.compat import is_py2
    assert type(simplified_h_t_t_p_lexer_0) == SimplifiedHTTPLexer
    assert type(simplified_h_t_t_p_lexer_0) == pygments.lexer.RegexLexer

# Generated at 2022-06-25 18:39:50.770029
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    assert isinstance(simplified_h_t_t_p_lexer_0, SimplifiedHTTPLexer)

# Generated at 2022-06-25 18:40:02.923567
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Setup
    formatter = ColorFormatter()
    body = "body"
    # Exercise
    result = formatter.format_body(body)
    # Verify
    assert result is body
    # Cleanup - none necessary



# Generated at 2022-06-25 18:40:11.454064
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(env={})
    assert color_formatter.get_style_class('nonexistent') == pygments.styles.get_style_by_name('default')
    assert color_formatter.get_style_class('nonexistent').__class__.__name__ == 'DefaultStyle'
    assert color_formatter.get_style_class('nonexistent').background_color == '#ffffff'
    assert color_formatter.get_style_class('nonexistent').styles[pygments.token.String.Escape].__class__.__name__ == 'Color'
    assert color_formatter.get_style_class('nonexistent').styles[pygments.token.String.Escape].color == '#00bbdd'

# Generated at 2022-06-25 18:40:23.693759
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.colors import ColorFormatter as c_f
    from httpie.plugins.colors import AUTO_STYLE as auto_style
    from httpie.plugins.colors import DEFAULT_STYLE as default_style
    from httpie.plugins.colors import AVAILABLE_STYLES as available_styles
    from httpie.context import Environment

    env = Environment(colors=256)
    formatter = c_f(env, False, auto_style)
    # mime: str, explicit_json: bool, body: str

# Generated at 2022-06-25 18:40:26.539790
# Unit test for function get_lexer
def test_get_lexer():
    # https://github.com/keleshev/httpie-pygments/pull/4
    get_lexer_0 = get_lexer(
        mime='application/json',
        explicit_json=False,
        body='{"key": "value"}'
    )
    if isinstance(get_lexer_0, pygments.lexers.JsonLexer):
        print('OK')
    else:
        print('FAIL')



# Generated at 2022-06-25 18:40:28.970764
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():

    env = Environment(
        colors=256,
        headers=False,
        pretty=True,
        print_body=True,
        stream=False,
        style='fruity'
    )

    ColorFormatter(env, explicit_json, color_scheme).format_body(body, mime)

# Generated at 2022-06-25 18:40:32.294349
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer.__name__ == 'SimplifiedHTTPLexer'
    assert SimplifiedHTTPLexer.__doc__ == SimplifiedHTTPLexer.__init__.__doc__


# Generated at 2022-06-25 18:40:33.707143
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # TODO
    pass


# Generated at 2022-06-25 18:40:44.863717
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers = '''\
HTTP/1.1 200 OK
Date: Tue, 17 Apr 2018 08:45:28 GMT
Server: Apache
Last-Modified: Wed, 13 Jan 2010 19:26:31 GMT
ETag: "c47a-5e6-47c6e03ce624c"
Accept-Ranges: bytes
Content-Length: 1510
Cache-Control: max-age=31536000
Expires: Wed, 17 Apr 2019 08:45:28 GMT
Keep-Alive: timeout=5, max=100
Connection: Keep-Alive
Content-Type: text/html

'''

    color_formatter = ColorFormatter(
        env=None,
        color_scheme=DEFAULT_STYLE
    )


# Generated at 2022-06-25 18:40:46.552266
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    try:
        ColorFormatter()
    except:
        print("Error with create ColorFormatter")


# Generated at 2022-06-25 18:40:50.666378
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    cf = ColorFormatter(Environment())
    assert not cf.get_lexer_for_body("application/json",'{}') 
    assert not cf.get_lexer_for_body("application/json",'{"a":1}') 
    assert cf.get_lexer_for_body("application/json",'{"a":1, "b":2}')

# Generated at 2022-06-25 18:41:05.950686
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    str_0 = 'g'
    instance_0 = pygments.lexers.text.HttpLexer(str_0)


# Generated at 2022-06-25 18:41:10.175948
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    obj = ColorFormatter(env, explicit_json, color_scheme)
    assert obj != None
    assert obj.group_name == 'colors'


# Generated at 2022-06-25 18:41:21.617540
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(Environment(colors=True))
    body = """<html>
    <h1>Hello, World!</h1>
    </html>"""
    code = formatter.format_body(body, mime='text/html')
    # Check the value of attribute in formatter
    assert(code == "\x1b[1;34m<html>\x1b[39;49;00m\n\x1b[1;34m  <h1>Hello, World!</h1>\x1b[39;49;00m\n\x1b[1;34m</html>\x1b[39;49;00m")
    body = '"""<html>\n    <h1>Hello, World!</h1>\n    </html>"""'
    code

# Generated at 2022-06-25 18:41:29.384002
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    style = 'solarized'
    style_class = ColorFormatter.get_style_class(style)
    formatter = Terminal256Formatter(
        style=style_class
    )

    http_lexer = PygmentsHttpLexer()
    headers = 'GET /api/updates HTTP/1.1\nHost: localhost:8080\nAccept-Encoding: gzip, deflate\nAccept: */*\nConnection: keep-alive\nUser-Agent: HTTPie/1.0.2\n\n'
    result = ColorFormatter.format_headers(headers, http_lexer=http_lexer, formatter=formatter)


# Generated at 2022-06-25 18:41:39.635698
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    Environment.colors = 256
    assert ColorFormatter(str, bool, DEFAULT_STYLE).formatter.__class__.__name__ == 'Terminal256Formatter'
    Environment.colors = True
    assert ColorFormatter(str, False, DEFAULT_STYLE).formatter.__class__.__name__ == 'TerminalFormatter'
    assert ColorFormatter(str, True, 'solarized').formatter.__class__.__name__ == 'Terminal256Formatter'
    assert ColorFormatter(str, False, 'solarized').formatter.__class__.__name__ == 'Terminal256Formatter'


# Generated at 2022-06-25 18:41:41.197752
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    obj = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:41:47.208687
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    color_formatter = ColorFormatter(
        env=env,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE
    )
    assert color_formatter.enabled == True

    env.colors = None
    color_formatter = ColorFormatter(
        env=env,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE
    )
    assert color_formatter.enabled == False

# Generated at 2022-06-25 18:41:51.722802
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Test with params: str('[1, 2, 3]')
    # Not implemented
    try:
        ColorFormatter.format_headers('[1, 2, 3]', )
    except NotImplementedError:
        pass


# Generated at 2022-06-25 18:41:53.396426
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    formatter = ColorFormatter(env)


# Generated at 2022-06-25 18:42:05.757139
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter()
    body = '"""some text""" '
    mime = 'text/python'
    assert (formatter.format_body(body, mime) == '"""some text""" ')
    body = ''' """string text""" '''
    mime = 'text/python'
    assert (formatter.format_body(body, mime) == '"""string text""" ')
    body = " '' "
    mime = 'text/python'
    assert (formatter.format_body(body, mime) == " '' ")
    body = '"""string""" '
    mime = 'text/python'
    assert (formatter.format_body(body, mime) == '"""string""" ')
    body = '"string" '
    mime = 'text/python'
   

# Generated at 2022-06-25 18:42:22.333766
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    mime = 'text/plain'
    body = ''
    assert color_formatter.format_body(mime, body) == ''


# Generated at 2022-06-25 18:42:25.333942
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_name = 'solarized'
    try:
        if pygments.styles.get_style_by_name(style_name):
            pass
        else:
            assert False
    except:
        assert False


# Generated at 2022-06-25 18:42:27.875306
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    class_0 = SimplifiedHTTPLexer()
    assert issubclass(type(class_0), pygments.lexers.regexlexer)


# Generated at 2022-06-25 18:42:28.821448
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-25 18:42:38.696217
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    formatter = ColorFormatter(env)
    mime = 'application/json'
    body = '{"status": 200}'
    formatter.format_body(body, mime)
    body = '{"status": 200'
    formatter.format_body(body, mime)
    mime = 'application/xml'
    body = '<status>200</status>'
    formatter.format_body(body, mime)
    mime = 'application/vnd'
    body = '{"status": 200}'
    formatter.format_body(body, mime)

# Test for method get_lexer of module httpie.plugins.format.colors

# Generated at 2022-06-25 18:42:49.213287
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class color_scheme():
        # UserDict subclass
        def __init__(self, *args, **kwargs):
            # default arguments
            self._Init__args = args
            self._Init__kwargs = kwargs

    class Environment():
        # UserDict subclass
        def __init__(self, *args, **kwargs):
            # default arguments
            self._Init__args = args
            self._Init__kwargs = kwargs
        pass

    color_scheme0 = color_scheme(2, 3, 5)
    env0 = Environment(2, 3, 5)
    color_formatter0 = ColorFormatter(env=env0, color_scheme=color_scheme0)
    assert color_formatter0.formatter is not None
    assert color_formatter0.enabled is True

# Generated at 2022-06-25 18:42:52.916167
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env=Environment()
    color_scheme='auto'
    obj = ColorFormatter(env, explicit_json=False, color_scheme=color_scheme)
    obj.get_style_class(color_scheme)

# Generated at 2022-06-25 18:43:02.265469
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = 'f/Nq&<GQL`=j'
    bool_0 = True
    bool_0 = False
    session_0 = test_case_0()
    str_1 = 'application/json'
    str_2 = '*1Jd'
    str_3 = '{}\x0c\x0e'
    optional_0 = get_lexer(str_0)
    if optional_0 != None:
        pass
    str_4 = 'color_scheme'
    str_5 = 'DEFAULT_STYLE'
    str_6 = 'color_scheme'
    str_7 = 'DEFAULT_STYLE'
    explicit_json = bool_0
    color_scheme = str_1

# Generated at 2022-06-25 18:43:03.871989
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_http_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:43:10.085236
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    encoders = dict()
    explicit_json = False
    color_scheme = 'solarized'
    env = Environment(encoders, explicit_json, None, color_scheme, False,
                      None, None)
    body_0 = 'body'
    mime_0 = 'mime'
    obj = ColorFormatter(env, explicit_json, color_scheme)
    optional_0 = obj.format_body(body_0, mime_0)


# Generated at 2022-06-25 18:44:08.469811
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(Environment(colors=256))
    color_formatter.format_body("Body", "MIME")



# Generated at 2022-06-25 18:44:13.067542
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    Env_Instance = Environment()
    ColorFormatter_Instance = ColorFormatter(
        env=Env_Instance,
    )
    assert ColorFormatter_Instance.format_body('str_0', 'str_1') == 'str_0'


# Generated at 2022-06-25 18:44:20.940798
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = 'HTTPHeaders'
    str_1 = 'application/json'
    str_2 = 'application/json'
    str_3 = '{"x": "y"}'
    kwargs_0 = {
        'explicit_json': False,
        'color_scheme': 'auto',
        'env': Environment(),
    }
    colorFormatter_0 = ColorFormatter(**kwargs_0)
    colorFormatter_0.group_name = 'colors'
    colorFormatter_0.enabled = True
    colorFormatter_0.explicit_json = False
    colorFormatter_0.formatter = TerminalFormatter()
    colorFormatter_0.http_lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-25 18:44:25.664316
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment(colors=True)
    color_formatter = ColorFormatter(env)
    str_0 = 'SNw46a'
    str_1 = '+0/IOL&T'
    str_2 = 'SNw46a'
    assert color_formatter.format_body(str_0, str_1) == str_2


# Generated at 2022-06-25 18:44:32.890161
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = '0'
    # test_case_0
    optional_0 = get_lexer(str_0)
    # test_case_1
    optional_1 = get_lexer('1')
    # test_case_2
    optional_2 = get_lexer('2')
    # test_case_3
    optional_3 = get_lexer('3')
    # test_case_4
    optional_4 = get_lexer('4')
    # test_case_5
    optional_5 = get_lexer('5')
    # test_case_6
    optional_6 = get_lexer('6')
    # test_case_7
    optional_7 = get_lexer('7')
    # test_case_8
    optional_8 = get_lexer('8')

# Generated at 2022-06-25 18:44:43.093183
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # - explicit_json = False
    # - mime = 'application/json'
    # - body = '{"data":[1,2,3,4],"number":1}'
    # - self.formatter = TerminalFormatter()
    # - self.http_lexer = SimplifiedHTTPLexer()
    # - self.explicit_json = False
    # - optional_0 = get_lexer(str_0)
    # - mime_type = 'application/json'
    # - body = '{"data":[1,2,3,4],"number":1}'
    # - self.formatter = TerminalFormatter()
    str_0 = '+0/IOL&T'
    optional_0 = get_lexer(str_0)
    mime_type = 'application/json'
    body

# Generated at 2022-06-25 18:44:51.531780
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    _env = Environment()
    _env.colors = True
    _explicit_json = False
    _color_scheme = 'solarized'
    _kwargs = {}

    color_formatter = ColorFormatter(
        _env,
        _explicit_json,
        _color_scheme,
        **_kwargs
    )

    assert color_formatter.formatter.style.styles.get(pygments.token.Token).get('background') == '#1c1c1c'


# Generated at 2022-06-25 18:45:02.446737
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # TODO: Make arguments to be used in this test
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    format_body = ColorFormatter(env, explicit_json, color_scheme).format_body
    # TypeError: Missing body argument
    # Please set the body argument to be used in test
    # TypeError: Missing mime argument
    # Please set the mime argument to be used in test
    # Execution is successful
    # Execution is successful
    # Execution is successful
    # Execution is successful
    # Execution is successful
    # Execution is successful
    # Execution is successful
    # Execution is successful
    # Execution is successful
    # Execution is successful
    # Execution is successful
    # Execution is successful
    # Execution is successful
    # Execution is successful
    # Execution is successful

# Generated at 2022-06-25 18:45:07.717373
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    arg_0 = Environment()
    arg_1 = 'auto'
    obj = ColorFormatter(arg_0, color_scheme=arg_1)
# Uncomment these lines to verify the correctness of the test case
#    assert obj is not None
#    assert obj.formatter is not None
#    assert obj.http_lexer is not None
#    assert obj.group_name == 'colors'
#    assert obj.enabled is True


# Generated at 2022-06-25 18:45:16.156857
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_1 = '&'
    str_2 = 'Ok'
    str_3 = ')L'
    str_4 = 'cBA0'
    str_5 = '-u'
    str_6 = '&'

    implicit_0 = ColorFormatter('application/json', '%')
    implicit_0.format_body(str_1, str_2)

    implicit_1 = ColorFormatter('text/html', 'pgP')
    implicit_1.format_body(str_3, str_4)

    implicit_2 = ColorFormatter('text/plain', 'z3A')
    implicit_2.format_body(str_5, str_6)


# Generated at 2022-06-25 18:45:48.115928
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    obj = ColorFormatter(Environment())


# Generated at 2022-06-25 18:45:51.507612
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env_0 = Environment()
    explicit_json_0 = False
    color_scheme_0 = DEFAULT_STYLE
    color_formatter_0 = ColorFormatter(env_0, explicit_json_0, color_scheme_0)


# Generated at 2022-06-25 18:45:57.435596
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    str_0 = '+0/IOL&T'
    # str -> bool
    optional_0 = get_lexer(str_0)
    # str -> bool
    optional_1 = get_lexer(str_0)
    # str -> bool
    optional_2 = get_lexer(str_0)
    class_0 = ColorFormatter
    instance_0 = class_0(optional_0,optional_1,optional_2)
    print(str(instance_0.explicit_json))
    method_0 = instance_0.format_headers
    str_1 = '+0/IOL&T'
    class_1 = SimplifiedHTTPLexer
    instance_1 = class_1()
    print(str(instance_1.name))
    print(str(instance_1.aliases))

# Generated at 2022-06-25 18:45:58.314771
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print('Testing ColorFormatter()')


# Generated at 2022-06-25 18:46:03.370614
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_scheme = DEFAULT_STYLE
    env = Environment(colors=True)
    explicit_json = False
    obj = ColorFormatter(env, explicit_json, color_scheme)
    obj.get_lexer_for_body()
    obj.get_style_class()
    obj.format_body()
    obj.format_headers()


# Generated at 2022-06-25 18:46:13.317571
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer('application/json'), pygments.lexers.get_lexer_by_name('json')) == True
    assert isinstance(get_lexer('text/plain'), pygments.lexers.get_lexer_by_name('text')) == True
    assert isinstance(get_lexer('text/html'), pygments.lexers.get_lexer_by_name('html')) == True
    assert isinstance(get_lexer('text/plain', explicit_json=True, body='{"x": "y"}'), pygments.lexers.get_lexer_by_name('json')) == True

# Generated at 2022-06-25 18:46:21.921510
# Unit test for function get_lexer
def test_get_lexer():
    str_0 = '|>&Y'
    str_1 = ''
    str_2 = '#0'
    str_3 = '#*'
    str_4 = '\x9d'
    str_5 = ';'
    str_6 = '+0/IOL&T'
    str_7 = '$'
    str_8 = '\r'
    str_9 = 'a'
    str_10 = '\x9a'
    str_11 = ','
    str_12 = '\r'
    str_13 = '0'
    str_14 = '\x08'
    str_15 = '\x83'
    str_16 = '\x9f'
    str_17 = '\x82'
    str_18 = '\x0b'


# Generated at 2022-06-25 18:46:26.125812
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = True
    color_scheme = DEFAULT_STYLE
    kwargs = {}
    color_formatter = ColorFormatter(env, 
                                     explicit_json,
                                     color_scheme,
                                     **kwargs)


# Generated at 2022-06-25 18:46:26.916375
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert True

# Generated at 2022-06-25 18:46:28.847391
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.formatter is not None


# Generated at 2022-06-25 18:47:45.209807
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json=False
    color_scheme=DEFAULT_STYLE
    kwargs={'env': env, 'explicit_json': explicit_json, 'color_scheme': color_scheme}
    form = ColorFormatter(**kwargs)
    assert form.group_name == "colors"
    assert form.env == env
    assert form.explicit_json == explicit_json
    assert form.formatter is not None
    assert form.http_lexer is not None


# Generated at 2022-06-25 18:47:51.920865
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    formatter = ColorFormatter(env=env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter.explicit_json == False
    env_1 = Environment()
    formatter_1 = ColorFormatter(env=env_1, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter_1.explicit_json == False


# Generated at 2022-06-25 18:47:53.202038
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    ed = Environment()
    ColorFormatter(ed)



# Generated at 2022-06-25 18:47:56.851222
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    x = ColorFormatter(Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert x.__init__(Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)


# Generated at 2022-06-25 18:48:02.158015
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    kwargs = {}

    ce = ColorFormatter(env=env, explicit_json=explicit_json, color_scheme=color_scheme, **kwargs)
    assert ce.enabled == False

# Generated at 2022-06-25 18:48:04.927992
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = '256'
    ColorFormatter(env, explicit_json = False, color_scheme = '256')


# Generated at 2022-06-25 18:48:08.563555
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=False, stdout_isatty=True)
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    color_formatter = ColorFormatter(env, explicit_json, color_scheme)
    assert color_formatter.formatter
    assert color_formatter.http_lexer

# Generated at 2022-06-25 18:48:13.038451
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter('a', True, None)
    assert formatter.explicit_json == True

    formatter2 = ColorFormatter('b', False, None)
    assert formatter2.explicit_json == False


# Generated at 2022-06-25 18:48:16.273717
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)


# Generated at 2022-06-25 18:48:22.121384
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    kwargs = { }
    color_formatter = ColorFormatter(env, explicit_json, color_scheme, **kwargs)
    assert color_formatter.group_name == "colors"
    assert color_formatter.enabled == True
    assert color_formatter.formatter.full == True
    assert color_formatter.formatter.noclasses == False
