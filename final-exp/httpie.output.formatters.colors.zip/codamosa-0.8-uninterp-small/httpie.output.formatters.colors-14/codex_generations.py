

# Generated at 2022-06-25 18:39:17.055301
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class TestImplColorFormatter:
        def format_headers(self, headers: str) -> str:
            pass

        def format_body(self, body: str, mime: str) -> str:
            pass

        def get_lexer_for_body(
            self, mime: str,
            body: str
        ) -> Optional[Type[Lexer]]:
            return get_lexer(
                mime=mime,
                explicit_json=self.explicit_json,
                body=body,
            )

    testImplColorFormatter = TestImplColorFormatter()
    testImplColorFormatter.format_headers("headers")
    testImplColorFormatter.format_body("body", "mime")

# Generated at 2022-06-25 18:39:25.830986
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    test_case_0()
    color_formatter_0 = ColorFormatter(Environment(colors=True), True)
    color_formatter_0.enabled = False
    color_formatter_1 = ColorFormatter(Environment(colors=256), True, 'solarized')
    color_formatter_1.enabled = False
    color_formatter_2 = ColorFormatter(Environment(colors=256), True, 'auto')
    color_formatter_2.enabled = False
    color_formatter_3 = ColorFormatter(Environment(colors=256), True, 'monokai')
    color_formatter_3.enabled = False

# Generated at 2022-06-25 18:39:28.374235
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()

# Generated at 2022-06-25 18:39:32.218248
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter_0 = ColorFormatter(
        env=Environment(colors=True, stdout_isatty=True),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    color_formatter_0.format_body(body="", mime="")


# Generated at 2022-06-25 18:39:35.514676
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter_0 = ColorFormatter(None)

    color_scheme = ''
    try:
        style_class = color_formatter_0.get_style_class(color_scheme)
    except ClassNotFound:
        pass # expected
    else:
        assert False, 'ExpectedClassNotFound'


# Generated at 2022-06-25 18:39:42.799115
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexers import text, special
    from pygments.token import _TokenType, Keyword, Name, Namespace, Text, Operator, Number, Keyword, Reserved, String, Operator, Exception, Number, Attribute, Name, Builtin, Pseudo, Constant, Decorator, Entity, Exception, Function, Tag, Variable, String, Backtick, Char, Escape, Heredoc, Regex, Number, Word, Comment, Preproc, Special, Deleted, Emph, Error, Heading, Inserted, Strong, Subheading, Token, Other, Punctuation, Generic, Literal
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()

# Generated at 2022-06-25 18:39:44.481427
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    color_formatter0 = ColorFormatter(env)


# Generated at 2022-06-25 18:39:55.690791
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-25 18:40:02.194121
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(Environment())

    StringConstant.test_ColorFormatter_get_style_class_cap_11 = {"solarized": "Solarized256Style"}

    color_scheme = StringConstant.test_ColorFormatter_get_style_class_cap_11["solarized"]

    actual_style_class = color_formatter.get_style_class(color_scheme)

    assert actual_style_class == Solarized256Style

# Generated at 2022-06-25 18:40:07.122184
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment()
    color_formatter = ColorFormatter(env, color_scheme=DEFAULT_STYLE)
    style_class = color_formatter.get_style_class(DEFAULT_STYLE)
    print(style_class.__name__)

if __name__ == '__main__':
    test_case_0()
    test_ColorFormatter_get_style_class()

# Generated at 2022-06-25 18:40:20.964234
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=True)
    c = ColorFormatter(env)
    response = 'HTTP/1.1 200 ok'
    print(c.format_headers(response))

if __name__ == '__main__':
    test_case_0()
    test_ColorFormatter_format_headers()

# Generated at 2022-06-25 18:40:23.779179
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    res = ColorFormatter(Environment(stream=None, colors=256), color_scheme="")
    assert(res.format_headers("")) == ""


# Generated at 2022-06-25 18:40:24.966944
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    test_case_0()


# Generated at 2022-06-25 18:40:26.252377
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Arrange
    color_formatter_0 = ColorFormatter(None)
    # Act
    color_formatter_0.format_body("", "")


# Generated at 2022-06-25 18:40:26.845604
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    test_case_0()

# Unit test

# Generated at 2022-06-25 18:40:28.507286
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter_0 = ColorFormatter(None)
    color_formatter_0.format_body("", "")


# Generated at 2022-06-25 18:40:31.679560
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    f = ColorFormatter(Environment(colors=256, style=''))
    assert f.format_body('', 'text/html') != ''
    assert f.format_body('', 'application/json') != ''
    assert f.format_body(json.dumps({'a': 1, 'b': {'c': 2}}), '') != ''

# Generated at 2022-06-25 18:40:34.167017
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:40:36.048054
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter_0 = ColorFormatter(None)
    color_formatter_0.get_style_class()

# Generated at 2022-06-25 18:40:44.764231
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    kwargs = dict()
    kwargs['explicit_json'] = False
    kwargs['color_scheme'] = '#1c1c1c'
    kwargs.update({'env': 'd7af'})
    kwargs.update({'kwargs': ''})
    obj = ColorFormatter(**kwargs)
    body = '5f5f5f'
    mime = '#afaf87'
    ans = '#af875f'
    method_return_value0 = obj.format_body(body, mime)
    assert method_return_value0 == ans

# Generated at 2022-06-25 18:40:56.500617
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env0 = Environment()
    color_formatter0 = ColorFormatter(env=env0)
    body0 = '''test_case_body'''
    mime0 = '''test_case_mime'''
    color_formatter0.format_body(body=body0, mime=mime0)


# Generated at 2022-06-25 18:40:57.482320
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter_0 = ColorFormatter()

# Generated at 2022-06-25 18:41:08.265898
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter_0 = ColorFormatter(Environment(colors=256))
    color_formatter_0.format_headers('*')
    color_formatter_1 = ColorFormatter(Environment(colors=256))
    color_formatter_1.format_headers('')
    color_formatter_2 = ColorFormatter(Environment(colors=256))
    color_formatter_2.format_headers('?J')
    color_formatter_3 = ColorFormatter(Environment(colors=256))
    color_formatter_3.format_headers('c%')
    color_formatter_4 = ColorFormatter(Environment(colors=256))
    color_formatter_4.format_headers('*!C')
    color_formatter_5 = ColorFormatter(Environment(colors=256))


# Generated at 2022-06-25 18:41:19.329791
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    sol = Solarized256Style()
    f = ColorFormatter(None,color_scheme=SOLARIZED_STYLE)
    f.formatter = Terminal256Formatter(style=sol)
    f.http_lexer = SimplifiedHTTPLexer()
    ans = f.format_headers("GET / HTTP/1.1\r\nhost:example.com\r\n\r\n")

# Generated at 2022-06-25 18:41:24.590954
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_syntax_processor_0 = ColorFormatter(Environment(''))
    assert color_syntax_processor_0.format_body('text/html','html') == 'html'
    assert color_syntax_processor_0.format_body('text/plain','text') == 'text'
    assert color_syntax_processor_0.format_body('application/json','json') == 'json'
    assert color_syntax_processor_0.format_body('application/xml','xml') == 'xml'
    assert color_syntax_processor_0.format_body('text/xml','xml') == 'xml'
    assert color_syntax_processor_0.format_body('image/bmp','Error') == 'Error'


# Generated at 2022-06-25 18:41:30.459761
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    json.loads('{"a":1,"b":2}')
    # Example of function call
    # ret = ColorFormatter.format_body(body = '{"a":1,"b":2}', mime = 'application/json')



# Generated at 2022-06-25 18:41:42.646552
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()

# Generated at 2022-06-25 18:41:44.698118
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    c = ColorFormatter(env=None)
    c.get_style_class('solarized')


# Generated at 2022-06-25 18:41:48.691199
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json=False
    color_scheme=DEFAULT_STYLE
    formatter = ColorFormatter(env,explicit_json,color_scheme)


# Generated at 2022-06-25 18:41:58.618072
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    assert not hasattr(simplified_h_t_t_p_lexer_0, 'tokens')
    assert simplified_h_t_t_p_lexer_0.name == 'HTTP'
    assert simplified_h_t_t_p_lexer_0.aliases == ['http']
    assert simplified_h_t_t_p_lexer_0.filenames == ['*.http']
    assert len(simplified_h_t_t_p_lexer_0.tokens['root']) == 3
    simplified_h_t_t_p_lexer_1 = SimplifiedHTTPLexer()

# Generated at 2022-06-25 18:42:12.865100
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:42:19.030458
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    print('Test: test_SimplifiedHTTPLexer()')
    solarized256style_0 = Solarized256Style()
    solarized256style_1 = Solarized256Style()
    colorformatter_0 = ColorFormatter(environ_0, explicit_json=False, color_scheme=DEFAULT_STYLE)
    colorformatter_0.get_lexer_for_body('', '')
    colorformatter_0.get_style_class('auto')
    colorformatter_0.format_headers('=')
    colorformatter_0.format_body('')



# Generated at 2022-06-25 18:42:20.510782
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:42:24.017459
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    testColorFormatter = ColorFormatter(env=None, explicit_json=False, color_scheme='', **{})
    assert testColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')

# Generated at 2022-06-25 18:42:31.820443
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Class to test:
    color_formatter_0 = ColorFormatter(env=None, explicit_json=False, color_scheme='auto')
    # Multiple asserts here
    # Return type tests
    assert isinstance(color_formatter_0.get_lexer_for_body("foo", "foo"), Optional)
    assert isinstance(color_formatter_0.get_lexer_for_body("foo", "foo"), Type)
    # Return value tests
    assert color_formatter_0.get_lexer_for_body("foo", "foo") is None
    # Return value tests
    assert color_formatter_0.get_lexer_for_body("foo", "foo") is None

# Generated at 2022-06-25 18:42:40.092794
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # check that if a body is supplied and flag explicit json is on,
    # the formatter will try to use the json lexer
    json_string = """{
        "test": "hello",
        "foo": "world"
    }"""
    formatter = ColorFormatter(Environment(), explicit_json=True)
    lexer = formatter.get_lexer_for_body(
        mime='application/json',
        body=json_string
    )
    assert lexer == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-25 18:42:50.598180
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer(): 
    assert simplified_h_t_t_p_lexer_0.name == 'HTTP'
    assert simplified_h_t_t_p_lexer_0.aliases == ['http']
    assert simplified_h_t_t_p_lexer_0.filenames == ['*.http']

# Generated at 2022-06-25 18:42:52.333321
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter_0 = ColorFormatter()


# Generated at 2022-06-25 18:42:55.236097
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter_0 = ColorFormatter(Environment(colors=True))
    color_formatter_0.get_lexer_for_body('text/html', '')

# Generated at 2022-06-25 18:43:03.741793
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Setup
    color_formatter_0 = ColorFormatter(
        Environment()
    )
    color_formatter_1 = ColorFormatter(
        Environment()
    )
    color_formatter_2 = ColorFormatter(
        Environment()
    )
    env = Environment()
    explicit_json = False
    mime = 'application/dummy'
    body = 'dummy'
    expected_0 = 'dummy'
    expected_1 = 'dummy'
    expected_2 = 'dummy'
    # Exercise
    actual_0 = color_formatter_0.format_body(body, mime)
    actual_1 = color_formatter_1.format_body(body, mime)
    actual_2 = color_formatter_2.format_body(body, mime)
    # Verify

# Generated at 2022-06-25 18:43:24.819381
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime = str()
    body = str()
    color_formatter_0.get_lexer_for_body(mime, body)

# Generated at 2022-06-25 18:43:32.496414
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Arrange
    environment_0 = httpie.context.Environment()
    explicit_json = False
    color_scheme = "auto"
    # Act
    color_formatter_0 = ColorFormatter(environment_0, explicit_json, color_scheme)
    # Assert
    assert color_formatter_0.enabled
    assert color_formatter_0.formatter == TerminalFormatter()
    assert color_formatter_0.http_lexer.__class__.__name__ == "PygmentsHttpLexer"

# Generated at 2022-06-25 18:43:37.748158
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.get_style_class() == Solarized256Style

if __name__ == '__main__':
    test_case_0()
    test_ColorFormatter_get_style_class()

# Generated at 2022-06-25 18:43:42.180636
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_0)
    color_formatter_1.format_body("6-HT2v", "application/x-www-form-urlencoded")


# Generated at 2022-06-25 18:43:49.821520
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():

    # Test case 1
    z3 = SimplifiedHTTPLexer()
    assert z3.name == 'HTTP'
    assert z3.aliases == ['http']
    assert z3.filenames == ['*.http']

# Generated at 2022-06-25 18:43:58.857083
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    # SUT
    get_lexer_for_body = color_formatter_0.get_lexer_for_body

    body_0 = '{"time":"2017-02-12T20:26:17.000051543Z","msg":"finished streaming"}'
    lexer_0 = get_lexer_for_body('application/json', body_0)
    assert lexer_0 == pygments.lexers.get_lexer_by_name('json')

    body_0 = '<html></html>'
    lexer_0 = get_lexer_for_body('text/html', body_0)
    assert lexer_0 == pygments.lexers.get_lexer_by_

# Generated at 2022-06-25 18:44:05.195963
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme = "My name is "
    assert ColorFormatter.get_style_class(color_scheme)


import httpie.compat as module_1

import unittest
import test.test_httpie.test_compat as module_2



# Generated at 2022-06-25 18:44:16.586618
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.environment == environment_0
    assert color_formatter_0.explicit_json == False
    assert color_formatter_0.color_scheme == DEFAULT_STYLE
    
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1, True)
    assert color_formatter_1.environment == environment_1
    assert color_formatter_1.explicit_json == True
    assert color_formatter_1.color_scheme == DEFAULT_STYLE

    environment_2 = module_0.Environment()

# Generated at 2022-06-25 18:44:19.709311
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.format_body("application/json", "{}")


# Generated at 2022-06-25 18:44:23.513295
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import pygments.lexer as lexer_0
    lexer_1 = lexer_0.RegexLexer()
    simplified_http_lexer_0 = SimplifiedHTTPLexer()
    assert simplified_http_lexer_0 is not None


# Generated at 2022-06-25 18:45:00.121694
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = "abcd"
    mime_0 = "application/json"
    assert color_formatter_0.format_body(body_0, mime_0) == body_0


# Generated at 2022-06-25 18:45:07.148979
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer_0 = SimplifiedHTTPLexer()
    assert lexer_0.name == 'HTTP'
    assert lexer_0.aliases == ['http']
    assert lexer_0.filenames == ['*.http']
    tokens_0 = lexer_0.tokens
    assert tokens_0['root'][0][0] == '(A-Z)( )([^ ]+)( )(HTTP)(/)(d+\.d+)'


# Generated at 2022-06-25 18:45:16.897177
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = "GET / HTTP/1.1\r\nContent-Type: text/plain\r\n\r\n"
    assert color_formatter_0.format_headers(headers_0) == "\x1b[32mGET\x1b[0m \x1b[33m/\x1b[0m \x1b[34mHTTP/1.1\x1b[0m\r\n\x1b[33mContent-Type\x1b[0m: \x1b[36mtext/plain\x1b[0m\r\n\r\n"



# Generated at 2022-06-25 18:45:22.497422
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body = 'hello'
    mime = 'text/html'
    color_formatter_0.format_body(body, mime)

    body = 'hello'
    mime = 'application/json'
    color_formatter_0.format_body(body, mime)


# Generated at 2022-06-25 18:45:27.060000
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    """
    Method get_style_class of class ColorFormatter
    """
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

    assert color_formatter_0.get_style_class('solarized256') == Solarized256Style


# Generated at 2022-06-25 18:45:36.664456
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    headers = """HTTP/1.1 200 OK
X-XSS-Protection: 1; mode=block
X-Frame-Options: sameorigin
Content-Type: text/html; charset=utf-8
ETag: W/"1866-1487339048000"
Cache-Control: private, max-age=0
X-Request-Id: 6b4a72b0-5b5c-45e1-bbd4-f47fc9c8b300
X-Runtime: 0.017566
Vary: Origin
Transfer-Encoding: chunked
Date: Mon, 17 Apr 2017 13:20:48 GMT
"""

# Generated at 2022-06-25 18:45:47.910560
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # 1. If the environment variable $NO_COLOR is set
    # 1.1. expect the ColorFormatter to be disabled
    module_0.Environment.terminal_supports_colors = lambda self, x: self.colors > 0
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0 == False  # Implementation
    # 1.2. expect the ColorFormatter to be disabled
    module_0.Environment.terminal_supports_colors = lambda self, x: self.colors == 0
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0 == False  # Implementation
    # 2. If the environment variable $NO_COLOR

# Generated at 2022-06-25 18:45:55.611423
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Check if lexer_for_body returns the correct lexer
    assert type(ColorFormatter(Environment()).get_lexer_for_body(
        "application/json", "")) == pygments.lexers.get_lexer_by_name('json')

    # Check if lexer_for_body returns the correct lexer
    assert type(ColorFormatter(Environment()).get_lexer_for_body(
        "application/javascript", "")) == pygments.lexers.get_lexer_by_name('javascript')

    # Check if lexer_for_body returns the correct lexer
    assert type(ColorFormatter(Environment()).get_lexer_for_body(
        "application/xml", "")) == pygments.lexers.get_lexer_by_name('xml')

    # Check if lexer_

# Generated at 2022-06-25 18:46:05.721034
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = ''
    
    expected = None
    actual = color_formatter_0.get_lexer_for_body('application/json', body_0)
    assert expected == actual
    body_1 = ''
    
    expected = None
    actual = color_formatter_0.get_lexer_for_body('application/javascript', body_1)
    assert expected == actual
    body_2 = ''
    
    expected = None
    actual = color_formatter_0.get_lexer_for_body('text/javascript', body_2)
    assert expected == actual
    body_3 = ''
    
    expected = None
    actual = color_formatter_0.get_

# Generated at 2022-06-25 18:46:12.576709
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = ''
    color_formatter_0.format_headers(headers_0)
    headers_1 = 'GET / HTTP/1.1\nHost: example.org\nAccept: */*'
    color_formatter_0.format_headers(headers_1)
    headers_2 = 'HTTP/1.1 200 OK'
    color_formatter_0.format_headers(headers_2)


# Generated at 2022-06-25 18:46:49.023517
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    SimplifiedHTTPLexer(color_formatter_0)

# Generated at 2022-06-25 18:46:55.299465
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0, color_scheme=SOLARIZED_STYLE)
    class_0 = color_formatter_0.get_style_class(color_scheme=SOLARIZED_STYLE)
    class_1 = color_formatter_0.get_style_class(color_scheme=DEFAULT_STYLE)


# Generated at 2022-06-25 18:47:02.862473
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():

    environment = module_0.Environment()
    color_formatter = ColorFormatter(environment)

    # Test 0
    # test_case_0
    mime = 'application/json'
    body = '{"foo": "bar"}'
    test_result = color_formatter.format_body(mime, body)
    assert test_result == '{\n    "foo": "bar"\n}'

    # Test 1
    # test_case_1
    mime = 'text/plain'
    body = '123 456'
    test_result = color_formatter.format_body(mime, body)
    assert test_result == '123 456'


# Generated at 2022-06-25 18:47:08.035352
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.enabled == True
    assert color_formatter_0.formatter == module_0.TerminalFormatter()
    assert color_formatter_0.http_lexer == module_0.SimplifiedHTTPLexer()



# Generated at 2022-06-25 18:47:11.565520
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = 'manni'
    color_formatter_0.get_style_class(color_scheme_0)


# Generated at 2022-06-25 18:47:15.197534
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('foo/bar') == TextLexer
    assert get_lexer('foo/json') == TextLexer
    assert get_lexer('foo/json', body=':)') == TextLexer
    assert get_lexer('foo/json', body='{}') != TextLexer


# Generated at 2022-06-25 18:47:17.505560
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Test for case 0 of constructor
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)


# Generated at 2022-06-25 18:47:24.025898
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = '''HTTP/1.1 200 OK\r\nX-XSS-Protection: 1; mode=block\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Length: 460\r\n\r\n'''
    color_formatter_0.format_headers(headers_0)

import httpie.output as module_1


# Generated at 2022-06-25 18:47:29.123061
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

    color_scheme = 'some style name'
    exception_0 = None
    try:
        color_formatter_0.get_style_class(color_scheme)
    except Exception as e_0:
        exception_0 = e_0

    assert exception_0 is not None

# Generated at 2022-06-25 18:47:30.923278
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # No exception
    SimplifiedHTTPLexer()



# Generated at 2022-06-25 18:48:57.885180
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Arrange
    body_0 = '<p>Some HTML</p>'
    mime_0 = 'text/html'
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)
    # Act
    actual_result_0 = color_formatter_1.format_body(body_0, mime_0)
    # Assert
    assert actual_result_0 == '<p>Some HTML</p>'


# Generated at 2022-06-25 18:49:02.944852
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = 'k<&gdn'
    mime_0 = 'application/javascript'
    color_formatter_0.format_body(body_0, mime_0)
    body_1 = '6:0Gv'
    mime_1 = 'text/plain'
    color_formatter_0.format_body(body_1, mime_1)

test_case_0()
test_ColorFormatter_format_body()