

# Generated at 2022-06-25 18:39:12.063304
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    dict_0 = None
    color_formatter_0 = ColorFormatter(**dict_0)
    dict_1 = None
    dict_0 = dict_1
    color_formatter_0 = ColorFormatter(**dict_0)
    dict_0 = dict_0
    str_0 = None
    str_1 = ''
    mime = str_0
    body = str_1
    color_formatter_0.get_lexer_for_body(mime, body)



# Generated at 2022-06-25 18:39:23.599731
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env_0 = Environment(colors=256)
    color_formatter_0 = ColorFormatter(env_0, explicit_json=False, color_scheme=DEFAULT_STYLE)
    env_1 = Environment(colors=256)
    color_formatter_1 = ColorFormatter(env_1, explicit_json=True, color_scheme=DEFAULT_STYLE)
    env_2 = Environment(colors=256)
    color_formatter_2 = ColorFormatter(env_2, explicit_json=False, color_scheme=SOLARIZED_STYLE)
    env_3 = Environment(colors=256)
    color_formatter_3 = ColorFormatter(env_3, explicit_json=True, color_scheme=SOLARIZED_STYLE)
   

# Generated at 2022-06-25 18:39:29.365249
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    dict_0 = None
    environment_0 = Environment(dict_0)
    assert environment_0 != None

    boolean_0 = False
    environment_0 = Environment(boolean_0)
    assert environment_0 != None

    dict_0 = None
    color_formatter_0 = ColorFormatter(**dict_0)
    assert color_formatter_0 != None

    environment_0 = Environment(dict_0)
    boolean_0 = False
    color_formatter_0 = ColorFormatter(environment_0, boolean_0)
    assert color_formatter_0 != None


# Generated at 2022-06-25 18:39:33.973637
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    dict_0 = {'explicit_json': False, 'color_scheme': 'default', 'env': ValueError()}
    color_formatter_0 = ColorFormatter(**dict_0)
    str_0 = 'Accept-Ranges: none'
    str_1 = color_formatter_0.format_headers(str_0)
    assert str_1 == 'Accept-Ranges: none'


# Generated at 2022-06-25 18:39:37.457232
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Fixtures
    color_scheme = 'solarized'
    # Setup
    color_formatter_0 = ColorFormatter(**None)
    # Exercise the SUT
    style_class = color_formatter_0.get_style_class(color_scheme)
    # Verify
    assert style_class is Solarized256Style


# Generated at 2022-06-25 18:39:48.258674
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    dict_0 = dict()
    dict_0['env'] = Environment()
    dict_0['env'].colors = 256
    dict_0['color_scheme'] = 'fruity'
    color_formatter_0 = ColorFormatter(**dict_0)
    headers_0 = "GET / HTTP/1.1\r\n"

# Generated at 2022-06-25 18:39:52.516889
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Test case for method format_headers
    args = {}
    kwargs = {
        'headers': 'string_0'
    }
    color_formatter_0 = ColorFormatter(**args)
    color_formatter_0.format_headers(**kwargs)


# Generated at 2022-06-25 18:39:53.376174
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    pass


# Generated at 2022-06-25 18:40:03.857409
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    response = '{"errors":["error 1","error 2"]}'
    json_str = '{"errors": ["error 1", "error 2"]}'

    # Test case 1
    color_formatter = ColorFormatter(environment = None, explicit_json = True, color_scheme = 'solarized')
    color_formatter.formatter.color_scheme = 'solarized'
    color_formatter.formatter.color_scheme_map['Token.Literal.String.Double'] = "#00afaf"
    color_formatter.formatter.color_scheme_map['Token.Text'] = "#8a8a8a"
    color_formatter.formatter.color_scheme_map['Name.Tag'] = "#d75f00"
    color_formatter.formatter.color_scheme_map

# Generated at 2022-06-25 18:40:06.191111
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter_0 = ColorFormatter(**dict_0)
    color_formatter_0.get_lexer_for_body(**dict_0)

# Generated at 2022-06-25 18:40:22.823230
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    tuple_0 = ("text/plain", "")
    str_0 = "text/plain"
    str_1 = ""
    str_2 = str_1
    str_3 = str_2
    str_4 = str_3
    str_5 = str_4
    str_6 = str_5
    str_7 = str_6
    str_8 = str_7
    str_9 = str_8
    str_10 = str_9
    str_11 = str_10
    str_12 = str_11
    str_13 = str_12
    str_14 = str_13

# Generated at 2022-06-25 18:40:26.684006
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():

    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    
    # call the method
    color_formatter_0.format_headers()


# Generated at 2022-06-25 18:40:29.760507
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    try:
        global pygments_lexer_2
        pygments_lexer_2 = SimplifiedHTTPLexer()
    except Exception as e:
        print('Failed to call __init__ of class replaced_SimplifiedHTTPLexer')
        print(e)


# Generated at 2022-06-25 18:40:41.250267
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    assert color_formatter_0.get_lexer_for_body(mime='text/foo', body='Hello') is None
    assert color_formatter_0.get_lexer_for_body(mime='text/foo', body='{"foo": "bar"}') is not None
    assert color_formatter_0.get_lexer_for_body(mime='text/html', body='{"foo": "bar"}') is not None
    assert color_formatter_0.get_lexer_for_body(mime='application/json', body='{"foo": "bar"}') is not None
    assert color_formatter_

# Generated at 2022-06-25 18:40:43.541856
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
  assert ColorFormatter.get_style_class(**{}) == Solarized256Style, "Expected different result"





# Generated at 2022-06-25 18:40:48.188711
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    str_0 = ''
    str_1 = ''
    assert color_formatter_0.format_body(str_0, str_1) == ''


# Generated at 2022-06-25 18:40:52.603286
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    color_scheme_0 = "red"
    style_class_0 = color_formatter_0.get_style_class(color_scheme_0)
    style_class_0 = color_formatter_0.get_style_class("red")

# Generated at 2022-06-25 18:40:54.476448
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    assert color_formatter_0.formatter.style is None

# Generated at 2022-06-25 18:41:04.863476
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)

    color_formatter_0.get_lexer_for_body('application/json', '{"key": 12345}')
    assert pygments.lexers.get_lexer_by_name('json') == pygments.lexers.get_lexer_by_name('json')
    assert pygments.lexers.get_lexer_by_name('json') != pygments.lexers.get_lexer_by_name('json')
    assert pygments.lexers.get_lexer_by_name('json') == pygments.lexers.get_lexer_by_name('json')
    assert pygments.lexers.get

# Generated at 2022-06-25 18:41:07.213146
# Unit test for function get_lexer
def test_get_lexer():
    assert hasattr(get_lexer(), '__call__')
    print("Test of function `get_lexer` in class `ColorFormatter` passed")

# Generated at 2022-06-25 18:41:19.771004
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    dict_0 = {}
    name_0 = "HTTP"
    aliases_0 = ["http"]
    filenames_0 = ["*.http"]
    tokens_0 = {}
    simplified_http_lexer_0 = SimplifiedHTTPLexer(**dict_0)



# Generated at 2022-06-25 18:41:24.019458
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    headers_0 = ''
    assert color_formatter_0.format_headers(headers_0) == ''

# Generated at 2022-06-25 18:41:33.498883
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    headers = "REQUEST_HEADERS"
    body = "REQUEST_BODY"
    mime = 'text/csv'
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    color_formatter_0.format_body(body, mime)
    color_formatter_0.format_body(body, mime)
    color_formatter_0.format_headers(headers)

# Generated at 2022-06-25 18:41:39.940722
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert type(SimplifiedHTTPLexer) == type
    assert issubclass(SimplifiedHTTPLexer, pygments.lexers.text._HttpLexer)
    assert not issubclass(SimplifiedHTTPLexer, pygments.style.Style)
    assert SimplifiedHTTPLexer.__module__ == 'httpie.plugins.colors'


# Generated at 2022-06-25 18:41:45.321936
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    string_0 = ''
    try:
        color_formatter_0.format_headers(string_0)
    except Exception as exception_0:
        print('Exception caught:', str(exception_0))


# Generated at 2022-06-25 18:41:50.773026
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    body_0 = "foo"
    mime_0 = "application/json"
    color_formatter_0.format_body(body_0, mime_0)
    color_formatter_0.format_body(body_0, mime_0)
    color_formatter_0.format_body(body_0, mime_0)


# Generated at 2022-06-25 18:41:53.858819
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    color_formatter_0.http_lexer = SimplifiedHTTPLexer()
    string_0 = "application/json"
    string_1 = "{}"
    assert color_formatter_0.format_body(string_0,string_1) == ""



# Generated at 2022-06-25 18:42:00.911336
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    str_0 = "Test"
    str_1 = color_formatter_0.format_headers(str_0)


# Generated at 2022-06-25 18:42:04.398565
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    string_0 = color_formatter_0.format_headers(string_0)


# Generated at 2022-06-25 18:42:08.370270
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    color_formatter_0 = ColorFormatter(environment_0, **dict_0)
    str_0 = 'Response: 201'
    assert color_formatter_0.format_headers(str_0) == '\x1b[90mResponse: 201\x1b[39m\x1b[39m'


# Generated at 2022-06-25 18:43:04.679970
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    str_0 = "0   "
    str_1 = "8W\x0c1e\x14\t\x06\x1c\x0b\x19\x17\x0e\x1d\x07\x0f\x1e\x0c\x15\x0a"
    str_2 = "PNz"
    str_3 = "C5"
    str_4 = "ADr"
    str_5 = "'R"
    str_6 = "q3.\x0f\x1f"
    str_7 = "p-Y\x14\x1d"
    boolean_0 = False
    str_8 = "7V"
    str_9 = "B_"
    str_10 = "ZD"

# Generated at 2022-06-25 18:43:12.050462
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Case 1
    input_1 = 'auto'
    expected_result_1 = pygments.styles.get_style_by_name('auto')
    actual_result_1 = ColorFormatter.get_style_class(input_1)
    assert expected_result_1 == actual_result_1

    # Case 2
    input_2 = 'solarized'
    expected_result_2 = Solarized256Style
    actual_result_2 = ColorFormatter.get_style_class(input_2)
    assert expected_result_2 == actual_result_2


# Generated at 2022-06-25 18:43:15.917410
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    str_0 = "VvRj\x0c/x'+Z^[W7C&-"
    optional_0 = get_lexer(str_0)
    test_case_0()

# It seems that the string returned by `assert_equals.__name__`
# is always `0`

# Generated at 2022-06-25 18:43:21.686181
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class_ColorFormatter = ColorFormatter(None, False, "")
    str_0 = "\x03\x19\x00\x00\x02\x00\x01\x00\x04\x00\x10\x00\x0c\x00"
    class_object_0 = class_ColorFormatter.format_headers(str_0)


# Generated at 2022-06-25 18:43:26.075682
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = "VvRj\x0c/x'+Z^[W7C&-"
    automatic_0 = ColorFormatter.format_body(str_0, str_0)
    return automatic_0


# Generated at 2022-06-25 18:43:28.968564
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class('asd')
    assert style_class is not None
    assert style_class == Solarized256Style


# Generated at 2022-06-25 18:43:32.169171
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter = ColorFormatter(NONE,False,AUTO_STYLE,False,True)
    assert color_formatter.format_headers("test") == 'test'


# Generated at 2022-06-25 18:43:34.836548
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    obj = ColorFormatter()
    param_0 = 'h_0'
    ret_val_0 = obj.format_headers(param_0)


# Generated at 2022-06-25 18:43:39.202119
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    state_0 = Environment(colors=10)
    explicit_json_0 = True
    color_scheme_0 = 'solarized'
    test_obj = ColorFormatter(state_0, explicit_json_0, color_scheme_0)
    print(test_obj)

# Generated at 2022-06-25 18:43:48.475081
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = "Q!s\x03\x0e\x0f\x1a\x0b"
    optional_0 = get_lexer(str_0)
    str_1 = "\"\x1d\x1eJ\x1e"
    optional_1 = get_lexer(str_1)
    str_2 = "Z\x17A\x1e\x15"
    optional_2 = get_lexer(str_2)
    str_3 = "q\x07\x1b\x17\\\x06\x1e\x0c\x19\x01\x07\x08\x1c\"\x1d\x1eJ\x1e\x19\x0b\x16\x17\x19\x1f"
   

# Generated at 2022-06-25 18:44:09.715718
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    explicit_json = False
    color_scheme = "hi"
    x=ColorFormatter(env, explicit_json, color_scheme)

    headers = "hi"
    x.format_headers(headers)


# Generated at 2022-06-25 18:44:18.946013
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print("test ColorFormatter...")
    str = "VvRj\x0c/x'+Z^[W7C&-"
    lexer = get_lexer(str)
    # test argument type
    obj = ColorFormatter(None, lexer, lexer, lexer)
    # test attributes
    if obj and obj.formatter:
        print("formatter in ColorFormatter!")
    else:
        print("attribute formatter not found in ColorFormatter!")
    if obj and obj.http_lexer:
        print("http_lexer in ColorFormatter!")
    else:
        print("attribute http_lexer not found in ColorFormatter!")


if __name__ == "__main__":
    test_case_0()
    test_ColorFormatter()

# Generated at 2022-06-25 18:44:28.430383
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Create an instance of class ColorFormatter.
    test_obj = ColorFormatter()

    # Variable used to store the result of method format_body of class ColorFormatter
    test_obj_result = None

    # Variable used to store the expected result of method format_body of class ColorFormatter
    test_obj_expected = None

    # Test method format_body of class ColorFormatter.
    test_obj_result = test_obj.format_body("\x0b^\x12\x1e\x11\x16h\x01\x1c\x06\x1e\x06\x1e\x0e\x1f\x17", "Z")

# Generated at 2022-06-25 18:44:39.414208
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = "VvRj\x0c/x'+Z^[W7C&-"
    bool_0 = True
    str_1 = "\\"
    bool_1 = False
    s_0 = 'k'
    int_0 = 0
    float_0 = float(int_0)
    float_1 = float(int_0)
    int_1 = 0
    int_2 = 0
    int_3 = 0
    float_2 = float(int_3)
    float_3 = float(int_3)
    int_4 = 0
    int_5 = 0
    float_4 = float(int_5)
    float_5 = float(int_5)
    float_6 = float(int_5)
    float_7 = float(int_5)
    float

# Generated at 2022-06-25 18:44:46.951555
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Init instance
    str_0 = '<a\x00href="http://foo.bar/?a=b&c=d">'
    float_0 = float('-inf')
    float_1 = float('inf')
    float_2 = float('-inf')
    float_3 = float('inf')
    float_4 = float('-inf')
    float_5 = float('inf')
    float_6 = float('-inf')
    float_7 = float('inf')
    float_8 = float('-inf')
    float_9 = float('inf')
    float_10 = float('-inf')
    float_11 = float('inf')
    float_12 = float('-inf')
    float_13 = float('inf')
    float_14 = float('-inf')

# Generated at 2022-06-25 18:44:50.539608
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    str_0 = 'zm_\x1b'
    optional_0 = ColorFormatter.get_lexer_for_body(str_0, 'qKj\x1d')


# Generated at 2022-06-25 18:44:59.539798
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = "GmdZ\x1d\x03|N7>fIx^yM\x10=&\x1d\x0e\x1d\x0f\x0e\x00g\x1e\x00\x05\x1e\x1a\x1d\x03\x1e\x00\x1a\x00\x00\x1e\x00\x1a\x03\x00\x03\x1d\x00\x1e\x1d\x04\x03\x1d\x1b'\x1e\x04\x1d\x1d\x00\x1a\x00"
    ColorFormatter_0 = ColorFormatter(str_0)

# Generated at 2022-06-25 18:45:04.873463
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    str_0 = "4'j\x7f\xa6\xeb\x12\x1f\xcc\xf6~\x84"
    assert ColorFormatter.get_style_class(str_0) == Solarized256Style


# Generated at 2022-06-25 18:45:08.348033
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    assert http_lexer.name == 'HTTP'
    assert http_lexer.aliases == ['http']
    assert http_lexer.filenames == ['*.http']
    assert isinstance(http_lexer.tokens, dict)


# Generated at 2022-06-25 18:45:13.021866
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Test Data:
    str_0 = "k#:fB,h!{=>5R,]vFF0"
    str_1 = "q&,0MC|}'z^\x0b_o&[#"
    # Test Procedure:
    test_result = ColorFormatter.get_lexer_for_body(str_0, str_1)



# Generated at 2022-06-25 18:45:49.111324
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    optional_0 = ColorFormatter.get_style_class("auto")


# Generated at 2022-06-25 18:45:57.740191
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(Environment())
    str_0 = "VvRj\x0c/x'+Z^[W7C&-"
    str_1 = '-\x7f\x00\x0c\x05\x1c\x03'
    str_2 = 'VvRj\x0c/x'
    str_3 = '\x0c'
    str_4 = '\x1c\x03'
    str_5 = '\x7f\x00'
    str_6 = '+Z^[W7C&-'
    str_7 = '-\x7f\x00\x0c\x05\x1c\x03'
    str_8 = '\x1c\x03'

# Generated at 2022-06-25 18:46:01.027859
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    str_0 = "VvRj\x0c/x'+Z^[W7C&-"
    test_0 = ColorFormatter(str_0)
    assert test_0.explicit_json == True
    assert test_0.enabled == True


# Generated at 2022-06-25 18:46:11.135850
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    obj = ColorFormatter(Environment(), explicit_json=False, color_scheme=SOLARIZED_STYLE)
    mime = 'application/json'
    body = '{"test": "pass"}'
    expected = '\x1b[38;5;2m{\x1b[39m\x1b[38;5;2m"test"\x1b[39m\x1b[38;5;2m:\x1b[39m\x1b[38;5;2m"pass"\x1b[39m\x1b[38;5;2m}\n\x1b[39m'
    assert(expected == obj.format_body(body, mime))


# Generated at 2022-06-25 18:46:12.062217
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    test_case_0()


# Generated at 2022-06-25 18:46:13.247067
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter.group_name == 'colors'


# Generated at 2022-06-25 18:46:21.842403
# Unit test for function get_lexer
def test_get_lexer():
    str_0 = "VvRj\x0c/x'+Z^[W7C&-"
    get_lexer(str_0)
    str_0 = "rQwDt\x06(Je)HFn-;8H?W"
    str_1 = "Pp'=8\x081>A^-aQ2"

# Generated at 2022-06-25 18:46:28.342289
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():

    # Create the object to be tested
    object_to_be_tested = ColorFormatter(explicit_json, color_scheme, **kwargs)

    # The method to be tested is decorated, so we need to get the underlying function
    function_to_be_tested = object_to_be_tested.format_headers.__func__

    # Create the parameters to be passed to the function
    headers = None

    # Call the function
    result = function_to_be_tested(object_to_be_tested, headers)

    # Check the result
    assert result == None


# Generated at 2022-06-25 18:46:33.351826
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment = Environment()
    variable_str_0 = 'application/json'
    variable_str_1 = '{}'
    variable_bool_0 = False
    variable_0 = ColorFormatter(
        environment,
        variable_bool_0,
        'fruity'
    )
    variable_0.get_lexer_for_body(variable_str_0, variable_str_1)


# Generated at 2022-06-25 18:46:33.928251
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert True

# Generated at 2022-06-25 18:47:57.370613
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    str_0 = "VvRj\x0c/x'+Z^[W7C&-"
    optional_0 = get_lexer(str_0)

# Generated at 2022-06-25 18:48:01.700123
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Build the arguments to pass to the test function
    optional_0 = get_lexer("")
    # Invoke the function
    test_SimplifiedHTTPLexer_0(optional_0)


# Generated at 2022-06-25 18:48:07.810037
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = "zN;\x1b }j\x0c\x1e"
    str_1 = "y=/V|\x0f~8\x18_6"

    # Test for case 0 and 1
    expected_0 = None
    expected_1 = ""
    assert get_lexer(str_0, False, str_1) == expected_0
    assert get_lexer(str_0, True, str_1) == expected_1


# Generated at 2022-06-25 18:48:13.979084
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    print()
    optional_0 = ColorFormatter(Environment(colors=256))
    str_0 = "VvRj\x0c/x'+Z^[W7C&-"
    optional_1 = optional_0.get_lexer_for_body(str_0, str_0)
    return optional_1


# Generated at 2022-06-25 18:48:17.264574
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    str_0 = "Mk-n<{6.` W6TfT"
    enum_0 = SimplifiedHTTPLexer(str_0)


# Generated at 2022-06-25 18:48:21.679046
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = '{"key":"value"}'
    result_1 = ColorFormatter.format_body(str_0)
    assert result_1 == '<span style="color: #00afaf;">{"key":"value"}</span>'


if __name__ == '__main__':
    test_case_0()
    
    test_ColorFormatter_format_body()

# Generated at 2022-06-25 18:48:26.205455
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    input_0 = "xj\x0b{*y|,?F\"t\x14\x10"
    value_0 = get_lexer_for_body(input_0)


# Generated at 2022-06-25 18:48:36.573322
# Unit test for method format_body of class ColorFormatter

# Generated at 2022-06-25 18:48:38.917975
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    CF_obj = ColorFormatter(None)
    CF_obj.format_headers("")


# Generated at 2022-06-25 18:48:46.621386
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    str_0 = "S\x01\x1d\x18\x1d\x06"
    formatter_0 = ColorFormatter(None, False)
    formatter_0.http_lexer = SimplifiedHTTPLexer()
    formatter_0.formatter = Terminal256Formatter(Solarized256Style)
    formatter_0.header_indent = 1
    formatter_0.explicit_json = 1
    res = formatter_0.format_body(str_0, "application/json")
    assert res == "S\x01\x1d\x18\x1d\x06"
