

# Generated at 2022-06-25 18:39:15.606385
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True)
    f = ColorFormatter(env=env)


# Generated at 2022-06-25 18:39:18.845167
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter_obj = ColorFormatter(Environment())
    color_formatter_obj.get_style_class(DEFAULT_STYLE)

# Generated at 2022-06-25 18:39:25.998333
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    assert (ColorFormatter.format_body(simplified_h_t_t_p_lexer_0,
                                                                "application/json",
                                                                "// Sample URL: http://www.arcgis.com/sharing/rest/content/items/00d49817e2c44ccc80dc37807f8d8b4b/data")
                                                                is
                                                                "[ { 'name' : 'Sample' } ]")

# Generated at 2022-06-25 18:39:30.395599
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:39:34.616942
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert len(SimplifiedHTTPLexer.name) > 0
    assert len(SimplifiedHTTPLexer.aliases) > 0
    assert len(SimplifiedHTTPLexer.filenames) > 0
    assert len(SimplifiedHTTPLexer.tokens) > 0


# Generated at 2022-06-25 18:39:36.064021
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()

# Generated at 2022-06-25 18:39:45.296793
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment(colors=256)
    color_formatter_1 = ColorFormatter(env)
    # assert ColorFormatter.get_style_class(color_formatter_1, color_scheme='auto') == Solarized256Style
    color_formatter_2 = ColorFormatter(env, color_scheme='solarized')
    # assert ColorFormatter.get_style_class(color_formatter_2, color_scheme='solarized') == Solarized256Style
    color_formatter_3 = ColorFormatter(env, color_scheme='default')
    # assert ColorFormatter.get_style_class(color_formatter_3, color_scheme='default') == Solarized256Style
    color_formatter_4 = ColorFormatter(env, color_scheme='fruity')
    #

# Generated at 2022-06-25 18:39:49.385566
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env)
    color_formatter.format_body("", "")



# Generated at 2022-06-25 18:39:53.490828
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment(colors=True, stdout_isatty=True)
    color_formatter_0 = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    style_class_0 = color_formatter_0.get_style_class(DEFAULT_STYLE)


# Generated at 2022-06-25 18:40:03.992936
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    assert simplified_h_t_t_p_lexer_0.name == 'HTTP'
    assert simplified_h_t_t_p_lexer_0.filenames == ['*.http']

# Generated at 2022-06-25 18:40:21.213511
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class_ = ColorFormatter
    with_ = {'env':Environment(colors=True), 'explicit_json':False, 'color_scheme':DEFAULT_STYLE}
    mime = 'application/json'
    body = '{test}'
    res = class_.get_lexer_for_body(mime=mime,body=body,**with_)
    assert isinstance(res,pygments.lexers.JsonLexer)

# Generated at 2022-06-25 18:40:23.692792
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style = ColorFormatter.get_style_class(SOLARIZED_STYLE)
    assert style == Solarized256Style

# Generated at 2022-06-25 18:40:24.604520
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():

    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()




# Generated at 2022-06-25 18:40:30.604081
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """
    Enables auto formatting of response body.
    """
    ColorFormatter(is_windows).format_body(body="",mime="")
    ColorFormatter(is_windows).format_body(body=None, mime="")

    # Tests for Content-Type text/*
    ColorFormatter(is_windows).format_body(body="", mime="text/html")
    ColorFormatter(is_windows).format_body(body="", mime="text/x-python")
    ColorFormatter(is_windows).format_body(body="", mime="text/*")
    ColorFormatter(is_windows).format_body(body="", mime="text")

    # Tests for Content-Type */json
    ColorFormatter(is_windows).format_body(body="", mime="application/json")
   

# Generated at 2022-06-25 18:40:32.613468
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment = Environment()
    color_formatter= ColorFormatter(env=environment)


# Generated at 2022-06-25 18:40:34.468274
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    color_formatter = ColorFormatter(env)

# Generated at 2022-06-25 18:40:38.001840
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(vars(Environment()))
    assert ColorFormatter(vars(Environment()), explicit_json=True)
    assert ColorFormatter(vars(Environment()), color_scheme='solarized')


# Generated at 2022-06-25 18:40:45.532065
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # pygments.lexers.text
    body = 'HTTP/1.0 200 OK\r\nCache-Control: max-age=0\r\n\r\nok\r\n'
    mime = 'http'
    color_formatter_0 = ColorFormatter(env=None, explicit_json=False, color_scheme=DEFAULT_STYLE)
    color_formatter_0.format_body(body=body, mime=mime)


# Generated at 2022-06-25 18:40:52.709876
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime="application/json", explicit_json=False, body='') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer(mime="application/xml", explicit_json=False, body='') == pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer(mime="text/html", explicit_json=False, body='') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer(mime="text/plain", explicit_json=False, body='') == pygments.lexers.get_lexer_by_name('text')

# Generated at 2022-06-25 18:40:55.419848
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter_0 = ColorFormatter()
    color_scheme_0 = 'kate'

    try:
        color_formatter_0.get_style_class(color_scheme_0)
    except ClassNotFound:
        assert True
    else:
        assert False


# Generated at 2022-06-25 18:41:23.977685
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.cli import parser
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    # Test for body with json that has an incorrect Content-Type
    with http('--print=H', 'GET', httpbin.url + '/get',
              env=Environment(stdin_isatty=True, colors=256)) as result:
        assert HTTP_OK in result

# Generated at 2022-06-25 18:41:33.848754
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # mime body
    mime = 'application/json'
    body = ''
    # expected output
    expected_output = None

    # create instance of class ColorFormatter
    color_formatter_instance = ColorFormatter()

    # get instance of method get_lexer_for_body from class ColorFormatter
    method = color_formatter_instance.get_lexer_for_body

    # assert that output of method get_lexer_for_body from class ColorFormatter is as expected
    assert method(mime = mime, body = body) == expected_output

# Generated at 2022-06-25 18:41:37.745526
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    # calling ColorFormatter constructor
    ColorFormatter(env, explicit_json, color_scheme)



# Generated at 2022-06-25 18:41:41.614083
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter_1 = ColorFormatter(None, False)
    color_scheme_1 = '1'
    color_formatter_1.get_style_class(color_scheme_1)

# Generated at 2022-06-25 18:41:44.853905
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(env)
    pygments.lexers.get_lexer_for_mimetype(mime_type='text/html')


# Generated at 2022-06-25 18:41:49.003065
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    assert simplified_h_t_t_p_lexer_0.name == 'HTTP'
    assert simplified_h_t_t_p_lexer_0.aliases == ['http']
    assert simplified_h_t_t_p_lexer_0.filenames == ['*.http']


# Generated at 2022-06-25 18:41:55.516713
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    try:
        color_formatter_0 = ColorFormatter(
            env='env_arg',
            explicit_json='explicit_json_arg',
            color_scheme='color_scheme_arg'
        )
    except Exception as e:
        print("Failed to create test instance of class ColorFormatter:", e)


if __name__ == '__main__':
    test_case_0()
    test_ColorFormatter()

# Generated at 2022-06-25 18:42:06.574161
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # The following source code was taken from a real HTTPie session:
    body = "{"
    body += "  \"args\": {},"
    body += "  \"headers\": {"
    body += "    \"Accept\": \"*/*\","
    body += "    \"Accept-Encoding\": \"gzip, deflate\","
    body += "    \"Connection\": \"close\","
    body += "    \"Host\": \"httpbin.org\","
    body += "    \"User-Agent\": \"HTTPie/0.9.9\""
    body += "  },"
    body += "  \"origin\": \"172.18.0.1\","
    body += "  \"url\": \"https://httpbin.org/get\""
    body += "}"
    mime = "application/json"
    expected_value = body
   

# Generated at 2022-06-25 18:42:15.104373
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie
    env = httpie.Environment()
    fp = ColorFormatter(env)
    mime = 'application/json'

# Generated at 2022-06-25 18:42:18.097371
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(Environment(colors=256), color_scheme="solarized")
    result = color_formatter.get_style_class("solarized")
    expected = Solarized256Style()
    assert result == expected

# Generated at 2022-06-25 18:42:29.237443
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    pygments_lexer_0 = SimplifiedHTTPLexer()

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-25 18:42:31.875001
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    formatter_plugin = None
    headers = ""
    with pytest.raises(TypeError):
        ColorFormatter.format_headers(formatter_plugin, headers)


# Generated at 2022-06-25 18:42:37.126880
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import httpie.context
    environment_0 = httpie.context.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = 'Custom: 1'
    output_0 = color_formatter_0.format_headers(headers_0)


# Generated at 2022-06-25 18:42:40.014346
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert ColorFormatter.get_lexer_for_body("application/json","") == pygments.lexers.get_lexer_by_name('json')


# Generated at 2022-06-25 18:42:46.295572
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.formatter, 'The instance attribute formatter should be set to a value other than None'
    assert color_formatter_0.http_lexer, 'The instance attribute http_lexer should be set to a value other than None'


import httpie.context as module_0


# Generated at 2022-06-25 18:42:50.427430
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = "GET http://www.google.com/"
    assert color_formatter_0.format_headers(headers_0) == "GET http://www.google.com/"


# Generated at 2022-06-25 18:43:00.602250
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)
    body = '{"name":"value"}'
    mime = 'application/json'
    assert (color_formatter_1.format_body(body, mime)
            == '{\n    {\n        "name": "value"\n    }\n}')

    color_formatter_2 = ColorFormatter(environment_1)
    body = '{"name":"value"}'
    mime = 'application/xml'
    assert (color_formatter_2.format_body(body, mime)
            == '<string xmlns="http://tempuri.org/">{"name":"value"}</string>')

    environment_3 = module_0.Environment()
    color_formatter_3 = Color

# Generated at 2022-06-25 18:43:05.207864
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.formatter = (
        pygments.formatters.terminal.TerminalFormatter()
    )
    color_formatter_0.http_lexer = SimplifiedHTTPLexer()
    color_formatter_0.enabled = True
    headers_0 = ''
    color_formatter_0.format_headers(headers_0)


# Generated at 2022-06-25 18:43:07.637693
# Unit test for function get_lexer
def test_get_lexer():
    assert ColorFormatter.get_lexer('test') is None
    assert ColorFormatter.get_lexer('') is None


# Generated at 2022-06-25 18:43:13.504902
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    body = ''
    mime = 'application/json'
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment=environment_1)
    assert color_formatter_1.get_lexer_for_body(mime, body) == None
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
# Test case for constructor of class ColorFormatter

# Generated at 2022-06-25 18:43:35.954868
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment(merge_headers=[])
    color_formatter_0 = ColorFormatter(environment_0)
    assert isinstance(color_formatter_0.get_lexer_for_body('mime', ''), Lexer)


# Generated at 2022-06-25 18:43:42.733890
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body = '{"hello": "world"}'
    mime = 'application/json'
    value_0 = color_formatter_0.format_body(body, mime)
    assert '\x1b[7m' in value_0
    assert '\x1b[27m' in value_0

# Generated at 2022-06-25 18:43:50.074853
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer.name == 'HTTP'
    assert SimplifiedHTTPLexer.aliases == ['http']
    assert SimplifiedHTTPLexer.filenames == ['*.http']

# Generated at 2022-06-25 18:43:53.995235
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.get_style_class("fruity")


# Generated at 2022-06-25 18:43:55.138782
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter_0 = ColorFormatter(environment_0)

# Generated at 2022-06-25 18:44:04.520666
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    string_0 = "{}"
    string_1 = "application/json"
    string_2 = color_formatter_0.format_body(string_0, string_1)
    print(string_2)
    string_3 = "{\"from\": \"httpbin.org\"}"
    string_4 = "application/json"
    string_5 = color_formatter_0.format_body(string_3, string_4)
    print(string_5)


# Generated at 2022-06-25 18:44:07.998585
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert type(color_formatter_0) == ColorFormatter


# Generated at 2022-06-25 18:44:12.532340
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers = 'HEADER1: HEADER2\r\nHEADER3: HEADER4\r\n'

    environment_0 = module_0.Environment(colors=256)
    color_formatter_0 = ColorFormatter(environment_0)
    
    assert "\x1b" not in color_formatter_0.format_headers(headers)


# Generated at 2022-06-25 18:44:17.248627
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = 'Accept: text-plain'
    assert type(color_formatter_0.format_headers(headers_0)) == str
    assert headers_0 == color_formatter_0.format_headers(headers_0)


# Generated at 2022-06-25 18:44:20.366937
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.get_style_class("abc")


# Generated at 2022-06-25 18:44:56.484025
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = "f"
    mime_0 = "application/json"
    assert color_formatter_0.format_body(body_0, mime_0) == "<span class='n'>f</span>"


# Generated at 2022-06-25 18:45:07.000075
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """
    Test format_body of ColorFormatter
    """
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    # /home/httpie/httpie/httpie/plugins/formatter/colors.py:201: str
    # /home/httpie/httpie/httpie/plugins/formatter/colors.py:200: str
    # /home/httpie/httpie/httpie/plugins/formatter/colors.py:199: str
    # /home/httpie/httpie/httpie/plugins/formatter/colors.py:220: 
    # (str, str)
    color_formatter_0.format_body("*", "*")


# Generated at 2022-06-25 18:45:16.519573
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter_0 = ColorFormatter(module_0.Environment())
    body_0 = '''<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<title>Redirecting...</title>
<h1>Redirecting...</h1>
<p>You should be redirected automatically to target URL: <a href="https://httpbin.org/anything/anything">https://httpbin.org/anything/anything</a>.  If not click the link.
'''
    mime_0 = 'text/html'
    result_0 = color_formatter_0.format_body(body_0, mime_0)
    assert result_0 is not None


# Generated at 2022-06-25 18:45:26.948042
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment(colors = False)
    color_formatter_0 = ColorFormatter(environment_0)
    assert type(color_formatter_0.format_headers("")) == str
    assert type(color_formatter_0.format_headers("")) == str
    assert type(color_formatter_0.format_headers("")) == str
    assert type(color_formatter_0.format_headers("")) == str
    assert type(color_formatter_0.format_headers("")) == str
    assert type(color_formatter_0.format_headers("")) == str
    assert type(color_formatter_0.format_headers("")) == str
    assert type(color_formatter_0.format_headers("")) == str

# Generated at 2022-06-25 18:45:33.363721
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    print("testing constructor of class SimplifiedHTTPLexer")
    url = "www.google.com/search?hl=en&cp=12&gs_id=1e&xhr=t&q=w3schools&es_nrs=true&pf=p&sclient=psy-ab&oq=w3schools&gs_l=&pbx=1&bav=on.2,or.r_gc.r_pw.r_qf.&fp=dcacfddfc0e0077c&bpcl=40096503&biw=1024&bih=673"

# Generated at 2022-06-25 18:45:39.837703
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)

    # Test if the body is unchanged when lexer is absent
    color_formatter_1.get_lexer_for_body = lambda mime: None
    mime = 'text/plain'
    body = 'HTTP/1.1 200 OK'
    expected = 'HTTP/1.1 200 OK'
    actual = color_formatter_1.format_body(body, mime)
    assert expected == actual


# Generated at 2022-06-25 18:45:49.013826
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():

    # Assign values to instance attributes of class SimplifiedHTTPLexer
    # http_lexer_0 = SimplifiedHTTPLexer()
    color_formatter_0 = ColorFormatter(http_lexer_0)
    color_formatter_0.format_headers("headers")
    color_formatter_0.format_body("body", "mime")
    color_formatter_0.get_lexer_for_body("mime", "body")
    color_formatter_0.get_style_class("color_scheme")
    color_formatter_0.format("data")


# Generated at 2022-06-25 18:45:57.615169
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # basic test
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body = "Hi there\n"
    mime = 'text/plain'
    temp = color_formatter_0.format_body(body, mime)
    assert(temp == '\x1b[1;37mHi there\n\x1b[0m')
    # basic test
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)
    body = "Hi there\n"
    mime = 'text/plain'
    temp = color_formatter_1.format_body(body, mime)

# Generated at 2022-06-25 18:46:00.599278
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.get_style_class('default') is Solarized256Style


# Generated at 2022-06-25 18:46:02.777986
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer is not None


# Generated at 2022-06-25 18:48:36.477634
# Unit test for function get_lexer
def test_get_lexer():
    body = """<html>
  <head>
    <title>Google</title>
  </head>
  <body>
    <p>Some text</p>
    <h1>Heading</h1>
  </body>
</html>"""
    # Request body is HTML
    assert isinstance(get_lexer('text/html', body=body), pygments.lexers.HtmlLexer)


# Generated at 2022-06-25 18:48:39.466902
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print('Unit test for constructor of class ColorFormatter')
    test_case_0()

if __name__ == '__main__':
    test_ColorFormatter()

# Generated at 2022-06-25 18:48:42.392501
# Unit test for function get_lexer
def test_get_lexer():
    mime_0 = 'text/plain'
    explicit_json_0 = False
    body_0 = '''
'''

    assert get_lexer(mime_0, explicit_json_0, body_0) == None


# Generated at 2022-06-25 18:48:50.032537
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    headers = "GET /foo HTTP/1.1\r\nHost: localhost"
    environment = module_0.Environment()
    color_formatter = ColorFormatter(environment)

# Generated at 2022-06-25 18:48:58.781094
# Unit test for function get_lexer
def test_get_lexer():
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)

    mime_types_0 = [
        '*/*',
        'application/json',
        'application/*',
        '*/*+json',
    ]

    body_0 = '\n    {\n        "k1": "v1",\n        "k2": "v2"\n    }\n    '

    for mime_0 in mime_types_0:
        assert color_formatter_1.get_lexer_for_body(mime_0, body_0) == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-25 18:48:59.340871
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    pass

# Generated at 2022-06-25 18:49:03.497905
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)
    assert color_formatter_1


