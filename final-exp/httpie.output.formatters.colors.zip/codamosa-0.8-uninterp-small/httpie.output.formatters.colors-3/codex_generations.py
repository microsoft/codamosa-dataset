

# Generated at 2022-06-25 18:39:10.873955
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_1 = None
    color_formatter_1 = ColorFormatter(environment_1)
    color_formatter_1.format_body("")
    environment_2 = None
    color_formatter_2 = ColorFormatter(environment_2)
    color_formatter_2.format_body("")
    # Unit test for method format_headers of class ColorFormatter
    color_formatter_2.format_headers("")
    environment_3 = None
    color_formatter_3 = ColorFormatter(environment_3)
    color_formatter_3.format_headers("")
    # Unit test for method get_lexer_for_body of class ColorFormatter
    color_formatter_3.get_lexer_for_body("")
    environment_4 = None
    color_formatter_4 = ColorForm

# Generated at 2022-06-25 18:39:12.903675
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_http_lexer_1 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:39:13.971625
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = None


# Generated at 2022-06-25 18:39:25.351167
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    environment_0.terminal_is_dumb = False
    headers_0 = "headers"
    assert color_formatter_0.format_headers(headers_0) == "\x1b[0;38;5;28mheaders\x1b[0m"
    environment_0.colors = 256
    environment_0.html = False
    assert color_formatter_0.format_headers(headers_0) == "\x1b[38;5;28mheaders\x1b[0m"
    environment_0.colors = 16
    assert color_formatter_0.format_headers(headers_0) == "\x1b[38;5;28mheaders\x1b[0m"
    environment

# Generated at 2022-06-25 18:39:27.063716
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Test for missing parts
    SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:39:31.606428
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_1 = None
    color_formatter_1 = ColorFormatter(environment_1)

    body_1 = "'Hello, world!' is a famous message"
    mime_1 = 'text/plain'
    ret = color_formatter_1.format_body(body_1, mime_1)
    assert ret == body_1


# Generated at 2022-06-25 18:39:36.490023
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environ = None
    color_formatter = ColorFormatter(environ)
    body = "body"
    mime = None
    if not isinstance(color_formatter, ColorFormatter):
        raise TypeError("assert_instance(color_formatter, ColorFormatter)")
    if not body:
        raise ValueError("assert_valid(body)")
    if not mime:
        raise ValueError("assert_valid(mime)")
    return color_formatter.format_body(body, mime)


# Generated at 2022-06-25 18:39:38.648570
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(ColorFormatter(), 'fruity') is pygments.styles.get_style_by_name('fruity')


# Generated at 2022-06-25 18:39:44.664057
# Unit test for function get_lexer
def test_get_lexer():
    # case 0
    mime_0 = None
    explicit_json_0 = False
    body_0 = None
    get_lexer_return = get_lexer(
        mime=mime_0,
        explicit_json=explicit_json_0,
        body=body_0,
    )
    get_lexer_return_expected = None
    assert get_lexer_return == get_lexer_return_expected


# Generated at 2022-06-25 18:39:47.658065
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)


# Generated at 2022-06-25 18:40:00.908511
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Variable test_environment is of type Environment
    test_environment = Environment()
    test_environment.colors = None
    # Variable test_explicit_json is of type bool
    test_explicit_json = False
    # Variable test_color_scheme is of type str
    test_color_scheme = str()

    # test_environment and test_explicit_json and test_color_scheme
    # are used as parameter
    test_ColorFormatter = ColorFormatter(test_environment,test_explicit_json, test_color_scheme)



# Generated at 2022-06-25 18:40:02.594755
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    assert env.colors
    assert ColorFormatter(env)

# Generated at 2022-06-25 18:40:05.012748
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer = SimplifiedHTTPLexer()
    assert simplified_h_t_t_p_lexer.name == 'HTTP'


# Generated at 2022-06-25 18:40:08.699456
# Unit test for function get_lexer
def test_get_lexer():
    #mime = "HTTP/1.1"
    #explicit_json = False
    #body = ""
    #assert SimplifiedHTTPLexer() == get_lexer(mime, explicit_json, body)
    assert 1

test_case_0()
test_get_lexer()

# Generated at 2022-06-25 18:40:11.834381
# Unit test for function get_lexer
def test_get_lexer():
    '''
    Pre-defined mime type: test
    Pre-defined lexer name: test
    Expected lexer: lexer_test
    '''
    assert get_lexer('test/test') == lexer_test

if __name__ == '__main__':
    test_case_0()
    test_get_lexer()

# Generated at 2022-06-25 18:40:16.561413
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():

    # Arrange
    headers = u'https://httpbin.org/IP'
    c_f_0 = ColorFormatter()

    # Act
    result = c_f_0.format_headers(headers)

    # Assert
    assert result == headers



# Generated at 2022-06-25 18:40:24.966254
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter_0 = ColorFormatter(
        env, False, DEFAULT_STYLE
    )
    color_formatter_0.get_lexer_for_body("application/json", "")
    color_formatter_0.get_lexer_for_body("text/plain", "")
    color_formatter_0.get_lexer_for_body("text/plain", "")
    color_formatter_0.get_lexer_for_body("text/plain", "")


# Generated at 2022-06-25 18:40:31.090825
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    colorFormatter_obj = ColorFormatter("")
    get_lexer_for_body_args_0 = "application/json"
    get_lexer_for_body_args_1 = ""
    get_lexer_for_body_ret_val_0 = pygments.lexers.get_lexer_for_mimetype("application/json")
    assert (
        colorFormatter_obj.get_lexer_for_body(
            get_lexer_for_body_args_0,
            get_lexer_for_body_args_1
        )
        ==
        get_lexer_for_body_ret_val_0
    )

# Generated at 2022-06-25 18:40:35.053046
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter_0 = ColorFormatter(Environment())
    mime = 'text/html'
    body = ''
    pygments.lexers.get_lexer_for_mimetype(mime)


# Generated at 2022-06-25 18:40:35.768315
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    pass

# Generated at 2022-06-25 18:40:52.889184
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # name
    assert SimplifiedHTTPLexer.name == 'HTTP'
    # aliases
    assert SimplifiedHTTPLexer.aliases == ['http']
    # filenames
    assert SimplifiedHTTPLexer.filenames == ['*.http']

    # tokens
    assert 'root' in SimplifiedHTTPLexer.tokens

    # a single element in tokens
    # request-line
    # [method] [address] [protocol]
    request_line_0 = SimplifiedHTTPLexer.tokens['root'][0]
    # [method]
    # model
    method_0 = request_line_0[0]
    # regex
    method_regex_0 = request_line_0[0]

# Generated at 2022-06-25 18:40:59.033246
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    color_formatter_0 = ColorFormatter(env)
    assert color_formatter_0.enabled == True
    # Check if instance variables are initialised correctly
    assert color_formatter_0.formatter.style.styles.get(pygments.token.Keyword).get(pygments.token.Keyword.Reserved) == "#0087ff"
    assert color_formatter_0.http_lexer.__class__.__name__ == "SimplifiedHTTPLexer"
    assert color_formatter_0.formatter.style.__class__.__name__ == "Solarized256Style"

    env = Environment(colors=16)
    color_formatter_0 = ColorFormatter(env)
    assert color_formatter_0.enabled == True
    #

# Generated at 2022-06-25 18:41:05.908671
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_1 = None
    color_formatter_1 = ColorFormatter(environment_1)
    headers_1 = '''Content-Type: application/xml; encoding=UTF-8
X-Nessus-Session-Id: 1974624298

'''
    result_1 = color_formatter_1.format_headers(headers_1)
    assert result_1 is not None
    assert result_1 == '''Content-Type: application/xml; encoding=UTF-8
X-Nessus-Session-Id: 1974624298

'''


# Generated at 2022-06-25 18:41:08.221787
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer(pygments.lexer.RegexLexer)


# Generated at 2022-06-25 18:41:19.276112
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = Environment(colors=None)
    headers_0 = '''POST /data HTTP/1.1
Accept: application/json
Content-Type: application/json
Host: localhost:5000
User-Agent: HTTPie/0.9.8
Content-Length: 15

{"foo": "bar"}'''
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.format_headers(headers_0)
    environment_0 = Environment(colors=None)
    body_0 = '{"foo": "bar"}'
    mime_0 = 'application/json'
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.format_body(body_0, mime_0)

# Generated at 2022-06-25 18:41:20.463880
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = None
    color_formatter_1 = ColorFormatter(environment_0)
    test_case_0()

# Generated at 2022-06-25 18:41:22.511966
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers_0 = "name"
    color_formatter_0 = ColorFormatter(None)
    color_formatter_0.formatter = None
    color_formatter_0.http_lexer = None
    str_0 = color_formatter_0.format_headers(headers_0)
    assert str_0


# Generated at 2022-06-25 18:41:24.549482
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer(pygments.lexer.RegexLexer) == pygments.lexer.RegexLexer

# Generated at 2022-06-25 18:41:25.718004
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    test_case_0()


# Generated at 2022-06-25 18:41:29.600673
# Unit test for function get_lexer
def test_get_lexer():
    get_lexer_0 = get_lexer(mime='application/json', body='')
    return get_lexer_0


# Generated at 2022-06-25 18:41:39.274541
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 18:41:44.171376
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)
    mime = bytes()

    # Call the method directly
    body = bytes()
    result = color_formatter_0.get_lexer_for_body(mime, body)
    assert result is PygmentsHttpLexer


# Generated at 2022-06-25 18:41:48.364695
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = '{'
    mime_0 = 'application/json'
    res = color_formatter_0.format_body(
        body_0,
        mime_0
    )
    assert res == "{", "Expected {, but got " + res


# Generated at 2022-06-25 18:41:52.733955
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = ' q'
    headers_1 = color_formatter_0.format_headers(headers_0)



# Generated at 2022-06-25 18:42:01.119103
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import unittest
    try:
        environment_0 = Environment()
        color_formatter_0 = ColorFormatter(environment_0)
        headers_0 = ""
        color_formatter_0.format_headers(headers_0)
    except Exception as ex:
        unittest.TestCase.fail('unexpected exception: ' + str(ex))


# Generated at 2022-06-25 18:42:02.480233
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print('Function "test_ColorFormatter" not implemented yet')


# Generated at 2022-06-25 18:42:06.633697
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)
    mime_0 = 'text/plain'
    body_0 = '{"foo":"bar"}'
    lexer_name_0 = color_formatter_0.get_lexer_for_body(mime_0, body_0)
    print(lexer_name_0.aliases)

# Generated at 2022-06-25 18:42:08.387826
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)


# Generated at 2022-06-25 18:42:16.813456
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexer import RegexLexer
    from pygments.token import Name
    from pygments.lexers.python import PythonLexer
    from pygments.token import Name
    Lexer = SimplifiedHTTPLexer(PythonLexer)
    content = 'A string'
    tokens = Lexer().get_tokens(content)
    assert(tokens[0][0] == Name.Attribute)
    assert(tokens[2][0] == Name.Attribute)


# Generated at 2022-06-25 18:42:19.409067
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)
    # Bad parameter 'headers' type, should be str
    with pytest.raises(TypeError):
        color_formatter_0.format_headers(headers=0)


# Generated at 2022-06-25 18:42:57.131800
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    argument_0 = "\xA7"
    argument_1 = "application/json"
    environment_0 = Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    return_value_0 = color_formatter_0.format_body(argument_0, argument_1)
    assert return_value_0 == "\xA7"


# Generated at 2022-06-25 18:43:04.593092
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)
    mime = "application/json"
    # test case 1
    explicit_json = False
    body = ""
    assert isinstance(color_formatter_0.get_lexer_for_body(
        mime, explicit_json, body), type(pygments.lexers.get_lexer_by_name('json')))
    # test case 2
    explicit_json = True
    body = ""
    assert isinstance(color_formatter_0.get_lexer_for_body(
        mime, explicit_json, body), type(pygments.lexers.get_lexer_by_name('json')))

# Generated at 2022-06-25 18:43:06.448441
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = Environment(colors=True)
    color_formatter_0 = ColorFormatter(environment_0)

# Generated at 2022-06-25 18:43:07.901987
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_http_lexer = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:43:12.049344
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = None

    result = color_formatter_0.get_style_class(color_scheme_0)

    assert result == Solarized256Style



# Generated at 2022-06-25 18:43:18.974906
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    color_formatter = ColorFormatter(env, color_scheme='solarized')

    # Case 3
    # assert None == color_formatter.format_body('Some body', None)

    # Case 2
    # assert None == color_formatter.format_body(None, 'application/json')

    # Case 1
    assert 'Some <span class="n">body</span>' == color_formatter.format_body(
        'Some body',
        'text/html'
    )


# Generated at 2022-06-25 18:43:22.328990
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_4 = None
    color_formatter_4 = ColorFormatter(environment_4)
    color_scheme_4 = None
    pygments_style_4 = color_formatter_4.get_style_class(color_scheme_4)

# Generated at 2022-06-25 18:43:28.800253
# Unit test for function get_lexer
def test_get_lexer():
    # body = '''
    # {
    #     "id": 1.0,
    #     "name": "2014"
    # }
    # '''
    # mime = 'application/json'
    mime = 'text/html'
    body = '''
    <!DOCTYPE html>
    <html>
    <head>
    <title>Page Title</title>
    </head>
    <body>
    <h1>This is a Heading</h1>
    <p>This is a paragraph.</p>
    </body>
    </html>
    '''
    # mime = 'text/xml'
    # body = '''
    # <bookstore>
    #   <book genre="autobiography" >
    #     <title>The Autobiography of Benjamin

# Generated at 2022-06-25 18:43:30.082256
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:43:33.416168
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_1 = None
    color_formatter_1 = ColorFormatter(environment_1)
    color_scheme = None
    style_class = color_formatter_1.get_style_class(color_scheme)


# Generated at 2022-06-25 18:44:03.560186
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer is not None

# Generated at 2022-06-25 18:44:07.098110
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = None
    # No exception is expected
    color_formatter_0.get_style_class(color_scheme_0)

# Generated at 2022-06-25 18:44:10.020429
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Just test if the constructor can be called.
    lexer = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:44:13.374156
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)

    headers_0 = "HTTP/1.1 200 OK"
    color_formatter_0.format_headers(headers_0)


# Generated at 2022-06-25 18:44:16.338196
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    input0 = 'example_string'
    expected_output = 'example_string'
    print_output = ColorFormatter.format_headers(input0)
    assert(print_output == expected_output)



# Generated at 2022-06-25 18:44:20.529018
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)
    str_0 = ""
    str_1 = ""
    response = color_formatter_0.get_lexer_for_body(str_0, str_1)
    assert(response == None)



# Generated at 2022-06-25 18:44:25.067077
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = Mock()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = Mock()
    # style_class = Solarized256Style
    assert pygments.styles.get_style_by_name(color_scheme_0) == Solarized256Style


# Generated at 2022-06-25 18:44:28.308246
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = None
    mime_0 = None
    assert color_formatter_0.format_body(body_0,mime_0) != None


# Generated at 2022-06-25 18:44:34.339895
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_1 = Environment(
        colors=True,
        stdin_isatty=False,
        stdout_isatty=False
    )

    explicit_json_1 = False
    color_formatter_1 = ColorFormatter(
        environment_1,
        explicit_json=explicit_json_1
    )

    mime_1 = 'application/json'
    body_1 = '[{"key": "value"}]'
    expected_1 = get_lexer(mime_1, explicit_json_1, body_1)

    actual_1 = color_formatter_1.get_lexer_for_body(mime_1, body_1)

    assert actual_1 == expected_1, \
        'Test case 1 failed'


# Generated at 2022-06-25 18:44:44.103887
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    string = "HTTP/1.1 200 OK\r\nServer: nginx/1.10.3\r\nDate: Sun, 19 Nov 2017 19:06:59 GMT\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: 2\r\nConnection: keep-alive\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept\r\n\r\n{}"

# Generated at 2022-06-25 18:45:23.848023
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = "solarized"
    var_0 = color_formatter_0.get_style_class(color_scheme_0)
    color_scheme_1 = "monokai"
    var_1 = color_formatter_0.get_style_class(color_scheme_1)
    color_scheme_2 = "auto"
    var_2 = color_formatter_0.get_style_class(color_scheme_2)
    color_scheme_3 = "fruity"
    var_3 = color_formatter_0.get_style_class(color_scheme_3)
    color_scheme_4 = "tango"
    var_4

# Generated at 2022-06-25 18:45:36.376128
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = Environment()
    # environment_0.color_scheme = 'solarized'
    color_formatter_0 = ColorFormatter(environment_0)
    assert(color_formatter_0.enabled)
    assert(color_formatter_0.formatter)
    assert(color_formatter_0.http_lexer)
    assert(color_formatter_0.formatter._style.__class__.__name__ == "Solarized256Style")
    assert(color_formatter_0.http_lexer.name == "SimplifiedHTTP")
    assert(color_formatter_0.http_lexer.aliases[0] == "http")
    assert(color_formatter_0.http_lexer.filenames[0] == "*.http")

# Generated at 2022-06-25 18:45:39.287128
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    obj = SimplifiedHTTPLexer()
    obj.tokens
    obj.name
    obj.aliases
    obj.filenames


# Generated at 2022-06-25 18:45:46.623148
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.util import ClassNotFound
    from pygments.lexers import get_lexer_by_name
    from pygments.lexers.special import TextLexer
    test_case_lexer = SimplifiedHTTPLexer()
    assert test_case_lexer.name == 'HTTP'
    assert test_case_lexer.aliases == ['http']
    assert test_case_lexer.filenames == ['*.http']
    test_case_lexer.tokens

# Generated at 2022-06-25 18:45:50.480641
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter_1 = ColorFormatter(None)
    color_scheme = 'DEFAULT_STYLE'

    # Call method to test
    style_class = color_formatter_1.get_style_class(color_scheme)


# Generated at 2022-06-25 18:45:53.880088
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_1 = None
    color_formatter_1 = ColorFormatter(environment_1)
    color_scheme_1 = ""
    style_class_0 = color_formatter_1.get_style_class(color_scheme_1)
    assert style_class_0 == Solarized256Style


# Generated at 2022-06-25 18:46:03.477501
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_1 = None
    color_formatter_1 = ColorFormatter(environment_1)
    mime_1 = 'text/html'
    body_1 = 'foo'
    expected_1 = 'foo'
    actual_1 = color_formatter_1.format_body(mime_1, body_1)
    assert actual_1 == expected_1

    environment_2 = None
    color_formatter_2 = ColorFormatter(environment_2)
    mime_2 = 'application/json'
    body_2 = 'foo'
    expected_2 = 'foo'
    actual_2 = color_formatter_2.format_body(mime_2, body_2)
    assert actual_2 == expected_2



# Generated at 2022-06-25 18:46:13.389078
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_1 = None
    explicit_json_1 = False
    color_scheme_1 = None
    color_formatter_1 = ColorFormatter(environment_1, explicit_json_1, color_scheme_1)
    assert color_formatter_1.enabled == False
    header_1 = "HTTP/1.1 200 OK\nContent-Length: 5\nDate: Wed, 20 Dec 2017 16:10:01 GMT\nContent-Type: application/json; charset=utf-8\nExpires: Thu, 21 Dec 2017 16:10:01 GMT\nCache-Control: max-age=86400\nServer: nginx\n\n"
    mime_1 = "application/json"
    body_1 = "{\"hel\" : \"lo\"}"

# Generated at 2022-06-25 18:46:21.999206
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = ''
    mime_0 = 'text/plain'
    # Uncomment next line to setup your test
    # color_formatter_0.explicit_json = True
    # Uncomment next line to setup your test
    # color_formatter_0.formatter = TerminalFormatter()
    # Uncomment next line to setup your test
    # color_formatter_0.http_lexer = pygments.lexers.special.TextLexer()
    # Uncomment next line to setup your test
    # color_formatter_0.enabled = True
    # Uncomment next line to setup your test
    # color_formatter_0.env = None
    # Uncomment next line to setup your test
    # color_

# Generated at 2022-06-25 18:46:30.897370
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = Environment(colors=True, styleguide=None)
    color_formatter_0 = ColorFormatter(environment_0)

    str_0 = 'application/javascript'
    str_1 = '{}'
    str_0 = color_formatter_0.format_body(str_1, str_0)
    assert str_0 == '{}'

    str_0 = 'application/json'
    str_1 = '{\n  "foo": "bar"\n}'
    str_0 = color_formatter_0.format_body(str_1, str_0)
    assert str_0 == '{\n\x1b[39;49;00m  "foo": "bar"\n\x1b[39;49;00m}'


# Generated at 2022-06-25 18:47:58.380645
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = Environment(colors=True)
    assert_equal(environment_0.colors, True)
    color_formatter_0 = ColorFormatter(environment_0)
    assert_equal(color_formatter_0.enabled, True)
    assert_equal(color_formatter_0.explicit_json, False)


# Generated at 2022-06-25 18:48:03.906921
# Unit test for function get_lexer
def test_get_lexer():
    color_formatter_0 = None
    test_get_lexer_0 = get_lexer(color_formatter_0)
    assert test_get_lexer_0 == None



# Generated at 2022-06-25 18:48:05.409993
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = None
    color_formatter_0 = ColorFormatter(environment_0)


# Generated at 2022-06-25 18:48:08.473338
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = None
    explicit_json_0 = False
    color_scheme_0 = DEFAULT_STYLE
    color_formatter_0 = ColorFormatter(environment_0, explicit_json_0, color_scheme_0)


# Generated at 2022-06-25 18:48:20.304253
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import unittest
    import pytest
    class ColorFormatterTest(unittest.TestCase):

        def setUp(self):
            self.env = Environment(colors=1)

        def tearDown(self):
            pass

        def test_constructor(self):
            color_formatter = ColorFormatter(self.env)
            assert color_formatter

        def test_constructor_with_args(self):
            color_formatter = ColorFormatter(self.env,
                                             explicit_json = True,
                                             color_scheme="abc")
            assert color_formatter

        def test_constructor_with_args_2(self):
            color_formatter = ColorFormatter(self.env,
                                             explicit_json = True)
            assert color_formatter


# Generated at 2022-06-25 18:48:24.983041
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = None
    explicit_json_0 = None
    color_scheme_0 = None
    color_formatter_0 = ColorFormatter(environment_0, explicit_json_0, color_scheme_0)



# Generated at 2022-06-25 18:48:32.334988
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_1 = Environment(colors=True)
    environment_2 = Environment(colors=False)
    environment_3 = Environment(colors=256)
    color_formatter_0 = ColorFormatter(environment_1)
    if (color_formatter_0.enabled):
        assert True
    else:
        assert False
    color_formatter_1 = ColorFormatter(environment_2)
    if (not color_formatter_1.enabled):
        assert True
    else:
        assert False


# Generated at 2022-06-25 18:48:38.504515
# Unit test for function get_lexer
def test_get_lexer():
    """

    """
    mime_0 = ()
    explicit_json_0 = False
    body_0 = ""
    actual = get_lexer(
        mime=mime_0,
        explicit_json=explicit_json_0,
        body=body_0
    )
    expected = (None)
    assert actual == expected, 'Expected different values'


# Generated at 2022-06-25 18:48:41.686839
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_1 = None
    explicit_json_1 = None
    color_scheme_1 = 'deft'
    color_formatter_1 = ColorFormatter(environment_1, explicit_json_1, color_scheme_1)


# Generated at 2022-06-25 18:48:45.154366
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_1 = None
    explicit_json=False
    color_scheme='auto'
    color_formatter_1 = ColorFormatter(environment_1, explicit_json, color_scheme)
