

# Generated at 2022-06-25 18:39:08.501717
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert True



# Generated at 2022-06-25 18:39:11.140990
# Unit test for function get_lexer
def test_get_lexer():
    s = 'Content-Type: application/json; charset=UTF-8'
    _result = get_lexer(s)
    assert type(_result) is type(pygments.lexers.JsonLexer)


# Generated at 2022-06-25 18:39:17.432960
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # SimplifiedHTTPLexer()
    simplified_http_lexer_0 = SimplifiedHTTPLexer()
    # SimplifiedHTTPLexer(*, aliases=None, filenames=None, flags=0, **options)
    simplified_http_lexer_1 = SimplifiedHTTPLexer(aliases=None, filenames=None, flags=0)


# Generated at 2022-06-25 18:39:19.003857
# Unit test for function get_lexer
def test_get_lexer():
    test_get_lexer_0()


# Generated at 2022-06-25 18:39:23.685605
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env_0 = Environment()
    formatter_0 = ColorFormatter(env_0)
    formatter_0.format_headers('headers')
    formatter_0.format_body('body', 'mime')
    formatter_0.get_lexer_for_body('mime', 'body')



# Generated at 2022-06-25 18:39:29.894237
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import StringIO
    import sys

    saved_out = sys.stdout
    try:
        out = StringIO.StringIO()
        sys.stdout = out
        environment_0 = Environment()
        color_formatter_0 = ColorFormatter(environment_0)
        color_formatter_0.format_headers('My-Header: My Value')
        assert(out.getvalue() == '\x1b[38;5;125mMy-Header\x1b[39;00m: \x1b[38;5;45mMy Value\x1b[39;00m\n')
    finally:
        sys.stdout = saved_out


# Generated at 2022-06-25 18:39:31.713872
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    list_0 = []
    simplifiedhttp_lexer_0 = SimplifiedHTTPLexer(*list_0)


# Generated at 2022-06-25 18:39:36.349664
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Given
    color_formatter_0 = ColorFormatter(None)
    headers_0 = {"Content-Length": "1000", "X-Random": "qwerty", "User-Agent": "HTTPie/0.9.8", "Cache-Control": "no-cache", "Connection": "keep-alive"}
    color_formatter_0.format_headers(headers_0)
    # When
    color_formatter_0.format_headers(headers_0)
    # Then


# Generated at 2022-06-25 18:39:37.762002
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer_1 = SimplifiedHTTPLexer()
    assert lexer_1 is not None

# Generated at 2022-06-25 18:39:48.810512
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    httpie_context_0 = Environment()
    color_formatter_0 = ColorFormatter(httpie_context_0)
    color_formatter_0.body_limit = 500
    httpie_context_0.colors = True
    color_formatter_0.enabled = True
    color_formatter_0.body = '{"field": "value"}'

    assert (
        color_formatter_0.format_body(
            body='{"field": "value"}',
            mime='application/json'
        ) == '{\n    "field": "value"\n}\n'
    )

# Generated at 2022-06-25 18:40:04.751888
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class_0 = ColorFormatter.get_style_class("fruity")
    style_class_0 = ColorFormatter.get_style_class("borland")
    style_class_0 = ColorFormatter.get_style_class("solarized")
    style_class_0 = ColorFormatter.get_style_class("default")
    style_class_0 = ColorFormatter.get_style_class("default")
    style_class_0 = ColorFormatter.get_style_class("fruity")

import pygments


# Generated at 2022-06-25 18:40:06.015975
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    class_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:40:08.974088
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = ''
    assert color_formatter_0.format_headers(headers_0) == None


# Generated at 2022-06-25 18:40:12.746996
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = 'solarized'
    get_style_class_call_result_0 = color_formatter_0.get_style_class(color_scheme_0)
    assert get_style_class_call_result_0 == Solarized256Style


# Generated at 2022-06-25 18:40:18.470032
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers = 'All'
    if (color_formatter_0.format_headers(headers) != '\x1b[38;5;28mAll\x1b[39m'): raise Exception()


# Generated at 2022-06-25 18:40:22.959982
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.get_style_class('solarized') == Solarized256Style


# Generated at 2022-06-25 18:40:25.549414
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0


# Generated at 2022-06-25 18:40:32.263681
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-25 18:40:36.173967
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)

if __name__ == '__main__':
    test_case_0()
    test_ColorFormatter()

# Generated at 2022-06-25 18:40:41.250710
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)
    headers_1 = ' '
    str_0 = color_formatter_1.format_headers(headers_1)
    assert str_0 == ' '


# Generated at 2022-06-25 18:40:56.514801
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    s = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:41:07.118968
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    tokens = {}
    root = []
    # Request Line
    root.append((r'([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)', pygments.lexer.bygroups(pygments.token.Name.Function, pygments.token.Text, pygments.token.Name.Namespace, pygments.token.Text, pygments.token.Keyword.Reserved, pygments.token.Operator, pygments.token.Number)))
    # Response Status-Line

# Generated at 2022-06-25 18:41:15.190030
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.get_lexer_for_body = lambda *args: None
    assert color_formatter_0.format_body("x\u00ad", "text/plain") == "x\u00ad"
    assert color_formatter_0.format_body("x", "text/plain") == "x"
    assert color_formatter_0.format_body("y", "text/plain") == "y"



# Generated at 2022-06-25 18:41:16.261793
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-25 18:41:19.664434
# Unit test for function get_lexer
def test_get_lexer():
    mime_0 = str()
    explicit_json_0 = bool()
    body_0 = str()
    get_lexer(mime_0, explicit_json_0, body_0)

# Generated at 2022-06-25 18:41:27.370448
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    # Hard-coded HTTP request/response
    body = """
<html>
<head><title>Hello World!</title></head>
<body>Hello World!</body>
</html>
"""
    mime = "text/html"
    expected = """
<html>
<head><title>Hello World!</title></head>
<body>Hello World!</body>
</html>
"""
    actual = color_formatter_0.format_body(mime=mime, body=body)
    assert actual == expected


# Generated at 2022-06-25 18:41:39.737133
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-25 18:41:45.490625
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime_0 = 'application/json'
    body_0 = '{"key": "value"}'
    assert color_formatter_0.get_lexer_for_body(mime_0, body_0) == pygments.lexers.get_lexer_by_name('json')


# Generated at 2022-06-25 18:41:55.364159
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = DEFAULT_STYLE
    kwargs_0 = {'env': environment_0, 'explicit_json': False, 'color_scheme': color_scheme_0}
    color_formatter_1 = ColorFormatter(**kwargs_0)
    return str(explicit_json) + str(color_scheme) + str(kwargs) + str(env) + str(enabled) + str(formatter) + str(group_name) + str(http_lexer)


# Generated at 2022-06-25 18:42:06.470417
# Unit test for function get_lexer
def test_get_lexer():
    # Check that we can get a lexer by mimetype.
    assert get_lexer('application/json') is pygments.lexers.get_lexer_by_name('json')
    # Check that we can get a lexer by filename extension.
    assert get_lexer('application/x-xz') is pygments.lexers.get_lexer_by_name('xz')
    # Check that we can get a lexer from a short mimetype.
    # See: https://github.com/psf/requests/issues/2980
    assert get_lexer('audio/L16') is pygments.lexers.get_lexer_by_name('L16')
    # Check that we get a generic lexer if we can't find more specific one.
    assert get_lexer('text/plain') is py

# Generated at 2022-06-25 18:42:20.771132
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert len(color_formatter_0.format_body('', '')) > 0
    assert len(color_formatter_0.format_body('', 'text/html')) > 0
    assert len(color_formatter_0.format_body('', 'application/json')) > 0
    assert len(color_formatter_0.format_body('', 'application/xml')) > 0
    assert len(color_formatter_0.format_body('', 'text/xml')) > 0
    assert len(color_formatter_0.format_body('', 'text/plain')) > 0


# Generated at 2022-06-25 18:42:21.722880
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    assert True


# Generated at 2022-06-25 18:42:30.719723
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    name_0 = 'HTTP'
    aliases_0 = ['http']
    filenames_0 = ['*.http']

# Generated at 2022-06-25 18:42:38.647831
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_1 = 'solarized'
    style_class_1 = pygments.styles.get_style_by_name('solarized')
    style_class_2 = color_formatter_0.get_style_class(color_scheme_1)
    assert style_class_1 == style_class_2

import httpie.context as module_1


# Generated at 2022-06-25 18:42:40.446237
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

# Generated at 2022-06-25 18:42:51.033900
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = ""
    color_formatter_0.format_headers(headers_0) # Expected: ''.

    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = "OK"
    color_formatter_0.format_headers(headers_0) # Expected: 'OK'.

    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    headers_0 = "OK"
    color_formatter_0.format_headers(headers_0) # Expected: 'OK'.

    environment_0 = module_0.Environment()
    color_form

# Generated at 2022-06-25 18:42:53.836680
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)


# Generated at 2022-06-25 18:43:00.912912
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.explicit_json == None
    assert color_formatter_0.formatter.style == pygments.styles.get_style_by_name("default")
    assert color_formatter_0.http_lexer.name == "HTTP"
    assert pygments.lexers.python.Python3Lexer.name == "Python 3"
    assert pygments.lexers.python.Python3TracebackLexer.name == "Python 3.0 Traceback"


# Generated at 2022-06-25 18:43:10.336627
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

# Generated at 2022-06-25 18:43:11.707488
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    test_lexer = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:43:36.655710
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from argparse import Namespace
    from httpie.core import main as httpie_core_main
    from httpie.compat import is_windows

# Generated at 2022-06-25 18:43:39.352821
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)


# Generated at 2022-06-25 18:43:43.444110
# Unit test for function get_lexer
def test_get_lexer():
    lexer_0 = get_lexer(mime='application/json', body='{"a": 1, "b": 2}')

    assert(
        isinstance(lexer_0, pygments.lexers.JsonLexer)
    )

# Generated at 2022-06-25 18:43:49.926371
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime = "application/json"
    body = '{"root":{"inner":["array",1,2]}}'
    result = color_formatter_0.get_lexer_for_body(mime, body)
    assert result == pygments.lexers.get_lexer_by_name('json')


# Generated at 2022-06-25 18:43:54.200644
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body = None
    mime = None
    color_formatter_0.format_body(body, mime)


# Generated at 2022-06-25 18:44:00.651472
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body_test_0 = '{"test": "test"}'
    mime_test_0 = 'application/json'
    result_0 = color_formatter_0.format_body(body_test_0, mime_test_0)
    assert result_0 == '\x1b[38;5;39m{\x1b[39m\x1b[38;5;39m"test"\x1b[39m\x1b[38;5;39m: \x1b[39m\x1b[38;5;39m"test"\x1b[39m\x1b[38;5;39m}\x1b[39m'


# Generated at 2022-06-25 18:44:03.607467
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    obj = pygments.lexers.get_lexer_by_name('http')
    assert obj == None


# Generated at 2022-06-25 18:44:07.899803
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime_0 = 'mime'
    body_0 = 'body'
    assert color_formatter_0.format_body(body_0, mime_0) == 'body'


# Generated at 2022-06-25 18:44:10.926089
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    try:
        lexer_0 = SimplifiedHTTPLexer()
    except Exception as inst_0:
        assert False
    else:
        pass


# Generated at 2022-06-25 18:44:19.581011
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter = ColorFormatter(environment_0)
    color_formatter.format_body('{"key": "value"}', 'application/json')
    color_formatter.format_body('{"key": "value"}',
                                'application/hal+json')
    color_formatter.format_body('{"key": "value"}', 'application/vnd.hal+json')
    color_formatter.format_body('{"key": "value"}', 'application/xml')
    color_formatter.format_body('{"key": "value"}', 'application/vnd.api+json')
    color_formatter.format_body('{"key": "value"}', 'application/vnd.api+json-stream')

# Generated at 2022-06-25 18:44:45.449707
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    pygments_highlight_0 = pygments.highlight(
        code="",
        lexer=None,
        formatter=color_formatter_0.formatter,
    )
    assert pygments_highlight_0 == "", "Expected <''>, but got <''>"


# Generated at 2022-06-25 18:44:46.572212
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    pass


# Generated at 2022-06-25 18:44:50.862152
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = DEFAULT_STYLE
    color_formatter_0.get_style_class(color_scheme_0)


# Generated at 2022-06-25 18:44:55.208211
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    str_0 = 'HTTP/1.0 401 Authorization Required'
    str_1 = color_formatter_0.format_headers(str_0)
    str_2 = 'HTTP/1.0 401 Authorization Required'
    assert str_1 == str_2


# Generated at 2022-06-25 18:44:57.959852
# Unit test for function get_lexer
def test_get_lexer():
    mime_0 = '*/*'
    explicit_json_0 = False
    body_0 = "ABCD"
    get_lexer(mime_0, explicit_json_0, body_0 )

# Generated at 2022-06-25 18:45:02.496221
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.format_body('', 'text/html')


# Generated at 2022-06-25 18:45:10.128548
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0=environment_0)

    assert color_formatter_0.format_headers('Accept: text/html\r\nCookie: foo=bar\r\n') == '\x1b[38;5;8mAccept\x1b[39m\x1b[38;5;15m: text/html\r\n\x1b[39m\x1b[38;5;8mCookie\x1b[39m\x1b[38;5;15m: foo=bar\r\n\x1b[39m'

# Generated at 2022-06-25 18:45:12.784864
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert not color_formatter_0.format_body('application/json', '')


# Generated at 2022-06-25 18:45:19.561341
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Test for case 0
    environment_0 = module_0.Environment()
    headers_0 = 'foo:bar\n'
    color_formatter_0 = ColorFormatter(environment_0)
    str_0 = color_formatter_0.format_headers(headers_0)
    assert str_0 == '\x1b[38;5;11mfoo\x1b[39m:\x1b[38;5;10mbar\x1b[39m\n'


# Generated at 2022-06-25 18:45:27.467171
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    _environment_0 = module_0.Environment()
    _explicit_json_0 = False
    _color_scheme_0 = 'dark'
    _mime_0 = 'application/json'
    _body_0 = '{}'
    color_formatter_0 = ColorFormatter(_environment_0, _explicit_json_0, _color_scheme_0, **{})
    assert color_formatter_0.format_body(_body_0, _mime_0) == '\x1b[30;01m{}\x1b[39;49;00m'


# Generated at 2022-06-25 18:45:59.019257
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():

    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)


# Generated at 2022-06-25 18:46:09.740746
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    http_lexer_0 = SimplifiedHTTPLexer()
    formatter_0 = Terminal256Formatter(Solarized256Style)
    color_formatter_0 = ColorFormatter(environment_0, formatter_0, http_lexer_0)
    assert color_formatter_0.formatter == formatter_0
    assert color_formatter_0.http_lexer == http_lexer_0

    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1, explicit_json=True)
    http_lexer_1 = SimplifiedHTTPLexer()
    formatter_1 = Terminal256Formatter(Solarized256Style)


# Generated at 2022-06-25 18:46:11.211810
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

# Generated at 2022-06-25 18:46:14.430037
# Unit test for function get_lexer
def test_get_lexer():
    explicit_json = False
    body = ''
    mime = 'text/json'

    lexer = get_lexer(
        mime=mime,
        explicit_json=explicit_json,
        body=body
    )
    assert lexer == None


# Generated at 2022-06-25 18:46:15.214238
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    pass


# Generated at 2022-06-25 18:46:17.617293
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    try:
        ColorFormatter(environment_0)
    except Exception as e:
        assert False


import httpie.plugins as module_1


# Generated at 2022-06-25 18:46:20.443948
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    assert ColorFormatter(environment_0, explicit_json=False, color_scheme='solarized', **{'kwargs': {}}) != None


# Generated at 2022-06-25 18:46:27.733692
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.group_name == 'colors'
    assert color_formatter_0.enabled == True
    assert color_formatter_0.formatter != None
    assert color_formatter_0.http_lexer != None
    assert color_formatter_0.explicit_json == False
    environment_0 = module_0.Environment(colors = False)
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.enabled == False


# Generated at 2022-06-25 18:46:36.172561
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    str_0 = 'json'
    int_0 = 256
    str_1 = 'auto'
    int_1 = 36
    int_2 = 24
    int_3 = 0
    str_2 = 'http://httpbin.org/json'

    environment_0 = module_0.Environment(colors=int_1, unicode_formatter='', colors_256=int_3, colors_16m=int_2)
    color_formatter_0 = ColorFormatter(environment_0)

    assert color_formatter_0.explicit_json == int_3
    assert color_formatter_0.formatter == Terminal256Formatter(style=Solarized256Style)
    assert color_formatter_0.get_style_class(str_0) == Solarized256Style

# Generated at 2022-06-25 18:46:44.335172
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()

    color_formatter_0 = ColorFormatter(environment_0)


# Generated at 2022-06-25 18:47:33.772203
# Unit test for function get_lexer
def test_get_lexer():
    pass


# Generated at 2022-06-25 18:47:39.423119
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():

    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0, False, 'vim')

    assert color_formatter_0.formatter._style == pygments.styles.get_style_by_name('vim')

    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1, True, 'vim')

    assert color_formatter_1.formatter._style == pygments.styles.get_style_by_name('vim')


# Generated at 2022-06-25 18:47:39.949713
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert 1

# Generated at 2022-06-25 18:47:41.156301
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

# Generated at 2022-06-25 18:47:43.819808
# Unit test for function get_lexer
def test_get_lexer():
    mime = 'foo/bar'
    body = 'some json body'
    assert(get_lexer(mime, body) != None)


# Generated at 2022-06-25 18:47:48.363949
# Unit test for function get_lexer
def test_get_lexer():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.get_lexer_for_body('application/json', '{}')


# Generated at 2022-06-25 18:47:58.032037
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    headers = '''HTTP/1.1 204 No Content\r\nCache-Control: private, max-age=0\r\nServer: GSE\r\nLast-Modified: Mon, 06 Aug 2012 06:02:09 GMT\r\nVary: *\r\nVary: Origin\r\nVary: X-Origin\r\nDate: Mon, 06 Aug 2012 06:02:09 GMT\r\nContent-Type: text/html; charset=UTF-8\r\nX-Content-Type-Options: nosniff\r\nX-Frame-Options: SAMEORIGIN\r\nX-XSS-Protection: 1; mode=block\r\nAlternate-Protocol: 80:quic,p=0.01\r\n'''

# Generated at 2022-06-25 18:48:03.569663
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0 is not None


# Generated at 2022-06-25 18:48:10.631911
# Unit test for function get_lexer
def test_get_lexer():
    headers = 'X-Response-Time: 10000'
    body_json = '{"id":1,"name":"foo"}'
    body_txt = 'TXT'
    body_html = '<html><head></head><body></body></html>'
    body_xml = '<xml><head></head><body></body></xml>'
    body_css = 'body { color: red; }'
    body_csv = 'a,b,c\nd,e,f\n'

    def assert_lexer(expected_lexer, mime, body):
        lexer = get_lexer(mime=mime, body=body)
        assert lexer is expected_lexer


# Generated at 2022-06-25 18:48:12.986599
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(Environment())
