

# Generated at 2022-06-25 18:39:14.330451
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    pygments_lexer_0 = SimplifiedHTTPLexer()
    assert pygments_lexer_0.name is not None
    assert pygments_lexer_0.aliases is not None
    assert pygments_lexer_0.filenames is not None
    assert pygments_lexer_0.tokens is not None

# Generated at 2022-06-25 18:39:25.637165
# Unit test for constructor of class ColorFormatter

# Generated at 2022-06-25 18:39:31.727603
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter_0 = ColorFormatter(**{})
    color_scheme_0 = ''
    var_0 = color_formatter_0.get_style_class(color_scheme_0)
    assert var_0 == Solarized256Style


# Generated at 2022-06-25 18:39:35.878974
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    dict_0 = None
    color_formatter_0 = ColorFormatter(**dict_0)
    str_0 = ''
    type_0 = color_formatter_0.get_style_class(str_0)
    return(type_0)

# Main for test case 0
if __name__ == '__main__':
    test_case_0()

# Main for ColorFormatter
if __name__ == '__main__':
    test_ColorFormatter_get_style_class()

# Generated at 2022-06-25 18:39:39.061167
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    dict_0 = None
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer(**dict_0)
    str_0 = None
    str_0 = simplified_h_t_t_p_lexer_0.format_headers(str_0)


# Generated at 2022-06-25 18:39:44.118334
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    dict_0 = None
    color_formatter_0 = ColorFormatter(**dict_0)
    assert type(color_formatter_0.format_headers("")) == str
    dict_1 = None
    color_formatter_1 = ColorFormatter(**dict_1)
    assert type(color_formatter_1.format_headers("")) == str


# Generated at 2022-06-25 18:39:49.385122
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    dict_0 = None
    color_formatter_0 = ColorFormatter(**dict_0)
    str_0 = None
    str_1 = color_formatter_0.format_headers(str_0)
    assert str_1 == str_0


# Generated at 2022-06-25 18:39:51.542331
# Unit test for function get_lexer
def test_get_lexer():
    mime_type_0 = ""
    get_lexer(mime = mime_type_0)


# Generated at 2022-06-25 18:39:56.754592
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_name = 'colorful'
    terminal_formatter_0 = None
    ansi_color_processor_0 = ColorFormatter(**terminal_formatter_0)
    ansi_color_processor_0.get_style_class(style_name)
    # Asserts that the expected and actual results match
    assert style_name == ansi_color_processor_0.get_style_class(style_name)


# Generated at 2022-06-25 18:39:59.396062
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    dict_0 = None
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer(**dict_0)

# Generated at 2022-06-25 18:40:23.863285
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter_0 = ColorFormatter(
        env=Environment(
            colors=256,
            stdin=None,
            isatty=True,
            stdout=None,
            stdin_isatty=True,
            stdout_isatty=True
        ),
        color_scheme='solarized'
    )
    color_formatter_0.format_headers(
        headers='PUT /people/1/ HTTP/1.1\r\nHost: example.org\r\nContent-Type: application/json\r\n\r\n'
    )


# Generated at 2022-06-25 18:40:26.952763
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    colorFormatter = ColorFormatter(env)
    mime = 'string'
    body = 'string'
    result = colorFormatter.format_body(body,mime)
    assert result 


# Generated at 2022-06-25 18:40:28.278281
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter_0 = ColorFormatter()
    color_formatter_0.format_body('', '')



# Generated at 2022-06-25 18:40:29.590148
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():

    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()



# Generated at 2022-06-25 18:40:30.745667
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(Environment())


# Generated at 2022-06-25 18:40:32.802154
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    r = ColorFormatter.format_body()
    assert len(r) > 0


# Generated at 2022-06-25 18:40:44.379229
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # A ColorFormatter instance should never initialize
    # if the environment has no color support.
    env_0 = Environment()
    env_0.colors = None
    explicit_json_0 = False
    color_scheme_0 = DEFAULT_STYLE
    kwargs_0 = {}
    formatter_0 = ColorFormatter(env_0, explicit_json_0, color_scheme_0, **kwargs_0)
    assert isinstance(formatter_0, ColorFormatter)
    headers = "Content-Type: application/json\n"
    assert formatter_0.format_headers(headers) is not None
    body = '{"foo":{"bar":0}}'
    mime = 'application/json'
    assert formatter_0.format_body(body, mime) is not None

# Generated at 2022-06-25 18:40:47.901969
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    input0 = ColorFormatter(Environment(colors=256))
    expected_output = None
    
    actual_output = input0.get_lexer_for_body("text/html; charset=utf-8", "")

    assert actual_output == expected_output



# Generated at 2022-06-25 18:40:50.013605
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter('httpie', False, 'solarized256')
    color_formatter.get_style_class('solarized256')


# Generated at 2022-06-25 18:40:53.727528
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():

    # Invalid constructor
    try:
        # None object
        ColorFormatter(env = None)
        assert False
    except:
        assert True

    # Checking default values
    c = ColorFormatter(env = Environment())
    assert c.enabled == True
    assert c.explicit_json == False
    assert c.formatter is not None
    assert c.http_lexer is not None


# Generated at 2022-06-25 18:41:08.307587
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    test_ColorFormatter_get_style_class_0()


# Generated at 2022-06-25 18:41:10.123599
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()



# Generated at 2022-06-25 18:41:12.229738
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:41:22.478035
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    print(lexer.name)
    # http
    print(lexer.aliases)
    # 'http'
    print(lexer.filenames)
    # ['*.http']
    print(lexer.tokens)
    # {'root': [('([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\\d+\\.\\d+)', <built-in function bygroups>), ('(HTTP)(/)(\\d+\\.\\d+)( +)(\\d{3})( +)(.+)', <built-in function bygroups>), ('(.*?)( *)(:)( *)(.+)', <built-in function bygroups>)]}

# Generated at 2022-06-25 18:41:25.397107
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=False)
    assert(ColorFormatter(env, explicit_json=False, color_scheme=SOLARIZED_STYLE, **kwargs).group_name == 'colors')


# Generated at 2022-06-25 18:41:30.149619
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    simplified_h_t_t_p_lexer_0.__init__()


# Generated at 2022-06-25 18:41:37.269046
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env = env, explicit_json = False, color_scheme = DEFAULT_STYLE, **kwargs)
    # What is mime??
    mime = 'text/html'
    # What is body???
    body = '<!DOCTYPE html>'
    color_formatter.format_body(body = body, mime = mime)


# Generated at 2022-06-25 18:41:39.786492
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:41:41.205044
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(Environment(), explicit_json=False, color_scheme=DEFAULT_STYLE)
    color_formatter.get_lexer_for_body('application/json', '{}')


# Generated at 2022-06-25 18:41:48.270344
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env_0 = Environment()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    color_formatter_0 = ColorFormatter(env_0)
    assert color_formatter_0.formatter != None
    assert color_formatter_0.http_lexer != None
    assert color_formatter_0.group_name == 'colors'
    assert color_formatter_0.explicit_json == False


# Generated at 2022-06-25 18:42:16.272588
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer().__init__().name == 'HTTP'
    assert SimplifiedHTTPLexer().__init__().aliases == ['http']
    assert SimplifiedHTTPLexer().__init__().filenames == ['*.http']


# Generated at 2022-06-25 18:42:22.790731
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # solarized256
    # ------------
    # 
    # A Pygments style inspired by Solarized's 256 color mode.
    # 
    # :copyright: (c) 2011 by Hank Gay, (c) 2012 by John Mastro.
    # :license: BSD, see LICENSE for more details.
    # 
    Base03 = "#1c1c1c"
    Base02 = "#262626"
    Base01 = "#4e4e4e"
    Base00 = "#585858"
    Base0 = "#808080"
    Base1 = "#8a8a8a"
    Base2 = "#d7d7af"
    Base3 = "#ffffd7"
    Yellow = "#af8700"
    Orange = "#d75f00"
    Red = "#af0000"
    Mag

# Generated at 2022-06-25 18:42:31.644954
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    e = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    mime = "<class 'httpie.plugins.builtin.download.HTTPDownload'> (['body'])"

# Generated at 2022-06-25 18:42:38.852897
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def test_get_lexer_for_body_0(explicit_json=False):
        lexer = """mime = "application/json"
body = '{ "key": "value" }'"""
        lexer = lexer.strip()
        lexer
        return lexer
    assert pygments.lexers.get_lexer_by_name('json') == test_get_lexer_for_body_0()


# Generated at 2022-06-25 18:42:45.596446
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    assert simplified_h_t_t_p_lexer_0.name == "HTTP"
    assert simplified_h_t_t_p_lexer_0.aliases == ["http"]
    assert simplified_h_t_t_p_lexer_0.filenames == ["*.http"]

# Integration test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-25 18:42:56.390166
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env=env, explicit_json=False, color_scheme='solarized')
    color_formatter.enabled = True
    color_formatter.explicit_json = False
    color_formatter.formatter = Terminal256Formatter(style=Solarized256Style)
    color_formatter.http_lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-25 18:43:01.444579
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Test for the presence of a '</div>'
    color_formatter_0 = ColorFormatter.instance
    mime = 'text/html'
    text = '<div>  hi  </div>'
    actual = color_formatter_0.format_body(text, mime)
    expected = '<div>  hi  </div>'
    assert actual.__contains__(expected)


# Generated at 2022-06-25 18:43:11.126138
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment()
    formatter = ColorFormatter(env, True)

    class TestCase:
        def __init__(self, mime, body, expected):
            self.mime = mime
            self.body = body
            self.expected = expected


# Generated at 2022-06-25 18:43:21.223033
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    test_ColorFormatter = ColorFormatter()
    test_ColorFormatter.enabled = True
    test_ColorFormatter.formatter = Terminal256Formatter()
    test_ColorFormatter.http_lexer = SimplifiedHTTPLexer()
    test_ColorFormatter.explicit_json = True

    # Test 0
    test_headers = "Content-Length: 123\n"
    print(test_ColorFormatter.format_headers(headers=test_headers))

    # Test 1
    test_headers = "Content-Length: 123\n"
    print(test_ColorFormatter.format_headers(headers=test_headers))

    # Test 2
    test_headers = "Content-Length: 123\nContent-Length: 123\n"

# Generated at 2022-06-25 18:43:27.821731
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Test with valid headers and valid content type
    test_case_0()

    # Test with valid headers and invalid content type
    test_case_1()

    # Test with valid headers and no content type
    test_case_2()

    # Test with invalid headers and valid content type
    test_case_3()

    # Test with invalid headers and invalid content type
    test_case_4()

    # Test with invalid headers and no content type
    test_case_5()

    # Test with no headers and valid content type
    test_case_6()

    # Test with no headers and invalid content type
    test_case_7()

    # Test with no headers and no content type
    test_case_8()


# Generated at 2022-06-25 18:44:10.050242
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter_0 = ColorFormatter(
                            env=None,
                            explicit_json=False,
                            color_scheme=None,
        )

    color_formatter_0.format_headers("headers")


# Generated at 2022-06-25 18:44:11.169319
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    test_case_0()



# Generated at 2022-06-25 18:44:12.803678
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    ColorFormatter("env", explicit_json=False, color_scheme=DEFAULT_STYLE)


# Generated at 2022-06-25 18:44:15.451310
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    test_color_formatter_get_style_class_0 = ColorFormatter(
        None,
        None,
        color_scheme=None
    )

# Generated at 2022-06-25 18:44:21.299288
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    ff = ColorFormatter(env=Environment(colors=True), verbose=True)
    mime = 'text/html'
    body = '<!doctype html><html><head><meta charset="utf-8">'
    result = ff.format_body(body, mime)
    assert result == '<!doctype html><html><head><meta charset="utf-8">'
    mime = 'application/json'
    body = '[{"id":1, "name":"SFA"}]'
    result = ff.format_body(body, mime)
    assert result == '[{"id":1, "name":"SFA"}]'


# Generated at 2022-06-25 18:44:28.936258
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter_0 = ColorFormatter(
        env=Environment(
            colors=256,
            isatty=False,
            stdin_isatty=False,
            stdout_isatty=False,
            stderr_isatty=False,
            stdout_is_redirected=True
        ),
        color_scheme='monokai',
        explicit_json=True
    )
    color_formatter_0.get_lexer_for_body(mime='text/plain', body='foo')
    color_formatter_0.format_body(body='foo', mime='text/plain')


# Generated at 2022-06-25 18:44:29.837742
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    pass


# Generated at 2022-06-25 18:44:31.940985
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    test_ColorFormatter_0 = ColorFormatter(0, False, "solarized")


# Generated at 2022-06-25 18:44:33.608639
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment = Environment()
    formatter = ColorFormatter(**{'env': environment})
    assert formatter is not None

# Generated at 2022-06-25 18:44:36.666340
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    CF = ColorFormatter(None, None)
    assert CF.get_style_class('auto') == Solarized256Style
    assert CF.get_style_class('solarized') == Solarized256Style


# Generated at 2022-06-25 18:45:03.796161
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # 0
    environment_0 = module_0.Environment(colors=True)
    explicit_json_0 = False
    color_scheme_0 = DEFAULT_STYLE
    color_formatter_0 = ColorFormatter(environment_0, explicit_json_0, color_scheme_0)
    assert color_formatter_0 is not None


# Generated at 2022-06-25 18:45:13.413620
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='application/json', explicit_json=False, body='') is not None
    assert get_lexer(mime='application/json', explicit_json=True, body='') is not None
    assert get_lexer(mime='application/json', explicit_json=False, body='{}') is not None
    assert get_lexer(mime='application/json', explicit_json=True, body='{}') is not None
    assert get_lexer(mime='application/json', explicit_json=False, body='foo bar') is not None
    assert get_lexer(mime='application/json', explicit_json=True, body='foo bar') is not None
    assert get_lexer(mime='text/foo', explicit_json=False, body='') is not None

# Generated at 2022-06-25 18:45:14.441053
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    test_case_0()

# Generated at 2022-06-25 18:45:25.362863
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    
    # Test a regular header
    header = 'Host: example.com'
    simplified_header = color_formatter_0.format_headers(header)
    assert(simplified_header == '\x1b[38;5;4mHost\x1b[39m: example.com')
    
    # Test a section of the request-response format
    header = 'HTTP/1.1 200 OK'
    simplified_header = color_formatter_0.format_headers(header)

# Generated at 2022-06-25 18:45:36.438548
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.format_body('','text/plain')
    color_formatter_0.format_body('body','application/json')
    color_formatter_0.format_body('','text/javascript')
    color_formatter_0.format_body('body','application/javascript')
    color_formatter_0.format_body('body','')
    color_formatter_0.format_body('','')
    color_formatter_0.format_body('body','text/plain')
    color_formatter_0.format_body('body','text/javascript')
    color_formatter_0.format_body('body','application/json')
    color_formatter_

# Generated at 2022-06-25 18:45:42.702858
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = get_random_str('str', min_length=1, max_length=10)
    ret = color_formatter_0.get_style_class(color_scheme_0)
    assert isinstance(ret, pygments.styles.Style)


# Generated at 2022-06-25 18:45:44.289773
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 18:45:45.698207
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplifiedHttpLexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:45:49.013779
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.group_name == 'colors'


# Generated at 2022-06-25 18:45:56.100250
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    last_lexer_0 = pygments.lexer.RegexLexer(name = 'HTTP', aliases = ['http'], filenames = ['*.http'], tokens = {})
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime_0 = 'application/json' # Default value to pass as argument to the called method
    body_0 = '{"message":"hello HTTPIE!"}' # Default value to pass as argument to the called method

# Generated at 2022-06-25 18:47:10.937647
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body = '<html><body><h1>HTTPie rocks!</h1></body></html>{}\n'
    mime = 'text/html'
    color_formatter_0.format_body(body, mime)


import httpie.config as module_1


# Generated at 2022-06-25 18:47:19.836547
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime_0 = 'text/plain'
    body_0 = 'None'
    pygments.highlight(
        code=body_0,
        lexer=color_formatter_0.get_lexer_for_body(mime_0, body_0),
        formatter=color_formatter_0.formatter,
    )
    mime_1 = 'application/json'
    body_1 = 'None'
    pygments.highlight(
        code=body_1,
        lexer=color_formatter_0.get_lexer_for_body(mime_1, body_1),
        formatter=color_formatter_0.formatter,
    )


# Generated at 2022-06-25 18:47:25.152455
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    expected_0 = "\x1b[38;5;18m{\n  \"foo\": \"bar\"\n}\x1b[0m"
    received_0 = color_formatter_0.format_body('{\n  "foo": "bar"\n}', 'application/json')
    assert received_0 == expected_0

# Generated at 2022-06-25 18:47:35.500040
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_2 = module_0.Environment()
    color_formatter_2 = ColorFormatter(environment_2, explicit_json=True)

    environment_3 = module_0.Environment()
    color_formatter_3 = ColorFormatter(environment_3, explicit_json=False)

    environment_4 = module_0.Environment()
    color_formatter_4 = ColorFormatter(environment_4, explicit_json=False, color_scheme='solarized')

    environment_5 = module_0.Environment()
    color_formatter_5 = ColorFormatter(environment_5, explicit_json=False, color_scheme='solarized', kwargs='abcd')

    environment_6 = module_0.Environment()

# Generated at 2022-06-25 18:47:38.281892
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.group_name == 'colors'

import httpie.downloads as module_1


# Generated at 2022-06-25 18:47:42.322673
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Code coverage test
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    lexer = color_formatter_0.get_lexer_for_body("application/json","abcd")
    assert isinstance(lexer, pygments.lexers.get_lexer_by_name('json')) == True


# Generated at 2022-06-25 18:47:47.975466
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    name_0 = SimplifiedHTTPLexer.name
    aliases_0 = SimplifiedHTTPLexer.aliases
    filenames_0 = SimplifiedHTTPLexer.filenames
    tokens_0 = SimplifiedHTTPLexer.tokens

# Generated at 2022-06-25 18:47:48.931540
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
	pass


# Generated at 2022-06-25 18:47:53.276522
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme = 'murphy'
    try:
        color_formatter_0.get_style_class(color_scheme)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 18:47:58.406532
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body = ''
    mime = 'some/value; some/value; some/value'
    assert get_lexer(
        mime=mime,
        explicit_json=color_formatter_0.explicit_json,
        body=body
    ) == None
