

# Generated at 2022-06-25 18:39:30.341785
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    assert simplified_h_t_t_p_lexer_0.name == "HTTP"
    assert len(simplified_h_t_t_p_lexer_0.aliases) == 1
    assert simplified_h_t_t_p_lexer_0.aliases[0] == "http"
    assert len(simplified_h_t_t_p_lexer_0.filenames) == 1
    assert simplified_h_t_t_p_lexer_0.filenames[0] == "*.http"
    assert (len(simplified_h_t_t_p_lexer_0.tokens.keys()) == 1)

# Generated at 2022-06-25 18:39:36.259308
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    #################################################################
    # Body Formating Unit Test
    #################################################################
    lexer_obj_example = pygments.lexers.get_lexer_by_name('json')
    ColorFormatter_obj = ColorFormatter(Environment.get_default_env())
    result = ColorFormatter_obj.format_body(body='{"hello":"world"}', mime="json")
    expected = pygments.highlight(
        code= '{"hello":"world"}',
        lexer= lexer_obj_example,
        formatter= ColorFormatter_obj.formatter,
    )
    assert result == expected


# Generated at 2022-06-25 18:39:40.066501
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter_0 = ColorFormatter(
        env=None,
        explicit_json=False,
        color_scheme='solarized'
    )
    color_formatter_1 = ColorFormatter(
        env=None,
        explicit_json=False,
        color_scheme='auto'
    )

# Generated at 2022-06-25 18:39:44.350571
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    form_plug = ColorFormatter(Environment(color=True),color_scheme=DEFAULT_STYLE)
    body_str = form_plug.format_body(body='my_body', mime='my_mime')
    assert body_str == 'my_body'


# Generated at 2022-06-25 18:39:55.546129
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    color_formatter = ColorFormatter(env)
    assert(color_formatter.explicit_json == False)
    assert(color_formatter.formatter.__class__ == TerminalFormatter)
    assert(color_formatter.http_lexer.__class__ == PygmentsHttpLexer)

    color_formatter_2 = ColorFormatter(env, True)
    assert(color_formatter_2.explicit_json == True)
    assert(color_formatter_2.formatter.__class__ == TerminalFormatter)
    assert(color_formatter_2.http_lexer.__class__ == PygmentsHttpLexer)

    env.colors = 256
    color_formatter_3 = ColorFormatter(env, True)

# Generated at 2022-06-25 18:39:57.621580
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_0 = ColorFormatter(
        Environment()
    )
    a = color_0.get_style_class('tango')


# Generated at 2022-06-25 18:40:00.237477
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    color_scheme = DEFAULT_STYLE
    explicit_json = False
    ColorFormatter(env, explicit_json, color_scheme)


# Generated at 2022-06-25 18:40:02.547085
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:40:04.396688
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter()
    assert color_formatter.get_style_class('solarized') == Solarized256Style


# Generated at 2022-06-25 18:40:06.372451
# Unit test for function get_lexer
def test_get_lexer():
    assert type(get_lexer('text/html', 'True', '.')) is SimplifiedHTTPLexer  # noqa E501


# Generated at 2022-06-25 18:40:16.608259
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True)
    color_formatter_0 = ColorFormatter(env)
    print(color_formatter_0.name)
    color_formatter_0.format_body("body", "mime")


# Generated at 2022-06-25 18:40:27.500091
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter_1 = ColorFormatter(explicit_json = False)
    print(color_formatter_1.format_body(body = "c29tZSBib2R5IGhlcmU=", mime = "audio/mp3"))
    print(color_formatter_1.format_body(body = "c29tZSBib2R5IGhlcmU=", mime = "text/html"))
    print(color_formatter_1.format_body(body = "c29tZSBib2R5IGhlcmU=", mime = "application/json"))
    print(color_formatter_1.format_body(body = "c29tZSBib2R5IGhlcmU=", mime = "text/html"))

# Generated at 2022-06-25 18:40:29.940103
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True, stdout_isatty=True)
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    ColorFormatter(env, explicit_json, color_scheme)


# Generated at 2022-06-25 18:40:41.465934
# Unit test for function get_lexer
def test_get_lexer():
    get_lexer_0_0 = get_lexer(mime='application/json', explicit_json=False, body='')
    assert(isinstance(get_lexer_0_0, pygments.lexers.special.TextLexer))
    get_lexer_0_1 = get_lexer(mime='application/json', explicit_json=False, body='{"message":"hello world"}')
    assert(isinstance(get_lexer_0_1, pygments.lexers.data.JsonLexer))
    get_lexer_0_2 = get_lexer(mime='text/json', explicit_json=False, body='')
    assert(isinstance(get_lexer_0_2, pygments.lexers.special.TextLexer))

# Generated at 2022-06-25 18:40:43.338020
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:40:51.990236
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer_0 = SimplifiedHTTPLexer()
    assert hasattr(simplified_h_t_t_p_lexer_0, "name")
    assert simplified_h_t_t_p_lexer_0.name == "HTTP"
    assert hasattr(simplified_h_t_t_p_lexer_0, "aliases")
    assert simplified_h_t_t_p_lexer_0.aliases == ["http"]
    assert hasattr(simplified_h_t_t_p_lexer_0, "filenames")
    assert simplified_h_t_t_p_lexer_0.filenames == ["*.http"]

# Generated at 2022-06-25 18:40:52.913432
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env_0 = Environment()
    color_formatter_0 = ColorFormatter(env_0)


# Generated at 2022-06-25 18:40:55.419498
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter_0 = ColorFormatter(
        {'colors': 2},
        False,
        None
    )
    assert (
        ColorFormatter.get_style_class(
            SOLARIZED_STYLE
        ) == Solarized256Style
    )

# Generated at 2022-06-25 18:41:05.654568
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Testing property style_name
    color_formatter_0 = ColorFormatter(
        env=None,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
        **{}
    )
    assert color_formatter_0.style_name == DEFAULT_STYLE
    color_formatter_0.color_scheme = SOLARIZED_STYLE
    assert color_formatter_0.style_name == SOLARIZED_STYLE
    # Testing property style_class
    color_formatter_0 = ColorFormatter(
        env=None,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
        **{}
    )
    assert color_formatter_0.style_class == TerminalFormatter

# Generated at 2022-06-25 18:41:16.813562
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env=Environment()
    color_scheme=DEFAULT_STYLE
    explicit_json=False

# Generated at 2022-06-25 18:41:26.941615
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Setup
    env = os.environ
    env["HTTPIE_COLORS"] = "256"
    env["HTTPIE_STYLE"] = "solarized"
    color_formatter = ColorFormatter(env)
    color_scheme = SOLARIZED_STYLE

    # Exercise
    style_class = color_formatter.get_style_class(str(color_scheme))

    # Verify
    assert style_class == Solarized256Style


# Generated at 2022-06-25 18:41:33.432879
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    httpie_environment_var = os.environ.get('HTTPIE_ENV')
    httpie_environment_var_0 = os.environ.get('HTTPIE_ENV_0')
    http_lexer_0 = PygmentsHttpLexer()
    color_formatter_0 = ColorFormatter(env=httpie_environment_var)


# Generated at 2022-06-25 18:41:36.417886
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(Environment({}), False, 'solarized')
    color_formatter.get_style_class('solarized')


# Generated at 2022-06-25 18:41:38.341943
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # ColorFormatter:ColorFormatter()
    assert True # TODO: implement your test here



# Generated at 2022-06-25 18:41:43.199987
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    color_formatter = ColorFormatter(env)
    color_formatter.format_headers("")
    color_formatter.format_headers("Content-Type: text/html; charset=UTF-8")


# Generated at 2022-06-25 18:41:47.843452
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter_0 = ColorFormatter()
    color_scheme = 'solarized'
    style_class = color_formatter_0.get_style_class(color_scheme)
    assert style_class==Solarized256Style

# Generated at 2022-06-25 18:41:49.817200
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_h_t_t_p_lexer = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:41:54.431033
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter_0 = ColorFormatter(
        env=Environment(),
        explicit_json=False,
        color_scheme='solarized',
    )
    # Test with default values of the keyword arguments.
    color_formatter_1 = ColorFormatter()


# Generated at 2022-06-25 18:42:03.406241
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    test_instance = ColorFormatter(None, None, None)
    # body_is_bytes = True
    body_is_bytes = True
    mime = 'application/json'
    body = b'{"hello": "world"}'
    expected_result = body if body_is_bytes else test_instance.format_body(body, mime)
    result = test_instance.format_body(body, mime)
    assert result == expected_result, 'Expected: {}, but got: {}'.format(expected_result, result)


# Generated at 2022-06-25 18:42:04.276995
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    colorFormatter = ColorFormatter(Environment())

# Generated at 2022-06-25 18:42:17.047707
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    _mime_0 = 'UNKNOWN_MIME_TYPE'
    _body_0 = 'UNKNOWN_BODY'

# Generated at 2022-06-25 18:42:24.180680
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    # case 1
    arguments_0 = 'text/html'
    arguments_1 = '<html></html>'
    result_0 = color_formatter_0.get_lexer_for_body(arguments_0, arguments_1)
    assert result_0.__name__ == 'HTMLLexer'
    # case 2
    arguments_2 = ''
    arguments_3 = ''
    result_1 = color_formatter_0.get_lexer_for_body(arguments_2, arguments_3)
    assert result_1 == None


# Generated at 2022-06-25 18:42:32.797546
# Unit test for function get_lexer
def test_get_lexer():
    # Test correct names
    assert isinstance(get_lexer("text/html"), pygments.lexers.html.HtmlLexer)
    assert isinstance(get_lexer("text/css"), pygments.lexers.css.CssLexer)
    assert isinstance(get_lexer("text/xml"), pygments.lexers.xml.XmlLexer)
    assert isinstance(get_lexer("application/javascript"), pygments.lexers.javascript.JavascriptLexer)
    assert isinstance(get_lexer("application/xml"), pygments.lexers.xml.XmlLexer)
    assert isinstance(get_lexer("application/json"), pygments.lexers.json.JsonLexer)

    # Test incorrect names
    assert isinstance(get_lexer("text/xhtml"), TextLexer)

# Generated at 2022-06-25 18:42:39.931785
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = 'Test string'
    mime_0 = 'application/json'
    assert color_formatter_0.format_body(body_0, mime_0) == "\x1b[38;5;11m" \
                                                             "Test string" \
                                                             "\x1b[39m"


# Generated at 2022-06-25 18:42:43.046136
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    
# Test if http_lexer of class Color was created correctly

# Generated at 2022-06-25 18:42:46.856890
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body(): 
    assert(ColorFormatter.format_body(ColorFormatter(), 'HTTP/1.1 400 Bad Request\r\n', 'HTTP/1.1 400 Bad Request\r\n')
            == 'HTTP/1.1 400 Bad Request\r\n')



# Generated at 2022-06-25 18:42:47.997701
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    test_case_0()

# Generated at 2022-06-25 18:42:48.880883
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    pass


# Generated at 2022-06-25 18:42:51.839558
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert_equal(color_formatter_0.format_headers(""), "")


# Generated at 2022-06-25 18:42:56.770678
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime = 'application/json'
    body = ''
    result = color_formatter_0.get_lexer_for_body(mime, body)
    assert result is not None


# Generated at 2022-06-25 18:43:11.254877
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.get_lexer_for_body('application/json', 'NoVuSg31cPU7eQi6mzzmb7VwPBZFGzE4V3qD')

# Generated at 2022-06-25 18:43:14.899517
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)

    return color_formatter_1.get_lexer_for_body('application/json', '{\n"foo": "bar"\n}')

import httpie.plugins as module_1


# Generated at 2022-06-25 18:43:20.536622
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    mime = 'application/json'
    body = 'json'
    assert color_formatter_0.get_lexer_for_body(mime, body) == pygments.lexers.get_lexer_by_name('json')


# Generated at 2022-06-25 18:43:24.744811
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = 'fruity'
    class_0 = color_formatter_0.get_style_class(color_scheme_0)
    assert [class_0.name] == ['fruity']


# Generated at 2022-06-25 18:43:29.819881
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body = "cute"
    mime = "application/json"
    result = color_formatter_0.format_body(body, mime)


# Generated at 2022-06-25 18:43:30.920275
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer



# Generated at 2022-06-25 18:43:35.653298
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = 'I am a JSON body.'
    mime_0 = 'application/json'
    rv_0 = color_formatter_0.format_body(body_0, mime_0)

# Generated at 2022-06-25 18:43:39.056142
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment = Environment()
    color_formatter = ColorFormatter(environment)
    headers = "string"
    assert color_formatter.format_headers(headers) == "string"


# Generated at 2022-06-25 18:43:43.929452
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = "test"
    mime_0 = "test"
    color_formatter_0.format_body(body_0, mime_0)


# Generated at 2022-06-25 18:43:51.171434
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    with mock.patch('httpie.context.Environment') as mock_Environment:
        mock_Environment().colors = unittest.mock.sentinel.colors
        mock_Environment().style = unittest.mock.sentinel.style
        mock_Environment.return_value = mock_Environment()
        color_formatter_0 = ColorFormatter(environment_0)



# Generated at 2022-06-25 18:44:19.455480
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    token_0 = pygments.token.Token
    token_1 = pygments.token.Token
    lexer_0 = SimplifiedHTTPLexer()
    assert lexer_0.name == 'HTTP'
    assert lexer_0.aliases == ['http']
    assert lexer_0.filenames == ['*.http']

# Generated at 2022-06-25 18:44:25.528965
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    environment_0.stdout_isatty = True
    environment_0.colors = 256
    expected_0 = 'aGVsbG8gd2U='
    actual_0 = color_formatter_0.format_body('aGVsbG8gd2U=', 'application/base64')

    assert actual_0 == expected_0


# Generated at 2022-06-25 18:44:27.109401
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

# Generated at 2022-06-25 18:44:30.600868
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.get_style_class(AUTO_STYLE)
    color_formatter_0.get_style_class(SOLARIZED_STYLE)


# Generated at 2022-06-25 18:44:32.075708
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplifiedHTTPlexer_0 = SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:44:42.331699
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_http_lexer_0 = SimplifiedHTTPLexer()
    simplified_http_lexer_0_clone = simplified_http_lexer_0.clone()
    simplified_http_lexer_0_hashcode = simplified_http_lexer_0.__hash__()
    simplified_http_lexer_0_repr = simplified_http_lexer_0.__repr__()
    simplified_http_lexer_0_str = simplified_http_lexer_0.__str__()
    simplified_http_lexer_0_get_tokens_unprocessed = simplified_http_lexer_0.get_tokens_unprocessed("")
    simplified_http_lexer_0_get_tokens = simplified_http_lexer_0.get_tokens("")
   

# Generated at 2022-06-25 18:44:44.597735
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)
    result_1 = color_formatter_1.get_style_class("solarized")

# Generated at 2022-06-25 18:44:50.501103
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    param_0 = 'foo'
    assert_equals(color_formatter_0.format_headers(param_0), '<span style="color: #aafa00;">' + param_0 + '</span>')


# Generated at 2022-06-25 18:44:59.540370
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():

    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.format_body(body='', mime='')

    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.format_body(body='o', mime='')

    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.format_body(body='6', mime='')

    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)

# Generated at 2022-06-25 18:45:09.410932
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_1 = module_0.Environment()
    color_formatter_1 = ColorFormatter(environment_1)
    arg_mime_0 = 'text/html'
    arg_body_0 = '<!DOCTYPE html>\n<html><head><title>Test</title></head><body>Test</body></html>'
    fn_return_0 = color_formatter_1.format_body(arg_mime_0, arg_body_0)

# Generated at 2022-06-25 18:45:51.837246
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0.format_body("body", "mime") == "body"


# Generated at 2022-06-25 18:45:54.269621
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(
        mime='application/json',
        explicit_json=False,
        body=''
    ) == pygments.lexers.get_lexer_by_name('json')


# Generated at 2022-06-25 18:46:04.361226
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers = "GET / HTTP/1.1\nAccept: */*\nHost: example.org\nUser-Agent: HTTPie/0.1.0-dev"

# Generated at 2022-06-25 18:46:08.588810
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert color_formatter_0

import httpie.plugins as module_1

import pygments.lexer as module_2


# Generated at 2022-06-25 18:46:13.062292
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    # ColorFormatter.get_style_class(solarized256)
    #assert color_formatter_0.get_style_class(solarized256) == Solarized256Style

import httpie.plugin as module_1


# Generated at 2022-06-25 18:46:21.639676
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    test_SimplifiedHTTPLexer_1()
    test_SimplifiedHTTPLexer_2()
    test_SimplifiedHTTPLexer_3()
    test_SimplifiedHTTPLexer_4()
    test_SimplifiedHTTPLexer_5()
    test_SimplifiedHTTPLexer_6()
    test_SimplifiedHTTPLexer_7()
    test_SimplifiedHTTPLexer_8()
    test_SimplifiedHTTPLexer_9()
    test_SimplifiedHTTPLexer_10()
    test_SimplifiedHTTPLexer_11()
    test_SimplifiedHTTPLexer_12()
    test_SimplifiedHTTPLexer_13()
    test_Sim

# Generated at 2022-06-25 18:46:30.333706
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    assert http_lexer.name == 'HTTP'
    assert http_lexer.tokens['root'][0] == (r'([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)',
         pygments.lexer.bygroups(pygments.token.Name.Function,
                                 pygments.token.Text,
                                 pygments.token.Name.Namespace,
                                 pygments.token.Text,
                                 pygments.token.Keyword.Reserved,
                                 pygments.token.Operator,
                                 pygments.token.Number))

# Generated at 2022-06-25 18:46:34.077266
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    str_0 = color_formatter_0.format_headers(headers="Content-Type: application/json;charset=utf-8")
    assert str_0 is not None


# Generated at 2022-06-25 18:46:37.815629
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_formatter_0.get_lexer_for_body = lambda a, b: "METAL"
    assert color_formatter_0.format_body("", "") == "METAL"


# Generated at 2022-06-25 18:46:41.976929
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = "test"
    mime_0 = "test"
    output_result_0 = color_formatter_0.format_body(body_0, mime_0)
    assert output_result_0 == "test"


# Generated at 2022-06-25 18:48:16.125785
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    color_scheme_0 = 'auto'
    style_class_0 = color_formatter_0.get_style_class(color_scheme_0)
    assert isinstance(style_class_0, type)
    assert issubclass(style_class_0, pygments.style.Style)


# Generated at 2022-06-25 18:48:20.303013
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    with open('/tmp/test_output.txt', 'w') as file_0:
        file_0.write(color_formatter_0.format_headers('headers'))


# Generated at 2022-06-25 18:48:25.951871
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.context as module_0
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    result = color_formatter_0.format_body("", "")
    assert type(result) is str


# Generated at 2022-06-25 18:48:36.385737
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    #Test case for ColorFormatter with default arguments
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    #Test case for ColorFormatter with explicit json set to False, color_scheme set to 'auto'
    color_formatter_1 = ColorFormatter(environment_0, False, 'auto')
    #Test case for ColorFormatter with explicit json set to False, color_scheme set to 'solarized'
    color_formatter_2 = ColorFormatter(environment_0, False, 'solarized')
    #Test case for ColorFormatter with explicit json set to False, color_scheme set to 'fruity'
    color_formatter_3 = ColorFormatter(environment_0, False, 'fruity')
    #Test case for ColorFormatter with

# Generated at 2022-06-25 18:48:39.699086
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # TODO: Check if any exception is thrown
    SimplifiedHTTPLexer()


# Generated at 2022-06-25 18:48:40.929040
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('test')


# Generated at 2022-06-25 18:48:45.120864
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    assert not color_formatter_0.format_body("response body", "text/html; charset=UTF-8")


# Generated at 2022-06-25 18:48:54.372539
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    environment_0 = module_0.Environment()
    color_formatter_0 = ColorFormatter(environment_0)
    body_0 = '{"response": "{}"}'
    mime_0 = 'application/json'
    Lexer_0 = get_lexer(
        mime=mime_0,
        explicit_json=False,
        body=body_0
    )
    color_formatter_1 = ColorFormatter(environment_0)
    body_1 = '{"response": "{}"}'
    mime_1 = 'application/json'
    color_formatter_1.format_body(body_1, mime_1)


# Generated at 2022-06-25 18:48:55.517407
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    test_case_0()



# Generated at 2022-06-25 18:48:59.720503
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    try:
        environment_0 = module_0.Environment()
        color_formatter_0 = ColorFormatter(environment_0)
        headers_0 = ''
        color_formatter_0.format_headers(headers_0)
    except:
        print("Unexpected error:", sys.exc_info()[0])
