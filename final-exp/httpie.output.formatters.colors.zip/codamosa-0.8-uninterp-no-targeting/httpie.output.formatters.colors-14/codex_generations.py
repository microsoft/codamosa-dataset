

# Generated at 2022-06-21 14:03:13.172654
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert True

# Generated at 2022-06-21 14:03:14.409869
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style()

# Generated at 2022-06-21 14:03:25.761340
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import isatty
    from httpie import ExitStatus, __version__
    from httpie.cli import parser
    environment = Environment(
        colors=256 if isatty(2) else 0,
        stdin=None,
        stdout=None,
        stderr=None,
        is_windows=is_windows,
        version=__version__,
    )

    args = parser.parse_args([
        '--verbose',
        '--formatter=colors',
        '--stream',
        '--output=solarized',
        'GET',
        'http://httpbin.org/get',
    ])

# Generated at 2022-06-21 14:03:33.859092
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    a = ColorFormatter(Environment(), "" ,'auto')
    # base case
    assert a.format_body("Hello World", "text/plain") == "Hello World"
    # css case
    assert a.format_body("body { font: Roboto; }", "text/css") ==\
    "\x1b[38;5;33mbody {\n    font: Roboto;\n}\x1b[0m"
    # json case
    assert a.format_body('{"key": "value"}', "text/html") == '{"key": "value"}'

# Generated at 2022-06-21 14:03:40.598953
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(
        env=Environment(),
        explicit_json=True,
        color_scheme=DEFAULT_STYLE
    )
    assert color_formatter.enabled
    assert color_formatter.formatter.style

    color_formatter = ColorFormatter(
        env=Environment(colors=0),
    )
    assert not color_formatter.enabled
    assert not color_formatter.formatter

# Generated at 2022-06-21 14:03:43.653829
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment(colors=False, defaults=None)
    assert ColorFormatter(env, explicit_json=False, color_scheme='fruity')

# Generated at 2022-06-21 14:03:46.228222
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.plugins
    httpie.plugins.__all__ = []
    from httpie.plugins import BuiltinPluginLoader
    assert ColorFormatter(BuiltinPluginLoader().load_all())

# Generated at 2022-06-21 14:03:52.841425
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Get the color formatter
    from httpie.plugins import FormatterPluginManager
    formatter = FormatterPluginManager.instances[0]

    # Get the headers from the CLI arguments
    from httpie.cli import parser
    from httpie import __version__
    args = parser.parse_args(['kev', 'https://httpbin.org/get'])
    headers = args.headers
    # Add version header
    headers.append('%s/%s' %
                   (formatter.CONTENT_TYPE_HEADER_NAME, __version__))
    headers.append('Accept-Encoding: ')
    headers.append('Accept: */*')
    headers.append('Accept-Encoding: gzip, deflate')
    headers.append('Host: httpbin.org')

# Generated at 2022-06-21 14:04:01.581473
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.base import BaseOutputSettings
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.plugins import PluginManager
    from httpie.output.streams import PathIO
    from httpie.config import Config
    from httpie import ExitStatus
    from httpie.cli import get_exit_status
    from httpie.compat import filename_to_ui, str


# Generated at 2022-06-21 14:04:12.252291
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = "Content-Type: text/plain\nX-Header: Foo\n\n"
    assert formatter.format_headers(headers) == ('\x1b[38;5;115mContent-Type'
        ': \x1b[0m\x1b[38;5;184mtext/plain\x1b[0m\n\x1b[38;5;115mX-Header:'
        ' \x1b[0m\x1b[38;5;184mFoo\x1b[0m\n\n')


# Generated at 2022-06-21 14:04:21.844608
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    lexer = formatter.get_lexer_for_body(
        mime="text/json",
        body='{"foo": 42}'
    )
    assert lexer is pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-21 14:04:25.360185
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    colorFormatter = ColorFormatter(None)
    assert colorFormatter.get_style_class("solarized") == Solarized256Style
    assert colorFormatter.get_style_class("manni") == pygments.styles.get_style_by_name("manni")

# Generated at 2022-06-21 14:04:25.992174
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Enviro

# Generated at 2022-06-21 14:04:27.851207
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Unit test of function get_lexer

# Generated at 2022-06-21 14:04:33.941006
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment()
    formatter = ColorFormatter(env, color_scheme='solarized')

    # Case 1 - The color scheme name is found on Pygments
    style_class = formatter.get_style_class('manni')
    assert style_class == pygments.styles.get_style_by_name('manni')

    # Case 2 - The color scheme name is not found on Pygments
    style_class = formatter.get_style_class('unknown_color_scheme')
    assert style_class == Solarized256Style

# Generated at 2022-06-21 14:04:43.927677
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from pygments.lexers.text import HttpLexer
    from pygments.lexers.data import JsonLexer
    color_formatter = ColorFormatter(None)
    assert color_formatter.get_lexer_for_body('application/json', '{}') == JsonLexer
    assert color_formatter.get_lexer_for_body('application/json', '') == JsonLexer
    assert color_formatter.get_lexer_for_body('application/hal+json', '') == JsonLexer
    assert color_formatter.get_lexer_for_body('application/hal+json', '{}') == JsonLexer
    assert not color_formatter.get_lexer_for_body('application/hal+xml', '')
    assert not color_formatter.get_

# Generated at 2022-06-21 14:04:54.862327
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def check(mime, body, expected_lexer_name):
        lexer = get_lexer(mime=mime, body=body)
        assert lexer.name == expected_lexer_name

    check('application/json', '{}', 'JSON')
    check('application/json', '', 'Text only')
    check('text/css', '', 'CSS')
    check('text/html', '', 'HTML')
    check('text/html', '<html></html>', 'HTML')
    check('application/xhtml+xml', '<html></html>', 'HTML')
    check('application/xhtml+xml', '', 'XML')

# Generated at 2022-06-21 14:05:06.101738
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style.BASE03 == "#1c1c1c"

# Generated at 2022-06-21 14:05:17.616678
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import pytest

    env = Environment(colors=256, stdout_isatty=True)

    formatter1 = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
    assert formatter1.formatter.__class__ is Terminal256Formatter
    assert formatter1.http_lexer is SimplifiedHTTPLexer

    formatter2 = ColorFormatter(env, color_scheme=DEFAULT_STYLE)
    assert formatter2.formatter.__class__ is TerminalFormatter
    assert formatter2.http_lexer is PygmentsHttpLexer

    formatter3 = ColorFormatter(env, color_scheme='does_not_exist')
    assert formatter3.formatter.__class__ is TerminalFormatter
    assert formatter3.http_lexer is Py

# Generated at 2022-06-21 14:05:18.916877
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert str(SimplifiedHTTPLexer('')) == '<SimplifiedHTTPLexer>'



# Generated at 2022-06-21 14:05:27.818804
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import httpie.plugins
    assert httpie.plugins.colors.ColorFormatter



# Generated at 2022-06-21 14:05:34.488673
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')
    assert ColorFormatter.get_style_class('default.') == pygments.styles.get_style_by_name('default')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized.') == Solarized256Style

# Generated at 2022-06-21 14:05:43.076729
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment(colors=True)
    cf = ColorFormatter(env)
    mime = 'text/plain'
    body = 'This is a test.'
    expected = 'This is a test.'
    result = cf.format_body(body, mime)
    assert (result == expected)
    mime = 'application/json'
    body = '{"key1": "value1"}'
    expected = '{\n    \x1b[38;5;45m"key1"\x1b[39m: \x1b[38;5;45m"value1"\x1b[39m\n}'
    result = cf.format_body(body, mime)
    assert (result == expected)

# Generated at 2022-06-21 14:05:48.884709
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # SimplifiedHTTPLexer is a subclass of RegexLexer
    assert issubclass(SimplifiedHTTPLexer, pygments.lexer.RegexLexer)
    # The following code is a complete application of SimplifiedHTTPLexer
    # adapted from pygments/styles/__init__.py
    from pygments.util import ClassNotFound
    from pygments.lexers.special import TextLexer
    from pygments.token import Error

    string = '''\
GET /index.html HTTP/1.1
Host: www.google.com\
'''
    lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(style=Solarized256Style)
    print(pygments.highlight(string, lexer, formatter))

# Generated at 2022-06-21 14:06:00.970444
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') == \
        pygments.lexers.get_lexer_by_name('text')
    assert get_lexer('text/html') == \
        pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/html; charset=utf-8') == \
        pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('application/json') == \
        pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/javascript') == \
        pygments.lexers.get_lexer_by_name('javascript')
    assert get_lexer('application/vnd.example+json') == \
        pygments.lexers.get

# Generated at 2022-06-21 14:06:09.318622
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Example request headers from RFC 7230 Section 5.4
    req_headers = """\
GET / HTTP/1.1
Host: example.com
Accept: image/gif, image/jpeg, */*
Accept-Language: en-us
Accept-Encoding: gzip, deflate
User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)
Connection: Keep-Alive"""

    # Example response headers from RFC 7230 Section 6.5

# Generated at 2022-06-21 14:06:16.814542
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import unittest
    from httpie.utils import SearchDict

    class TestCase(unittest.TestCase):
        def test_format_headers(self):
            env = Environment()
            env.colors = [256]
            cf = ColorFormatter(env)

            headers = SearchDict(
                [
                    ('Status', '200 OK'),
                    ('Date', 'Thu, 27 Nov 2014 15:03:03 GMT'),
                    ('Content-Type', 'application/json')
                ]
            )

            # Show Headers
            headers_showed = cf.format_headers(headers)

# Generated at 2022-06-21 14:06:17.626161
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-21 14:06:28.906060
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    print('testing ColorFormatter.format_headers')
    # a header
    assert ColorFormatter.format_headers('string') == '\x1b[39m\x1b[38;5;251mstring\x1b[39m\x1b[0m'

    # JSON headers

# Generated at 2022-06-21 14:06:39.035139
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.formatter.colors import ColorFormatter
    color_formatter = ColorFormatter(None)
    assert color_formatter.get_lexer_for_body("application/json", "{}") == pygments.lexers.get_lexer_by_name("json")
    assert color_formatter.get_lexer_for_body("application/json", "{}", explicit_json=True) == pygments.lexers.get_lexer_by_name("json")
    assert not color_formatter.get_lexer_for_body("application/json", "")
    assert not color_formatter.get_lexer_for_body("application/json", "", explicit_json=True)



# Generated at 2022-06-21 14:06:57.855586
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment(), False, 'base16')
    assert formatter.enabled == True

# Generated at 2022-06-21 14:07:00.155506
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']



# Generated at 2022-06-21 14:07:01.153688
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    pass

# Generated at 2022-06-21 14:07:03.986186
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style.__module__ == 'httpie.plugins.colors'
    assert Solarized256Style.__name__ == 'Solarized256Style'

# Generated at 2022-06-21 14:07:05.699183
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-21 14:07:14.090640
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import StringIO
    sample = StringIO.StringIO("""
GET / HTTP/1.1
Host: google.com
Accept: text/plain
Accept-Encoding: gzip, deflate

HTTP 1.1 200 OK
Content-Type: text/plain
Date: Sat, 21 Apr 2018 17:53:53 GMT
Server: Apache
Transfer-Encoding: chunked
Connection: Keep-Alive
Content-Encoding: gzip

Some data
    """)
    lexer = SimplifiedHTTPLexer()
    sample.seek(0)
    for line in sample:
        for token, content in lexer.get_tokens(line):
            print("%s, %s, %s" % (str(token), content, token.split('.')[-1]))

# Generated at 2022-06-21 14:07:24.260625
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import httpie.compat
    import pygments.lexers
    from httpie.core import http_names_and_values

    if httpie.compat.is_windows():
        assert True
        return

    # Save original value
    original = httpie.core.EXCLUDED_TYPES
    httpie.core.EXCLUDED_TYPES = ('text/plain',)

    formatter = ColorFormatter(
        env=httpie.Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    assert formatter.enabled

    # h = headers string

# Generated at 2022-06-21 14:07:35.556575
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    is_windows = False
    if is_windows:
        style = Solarized256Style
    else:
        style = pygments.styles.get_style_by_name("monokai")
    formatter = Terminal256Formatter(style=style)
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-21 14:07:43.852751
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class TestColorFormatter(ColorFormatter):
        def get_style_class(self, color_scheme: str) -> Type[pygments.style.Style]:
            return Solarized256Style

    color_name = 'solarized-{}'.format(Solarized256Style._name)
    env = Environment()
    env.update({'colors': 256})
    fmt = TestColorFormatter(env, color_scheme=color_name, verbose=False)

    expected_json = """\
{
    "status": "ok",
    "version": "1.x"
}
"""
    actual_json = fmt.format_body('{"status": "ok", "version": "1.x"}', "application/json")  # noqa
    assert actual_json == expected_json


# Generated at 2022-06-21 14:07:54.133834
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import re
    import httpie.plugins.builtin.colors
    import httpie.plugins.builtin.format
    import httpie.output
    import httpie.context
    from httpie.plugins.builtin.colors import ColorFormatter
    from httpie.plugins.builtin.format import Formatter
    from httpie.output.streams import Stream
    from httpie.output.writers import StdoutWriter
    from httpie.context import Environment
    from pygments.lexers import JsonLexer
    from pygments.style import Style
    from pygments.formatters import TerminalFormatter


# Generated at 2022-06-21 14:08:29.730760
# Unit test for function get_lexer
def test_get_lexer():
    # HTML
    assert get_lexer('text/html') == pygments.lexers.html.HtmlLexer
    asser

# Generated at 2022-06-21 14:08:39.504572
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    """
    Test ColorFormatter.get_style_class method

    """
    if is_windows:
        # fruty color style for windows
        assert ColorFormatter.get_style_class(
            'solarized'
        ) == Solarized256Style
        assert ColorFormatter.get_style_class(
            'auto'
        ) == pygments.styles.get_style_by_name('fruity')
    else:
        # solarized color style for other OSes
        assert ColorFormatter.get_style_class(
            'solarized'
        ) == Solarized256Style
        assert ColorFormatter.get_style_class(
            'auto'
        ) == Solarized256Style

# Generated at 2022-06-21 14:08:40.060622
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    pass

# Generated at 2022-06-21 14:08:44.667724
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer(mime='application/json', body='{}')
    assert lexer and lexer.name == 'JSON', lexer

    lexer = get_lexer(mime='application/sometype+json', body='{}')
    assert lexer and lexer.name == 'JSON', lexer

    lexer = get_lexer(mime='application/unknown', body='{}')
    assert lexer and lexer.name == 'Text only', lexer

# Generated at 2022-06-21 14:08:56.426306
# Unit test for function get_lexer

# Generated at 2022-06-21 14:08:58.276333
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-21 14:09:08.948636
# Unit test for function get_lexer
def test_get_lexer():
    # Test 1 - text/html but with invalid HTML
    html_lexer = get_lexer('text/html', b"<html><head><body><h1>")
    assert html_lexer.name == 'HTML'

    # Test 2 - text/plain
    plain_lexer = get_lexer('text/plain')
    assert plain_lexer.name == 'Text only'

    # Test 3 - Non-existent MIME type
    no_lexer = get_lexer('application/nonexist')
    assert no_lexer is None

    # Test 4 - application/json
    json_lexer = get_lexer('application/json')
    assert json_lexer.name == 'JSON'

    # Test 5 - application/json but with invalid JSON

# Generated at 2022-06-21 14:09:11.200123
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    solarized256 = Solarized256Style
    assert solarized256.background_color == "#1c1c1c"
    assert solarized256.styles[pygments.token.Number] == "#00afaf"

# Generated at 2022-06-21 14:09:17.213668
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    raw_headers = b"""GET / HTTP/1.1\r\nHost: localhost:5050\r\nUser-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:44.0) Gecko/20100101 Firefox/44.0\r\nAccept: */*\r\nAccept-Language: en-US,en;q=0.5\r\nAccept-Encoding: gzip, deflate\r\nCookie: _xsrf=2|d9f9a9ac|2740594e1b0f1de2d11c75b10390160c|1457503788\r\nConnection: keep-alive\r\nCache-Control: max-age=0\r\n\r\n"""

# Generated at 2022-06-21 14:09:18.822172
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert isinstance(ColorFormatter._create(None, None), ColorFormatter)

# Generated at 2022-06-21 14:10:34.377332
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = pygments.formatter.Formatter(style='none')
    class FakeEnv(object):
        def __init__(self):
            self.colors = 256
        def get_style(self):
            return pygments.style.Style
        def get_formatter(self):
            return formatter
    color_formatter = ColorFormatter(FakeEnv(), explicit_json=False,
                                     color_scheme='solarized')

# Generated at 2022-06-21 14:10:43.321989
# Unit test for function get_lexer
def test_get_lexer():
    assert not get_lexer('application/xml', explicit_json=False, body='')
    assert get_lexer('application/json', explicit_json=False, body='').__name__ == 'JSONLexer'
    assert get_lexer('application/json', explicit_json=False, body='').__name__ == 'JSONLexer'
    assert get_lexer('application/json', explicit_json=False, body='{"a":"b"}').__name__ == 'JSONLexer'
    assert not get_lexer('application/json', explicit_json=False, body='not json')
    assert get_lexer('application/json', explicit_json=True, body='not json').__name__ == 'JSONLexer'

# Generated at 2022-06-21 14:10:48.198160
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class env:
        colors = True
    formatter = ColorFormatter(env=env)
    body = formatter.format_body('[1, 2, 3, 4]', 'application/json')
    assert body == '<pygments.formatters.terminal.TerminalFormatter object at 0x000002427B832278>'

# Generated at 2022-06-21 14:10:52.219561
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE).__name__ == \
           'TerminalFormatter'
    assert ColorFormatter.get_style_class('solarized').__name__ == \
           'Solarized256Style'
    assert ColorFormatter.get_style_class('nonexistent') is None

# Generated at 2022-06-21 14:10:53.299011
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert style.styles == Solarized256Style.styles

# Generated at 2022-06-21 14:10:59.861816
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from unittest import mock
    class TestColorFormatter(ColorFormatter):
        def __init__(
            self,
            env: Environment,
            explicit_json=False,
            color_scheme=DEFAULT_STYLE,
            **kwargs
        ):
            super().__init__(**kwargs)
            self.env = env
            self.explicit_json = explicit_json
            self.formatter = None
            self.http_lexer = None

    with mock.patch('httpie.plugins.builtin.colors.DEFAULT_STYLE', 'solarized'):
        assert(
            Solarized256Style ==
            TestColorFormatter(
                env=Environment(colors=256),
                color_scheme='auto'
            ).get_style_class('auto')
        )

# Generated at 2022-06-21 14:11:10.663895
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    import pytest

    class MockLexer:
        name = "json"

    class MockLexer2:
        name = "test"

    class MockLexer3:
        name = "text"

    class MockLexer4:
        name = "json"

    class MockEnvironment:
        colors = True
        style = None

    content_types = {
        "application/json": json.loads,
        "application/xml": None
    }


# Generated at 2022-06-21 14:11:17.941656
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    def test(content_type, data, expected_lexer_name):
        print('content type:'+ content_type)
        if data:
            print('data:'+ data)
        formatter = ColorFormatter(Environment())
        lexer = formatter.get_lexer_for_body(content_type, data)
        if lexer:
            lexer_name = lexer.name
        else:
            lexer_name = None

        print('expected lexer:'+ str(expected_lexer_name))
        print('actual lexer:' + str(lexer_name))
        if expected_lexer_name != lexer_name:
            raise Exception('expected {}, got {}'.format(
                expected_lexer_name, lexer_name
            ))

    test('text/plain', 'abcdefgh', None)

# Generated at 2022-06-21 14:11:29.040848
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import UnsupportedEnvironment

    class MockEnvironment:
        def __init__(self, colors=0):
            self.colors = colors

    class MockStream:
        def __init__(self):
            self.written = ""

        def write(self, bytes):
            self.written += bytes

    class MockStdStreams:
        def __init__(self):
            self.stdout = MockStream()
            self.stderr = MockStream()


# Generated at 2022-06-21 14:11:34.472134
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    "Test the constructor of ColorFormatter"
    env = Environment()
    assert env.colors == 256
    ColorFormatter(env)

    env.colors = 256
    ColorFormatter(env, color_scheme='tango')

    env.colors = 256
    ColorFormatter(env, color_scheme='auto')

    env.colors = 16
    ColorFormatter(env, color_scheme='solarized')