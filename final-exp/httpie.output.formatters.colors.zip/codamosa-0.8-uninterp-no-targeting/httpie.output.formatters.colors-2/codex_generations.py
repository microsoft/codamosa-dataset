

# Generated at 2022-06-21 14:03:11.564912
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == "HTTP"

# Generated at 2022-06-21 14:03:23.516416
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pygments
    import pygments.lexers.other
    import pygments.lexers.special
    import pygments.lexers.text
    from httpie.plugins import FormatterPlugin

    # Override pygments classes
    class FakeFormatter(FormatterPlugin):
        def format_body(self, body: str, mime: str) -> str:
            return pygments.highlight(
                code=body,
                lexer=pygments.lexers.other.CssLexer(),
                formatter=pygments.formatters.terminal.TerminalFormatter()
            )

    class FakeLexer(Type[pygments.lexer.Lexer]):
        pass

    color_formatter = ColorFormatter(env, **kwargs)

    # Test mime is None, body is None

# Generated at 2022-06-21 14:03:24.175763
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    obj = ColorFormatter(None)

# Generated at 2022-06-21 14:03:32.759317
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import builtin
    import os
    import tempfile
    filename = tempfile.mktemp()
    with open(filename, 'wb') as file:
        file.write(b'{"key": "value"}')
    http_lexer = SimplifiedHTTPLexer()
    formatter = TerminalFormatter()
    tempdir = os.path.dirname(filename)
    cformatter = ColorFormatter(builtin.env, False, DEFAULT_STYLE,
                                dir_name=tempdir, filename=os.path.basename(filename))
    correct_output = pygments.highlight(
        code=open(filename, 'r').read(),
        lexer=pygments.lexers.get_lexer_by_name('json'),
        formatter=formatter,
    )
   

# Generated at 2022-06-21 14:03:37.628518
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity') is pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) is Solarized256Style
    assert ColorFormatter.get_style_class('unknown') is None

# Generated at 2022-06-21 14:03:41.777573
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(Environment(colors=True))
    color_formatter.enabled
    color_formatter.formatter.__class__
    assert isinstance(color_formatter.http_lexer, SimplifiedHTTPLexer)


# Generated at 2022-06-21 14:03:50.374808
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    ex = """GET / HTTP/1.1
Host: example.com
Accept: text/html
Cache-Control: no-cache
User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36 OPR/26.0.1656.60
Accept-Encoding: gzip, deflate, lzma
Accept-Language: en-US,en;q=0.5
"""
    tokens = lexer.get_tokens(ex)

    assert len(tokens) == 12
    assert tokens[0][0] == pygments.token.Name.Function
    assert tokens[0][1] == 'GET'

# Generated at 2022-06-21 14:03:59.903164
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    if is_windows:
        return
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    plugin_manager.load_builtin_plugins()
    plugin_manager.load_plugins()
    plugin = plugin_manager.get('colors')[0]

    env = Environment(colors=256)
    plugin_ = ColorFormatter(env=env)

    # Test JSON body
    body = '{"test":1}'
    lexer = get_lexer(mime='application/json', body=body)

# Generated at 2022-06-21 14:04:12.573999
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():

    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.filenames == ['*.http']

    # Request-Line
    assert lexer.get_tokens('GET /test/test HTTP/1.1\r\n')[0] == (
        pygments.token.Name.Function, 'GET')

    assert lexer.get_tokens('GET /test/test HTTP/1.1\r\n')[1] == (
        pygments.token.Text, ' ')

    assert lexer.get_tokens('GET /test/test HTTP/1.1\r\n')[2][0] == (
        pygments.token.Name.Namespace, '/test/test')


# Generated at 2022-06-21 14:04:19.881696
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    lexer = get_lexer(mime='application/json', body='{"a": "b"}')
    assert lexer == pygments.lexers.get_lexer_by_name('json'), "It should return a right lexer"
    lexer = get_lexer(mime='text', body='{"a": "b"}')
    assert lexer == pygments.lexers.get_lexer_by_name('text'), "It should return a right lexer"

# Generated at 2022-06-21 14:04:29.324283
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer.name == 'HTTP'
    assert SimplifiedHTTPLexer.aliases[0] == 'http'
    assert SimplifiedHTTPLexer.filenames[0] == '*.http'
    assert SimplifiedHTTPLexer.tokens['root'][0][0] == '([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\\d+\\.\\d+)'

# Generated at 2022-06-21 14:04:30.259411
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    pass


# Generated at 2022-06-21 14:04:32.461733
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Explicit JSON request
    lexer = get_lexer(mime='application/json', explicit_json=True, body='{}')
    assert 'JSON' == lexer.__name__

# Generated at 2022-06-21 14:04:36.913725
# Unit test for function get_lexer
def test_get_lexer():
    """
    >>> get_lexer(mime='application/json', body='{"foo": "bar"}')
    <class 'pygments.lexers.data.JsonLexer'>
    >>> get_lexer(mime='application/json', body='Not JSON')
    >>> get_lexer(mime='text/html', body='<!doctype html><title>Hi')
    <class 'pygments.lexers.html.HtmlLexer'>
    """

# Generated at 2022-06-21 14:04:38.211262
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_http_lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-21 14:04:47.030158
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.compat import is_windows, is_py38

    env = Environment(colors=256, stdout_isatty=True, stderr_isatty=is_windows)

    formatter = ColorFormatter(env)
    ret = formatter.format_body('{"array":[1,2,3,4]}', 'application/json')
    print(ret)
    assert ret.strip() == '{\n    "array": [\n        1,\n        2,\n        3,\n        4\n    ]\n}'

    ret = formatter.format_body('{"array":[1,2,3,4]}', 'application/json;charset=UTF-8')
    print(ret)

# Generated at 2022-06-21 14:04:59.247563
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert style.BRIGHT == 1
    assert style.DARK == 2
    assert style.NORMAL == 22

# Generated at 2022-06-21 14:05:11.304393
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPlugin
    import pygments.lexers
    import pygments.lexers.text
    import pygments.lexers.special

    env = None
    explicit_json = False
    color_scheme = 'auto'

    cf = ColorFormatter(
        env=env,
        explicit_json=explicit_json,
        color_scheme=color_scheme,
    )

    # 1. custom lexer
    lexer = pygments.lexers.get_lexer_by_name('json')
    assert cf.get_lexer_for_body('text/x-json', "") == lexer

    lexer = pygments.lexers.get_lexer_by_name('python')
    assert cf.get_lexer_for_body('text/x-python', "")

# Generated at 2022-06-21 14:05:11.936659
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:05:19.955009
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """
    Test conformance of ColorFormatter.format_body()
    to the following test spec:

    Specifically: if format_body() has been called and
    get_lexer_for_body() returned a non-Null lexer, then
    the body is passed through pygments.highlight().

    If get_lexer_for_body() returned a Null lexer then
    the body is not passed through pygments.highlight().
    """

    from unittest.mock import Mock, patch

    c = ColorFormatter(Environment(colors=True))
    c.formatter = Mock()
    c.http_lexer = Mock()

    # Case: get_lexer_for_body() returns a lexer
    c.get_lexer_for_body = Mock(return_value='lexer')

# Generated at 2022-06-21 14:05:37.134471
# Unit test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-21 14:05:38.119048
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    x = Solarized256Style()

# Generated at 2022-06-21 14:05:39.813685
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(), explicit_json=True, color_scheme='solarized')

# Generated at 2022-06-21 14:05:47.092891
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.output.default import DEFAULT_OPTIONS

    env = Environment(
        colors=256,
        stdout=None,
        stdin=None,
        stdin_isatty=False,
        stdout_isatty=False,
        is_windows=False,
        stdout_raw=False,
        stdout_json=False,
        stdout_json_indent=None,
        stdout_formatted=False,
        stdout_prettified=False,
        stdout_stream=False,
        impl='httplib',
        options=DEFAULT_OPTIONS,
        configuration_dir=None,
        plugin_manager=None
    )

    # Test 1: should not colorize
    body = '{"hello": "world"}'

# Generated at 2022-06-21 14:05:58.959259
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert not get_lexer(mime="text")
    assert get_lexer(mime="text/html") == pygments.lexers.HtmlLexer
    assert get_lexer(mime="foo/bar") == pygments.lexers.TextLexer
    # TODO: fix this!
    # You might be interested in the HTML parser.
    assert get_lexer(mime="text/plain", body="<html>") == pygments.lexers.HtmlLexer
    assert get_lexer(mime="", body="<html>") == pygments.lexers.HtmlLexer
    assert get_lexer(mime="application/x-www-form-urlencoded", body="foo=bar") == pygments.lexers.UrlEncodedLexer

# Generated at 2022-06-21 14:06:06.613725
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert [
        (pygments.token.Name.Function, 'GET'),
        (pygments.token.Text, ' '),
        (pygments.token.Name.Namespace, '/'),
        (pygments.token.Text, ' '),
        (pygments.token.Keyword.Reserved, 'HTTP'),
        (pygments.token.Operator, '/'),
        (pygments.token.Number, '1.1')] == list(lexer.get_tokens('GET / HTTP/1.1'))  # noqa: E501


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-21 14:06:14.790221
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-21 14:06:16.704129
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer(mime='text/css')
    assert lexer is not None

# Generated at 2022-06-21 14:06:28.121866
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.formatter import (
        format_body,
        format_headers,
        format_json,
        format_stream,
    )
    from httpie.output import Stream
    body = ''
    mime = 'application/html'
    output = Stream(environment=Environment())
    formatters = [
        format_json,
        format_body,
        format_headers,
        format_stream,
    ]
    cf = ColorFormatter(Environment(),
                        explicit_json=False,
                        color_scheme='fruity')
    assert cf is not None
    body = cf.format_body(body, mime)
    assert body == ''
    body = 'foo'
    body = cf.format_body(body, mime)
    assert body == 'foo'

# Generated at 2022-06-21 14:06:32.676248
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    formatter = ColorFormatter(Environment())
    assert formatter.formatter.style == pygments.styles.get_style_by_name('default')
    #TODO: test color_scheme
    #TODO: test explicit_json

# Generated at 2022-06-21 14:06:45.944568
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
  env = Environment()
  c = ColorFormatter(env)
  body = c.format_body('<html><body><h1>Test</h1></body></html>', 'text/html')
  assert body == '<html><body><h1>Test</h1></body></html>'



# Generated at 2022-06-21 14:06:47.668402
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer is not None

# Generated at 2022-06-21 14:06:57.889724
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from pygments.lexers import HttpLexer
    from pygments.token import Token

    env = Environment(colors=256)
    color_formatter = ColorFormatter(env)
    headers = "Host: 127.0.0.1:5000\nAccept: */*\nAccept-Encoding: gzip, deflate\nConnection: keep-alive\nContent-Length: 2\nContent-Type: application/json\nUser-Agent: HTTPie/0.9.9"

# Generated at 2022-06-21 14:06:58.962190
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("colorful")

# Generated at 2022-06-21 14:07:03.765614
# Unit test for function get_lexer
def test_get_lexer():
    with open("test_data/request_headers.txt") as f:
        headers = f.read()
        lexer = get_lexer("text/plain")
        assert lexer is None
        lexer = get_lexer("text/html")
        assert lexer is not None
        lexer = get_lexer("application/json")
        assert lexer is not None
        lexer = get_lexer("application/json", explicit_json=True, body="{}")
        assert lexer is not None
        lexer = get_lexer("application/json", body="{}")
        assert lexer is None

# Generated at 2022-06-21 14:07:04.700825
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style().styles

# Generated at 2022-06-21 14:07:14.596308
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # empty input
    assert ColorFormatter(Environment()).get_lexer_for_body('', '') is None
    assert ColorFormatter(Environment()).get_lexer_for_body('', '{}') is None
    # JSON
    assert ColorFormatter(Environment()).get_lexer_for_body('', '{}') is None
    assert ColorFormatter(Environment()).get_lexer_for_body('application/json', '{}') is pygments.lexers.get_lexer_by_name('json')
    assert ColorFormatter(Environment()).get_lexer_for_body('application/json', '"bar"') is pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-21 14:07:24.613705
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/x-html') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/x-html+jinja') == pygments.lexers.get_lexer_by_name('html+jinja')
    assert get_lexer('application/xml') == pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('application/xml-dtd') == pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('application/rss+xml') == pygments.lexers.get_lexer_by_name('rss')
    assert not get

# Generated at 2022-06-21 14:07:35.965748
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') is None
    assert get_lexer('text/html', body='<html></html>') is None
    assert get_lexer('text/html', body='{"foo": "bar"}') is None
    assert get_lexer('text/html', body='{"foo": "bar"}', explicit_json=True) is pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json') is pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/javascript') is pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/vnd.api+json') is pygments.lexers.get_lexer_by_name('json')


# Generated at 2022-06-21 14:07:37.187737
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') is not None

# Generated at 2022-06-21 14:07:53.549373
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:08:04.093849
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import SQLFormatter
    from httpie.plugins.builtin import JSONFormatter

    color_formatter = ColorFormatter(
        env=Environment(colors=256),
        explicit_json=False,
        color_scheme=SOLARIZED_STYLE,
        format_options=[]
    )

    assert color_formatter.get_style_class(SOLARIZED_STYLE) is Solarized256Style
    assert color_formatter.get_style_class(AUTO_STYLE) is not Solarized256Style

    # Test that ColorFormatter is also compatible with plugins
    assert isinstance(color_formatter, HTTPBasicAuth) is True
    assert isinstance(color_formatter, SQLFormatter)

# Generated at 2022-06-21 14:08:12.274164
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from httpie.plugins.builtin import SimplifiedHTTPLexer
    print(SimplifiedHTTPLexer().get_tokens_unprocessed(r"a\rtrue:false\rContent-Type:application/json"))
    print(SimplifiedHTTPLexer().get_tokens_unprocessed(r"POST https://127.0.0.1:6543/test HTTP/1.1"))
    print(SimplifiedHTTPLexer().get_tokens_unprocessed(r"HTTP/1.1 200 OK"))

# Generated at 2022-06-21 14:08:13.199587
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # TODO
    assert False

# Generated at 2022-06-21 14:08:22.619311
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    from httpie.compat import is_windows
    from io import StringIO
    import sys

    env = Environment()
    env.stdout = sys.stdout = StringIO()

    formatter = ColorFormatter(env)
    if is_windows:
        assert str(formatter.formatter) == "<TerminalFormatter style='fruity'>\n"
    else:
        assert str(formatter.formatter) == "<TerminalFormatter style='auto'>\n"

    assert formatter.http_lexer.__class__.__name__ == 'PygmentsHttpLexer'
    assert formatter.explicit_json == False

    formatter = ColorFormatter(env, explicit_json=True)
    assert formatter.explicit_json == True

    formatter = ColorFormatter

# Generated at 2022-06-21 14:08:23.555785
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()

# Generated at 2022-06-21 14:08:31.487546
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    #Test instance creation
    instance = ColorFormatter(env=None, explicit_json=None, color_scheme="auto")
    assert isinstance(instance, ColorFormatter)
    assert instance.group_name == 'colors'
    assert instance.enabled
    assert instance.explicit_json == False
    assert instance.formatter is not None
    assert instance.http_lexer is not None

    #Test instance creation with 'Terminal256Formatter'
    instance = ColorFormatter(env=None, explicit_json=None, color_scheme=SOLARIZED_STYLE)
    assert isinstance(instance, ColorFormatter)
    assert instance.group_name == 'colors'
    assert instance.enabled
    assert instance.explicit_json == False
    assert instance.formatter is not None
    assert instance.http

# Generated at 2022-06-21 14:08:41.873164
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import pytest
    from httpie.compat import is_windows
    from httpie.context import Environment

    env = Environment()
    if is_windows:
        color_scheme = 'fruity'  # fruity is the only built-in style we have
    else:
        color_scheme = 'solarized'

    f = ColorFormatter(env, color_scheme=color_scheme)
    assert f.formatter.__class__.__name__ in ('TerminalFormatter',
                                               'Terminal256Formatter')
    assert f.http_lexer.__class__.__name__ in ('PygmentsHttpLexer',
                                                'SimplifiedHTTPLexer')


# Generated at 2022-06-21 14:08:54.699668
# Unit test for function get_lexer
def test_get_lexer():
    get_lexer('application/x-www-form-urlencoded')
    get_lexer('application/json')
    get_lexer('application/json', explicit_json=True)
    get_lexer('application/json', explicit_json=True, body='{}')
    get_lexer('application/msgpack')
    get_lexer('application/vnd.msgpack')
    get_lexer('application/vnd.blah.msgpack')
    get_lexer('application/vnd.blah+msgpack')
    get_lexer('application/vnd.blah+ms.gp.ck')
    get_lexer('application/vnd.blah+ms.gp.ck', explicit_json=True)

# Generated at 2022-06-21 14:09:04.511952
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import os
    env = Environment(colors=256, stdout_isatty=True, stdin_isatty=True)
    formatter = ColorFormatter(env, color_scheme='solarized256')
    subject = formatter.format_headers("""\
Content-Type: application/json
Hello: World
""")
    assert subject == """\
\x1b[38;5;148mContent-Type\x1b[39;00m: application/json
\x1b[38;5;148mHello\x1b[39;00m: \x1b[38;5;148mWorld\x1b[39;00m
"""

# Generated at 2022-06-21 14:09:45.824773
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import requests

    class FakeResponse:
        def __init__(self, headers, body):
            self.headers = headers
            self.raw = body
            self.encoding = 'utf-8'

    class FakeSession:
        def __init__(self, headers, body):
            self.headers = headers
            self.raw = body
            self.encoding = 'utf-8'

    class FakeEnv:
        colors = True

    env = FakeEnv()
    data = {
        'headers': {
            'content-type': 'application/json',
        },
        'body': '{"foo": "bar"}',
        'result': '{\n'
                  '    "foo": "bar"\n'
                  '}\n'
    }

# Generated at 2022-06-21 14:09:49.133397
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    print('TEST SOLARIZED256STYLE')
    s256s = Solarized256Style()
    assert s256s.background_color == "#1c1c1c"
    assert s256s.styles[pygments.token.String] == "#00afaf"
    print('OK')

# Generated at 2022-06-21 14:09:59.015211
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    x = SimplifiedHTTPLexer()
    assert x.name == 'HTTP'
    assert x.aliases == ['http']
    assert x.filenames == ['*.http']

# Generated at 2022-06-21 14:10:09.077203
# Unit test for function get_lexer
def test_get_lexer():
    from httpie.cli.parser import get_lexer as hc_get_lexer
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPieJSONEncode
    from httpie.plugins.builtin import HTTPieJSONDecode
    from httpie.plugins.colors import ColorFormatter
    from httpie.plugins.colors import Solarized256Style

    class FakePlugin(object):
        """
        A plugin that does nothing.

        """
        class Group(object):
            name = 'fake'

        def __init__(self, **kwargs):
            pass

        def __call__(self, *args, **kwargs):
            return args[0]


# Generated at 2022-06-21 14:10:14.157100
# Unit test for function get_lexer
def test_get_lexer():
    # type: () -> None
    l = get_lexer('text/html; charset=utf-8')
    assert l.name == 'HTML'

    l = get_lexer('application/json')
    assert l.name == 'JSON'

    l = get_lexer('application/json', True)
    assert l.name == 'JSON'

    l = get_lexer('application/json', False, '{"a": 1}')
    assert l.name == 'JSON'

    l = get_lexer('application/xml')
    assert l.name == 'XML'

    l = get_lexer('text/plain')
    assert l.name == 'Text only'

# Generated at 2022-06-21 14:10:21.344668
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    cf = ColorFormatter(env, color_scheme='solarized')
    assert (cf.formatter.__dict__['style'] == Solarized256Style)
    cf = ColorFormatter(env, color_scheme='solarized')
    assert (cf.formatter.__dict__['style'] == Solarized256Style)
    cf = ColorFormatter(env, color_scheme='monokai')
    assert (cf.formatter.__dict__['style'] != Solarized256Style)

# Generated at 2022-06-21 14:10:25.298519
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    explicit_json = False
    color_scheme = DEFAULT_STYLE
    f = ColorFormatter(
        env,
        explicit_json=explicit_json,
        color_scheme=color_scheme
    )

# Generated at 2022-06-21 14:10:33.673592
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment(), False)
    assert not formatter.get_lexer_for_body("", "")
    assert formatter.get_lexer_for_body("foo", "") == pygments.lexers.get_lexer_by_name("foo")
    assert not formatter.get_lexer_for_body("foo", "bar")
    assert formatter.get_lexer_for_body("application/json", "") == pygments.lexers.get_lexer_by_name("JSON")
    assert formatter.get_lexer_for_body("foo/bar+json", "") == pygments.lexers.get_lexer_by_name("json")
    assert formatter.get_lexer_for_body("foo/bar+json", "bar") == pygments.lexers

# Generated at 2022-06-21 14:10:42.725215
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import os
    import httpie.core
    import sys
    import pytest
    from httpie.core import http
    from httpie.core import main
    from httpie.utils import compat_str
    from httpie.utils import get_response_and_headers
    from httpie.core import __version__
    from httpie.core import request
    from httpie.core import request_info
    from json import dump
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    def binary_suppressed_stdout():
        yield b"{}\n\n{}".format(BINARY_SUPPRESSED_NOTICE, 'test')

    config_dir = os.path.join(os.path.dirname(__file__), "../httpie/config")

    args = parser.parse_

# Generated at 2022-06-21 14:10:52.347450
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    headers = (
        'HTTP/1.1 200 OK\n'
        'Date: Thu, 27 Jun 2013 13:10:48 GMT\n'
        'Server: Apache/2.2.22 (Ubuntu)\n'
        'Last-Modified: Wed, 22 May 2013 20:17:54 GMT\n'
        'ETag: "15a991-5d5-4daed53a60880"\n'
        'Accept-Ranges: bytes\n'
        'Content-Length: 1493\n'
        'Vary: Accept-Encoding\n'
        'Content-Type: text/html\n'
        'X-Pad: avoid browser bug'
    )

# Generated at 2022-06-21 14:12:05.423292
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    f = ColorFormatter()
    assert '<div>' in f.format_body('<div>', 'text/html')

# Generated at 2022-06-21 14:12:10.658331
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.context import Environment

    formatter = ColorFormatter(
        env=Environment(colors=8),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )

# Generated at 2022-06-21 14:12:11.233126
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    pass

# Generated at 2022-06-21 14:12:20.405314
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(Environment())
    assert color_formatter.get_lexer_for_body(
        "application/json", "{\"a\":1,\"b\":2}") is not None
    assert color_formatter.get_lexer_for_body(
        "text/json", "{\"a\":1,\"b\":2}") is not None
    assert color_formatter.get_lexer_for_body(
        "text/vnd.something+json", "{\"a\":1,\"b\":2}") is not None
    assert color_formatter.get_lexer_for_body(
        "text/vnd.something.sub+json", "{\"a\":1,\"b\":2}") is not None

# Generated at 2022-06-21 14:12:26.026939
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    data = open("testdata/example-response.txt").read()
    headers, body = data[:data.find('\r\n\r\n')], data[data.find('\r\n\r\n')+4:]

    f = ColorFormatter(env = Environment())
    f_out = open("testdata/example-response-fomatted.txt", "w+")
    f_out.write(f.format_headers(headers))
    f_out.write(f.format_body(body, 'application/json'))

# Generated at 2022-06-21 14:12:35.968980
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.plugins.builtin.colors
    from httpie.output.streams import ResponseBodyStream
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin

    class B(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

        def format_body(self, body: str, mime: str) -> str:
            return body

    class C(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

        def format_body(self, body: str, mime: str) -> str:
            return body


# Generated at 2022-06-21 14:12:43.720921
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, not env.render_all_output_in_colors)


# Generated at 2022-06-21 14:12:46.544725
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain')
    assert get_lexer('text/plain', body='{"a": 1}')
    assert get_lexer('text/plain', explicit_json=True, body='{"a": 1}')

# Generated at 2022-06-21 14:12:48.556064
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    formatter = ColorFormatter(None)
    print(formatter.format_body(
        "GET https://example.com/resource\r\nUser-Agent: httpie\r\n",
        'text/plain'
    ))

# Generated at 2022-06-21 14:12:48.982223
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()