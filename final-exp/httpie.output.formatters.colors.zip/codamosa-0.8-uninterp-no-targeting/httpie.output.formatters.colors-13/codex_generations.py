

# Generated at 2022-06-21 14:03:05.704427
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer(
        mime='text/plain',
        explicit_json=False,
        body=''
    )

    assert lexer == pygments.lexers.get_lexer_by_name('text')

# Generated at 2022-06-21 14:03:14.361292
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(Environment())

    def assert_lexer(expected_lexer, mime, body=''):
        assert (
            color_formatter.get_lexer_for_body(mime, body) ==
            expected_lexer
        )

    assert_lexer(pygments.lexers.JsonLexer, 'application/json', '{"a": 0}')
    assert_lexer(
        pygments.lexers.JsonLexer,
        'application/json',
        '{"a": 0}',
        explicit_json=True,
    )
    assert_lexer(pygments.lexers.JsonLexer, 'application/json+something')
    assert_lexer(pygments.lexers.JsonLexer, 'application/json+something')
    assert_lex

# Generated at 2022-06-21 14:03:25.710395
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from . import http

    class FakeEnvironment:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    with open(http.HTTPBIN_GET, 'rb') as f:
        body = f.read()

    json_mime = 'application/json'
    html_mime = 'text/html'
    plain_text_mime = 'text/plain'
    no_mime = 'application/unknown'

    assert get_lexer(json_mime, body=body).__name__ == 'JSON Lexer'
    assert get_lexer(html_mime, body=body).__name__ == 'HTML'

# Generated at 2022-06-21 14:03:28.427791
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') is not None
    assert get_lexer('application/vnd.api+json') is not None
    assert get_lexer('text/html') is not None

# Generated at 2022-06-21 14:03:31.310787
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
  assert ColorFormatter.get_style_class(
    'solarized256'
  ) == Solarized256Style, 'should return solarized256'
  assert ColorFormatter.get_style_class(
    'nonexistentstyle'
  ) == None, 'should return None'

# Generated at 2022-06-21 14:03:37.757552
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.input import ParseError
    from httpie.plugins import FormatterPlugin, BuiltinFormatterPlugin
    from httpie.output.streams import get_default_stream
    from httpie.output.writers import get_writer

    env = Environment()
    env.stdout = get_default_stream('stdout')
    stdout = get_writer(format=DEFAULT_STYLE, env=env)
    bfp = BuiltinFormatterPlugin(env=env, stdout=stdout)
    formatter = ColorFormatter(env=env, stdout=stdout)

    assert not formatter.get_lexer_for_body('application/x-executable', 'hello world')


# Generated at 2022-06-21 14:03:42.895523
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.cli.terminal import COLOR_SCHEME
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie import ExitStatus

    # Setup env

# Generated at 2022-06-21 14:03:49.076398
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.alias_matches() == []
    assert lexer.analyse_text('GET /afsdfs/sdfsdfs HTTP/1.0') == 1.0
    assert lexer.analyse_text('GET /afsdfs/sdfsdfs HTTP/0.9') == 0.0
    assert lexer.analyse_text('GET /afsdfs/sdfsdfs HTTP/001.0') == 0.0



# Generated at 2022-06-21 14:03:58.879690
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    env.stdout_isatty = True
    env.colors = True

    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme='solarized')

    headers = """\
HTTP/1.1 200 OK
Content-Type: application/json
Date: Thu, 29 Oct 2015 14:11:51 GMT
Content-Length: 4
Server: TornadoServer/4.2.1
Access-Control-Allow-Origin: *
Access-Control-Allow-Headers: x-requested-with

"""

    headers = color_formatter.format_headers(headers)


# Generated at 2022-06-21 14:04:06.027521
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    test_config = Config(default_options=dict(colors=1))
    test_env = Environment(config=test_config)
    assert issubclass(ColorFormatter, FormatterPlugin)
    assert isinstance(ColorFormatter(env=test_env, indent_level=0), ColorFormatter)


# Generated at 2022-06-21 14:04:22.736768
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.core import Environment
    from httpie import plugins
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from pygments.formatters.terminal import TerminalFormatter
    from pygments.lexer import Lexer
    from pygments.lexer import RegexLexer
    from pygments.lexers.special import TextLexer
    from pygments.lexers.text import HttpLexer as PygmentsHttpLexer
    from pygments.util import ClassNotFound
    from pygments.formatters.terminal256 import Terminal256Formatter
    from pygments.styles import get_all_styles
    from pygments.styles import get_style_by_name


# Generated at 2022-06-21 14:04:26.781736
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.cli import parser

    parser.parse_args(['color.test', '--color', '256'])
    env = parser.env
    env.colors = 256
    h = ColorFormatter(env, explicit_json=True, color_scheme=SOLARIZED_STYLE)

    assert(h.color_scheme == SOLARIZED_STYLE)

# Generated at 2022-06-21 14:04:35.690483
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments import highlight  # type: ignore
    from pygments.formatters import TerminalFormatter

    lexer = SimplifiedHTTPLexer()
    expected = """\
<Name.Function>GET</Name.Function> <Text> </Text>
<Name.Namespace>/a</Name.Namespace> <Text> </Text>
<Keyword.Reserved>HTTP</Keyword.Reserved>
<Operator>/</Operator><Number>2.0</Number>

<Name.Attribute>Host</Name.Attribute><Text> </Text>
<Operator>:</Operator><Text> </Text><String>example.com</String>

<Name.Attribute>Accept</Name.Attribute><Text> </Text>
<Operator>:</Operator><Text> </Text><String>application/json</String>"""

# Generated at 2022-06-21 14:04:45.170263
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class TestEnv:
        def __init__(self, colors=True):
            self.colors = colors

    class TestColorFormatter(ColorFormatter):
        pass


# Generated at 2022-06-21 14:04:47.171592
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style().styles[pygments.token.Token.Other] == '#b58900'

# Generated at 2022-06-21 14:04:59.392728
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Test with a simple request line and three headers.
    request_line = 'GET / HTTP/1.1'
    headers = 'Content-Type: application/json\n' \
              'Authorization: Basic YW5kcm9pZDp0ZXN0\n' \
              'Connection: Keep-Alive'
    test_input = request_line + '\n' + headers

    # Test with default style.
    formatter = ColorFormatter(Environment())

# Generated at 2022-06-21 14:05:02.692551
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    code = '''POST / HTTP/2.0
Foo: Baz
Baz: Foo'''
    assert pygments.highlight(code, lexer)

# Generated at 2022-06-21 14:05:14.760906
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert style.styles[pygments.token.Keyword] == "#5f8700"
    assert style.styles[pygments.token.Keyword.Constant] == "#d75f00"
    assert style.styles[pygments.token.Keyword.Declaration] == "#0087ff"
    assert style.styles[pygments.token.Keyword.Namespace] == "#d75f00"
    assert style.styles[pygments.token.Keyword.Reserved] == "#0087ff"
    assert style.styles[pygments.token.Keyword.Type] == "#af0000"
    assert style.styles[pygments.token.Name.Attribute] == "#8a8a8a"
    assert style.styles[pygments.token.Name.Builtin] == "#0087ff"


# Generated at 2022-06-21 14:05:22.210263
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.cli import parser
    from httpie.context import Environment
    test_args = parser.parse_args(
        args=['--json', 'colors'],
        env=Environment()
    ) # type: Namespace
    color_formatter = ColorFormatter(
        env=test_args.env,
        explicit_json=test_args.json,
        color_scheme=test_args.colors,
    )
    assert color_formatter.explicit_json == test_args.json
    assert color_formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-21 14:05:34.086466
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.input import ParseError
    from httpie.plugins import plugin_manager
    from httpie.utils import get_mime_type
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.compat import is_windows
    import httpie.plugins
    env = Environment()
    config = Config()
    plugin_manager.load_installed_plugins()
    formatter = ColorFormatter(env,config)
    assert str(formatter.format_body('','')) == ''
    assert str(formatter.format_body('<html><body>Hi</body></html>','text/html')) == '<html><body>Hi</body></html>'

# Generated at 2022-06-21 14:05:52.200706
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class ColorFormatter(FormatterPlugin):
        explicit_json=False
        def get_lexer_for_body(self, mime, body):
            return get_lexer(
                mime=mime,
                explicit_json=self.explicit_json,
                body=body
            )

    env = Environment()
    cf = ColorFormatter(env)

    # Text
    lexer = cf.get_lexer_for_body('text/plain')
    assert lexer == TextLexer

    # JavaScript
    lexer = cf.get_lexer_for_body('application/javascript')
    assert lexer == pygments.lexers.JavascriptLexer
    lexer = cf.get_lexer_for_body('text/javascript')
    assert lexer == pygments.lexers.JavascriptLexer



# Generated at 2022-06-21 14:05:59.753610
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class('solarized')
    assert style_class == Solarized256Style
    style_class = ColorFormatter.get_style_class('monokai')
    assert style_class == pygments.styles.get_style_by_name('monokai')
    style_class = ColorFormatter.get_style_class('doesnotexist')
    assert style_class == Solarized256Style

# Generated at 2022-06-21 14:06:08.362759
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import plugin_manager

    f = plugin_manager.lookup('colors')()

# Generated at 2022-06-21 14:06:19.616781
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    print("ColorFormatter.format_body")
    a = ColorFormatter(None)
    assert a.format_body(
        "http://localhost:5000/api/v1.0/tasks/\r\n{\r\n  \"task\": \"daf\"\r\n}",
        "application/json") == "http://localhost:5000/api/v1.0/tasks/\r\n{\r\n  \"task\": \"daf\"\r\n}"

# Generated at 2022-06-21 14:06:20.898171
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-21 14:06:32.865864
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    """
    Given
    - [ ] an environment with and without `color` set to ``256``
    - [ ] the `Content-Type`, `explicit_json` and `body`
    When
    - [ ] method `get_lexer_for_body` is called
    Then
    - [ ] the corresponding lexer for the given `body` is returned
    """
    from pygments.lexers.special import HttpLexer
    from httpie.context import Environment
    from httpie.formatter.colors import ColorFormatter, get_lexer, get_lexer_for_body

    color_env_8 = Environment(colors=8)
    color_env_256 = Environment(colors=256)

    cformatter1_8 = ColorFormatter(color_env_8)

# Generated at 2022-06-21 14:06:42.272017
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    """
    This method format the header using the pygments

    :return:
    """
    environment = Environment(colors=False)
    color_formatter = ColorFormatter(env=environment, explicit_json=False, color_scheme=DEFAULT_STYLE)
    headers = "HTTP/1.1 200 OK\r\nDate: Mon, 27 Jul 2009 12:28:53 GMT\r\nServer: Apache/2.2.14 (Win32)\r\nLast-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\nContent-Length: 88\r\nContent-Type: text/html\r\nConnection: Closed\r\n\r\n"

# Generated at 2022-06-21 14:06:54.407903
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('application/json', True, '{"foo": "bar"}')
    assert lexer == pygments.lexers.get_lexer_by_name('json')
    assert lexer == pygments.lexers.get_lexer_by_mimetype('application/json')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer('application/json', False, '{"foo": "bar"}')
    assert lexer == pygments.lexers.get_lexer_by_name('json')
    assert lexer == pygments.lexers.get_lexer_by_mimetype('application/json')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    lexer

# Generated at 2022-06-21 14:07:02.064693
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import urlopen
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth
    env = Environment()
    env.stdout = env.stderr = None
    env.auth = [HTTPBasicAuth(), HTTPDigestAuth()]
    env.headers = None
    env.follow_redirects = True
    env.max_redirects = 10
    env.timeout = None
    env.output_options = None
    env.verify = True
    env.verify_ssl_certificates = True
    env.cert = None
    env.clientcert = None
    env.threads = 1
    env.download_resume_from = 0
    env.session = None
    env.kvstore = None
   

# Generated at 2022-06-21 14:07:03.168878
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    # Doesn't require any assertion; will crash if a UnicodeEncodeError occurs
    print(Solarized256Style)

# Generated at 2022-06-21 14:07:25.768432
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(color=1, colors=16)
    cf = ColorFormatter(env, explicit_json=False, color_scheme="monokai")
    assert cf.formatter != None
    env = Environment(color=0, colors=16)
    cf = ColorFormatter(env, explicit_json=False, color_scheme="monokai")
    assert cf.formatter == None
    env = Environment(color=1, colors=256)
    cf = ColorFormatter(env, explicit_json=False, color_scheme="monokai")
    assert cf.formatter != None
    assert cf.formatter != "TerminalFormatter"
    env = Environment(color=1, colors=256)
    cf = ColorFormatter(env, explicit_json=False, color_scheme="auto")

# Generated at 2022-06-21 14:07:27.022218
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    pass


# Generated at 2022-06-21 14:07:38.436544
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    colorFormatter = ColorFormatter(Environment(), explicit_json=False, color_scheme='solarized')
    assert (colorFormatter.format_headers('hello:\nworld\nhello\n') == "\x1b[38;5;239mhello\x1b[39;49;00m: \n\x1b[38;5;239mworld\x1b[39;49;00m \n\x1b[38;5;239mhello\x1b[39;49;00m \n")
    assert (colorFormatter.format_body("hello\nworld\nhello\n", "text/plain") == "hello \nworld \nhello \n")

# Generated at 2022-06-21 14:07:48.447542
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplified_http_lexer = SimplifiedHTTPLexer()
    test_string = 'GET /foo HTTP/1.1'
    test_token = (
        (test_string, pygments.token.Function),
        (' ', pygments.token.Text),
        ('/foo', pygments.token.Namespace),
        (' ', pygments.token.Text),
        ('HTTP', pygments.token.Reserved),
        ('/', pygments.token.Operator),
        ('1.1', pygments.token.Number),
    )
    assert list(simplified_http_lexer.get_tokens(test_string)) == test_token


# Generated at 2022-06-21 14:07:54.789073
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():

    # Test env.color and explicit_json
    formatter1 = ColorFormatter(env='', explicit_json=True, color_scheme=DEFAULT_STYLE)
    assert formatter1.enabled == True
    assert formatter1.explicit_json == True

    # Test no env.color
    formatter2 = ColorFormatter(env='', explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert formatter2.enabled == False
    assert formatter2.explicit_json == False



# Generated at 2022-06-21 14:08:03.979622
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():

    class Dummy(ColorFormatter):
        def __init__(self):
            pass

    style = Dummy.get_style_class('monokai')
    assert isinstance(style, type(pygments.styles.get_style_by_name('monokai')))
    assert style.__name__ == 'MonokaiStyle'

    style = Dummy.get_style_class('solarized')
    assert isinstance(style, type(Solarized256Style))
    assert style.__name__ == 'Solarized256Style'

    style = Dummy.get_style_class('unknown')
    assert isinstance(style, type(pygments.styles.get_style_by_name('monokai')))
    assert style.__name__ == 'MonokaiStyle'

# Generated at 2022-06-21 14:08:07.133554
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.plugins.builtin.colors.color_formatter
    httpie.plugins.builtin.colors.color_formatter.ColorFormatter.format_body('', '')

# Generated at 2022-06-21 14:08:17.845401
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-21 14:08:20.098470
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert ColorFormatter.get_lexer_for_body("application/json", "{key:value}") == pygments.lexers.get_lexer_by_name("json")

# Generated at 2022-06-21 14:08:29.133604
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """
    Test ColorFormatter._format_body() with various mime types
    and bodies.
    """
    color_formatter = ColorFormatter()

    # Mime JSON
    body = '{"message": "Hello World"}'
    result = color_formatter.format_body(body, mime='application/json')
    assert result == body

    # Mime text
    body = 'Hello World'
    result = color_formatter.format_body(body, mime='text/plain')
    assert result == body

    # Mime html
    body = '<!doctype html><html><body>Hello World</body></html>'
    result = color_formatter.format_body(body, mime='text/html')
    assert result == body

# Generated at 2022-06-21 14:09:05.158798
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    environment = Environment(colors=256)
    color_formatter = ColorFormatter(env=environment, color_scheme='solarized')
    headers = 'HTTP/1.1 200 OK\r\ncontent-type: text/html\r\n\r\n'
    color_formatter.format_headers(headers=headers)
    print("test_ColorFormatter_format_headers")


# Generated at 2022-06-21 14:09:13.442877
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    env = Environment()
    formatter = ColorFormatter(env)
    http_lexer = formatter.http_lexer
    assert isinstance(http_lexer, SimplifiedHTTPLexer)
    assert http_lexer.name == 'HTTP'
    assert http_lexer.aliases == ['http']
    assert http_lexer.filenames == ['*.http']

# Generated at 2022-06-21 14:09:23.286348
# Unit test for function get_lexer
def test_get_lexer():
    _get_lexer_test_pls_ignore = {  # type: ignore
        # text/*
        'text/plain': TextLexer,
        'text/html': PygmentsHttpLexer,
        # application/*
        'application/javascript': pygments.lexers.get_lexer_by_name('js'),
        'application/json': pygments.lexers.get_lexer_by_name('json'),
        'application/xml': pygments.lexers.get_lexer_by_name('xml'),
        # application/vnd.org.w3.www.http.**
        'application/vnd.org.w3.www.http.request': PygmentsHttpLexer,
        'application/vnd.org.w3.www.http.response': PygmentsHttpLexer,
    }

   

# Generated at 2022-06-21 14:09:29.794745
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import os
    import sys
    import httpie

    sys.argv = ['httpie.py', 'httpie.org', '--json']
    httpie.HTTPIE_ROOT = os.path.dirname(os.path.dirname(__file__))
    env = Environment()
    env.colors = True
    formatter = ColorFormatter(env)

    body = '{"name":"httpie"}'
    mime = 'application/json; charset=utf-8'
    lexer = formatter.get_lexer_for_body(mime=mime, body=body)
    assert pygments.lexers.get_lexer_by_name('json') == lexer

    body = '{"name":"httpie"}'
    mime = 'application/json; application=httpie'
    lexer

# Generated at 2022-06-21 14:09:38.658644
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class TestEnv(object):
        def __init__(self, colors=False):
            self.colors = colors
    is_256_color_supported = TestEnv(colors=True)

    test_formatter = ColorFormatter(env=is_256_color_supported,
                                   explicit_json=False,
                                   color_scheme="fruity")
    assert test_formatter.formatter.__class__.__name__ == "Terminal256Formatter"
    assert test_formatter.http_lexer.__class__.__name__ == "SimplifiedHTTPLexer"
    assert test_formatter.enabled


# Generated at 2022-06-21 14:09:46.721161
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(env, explicit_json=True)

    assert get_lexer('application/json', body='{"fields": {"foo": "bar"}}')
    assert get_lexer('application/json', body='{"fields": {"foo": "bar"}}').name == "JSON"

    assert get_lexer('application/json', body='{ "foo": "bar" }')
    assert get_lexer('application/json', body='{ "foo": "bar" }').name == "JSON"

    assert get_lexer('application/json', body='{"foo": "bar"}')
    assert get_lexer('application/json', body='{"foo": "bar"}').name == "JSON"

    assert not get_lexer('application/json', body='{"foo": "bar"')

# Generated at 2022-06-21 14:09:51.630379
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/xml') is pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('application/xml+rss') is pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('application/json') is pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json+hal') is pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-21 14:09:55.013456
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.client import Environment
    env = Environment(colors=256)

    cf = ColorFormatter(env, color_scheme=DEFAULT_STYLE)
    cf = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)

# Generated at 2022-06-21 14:10:05.628884
# Unit test for function get_lexer
def test_get_lexer():
    # Test for mime type
    get_lexer(mime='text/css')
    get_lexer(mime='application/x-javascript')
    get_lexer(mime='text/plain')
    get_lexer(mime='application/json')
    get_lexer(mime='application/json', body='{...}')
    get_lexer(mime='application/x-yaml', body='{...}')
    # Test for lexer names
    get_lexer(mime='text/css', explicit_json=True)
    get_lexer(mime='application/x-javascript', explicit_json=True)
    get_lexer(mime='text/plain')
    get_lexer(mime='application/json')

# Generated at 2022-06-21 14:10:09.076665
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    print(pygments.highlight(
        code='GET / HTTP/1.1',
        lexer=SimplifiedHTTPLexer(),
        formatter=Terminal256Formatter(
            style=Solarized256Style,
        ),
    ))

# Generated at 2022-06-21 14:10:54.642967
# Unit test for function get_lexer

# Generated at 2022-06-21 14:11:03.773892
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.compat import is_py26
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output import get_formatter, writers

    environment = Environment(
        stdout=writers.UnicodeBytesIO(),
        colors=256,
    )

    color_formatter = ColorFormatter(
        env=environment,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )

    assert color_formatter.get_lexer_for_body(
        mime='application/json',
        body='{"test":"test"}',
    )


# Generated at 2022-06-21 14:11:04.813331
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()

# Generated at 2022-06-21 14:11:08.514866
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment = Environment(colors=256, scheme=DEFAULT_STYLE)
    colorFormatter = ColorFormatter(env=environment)
    assert isinstance(colorFormatter, FormatterPlugin)

# Generated at 2022-06-21 14:11:10.548356
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    try:
        style_cls = Solarized256Style
    except NameError:
        # Pass if Solarized256Style wasn't defined
        pass

# Generated at 2022-06-21 14:11:12.560216
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    expected = Solarized256Style
    actual = ColorFormatter.get_style_class(SOLARIZED_STYLE)
    assert expected == actual

# Generated at 2022-06-21 14:11:19.037620
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Test the default solarized256 style
    c = ColorFormatter(Environment(), color_scheme=DEFAULT_STYLE)
    assert isinstance(c.get_style_class(DEFAULT_STYLE), Solarized256Style)

    # Test the solarized256 style
    c = ColorFormatter(Environment(), color_scheme=SOLARIZED_STYLE)
    assert isinstance(c.get_style_class(SOLARIZED_STYLE), Solarized256Style)

    # Test an alternative style
    c = ColorFormatter(Environment(), color_scheme='monokai')
    assert (c.get_style_class('monokai') == pygments.styles.MonokaiStyle)

    # An non existing style
    c = ColorFormatter(Environment(), color_scheme='unknown')
   

# Generated at 2022-06-21 14:11:29.716892
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(AUTO_STYLE) == pygments.styles.get_style_by_name(AUTO_STYLE)
    assert ColorFormatter.get_style_class('native') == pygments.styles.get_style_by_name('native')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized-light') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized dark') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized light') == Solarized256Style

# Generated at 2022-06-21 14:11:34.157470
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    body_data = '\n'.join([
        "this is line 1",
        "this is line 2"
    ])
    color_formatter = ColorFormatter(env=None)
    assert color_formatter.format_body(body_data, "plain/text") == body_data
    # TODO(konstantin): fill with more tests

# Generated at 2022-06-21 14:11:43.414395
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import sys
    from httpie.context import Environment
    from httpie.plugins import plugin_manager

    env = Environment(colors=256)
    if is_windows:
        env.colors = 256
    plugin_manager.load_installed(env=env)

    formatter = plugin_manager.instantiate(
        name='colors',
        env=env,
        term=sys.stdout,
        color_scheme='solarized',
    )

    lexer = formatter.get_lexer_for_body('application/json', '''{
        "time": "2019-11-01 03:47:03",
        "timezone": "UTC",
        "ip": "1.1.1.1"
    }''')
    assert lexer is not None

    lexer = formatter.get_