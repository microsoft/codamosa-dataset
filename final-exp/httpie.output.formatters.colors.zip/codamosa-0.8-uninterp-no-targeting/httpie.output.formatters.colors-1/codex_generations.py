

# Generated at 2022-06-21 14:03:14.310851
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer() is not None

# Generated at 2022-06-21 14:03:16.662175
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) == Solarized256Style

# Generated at 2022-06-21 14:03:18.259634
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    ss = pygments.styles.get_style_by_name('solarized256')

# Generated at 2022-06-21 14:03:26.437767
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('text/html')
    assert lexer == pygments.lexers.get_lexer_by_name('html')

    lexer = get_lexer('text/x-python')
    assert lexer == pygments.lexers.get_lexer_by_name('python')

    lexer = get_lexer('text/unknown', explicit_json=False)
    assert lexer == pygments.lexers.get_lexer_by_name('text')

    lexer = get_lexer('text/unknown', explicit_json=True)
    assert lexer == None

# Generated at 2022-06-21 14:03:34.281720
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    c = ColorFormatter(Environment())
    assert not c.get_lexer_for_body('text/plain', '')
    assert c.get_lexer_for_body('text/css', '') is pygments.lexers.CssLexer
    assert c.get_lexer_for_body('application/javascript', '') is pygments.lexers.JavascriptLexer
    assert c.get_lexer_for_body('text/javascript', '') is pygments.lexers.JavascriptLexer
    assert c.get_lexer_for_body('application/json', '') is pygments.lexers.JsonLexer
    assert c.get_lexer_for_body('application/javascript', '{}') is pygments.lexers.JavascriptLexer
    assert c.get_lexer_for_

# Generated at 2022-06-21 14:03:45.517047
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    _test_http_line(
        line='POST /test HTTP/1.1',
        types=((pygments.token.Name.Function, 'POST'),
               (pygments.token.Text, ' '),
               (pygments.token.Name.Namespace, '/test'),
               (pygments.token.Text, ' '),
               (pygments.token.Keyword.Reserved, 'HTTP'),
               (pygments.token.Operator, '/'),
               (pygments.token.Number, '1.1')),
    )

# Generated at 2022-06-21 14:03:55.166191
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    # assert that the style class has the correct color scheme
    # if this fails, assertEquals will print which color scheme is wrong
    s256 = Solarized256Style()

# Generated at 2022-06-21 14:04:01.972761
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    # Request-Line
    http_request_line_text = "GET / HTTP/1.1"
    http_request_line_tokens = [
        (pygments.token.Name.Function, "GET "),
        (pygments.token.Name.Namespace, "/ "),
        (pygments.token.Keyword.Reserved, "HTTP"),
        (pygments.token.Operator, "/"),
        (pygments.token.Number, "1.1"),
    ]
    # don't need to know the exact number of lines
    assert len(list(lexer.get_tokens(http_request_line_text))) == \
        len(http_request_line_tokens)

# Generated at 2022-06-21 14:04:03.600029
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    JsonFormatter(Environment()).format_headers("")

# Generated at 2022-06-21 14:04:15.077561
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import sys
    from io import StringIO
    from httpie.plugins.builtin import HTTPieJSONEncoder

    print_ = StringIO()
    sys.stdout = print_

    class SomeClass():
        """
        Some class to test json encode
        """
        def __init__(self, name):
            self.name = name

        def __str__(self):
            return self.name

        def __repr__(self):
            return self.name

    output = StringIO()
    data = {
        'some': {'nested': 'items'},
        'a_list': [
            'a string',
            {'a_dict': {'another': 'dict'}},
            SomeClass('some class'),
            SomeClass('another class')
        ]
    }

# Generated at 2022-06-21 14:04:21.557132
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    print(SimplifiedHTTPLexer().get_tokens(''))

# Generated at 2022-06-21 14:04:26.206898
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer(mime='text/html') is not None
    assert get_lexer(mime='text/html', explicit_json=True,
                     body='{"hello": "world"}') is not None
    assert get_lexer(mime='text/html', explicit_json=True, 
                     body='<!doctype html><html>') is not None

# Generated at 2022-06-21 14:04:30.696499
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class DummyEnv:
        colors = 256

    env = DummyEnv()
    formatter = ColorFormatter(
        env=env,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    assert isinstance(formatter, ColorFormatter)

# Generated at 2022-06-21 14:04:37.953752
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    env.colors = 256
    plugin = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)

    def check(headers, expected):
        actual = plugin.format_headers(headers)
        return actual == expected

    # Legacy style
    assert check('HTTP/2 200 OK', '\x1b[38;5;28mHTTP\x1b[39m\x1b[38;5;173m/\x1b[39m\x1b[38;5;173m2\x1b[39m \x1b[38;5;173m200\x1b[39m \x1b[38;5;25mOK\x1b[39m')
    # Simplified style

# Generated at 2022-06-21 14:04:46.835576
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Test that lexer is resolved by mimetype.
    assert get_lexer(mime='text/xml') == pygments.lexers.XmlLexer
    assert get_lexer(mime='text/xsl') == pygments.lexers.XslLexer

    # Test that lexer is resolved by subtype.
    assert get_lexer(mime='application/json') == pygments.lexers.JsonLexer
    assert get_lexer(mime='application/javascript') == \
        pygments.lexers.JavascriptLexer
    assert get_lexer(mime='text/x-shellscript') == \
        pygments.lexers.BashLexer

    # Test that lexer is resolved by subtype name.

# Generated at 2022-06-21 14:04:59.050297
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from httpie.core import main
    import httpie.input
    import httpie.plugins

    args = httpie.input.ParseResult(**vars(main.parse_args(args=[])))
    plugins = httpie.plugins.PluginManager(env=args.env).get_list(args)
    formatter = plugins[0].get_formatter(args)

    headers = '''GET / HTTP/1.1
Host: localhost:5000
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive


'''

# Generated at 2022-06-21 14:05:10.971231
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    # The class definition contains some weird code that may be
    # related to a problem running the Python code on Python 2.
    # The code doesn't seem to be required by Pygments to support
    # Solarized256Style; the class inherits from Style and doesn't
    # override (or implement) any methods which Pygments would
    # typically call to know about the style.
    #
    # This test checks that the weird code in the class definition
    # is harmless and doesn't raise an exception.
    style = Solarized256Style()
    cls = type(style)

# Generated at 2022-06-21 14:05:12.133619
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-21 14:05:19.045306
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') == TextLexer
    assert get_lexer('text/html') == pygments.lexers.HtmlLexer
    assert get_lexer('text/markdown') == pygments.lexers.RstLexer
    assert get_lexer('application/json') == pygments.lexers.JsonLexer

    assert get_lexer('application/json', body='[]') == pygments.lexers.JsonLexer
    assert get_lexer('text/html', body='[]') == pygments.lexers.HtmlLexer

# Generated at 2022-06-21 14:05:30.473759
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
        style=Solarized256Style
    )
    text = "HTTP/1.1 200 OK"
    result = pygments.highlight(
        code=text,
        lexer=lexer,
        formatter=formatter,
    )
    assert result.strip() == "\x1b[38;5;202mHTTP\x1b[0m\x1b[38;5;200m/\x1b[0m\x1b[38;5;202m1.1\x1b[0m \x1b[38;5;202m200\x1b[0m \x1b[38;5;202mOK\x1b[0m"

    formatter = TerminalFormatter()
    result

# Generated at 2022-06-21 14:05:45.005438
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    cf = ColorFormatter(Environment())

    assert get_lexer(
        mime='application/json',
        explicit_json=False,
        body='',
    ) is None

    assert get_lexer(
        mime='application/json',
        explicit_json=False,
        body='{}',
    ) is None

    assert get_lexer(
        mime='application/json',
        explicit_json=False,
        body='[1,2]',
    ).__name__ == 'JSONLexer'

    assert get_lexer(
        mime='application/json',
        explicit_json=True,
        body='[1,2]',
    ).__name__ == 'JSONLexer'


# Generated at 2022-06-21 14:05:46.880843
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) is Solarized256Style

# Generated at 2022-06-21 14:05:58.608254
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(colors=256), color_scheme='solarized').formatter == Terminal256Formatter(Solarized256Style)
    assert ColorFormatter(Environment(colors=256)).formatter == Terminal256Formatter(Solarized256Style)
    assert ColorFormatter(Environment(colors=256), color_scheme='solarized').formatter == Terminal256Formatter(Solarized256Style)
    assert ColorFormatter(Environment(colors=256), color_scheme='solarized', explicit_json=True).formatter == Terminal256Formatter(Solarized256Style)
    assert ColorFormatter(Environment(colors=256), color_scheme='solarized', explicit_json=False).formatter == Terminal256Formatter(Solarized256Style)

# Generated at 2022-06-21 14:06:07.508470
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # test_response_header_formatting.py
    # https://github.com/jakubroztocil/httpie/blob/master/tests/test_response_header_formatting.py
    import io

    import pytest
    from httpie.output.streams import Stream
    from httpie.plugins import FormatterPlugin

    @pytest.fixture
    def formatter_plugin(stream) -> FormatterPlugin:
        formatter_plugin = ColorFormatter(
            env=Environment(),
            explicit_json=False,
        )
        formatter_plugin.stream = stream
        return formatter_plugin

    @pytest.fixture
    def stream() -> Stream:
        return Stream(stdout=io.StringIO(), stderr=io.StringIO())




# Generated at 2022-06-21 14:06:10.137051
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert style.background_color == '#1c1c1c'
    assert style.styles[pygments.token.Keyword] == '#5f8700'

# Generated at 2022-06-21 14:06:17.452176
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie import ExitStatus
    environment = Environment(
        colors=256,
        stdout_isatty=True,
        stdin_isatty=True,
    )
    color_formatter = ColorFormatter(
        env=environment,
    )
    def do_test(response_line, headers, expected):
        output = color_formatter.format_headers(
            response_line + '\r\n' + headers
        )
        assert output == '\x1b[38;5;244m' + expected + '\x1b[39m'
    do_test(
        'HTTP/1.1 200 OK',
        'Content-Type: text/plain',
        'HTTP/1.1 200 OK\r\nContent-Type: text/plain'
    )

# Generated at 2022-06-21 14:06:22.241226
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    formatter = ColorFormatter(env, color_scheme='solarized')

# Generated at 2022-06-21 14:06:34.006902
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    output = pygments.highlight(
        code='GET / HTTP/1.1\nHost: example.com\n\n',
        lexer=SimplifiedHTTPLexer(),
        formatter=TerminalFormatter(style=Solarized256Style)
    )

# Generated at 2022-06-21 14:06:43.026712
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    # Request-Line
    tokens = lexer.get_tokens('GET /index.html HTTP/1.0')
    assert 'GET' == tokens[0][1]
    assert 'GET' == tokens[0][2][0]
    assert 'HTTP' == tokens[4][1]
    assert 'HTTP' == tokens[4][2][0]
    assert '/' == tokens[5][1]
    assert '/' == tokens[5][2][0]
    assert '1.0' == tokens[6][1]
    assert '1.0' == tokens[6][2][1]
    # Response Status-Line
    tokens = lexer.get_tokens('HTTP/1.0 200 OK')
    assert 'HTTP' == tokens[0][1]
   

# Generated at 2022-06-21 14:06:43.796204
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-21 14:06:52.319219
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    assert ColorFormatter(Environment()).format_headers('HTTP/1.1 123 OK\r\n') == 'HTTP/1.1 123 OK\r\n'

# Generated at 2022-06-21 14:06:59.412729
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import subprocess
    def run_cmd(cmd):
        return subprocess.check_output(cmd, shell=True).decode()

    # `http` is a flag of environment
    env = Environment(color=True, http='httpie')
    assert env.colors

    # `formatter` is a flag of class ColorFormatter
    formatter = ColorFormatter(env)
    assert isinstance(formatter, ColorFormatter)
    assert formatter.enabled
    formatter.enabled = False
    assert not formatter.enabled

    formatter.enabled = True
    # test on JSON
    # 1. a correct json
    mime = 'application/json'

# Generated at 2022-06-21 14:07:09.827570
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SampleRequestLine = \
        "POST /path/to/resource HTTP/1.1"
    SampleResponseLine = \
        "HTTP/1.1 200 OK"
    SampleHeader = \
        "Accept-Charset: utf-8"
    # Lexer
    lexer = SimplifiedHTTPLexer()
    # Tokens
    tokens = []
    # Get tokens for that sample request line
    tokens += list(lexer.get_tokens(SampleRequestLine))
    # Get tokens for that sample response line
    tokens += list(lexer.get_tokens(SampleResponseLine))
    # Get tokens for that sample header
    tokens += list(lexer.get_tokens(SampleHeader))
    # Expected result

# Generated at 2022-06-21 14:07:17.791207
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
  # test data:
  request_code = """POST /post HTTP/1.1
Host: httpbin.org
Connection: keep-alive
User-Agent: HTTPie/0.9.5
Accept-Encoding: gzip, deflate
Accept: */*
Content-Length: 16
Content-Type: application/json

{"hello": "world"}"""

# Generated at 2022-06-21 14:07:23.763709
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """
    test_ColorFormatter_format_body
    --------------
    This function unit tests the method format_body of the class ColorFormatter
    """
    print("Test: format_body of class ColorFormatter")
    import shutil
    import httpie.cli
    test_line = 'GET /demo HTTP/1.1\r\nHost: httpbin.org\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\nUser-Agent: python-requests/2.22.0\r\n\r\n'

# Generated at 2022-06-21 14:07:30.678217
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie.cli
    import httpie.plugins
    import os
    import pytest
    import shutil
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
        style=Solarized256Style()
    )
    cfg = httpie.cli.Config(__file__ + os.sep)
    cfg.colors = 256

# Generated at 2022-06-21 14:07:36.101972
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class TestEnv():
        def __init__(self, colors=256):
            self.colors = colors

    assert ColorFormatter(TestEnv(colors=256), color_scheme="solarized").get_style_class("solarized") == Solarized256Style
    assert ColorFormatter(TestEnv()).get_style_class("solarized") == Solarized256Style

# Generated at 2022-06-21 14:07:44.216470
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    env = Environment(color_scheme='solarized256')
    formatter = ColorFormatter(env)
    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Length: 18\r\n'
        '\r\n'
    )
    assert formatter.format_headers(headers) == headers

    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Date: Sun, 10 Feb 2019 02:03:56 GMT\r\n'
        'Server: Apache\r\n'
        'Content-Length: 18\r\n'
        '\r\n'
    )

# Generated at 2022-06-21 14:07:54.394686
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexer import words
    from pygments.lexers import PythonLexer
    from pygments.lexers import Python3Lexer
    from pygments.lexer import RegexLexer

    class MyLexer(RegexLexer):
        """
        For `MyLexer` usage.
        """
        name = 'MyLexer'
        aliases = ['mylexer']
        filenames = ['*.mylexer']


# Generated at 2022-06-21 14:08:04.164002
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-21 14:08:23.672747
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from json import JSONDecodeError
    from httpie.compat import is_windows
    from httpie.compat import is_py36

    # Test FormatterPlugin class
    # Test constructor, get_lexer_for_body and format_body
    formatterPlugin = FormatterPlugin(
        env=None,
        explicit_json=False,
        color_scheme='solarized' if not is_windows else 'fruity',
        **{
            '__XXXX': '__YYYY',
            '__ZZZZ': '__XXXX'
        }
    )

    # Test constructor
    assert formatterPlugin.env is None, \
        'Unexpected value of instance variable of class FormatterPlugin'


# Generated at 2022-06-21 14:08:27.535320
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment(), color_scheme='solarized')
    assert formatter.get_lexer_for_body('text/plain', 'some text') == pygments.lexers.get_lexer_by_name('text')
    assert formatter.get_lexer_for_body('text/html', 'some html') == pygments.lexers.get_lexer_by_name('html')
    assert formatter.get_lexer_for_body('application/json', '{"some": "json"}') == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-21 14:08:35.971969
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # Test default
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) \
        == pygments.styles.get_style_by_name(DEFAULT_STYLE)
    # Test existing
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) \
        == Solarized256Style
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE.upper()) \
        == Solarized256Style
    # Test non-existing
    assert ColorFormatter.get_style_class('foobar') is None

# Generated at 2022-06-21 14:08:44.545828
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') == TextLexer
    assert get_lexer('text/html') == pygments.lexers.HtmlLexer

    # specific lexers
    assert get_lexer('application/json') == pygments.lexers.JsonLexer
    assert get_lexer('application/x-httpd-php') == \
           pygments.lexers.PhpLexer
    assert get_lexer('application/x-sh') == pygments.lexers.BashLexer
    assert get_lexer('text/x-c') == pygments.lexers.CLexer
    assert get_lexer('application/xml') == pygments.lexers.XmlLexer

    # wildcard based lexers
    assert get_lexer('text/css') == pygments.lexers.Css

# Generated at 2022-06-21 14:08:56.346973
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import os
    http_lexer = PygmentsHttpLexer()
    formatter = Terminal256Formatter(style=Solarized256Style)
    test_dir = os.getcwd()
    os.chdir(test_dir)
    parser = argparse.ArgumentParser(
        add_help=False,
        usage=argparse.SUPPRESS,
    )
    parser.add_argument('-h', '--help', dest='help',
                        help='Show this help message and exit.',
                        action=argparse.SUPPRESS)
    parser.add_argument('--debug', dest='debug',
                        help='Show the full traceback on exceptions.',
                        action=argparse.SUPPRESS)
    env = Environment(parser, args=[])

# Generated at 2022-06-21 14:08:58.571606
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-21 14:08:59.623184
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer

# Generated at 2022-06-21 14:09:04.198934
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert(ColorFormatter({'colors': True}, DEFAULT_STYLE))
    assert(ColorFormatter({'colors': '256'}, DEFAULT_STYLE))
    assert(not ColorFormatter({'colors': False}, DEFAULT_STYLE))

# Generated at 2022-06-21 14:09:06.877596
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter(True)
    assert (cf.enabled == True)
    cf = ColorFormatter(False)
    assert (cf.enabled == False)

# Generated at 2022-06-21 14:09:14.465577
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(style=Solarized256Style)
    http = \
        """POST / HTTP/1.1
Content-Type: application/json
User-Agent: HTTPie/1.0.0
Accept-Encoding: gzip, deflate
Accept: application/json, */*
Connection: keep-alive
Content-Length: 9
Host: httpbin.org

{"key": 3}"""

# Generated at 2022-06-21 14:10:03.445316
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') is None
    assert get_lexer('text/plain') is None
    assert get_lexer('application/json') is not None
    assert get_lexer('application/json', explicit_json=True) is not None
    assert get_lexer('application/json', explicit_json=True, body='{}') \
        is not None
    assert get_lexer('application/json', explicit_json=True, body='{') \
        is None
    assert get_lexer('application/pdf') is None
    assert get_lexer('application/pdf', body='%PDF-1.4') is not None
    assert get_lexer('application/octet-stream', body='%PDF-1.4') is not None

# Generated at 2022-06-21 14:10:09.041059
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    for color_scheme in AVAILABLE_STYLES:
        ColorFormatter(env=Environment(colors=True), color_scheme=color_scheme)
        ColorFormatter(env=Environment(colors=256), color_scheme=color_scheme)
        if is_windows:
            ColorFormatter(env=Environment(colors=True), color_scheme=color_scheme)

# Generated at 2022-06-21 14:10:12.998703
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json

    body = {
        "name": "zhujiefeng",
        "age": 29,
        "sex": "male"
    }
    body_str = json.dumps(body)
    c = ColorFormatter(
        Environment(colors=16),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    re = c.format_body(body_str, "application/json")
    print(re)

# Generated at 2022-06-21 14:10:16.285335
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexers._mapping import LEXERS
    LEXERS['text']['http'] = [
        (SimplifiedHTTPLexer, [], None)]
    pygments.lexers.get_lexer_by_name('http')



# Generated at 2022-06-21 14:10:17.010373
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:10:17.542900
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert True

# Generated at 2022-06-21 14:10:18.858322
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer(startinline=False)

# Generated at 2022-06-21 14:10:28.949686
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    code = """\
GET / HTTP/1.1
Accept-Encoding: gzip, deflate, compress
Accept: */*
User-Agent: HTTPie/0.9.2


HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 14
"""

# Generated at 2022-06-21 14:10:33.346700
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Create a mock class which implements format_body method
    class ColorFormatterMock:
        def format_body(self, body, mime):
            return body

    color_formatter = ColorFormatterMock()
    body = '{"foo": "bar"}'
    mime = 'application/json'
    assert body == color_formatter.format_body(body, mime)

# Generated at 2022-06-21 14:10:35.101780
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors='256')
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__.__name__ == 'Terminal256Formatter'

# Generated at 2022-06-21 14:11:21.280126
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(True) != None

# Generated at 2022-06-21 14:11:22.646761
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    print(Solarized256Style)

# Generated at 2022-06-21 14:11:33.454278
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    formatter = ColorFormatter(env)
    assert formatter.formatter.__class__ == Terminal256Formatter
    assert formatter.http_lexer.__class__ == SimplifiedHTTPLexer

    formatter = ColorFormatter(env, color_scheme=AUTO_STYLE)
    assert formatter.formatter.__class__ == TerminalFormatter
    assert formatter.http_lexer.__class__ == PygmentsHttpLexer

    # test 256 color scheme
    formatter = ColorFormatter(env, color_scheme='github')
    assert formatter.formatter.__class__ == Terminal256Formatter
    style_class = formatter.formatter.style.__class__
    assert style_class.__name__ == 'GithubStyle'

    # test invalid color scheme
    form

# Generated at 2022-06-21 14:11:40.345839
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Arrange
    from httpie.cli.argtypes import KeyValueArgType
    from httpie import ExitStatus
    from tests.utils import MockEnvironment, http, HTTP_OK
    env = MockEnvironment()
    env.stdout_isatty = True

    # Act
    r = http(
        '--print=H',
        '--formatter=colors',
        '--headers', 'one: 1', 'two: 2',
        'GET', httpbin('headers')
    )

    # Assert
    assert HTTP_OK in r
    assert 'HTTP/1.1 200 OK' not in r
    assert 'Request Headers' in r

# Generated at 2022-06-21 14:11:43.681558
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    f = ColorFormatter(env, color_scheme=DEFAULT_STYLE)
    assert isinstance(f.formatter, Terminal256Formatter)

# Generated at 2022-06-21 14:11:48.775450
# Unit test for function get_lexer
def test_get_lexer():
    assert not get_lexer('text/xyz')
    assert get_lexer('text/plain') is TextLexer
    assert get_lexer('text/plain', body='{}') is TextLexer
    assert get_lexer('text/plain', explicit_json=True) is TextLexer
    assert get_lexer('text/plain', body='{}', explicit_json=True) is pygments.lexers.JavascriptLexer

# Generated at 2022-06-21 14:11:50.046700
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style.__bases__[0] == pygments.style.Style

# Generated at 2022-06-21 14:12:00.995126
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert lexer.aliases == ['http']
    assert lexer.filenames == ['*.http']
    root_rule = lexer.tokens['root']
    assert len(root_rule) == 3
    assert root_rule[0][0] == '([A-Z]+)( +)([^ ]+)( +)(HTTP)(/)(\d+\.\d+)'

# Generated at 2022-06-21 14:12:08.426655
# Unit test for method format_body of class ColorFormatter

# Generated at 2022-06-21 14:12:19.384660
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from json import dumps
    from httpie.core import Environment

    def call(
        body: str,
        mime: str,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE
    ) -> str:
        return ColorFormatter(
            env=Environment(colors=256),
            explicit_json=explicit_json,
            color_scheme=color_scheme
        ).format_body(body, mime)

    # No colorization
    assert call('{}', 'application/json') == '{}'
    assert call('[1, 2, 3]', 'application/json') == '[1, 2, 3]'
    assert call('', '') == ''

    # Explicit JSON