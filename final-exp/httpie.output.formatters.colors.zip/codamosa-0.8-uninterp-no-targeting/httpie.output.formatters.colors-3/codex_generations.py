

# Generated at 2022-06-21 14:03:07.625549
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(None, None, None)
    assert formatter.http_lexer.__class__.__name__ == "SimplifiedHTTPLexer"
    assert formatter.formatter.__class__.__name__ == "Terminal256Formatter"

# Generated at 2022-06-21 14:03:12.113800
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment()
    formatter = ColorFormatter(env)
    body = '{"key": "value"}'
    mime = 'text/html'
    explicit_json = True
    assert formatter.get_lexer_for_body(mime, body)
    mime = 'application/json'
    assert formatter.get_lexer_for_body(mime, body)

# Generated at 2022-06-21 14:03:16.279044
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert pygments.highlight(
        code='',
        lexer=SimplifiedHTTPLexer(),
        formatter=Terminal256Formatter(style=Solarized256Style)
    ) == '\n'

# Generated at 2022-06-21 14:03:27.030738
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    json_first = ColorFormatter(Environment(colors=1), explicit_json=True)
    json_last = ColorFormatter(Environment(colors=1), explicit_json=False)

    def test(mime, body, explicit_json=False):
        # Pass body to trigger JSON auto-detection
        assert json_first.get_lexer_for_body(mime, body) \
            == json_last.get_lexer_for_body(mime, body)

    # Properly detects JSON mime
    test('application/json', '{}')
    test('application/json', '{')
    test('application/json', '{', explicit_json=True)
    test('application/json', '{', explicit_json=False)

    # Falls back to text if mime is invalid

# Generated at 2022-06-21 14:03:28.339513
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer('HTTP','','')

# Generated at 2022-06-21 14:03:35.538866
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import StdoutStream
    from httpie.plugins import plugin_manager

    output_stream = StdoutStream()
    env = Environment(colors=254, stdout=output_stream)

    formatter = ColorFormatter(
        env=env,
        explicit_json=False,
        color_scheme='solarized'
    )

# Generated at 2022-06-21 14:03:39.593441
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.lexers.text import HttpLexer
    http_lexer = HttpLexer()
    simplified_http_lexer = SimplifiedHTTPLexer()
    assert(http_lexer != simplified_http_lexer)

# Generated at 2022-06-21 14:03:41.975159
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class("solarized-dark") is pygments.styles.get_style_by_name("solarized-dark")

# Generated at 2022-06-21 14:03:50.491857
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie import ExitStatus
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import FormatterPlugin

    class TestFormatter(FormatterPlugin):
        allow_styles = True  # Override this attribute to be true
        pprint_enabled = True  # for testing format_body

        def format_body(self, body, mime):
            return 'formatted body'

    env = Environment(stdout=None, color=True)
    formatter = TestFormatter(env)

    # Test format_body when Content-Type is application/json
    assert formatter.format_body('{"key": "value"}', 'application/json') == 'formatted body'

    # Test format_body when Content-Type is text/html and has non

# Generated at 2022-06-21 14:03:59.429588
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(Environment({'httpie': {'colors': '256'}}), color_scheme='solarized')
    body = '{"name":"httpie","description":"Modern command line HTTP client – user-friendly curl alternative with intuitive UI, JSON support, syntax highlighting, wget-like downloads, extensions, etc."}'
    mime = 'application/json'
    assert color_formatter.format_body(body, mime) == '{\n' + ' ' * 8 + '"name": "httpie",\n' + ' ' * 8 + '"description": "Modern command line HTTP client – user-friendly curl alternative with intuitive UI, JSON support, syntax highlighting, wget-like downloads, extensions, etc."\n}'


# Generated at 2022-06-21 14:04:08.103980
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-21 14:04:14.196107
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import sys
    import io
    sys.stdout = io.StringIO()
    headers = "a: b\r\n" + \
              "Content-Type: text/plain\r\n"

    cf = ColorFormatter(Environment(colors=True), verbose=0)
    cf.format_headers(headers)
    print(sys.stdout.getvalue())


# Generated at 2022-06-21 14:04:23.897741
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-21 14:04:25.170096
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = get_lexer(mime='text/html')
    assert lexer is not None

# Generated at 2022-06-21 14:04:29.000804
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    print('test_SimplifiedHTTPLexer')
    key_words = ['GET', 'POST', 'HTTP', 'GET', 'POST', 'HTTP', '200', '400']
    for i in key_words:
        print (i)

# Generated at 2022-06-21 14:04:39.264212
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def assert_lexer_name(method, mime, body, expected):
        lexer = method(mime, body)
        assert lexer.name == expected

    formatter = ColorFormatter(Environment(), False, "solarized")
    assert_lexer_name(formatter.get_lexer_for_body, "", "", "Text only")
    assert_lexer_name(formatter.get_lexer_for_body, "text/plain", "", "Text only")
    assert_lexer_name(formatter.get_lexer_for_body, "text/plain; charset=utf-8", "", "Text only")
    assert_lexer_name(formatter.get_lexer_for_body, "text/html", "<html>", "HTML")

# Generated at 2022-06-21 14:04:39.913740
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    pass

# Generated at 2022-06-21 14:04:42.708299
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) is None
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) is Solarized256Style

# Generated at 2022-06-21 14:04:48.428903
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class Mock:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    cf = ColorFormatter(Mock(colors=256))
    headers = "\r\n".join([
        "HTTP/1.1 200 OK",
        "Content-Type: text/plain",
        "Content-Length: 4",
        "Connection: close"
    ])

# Generated at 2022-06-21 14:05:00.427580
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer(mime='application/json', explicit_json=False, body='')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer(mime='application/json', explicit_json=False, body='abc')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer(mime='application/json', explicit_json=True, body='')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer(mime='application/json', explicit_json=True, body='abc')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-21 14:05:13.282802
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.output import OutputOptions, OutputWriter

    class _Env(Environment):
        def __init__(self, **kwargs):
            self.config = {}
            self.colors = kwargs.get('colors', False)

    env = _Env()
    o = OutputOptions()
    o.colors = True
    o.style = "solarized"
    o.stream = True
    o.silent = True
    o.pretty = True
    out = OutputWriter(o)
    ColorFormatter(env, out, out)



# Generated at 2022-06-21 14:05:19.745647
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json+custom') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json+custom', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-21 14:05:23.358856
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    assert http_lexer.name == 'HTTP'
    assert http_lexer.aliases == ['http']
    assert http_lexer.filenames == ['*.http']

# Generated at 2022-06-21 14:05:35.016042
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import httpie.plugins.builtin

    def assert_headers_formatting(expected, *lines):
        env = Environment()
        formatter = ColorFormatter(env, style='fruity')
        assert expected.strip() == formatter.format_headers(
            '\n'.join(lines)
        )

    # Request
    assert_headers_formatting(
        '\x1b[90mGET / HTTP/1.1\x1b[39;49;00m',
        'GET / HTTP/1.1'
    )

# Generated at 2022-06-21 14:05:44.133041
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer(mime="text/html", body="") == pygments.lexers.get_lexer_by_name("html")
    assert get_lexer(mime="application/json", body="") == pygments.lexers.get_lexer_by_name("json")
    assert get_lexer(mime="application/xml", body="") == pygments.lexers.get_lexer_by_name("xml")

    assert get_lexer(mime="application/json", body="{}") == pygments.lexers.get_lexer_by_name("json")
    assert get_lexer(mime="text/plain", body="{}") == None
    assert get_lexer(mime="text/plain", body="{}", explicit_json=True) == pygments.lexers

# Generated at 2022-06-21 14:05:55.841595
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    import httpie
    env = httpie.Environment()
    cm = ColorFormatter(env)

    # Produce a simple HTML string
    body = "<!DOCTYPE html>\n<html>\n<body>\n\n<h1>My First Heading</h1>\n\n" \
           "<p>My first paragraph.</p>\n\n</body>\n</html>"

    # Get the lexer for the body (HTML)
    lexer = cm.get_lexer_for_body("text/html", body)

    # Highlight the body
    body = pygments.highlight(
        code=body,
        lexer=lexer,
        formatter=cm.formatter,
    )

    assert body



# Generated at 2022-06-21 14:06:05.700747
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.plugins import BuiltinPluginManager

    headers_str = """\
HTTP/1.1 200 OK
Content-Length: 0
Content-Type: text/plain
Date: Mon, 07 Oct 2019 15:14:25 GMT
Server: TestServer
"""
    env = Environment(colors=True)
    cf = ColorFormatter(env, False)
    headers_html = cf.format_headers(headers_str)
    assert 'HTTP/1.1' in headers_html
    assert 'OK' in headers_html
    assert 'text/plain' in headers_html
    assert 'Date' in headers_html
    assert 'Content-Type' in headers_html
    assert 'Content-Length' in headers_html
    assert 'Server' in headers_html

    headers_str = 'HTTP/1.1'

# Generated at 2022-06-21 14:06:09.510175
# Unit test for function get_lexer
def test_get_lexer():
    assert(type(get_lexer('application/json')) == type(pygments.lexers.get_lexer_by_name('json')))
    assert(type(get_lexer('application/xml')) == type(pygments.lexers.get_lexer_by_name('XML')))

# Generated at 2022-06-21 14:06:13.718642
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert (
        SimplifiedHTTPLexer().get_tokens('GET / HTTP/1.1') ==
        SimplifiedHTTPLexer().get_tokens('GET / HTTP/1.1\r\n')
    )

# Generated at 2022-06-21 14:06:24.672641
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer().name == 'HTTP'
    assert SimplifiedHTTPLexer().aliases == ['http']
    assert SimplifiedHTTPLexer().filenames == ['*.http']

# Generated at 2022-06-21 14:06:31.892595
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    pass

# Generated at 2022-06-21 14:06:32.542211
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter

# Generated at 2022-06-21 14:06:42.020605
# Unit test for function get_lexer
def test_get_lexer():
    def test_case(mime, explicit_json, body, expected):
        if expected:
            expected = pygments.lexers.get_lexer_by_name(expected)
        assert get_lexer(mime, explicit_json, body) == expected
    test_case('application/json', False, '{}', 'json')
    test_case('application/xml', False, '<!xml', 'xml')
    test_case('application/x-www-form-urlencoded', False, 'a=b', 'url')
    test_case('application/x-www-form-urlencoded', True, 'a=b', 'json')
    test_case('text/plain', False, 'a=b', 'txt')
    test_case('text/plain', True, 'a=b', 'json')
   

# Generated at 2022-06-21 14:06:54.130613
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('application/json', body='{"key":"value"}')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer('application/json+unknown', body='''
    {
        "key": "value"
    }
    ''')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer('application/json+unknown')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer('application/json+unknown', explicit_json=True,
                      body='{"key":"value"}')

# Generated at 2022-06-21 14:06:58.771824
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import sys

    try:
        get_lexer(
            mime="com.tikal.tpo",
            explicit_json=False,
            body=""
        )
    except Exception as e:
        if ( type(e) == ClassNotFound):
            sys.exit(0)
        else:
            print(e)
            sys.exit(-1)
    sys.exit(-1)

# Generated at 2022-06-21 14:07:04.832555
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    # Test case 1
    output = pygments.highlight(
        code='GET / HTTP/1.1\n',
        lexer=http_lexer,
        formatter=Terminal256Formatter(style=Solarized256Style),
    ).strip()
    output = output.replace('\033[38;5;', '\033[38;2;')
    assert (output == '\x1b[38;2;37m\x1b[48;2;28mGET \x1b[38;2;241m/'
            ' \x1b[38;2;101mHTTP/1.1\x1b[0m\n')
    # Test case 2

# Generated at 2022-06-21 14:07:05.651176
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-21 14:07:09.532427
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256, verbose=True, debug=False)
    formatter = ColorFormatter(env, color_scheme='monokai')
    assert(formatter.formatter.style.styles == pygments.styles.get_style_by_name('monokai').styles)
    assert(formatter.enabled == True)

# Generated at 2022-06-21 14:07:10.202606
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:07:18.034425
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/javascript') == pygments.lexers.get_lexer_by_name('javascript')
    assert get_lexer('application/x-javascript') == pygments.lexers.get_lexer_by_name('javascript')
    assert get_lexer('text/javascript') == pygments.lexers.get_lexer_by_name('javascript')
    assert get_lexer('text/x-javascript') == pygments.lexers.get_lexer_by_name('javascript')
    assert get_lexer('application/vnd.oasis.opendocument.text') == pygments.lexers.get_lexer_by_name('odt')

# Generated at 2022-06-21 14:07:34.807654
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter()
    assert formatter.format_headers(headers='foo: bar') == """
http:\x1b[36m\x1b[1mGET\x1b[22m\x1b[39m / HTTP/1.1\r
\x1b[33mHost\x1b[39m: localhost:80\r
\x1b[33mUser-Agent\x1b[39m: HTTPie/0.9.2\r
\x1b[33mAccept\x1b[39m: */*\r
\x1b[33mfoo\x1b[39m: bar\r
"""

# Generated at 2022-06-21 14:07:37.124569
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert isinstance(lexer, pygments.lexer.RegexLexer)

# Generated at 2022-06-21 14:07:48.906510
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin

    env = Environment(colors=256)
    color_formatter = ColorFormatter(env)
    color_formatter.enabled = True
    assert color_formatter.format_headers('test_headers') == u'\x1b[38;5;215mtest_headers\x1b[0m'

    env = Environment(colors=256)
    color_formatter = ColorFormatter(env)
    color_formatter.enabled = False
    assert color_formatter.format_headers('test_headers') == 'test_headers'

    env = Environment(colors=256)
    color_formatter = ColorFormatter(env)
    color_formatter.enabled = False
    assert color_formatter.format_

# Generated at 2022-06-21 14:07:55.792241
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('auto') == Solarized256Style
    assert ColorFormatter.get_style_class('default') == Solarized256Style
    assert ColorFormatter.get_style_class('terminal16') == Solarized256Style
    assert ColorFormatter.get_style_class('terminal256') == Solarized256Style
    assert ColorFormatter.get_style_class('unknown') == Solarized256Style

# Generated at 2022-06-21 14:07:56.515471
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:07:58.293504
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer

# Generated at 2022-06-21 14:08:04.752455
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter.started_value
    assert formatter.get_lexer_for_body('application/json')
    assert formatter.get_lexer_for_body('application/hal+json')
    assert formatter.get_lexer_for_body('application/schema+json')
    assert formatter.get_lexer_for_body('application/vnd.schema+json')
    assert formatter.get_lexer_for_body('application/vnd.example.format+json')
    assert formatter.get_lexer_for_body('application/vnd+json')

# Generated at 2022-06-21 14:08:15.130447
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(Environment(colors=256))
    headers = """GET / HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: localhost
User-Agent: HTTPie/0.9.6"""
    result = formatter.format_headers(headers)

# Generated at 2022-06-21 14:08:21.914518
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins import FormatterPlugin
    color_formatter = ColorFormatter(
        env=None,
        explicit_json=False,
        color_scheme=SOLARIZED_STYLE,
    )
    assert(color_formatter.get_style_class('solarized') == Solarized256Style)
    assert(color_formatter.get_style_class('solarized256') == Solarized256Style)
    assert(color_formatter.get_style_class('solarized256') != FormatterPlugin)

# Generated at 2022-06-21 14:08:30.441806
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie import ExitStatus
    from httpie.context import Environment
    from httpie.core import main_communicate
    from httpie.output import get_default_options

    # Test a known good request
    env = Environment(stdin=None, stdout=None, stderr=None,
                      isatty=True, colors=256)
    options = get_default_options()
    args = ['https://httpbin.org/get']
    stdout, stderr, exit_status = main_communicate(args,
                                                   env,
                                                   options)
    cf = ColorFormatter(env)
    lexer = cf.get_lexer_for_body('application/json', stdout)
    assert(lexer is not None)

    # Test a good request with incorrect mimetype

# Generated at 2022-06-21 14:08:56.190187
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import manager
    from httpie.config import Config

    env = Environment(
        colors=True,
        config=Config(),
        stdin=None,
        stdout=None,
        stdout_isatty=False,
        stdin_isatty=False,
    )

    explicit_json = False
    color_formatter = ColorFormatter(
        env=env,
        explicit_json=explicit_json,
        color_scheme=DEFAULT_STYLE,
    )

    mime = 'application/json'

# Generated at 2022-06-21 14:08:56.774060
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert True

# Generated at 2022-06-21 14:09:04.854587
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') == pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='{}') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True, body='invalid') is None

# Generated at 2022-06-21 14:09:05.403367
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:09:13.643302
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    import pytest
    from httpie.plugin import get_plugin_manager
    from httpie.plugins.builtin import HTTPPassThroughPlugin
    from httpie.output.streams import get_default_stdout
    from httpie.plugins.builtin import HTTPiePlugin, ColorFormatter

    pm = get_plugin_manager()
    pm.register(HTTPiePlugin)
    pm.register(HTTPPassThroughPlugin)

    pm.register(ColorFormatter)
    pm.prepare()

    color_formatter = pm.instantiate(
        ColorFormatter,
        # The TestEnvironment object is used by the ColorFormatter object
        # to detect if we are on Windows or not (by checking the
        # environment.is_windows variable) 
        env=Environment(colors=256, is_windows=False)
    )
    color

# Generated at 2022-06-21 14:09:17.160109
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    testStyle = Solarized256Style()
    assert isinstance(testStyle, pygments.style.Style)
    assert testStyle.background_color == "#1c1c1c"
    assert isinstance(testStyle.styles, dict)

# Generated at 2022-06-21 14:09:19.718076
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style

# Generated at 2022-06-21 14:09:21.265316
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert isinstance(ColorFormatter(Environment(colors=256), color_scheme="solarized"), ColorFormatter)

# Generated at 2022-06-21 14:09:28.840205
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import unittest

    class ColorFormatterTest(unittest.TestCase):
        from httpie.context import Environment
        from httpie import plugins
        from httpie.plugins import FormatterPlugin
        env = Environment()
        fp = ColorFormatter(env, explicit_json=False)

        def test_format_headers(self):
            headers = """\
HTTP/1.1 200 OK
Content-Length: 13
Content-Type: application/json
Date: Sun, 20 May 2018 04:05:34 GMT
Server: Werkzeug/0.14.1 Python/3.6.4

"""

# Generated at 2022-06-21 14:09:39.323482
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=True)
    color_formatter = ColorFormatter(env)
    headers = color_formatter.format_headers(
        """GET / HTTP/1.1
Host: localhost:8080
Accept: */*
Accept-Encoding: gzip, deflate
User-Agent: HTTPie/0.9.7

""".strip()
    )

# Generated at 2022-06-21 14:10:12.058158
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    formatter = TerminalFormatter()

    code = 'header: value\r\n'
    tokens = lexer.get_tokens(code)
    output = pygments.format(tokens, formatter)
    assert output == code

# Generated at 2022-06-21 14:10:12.770625
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-21 14:10:17.092664
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from json import JSONDecodeError
    try:
        ColorFormatter(Environment(), 'dummy').get_style_class('dummy')
        assert False, 'Expected the color_scheme dummy to raise ClassNotFound'
    except ClassNotFound:
        pass

    try:
        ColorFormatter(Environment(), 'dummy').get_style_class(SOLARIZED_STYLE)
        assert False, 'Expected the color_scheme solarized to raise ClassNotFound'
    except ClassNotFound:
        pass

    try:
        ColorFormatter(Environment(), 'dummy').get_style_class(AUTO_STYLE)
        assert False, 'Expected the color_scheme auto to raise ClassNotFound'
    except ClassNotFound:
        pass


# Generated at 2022-06-21 14:10:19.285617
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(color_scheme='nonexist') == Solarized256Style

# Generated at 2022-06-21 14:10:29.246953
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # given
    env = Environment(stdin=None, stdout=None, stderr=None,
                      vars=None, config_dir=None, colors=True)
    color_formatter = ColorFormatter(env=env)
    headers_str = (
        "HTTP/1.1 200 OK\r\n"
        "Date: Wednesday, 27-May-2020 14:16:31 GMT\r\n"
        "Server: Apache/2.4.39 (Unix)\r\n"
        "Connection: close\r\n"
        "Content-Length: 0\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        "X-Powered-By: PHP/5.6.40\r\n"
    )

    # when
    actual

# Generated at 2022-06-21 14:10:36.593820
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.input import ParseError

    class MockEnvironment():
        def __init__(self):
            self.is_windows = False
            self.colors = 256

    def test_call(content, mime, **kwargs):
        return ColorFormatter(
            env=MockEnvironment(),
            color_scheme=SOLARIZED_STYLE,
            **kwargs
        ).get_lexer_for_body(
            content=content,
            mime=mime,
        )

    assert test_call('{}', 'application/json')\
        is pygments.lexers.get_lexer_by_name('json')
    assert test_call('{}', 'application/json; charset=utf-8')\
        is pygments.lexers.get_lexer_by_

# Generated at 2022-06-21 14:10:45.714064
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import requests
    import httpie.cli
    import httpie.cli.formatters
    client = httpie.cli.CLI(
        env=httpie.cli.Environment(colors=256),
        formatter=httpie.cli.formatters.JSONFormatter(),
        style=httpie.cli.formatters.Colors.solarized256
    )
    response_object = requests.get('https://httpbin.org/get')
    headers = client.format_headers(response_object.headers)

# Generated at 2022-06-21 14:10:55.030454
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    """Color formatter test"""

    c = ColorFormatter({}, "")
    result = c.format_headers("GET / HTTP/1.1\r\n"
                              "Host: \r\n"
                              "Accept: */*\r\n"
                              "Accept-Encoding: gzip, deflate, br\r\n"
                              "Accept-Language: fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7\r\n"
                              "\r\n")

    #     '\x1b[1mGET \x1b[32m/ \x1b[37mHTTP/1.1\r\n'
    #     '\x1b[1mHost: \x1b[37m\r\n'

# Generated at 2022-06-21 14:11:01.554803
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.compat import is_windows
    import json

    env = Environment(colors=256)
    formatter = ColorFormatter(env)

    colorized_json_body = formatter.format_body(
        """{
            "key1": "value1",
            "key2": "value2"
        }""",
        'application/json',
    )


# Generated at 2022-06-21 14:11:12.263540
# Unit test for constructor of class SimplifiedHTTPLexer