

# Generated at 2022-06-21 14:03:22.877770
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='no/lexer') is None
    assert get_lexer(mime='no/lexer', body='') is None
    assert get_lexer(mime='no/lexer', body='foo') is None
    assert get_lexer(mime='no/lexer', explicit_json=True) is None
    assert get_lexer(mime='no/lexer', explicit_json=True, body='') is None
    assert get_lexer(mime='no/lexer', explicit_json=True, body='foo') is None
    assert get_lexer(mime='application/json', body='') is None
    assert get_lexer(mime='application/json', body='foo') is None

# Generated at 2022-06-21 14:03:26.347848
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    x = Solarized256Style()
    assert x.styles[pygments.token.Name.Attribute] ==  "#8a8a8a"
    assert x.styles[pygments.token.Generic.Inserted] == "#00af87"

# Generated at 2022-06-21 14:03:33.986203
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    text = '''\
GET / HTTP/1.1
Host: httpbin.org
Accept-Encoding: gzip, deflate
Accept: */*
User-Agent: HTTPie/0.9.8

'''
    simplifiedhttp_lexer = SimplifiedHTTPLexer()
    tokens = list(simplifiedhttp_lexer.get_tokens(text))
    assert len(tokens) == 21
    assert tokens[0] == (pygments.token.Name.Function, 'GET')
    assert tokens[2] == (pygments.token.Name.Namespace, '/')
    assert tokens[4] == (pygments.token.Keyword.Reserved, 'HTTP')
    assert tokens[5] == (pygments.token.Operator, '/')

# Generated at 2022-06-21 14:03:41.524277
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_scheme = 'solarized'
    assert ColorFormatter.get_style_class(color_scheme) == Solarized256Style
    color_scheme = 'not_valid_color_scheme'
    assert ColorFormatter.get_style_class(color_scheme) == Solarized256Style
    color_scheme = 'fruity'
    assert ColorFormatter.get_style_class(color_scheme) == pygments.styles.get_style_by_name(color_scheme)

# Generated at 2022-06-21 14:03:45.520561
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import pygments.lexers
    import pygments.util

    # Test a Request-Line
    # Basic test
    token = next(pygments.lexers.get_lexer_for_mimetype(
        'text/plain')('GET / HTTP/1.1\r\n').get_tokens(''))
    assert(token[0] == pygments.token.Name.Function)
    assert(token[1] == 'GET')
    token = next(pygments.lexers.get_lexer_for_mimetype(
        'text/plain')('GET / HTTP/1.1\r\n').get_tokens(''))
    assert(token[0] == pygments.token.Text)
    assert(token[1] == ' ')

# Generated at 2022-06-21 14:03:50.557118
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    import httpie.plugins

    env = Environment(stdin=False, stdout=False, vcstype=None,
                      format=['colors'])
    httpie.plugins.load_internal_plugins()
    color_formatter = httpie.plugins.get_formatter('colors', env)

    assert isinstance(color_formatter, ColorFormatter)

# Generated at 2022-06-21 14:03:56.423300
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins.colors import ColorFormatter

    class FakeEnvironment():
        def __init__(self, colors=256):
            self.colors = colors

    fake_env = FakeEnvironment()
    assert ColorFormatter.get_style_class(fake_env, color_scheme='solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class(fake_env, color_scheme='default') != Solarized256Style

# Generated at 2022-06-21 14:03:56.939956
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:04:03.746982
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from unittest.mock import Mock

    mime = 'application/json'
    body = '{"foo": 1}'
    explicit_json = False
    cf = ColorFormatter(env=Mock(), explicit_json=explicit_json)
    assert cf.get_lexer_for_body(mime, body) is not None

    from io import StringIO
    from httpie.plugins import FormatterPlugin
    fp = StringIO()
    fp.close = lambda: None # FIXME: hacky way to keep fp open and close on __del__
    fp.write = lambda x: x

    fp.name = 'output.json'

    # Test that the lexer is used even when the body is invalid json
    # with a json extension.
    body = 'this is not valid JSON'

# Generated at 2022-06-21 14:04:15.174922
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.context import Environment
    from httpie import ExitStatus


# Generated at 2022-06-21 14:04:23.463843
# Unit test for function get_lexer
def test_get_lexer():
    lex = get_lexer('application/json; charset=utf-8', '', '')
    assert lex is not None
    assert lex.name == 'JSON'

# Generated at 2022-06-21 14:04:31.121338
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """tests if color formatter adds colors to body only if there is no lexer available"""
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment

    color_formatter = ColorFormatter(env=Environment(colors=256))
    assert color_formatter.format_body(mime="application/octet-stream", body="") == ""

    dummy_color_formatter = DummyColorFormatter(env=Environment(colors=256))
    assert dummy_color_formatter.format_body(mime="application/octet-stream", body="") == "dummy"



# Generated at 2022-06-21 14:04:35.316307
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins.builtin import HTTPHeaders
    assert ColorFormatter(None).format_headers(HTTPHeaders(dict(
        foo='bar',
    )).format()) == '\x1b[1m\x1b[34mfoo\x1b[39;49m\x1b[22m: \x1b[31mbar\x1b[39;49m'

# Generated at 2022-06-21 14:04:37.488414
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()
    assert s.styles[pygments.token.Name.Entity] == Solarized256Style.ORANGE

# Generated at 2022-06-21 14:04:46.493774
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import os
    os.environ['NO_COLOR'] = 'True'
    ColorFormatter.ALTERNATE_RESET = ''
    formatter = ColorFormatter(Environment())
    # the "RESET" that isn't really a reset
    assert formatter.format_headers('header: value') == (
        '\x1b[38;5;246mheader\x1b[0m:\x1b[38;5;246m ' +
        'value\x1b[0m'
    )

    # a "RESET" which actually is a reset, like on Windows
    ColorFormatter.ALTERNATE_RESET = '\x1b[m'
    formatter = ColorFormatter(Environment())

# Generated at 2022-06-21 14:04:47.989705
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('colorful') is None

# Generated at 2022-06-21 14:05:00.109010
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment

    def do_call(env_args, **kwargs):
        env = Environment(colors=True, **env_args)
        f = ColorFormatter(env, True)
        headers = '''\
Content-Length: 1234
Content-Type: application/json
Connection: keep-alive
X-Secret-Token: xxx
'''
        return f.format_headers(headers)

# Generated at 2022-06-21 14:05:12.183666
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-21 14:05:19.957923
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(
        env=env,
        explicit_json=False,
        color_scheme=SOLARIZED_STYLE,
    )
    lexer = formatter.get_lexer_for_body('image/png', 'foo')
    assert lexer is None
    lexer = formatter.get_lexer_for_body('application/json', 'foo')
    assert lexer is None
    lexer = formatter.get_lexer_for_body('application/json', '{}')
    assert lexer is not None
    lexer = formatter.get_lexer_for_body('application/http', 'foo')
    assert lexer is not None
    lexer = formatter.get_

# Generated at 2022-06-21 14:05:32.065940
# Unit test for function get_lexer
def test_get_lexer():
    # type: () -> None
    from httpie.globals import DEFAULT_JSON_INDENT

    lexer = get_lexer(mime='application/json')

# Generated at 2022-06-21 14:05:59.911840
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import get_default_std_streams
    env = Environment(colors=256, stdin_isatty=True, stdout_isatty=True)
    stdout, stdin = get_default_std_streams(env)
    formatter = ColorFormatter(env=env, stdout=stdout, stdin=stdin)

# Generated at 2022-06-21 14:06:08.476533
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.main import parser
    lexer = ColorFormatter(
        parser.parse_args([
            '--json',
            'httpbin.org/get'
        ]),
        explicit_json=False,
        color_scheme='auto'
    ).get_lexer_for_body(
        mime='application/json',
        body='{"a":true}'
    )
    assert lexer.name == 'JSON'
    lexer = ColorFormatter(
        parser.parse_args([
            '--json',
            'httpbin.org/get'
        ]),
        explicit_json=True,
        color_scheme='auto'
    ).get_lexer_for_body(
        mime='application/json',
        body='{"a":true}'
    )
    assert lex

# Generated at 2022-06-21 14:06:16.203573
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Request-Line
    request_line = (
        'GET /foo HTTP/1.1',
        [
            (0, 'GET', 'Name.Function'),
            (3, ' ', 'Text'),
            (4, '/foo', 'Name.Namespace'),
            (8, ' ', 'Text'),
            (9, 'HTTP', 'Keyword.Reserved'),
            (13, '/', 'Operator'),
            (14, '1.1', 'Number'),
        ]
    )
    t = SimplifiedHTTPLexer().get_tokens_unprocessed(request_line[0])
    assert list(t) == request_line[1]

    # Response Status-Line

# Generated at 2022-06-21 14:06:27.351289
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    from httpie.formatters import JSONPointer

    content = '{ "name": "Anton" }'
    mime = 'application/json'
    env = Environment(colors=0)
    f = ColorFormatter(env, color_scheme='monokai')
    body = f.format_body(content, mime)
    assert body == "\x1b[38;5;236m{\x1b[39m \x1b[38;5;37m\"name\"\x1b[39m:\x1b[39m \x1b[38;5;37m\"Anton\"\x1b[39m \x1b[38;5;236m}\x1b[39m\n"
    env.colors = 256
    env.stdout_

# Generated at 2022-06-21 14:06:38.601431
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.cli import Environment
    from httpie.output import BINARY_SUPPRESSED_NOTICE

    env = Environment(stdin=None, stdout=None, stderr=None)
    env.colors = 256
    formatter = ColorFormatter(env)


# Generated at 2022-06-21 14:06:45.533797
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.formatters.utils import get_prettifier
    prettifier = get_prettifier(indent=2, sort_keys=False)
    color_formatter = ColorFormatter({"colors": False}, False, DEFAULT_STYLE)
    json_formatter = JSONFormatter({"colors": False}, False, DEFAULT_STYLE)

    headers = color_formatter.format_headers("Content-Type: application/json")
    body = color_formatter.format_body('{"text": "Colored text"}', 'application/json')
    expected_body = prettifier(json_formatter.format_body('{"text": "Colored text"}', 'application/json'))
    assert body == expected_body

# Generated at 2022-06-21 14:06:56.722701
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer(mime='text/html', body='<html></html>')
    assert lexer is pygments.lexers.get_lexer_by_name('html')
    lexer = get_lexer(mime='text/xhtml', body='<html></html>')
    assert lexer is pygments.lexers.get_lexer_by_name('xml')
    lexer = get_lexer(mime='application/xhtml+xml', body='<html></html>')
    assert lexer is pygments.lexers.get_lexer_by_name('xml')
    lexer = get_lexer(mime='application/xml', body='<html></html>')
    assert lexer is pygments.lexers.get_lexer_by_name('xml')
    lexer

# Generated at 2022-06-21 14:07:06.964646
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    def get_lexer(mime, body='', explicit_json=False):
        return ColorFormatter(Environment(colors=None)).get_lexer_for_body(mime, body)

    assert get_lexer('application/json') is not None
    assert get_lexer('application/json+whatever') is not None
    assert get_lexer('application/x-json') is not None
    assert get_lexer('text/json') is not None
    assert get_lexer('application/json', explicit_json=True) is not None
    assert get_lexer('text/plain') is None
    assert get_lexer('text/json', explicit_json=True) is None
    assert get_lexer('application/json', '{') is not None
    assert get_lexer('text/json', '{')

# Generated at 2022-06-21 14:07:17.960182
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class TestEnv(object):
        def __init__(self):
            self.colors = 256

    env = TestEnv()
    cf = ColorFormatter(env=env)

    assert cf.get_lexer_for_body('s/s') == TextLexer
    assert cf.get_lexer_for_body('application/json') == pygments.lexers.JsonLexer
    assert cf.get_lexer_for_body('application/json', body='{}') == pygments.lexers.JsonLexer
    assert cf.get_lexer_for_body('text/plain', body='[') == TextLexer
    assert cf.get_lexer_for_body('text/plain', body='{') == TextLexer

# Generated at 2022-06-21 14:07:27.180067
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():

    from pygments.token import *
    from pygments.lexers import get_lexer_for_mimetype
    from pygments.lexers import get_lexer_by_name

    assert get_lexer_for_mimetype('text/http') is not \
        get_lexer_by_name('HTTP')

    assert get_lexer_for_mimetype('text/http') is \
        SimplifiedHTTPLexer

    assert get_lexer_by_name('HTTP') is \
        PygmentsHttpLexer

    assert get_lexer_for_mimetype('text/http') is \
        get_lexer_by_name('HTTP')

# Generated at 2022-06-21 14:07:50.306463
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class MockColorFormatter(ColorFormatter):
        def __init__(self, style):
            pass

    assert MockColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-21 14:07:56.589600
# Unit test for function get_lexer
def test_get_lexer():
    sample_body = """
{
  "a": 1,
  "b": 2
}
    """.strip()

    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', explicit_json=True, body=sample_body)
    assert get_lexer('application/javascript')
    assert get_lexer('application/javascript', body=sample_body)
    assert get_lexer('text/javascript')
    assert get_lexer('text/javascript', body=sample_body)

# Generated at 2022-06-21 14:08:05.412792
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.parsers import JsonParser
    from httpie.plugins.parsers import FormParser
    from httpie.plugins.formatters import JsonFormatter
    from httpie.plugins.formatters import FormFormatter

    # Lexer for explicit --json and with json mimetype
    assert get_lexer('application/json') == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json', explicit_json=True) == pygments.lexers.get_lexer_by_name('json')

    # Lexer for html mimetype
    assert get_lexer('text/html') == pygments.lexers.get_lexer_by_name('html')

    # Lexer for xml mimetype

# Generated at 2022-06-21 14:08:14.538696
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer("text/plain") is None

    # application/javascript
    assert get_lexer("application/javascript", body='{}')
    assert get_lexer("application/javascript", explicit_json=True, body='{}')

    # application/json
    assert get_lexer("application/json", body='{}')
    assert get_lexer("application/json", explicit_json=True, body='{}')

    # application/x-www-form-urlencoded
    assert get_lexer("application/x-www-form-urlencoded")
    assert get_lexer("application/x-www-form-urlencoded", explicit_json=True)

# Generated at 2022-06-21 14:08:23.640511
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    c = ColorFormatter(None)


# Generated at 2022-06-21 14:08:31.506100
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-21 14:08:39.546438
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    c = ColorFormatter(Environment)
    assert c.format_body(
        "<html>hello</html>",
        "text/html"
    ) == "\x1b[39;49;00m<\x1b[39;49;00mhtml\x1b[39;49;00m>\x1b[39;49;00mhello\x1b[39;49;00m</\x1b[39;49;00mhtml\x1b[39;49;00m>\x1b[39;49;00m"

# Generated at 2022-06-21 14:08:41.757389
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer_ = pygments.lexers.get_lexer_for_mimetype("HTTP")
    assert isinstance(lexer_, SimplifiedHTTPLexer)

# Generated at 2022-06-21 14:08:54.699816
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.context import Environment

    mock_args = parser.parse_args([])
    mock_args.explicit_json = False
    env = Environment(args=mock_args)

    color_formatter = ColorFormatter(env=env)

    mime = 'application/json'
    body_pretty = '{\n  "test": "json"\n}'
    body_pretty_formatted = body_pretty

    body_ugly = '{"test":"json"}'
    body_ugly_formatted = body_ugly

    assert color_formatter.format_body(body_pretty, mime) == body_pretty_formatted
    assert color_formatter.format_body(body_ugly, mime) == body_ugly

# Generated at 2022-06-21 14:09:01.355720
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    print("We are testing the constructor of class ColorFormatter")
    foo = ColorFormatter(
        env = Environment(stdout_isatty=False),
        explicit_json=False,
        color_scheme = 'auto'
    )
    foo = ColorFormatter(
        env = Environment(stdout_isatty=True, colors=256),
        explicit_json=False,
        color_scheme = 'monokai'
    )


# Generated at 2022-06-21 14:09:50.756891
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment

    env = Environment(auto_envvar_prefix='HTTPIE_JWPLAYER_API')
    # env.stdout_isatty = True
    # env.stderr_isatty = True
    # env.is_windows = False
    # env.colors = 256

    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
        style=Solarized256Style,
    )

    color_formatter = ColorFormatter(
        env= env,
        explicit_json=False,
        color_scheme=SOLARIZED_STYLE,
    )

    # Test setup
    assert isinstance(color_formatter.formatter, Terminal256Formatter)
    assert color_formatter.formatter.style == Solarized256

# Generated at 2022-06-21 14:09:51.390162
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:09:52.979489
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert isinstance(ColorFormatter({'colors': True, 'style': 'default'}), ColorFormatter)

# Generated at 2022-06-21 14:09:57.617023
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    # print()
    # print("test_SimplifiedHTTPLexer")
    # print("-----------------------")
    # print("test_SimplifiedHTTPLexer:")
    # print("In: Request-Line: http://http.org HTTP/1.1")
    # print("Out: ", http_lexer.get_tokens(
    #     "http://http.org HTTP/1.1"
    # ))
    # print("-----------------------")
    # print("test_SimplifiedHTTPLexer:")
    # print("In: Response Status-Line: HTTP/1.1 200 OK")
    # print("Out: ", http_lexer.get_tokens(
    #     "HTTP/1.1 200 OK"


# Generated at 2022-06-21 14:10:08.488506
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    try:
        # SimplifiedHTTPLexer not in this file, it is here:
        import httpie.utils
        assert httpie.utils.SimplifiedHTTPLexer
    except:
        pass

    lexer = SimplifiedHTTPLexer()
    # https://pygments.org/docs/tokens/#name.attribute
    toks = lexer.get_tokens_unprocessed(b"HTTP/1.1 200 ok\n")
    # print(toks)
    # https://pygments.org/api/pygments.lexer.html#pygments.lexer.RegexLexer
    t0 = list(toks)[-2]
    tok = t0[0]
    assert tok is pygments.token.Name.Attribute
    text = t0[1]


# Generated at 2022-06-21 14:10:11.581680
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(
        Environment(colors=256),
        color_scheme='fruity'
    )
    assert color_formatter.get_style_class(
        color_scheme='fruity'
    ) == pygments.styles.get_style_by_name('fruity')

# Generated at 2022-06-21 14:10:21.078533
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # When a body is empty, it is never lexed
    assert not ColorFormatter.get_lexer_for_body(
        mime='application/json',
        body='',
    )

    # When the HTTPie environment is not in a terminal, no lexer is used
    class FakeEnv:
        def __init__(self, tty): self.is_terminal = tty

    assert not ColorFormatter.get_lexer_for_body(
        mime='application/json',
        body='{"foo": "bar"}',
    )

    # When the MIME is not recognized, json is used if the body is valid

# Generated at 2022-06-21 14:10:30.737949
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    input_text = '''\
GET / HTTP/1.1
Host: example.com
Accept: text/plain

HTTP/1.1 200 OK
Content-Type: text/plain
Content-Length: 3

Hi
'''
    # Catch only the tokens that are interesting to us.

# Generated at 2022-06-21 14:10:37.157220
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter.__module__.startswith("httpie.output.formatters.")
    assert ColorFormatter.__name__ == "ColorFormatter"
    assert ColorFormatter.__doc__.startswith("Colorize using Pygments")
    assert ColorFormatter.group_name == "colors"
    assert not ColorFormatter.enabled
    assert ColorFormatter.explicit_json == False
    assert ColorFormatter.color_scheme == DEFAULT_STYLE
    assert not ColorFormatter.formatter
    assert not ColorFormatter.http_lexer
    #ClassNotFound raised
    assert ColorFormatter.get_style_class("auto") == Solarized256Style
    assert ColorFormatter.get_style_class("solarized") == Solarized256Style

# Generated at 2022-06-21 14:10:38.764255
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s256 = Solarized256Style()  # noqa
    assert s256

# Generated at 2022-06-21 14:12:12.451497
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class FakeEnvironment:
        colors = True

    env = FakeEnvironment()

    color_formatter = ColorFormatter(env)
    assert color_formatter.group_name == 'colors'
    assert color_formatter.formatter is not None

# Generated at 2022-06-21 14:12:16.367480
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(Environment())
    assert color_formatter.formatter
    assert color_formatter.http_lexer
    assert color_formatter.explicit_json




# Generated at 2022-06-21 14:12:24.275721
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    env.colors = False
    formatter = ColorFormatter(env, False, 'solarized')
    headers = """POST /post HTTP/1.1
Host: httpbin.org
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 27
Content-Type: application/x-www-form-urlencoded

foo=bar&abc=xyz&abc=123"""
    headers = formatter.format_headers(headers)
    assert 'HTTP/1.1' in headers
    assert 'foo=bar' in headers
    assert 'abc=xyz' in headers
    assert 'abc=123' in headers
    assert 'Content-Type' in headers
    assert 'Content-Length' in headers

# Generated at 2022-06-21 14:12:30.472643
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.context import Environment
    from httpie.output import get_formatter
    from httpie.plugins import FormatterPlugin

    # We'll need a formatter to test this method. Create one with default
    # settings.
    argv = ['--headers']
    env = Environment(argv)
    formatter = get_formatter(env=env)
    # Make sure we have an instance of ColorFormatter.
    assert isinstance(formatter, ColorFormatter)

    # The MIME type and body of the response to test.
    mime_type = 'application/json'

# Generated at 2022-06-21 14:12:39.174465
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment(colors=False)
    colorFormatter = ColorFormatter(env=env)
    assert colorFormatter.enabled == False

    env = Environment(colors=True)
    colorFormatter = ColorFormatter(env=env)
    assert colorFormatter.enabled == True

    env = Environment(colors=256)
    colorFormatter = ColorFormatter(env=env, color_scheme='solarized')
    assert isinstance(colorFormatter.formatter, Terminal256Formatter)
    assert colorFormatter.formatter.style == Solarized256Style

    colorFormatter = ColorFormatter(env=env, color_scheme='monokai')
    assert isinstance(colorFormatter.formatter, Terminal256Formatter)

# Generated at 2022-06-21 14:12:45.563845
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Tests that the values are correct after initialization
    env = Environment()
    explicit_json = False
    color_scheme = "fruity"
    formatter = ColorFormatter(
        env=env,
        explicit_json=False,
        color_scheme=color_scheme,
    )
    assert formatter.explicit_json == explicit_json
    assert formatter.formatter.style == pygments.styles.get_style_by_name(color_scheme)
    assert hasattr(formatter.http_lexer, 'tokens')
    assert hasattr(formatter.http_lexer, 'start')
    assert hasattr(formatter.http_lexer, 'end')


# Generated at 2022-06-21 14:12:51.254099
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    assert ColorFormatter.format_headers(ColorFormatter, "Content-Type: text/html\nCache-Control: no-cache") == "\x1b[38;05;34mContent-Type\x1b[39;00m\x1b[38;05;245m: \x1b[39;00m\x1b[38;05;31mtext/html\x1b[39;00m\n\x1b[38;05;34mCache-Control\x1b[39;00m\x1b[38;05;245m: \x1b[39;00m\x1b[38;05;31mno-cache\x1b[39;00m"

# Generated at 2022-06-21 14:12:51.741637
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    pass

# Generated at 2022-06-21 14:13:01.798896
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    import jsonschema
    from httpie.plugins import FormatterPlugin
    from httpie.compat import urljoin
    json_path = "tests/test_ColorFormatter_format_body.json"
    with open(json_path, 'r') as json_file:
        test_data = json.load(json_file)
    schema_path = "tests/test_ColorFormatter_format_body.schema.json"
    with open(schema_path, 'r') as schema_file:
        schema = json.load(schema_file)
        jsonschema.validate(test_data, schema)
        for url in test_data:
            kwargs = test_data[url]['kwargs']
            for test in test_data[url]['tests']:
                formatter