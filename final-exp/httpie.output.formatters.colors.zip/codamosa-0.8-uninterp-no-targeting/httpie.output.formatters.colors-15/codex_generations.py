

# Generated at 2022-06-21 14:03:09.433934
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter()
    assert not formatter.explicit_json
    assert formatter.formatter is not None
    assert formatter.http_lexer is not None

# Generated at 2022-06-21 14:03:16.770686
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from datetime import datetime
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    env = Environment(colors=256)
    test_string = "string"
    expected = b'\x1b[38;5;7m' + test_string.encode() + b'\x1b[39m'
    formatter = FormatterPlugin(env=env)
    result = formatter.format_body(test_string, 'text/plain')
    assert result == expected

# Generated at 2022-06-21 14:03:20.456730
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # isinstance(SimplifiedHTTPLexer(), pygments.lexer.RegexLexer)
    assert len([x for x in SimplifiedHTTPLexer.tokens.keys() if x == 'root']) == 1



# Generated at 2022-06-21 14:03:25.761475
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer('text/html'), pygments.lexers.HtmlLexer)
    assert isinstance(get_lexer('text/javascript'), pygments.lexers.JavascriptLexer)
    assert isinstance(get_lexer('application/json'), pygments.lexers.JsonLexer)
    assert get_lexer('text/plain') is None

# Generated at 2022-06-21 14:03:33.858649
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers = (
        'GET / HTTP/1.1\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Host: httpbin.org\r\n'
        'Accept: */*\r\n'
        'User-Agent: HTTPie/0.9.9\r\n'
        'Connection: keep-alive\r\n\r\n'
        'some body'
    )
    assert ColorFormatter().format_headers(headers) == '\x1b[90m' \
        'GET / HTTP/1.1\r\n' \
        'Accept-Encoding: gzip, deflate\r\n' \
        'Host: httpbin.org\r\n' \
        'Accept: */*\r\n' \
       

# Generated at 2022-06-21 14:03:45.055910
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import sys
    import io
    import json

    # Save stdout
    old_stdout = sys.stdout
    sys.stderr.write(old_stdout.encoding)
    sys.stderr.flush()
    # Create a new stdout and redirect it to stdout
    f = io.StringIO()
    sys.stdout = f

    # Test the method
    ColorFormatter.format_body(b'Zm9vCg==\r\n', 'text/plain')

    # Restore stdout
    sys.stdout = old_stdout
    # Get output from f
    output = f.getvalue()

    # Parse the output using json
    test = json.loads(output)

    # Test

# Generated at 2022-06-21 14:03:48.016462
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter(env=Environment(),
                        explicit_json=False,
                        color_scheme='xterm')
    assert cf.formatter == TerminalFormatter
    assert isinstance(cf.http_lexer, PygmentsHttpLexer)

# Generated at 2022-06-21 14:03:57.841628
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-21 14:04:01.519027
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert (
        list(SimplifiedHTTPLexer().get_tokens_unprocessed(
            'json: "string"'
        )) == [
            (pygments.token.Name.Attribute, 'json'),
            (pygments.token.Text, ': '),
            (pygments.token.String, '"string"')
        ]
    )

# Generated at 2022-06-21 14:04:13.934507
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import PluginManager

    body_text_html = """<html><body><h1>Hello World!</h1></body></html>"""
    body_text_plain = "Hello World!"
    body_application_json = '{"hello": "world"}'
    body_application_javascript = '{"hello": "world"}'
    body_application_xml = '<hello>world</hello>'
    body_application_zip = '<hello>world</hello>'

    # init ColorFormatter
    plugin = PluginManager().get('colors')[0]
    assert isinstance(plugin, ColorFormatter)

    # format html
    lexer = plugin.get_lexer_for_body(mime='text/html', body=body_text_html)
    assert lexer == pygments.lexers.H

# Generated at 2022-06-21 14:04:28.865571
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    code = '\n'.join([
        'GET / HTTP/1.1',
        'Host: httpie.org',
        'Connection: keep-alive',
        'Accept: */*',
        'User-Agent: HTTPie/0.7.2',
    ])

# Generated at 2022-06-21 14:04:34.058591
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import manager
    manager.load_internal_plugins()
    cf = manager.instantiate(ColorFormatter)
    body = """
    {
     "item": {
      "name": "Arthur",
      "family_name": "Dent"
     }
    }
    """
    body = cf.format_body(body, "application/json")
    assert body

# Generated at 2022-06-21 14:04:35.622744
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style
    assert(type(style) == type)

# Generated at 2022-06-21 14:04:44.525049
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    from httpie.output.streams import DEFAULT_RAW_STREAM

    env = Environment(
        color=True,
        colors=256,
        stdin=DEFAULT_RAW_STREAM,
        stdin_isatty=True,
        stdout=DEFAULT_RAW_STREAM,
        stdout_isatty=True,
        style=None,
    )

    color_formatter = ColorFormatter(env=env,
                                     explicit_json=False,
                                     color_scheme='solarized')

    assert color_formatter.group_name == 'colors'
    assert color_formatter.formatter != None
    assert color_formatter.http_lexer != None

# Generated at 2022-06-21 14:04:48.515760
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    e = Environment(colors=True)
    color = ColorFormatter(env=e, output_file=None, explicit_json=False, color_scheme=DEFAULT_STYLE, priority=50)
    assert type(color) == ColorFormatter

# Generated at 2022-06-21 14:04:49.647448
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    theClass = ColorFormatter.get_style_class("solarized")
    assert theClass == Solarized256Style

# Generated at 2022-06-21 14:04:50.722631
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()

# Generated at 2022-06-21 14:04:53.194542
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Test constructor of class ColorFormatter
    env = Environment(colors=True)
    formatter = ColorFormatter(env)

# Generated at 2022-06-21 14:04:57.313621
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from terminal import Terminal
    env = Environment(colors=Terminal.NUM_COLORS)

    color_formatter = ColorFormatter(env, color_scheme='auto')
    assert color_formatter.get_style_class('auto') == Solarized256Style



# Generated at 2022-06-21 14:05:09.651113
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # File mimetype
    assert(ColorFormatter.get_lexer_for_body(
        mime="application/octet-stream",
        body=""
    ) == pygments.lexers.get_lexer_by_name('text'))

    # JSON mimetype
    assert(ColorFormatter.get_lexer_for_body(
        mime="application/json",
        body="{}"
    ) == pygments.lexers.get_lexer_by_name('json'))
    assert(ColorFormatter.get_lexer_for_body(
        mime="application/json",
        body=""
    ) == pygments.lexers.get_lexer_by_name('json'))

# Generated at 2022-06-21 14:05:22.459957
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(None, None)
    data = """HTTP/1.1 200 OK
Connection: keep-alive
Content-Encoding: gzip
Content-Type: text/html; charset=utf-8
Date: Sat, 20 Aug 2016 03:18:25 GMT
Transfer-Encoding: chunked
X-Powered-By: Express
"""
    res = formatter.format_headers(data)
    print(res)

# Generated at 2022-06-21 14:05:34.245067
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.colors import ColorFormatter
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import UnsupportedStream

    env = Environment()

    httpie_json = {
        'url': 'https://jsonplaceholder.typicode.com/posts/1',
        'headers': {'accept': 'application/json'},
        'json': {'foo': 'bar'},
        'auth': ('user', 'password')
    }

    formatter = ColorFormatter(env, stream=UnsupportedStream(),
                               explicit_json=False)
    print(httpie_json['headers']['accept'])

# Generated at 2022-06-21 14:05:38.077509
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(
        env=Environment(
            colors=256,
        ),
        color_scheme='solarized',
    )

    result = isinstance(color_formatter.formatter, Terminal256Formatter)
    assert result == True

# Generated at 2022-06-21 14:05:45.071099
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    def _test(data, expected):
        actual = ColorFormatter(None, None).format_headers(data)
        assert actual == expected

    _test(
        """\
HTTP/1.1 200 OK
Host: example.com
Content-Length: 4

""",
        """\
HTTP/1.1 200 OK
Host: example.com
Content-Length: 4

"""
    )

    _test(
        """\
GET /foo HTTP/1.1
Host: example.com
Content-Length: 4

""",
        """\
GET /foo HTTP/1.1
Host: example.com
Content-Length: 4

"""
    )

# Generated at 2022-06-21 14:05:48.827025
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style
    assert ColorFormatter.get_style_class('Solarized256') == Solarized256Style

# Generated at 2022-06-21 14:05:52.356462
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-21 14:05:56.576535
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    klass = Solarized256Style
    assert klass.background_color == "#1c1c1c"
    assert klass.styles[pygments.token.Keyword] == "#5f8700"

# Generated at 2022-06-21 14:05:58.221245
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter("nothing")
    assert formatter.enabled == False



# Generated at 2022-06-21 14:06:07.306711
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer().name == 'HTTP'
    assert SimplifiedHTTPLexer().aliases == ['http']
    assert SimplifiedHTTPLexer().filenames == ['*.http']

# Generated at 2022-06-21 14:06:15.356201
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment(colors=256)
    body = '{foo: "bar"}'
    cases = [
        {'mime': 'application/json', 'result': 'json'},
        {'mime': 'application/jso', 'result': None},
        {'mime': 'application/json+', 'result': None},
        {'mime': 'application/json+foo', 'result': 'json'},
        {'mime': 'application/foo+json', 'result': 'json'},
        {'mime': 'application/foo+bar', 'result': None},
    ]
    for case in cases:
        result = ColorFormatter(env).get_lexer_for_body(case['mime'], body)
        if case['result']:
            assert result.name == case['result']

# Generated at 2022-06-21 14:06:36.880941
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    """
    Test the ColorFormatter.get_lexer_for_body method.
    """
    fn = ColorFormatter.get_lexer_for_body
    # Defaults
    assert fn('', '', '') is None
    assert fn('text/plain', '', '') is None
    # JSON type
    assert fn('application/json', '{}', '') is pygments.lexers.get_lexer_by_name('json')
    # Unknown
    assert fn('application/unknown', '', '') is None

# Generated at 2022-06-21 14:06:44.729311
# Unit test for function get_lexer
def test_get_lexer():
    from pygments.lexers.data import JavascriptLexer

    # JSON
    assert get_lexer('application/json')
    assert get_lexer('application/json;charset=UTF-8')
    assert get_lexer('application/json-patch+json')
    assert get_lexer('application/ld+json')
    assert get_lexer('application/schema+json')
    assert get_lexer('application/vnd.api+json')
    assert get_lexer('application/vnd.geo+json')
    assert get_lexer('application/vnd.github.v3+json')
    assert get_lexer('application/vnd.google-earth.kml+json')
    assert get_lexer('application/vnd.google-earth.kmz+json')
    assert get_lex

# Generated at 2022-06-21 14:06:48.789282
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer(mime='application/json', explicit_json=True)
    assert lexer is not None
    assert isinstance(lexer, pygments.lexer.RegexLexer)



# Generated at 2022-06-21 14:06:50.281704
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment(colors=256), 'solarized')

# Generated at 2022-06-21 14:06:59.640597
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pygments.formatters.terminal
    from pygments.lexer import RegexLexer, bygroups, include, using
    from pygments.lexers import ElementTreeLexer
    from pygments.token import Punctuation, Text

    class ElementTreePlaintextLexer(RegexLexer):
        name = 'ElementTree'
        aliases = ['etree']
        filenames = ['*.et']


# Generated at 2022-06-21 14:07:07.669351
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin

    class TestColorFormatter(FormatterPlugin):

        def format_body(self, body, mime='text/plain'):
            return super().format_body(body, mime)

    test_color_formatter = TestColorFormatter()
    # test 1
    assert test_color_formatter.format_body('{"key":1}','application/json') is not None
    # test 2
    assert test_color_formatter.format_body('{"key":1}','text/html') is None

# Generated at 2022-06-21 14:07:16.053854
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def test_lexer(formatter: ColorFormatter, typed_data, expected_lexer):
        body, mime = typed_data
        lexer = formatter.get_lexer_for_body(mime, body)
        assert lexer == expected_lexer

    formatter = ColorFormatter(
        env=None,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    test_lexer(
        formatter,
        (
            '{ "key": "value" }',
            'application/json',
        ),
        pygments.lexers.get_lexer_by_name('json')
    )

# Generated at 2022-06-21 14:07:25.672159
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.core import Environment
    env = Environment()
    env.colors = 256
    env.color_scheme = "solarized256"
    formatter = ColorFormatter(env)
    headers = """Host: 127.0.0.1:5000
User-Agent: user-agent
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive
-cookie: a=b
-cookie: c=d
-cookie: e=f
-cookie: g=h
"""

# Generated at 2022-06-21 14:07:37.440634
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    print("test_ColorFormatter_format_body")
    class TestColorFormatter(ColorFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.formatter = self.get_style_class('monokai')
            self.http_lexer = self.get_lexer_for_body('text/html')
    test_string = "<repeat attr=\"value\">hello</repeat><repeat>world</repeat>"

# Generated at 2022-06-21 14:07:49.408554
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    content = 'DELETE https://example.com/ HTTP/1.1\r\n'\
              'Host: example.com\r\n'\
              'Accept: */*\r\n'
    tokens = lexer.get_tokens(content)

# Generated at 2022-06-21 14:08:19.118553
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class mock_pygments_highlight:
        def __init__(self, code, lexer, formatter):
            pass

        def __call__(self):
            return "highlighted"
    import mock
    import pygments.lexers.text
    with mock.patch('pygments.highlight', mock_pygments_highlight):
        with mock.patch('pygments.lexers.text.UrlLexer') as mock_UrlLexer:
            mock_UrlLexer.return_value.__call__.return_value = "lexed"
            cf = ColorFormatter(Environment(colors=256))
            result = cf.format_body("body", "mime")
            assert result == "highlighted"



# Generated at 2022-06-21 14:08:22.957901
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_fmt = ColorFormatter(Environment(colors=True, color_scheme=DEFAULT_STYLE))
    assert color_fmt.format_body('\000', 'application/json') == '\000'


# Generated at 2022-06-21 14:08:31.103908
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # arrange
    env = Environment(colors=256, stdin=None, stdout=None, stderr=None)
    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=SOLARIZED_STYLE, **{})

    # act
    result = color_formatter.format_headers("HTTP/1.1 200 OK\nContent-Type: application/json\n") # Http 200
    # arrange

# Generated at 2022-06-21 14:08:37.772440
# Unit test for function get_lexer
def test_get_lexer():
    env = Environment(
        colors=True,
        colormode='256',
        style='auto',
    )
    formatter = ColorFormatter(env)

    def check(mime, body, expected_lexer):
        assert formatter.get_lexer_for_body(mime, body) == expected_lexer

    check(
        'application/json',
        '{}',
        pygments.lexers.get_lexer_by_name('json'),
    )

# Generated at 2022-06-21 14:08:42.620878
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert hasattr(style, 'background_color')
    assert hasattr(style, 'styles')
    assert hasattr(style.styles, '__iter__')
    for attribute in dir(style.styles):
        if not attribute.startswith('_'):
            assert hasattr(style.styles[getattr(pygments.token, attribute)], '__iter__')

# Generated at 2022-06-21 14:08:46.141557
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Initialisation test
    formatter = ColorFormatter(Environment(colors=True), False, 'auto')
    assert formatter.explicit_json == False
    assert formatter.http_lexer.name == 'HTTP'

# Generated at 2022-06-21 14:08:50.346162
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    color = Solarized256Style().styles
    assert color[pygments.token.String] == '#00afaf'
    assert color[pygments.token.Generic.Heading] == '#d75f00'

# Generated at 2022-06-21 14:08:53.752435
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from unittest.mock import Mock
    c = ColorFormatter(env = Mock(colors=True), mime = "application/json", body = '{"foo": "bar"}')
    lexer = c.get_lexer_for_body("application/json", body = '{"foo": "bar"}')

    assert lexer

# Generated at 2022-06-21 14:08:59.742605
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    if is_windows:
        import colorama
        colorama.init()
    else:
        import termcolor
    env = Environment()
    env.colors = 256
    env.color_scheme = 'solarized'
    color_formatter = ColorFormatter(env)
    headers = '''GET / HTTP/1.1
    User-Agent: curl/7.58.0
    Host: www.baidu.com
    Accept: */*
    '''
    print(color_formatter.format_headers(headers))



# Generated at 2022-06-21 14:09:00.364845
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-21 14:09:24.095592
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.context import Environment
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    from requests.structures import CaseInsensitiveDict
    assert formatter.format_headers(CaseInsensitiveDict({"id": "abc", "name": "杭柯"})) == "\x1b[38;5;33mID\x1b[39m: \x1b[38;5;72mabc\x1b[39m\r\n\x1b[38;5;33mName\x1b[39m: \x1b[38;5;72m杭柯\x1b[39m"

# Generated at 2022-06-21 14:09:28.612494
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from . import core

    env = core.Environment()
    color_formatter = ColorFormatter(env)

    assert color_formatter.explicit_json == False

    assert color_formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert color_formatter.formatter.style.__class__.__name__ == 'DefaultStyle'

    assert color_formatter.http_lexer.__class__.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-21 14:09:29.536736
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    pass

# Generated at 2022-06-21 14:09:39.683734
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import unittest
    import sys
    class ColorFormatterTestCase(unittest.TestCase):
        def test_format_headers(self):
            import httpie
            formatters = httpie.plugins.manager.get_formatters()
            for _, formatter in formatters.items():
                if isinstance(formatter, ColorFormatter):
                    headers = """\
Accept: application/json
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length: 0
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.2
"""
                    # output = formatter.format_headers(headers)
                    # print(output, file=sys.stderr)

# Generated at 2022-06-21 14:09:41.208540
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert SimplifiedHTTPLexer(mimetypes=['text/http']).name == 'HTTP'

# Generated at 2022-06-21 14:09:49.205322
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    env.colors = True
    env.color_scheme = 'solarized256'
    color_formatter = ColorFormatter(env)


# Generated at 2022-06-21 14:09:51.630034
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    env.color_scheme = 'default'
    formatter = ColorFormatter(env)

# Generated at 2022-06-21 14:10:01.729585
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment()
    env.colors = 256
    color_formatter = ColorFormatter(env, color_scheme=AUTO_STYLE)
    # A line of HTTP headers

# Generated at 2022-06-21 14:10:04.909590
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()
    assert s.__class__.__name__ == 'Solarized256Style'

__all__ = (
    'ColorFormatter',
    'Solarized256Style',
)

# Generated at 2022-06-21 14:10:06.859978
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')

# Generated at 2022-06-21 14:10:53.192243
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import is_windows

    class ColorFormatter(object):
        """
        Colorize using Pygments

        This processor that applies syntax highlighting to the headers,
        and also to the body if its content type is recognized.

        """
        group_name = 'colors'

        def __init__(
            self,
            env=None,
            explicit_json=False,
            color_scheme=DEFAULT_STYLE,
            **kwargs
        ):
            super().__init__(**kwargs)

            if not env:
                self.enabled = False
                return

            use_auto_style = color_scheme == AUTO_STYLE
            has_256_colors = env.colors == 256
            if use_auto_style or not has_256_colors:
                http_

# Generated at 2022-06-21 14:10:57.144592
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    if is_windows:
        assert ColorFormatter.get_style_class('auto') is pygments.styles.get_style_by_name('fruity')
    else:
        assert ColorFormatter.get_style_class('auto') is pygments.styles.get_style_by_name('monokai')
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style

# Generated at 2022-06-21 14:11:08.023238
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(style=Solarized256Style)
    test_sample = """GET / HTTP/1.1
Host: 127.0.0.1:8080
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Connection: keep-alive
Upgrade-Insecure-Requests: 1
Cache-Control: max-age=0"""

# Generated at 2022-06-21 14:11:16.245920
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from io import StringIO

    buf = StringIO()
    e = Environment(colors=True, stdout=buf)
    x = ColorFormatter(e)

    expected = '\x1b[1m\x1b[33mGET\x1b[0m \x1b[1m\x1b[34m/tests/dict/\x1b[0m \x1b[1m\x1b[32mHTTP/1.1\x1b[0m'
    actual = x.format_headers('GET /tests/dict/ HTTP/1.1')
    assert actual == expected, actual


# Generated at 2022-06-21 14:11:27.801403
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.client import JSONClient
    from httpie.plugins import FormatterPlugin
    from httpie.cli import base
    from httpie.output import get_preferred_encoding
    http = JSONClient()
    args = base.parser().parse_args(["http://127.0.0.1:8080/foo"])
    args.style = ['solarized']
    output_options = http.get_options(args)
    style_plugin = FormatterPlugin.get_plugin_from_env(args.style, output_options)
    headers = '''HTTP/1.1 200 OK
Content-Length: 15
Content-Type: application/json
Date: Wed, 16 Aug 2017 13:20:03 GMT
Server: TornadoServer/4.3

'''

# Generated at 2022-06-21 14:11:37.085219
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    """
    Request-Line:
    GET http://www.google.com/ HTTP/1.1

    Response Status-Line:
    HTTP/1.1 200 OK

    HTTP headers:
    Content-Type: application/json
    Content-Length: 27
    """

# Generated at 2022-06-21 14:11:40.422800
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class FakeEnv:
        def __init__(self):
            self.colors = True

    env = FakeEnv()
    cf = ColorFormatter(env)
    assert(cf.get_style_class('solarized') == Solarized256Style)

# Generated at 2022-06-21 14:11:48.644553
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():

    # When style is set to invalid string, then default style should be returned
    assert ColorFormatter.get_style_class(color_scheme='not-valid-color-schema') == pygments.styles.get_style_by_name(DEFAULT_STYLE)

    # When style is set to valid string, then specified style should be returned
    assert ColorFormatter.get_style_class(color_scheme='solarized') == Solarized256Style

    # When style is set to 'auto', then default style should be returned
    assert ColorFormatter.get_style_class(color_scheme='auto') == pygments.styles.get_style_by_name(DEFAULT_STYLE)

# Generated at 2022-06-21 14:11:59.640208
# Unit test for function get_lexer
def test_get_lexer():
    # pylint: disable=W0612
    class TestLexer1(pygments.lexer.RegexLexer):
        name = 'TEST1'
        tokens = {}

    class TestLexer2(pygments.lexer.RegexLexer):
        name = 'TEST2'
        tokens = {}

    class TestLexer3(pygments.lexer.RegexLexer):
        name = 'TEST3'
        tokens = {}

    class TestLexer4(pygments.lexer.RegexLexer):
        name = 'TEST4'
        tokens = {}

    assert get_lexer('unknown/unknown') is None
    assert get_lexer('test1/test1') is TestLexer1
    assert get_lexer('test2/test2') is TestLexer2
    assert get

# Generated at 2022-06-21 14:12:07.457451
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    text = '''GET http://httpbin.org/ HTTP/1.1
Content-Type: application/json'''
    tokens = lexer.get_tokens(text)
    token_types = [x[0] for x in tokens]
    # A REALLY REALLY REALLY LONG line for PyCharm's code formatter