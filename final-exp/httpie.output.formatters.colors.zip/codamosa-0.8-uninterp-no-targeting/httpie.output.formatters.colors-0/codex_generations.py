

# Generated at 2022-06-21 14:03:24.598632
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # input: GET /url HTTP/1.1
    # output: token.Keyword.Reserved, token.Operator,
    #         token.Name.Namespace, token.Number
    assert next(SimplifiedHTTPLexer().get_tokens_unprocessed('GET /url HTTP/1.1')
                )[1] == (pygments.token.Keyword.Reserved, '/',
                          pygments.token.Name.Namespace, ' ',
                          pygments.token.Keyword.Reserved, '/',
                          pygments.token.Number)

    # input: HTTP/1.1 200 OK
    # output: token.Keyword.Reserved, token.Operator,
    #         token.Number, token.Text, token.Number,
    #         token.Text, token.Name.Exception


# Generated at 2022-06-21 14:03:30.801317
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    req = {
        "args": {},
        "body": "",
        "headers": {},
    }
    response = {
        "status_code": 200,
        "headers": {},
        "content": {
            "text": "{\n  \"name\": \"jake\",\n  \"age\": 32\n}",
            "type": "application/json"
        }
    }

    print(ColorFormatter(Environment()).format_body(response["content"]["text"], response["content"]["type"]))

# Generated at 2022-06-21 14:03:32.698481
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(None)
    style_class = color_formatter.get_style_class('solarized')
    assert style_class == Solarized256Style

# Generated at 2022-06-21 14:03:37.562316
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    """
    Method get_style_class of class ColorFormatter should return the
    expected Style class object.
    """
    from httpie.plugins import FormatterPlugin

    plugin = FormatterPlugin(None)
    style_class = ColorFormatter.get_style_class('solarized')
    assert style_class.__name__ == 'Solarized256Style'

# Generated at 2022-06-21 14:03:44.264813
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class TestAutoStyle(pygments.style.Style):
        """Test style for ColorFormatter.get_style_class"""
        ...
    expected_result = TestAutoStyle
    test_env = Environment()
    test_env.colors = None
    test_formatter = ColorFormatter(test_env, explicit_json=False, color_scheme="auto")
    result = test_formatter.get_style_class("auto")
    assert result == expected_result

# Generated at 2022-06-21 14:03:46.140844
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # type: () -> None
    import httpie.colors
    httpie.colors.SimplifiedHTTPLexer('foo')

# Generated at 2022-06-21 14:03:48.141569
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # given
    ColorFormatter.get_style_class(SOLARIZED_STYLE).__name__ == 'Solarized256Style'

# Generated at 2022-06-21 14:03:57.969245
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def assert_lexer(mime, body, expected):
        class Env:
            pass

        env = Env()
        env.colors = True
        formatter = ColorFormatter(env, color_scheme=SOLARIZED_STYLE)
        lexer_class = formatter.get_lexer_for_body(mime=mime, body=body)
        assert lexer_class and lexer_class._name_ == expected

    assert_lexer('text/html', '<html>', 'html')
    assert_lexer('application/json', '{}', 'json')
    assert_lexer('application/json', '<head>', '')
    expected = 'javascript (js)' if is_windows else 'javascript'

# Generated at 2022-06-21 14:04:09.715072
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import os
    import re
    from httpie.context import Environment

    class EnvironmentStub(Environment):

        def __init__(self):
            self.is_windows = is_windows
            self.stdin = None
            self.stdin_isatty = False
            self.stdout = None
            self.stdout_isatty = True
            self.colors = 256
            self.color_scheme = 'auto'
            self.default_options = []
            self.config_dir = os.path.join(os.path.dirname(__file__), 'test', 'httpie')

# Generated at 2022-06-21 14:04:21.005271
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class MockEnvironment:
        colors = True

    class MockBody:
        def __init__(self, mime):
            self.mime = mime

    class MockRequest:
        def __init__(self, method: str, path: str, headers: dict, body: MockBody):
            self.method = method
            self.scheme = 'http'
            self.host = 'httpbin.org'
            self.path = path
            self.headers = headers
            self.body = body

    class MockResponse:
        def __init__(self, status_code: int, headers: dict, body: str):
            self.status_code = status_code
            self.headers = headers
            self.body = body


# Generated at 2022-06-21 14:04:34.799083
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from pygments.lexers.html import HtmlLexer
    from httpie.main import main
    from httpie.core import program
    from httpie.context import Environment, ExitStatus

    import io
    from unittest.mock import Mock

    from httpie._compat import isatty


    # Test that out_write(), out_flush(), and out_isatty() methods
    # of ConsoleWriter are called once by ColorFormatter.format_headers()
    # with a request

    # Create a Mock object to wrap httpie.main.program
    mock_program = Mock()

    # Attach the mock to httpie.main.program
    program.program = mock_program

    # Create a fake stdout to store output of httpie.main.program
    stdout = io.StringIO()

    # Set the value of the

# Generated at 2022-06-21 14:04:39.213010
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    # simple existent style
    assert ColorFormatter.get_style_class('monokai')

    # non existent style
    assert ColorFormatter.get_style_class('foo') is None

    # solarized style
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style



# Generated at 2022-06-21 14:04:47.556693
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def assert_lexer(code, assert_mime, assert_str):
        mime = pygments.lexers.get_lexer_for_mimetype(assert_mime)
        #  print(mime)
        if r'.*' in mime.aliases[0]:
            #  print("yes")
            assert isinstance(code, TextLexer)
        else:
            assert mime.name == assert_str
    my_lexer = ColorFormatter(None, None, None)
    body = "{\nasdasjdjd:\"a\"\n}"
    mime = "application/json"
    assert_lexer(my_lexer.get_lexer_for_body(mime, body), mime, "Json")
    body = "asdasdasdasda"

# Generated at 2022-06-21 14:04:59.710730
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.output.streams import ByteStream
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment(colors=256, stdin=ByteStream())
    cf = ColorFormatter(
        env=env,
        explicit_json=True,
        color_scheme='solarized'
    )
    str_headers = 'HTTP/1.1 200 OK\nContent-Type: application/json\n'
    formatting_headers = cf.format_headers(str_headers)

# Generated at 2022-06-21 14:05:11.775895
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    BASE03 = "#1c1c1c"
    BASE02 = "#262626"
    BASE01 = "#4e4e4e"
    BASE00 = "#585858"
    BASE0 = "#808080"
    BASE1 = "#8a8a8a"
    BASE2 = "#d7d7af"
    BASE3 = "#ffffd7"
    YELLOW = "#af8700"
    ORANGE = "#d75f00"
    RED = "#af0000"
    MAGENTA = "#af005f"
    VIOLET = "#5f5faf"
    BLUE = "#0087ff"
    CYAN = "#00afaf"
    GREEN = "#5f8700"

    assert Solarized256Style.background_color == BASE03

# Generated at 2022-06-21 14:05:20.860502
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin.colors import ColorFormatter
    import pygments.lexers.data
    import pygments.lexers.markup
    lexer_list = [
        pygments.lexers.data.JsonLexer,
        pygments.lexers.data.XmlLexer,
        pygments.lexers.markup.HtmlLexer,
        pygments.lexers.markup.XmlLexer
    ]
    c = ColorFormatter(env=None, color_scheme='monokai', explicit_json=False)

    json_data = """{
        "nums": [1, 2, 3],
        "strs": ["one", "two", "three"]
    }"""

# Generated at 2022-06-21 14:05:33.024721
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class mock_lexer:
        name = 'MOCK'

    class mock_env(Environment):
        def __init__(self, colors):
            self.colors = colors

    lexer = mock_lexer()
    env = mock_env(256)
    cf = ColorFormatter(env)
    cf.formatter.formatter.__class__.name = 'Terminal256Formatter'
    cf.http_lexer.name = 'SimplifiedHTTPLexer'

    body = '{"hello": "world"}'
    assert body == cf.format_body(body, 'application/json')

    body = '<html><head><title>Title</title></head><body>Hello World</body></html>'
    assert body == cf.format_body(body, 'text/html')

    cf.formatter

# Generated at 2022-06-21 14:05:41.799863
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Arrange
    headers = '''GET / HTTP/1.1\r\nHost: example.org\r\nUser-Agent: httpie/0.5'''
    formatter = ColorFormatter(None, None)
    expected = '\x1b[33mGET / HTTP/1.1\r\nHost\x1b[39;49;00m: \x1b[36mexample.org\r\nUser-Agent\x1b[39;49;00m: \x1b[33mhttpie/0.5\x1b[39;49;00m'
    # Act
    actual = formatter.format_headers(headers)
    # Assert
    assert expected == actual

# Generated at 2022-06-21 14:05:46.624005
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    http_lexer = SimplifiedHTTPLexer()
    formatter = TerminalFormatter()
    ColorFormatter.format_headers(headers = 'GET /api/users HTTP/1.1\r\nAccept: application/json\r\nAccept-Encoding: gzip, deflate, br\r\nConnection: keep-alive\r\nHost: reqres.in\r\nUser-Agent: HTTPie/2.0.0\r\n\r\n', http_lexer = http_lexer, formatter = formatter)

# Generated at 2022-06-21 14:05:58.228028
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import str
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import StdoutOutput


# Generated at 2022-06-21 14:06:17.418286
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert get_lexer(mime='application/json') is not None
    assert get_lexer(mime='application/json', explicit_json=True) is not None
    assert get_lexer(mime='text/plain') is None
    assert get_lexer(mime='text/plain', explicit_json=True) is not None
    assert get_lexer(mime='text/html') is not None
    assert get_lexer(mime='text/html', explicit_json=True) is not None
    assert get_lexer(mime='application/json', body='{"key": "value"}') is not None
    assert get_lexer(mime='application/json', body='{"key": "value"}', explicit_json=True) is not None

# Generated at 2022-06-21 14:06:22.220003
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie import ExitStatus
    from httpie.output import SEP_CREDENTIALS, SEP_HEADERS
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from tests.output.streams import stream

    env = Environment()
    env.stdout = stream.WritableStream()
    formatter = ColorFormatter(env)

    # Test that the headers are colorized appropriately

# Generated at 2022-06-21 14:06:34.007437
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer('application/json'), pygments.lexers.JsonLexer)
    assert get_lexer('application/json')
    assert isinstance(get_lexer('application/javascript'), pygments.lexers.JsonLexer)
    assert get_lexer('application/javascript')
    assert isinstance(get_lexer('application/x-www-form-urlencoded'), pygments.lexers.JsonLexer)
    assert get_lexer('application/x-www-form-urlencoded')
    assert isinstance(get_lexer('text/html'), pygments.lexers.HtmlLexer)
    assert get_lexer('text/html')
    assert get_lexer('text/html+jinja')

# Generated at 2022-06-21 14:06:39.090202
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    from httpie.plugins import FormatterPlugin
    from httpie.request import HTTPRequest
    from httpie.response import HTTPResponse
    from httpie.client import Client

    http_request = HTTPRequest()

    http_response = HTTPResponse()
    http_response.headers['Content-Type'] = 'application/json'

    http_response.headers['Content-Type'] = 'application/json'
    http_response.body = json.dumps({'response_body':'hello world'})

    environment = 'test'
    httpie = Client(http_request, environment)
    formatter = ColorFormatter(environment)
    response = formatter.format_body(http_response.body, http_response.headers['Content-Type'])

# Generated at 2022-06-21 14:06:42.546377
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(Environment(colors=256), color_scheme='solarized256')
    assert color_formatter.get_style_class('solarized256') == Solarized256Style


# unit test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-21 14:06:43.611729
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:06:45.280320
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer.__init__()


# Generated at 2022-06-21 14:06:46.002212
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:06:52.696494
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    f = ColorFormatter()
    headers = '''POST /post HTTP/1.1\r
Host: httpbin.org\r
Content-Length: 14\r
User-Agent: httpie\r
Accept: */*\r
Content-Type: application/x-www-form-urlencoded\r
Connection: keep-alive\r
\r
'''
    print(f.format_headers(headers))

# Generated at 2022-06-21 14:06:53.363937
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    pass

# Generated at 2022-06-21 14:07:09.008503
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import pygments.lexers as plexers
    simplifiedHTTPLexer=SimplifiedHTTPLexer()
    assert isinstance(simplifiedHTTPLexer,plexers.RegexLexer)

# Generated at 2022-06-21 14:07:09.542383
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:07:10.252397
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:07:18.065509
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.core import main

    import pytest

    # Test with a JSON response
    _result = main(
        [
            "--print bB",
            "https://httpbin.org/get"
        ]
    )
    if is_windows:
        # Colorama init screws up the tests
        import sys
        sys.stdout.write(_result.stdout)
        sys.stderr.write(_result.stderr)

    assert _result.exit_status == 0, _result.stdout + _result.stderr
    assert "HTTP/1.1 200" in _result.stdout, _result.stdout
    assert "Content-Type: application/json" in _result.stdout, _result.stdout

    # Test with an XML response

# Generated at 2022-06-21 14:07:19.570511
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-21 14:07:21.982122
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class('default')
    assert style_class == pygments.styles.get_style_by_name('default')

# Generated at 2022-06-21 14:07:23.775184
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    try:
        Solarized256Style()
    except Exception as e:
        print(e)
        raise

# Generated at 2022-06-21 14:07:24.773606
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == "HTTP"


# Generated at 2022-06-21 14:07:32.308507
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    def mock_Environment():
        pass
    e = mock_Environment()
    e.colors = True
    f = ColorFormatter(e)
    assert isinstance(f.formatter, TerminalFormatter)
    assert isinstance(f.http_lexer, SimplifiedHTTPLexer)
    e.colors = 256
    f = ColorFormatter(e)
    assert isinstance(f.formatter, Terminal256Formatter)
    assert isinstance(f.http_lexer, PygmentsHttpLexer)

# Generated at 2022-06-21 14:07:41.847119
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.plugins import FormatterPlugin

    FormatterPlugin.key = 'colors'
    formatter = ColorFormatter(None, explicit_json=False, color_scheme=SOLARIZED_STYLE)

    request_line = 'GET / HTTP/1.1'

# Generated at 2022-06-21 14:08:09.219607
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    from pygments import styles
    from pygments.token import Token
    Solarized256Style()
    styles.get_style_by_name('solarized256')

    # test look-up of all Token
    for name in Token.__dict__.keys():
        if name[0] == '_':
            continue
        token = getattr(Token, name)
        Solarized256Style.styles[token]

# Generated at 2022-06-21 14:08:13.070035
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    env = Environment(colors=True)
    ColorFormatter(env, explicit_json=False, color_scheme=SOLARIZED_STYLE)
    ColorFormatter(env, explicit_json=False, color_scheme=AUTO_STYLE)

# Generated at 2022-06-21 14:08:22.512435
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest

    # list of pairs of the form <input string>, <expected result>
    test_data = [
        # Try to get a lexer for the content type of the given body
        ['application/json', '{}', pygments.lexers.get_lexer_by_name('json')],
        ['application/xml', '', pygments.lexers.get_lexer_by_name('xml')],
        ['text/plain', '', pygments.lexers.get_lexer_by_name('text')],
        ['text/plain+no_lexer', '', None],
        ['text/plain+json', '{}', pygments.lexers.get_lexer_by_name('json')],
        ['application/octet-stream', '{}', None]
    ]

    e = Environment

# Generated at 2022-06-21 14:08:30.885293
# Unit test for function get_lexer
def test_get_lexer():
    tests = [
      ('application/json', False, '{"key": "value"}', 'json'),
      ('application/json', True, '{"key": "value"}', 'json'),
      ('text/plain', False, '{"key": "value"}', None),
      ('text/plain', True, '{"key": "value"}', 'json'),
      ('text/html', False, '<html><body>foo</body></html>', 'html'),
      ('text/html', False, '<html><body>{"key": "value"}</body></html>', 'html'),
      ('text/html', True, '<html><body>{"key": "value"}</body></html>', 'html+json'),
    ]

    for mime, explicit_json, body, lexer_name in tests:
        lexer = get_

# Generated at 2022-06-21 14:08:37.266327
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer(mime='text/html')
    assert get_lexer(mime='application/json')
    assert get_lexer(mime='application/vnd+json')
    assert get_lexer(mime='text/plain', body='[1,2,3]')
    assert get_lexer(mime='text/plain', explicit_json=True, body='[1,2,3]')

# Generated at 2022-06-21 14:08:42.177624
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity') is pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style
    assert ColorFormatter.get_style_class('auto') is None
    assert ColorFormatter.get_style_class('undefined_style') is None

# Generated at 2022-06-21 14:08:46.191622
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-21 14:08:53.943817
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    fmt = ColorFormatter(Environment(colors=256, is_windows=False), color_scheme=SOLARIZED_STYLE)
    assert fmt.enabled == True
    assert fmt.http_lexer.__name__ == 'SimplifiedHTTPLexer'
    assert fmt.formatter.__class__.__name__ == 'Terminal256Formatter'
    assert fmt.formatter.style.__name__ == 'Solarized256Style'

# Generated at 2022-06-21 14:09:01.252928
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Request-Line
    request_line = 'GET / HTTP/1.1'
    request_line_inv = SimplifiedHTTPLexer.tokens['root'][0][0]
    request_line_toks = pygments.lexer.bygroups(
        pygments.token.Name.Function,
        pygments.token.Text,
        pygments.token.Name.Namespace,
        pygments.token.Text,
        pygments.token.Keyword.Reserved,
        pygments.token.Operator,
        pygments.token.Number
    )
    assert (request_line_inv, request_line_toks) == pygments.lex(
        request_line,
        SimplifiedHTTPLexer
    )[0]

    # Response Status-Line

# Generated at 2022-06-21 14:09:03.488060
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    ss = Solarized256Style
    assert ss.__doc__ is not None

# Generated at 2022-06-21 14:09:47.152365
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    simplifier_test = SimplifiedHTTPLexer()


# Generated at 2022-06-21 14:09:53.296227
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def test(mime, body, expected, description):
        actual = ColorFormatter.get_lexer_for_body(None, mime, body)
        assert actual == expected, (
            'Expected %r but got %r for mime type %r and body %r' % (
                expected, actual, mime, body
            )
        )
        return True

    # JSON
    yield test, 'application/json', '{}', pygments.lexers.get_lexer_by_name(
        'json'
    ), 'application/json gets a json lexer'
    yield test, 'application/json', '{', pygments.lexers.get_lexer_by_name(
        'json'
    ), 'application/json gets a json lexer even for invalid json'

# Generated at 2022-06-21 14:09:57.594654
# Unit test for function get_lexer
def test_get_lexer():
    from pygments.lexers.text import HttpLexer

    def assert_get_lexer(mime, expected_class):
        assert isinstance(get_lexer(mime), expected_class)

    assert_get_lexer('text/html', pygments.lexers.html.HtmlLexer)
    assert_get_lexer('text/html; charset=utf-8', pygments.lexers.html.HtmlLexer)
    assert_get_lexer('text/javascript', pygments.lexers.javascript.JavascriptLexer)
    assert_get_lexer('application/json', pygments.lexers.data.JsonLexer)
    assert_get_lexer('foo/bar', HttpLexer)

# Generated at 2022-06-21 14:10:08.448158
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie import ExitStatus
    from httpie.input import SEP_CREDENTIALS
    from httpie.plugins import BuiltinPluginManager
    import json

    class MockEnvironment:
        colors = 256
        stdout_isatty = True
        stdin_isatty = False

    config = {
        'default_options': [
            '--ignore-stdin'
        ]
    }
    httpie = MockHttpie(
        config.copy(),
        plugins=BuiltinPluginManager()
    )
    httpie.env = MockEnvironment()

    # {
    #   "name": "John Doe",
    #   "age": 43
    # }
    #
    # {
    #   "name": "John Doe",
    #   "age": 43
    # }

# Generated at 2022-06-21 14:10:12.175802
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')
    assert ColorFormatter.get_style_class('default') != pygments.styles.get_style_by_name('bw')
    assert ColorFormatter.get_style_class('test') == None

# Test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-21 14:10:15.216323
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    http_lexer = SimplifiedHTTPLexer()
    assert http_lexer.name == 'HTTP'
    assert http_lexer.aliases == ['http']
    assert http_lexer.filenames == ['*.http']

# Generated at 2022-06-21 14:10:22.861032
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter('', '')
    sample_headers = '''\
HTTP/1.1 200 OK
Date: Mon, 13 Aug 2012 20:55:56 GMT
Server: Apache/2.2.21 (FreeBSD)
Last-Modified: Thu, 21 Jun 2012 15:44:44 GMT
ETag: "150000026edf-1c6-4c231a8eaa680"
Accept-Ranges: bytes
Content-Length: 444
Content-Type: text/html

'''
    assert formatter.format_headers(sample_headers) == sample_headers

# Generated at 2022-06-21 14:10:32.335982
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-21 14:10:36.760140
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class FakeEnv(object):
        def __init__(self, colors=False, **kwargs):
            self.colors = colors
    assert ColorFormatter(FakeEnv()).format_headers('foo') == 'foo'
    assert ColorFormatter(FakeEnv(colors=True)).format_headers('foo') == 'foo'

# Generated at 2022-06-21 14:10:45.941700
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    '''
    Test constructor of class ColorFormatter
    '''

# Generated at 2022-06-21 14:12:30.045274
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    formatter = ColorFormatter(
        env,
        explicit_json=False,
        color_scheme='auto',
    )
    assert formatter is not None

# Generated at 2022-06-21 14:12:32.724402
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    """
    >>> s = Solarized256Style()
    >>> import pygments
    >>> isinstance(s, pygments.style.Style)
    True
    """

# Generated at 2022-06-21 14:12:41.399090
# Unit test for function get_lexer
def test_get_lexer():
    test_cases = [
        ('application/json', pygments.lexers.get_lexer_by_name('json')),
        ('application/json+foo', pygments.lexers.get_lexer_by_name('json')),
        ('application/json+foo', pygments.lexers.get_lexer_by_name('foo')),
        ('application/json2+foo2', pygments.lexers.get_lexer_by_name('json2')),
        ('application/json2+foo2', pygments.lexers.get_lexer_by_name('foo2')),
        ('foo/bar', None),
    ]
    for mime, expected in test_cases:
        lexer = get_lexer(mime)
        assert (lexer is expected)

# Generated at 2022-06-21 14:12:47.582492
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    color_formatter = ColorFormatter(None,
                                     explicit_json=False,
                                     color_scheme=DEFAULT_STYLE)

# Generated at 2022-06-21 14:12:48.157045
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    cf = ColorFormatter()

# Generated at 2022-06-21 14:12:49.450908
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    Style = ColorFormatter.get_style_class(SOLARIZED_STYLE)
    assert Style is Solarized256Style

# Generated at 2022-06-21 14:12:50.970922
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert (isinstance(SimplifiedHTTPLexer, pygments.lexer.RegexLexer))

# Generated at 2022-06-21 14:12:57.422235
# Unit test for function get_lexer
def test_get_lexer():

    # No need to check all available types,
    # just some of the more generic ones.

    assert get_lexer('application/json')
    assert get_lexer('application/javascript')
    assert get_lexer('application/xml')
    assert get_lexer('text/html')
    assert get_lexer('text/css')
    assert get_lexer('text/plain')
    assert get_lexer('text/x-python')
    assert get_lexer('foo/bar')



# Generated at 2022-06-21 14:12:59.332019
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style

# Generated at 2022-06-21 14:13:07.159370
# Unit test for function get_lexer
def test_get_lexer():
    import json  # noqa: F401
    from wsgiref.util import request_uri
    from httpie.core import get_lexer

    assert get_lexer('text/plain') is None
    assert get_lexer('text/plain', explicit_json=True) is None
    assert get_lexer('text/plain',
                     explicit_json=True,
                     body='') is None
    assert get_lexer('text/plain',
                     explicit_json=True,
                     body='{}') is None
    assert get_lexer('text/plain',
                     explicit_json=True,
                     body='{}') is None
    assert not get_lexer('text/plain',
                          explicit_json=True,
                          body='{}')