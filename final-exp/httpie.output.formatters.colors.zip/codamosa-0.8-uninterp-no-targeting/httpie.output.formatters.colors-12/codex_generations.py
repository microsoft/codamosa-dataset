

# Generated at 2022-06-21 14:03:23.561528
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.plugins import FormatterPlugin
    from httpie.compat import is_windows
    from httpie.context import Environment
    
    formatter = ColorFormatter(env=Environment(colors=True), color_scheme='solarized')

    assert formatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')
    assert formatter.get_style_class('solarized') == Solarized256Style
    assert formatter.get_style_class('auto') == pygments.styles.get_style_by_name('fruity') if is_windows else pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-21 14:03:32.389461
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(get_lexer('text/html'), pygments.lexers.HtmlLexer)
    assert isinstance(get_lexer('text/html; charset=utf-8'),
                      pygments.lexers.HtmlLexer)
    assert isinstance(get_lexer('text/html; charset=UTF-8'),
                      pygments.lexers.HtmlLexer)
    assert isinstance(get_lexer('text/html; charset=us-ascii'),
                      pygments.lexers.HtmlDjangoLexer)
    assert isinstance(get_lexer('application/javascript'),
                      pygments.lexers.JavascriptLexer)
    assert isinstance(get_lexer('application/json'),
                      pygments.lexers.JsonLexer)

# Generated at 2022-06-21 14:03:34.213441
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('fruity') is pygments.styles.get_style_by_name('fruity')

# Generated at 2022-06-21 14:03:36.966147
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')

# Generated at 2022-06-21 14:03:38.884616
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter()
    assert color_formatter.formatter



# Generated at 2022-06-21 14:03:45.470107
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    mime = 'application/json'
    body = '{"foo": "bar", "baz": 123}'
    assert body == ColorFormatter(None, color_scheme='auto').format_body(body, mime)
    assert '\x1b[30m\x1b[42m'+body+'\x1b[39m\x1b[49m' == ColorFormatter(None, color_scheme='solarized').format_body(body, mime)

# Generated at 2022-06-21 14:03:51.750622
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    assert (ColorFormatter(Environment(colors=True)).get_lexer_for_body("application/json", "{\n  \"key\": \"value\"\n}")) == pygments.lexers.get_lexer_by_name("json")
    assert (ColorFormatter(Environment(colors=True)).get_lexer_for_body("image/png", open("tests/data/image-png-base64", "rb").read())) == pygments.lexers.get_lexer_for_mimetype("image/png")
    assert (ColorFormatter(Environment(colors=True)).get_lexer_for_body("text/plain", "{\n  \"key\": \"value\"\n}")) == None

# Generated at 2022-06-21 14:04:00.831133
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.compat import str
    from httpie.output.streams import ColorizedStream

    # Case when format_body returns body without modification. This can
    # happen if the content type is not supported by any Pygments lexer.
    # For example, binary files have content type 'application/octet-stream'.
    color_formatter = ColorFormatter(Environment(), False, False)
    body = 'Binary data'
    body = color_formatter.format_body(body, 'application/octet-stream')
    assert body == 'Binary data'

    # Case when format_body returns body after applying a Pygments lexer
    color_formatter = ColorFormatter(Environment(), False, False)
    body = '{"foo": "bar"}'

# Generated at 2022-06-21 14:04:13.672808
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # pylint: disable=unused-variable
    from httpie import ExitStatus
    from httpie.cli import env
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import builtin as builtin_plugins
    from httpie.plugins.manager import PLUGIN_MANAGER as plugin_manager

    plugin_manager.load_installed_plugins()

    color_formatter = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)

    assert color_formatter.formatter.__class__.__name__ == 'TerminalFormatter'
    assert color_formatter.http_lexer.__class__.__name__ == 'PygmentsHttpLexer'


# Generated at 2022-06-21 14:04:23.570009
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-21 14:04:38.257817
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.context import Environment
    env = Environment(colors=True, stdout_isatty=True)
    formatter = ColorFormatter(env=env)
    body = """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html>
      <head>
        <title>301 Moved Permanently</title>
      </head>
      <body>
        <h1>Moved Permanently</h1>
        <p>The document has moved <a href="http://example.com/">here</a>.</p>
      </body>
    </html>"""


# Generated at 2022-06-21 14:04:39.072424
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:04:44.366235
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    assert ColorFormatter('application/json').format_body('', 'application/json') == ''
    assert ColorFormatter('application/json').format_body('{"content_type": "application/json"}', 'application/json') == '{\n    \x1b[32m"content_type"\x1b[39;49;00m: \x1b[32m"application/json"\x1b[39;49;00m\n}\n'

# Generated at 2022-06-21 14:04:56.594744
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import httpie.compat
    from httpie.context import Environment
    from httpie.output.streams import STDOUT_ENCODING

    env = Environment()
    color_formatter = ColorFormatter(env)

    assert color_formatter.format_headers('foo: bar') == '\x1b[37mfoo:\x1b[39m \x1b[37mbar\x1b[39m'
    assert color_formatter.format_headers('baz: qux') == '\x1b[37mbaz:\x1b[39m \x1b[37mqux\x1b[39m'

# Generated at 2022-06-21 14:05:02.844459
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json') is not None
    assert get_lexer('application/json')
    assert get_lexer('application/json; charset=utf-8')

    assert get_lexer('application/json', explicit_json=True,
                     body='"foo"') is not None
    assert get_lexer('application/json', explicit_json=True,
                     body='{}') is not None
    assert get_lexer('application/json', explicit_json=True,
                     body='[]') is not None
    assert not get_lexer('application/json', explicit_json=True,
                         body='<html></html>')
    assert not get_lexer('application/json', explicit_json=True,
                         body='foo')

# Generated at 2022-06-21 14:05:14.889850
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.input import ParseError

    response = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json; charset=utf-8\r\n'
        '\r\n'
        # JSON body.
        '{"foo": "bar"}'
    )

    assert(ColorFormatter.format_body(response, 'application/json') == '{\n    "foo": "bar"\n}')

    # Wrong Content-Type
    assert(ColorFormatter.format_body(response, 'text/html') == response)

    # Unsupported Content-Type
    assert(ColorFormatter.format_body(response, 'image/png') == response)

    # Invalid JSON

# Generated at 2022-06-21 14:05:15.872546
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()  # should not raise an exception

# Generated at 2022-06-21 14:05:19.006072
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class FakeEnv:
        def __init__(self, colors=True):
            self.colors = colors

    fake_env = FakeEnv()
    assert ColorFormatter(fake_env, explicit_json=True, color_scheme='solarized')


# Generated at 2022-06-21 14:05:19.531668
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    pass

# Generated at 2022-06-21 14:05:25.451196
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    text = """GET / HTTP/1.1
Host: example.org
Accept: */*
Accept-Encoding: gzip, deflate

"""
    text = pygments.highlight(
        code=text,
        lexer=lexer,
        formatter=Terminal256Formatter()
    )
    assert text == "\x1b[38;5;59m" + "GET / HTTP/1.1\n" + "\x1b[38;5;59m" + "Host: example.org\n" + "\x1b[38;5;59m" + "Accept: */*\n" + "\x1b[38;5;59m" + "Accept-Encoding: gzip, deflate\n" + "\n"

# Generated at 2022-06-21 14:05:35.878399
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(None)
    assert(isinstance(color_formatter, ColorFormatter))

# Generated at 2022-06-21 14:05:44.630638
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer.name == 'HTTP'
    assert sorted(list(lexer.aliases)) == ['http']
    assert sorted(list(lexer.filenames)) == ['*.http']

# Generated at 2022-06-21 14:05:56.007803
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import unittest


# Generated at 2022-06-21 14:06:05.801604
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import sys
    import unittest
    import tempfile
    import os

    class TestColorFormatter(unittest.TestCase):
        def test_format_headers(self):
            from httpie.core import main

            with tempfile.TemporaryDirectory() as tmpdirname:
                sys.path.insert(0, tmpdirname)

# Generated at 2022-06-21 14:06:06.867947
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()



# Generated at 2022-06-21 14:06:17.616894
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    expected = "\x1b[32mGET\x1b[39m \x1b[33m/resource\x1b[39m \x1b[34mHTTP/1.1\x1b[39m\r\n\
\x1b[34mHost\x1b[39m: \x1b[36mexample.com\x1b[39m\r\n\
\x1b[34mCookie\x1b[39m: \x1b[36mkey1=value1; key2=value2\x1b[39m\r\n\
\r\n"
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-21 14:06:28.863556
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # for each endpoint, make a request
    # for each mime in response, try to make a lexer from mime
    from httpie.plugins import builtin
    from httpie.core import main
    from httpie.core import get_config_dict
    from httpie.compat import is_py26
    # somehow, this line is necessary to avoid file not found error
    import httpie.status
    # in case there is no config file
    config = get_config_dict()
    # add color so we can use color formatter
    config['colors'] = 256
    env = builtin.Environment(config=config)
    formatter = ColorFormatter(env)

    # test data
    # path : multi-value headers, mime

# Generated at 2022-06-21 14:06:39.665418
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class TestFormatter:
        id = None
        explicit_json = False

    class TestPluginContainer:
        formatter = TestFormatter()

    color_formatter = ColorFormatter(Environment(colors=256))
    color_formatter.container = TestPluginContainer()

    # Test mime types
    assert color_formatter.format_body('{}', 'application/json')
    assert color_formatter.format_body('<html>', 'text/html')
    assert color_formatter.format_body('<xml>', 'text/xml')
    assert color_formatter.format_body('<xhtml>', 'text/xhtml')
    assert not color_formatter.format_body('<xml>', 'application/xml')

# Generated at 2022-06-21 14:06:51.562849
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.utils import strip_ansi
    from httpie.context import Environment
    from httpie.plugins.colors import ColorFormatter
    from httpie.compat import is_windows
    if is_windows:
        import colorama
        colorama.init()
    env = Environment(colors=256, style=Solarized256Style)
    formatter = ColorFormatter(env)
    
    request_headers = '''GET / HTTP/1.1\r
Host: 127.0.0.1:5000\r
User-Agent: HTTPie/0.9.2\r
Content-Length: 2\r
Accept-Encoding: gzip, deflate\r
Accept: */*'''


# Generated at 2022-06-21 14:07:00.351408
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    headers = '''
POST /upload HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, compress
Accept-Language: en-us
Connection: keep-alive
Content-Length: 12345
Content-Type: multipart/form-data; boundary=AaB03x
Host: example.com
User-Agent: HTTPie/0.9.2
'''.strip()

# Generated at 2022-06-21 14:07:11.083020
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain') == pygments.lexers.TextLexer
    assert get_lexer('text/plain', explicit_json=True, body='{"a": 1}') == pygments.lexers.JsonLexer
    # use json lexer when content-type is text/*
    assert get_lexer('text/html', explicit_json=True, body='<html></html>') == pygments.lexers.JsonLexer

# Generated at 2022-06-21 14:07:18.461365
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from requests.structures import CaseInsensitiveDict as icid
    from httpie.output.streams import stderr_text_stream
    from httpie.context import Environment
    env = Environment(colors=True, stdout=None, stderr=stderr_text_stream)
    headers = icid({
        'content-type': 'text/plain',
        'Content-Length': '2048',
    })
    color_fmt = ColorFormatter(env=env, color_scheme='solarized')
    output = color_fmt.format_headers(headers)

# Generated at 2022-06-21 14:07:27.566052
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-21 14:07:28.358693
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:07:39.376574
# Unit test for function get_lexer

# Generated at 2022-06-21 14:07:40.989892
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter()
    assert formatter


# Generated at 2022-06-21 14:07:44.294229
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(  # noqa: F821
        'solarized'
    ) is Solarized256Style



# Generated at 2022-06-21 14:07:54.431882
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    from httpie.plugins import FormatterPluginManager

    f = FormatterPluginManager().instantiate(
        plugin='colors',
        explicit_json=False,
        color_scheme='auto',
    )
    cf = ColorFormatter(None, False, 'auto')

    body = "so many bunnies!"
    assert f.format_body(body, "text/plain") == body

    body = '{"bunnies": "so many bunnies!"}'
    assert f.format_body(body, "application/json") == body

    body = "so many bunnies!"
    assert cf.format_body(body, "application/json") == body

    body = "so many bunnies!"
    assert cf.format_body(
        body, "text/plain",
    ) == py

# Generated at 2022-06-21 14:08:03.863934
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    env = Environment(colors=256)

    # The color_scheme is not a valid style
    assert ColorFormatter(env, color_scheme='foo').get_style_class('foo') == Solarized256Style

    # The color_scheme is a valid style but the environment has no 256 color support
    env.colors = True
    assert ColorFormatter(env, color_scheme='fruity').get_style_class('fruity') == Solarized256Style

    # The color_scheme is a valid style and the environment has 256 color support
    env.colors = 256
    assert ColorFormatter(env, color_scheme='fruity').get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')

# Generated at 2022-06-21 14:08:13.736471
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins.builtin import JSONStreamLexer
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    env = Environment()
    formatter = ColorFormatter(env,explicit_json=False,color_scheme=DEFAULT_STYLE)
    body = '''{"id": "1234567890", "name": "Foo", "price": 123, "tags": ["Bar", "Eek"], "stock": {  "warehouse": 300,  "retail": 20 }, "nested": {"foo": "Bar"}}'''
    mime = 'application/json'
    lexer = formatter.get_lexer_for_body(mime, body)
    assert lexer == JSONStreamLexer

# Generated at 2022-06-21 14:08:21.991842
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:08:26.486123
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html')
    assert get_lexer('application/json')
    assert get_lexer('application/json', explicit_json=True)
    assert get_lexer('application/json', body='"a": "b"')
    assert get_lexer('application/json+oas', body='"a": "b"')

# Generated at 2022-06-21 14:08:31.600609
# Unit test for function get_lexer
def test_get_lexer():
    lexer = get_lexer('application/json')
    assert lexer is pygments.lexers.get_lexer_by_name('json')

    lexer = get_lexer('application/ld+json')
    assert lexer is pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-21 14:08:41.988939
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pygments.lexer
    import pygments.lexers
    from pygments.lexers.python import Python3Lexer
    # Simulates the method signature of ColorFormatter.format_body
    ColorFormatter.format_body("print('Hello')", "text/x-python") == '<span style="color: #7f0055; font-weight: bold">print</span>'
    # Fetch the lexer and style classes
    lexer = pygments.lexers.get_lexer_for_mimetype("text/x-python")
    formatter = pygments.formatters.Terminal256Formatter(style=pygments.styles.get_style_by_name("solarized-dark"))
    # Apply the above classes to the string "print('Hello')"

# Generated at 2022-06-21 14:08:50.394460
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(style=Solarized256Style)
    for line in (
        'GET http://example.com/ HTTP/1.1',
        'HTTP/1.1 200 OK',
        'User-Agent: HTTPie/1.0.3-dev',
    ):
        print(pygments.highlight(
            code=line,
            lexer=lexer,
            formatter=formatter,
        ))



# Generated at 2022-06-21 14:08:58.856669
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    print(ColorFormatter.get_lexer_for_body('text/html','<html>'))
    print(ColorFormatter.get_lexer_for_body('application/json','{"a":1}'))
    print(ColorFormatter.get_lexer_for_body('application/x-javascript', '{"a":1}'))
    print(ColorFormatter.get_lexer_for_body('application/x-javascript', 'alert("hi");'))
    print(ColorFormatter.get_lexer_for_body('application/javascript', 'alert("hi");'))
    print(ColorFormatter.get_lexer_for_body('application/javascript', '{"a":1}'))

# Generated at 2022-06-21 14:08:59.963404
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment())

# Generated at 2022-06-21 14:09:10.190523
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    try:
        from httpie.plugins import builtin
    except ImportError:
        from httpie.plugins.builtin import builtin
    formatter = builtin.ColorFormatter()
    headers = formatter.format_headers("""HTTP/1.1 200 OK
Date: Tue, 18 Oct 2016 11:58:56 GMT
Server: Apache
Last-Modified: Mon, 17 Oct 2016 17:11:30 GMT
ETag: "63943-5387b213f5b00"
Accept-Ranges: bytes
Content-Length: 39219
Connection: close
Content-Type: text/html; charset=UTF-8

""")

# Generated at 2022-06-21 14:09:16.545556
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment(colors=256)
    formatter = ColorFormatter(env=env)
    # with correct content-type and correct body
    assert formatter.get_lexer_for_body(
        mime="application/json",
        body='{"some":"body"}'
    ) == pygments.lexers.get_lexer_by_name('json')
    # with incorrect content-type and incorrect body
    assert formatter.get_lexer_for_body(
        mime="application/json",
        body='{"some": "body"}'
    ) == None
    # with correct content-type but incorrect body
    assert formatter.get_lexer_for_body(
        mime="application/json",
        body='"some": "body"'
    ) == None
    # with incorrect content-type but

# Generated at 2022-06-21 14:09:25.782515
# Unit test for function get_lexer
def test_get_lexer():

    def test(mime, body='', explicit_json=False):
        return get_lexer(mime, explicit_json, body)

    assert test('foo/bar') is None
    assert test('application/json') is not None
    assert test('application/json', '{}') is not None
    assert test('application/json', '{}', True) is not None
    assert test('text/plain') == pygments.lexers.get_lexer_by_name('text')
    assert test('application/json-rpc') == pygments.lexers.get_lexer_by_name('json')
    assert test('application/vnd.api+json') == pygments.lexers.get_lexer_by_name('json')
    assert test('application/vnd.api+json', '{}') == py

# Generated at 2022-06-21 14:09:45.545095
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    try:
        Solarized256Style()
    except Exception as e:
        assert False, "constructor throws " + str(e)
    else:
        assert True

# Generated at 2022-06-21 14:09:52.371035
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # This tests JSON responses.
    data_json = {"field_one": "value_one", "field_two": "value_two"}
    json_str = json.dumps(data_json, indent=2)
    # Create a formatter.
    fake_env = Environment()
    fake_env.colors = True
    formatter = ColorFormatter(env=fake_env)
    # Test body formatting.
    body = formatter.format_body(body=json_str, mime="")
    # The _json plugin parses the JSON and serializes it a bit prettier.
    # We don't do anything like this in format_body.

# Generated at 2022-06-21 14:10:00.232995
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie import ExitStatus
    environment = Environment()
    color_formatter = ColorFormatter(env=environment)
    assert color_formatter.enabled is False
    assert color_formatter.formatter is None
    assert color_formatter.http_lexer is None
    assert color_formatter.group_name == 'colors'
    assert color_formatter.exit_status == ExitStatus.OK
    assert color_formatter.explicit_json is False
    color_formatter = ColorFormatter(env=environment, explicit_json=True)
    assert color_formatter.explicit_json is True

# Generated at 2022-06-21 14:10:07.174296
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True, stdout_isatty=True)
    cf = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert cf.formatter == TerminalFormatter()
    env2 = Environment(colors=256, stdout_isatty=True)
    cf2 = ColorFormatter(env2, explicit_json=False, color_scheme=DEFAULT_STYLE)
    assert isinstance(cf2.formatter, Terminal256Formatter)

# Generated at 2022-06-21 14:10:11.571998
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from pygments.lexer import Lexer

    class MockLexer(Lexer):
        name = 'Mock'
        aliases = ['mock']

    class MockTok(Token):
        MockTok = 0

    lexer = MockLexer(startinlinetokens=[MockTok.MockTok])

    assert lexer.startinlinetokens == [MockTok.MockTok]

# Generated at 2022-06-21 14:10:16.315916
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    """
    Test ColorFormatter.get_lexer_for_body
    """
    env = Environment(colors=256)
    formatter = ColorFormatter(env)
    lexer = formatter.get_lexer_for_body(mime='', body='')
    assert lexer is None
    lexer = formatter.get_lexer_for_body(mime='text/plain', body='')
    assert lexer is None
    lexer = formatter.get_lexer_for_body(mime='application/json', body='')
    assert lexer is pygments.lexers.get_lexer_by_name('json')
    lexer = formatter.get_lexer_for_body(mime='application/json+xyz', body='')
    assert lexer is pygments

# Generated at 2022-06-21 14:10:17.344882
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()

# Generated at 2022-06-21 14:10:28.115702
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    def get_lexer_for_body(mime: str, body: str) -> Optional[Type[Lexer]]:
        return ColorFormatter(Environment()).get_lexer_for_body(mime, body)

    # If None is passed to get_lexer_for_body(), then return None.
    assert get_lexer_for_body(None, '') is None

    # JSON responses with an incorrect Content-Type?
    # If the body can be parsed as JSON, and the mime is not recognized,
    # then the JSON lexer is taken.
    assert get_lexer_for_body(
        mime='foo/bar',
        body='{"foo": "bar"}'
    ) == pygments.lexers.get_lexer_by_name('json')
    assert get_lexer_for_body

# Generated at 2022-06-21 14:10:35.903135
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter()
    assert formatter.get_lexer_for_body('text/plain', '') == None
    assert formatter.get_lexer_for_body('application/json', '') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/json+foo', '') == pygments.lexers.get_lexer_by_name('json')
    assert formatter.get_lexer_for_body('application/xml', '') == pygments.lexers.get_lexer_by_name('xml')
    assert formatter.get_lexer_for_body('application/xml+foo', '') == pygments.lexers.get_lexer_by_name('xml')
    assert formatter.get_

# Generated at 2022-06-21 14:10:45.109779
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.cli.argtypes import ColorScheme
    from httpie.plugins.colors import DEFAULT_STYLE, ColorFormatter
    from httpie.styles import Style
    from pygments.formatters.terminal256 import Terminal256Formatter

    # Test default DEFAULT_STYLE: 'auto'
    color_formatter = ColorFormatter(Environment())
    style_class = color_formatter.get_style_class(DEFAULT_STYLE)
    assert issubclass(style_class, Style)
    assert issubclass(style_class, Terminal256Formatter)

    # Test custom Color Scheme
    color_formatter = ColorFormatter(Environment())
    style_class = color_formatter.get_style_class('monokai')
    assert issubclass(style_class, Style)
    assert iss

# Generated at 2022-06-21 14:11:15.480772
# Unit test for function get_lexer

# Generated at 2022-06-21 14:11:26.459861
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-21 14:11:32.999362
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # mock attr
    env = Environment(colors=True)
    c = ColorFormatter(env, explicit_json=False, color_scheme="default")
    mime = "application/json"
    body = ""
    assert isinstance(c, ColorFormatter)
    assert isinstance(c.get_lexer_for_body(mime, body), type(None))
    assert c.get_lexer_for_body(mime, body) is None

# Generated at 2022-06-21 14:11:37.123186
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.formatters.colors import ColorFormatter
    from pygments.styles import get_style_by_name
    assert ColorFormatter.get_style_class('fruity') == get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('solarized') == ColorFormatter.get_style_class('Solarized256Style')

# Generated at 2022-06-21 14:11:46.975798
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Create instance of mock class
    class Mock(object):
        pass
    mock = Mock()
    # Create instance of ColorFormatter
    cf = ColorFormatter(mock, explicit_json=False, color_scheme=DEFAULT_STYLE)
    # Create a list of tuples with headers and expected output

# Generated at 2022-06-21 14:11:52.584386
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    mimetype="text/html"
    htmlbody='''<html>
                    <head>
                        <title>This is title</title>
                    </head>
                    <body>
                        <p>This is p of body</p>
                    </body>
                </html>'''
    assert ColorFormatter.format_body(None, htmlbody, mimetype)==htmlbody

# Generated at 2022-06-21 14:12:02.813286
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.output.streams import ColorizedStdoutStream
    from httpie.plugins import FormatterPluginManager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPieStream


# Generated at 2022-06-21 14:12:03.315191
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    pass

# Generated at 2022-06-21 14:12:05.291443
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE).__name__.startswith('Solarized')

# Generated at 2022-06-21 14:12:07.943877
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(Environment(colors=256))
    formatter.format_headers("x-test:test")
    formatter.format_body("test", "test")
    formatter.get_lexer_for_body("test", "test")
    formatter.get_style_class("test")