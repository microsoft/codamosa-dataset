

# Generated at 2022-06-21 14:03:19.336705
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    class MockEnvironment:
        """
        MockEnvironment
        ---------------

        A mock environment with an attribute `colors`.

        """
        def __init__(self, colors: int):
            self.colors = colors

    syn = SimplifiedHTTPLexer()

# Generated at 2022-06-21 14:03:29.418625
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    class FakeEnv(object):
        colors = True
        stdout_isatty = True
        style = 'solarized'
        formatter = 'terminal256'

    env = FakeEnv()
    formatter = ColorFormatter(env)
    input = 'HTTP/1.1 200 OK\n' \
            'Connection: keep-alive\n' \
            'Content-Length: 1678\n' \
            'Content-Type: application/json\n' \
            'Date: Thu, 22 Apr 2021 13:46:39 GMT\n' \
            'Server: nginx\n' \
            'Via: 1.1 google\n'
    output = formatter.format_headers(input)

# Generated at 2022-06-21 14:03:30.264605
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert style

# Generated at 2022-06-21 14:03:34.336995
# Unit test for function get_lexer
def test_get_lexer():
    assert isinstance(
        get_lexer('application/json'),
        pygments.lexers.get_lexer_by_name('json')
    )
    assert isinstance(
        get_lexer('application/json', explicit_json=True),
        pygments.lexers.get_lexer_by_name('json')
    )
    assert get_lexer('application/json', explicit_json=True, body='[1,2,3]')



# Generated at 2022-06-21 14:03:35.115155
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:03:46.201339
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # type: () -> None
    """Test ColorFormatter.format_headers()

    :param ColorFormatter color_formatter: A ColorFormatter instance.
    :rtype: str
    """
    color_formatter = ColorFormatter(Environment(colors=256))

    print('Calling ColorFormatter.format_headers()')

# Generated at 2022-06-21 14:03:56.030969
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()

# Generated at 2022-06-21 14:04:03.241310
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-21 14:04:14.733673
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment(colors=256, output_options={}))
    assert formatter.get_lexer_for_body('application/json', '')
    assert isinstance(formatter.get_lexer_for_body('application/json', ''), type(pygments.lexers.JsonLexer()))
    assert formatter.get_lexer_for_body('application/json-patch+json', b'{"op":"remove"}')
    assert isinstance(formatter.get_lexer_for_body('application/json-patch+json', b'{"op":"remove"}'), type(pygments.lexers.JsonLexer()))
    assert formatter.get_lexer_for_body('application/xml', '<Request><Login>foo</Login></Request>')

# Generated at 2022-06-21 14:04:23.952197
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import plugin_manager
    plugin_manager.load_installed_plugins()
    plugin_manager.add_command()

    parser = plugin_manager.get_optparser()
    parser.add_argument = parser.add_option

    env = Environment(
        auto_envvar_prefix='HTTPIE_COLORS',
        colors=256,
        stdout_isatty=True,
        stdin_isatty=False,
        style=DEFAULT_STYLE
    )

    ColorFormatter(env).format_body('{"a":1}', 'application/json')
    ColorFormatter(env).format_body('{"a":1}', 'application/json')
    ColorFormatter(env).format_body('{"a":1}', 'application/json')

# Generated at 2022-06-21 14:04:42.180590
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from pygments.formatters import terminal
    color_scheme = 'solarized'
    style = ColorFormatter(None).get_style_class(color_scheme)
    assert isinstance(style, terminal.Terminal256Formatter)
    assert style.style == Solarized256Style

# Generated at 2022-06-21 14:04:47.279185
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    colorFormatter = ColorFormatter(Environment(), False, DEFAULT_STYLE)
    html_body = '''<html>blah blah</html>'''
    assert colorFormatter.format_body(html_body, 'text/html') == '<html>blah blah</html>'

    json_body = '''{"id":"1", "name":"Jane Doe"}'''
    assert colorFormatter.format_body(json_body, 'application/json') != '{"id":"1", "name":"Jane Doe"}'

# Generated at 2022-06-21 14:04:49.490159
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    ColorFormatter.format_headers(headers='test headers')



# Generated at 2022-06-21 14:04:50.572062
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer(text='')

# Generated at 2022-06-21 14:04:54.965423
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=256)
    c=ColorFormatter(env=env, color_scheme='solarized')
    try:
        l=c.get_lexer_for_body('application/json','{"a":1}')
    except ClassNotFound:
        pass

# Generated at 2022-06-21 14:04:56.655583
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    actual = ColorFormatter.get_style_class(SOLARIZED_STYLE)()
    expected = Solarized256Style()

    assert actual.styles == expected.styles
    assert actual.background_color == expected.background_color

# Generated at 2022-06-21 14:05:02.935337
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    class ColorFormatterTest(ColorFormatter):
        pass
    class EnvironmentTest():
        colors = 256
    class DummyRequest():
        body = ""
    class DummyResponse():
        env = EnvironmentTest()
    formatter = ColorFormatterTest(DummyResponse())

    with pytest.raises(ValueError):
        ColorFormatterTest(DummyResponse(), explicit_json = True).format_body("", "")

    with pytest.raises(ValueError):
        formatter.format_body("{}", "")

    with pytest.raises(ValueError):
        formatter.format_body("{}", "")

    with pytest.raises(ValueError):
        formatter.format_body("{}", "")


# Generated at 2022-06-21 14:05:14.934494
# Unit test for function get_lexer
def test_get_lexer():
    from pygments.lexers import get_lexer_by_name

    assert not get_lexer('')
    assert not get_lexer('foo/bar')

    lexer = get_lexer('text/plain')
    assert isinstance(lexer, TextLexer)

    lexer = get_lexer('application/json')
    assert isinstance(lexer, get_lexer_by_name('json'))

    lexer = get_lexer('application/json; charset=UTF-8')
    assert isinstance(lexer, get_lexer_by_name('json'))

    lexer = get_lexer('application/json; charset=UTF-8', explicit_json=True)
    assert isinstance(lexer, get_lexer_by_name('json'))

    lexer = get_

# Generated at 2022-06-21 14:05:15.924635
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style


# Generated at 2022-06-21 14:05:22.489117
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.colors import ColorFormatter
    formatter = ColorFormatter(None)
    assert formatter.get_lexer_for_body('application/json', '{}')
    assert not formatter.get_lexer_for_body('application/json', 'not json')
    assert not formatter.get_lexer_for_body('application/json', '')
    assert formatter.get_lexer_for_body('text/plain', '{}')
    assert formatter.get_lexer_for_body('text/plain', 'not json')
    assert not formatter.get_lexer_for_body('text/plain', '')

# Generated at 2022-06-21 14:05:39.859489
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter(Environment(colors=True, color_scheme='fruity')).get_style_class('fruity') == pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter(Environment(colors=True, color_scheme='16')).get_style_class('16') == pygments.styles.get_style_by_name('16')
    assert ColorFormatter(Environment(colors=True, color_scheme='monokai')).get_style_class('monokai') == pygments.styles.get_style_by_name('monokai')
    assert ColorFormatter(Environment(colors=True, color_scheme='solarized')).get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-21 14:05:47.119801
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    env = Environment(colors=256)
    formatter = ColorFormatter(env=env, explicit_json=False, color_scheme='solarized')
    headers = '''Accept: application/json, text/javascript, */*; q=0.01
Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3
Accept-Encoding: gzip, deflate
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Content-Length: 14
X-Test: Test
X-TEST: Test'''
    colorized_headers = formatter.format_headers(headers)
    assert colorized_headers.count('\x1b') == 4

# Generated at 2022-06-21 14:05:47.713937
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:05:53.173890
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    environment = Environment(
        colors=256
    )
    formatter = ColorFormatter(
        env=environment,
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )
    assert (formatter.enabled)
    assert (formatter.formatter.__class__.__name__ == "Terminal256Formatter")

# Generated at 2022-06-21 14:06:04.250952
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie.cli.formatter
    color = httpie.cli.formatter.ColorFormatter(None, None)
    mime_type1 = 'text/html'
    mime_type2 = 'application/json'
    mime_type3 = 'application/jsonp'
    mime_type4 = 'application/jsonp'
    mime_type5 = 'application/jsonp'
    body1 = '<html> <head> <title>404 Not Found</title> </head> <body bgcolor="white">' \
            '<center><h1>404 Not Found</h1></center></body></html>'
    body2 = '{"a": 2, "b": 4}'
    body3 = '{"a": 2, "b": 4}'

# Generated at 2022-06-21 14:06:13.604065
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPluginManager
    from httpie.output.streams import Streams
    from requests.models import Request

    streams = Streams()

    class MockEnvironment(object):
        colors = True
        stream = streams.stdout
        is_terminal = True
        stdin_isatty = False
        stdout_isatty = True
        headers = {}
        verify = True
        trust_env = True
        style = 'fruity'
        output_options = {}

    env = MockEnvironment()
    manager = FormatterPluginManager(env=env).plugins[0]

    http_request = Request('GET', 'http://httpbin.org/headers')

# Generated at 2022-06-21 14:06:17.897332
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    f = ColorFormatter(Environment(), explicit_json=False)
    assert f.get_lexer_for_body('application/json', '{"foo": 1}') == pygments.lexers.get_lexer_by_name('json')



# Generated at 2022-06-21 14:06:19.527439
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    fmt = ColorFormatter(Environment(), color_scheme='solarized')

# Generated at 2022-06-21 14:06:24.618944
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
                style=Solarized256Style
            )
    # Test if function format_body will raise an exception
    try:
        ColorFormatter.format_body(formatter, http_lexer, "", "")
    except TypeError:
        return False
    return True

# Generated at 2022-06-21 14:06:31.883207
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import os
    import sys
    import unittest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.env = Environment(colors=256)
            self.formatter = ColorFormatter(self.env)

    env = Environment(colors=256)
    formatter = ColorFormatter(env)

# Generated at 2022-06-21 14:06:54.974544
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.compat import pygments_version
    from httpie.plugins.colors import ColorFormatter
    from httpie.context import Environment

    def get_style_class(color_scheme):
        return ColorFormatter(
            env=Environment(),
            color_scheme=color_scheme
        ).get_style_class(color_scheme)

    # Styles provided by Pygments, except the `solarized256` style
    # which is a custom style bundled with httpie.
    available_styles = list(
        set(pygments.styles.get_all_styles()) - {SOLARIZED_STYLE}
    )

    if pygments_version >= (2, 4):
        available_styles.append(AUTO_STYLE)


# Generated at 2022-06-21 14:07:05.496025
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    class FakeEnvironment:
        colors = 256
    environment = FakeEnvironment()

    class FakeFormatter:
        def __init__(self, **kwargs):
            pass

        def format(self, lexer, formatter):
            return "<html><body><p>text</p></body></html>"

    class FakeLexer:
        def __init__(self, **kwargs):
            pass

    color_formatter = ColorFormatter(environment, explicit_json=False, color_scheme=DEFAULT_STYLE)
    color_formatter.formatter = FakeFormatter()
    color_formatter.get_lexer_for_body = lambda mime, body: FakeLexer()

# Generated at 2022-06-21 14:07:14.196650
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Arrange
    mock_environ = generate_mock_environ()
    mock_kwargs = generate_mock_kwargs()
    formatter = ColorFormatter(env=mock_environ, **mock_kwargs)
    formatter.formatter = Terminal256Formatter(
        style=Solarized256Style
    )
    formatter.http_lexer = SimplifiedHTTPLexer()
    mock_content = 'HTTP/1.1 200 OK\nTest: test\nFoo: bar\n'
    # Act
    response = formatter.format_headers(mock_content)
    # Assert
    assert response.startswith('\x1b[38;5;64mHTTP/1.1')

# Generated at 2022-06-21 14:07:15.009494
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:07:24.875342
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # unit test: httpie.formatter.ColorFormatter.format_body
    import httpie.formatter
    import pygments.lexers

    class MockTerminalFormatter(httpie.formatter.TerminalFormatter):
        def __init__(self, **kwargs):
            self.__initialized = True

            # initialize super class
            super(MockTerminalFormatter, self).__init__(**kwargs)

            # set mock value for property "style" of parent class
            self.style = mock_style

    class MockTerrain256Formatter(httpie.formatter.Terminal256Formatter):
        def __init__(self, **kwargs):
            self.__initialized = True

            # initialize super class

# Generated at 2022-06-21 14:07:36.249088
# Unit test for function get_lexer
def test_get_lexer():
    cases = [
        ('text/html', None),
        ('text/html+jinja', 'jinja'),
        ('text/html+jinja2', 'jinja2'),
        ('text/html+django', 'django'),
        ('text/x-c', 'c'),
        ('text/x-c++src', 'cpp'),
        ('application/json', None),
        ('application/json-home', 'json'),
        ('application/json+home', 'json'),
        ('text/foo+json', 'json'),
        ('text/foo+json-foo', 'json'),
    ]
    for content_type, lexer_name in cases:
        lexer = get_lexer(content_type)
        assert lexer_name == lexer.name if lexer else lexer

# Generated at 2022-06-21 14:07:44.302102
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest
    from httpie.cli import parser
    from httpie.context import Environment

    # test data
    headers = (
        'GET / HTTP/1.1\n'
        'Accept: */*\n'
        'Accept-Encoding: gzip, deflate\n'
        'Connection: keep-alive\n'
        'Host: example.com\n'
        'User-Agent: HTTPie/1.0.2\n'
        'X-Something: \U0001F4A9\n'
    )

# Generated at 2022-06-21 14:07:54.468241
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    import unittest
    import os
    import json

    class ColorFormatter(FormatterPlugin):
        """
        Colorize using Pygments

        This processor that applies syntax highlighting to the headers,
        and also to the body if its content type is recognized.

        """
        group_name = 'colors'

        def __init__(
            self,
            env: Environment,
            explicit_json=False,
            color_scheme=DEFAULT_STYLE,
            **kwargs
        ):
            super().__init__(**kwargs)

            if not env.colors:
                self.enabled = False
                return

            use_auto_style = color_scheme == AUTO_STYLE

# Generated at 2022-06-21 14:07:59.883317
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    lexer = pygments.lexers.get_lexer_by_name('http')
    formatter = Terminal256Formatter(style=Solarized256Style)

    tokens = [(pygments.token.Token, 'abc')]
    assert 'abc' == pygments.highlight(
        code='abc',
        lexer=lexer,
        formatter=formatter
    )

# Generated at 2022-06-21 14:08:02.506335
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    import httpie.plugins.colors
    color = httpie.plugins.colors.ColorFormatter
    env = httpie.plugins.colors.Environment()
    assert color(env)

# Generated at 2022-06-21 14:08:40.008802
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    instances = {}
    is_windows = False
    explicit_json = True
    color_scheme = "default"

    env = {"colors": 256,
           }

    instances['http_lexer'] = PygmentsHttpLexer()
    instances['formatter'] = Terminal256Formatter(
        style=Solarized256Style)

    cf = ColorFormatter(env, explicit_json, color_scheme)

    assert cf.explicit_json == explicit_json
    assert cf.formatter == instances['formatter']
    assert cf.http_lexer == instances['http_lexer']

# Generated at 2022-06-21 14:08:47.013005
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import pygments.lexers
    import pygments.formatters
    lexer = pygments.lexers.get_lexer_by_name("http")
    formatter = pygments.formatters.TerminalFormatter()
    pygments.highlight(
        "GET / HTTP/1.1\r\nHost: foo.com\r\nAccept: */*\r\n\r\n",
        lexer, formatter)
    pygments.highlight(
        "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n",
        lexer, formatter)

# Generated at 2022-06-21 14:08:48.483394
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-21 14:08:49.848830
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()

# Generated at 2022-06-21 14:08:59.281942
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    mime_dict = {"html": ["html","htm","shtml","shtm","xhtml","phtml"],
                 "text": ["text","txt","conf","def","list","log","in","ini","dsc"],
                 "pdf": ["pdf"],
                 "xml": ["xml"],
                 "javascript": ["js","mjs"],
                 "css": ["css"],
                 "json": ["json"],
                 "markdown": ["md"],
                 "yaml": ["yaml"]
                }
    from httpie.context import Environment
    env = Environment()
    cf = ColorFormatter(env, explicit_json=False, color_scheme=DEFAULT_STYLE)

# Generated at 2022-06-21 14:09:07.065938
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    http_lexer = SimplifiedHTTPLexer()
    formatter = Terminal256Formatter(
        style=Solarized256Style
    )
    colorFormatter = ColorFormatter(None)
    assert colorFormatter.get_lexer_for_body("application/json", "") == pygments.lexers.get_lexer_by_name('json')
    assert colorFormatter.get_lexer_for_body(
        "image/png", "") == pygments.lexers.get_lexer_by_name(
        'png')

# Generated at 2022-06-21 14:09:16.501705
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    code = '''
GET / HTTP/1.1
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.2

'''

# Generated at 2022-06-21 14:09:25.779636
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    solarized256 = Solarized256Style()
    assert solarized256.background_color == "#1c1c1c"
    assert solarized256.styles[pygments.token.Keyword] == "#5f8700"
    assert solarized256.styles[pygments.token.Keyword.Constant] == "#d75f00"
    assert solarized256.styles[pygments.token.Keyword.Declaration] == "#0087ff"
    assert solarized256.styles[pygments.token.Keyword.Namespace] == "#d75f00"
    assert solarized256.styles[pygments.token.Keyword.Reserved] == "#0087ff"
    assert solarized256.styles[pygments.token.Keyword.Type] == "#af0000"

# Generated at 2022-06-21 14:09:36.447864
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers_str = """HTTP/1.1 200 OK
Date: Tue, 09 Jan 2018 21:45:19 GMT
Server: Apache
X-Powered-By: PHP/5.6.30
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0
Pragma: no-cache
Set-Cookie: PHPSESSID=b2o2elop9jfrbhm9d1tajoujv0; path=/
Content-Length: 8
Connection: close
Content-Type: text/html; charset=UTF-8
Content-Encoding: gzip

test = 1"""

    output = ColorFormatter(None, explicit_json=False, color_scheme='manni').format_body

# Generated at 2022-06-21 14:09:41.427302
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from pytest import raises
    from requests import Response
    from httpie.compat import str

    response = Response()
    response.status_code = 200
    response.headers = {'Content-Type': "text/plain"}
    response.raw = str('{"key": "value"}')

    formatter = ColorFormatter(env={'colors': 256})

    formatter.format_body(body=response.text, mime=response.headers['Content-Type'])

# Generated at 2022-06-21 14:10:16.462804
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-21 14:10:21.895770
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment()
    env.colors = 256
    colorFormatter = ColorFormatter(env, 
        explicit_json=False, 
        color_scheme='solarized', 
        #kwargs=None
    )
    assert colorFormatter.get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-21 14:10:25.422553
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    lexer = ColorFormatter(None).get_lexer_for_body('application/json', '{}')
    assert lexer == pygments.lexers.get_lexer_by_name('json')

# Generated at 2022-06-21 14:10:33.781090
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import pytest
    from pygments.token import Token
    class Token: Token
    class Text: Token.Text
    class Name: Token.Name

    http_lexer = SimplifiedHTTPLexer()
    expected_tokens = {
        Token.Text: 0,
        Token.Operator: 3,
        Token.Name: 0,
        Token.Number: 0,
        Token.Name.Attribute: 0,
        Token.String: 0
    }
    tokens = http_lexer.get_tokens('Accept: text/html')
    for token, token_name in tokens:
        expected_tokens[token_name] += 1


# Generated at 2022-06-21 14:10:34.966793
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    assert ColorFormatter(Environment(), formatter_type='colors')

# Generated at 2022-06-21 14:10:44.107876
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment())
    assert formatter.enabled

    # application/json with body
    assert formatter.get_lexer_for_body('application/json', '{}')
    # application/json with no body
    assert not formatter.get_lexer_for_body('application/json', '')
    # application/XXX+json with body
    assert formatter.get_lexer_for_body('application/json', '{}')
    # application/XXX+json with body
    assert not formatter.get_lexer_for_body('application/json', '{}')
    # application/X+json with body
    assert formatter.get_lexer_for_body('application/json', '{}')
    # application/X+json with no body
    assert not formatter.get_

# Generated at 2022-06-21 14:10:53.528484
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    from pygments.token import Token
    from httpie.plugins.colors import SimplifiedHTTPLexer
    lexer = SimplifiedHTTPLexer()  # type: SimplifiedHTTPLexer
    http_request_line = (
        Token.Name.Function,
        Token.Text,
        Token.Name.Namespace,
        Token.Text,
        Token.Keyword.Reserved,
        Token.Operator,
        Token.Number
    )
    tokens = lexer.get_tokens_unprocessed(
        "GET / HTTP 1.1\r\nContent-Type: application/json\r\n",
    )

# Generated at 2022-06-21 14:10:56.077940
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    c = ColorFormatter(None, color_scheme='solarized')
    assert c.get_lexer_for_body('text/html', '').__name__ == 'HtmlLexer'
    assert c.get_lexer_for_body('application/json', '').__name__ == 'JsonLexer'

# Generated at 2022-06-21 14:10:57.793822
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')


# Generated at 2022-06-21 14:11:08.677249
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    # Constructor with all defaults
    c = ColorFormatter(
        env=Environment(colors=256,
                        style='auto'),
        explicit_json=False)
    assert c.color_scheme == 'solarized'
    assert c.explicit_json == False
    assert c.formatter.__class__ == Terminal256Formatter
    assert c.http_lexer.__class__ == SimplifiedHTTPLexer

    # Explicit color scheme chosen
    c = ColorFormatter(
        env=Environment(colors=256,
                        style='fruity'),
        explicit_json=False)
    assert c.color_scheme == 'fruity'
    assert c.explicit_json == False
    assert c.formatter.__class__ == Terminal256Formatter
    assert c.http_lexer.__class

# Generated at 2022-06-21 14:12:43.834160
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('default') == pygments.styles.get_style_by_name('default')
    assert ColorFormatter.get_style_class('foo') == pygments.styles.get_style_by_name('foo')
    assert ColorFormatter.get_style_class('bar') == pygments.styles.get_style_by_name('bar')

# Generated at 2022-06-21 14:12:44.490565
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()


# Generated at 2022-06-21 14:12:50.339394
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    headers = "HTTP/1.1 200 OK\r\nConnection: close\r\nContent-Length: 16\r\n"
    headers_expect = "\x1b[90mHTTP\x1b[39m\x1b[90m/\x1b[39m\x1b[33m1.1\x1b[39m \x1b[92m200\x1b[39m \x1b[35mOK\x1b[39m\n\x1b[33mConnection\x1b[39m: \x1b[34mclose\x1b[39m\n\x1b[33mContent-Length\x1b[39m: \x1b[34m16\x1b[39m\n"

# Generated at 2022-06-21 14:12:51.080822
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:12:54.650822
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s256 = Solarized256Style()
    assert s256._style['Token'][0] == '#8a8a8a'
    assert s256._style['Generic.Strong'][0] == 'bold'

# Generated at 2022-06-21 14:12:56.152215
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    color_style = Solarized256Style()
    assert color_style.background_color == Solarized256Style.BASE03

# Generated at 2022-06-21 14:13:00.409949
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Returns None if the mime type of the body is not recognized
    formatter = ColorFormatter(Environment(colors=256, is_windows=False))
    actualLexer = formatter.get_lexer_for_body('text/xml', '')
    assert actualLexer is None


# Generated at 2022-06-21 14:13:08.310430
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment(colors=True)
    c = ColorFormatter(env)
    headers = c.format_headers(
        'HTTP/1.1 200 OK\r\nCache-Control: max-age=604800\r\n'
    )