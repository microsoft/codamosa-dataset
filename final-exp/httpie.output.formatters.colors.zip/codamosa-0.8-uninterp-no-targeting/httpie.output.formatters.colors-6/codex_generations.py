

# Generated at 2022-06-21 14:03:18.978023
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Request-Line
    tokens = SimplifiedHTTPLexer().get_tokens('GET /foo HTTP/1.1')
    assert tokens.__next__() == (pygments.token.Name.Function, 'GET')
    assert tokens.__next__() == (pygments.token.Text, ' ')
    assert tokens.__next__() == (pygments.token.Name.Namespace, '/foo')
    assert tokens.__next__() == (pygments.token.Text, ' ')
    assert tokens.__next__() == (pygments.token.Keyword.Reserved, 'HTTP')
    assert tokens.__next__() == (pygments.token.Operator, '/')
    assert tokens.__next__() == (pygments.token.Number, '1.1')

    # Response Status-Line
   

# Generated at 2022-06-21 14:03:28.429013
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/plain')
    assert get_lexer('text/plain', body='')
    assert get_lexer('text/plain', body='') is None
    assert get_lexer('application/json', body='') is None
    assert get_lexer('application/json', body='{') is None
    assert get_lexer('application/json', body='{}') is not None
    assert get_lexer('application/json', explicit_json=True, body='{') is not None
    assert get_lexer('application/json', explicit_json=True, body='{}') is not None
    assert get_lexer('application/json', explicit_json=True, body='') is None

# Generated at 2022-06-21 14:03:32.048377
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    color_formatter = ColorFormatter(Environment(colors=True, stdout_isatty=True), color_scheme='solarized')
    print(color_formatter.format_body('{"key": "value"}', 'application/json'))


if __name__ == '__main__':
    test_ColorFormatter_format_body()

# Generated at 2022-06-21 14:03:33.200965
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    c=ColorFormatter()

# Generated at 2022-06-21 14:03:33.763298
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    pass

# Generated at 2022-06-21 14:03:42.879043
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('test') is None
    assert ColorFormatter.get_style_class('solarized') is Solarized256Style
    assert ColorFormatter.get_style_class('solarized256') is Solarized256Style
    assert ColorFormatter.get_style_class('fruity') is pygments.styles.get_style_by_name('fruity')
    assert ColorFormatter.get_style_class('auto') is Solarized256Style
    assert ColorFormatter.get_style_class('') is Solarized256Style
    assert ColorFormatter.get_style_class('test', ) is None

# Generated at 2022-06-21 14:03:47.253889
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.get_config_dict = lambda: {'colors': True}
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json\r\n'

    assert ColorFormatter(env).format_headers(headers) == headers

# Generated at 2022-06-21 14:03:54.508259
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.color import ColorFormatter
    formatter = ColorFormatter('', '')
    assert formatter.get_lexer_for_body('application/json', '')
    assert formatter.get_lexer_for_body('application/json+foo', '')
    assert formatter.get_lexer_for_body('application/json-bar', '')
    assert formatter.get_lexer_for_body('application/json+foo-bar', '')
    assert formatter.get_lexer_for_body('application/json+foo; charset=UTF-8', '')

# Generated at 2022-06-21 14:04:02.567318
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(Environment(), explicit_json=False, color_scheme="default")

    # The following cases are tested: Lexer from mime type, Lexer from
    # subtype, Lexer from subtype name, Lexer from subtype suffix,
    # 'json' in subtype, TextLexer for unknown type, json for explicit_json
    assert(color_formatter.get_lexer_for_body("application/json", "") == pygments.lexers.get_lexer_by_name("json"))
    assert(color_formatter.get_lexer_for_body("application/javascript", "") == pygments.lexers.get_lexer_by_name("javascript"))

# Generated at 2022-06-21 14:04:14.092792
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import io

    import pygments.formatters
    import pygments.lexer
    import pygments.lexers

    class MockHttpLexer(pygments.lexer.RegexLexer):
        name = 'HTTP'
        aliases = ['http']
        filenames = ['*.http']


# Generated at 2022-06-21 14:04:28.865173
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import tempfile
    import shutil
    import os
    import sys
    import http.client
    import httplib2
    import pygments
    import os
    import sys
    import getopt
    import json
    

# Generated at 2022-06-21 14:04:36.759231
# Unit test for method get_lexer_for_body of class ColorFormatter

# Generated at 2022-06-21 14:04:45.937564
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json').__name__ == 'JSONLexer'
    assert get_lexer('application/xml').__name__ == 'XMLLexer'
    assert get_lexer('application/javascript').__name__ == 'JavascriptLexer'
    assert get_lexer('text/css').__name__ == 'CssLexer'
    assert get_lexer('text/html').__name__ == 'HtmlLexer'
    assert get_lexer('text/plain').__name__ == 'TextLexer'
    assert not get_lexer('text/x-unknown')
    assert not get_lexer('application/x-unknown')
    assert not get_lexer('something/else')


# Generated at 2022-06-21 14:04:57.594231
# Unit test for function get_lexer
def test_get_lexer():
    from httpie import ExitStatus
    color_formatter = ColorFormatter(Environment())
    assert get_lexer('application/json') is pygments.lexers.get_lexer_by_name(
        'json')
    assert get_lexer('application/javascript') is pygments.lexers.get_lexer_by_name(
        'javascript')
    assert get_lexer('text/xml') is pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('text/html') is pygments.lexers.get_lexer_by_name('html')
    assert get_lexer('text/plain') is pygments.lexers.get_lexer_by_name('text')
    assert get_lexer('application/octet-stream') is None

    assert get_lex

# Generated at 2022-06-21 14:05:02.228303
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_name = 'solarized'
    style_class = ColorFormatter(
        Environment({}),
        color_scheme=style_name,
        explicit_json=False,
    ).get_style_class(style_name)
    assert style_class == Solarized256Style

# Generated at 2022-06-21 14:05:14.272669
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter(env=Environment())
    headers = formatter.format_headers("""GET / HTTP/1.1
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate, compress
Accept: */*
Host: httpbin.org


""")


# Generated at 2022-06-21 14:05:22.400076
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    class DummyEnv():
        colors = True
    d = DummyEnv()
    cf = ColorFormatter(env=d)

    # HTML
    assert pygments.lexers.html.HtmlLexer == cf.get_lexer_for_body(
        mime='text/html', body='<html><body></body></html>')
    assert pygments.lexers.html.HtmlLexer == cf.get_lexer_for_body(
        mime='text/html; charset=utf-8', body='<html><body></body></html>')
    assert pygments.lexers.html.HtmlLexer == cf.get_lexer_for_body(
        mime='text/html; charset=utf-8', body='<!DOCTYPE html>')

    # XML


# Generated at 2022-06-21 14:05:25.113898
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class Environment:
        def __init__(self):
            self.colors = True
    colorformatter = ColorFormatter(Environment)
    assert colorformatter.enabled

# Generated at 2022-06-21 14:05:36.903927
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import Plugin

    class DummyPlugin(Plugin):
        def __init__(self):
            super().__init__()


    env = Environment(colors=256, stdout=None, stdin=None,
                      stdin_isatty=False, stdout_isatty=False,
                      merge_cookies=True, defaults=None, config_dir=None,
                      config_path=None, plugins=[DummyPlugin()])

    # test when body is None, the method return None
    cf = ColorFormatter(env=env, color_scheme=DEFAULT_STYLE)
    assert cf.get_lexer_for_body(mime='application/problem+xml', body=None) is None

   

# Generated at 2022-06-21 14:05:37.886914
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style(): Solarized256Style()



# Generated at 2022-06-21 14:05:50.129544
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.output.colors import ColorFormatter
    from httpie.compat import is_windows

    color_formatter = ColorFormatter(
        Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
        **{}
    )
    assert color_formatter.get_lexer_for_body(
        'application/json',
        body='{"foo": "bar"}'
    ) == pygments.lexers.get_lexer_by_name('json')
    assert color_formatter.get_lexer_for_body(
        'xxx/xxx',
        body='{"foo": "bar"}'
    ) == None

# Generated at 2022-06-21 14:05:51.921758
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(color_scheme='solarized') == Solarized256Style

# Generated at 2022-06-21 14:05:53.501291
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # TODO: add more unit tests
    pass

# Generated at 2022-06-21 14:05:56.957688
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    formatter = ColorFormatter(
        env=Environment(),
        explicit_json=False,
        color_scheme=DEFAULT_STYLE,
    )

# Generated at 2022-06-21 14:06:02.414890
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('text/html') is None
    assert get_lexer('text/html', body='{"foo": true}') is None
    assert get_lexer('text/html', explicit_json=True, body='{"foo": true}')
    assert get_lexer('text/html', explicit_json=True, body='{"foo": true}').name == 'JSON'

# Generated at 2022-06-21 14:06:09.175086
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class
    assert pygments.styles.get_style_by_name(ColorFormatter.get_style_class(SOLARIZED_STYLE)) 
    assert pygments.styles.get_style_by_name(ColorFormatter.get_style_class(AUTO_STYLE))
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style


# Generated at 2022-06-21 14:06:12.024105
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(Environment(colors=256), color_scheme=SOLARIZED_STYLE)
    style = color_formatter.get_style_class()

    assert style == Solarized256Style

# Generated at 2022-06-21 14:06:18.686344
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    from httpie.formatter import (
        __HTTPIE_JSON_FLAGS__,
        __HTTPIE_JSON_PREFIX__,
        __HTTPIE_JSON_SUMMARY__,
    )

    env = Environment(colors=256)
    c = ColorFormatter(env, explicit_json=True, color_scheme="solarized")

    with pytest.raises(AttributeError) as excinfo:
        c.format_body("No body", mime="text/html")
    assert "body" in str(excinfo.value)

    with pytest.raises(AttributeError) as excinfo:
        c.format_body("No mime", body="")
    assert "mime" in str(excinfo.value)


# Generated at 2022-06-21 14:06:20.427130
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    formatter = ColorFormatter
    formatter.format_headers(headers='HTTP/1.1 400 Bad Request')

# Generated at 2022-06-21 14:06:32.335828
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    import types
    S = Solarized256Style
    s = S()
    ok = True
    # s should be an instance of a class
    if type(s) != types.InstanceType:
        print('type(s) = %s, expected %s' % (type(s), types.InstanceType))
        ok = False
    # s.background_color should be a string
    if type(s.background_color) != str:
        print('type(s.background_color) = %s, expected %s' % (type(s.background_color), str))
        ok = False
    # s.styles should be a dict
    if type(s.styles) != dict:
        print('type(s.styles) = %s, expected %s' % (type(s.styles), dict))
        ok = False
    #

# Generated at 2022-06-21 14:06:54.130757
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(DEFAULT_STYLE) == Solarized256Style

# Generated at 2022-06-21 14:07:01.921406
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    """
    Test method format_body of class ColorFormatter.

    """
    # Test with body as an empty string, text/plain media type
    assert ColorFormatter.format_body(body="", mime="text/plain") == ""
    # Test with body as a non-empty string, text/plain media type

# Generated at 2022-06-21 14:07:11.813726
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.context import Environment

    # create Environment instance

# Generated at 2022-06-21 14:07:23.245041
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment()
    cf = ColorFormatter(env, explicit_json=False)
    http_lexer = SimplifiedHTTPLexer()
    formatter = TerminalFormatter()
    cf.http_lexer = http_lexer
    cf.formatter = formatter
    assert cf.get_lexer_for_body('application/json', '') == pygments.lexers.get_lexer_by_name('json')
    assert cf.get_lexer_for_body('application/vnd+json', '') == pygments.lexers.get_lexer_by_name('json')
    assert cf.get_lexer_for_body('text/vnd+json', '') == pygments.lexers.get_lexer_by_name('json')
    assert cf.get_lexer_for_

# Generated at 2022-06-21 14:07:30.391551
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    class TestType(type):
        def __call__(cls, *args, **kwargs):
            instance = super().__call__(*args, **kwargs)
            return instance

    class TestLexer(SimplifiedHTTPLexer, metaclass=TestType):
        name = 'test'
        aliases = ['test']
        filenames = ['*.tst']

# Generated at 2022-06-21 14:07:31.492062
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()

# Generated at 2022-06-21 14:07:41.312085
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import unittest
    from pygments.formatters import Terminal256Formatter
    fmter = Terminal256Formatter(style=Solarized256Style)
    lexer = SimplifiedHTTPLexer()
    result = pygments.highlight("GET / HTTP/1.1\nHost: localhost:8080\n\n", lexer, fmter)

# Generated at 2022-06-21 14:07:52.589441
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    """Test: method format_headers of class ColorFormatter"""
    # Setup
    import io
    fp = io.StringIO("")
    env = Environment()
    env.colors = True
    color_formatter = ColorFormatter(env, explicit_json=False,
                                     color_scheme=DEFAULT_STYLE)

    # Exercise
    color_formatter.format_headers("HTTP/1.0 200 Ok\nDate: Sat, 14 Aug 2010 "
                                   "04:30:29 GMT")

    # Verify
    actual = fp.getvalue()

# Generated at 2022-06-21 14:08:03.439245
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins.manager import PluginManager
    from httpie.context import Environment
    from httpie.input import ParseError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins.color import ColorFormatter
    plugin_manager = PluginManager()
    env = Environment(color=True, stdin=None, stdout=None, stderr=None)
    formatter = ColorFormatter(env)
    assert isinstance(formatter.get_lexer_for_body('application/json', '{\n  "hello": "world"\n}'), pygments.lexers.JsonLexer)

# Generated at 2022-06-21 14:08:13.954728
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Given the ColorFormatter object
    def get_env():
        env = Environment(
            colors=1024,
            stdout_isatty=True,
            stdin_isatty=True,
            is_windows=False,
            stdout_raw=False,
            stdin_raw=False,
        )
        env.stdout = open('/dev/null','w')
        env.stderr = None
        return env
    color_formatter = ColorFormatter(get_env())
    # When we get the correct lexer for python code
    mime = 'application/json'
    body = '{ "test" : "test", "test2": ["one", "two", "three"] }'
    lexer = color_formatter.get_lexer_for_body(mime, body)
   

# Generated at 2022-06-21 14:08:58.572002
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    SimplifiedHTTPLexer()

# Generated at 2022-06-21 14:09:00.006372
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    # noinspection PyUnusedLocal
    Solarized256Style()

# Generated at 2022-06-21 14:09:10.226027
# Unit test for function get_lexer
def test_get_lexer():
    # Note: The unit test tests the return values of a function. It does not
    #       test other side effects, for example if the function raises an
    #       error.
    #       For the most part, the side effect is the behavior of the
    #       pygments.get_lexer_for_mimetype and the pygments.lexers.get_lexer_by_name
    #       when the input argument is the list which is generated in the
    #       get_lexer function.
    assert get_lexer(mime="text/html") == pygments.lexers.get_lexer_by_name("html")
    assert get_lexer(mime="text/html; charset=utf-8") == pygments.lexers.get_lexer_by_name("html")

# Generated at 2022-06-21 14:09:20.051483
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import pytest
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters import JsonFormatter
    from httpie.output.formatters import PygmentsFormatter

    env = Environment(colors=True)
    color_formatter = ColorFormatter(env)
    json_formatter = JsonFormatter(env)

    body = '{ "mykey": "myvalue" }'
    body_formatted = color_formatter.format_body(body, 'application/json')
    assert body.strip() == json_formatter.format_body(body, 'application/json')
    assert body_formatted.strip() != body_formatted

    body = '<h1>mybody</h1>'
    body_formatted = color_formatter.format

# Generated at 2022-06-21 14:09:27.997058
# Unit test for constructor of class Solarized256Style

# Generated at 2022-06-21 14:09:38.583028
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import json
    from httpie.plugins.builtin import JSONFormatter

    class TestEnvironment:
        colors = 256
        stdout_isatty = True

    # test request content type and response content type
    colorFormatter = ColorFormatter(TestEnvironment)
    body_json = json.dumps({
        'name': 'Smith'
    })
    # test explicit_json
    assert body_json in colorFormatter.format_body(body_json, 'application/json')
    # test format_body can work with json body and not json content type
    assert body_json in colorFormatter.format_body(body_json, 'text/plain')
    # test format_body can work with json body and json content type
    assert body_json in colorFormatter.format_body(body_json, 'application/json')

    #

# Generated at 2022-06-21 14:09:39.756019
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class('solarized256') == Solarized256Style

# Generated at 2022-06-21 14:09:47.933036
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # HTTP-Request:
    request = (
        'GET /foo/bar.html HTTP/1.1\r\n'
        'Content-Type: text/plain; charset=utf-8\r\n'
    )

# Generated at 2022-06-21 14:09:50.594107
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    class ColorFormatter(object):
        def get_style_class(color_scheme):
            pass
    assert ColorFormatter.get_style_class("solarized") == Solarized256Style
    assert ColorFormatter.get_style_class("auto") == Solarized256Style

# Generated at 2022-06-21 14:09:51.873103
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    style_class = ColorFormatter.get_style_class('manni')
    assert style_class == pygments.styles.manni.ManniStyle

# Generated at 2022-06-21 14:12:12.598611
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    ColorFormatter(Environment(colors=True, style=SOLARIZED_STYLE))

# Generated at 2022-06-21 14:12:22.519587
# Unit test for function get_lexer
def test_get_lexer():
    def get_lexer(mime, explicit_json=False, body='') -> Optional[Type[Lexer]]:
        return ColorFormatter.get_lexer_for_body(mime, explicit_json, body)

    assert isinstance(get_lexer('text/plain'), TextLexer)
    assert isinstance(get_lexer('application/json'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/foo+json'), pygments.lexers.JsonLexer)
    assert isinstance(get_lexer('application/xml'), pygments.lexers.XmlLexer)
    assert isinstance(get_lexer('application/xml+whatever'), pygments.lexers.XmlLexer)

# Generated at 2022-06-21 14:12:29.314185
# Unit test for constructor of class SimplifiedHTTPLexer

# Generated at 2022-06-21 14:12:35.828370
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    env = Environment()
    formatter = ColorFormatter(env=env)
    assert not formatter.get_lexer_for_body(
        mime='application/vnd.api+json',
        body='{"data": "foobar"}',
    )
    assert formatter.get_lexer_for_body(
        mime='application/vnd.api+json',
        body='{"data": "foobar"}',
        explicit_json=True
    )

# Generated at 2022-06-21 14:12:43.364363
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import pytest

    env = Environment(colors=True)
    formatter = ColorFormatter(env)
    mime = 'application/http-request'
    headers = 'GET / HTTP/1.1\r\nHost: www.example.org\r\n'

    res = formatter.format_headers(headers)
    assert '\x1b' in res
    assert 'HTTP' in res
    assert '/' in res
    assert 'GET' in res
    assert 'Host' in res

    formatter.enabled = False
    res = formatter.format_headers(headers)
    assert '\x1b' not in res
    assert 'HTTP' in res
    assert '/' in res
    assert 'GET' in res
    assert 'Host' in res

# Generated at 2022-06-21 14:12:47.583661
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    class TestEnv:
        colors = 256
    class TestKwargs:
        pass
    color_formatter = ColorFormatter(env=TestEnv(), **TestKwargs)
    assert color_formatter.group_name == 'colors'
    assert color_formatter.formatter.get_style_defs() == \
        Terminal256Formatter(style=Solarized256Style).get_style_defs()
    assert color_formatter.http_lexer.__name__ == 'SimplifiedHTTPLexer'

# Generated at 2022-06-21 14:12:57.389046
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    req = 'GET / HTTP/1.1\nHost: example.org\nAccept-Charset: utf-8\n'
    lexer = SimplifiedHTTPLexer()
    tokens = list(lexer.get_tokens(req))
    assert len(tokens) == 6
    assert tokens[0] == (pygments.token.Name.Function, 'GET')
    assert tokens[1] == (pygments.token.Text, ' ')
    assert tokens[2] == (pygments.token.Name.Namespace, '/')
    assert tokens[3] == (pygments.token.Text, ' ')
    assert tokens[4] == (pygments.token.Keyword.Reserved, 'HTTP')
    assert tokens[5] == (pygments.token.Operator, '/')

# Generated at 2022-06-21 14:13:06.292507
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter = ColorFormatter(Environment(),
                                     explicit_json=False,
                                     color_scheme=DEFAULT_STYLE)
    headers = color_formatter.format_headers("HTTP/2 200\r\n\
Content-Type: text/plain\r\n\
Content-Length: 11\r\n\
\r\n")