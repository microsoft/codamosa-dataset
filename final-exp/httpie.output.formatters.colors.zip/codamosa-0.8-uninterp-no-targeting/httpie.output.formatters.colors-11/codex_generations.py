

# Generated at 2022-06-21 14:03:12.507870
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    assert isinstance(SimplifiedHTTPLexer(), pygments.lexer.RegexLexer)

# Generated at 2022-06-21 14:03:19.897196
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    '''
    Testing ColorFormatter.format_body method (ColorFormatter.py)
    with every mime-type in supported_types
    '''

    supported_types = {'json', 'http', 'html', 'css', 'yaml', 'xml', 'javascript'}
    result = ''
    for mime_type in supported_types:
        result = mime_type + '\n'
        assert ColorFormatter._format_body(result, mime_type) == result

# Generated at 2022-06-21 14:03:29.805542
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from . import main

    color_formatter = ColorFormatter(
        env=main.get_environment(),
        explicit_json=False,
        color_scheme='default'
    )
    assert type(color_formatter.formatter) != Terminal256Formatter

    color_formatter = ColorFormatter(
        env=main.get_environment(),
        explicit_json=False,
        color_scheme='256'
    )
    assert type(color_formatter.formatter) == Terminal256Formatter

    color_formatter = ColorFormatter(
        env=main.get_environment(),
        explicit_json=False,
        color_scheme='solarized'
    )
    assert type(color_formatter.get_style_class('solarized')) == type(Solarized256Style)
    
   

# Generated at 2022-06-21 14:03:35.050095
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    """
    Test that color headers are correct
    """
    from httpie.core import main
    import httpie.cli
    import httpie.plugins
    import re

    _, stdout, _ = main(args=[])
    lines = stdout.readlines()

    # Assert that the only style line starts with '\x1b['
    assert len(list(filter(lambda x: re.match('\x1b\[.*m', x), lines))) == 1

    # Assert that the only style line ends with 'm'
    assert len(list(filter(lambda x: re.match('.*m$', x), lines))) == 1

# Generated at 2022-06-21 14:03:46.102313
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    import httpie.compat
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.plugins import builtin

    class DummyFormatter(FormatterPlugin):
        def get_headers(self, headers):
            return headers
        def format_body(self, body, mime):
            return 'dummy'
    class DummyEnvironment(Environment):
        colors = 256
        stdin_isatty = False
        stdout_isatty = False
        is_windows = False
    # JSON
    env = DummyEnvironment()
    def test_json():
        formatter = DummyFormatter(env, explicit_json=False)
        assert formatter.format_body('{"foo":"bar"}', 'application/json') == 'dummy'

# Generated at 2022-06-21 14:03:55.940760
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.context import Environment

    args = parser.parse_args([])
    env = Environment(vars(args))

    if is_windows:
        # Colors on Windows via colorama don't look that
        # great and fruity seems to give the best result there.
        args.color_scheme = 'fruity'
    else:
        args.color_scheme = 'solarized'

    args.print_body = True
    args.output_options = None

    # This function is invoked by the main method and we need to set the
    # exit status code, so we wrap it into a try/except block. If an
    # exception is raised, set its exit status.

# Generated at 2022-06-21 14:03:57.319775
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/vnd.python.pygments-formatter') \
        is pygments.lexers.get_lexer_by_name('py')

# Generated at 2022-06-21 14:04:03.960846
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    env = Environment()
    formatter = ColorFormatter(env)
    body_1 = "{\n    \"title\": \"hello world\"\n}"
    body_2 = """<html>
    <body>
        <h1>Hello World</h1>
    </body>
</html>""".strip()
    body_3 = "hello, world"
    mime_1 = "application/json"
    mime_2 = "text/html"
    mime_3 = "text/plain"
    assert body_1 == formatter.format_body(body_1, mime_1)
    assert body_2 == formatter.format_body(body_2, mime_2)
    assert body_3 == formatter.format_body(body_3, mime_3)

# Generated at 2022-06-21 14:04:12.889678
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    from httpie.context import Environment
    from httpie.plugins import PluginManager
    plugin_manager = PluginManager()
    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        stdin_isatty=True,
        stdout_isatty=True,
        stderr_isatty=True,
        colors=256,
    )
    formatter = ColorFormatter(env, color_scheme=DEFAULT_STYLE, explicit_json=False)
    assert formatter.explicit_json == False

test_ColorFormatter()

# Generated at 2022-06-21 14:04:17.204122
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()

    for t, color in style.styles.items():
        assert isinstance(t, pygments.token.Token)
        assert isinstance(color, str)  # Color style can be a string or a
                                       # tuple

# Generated at 2022-06-21 14:04:32.999160
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.context import Environment

    env = Environment()
    env.stdout_isatty = True  # so that colorizer is enabled
    cf = ColorFormatter(env, explicit_json=False, color_scheme='monokai')

    # check different mime types
    assert cf.format_body('body', 'application/json').strip() == 'body'
    assert cf.format_body('body', 'application/json; charset=utf-8').strip() == 'body'
    assert cf.format_body('body', 'application/javascript; charset=utf-8').strip() == 'body'
    assert cf.format_body('body', 'text/json').strip() == 'body'

# Generated at 2022-06-21 14:04:43.408607
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    import requests
    import tempfile

    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPPasswordAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONStream
    from httpie.plugins.builtin import PlainTextAuth
    from httpie.plugins.builtin import PrettyJSONStream
    from httpie.plugins import FormatterPlugin

    # \n is needed in case of a tuple with a single value
    input_headers = ("Accept: application/json\n"
                "User-Agent: HTTPie/0.11.2\n"
                "Connection: keep-alive")

    # get the output from the HTTPie pipeline

# Generated at 2022-06-21 14:04:49.119093
# Unit test for function get_lexer
def test_get_lexer():
    assert pygments.lexers.get_lexer_for_mimetype('application/json') == \
        pygments.lexers.get_lexer_by_name('json')
    assert get_lexer('application/json') == \
        pygments.lexers.get_lexer_by_name('json')
    assert pygments.lexers.get_lexer_for_mimetype('application/xml') == \
        pygments.lexers.get_lexer_by_name('xml')
    assert get_lexer('application/xml') == \
        pygments.lexers.get_lexer_by_name('xml')
    assert pygments.lexers.get_lexer_for_mimetype('application/x-sh') == \
        pygments.lexers.get_lexer_

# Generated at 2022-06-21 14:04:52.120653
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # constructor
    simplified_http_lexer = SimplifiedHTTPLexer()
    assert(simplified_http_lexer is not None)


# Generated at 2022-06-21 14:04:53.546556
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    assert lexer

# Generated at 2022-06-21 14:05:04.825097
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.formatters import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.output import BINARY_SUPPRESSED_NOTICE

    class TestJsonFormatter(FormatterPlugin, JSONFormatter):
        def __init__(self):
            FormatterPlugin.__init__(self)
            JSONFormatter.__init__(self)
            self.kwargs = {}

        def __call__(self, *args, **kwargs):
            self.kwargs = kwargs
            return FormatterPlugin.__call__(self, *args, **kwargs)

    class TestColorFormatter(FormatterPlugin):
        def __init__(self, env=None):
            FormatterPlugin.__init__(self)
            self.env = env
            self.kwargs = {}


# Generated at 2022-06-21 14:05:15.235121
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():

    body = '{"status": "Enabled","neverExpire": false,"created": 1588270936723,"expireAt": 1589080221488}'
    mime = 'application/json;charset=utf-8'
    assert get_lexer(mime, False, body).name == 'JSON'
    assert get_lexer(mime, True, body).name == 'JSON'
    assert get_lexer(mime, True, body).name == 'JSON'
    assert get_lexer(mime, False, body).name == 'JSON'

    mime = 'application/json'
    assert get_lexer(mime, True, body).name == 'JSON'

# Generated at 2022-06-21 14:05:22.990049
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    # Request-Line
    assert [t[0] for t in SimplifiedHTTPLexer().get_tokens('GET / HTTP/1.1')] == [
        pygments.token.Name.Function,
        pygments.token.Text,
        pygments.token.Name.Namespace,
        pygments.token.Text,
        pygments.token.Keyword.Reserved,
        pygments.token.Operator,
        pygments.token.Number
    ]

    # Response Status-Line

# Generated at 2022-06-21 14:05:34.648498
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Initialization
    formatter = ColorFormatter(Environment())
    formatter.enabled = True
    formatter.explicit_json = False

    # First test
    assert formatter.format_body(body="<html><h1>Index</h1></html>", mime="text/html") == "<html><h1>Index</h1></html>"
    assert formatter.format_body(body="{'name':'John','age':30,'car':null}", mime="application/json") == "{'name':'John','age':30,'car':null}"

# Generated at 2022-06-21 14:05:43.849922
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from io import StringIO
    from httpie.formatter import COLOR_SCHEMES
    from httpie.output.streams import WRITE_FUNCS_BY_COLOR_SCHEME
    from httpie import formatter

    test_str = '''
    {
        "key1": "value1",
        "key2": "value2"
        
    }
    '''

    def run_test(color_scheme, explicit_json, body_schema, except_schema):
        test_buffer_out = StringIO()
        test_color_out = formatter.get_formatter(
            WRITE_FUNCS_BY_COLOR_SCHEME[color_scheme],
            Environment(),
            color_scheme=color_scheme
        )(test_buffer_out)

        color_formatter

# Generated at 2022-06-21 14:05:49.056141
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style()

# Generated at 2022-06-21 14:05:49.642708
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:06:01.829857
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    # Arrange
    formatter = ColorFormatter(env=None)
    headers = '''HTTP/1.1 200 OK
Server: nginx
Date: Tue, 23 Jun, 2020 18:29:49 GMT
Content-Type: application/json
Content-Length: 36
Connection: keep-alive
X-Powered-By: PHP/5.4.4-14+deb7u7
Expires: Thu, 01 Jan 1970 00:00:00 GMT
Cache-Control: no-cache
Pragma: no-cache

'''
    # Act
    formatted = formatter.format_headers(headers)
    # Assert

# Generated at 2022-06-21 14:06:11.949259
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from io import StringIO
    from httpie.output.formatters.colors import ColorFormatter
    import environment
    import requests
    env = environment.Environment()
    http_response_body = StringIO()
    http_response_body.write("""HTTP/1.1 200 OK\r\n""")
    http_response_body.write("""Date: Thu, 09 Jan 2020 20:36:03 GMT\r\n""")
    http_response_body.write("""Content-Type: text/html; charset=utf-8\r\n""")
    http_response_body.write("""Content-Length: 145\r\n""")
    http_response_body.write("""Connection: close\r\n""")
    http_response_body.write("""Server: nginx\r\n""")


# Generated at 2022-06-21 14:06:12.498003
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:06:13.844940
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-21 14:06:14.574120
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    assert Solarized256Style

# Generated at 2022-06-21 14:06:25.772264
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(None, explicit_json=False, color_scheme='fruity')

    mime = 'application/json'
    assert str(type(formatter.get_lexer_for_body(mime, ''))) == "<class 'pygments.lexers.data.JsonLexer'>"

    mime = 'application/json;charset=UTF-8'
    assert str(type(formatter.get_lexer_for_body(mime, ''))) == "<class 'pygments.lexers.data.JsonLexer'>"

    mime = 'application/hal+json'
    assert str(type(formatter.get_lexer_for_body(mime, ''))) == "<class 'pygments.lexers.data.JsonLexer'>"


# Generated at 2022-06-21 14:06:33.552484
# Unit test for function get_lexer
def test_get_lexer():
    # Type
    assert get_lexer('foo/bar') is None
    # Subtype
    assert get_lexer('application/foo') is None
    assert get_lexer('application/json') is not None
    # Subtype + Suffix
    assert get_lexer('text/x-foo') is None
    assert get_lexer('text/x-python') is not None
    # Explicit JSON
    assert get_lexer('text/plain', True, '[{"a": 42}]') is not None

# Generated at 2022-06-21 14:06:38.688637
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    '''
    Solarized256Style_test
    ----------------------
    A unit test to check if the default style is Solarized256Style
    '''
    color_formatter = ColorFormatter(Environment())
    solarized256_style = color_formatter.get_style_class(SOLARIZED_STYLE)
    assert solarized256_style == Solarized256Style

# Generated at 2022-06-21 14:06:54.496140
# Unit test for function get_lexer
def test_get_lexer():
    l = get_lexer('application/json')
    assert l.__name__ == 'JSONLexer'

    l = get_lexer('application/json', explicit_json=True)
    assert l.__name__ == 'JSONLexer'

    l = get_lexer('application/vnd.api+json',
                  explicit_json=True,
                  body='{"foo":"bar"}')
    assert l.__name__ == 'JSONLexer'

    l = get_lexer('application/vnd.api+json',
                  explicit_json=True,
                  body='foo bar')
    assert not l

    l = get_lexer('application/vnd.api+json',
                  body='foo bar')
    assert not l

# Generated at 2022-06-21 14:07:02.091613
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.core import parse_items

    env = Environment(colors=256, stdin=None, stdout=None)
    formatter = ColorFormatter(env)

    def do_test(mime, body, lexer_name=None, should_highlight=True):
        lexer = formatter.get_lexer_for_body(mime, body)
        if lexer:
            assert lexer.name == lexer_name
        else:
            assert not should_highlight

    do_test('application/json', '{"foo": "bar"}', 'json')
    do_test('application/json', '{invalid')
    do_test('application/xml', '<root></root>', 'xml')
    do_test('text/plain', 'hello, world!')

# Generated at 2022-06-21 14:07:04.658479
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    # Arrange
    # verify the expected exception is raised
    env = Environment()
    formatter = ColorFormatter(env)
    mime = 'text/plain'
    body = '{"key": "value"}'
    expected = pygments.lexers.get_lexer_by_name('json')
    # Act

# Generated at 2022-06-21 14:07:13.606291
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    colorer = ColorFormatter(Environment(colors=True))
    assert colorer.format_body('{a}', 'application/json') == '\x1b[34m{\n ' \
                                                             '\x1b[39m\x1b[37ma\x1b[39m' \
                                                             '\x1b[34m\n}' \
                                                             '\x1b[39m'
    assert colorer.format_body('{a}', 'application/atom+xml') == '{a}'
    assert colorer.format_body('<a>', 'application/xml') == '<a>'
    assert colorer.format_body('<a>', 'application/a') == '<a>'

# Generated at 2022-06-21 14:07:18.363838
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    obj = ColorFormatter(None, False)
    assert obj.explicit_json == False
    assert obj.formatter.__class__.__name__ == "TerminalFormatter"
    assert obj.http_lexer.__class__.__name__ == "SimplifiedHTTPLexer"

# Generated at 2022-06-21 14:07:21.366014
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    style = Solarized256Style()
    assert style.background_color == Solarized256Style.BASE03
    assert style.styles[pygments.token.Keyword] == Solarized256Style.GREEN

# Generated at 2022-06-21 14:07:29.389632
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(Environment())

    def test(mime, body, lexer_class):
        lexer = color_formatter.get_lexer_for_body(mime, body)
        assert lexer is lexer_class

    test('application/json', '{}', pygments.lexers.JsonLexer)
    test('application/json', '', pygments.lexers.JsonLexer)
    assert color_formatter.get_lexer_for_body('application/json', 'bad') is None
    test('application/json', '{}', pygments.lexers.JsonLexer)
    test('application/json', '{}', pygments.lexers.JsonLexer)

# Generated at 2022-06-21 14:07:39.824930
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.core import httpsession

    env = Environment()
    env.colors = 256

    sess = httpsession.HTTPSession()
    fmtr = ColorFormatter(env=env)

    body = '{"Hello": "World"}'
    mime = 'text/json'
    res = fmtr.format_body(body=body, mime=mime)
    assert res.strip('\n').endswith(body)

    body = '{"Hello": "World"}'
    mime = 'image/png'
    res = fmtr.format_body(body=body, mime=mime)
    assert res.strip('\n').endswith(body)

    body = '<html><body>Hello World</body></html>'
    mime = 'text/html'
   

# Generated at 2022-06-21 14:07:51.330061
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    # Given
    formatter = ColorFormatter(env=None)
    body = """{"id":1, "name":"test1"}\n{"id":2, "name":"test2"}"""
    mime = "application/json"
    # When
    result = formatter.format_body(body=body, mime=mime)
    # Then

# Generated at 2022-06-21 14:07:58.696249
# Unit test for method format_headers of class ColorFormatter

# Generated at 2022-06-21 14:08:12.473204
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    import httpie.cli.json
    from httpie.plugins import FormatterPlugin

    env = httpie.cli.Environment(
        colors = 256,
        formatter_plugins = [FormatterPlugin],
        stdin_isatty = True
    )
    formatter = ColorFormatter(
        env,
        explicit_json = False,
        color_scheme = DEFAULT_STYLE
    )

    assert formatter.get_lexer_for_body(
        mime = 'text/csv',
        body = '"test","test"'
    ).name == 'CSV'

    assert formatter.get_lexer_for_body(
        mime = 'text/html',
        body = '<!DOCTYPE html>\n<html>\n<head></head></head>'
    ).name

# Generated at 2022-06-21 14:08:15.137278
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():  # pragma: no cover
    assert Solarized256Style.background_color == '#1c1c1c'
    assert Solarized256Style.styles[pygments.token.Token.Other] == '#d75f00'

# Generated at 2022-06-21 14:08:15.912651
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    pass

# Generated at 2022-06-21 14:08:22.969622
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    from httpie.clients import json
    from httpie.compat import is_windows
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    if is_windows:
        assert ColorFormatter(Environment(), {}).get_style_class('auto') == pygments.styles.get_style_by_name('fruity')
    else:
        assert ColorFormatter(Environment(), {}).get_style_class('auto') == pygments.styles.get_style_by_name('default')
    assert ColorFormatter(Environment(), {}).get_style_class('solarized') == Solarized256Style

# Generated at 2022-06-21 14:08:29.414905
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    #expected_formatter = TerminalFormatter(bg=None, encoding='utf-8',
    #                                       style=TerminalStyle)
    #expected_lexer = HttpLexer()
    expected_env=Environment()
    expected_env.colors = 256
    #expected_style = 'fruity'
    formatter = ColorFormatter(expected_env, color_scheme=None)
    #assert formatter.formatter == expected_formatter
    #assert formatter.http_lexer == expected_lexer
    #assert formatter.style == expected_style

# Generated at 2022-06-21 14:08:31.724562
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    s = Solarized256Style()
    assert s.styles[pygments.token.Token] == "#8a8a8a"

# Generated at 2022-06-21 14:08:42.064902
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    formatter = ColorFormatter(Environment())

    css_lexer = formatter.get_lexer_for_body(mime='text/css', body='a{color:red}')
    assert isinstance(css_lexer, pygments.lexers.get_lexer_by_name('css'))
    assert isinstance(css_lexer, pygments.lexers.CssLexer)

    json_lexer = formatter.get_lexer_for_body(mime='application/json', body='{"foo":"bar"}')
    assert isinstance(json_lexer, pygments.lexers.get_lexer_by_name('json'))
    assert isinstance(json_lexer, pygments.lexers.JsonLexer)

    html_lexer = formatter.get_lexer_for_

# Generated at 2022-06-21 14:08:50.825205
# Unit test for function get_lexer
def test_get_lexer():
    assert get_lexer('application/json')
    assert get_lexer('application/json+a')
    assert get_lexer('application/json+a', body='{')

    assert get_lexer('application/xml')
    assert get_lexer('application/xml+a')
    assert not get_lexer('application/xml+a', body='{')

    assert get_lexer('text/plain')
    assert get_lexer('text/plain+a')
    assert not get_lexer('text/plain+a', body='{')

# Generated at 2022-06-21 14:08:59.897557
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    lexer = SimplifiedHTTPLexer()
    tokens = lexer.get_tokens_unprocessed('GET / HTTP/1.1')
    assert list(tokens) == [
        (pygments.token.Name.Function, 'GET'),
        (pygments.token.Text, ' '),
        (pygments.token.Name.Namespace, '/'),
        (pygments.token.Text, ' '),
        (pygments.token.Keyword.Reserved, 'HTTP'),
        (pygments.token.Operator, '/'),
        (pygments.token.Number, '1.1'),
        (pygments.token.Text, '\n'),
    ]

    tokens = lexer.get_tokens_unprocessed('Content-Type: text/plain')

# Generated at 2022-06-21 14:09:06.879498
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    color_formatter = ColorFormatter(Environment(colors=256))
    lexer = color_formatter.get_lexer_for_body('application/json', '')
    assert lexer == pygments.lexers.get_lexer_by_name('json')
    lexer = color_formatter.get_lexer_for_body('text/html', '')
    assert lexer == pygments.lexers.get_lexer_by_name('html')

# Generated at 2022-06-21 14:09:29.416277
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    content_types = ['text/html', 'text/plain', 'text/css', 'application/json', 'application/javascript', 'image/gif']
    expected_result = ["text/html", "text/plain", "text/css", "application/json", "text/plain", "text/plain"]
    body = "<html><body>Hi!</body></html>"

    for i in range(len(content_types)):
        formatter = ColorFormatter(None)
        assert formatter.format_body(body, content_types[i]).__contains__(expected_result[i])

# Generated at 2022-06-21 14:09:36.757843
# Unit test for function get_lexer
def test_get_lexer():
    """
    The first test should pass:
        - with the local lexer being picked
        - with the fallback lexer being picked
        - with the TextLexer if name/type cannot be resolved
    """
    assert get_lexer('text/plain') is None
    lexer = get_lexer('text/html')
    assert lexer.name == 'HTML'
    lexer = get_lexer('application/x-httpd-php')
    assert lexer.name == 'Text only'

# Generated at 2022-06-21 14:09:38.236994
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    import sys
    pygments.lexers.get_lexer_by_name("http")
    print("Test passed")

# Generated at 2022-06-21 14:09:46.291228
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from pygments.lexers.markup import HtmlLexer
    from pygments.formatters.terminal import TerminalFormatter
    import pygments
    formatter = TerminalFormatter(
        style=Solarized256Style
    )
    assert ColorFormatter.format_body(
        "foo bar body",
        "text/html",
        env=Environment(colors=256, is_windows=False),
    ) == "foo bar body"

# Generated at 2022-06-21 14:09:47.507606
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    env = Environment(colors=True)
    ColorFormatter(env)

# Generated at 2022-06-21 14:09:48.045761
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:09:50.693008
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    color_formatter = ColorFormatter(None, None)
    headers = 'Content-Length: 123'
    result = color_formatter.format_headers(headers)
    assert result == 'Content-Length: \x1b[38;5;49m123'

# Generated at 2022-06-21 14:09:53.653815
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    color_formatter = ColorFormatter(Environment(), explicit_json=True, color_scheme=SOLARIZED_STYLE)
    assert color_formatter.get_style_class(SOLARIZED_STYLE) == Solarized256Style

# Generated at 2022-06-21 14:09:54.728620
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    ss = Solarized256Style()
    assert(ss)

# Generated at 2022-06-21 14:09:56.484210
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    assert ColorFormatter.get_style_class(SOLARIZED_STYLE) is Solarized256Style

# Generated at 2022-06-21 14:10:50.617324
# Unit test for method format_headers of class ColorFormatter
def test_ColorFormatter_format_headers():
    from httpie.compat import is_windows
    from httpie.plugins import PluginManager
    from httpie import ExitStatus
    from utils import http, HTTP_OK, COLOR, CRLF
    from fixtures import httpbin

    pm = PluginManager()
    if is_windows:
        pm.add_plugin(ColorFormatter())
    else:
        pm.add_plugin(ColorFormatter, color_scheme=AUTO_STYLE)
    pm.load_builtin_plugins()

    env = pm.get_env()
    color_formatter = pm.get_formatter('colors')

    # get

# Generated at 2022-06-21 14:10:51.191773
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    Solarized256Style()

# Generated at 2022-06-21 14:10:52.670674
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter('auto')
    assert color_formatter.color_scheme == 'auto'

# Generated at 2022-06-21 14:10:56.933942
# Unit test for constructor of class SimplifiedHTTPLexer
def test_SimplifiedHTTPLexer():
    s = SimplifiedHTTPLexer()
    assert list(s.get_tokens('GET /example.com HTTP/1.1'))
    assert list(s.get_tokens('Accept: text/html'))
    assert list(s.get_tokens('Accept-Language: en-US'))
    assert list(s.get_tokens('HTTP/1.1 200 OK\r\n'))

# Generated at 2022-06-21 14:11:07.762957
# Unit test for method get_lexer_for_body of class ColorFormatter
def test_ColorFormatter_get_lexer_for_body():
    from httpie.plugins import FormatterPluginManager
    from httpie.formatters import FORMATS

    mime = 'application/json'
    explicit_json = False
    body = ''
    env = Environment()
    color_scheme = 'solarized'
    # env.colors = True
    # formatter_name = FORMATS[1]
    formatters = FormatterPluginManager()
    formatters.formatters = {
        'json': None,
        'colors': ColorFormatter(env, explicit_json, color_scheme)
    }
    formatters.formatters['colors'].format_body(body, mime)
    # print(formatters.formatters['colors'].format_body(body, mime))
    # print(formatters.formatters['colors'].get_lexer_

# Generated at 2022-06-21 14:11:14.980302
# Unit test for method format_body of class ColorFormatter
def test_ColorFormatter_format_body():
    from httpie.utils import get_mimetype_from_headers
    from tests.test_client import MockEnvironment, MockResponse

    header_dict = {'content-type':'application/json;charset:utf-8'}
    response = MockResponse(content='response_body', headers=header_dict)
    env = MockEnvironment(colors=True)
    colorizer = ColorFormatter(env=env, stdout=None)
    body = colorizer.format_body(mime=get_mimetype_from_headers(header_dict), body=response.content.decode())
    assert body == response.content.decode()


# Generated at 2022-06-21 14:11:19.549768
# Unit test for constructor of class ColorFormatter
def test_ColorFormatter():
    color_formatter = ColorFormatter(Environment())
    # check that explicit_json is initialized to False
    assert color_formatter.explicit_json == False
    # check that formatter and http_lexer are initialized
    assert color_formatter.formatter != None
    assert color_formatter.http_lexer != None



# Generated at 2022-06-21 14:11:30.619860
# Unit test for function get_lexer

# Generated at 2022-06-21 14:11:31.938116
# Unit test for constructor of class Solarized256Style
def test_Solarized256Style():
    instance = Solarized256Style()
    assert instance



# Generated at 2022-06-21 14:11:35.551200
# Unit test for method get_style_class of class ColorFormatter
def test_ColorFormatter_get_style_class():
    cf = ColorFormatter()
    assert isinstance(cf.get_style_class(SOLARIZED_STYLE), Solarized256Style)
    # TODO
    #assert isinstance(cf.get_style_class(DEFAULT_STYLE), Solarized256Style)