

# Generated at 2022-06-23 14:27:54.134397
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.some_attr = 'A'

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert 'A' == a1.some_attr

# Example of usage of singleton class
if __name__ == '__main__':
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.some_attr = 'A'

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert 'A' == a1.some_attr

# Generated at 2022-06-23 14:28:01.868149
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # pylint: disable=R0903
    class TestSingleton(object):
        '''Test class for Singleton metaclass'''
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    # Provide a mock for ansible.module_utils.six
    class MockAnsibleModuleUtilsSix(object):
        @staticmethod
        def PY2():
            return False

    # Provide a mock for ansible.module_utils.urls.open_url

# Generated at 2022-06-23 14:28:07.161742
# Unit test for constructor of class Singleton
def test_Singleton():
    class Dog:
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    if __name__ == '__main__':
        d1 = Dog('Fido')
        d2 = Dog('Rover')

        assert id(d1) == id(d2)
        print('Singleton works')

# Generated at 2022-06-23 14:28:13.614463
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Singleton1(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 0

        def incr_x(self, value):
            self.x += value
            return self.x

        def get_x(self):
            return self.x

    s1 = Singleton1()
    assert s1 == Singleton1()

    s1.incr_x(10)
    assert s1 == Singleton1()
    assert s1.get_x() == 10
    assert Singleton1().get_x() == 10

# Generated at 2022-06-23 14:28:22.304403
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingletonClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = 'MySingletonClass'
            self.value = 0
    # Instantiate class "MySingletonClass"
    obj1 = MySingletonClass()
    # Increment obj1.value 3 times
    for i in xrange(3):
        obj1.value += 1
    # obj2 should be the same as obj1
    obj2 = MySingletonClass()
    assert obj1.name == obj2.name
    assert obj1.value == obj2.value
    # Assign value 3 to obj2.value
    obj2.value = 3
    # Check if obj1.value is also 3
    assert obj1.value == obj2.value
    # Instantiate class "Singleton" with

# Generated at 2022-06-23 14:28:26.469829
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 2

    a = Test()
    b = Test()
    assert a.foo == 2
    assert b.foo == 2
    assert a is b

# Generated at 2022-06-23 14:28:34.050013
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(metaclass=Singleton):
        pass

    # Assert there is not singleton instance
    assert SingletonTest._Singleton__instance is None

    # Instantiate singleton
    singleton1 = SingletonTest()
    assert isinstance(singleton1, SingletonTest)

    # Assert singleton instance has been created
    assert isinstance(SingletonTest._Singleton__instance, SingletonTest)

    # Another instance return the same singleton instance
    singleton2 = SingletonTest()
    assert singleton1 == singleton2

    # Test str(singleton) is defined
    try:
        str(SingletonTest())
    except:
        assert False, "str(singleton) is not defined"

# Generated at 2022-06-23 14:28:40.052912
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 'bar'

    a = MySingleton()
    assert a.foo == 'bar'
    b = MySingleton()
    assert b is a
    assert a.foo == 'bar'

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:28:47.853266
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, *args):
            self.args = args

    mysingleton = MySingleton(*[1, 2, 3, 4])
    assert mysingleton.args == (1, 2, 3, 4), "Singleton object has wrong constructor args"

    mysingleton2 = MySingleton(*[5, 6, 7, 8])
    assert mysingleton2.args == (1, 2, 3, 4), "Singleton object does not share state!"
    assert mysingleton2 is mysingleton, "Singleton object instantiated more than once!"

# Generated at 2022-06-23 14:28:51.712846
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingletonClass(object):
        __metaclass__ = Singleton

    x1 = TestSingletonClass()
    x2 = TestSingletonClass()
    assert x1 is x2
    assert id(x1) == id(x2)



# Generated at 2022-06-23 14:28:54.402826
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = 0

    a1 = A()
    a1.a = 1
    a2 = A()
    assert a1.a == a2.a
    assert id(a1) == id(a2)


# Generated at 2022-06-23 14:28:59.243477
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClassSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1
            self.b = 2

    a = MyClassSingleton()
    b = MyClassSingleton()

    assert a == b
    assert a.a == b.a
    assert a.b == b.b

# Generated at 2022-06-23 14:29:03.945503
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    a = A('s3cret')
    b = A('pub1ic')

    assert a.val == 's3cret'
    assert a is b

# Generated at 2022-06-23 14:29:08.912266
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test1(object):
        __metaclass__ = Singleton

        def __init__(self, bar):
            self.bar = bar

    class Test2(object):
        __metaclass__ = Singleton

        def __init__(self, bar):
            self.bar = bar

    t1 = Test1('test')
    t2 = Test2('test')

    assert id(t1) == id(Test1('test'))
    assert id(t2) == id(Test2('test'))
    assert id(t1) != id(t2)

    t2.bar = 'foo'

    assert id(t2) == id(Test2('foo'))

# Generated at 2022-06-23 14:29:13.217915
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest1(object):
        __metaclass__ = Singleton

    x = SingletonTest1()
    y = SingletonTest1()

    assert x == y, "Singleton instantiation error"



# Generated at 2022-06-23 14:29:15.716658
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(metaclass=Singleton):
        pass

    s1 = SingletonTest()
    s2 = SingletonTest()
    assert s1 is s2

# Generated at 2022-06-23 14:29:17.455313
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import doctest
    from .ansible_module_common import AnsibleModule, DummyAnsibleModule
    doctest.testmod(AnsibleModule)
    doctest.testmod(DummyAnsibleModule)

# Generated at 2022-06-23 14:29:21.341369
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    # ensure a1 and a2 are the same instance
    assert a1 == a2
    # ensure a1 and a2 have same id
    assert id(a1) == id(a2)


# Generated at 2022-06-23 14:29:24.172263
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class OldClass(object):
        __metaclass__ = Singleton

    old1 = OldClass()
    old2 = OldClass()
    old3 = OldClass()

    assert old1 == old2
    assert old1 == old3
    assert old2 == old3

    return True



# Generated at 2022-06-23 14:29:35.175193
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.compat.tests import unittest

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = "TestSingleton"

    self.assertFalse(hasattr(TestSingleton, 'instance'))
    self.assertTrue(hasattr(TestSingleton, '__instance'))

    a = TestSingleton()
    self.assertTrue(isinstance(a, TestSingleton))

    b = TestSingleton()
    self.assertTrue(isinstance(b, TestSingleton))
    self.assertIs(a, b)


if __name__ == '__main__':
    from ansible.compat.tests import unittest
    unittest.main()

# Generated at 2022-06-23 14:29:44.030397
# Unit test for constructor of class Singleton
def test_Singleton():
    # from dynamic_inventory_sources import DynamicInventorySource
    from dynamic_inventory_source import DynamicInventorySource
    from inventory_sources import InventorySources
    from inventory_sources import InventorySourcesFactory
    from inventory_sources import InventorySourceFactory

    # class DummyInventorySource(DynamicInventorySource):
    #     def __init__(self):
    #         super(DummyInventorySource, self).__init__()
    class DummyInventorySource(DynamicInventorySource):
        def __init__(self):
            super(DummyInventorySource, self).__init__()

        def find_hosts(self, pattern, config):
            return []

    def dummy(name, config):
        return DummyInventorySource()

    InventorySources.add_source('dummy', dummy)

    # # Create an instance

# Generated at 2022-06-23 14:29:47.959576
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self):
            super(C, self).__init__()
            self.foo = 1

    assert C().foo == 1
    assert C().foo == 1



# Generated at 2022-06-23 14:29:52.829020
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    s1 = MySingleton()
    s2 = MySingleton()

    assert isinstance(s1, MySingleton)
    assert isinstance(s2, MySingleton)

    assert s1 is s2

# Generated at 2022-06-23 14:29:56.900804
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    instances = []
    # pylint: disable=missing-docstring
    class A:
        __metaclass__ = Singleton
        def __init__(self):
            instances.append(self)

    a = A()
    b = A()
    assert instances == [a]
    assert a is b
    assert instances[0] is b


# Generated at 2022-06-23 14:29:59.776438
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    a = Foo()
    b = Foo()

    assert a is b

# Generated at 2022-06-23 14:30:03.445321
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.x = "test"

    a = TestSingleton()
    b = TestSingleton()
    assert a == b

# Generated at 2022-06-23 14:30:13.683883
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestA(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    class TestB(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestA('John')
    assert a.name == 'John'
    b = TestB('Mary')
    assert b.name == 'Mary'

    # test multi-thread access to class instances
    import queue
    import threading
    def hit(q, cls, args, kwargs):
        instance = cls(*args, **kwargs)
        assert instance.name == a.name
        q.put(instance)

    q = queue.Queue()

# Generated at 2022-06-23 14:30:20.134289
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            # no lock needed in a singleton
            self.other = "test"

    instance = MyClass()
    MyClass.__instance = None

    # Make sure it's the same instance
    instance2 = MyClass()
    assert id(instance) == id(instance2)

    # Make the instance None
    MyClass.__instance = None
    # Create a new instance
    instance3 = MyClass()
    assert id(instance) != id(instance3)

    print('Singleton class constructor ok.')


# Generated at 2022-06-23 14:30:23.013934
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(Singleton):
        def __init__(self, arg):
            self.arg = arg

    a1 = A(1)
    assert a1.arg == 1

    a2 = A(2)
    assert a2.arg == 1

# Generated at 2022-06-23 14:30:28.115741
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, foo):
            self.var = foo
    def set_var(x):
        myinst.var = x
    def get_var():
        return myinst.var
    myinst = MyClass("first init call")
    myinst = MyClass("second init call")
    set_var("myvar")
    assert get_var() == "myvar"

# Generated at 2022-06-23 14:30:32.449787
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.my_list = []
    foo = MyClass()
    foo.my_list.append('bar')
    foo2 = MyClass()
    foo2.my_list.append('baz')
    assert len(foo2.my_list) == 2
    assert foo is foo2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:30:36.341781
# Unit test for constructor of class Singleton
def test_Singleton():
    print("Start test Singleton......")
    class MyClass(object):
        __metaclass__ = Singleton
    a = MyClass()
    b = MyClass()
    if a == b:
        print("a == b")
    else:
        print("a != b")
    print("End test Singleton......")


# Generated at 2022-06-23 14:30:41.090639
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self._name = name
    instance1 = TestSingleton("instance1")
    instance2 = TestSingleton("instance2")
    assert instance1 == instance2

# Generated at 2022-06-23 14:30:42.417295
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    x = A()
    assert x == A()

# Generated at 2022-06-23 14:30:50.506624
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert(Foo() is Foo())

    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    foo1 = Foo(42)
    foo2 = Foo(43)
    assert(foo1 is foo2)
    assert(foo1.value == 42)
    assert(foo2.value == 42)


# Generated at 2022-06-23 14:30:54.231297
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.errors import AnsibleError

    class TestSingleton:
        __metaclass__ = Singleton
        def __init__(self):
            pass

    assert TestSingleton() is TestSingleton()
    assert TestSingleton() is not TestSingleton('a')

# Generated at 2022-06-23 14:31:00.763397
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a class Foo with singleton functionality
    class Foo(object):
        """Class to be used for testing Singleton functionality
        """
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

        def __str__(self):
            return "Foo[%s]" % self.name

    f1 = Foo("one")
    f2 = Foo("two")

    assert f1 is f2



# Generated at 2022-06-23 14:31:09.314588
# Unit test for constructor of class Singleton
def test_Singleton():
    from types import ModuleType

    with open('test_singleton_module.py','w') as f:
        f.write('from ansible.module_utils._text import to_bytes\n')
        f.write('from ansible.module_utils.parsing.convert_bool import boolean\n')
        f.write('from ansible.plugins.loader import ps_script_parser\n')
        f.write('from ansible.plugins.loader import shell_loader\n')
        f.write('from ansible.plugins.loader import module_loader\n')
        f.write('from ansible.plugins.loader import connection_loader\n')
        f.write('from ansible.plugins.loader import fragment_loader\n')
        f.write('from ansible.plugins.loader import strategy_loader\n')
        f

# Generated at 2022-06-23 14:31:13.626902
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass
    # class MySingleton is Singleton
    assert 'Singleton' in MySingleton.__class__.__name__
    # create instance __instance
    MySingleton()
    # create another instance __instance1
    MySingleton()
    # Two instances return the same object
    assert MySingleton() is MySingleton()

# test_Singleton()

# Generated at 2022-06-23 14:31:18.332580
# Unit test for constructor of class Singleton
def test_Singleton():
    class Tester(object):
        __metaclass__ = Singleton
        def __init__(self, *args):
            self.args = args
    t1 = Tester('a', 'b')
    t2 = Tester('c', 'd')
    assert (t1 is t2)

# Generated at 2022-06-23 14:31:22.068708
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    foo1 = Foo(1)
    foo2 = Foo(2)

    assert foo1.a == 1
    assert foo2.a == 1



# Generated at 2022-06-23 14:31:24.688475
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        pass

    inst1 = MyClass()
    inst2 = MyClass()
    assert inst1 is inst2



# Generated at 2022-06-23 14:31:31.446054
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 0

    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 1

    a = A()
    a.i = 10
    b = B()
    b.i = 11

    assert A() is a and a.i == b.i
    assert B() is b and b.i == b.i



# Generated at 2022-06-23 14:31:39.301290
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(metaclass=Singleton):
        pass

    class Y(metaclass=Singleton):
        pass

    class Z(metaclass=Singleton):
        def __init__(self, data=None):
            self.data = data

    x = X()
    y = Y()
    z = Z()
    z1 = Z('test')

    assert x is not None
    assert y is not None
    assert x is not y

    assert z is not None
    assert z is not z1

    assert z.data is None
    assert z1.data == 'test'

# Generated at 2022-06-23 14:31:45.572737
# Unit test for constructor of class Singleton
def test_Singleton():
    # Class A is a singleton
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2

# Test that singleton subclasses also work

# Generated at 2022-06-23 14:31:52.507822
# Unit test for constructor of class Singleton
def test_Singleton():
    '''
    Creates a class SingletonTest whose metaclass is 'Singleton'
    and two instances of SingletonTest. Checks for identity of the two instances.
    '''
    class SingletonTest(object):
        __metaclass__ = Singleton
    test1 = SingletonTest()
    test2 = SingletonTest()
    assert test1 is test2, "Instantiation of Singleton failed"


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:31:56.375681
# Unit test for constructor of class Singleton
def test_Singleton():
   class Foo(object):
      __metaclass__ = Singleton

   class Bar(object):
      __metaclass__ = Singleton

   f1 = Foo()
   f2 = Foo()
   b1 = Bar()
   b2 = Bar()

   assert(f1 is f2)
   assert(b1 is b2)

# Generated at 2022-06-23 14:32:05.485827
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 == a2
    assert a1 is a2

    class B:
        __metaclass__ = Singleton

        def __init__(self):
            self.n = 0

    b1 = B()
    b1.n = 1
    b2 = B()
    assert b1 == b2
    assert b1.n == b2.n
    assert b1 is b2

    b2.n = 2
    assert b1.n == b2.n
    assert b1 is b2

# Generated at 2022-06-23 14:32:10.338423
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    class Boo(Foo):
        pass

    class Poo(Foo):
        pass

    assert Foo() == Boo()
    assert Boo() == Poo()
    assert Foo() == Poo()

# Generated at 2022-06-23 14:32:12.719620
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 is a2

# Generated at 2022-06-23 14:32:17.058865
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b


    a = TestClass(1, 2)

    b = TestClass(3, 4)
    assert a
    assert b
    assert id(a) == id(b)



# Generated at 2022-06-23 14:32:23.780943
# Unit test for constructor of class Singleton
def test_Singleton():
    from six import with_metaclass
    class Foo(with_metaclass(Singleton, object)):
        def __init__(self, id):
            self.id = id

    f1 = Foo(1)
    f2 = Foo(2)
    assert f1 is f2
    assert f1.id == 1


#
# FIXME: This cache class is very generic and may be useful elsewhere.
#

# Generated at 2022-06-23 14:32:27.770557
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = "test"

    try:
        assert TestClass() == TestClass()
        assert TestClass().test == "test"
    except AssertionError:
        raise AssertionError("Singleton not working as expected")

# Generated at 2022-06-23 14:32:38.944799
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    import ansible.module_utils.connection as connection
    # It should call the __call__ function.
    # It should create a new instance.
    # It should return the existing instance.
    # It should raise an error.
    class MyClass(Singleton):
        def __init__(self):
            self.value = 0
        def inc(self):
            self.value += 1
        def __call__(self, *args, **kw):
            raise Exception('Wrong method called.')
    obj1 = MyClass()
    obj2 = MyClass()
    assert obj1 is obj2, "Objects should be the same"
    obj1.inc()
    obj2.inc()
    assert obj1 is obj2, "Objects should be the same"

# Generated at 2022-06-23 14:32:43.535451
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    x = SingletonTest(1)
    y = SingletonTest(2)

    assert id(x) == id(y)
    assert x.value == y.value
    return True

# Generated at 2022-06-23 14:32:45.082420
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.id = id(self)

    instance = MyClass()
    assert(MyClass() is instance)

# Generated at 2022-06-23 14:32:47.490103
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    test = None
    assert Test() == (test == None and Test())


# Generated at 2022-06-23 14:32:52.151047
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    a = Singleton('a', (), {})
    b = Singleton('b', (), {})
    s1 = a()
    s2 = b()
    assert s1 is not s2
    assert a() is s1
    assert b() is s2
    assert a() is s1


# Generated at 2022-06-23 14:32:55.735798
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    assert A() == A()
    assert B() == B()
    assert A() != B()



# Generated at 2022-06-23 14:32:57.601189
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Single2(with_metaclass(Singleton)):
        pass

    assert Single2() is Single2()



# Generated at 2022-06-23 14:33:02.746281
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    a = A(1)
    b = A(2)
    assert a.a == 1
    assert a is b

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:33:07.460841
# Unit test for constructor of class Singleton
def test_Singleton():
    # pylint: disable=C0103
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    # pylint: enable=C0103

    # Create two instances
    instance1 = MySingleton()
    instance2 = MySingleton()

    # Check two instances are the same
    assert instance1 is instance2

# Generated at 2022-06-23 14:33:15.656829
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    # In the first call of the class, the instance is instantiated,
    # and the instance returned from the method __call__ should be equal
    # to the singleton instance of the class.
    instance1 = MyClass()
    assert instance1 == MyClass.__instance

    # In the second call of the class, the singleton instance of the
    # class is returned, so the instance returned from the method __call__
    # should be equal to the singleton instance of the class.
    instance2 = MyClass()
    assert instance2 == MyClass.__instance

    # In the third call of the cla

# Generated at 2022-06-23 14:33:18.349933
# Unit test for constructor of class Singleton
def test_Singleton():
    class A:
        __metaclass__ = Singleton
        def __init__(self):
            pass
    a1 = A()
    a2 = A()
    assert a1 == a2

# Generated at 2022-06-23 14:33:27.068680
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg=0):
            self.arg = arg
            self.instance_num = 0
            self.lock = RLock()

        def increase(self):
            with self.lock:
                self.instance_num += 1


    instance1 = MyClass('hello')
    instance2 = MyClass('world')
    assert instance1 == instance2
    instance1.increase()
    assert instance1.instance_num == 1
    instance2.increase()
    assert instance1.instance_num == 2

# Generated at 2022-06-23 14:33:30.213428
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class X(object):
        __metaclass__ = Singleton

    x = X()
    assert(x is X())
    assert(x is X())



# Generated at 2022-06-23 14:33:33.799015
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 is not None
    assert a2 is not None
    assert a1 is a2


# Generated at 2022-06-23 14:33:37.509585
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 2

    a1 = A()
    assert a1.value == 2
    a2 = A()
    assert a2.value == 2
    a2.value = 3
    assert a1.value == 3


# Generated at 2022-06-23 14:33:41.410831
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        pass

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-23 14:33:44.243747
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1=A()
    a2=A()
    assert(a1 is a2)

# Generated at 2022-06-23 14:33:55.690530
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a=None, b=None):
            self.a = a
            self.b = b
            pass
        def __repr__(self):
            return "instance of A, a:%s, b:%s" % (self.a, self.b)

    a = A(a=1)
    b = A(b=1)
    assert a == b

    class B(object):
        __metaclass__ = Singleton
        def __init__(self, a=None, b=None):
            self.a = a
            self.b = b
            pass

# Generated at 2022-06-23 14:33:59.046706
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Initialize
    class Boo():
        __metaclass__ = Singleton

    boo1 = Boo()
    boo2 = Boo()

    assert boo1 is boo2, 'boo1 and boo2 should point to the same object'


# Generated at 2022-06-23 14:34:08.451158
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass1(object):
        __metaclass__ = Singleton

    class TestClass2(object):
        __metaclass__ = Singleton

    obj1 = TestClass1()
    obj2 = TestClass1()
    assert id(obj1) == id(obj2)
    assert obj1 == obj2

    # obj1 and obj2 should not be same object as TestClass2 is different from TestClass1
    obj3 = TestClass2()
    assert id(obj1) != id(obj3)
    assert obj1 != obj3

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:34:10.541338
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

    a = A()
    b = A()
    return a is b



# Generated at 2022-06-23 14:34:14.839048
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()
    t3 = TestSingleton()
    assert t1 == t2
    assert t3 == t2



# Generated at 2022-06-23 14:34:22.850489
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self._a = 0
            self._b = 1

        def get_a(self):
            return self._a

        def set_a(self, a):
            self._a = a

        def get_b(self):
            return self._b

        def set_b(self, b):
            self._b = b

        def __str__(self):
            return 'a: %s, b: %s' % (self._a, self._b)

    a = TestClass()
    b = TestClass()

    assert a is b

    a.set_a(20)
    assert a._a == 20
    assert b._a == 20

    a.set_b(10)
    assert a

# Generated at 2022-06-23 14:34:28.022288
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    instance1 = A(1)
    instance2 = A(2)
    assert(instance1 is instance2)
    assert(instance1.a == instance2.a)


# Generated at 2022-06-23 14:34:32.052509
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    s1 = SingletonTest(1)
    assert s1.arg == 1
    s1_0 = SingletonTest(0)
    assert s1_0 is s1


# Generated at 2022-06-23 14:34:35.387892
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-23 14:34:40.590981
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Object1(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.initialized = True

    object1 = Object1()
    assert isinstance(object1, Object1)
    assert object1.initialized

    object2 = Object1()
    assert object1 is object2
    assert object1.initialized

    class Object2(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.initialized = True

    object3 = Object2()
    assert isinstance(object3, Object2)
    assert object3.initialized

    object4 = Object2()
    assert object3 is object4
    assert object3.initialized

    assert object1 is not object3

    class Object3(object):
        __metaclass__ = Singleton


# Generated at 2022-06-23 14:34:43.188509
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySigleton(object):
        __metaclass__ = Singleton

    assert MySigleton() is MySigleton()

test_Singleton___call__()

# Generated at 2022-06-23 14:34:46.557748
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo:
        __metaclass__ = Singleton
        def __init__(self, n):
            self.n = n

    assert Foo(1) is Foo(2)
    assert Foo(1).n == Foo(2).n


# vim: filetype=python

# Generated at 2022-06-23 14:34:50.469090
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            pass

    a = A()
    b = A()
    if a is b:
        print('Passed.')
    else:
        print('Failed.')



# Generated at 2022-06-23 14:34:54.196780
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A():
        __metaclass__ = Singleton
        pass

    class B():
        pass

    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)

    b1 = B()
    b2 = B()
    assert id(b1) != id(b2)

# Generated at 2022-06-23 14:34:56.576566
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def method(self):
            pass

    s1 = MySingleton()
    s2 = MySingleton()
    assert(s1 == s2)

# Generated at 2022-06-23 14:35:03.635677
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test Singleton()"""
    import os

    class fdSingleton(os.FDPass):
        __metaclass__ = Singleton

    # First call, an object is created in fdSingleton.__instance
    fdSingleton(5)
    assert fdSingleton.__instance is not None

    # Second call, the object created in the first call is returned
    fdSingleton(10)
    assert fdSingleton.__instance is not None


# Generated at 2022-06-23 14:35:10.802859
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():  # noqa
    from ansibullbot.utils.extractors import is_trivial_regex

    class SomeSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    assert SomeSingleton.__instance is None
    inst1 = SomeSingleton(5)
    assert SomeSingleton.__instance is inst1
    assert inst1.a == 5
    inst2 = SomeSingleton(10)
    assert SomeSingleton.__instance is inst1
    assert inst1.a == 5
    assert inst2.a == 5
    assert inst1 is inst2

    class WeakSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    assert WeakSingleton.__

# Generated at 2022-06-23 14:35:13.557428
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    first = Foo()
    second = Foo()

    assert first is second

# Generated at 2022-06-23 14:35:17.433478
# Unit test for constructor of class Singleton
def test_Singleton():
    class foo(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    a = foo('a')
    b = foo('b')
    assert id(a) == id(b)

# Generated at 2022-06-23 14:35:21.231503
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    f1 = Foo('test')
    f2 = Foo('test2')
    assert f1 is f2



# Generated at 2022-06-23 14:35:24.311774
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import types
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
        def bar(self):
            return 1

    assert isinstance(Foo(), types.InstanceType)


# Generated at 2022-06-23 14:35:32.245803
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    first_foo = Foo(1)
    second_foo = Foo(2)

    print(first_foo.val)
    print(second_foo.val)
    print(first_foo is second_foo)
    print(id(first_foo), id(second_foo))

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:35:38.560018
# Unit test for constructor of class Singleton
def test_Singleton():
    msg=u"I'm the one and only one!"
    # noinspection PyUnusedLocal
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, msg):
            self.msg = msg

    s1 = TestSingleton(msg)
    s2 = TestSingleton(msg)
    assert s1 is s2
    assert hasattr(s1, u'msg')
    assert s1.msg == s2.msg


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:35:42.438792
# Unit test for constructor of class Singleton
def test_Singleton():

    class A(metaclass=Singleton):
        def __init__(self):
            self.a = "A"
            self.b = "B"


    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a2.a == "A"
    assert a1.b == "B"

# Generated at 2022-06-23 14:35:50.176398
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import datetime

    class SingletonTestClass(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class NonSingletonTestClass(object):
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    # Instantiate two instances of SingletonTestClass and two instances of NonSingletonTestClass
    t1 = datetime.datetime.now()
    singleton_instance1 = SingletonTestClass("singleton_instance1")
    t2 = datetime.datetime.now()
    singleton_instance2 = SingletonTestClass("singleton_instance2")
    t3 = datetime.datetime.now()

# Generated at 2022-06-23 14:35:52.476734
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b



# Generated at 2022-06-23 14:35:59.295020
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.abc = 123

    a = TestSingleton()
    b = TestSingleton()
    assert a == b
    assert a.abc == b.abc

    c = TestSingleton()
    c.abc = 456
    assert a == b
    assert a.abc == b.abc
    assert a != c
    assert a.abc != c.abc
    assert b != c
    assert b.abc != c.abc

    try:
        d = TestSingleton.__new__(TestSingleton)
        pytest.fail("Expected TypeError exception but did not get it")
    except TypeError:
        pass

# Generated at 2022-06-23 14:36:10.094917
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Set up the class definition that we can decorate with the Singleton class
    class Foo(object):
        my_singleton_counter = 0

        def __init__(self):
            Foo.my_singleton_counter += 1

        def foo_factory(self):
            return "Foo number " + str(Foo.my_singleton_counter)

        foo_factory = classmethod(foo_factory)


    # Add the Singleton class as a metaclass so it keeps track of the
    # single instance of the object
    class SingletonFoo(object):
        __metaclass__ = Singleton

    # Make sure that we get the same object back each time
    foo1 = SingletonFoo.foo_factory()
    assert foo1 == "Foo number 1"

    foo2 = SingletonFoo

# Generated at 2022-06-23 14:36:13.421178
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()

    assert foo1 == foo2


# Generated at 2022-06-23 14:36:22.572183
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from collections import defaultdict
    from copy import copy

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            # Test that we're truly a singleton
            self.instance_history = defaultdict(int)
            self.instance_history[id(self)] += 1
            return self

        def __getstate__(self):
            # Test that we're truly a singleton
            state = copy(self.__dict__)
            state['call_history'] = copy(self.instance_history)
            return state

        def __setstate__(self, state):
            self.__dict__.update(state)
            self.instance_history = defaultdict(int)
            for key, value in state['call_history'].items():
                self.instance_history[key]

# Generated at 2022-06-23 14:36:25.399408
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        def __init__(self):
            pass
    assert TestClass() is TestClass()


# Generated at 2022-06-23 14:36:35.331020
# Unit test for constructor of class Singleton
def test_Singleton():
    class _TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 0

        def greet(self):
            self.i += 1
            print(self.i)

    t = _TestSingleton()
    assert isinstance(t, _TestSingleton)
    assert t.__class__.__name__ == '_TestSingleton'
    assert t.__class__.__bases__ == (object,)

    t.greet()
    assert t.i == 1

    u = _TestSingleton()
    assert u is t
    assert t.i == 1

    u.greet()
    assert u.i == 2
    assert t.i == 2

# Generated at 2022-06-23 14:36:39.631805
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class foo (metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    f1 = foo(1)
    f2 = foo(2)
    assert f1.x == 1
    assert f1 is f2


# Generated at 2022-06-23 14:36:46.053470
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Parent(object):
        pass

    class Child(Parent):
        def __init__(self):
            self.x = 1

        __metaclass__ = Singleton

    print(Child.__instance)
    rc = Child()
    print(Child.__instance)
    print(rc.x)
    rc1 = Child()
    print(rc1.x)
    # print(id(rc))
    # print(id(rc1))
    # print(rc == rc1)


# Generated at 2022-06-23 14:36:50.905664
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("Initialize class A")

        def test(self):
            print("A")

    A()
    a = A()
    a.test()


# Generated at 2022-06-23 14:36:55.538994
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self):
            pass

    foo1 = Foo()
    foo2 = Foo()
    if foo1 is not foo2:
        raise Exception("Both instances should be equal")

# Generated at 2022-06-23 14:37:00.211412
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, param):
            self.param = param

    a = Test(param='a')
    assert a.param == 'a'
    b = Test(param='b')
    assert a.param == 'a' # instance a is the same instance as b
    assert b.param == 'a' # instance b is the same instance as a
    assert id(a) == id(b)

# Generated at 2022-06-23 14:37:06.978004
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            if isinstance(other, Test):
                return self.value == other.value
            return False

    test1 = Test(1)
    assert test1 == Test(1)
    assert test1 == Test(1)
    assert test1 is Test(1)
    assert test1 is Test(1)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:37:11.098477
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    o1 = A(123)
    o2 = A(321)
    assert o1 is o2 and o1.arg == 123

# Generated at 2022-06-23 14:37:17.787925
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class SingletonTestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

        def __str__(self):
            return 'test_Singleton___call__.SingletonTestClass()'

    class NonSingletonTestClass(object):
        def __init__(self):
            pass

        def __str__(self):
            return 'test_Singleton___call__.NonSingletonTestClass()'

    # Test singleton
    SingletonTestClass()
    SingletonTestClass()
    SingletonTestClass()

    # Test non-singleton
    NonSingletonTestClass()
    NonSingletonTestClass()
    NonSingletonTestClass()

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-23 14:37:21.972142
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class cls1(object):
        __metaclass__ = Singleton

    c1 = cls1()
    c2 = cls1()
    assert(c1 is c2)


# Generated at 2022-06-23 14:37:26.532476
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, init_var):
            self.init_var = init_var

    TestClass('var1')
    TestClass('var2')

    assert TestClass.__instance.init_var == 'var1'


# Generated at 2022-06-23 14:37:34.399586
# Unit test for constructor of class Singleton
def test_Singleton():
    class my_class(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    def get_two_instances(a, b):
        instance = my_class(a, b)
        another = my_class(a, b)
        return (instance, another)

    instance1 = get_two_instances(1, 2)
    instance2 = get_two_instances(3, 4)
    assert (instance1[0] is instance2[0] and
            instance1[1] is instance2[1])
    assert (instance1[0].a == instance1[1].a == 1 and
            instance1[0].b == instance1[1].b == 2)

# Generated at 2022-06-23 14:37:36.398249
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, arg):
            self.arg = arg

    a = A(1)
    b = A(2)
    assert a is b
    assert a.arg == 2



# Generated at 2022-06-23 14:37:38.659172
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    c = MyClass()
    assert c is MyClass()

# Generated at 2022-06-23 14:37:41.325466
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b



# Generated at 2022-06-23 14:37:44.154059
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert id(a1) == id(a2)


# Generated at 2022-06-23 14:37:47.123951
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            # self.name = 'SingletonTest'
            pass

    s1 = SingletonTest()
    s2 = SingletonTest()
    assert s1 is s2, "failed to create Singleton instance"

if __name__ == '__main__':
    test_Singleton___call__()