

# Generated at 2022-06-23 14:27:50.702234
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    assert a
    b = A()
    assert b == a

    class B(object):
        __metaclass__ = Singleton

    bb = B()
    assert bb
    aa = A()
    assert aa == a
    assert bb != a

    class C(A):
        pass

    cc = C()
    assert cc
    assert cc == a
    bb = B()
    assert bb



# Generated at 2022-06-23 14:27:55.529024
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, foo=''):
            self.foo = foo

    assert MySingleton('bar').foo == 'bar'
    assert MySingleton().foo == 'bar'

# Generated at 2022-06-23 14:27:59.204694
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()

    with Singleton.__rlock:
        Test.__instance = None

    c = Test()

    assert a is b
    assert b is not None
    assert c is not a



# Generated at 2022-06-23 14:28:01.467447
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            pass

    a1 = A()
    a2 = A()
    assert a1 == a2

# Generated at 2022-06-23 14:28:10.213587
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 42

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 == foo2
    assert foo1.value == 42
    assert foo2.value == 42
    foo1.value = 99
    assert foo1.value == 99
    assert foo2.value == 99
    foo2.value = 0xDEADBEEF
    assert foo1.value == 0xDEADBEEF
    assert foo2.value == 0xDEADBEEF



# Generated at 2022-06-23 14:28:16.484700
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.number = 0

        def fun(self):
            self.number += 1

    t1 = TestSingleton()
    t1.fun()
    t2 = TestSingleton()
    t2.fun()
    assert t1.number == t2.number



# Generated at 2022-06-23 14:28:19.240511
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    s1 = MySingleton()
    s2 = MySingleton()
    assert s1 is s2

# Generated at 2022-06-23 14:28:23.870896
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a = Foo(1)
    b = Foo(2)

    assert a.value == 1
    assert b.value == 1
    assert a is b

# Generated at 2022-06-23 14:28:29.656971
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    foo1 = Foo(0)
    foo2 = Foo(1)

    # Foo() should return the same object
    assert foo1 is foo2
    assert foo1.value == 1

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:28:31.156501
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Block(object):
        __metaclass__ = Singleton

    Block()
    Block()

# Generated at 2022-06-23 14:28:33.624089
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestedSingleton(object):
        __metaclass__ = Singleton
        pass

    instance1 = TestedSingleton()
    instance2 = TestedSingleton()

    assert instance1 is instance2, "Should be the same instance"

# Generated at 2022-06-23 14:28:39.586566
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, param=None):
            self.param = param

    # create a number of instances which all should be the same
    one = Test(1)
    two = Test(2)
    three = Test()
    four = Test()
    assert one == two == three == four


# Generated at 2022-06-23 14:28:48.837682
# Unit test for constructor of class Singleton
def test_Singleton():
    # Note: This is a somewhat contrived test to demonstrate ability to
    # access the underlying instance of a singleton.  In reality, this
    # test would be a part of a unit test for class Foo.
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    f1 = Foo()
    # Ensure that accessing the instance via the class returns the
    # same instance
    assert f1 is Foo.__instance

    # Ensure that the same instance is returned for all calls to the
    # constructor
    f2 = Foo()
    assert f2 is Foo.__instance

    # Ensure constructor values are set on the instance
    assert f1.x == 1
    assert f2.x == 1

    # Ensure the constructor was only called once
    assert f1 is f2

# Generated at 2022-06-23 14:28:54.007870
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a=0):
            self.a = a

    i1 = A(1)
    i2 = A()
    i2.a = 2
    print("i1.a=%s i2.a=%s" % (i1.a, i2.a))


# Generated at 2022-06-23 14:28:58.140852
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

    a = A()
    assert type(a) == A
    b = A()
    assert a == b
    assert id(a) == id(b)
    assert isinstance(a, A)


# Generated at 2022-06-23 14:29:04.634930
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    class MyOtherClass(object):
        __metaclass__ = Singleton

    m1 = MyClass()
    m2 = MyOtherClass()
    m3 = MyOtherClass()

    assert(m1.__class__ == MyClass)
    assert(m2.__class__ == MyOtherClass)
    assert(m3.__class__ == MyOtherClass)

    assert(m2 == m3)
    assert(m1 != m2)


# Generated at 2022-06-23 14:29:07.577466
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        def __init__(self):
            self.a = 0

    f1 = Foo()
    f2 = Foo()

    assert f1 is f2

    f1.a = 1
    assert f2.a == 1


# vim: set fileencoding=utf-8 :

# Generated at 2022-06-23 14:29:11.337542
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()

    assert foo1 is foo2


# Generated at 2022-06-23 14:29:14.165675
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    from_a = A()
    assert (a == from_a)

# Generated at 2022-06-23 14:29:21.154327
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    a = MyClass()
    print("==> a: ", a)
    b = MyClass()
    print("==> b: ", b)
    assert a is b

    class MyOtherClass(object):
        __metaclass__ = Singleton

    a = MyOtherClass()
    print("==> a: ", a)
    b = MyOtherClass()
    print("==> b: ", b)
    assert a is b


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:29:25.605452
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            super(A, self).__init__()
            self.value = 'hello'

    a1 = A()
    a2 = A()
    print(a1, a2)
    print(a1.value)
    print(a2.value)
    a1.value = 'world'
    print(a1.value)
    print(a2.value)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:29:31.026139
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.value = val

    for i in range(10):
        s = SingletonTest(i)
        assert s.value == i

# Generated at 2022-06-23 14:29:34.608439
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTestClass(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args_list = list(args)
            self.kwargs_dict = kwargs

    args = (1, 2)
    kwargs = {'ansible': 'awesome'}
    obj = SingletonTestClass(*args, **kwargs)
    assert obj.args_list == list(args)
    assert obj.kwargs_dict == kwargs

    obj2 = SingletonTestClass(*args, **kwargs)
    assert obj == obj2

# Generated at 2022-06-23 14:29:42.891805
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Sample(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 0

        def __repr__(self):
            return "Sample"

        def __eq__(self, other):
            return id(self) == id(other)

    sample1 = Sample()
    sample2 = Sample()
    sample3 = Sample()

    assert id(sample1) == id(sample2) == id(sample3)
    assert sample1 is sample2 is sample3

    sample1.value = 1
    sample2.value = 2

    assert sample1.value == sample2.value == sample3.value == 2

# Test whether __call__ will retrun the same instance if there was previously created.

# Generated at 2022-06-23 14:29:47.237963
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    test1 = Test()
    test2 = Test()
    print('test1 instance is equal to test2 instance:', test1 is test2)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:29:51.276280
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-23 14:29:52.336637
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
    TestClass()
    TestClass()

# Generated at 2022-06-23 14:29:54.648536
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    s1 = SingletonTest()
    s2 = SingletonTest()
    assert s1 is s2

# Generated at 2022-06-23 14:30:04.682593
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, bar=None):
            self._bar = bar

        @property
        def bar(self):
            return self._bar

    f1 = Foo('baz')
    assert f1.bar == 'baz'
    f2 = Foo()
    assert f2.bar == 'baz'
    assert f1 is f2


# Make coding more python3-ish
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import os
import sys
import traceback

# FIXME: we should be able to use a bare import here, but due to execution model
#        we need to explicitly import the "__init__.py" file instead
from ansible.compat.six import reload

# Generated at 2022-06-23 14:30:11.138979
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Set up instance
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.x = 'test'

    # Check that it is set up properly
    t1 = TestSingleton()
    assert t1.x == 'test'

    # Check that a second time always returns the same instance
    t2 = TestSingleton()
    assert t2 is t1


# Generated at 2022-06-23 14:30:15.579080
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    assert TestSingleton('foo') == TestSingleton('bar')
    assert TestSingleton('foo').a == 'foo'
    assert TestSin

# Generated at 2022-06-23 14:30:20.951735
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, name=None):
            print("__init__ called")
            self.name = name

    a = A("Alice")
    print(a)
    b = A("Bob")
    print(b)
    c = A("Charlie")
    print(b is c)
    print(a is c)
    print(a.name)
    print(c.name)
    assert a is b is c



# Generated at 2022-06-23 14:30:24.435698
# Unit test for constructor of class Singleton
def test_Singleton():
    class a:
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name
    a1 = a("george")
    a2 = a("james")
    assert a1 == a2
    assert a1.name == "james"


# Generated at 2022-06-23 14:30:28.191413
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        def __init__(self, arg):
            self.var = arg

    x = TestSingleton(10)
    y = TestSingleton(20)
    print(x.var, y.var)
    assert x == y


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:30:30.015522
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert id(Foo()) == id(Foo())

# Generated at 2022-06-23 14:30:36.330389
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Setup
    class A(object):
        __metaclass__ = Singleton

    # Precondition
    assert A.__instance is None

    # Exercise
    a1 = A()

    # Verify
    assert A.__instance is not None
    assert A.__instance == a1

    # Exercise again
    a2 = A()

    # Verify again
    assert A.__instance is not None
    assert A.__instance == a2


# Unit test of decorator

# Generated at 2022-06-23 14:30:42.130584
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)

    assert id(a1) == id(a2)
    assert a1.x == 1
    assert a1.x == a2.x

# Generated at 2022-06-23 14:30:49.089950
# Unit test for constructor of class Singleton
def test_Singleton():
    global CallCount
    CallCount = 0
    class DummySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            global CallCount
            CallCount += 1

    a = DummySingleton()
    assert CallCount == 1
    b = DummySingleton()
    assert CallCount == 1
    assert a == b
    assert id(a) == id(b)
    del a
    del b

# Generated at 2022-06-23 14:30:53.661027
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest

    class A(object):
        __metaclass__ = Singleton

    # check that the class is still callable (e.g. not implementing a singleton)
    a = A()

    # check that the class is not callable (e.g. implementing a singleton)
    with pytest.raises(TypeError):
        b = A()


# Generated at 2022-06-23 14:31:00.383810
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # class Foo is a singleton
    class Foo(metaclass=Singleton):
        pass

    # No instance of Foo exists yet
    assert Foo.__instance is None

    # Instantiate the first instance of Foo
    a = Foo()

    # One instance of Foo exists
    assert Foo.__instance is not None

    # Retrieve the only instance of Foo
    b = Foo()

    # The two previously instantiated instances of Foo refer to the same object
    assert a is b



# Generated at 2022-06-23 14:31:07.050626
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

        def __str__(self):
            return "MyClass(%s)" % self.value

    # A class that uses Singleton must be called to construct an
    # instance
    obj = MyClass("Foo")
    assert obj
    assert isinstance(obj, MyClass)

    # The same object is returned when the class is called
    obj2 = MyClass("Bar")
    assert obj2
    assert isinstance(obj2, MyClass)
    assert obj is obj2

# Generated at 2022-06-23 14:31:11.156007
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.var = 0

    o1 = Test()
    o2 = Test()

    o1.var = 1
    assert o1.var == o2.var

# Generated at 2022-06-23 14:31:14.670945
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, v):
            pass

    assert MyClass(1) is MyClass(2)

# Generated at 2022-06-23 14:31:19.555112
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    cls_name = 'Singleton_test___call__'
    cls_dict = {}
    cls_bases = ()
    cls = Singleton(cls_name, cls_bases, cls_dict)

    ob1 = cls()
    ob2 = cls()
    assert ob1 == ob2

# Generated at 2022-06-23 14:31:24.835580
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    obj1 = SingletonClass()
    obj2 = SingletonClass()

    # test if obj1 and obj2 are the same reference
    assert obj1 is obj2


# Generated at 2022-06-23 14:31:27.857514
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    a = A()
    b = A()
    assert id(a) == id(b)


# Generated at 2022-06-23 14:31:31.720806
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    f = Foo()
    assert f.a == 1

    f = Foo()
    f.a = 2
    assert f.a == 2


# Generated at 2022-06-23 14:31:36.536568
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        num_instances = 0
        def __init__(self):
            type(self).num_instances += 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert Test.num_instances == 1

# Generated at 2022-06-23 14:31:41.350346
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    a3 = A()
    assert id(a1) == id(a2)
    assert id(a1) == id(a3)


# Generated at 2022-06-23 14:31:44.127695
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1(object):
        __metaclass__ = Singleton

    a = Test1()
    b = Test1()
    assert a is b


# Generated at 2022-06-23 14:31:45.837698
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    c1 = TestSingleton()
    c2 = TestSingleton()
    assert c1 is c2

# Generated at 2022-06-23 14:31:51.983411
# Unit test for constructor of class Singleton
def test_Singleton():
    class Bar:
        __metaclass__ = Singleton

        def __init__(self, i):
            self.id = i

        def __str__(self):
            return str(self.id)

    a = Bar(1)
    b = Bar(1)
    assert a is b
    assert id(a) == id(b)

    print("OK")


# Generated at 2022-06-23 14:31:56.558088
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    class B(A):
        pass

    a1 = A()
    a2 = A()
    b = B()
    assert a1 == a2
    assert a1 != b
    assert a1 == A()
    assert a1 == B()

    class C(object):
        pass

    c = C()
    assert a1 != c

# Generated at 2022-06-23 14:32:00.182147
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self):
            self.foo = 'bar'

        def boo(self):
           return self.foo + ' boo'

    assert Foo().boo() == 'bar boo'

# Generated at 2022-06-23 14:32:08.848470
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Unit test for method __call__ of class Singleton"""
    class Example(metaclass=Singleton):
        # pylint: disable=too-few-public-methods
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    instance1 = Example()
    assert instance1.args == () and instance1.kwargs == {}

    instance2 = Example(1, 2, 3)
    assert instance2.args == (1, 2, 3) and instance2.kwargs == {}

    instance3 = Example(foo='bar')
    assert instance3.args == () and instance3.kwargs == {'foo': 'bar'}

    assert instance1 is instance2 is instance3

# Generated at 2022-06-23 14:32:14.047617
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class X(object):
        __metaclass__ = Singleton
        def __init__(self, value=None):
            self.value = value

    x1 = X(1)
    x2 = X(2)

    assert x1.value == 1
    assert x2.value == 1

    assert x1 is x2

# Generated at 2022-06-23 14:32:18.674661
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    t1 = Test(1)
    t2 = Test(2)
    t3 = Test(3)

    assert t1.x == 1
    assert t2.x == 1
    assert t3.x == 1

    assert t1 == t2
    assert t2 == t3
    assert t3 == t1



# Generated at 2022-06-23 14:32:21.490024
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert a is b, "instances are not equal"

# Generated at 2022-06-23 14:32:26.983780
# Unit test for constructor of class Singleton
def test_Singleton():
    class B(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a
            self.b = None
    a = B(1)
    assert a.a == 1
    b = B(2)
    assert b is a
    b.b = 3
    assert a.b == 3

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:32:31.425563
# Unit test for constructor of class Singleton
def test_Singleton():
    class Tmp(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 42

    t = Tmp()
    assert(t.foo == 42)

    assert(Tmp() == t)



# Generated at 2022-06-23 14:32:37.741606
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class test_Singleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert(test_Singleton() == test_Singleton())
    assert(type(test_Singleton.__instance) == type(test_Singleton()))
    assert(isinstance(test_Singleton(), test_Singleton))
    assert(isinstance(test_Singleton(), object))


# Generated at 2022-06-23 14:32:39.033482
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(metaclass=Singleton): pass
    assert C() is C()

# Generated at 2022-06-23 14:32:47.489979
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.__a = a
            self.__b = b

        def get_a(self):
            return self.__a

        def get_b(self):
            return self.__b

    # first call
    t1 = Test('a', 'b')
    assert t1.get_a() == 'a' and t1.get_b() == 'b'

    # second call
    t2 = Test('c', 'd')
    assert t2 is t1

    # check values from first call
    assert t2.get_a() == 'a' and t2.get_b() == 'b'

# Generated at 2022-06-23 14:32:50.027861
# Unit test for constructor of class Singleton
def test_Singleton():
    class test(object):
        __metaclass__ = Singleton

    a = test()
    b = test()
    if a is not b:
        raise AssertionError('Should have been the same instance')



# Generated at 2022-06-23 14:32:55.779278
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 0

    test = Test()
    assert id(test) == id(Test())

    test.value = 2
    test2 = Test()
    assert test.value == test2.value



# Generated at 2022-06-23 14:33:06.490896
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()
    #print(A().__dict__)
    assert A().__dict__ is A().__dict__


if __name__ == "__main__":
    import sys
    import unittest

    class Test_Singleton(unittest.TestCase):
        def test__call__(self):
            class A(object):
                __metaclass__ = Singleton

            a1 = A()
            a2 = A()
            self.assertIs(a1, a2)
            self.assertIs(a1.__dict__, a2.__dict__)

    unittest.main(argv=sys.argv)

# Generated at 2022-06-23 14:33:10.491733
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

        def get_x(self):
            return self.x

    a = TestClass('x')
    b = TestClass('y')
    assert a == b
    assert a.get_x() == 'x'

# Generated at 2022-06-23 14:33:16.270338
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        x = 0
        def __init__(self):
            A.x += 1

    a1 = A()
    assert(isinstance(a1, A))
    a2 = A()
    assert(isinstance(a2, A))
    assert(id(a1) == id(a2))
    assert(A.x == 1)


# Generated at 2022-06-23 14:33:21.656307
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = 1
    print(TestSingleton.__bases__, TestSingleton.__name__)

    a = TestSingleton()
    assert a.test == 1
    b = TestSingleton()
    assert a.test == 1
    assert a == b


# Generated at 2022-06-23 14:33:27.414805
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = None

    foo = Foo()
    foo.value = 123
    # print(foo.value)
    # print(Foo().value)
    assert(Foo().value == 123)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:33:34.959841
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from json import dumps
    from src.json_encoder import JSONEncoder
    from src.singleton import Singleton

    class Test(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return 'Test(name="{}")'.format(self.name)

    obj_a = Test('abc')
    obj_b = Test('def')

    # obj_b is actually same as obj_a
    assert obj_a is obj_b



# Generated at 2022-06-23 14:33:36.484074
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object):
        __metaclass__ = Singleton

    assert id(C()) == id(C())

# Generated at 2022-06-23 14:33:41.228425
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyS(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 5

    my1 = MyS()
    my2 = MyS()
    assert id(my1) == id(my2)
    assert my1 is my2
    assert my1.x == 5
    assert my2.x == 5
    my1.x = 3
    assert my1.x == my2.x


# Generated at 2022-06-23 14:33:48.264961
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton1(metaclass=Singleton):
        pass
    class MySingleton2(metaclass=Singleton):
        pass

    assert MySingleton1() is MySingleton1()
    assert id(MySingleton1()) is id(MySingleton1())

    assert MySingleton1() is not MySingleton2()
    assert id(MySingleton1()) is not id(MySingleton2())

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-23 14:33:55.164708
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object, metaclass=Singleton):
        def __init__(self):
            self.x = 2
            self.y = 5

    t1 = SingletonTest()
    assert t1.x == 2 and t1.y == 5

    t2 = SingletonTest()
    assert t2 is t1

    t2.x = 4
    assert t2.x == 4 and t1.x == 4

# Generated at 2022-06-23 14:34:00.390252
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyKlass(object):
        __metaclass__ = Singleton

        def __init__(self, v):
            self.v = v

    class MyChildClass(MyKlass):
        pass

    a = MyKlass('a')
    b = MyKlass('b')
    print(a, b)
    print(a == b)
    print(a.v, b.v)


# Generated at 2022-06-23 14:34:03.706556
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create class that inherit from Singleton class
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.attribute = 999

    assert Foo().attribute == 999

# Generated at 2022-06-23 14:34:08.021567
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    x = A()
    y = A()
    assert x is y
    assert x.a == 1

# Generated at 2022-06-23 14:34:11.552368
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-23 14:34:13.273684
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    assert(A() == A())


# Generated at 2022-06-23 14:34:15.855257
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()

    assert a is b


# Generated at 2022-06-23 14:34:21.492370
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a class with a singleton metaclass
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.count_init = 0
        def add_init(self):
            self.count_init += 1
    # Verify that there is only one instance at a time
    a = A()
    a.add_init()
    b = A()
    b.add_init()
    assert a is b
    assert a.count_init == 2


# Generated at 2022-06-23 14:34:27.871514
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return self.name

        def foo(self):
            return self.name

    t1 = Test('t1')
    t2 = Test('t2')
    assert t1 is t2
    assert 't1' == t1.foo()


# Generated at 2022-06-23 14:34:35.882722
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass:
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name

    print(__name__ + '.test_Singleton')

    # Test the class and its constructor.
    tc1 = TestClass('foo')
    print(tc1.get_name())
    assert tc1.name == 'foo'

    tc2 = TestClass('bar')
    assert tc2 is tc1
    print(tc2.get_name())
    assert tc2.name == 'bar'

# Generated at 2022-06-23 14:34:38.617303
# Unit test for constructor of class Singleton
def test_Singleton():
    class Myclass(object):
        __metaclass__ = Singleton

    c1 = Myclass()
    c2 = Myclass()
    assert(c1 == c2)

# Generated at 2022-06-23 14:34:43.053991
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 0
            print('__init__ of A')
    a1 = A()
    a2 = A()
    print(a1 == a2)


# Generated at 2022-06-23 14:34:47.379542
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a
    s = C(10)
    assert type(s) is C
    assert s.a == 10
    t = C(20)
    assert type(t) is C
    assert t.a == 10
    assert s is t



# Generated at 2022-06-23 14:34:51.081088
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = True

    instance1 = SingletonTest()
    instance2 = SingletonTest()
    assert instance1.test
    assert instance1 == instance2
    return 0

if __name__ == '__main__':
    if test_Singleton():
        SystemExit(1)

# Generated at 2022-06-23 14:34:52.530046
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton('name', ('tuple',), {'dct': dict()}) is Singleton


# Generated at 2022-06-23 14:34:56.412137
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    assert MyClass.__instance is None
    assert MyClass('test').value == 'test'
    assert MyClass.__instance.value == 'test'
    assert MyClass('example').value == 'test'
    assert MyClass.__instance.value == 'test'

# Generated at 2022-06-23 14:34:57.121136
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton('singleton', (), {})

# Generated at 2022-06-23 14:34:58.317822
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    assert SingletonTest() == SingletonTest()

# Generated at 2022-06-23 14:35:07.858994
# Unit test for constructor of class Singleton
def test_Singleton():
    class myClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2=None):
            self.arg1 = arg1
            self.arg2 = arg2

        def foo(self):
            return 1

    class myOtherClass(myClass):
        def __init__(self, arg3):
            super(myOtherClass, self).__init__(arg3)

    assert myClass is myOtherClass

    assert myClass('hi', 'there').arg1 == 'hi'
    assert myOtherClass('hello').arg1 == 'hello'
    assert myOtherClass('hello').arg2 is None

    assert myClass('hi', 'there') == myOtherClass('hello')

    assert myClass('hi', 'there').foo() == myOtherClass('hello').foo()


# Generated at 2022-06-23 14:35:09.488202
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-23 14:35:15.421727
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

    class B:
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()

    assert a1 is a2
    assert b1 is not a1
    assert b1 is b2

# Generated at 2022-06-23 14:35:20.077089
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestSingleton(with_metaclass(Singleton, object)):
        def __init__(self):
            pass

    S1 = TestSingleton()
    S2 = TestSingleton()
    S3 = TestSingleton()
    assert S1 == S2 == S3

# Generated at 2022-06-23 14:35:31.353191
# Unit test for constructor of class Singleton
def test_Singleton():

    class Base(object, metaclass=Singleton):
        def __init__(self, *args, **kwargs):
            super(Base, self).__init__(*args, **kwargs)
            self.value = 'value1'

        def __str__(self):
            return self.value

    # Test if we can get the same instance
    x = Base()
    y = Base()
    print(x)
    assert x is y, "x and y should be the same instance"
    assert type(x) is Base, "type(x) should be Base"
    assert isinstance(x, Base), 'x should be instance of Base'

    # Test if we can set the same value
    x.value = 'value2'
    print(y)
    assert y.value == 'value2'


# Generated at 2022-06-23 14:35:33.047700
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    instance = Singleton()

    assert instance is Singleton()
    assert Singleton() is Singleton()

# Generated at 2022-06-23 14:35:41.276893
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test1(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("Test1 instance created")

    class Test2(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("Test2 instance created")

    t1 = Test1()
    t2 = Test2()

    t11 = Test1()
    t22 = Test2()

    assert t11 == t1, "unit test failed"
    assert t11 == t22, "unit test failed"
    assert t1 == t2, "unit test failed"

# Generated at 2022-06-23 14:35:47.665330
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class SingletonClassWithDecorator(object):
        __metaclass__ = Singleton

        def __init__(self, some_data):
            self.some_data = some_data

    class SingletonClassWithInheritance(SingletonClassWithDecorator):
        pass

    assert SingletonClassWithDecorator(1) is SingletonClassWithDecorator(1)
    assert SingletonClassWithDecorator(1).some_data == 1
    assert SingletonClassWithDecorator(1) is SingletonClassWithDecorator(2)

    assert SingletonClassWithInheritance(1) is SingletonClassWithInheritance(1)
    assert SingletonClassWithInheritance(1).some_data == 1

# Generated at 2022-06-23 14:35:53.296365
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from uuid import uuid4

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.id = uuid4()

    a, b, c = [TestClass() for _ in range(3)]
    assert a.id == b.id == c.id
    assert a is b is c



# Generated at 2022-06-23 14:35:56.501508
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert Test() is Test()
    assert Test.__rlock is not None
    assert Test.__instance is not None
    assert Test.__instance is Test()


__all__ = ["Singleton"]

# Generated at 2022-06-23 14:35:58.174864
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class DummyClass(object):
        __metaclass__ = Singleton

    a = DummyClass()
    b = DummyClass()

    assert a is b

# Generated at 2022-06-23 14:36:01.563537
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 == foo2



# Generated at 2022-06-23 14:36:05.332766
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __meta__ = Singleton

    obj_a = A()
    obj_b = A()

    assert obj_a is obj_b


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:36:08.696913
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert id(t1) == id(t2), "test class should be Singleton"

# Generated at 2022-06-23 14:36:13.375071
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create an instance of class Singleton
    class SingletonClass(object):
        __metaclass__ = Singleton

    # Call __init__ method of SingletonClass
    instance1 = SingletonClass()
    instance2 = SingletonClass()
    assert(instance1 == instance2)

# Test for exception Raised

# Generated at 2022-06-23 14:36:19.329017
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton): pass
    class B(metaclass=Singleton): pass
    a1 = A()
    a2 = A()
    assert a1 is a2
    b1 = B()
    b2 = B()
    assert b1 is b2
    a3 = A()
    assert a1 is a3
    assert b1 is a3
    assert a1 is b1
    assert a1 is b2


# Generated at 2022-06-23 14:36:25.418020
# Unit test for constructor of class Singleton
def test_Singleton():
    try:
        from unittest import mock
        mock.patch('ansible.config.Singleton.__init__').start()
    except ImportError:
        # This is for py2.7 only so we can continue testing
        import mock
        mock.patch('ansible.config.Singleton.__init__').start()

    from ansible.config.Singleton import Singleton
    class Test(metaclass=Singleton):
        pass
    t = Test()
    assert t.__init__.call_count == 1
    t = Test()
    assert t.__init__.call_count == 1
    mock.patch.stopall()

# Generated at 2022-06-23 14:36:29.430082
# Unit test for constructor of class Singleton
def test_Singleton():
    class ClassA(object):
        __metaclass__ = Singleton

    a1 = ClassA()
    a2 = ClassA()
    a3 = ClassA()

    assert id(a1) == id(a2)
    assert id(a2) == id(a3)

# Generated at 2022-06-23 14:36:32.094546
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    s_c_init = MyClass(42)
    assert id(s_c_init) == id(MyClass())
    assert s_c_init.value == 42
    assert MyClass().value == 42

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:36:35.831966
# Unit test for constructor of class Singleton
def test_Singleton():
    import unittest
    class Test(object):
        __metaclass__ = Singleton

    class TestCase(unittest.TestCase):
        def test(self):
            assert Test() is Test()

    unittest.TextTestRunner().run(unittest.TestSuite([TestCase('test')]))

# Generated at 2022-06-23 14:36:39.347224
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(NeutronClient, metaclass=Singleton):
        pass

    s1 = SingletonTest()
    s2 = SingletonTest()
    assert s1 is s2



# Generated at 2022-06-23 14:36:47.112219
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, attr):
            self.attr = attr

        def get_attr(self):
            return self.attr

    instance1 = TestSingleton(42)
    instance2 = TestSingleton('hello')
    instance3 = TestSingleton(1.0)

    assert instance1 is instance2 is instance3
    assert instance1.get_attr() == 42.0
    assert instance2.get_attr() == 'hello'
    assert instance3.get_attr() == 1.0

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:36:55.489579
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2):
            self._arg1 = arg1
            self._arg2 = arg2

        def get_args(self):
            return self._arg1, self._arg2
    test_arg1 = "arg1_value"
    test_arg2 = "arg2_value"
    instance1 = TestClass(test_arg1, test_arg2)
    instance2 = TestClass(test_arg1, test_arg2)
    instance3 = TestClass(test_arg1, test_arg2)
    assert instance1 is instance2
    assert instance1 is instance3
    assert instance1.get_args() == (test_arg1, test_arg2)

# Generated at 2022-06-23 14:36:59.426611
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    obj1 = SingletonTest('test')
    obj2 = SingletonTest('test2')
    assert obj1 == obj2
    assert obj1.arg == 'test'
    assert obj2.arg == 'test'

# Generated at 2022-06-23 14:37:07.542145
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton:
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    instance1 = MySingleton()
    assert instance1 == MySingleton()

    instance2 = MySingleton(1, 2, x=3, y=4)
    assert instance2 == MySingleton(1, 2, x=3, y=4)
    assert instance2 == MySingleton()
    assert instance2.args == (1, 2)
    assert instance2.kwargs == {'x': 3, 'y': 4}
    assert instance1.args == ()
    assert instance1.kwargs == {}

# Generated at 2022-06-23 14:37:16.987781
# Unit test for constructor of class Singleton
def test_Singleton():
    global singleton, singleton1

    class TestSingleton(object):
        """Test class for Singleton
        """
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    # instantiate the class
    singleton = TestSingleton()

    # verify the value of singleton.test is 'test'
    if singleton.test != 'test':
        raise ValueError('Test 1 Failed')

    # create singleton1
    singleton1 = TestSingleton()

    # check if singleton and singleton1 are the same object
    if singleton != singleton1:
        raise ValueError('Test 2 Failed')

    # modify the value of singleton1.test = 'test1'
    singleton1.test = 'test1'
    # verify the value of singleton.

# Generated at 2022-06-23 14:37:20.174593
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    test_inst1 = TestSingleton()
    test_inst2 = TestSingleton()
    assert test_inst1 == test_inst2
    return test_inst1

# Generated at 2022-06-23 14:37:27.731365
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    SingletonTest('first')
    assert SingletonTest('second') is not None
    assert SingletonTest('second').name == 'first'
    assert SingletonTest('second').name == 'first'
    assert SingletonTest('second').name == 'first'


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:37:31.641752
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    # create the first instance of the class
    instance_1 = TestSingleton()
    # create the second instance of the class
    instance_2 = TestSingleton()

    # the second instance must be equal to the first one
    assert instance_1 == instance_2

# Generated at 2022-06-23 14:37:33.059822
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    assert A() == a


# Generated at 2022-06-23 14:37:35.675092
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            # Let's prove this is only called once.
            try:
                self.__counter += 1
            except AttributeError:
                self.__counter = 1

        @property
        def counter(self):
            return self.__counter

    a = MySingleton()
    b = MySingleton()
    assert a is b
    assert a.counter == 1

# Generated at 2022-06-23 14:37:38.059792
# Unit test for constructor of class Singleton
def test_Singleton():
    # Test that Singleton class is not a singleton
    assert Singleton('a', (), {}) != Singleton('a', (), {})
    # Test that SingletonMetaclass is a singleton
    assert Singleton('a', (Singleton,), {}) is Singleton('a', (Singleton,), {})

# Generated at 2022-06-23 14:37:40.808485
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, value=0):
            self.value = value

    a = TestClass(5)
    b = TestClass()
    assert a.value == b.value
    a.value = 10
    assert a.value == b.value


# Generated at 2022-06-23 14:37:51.513105
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from six import PY2
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible.module_utils.six import with_metaclass

    class DummyClass(with_metaclass(Singleton, object)):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    if PY2:
        mock_super = '__builtin__.super'
    else:
        mock_super = 'builtins.super'

    with patch(mock_super) as super_mock:
        # Test if the lock is acquire to prevent multiple instantiation
        with patch.object(DummyClass, '__rlock') as lock_mock:
            lock_m