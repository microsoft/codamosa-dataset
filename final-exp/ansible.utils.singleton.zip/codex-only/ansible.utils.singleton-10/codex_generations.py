

# Generated at 2022-06-23 14:27:44.735994
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        pass

    # Singleton.__call__() creates an instance of the class
    # so if we get here it was successful.
    assert(isinstance(Test(), Test))

# Generated at 2022-06-23 14:27:47.680577
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():


    class A(object):
        __metaclass__ = Singleton

    inst1 = A()
    inst2 = A()

    # Because we instantiated the class twice, both instances should
    # refer to the same object.
    assert inst1 is inst2



# Generated at 2022-06-23 14:27:49.046011
# Unit test for constructor of class Singleton
def test_Singleton():
    class x(metaclass=Singleton):
        pass

    assert id(x()) == id(x())



# Generated at 2022-06-23 14:27:52.709562
# Unit test for constructor of class Singleton
def test_Singleton():

    class SingletonTestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('init')
            self.state = 0

        def update(self):
            self.state += 1

    assert SingletonTestClass is SingletonTestClass()
    assert SingletonTestClass().state == 0
    SingletonTestClass().update()
    assert SingletonTestClass().state == 1

# Generated at 2022-06-23 14:27:59.018662
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        """This is a Test class
        """
        __metaclass__ = Singleton

    # create an instance of Test class
    a = Test()
    # Then create another test class instance
    b = Test()
    # Check whether the instances are the same,
    # if it is the same, then it can pass the test.
    print(a == b)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:28:04.690454
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create a class C that uses the Singleton metaclass
    class C():
        __metaclass__ = Singleton

    # Try instantiating an object from the class
    # This should be the first and only instance
    c = C()

    # Try again, should return the same object
    c1 = C()

    # Ensure both c and c1 are the same object
    assert c == c1 == C.__instance

# Generated at 2022-06-23 14:28:07.849889
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    Foo = Singleton('Foo', (object,), dict(var=0))
    assert isinstance(Foo(), Foo)
    assert Foo() == Foo()
    Foo().var = 1
    assert Foo().var == 1

# Generated at 2022-06-23 14:28:12.466915
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            super(A, self).__init__()
            self.unique = 9

    a = A()
    b = A()
    assert(a.unique == 9)
    assert(b.unique == 9)
    assert(a is b)


# Generated at 2022-06-23 14:28:17.884732
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    a = S(1)
    b = S(2)
    c = S(3)

    assert a == b
    assert a == c
    assert b == c
    assert a.value == 1
    assert b.value == 1
    assert c.value == 1

# Generated at 2022-06-23 14:28:20.602948
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    
    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-23 14:28:26.408881
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = "bar"

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.bar = "foo"

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()



# Generated at 2022-06-23 14:28:32.226076
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert(t1.a == 1)
    assert(t2.a == 1)
    t1.a += 1
    assert(t1.a == 2)
    assert(t2.a == 2)
    assert(t1 is t2)

# Generated at 2022-06-23 14:28:36.710573
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    my_class1 = MyClass()
    my_class2 = MyClass()
    assert my_class1 is my_class2

# Generated at 2022-06-23 14:28:42.379254
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import sys
    import traceback
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a = A(1)
    assert a.a == 1

    b = A(2)
    assert b.a == 1
    assert b is a

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:28:45.950206
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = A()
    b = A()

    assert a == b
    assert a is b

# Generated at 2022-06-23 14:28:50.405065
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self, an_arg):
            self.an_arg = an_arg

    a = S('a')
    b = S('b')

    assert a is b



# Generated at 2022-06-23 14:28:58.313139
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton:
        """My singleton class"""
        __metaclass__ = Singleton

        def __init__(self):
            self.unique_name = 'unique name'

    class MySingleton2:
        """My singleton class"""
        __metaclass__ = Singleton

        def __init__(self):
            self.unique_name = 'unique name'

    # Check that two singleton instantiations return the same singleton
    assert MySingleton() == MySingleton()
    # Check that two singleton classes instantiations do not return the same singleton
    assert MySingleton() != MySingleton2()

# Generated at 2022-06-23 14:29:05.580305
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 123

    #assert isinstance(TestSingleton(), TestSingleton)
    #assert TestSingleton.__instance is None

    s1 = TestSingleton()
    assert isinstance(s1, TestSingleton)
    assert s1.value == 123

    s2 = TestSingleton()
    assert isinstance(s2, TestSingleton)
    assert s2.value == 123
    assert s2 is s1

    print('test_Singleton___call__ passed')

# Generated at 2022-06-23 14:29:13.943217
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, x=0):
            self.x = x

    a = Foo()
    b = Foo()
    assert a is b
    assert a.x == 0
    a.x = 5
    assert b.x == 5

    c = Foo(x=3)
    assert a is c
    assert c.x == 5

    d = Foo(x=10)
    assert a is d
    assert d.x == 5

# Generated at 2022-06-23 14:29:18.320389
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1(object):
        __metaclass__ = Singleton

    class Test2(object):
        __metaclass__ = Singleton

    assert Test1() is Test1()
    assert Test2() is Test2()

    assert Test1() is not Test2()
    assert Test1() != Test2()

# Generated at 2022-06-23 14:29:28.961490
# Unit test for constructor of class Singleton
def test_Singleton():
    class test: pass
    class test2(object): pass
    class test3(test2, test): pass

    # test should be Singleton class
    assert isinstance(test, Singleton)

    # test2 should not be a Singleton class
    assert not isinstance(test2, Singleton)

    # test3 should not be a Singleton class
    assert not isinstance(test3, Singleton)

    # create an instance of test
    t = test()
    # test should still be a Singleton class
    assert isinstance(test, Singleton)
    # the singleton instance of test should be the same as t
    assert test() == t

    # create an instance of test2
    t2 = test2()
    # test2 should not be a Singleton class
    assert not isinstance(test2, Singleton)
    #

# Generated at 2022-06-23 14:29:33.144372
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a Singleton class TestClass
    class TestClass(object):
        __metaclass__ = Singleton

    # Create TestClass instances
    tc1 = TestClass()
    tc2 = TestClass()

    # Make sure we get the same instance
    assert(tc1 == tc2)

# Generated at 2022-06-23 14:29:35.634176
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

    c1 = C()
    c2 = C()

    return c1 == c2



# Generated at 2022-06-23 14:29:38.668649
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass


    obj1 = TestSingleton()
    obj2 = TestSingleton()
    assert(obj1 == obj2)

# Generated at 2022-06-23 14:29:49.111044
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Class Singleton is not to be instantiated outside this module
    class A(object, metaclass=Singleton):
        a = 0
        def __init__(self):
            A.a += 1

    a1 = A()
    a2 = A()
    assert a1 is a2

    class B(object, metaclass=Singleton):
        b = 0
        def __init__(self):
            B.b += 1

    b1 = B()
    b2 = B()
    assert b1 is b2

    # Class A and B are not the same class
    assert a1 is not b1

    # Class A and B are singletons.
    assert A is a1
    assert B is b1


# Generated at 2022-06-23 14:29:51.966400
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    instance1 = TestClass()
    assert instance1  # an object is created

    # the original object is always returned
    instance2 = TestClass()
    assert id(instance1) == id(instance2)


# Generated at 2022-06-23 14:29:53.984443
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        pass
    assert TestSingleton() == TestSingleton()



# Generated at 2022-06-23 14:29:58.268761
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''
    Args:
      None

    Returns:
      None

    Raises:
      None
    '''

    class TestSingleton(object):
        __metaclass__ = Singleton

    singleton1 = TestSingleton()
    singleton2 = TestSingleton()
    assert singleton1 is singleton2

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:30:01.453531
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-23 14:30:07.054339
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo1(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("Foo1 initialized")

    class Foo2(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("Foo2 initialized")

    f1_obj1 = Foo1()
    f1_obj2 = Foo1()
    assert f1_obj1 is f1_obj2

    f2_obj1 = Foo2()
    f2_obj2 = Foo2()
    assert f2_obj1 is f2_obj2

# Generated at 2022-06-23 14:30:11.392425
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, msg):
            self.msg = msg

    instance1 = MySingleton('Hello')
    instance2 = MySingleton('World')
    assert instance1 == instance2

# Generated at 2022-06-23 14:30:20.485515
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass:
        def __init__(self):
            # In the source code, this instance variable happens to
            # be an instance of `Display`.
            self.display = 'foo'
            self.other_var = 'bar'

    # Create a singleton class by inheriting from TestClass and
    # by inheriting from Singleton. Because the class should
    # implement Singleton functionality, the class instantiation
    # should return the same object.
    SingletonTestClass = type('SingletonTestClass',
                              (TestClass, Singleton),
                              {})

    # Create the first instance of the singleton class.
    singleton_obj1 = SingletonTestClass()

    # This instance variable should be created by the constructor
    # of TestClass.
    assert(singleton_obj1.display == 'foo')

    #

# Generated at 2022-06-23 14:30:22.691054
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert(a is b)
    assert(a == b)

# Generated at 2022-06-23 14:30:26.581927
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = "SingletonTest"

    first_instance = SingletonTest()
    second_instance = SingletonTest()
    assert first_instance is second_instance
    assert first_instance.name == second_instance.name


# Generated at 2022-06-23 14:30:33.839559
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.counter = 0

        def inc(self):
            self.counter += 1

    assert(A() is A())

    A().inc()
    assert(A().counter == 1)

    A().inc()
    A().inc()
    assert(A().counter == 3)

    assert(A() is A())

    A().counter = 10
    assert(A().counter == 10)



# Generated at 2022-06-23 14:30:36.722045
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass

    class B(metaclass=Singleton):
        pass

    assert A() == A()
    assert B() == B()
    assert A() != B()
    assert B() != A()

# Generated at 2022-06-23 14:30:41.826989
# Unit test for constructor of class Singleton
def test_Singleton():
    class test1(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class test2(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert(test1 is test2)



# Generated at 2022-06-23 14:30:44.614926
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        v = 1
    a = A()
    b = A()
    assert a.v == 1
    assert a is b



# Generated at 2022-06-23 14:30:51.835813
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

    # __new__ was called and instanstiated the singleton
    assert isinstance(Foo(), Foo)
    assert Foo() is Foo()

    # __new__ was called and instanstiated the singleton
    assert isinstance(Bar(), Bar)
    assert Bar() is Bar()

    # only one instance is created for both classes
    assert not Foo() is Bar()



# Generated at 2022-06-23 14:31:02.222184
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from tests.unit.compat.mock import MagicMock

    class TestSingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    tc1 = TestSingletonClass('test1', 'test2')
    assert tc1.a == 'test1'
    assert tc1.b == 'test2'

    tc2 = TestSingletonClass('test3', 'test4')
    assert tc2.a == 'test1'
    assert tc2.b == 'test2'

    assert tc1 is tc2

    with MagicMock(side_effect=RuntimeError('cannot instantiate')) as mock_init:
        tm3 = TestSingletonClass('test5', 'test6')
        tm

# Generated at 2022-06-23 14:31:08.639836
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(object):
        """
        Test class that uses Singleton as its metaclass.
        """
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name
            """
            NOTE: We need a member to make it easy to tell
            the instances apart.
            """
    # 1st instance should be created
    x1 = X('first')
    # 2nd instance should not be created
    x2 = X('second')
    assert x1 == x2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:31:11.822283
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class Bar(Foo):
        def __init__(self):
            pass

    b1 = Bar()
    assert b1 is Bar()


# Generated at 2022-06-23 14:31:16.280580
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class One(object):
        __metaclass__ = Singleton

    a = One()
    b = One()
    assert a is b
    assert a.__class__ is b.__class__
    assert a.__class__.__name__ == 'One'

# Generated at 2022-06-23 14:31:21.992051
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            print("call init")
            self.val = value

    first = Foo(1)
    second = Foo(2)
    print(first.val)
    print(second.val)
    print(id(first))
    print(id(second))
    print(first is second)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:31:26.938516
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.v = value

    c1 = C('1')
    c2 = C('2')
    assert c1 is c2
    assert c1.v == '1'
    assert c2.v == '1'

# Generated at 2022-06-23 14:31:32.023636
# Unit test for constructor of class Singleton
def test_Singleton():
    class A:
        __metaclass__ = Singleton
        def __init__(self):
            self.data = 0

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.data == 0
    assert a2.data == 0
    a1.data = 1
    assert a1.data == 1
    assert a2.data == 1

# Generated at 2022-06-23 14:31:39.154165
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.counter = 0

        def increment(self):
            self.counter += 1

    c = MyClass()
    c.increment()
    assert c.counter == 1

    c = MyClass()
    c.increment()
    assert c.counter == 2

    d = MyClass()
    d.increment()
    assert d.counter == 3


# vim: set expandtab:ts=4:sw=4

# Generated at 2022-06-23 14:31:42.072581
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert(a1 is a2)

# Generated at 2022-06-23 14:31:48.356496
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo:
        __metaclass__ = Singleton
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    x = Foo(1, 2, 3)
    y = Foo(4, 5, 6)

    assert x is y
    assert x.a == 4
    assert y.b == 5
    assert x.c == 6

# Generated at 2022-06-23 14:31:52.973859
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    x = Test(1)
    y = Test(2)
    assert x.val == 1
    assert y.val == 1


# Generated at 2022-06-23 14:31:57.997115
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 1

    s1 = S()
    s2 = S()
    assert s1 is s2
    assert s1.value == 1
    s1.value = 2
    assert s2.value == 2
    assert s1 == s2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:32:04.908270
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    test_instance = TestClass('test_instance_one')
    assert test_instance.name == 'test_instance_one'

    test_instance_two = TestClass('test_instance_two')
    assert test_instance_two is test_instance
    assert test_instance_two.name == 'test_instance_one'

# Generated at 2022-06-23 14:32:06.922421
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            pass
    a = MyClass()
    b = MyClass()
    assert a is b

# Generated at 2022-06-23 14:32:11.691296
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.plugins.loader import PluginLoader
    assert(PluginLoader.__instance is None)
    PluginLoader.__instance = 1
    l = PluginLoader()
    assert(PluginLoader.__instance == 1)

# Unit test  for method __init__ of class Singleton

# Generated at 2022-06-23 14:32:16.254326
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("__init__")

    print("Create Instance")
    ins = Test()
    assert ins == Test()
    assert ins == Test()
    assert ins == Test()
    assert ins == Test()


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:32:21.304136
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    a = MySingleton('a')
    b = MySingleton('b')

    assert a is b
    assert a.name == 'b'

# Generated at 2022-06-23 14:32:27.475121
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """ When you create an object of class Singleton,
        it must create only one instance of the object.
    """
    class TestSingleton(metaclass=Singleton):
        def __init__(self, parm):
            self.parm = parm
    test_obj_1st = TestSingleton('1st')
    test_obj_2st = TestSingleton('2st')
    if not test_obj_1st == test_obj_2st:
        raise Exception('Error!')

# Generated at 2022-06-23 14:32:33.437001
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def get_id(self):
            return id(self)

    i1 = Test()
    j1 = Test()

    print(i1.get_id())
    print(j1.get_id())

    assert i1.get_id() == j1.get_id()



# Generated at 2022-06-23 14:32:35.978850
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        pass

    t1 = Test()
    t2 = Test()
    assert t1 is t2, "Singleton constructor failed"

# Generated at 2022-06-23 14:32:41.116027
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    test_class = SingletonTest('initial')
    assert test_class.val == 'initial'

    test_class = SingletonTest('new')
    assert test_class.val == 'initial'

# Generated at 2022-06-23 14:32:43.352101
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 == foo2

# Generated at 2022-06-23 14:32:46.837252
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class cls(object):
        __metaclass__ = Singleton

    cls1 = cls()
    cls2 = cls()

    print(cls1)
    print(cls2)
    print(cls1 is cls2)

test_Singleton___call__()

# Generated at 2022-06-23 14:32:48.813667
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
    ts = TestSingleton()
    ts2 = TestSingleton()
    assert ts == ts2

# Generated at 2022-06-23 14:32:59.035032
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def __str__(self):
            return 'Test'

    # __call__ should return the same instance
    assert Test() is Test()
    assert id(Test()) == id(Test())

    # verify that Singleton can be subclassed
    class TestSubclass(Test):
        def __str__(self):
            return 'TestSubclass'

    # __call__ should return the same instance
    assert Test() is Test()
    assert id(Test()) == id(Test())
    # verify that __call__ returns the same instance for subclass
    assert TestSubclass() is TestSubclass()
    assert id(TestSubclass()) == id(TestSubclass())
    assert Test() is not TestSubclass()

# Generated at 2022-06-23 14:33:03.076085
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 0

    a = TestClass()
    b = TestClass()

    assert a == b
    a.value += 1
    assert a.value == b.value

# Generated at 2022-06-23 14:33:05.432618
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-23 14:33:07.299565
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class _TestSingleton(metaclass=Singleton):
        pass

    assert _TestSingleton() is _TestSingleton()

# Generated at 2022-06-23 14:33:11.789001
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    # instances of MyClass must always be the same object
    assert MyClass('a') == MyClass('b')
    assert MyClass('b').value == 'b'
    assert MyClass('a').value == 'a'

# Generated at 2022-06-23 14:33:20.329264
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import types
    from threading import Thread

    # Simple class inheriting from Singleton
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    # Simple class not inheriting from Singleton
    class SingletonTest2(object):
        def __init__(self):
            pass

    # Use SingletonTest with args
    SingletonTest3 = type('SingletonTest3', (object,), {'__metaclass__': Singleton,
                                                         '__init__': lambda self, a, b: (setattr(self, 'a', a), setattr(self, 'b', b))})

    # Simple class not inheriting from Singleton

# Generated at 2022-06-23 14:33:25.224239
# Unit test for constructor of class Singleton
def test_Singleton():
    try:
        class MySingleton(object):
            __metaclass__ = Singleton
    # Check that any errors raised during class construction are TypeErrors
    except TypeError as e:
        assert False, ('Constructed an invalid singleton class, encountered error: {0}'.format(e))
    else:
        assert True, ('Constructed a valid singleton class')

# Generated at 2022-06-23 14:33:29.907563
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, a='a'):
            self.a = a

    assert MyClass('a') is MyClass()
    assert MyClass() is MyClass()
    assert MyClass('b') is MyClass()

# Generated at 2022-06-23 14:33:37.227413
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from random import randrange
    from threading import Thread

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = randrange(10)

    test_instances = []

    for _ in range(100):
        test_instances.append(Thread(target=SingletonTest))
        test_instances[-1].start()

    for index in range(len(test_instances)):
        test_instances[index].join()
        assert test_instances[index].value == test_instances[0].value



# Generated at 2022-06-23 14:33:43.223719
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    # instantiate singleton
    test_singleton1 = TestSingleton()

    assert test_singleton1 is TestSingleton()
    assert test_singleton1 == TestSingleton()
    assert test_singleton1 is not None

# Generated at 2022-06-23 14:33:50.292801
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    if a1.x != 1:
        raise Exception("test_Singleton___call__ failed for a1.x")
    if a2.x != 1:
        raise Exception("test_Singleton___call__ failed for a2.x")
    return 0



# Generated at 2022-06-23 14:33:55.690917
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 'test'

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert 'test' == t1.val
    assert t1 == t2


# Generated at 2022-06-23 14:33:57.517158
# Unit test for constructor of class Singleton
def test_Singleton():
    """Unit test for constructor of class Singleton.
    """

    class Foo:
        __metaclass__ = Singleton

        def __init__(self):
            pass

    foo1 = Foo()
    foo2 = Foo()

    assert foo1 == foo2

# Generated at 2022-06-23 14:34:01.881121
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, x=0):
            self.x = x

    assert isinstance(A(), A)
    assert A().x == 0

    a = A(1)
    assert a.x == 1

    b = A()
    assert b.x == 1
    assert a is b

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:34:04.887797
# Unit test for constructor of class Singleton
def test_Singleton():
    class classTest(object):
        __metaclass__ = Singleton

    classTest_1 = classTest()
    classTest_2 = classTest()

    assert classTest_1 == classTest_2

# Generated at 2022-06-23 14:34:09.879284
# Unit test for constructor of class Singleton
def test_Singleton():
    class Class(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    x = Class('foo')
    assert x.name == 'foo'

    y = Class('bar')
    assert y.name == 'foo'
    assert y is x

# Generated at 2022-06-23 14:34:20.045377
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class MySingletonWithArgs(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    my_singleton_1 = MySingleton()
    assert my_singleton_1 is MySingleton()

    my_singleton_2 = MySingletonWithArgs(1, 2)
    my_singleton_3 = MySingletonWithArgs(3, 4)
    assert my_singleton_2 is my_singleton_3
    assert (my_singleton_2.arg1, my_singleton_2.arg2) == (3, 4)

# Generated at 2022-06-23 14:34:24.525057
# Unit test for constructor of class Singleton
def test_Singleton():
    global a
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    a = A('a')
    b = A('b')
    if a is not b:
        raise Exception("Singleton class not working")


# Generated at 2022-06-23 14:34:32.720866
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        # __metaclass__ = Singleton
        def __init__(self):
            self.x = "test"


    a = TestSingleton()
    b = TestSingleton()
    c = TestSingleton()

    assert a is b
    assert b is c
    assert a is c

    assert a.x is b.x
    assert b.x is c.x
    assert a.x is c.x

    a.x = "test2"
    assert a.x is b.x
    assert b.x is c.x
    assert a.x is c.x

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:34:37.487544
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 'a'
    obj_1 = SingletonTest()
    obj_2 = SingletonTest()
    assert obj_1 is obj_2

# Generated at 2022-06-23 14:34:42.316653
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    # Create two instances of A
    a = A()
    b = A()

    # Check to see if they are the same object
    if a is not b:
        raise AssertionError("%r is not %r" % (a, b))


# Generated at 2022-06-23 14:34:50.475455
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import os
    import tempfile

    def cleanup(filename):
        if os.path.exists(filename):
            os.unlink(filename)

    def write_to_file(filename, data):
        f = open(filename, 'a')
        f.write(data)
        f.close()

    # Test temporary file class
    class TempFile(object):
        __metaclass__ = Singleton

        class Lock(object):
            def __init__(self):
                self.lock = RLock()

            def lock(self):
                self.lock.acquire()

            def unlock(self):
                self.lock.release()

        def __init__(self):
            self.name = None
            self.lock = TempFile.Lock()
            self.readers = 0


# Generated at 2022-06-23 14:34:52.722580
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingle(object):
        __metaclass__ = Singleton

    ts1 = TestSingle()
    ts2 = TestSingle()
    assert ts1 is ts2

# Generated at 2022-06-23 14:34:56.184383
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    assert id(A('first')) == id(A('second'))



# Generated at 2022-06-23 14:35:01.130831
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyTestClass(object, metaclass=Singleton):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    assert(MyTestClass(1, 2, 3) is MyTestClass(4, 5, 6))

# Generated at 2022-06-23 14:35:03.730427
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass:
        __metaclass__ = Singleton

    instance_one = MyClass()
    instance_two = MyClass()
    assert instance_one == instance_two

# Generated at 2022-06-23 14:35:05.147482
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
    a = MySingleton()
    b = MySingleton()
    assert a == b

# Generated at 2022-06-23 14:35:08.124969
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    obj1 = MySingleton()
    obj2 = MySingleton()

    assert(obj1 is obj2)

# Generated at 2022-06-23 14:35:17.795212
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = 'FOO'

    f1 = Foo()
    f2 = Foo()
    f1.hello = 'world'
    try:
        assert f1 is f2
        assert f1.foo == 'FOO'
        assert f2.foo == 'FOO'
        assert f1.hello == 'world'
        assert f2.hello == 'world'
        assert f1.__class__ is f2.__class__
        assert Foo.__class__ is Singleton
        print('Singleton unit test passed')
    except Exception as e:
        print('Singleton Unit Test Failed')
        raise e

# Generated at 2022-06-23 14:35:22.436518
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 'test'

    test = TestSingleton()
    assert test.value == 'test'

    test2 = TestSingleton()
    assert test2.value == 'test'
    assert test is test2

# Generated at 2022-06-23 14:35:27.980317
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test 1
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    test = Test()
    assert(Test() is test), "Test 1: __call__ of class Singleton doesn't work."

    # Test 2
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2
    test = Test('test', 'test')
    assert(Test('test', 'test') is test), "Test 2: __call__ of class Singleton doesn't work."

test_Singleton___call__()



# Generated at 2022-06-23 14:35:36.615432
# Unit test for constructor of class Singleton
def test_Singleton():
  # test the result of Singleton() is an instance of Singleton
  assert isinstance(Singleton(), Singleton)

  class Foo(object):
    __metaclass__ = Singleton

  class Bar(object):
    __metaclass__ = Singleton

  # test the result of Foo(), Foo(), Bar(), Bar() is an instance of
  # Singleton class Foo, Singleton class Bar.
  # In other words, there's only one instance of each Singleton class.
  assert isinstance(Foo(), Foo)
  assert isinstance(Bar(), Bar)

  assert Foo() is not Bar()



# Generated at 2022-06-23 14:35:40.383600
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    obj1 = TestSingleton()
    obj2 = TestSingleton()
    assert obj1 is obj2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:35:48.106230
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, arg1, arg2):
            print("__init__ %s %s"%(arg1, arg2))
            self.arg1 = arg1
            self.arg2 = arg2

    x = A(1, 2)
    y = A(3, 4)
    print(x is y)
    print(x.arg1, x.arg2)
    print(y.arg1, y.arg2)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:35:52.651777
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 10

    a = SingletonTest()
    b = SingletonTest()
    assert a is b
    assert a.x == b.x == 10



# Generated at 2022-06-23 14:35:54.763420
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Empty(metaclass=Singleton):
        def __init__(self):
            self.val = 1

    assert Empty().val == 1
    assert Empty().val == 1

# Generated at 2022-06-23 14:36:01.513522
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    # test with arguments
    first = SingletonTest("first")
    second = SingletonTest("second")
    assert first is second
    assert first.value == "first"
    assert second.value == "first"

    # test without arguments
    class SingletonTestNoArgument(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    first = SingletonTestNoArgument()
    second = SingletonTestNoArgument()
    assert first is second

# Generated at 2022-06-23 14:36:09.448038
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a=1):
            self.a = a

    # create the first instance of A
    a = A()
    # it should have an attribute a with value 1
    assert(a.a == 1)
    # create another instance of A
    b = A()
    # it should have the same attributes as a
    assert(id(a) == id(b))
    # make sure a's attribute a is the same as b's attribute a
    assert(a.a == b.a)



# Generated at 2022-06-23 14:36:15.249193
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    obj_1 = TestClass()
    obj_2 = TestClass()

    try:
        assert obj_1 is obj_2
    except AssertionError:
        print("Singleton error: obj_1 is not the same object as obj_2")


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-23 14:36:17.534926
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-23 14:36:19.835889
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        pass

    ts1 = TestSingleton()
    ts2 = TestSingleton()

    assert ts1 is ts2



# Generated at 2022-06-23 14:36:23.451412
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            print("TestSingleton's __init__ is run!")
            self.foo = foo

    assert TestSingleton('foo').foo == 'foo'
    assert TestSingleton('foo').foo == 'foo'

# Generated at 2022-06-23 14:36:26.656493
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
    a = TestSingleton()
    b = TestSingleton()
    assert a == b


# Generated at 2022-06-23 14:36:33.318274
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    test1 = Test('first', 'second')
    test2 = Test('third', 'fourth')

    assert test1.arg1 == 'first'
    assert test1.arg2 == 'second'
    assert test1 is test2

# Generated at 2022-06-23 14:36:36.163289
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = X()
    b = X()
    assert(a is b)
    assert('Singleton' in str(X))

# Generated at 2022-06-23 14:36:40.739753
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert A.__instance == None
    assert A() == A()
    assert type(A.__instance) == A
    assert B.__instance == None
    assert B() == B()
    assert type(B.__instance) == B

# B tests the metaclass inheritance

# Generated at 2022-06-23 14:36:44.060700
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    assert isinstance(TestSingleton(), TestSingleton)

# Generated at 2022-06-23 14:36:49.124493
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    from nose.tools import assert_is_instance

    foo = Foo()
    assert_is_instance(foo, Foo)

    bar = Foo()

    from nose.tools import assert_equal

    assert_equal(foo, bar)


# Generated at 2022-06-23 14:36:53.574401
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass:
        __metaclass__ = Singleton

        def __init__(self, x, y):
            self.x = x
            self.y = y

    instance1 = SingletonClass(10, 20)
    instance2 = SingletonClass(10, 20)

    assert instance1 == instance2
    assert instance1 is instance2
    assert instance1.x == instance2.x
    asse

# Generated at 2022-06-23 14:36:55.943077
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
    assert TestClass() is TestClass()



# Generated at 2022-06-23 14:37:06.508208
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test : Call the Singleton class with/without arguments
    # Expect : create only one instance of the class with the first call
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass.__instance

    a = TestClass(foo='bar')
    b = TestClass()
    assert a is b

    # Test : Call the Singleton class with/without arguments in a multithreaded environment
    # Expect : create only one instance of the class

    import threading
    from multiprocessing import Queue, Process
    from Queue import Empty
    from time import sleep

    # Create 1000 instances of TestClass in multiple threads
    # Create a sentinel so the main process knows when it's done
    sentinel = object()
    q = Queue()
    NUM_THREADS = 2
   

# Generated at 2022-06-23 14:37:11.715464
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        """Test class"""
        __metaclass__ = Singleton

        def __init__(self):
            super(Test, self).__init__()
            self.name = 'test'

    t1 = Test()
    t2 = Test()
    assert id(t1) == id(t2)

# Generated at 2022-06-23 14:37:16.835042
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 0

    a = TestSingleton()
    print(a.value)
    print("The hash value of a is:")
    print(hash(a))
    b = TestSingleton()
    print("The hash value of b is:")
    print(hash(b))
    print("The value of a and b are the same:")
    print(a.value == b.value)



# Generated at 2022-06-23 14:37:20.968985
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert Singleton.__call__.__doc__.splitlines()[0] == "Metaclass for classes that wish to implement Singleton"
    assert Singleton.__call__.__doc__.splitlines()[1] == "functionality.  If an instance of the class exists, it's returned,"
    assert Singleton.__call__.__doc__.splitlines()[2] == "otherwise a single instance is instantiated and returned."


# Generated at 2022-06-23 14:37:24.737914
# Unit test for constructor of class Singleton
def test_Singleton():
    """Singleton() -> Single object Instance
    """
    class Foo(object):
        pass

    class Bar(object):
        __metaclass__ = Singleton

    assert Foo() is not Foo()
    assert Bar() is Bar()

# Generated at 2022-06-23 14:37:29.626245
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    class B(A):
        def __init__(self):
            self.b = 1

    a = A()
    b = B()

    assert a is b
    assert a.a is b.a

# Generated at 2022-06-23 14:37:35.043673
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, name=None):
            self.name = name

    a = SingletonTest(name="foo")
    b = SingletonTest(name="bar")

    assert a is b
    assert a.name == b.name == "foo"

# Generated at 2022-06-23 14:37:40.080331
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    # first instance
    test1 = Test('test')
    assert test1.name == 'test'

    # second instance
    test2 = Test('test2')
    assert test1 == test2 and test1.name == test2.name

# Generated at 2022-06-23 14:37:45.184319
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo:
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    instance1 = Foo(1)
    instance2 = Foo(2)

    assert instance1 == instance2
    assert id(instance1) == id(instance2)
    assert instance1.a == 1
    assert instance2.a == 1
