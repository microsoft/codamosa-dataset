

# Generated at 2022-06-23 14:27:45.733273
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = A()
    b = A()
    assert a is b
    assert id(a) == id(b)



# Generated at 2022-06-23 14:27:56.967629
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.log = []
            self.log.append(args)
            self.log.append(kwargs)

        def add_to_log(self, *args, **kwargs):
            self.log.append(args)
            self.log.append(kwargs)

    t1 = TestSingleton('t1_args', kw1='t1_kwargs')
    t2 = TestSingleton('t2_args', kw2='t2_kwargs')

    t3 = TestSingleton('t3_args', kw3='t3_kwargs')

    assert t1 == t2
    assert t3 == t2

    t1.add_to_log

# Generated at 2022-06-23 14:27:59.957030
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    
    assert a1 == a2, "Singleton failed."

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:28:06.885380
# Unit test for constructor of class Singleton
def test_Singleton():
    class A:
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 'A'

    class B:
        __metaclass__ = Singleton
        def __init__(self):
            self.b = 'B'

    a = A()
    b = B()
    assert(a.a == 'A')
    assert(b.b == 'B')

    assert(a is A())
    assert(b is B())

# Generated at 2022-06-23 14:28:11.606504
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self, test_var):
            self.test_var = test_var

    f1 = Foo(test_var=1)
    f2 = Foo(test_var=2)
    assert f1 is f2
    assert f1.test_var == 2
    assert f2.test_var == 2



# Generated at 2022-06-23 14:28:16.660086
# Unit test for constructor of class Singleton
def test_Singleton():
    # actual code
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = "my singleton class"
    # test
    x = MyClass()
    y = MyClass()
    assert x == y

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:28:19.372556
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a
    a = A(1)
    b = A(2)
    assert a is b

# Generated at 2022-06-23 14:28:20.512361
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass


# Generated at 2022-06-23 14:28:25.578181
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object, metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    a = A(1)
    assert a.a == 1
    b = A(2)
    assert b.a == 1
    assert a == b
    assert id(a) == id(b)


# Generated at 2022-06-23 14:28:29.943908
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    a1 = A('foo')
    a1_1 = A('bar')
    a2 = A('baz')
    assert a1 == a1_1 == a2

# Generated at 2022-06-23 14:28:41.733398
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            super(Test, self).__init__()

            self._args = args
            self._kwargs = kwargs

        def __str__(self):
            return "Test(%s, %s)" % (self._args, self._kwargs)

        def __repr__(self):
            return "Test(%s, %s)" % (self._args, self._kwargs)

    a = Test("foo", "bar")
    b = Test("baz", "bim")

    assert(a is b)

    assert("foo" in str(a))
    assert("bar" in str(a))
    assert("baz" in str(a))

# Generated at 2022-06-23 14:28:43.370008
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() == A()


# Generated at 2022-06-23 14:28:47.077732
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object, metaclass=Singleton):
        def __init__(self):
            pass
    o1 = C()
    o2 = C()
    assert(o1 is o2)


# Generated at 2022-06-23 14:28:50.453472
# Unit test for constructor of class Singleton
def test_Singleton():
    # check that class is a singleton
    class A(metaclass=Singleton):
        pass

    a = A()
    b = A()
    assert a == b
    assert id(a) == id(b)

# Generated at 2022-06-23 14:28:56.005160
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 0

        def incr(self):
            self.x += 1

    # create an instance and call incr()
    a = SingletonTestClass()
    a.incr()

    # create a second instance, it should return  the same instance of a
    b = SingletonTestClass()
    assert a is b

    # call incr() on b, it should increment x in the same instance as a
    b.incr()

    # assert that the value of x in instance a is 2
    assert 2 == a.x


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:28:58.283817
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert a is b


# Generated at 2022-06-23 14:29:02.897117
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.b = 1

    foo_0 = Foo()
    foo_1 = Foo()
    assert foo_0 == foo_1
    assert foo_0 is foo_1



# Generated at 2022-06-23 14:29:04.432710
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class One(object):
        __metaclass__ = Singleton

    instance1 = One()
    instance2 = One()
    assert instance1 is instance2

# Generated at 2022-06-23 14:29:06.017919
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    assert a1 is A()


# Generated at 2022-06-23 14:29:13.315177
# Unit test for constructor of class Singleton
def test_Singleton():
    '''Verify Singleton() can be instantiated'''
    assert Singleton is Singleton
    assert Singleton.__doc__ == 'Metaclass for classes that wish to implement Singleton\n    functionality.  If an instance of the class exists, it\'s returned,\n    otherwise a single instance is instantiated and returned.\n    '
    assert Singleton.__init__.__doc__ == None
    assert Singleton.__call__.__doc__ == None

# Generated at 2022-06-23 14:29:17.284007
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''
    Test Singleton.__call__
    '''
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    assert id(foo1) == id(foo2)



# Generated at 2022-06-23 14:29:19.937500
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = "foo"

    assert Foo() is Foo()
    assert Foo().x == "foo"

# Generated at 2022-06-23 14:29:23.604058
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Single(object):
        __metaclass__ = Singleton

    # For the first call of __call__ , instance of Single should be created.
    single = Single()
    assert single is not None
    # For the second call of __call__ , single shouldn't be re-created.
    single2 = Single()
    assert single2 is single



# Generated at 2022-06-23 14:29:32.603457
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    class C(object):
        __metaclass__ = Singleton

    c1 = C()
    c2 = C()

    # we expect these to be the same
    assert c1 is c2

    with patch('threading.RLock') as mock_lock:
        c3 = C()
        # we expect this to be the same
        assert c3 is c2

        # we expect RLock's constructor to have been called
        mock_lock.assert_called_once()

# Generated at 2022-06-23 14:29:38.749925
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self, a=1):
            self.a = a

    class B:
        def __init__(self, b=1):
            self.b = b

    i = 0
    while i < 1000:
        assert A() is A()
        assert A(i) is A(i)
        assert B() is not B()
        assert B(i) is not B(i)
        i += 1



# Generated at 2022-06-23 14:29:43.261261
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class X(metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    X(1)
    X(2)  # Overrides the previous instance
    X(3)  # Overrides the previous instance
    assert X.__instance.a == 3

# Generated at 2022-06-23 14:29:45.509967
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-23 14:29:54.297109
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread

    class DummySingleton(metaclass=Singleton):
        def __init__(self):
            pass

    d1 = DummySingleton()
    d2 = DummySingleton()
    assert id(d1) == id(d2)

    ds = [DummySingleton]
    ts = [Thread(target=DummySingleton) for _ in range(100)]
    for t in ts:
        t.start()

    for t in ts:
        t.join()

    assert len(ds) == 1
    ds = ds[0]
    assert id(ds) == id(d1)

# Generated at 2022-06-23 14:29:57.204729
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Define a class using Singleton
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 == test2

# Generated at 2022-06-23 14:30:04.537675
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Fixture
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    # Test
    assert MyClass.__instance == None
    assert MyClass.__rlock.acquire(False) == True
    assert MyClass(1) == MyClass.__instance
    assert MyClass(2) == MyClass.__instance
    assert MyClass.__instance.value == 1

    # Cleanup


# Generated at 2022-06-23 14:30:13.570535
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    test1 = A('test1', 'test2', 'test3')
    test2 = A('test1', 'test2', 'test3')
    test3 = A('test1', 'test2', 'test4')

    assert test1.a == 'test1'
    assert test2.b == 'test2'
    assert test3.c == 'test4'
    assert id(test1) == id(test2)
    assert id(test3) != id(test2)

# Generated at 2022-06-23 14:30:16.220948
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            print('Initializing...')

    print(A() is A())
    print(A() is A())

# Generated at 2022-06-23 14:30:24.470330
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = 'aa'

    class B(object):
        __metaclass__ = Singleton
        def __init__(self, arg1):
            self.name = 'bb'+arg1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1 == a2
    assert a1.name == 'aa'
    assert a2.name == 'aa'
    assert a1.name == a2.name

    b1 = B('1')
    b2 = B('2')
    assert b1 is b2
    assert b1 == b2
    assert b1.name == 'bb2'
    assert b2.name == 'bb2'
   

# Generated at 2022-06-23 14:30:27.380821
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 0

    assert isinstance(Test(), Test)
    assert Test() is Test()

# Generated at 2022-06-23 14:30:32.992235
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(metaclass=Singleton):
        def __init__(self, a, b):
            self.__a = a
            self.__b = b

        def print(self):
            print (self.__a, self.__b)

    t = SingletonTest(1, 2)
    assert hasattr(t, '__a')
    assert hasattr(t, '__b')
    assert hasattr(t, 'print')
    assert hasattr(t, '__instance')
    assert hasattr(t, '__rlock')
    assert not hasattr(t, '__call__')


# Generated at 2022-06-23 14:30:36.308788
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        def __init__(self, value):
            self._value = value

    t1 = Test(1)
    t2 = Test(2)

    print(repr(t1))
    print(repr(t2))

# Generated at 2022-06-23 14:30:42.422783
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 1

    tc = TestClass()
    tc.value = 2
    tc2 = TestClass()
    assert tc is tc2
    assert tc2.value == 2


# Base class for simple classes with only read-write attributes
# and no objects returned by methods

# Generated at 2022-06-23 14:30:48.383601
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            pass

        def get_a(self):
            return 'a'

    a = A()
    assert a.get_a() == 'a'
    b = A()
    assert b.get_a() == 'a'
    assert a is b

# Generated at 2022-06-23 14:30:50.991774
# Unit test for constructor of class Singleton
def test_Singleton():
    class testClass(object):
        __metaclass__ = Singleton

    with open('path/to/file', 'w') as f:
        f.write('content')

    assert testClass() is testClass()

# Generated at 2022-06-23 14:30:55.446581
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.parsing.loader import DataLoader

    # Test creation of a unique instance of a class
    instance1 = DataLoader()
    assert isinstance(instance1, DataLoader)

    # Test multiple call of __call__ on class
    instance2 = DataLoader()
    assert instance1 == instance2

# Generated at 2022-06-23 14:30:58.395475
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x=0, y=0):
            self.x = x
            self.y = y
    a1 = A()
    assert a1
    a2 = A(x=0, y=1)
    assert a2
    assert a1.x == a2.x
    assert a1.y == a2.y
    assert id(a1) == id(a2)

# Generated at 2022-06-23 14:31:01.572415
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    a = A()
    b = A()

    assert(a == b)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:31:09.759366
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton
        def __init__(self, foo):
            self.foo = foo

    class SingletonClass2(object):
        __metaclass__ = Singleton

        def __init__(self, bar):
            self.bar = bar

    sc = SingletonClass('a')
    sc2 = SingletonClass('b')
    sc2 = SingletonClass2('b')
    sc2 = SingletonClass2('c')
    sc3 = SingletonClass('b')
    assert sc.foo == 'a', 'foo=%s' % sc.foo
    assert sc2.foo == 'a', 'foo=%s' % sc2.foo
    assert sc2.bar == 'c', 'bar=%s' % sc2.bar
    assert sc3

# Generated at 2022-06-23 14:31:15.212174
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    # Initalize class
    test_class_1 = TestClass()
    assert(test_class_1 != None)

    # Test that Singleton functions
    test_class_2 = TestClass()
    assert(test_class_1 == test_class_2)

# Generated at 2022-06-23 14:31:17.180481
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            # this is guaranteed to be called only once.
            self.__value = 10

    a = A()
    b = A()
    assert id(a) == id(b)

# Generated at 2022-06-23 14:31:24.650056
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global it_was_called
    it_was_called = 0

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            global it_was_called
            it_was_called += 1

    a = A()
    b = A()

    assert a == b
    assert it_was_called == 1

    # Test that we can change the singleton
    # if we want to.

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            global it_was_called
            it_was_called += 1

    a = A()
    assert a != b
    assert it_was_called == 2


# Generated at 2022-06-23 14:31:28.531226
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()

    assert foo1 is foo2
    assert id(foo1) == id(foo2)

test_Singleton()

# Generated at 2022-06-23 14:31:33.904308
# Unit test for constructor of class Singleton
def test_Singleton():
    class ClassA(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    class ClassB(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.b = 1

    a0 = ClassA()
    a1 = ClassA()
    assert a0.a == a1.a
    assert a0.a == a1.a

    b0 = ClassB()
    b1 = ClassB()
    assert b0.b == b1.b
    assert b0.b == b1.b

    assert a1.a != b1.b

# Generated at 2022-06-23 14:31:38.888868
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(metaclass=Singleton):
        def __init__(self):
            self.singleton = True
    # create two instances
    test_instance_1 = TestClass()
    test_instance_2 = TestClass()
    # assert that both variables point to the same object
    assert test_instance_1 is test_instance_2
    # assert that the object is a singleton
    assert test_instance_1.singleton is True
    assert test_instance_2.singleton is True



# Generated at 2022-06-23 14:31:47.014387
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingleTest(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    t1 = SingleTest('a', 'b')
    t2 = SingleTest('1', '2')

    assert t1.arg1 == 'a'
    assert t1.arg2 == 'b'
    assert t2.arg1 == 'a'
    assert t2.arg2 == 'b'
    assert t1 == t2

# Generated at 2022-06-23 14:31:52.507827
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    test_singleton___call__
    """
    a = Singleton('a', (), {})
    a1 = a()
    a2 = a()
    assert a1 is a2

    b = Singleton('b', (), {})
    b1 = b()
    b2 = b()
    assert b1 is b2

    assert a1 is not b1

# Generated at 2022-06-23 14:31:56.059059
# Unit test for constructor of class Singleton
def test_Singleton():
	class A(metaclass = Singleton):
		def __init__(self):
			self.a = 1
			print("Class A initialized!")

	# Here should print "Class A initialized!"
	test = A()


if __name__ == '__main__':
	test_Singleton()

# Generated at 2022-06-23 14:32:06.699334
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.first_var = 4
            self.second_var = 5

        def increment_first_var(self):
            self.first_var = self.first_var + 1

        def increment_second_var(self):
            self.second_var = self.second_var + 1

    class MyClass2(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.first_var = 7
            self.second_var = 9

        def increment_first_var(self):
            self.first_var = self.first_var + 1

        def increment_second_var(self):
            self.second_var = self.second_var + 1


# Generated at 2022-06-23 14:32:11.310870
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton

    a = S()
    b = S()

    assert a is b
    assert a == b
    assert id(a) == id(b)


# Generated at 2022-06-23 14:32:18.220105
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class SingletonTest(object):
        __metaclass__ = Singleton

    # for testing, we'll add a value to this class so we can see it change
    SingletonTest.val = 'A'

    # Create an instance
    s = SingletonTest()

    # Give it a value
    s.val = 1

    # Create a second instance
    s2 = SingletonTest()

    # Assert that the two instances are the same instance
    assert(s == s2)
    assert(s is s2)

    # Assert that the value is the same
    assert(s.val == s2.val)
    assert(s.val == 1)

# Generated at 2022-06-23 14:32:22.614811
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestClass('test1')
    b = TestClass('test2')
    assert a.name == b.name

# Generated at 2022-06-23 14:32:30.115250
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Check that an instance is created and returned on first call
    from ansible.module_utils._text import to_text
    instance_1 = Singleton('SomeClass', tuple(), {})
    assert isinstance(instance_1, Singleton)
    assert isinstance(instance_1, type)

    # Check that the instance created is returned if __call__ is called
    # on the class again
    instance_2 = Singleton('SomeClass', tuple(), {})
    assert isinstance(instance_2, Singleton)
    assert isinstance(instance_2, type)
    assert isinstance(instance_1, Singleton)
    assert isinstance(instance_1, type)
    assert instance_1 == instance_2



# Generated at 2022-06-23 14:32:33.891880
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert(a is b)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:32:39.034887
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, s):
            self.s = s

    obj1 = SingletonTest("obj1")
    obj2 = SingletonTest("obj2")
    assert obj1 is obj2
    assert obj2.s == "obj1"


# Generated at 2022-06-23 14:32:41.966895
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = MyClass()
    b = MyClass()
    assert(a is b)

# Generated at 2022-06-23 14:32:50.047871
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestClass(object):
        """Class for testing Singleton functionality."""
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2, arg3):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3

    test_obj_1 = TestClass(1, 2, 3)
    test_obj_2 = TestClass(4, 5, 6)

    assert test_obj_1 is test_obj_2
    assert test_obj_1.arg1 == 1
    assert test_obj_1.arg2 == 2
    assert test_obj_1.arg3 == 3
    assert test_obj_2.arg1 == 1
    assert test_obj_2.arg2 == 2
    assert test_obj_2.arg3 == 3

# Generated at 2022-06-23 14:32:56.796817
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, a, b=2):
            self.a = a
            self.b = b

    assert MyClass(a=1, b=4).__dict__ == MyClass(a=2, b=4).__dict__
    assert MyClass(a=1, b=4).__dict__ != MyClass(a=1, b=3).__dict__

# Generated at 2022-06-23 14:33:03.965300
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestCase(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 1

    # Check multiple instantiations of the class
    t1 = TestCase()
    t2 = TestCase()

    assert t1 is t2
    assert t1.val is t2.val

    # Change the value of the original class
    t1.val = 2

    assert t2.val is 2

    t1.val = 1

# Generated at 2022-06-23 14:33:09.819435
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = None

    # Create a SingletonTest object.
    obj1 = SingletonTest()
    obj1.x = 5

    # Get the SingletonTest object again.
    obj2 = SingletonTest()
    if obj1 is not obj2:
        raise Exception("Not a Singleton")

    # Verify that obj2 has the same value.
    if obj2.x != 5:
        raise Exception("Expected obj2.x = 5, but got %d" % obj2.x)

# Generated at 2022-06-23 14:33:14.062231
# Unit test for constructor of class Singleton
def test_Singleton():
    class singleton_obj(object):
        __metaclass__ = Singleton

        def __init__(self, id):
            self.id = id

    a = singleton_obj(1)
    b = singleton_obj(2)

    assert id(a) == id(b)

# Generated at 2022-06-23 14:33:15.663155
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
    instance_1 = TestSingleton()
    instance_2 = TestSingleton()
    instance_1.data = 123
    assert instance_1 is instance_2
    assert instance_2.data == 123

# Generated at 2022-06-23 14:33:18.631335
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    test = TestSingleton()
    check = TestSingleton()
    assert(test == check)



# Generated at 2022-06-23 14:33:21.806874
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        pass

    # New instance
    t1 = Test()

    # Same instance
    t2 = Test()

    assert t1 is t2

# Generated at 2022-06-23 14:33:26.772568
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class test(object):
        __metaclass__ = Singleton

    test_inst1 = test()
    test_inst2 = test()

    if test_inst1 is not test_inst2:
        raise AssertionError('The same instance of class test should be '
                             'returned since test is a Singleton')


# Generated at 2022-06-23 14:33:31.467016
# Unit test for constructor of class Singleton
def test_Singleton():
    from py.test import raises
    class Test(object):
        __metaclass__ = Singleton
    assert Test() is Test()
    with raises(RuntimeError):
        Test.__instance = object()
        Test()

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:33:33.128845
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton('Singleton', (), {}) == Singleton('Singleton', (), {})

# Generated at 2022-06-23 14:33:37.269142
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    class MyClass2(object):
        __metaclass__ = Singleton

    a1 = MyClass()
    a2 = MyClass()
    a3 = MyClass2()
    a4 = MyClass2()

    assert a1 == a2
    assert a3 == a4
    assert a1 != a3

# Generated at 2022-06-23 14:33:44.096285
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(with_metaclass(Singleton, object)):
        def __init__(self, name):
            self.name = name

    f1 = Foo('f1')
    f2 = Foo('f2')

    assert f1.name == 'f1'
    assert f1 == f2

    f3 = Foo('f3')
    assert f3 == f1



# Generated at 2022-06-23 14:33:47.265331
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    c1 = TestSingleton()
    c2 = TestSingleton()
    assert c1 is c2


# Generated at 2022-06-23 14:33:50.152331
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()

    assert foo1 is foo2


# Generated at 2022-06-23 14:34:00.571825
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread
    from time import sleep
    from unittest import TestCase

    class State(object):
        def __init__(self):
            self.updated = False

        def update(self):
            self.updated = True

    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, state):
            self.state = state

        def update(self):
            self.state.update()

    class Test(TestCase):
        def test_update(self):
            state = State()
            foo = Foo(state)
            t1 = Thread(target=foo.update)
            t2 = Thread(target=foo.update)
            t1.start()
            t2.start()
            t1.join()
            t2.join()
            self.assertTrue

# Generated at 2022-06-23 14:34:04.600226
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = A()
    b = A()
    assert a is b
    assert a.x == b.x == 1



# Generated at 2022-06-23 14:34:12.860715
# Unit test for constructor of class Singleton
def test_Singleton():
    """Test that the constructor of class Singleton works as intended.
    """
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 0

        def increment(self):
            self.val += 1

    test1 = TestClass()
    test2 = TestClass()
    assert test1 is test2
    test1.increment()
    assert test1.val == test2.val

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:34:16.901921
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    foo1 = Foo()
    assert foo1
    foo2 = Foo()
    assert foo1 == foo2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:34:19.365495
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2


# Generated at 2022-06-23 14:34:25.123305
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.num = 1

    # Instantiate object
    t = Test()

    # Since t creates a singleton object, another call to Test() will
    # return the same object
    t2 = Test()
    assert t == t2
    assert t is t2

    # t2 should have the value of num set to 1
    assert t2.num == 1

    # Now, change the value of num in t to 2
    t.num = 2

    # If t is a singleton, then t2 will have the value of num as
    # 2 as well
    assert t2.num == 2

    # Undo changes
    t.num = 1

if __name__ == "__main__":
    test_Singleton

# Generated at 2022-06-23 14:34:31.691912
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    foo1 = Foo(42)
    foo2 = Foo(43)

    # should be the same instance
    assert(foo1 == foo2)

    # should both have arg value of 42
    assert(foo1.arg == 42)
    assert(foo2.arg == 42)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:34:34.743295
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert MyClass() is MyClass()

# Generated at 2022-06-23 14:34:37.623436
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    # test if this is singleton
    assert id(MyClass()) == id(MyClass())

# Generated at 2022-06-23 14:34:45.412405
# Unit test for constructor of class Singleton
def test_Singleton():
    class Singleton_Test(object):
        __metaclass__ = Singleton

    # Create the singleton:
    s1 = Singleton_Test()
    assert (isinstance(s1, Singleton_Test))

    # Get the singleton:
    s2 = Singleton_Test()
    assert (s1 is s2)

    # Test that the singleton is always the same:
    s1.sValue = "First"
    s2.sValue = "Second"
    assert (s1.sValue == "Second")

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:34:49.484042
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    c = C(1)
    assert(c == C(2))
    assert(c is C(2))
    assert(c.a == 1)



# Generated at 2022-06-23 14:34:52.606714
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'Laurent'

    t1 = SingletonTest()
    t2 = SingletonTest()

    assert(t1 == t2)

# Generated at 2022-06-23 14:34:57.364168
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import mock

    class TestClass(metaclass=Singleton):
        __init__ = mock.Mock()

    x = TestClass()
    assert TestClass() is x
    assert TestClass.__init__.call_count == 1, TestClass.__init__.call_count



# Generated at 2022-06-23 14:35:02.131065
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Teko(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.tekoval = 123
    o1 = Teko()
    o2 = Teko()
    assert(o1.tekoval == o2.tekoval)

test_Singleton___call__()

# Generated at 2022-06-23 14:35:04.399482
# Unit test for constructor of class Singleton
def test_Singleton():
    class_a = Singleton('class_a', (object,), {})
    assert class_a.__instance is None
    a = class_a()
    assert a is not None
    assert class_a.__instance == a
    b = class_a()
    assert a is b

# Generated at 2022-06-23 14:35:05.392230
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-23 14:35:09.390844
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self, num):
            self.num = num

    s1 = S(1)
    s2 = S(2)
    assert (s1.num == 1)
    assert (s2.num == s1.num)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:35:14.589089
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = MyClass(10)
    b = MyClass(20)

    assert a.x == b.x
    assert a is b

# Generated at 2022-06-23 14:35:20.021421
# Unit test for constructor of class Singleton
def test_Singleton():
    # create single instance for test
    class singleton(object):
        __metaclass__ = Singleton

    # create two instances
    # Note: If Singleton works correctly, both should be the same
    s1 = singleton()
    s2 = singleton()

    # test if two instances equal
    assert s1 == s2

# Generated at 2022-06-23 14:35:26.248187
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    class B(A):
      pass

    a = A()
    b = B()

    assert a is b

    import unittest

    class TestSingleton(unittest.TestCase):
        def test_simple_singleton(self):
            class TestClass(object):
                __metaclass__ = Singleton

            a = TestClass()
            b = TestClass()

            self.assertTrue(a is b)

# Generated at 2022-06-23 14:35:32.331793
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''
    Testing the Singleton.__call__ method
    '''
    class TestClass(object):
        __metaclass__ = Singleton

    t1 = TestClass()
    t2 = TestClass()
    assert t1 == t2, "The '__call__' method of class Singleton failed"


# Generated at 2022-06-23 14:35:39.214397
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        """Class A"""
        __metaclass__ = Singleton
    """Class A"""
    a = A()
    """Create object 'a' of class A"""
    b = A()
    """Create object 'b' of class A"""
    assert(id(a) == id(b))
    """If true, then only one object 'a' is created with id equal to id of object 'b'"""


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:35:45.423403
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.data = 1

    a = A()
    assert a.data == 1

    a.data = 2
    b = A()
    assert a.data == 2
    assert b.data == 2

    b.data = 3
    assert a.data == 3
    assert b.data == 3

    a = A()
    c = A()
    assert a.data == 3
    assert c.data == 3

    c.data = 4
    assert a.data == 4
    assert c.data == 4


# Generated at 2022-06-23 14:35:52.362117
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.num = 0

        def increment(self):
            self.num += 1

    a = Test()
    a.increment()
    assert(a.num == 1)
    b = Test()
    b.increment()
    assert(b.num == 2)
    assert(a.num == b.num)

# Generated at 2022-06-23 14:35:54.789586
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    x = Test()
    y = Test()

    assert id(x) == id(y), "Singletons must be identical"

# Generated at 2022-06-23 14:36:02.510013
# Unit test for constructor of class Singleton
def test_Singleton():
    """Unit test for the Singleton class constructor"""

# Generated at 2022-06-23 14:36:05.532346
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

    x = TestClass()
    y = TestClass()

    assert(x is y)

# Generated at 2022-06-23 14:36:09.208685
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Make sure the class is actually a singleton
    class MyClass(object):
        __metaclass__ = Singleton
        pass

    _instance1 = MyClass()
    _instance2 = MyClass()
    assert id(_instance1) == id(_instance2)

# Generated at 2022-06-23 14:36:13.766409
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self, test=None):
            pass
    assert Foo() is Foo()
    assert Bar() is Bar()

# Generated at 2022-06-23 14:36:17.922637
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    import nose.tools as nt
    nt.assert_is(Foo(), Foo())


if __name__ == "__main__":
    print("Running self tests for Singleton class...")
    test_Singleton___call__()

# Generated at 2022-06-23 14:36:20.802063
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("test __init__")

    t1 = Test()
    t2 = Test()
    assert t1 is t2


# Generated at 2022-06-23 14:36:25.350908
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    c1 = TestClass(10)
    assert c1.x == 10
    c2 = TestClass(20)
    assert c2 == c1
    assert c2.x == 10
    return True

# Generated at 2022-06-23 14:36:35.905626
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # common attributes
    name = "name"
    bases = (1,)
    dct = dict()

    # make_Class is a classname generator
    make_Class = lambda n: type(n, (object,), dict(__metaclass__=Singleton))

    # Class1, Class2 and Class3 are three Singleton classes with the same __call__
    # method
    Class1 = make_Class(name + "1")
    Class2 = make_Class(name + "2")
    Class3 = make_Class(name + "3")

    # instance1 is a instance of Class1, instance2 is an instance of Class2
    instance1 = Class1.__call__()
    instance2 = Class2.__call__()

    # instance3 is an instance of Class3
    instance3 = Class3()

    # instance

# Generated at 2022-06-23 14:36:42.111450
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Check normal instantiation
    class Normal(object):
        pass

    normal1 = Normal()
    normal2 = Normal()

    assert normal1 != normal2

    # Check singleton instantiation
    class SingletonTest(object):
        __metaclass__ = Singleton

    singleton1 = SingletonTest()
    singleton2 = SingletonTest()

    assert singleton1 == singleton2

# Generated at 2022-06-23 14:36:46.558172
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test:
        __metaclass__ = Singleton

        def __init__(self):
            self.new = True

    t1 = Test()
    t2 = Test()

    assert(t1 is t2)
    assert(t1.new)

    t1.new = False
    assert(not t2.new)

# Generated at 2022-06-23 14:36:50.721893
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = A()
    b = A()
    assert a == b


# Generated at 2022-06-23 14:36:57.739473
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object, metaclass=Singleton):
        def __init__(self):
            pass

    class MyDerivedClass(MyClass):
        def __init__(self):
            super(MyDerivedClass, self).__init__()

    obj1 = MyClass()
    obj2 = MyClass()
    obj3 = MyDerivedClass()
    assert id(obj1) == id(obj2)
    assert id(obj1) != id(obj3)

# Generated at 2022-06-23 14:37:01.897477
# Unit test for constructor of class Singleton
def test_Singleton():
     class MyClass(object):
         __metaclass__ = Singleton
         def __init__(self):
             self.s = None
             self.name = "MyClass"
     assert MyClass().name == "MyClass"

# Generated at 2022-06-23 14:37:04.024253
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() == A()




# Generated at 2022-06-23 14:37:10.585129
# Unit test for constructor of class Singleton
def test_Singleton():
    # Class definition
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    # Instantiation of object
    obj1 = TestClass(1, 2)
    obj2 = TestClass(3, 4)
    print(obj1 is obj2)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:37:13.312439
# Unit test for constructor of class Singleton
def test_Singleton():
    class B:
        __metaclass__ = Singleton

    class C:
        pass

    import inspect

    assert inspect.signature(B) == inspect.signature(C)
    assert B() == B()

# Generated at 2022-06-23 14:37:14.513754
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  from time import time
  assert time() == time()


# Generated at 2022-06-23 14:37:17.551125
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = TestSingleton()
    b = TestSingleton()
    # unit test for a == b
    assert a == b


# Generated at 2022-06-23 14:37:20.692531
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()

    assert(foo1 == foo2)

# Generated at 2022-06-23 14:37:27.346694
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    ## Arrange
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, global_state):
            self.global_state = global_state

    ## Act
    o1 = MySingleton('state_1')
    o2 = MySingleton('state_2')

    ## Assert
    assert o1 is o2
    assert o2.global_state == 'state_1'



# Generated at 2022-06-23 14:37:31.889591
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object):
        __metaclass__ = Singleton

    assert C() is not None
    assert C() is C()
    assert C() == C()

    C_ = C()
    C_sing = C()
    assert C_ is C_sing
    assert C_ == C_sing
    assert C_ is not None
    assert C_sing is not None

# Generated at 2022-06-23 14:37:35.892681
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    class MySingleton2(object):
        __metaclass__ = Singleton

    assert MySingleton() == MySingleton()
    assert MySingleton() != MySingleton2()

# Generated at 2022-06-23 14:37:38.520950
# Unit test for constructor of class Singleton
def test_Singleton():
    test1 = Singleton("test1", object, object)
    test2 = Singleton("test2", object, object)
    assert test1 == test2


# Generated at 2022-06-23 14:37:42.344962
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest

    class SingletonClass(object):
        __metaclass__ = Singleton

    singleton_1 = SingletonClass()
    singleton_2 = SingletonClass()

    assert id(singleton_1) == id(singleton_2)

# Generated at 2022-06-23 14:37:48.694465
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self):
            self.name = 'test'
            self.seq = 0
            self.lock = RLock()

    t1 = Test()
    t2 = Test()

    assert t1 is t2
    assert t1.name == t2.name

    with t1.lock:
        t1.seq += 1
    with t2.lock:
        t2.seq += 1

    assert t1.seq == t2.seq