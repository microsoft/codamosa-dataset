

# Generated at 2022-06-23 14:27:45.732949
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.id = 0

    foo_1 = Foo()
    foo_2 = Foo()

    assert foo_1 is foo_2

# Generated at 2022-06-23 14:27:56.968036
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test1(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    class Test2(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 'a'

    class Test3(object):
        __metaclass__ = Singleton

    class Test4(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a + b

    class Test5(object):
        __metaclass__ = Singleton

    assert Test1() is Test1()
    assert Test2() is Test2()
    assert Test3() is Test3()
    assert Test4(1, 2) is Test4(1, 2)
    assert Test5()

# Generated at 2022-06-23 14:27:57.345053
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-23 14:27:59.362758
# Unit test for constructor of class Singleton
def test_Singleton():
    s = Singleton("name", [], {'a':1})


# Generated at 2022-06-23 14:28:05.749474
# Unit test for constructor of class Singleton
def test_Singleton():
    class test_singleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            print('__init__ called')

    with test_singleton() as a1:
        print('a1 got')
        with test_singleton() as a2:
            print('a2 got')
            assert a1 is a2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:28:08.573711
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo = Foo()
    foo_bar = Foo()
    assert foo is foo_bar, 'Foo() should return a single instance.'

# Generated at 2022-06-23 14:28:13.163516
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self, value=None):
            self.value = value

    test1 = Test('value')
    assert test1.value == 'value'
    test2 = Test()
    assert test2.value == 'value'
    assert test1 is test2
    test3 = Test()
    assert test1 is test3



# Generated at 2022-06-23 14:28:22.003465
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.data = []

        def append(self, value):
            if value not in self.data:
                self.data.append(value)

        def __repr__(self):
            return "%s" % self.data

    class SubTestSingleton(TestSingleton):
        pass

    a = TestSingleton()
    a.append(42)
    b = TestSingleton()
    b.append(23)

    sub_a = SubTestSingleton()
    sub_a.append(42)
    sub_b = SubTestSingleton()
    sub_b.append(23)

    assert a is b
    assert sub_a is sub_b

# Generated at 2022-06-23 14:28:27.051948
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonExample(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 0

        def increment(self):
            self.test += 1

    s = SingletonExample()
    s.increment()
    assert s.test == 1
    t = SingletonExample()
    assert s is t

# Generated at 2022-06-23 14:28:32.625761
# Unit test for constructor of class Singleton
def test_Singleton():
    # test if two instances of Singleton class share the same id
    class TestSingleton1(object):
        __metaclass__ = Singleton

    class TestSingleton2(object):
        __metaclass__ = Singleton

    assert id(TestSingleton1()) == id(TestSingleton1())
    assert id(TestSingleton2()) == id(TestSingleton2())


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 14:28:42.484448
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'A'

    a1 = A()
    a2 = A()

    assert a1 is a2
    assert a1.name == a2.name == 'A'

    # test metaclass inheritance
    class B(A):
        def __init__(self):
            super(B, self).__init__()
            self.name = 'B'

    b1 = B()
    b2 = B()

    assert b1 is b2
    assert b1.name == b2.name == 'B'
    assert a1 is b1

# Generated at 2022-06-23 14:28:50.718167
# Unit test for constructor of class Singleton
def test_Singleton():

    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.count = 0

        def __str__(self):
            return 'count is %d' % self.count

    a = MyClass()
    a.count = a.count + 1
    b = MyClass()
    b.count = b.count + 2
    c = MyClass()
    c.count = c.count + 3
    assert a is b
    assert b is c
    print(a)

# Generated at 2022-06-23 14:28:53.356150
# Unit test for constructor of class Singleton
def test_Singleton():
    class DummyClass:
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    assert DummyClass('bar') == DummyClass('car')
    assert DummyClass().foo == 'bar'

# Generated at 2022-06-23 14:28:57.405671
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a
    a = A('a')
    b = A('b')
    assert a.a == 'a'
    assert a == b

# Generated at 2022-06-23 14:29:01.558396
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class singleton_class():
        __metaclass__ = Singleton

    c1 = singleton_class()
    c2 = singleton_class()
    c3 = singleton_class()

    assert c1 == c2
    assert c2 == c3
    assert c3 == c1

# Generated at 2022-06-23 14:29:04.335252
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert a is b
# /Unit test for method __call__ of class Singleton

# Generated at 2022-06-23 14:29:08.563349
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.instance_id = 0

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 is test2
    assert test1.instance_id == test2.instance_id

    test1.instance_id = 1
    assert test1 is test2
    assert test1.instance_id == test2.instance_id

# Generated at 2022-06-23 14:29:18.981712
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            # This line is necessary to test the __rlock
            # implemented in the __call__ method of Singleton.
            # When you instantiate a class that has a Singleton
            # metaclass, the line below will be executed twice
            # if __rlock is not implemented, but only once if __rlock
            # is implemented.
            print("I am testing if Singleton____call__ is call only once")

    # test the __call__ method of the Singleton metaclass
    s1 = TestSingleton()
    print(s1)
    s2 = TestSingleton()
    print(s2)



# Generated at 2022-06-23 14:29:29.797060
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):

        # TestClass is a singleton
        __metaclass__ = Singleton

        def __init__(self):
            self.var = 10

        def getvar(self):
            return self.var

        def setvar(self, newvar):
            self.var = newvar

    # First instance created
    t1 = TestClass()
    if t1.getvar() != 10:
        raise AssertionError("Initialization Test Failed")
    else:
        print("Initialization Test Passed")

    # Change the value of var
    t1.setvar(20)
    if t1.getvar() != 20:
        raise AssertionError("Update Test Failed")
    else:
        print("Update Test Passed")

    # Now create another instance, this should return t1

# Generated at 2022-06-23 14:29:39.470717
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 0

        def inc(self):
            self.val += 1

    Foo.c = 1
    Bar.c = 2

    def called_once(object):
        assert object.val == 1
        object.inc()
        assert object.val == 2

    foo = Foo()
    bar = Bar()
    bar1 = Bar()

    foo.c == 1
    bar.c == 2

    foo.b = 2
    bar.b = 3

    assert foo.b == 2
    assert bar.b == 3
    assert foo.c == 1
    assert bar.c == 2


# Generated at 2022-06-23 14:29:46.066436
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''
    Unit test the __call__ method of the Singleton metaclass
    '''
    import threading

    class Foo(object):
        __metaclass__ = Singleton

    assert Foo() is Foo()

    # other threads should return the same instance
    def f():
        assert Foo() is Foo()
    
    threads = [threading.Thread(target=f) for i in range(10)]
    for t in threads:
        t.start()

# Generated at 2022-06-23 14:29:54.142121
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class myClass():
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 0

        def inc(self):
            self.i += 1

    x = myClass()
    x.inc()
    y = myClass()
    y.inc()
    z = myClass()
    z.inc()
    r1 = (x, x.i)
    r2 = (y, y.i)
    r3 = (z, z.i)
    assert x is y is z
    assert r1 == r2 and r2 == r3


# Generated at 2022-06-23 14:29:56.508343
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    instance1 = MySingleton()
    instance2 = MySingleton()

    assert instance1 == instance2
    assert instance1 is instance2

# Generated at 2022-06-23 14:30:00.673957
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo:
        __metaclass__ = Singleton

    class Bar:
        __metaclass__ = Singleton

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()

# Generated at 2022-06-23 14:30:05.668372
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def incr_value(self):
            self.value += 1

    test_obj = TestClass()
    assert test_obj.value == 0
    test_obj.incr_value()
    assert test_obj.value == 1
    test_obj = TestClass()
    assert test_obj.value == 1


# Generated at 2022-06-23 14:30:11.013937
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    def func():
        a = A()
        assert a is not None
        return a

    a1 = func()
    a2 = func()

    assert a1 is a2

# Generated at 2022-06-23 14:30:18.214875
# Unit test for constructor of class Singleton
def test_Singleton():
    class Dog(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    d1 = Dog("Fido")
    d2 = Dog("Spot")
    d3 = Dog("Spike")
    if (d1.name, d2.name, d3.name) != ("Fido", "Fido", "Fido"):
        raise Exception("Test failed: expected Fido, Fido, Fido but got %s, %s, %s" % (d1.name, d2.name, d3.name))

# Generated at 2022-06-23 14:30:26.042353
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # This class is used only to test the Singleton class.
    # pylint: disable=too-few-public-methods
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingleton2(object):
        __metaclass__ = Singleton

    class TestSingleton3(object):
        __metaclass__ = Singleton

    test1 = TestSingleton()
    assert test1 is TestSingleton()

    test2 = TestSingleton2()
    assert test2 is TestSingleton2()

    test3 = TestSingleton3()
    assert test3 is TestSingleton3()

    assert test1 is not test2
    assert test1 is not test3
    assert test2 is not test3



# Generated at 2022-06-23 14:30:28.581814
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        pass

    assert MyClass() == MyClass()
    assert id(MyClass()) == id(MyClass())
    assert type(MyClass()) == MyClass


# Generated at 2022-06-23 14:30:35.901803
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test if, when same class is created multiple time, only one instance of this class is created.
    
    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    t1 = Test()
    t2 = Test()
    t3 = Test()

    assert t1 is t2
    assert t2 is t3



# Generated at 2022-06-23 14:30:39.924695
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.counter = 0

        def inc(self):
            self.counter += 1

    instance1 = TestClass()
    assert type(instance1) == TestClass
    assert instance1.counter == 0
    instance1.inc()
    instance1.inc()
    instance2 = TestClass()
    assert type(instance2) == TestClass
    assert instance2.counter == 2



# Generated at 2022-06-23 14:30:42.624054
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-23 14:30:47.658657
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a = A()
    assert a.a == 1

    a.a = 2
    b = A()
    assert b.a == 2

# Generated at 2022-06-23 14:30:49.552787
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Result(object):
        pass
    result = Result()

    class Example(metaclass=Singleton):
        def __init__(self):
            self.result = result

    assert Example() is Example()
    assert result is Example().result


# Generated at 2022-06-23 14:30:51.093117
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    assert Foo() == Foo()


# Generated at 2022-06-23 14:30:54.183143
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:30:57.612365
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    p1 = TestSingleton()
    p2 = TestSingleton()

    assert p1 == p2
    assert p1 is p2

# Generated at 2022-06-23 14:31:02.449055
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    # Create 2 objects of class Test
    test_obj1 = Test()
    test_obj2 = Test()

    # Test for object equality
    assert(test_obj1 == test_obj2)

    # Test for object id equality
    assert(id(test_obj1) == id(test_obj2))



# Generated at 2022-06-23 14:31:03.915477
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MeSingleton(object):
        __metaclass__ = Singleton

    # Call for the first time, Instance is created
    me1 = MeSingleton()

    # Call for the second time, same instance returned
    me2 = MeSingleton()

    assert me1 == me2

# Generated at 2022-06-23 14:31:12.972541
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        pass

    class B(A):
        __metaclass__ = Singleton

    class C(A):
        pass

    b1 = B()
    b2 = B()
    c1 = C()
    c2 = C()

    assert b1 == b2
    assert b1 != c1
    assert b2 != c2
    assert b1 is b2
    assert b1 is not c1
    assert b2 is not c2
    assert c1 != c2
    assert c1 is not c2

    if hasattr(b1, '__weakref__'):
        assert b1.__weakref__() is b2
        assert b2.__weakref__() is b1
        assert c1.__weakref__() is c2
        assert c2.__weakref__

# Generated at 2022-06-23 14:31:18.283702
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TempClass(object):
        __metaclass__ = Singleton

    a = TempClass()
    b = TempClass()
    print("a = %s, b = %s" % (a, b))
    assert (a is b)


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:31:21.714540
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self, x=0):
            self.x = x

    assert Foo().x == 0
    assert Foo(x=1) is Foo(x=2)
    assert Foo(x=1).x == 2

# Generated at 2022-06-23 14:31:23.593315
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() == A()



# Generated at 2022-06-23 14:31:26.507504
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    a = Foo()
    assert id(a) == id(Foo())


# Generated at 2022-06-23 14:31:31.364220
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('Ctor called')

    obj1 = Test()
    obj2 = Test()

    assert not obj1 is None
    assert obj1 is obj2

if __name__ == '__main__':
    # self test
    test_Singleton()

# Generated at 2022-06-23 14:31:34.783751
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-23 14:31:36.383562
# Unit test for constructor of class Singleton
def test_Singleton():

    class Foo(object):
        __metaclass__ = Singleton

    assert Foo() == Foo()
    assert not Foo() != Foo()
# End unit test

# Generated at 2022-06-23 14:31:39.556320
# Unit test for constructor of class Singleton
def test_Singleton():

    class SingletonTest(object):
        __metaclass__ = Singleton

    instance1 = SingletonTest()
    instance2 = SingletonTest()

    assert(instance1 == instance2)

# Generated at 2022-06-23 14:31:50.970879
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Singleton is an abstract class
    class A(metaclass=Singleton):
        def __init__(self, arg1=None, arg2=None):
            self.arg1 = arg1
            self.arg2 = arg2

    # Create instances of class A
    a1 = A(1, 2)
    a2 = A()
    assert a1.arg1 == 1 and a1.arg2 == 2
    assert a2.arg1 is None and a2.arg2 is None
    assert a1 is a2

    # Make sure that you don't get an instance
    # if class A is an instance of another class
    b = object()
    assert A is not b
    assert A() is not b and A() is not b()

if __name__ == "__main__":
    test_Singleton___call

# Generated at 2022-06-23 14:31:53.111172
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    a = MyClass()
    b = MyClass()

    assert a is b

# Generated at 2022-06-23 14:31:54.977054
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    obj1 = Foo()
    obj2 = Foo()

    assert obj1 == obj2

# Generated at 2022-06-23 14:32:00.075341
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingleton2(object):
        __metaclass__ = Singleton

    assert isinstance(TestSingleton(), TestSingleton)
    assert isinstance(TestSingleton2(), TestSingleton2)

    # Confirm that different Singleton classes return different instances
    assert TestSingleton() != TestSingleton2()

    # Confirm that repeated calls to __call__ return the same instance
    assert TestSingleton() is TestSingleton()
    assert TestSingleton2() is TestSingleton2()

# Generated at 2022-06-23 14:32:10.024286
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S1(object):
        __metaclass__ = Singleton

    class S2(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.attr = 'foo'

    s1 = S1()
    assert id(s1) == id(S1())

    s2 = s2_2 = S2()
    assert id(s2) == id(S2())
    assert id(s2_2) == id(S2())
    assert s2.attr == 'foo'

    s1_1 = S1()
    assert id(s1) == id(s1_1)

    assert id(s1) != id(s2)

# Generated at 2022-06-23 14:32:15.479798
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Class(object):
        __metaclass__ = Singleton
    assert Class() == Class()
    class SubClass(Class):
        pass
    assert SubClass() == Class()
    assert SubClass() == SubClass()
    assert SubClass() == SubClass()
    class SubSubClass(SubClass):
        pass
    assert SubSubClass() == SubClass()
    assert SubSubClass() == Class()

# Generated at 2022-06-23 14:32:19.861576
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    a = MyClass()
    b = MyClass()
    assert id(a) == id(b)

# Generated at 2022-06-23 14:32:25.768227
# Unit test for constructor of class Singleton
def test_Singleton():
    class DummyClass(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    a = DummyClass(1)
    assert type(a) is DummyClass
    assert a.x == 1
    b = DummyClass(2)
    assert type(b) is DummyClass
    assert a is b
    assert a.x == 1
    assert b.x == 1

# Generated at 2022-06-23 14:32:30.509053
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    obj1 = MyClass(1)
    obj2 = MyClass(2)

    assert obj1.val == 1
    assert obj2.val == 1
    assert obj1 is obj2



# Generated at 2022-06-23 14:32:41.474544
# Unit test for constructor of class Singleton
def test_Singleton():
    import pytest

    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingleton2(object):
        __metaclass__ = Singleton

    class TestSingleton3(object):
        __metaclass__ = Singleton

    class TestSingleton4(object):
        __metaclass__ = Singleton

    class TestSingleton5(object):
        __metaclass__ = Singleton

    class TestSingleton6(object):
        __metaclass__ = Singleton

    instance1 = TestSingleton()
    instance2 = TestSingleton2()
    instance3 = TestSingleton3()
    instance4 = TestSingleton4()
    instance5 = TestSingleton5()
    instance6 = TestSingleton6()

    assert(isinstance(instance1, TestSingleton))

# Generated at 2022-06-23 14:32:46.641613
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Class1(object):
        __metaclass__ = Singleton

    class Class2(object):
        __metaclass__ = Singleton

    obj1 = Class1()
    obj2 = Class1()
    print("obj1 == obj2: {}".format(obj1 is obj2))

    obj3 = Class2()
    obj4 = Class2()
    print("obj3 == obj4: {}".format(obj3 is obj4))

# Generated at 2022-06-23 14:32:53.998500
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    class TestNotSingleton(object):
        def __init__(self):
            self.x = 1

    test = Test()
    test_not = TestNotSingleton()
    assert test.x == 1
    assert test.x == test_not.x

    test.x = 100
    assert test.x == test_not.x


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:32:57.362035
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = 'foo'

    a, b = Foo(), Foo()

    assert a == b
    assert a.foo == b.foo

test_Singleton()

# Generated at 2022-06-23 14:33:01.164193
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_var = 0

    test_singleton = TestSingleton()
    assert test_var == 0

# Generated at 2022-06-23 14:33:04.396080
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = Foo()
    b = Foo()
    return a is b


# Generated at 2022-06-23 14:33:06.571095
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Class(object):
        __metaclass__ = Singleton

    a = Class()
    b = Class()
    assert a == b
    assert a is b

# Generated at 2022-06-23 14:33:08.863781
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    x = A()
    y = A()

    assert x == y


# Generated at 2022-06-23 14:33:18.222732
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class A(object):
        __metaclass__ = Singleton
    class B(object):
        __metaclass__ = Singleton

    assert(A() is A())
    assert(B() is B())
    assert(A() is not B())

    class A(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value
    class B(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    assert(A('foo') is A('bar'))
    assert(B('foo') is B('bar'))
    assert(A('foo') is not B('bar'))

    class C(object):
        __metaclass__ = Singleton
       

# Generated at 2022-06-23 14:33:24.396739
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 1

    a = A()
    assert a.val == 1
    a.val = 2
    b = A()
    assert a is b
    assert b.val == 2

# Ensure that the Singleton class itself is a singleton.
test_Singleton___call__()

# Generated at 2022-06-23 14:33:29.857211
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__= Singleton

        def __init__(self):
            self.name = "TEST"

        def get_name(self):
            return self.name

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1.get_name() == test2.get_name()

# Generated at 2022-06-23 14:33:32.573918
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-23 14:33:36.226536
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    instance1 = MySingleton(1)
    instance2 = MySingleton('1')

    assert instance1.arg == instance2.arg

# Generated at 2022-06-23 14:33:42.153713
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(with_metaclass(Singleton, object)):
        __something = ""

        def __init__(self, a, b):
            super(SingletonTest, self).__init__()
            self.__something = a + b

        def __repr__(self):
            return self.__something

    # Test that SingletonTest is actually a Singleton
    st1 = SingletonTest("a", "b")
    st2 = SingletonTest("c", "d")
    print(st1 == st2)
    assert st1 == st2


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:33:45.387524
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        pass
    class Bar(Foo):
        pass
    assert Foo() is Foo()
    assert Foo() is Bar()
    assert Foo() is not None

# Generated at 2022-06-23 14:33:47.711207
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    test = Test()
    assert test is Test()


# Generated at 2022-06-23 14:33:53.841046
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    ''' test class Singleton can create a single instance '''

    class A():
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    a = A()
    assert a.value == 0
    a.value = 10
    a2 = A()
    assert a2.value == a.value == 10



# Generated at 2022-06-23 14:33:59.984630
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.instance = 0

    f1 = Foo()
    assert f1.instance == 0
    f1.instance = 1
    assert f1.instance == 1

    f2 = Foo()
    assert f1 is f2
    assert f2.instance == 1
    f2.instance = 2
    assert f1.instance == 2
    assert f2.instance == 2


test_Singleton()

# Generated at 2022-06-23 14:34:04.028351
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'Singleton'

    a = A()
    b = A()

    assert(a is b)


# Generated at 2022-06-23 14:34:06.611044
# Unit test for constructor of class Singleton
def test_Singleton():
    class Object(object):
        __metaclass__ = Singleton

    assert Object() == Object()


# Generated at 2022-06-23 14:34:13.641697
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    # Create first instance
    instance1 = MyClass('value1')
    # Check value
    assert instance1.value == 'value1'

    # Create second instance
    instance2 = MyClass('value2')
    # Check that the values are the same
    assert instance2.value == 'value1'
    # Check that the instances are the same
    assert instance1 is instance2

# Generated at 2022-06-23 14:34:15.434581
# Unit test for constructor of class Singleton
def test_Singleton():
  assert Singleton(1)
  assert Singleton(1)

# Generated at 2022-06-23 14:34:18.681191
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    t1 = SingletonTest()
    t2 = SingletonTest()

    assert(t1 == t2)

# Generated at 2022-06-23 14:34:21.596287
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, arg1):
            self.arg1 = arg1

    a = A('foo')
    assert a.arg1 == 'foo'
    b = A('bar')
    assert b == a

# Generated at 2022-06-23 14:34:24.220242
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    a, b = Foo(), Foo()
    assert a == b


# Generated at 2022-06-23 14:34:30.740599
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 42

    m1 = MySingleton()
    assert isinstance(m1, MySingleton)
    m2 = MySingleton()
    assert isinstance(m2, MySingleton)
    assert id(m1) == id(m2)
    assert m1.value == 42
    assert m2.value == 42


# Generated at 2022-06-23 14:34:32.903873
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        pass

    obj1 = MyClass()
    obj2 = MyClass()

    assert obj1 is obj2


# Generated at 2022-06-23 14:34:36.039895
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()


# Generated at 2022-06-23 14:34:38.751791
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = Foo()
    b = Foo()

    assert a is b

# Generated at 2022-06-23 14:34:42.021359
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 0

    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.b = 1

    a = A()
    b = B()
    assert id(a) == id(A())
    assert id(b) == id(B())
    assert id(a) != id(b)

    a.a = 2
    assert a.a == A().a


# Generated at 2022-06-23 14:34:44.513222
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        pass

    a = MyClass()
    b = MyClass()
    assert a is b



# Generated at 2022-06-23 14:34:52.377553
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class A(metaclass=Singleton):
        def __init__(self):
            self.name = "a"

    class B(metaclass=Singleton):
        def __init__(self):
            self.name = "b"

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()

    assert(a1 == a2)
    assert(b1 == b2)

    assert(a1.name == "a")
    assert(b1.name == "b")

    a1.name = "c"
    assert(a1.name == "c")
    assert(a2.name == "c")



# Generated at 2022-06-23 14:34:54.909783
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()

    assert f1 is f2, "Singleton class should always return the same instance"



# Generated at 2022-06-23 14:34:57.506985
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.val = value

    a = A(5)
    b = A(10)
    assert(a.val == 5)
    assert(b.val == 5)

# Generated at 2022-06-23 14:35:02.316078
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    assert A() is A()
    assert isinstance(A(), A)
    assert A() is not B()
    assert isinstance(B(), B)
    assert B() is B()

# Generated at 2022-06-23 14:35:07.280612
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a=None):
            self.a = a

    a = A()
    assert a.a == None
    b = A()
    assert b.a == None
    assert a is b
    a.a = 'test'
    assert a.a == 'test'
    assert b.a == 'test'
    assert a is b

    c = A(42)
    assert c.a == 42
    assert a is c



# Generated at 2022-06-23 14:35:09.380162
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton is Singleton
    assert Singleton is not type
    assert Singleton is not object



# Generated at 2022-06-23 14:35:13.325619
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    tc1 = TestClass()
    tc2 = TestClass()

    assert tc1 == tc2

# Generated at 2022-06-23 14:35:16.416186
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self, data):
            self.data = data

    assert SingletonClass('foo') is SingletonClass('bar')


# Generated at 2022-06-23 14:35:19.710261
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        pass

    p1 = SingletonTest()
    p2 = SingletonTest()
    assert p1 is p2


# Generated at 2022-06-23 14:35:23.774537
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    assert TestSingleton(1) == TestSingleton(2)
    assert TestSingleton(2).value == 2


# Singleton class with lazy initialization

# Generated at 2022-06-23 14:35:25.472199
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = 'singleton test'
    assert(Test() is Test())

# Generated at 2022-06-23 14:35:32.655802
# Unit test for constructor of class Singleton
def test_Singleton():
    class ATest(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1
            self.b = 2

    x = ATest()
    y = ATest()

    assert id(x) == id(y)
    x.a = 3
    assert x.a == 3 and y.a == 3


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:35:39.462993
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # define class
    class ASingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.var = 1

    # initialize an object
    obj1 = ASingleton()

    # re-initialize an object
    obj2 = ASingleton()

    # check equality of two objects
    assert(obj1 == obj2)
    assert(id(obj1) == id(obj2))

    # modify var of obj1
    obj1.var = 2

    # check consistency of obj2.var
    assert(obj2.var == 2)

# Generated at 2022-06-23 14:35:42.216791
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    # Instantiate class A twice
    a1 = A('foo')
    a2 = A('bar')

    # Same instance is returned
    assert a1.arg == a2.arg


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:35:49.216936
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
    singleton_test_1 = SingletonTest()
    singleton_test_2 = SingletonTest()
    print('singleton_test_1 is singleton_test_2:', singleton_test_1 is singleton_test_2)
    print('singleton_test_1 is SingleTest:', singleton_test_1 is SingletonTest)
    print('singleton_test_2 is SingleTest:', singleton_test_2 is SingletonTest)
    print('singleton_test_1 == singleton_test_2:', singleton_test_1 == singleton_test_2)


# Generated at 2022-06-23 14:35:57.143566
# Unit test for constructor of class Singleton
def test_Singleton():

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('__init__')
            self.x = 1
            self.y = 2

    assert A() is A()
    assert A().x == 1 and A().y == 2
    A().x = 2
    A().y = 3
    assert A().x == 2 and A().y == 3
    assert A().x == 2 and A().y == 3

    class B():
        pass

    try:
        B = Singleton(B.__name__, (object,), {'x': 1, 'y': 2})
        assert False
    except TypeError:
        assert True

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:36:03.862429
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 0

    test1 = Test()
    test2 = Test()
    assert(test1 is test2)
    assert(test1.val == test2.val)
    assert(test1.val == 0)
    test1.val = 1
    assert(test1.val == 1)
    assert(test2.val == 1)

# Generated at 2022-06-23 14:36:07.723576
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    test_instance_1 = Test()
    test_instance_2 = Test()

    assert test_instance_1 is test_instance_2

# Generated at 2022-06-23 14:36:18.164078
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        pass

    A = Singleton('A', (), {'__doc__': 'Singleton test class'})

    # Call the constructor and check if is a singleton
    a1 = A()
    a2 = A()
    assert(a1 == a2)
    assert(a1 is a2)

    class B(object):
        pass

    B = Singleton('B', (), {'__doc__': 'Singleton test class'})

    # Call the constructor and check if is a singleton
    b1 = B()
    b2 = B()
    assert(b1 == b2)
    assert(b1 is b2)

    # A and B are different singletons
    assert(a1 != b1)
    assert(a1 is not b1)

# Generated at 2022-06-23 14:36:21.695181
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            super(A, self).__init__()

    a1 = A()
    a2 = A()

    # I'm just not sure how to test for singletonness
    assert a1 is a2



# Generated at 2022-06-23 14:36:23.279067
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    assert id(A()) == id(A())

# Generated at 2022-06-23 14:36:28.624510
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    assert f1

    class Bar(object):
        __metaclass__ = Singleton

    b1 = Bar()
    assert b1

    assert f1 is b1
    f2 = Foo()
    assert f1 is f2

# Generated at 2022-06-23 14:36:31.804725
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    assert(Foo() is Foo())


# Generated at 2022-06-23 14:36:36.671195
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self, v):
            self.v = v

        def is_singleton(self, v):
            return self.v == v

    s = S(12)
    assert(s.is_singleton(12))

    t = S(13)
    assert(t.is_singleton(12))
    assert(s is t)


# Generated at 2022-06-23 14:36:40.484025
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    cls1 = MyClass()
    cls2 = MyClass()
    assert cls1 is cls2



# Generated at 2022-06-23 14:36:47.451393
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    assert isinstance(Test, Singleton)
    assert Test.__instance is None
    assert Test.__rlock

    instance1 = Test("one")
    assert instance1.name == "one"
    assert Test.__instance is instance1
    assert Test.__rlock

    instance2 = Test("two")
    assert instance2.name == "one"
    assert instance2 is instance1
    assert Test.__instance is instance2
    assert Test.__rlock


# Generated at 2022-06-23 14:36:55.087844
# Unit test for constructor of class Singleton
def test_Singleton():
    import unittest
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_data = None

        def set_data(self, data):
            self.test_data = data

        def get_data(self):
            return self.test_data



    class TestSingletonCase(unittest.TestCase):
        def test_singleton(self):
            foo_one = TestSingleton()
            foo_two = TestSingleton()

            foo_one.set_data(1)

            self.assertTrue(foo_two.get_data() == foo_one.get_data())

    unittest.main()



# Generated at 2022-06-23 14:36:57.923853
# Unit test for constructor of class Singleton
def test_Singleton():
    s = Singleton
    class C():
        __metaclass__ = s
        def __init__(self):
            self.x = 1

    c = C()
    assert c.x == 1

# Generated at 2022-06-23 14:37:01.561997
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert isinstance(Singleton('test_class', (), {}), Singleton)
    assert Singleton('test_class_1', (), {}) is Singleton('test_class_2', (), {})



# Generated at 2022-06-23 14:37:04.595331
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test case: method __call__ should return a class object as expected
    class Test(object):
        __metaclass__ = Singleton

    test1 = Test()
    test2 = Test()
    if not test1 is test2:
        return False

    return True


# Generated at 2022-06-23 14:37:07.237440
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-23 14:37:12.108645
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        pass

    a = A()
    b = A()

    assert a == b

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    b = B()
    c = B()

    assert b == c

# Generated at 2022-06-23 14:37:15.399625
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = ''

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = ''

    a = A()
    b = B()
    assert id(a) != id(b)
    assert a.name == b.name

    a = A()
    assert id(a) != id(b)
    assert a.name == b.name

# Generated at 2022-06-23 14:37:19.418149
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create class SingletonTest
    class SingletonTest(Singleton):
        def __init__(self):
            self.test = 'test'
        def get_test(self):
            return 'test'
    # Instantiate SingletonTest
    st = SingletonTest();
    # Make sure that st is only instance of SingletonTest
    assert id(st) == id(SingletonTest())
    # Make sure that st has test variable
    assert st.test == 'test'
    # Make sure that st has function get_test()
    assert st.get_test() == 'test'

# test Singleton
test_Singleton()

# Generated at 2022-06-23 14:37:27.258369
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, v=0):
            self.val = v

    a1 = A(1)
    a2 = A(2)
    a3 = A()
    print(a1.val, a2.val, a3.val)
    assert a1 == a2 == a3
    assert a1.val == a2.val == a3.val == 0

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:37:30.827349
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    test1 = Test()
    test2 = Test()
    assert test1 is test2

    test2.value = 2
    assert test1.value == 2

# Generated at 2022-06-23 14:37:41.278124
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, v):
            self.v = v

    i1 = TestClass(1)
    assert i1.v == 1
    i2 = TestClass(10)
    assert i1 is not None
    assert i1 is i2
    # check that created instances have expected attributes
    assert i1.v == 10
    assert i2.v == 10
    # check that nothing unexpected happens if we try to call class
    # with more arguments than expected
    try:
        i3 = TestClass(11, 'a')
        i4 = TestClass('b')
    except TypeError:
        pass
    # check that instances created in different threads are not the
    # same
    import threading

# Generated at 2022-06-23 14:37:43.735550
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class foo(object):
        __metaclass__ = Singleton

    f = foo()
    f1 = foo()
    return f == f1
