

# Generated at 2022-06-23 14:27:45.300225
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(object):
        __metaclass__ = Singleton

    assert X() is X() is X()
    assert X() == X() == X()
    assert X() is not ''
    assert X() == ''
    assert '' == X()
    assert X() is not True
    assert X() == True
    assert True == X()

# Generated at 2022-06-23 14:27:48.534803
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, arg=0):
            self.arg = arg

    foo1 = Foo(arg=1)
    foo2 = Foo()
    assert foo1 is foo2
    assert foo1.arg == 1

# Generated at 2022-06-23 14:27:54.918845
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SampleSingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("SampleSingletonClass init")

    a = SampleSingletonClass()
    print("Id a = {}".format(id(a)))
    b = SampleSingletonClass()
    print("Id b = {}".format(id(b)))
    assert id(a) == id(b)

# Generated at 2022-06-23 14:28:00.058964
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    a1 = A(1)
    a2 = A(2)

    assert a1 == a2

    a3 = A(3)
    assert a1 == a3
    assert a1.val == 3


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:28:10.944810
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from multiprocessing import Process
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.object_count = 0

        def __str__(self):
            return "ID {0}".format(self.object_count)

    def test_thread(thread_id):
        singleton = TestSingleton()
        print("Thread ID {0} => {1}".format(thread_id, singleton))
        singleton.object_count = thread_id

    first_thread = Process(target=test_thread, args=(1,))
    second_thread = Process(target=test_thread, args=(2,))
    third_thread = Process(target=test_thread, args=(3,))


# Generated at 2022-06-23 14:28:14.861025
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class DummyClass(object):
        __metaclass__ = Singleton
    inst1 = DummyClass()
    inst2 = DummyClass()
    assert inst1 is inst2


# Generated at 2022-06-23 14:28:19.072496
# Unit test for constructor of class Singleton
def test_Singleton():
    class Y(object):
        __metaclass__ = Singleton
    class Z(object):
        __metaclass__ = Singleton

    x = Y()
    y = Y()
    z = Z()

    assert id(x) == id(y)
    assert id(y) != id(z)


# This is needed for python 2.6 and 2.7

# Generated at 2022-06-23 14:28:22.324113
# Unit test for constructor of class Singleton
def test_Singleton():
    class s(object):
        __metaclass__ = Singleton

    # Check for same instance returned on multiple calls
    obj1 = s()
    obj2 = s()
    assert obj1 is obj2


# Generated at 2022-06-23 14:28:32.460526
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(metaclass=Singleton):
        def __init__(self, *args, **kwargs):
            self.init_args = args
            self.init_kwargs = kwargs

        def __repr__(self):
            return "<TestClass instance: {} {}>".format(self.init_args, self.init_kwargs)

    tc1 = TestClass(1, 2, a=3, b=4)
    assert tc1.__repr__() == "<TestClass instance: (1, 2) {'a': 3, 'b': 4}>"
    tc2 = TestClass(a=1, b=2)
    assert tc2.__repr__() == "<TestClass instance: () {'a': 1, 'b': 2}>"
    assert tc1 is tc2



# Generated at 2022-06-23 14:28:37.431337
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    f = Foo()
    f1 = Foo()
    print(f == f1)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:28:41.473970
# Unit test for constructor of class Singleton
def test_Singleton():
  class A(metaclass=Singleton):
    def __init__(self):
      self.bbb = "ddd"

  a = A()
  b = A()
  assert id(a) == id(b)
  assert a.bbb == b.bbb

# Generated at 2022-06-23 14:28:44.128748
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    st1 = SingletonTest()
    st2 = SingletonTest()
    assert st1 is st2

# Generated at 2022-06-23 14:28:47.621507
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 is a2


# Generated at 2022-06-23 14:28:58.097404
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a class that extends the Singleton metaclass
    class ClassM(object):
        __metaclass__ = Singleton

        # A class variable to store the number of times the __call__
        # method of the metaclass has been called
        cnt = 0

        def __init__(self):
            # Increment the class variable _cnt_
            ClassM.cnt += 1

    # Create an instance of the class
    obj1 = ClassM()
    # Check the value of the class variable _cnt_
    assert ClassM.cnt == 1

    # Create another instance of the class
    obj2 = ClassM()
    # The value of the class variable _cnt_ should be unchanged
    assert ClassM.cnt == 1
    # Check that the two instances are the same
    assert obj1 is obj2



# Generated at 2022-06-23 14:29:06.312127
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, x=0):
            self.x = x

    # Tests
    a = MySingleton(12)
    b = MySingleton(14)
    print("a: " + str(a.x))
    print("b: " + str(b.x))
    # Output: a: 12 b: 12

    c = MySingleton(15)
    print("a: " + str(a.x))
    print("b: " + str(b.x))
    print("c: " + str(c.x))
    # Output: a: 15 b: 15 c: 15

# Generated at 2022-06-23 14:29:11.538108
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.module_utils.six import with_metaclass

    class TestCase(with_metaclass(Singleton, object)):
        def __init__(self):
            self.foo = "bar"

    assert TestCase() is TestCase()
    assert TestCase().foo == "bar"

# Generated at 2022-06-23 14:29:14.347032
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-23 14:29:18.321846
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = 'bar'
    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.foo == 'bar'

# Generated at 2022-06-23 14:29:21.741505
# Unit test for constructor of class Singleton
def test_Singleton():
    class Dummy():
        __metaclass__ = Singleton
        def __init__(self):
            pass
    dummy1 = Dummy()
    dummy2 = Dummy()
    assert dummy1 is dummy2
    dummy1 = Dummy()
    dummy3 = Dummy()
    assert dummy1 is dummy3

# Generated at 2022-06-23 14:29:24.254418
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self, arg):
            self.arg = arg
    a = Test(1)
    b = Test(2)
    assert a is b
    assert a.arg == 1



# Generated at 2022-06-23 14:29:29.695953
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    class TestSingle(metaclass=Singleton):
        def __init__(self):
            pass

    assert Test(0) is Test(1)
    assert TestSingle() is TestSingle()

# Generated at 2022-06-23 14:29:35.737179
# Unit test for constructor of class Singleton
def test_Singleton():
    import types

    # test any subclass of Singleton
    class MyClass(object):
        __metaclass__ = Singleton

    my_class = MyClass()
    assert isinstance(my_class, MyClass)
    assert isinstance(my_class, Singleton)
    assert isinstance(my_class, types.InstanceType)

    assert MyClass() is my_class
    assert MyClass() is my_class

# Generated at 2022-06-23 14:29:39.912946
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.var = None

    A_obj = A()
    A_obj.var = 1
    A_obj2 = A()
    A_obj2.var = 2
    assert A_obj.var == 2
    assert A_obj == A_obj

# Generated at 2022-06-23 14:29:47.334729
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test with a class that does not implement Singleton
    class MyClass(object):
        pass
    class1 = MyClass()
    class2 = MyClass()
    assert(id(class1) != id(class2))

    # Test with a class that does implement Singleton
    class MySingletonClass(object):
        __metaclass__ = Singleton
    singleton1 = MySingletonClass()
    singleton2 = MySingletonClass()
    assert(id(singleton1) == id(singleton2))


# Generated at 2022-06-23 14:29:52.346416
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a1 = A()
    a2 = A()
    assert a1 == a2
    print(a1)
    print(a2)
    assert id(a1) == id(a2)


# Generated at 2022-06-23 14:29:55.886109
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    obj1 = A(1)
    obj2 = A(2)
    assert obj1 is obj2
    assert obj1.a == 1


# Generated at 2022-06-23 14:29:58.300975
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(metaclass=Singleton):
        pass
    class SingletonTest2(metaclass=Singleton):
        pass

    assert SingletonTest() is SingletonTest()
    assert SingletonTest2() is SingletonTest2()

# Generated at 2022-06-23 14:30:02.186807
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = MyClass()
    b = MyClass()
    assert a is b

# Generated at 2022-06-23 14:30:08.528952
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1(object):
        __metaclass__ = Singleton

    class Test2(object):
        __metaclass__ = Singleton

    # If a class instance of Test1 is not found, create a new instance
    # and return it.
    test1_1 = Test1()

    # If the class instance of Test1 exists, return it.
    test1_2 = Test1()

    # If a class instance of Test2 is not found, create a new instance
    # and return it.
    test2_1 = Test2()

    # If the class instance of Test2 exists, return it.
    test2_2 = Test2()

    # Make sure Test1 instance and Test2 instance remain the same.
    assert test1_1 == test1_2
    assert test2_1 == test2_2

    # Make

# Generated at 2022-06-23 14:30:16.707100
# Unit test for constructor of class Singleton
def test_Singleton():
    """
    >>> Singleton(str)
    <class '__main__.str'>
    >>> class A(object):
    ...    __metaclass__ = Singleton
    ...
    >>> A()
    <__main__.A object at 0x7f5e2d0e5b10>
    >>> B = A()
    >>> B.__class__
    <class '__main__.A'>
    >>> A().__class__
    <class '__main__.A'>
    >>> x = Singleton(str)
    >>> x()
    'hello'
    >>> x('hi')
    'hello'
    """


# Generated at 2022-06-23 14:30:26.514132
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class D(C):

        def __init__(self):
            pass

    # Test 1
    o1 = C()
    o1.a = 10
    o2 = C()
    assert o1 is o2
    assert o1.a == 10
    assert hasattr(o1, 'a')
    assert hasattr(o2, 'a')

    # Test 2
    o3 = D()
    o3.b = 20
    o4 = D()
    assert o3 is o4
    assert o3.b == 20
    assert hasattr(o3, 'b')
    assert hasattr(o4, 'b')

# Generated at 2022-06-23 14:30:32.693225
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    instance1 = TestSingleton('instance1')
    assert instance1.name == 'instance1'

    instance2 = TestSingleton('instance2')
    assert instance1.name == 'instance1'
    assert instance2.name == 'instance1'


# Generated at 2022-06-23 14:30:42.821076
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Arrange
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.args = []
            self.kw = {}

        def __call__(self, *args, **kw):
            self.args = args
            self.kw = kw
            return "TestSingleton"

    obj_1 = TestSingleton()
    obj_2 = TestSingleton()
    # Act
    obj_1("Test arg 1", "Test arg 2")
    obj_2("Test arg 3", "Test arg 4")

    # Assert
    assert obj_1 == obj_2
    assert obj_1.args == ["Test arg 3", "Test arg 4"]
    assert obj_1.kw == {}

# Generated at 2022-06-23 14:30:51.229686
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test = [None, None]
    class Class(object, metaclass=Singleton):
        def __init__(self, value):
            self.value = value
            test[0] = self
        def get_value(self):
            return self.value

    a = Class(1)
    test[1] = a
    assert a is b
    assert test[0] is a
    assert test[1] is a
    assert a.get_value() == 1
    b = Class(2)
    assert b is a
    assert b.get_value() == 1

# Generated at 2022-06-23 14:31:01.649173
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()

    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1

    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2

    a2.a = 3
    assert a1.a == 3
    assert a2.a == 3

    class B(A):
        def __init__(self):
            self.b = 1

    b1 = B()
    b2 = B()
    assert b1 is a1
    assert b1 is b2

    assert b1.b == 1
    assert b2.b == 1

    b1

# Generated at 2022-06-23 14:31:09.826906
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    t1 = Test(1)
    t2 = Test(2)
    t3 = Test(3)
    assert t1 == t2 == t3, "Singleton class should return the same instance always!"
    assert t1.a == t2.a == t3.a == 1, "Singleton class should init only once!"


if __name__ == "__main__":
    import sys
    import unittest
    from unittest import TestLoader, TextTestRunner
    from test_dynamic_inventory_common import AnsibleExitJson, AnsibleFailJson, ModuleTestCase


# Generated at 2022-06-23 14:31:14.853852
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest:
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    assert SingletonTest(1) == SingletonTest(2)
    assert SingletonTest(1).x == 1
    assert SingletonTest(2).x == 1

# Generated at 2022-06-23 14:31:23.870132
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'I am A'
            self.__class__.init_count += 1

        def __del__(self):
            self.__class__.del_count += 1

    A.init_count = 0
    A.del_count = 0

    a1 = A()

    assert a1.name == 'I am A'
    assert A.init_count == 1
    assert A.del_count == 0

    a1 = A()

    assert a1.name == 'I am A'
    assert A.init_count == 1
    assert A.del_count == 0

    del a1

    assert A.init_count == 1
    assert A.del_count == 0

# Generated at 2022-06-23 14:31:25.722005
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton

    s1 = S()
    s2 = S()

    assert id(s1) == id(s2)

# Test class that Singleton decorator works

# Generated at 2022-06-23 14:31:28.057274
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        pass

    x = Foo()
    y = Foo()

    assert x is y

# Generated at 2022-06-23 14:31:31.893962
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__=Singleton
        def __init__(self):
            self.value=None
    a=A()
    a.value=True
    b=A()
    assert b.value==True

# Usage of the Singleton constructor.

# Generated at 2022-06-23 14:31:35.387162
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
    a = Test()
    b = Test()
    assert a is b



# Generated at 2022-06-23 14:31:46.114314
# Unit test for constructor of class Singleton
def test_Singleton():
    # test with normal class
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.num = 0

    s1 = Foo()
    s2 = Foo()
    s1.num = 1
    assert s1 is s2
    assert s1.num == s2.num

    # test with new style class
    class Foo(object, metaclass=Singleton):
        def __init__(self):
            self.num = 0

    s1 = Foo()
    s2 = Foo()
    s1.num = 1
    assert s1 is s2
    assert s1.num == s2.num

    # test with unmetaclassed class
    class Foo():
        def __init__(self):
            self.num = 0

    s1 = Foo

# Generated at 2022-06-23 14:31:54.400581
# Unit test for constructor of class Singleton
def test_Singleton():

    class TestClass:
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class TestSubclass(TestClass):
        '''Subclass of a singleton class should also be a singleton'''

    class TestStringSubclass(str):
        '''Subclass of a builtin type (str) should not be a singleton'''

    assert TestClass() is TestClass()
    assert TestSubclass() is TestSubclass()
    assert TestSubclass() is TestClass()
    assert TestStringSubclass() is not TestStringSubclass()

test_Singleton()

# Generated at 2022-06-23 14:31:56.219881
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
    a = Foo()
    b = Foo()
    assert a is b

# Generated at 2022-06-23 14:32:00.142525
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # we want to ensure that the instance returned by calling a singleton class
    # is always the same
    class TestSingleton(object):
        __metaclass__ = Singleton

    instance1 = TestSingleton()
    instance2 = TestSingleton()
    assert instance1 is instance2

# Generated at 2022-06-23 14:32:10.165676
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 == a2
    assert a1 is a2
    assert hasattr(a1, 'a')
    assert hasattr(a2, 'a')


# Generated at 2022-06-23 14:32:15.599873
# Unit test for constructor of class Singleton
def test_Singleton():
    import sys

    class A(metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    assert id(A(1)) == id(A(2))
    assert sys.getrefcount(A(1)) == 2

    assert id(A(1)) != id(A(3)(4))

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:32:21.989127
# Unit test for constructor of class Singleton
def test_Singleton():
    class singleton(object):
        __metaclass__ = Singleton
    class singleton2(object):
        __metaclass__ = Singleton

    a = singleton()
    b = singleton()
    c = singleton2()
    d = singleton2()
    assert a is b and c is d
    assert a is not c
    print('singleton passed')


# Generated at 2022-06-23 14:32:25.260343
# Unit test for constructor of class Singleton
def test_Singleton():

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 1

    assert A() is A()
    assert A().foo == 1

# Generated at 2022-06-23 14:32:30.408531
# Unit test for constructor of class Singleton
def test_Singleton():
    class S1(object):
        __metaclass__ = Singleton
    s = S1()
    assert s is S1()
    class S2(object):
        __metaclass__ = Singleton
    s = S2()
    assert s is S2()
    assert s is not S1()
    assert S1() is S1()
    assert S2() is S2()

# Generated at 2022-06-23 14:32:33.437058
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-23 14:32:34.775946
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

# Generated at 2022-06-23 14:32:39.984115
# Unit test for constructor of class Singleton
def test_Singleton():
    class First(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class Second(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    assert First() is First()
    assert Second() is Second()
    assert First() is not Second()

# Generated at 2022-06-23 14:32:42.980698
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonObject(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    obj = SingletonObject()
    obj2 = SingletonObject()

    assert obj is obj2

# Generated at 2022-06-23 14:32:50.386983
# Unit test for constructor of class Singleton
def test_Singleton():
    class Single(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    class Single2(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 2

    a = Single()
    assert a.x == 1

    b = Single2()
    assert b.x == 2

    a = Single()
    assert a.x == 1

    b = Single2()
    assert b.x == 2

    assert a == Single()
    assert a == Single()
    assert a == Single()
    assert a == Single()
    assert b == Single2()
    assert b == Single2()
    assert b == Single2()
    assert b == Single2()

# Generated at 2022-06-23 14:32:54.325651
# Unit test for constructor of class Singleton
def test_Singleton():
    class Child(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    obj1 = Child()
    assert id(obj1) == id(Child())



# Generated at 2022-06-23 14:33:00.452975
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import random
    import pickle

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = random.randint(0, 100)

    a = A()
    b = A()

    assert a.x == b.x

    c = pickle.loads(pickle.dumps(a))
    d = pickle.loads(pickle.dumps(b))

    # Check if instances are the same also after being serialized
    assert a is c
    assert b is d
    assert c is d

# vim: set noexpandtab ts=4 sw=4 :

# Generated at 2022-06-23 14:33:04.060122
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    s1 = TestSingleton()
    s2 = TestSingleton()
    assert id(s1) == id(s2)


# Generated at 2022-06-23 14:33:08.286373
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    This code is testing method `__call__` of class Singleton.

    Test points:
        1. Calling Singleton will return the same instance.
    :return:
    """
    class TestSingleton(metaclass=Singleton):
        pass

    a1 = TestSingleton()
    a2 = TestSingleton()
    assert a1 is a2

# Generated at 2022-06-23 14:33:10.184333
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

    c1 = C()

    assert c1 == C()



# Generated at 2022-06-23 14:33:12.611153
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    obj1 = MySingleton()
    obj2 = MySingleton()

    assert obj1 == obj2

# Generated at 2022-06-23 14:33:16.811499
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    assert A(1).val == 1
    assert A(2).val == 1
    assert A(3).val == 1
    assert A(4).val == 1

# Generated at 2022-06-23 14:33:19.195916
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert a == b


# Generated at 2022-06-23 14:33:25.796735
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val
    instance1 = Test(1)
    instance2 = Test(2)

    # check that singleton was created
    assert instance1 == instance2

    # check that value was set
    assert instance1.val == 1
    assert instance2.val == 1

# Generated at 2022-06-23 14:33:29.714795
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class SingletonClass(object):
        __metaclass__ = Singleton

    SingletonClassInstance = SingletonClass()

    other_SingletonClassInstance = SingletonClass()

    assert SingletonClassInstance == other_SingletonClassInstance



# Generated at 2022-06-23 14:33:33.456765
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """ Ensure class variable __instance is initialized to None.
    """
    class Noop(metaclass=Singleton):
        def __init__(self):
            pass

    assert Noop.__instance is None



# Generated at 2022-06-23 14:33:36.377598
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingletonClass(object):
        __metaclass__ = Singleton

    class MyClass(object):
        pass
    assert MySingletonClass() == MySingletonClass()
    assert MySingletonClass() != MyClass()


# Generated at 2022-06-23 14:33:37.603110
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton('test','','test') != Singleton('test','','test')

# Generated at 2022-06-23 14:33:45.836500
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test_field = 1

    from multiprocessing import Process

    def test_function():
        instance = SingletonTest()
        assert instance.test_field == 1

    for _ in range(100):
        process = Process(target=test_function)
        process.start()
        process.join()

    assert SingletonTest().test_field == 1


# Generated at 2022-06-23 14:33:57.403057
# Unit test for constructor of class Singleton
def test_Singleton():
    class GlobalTest(object):
        """A trivial class to be used for testing the Singleton class."""
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = None

        @property
        def foo(self):
            return self.__foo

        @foo.setter
        def foo(self, value):
            self.__foo = value

    class LocalTest(object):
        """A trivial class to be used for testing the Singleton class."""
        def __init__(self):
            self.foo = None

        @property
        def foo(self):
            return self.__foo

        @foo.setter
        def foo(self, value):
            self.__foo = value

    Singleton_test_obj = GlobalTest()

# Generated at 2022-06-23 14:34:00.749526
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    TestClass.__instance = None
    TestClass()
    assert TestClass.__instance == TestClass
    TestClass.__instance = None
    TestClass()
    assert TestClass.__instance == TestClass



# Generated at 2022-06-23 14:34:09.831951
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread

    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.x = 0
        def incr(self):
            self.x += 1

    def run_TestSingleton():
        obj = TestSingleton()
        obj.incr()

    nb_threads = 2
    threads = [Thread(target=run_TestSingleton) for i in range(nb_threads)]
    [thread.start() for thread in threads]
    [thread.join() for thread in threads]

    assert TestSingleton().x == nb_threads

test_Singleton___call__()

# Generated at 2022-06-23 14:34:11.871416
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.counter = 0

        def increment(self):
            self.counter += 1

    a = TestClass()
    b = TestClass()
    assert a == b
    a.increment()
    assert a.counter == 1
    assert b.counter == 1

# Generated at 2022-06-23 14:34:15.288022
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    assert MyClass(1) is MyClass(2)
    assert MyClass(1).x == 1

# Generated at 2022-06-23 14:34:19.201391
# Unit test for constructor of class Singleton
def test_Singleton():
    # Check that Singleton creates a correct class
    class TestClass(object):
        __metaclass__ = Singleton

    # Check that we get the same instance each time we call TestClass()
    instance1 = TestClass()
    instance2 = TestClass()

    assert instance1 == instance2


# Generated at 2022-06-23 14:34:22.003446
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            super(A, self).__init__()

    a1 = A()
    a2 = A()
    assert(a1 is a2)


# Generated at 2022-06-23 14:34:29.487579
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print('Testing method __call__ of class Singleton')
    from test_Singleton import Foo

    # create an instance of Foo class
    foo1 = Foo()
    # save the hash of the instance
    hash_foo1 = hash(foo1)
    # call __call__ of class Singleton
    foo2 = Foo()
    # save the hash of the instance
    hash_foo2 = hash(foo2)
    # test that the hashes are the same
    assert hash_foo1 == hash_foo2
    print('Test passed')


# Generated at 2022-06-23 14:34:31.576780
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-23 14:34:35.049345
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x
    a = A(1)

    assert A(1) is a

# Generated at 2022-06-23 14:34:40.048769
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest:
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 0

    a = SingletonTest()
    a.val = 1

    b = SingletonTest()
    b.val = 2

    assert a == b
    assert a.val == b.val
    assert a is b

# Generated at 2022-06-23 14:34:44.552887
# Unit test for constructor of class Singleton
def test_Singleton():
    import unittest

    class SingletonTest(object):
        __metaclass__ = Singleton

    s1 = SingletonTest()
    assert(s1 is not None)
    s2 = SingletonTest()
    assert(s1 is s2)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:34:46.166871
# Unit test for constructor of class Singleton
def test_Singleton():
    a = Singleton('a', (object,), {})
    b = Singleton('b', (object,), {})

    assert a is not None and a is b

# Generated at 2022-06-23 14:34:49.626074
# Unit test for constructor of class Singleton
def test_Singleton():
    class Single(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    a = Single(1)
    b = Single(2)
    print(a.x)
    print(b.x)
    print(a is b)


# Generated at 2022-06-23 14:34:52.760485
# Unit test for constructor of class Singleton
def test_Singleton():
    class K(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg
    k1 = K(1)
    k2 = K(2)
    assert k1 is k2
    assert k1.arg == 1

# Generated at 2022-06-23 14:34:59.382066
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread
    from Queue import Queue

    # class S is a Singleton and can only have one instance
    class S(Singleton):
        pass

    # class P has a method that returns the instance of class S
    class P:
        def test(self):
            return S()

    # ------------------------------------------------------------------
    # Test scenario 1:
    # Multiple threads executing P.test().
    # Expected behavior:
    #     All returned instances of class S are the same.
    # ------------------------------------------------------------------
    q = Queue()

    def do_test():
        try:
            q.put_nowait(P().test())
        except Exception as e:
            print(e)
        finally:
            q.task_done()

    for _ in range(10):
        Thread(target=do_test).start()

   

# Generated at 2022-06-23 14:35:05.446454
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, param1):
            self.param1 = param1
    # First instance
    instance1 = MyClass("foo")
    assert instance1.param1 == "foo"
    # Second instance
    instance2 = MyClass("bar")
    assert instance2.param1 == "foo"
    assert instance1 is instance2



# Generated at 2022-06-23 14:35:08.794749
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    # Test that there is only one instance of TestClass
    x = TestClass()
    y = TestClass()
    assert x is y


# Generated at 2022-06-23 14:35:17.826198
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass
    a1 = A()
    a2 = A()

    class B(object, metaclass=Singleton):
        pass
    b1 = B()
    b2 = B()

    print('a1 is a2: %s' % (a1 is a2))
    print('b1 is b2: %s' % (b1 is b2))
    print('a1 is b1: %s' % (a1 is b1))
    assert a1 is a2
    assert b1 is b2
    assert a1 is not b1

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:35:21.629713
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class ClassSingleton(object):
        __metaclass__ = Singleton

    class_singleton = ClassSingleton()
    assert class_singleton is ClassSingleton()

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:35:25.877647
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        pass
    instance1 = MyClass()
    assert instance1
    instance2 = MyClass()
    assert instance1 is instance2
    instance3 = MyClass()
    assert instance1 is instance3

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:35:32.281543
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import os
    import tempfile

    class TestedClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.tmpFd, self.tmpName = tempfile.mkstemp()
            os.close(self.tmpFd)

# Generated at 2022-06-23 14:35:38.786726
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    obj_1 = TestSingleton()
    assert isinstance(obj_1, TestSingleton)

    obj_2 = TestSingleton()
    assert isinstance(obj_2, TestSingleton)
    assert id(obj_1) == id(obj_2)

    class NotASingleton(object):
        __metaclass__ = type

    assert NotASingleton() is not NotASingleton()

# Generated at 2022-06-23 14:35:41.046715
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a == b
    assert id(a) == id(b)

# Generated at 2022-06-23 14:35:42.827675
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class foo(object):
        __metaclass__ = Singleton

    # Should not raise
    foo.__call__()

    assert foo() is foo()

# Generated at 2022-06-23 14:35:46.928336
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 == a2
    assert a1.x == a2.x
    assert a1.x == 1
    assert A(2) == a1

# Generated at 2022-06-23 14:35:53.212393
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name

    a = TestClass('a')
    b = TestClass('b')

    assert id(a) == id(b)
    assert a.get_name() == b.get_name()

# Generated at 2022-06-23 14:35:55.430320
# Unit test for constructor of class Singleton
def test_Singleton():
    class TempClass(object):
        __metaclass__ = Singleton

    s1 = TempClass()
    s2 = TempClass()

    print(s1 is s2) # -> True

# Generated at 2022-06-23 14:36:00.598824
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(Singleton):
        def __init__(self, name):
            self.name = name

    # Constructor for class Foo is used to create a single instance
    f = Foo('foo')
    # Any further calls of the constructor will return the single instance
    assert Foo('bar') == f
    assert Foo('baz') == f

    # The single instance has been initialized properly
    assert f.name == 'foo'

# Generated at 2022-06-23 14:36:05.431799
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    t1 = TestSingleton(10)
    t2 = TestSingleton(20)
    assert t1 is t2
    assert t1.x == 20

# Generated at 2022-06-23 14:36:10.314225
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    test = TestClass(10)
    assert test.val == 10, "Define a singleton class with 10 as its value"

    test_1 = TestClass(100)
    assert test.val == 10 and test_1.val == 10, "The constructor is called only once"

# Generated at 2022-06-23 14:36:15.099540
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    tc1 = TestClass() # Instance is created
    tc2 = TestClass() # And reused

    assert tc1 is tc2

    tc2 = None
    tc2 = TestClass()

    assert tc1 is tc2

# Generated at 2022-06-23 14:36:19.158352
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('Foo created')

    print('test')
    if Foo() is not Foo():
        raise Exception('Singleton failed')
    else:
        print('Passed')


# Generated at 2022-06-23 14:36:22.881756
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.x = 3

    assert isinstance(A(), A)
    a1 = A()
    a2 = A()
    assert a1 is a2
    a1.x = 4
    assert a2.x == 4

# Generated at 2022-06-23 14:36:26.237324
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        pass

    t1 = Test()
    t2 = Test()
    t3 = Test()

    assert t1 == t2 == t3



# Generated at 2022-06-23 14:36:29.923360
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Obj(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    obj1 = Obj()
    obj2 = Obj()
    assert(obj1 is obj2)



# Generated at 2022-06-23 14:36:35.245865
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    # should not instantiate a new instance
    a1 = A("Hello")
    a2 = A("World")
    assert a1 == a2
    assert a1.name == "World"
    assert a2.name == "World"

# Generated at 2022-06-23 14:36:37.916549
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    a = A()
    b = A()
    assert(a is b)

# Generated at 2022-06-23 14:36:42.013184
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    my_class_a = MyClass()
    my_class_b = MyClass()

    assert my_class_a is my_class_b

# Generated at 2022-06-23 14:36:45.295033
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = 5

    if A().test == 5:
        return True
    raise RuntimeError("Singleton failed unit test")

# Generated at 2022-06-23 14:36:53.246369
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, parameter):
            self.parameter = parameter

    x = MyClass("test")
    print("Testing instance created")
    print("%s" % x.parameter)
    y = MyClass("test2")
    print("Testing instance created")
    print("%s" % y.parameter)
    print(x == y)
    print("%s" % x.parameter)
    print("%s" % y.parameter)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:36:56.440753
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    x1 = TestSingleton()
    x2 = TestSingleton()
    assert(x1 == x2)

# Generated at 2022-06-23 14:37:05.567716
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, a, b, c):
            self.__a = a
            self.__b = b
            self.__c = c

        def __str__(self):
            return 'MyClass(%s, %s, %s)' % (self.__a, self.__b, self.__c)

    # testing __call__
    obj1 = MyClass(1, 2, 3)
    obj2 = MyClass(4, 5, 6)
    assert obj1 == obj2


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:37:15.295150
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Single1(metaclass=Singleton):
        pass

    class Single2(Single1):
        pass

    s1 = Single1()

    s2 = Single2()

    assert s1 is s2
    #assert Single1() is Single1()
    #assert Single2() is Single2()
    #assert Single1() is Single2()
    #assert Single2() is Single1()
    #assert Single1() is s1
    #assert Single2() is s2
    #assert Single1() is s2
    #assert Single2() is s1
    #assert s1 is Single1()
    #assert s2 is Single2()
    #assert s2 is Single1()
    #assert s1 is Single2()

# Generated at 2022-06-23 14:37:17.225756
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass:
        __metaclass__ = Singleton

    a = SingletonClass()
    assert a is not None

    b = SingletonClass()
    assert b is not None
    assert b is a

# Generated at 2022-06-23 14:37:23.618162
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object):
        __metaclass__ = Singleton
        def __init__(self, number):
            self.number = number


    c1 = C(1)
    assert c1.number == 1
    c2 = C(2)
    assert c2.number == 1
    assert c1 is c2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:37:25.735119
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2

# Generated at 2022-06-23 14:37:30.360183
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 3
        def f(self, b):
            print("f({})".format(b))

    a1 = A()
    assert a1.x == 3
    a1.f(4)
    assert a1 == A()

# Generated at 2022-06-23 14:37:37.687334
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    class C(object):
        __metaclass__ = Singleton

        def __init__(self, a=0):
            self.a = a

    a = A()
    b = B()
    c = C()
    assert a == A() and b == B() and c == C()
    assert a is A() and b is B() and c is C()
    assert c.a == 0



# Generated at 2022-06-23 14:37:47.848002
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test cases:
    #   - Test for case with one instance
    #   - Test for case with two instantiations
    #   - Test for case with two instantiations in different thread
    #   - Test for case with two different instantiations in different thread
    #   - Test for case with two different instantiations in different thread by diffrent class type
    class SingletonA(metaclass=Singleton):
        def __init__(self):
            pass

    class SingletonB(metaclass=Singleton):
        def __init__(self):
            pass

    class TestSingletonCall(object):
        def test_one_instance(self):
            obj1 = SingletonA()
            obj2 = SingletonA()
            assert obj1 is obj2

        def test_two_instances(self):
            obj1 = SingletonA