

# Generated at 2022-06-23 14:27:49.260991
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("An instance of class A is created!")

    a = A()
    print(a)
    b = A()
    print(b)
    with open('out.log', 'w') as f:
        f.write(str(a) + '\n')
        f.write(str(b) + '\n')
        f.write(str(a == b) + '\n')

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:27:55.627610
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    first = TestSingleton(1, 2)
    second = TestSingleton(3, 4)
    assert first.a == second.a
    assert first.b == second.b

# Generated at 2022-06-23 14:27:58.981195
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test method __call__ of class Singleton"""

    class TestClass(object):
        __metaclass__ = Singleton

    obj1 = TestClass()
    obj2 = TestClass()

    assert id(obj1) == id(obj2)



# Generated at 2022-06-23 14:28:04.186100
# Unit test for constructor of class Singleton
def test_Singleton():
    class Bob(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x
    assert Bob(1) is Bob(2)
    assert Bob(1).x == 2
    assert Bob(1).x == Bob(2).x
    b = Bob(3)
    assert Bob(1) is b

# Generated at 2022-06-23 14:28:10.672798
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass1(object):
        __metaclass__ = Singleton

    class TestClass2(TestClass1):
        pass

    t1c1, t1c2 = TestClass1(), TestClass1()
    assert t1c1 == t1c2

    t2c1, t2c2 = TestClass2(), TestClass2()
    assert t2c1 == t2c2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:28:20.856287
# Unit test for constructor of class Singleton
def test_Singleton():
    class NonSingletonClass:
        pass

    class TestSingletonClass(metaclass=Singleton):
        pass

    class TestSingletonClassWithArgs(metaclass=Singleton):
        def __init__(self, arg):
            self.arg = arg

    # Test instance counter
    i1 = TestSingletonClass()
    i2 = TestSingletonClass()
    i3 = TestSingletonClass()
    assert i1 is i2
    assert i2 is i3

    # Test multiple singletons
    s1 = TestSingletonClassWithArgs(1)
    s2 = TestSingletonClassWithArgs(2)
    s3 = TestSingletonClassWithArgs(3)
    assert s1 is s2
    assert s2 is s3

    enc1 = TestSingletonClass()
    enc2 = TestSingleton

# Generated at 2022-06-23 14:28:29.065291
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Singleton_test(object):
        __metaclass__ = Singleton
        pass

    obj1 = Singleton_test()
    obj2 = Singleton_test()
    assert id(obj1) == id(obj2)

    class Singleton_test_2(object):
        __metaclass__ = Singleton
        pass

    obj3 = Singleton_test_2()
    assert id(obj1) == id(obj2)
    assert id(obj1) != id(obj3)
    assert id(obj2) != id(obj3)

# Generated at 2022-06-23 14:28:31.565024
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-23 14:28:37.481094
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    class B(object):
        __metaclass__ = Singleton

    if A() is not A():
        raise Exception("A() is not A()")
    if A() is B():
        raise Exception("A() is B()")

# Generated at 2022-06-23 14:28:43.568941
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Object(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def update(self):
            self.value += 1

    assert Object.__instance is None
    obj1 = Object()
    assert Object.__instance is obj1
    assert obj1.value == 0
    obj1.update()
    obj2 = Object()
    assert Object.__instance is obj1 and Object.__instance is obj2
    assert obj1.value == obj2.value



# Generated at 2022-06-23 14:28:45.721568
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()

# Generated at 2022-06-23 14:28:49.787296
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class OneInstance(object):
        __metaclass__ = Singleton

    obj1 = OneInstance()
    obj2 = OneInstance()
    assert id(obj1) == id(obj2), "Singleton class (obj1 != obj2) !!"

# Generated at 2022-06-23 14:28:53.834457
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = A(123)
    b = A(321)
    assert a is b
    assert a.value == 321 # b value is more recent



# Generated at 2022-06-23 14:28:56.683384
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    assert foo1 is not None

    foo2 = Foo()
    assert foo1 is foo2

# Generated at 2022-06-23 14:28:58.952105
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    # assert that __call__ is returning the same instance
    assert A() is A()

# Generated at 2022-06-23 14:29:04.169878
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SimpleClass(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a = SimpleClass(42)
    b = SimpleClass(43)

    assert(a == b)
    assert(a.value == 42)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 14:29:07.554347
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import os
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, pid):
            self.pid = pid
    f = Foo(os.getpid())
    assert f.pid == os.getpid()
    g = Foo(os.getppid())
    assert f.pid == g.pid



# Generated at 2022-06-23 14:29:09.935547
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        pass
    assert TestClass() == TestClass()

# Generated at 2022-06-23 14:29:14.546482
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    # Create singleton class instance
    i1 = SingletonTest()
    # Create another instance
    i2 = SingletonTest()
    # Assert both instances are the same
    assert i1 == i2

# Generated at 2022-06-23 14:29:16.137235
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.bar = 42

    foo = Foo()
    assert foo.bar == 42
    foo2 = Foo()
    assert foo2.bar == 42

# Generated at 2022-06-23 14:29:19.852218
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self, arg1):
            self.arg = arg1

    c1 = C(1)
    c2 = C(2)
    return c1.arg, c2.arg



# Generated at 2022-06-23 14:29:23.011632
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        """ class to test singleton"""
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 'value'
    a = Test()
    b = Test()
    assert a is b
    assert a.value == b.value == 'value'

# Generated at 2022-06-23 14:29:25.634502
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2

# Generated at 2022-06-23 14:29:31.416793
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_a = TestSingleton()
    test_singleton_b = TestSingleton()
    assert (test_singleton_a is test_singleton_b), "instance of TestSingleton is not unique"


# Generated at 2022-06-23 14:29:35.434489
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonA(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 'bar'

    assert SingletonA().foo == 'bar'  # pylint: disable=no-member
    assert SingletonA() is SingletonA()

# Generated at 2022-06-23 14:29:38.868185
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = Foo()
    b = Foo()
    assert a is b


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:29:42.603548
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print("Hello, world!")
    return 0

if __name__ == '__main__':
    print('This program is being run by itself')
    test_Singleton___call__()
else:
    print('I am being imported from another module')

# Generated at 2022-06-23 14:29:44.702559
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    a is b



# Generated at 2022-06-23 14:29:51.649717
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print("Test #1")
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a = Foo("Hello")
    b = Foo("Hello")
    print("a == b:", a == b)
    print("a is b:", a is b)
    print("a.value == b.value:", a.value == b.value)
    print("")


# Generated at 2022-06-23 14:29:56.669286
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from units.compat.unittest import TestCase

    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    class TestSingleton(TestCase):
        def test_Singleton___call__(self):
            self.assertIs(A(), A())
            self.assertIsNot(A(), B())
            self.assertIs(B(), B())

    return TestSingleton

# Generated at 2022-06-23 14:30:00.452443
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
    t1 = Test()
    t2 = Test()
    assert t1 is t2


# Generated at 2022-06-23 14:30:06.060443
# Unit test for constructor of class Singleton
def test_Singleton():
    import unittest
    test = unittest.TestCase()
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    a = SingletonTest("a")

    test.assertEqual(a.name, "a")

    b = SingletonTest("b")
    test.assertEqual(b.name, "a")
    test.assertTrue(a is b)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:30:12.131209
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    temp_test_1 = TestClass(1)
    temp_test_2 = TestClass(2)

    return temp_test_1.value == temp_test_2.value and temp_test_2.value == 1


# Generated at 2022-06-23 14:30:15.799043
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 is a2
    assert type(a1) is A
    assert type(a2) is A


# Generated at 2022-06-23 14:30:18.569453
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-23 14:30:22.345509
# Unit test for constructor of class Singleton
def test_Singleton():
    # simply check if Singleton works as expected
    class TmpS(object):
        __metaclass__ = Singleton

    a = TmpS()
    assert a.__class__ == TmpS
    b = TmpS()
    assert a is b

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:30:24.442942
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    assert Test('bar') == Test('baz')



# Generated at 2022-06-23 14:30:26.755546
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        def __init__(self):
            self.x = 'Hello'

    assert Foo() is Foo()
    assert Foo().x == 'Hello'



# Generated at 2022-06-23 14:30:28.454962
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    f = Foo()
    g = Foo()

    assert f is g

# Generated at 2022-06-23 14:30:36.122128
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.num = 0

    s1 = MySingleton()
    s2 = MySingleton()

    if s1.num != 0:
        raise Exception("Singleton failed to initialize")

    s1.increment()
    if s1.num != 1:
        raise Exception("Singleton failed to increment")

    if s2.num != 1:
        raise Exception("Singleton failed to increment a second time")



test_Singleton()

# Generated at 2022-06-23 14:30:45.544721
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from random import randint
    from sys import stdout
    from time import sleep

    class TestingSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value=0):
            self.value = value

        def update(self):
            self.value += 1

    def __get_random_value():
        return randint(0, 10)

    def __print_info(msg, obj1, obj2):
        stdout.write('%s\n' % msg)
        stdout.flush()

        stdout.write('value in obj1: %s\n' % obj1.value)
        stdout.write('value in obj2: %s\n' % obj2.value)
        stdout.flush()


# Generated at 2022-06-23 14:30:50.347799
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kw):
            pass

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kw):
            pass

    assert Foo() is Foo()
    assert Bar() is not Foo()

# Generated at 2022-06-23 14:31:00.075700
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global runnable
    class Runnable(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.counter = 0
        def run(self):
            self.counter += 1
            return "Counter was %d" % self.counter
    runnable = Runnable()
    global r
    class R(object):
        def __init__(self):
            self.r = runnable
    r = R()
    assert r.r == runnable
    assert runnable.counter == 0
    assert runnable.run() == "Counter was 1"
    assert runnable.run() == "Counter was 2"
    assert runnable.run() == "Counter was 3"

# Generated at 2022-06-23 14:31:08.898880
# Unit test for constructor of class Singleton
def test_Singleton():
    class T(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.data = 0

    class T2(object):
        __metaclass__ = Singleton


# Generated at 2022-06-23 14:31:13.384434
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2
    b1 = B()
    b2 = B()
    assert b1 is b2
    assert a1 is not b1
    assert id(a1) == id(a2)
    assert id(b1) == id(b2)

# Generated at 2022-06-23 14:31:16.907961
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 0

    a = A()
    assert A() is a


# Generated at 2022-06-23 14:31:24.920041
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        counter = 0

        def __init__(self):
            A.counter += 1
            assert A.counter == 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert A.counter == 1

    from multiprocessing import Process
    from time import sleep

    class B(metaclass=Singleton):
        counter = 0

        def __init__(self):
            B.counter += 1
            assert B.counter == 1
            sleep(2)

    class C(metaclass=Singleton):
        counter = 0

        def __init__(self):
            C.counter += 1
            assert C.counter == 1
            sleep(1)

    b1 = B()
    p = Process(target=C)
    p

# Generated at 2022-06-23 14:31:34.878399
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(Object, metaclass=Singleton):
        def __init__(self, message):
            self.message = message

    print('The class name is: ', TestSingleton.__name__)
    a_singleton = TestSingleton('OnlyIamAlone')
    print('The message is:', a_singleton.message)
    print('The dict is:', a_singleton.get_dict())
    b_singleton = TestSingleton('I should not be alone')
    print('The message is:', b_singleton.message)
    print('The dict is:', b_singleton.get_dict())

# A class that implememt the Singleton metaclass

# Generated at 2022-06-23 14:31:37.084687
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Defines a test class which is implemented as a Singleton
    class TestClass(metaclass=Singleton):
        foo = "bar"

    assert TestClass() == TestClass("hello", "world")



# Generated at 2022-06-23 14:31:41.976286
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2, "This should be the same instance"


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:31:45.895699
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert(a is b)

    class B(object):
        __metaclass__ = Singleton

    c = B()
    assert(a is not c)

# Generated at 2022-06-23 14:31:48.831568
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global TestSingleton
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()



# Generated at 2022-06-23 14:31:52.315430
# Unit test for constructor of class Singleton
def test_Singleton():
    class a(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a1 = a()
    a2 = a()

    assert a1 == a2

# Generated at 2022-06-23 14:31:54.821545
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, name=None):
            self.name = name
    # Instantiate it twice
    a = MyClass('foo')
    b = MyClass('bar')
    # The same location
    assert a is b
    # And the name should be 'bar' which is the last one
    assert a.name == 'bar'

# Generated at 2022-06-23 14:32:00.383983
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        def __init__(self, arg):
            self.arg = arg

    class B(Singleton):
        def __init__(self, arg):
            self.arg = arg

    obj1 = B("foo")
    assert isinstance(obj1, B), "obj1 is not of class B"
    obj2 = B("bar")
    assert obj1 is obj2, "obj1 is not obj2"
    obj3 = A("foo")
    assert not isinstance(obj3, B), "obj3 is of class B"
    assert obj3.arg == "foo", "obj3.arg is not 'foo'"

# Generated at 2022-06-23 14:32:07.319869
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert id(a1) == id(a2)
    assert a1.x == 1


# Generated at 2022-06-23 14:32:16.954270
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import types

    class Foo(types.TypeType):
        __metaclass__ = Singleton

        def __init__(self, foobar):
            self.foobar = foobar

    def create_Foo(foobar):
        return Foo(foobar)

    # create Foo class
    Foo = Foo('__init__', (object,), {'__init__': __init__, '__metaclass__': Singleton})

    # create Foo class instances
    foo1 = create_Foo('foo1')
    foo2 = create_Foo('foo2')

    # check if foo1 and foo2 are the same instance
    assert foo1 is foo2


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:32:19.348324
# Unit test for constructor of class Singleton
def test_Singleton():
    # Test for constructor
    Singleton()
    Singleton('Ansible', (), {})

# Generated at 2022-06-23 14:32:27.475823
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.b = 5

    class Bar(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 2

    # make sure it's a singleton
    assert Foo() is Foo()
    # make sure it's separate from other singleton
    assert Foo() is not Bar()
    # make sure state is maintained
    foo1 = Foo()
    foo2 = Foo()
    assert foo1.b == 5
    foo1.b += 1
    assert foo1.b == 6
    assert foo2.b == 6

# Generated at 2022-06-23 14:32:35.678000
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    assert TestSingleton('test').name == 'test'

    test_singleton_1 = TestSingleton('test_singleton_1')
    assert test_singleton_1.name == 'test_singleton_1'

    test_singleton_2 = TestSingleton('test_singleton_2')
    assert test_singleton_2.name == 'test_singleton_1'
    assert test_singleton_1 is test_singleton_2

# Generated at 2022-06-23 14:32:40.850801
# Unit test for constructor of class Singleton
def test_Singleton():
    class MockSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = "bar"

    ms1 = MockSingleton()
    ms2 = MockSingleton()

    assert ms1.foo == "bar"
    assert ms1 is ms2


test_Singleton()

# Generated at 2022-06-23 14:32:45.148399
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg1):
            self.arg1 = arg1

    a = TestClass(123)
    b = TestClass(456)
    assert a == b
    assert a.arg1 == 123
    assert b.arg1 == 123

# Generated at 2022-06-23 14:32:48.119152
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    ts = TestSingleton("foo")
    assert ts.value == "foo"
    assert ts is TestSingleton("bar")

# Generated at 2022-06-23 14:32:51.378804
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TSingleton:
        __metaclass__ = Singleton
        def __init__(self):
            pass

    assert TSingleton() == TSingleton()


# Generated at 2022-06-23 14:32:56.464968
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        pass

    # Test first call
    t1 = Test()

    assert t1.__class__ == Test
    assert Test.__instance == t1

    # Test second call
    t2 = Test()

    assert t2 == t1
    assert t2.__class__ == Test
    assert Test.__instance == t2


# Generated at 2022-06-23 14:33:02.794917
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    f1 = Foo('bar')
    f2 = Foo('not bar')
    assert f1 is f2, "singleton should return same instance"
    assert f1.foo == f2.foo, "instances should be the same"



# Generated at 2022-06-23 14:33:04.844675
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    a1=A()
    a2=A()
    assert a1 is a2

# Generated at 2022-06-23 14:33:12.206627
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            self.name = 'A'

        def getName(self):
            return self.name

    class B(metaclass=Singleton):
        def __init__(self):
            self.name = 'B'

        def getName(self):
            return self.name

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()

    assert a1 is a2, "A __init__ returned wrong instance of class"
    assert b1 is b2, "B __init__ returned wrong instance of class"
    assert a1 is not b1, "A and B __init__ returned same instance"
    assert a1.name == 'A', "A __init__ returned wrong name"

# Generated at 2022-06-23 14:33:17.700966
# Unit test for constructor of class Singleton
def test_Singleton():
    class Klass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    klass_list = []
    for i in range(10):
        klass_list.append(Klass())
    for i in range(10):
        assert(klass_list[0] is klass_list[i])
        assert(klass_list[0].a == 1)

# Generated at 2022-06-23 14:33:22.873292
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo:
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 == foo2
    assert foo1 is foo2


from ansible.module_utils._text import to_native
from ansible.module_utils.urls import open_url



# Generated at 2022-06-23 14:33:27.804072
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Testing class
    class SingletonTester(object):
        __metaclass__ = Singleton

    # Getting two instance of SingletonTester
    st1 = SingletonTester()
    st2 = SingletonTester()

    # Checking if both are the same instance
    assert(st1 is st2)


# Generated at 2022-06-23 14:33:29.997280
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
    foo = Foo()
    assert foo is Foo()

# Generated at 2022-06-23 14:33:38.014366
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from random import randrange
    from six import ensure_str
    from threading import Thread
    from time import sleep

    class TestClass(object):
        __metaclass__ = Singleton
        __slots__ = ('__dict__', 'value')

        def __init__(self, value=None):
            self.value = value

    def worker(cls, value):
        instance = cls(value)
        sleep(1)
        return instance

    threads = [Thread(target=worker, args=(TestClass, randrange(1000))) for _ in range(10)]
    [thread.start() for thread in threads]
    [thread.join() for thread in threads]

    # We expect a single instance of TestClass to have been created.
    assert len({thread.result for thread in threads}) == 1


# Generated at 2022-06-23 14:33:42.495849
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        # initialize all the required functions
        def __init__(self):
            self.var = 1

        def inc_var(self):
            self.var += 1

    # first instantiation
    test = TestSingleton()
    assert test.var == 1
    test.inc_var()
    assert test.var == 2

    # second instantiation
    test2 = TestSingleton()
    assert test2.var == 2

# Generated at 2022-06-23 14:33:47.412500
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass:
        __metaclass__ = Singleton
        def __init__(self, n):
            self.n = n

    a = SingletonClass(1)
    b = SingletonClass(2)

    assert a is b
    assert a.n == 1
    assert b.n == 1


# Generated at 2022-06-23 14:33:50.290520
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(metaclass=Singleton):
        pass

    testclass1 = TestClass()
    testclass2 = TestClass()

    assert testclass1 is testclass2

# Generated at 2022-06-23 14:33:53.358150
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestCase(object):
        __metaclass__ = Singleton


# Test it!
test_Singleton___call__()

# Generated at 2022-06-23 14:34:01.331291
# Unit test for constructor of class Singleton
def test_Singleton():
    class myClass(object):
        def __init__(self, name):
            self.name = name

    class mySingletonClass(myClass):
        __metaclass__ = Singleton

    # call constructor of myClass one
    c1 = myClass('c1')

    # call constructor of mySingletonClass one
    s1 = mySingletonClass('s1')
    print(id(s1))

    # call constructor of mySingletonClass two
    s2 = mySingletonClass('s2')
    print(id(s2))

    #call constructor of mySingletonClass three
    s3 = mySingletonClass('s3')
    print(id(s3))



# Generated at 2022-06-23 14:34:05.079695
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a


    a = A("hello")
    b = A("bye")
    assert a == b
    assert a.a == b.a

# Generated at 2022-06-23 14:34:14.193237
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Testing1(object):
        __metaclass__ = Singleton

    # Test 1.
    # Create an instance of Testing1
    instance1 = Testing1()

    # Ensure that the instance created is assigned to __instance of class Testing1
    assert Testing1.__instance is instance1

    # Test 2.
    # Create another instance of Testing1
    instance2 = Testing1()

    # Ensure that the instance created is not assigned to __instance of class Testing1,
    # and instance1 is returned instead.
    assert Testing1.__instance is instance1
    assert instance2 is instance1



# Generated at 2022-06-23 14:34:15.559508
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

# Generated at 2022-06-23 14:34:18.140856
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    singleton = Test()
    assert singleton == Test()
    assert singleton is Test()

# Generated at 2022-06-23 14:34:20.147968
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    a3 = A()
    assert a1 is a2
    assert a2 is a3

test_Singleton___call__()

# Generated at 2022-06-23 14:34:24.262100
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
    
    obj_0 = TestClass()
    obj_1 = TestClass()

    assert obj_0 is obj_1

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:34:29.634279
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(object, metaclass=Singleton):
        def __init__(self, a=1):
            self.a = a

    x1 = X(2)
    x2 = X(3)

    assert x1 is x2
    assert x1.a == 2
    assert x2.a == 2


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:34:35.242024
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    class C(A):
        pass

    assert A() is A()
    assert B(10) is B(20)
    assert A() is not B(20)
    assert A() is not C()
    assert B(20) is not C()

# Generated at 2022-06-23 14:34:45.447885
# Unit test for constructor of class Singleton
def test_Singleton():
    class test1(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.obj1 = 1

    class test2(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.obj2 = 2

    # test1 and test2 will be two different objects
    obj1 = test1()
    obj2 = test2()

    # test3 and test4, both objects are instantiated from the same class.
    # but, both objects should be the same
    class test3(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.obj1 = 1

    class test4(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.obj2 = 2



# Generated at 2022-06-23 14:34:52.453152
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    class B(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a1 = A()
    a2 = A()

    b1 = B(1)
    b2 = B(2)

    assert id(a1) == id(a2)
    assert id(b1) != id(b2)
    assert b1.value == 1
    assert b2.value == 2



# Generated at 2022-06-23 14:34:53.837556
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()

# Generated at 2022-06-23 14:34:55.715584
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
    x1 = Test()
    x2 = Test()
    assert x1 is x2


# Generated at 2022-06-23 14:35:02.968783
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.test_var = 'testing'
            print('I was instantiated')

    # First instance
    t1 = TestSingleton()
    assert t1.test_var == 'testing'

    # Second instance
    t2 = TestSingleton()
    assert t2.test_var == 'testing'

    # Both instances are the same
    assert t1 == t2

# Generated at 2022-06-23 14:35:06.719158
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('TestSingleton init')

    obj1 = TestSingleton()
    obj2 = TestSingleton()
    print(obj1)
    print(obj2)
    assert obj1 is obj2


# Generated at 2022-06-23 14:35:08.363963
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()

    assert a is b

# Generated at 2022-06-23 14:35:11.739372
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    test1 = Test()
    test2 = Test()
    assert(test1 == test2)


# Generated at 2022-06-23 14:35:15.294583
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, *args, **kwargs):
           pass

    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-23 14:35:20.774578
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __str__(self):
            return "Singleton Test"


    a = TestSingleton()
    b = TestSingleton()

    assert a is b, "a is not b"
    assert a == b, "a is not equal to b"

# Generated at 2022-06-23 14:35:25.071236
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class T(metaclass=Singleton):
        def __init__(self):
            self.a = 1
    t1 = T()
    t2 = T()
    assert id(t1) == id(t2)
    assert t1.a == 1
    t1.a = 2
    assert t2.a == 2


# Generated at 2022-06-23 14:35:29.896191
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            self.data = {}

    c = MyClass()
    d = MyClass()
    assert(c is d)

    # the below line won't work
    # e = Singleton()



# Generated at 2022-06-23 14:35:34.467677
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(metaclass=Singleton):
        def __init__(self):
            self.foo = "bar"

    instance1 = SingletonTest()
    instance2 = SingletonTest()
    assert instance1.foo == "bar"
    assert instance2.foo == "bar"
    assert instance1 is instance2

# Generated at 2022-06-23 14:35:39.468267
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.utils.unsafe_proxy import UnsafeProxy


    class Test(UnsafeProxy, object):
        __metaclass__ = Singleton

        def __init__(self):
            self.__keys = []
            super(Test, self).__init__(self.__keys)

    t1 = Test()
    t2 = Test()

    assert t1 is t2

# Generated at 2022-06-23 14:35:40.883447
# Unit test for constructor of class Singleton
def test_Singleton():
    class Sample(with_metaclass(Singleton, object)):
        def __init__(self):
            pass
    a = Sample()
    b = Sample()
    assert a is b

# Generated at 2022-06-23 14:35:43.552547
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        count = 0
        def __init__(self):
            pass
    test1 = Test()
    test2 = Test()
    assert test1 is test2



# Generated at 2022-06-23 14:35:47.505424
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonX(metaclass=Singleton):
        def __init__(self):
            self.data = 'data'
    class SingletonY(metaclass=Singleton):
        def __init__(self):
            self.data = 'data'

    assert SingletonX() == SingletonX()
    assert SingletonX() != SingletonY()

# Generated at 2022-06-23 14:35:57.178078
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    import unittest2 as unittest

    # ------------------------
    # Test: class.instance => same instance
    # ------------------------
    class TestObjectA(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.init_count = 0

    # class.instance => instance
    assert TestObjectA() == TestObjectA()

    # ------------------------
    # Test: class() => same instance
    # ------------------------
    class TestObjectB(object):
        __metaclass__ = Singleton
        instance_count = 0

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.init_count = 0
            TestObjectB.instance_count += 1

    # class() => instance
    assert TestObject

# Generated at 2022-06-23 14:36:01.936477
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = True

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert(test1 == test2)
    assert(test1.test == test2.test)

# Generated at 2022-06-23 14:36:10.058094
# Unit test for constructor of class Singleton
def test_Singleton():
    try:
        # Single instance
        s = Singleton()
        assert isinstance(s, Singleton)
        assert s == Singleton()
        assert s is Singleton()
        # Same type
        assert type(s) == type(Singleton())
        assert type(s) is type(Singleton())
        assert type(s) == Singleton
        assert type(s) is Singleton
        # Differ from singleton
        assert s != Singleton
        assert s is not Singleton
    except BaseException as e:
        print(e)
        raise

if __name__ == "__main__":
    test_Singleton()
    print("Done")

# Generated at 2022-06-23 14:36:15.748257
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = "hi"

    s = MySingletonClass()
    assert s.x == "hi"
    s.x = "goodbye"

    q = MySingletonClass()
    assert q.x == "goodbye"
    assert q == s

# Generated at 2022-06-23 14:36:22.232938
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread

    class Class(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.counter = 1

        def __str__(self):
            return str(self.counter)

    class ClassThread(Thread):
        def run(self):
            print(Class())

    class_threads = [ClassThread() for i in range(10)]
    for class_thread in class_threads:
        class_thread.start()
    for class_thread in class_threads:
        class_thread.join()

# Generated at 2022-06-23 14:36:26.570364
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 5

    a = A()
    assert a.x == 5
    assert A().x == 5

    a.x = 10
    assert a.x == 10
    assert A().x == 10

# Generated at 2022-06-23 14:36:32.047274
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    obj1 = TestClass(1)
    obj2 = TestClass(2)
    assert obj1 is obj2
    assert obj1.value == 1


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:36:34.880810
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        """Test class to test Singleton metaclass
        """
        __metaclass__ = Singleton

    assert Test() is Test()
    assert Test() is not Test()



# Generated at 2022-06-23 14:36:45.768255
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    from . import TestCase, display

    class MyClass:
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    display.display('\nClass MyClass extends Singleton')
    display.display('\t(i) Instantiate MyClass(1, 2)')
    myclass1 = MyClass(1, 2)
    display.display('\t(ii) Instantiate MyClass(3, 4)')
    myclass2 = MyClass(3, 4)
    display.display('\t(i) myclass1.a = ' + str(myclass1.a) + ', myclass1.b = ' + str(myclass1.b))

# Generated at 2022-06-23 14:36:48.742098
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()

# Generated at 2022-06-23 14:36:52.660649
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingletonFalse(object):
        pass

    a = TestSingleton()
    b = TestSingleton()
    c = TestSingletonFalse()
    d = TestSingletonFalse()
    assert a is b
    assert c is d

# Generated at 2022-06-23 14:36:56.959617
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    my_class = MyClass()
    assert isinstance(my_class, MyClass)
    assert my_class == MyClass()

# Generated at 2022-06-23 14:37:03.796518
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    single = MySingleton('one', 'two')
    assert single.a == 'one'
    assert single.b == 'two'
    single2 = MySingleton('one', 'two')
    assert single2 is single


# Generated at 2022-06-23 14:37:11.518994
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    __instance = None
    s_instance = None

    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

        def set_instance(self, instance):
            global __instance
            __instance = instance

        def get_instance(self):
            return __instance

    # 1st call
    s_instance=TestClass()
    s_instance.set_instance(s_instance)

    # 2nd call
    t_instance=TestClass()
    t_instance.set_instance(t_instance)

    # 3rd call
    u_instance=TestClass()
    u_instance.set_instance(u_instance)

    assert isinstance(s_instance.get_instance(), TestClass)
    assert isinstance(t_instance.get_instance(), TestClass)

# Generated at 2022-06-23 14:37:20.109880
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase
    from importlib import import_module

    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name

    class MyTest(TestCase):
        def test_singleton_behaviour(self):
            obj1 = SingletonTest('test1')
            obj2 = SingletonTest('test2')
            self.assertEqual(obj1, obj2)
            self.assertEqual(obj1.get_name(), obj2.get_name())

    module = import_module('__main__')
    test = MyTest()
    test.test_singleton_behaviour()

# Generated at 2022-06-23 14:37:23.715631
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    a1 = A()
    a2 = A()
    if a1 is not a2:
        raise Exception("A is not Singleton")

# Generated at 2022-06-23 14:37:30.002650
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.x = 0

    a1 = A()
    a2 = A()
    a3 = A()
    assert a1 is a2
    assert a2 is a3
    a1.x = 1
    assert a1 is a2
    assert a2 is a3
    assert a1.x == a2.x
    assert a2.x == a3.x

# Generated at 2022-06-23 14:37:33.472936
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        pass

    t1 = Test()
    t2 = Test()
    assert id(t1) == id(t2)

# Generated at 2022-06-23 14:37:35.407697
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-23 14:37:37.560837
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        pass

    a = TestClass()
    b = TestClass()
    assert a is b

# Generated at 2022-06-23 14:37:40.319948
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 == a2



# Generated at 2022-06-23 14:37:42.872592
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class testSingleton(object):
        __metaclass__ = Singleton
    a = testSingleton()
    b = testSingleton()
    assert a is b


# Generated at 2022-06-23 14:37:48.091095
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    instance1 = SingletonTest('test1')
    instance2 = SingletonTest('test2')
    assert instance1 is instance2
    assert instance1.name == instance2.name


if __name__ == '__main__':
    test_Singleton()