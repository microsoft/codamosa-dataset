

# Generated at 2022-06-23 14:27:54.279926
# Unit test for constructor of class Singleton
def test_Singleton():
    import pytest

    class Fool(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

    class Baz(object):
        __metaclass__ = Singleton

    try:
        fool1 = Fool()
        fool2 = Fool()
        fool1 is fool2
    except Exception as ex:
        # this should fail
        pytest.fail('Fool.__init__() failed: {0}'.format(ex))

    try:
        bar1 = Bar()
        Bar.__instance = None
        bar2 = Bar()
        assert bar1 is bar2
    except Exception as ex:
        # this should fail
        pytest.fail('Bar.__init__() failed: {0}'.format(ex))


# Generated at 2022-06-23 14:28:01.924635
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest


    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.my_list = set()

        def add_obj(self, obj):
            self.my_list.add(obj)


    class TestSingletonCase(unittest.TestCase):

        def __init__(self, *args, **kwargs):
            super(TestSingletonCase, self).__init__(*args, **kwargs)
            self.my_list_1 = set()
            self.my_list_2 = set()

        def test_add_obj(self):
            s = TestSingleton()
            s.add_obj(1)
            s.add_obj(2)
            s.add_obj(3)
            self.__class

# Generated at 2022-06-23 14:28:06.840349
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self, x):
            self.x = x
        def get_x(self):
            return self.x

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2


# Generated at 2022-06-23 14:28:11.285162
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("A object is created!")

    a = A()
    print(id(a))
    b = A()
    print(id(b))
    assert id(a) == id(b)


# Generated at 2022-06-23 14:28:15.323405
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass
    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2

# Generated at 2022-06-23 14:28:22.331154
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    # Test class
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a='a'):
            self.__a = a

        def get_a(self):
            return self.__a

    # Test case 1
    instance1 = TestSingleton('b')
    assert instance1.get_a() == 'b'

    # Test case 2
    instance2 = TestSingleton('c')
    assert instance1 == instance2
    assert instance1.get_a() == 'c'
    assert instance2.get_a() == 'c'

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:28:27.016104
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a subclass of Singleton
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    # Call the constructor
    a = Foo()
    # a and b should be the same object
    b = Foo()
    assert a is b



# Generated at 2022-06-23 14:28:29.350414
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    FOO_INSTANCE_ID = id(Foo())

    for _ in range(100):
        assert id(Foo()) == FOO_INSTANCE_ID

# Generated at 2022-06-23 14:28:31.609637
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    test1 = Test("test1")
    test2 = Test("test2")
    assert id(test1) == id(test2)
    assert test1.arg == "test2"
    assert test2.arg == "test2"

# Generated at 2022-06-23 14:28:43.073390
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest
    from threading import Thread
    class B(pytest.TestCase):
        """
        Test class B 
        """
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 3
    def create_thread():
        """
        Create thread
        """
        B()

    def first_thread():
        """
        A simple function that tests if the class B
        instantiated in the first thread has a attr a
        """
        assert B().a == 3

    def second_thread():
        """
        A simple function that tests another class B
        instantiated in the second thread has also a attr a
        """
        assert B().a == 3

    # test for singleton attr instantiation for class B
    # by ensuring that all classes B have the same attr

# Generated at 2022-06-23 14:28:49.130087
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a singleton class
    class SingletonClass:
        __metaclass__ = Singleton

    # Instantiate and test that the same instance is returned
    # on subsequent calls
    instance1 = SingletonClass()
    instance2 = SingletonClass()
    assert instance1 == instance2
    assert id(instance1) == id(instance2)


# Generated at 2022-06-23 14:28:55.434860
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    x = TestSingleton(42)
    print(id(x))
    y = TestSingleton(43)
    print(id(y))
    z = TestSingleton(44)
    print(id(z))
    assert id(x) == id(y) == id(z)



# Generated at 2022-06-23 14:29:01.267022
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class class1(object):
        __metaclass__ = Singleton
        a = 0
        def __init__(self):
            class1.a += 1
    class1()
    class1()
    assert (class1.a == 1)
    class1()
    class1()
    assert (class1.a == 1)

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-23 14:29:04.411736
# Unit test for constructor of class Singleton
def test_Singleton():
    class t1(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    a=t1()
    b=t1()
    assert id(a) == id(b)

# Generated at 2022-06-23 14:29:07.377324
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.var = 1

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1.var == 1
    assert t2.var == 1
    assert t1.var == t2.var

# Generated at 2022-06-23 14:29:12.792272
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
    test_instance = TestSingleton()
    print(test_instance)

# test in the command line:
# $ python [python source code]
if __name__== "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:29:17.877433
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            pass


if __name__ == '__main__':
    import unittest
    class MyTestCase(unittest.TestCase):
        def setUp(self):
            '''
            This function will be called for each testcase before running code defined in the testcase.
            '''
            pass

        def tearDown(self):
            '''
            This function will be called for each testcase after running code defined in the testcase.
            '''
            pass

        def test_Singleton(self):
            a = test_Singleton()
            b = test_Singleton()
            c = test_Singleton()
            assert b is c


# Generated at 2022-06-23 14:29:19.852281
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S1(object, metaclass=Singleton):
        pass

    a = S1()
    b = S1()

    assert a is b

# Generated at 2022-06-23 14:29:24.599632
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        def __init__(self):
            self.a = 0
    a = TestClass()
    b = TestClass()
    assert a is b
    assert a.a == b.a == 0

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-23 14:29:28.766535
# Unit test for constructor of class Singleton
def test_Singleton():
    obj1 = Singleton()
    obj2 = Singleton()

    # test whether id of obj1 and obj2 are the same
    assert id(obj1) == id(obj2)



# Generated at 2022-06-23 14:29:31.802521
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object, metaclass=Singleton):
        pass

    assert type(TestSingleton()) == TestSingleton
    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-23 14:29:35.521681
# Unit test for constructor of class Singleton
def test_Singleton():

    class TestClass(metaclass=Singleton):
        def __init__(self):
            self.val = 1

    test_obj1 = TestClass()
    test_obj2 = TestClass()

    assert test_obj1.val == 1
    assert test_obj2.val == 1
    assert test_obj1 == test_obj2

    test_obj2.val = 4
    assert test_obj2.val == test_obj1.val

    test_obj1.val = 0
    assert test_obj2.val == test_obj1.val

    test_obj2 = None
    test_obj1 = None



# Generated at 2022-06-23 14:29:44.306556
# Unit test for constructor of class Singleton
def test_Singleton():
    def assert_is_not_none():
        assert s1.__instance is not None
        assert s2.__instance is not None

    def assert_is_none():
        assert s1.__instance is None
        assert s2.__instance is None

    class s1(object):
        __metaclass__ = Singleton
        pass

    class s2(object):
        __metaclass__ = Singleton
        pass

    assert_is_none()
    s1()
    assert_is_not_none()
    s2()
    assert_is_not_none()
    s2()
    assert_is_not_none()

    # clean up singleton
    s1.__instance = None
    s2.__instance = None
    assert_is_none()



# Generated at 2022-06-23 14:29:54.410951
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        """The class of instances that implement the Singleton pattern.
        """
        __metaclass__ = Singleton

        def __init__(self, a=0):
            self.a = a

    class TestSingleton2(object):
        """The class of instances that implement the Singleton pattern.
        """
        __metaclass__ = Singleton

        def __init__(self, b=0):
            self.b = b

    assert TestSingleton(2) == TestSingleton(3)
    assert TestSingleton().a == TestSingleton(1).a
    assert TestSingleton2().b == TestSingleton2(5).b
    assert TestSingleton() != TestSingleton2()


# Tests for method __init__ of class Singleton

# Generated at 2022-06-23 14:30:03.818494
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo:
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 0
            self.b = 3

    f1 = Foo()
    f2 = Foo()
    assert f1 == f2
    assert f1 is f2
    assert f1.a == 0
    assert f1.b == 3
    assert f2.a == 0
    assert f2.b == 3

    f1.a = 1
    f1.b = 2
    assert f1 == f2
    assert f1 is f2
    assert f1.a == 1
    assert f1.b == 2
    assert f2.a == 1
    assert f2.b == 2



# Generated at 2022-06-23 14:30:06.000278
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    s1 = TestSingleton()
    s2 = TestSingleton()

    assert s1 == s2

# Generated at 2022-06-23 14:30:13.335830
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = None
            print('initializing A')

    class B(A):
        def __init__(self):
            print('initializing B')

    a1 = A()
    a2 = A()

    assert(a1 is a2)

    b1 = B()
    b2 = B()

    assert(b1 is b2)
    assert(a1 is b1)

# Generated at 2022-06-23 14:30:21.545801
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, name, value):
            self._name = name
            self._value = value

        def name(self):
            return self._name

        def value(self):
            return self._value

    # Call the class a 1st time
    myClassInstance1 = MyClass('foo', 'bar')

    # Call the class a 2nd time
    myClassInstance2 = MyClass('spam', 'eggs')

    # Check that the 2nd call to the class did not instantiate a new instance
    assert myClassInstance1 is myClassInstance2
    assert myClassInstance1.name() == 'foo'
    assert myClassInstance1.value() == 'bar'


# Generated at 2022-06-23 14:30:28.455227
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import sys
    import mock

    class SingletonClassTest(object):
        __metaclass__ = Singleton

    class SingletonClassSubclassTest(SingletonClassTest, object):
        pass

    with mock.patch.object(sys, 'modules', {'__main__': mock.MagicMock()}):
        inst1 = SingletonClassTest()
        assert inst1 is SingletonClassTest()
        inst2 = SingletonClassSubclassTest()
        assert inst2 is SingletonClassSubclassTest()
        assert inst1 is inst2


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

# Generated at 2022-06-23 14:30:39.884923
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.data = "data"

    class B(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class C(object):
        __metaclass__ = Singleton
        def __init__(self, a = "a", b = "b"):
            self.a = a
            self.b = b

    print("A singleton")
    a1 = A()
    print(a1.data)
    a2 = A()
    a2.data = "new data"
    print(a1.data)

    print("B singleton")
    b1 = B(1, 2)

# Generated at 2022-06-23 14:30:45.116736
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # No object defined yet
    assert Singleton.__instance is None

    # Creates the only object of class TestClass
    test_a = TestClass()
    assert test_a is Singleton.__instance

    # Creates an object of class TestClass,
    # but it uses the reference of the firstly created object
    test_b = TestClass()
    assert test_a is test_b
    assert test_b is Singleton.__instance


# Generated at 2022-06-23 14:30:56.065778
# Unit test for constructor of class Singleton
def test_Singleton():
    from types import MethodType
    from test_utils.fixtures import TempDirFixture
    from test_utils.compat import is_py3
    from test_utils.sanity import (
        AnsibleModuleTestCase,
        AnsibleExitJson,
        AnsibleFailJson,
    )
    from test_utils.sanity import AnsibleModuleTestCase

    # Generate a class
    class SingletonTest():
        __metaclass__ = Singleton

    # Instantiate a class
    test_cls_1 = SingletonTest()

    if not is_py3:
        type.__call__ = MethodType(type.__call__, None, type)

    # Instantiate a class
    test_cls_2 = SingletonTest()

    assert(test_cls_1 == test_cls_2)

# Generated at 2022-06-23 14:31:01.995106
# Unit test for constructor of class Singleton
def test_Singleton():

    class TestClass(metaclass=Singleton):
        def __init__(self):
            super(TestClass, self).__init__()
            self.a = 1
            self.b = 2

    o1 = TestClass()
    o2 = TestClass()

    assert (o1 == o2)
    assert (o1 is o2)
    assert (o1.a == o2.a)
    assert (o1.b == o2.b)

# Generated at 2022-06-23 14:31:07.688360
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class A(object):
        __metaclass__ = Singleton

        def __init__(self, v):
            self.v = v

    a = A(1)
    assert isinstance(a, A)
    assert a.v == 1

    b = A(2)
    assert isinstance(b, A)
    assert b.v == 1

    # Check instance hash
    c = A(3)
    assert hash(a) == hash(c)

    # Check instance unicity
    assert a is b is c

# Generated at 2022-06-23 14:31:13.215615
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(with_metaclass(Singleton)):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return str(self.value)

    t1 = Test(42)
    t2 = Test(43)
    assert t1 is t2
    assert t1.value == 42 and t2.value == 42


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:31:23.124252
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("Init")
        def __del__(self):
            print("Del")

    print("Create a new instance")
    s1 = SingletonTest()
    print("Create another instance")
    s2 = SingletonTest()

    print("Check if they're the same")
    print("s1 == s2 : {}".format(s1 == s2))

    print("Delete s1")
    del s1

    print("Create a new instance")
    s3 = SingletonTest()

    print("Check if they're the same")
    print("s2 == s3 : {}".format(s2 == s3))

    del s2
    del s3


# Generated at 2022-06-23 14:31:27.755474
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    assert(Foo(1).x == 1)

    assert(Foo(2).x == 1)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:31:31.739906
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, initarg):
            self.initarg = initarg
    class Bar():
        __metaclass__ = Singleton
        def __init__(self, initarg):
            self.initarg = initarg

    foo = Foo(1)
    foo2 = Foo(2)
    assert foo.initarg == foo2.initarg
    assert foo.initarg == 1

    bar = Bar(3)
    bar2 = Bar(4)
    assert bar.initarg == bar2.initarg
    assert bar.initarg == 3

    assert foo is not bar
    assert foo2 is not bar2
    assert foo2 is foo
    assert bar2 is bar

# Generated at 2022-06-23 14:31:35.561436
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    singleton1 = SingletonTest()
    singleton2 = SingletonTest()
    assert singleton1 is singleton2

# Generated at 2022-06-23 14:31:42.895811
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    instance1 = TestSingleton("bar")
    assert isinstance(instance1, TestSingleton), "instance1 is not an instance of TestSingleton"

    instance2 = TestSingleton("baz")
    assert instance1 is instance2, "instance1 is not instance2"
    assert instance1.foo == instance2.foo, "instance1.foo != instance2.foo"

# Generated at 2022-06-23 14:31:44.569357
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    m = MyClass(23)
    assert m.a == 23
    assert m is MyClass(24)

# Generated at 2022-06-23 14:31:47.492208
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
    a = Test()
    b = Test()
    assert a is b


# Generated at 2022-06-23 14:31:52.881376
# Unit test for constructor of class Singleton
def test_Singleton():
    # check the constructor
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 10

    t1 = Test()
    t2 = Test()
    assert (t1.value == 10)
    assert (t2.value == 10)
    assert (t1.value == t2.value)


# Generated at 2022-06-23 14:31:55.420454
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    s = TestSingleton()
    s2 = TestSingleton()

    assert(s == s2)


# Generated at 2022-06-23 14:31:59.004752
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # TODO
    # See https://github.com/ansible/ansible/issues/54434
    # See https://github.com/ansible/ansible/issues/54270
    return


# Generated at 2022-06-23 14:32:04.054007
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from datetime import datetime

    class Foo():
        __metaclass__ = Singleton

        def __init__(self):
            self.id = datetime.now()

    a = Foo()
    b = Foo()

    assert a == b
    assert a.id == b.id

# Generated at 2022-06-23 14:32:07.886222
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        pass
    assert(SingletonTest() != SingletonTest())

    class SingletonTest(object):
        __metaclass__ = Singleton

    assert(SingletonTest() == SingletonTest())

# Generated at 2022-06-23 14:32:11.833097
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            pass

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-23 14:32:18.975970
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import time

    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            time.sleep(0.5)
            self.token = 'MyClass'

    start = time.time()
    my1 = MyClass()
    my2 = MyClass()
    my3 = MyClass()

    assert(my1 == my2)
    assert(my1 == my3)
    assert(my2 == my3)

    assert(my1.token == 'MyClass')
    assert(my2.token == 'MyClass')
    assert(my3.token == 'MyClass')
    print('time spent: %s' % (time.time() - start,))

# Generated at 2022-06-23 14:32:20.839995
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class a(object):
        __metaclass__ = Singleton

    assert(a() is a())


# Generated at 2022-06-23 14:32:24.558922
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert id(a) == id(b)


# Generated at 2022-06-23 14:32:29.825481
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name
            print("Create TestSingleton instance: " + self.name)

    test = TestSingleton("a")
    print(test.name)

    test = TestSingleton("b")
    print(test.name)



# Generated at 2022-06-23 14:32:40.896958
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    class B(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1.a == 1, "Instance a1 is not expected."
    assert a1 is a2, "Instance a1 is not equal to instance a2."

    b1 = B("test")
    b2 = B("test")
    assert b1.a == "test", "Instance b1 is not expected."
    assert b1 is b2, "Instance b1 is not equal to instance b2."

# Generated at 2022-06-23 14:32:45.188344
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(metaclass=Singleton):
        pass

    my_singleton_instance_1 = MySingleton()
    my_singleton_instance_2 = MySingleton()

    assert my_singleton_instance_1 == my_singleton_instance_2
    assert my_singleton_instance_1 is my_singleton_instance_2

# Generated at 2022-06-23 14:32:51.762831
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    from threading import Thread
    from time import sleep

    num_threads = 10

    def thread_func(singleton_instance, thread_id):
        try:
            if singleton_instance is not None:
                sleep(0.5)
                assert singleton_instance is SingletonTest()
                print("thread " + thread_id + ": ok")
            else:
                print("thread " + thread_id + ": unexpected None")

        except AssertionError:
            print("thread " + thread_id + ": unexpected None")

        except:
            print("thread " + thread_id + ": unexpected error")

    threads = []

# Generated at 2022-06-23 14:32:57.361379
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    m = MySingleton(0,0)
    assert(m.a == 0 and m.b == 0)

    m = MySingleton(1,1)
    assert(m.a == 0 and m.b == 0)



# Generated at 2022-06-23 14:33:01.872280
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):

        __metaclass__ = Singleton

        def __init__(self):
            self.value = 10

    f1 = Foo()
    f2 = Foo()

    assert f1.value == f2.value



# Generated at 2022-06-23 14:33:04.904206
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(with_metaclass(Singleton, object)):
        pass

    x = MyClass()
    assert id(x) == id(MyClass()), "MyClass is not singleton"


# Generated at 2022-06-23 14:33:09.183557
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = SingletonTest()
    b = SingletonTest()

    assert a is b
    assert a.x == 1
    assert b.x == 1

    a.x = 2

    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-23 14:33:10.916157
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert id(A()) == id(A())

# Generated at 2022-06-23 14:33:15.076568
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestClass1(object):
        __metaclass__ = Singleton

    a1 = TestClass1()
    a2 = TestClass1()
    assert a1 is a2

    b1 = TestClass1()
    b2 = TestClass1()
    assert a1 is b1
    assert a2 is b2

# Generated at 2022-06-23 14:33:16.397473
# Unit test for constructor of class Singleton
def test_Singleton():
    a = Singleton()
    b = Singleton()
    assert a == b

# Generated at 2022-06-23 14:33:21.454195
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    class B(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 == a2

    b1 = B()
    b2 = B()
    assert b1 == b2

# Generated at 2022-06-23 14:33:30.554312
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestSingleton(object):
        """The class to be tested - TestSingleton"""
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    # The instance of TestSingleton should be the same
    test_singleton_instance_1 = TestSingleton(1)
    test_singleton_instance_2 = TestSingleton(2)

    assert test_singleton_instance_1 is test_singleton_instance_2
    assert test_singleton_instance_1.value == 2


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:33:38.988568
# Unit test for constructor of class Singleton
def test_Singleton():
    from contextlib import contextmanager
    from itertools import cycle
    from threading import Thread
    from time import sleep

    class SingletonTest(object):
        __metaclass__ = Singleton

    @contextmanager
    def threads(n):
        """Give me n threads to play with."""
        threads = []

        try:
            for _ in xrange(n):
                t = Thread(target=SingletonTest)
                t.start()
                threads.append(t)
                yield threads[-1]

        finally:
            for thread in threads:
                thread.join()

    # Test that a single instance is created and returned
    with threads(1):
        pass

    # Test that the same instance is being returned from multiple threads
    instances = set()

# Generated at 2022-06-23 14:33:48.265383
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    print("-" * 10, "test_Singleton___call__", "-" * 10)
    instance1 = MyClass()
    instance2 = MyClass()
    instance1.a = 2
    print(instance1.a)
    print(instance2.a)
    assert instance1 is instance2
    print("-" * 10, "test_Singleton___call__", "-" * 10)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:33:51.091190
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass

    a1 = A()
    a2 = A()
    assert a1 == a2


# Generated at 2022-06-23 14:34:01.165972
# Unit test for constructor of class Singleton
def test_Singleton():
    import sys
    sys.path.append("/Users/xiaojing/Desktop/work/PycharmProject/senz_project/env/lib/python2.7/site-packages")
    import six

    class A(six.with_metaclass(Singleton, object)):
        def __init__(self):
            self.name = 'A'

    a1 = A()
    assert a1.name == 'A'
    a2 = A()
    assert a2.name == 'A'
    assert a1 == a2
    a2.name = 'B'
    assert a2.name == 'B'
    assert a1.name == 'B'

    class B(six.with_metaclass(Singleton, object)):
        def __init__(self):
            self.name = 'B'

# Generated at 2022-06-23 14:34:06.304028
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class a(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a1 = a()
    assert a1
    a2 = a()
    assert a2
    assert a1 == a2
    assert id(a1) == id(a2)


# Generated at 2022-06-23 14:34:14.052598
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest

    class M(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 5

    m1 = M()
    m2 = M()
    if not m1.a == 5:
        pytest.fail('m1.a not 5')
    if not m2.a == 5:
        pytest.fail('m2.a not 5')
    if not m1 is m2:
        pytest.fail('m1 not m2')


# Generated at 2022-06-23 14:34:22.432855
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    # Tests class implementing Singleton
    class Test1(metaclass=Singleton):
        def __init__(self):
            self.ini = 0

    # Tests class implementing Singleton
    class Test2(metaclass=Singleton):
        def __init__(self):
            pass

    # Tests inherited class using the same Singleton instance
    class Test3(Test2):
        def __init__(self):
            pass

    # Tests inherited class using a different Singleton instance
    class Test4(Test2):
        def __init__(self):
            pass

        class __metaclass__(Singleton):
            pass

    # Tests class implementing Singleton with __init__ method
    # calling its superclass method
    class Test5:
        def __init__(self):
            pass


# Generated at 2022-06-23 14:34:28.171737
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, foo, bar='bar'):
            self.foo = foo
            self.bar = bar

    f1 = Foo('hello world!')
    f2 = Foo('good bye world!', bar='baz')
    assert f1 is f2
    assert f1.bar == 'baz'

# Generated at 2022-06-23 14:34:38.387467
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class Module1(AnsibleModule):
        """empty AnsibleModule"""
        @staticmethod
        def exit_json(*args, **kwargs):
            pass

        @staticmethod
        def fail_json(*args, **kwargs):
            pass

    class Module2(AnsibleModule):
        """empty AnsibleModule"""
        @staticmethod
        def exit_json(*args, **kwargs):
            pass

        @staticmethod
        def fail_json(*args, **kwargs):
            pass

    # call constructor of AnsibleModule

# Generated at 2022-06-23 14:34:45.081298
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    # Create 2 instances of Foo
    foo = Foo()
    foo2 = Foo()

    # Test if the 2 instances are the same
    #assert foo is foo2

    # Create 2 instances of Foo using different parameters
    foo3 = Foo(1, 2)
    foo4 = Foo(3, 4)

    # Test again if the 2 instances are the same
    #assert foo3 is foo4
#test_Singleton()

# Generated at 2022-06-23 14:34:48.101238
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(with_metaclass(Singleton)):
        def __init__(self, thing):
            self.thing = thing

    a = TestClass(1)
    b = TestClass(2)
    assert a is b
    assert b.thing == 2

# Generated at 2022-06-23 14:34:50.064484
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass
    assert TestSingleton() == TestSingleton()

# Generated at 2022-06-23 14:34:51.989942
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    b1 = A()
    b2 = A()
    assert b1 is b2

# Generated at 2022-06-23 14:34:53.427185
# Unit test for constructor of class Singleton
def test_Singleton():
    assert(Singleton is not None)


# Generated at 2022-06-23 14:34:57.806963
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            pass

    TestClass(1, 2, 3)
    TestClass(4, 5, 6)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:35:02.642613
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, val=1):
            self.val = val

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.val == a2.val == 1


# Generated at 2022-06-23 14:35:04.551696
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()

    assert f1 is f2

# Generated at 2022-06-23 14:35:08.114298
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('Creating class')

    my1 = MySingleton()
    my2 = MySingleton()
    assert my1 == my2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:35:16.463995
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test1(object):
        __metaclass__ = Singleton
        pass

    class Test2(object):
        __metaclass__ = Singleton
        pass

    t1 = Test1()
    assert isinstance(t1, Test1)
    t2 = Test1()
    assert t1 is t2
    assert not isinstance(t2, Test2)

    t3 = Test2()
    assert isinstance(t3, Test2)
    t4 = Test2()
    assert t3 is t4
    assert not isinstance(t4, Test1)

# Generated at 2022-06-23 14:35:18.327863
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-23 14:35:23.618041
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(metaclass=Singleton):
        def __init__(self, a, b):
            self.a = a + 1
            self.b = b + 1

    x = SingletonTest(1, 2)
    y = SingletonTest(3, 4)

    assert id(x) == id(y)
    assert x.a == 2
    assert x.b == 3


# Generated at 2022-06-23 14:35:25.009985
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Klass(metaclass=Singleton):
        pass

    assert Klass is Klass()


# Generated at 2022-06-23 14:35:33.575126
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

        def set_value(self, value):
            self.value = value

        def get_value(self):
            return self.value

    assert Test(1).get_value() == 1
    a = Test(2)
    assert a.get_value() == 2
    assert a is Test(2)
    a.set_value(3)
    assert Test(2).get_value() == 3


# Testing only - not intended for use

# Generated at 2022-06-23 14:35:38.496174
# Unit test for constructor of class Singleton
def test_Singleton():
    # Test the class Singleton
    class TestSingleton(object):
        __metaclass__ = Singleton

    # Create two instances
    s1 = TestSingleton()
    s2 = TestSingleton()

    # Check that there are only two instances in the system
    assert(s1 is s2)


if __name__ == '__main__':
    # Run test
    test_Singleton()

# Generated at 2022-06-23 14:35:46.096120
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    # Test if the singleton is correctly initialized on creation
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    foo = Foo(a=42)
    assert foo.a == 42
    foo2 = Foo(a=23)
    assert foo2.a == 42
    assert foo is foo2

    # Test if the singleton is correctly initialized when
    # the instance has already been created
    class Bar(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    bar = Bar()
    assert bar.a is None
    bar2 = Bar(a=42)
    assert bar2.a == 42
    assert bar is bar2

    # Test if the singleton is correctly

# Generated at 2022-06-23 14:35:51.044739
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global t1
    global t2
    global t3

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, msg):
            self.msg = msg
            print(msg)

        def getMsg(self):
            return self.msg

    t1 = TestSingleton('1')
    t2 = TestSingleton('2')
    t3 = TestSingleton('3')
    assert t1 is t2 is t3


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:35:57.209762
# Unit test for constructor of class Singleton
def test_Singleton():
    # pylint: disable=C0111
    class E(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            # pylint: disable=W0231
            self.args = args
            self.kwargs = kwargs

    assert E() is E(), "Instance returned wasn't singleton"

    e = E(1, 2, three=3)
    assert e.args == (1, 2), "Instance returned wasn't singleton"
    assert e.kwargs == {"three": 3}, "Instance returned wasn't singleton"

# Generated at 2022-06-23 14:36:02.075041
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2

# Test for method __call__ of class Singleton
# Even if there are multiple calls with different arguments,
# only one instance should be created

# Generated at 2022-06-23 14:36:04.340169
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    assert isinstance(A(), A)
    assert A() is A()



# Generated at 2022-06-23 14:36:09.713890
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    foo1 = Foo()
    foo2 = Foo()
    if foo1.a != foo2.a:
        raise RuntimeError('Failed to create singleton')

# Test it
if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:36:12.542254
# Unit test for constructor of class Singleton
def test_Singleton():
    class Single:
        __metaclass__ = Singleton

    s = Single()
    t = Single()
    assert s is t


# Generated at 2022-06-23 14:36:15.240823
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a = A(1)
    b = A(2)
    assert a is b
    assert a.a == 1
    assert a.a == b.a

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:36:18.254554
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    obj1 = TestClass()
    obj2 = TestClass()
    assert obj1 == obj2

# Generated at 2022-06-23 14:36:21.650205
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    class MySubClass(MyClass):
        pass

    class MyOtherClass(object):
        __metaclass__ = Singleton

    a = MyClass()
    b = MyClass()
    c = MyOtherClass()
    d = MyOtherClass()

    assert a is b
    assert c is d

# Generated at 2022-06-23 14:36:25.308950
# Unit test for constructor of class Singleton
def test_Singleton():
    class A():
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert(a1 == a2)
    #assert(id(a1) == id(a2))


# Generated at 2022-06-23 14:36:27.851519
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Klass:  # noqa
        __metaclass__ = Singleton

    assert id(Klass()) == id(Klass())



# Generated at 2022-06-23 14:36:30.772061
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    cls1 = MyClass()
    cls2 = MyClass()
    assert cls1 is cls2

# Generated at 2022-06-23 14:36:37.144501
# Unit test for constructor of class Singleton
def test_Singleton():
    """Checks if Singleton works as expected
    """
    
    class TestClass(metaclass = Singleton):
        def __init__(self, value = None):
            self.value = value

    a = TestClass("a")
    b = TestClass("b")
    c = TestClass("c")

    assert a is b
    assert b is c
    assert a is c

    assert a.value == "c"
    assert b.value == "c"
    assert c.value == "c"

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:36:41.960682
# Unit test for constructor of class Singleton
def test_Singleton():
    class T(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    t = T(1)
    assert t.arg == 1

    u = T(2)
    assert u == t
    assert u.arg == 1

# Generated at 2022-06-23 14:36:45.216437
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 5

    assert TestSingleton() is TestSingleton()
    assert TestSingleton().value == 5

# Generated at 2022-06-23 14:36:54.296340
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("MyClass __init__ called")

    a1 = MyClass()
    a2 = MyClass()
    print("id(a1) = ", id(a1), "id(a2) = ", id(a2))
    assert id(a1) == id(a2)
    print("id(a1._Singleton__instance) = ", id(a1._Singleton__instance), "id(a2._Singleton__instance) = ", id(a2._Singleton__instance))
    assert id(a1._Singleton__instance) == id(a2._Singleton__instance)

test_Singleton()

# Generated at 2022-06-23 14:36:57.976558
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
    test_a = Test()
    test_b = Test()
    assert id(test_a) == id(test_b), 'Instance of singleton class is not unique'



# Generated at 2022-06-23 14:37:04.585470
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    test_instance = TestClass("this is a test")
    assert test_instance.value == "this is a test"

    test_instance2 = TestClass("this is a test 2")
    assert test_instance.value == "this is a test"
    assert test_instance is test_instance2

# Generated at 2022-06-23 14:37:09.312453
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        test_value = 1

    class Test1(object):
        __metaclass__ = Singleton
        test_value = 1

    test1 = Test()
    test2 = Test1()
    assert test1 is test2

# Generated at 2022-06-23 14:37:13.523396
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self, x=0):
            self.x = x

    a = A(1)
    b = A()
    assert a == b
    assert a.x == 1
    assert b.x == 1


# Generated at 2022-06-23 14:37:15.744962
# Unit test for constructor of class Singleton
def test_Singleton():
    class Myclass(metaclass=Singleton):
        pass

    Myclass1 = Myclass()
    Myclass2 = Myclass()

    assert Myclass1 == Myclass2

# Generated at 2022-06-23 14:37:19.273932
# Unit test for constructor of class Singleton
def test_Singleton():
    from six import with_metaclass
    class A(with_metaclass(Singleton, object)):
        def __init__(self):
            pass

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-23 14:37:24.690289
# Unit test for constructor of class Singleton
def test_Singleton():
    def f(x):
        return x
    
    # If assign to Singleton class, the __call__ of Singleton metaclass will be called
    Singleton1 = Singleton('Singleton1', (object,), {'__init__': f})
    x = Singleton1(1)
    y = Singleton1(2)
    print(x == y)


# Generated at 2022-06-23 14:37:30.147823
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    foo = Foo('test')
    assert foo
    assert foo.name == 'test'

    foo2 = Foo('test2')
    assert foo2
    assert foo2.name == 'test'


if __name__ == '__main__':
  test_Singleton()

# Generated at 2022-06-23 14:37:34.897770
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, n):
            self.n = n

    tc1 = TestClass(1)
    tc2 = TestClass(2)
    assert tc1.n == 1
    assert tc2.n == 1

# Generated at 2022-06-23 14:37:40.366499
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # singleton
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2

    # non singleton
    class B(object):
        __metaclass__ = Singleton
        __singleton__ = False

    b1 = B()
    b2 = B()
    assert b1 is not b2

# Generated at 2022-06-23 14:37:45.061149
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = A(1, 2)
    t2 = A(2, 3)

    assert t1 == t2
    assert t1.a == 1
    assert t1.b == 2