

# Generated at 2022-06-23 14:27:47.352247
# Unit test for constructor of class Singleton
def test_Singleton():

    class SingletonTest1(object):
        __metaclass__ = Singleton

    class SingletonTest2(object):
        __metaclass__ = Singleton

    instance1 = SingletonTest1()
    instance2 = SingletonTest1()
    assert instance1 is instance2

    instance3 = SingletonTest2()
    instance4 = SingletonTest2()
    assert instance3 is instance4

    assert instance1 != instance3

# Generated at 2022-06-23 14:27:52.769136
# Unit test for constructor of class Singleton
def test_Singleton():
    """Test that Singleton(type) returns the same object if it is
    instantiated more than once"""
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)
    assert a1 is a2

# Generated at 2022-06-23 14:27:55.527307
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    assert Foo() == Foo()

# Generated at 2022-06-23 14:27:59.203964
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        pass
    s1 = TestSingleton()
    s2 = TestSingleton()
    assert s1 is s2
    assert TestSingleton.__instance is s1
    assert TestSingleton.__instance is s2

# Generated at 2022-06-23 14:28:06.737461
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = 1
        def incr(self):
            self.foo += 1
    a = MyClass()
    b = MyClass()
    print('a: ', a.foo)
    print('b: ', b.foo)
    assert a == b
    b.incr()
    print('b: ', b.foo)
    print('a: ', a.foo)
    assert b.foo == a.foo


# Generated at 2022-06-23 14:28:11.176928
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass
    a1 = A()
    a2 = A()
    assert a1 == a2
    class B(A):
        pass
    b1 = B()
    assert b1 == a1


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:28:20.992699
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from sys import modules
    from os import path
    from .loader import get_all_plugin_loaders
    from .callback import CallbackModule
    from .filter import FilterModule

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.counter = 0

        def inc_counter(self):
            self.counter += 1

    # Test that plugin loaders are singletons
    plugin_loaders = get_all_plugin_loaders()
    assert plugin_loaders['action'] is plugin_loaders['action']

    assert hasattr(modules[__name__], 'FilterModule')
    assert hasattr(modules[__name__], 'TestSingleton')
    assert not hasattr(modules[__name__], 'CallbackModule')

# Generated at 2022-06-23 14:28:24.501751
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert id(t1) == id(t2)

# Generated at 2022-06-23 14:28:26.725407
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        """Test Singleton metaclass"""
        __metaclass__ = Singleton
        def __init__(self):
            self.data = []

    t1 = TestClass()
    t2 = TestClass()

    assert t1 == t2
    t1.data.append("Hello World!")
    assert t1.data == t2.data

# Generated at 2022-06-23 14:28:30.570888
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    t1 = Test()
    assert t1.a == 1

    t2 = Test()
    assert t2.a == 1

    t2.a = 2
    assert t2.a == 2

    assert t1 is t2
    assert t1.a == t2.a
    assert t1.a == 2

# Generated at 2022-06-23 14:28:33.623531
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    s1 = TestSingleton()
    s2 = TestSingleton()
    assert s1 == s2

# Generated at 2022-06-23 14:28:43.858997
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.v = 0

        def test(self):
            self.v += 1
            return self.v

    class Test2(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.v = 0

        def test(self):
            self.v += 1
            return self.v

    a, b, c = Test(), Test(), Test()
    a1, a2, a3 = Test2(), Test2(), Test2()

    assert a == b and a == c
    assert a1 == a2 and a2 == a3

    assert a.test() == 1 and b.test() == 2 and c.test() == 3
    assert a1.test() == 1 and a

# Generated at 2022-06-23 14:28:49.132409
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    assert TestSingleton('name').name == 'name'
    assert TestSingleton('name2').name == 'name'

# Test for Singleton Class Example:

# Generated at 2022-06-23 14:28:53.965226
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = A()
    assert a.a == 1
    a2 = A()
    assert a2 is a
    assert a2.a == 1
    a2.a = 2
    assert a.a == 2


test_Singleton()

# Generated at 2022-06-23 14:29:04.253593
# Unit test for constructor of class Singleton
def test_Singleton():
    class Dummy(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.attr = 1

        def set_attr(self, attr):
            self.attr = attr

    class Dummy2(object, metaclass=Singleton):
        def __init__(self):
            self.attr2 = 2

        def set_attr(self, attr):
            self.attr2 = attr

    a = Dummy()
    b = Dummy()
    c = Dummy2()
    assert(a.attr == b.attr)
    assert(a.attr == c.attr2)
    a.set_attr(3)
    assert(a.attr == 3)
    assert(b.attr == 3)
    assert(a.attr == c.attr2)

# Generated at 2022-06-23 14:29:15.011671
# Unit test for constructor of class Singleton
def test_Singleton():

    # Create a class with the name 'TestSingleton' inheriting from object and use the Singleton metaclass
    class TestSingleton(object, metaclass=Singleton):

        # The constructor should have the arguments self and word
        def __init__(self, word):

            # Set the word attribute of the instance
            self.word = word

    # Assert TestSingleton's string representation is TestSingleton
    assert str(TestSingleton) == 'TestSingleton'

    # Create three instances
    a = TestSingleton('hello')
    b = TestSingleton('world')
    c = TestSingleton('!')

    # Assert that a, b, and c are the same instance
    assert a is b is c

    # Assert that the word attribute is '!'
    assert a.word == '!'

# Generated at 2022-06-23 14:29:17.802042
# Unit test for constructor of class Singleton
def test_Singleton():
    class CA(object):
        __metaclass__ = Singleton

    a1 = CA()
    a2 = CA()
    assert a1 is a2



# Generated at 2022-06-23 14:29:19.726096
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    a = A()
    assert a is A()


# Generated at 2022-06-23 14:29:31.560592
# Unit test for constructor of class Singleton
def test_Singleton():
    class NoArgClass(metaclass=Singleton):
        def __init__(self):
            self.data = 1

    nac1 = NoArgClass()
    nac2 = NoArgClass()
    assert nac1 == nac2
    assert nac1.data == 1
    assert nac2.data == 1

    class PositionalArgClass(metaclass=Singleton):
        def __init__(self, arg):
            self.data = arg

    pac1 = PositionalArgClass(1)
    pac2 = PositionalArgClass(2)
    assert pac1 == pac2
    assert pac1.data == 1
    assert pac2.data == 1


    class KeywordArgClass(metaclass=Singleton):
        def __init__(self, arg=None):
            self.data = arg



# Generated at 2022-06-23 14:29:34.320952
# Unit test for constructor of class Singleton
def test_Singleton():
    # not implemented yet
    """
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, a='a'):
            self.a = a

    obj1 = MyClass()
    obj2 = MyClass()
    assert id(obj1) == id(obj2)

    obj1.a = "test"
    assert obj2.a == obj1.a
    """
    return

# Generated at 2022-06-23 14:29:35.688042
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        pass

    assert Test() is Test()

# Generated at 2022-06-23 14:29:38.707972
# Unit test for constructor of class Singleton
def test_Singleton():
    class Example(object):
        __metaclass__ = Singleton

    ex1 = Example()
    assert ex1

    ex2 = Example()
    assert ex2 is ex1

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:29:45.724172
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Clazz(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    # Get two instances of Clazz class
    c1 = Clazz(10)
    c2 = Clazz(11)
    # Check if both instances are unique
    assert id(c1) == id(c2)
    # Check if value of x is overwritten to the latest value
    assert c1.x == 11
    assert c2.x == 11



# Generated at 2022-06-23 14:29:48.642485
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        pass

    a1 = A()
    a2 = A()
    assert(a1 is a2)



# Generated at 2022-06-23 14:29:52.508682
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 10

    a1 = A()
    a2 = A()

    assert a1 is a2
    assert id(a1) == id(a2)

# Generated at 2022-06-23 14:29:56.325374
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Dummy(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    dummy1 = Dummy(1)
    dummy2 = Dummy(2)
    assert dummy1 is dummy2
    assert dummy1.value == 1
    assert dummy2.value == 1


# Generated at 2022-06-23 14:29:59.818429
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(Singleton):
        def __init__(self, name):
            self.name = name

    foo_1 = Foo('test')
    assert foo_1.name == 'test'

    foo_2 = Foo('test2')
    assert foo_2.name == 'test'

    assert foo_1 is foo_2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:30:02.443519
# Unit test for constructor of class Singleton
def test_Singleton():
    class Temp(object):
        __metaclass__ = Singleton
    a=Temp()
    b=Temp()
    assert(a is b)

# Generated at 2022-06-23 14:30:04.820495
# Unit test for constructor of class Singleton
def test_Singleton():
    # test that class Singleton exists
    assert isinstance(Singleton, type)

    # test instance of Singleton class
    assert isinstance(Singleton('test_Singleton', (object,), {}), Singleton)



# Generated at 2022-06-23 14:30:15.250570
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import time
    
    class TestClass(object):
        __metaclass__ = Singleton
    '''
    Instance will be created in the first call.
    '''
    t1 = TestClass()
    assert t1 is not None

    '''
    Instance will be returned in the second call.
    '''
    t2 = TestClass()
    assert t2 is t1

    '''
    Instance will be returned even if the singleton class (TestClass)
    is inherited and the instance of the parent class (SingletonClass)
    does not exist.
    '''
    class SingletonClass(object):
        __metaclass__ = Singleton
    class InheritedClass(TestClass):
        pass
    t3 = InheritedClass()
    assert t3 is t1



# Generated at 2022-06-23 14:30:16.844412
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        pass

    c = MyClass()
    assert c is MyClass()

# Generated at 2022-06-23 14:30:21.210802
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class c(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    assert c(1) is not None
    assert c(1).val == 1
    assert c(2).val == 1
    assert c(2) is c(1)
    assert c(2).val == c(1).val


# Generated at 2022-06-23 14:30:24.276392
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    a = Foo(42)
    b = Foo(99)
    assert a is b
    assert a.x == b.x == 42

# Generated at 2022-06-23 14:30:29.151803
# Unit test for constructor of class Singleton
def test_Singleton():
    import types

    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val
    # First time
    obj1 = Test(1)
    assert isinstance(obj1, Test)
    assert obj1.val == 1
    # Second time
    obj2 = Test(2)
    assert isinstance(obj2, Test)
    assert obj2.val == 1
    # obj2 should be the same as obj1
    assert obj1 is obj2

# Generated at 2022-06-23 14:30:34.840933
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    a = MyClass()
    b = MyClass()
    assert a is b  # same object
    c = MyClass()
    assert c is b  # same object

    class NotMyClass(object):
        pass

    b = NotMyClass()
    assert a is not b  # not same object

# Generated at 2022-06-23 14:30:41.920064
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        value = 0

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a is b
    assert a.value == 1

    a.value = 3
    assert a.value == 3
    assert b.value == 3


if __name__ == '__main__':
    test_Singleton()
    print("Tests passed")

# Generated at 2022-06-23 14:30:46.153160
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton = Singleton('singleton', (), {})
    singleton(1)
    singleton(2)
    assert singleton(None) == 1, "Constructor Singleton fails"
    print("Singleton Constructor Test: PASS")


# Generated at 2022-06-23 14:30:48.161248
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()


# Generated at 2022-06-23 14:30:57.053959
# Unit test for constructor of class Singleton
def test_Singleton():
    class c(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1
    obj1 = c()
    obj2 = c()
    print(obj1.x, obj2.x)
    assert obj1 == obj2
    obj1.x = 2
    print(obj1.x, obj2.x)
    assert obj1.x == obj2.x

    obj1 = c()
    obj2 = c()
    obj3 = c()
    print(obj1.x, obj2.x, obj3.x)
    assert obj1 == obj2 == obj3

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:30:58.900050
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-23 14:31:03.731456
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    a1 = A(1, 2)
    a2 = A(3, 4)
    assert a1 is a2
    assert a1.a == 1
    assert a1.b == 2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:31:06.770575
# Unit test for constructor of class Singleton
def test_Singleton():
    class Singleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    s1 = Singleton()
    s2 = Singleton()
    assert s1 is s2

# Generated at 2022-06-23 14:31:08.325047
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton): pass

    a=A()
    b=A()

    assert id(a)==id(b)

# Generated at 2022-06-23 14:31:11.512409
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    class B(object):
        pass
    a = A()
    b = A()
    c = B()
    d = B()
    assert a == b
    assert c != d

# Generated at 2022-06-23 14:31:15.833573
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        pass

    # Create an instance of the class
    my_inst = MyClass()

    # Assert that the class only has one instance
    assert MyClass() == my_inst

# Generated at 2022-06-23 14:31:20.319740
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1
            self.y = 2
            raise Exception("How did I get here?")

    obj1 = MySingleton()
    obj2 = MySingleton()
    assert id(obj1) == id(obj2)

# Generated at 2022-06-23 14:31:31.084035
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class B(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    a1 = A(1,2)
    a2 = A(1,2)
    b1 = B(1,2)
    b2 = B(1,2)
    assert a1 == a2
    assert b1 == b2
    assert a1 != b1
    assert a2 != b2

    # make sure we can still instantiate the class normally
    a3 = A('a', 'b')
   

# Generated at 2022-06-23 14:31:40.529157
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from types import MethodType

    class A(object):
        __metaclass__ = Singleton

    # Test create 2 instances, if 2 instance are the same object
    obj1 = A()
    obj2 = A()
    assert id(obj1) == id(obj2)

    # Test that if a method is added to instance 1, instance 2 gets it too.
    new_method = MethodType(lambda self: self, obj1, obj1.__class__)
    setattr(obj1, 'new_method', new_method)
    assert hasattr(obj2, 'new_method')
    assert hasattr(obj2.new_method, '__self__')
    assert id(obj2.new_method.__self__) == id(obj2)
    assert id(obj2.new_method.__self__) == id

# Generated at 2022-06-23 14:31:42.641875
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.counter = 0

    a = MySingleton()
    b = MySingleton()

    a.counter = 42
    assert (a.counter == b.counter)
    b.coun

# Generated at 2022-06-23 14:31:48.264200
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        value = 1

        def get_value(self):
            return self.value

    assert TestSingleton().get_value() == 1
    assert TestSingleton().get_value() == 1

    o = TestSingleton()
    o.value = 2
    assert o.get_value() == 2
    assert TestSingleton().get_value() == 2

# Generated at 2022-06-23 14:31:51.743435
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTester(object):
        __metaclass__ = Singleton

    a = SingletonTester()
    b = SingletonTester()
    assert (a == b)



# Generated at 2022-06-23 14:31:59.602520
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    a = 'a'
    b = 'b'

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self,value):
            self.value = value

    tsA = TestSingleton(a)
    assert(tsA == TestSingleton(a))
    assert(tsA == tsA)
    assert(tsA is TestSingleton(a))
    assert(tsA is tsA)
    assert(tsA.value == a)
    tsB = TestSingleton(b)
    assert(tsA == tsB)
    assert(tsA.value == b)
    assert(tsB.value == b)
    assert(tsB == tsA)
    assert(tsB is tsA)
    assert(tsB is TestSingleton(a))

# Generated at 2022-06-23 14:32:08.392945
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, val=0):
            self.val = val
    a = A(10)
    b = A(20)
    assert a is b
    assert a.val == b.val == 10
    assert a.val == 10
    assert b.val == 10


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:32:12.015183
# Unit test for constructor of class Singleton
def test_Singleton():
    """Unit test for constructor of class Singleton
    """
    class MyObject(object):
        __metaclass__ = Singleton
        """Class with Singleton behaviour"""

# Generated at 2022-06-23 14:32:15.260459
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        def __init__(self):
            pass
    test_instance_1 = Test()
    test_instance_2 = Test()
    assert test_instance_1 is test_instance_2


# Generated at 2022-06-23 14:32:20.637973
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, test):
            self.test = test

    a = Test("First")
    b = Test("Second")

    assert a == b
    assert a.test == "First"


# Generated at 2022-06-23 14:32:22.489600
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
    assert Foo() == Foo()

# Generated at 2022-06-23 14:32:25.886059
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass__call__(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    TestClass__call__()
    TestClass__call__()
    TestClass__call__()


# Generated at 2022-06-23 14:32:36.535066
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import multiprocessing
    from multiprocessing import Process

    class MySingleton(object):
        __metaclass__ = Singleton

    # Test with threads
    instance1 = MySingleton()
    instance2 = MySingleton()
    assert instance1 is instance2

    # Test with processes
    instance1 = MySingleton()
    p = Process(target=lambda: MySingleton())
    p.start()
    p.join()
    instance2 = MySingleton()
    assert instance1 is instance2

    # Test with processes, and some threads
    instance1 = MySingleton()
    instance2 = []
    threads = []
    for i in range(0, 2):
        threads.append(multiprocessing.Process(target=lambda: instance2.append(MySingleton())))  # noqa
       

# Generated at 2022-06-23 14:32:39.655776
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert id(a) == id(b)

# Generated at 2022-06-23 14:32:43.443232
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            pass
    obj = MyClass()
    assert id(obj) == id(MyClass())

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:32:48.369899
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class MyClass2(MyClass):
        pass

    # two different classes
    m1 = MyClass()
    m2 = MyClass2()

    # two instances of the same class
    m3 = MyClass()
    m4 = MyClass()

    assert m1 is not m2
    assert m1 is m3
    assert m3 is m4

# Generated at 2022-06-23 14:32:51.752121
# Unit test for constructor of class Singleton
def test_Singleton():
    class ASingleton(object):
        __metaclass__ = Singleton

    s1 = ASingleton()
    s2 = ASingleton()
    assert s1 is s2

# Generated at 2022-06-23 14:33:00.276611
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        """docstring for ClassName"""
        __metaclass__ = Singleton

        def __init__(self, name, pwd):
            self.name = name
            self.pwd = pwd

    a1 = A('a1', 'a1')
    a2 = A('a2', 'a2')
    a3 = A('a3', 'a3')
    assert a1 is a2
    assert a1 is a3
    assert a2 is a3
    assert a1.name == 'a3'
    assert a1.pwd == 'a3'
    assert a2.name == 'a3'
    assert a2.pwd == 'a3'
    assert a3.name == 'a3'
    assert a3.pwd == 'a3'


# Generated at 2022-06-23 14:33:09.403734
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonA(object):
        __metaclass__ = Singleton

    class SingletonB(object):
        __metaclass__ = Singleton

    singleton_a1 = SingletonA()
    singleton_a2 = SingletonA()
    assert singleton_a1 == singleton_a2

    singleton_b1 = SingletonB()
    singleton_b2 = SingletonB()
    assert singleton_b1 == singleton_b2

    assert singleton_a1 != singleton_b1
    assert singleton_a2 != singleton_b2

    assert singleton_a1 is singleton_a2
    assert singleton_b1 is singleton_b2
    assert singleton_a1 is not singleton_b1

# Generated at 2022-06-23 14:33:11.477581
# Unit test for constructor of class Singleton
def test_Singleton():
    """Unit test for Singleton"""
    class MyClass(metaclass=Singleton):
        pass

    assert MyClass() is MyClass()

# Generated at 2022-06-23 14:33:16.096051
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test of Singleton.__call__"""
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    assert TestSingleton('first') is TestSingleton('second')
    assert TestSingleton.__instance.value == 'first'



# Generated at 2022-06-23 14:33:22.873828
# Unit test for constructor of class Singleton
def test_Singleton():
    class testSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, element):
            self.element = element

    singleton1 = testSingleton(1)
    singleton2 = testSingleton(2)

    assert isinstance(singleton1, testSingleton)
    assert isinstance(singleton2, testSingleton)
    assert singleton1 is singleton2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:33:27.016972
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    test_foo_1 = Foo()
    test_foo_2 = Foo()

    assert test_foo_1 == test_foo_2
    assert test_foo_1 is test_foo_2

# Generated at 2022-06-23 14:33:29.998307
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    assert A('a') is A('a')

# Generated at 2022-06-23 14:33:34.313940
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

        def print_singleton(self):
            print('Singleton Object')

    # Print singelton object
    s = SingletonTest()
    s.print_singleton()

    # Print singelton object
    s = SingletonTest()
    s.print_singleton()


test_Singleton()

# Generated at 2022-06-23 14:33:42.074505
# Unit test for constructor of class Singleton
def test_Singleton():
    import os, sys
    #this_file = os.path.abspath(__file__).rpartition("/")[0]
    this_file = os.path.abspath(__file__)
    this_file = os.path.split(this_file)[0]
    sys.path.insert(0, this_file)
    from cartesian_product import CartesianProduct
    import copy

    # Create a singleton of CartesianProduct, verify that the instances are the same
    c1 = CartesianProduct()
    c2 = CartesianProduct()
    print ("c1.id={0}, c2.id={1}".format(id(c1), id(c2)))
    assert id(c1) == id(c2)

    # Let's change the value of one instance and check if the value of the other

# Generated at 2022-06-23 14:33:48.213596
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # class Base inherits Singleton
    class Base(object):
        __metaclass__ = Singleton

    # Base class is a Singleton.
    # No matter we call Base() or Base(1, 2, 3)
    # what we get is the same instance
    class_instance_1 = Base()
    class_instance_2 = Base(1, 2, 3)
    assert(class_instance_1 is class_instance_2)


# Generated at 2022-06-23 14:33:55.120581
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Point:
        __metaclass__ = Singleton
        def __init__(self, x, y):
            self.x = x
            self.y = y

    p1 = Point(1, 1)
    assert p1.x == 1
    assert p1.y == 1

    p2 = Point(2, 2)
    assert p1 is p2
    assert p2.x == 1
    assert p2.y == 1

# Generated at 2022-06-23 14:33:57.484800
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    assert(a is A())



# Generated at 2022-06-23 14:34:00.242826
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(__builtins__.object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = 'foo'

    assert isinstance(Foo(), Foo)
    assert Foo() is Foo()



# Generated at 2022-06-23 14:34:03.443463
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    obj = TestClass()
    assert TestClass() is obj

# Generated at 2022-06-23 14:34:10.020222
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        _x = 0
        def __init__(self, **kwargs):
            self._x = kwargs.get('x')

    a = A(x=1)
    assert isinstance(a, A)
    assert a._x == 1

    b = A(x=2)
    assert isinstance(b, A)
    assert b._x == 1

# Generated at 2022-06-23 14:34:20.203503
# Unit test for constructor of class Singleton
def test_Singleton():
    """Test to check the Singleton metaclass

    The test is implemented as follows:

    * Create a class that utilizes the Singleton metaclass
    * Instantiate the class
    * Instantiate the class again, and compare the two instances
    """
    class TestSingleton(object):
        __metaclass__ = Singleton

    s1 = TestSingleton()
    s2 = TestSingleton()

    assert id(s1) == id(s2)

    # Make sure that the singleton is not reused after being
    # destroyed by the garbage collector
    del s1
    del s2
    s3 = TestSingleton()
    assert (s1 is None) and (s2 is None) and (s3 is not None)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:34:30.881051
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import threading

    flag = 0

    class SingletonDemo(object):
        __metaclass__ = Singleton

        def __init__(self):
            global flag
            self.flag = flag
            self.event = threading.Event()
            self.event.clear()

        def set_event(self):
            self.event.set()

        def wait_event(self):
            self.event.wait()

    def run(var):
        s = SingletonDemo()
        assert(s.__class__.__instance is s)

    t1 = threading.Thread(target=run, args=(flag,))
    t2 = threading.Thread(target=run, args=(flag,))
    t1.start()
    t2.start()
    t1.join()
    t2.join()

# Generated at 2022-06-23 14:34:38.344436
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, attr1):
            self.attr1 = attr1
    ts1 = TestSingleton(1)
    assert ts1.attr1 == 1
    ts2 = TestSingleton(2)
    assert ts2.attr1 == 1
    assert ts1 is ts2
    ts3 = TestSingleton(3)
    assert ts3.attr1 == 1
    assert ts1 is ts3
    assert ts2 is ts3

# Generated at 2022-06-23 14:34:44.685150
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.mutex = RLock()
            self.x = None
    a1 = A()
    a2 = A()
    assert isinstance(a1, A)
    assert isinstance(a2, A)
    assert a1 is a2

    a1.x = "a"
    assert a1 is a2
    assert a1.x == a2.x

# Generated at 2022-06-23 14:34:48.238345
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingletonA(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 5

    a = MySingletonA()
    b = MySingletonA()
    assert id(a) == id(b)



# Generated at 2022-06-23 14:34:50.177195
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 5

    assert MyClass() is MyClass()

# Generated at 2022-06-23 14:34:52.452668
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()

    assert id(t1) == id(t2)

# Generated at 2022-06-23 14:34:57.289755
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
	class Foo(object):
		__metaclass__ = Singleton
		def __init__(self, x):
			self.x = x

	f1 = Foo(1)
	f2 = Foo(2)
	assert f1 is f2
	assert f1.x == 1


# Generated at 2022-06-23 14:34:58.870949
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        pass

    instance1 = MyClass()
    instance2 = MyClass()

    assert id(instance1) == id(instance2)

# Generated at 2022-06-23 14:35:04.635999
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class testClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 0

    a = testClass()
    b = testClass()
    print(id(a), id(b))
    a.x = 1
    print(b.x)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:35:05.978691
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.module_utils import six
    import imp


# Generated at 2022-06-23 14:35:09.357055
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, num):
            self.num = num

    assert TestSingleton(1) is TestSingleton(2)
    assert TestSingleton(2).num == 1
    assert id(TestSingleton(1)) == id(TestSingleton(2))

# Generated at 2022-06-23 14:35:17.387292
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
    print("test Singleton")
    print("test1:")
    print("Test is %s" % Test)
    test1 = Test()
    print("test1 is %s" % test1)
    print("test2:")
    test2 = Test()
    print("test2 is %s" % test2)
    print("test3:")
    test3 = Test()
    print("test3 is %s" % test3)
    print("Test is %s" % Test)


# Generated at 2022-06-23 14:35:24.477331
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object, metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    foo = A("foo")
    assert foo.name == "foo"
    bar = A("bar")
    assert foo is bar
    assert foo.name == "foo"

    # Instantiating a class that has been decorated with @Singleton is the same
    # as getting an instance of Singleton.
    class B(A):
        pass

    quux = B("quux")
    assert foo is quux
    assert quux.name == "foo"

# Generated at 2022-06-23 14:35:30.132272
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a_1 = A(1)
    a_2 = A(2)
    a_3 = A(3)
    assert a_1 is a_2
    assert a_1 is a_3

# Generated at 2022-06-23 14:35:35.330378
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, **metadata):
            self.__dict__.update(metadata)

    test_instance = TestSingleton(test_foo="test_bar", test_bar="test_foo")
    assert test_instance.test_foo == "test_bar"
    assert test_instance.test_bar == "test_foo"

# Generated at 2022-06-23 14:35:40.995196
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    # Create two instances of class Foo
    a = Foo("a")
    b = Foo("b")

    # Verify that the instances are equal
    assert(a == b)

    # Verify that the values are also equal
    assert(a.value == b.value)


# Generated at 2022-06-23 14:35:44.665984
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.__test = "Test"
    s1 = S()
    assert s1.__test == "Test"
    s2 = S()
    assert s1 == s2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:35:47.653308
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = TestSingleton()
    b = TestSingleton()

    assert a == b
    assert a is b



# Generated at 2022-06-23 14:35:51.198102
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

    x = SingletonTest()
    y = SingletonTest()

    assert x == y

# Generated at 2022-06-23 14:35:57.602944
# Unit test for constructor of class Singleton
def test_Singleton():
    class Spam(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('setting up spam')
            self.eggs = 42

        def do_work(self, arg):
            return arg + self.eggs

    assert not Spam.__instance
    assert Spam.__rlock
    s1 = Spam()
    assert Spam.__instance is s1
    s2 = Spam()
    assert s2 is s1
    assert s2.eggs == 42
    assert Spam.__instance.eggs == 42
    assert s2.do_work(1) == 43

# Generated at 2022-06-23 14:36:02.266964
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = Foo('a')
    b = Foo('b')
    assert a.arg == 'a'
    assert b.arg == 'a'

# Generated at 2022-06-23 14:36:10.313572
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, foo, bar=None):
            self.foo_ = foo
            self.bar_ = bar

    a1 = A('foo')
    a2 = A('foo')
    a3 = A('foo')
    assert a1 is a2
    assert a2 is a3

    b1 = A('bar', 'baz')
    b2 = A('bar', 'baz')
    assert b1 is b2
    assert b1 is not a1
    assert b1.foo_ == 'bar'
    assert b1.bar_ == 'baz'

# Generated at 2022-06-23 14:36:16.332994
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test_value = ""

    test_object1 = TestSingleton()
    test_object2 = TestSingleton()
    assert test_object1 is test_object2
    test_object1.test_value = "12345"
    assert test_object2.test_value == "12345"

# Generated at 2022-06-23 14:36:21.184211
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    class B(A):
        def __init__(self, val):
            super(B, self).__init__(val)

    a = A(1)
    b = B(2)

    assert a is b
    assert a.val == b.val == 2

# Generated at 2022-06-23 14:36:29.282103
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, one, two):
            self.__one = one
            self.__two = two

        def get_one(self):
            return self.__one

        def get_two(self):
            return self.__two

    s = TestSingleton(1, 2)
    assert s.get_one() == 1
    assert s.get_two() == 2

    s = TestSingleton(3, 4)
    assert s.get_one() == 1
    assert s.get_two() == 2

# Generated at 2022-06-23 14:36:34.364792
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = 'hello'

    test1 = TestSingleton()
    test1.test = 'hello'

    test2 = TestSingleton()
    test2.test = 'world'

    assert test1.test == 'world'

# Generated at 2022-06-23 14:36:39.102702
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    assert(Test().value == 0)

    Test.__instance = None
    Test().value = 1

    assert(Test().value == 1)

# Generated at 2022-06-23 14:36:41.963844
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 is a2



# Generated at 2022-06-23 14:36:44.595876
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SimpleSingleton(object):
        __metaclass__ = Singleton

    assert SimpleSingleton() is SimpleSingleton() is SimpleSingleton.__instance


# Generated at 2022-06-23 14:36:47.806060
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    a1 = A()
    a2 = A()
    assert a1 is a2
    return True

# Generated at 2022-06-23 14:36:52.208401
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'MySingletonClass'

    # Test if singleton classes are really singletons
    obj1 = MySingletonClass()
    obj2 = MySingletonClass()
    assert obj1 is obj2


# Generated at 2022-06-23 14:36:58.527619
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class ConcreateSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    singleton1 = ConcreateSingleton()
    singleton2 = ConcreateSingleton()

    assert singleton1 == singleton2
    assert singleton1.a == singleton2.a
    singleton2.a = 2
    assert singleton1.a == 2
    assert singleton2.a == 2

# Generated at 2022-06-23 14:37:02.042171
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.config.base import BaseConfig

    class Configuration(BaseConfig):
        __metaclass__ = Singleton

    x1 = Configuration()
    assert x1 is not None

    x2 = Configuration()
    assert x1 is x2

# Generated at 2022-06-23 14:37:07.154060
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.counter = 0

        def increment(self):
            self.counter += 1

    instance1 = TestClass()
    instance1.increment()

    instance2 = TestClass()
    instance2.increment()

    assert instance1.counter == 2
    assert instance2.counter == 2
    assert instance1 is instance2

# Generated at 2022-06-23 14:37:16.685352
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class NonSingletonClass(object):
        def __init__(self,id):
            self.id=id
        def __str__(self):
            return "NonSingletonClass:id=%s"%(self.id)

    class SingletonClass(object):
        __metaclass__ = Singleton
        def __init__(self,id):
            self.id=id
        def __str__(self):
            return "SingletonClass:id=%s"%(self.id)

    a=NonSingletonClass(1)
    b=NonSingletonClass(1)
    c=NonSingletonClass(2)
    d=SingletonClass(3)
    e=SingletonClass(3)
    f=SingletonClass(4)
    assert a==b
    assert c==d

# Generated at 2022-06-23 14:37:22.976299
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    instance1 = TestClass(1)
    instance2 = TestClass(2)
    assert instance1 == instance2
    assert instance1.arg == instance2.arg
    assert instance1 is instance2

    # Ensure that __new__ is called only once, even if __init__
    # is called multiple times.
    class TestClass2(object):
        __metaclass__ = Singleton
        _new_was_called = False

        def __new__(cls, *args, **kwargs):
            if not cls._new_was_called:
                cls._new_was_called = True
                return super(TestClass2, cls).__new__(cls)

# Generated at 2022-06-23 14:37:28.727480
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("__init__ is called")
            self.a = 0

    test1 = TestClass()
    test2 = TestClass()
    test2.a = 1
    assert test1.a == test2.a == 1

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:37:33.550597
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    my_obj1 = MyClass()
    my_obj2 = MyClass()

    assert my_obj1 is my_obj2


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:37:39.595703
# Unit test for constructor of class Singleton
def test_Singleton():
    class test(object, metaclass=Singleton):
        def __init__(self, x=1, y=2, z=3):
            self.x, self.y, self.z = x, y, z
        def __str__(self):
            return "test(x=%d, y=%d, z=%d)" % (self.x, self.y, self.z)

    assert(str(test()) == "test(x=1, y=2, z=3)")
    assert(test() == test())
    assert(test(x=4, y=5, z=6) == test())
    assert(str(test(x=7, y=8, z=9)) == "test(x=7, y=8, z=9)")

# Generated at 2022-06-23 14:37:41.879721
# Unit test for constructor of class Singleton
def test_Singleton():
    class ttt:
        __metaclass__ = Singleton


    test = ttt()
    assert test == ttt()

# Generated at 2022-06-23 14:37:45.726601
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    c1 = MyClass()
    c2 = MyClass()

    assert (c1 == c2)
    assert (c1 is c2)


if __name__ == '__main__':
    test_Singleton()