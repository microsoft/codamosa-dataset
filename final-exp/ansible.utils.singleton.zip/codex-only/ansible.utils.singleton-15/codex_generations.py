

# Generated at 2022-06-23 14:27:48.055296
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name
    test1 = Test("hello")
    test2 = Test("goodnight")
    assert test1.name == "hello"
    assert test2.name == "hello"
    assert test1 is test2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:27:49.116653
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton('test', (), {}) == Singleton('test', (), {})

# Generated at 2022-06-23 14:27:54.706290
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, number):
            self.number = number

    t1 = Test(1)
    t2 = Test(2)

    assert t1.number == 1
    assert t2.number == 1
    assert t1 is t2



# Generated at 2022-06-23 14:28:02.068263
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass:
        """Test case for Singleton metaclass"""
        def __init__(self, param):
            self.init = param

        def __repr__(self):
            return '<MyClass instance at 0x%x>' % id(self)

    class MySubClass(MyClass):
        """Test case for Singleton metaclass"""
        pass

    # Test case 1
    obj_a = MyClass(1)
    obj_b = MyClass(2)

    assert obj_a != obj_b

    # Test case 2
    obj_a = MyClass(3)
    obj_b = MyClass(3)

    assert obj_a != obj_b

    # Test case 1
    obj_a = MySubClass(5)
    obj_b = MySubClass(5)


# Generated at 2022-06-23 14:28:12.467867
# Unit test for constructor of class Singleton
def test_Singleton():
    # singleton pattern is not working
    class DerivedKlass(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x
            print(type(self))

    i1 = DerivedKlass(1)
    i2 = DerivedKlass(2)
    assert(i1 is not i2) 

    # singleton pattern is working
    class DerivedKlass(object):
        __metaclass__ = Singleton
        y = 1

        def __init__(self):
            self.x = self.y
            print(type(self))

    i1 = DerivedKlass()
    i1.y = 2
    i2 = DerivedKlass()
    assert(i1 is i2)


# Generated at 2022-06-23 14:28:16.915586
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = 'test singleton'

    my_test_singleton = TestSingleton()
    assert my_test_singleton.name == 'test singleton'



# Generated at 2022-06-23 14:28:19.668375
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        pass

    a = Test()
    assert id(a) == id(Test())



# Generated at 2022-06-23 14:28:25.101592
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    a = A("Ansible")
    a1 = A("Ansible")
    assert a.name == "Ansible"
    assert a1.name == "Ansible"
    assert a == a1

# Generated at 2022-06-23 14:28:28.063144
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    A(10)
    A(100)

# Generated at 2022-06-23 14:28:32.836683
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleClass(object):
        __metaclass__ = Singleton

        def __init__(self, foo=None):
            self.foo = foo

    for i in range(100):
        a = MySingleClass()
        b = MySingleClass()
        assert a is b

    a = MySingleClass(foo=10)
    b = MySingleClass()
    assert a is b
    assert a.foo == b.foo

# Generated at 2022-06-23 14:28:37.973908
# Unit test for method __call__ of class Singleton

# Generated at 2022-06-23 14:28:42.898139
# Unit test for constructor of class Singleton
def test_Singleton():
    class foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    print(id(foo()))
    print(id(foo()))
    print(id(foo()))
    print(id(foo()))
    print(id(foo()))



# Generated at 2022-06-23 14:28:49.324952
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        pass

    obj1 = MyClass()
    assert isinstance(obj1, MyClass), "obj1 is not a MyClass object"

    obj2 = MyClass()
    assert isinstance(obj2, MyClass), "obj2 is not a MyClass object"

    assert obj1 is obj2, "obj1 is not the same object as obj2"


# Generated at 2022-06-23 14:28:58.000710
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create a metaclass dynamically
    Singleton.__instance = None
    Singleton.__rlock    = None
    Singleton.__name     = "Singleton"
    Singleton.__bases    = ()
    Singleton.__dct      = {}
    Singleton.__mro__    = ()
    Singleton.__class__  = None
    Singleton.__doc__    = "Metaclass for classes that wish to implement Singleton functionality.  If an instance of the class exists, it's returned, otherwise a single instance is instantiated and returned."
    Singleton.__module__ = "__main__"

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:29:07.021274
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test __call__ of class Singleton with class that uses Singleton
    class TestClass(object):
        __metaclass__ = Singleton
        pass

    print(str(TestClass))

    # Test __call__ of class Singleton with class that uses Singleton
    # and one that doesn't
    class TestClass2(object):
        __metaclass__ = Singleton
        pass

    class TestClass3(object):
        pass

    print(str(TestClass2))
    print(str(TestClass3))

    # Create instances of TestClass and TestClass2 and compare them to
    # see if they are the same
    t1 = TestClass()
    t2 = TestClass()
    t3 = TestClass2()
    t4 = TestClass2()

    print(str(t1))

# Generated at 2022-06-23 14:29:12.792893
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, arg):
            self.arg = arg
        def __str__(self):
            return self.arg

    arg = 'some_string'
    a1 = A(arg)
    a2 = A(arg)
    assert a1.arg == a2.arg



# Generated at 2022-06-23 14:29:13.197809
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-23 14:29:20.019709
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(metaclass=Singleton):
        # Variables (should) keep between calls
        value = 0

        def __init__(self):
            # Automatic increment
            self.value += 1

    # By call, we instantiate the class and return the instance
    assert isinstance(MySingleton(), MySingleton)
    assert MySingleton().value == 1

    # This test fails if the class is not a singleton and call a
    # method, each call should increment the value
    assert MySingleton().value == 1



# Generated at 2022-06-23 14:29:28.714751
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, arg1):
            self.arg1 = arg1

    assert TestSingleton.__instance == None

    s1 = TestSingleton('foo')
    assert TestSingleton.__instance == s1
    assert s1.arg1 == 'foo'

    s2 = TestSingleton('bar')
    assert TestSingleton.__instance == s1
    assert s2.arg1 == 'foo'


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:29:32.890332
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        # This class is a Singleton.
        __metaclass__ = Singleton

    # Create two instances
    obj1 = MyClass()
    obj2 = MyClass()

    # They are the same instance
    assert obj1 is obj2

# Generated at 2022-06-23 14:29:34.414772
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    obj1 = SingletonTest()
    obj2 = SingletonTest()

    assert obj1 is obj2


# Generated at 2022-06-23 14:29:39.778874
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        def __init__(self,x):
            self.x=x

    class B(A):
        __metaclass__=Singleton

    class C(B):
        pass

    a=B(1)
    b=B(2)
    c=C(3)

    assert a is b
    assert a is not c
    assert a.x is 1
    assert b.x is 1
    assert c.x is 3


# Generated at 2022-06-23 14:29:45.979538
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class DummyClass(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    obj1 = DummyClass(name="obj1")
    obj2 = DummyClass(name="obj2")
    assert obj1 is obj2, "__call__ method of Singleton class failed"


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:29:51.939886
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C( with_metaclass(Singleton) ):
        pass

    x = C()
    y = C()
    assert x is y

    # Not affected by reset __instance
    C.__instance = None
    z = C()
    assert x is z

    # Not affected by reset __instance to another object
    C.__instance = object()
    w = C()
    assert x is w

# Generated at 2022-06-23 14:29:55.525812
# Unit test for constructor of class Singleton
def test_Singleton():
    # Because Singleton() is a meta class, so it's
    # constructor can not be accessed by __init__
    # method, and the only way is to call Singleton
    # class directly
    assert Singleton('example', (object,), {})
    assert Singleton is Singleton('example', (object,), {})

# Generated at 2022-06-23 14:29:57.965301
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2
    assert foo1
    assert isinstance(foo1, Foo)



# Generated at 2022-06-23 14:30:05.116066
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import collections

    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = {}

    a = A()
    b = A()

    assert(a is b)
    assert(isinstance(a, A))
    assert(isinstance(a.a, collections.MutableMapping))
    assert(a is b)
    assert(isinstance(a, A))
    assert(isinstance(a.a, collections.MutableMapping))


# Generated at 2022-06-23 14:30:08.180647
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class ExampleSingleton(object):
        __metaclass__ = Singleton

    instance = ExampleSingleton()

    assert instance is ExampleSingleton()



# Generated at 2022-06-23 14:30:14.717365
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = 0
    a = A()
    a.a = 1
    b = A()
    assert a.a == 1
    assert b.a == 1
    c = A()
    c.a = 2
    assert a.a == 2
    assert b.a == 2
    assert c.a == 2
    assert a == b
    assert a == c
    assert b == c



# Generated at 2022-06-23 14:30:19.468550
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = A(42)
    b = A(43)
    assert a.x == 42
    assert b.x == 42


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:30:24.896800
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 10

    f = Foo()
    assert(isinstance(f, Foo))
    assert(f.x == 10)

    g = Foo()
    assert(f is g)
    assert(g.x == 10)

    g.x = 20
    assert(f.x == 20)



# Generated at 2022-06-23 14:30:28.416509
# Unit test for constructor of class Singleton
def test_Singleton():
    from nose.tools import assert_equal

    class TestSingleton(object):
        __metaclass__ = Singleton
        pass

    class_1 = TestSingleton()
    class_2 = TestSingleton()

    assert_equal(class_1, class_2)

# Generated at 2022-06-23 14:30:38.488295
# Unit test for constructor of class Singleton
def test_Singleton():

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class SingletonTest2(object):
        __metaclass__ = Singleton
        pass

    class SingletonTest3(object):
        def __init__(self):
            pass

        @classmethod
        def get_instance(cls):
            if not hasattr(cls, '_instance'):
                cls._instance = cls()
            return cls.instance

    instance1 = SingletonTest()
    instance2 = SingletonTest()
    assert id(instance1) == id(instance2)

    instance3 = SingletonTest2()
    instance4 = SingletonTest2()
    assert id(instance3) == id(instance4)

# Generated at 2022-06-23 14:30:43.166719
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'test'

    assert isinstance(Test(), Test) is True

    # Test for singleton
    assert Test() == Test()

# Test for singleton

# Generated at 2022-06-23 14:30:49.617366
# Unit test for constructor of class Singleton
def test_Singleton():
    #Singleton
    class SingletonTest:
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg
        
    s1 = SingletonTest('test')
    s2 = SingletonTest('test')

    assert(s1 == s2)
    assert(s1.arg == s2.arg)

# Generated at 2022-06-23 14:30:52.299817
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    ob1 = MySingleton()
    ob2 = MySingleton()

    assert ob1 == ob2
    #assert ob1 is ob2

# Generated at 2022-06-23 14:30:58.098321
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 0

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.x == 0
    assert a2.x == 0
    a1.x += 1
    assert a2.x == 1



# Generated at 2022-06-23 14:31:03.406502
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = "A"

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = "B"

    assert id(A()) == id(A())
    assert id(A()) != id(B())
    assert A().name == "A"
    assert B().name == "B"


# Generated at 2022-06-23 14:31:05.873928
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-23 14:31:08.021165
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        pass

    a = Foo()
    b = Foo()

    assert a is b



# Generated at 2022-06-23 14:31:13.169502
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = MySingleton(value='a')
    b = MySingleton(value='b')

    assert a is not None
    assert a is b
    assert a.value == 'b'
    assert b.value == 'b'


# Generated at 2022-06-23 14:31:23.124858
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    import sys

    class foo(object):
        __metaclass__ = Singleton

        def __init__(self, test_arg):
            self.test_arg = test_arg

    class foo_tests(unittest.TestCase):
        def test_case_1(self):
            self.assertEqual(foo("Hello").test_arg, "Hello", "test_Singleton___call__: test_case_1 failed")
            self.assertEqual(foo("World").test_arg, "Hello", "test_Singleton___call__: test_case_1 failed")

    runner = unittest.TextTestRunner(stream=sys.stdout)
    result = runner.run(unittest.makeSuite(foo_tests))
    if not result.wasSuccessful():
        sys.exit

# Generated at 2022-06-23 14:31:28.975884
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    first_inst = MyClass(1)
    second_inst = MyClass(2)
    third_inst = MyClass(3)

    assert first_inst == second_inst == third_inst
    assert first_inst.a == 1

# Generated at 2022-06-23 14:31:32.573156
# Unit test for constructor of class Singleton
def test_Singleton():
  class A(metaclass=Singleton):
    def __init__(self,x):
      self._x = x
    @property
    def x(self):
      return self._x
  a1 = A("one")
  a2 = A("two")
  print("a1:",a1.x)
  print("a2:",a2.x)


# Generated at 2022-06-23 14:31:38.010784
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 17

    a = A()
    assert(a.value == 17)

    b = A()
    assert(a is b)
    assert(b.value == 17)
    b.value += 1
    assert(b.value == 18)
    assert(a.value == 18)



# Generated at 2022-06-23 14:31:43.972998
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        from importlib import reload
    except ImportError as e:
        try:
            # python2
            from imp import reload
        except ImportError as e:
            raise RuntimeError('Unable to import reload()')

    # Define a singleton class
    class SingletonClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    class NotSingletonClass(object):
        def __init__(self):
            pass

    sc1 = SingletonClass()
    sc2 = SingletonClass()
    assert sc1 is sc2, 'Singleton class not singleton'

    reload(SingletonClass)
    reload(Singleton)
    sc3 = SingletonClass()
    assert sc1 is sc3, 'Singleton class not singleton'

    nsc1 = Not

# Generated at 2022-06-23 14:31:45.720095
# Unit test for constructor of class Singleton
def test_Singleton():
    s = Singleton('a', (), {})
    assert(isinstance(s, Singleton))



# Generated at 2022-06-23 14:31:49.987365
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    # Should never return false, Singleton should always return
    # the same object
    if Foo() is not Foo():
        print("Singleton failed")


# Class that implements the Singleton pattern

# Generated at 2022-06-23 14:31:58.701888
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread
    """Test method __call__ of class Singleton"""
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    # Instance of Test have only one object
    t1 = Test(1, 2)
    t2 = Test(3, 4)
    assert t1 == t2

    # Check __call__ works in multi-threading
    L = [None] * 10
    def get_instance(i):
        t = Test(i, i)
        L[i] = t

    threads = [Thread(target=get_instance, args=(i,)) for i in range(len(L))]
    [t.start() for t in threads]

# Generated at 2022-06-23 14:32:07.392751
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test if call on class is idempotent"""
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, a, b=1):
            self.a = a
            self.b = b

    f1 = Foo('bar')
    f2 = Foo('bar')
    f3 = Foo('bar', b=2)

    assert f1 is f2 is f3
    assert f1.a == 'bar'
    assert f1.b == 1
    assert f2.a == 'bar'
    assert f2.b == 1
    assert f3.a == 'bar'
    assert f3.b == 2

# Generated at 2022-06-23 14:32:11.740993
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Temp(object):
        __metaclass__ = Singleton
        pass

    t1 = Temp()
    t2 = Temp()
    assert id(t1) == id(t2)
    assert t1 == t2

# Generated at 2022-06-23 14:32:18.007025
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass

    class B(metaclass=Singleton):
        pass

    a_1 = A()
    a_2 = A()
    b_1 = B()
    b_2 = B()
    print(a_1, a_2)
    print(b_1, b_2)
    assert a_1 is a_2
    assert b_1 is b_2
    assert a_1 is not b_1


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:32:28.373666
# Unit test for constructor of class Singleton
def test_Singleton():
    import threading
    import time

    class State:
        __metaclass__ = Singleton
        def __init__(self):
            self.b = 0
            self.lock = threading.Lock()
            self.list = []

    def action(a, b):
        if a == 0:
            # change state
            state = State()
            with state.lock:
                state.b = b
                state.list.append(b)
                print(state.b, state.list)
        elif a == 1:
            # just read state
            state = State()
            with state.lock:
                print(state.b, state.list)
        else:
            raise Exception

    threads = []

# Generated at 2022-06-23 14:32:34.591969
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 10

    a = A()
    b = A()
    print(a.value)
    print(b.value)
    print(id(a))
    print(id(b))
    print(a == b)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:32:41.698625
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 'new'

        def get_x(self):
            return self.x

    l1 = TestSingleton()
    l2 = TestSingleton()
    assert l1 is l2
    assert l1.get_x() == 'new'
    l2.x = 'old'
    assert l1.get_x() == 'old'


# Generated at 2022-06-23 14:32:47.145585
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    bar1 = Bar()
    foo2 = Foo()
    bar2 = Bar()

    assert foo1 is not None
    assert foo2 is not None
    assert bar1 is not None
    assert bar2 is not None
    assert foo1 is foo2
    assert bar1 is bar2
    assert foo1 is not bar1

# Generated at 2022-06-23 14:32:51.453359
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, name=None):
            if hasattr(self, 'name'):
                raise RuntimeError('MyClass is Singleton, you can not instantiate it twice.')

            self.name = name


    a = MyClass('foo')
    assert a.name == 'foo'
    b = MyClass('bar')
    assert b.name == 'foo'
    assert a is b

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:32:56.169784
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from collections import namedtuple
    from random import shuffle

    class SingletonTest(object):
        __metaclass__ = Singleton

    expected = SingletonTest()
    shuffle_iter = [SingletonTest(), expected]
    shuffle(shuffle_iter)

    first, second = tuple(shuffle_iter)

    assert first is second


# Generated at 2022-06-23 14:32:59.258439
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    assert(Foo() == Foo())

# Generated at 2022-06-23 14:33:05.481353
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Tested(object):
        __metaclass__ = Singleton

    assert Tested is Tested()

    class Tested(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    x = Tested(1, 2)
    y = Tested(3, 4)

    assert x is y
    assert x.a == 1
    assert x.b == 2

# Generated at 2022-06-23 14:33:11.970290
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton
        def __init__(self, foo):
            self.foo = foo

    a = S(1)
    b = S(2)
    assert a == b
    assert a.foo == b.foo
    assert a.foo == 1
    assert b.foo == 1

    class S(object):
        __metaclass__ = Singleton

    c = S()
    d = S()
    assert c == d

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:33:16.893680
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, x=1):
            self.x = x

    x = MySingleton()
    y = MySingleton(2)
    print(x.x)
    print(y.x)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:33:26.442157
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    class B(object):
        __metaclass__ = Singleton

        def __init__(self, b):
            self.b = b

    a1 = A(1)
    a2 = A(2)
    b1 = B(1)
    b2 = B(2)

    assert a1 is a2
    assert a1.a == 1
    assert b1 is b2
    assert b1.b == 1
    assert a1 is not b1

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:33:34.162317
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, b=0):
            self.b = b
    class B(object):
        def __init__(self, b=0):
            self.b = b
    assert(A(2) is A(3))
    assert(A(2) is A())
    assert(B(2) is not B())
    assert(B(2) is not B(3))

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:33:39.244900
# Unit test for constructor of class Singleton
def test_Singleton():
    class Bar(metaclass=Singleton):
        pass

    class Foo(metaclass=Singleton):
        def __init__(self):
            self.bar = Bar()

    foo1 = Foo()
    assert foo1 is not None
    assert foo1.bar is not None
    foo2 = Foo()
    assert foo2 is not None
    assert foo2.bar is not None
    assert foo1 is foo2
    assert foo1.bar is foo2.bar

# Generated at 2022-06-23 14:33:42.740631
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo = Foo()
    bar = Foo()

    assert foo is bar, "instances of singleton class should be identical"

# Generated at 2022-06-23 14:33:50.332285
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SimpleClass:
        __metaclass__ = Singleton
        value = 0

        def __init__(self):
            SimpleClass.value += 1

    s1 = SimpleClass()
    s2 = SimpleClass()
    assert s1.value == 1
    assert s2.value == 1

    s3 = SimpleClass()
    s4 = SimpleClass()
    assert s3.value == 1
    assert s4.value == 1

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:33:58.888022
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase as UnitTestCase
    class TestClass(object):
        __metaclass__ = Singleton
    class TestCase(UnitTestCase):
        def test_method__call__(self):
            test_object = TestClass()
            self.assertEqual(id(test_object), id(TestClass()))
    import unittest
    suite = unittest.TestLoader().loadTestsFromTestCase(TestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:34:03.837417
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1

# Generated at 2022-06-23 14:34:06.927801
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object, metaclass=Singleton):
        pass

    a = A()
    b = A()

    assert a is b

# Generated at 2022-06-23 14:34:11.647977
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object, metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1

# Generated at 2022-06-23 14:34:18.129286
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'test'

    t1 = TestClass()
    t2 = TestClass()
    print(id(t1) == id(t2))
    assert id(t1) == id(t2)
    assert t1.name == t2.name

if __name__ == "__main__":
#     test_Singleton()
    test_Singleton()

# Generated at 2022-06-23 14:34:20.275256
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    f0 = Foo()
    f1 = Foo()

    assert f0 is f1


# Generated at 2022-06-23 14:34:27.034872
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x
    assert Test(x=1) == Test(x=2)
    assert Test(x=1).x == Test(x=2).x
    assert Test(x=1).x == 1
    assert Test(x=1) == Test(x=1)
    assert Test(x=1).x == Test(x=1).x

# Generated at 2022-06-23 14:34:35.508796
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            Test.instances.append(self)
            self.i = Test.i
            Test.i += 1

    Test.instances = []
    Test.i = 0

    t0 = Test()
    assert len(Test.instances) == 1
    assert Test.instances[0] == t0
    assert t0.i == 0

    t1 = Test()
    assert len(Test.instances) == 1
    assert Test.instances[0] == t1
    assert t1.i == 1

    t2 = Test()
    assert len(Test.instances) == 1
    assert Test.instances[0] == t2
    assert t2.i == 2

# Generated at 2022-06-23 14:34:39.308375
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    instance1 = MyClass()
    instance2 = MyClass()
    assert instance1 is instance2
    assert instance1.__rlock is instance2.__rlock

# Generated at 2022-06-23 14:34:44.548527
# Unit test for constructor of class Singleton
def test_Singleton():
    global singleton_instance
    singleton_instance = True

    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            global singleton_instance
            singleton_instance = False

    a = MySingleton()
    assert singleton_instance is True
    b = MySingleton()
    assert singleton_instance is True
    assert a is b

# Generated at 2022-06-23 14:34:46.080321
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    assert A() is A()



# Generated at 2022-06-23 14:34:51.901403
# Unit test for constructor of class Singleton
def test_Singleton():
    # Class C inherits Singleton Metaclass
    class C(object):
        __metaclass__ = Singleton
        def __init__(self, a, b=1):
            self.a = a
            self.b = b

    c1 = C(1, 2)
    c2 = C(3)
    assert c1 is c2
    assert c1.a == 1
    assert c1.b == 2
    assert c2.a == 1
    assert c2.b == 2
    c1.a = 4
    assert c2.a == 4


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:34:56.147567
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

        def __repr__(self):
            return 'X(%s)' % self.arg

    x = X('foobar')
    y = X('spam')

    assert x is y
    assert y.arg == 'foobar'
    assert x.arg == 'foobar'


# Generated at 2022-06-23 14:35:04.594982
# Unit test for constructor of class Singleton
def test_Singleton():
    class SamplClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

        def inc(self):
            self.a += 1

    cls1 = SamplClass()
    cls2 = SamplClass()
    assert (cls1 == cls2)
    assert (id(cls1) == id(cls2))
    cls1.inc()
    assert (cls1.a == 2)
    assert (cls2.a == 2)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:35:09.758107
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SS(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.i = 0

        def inc(self):
            self.i += 1

    s = SS()
    assert s.i == 0, 'i should be 0'
    s.inc()
    assert s.i == 1, 'i should be 1'
    s = SS()
    assert s.i == 1, 'i should still be 1'

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:35:16.573478
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    obj1 = MyClass([1, 2], 'Test')
    obj2 = MyClass(None, None)
    assert id(obj1) == id(obj2), "Metaclass Singleton is not working"



# Generated at 2022-06-23 14:35:18.682674
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test = TestSingleton()
    assert isinstance(test, TestSingleton)
    test2 = TestSingleton()
    assert test is test2

# Generated at 2022-06-23 14:35:22.101780
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    # first instance
    foo1 = Foo()

    # second instance
    foo2 = Foo()

    assert(foo1 is foo2)



# Generated at 2022-06-23 14:35:28.418033
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''
    Test scenarios:
    1. Class without Singleton metaclass:
        1.1 run class constructor with parameters
        1.2 run class constructor without parameters
    2. Class with Singleton metaclass:
        2.1 run class constructor with parameters
        2.2 run class constructor without parameters
    3. Class without Singleton metaclass, with custom __new__ method
        3.1 run class constructor with parameters
        3.2 run class constructor without parameters
    '''

    class TestClassWithoutSingleton(object):
        def __init__(self, param1, param2):
            self.param1 = param1
            self.param2 = param2
    
    class TestClassWithSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, param1, param2):
            self

# Generated at 2022-06-23 14:35:38.736398
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        # Use Singleton as metaclass to implement singleton
        __metaclass__ = Singleton

        def __init__(self, arg0):
            self.arg0 = arg0

    # Call TestClass(), it's a singleton object
    test_obj0 = TestClass(123)
    print('TestClass instance 0: arg0:{0}'.format(test_obj0.arg0))

    # Call TestClass() again, it's the same singleton object
    test_obj1 = TestClass(321)
    print('TestClass instance 1: arg0:{0}'.format(test_obj1.arg0))

    # TestClass.__instance is the singleton object
    print('TestClass.__instance: arg0:{0}'.format(TestClass.__instance.arg0))
    assert Test

# Generated at 2022-06-23 14:35:46.226951
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

        def __str__(self):
            return str(vars(self))

    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 2

        def __str__(self):
            return str(vars(self))

    a = A()
    b = A()
    assert id(a) == id(b), "Singleton failed to create single instance"
    assert a.a == 1, "Singleton failed to create single instance"  # verify that constructor actually got called
    c = B()
    d = B()
    assert id(c) == id(d), "Singleton failed to create single instance"
    assert c

# Generated at 2022-06-23 14:35:54.068525
# Unit test for constructor of class Singleton
def test_Singleton():
    assert isinstance(Singleton, type)
    assert issubclass(Singleton, type)

    # Test that no instances have been cached
    assert Singleton.__instance is None

    # Test that we can call __call__
    assert Singleton('foo', (), {}) is not None

    # Test that singletons are cached
    assert Singleton('foo', (), {}) is Singleton.__instance
    assert Singleton('bar', (), {}) is Singleton.__instance


# Generated at 2022-06-23 14:35:58.341181
# Unit test for constructor of class Singleton
def test_Singleton():
    class singleton_class(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = "value"

    x = singleton_class()
    y = singleton_class()

    assert (x == y)
    assert (x is y)

# Generated at 2022-06-23 14:36:09.288943
# Unit test for constructor of class Singleton
def test_Singleton():
    # Meta class Singleton should be instantiated
    meta_class = Singleton("Meta", (object,), {})
    assert isinstance(meta_class, Singleton)

    # class 'Test' inherits meta class Singleton
    class Test(object):
        __metaclass__ = Singleton

    # meta class should be assigned to class Test
    assert isinstance(type(Test), Singleton)
    # instantiate class Test by calling constructor
    test1 = Test("a", "b")
    # call class Test again
    test2 = Test("c", "d")
    # instance 'test2' is not created a second time
    assert id(test1) == id(test2)
    # test1 and test2 are actually the same instance
    assert test1 is test2


test_Singleton()

# Generated at 2022-06-23 14:36:13.129492
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = TestSingleton()
    b = TestSingleton()
    assert id(a) == id(b)

# Generated at 2022-06-23 14:36:16.916255
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            pass
    # Instantiate two objects of class A
    s = A()
    s2 = A()
    # verify they're the same object
    assert s is s2


# Generated at 2022-06-23 14:36:18.982978
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = 'biqiang'
    s1 = S()
    s2 = S()
    assert s1 == s2
    assert s1.name == s2.name

# Generated at 2022-06-23 14:36:21.813566
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)

# Generated at 2022-06-23 14:36:24.058281
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    def Singleton_Class(metaclass=Singleton):
        pass

    s1 = Singleton_Class()
    s2 = Singleton_Class()

    assert s1 == s2


# Generated at 2022-06-23 14:36:28.822306
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = MyClass()
    b = MyClass()
    assert a is b
    assert a.x == b.x
    b.x = 2
    assert a.x == 2

# Generated at 2022-06-23 14:36:33.179134
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self):
            pass

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:36:35.798124
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.b = 1
    a = A()
    assert a.b == 1
    assert A().b == 1

# Generated at 2022-06-23 14:36:39.679853
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test_Singleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    object1 = Test_Singleton()
    object2 = Test_Singleton()

    assert object1 is object2

# Generated at 2022-06-23 14:36:43.067936
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            pass

    assert TestClass('arg1') is TestClass('arg2')



# Generated at 2022-06-23 14:36:51.329536
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        # Method __init__ will be overridden when __instance is singleton
        def __init__(self, val=0):
            print("MySingleton created")
            # Prevent multiple thread from accessing self.val at the same time
            self.__lock = RLock()
            self.val = val

        # TypeError: __new__() takes 1 positional arguments but 2 were given
        # The right way to use the constructor is to use the metaclass
        #def __new__(cls, *args, **kw):
        #    if not hasattr(cls, '_instance'):
        #        cls._instance = super(MySingleton, cls).__new__(cls, *args, **kw)
        #    return cls._instance



# Generated at 2022-06-23 14:36:53.606867
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    class YourSingleton(object):
        __metaclass__ = Singleton

    assert MySingleton() is YourSingleton() is MySingleton()

# Generated at 2022-06-23 14:36:56.676094
# Unit test for constructor of class Singleton
def test_Singleton():
    class singleton(object):
        __metaclass__ = Singleton
    p, q = singleton(), singleton()
    assert p == q
    assert p is q

# Generated at 2022-06-23 14:36:59.785287
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    instanceA = TestSingleton()
    instanceB = TestSingleton()

    assert(instanceA != instanceB)

# Generated at 2022-06-23 14:37:01.749357
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()

# Generated at 2022-06-23 14:37:05.836660
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    a = A()
    b = B()
    assert a is A()
    assert b is B()
    assert a is not b


# Generated at 2022-06-23 14:37:09.486496
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Klass(object, metaclass=Singleton):
        pass
    k1 = Klass()
    k2 = Klass()
    assert(k1 is k2)

# Generated at 2022-06-23 14:37:13.226197
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton

    obj1 = SingletonClass()
    obj2 = SingletonClass()

    assert obj1 == obj2

# For testing purposes
if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:37:16.942593
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a1 = A('a1')
    assert a1.name == 'a1'

    a2 = A('a2')
    assert a1.name == 'a1'
    assert a2.name == 'a1'
    assert a1 is a2


# Generated at 2022-06-23 14:37:21.712191
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class ASingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value=None):
            self._value = value

        @property
        def Value(self):
            return self._value

        @Value.setter
        def Value(self, value):
            self._value = value

    a = ASingleton('123')
    b = ASingleton()
    assert a is b
    assert a.Value == b.Value == '123'
    b.Value = '456'
    assert a.Value == b.Value == '456'

# Generated at 2022-06-23 14:37:31.501298
# Unit test for constructor of class Singleton
def test_Singleton():
    # Normal class
    class A:
        pass

    # Derive class B from Singleton
    class B(object):
        __metaclass__ = Singleton

    # Instantiate the class A
    a = A()
    # Instantiate the class B, and it will return the same object
    # if we instantiate it more than once.
    b = B()
    b1 = B()
    assert(a != b)
    assert(b == b1)

    # The __call__(cls, *args, **kw) method will be triggered if the
    # instance of the class B is called as a function.
    def func_B(*args, **kwargs):
        print(*args, **kwargs)

    b = B()
    b()
    b(func_B)

# Generated at 2022-06-23 14:37:37.351717
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = "bar"

    # This line will fail if __init__() is called more than once
    test_singleton = TestSingleton()
    print(test_singleton.foo)
    assert(test_singleton.foo)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:37:43.987230
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self._x = 1

        def get(self):
            return self._x

        def add(self):
            self._x += 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.get() == 1
    t1.add()
    t1.add()
    assert t1.get() == 3
    assert t2.get() == 3