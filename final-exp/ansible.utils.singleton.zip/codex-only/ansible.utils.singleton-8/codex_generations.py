

# Generated at 2022-06-23 14:27:48.349898
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):

        def __init__(self, a=None, b=None, c=None):
            self.a = a
            self.b = b
            self.c = c

    assert Foo() is Foo()

    assert Foo('x') is Foo('x')

    assert Foo(1, 2, 3) is Foo(1, 2, 3)

    assert Foo() is not Foo('x')

    assert Foo() is not Foo(1, 2, 3)

    assert Foo(1, 2, 3) is not Foo(3, 2, 1)

    assert Foo('x') is not Foo(1, 2, 3)

# Generated at 2022-06-23 14:27:50.226398
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()

    assert t1 is t2
    assert Test() is t1

# Generated at 2022-06-23 14:27:57.052791
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase

    class A(object):
        __metaclass__ = Singleton

        def __init__(self, n):
            self.n = n

    a1 = A(1)
    a2 = A(2)

    TestCase().assertEqual(a1.n, 1)
    TestCase().assertEqual(a2.n, 1)
    TestCase().assertEqual(a1, a2)

# Generated at 2022-06-23 14:27:59.215459
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    instance1 = TestSingleton()
    instance2 = TestSingleton()
    assert(instance1 is instance2)

# Generated at 2022-06-23 14:28:09.640922
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    foo1 = Foo(1, 2, 3, x=1, y=2, z=3)
    foo2 = Foo(4, 5, 6, x=4, y=5, z=6)

    assert foo1 is foo2
    assert foo1.args == (1, 2, 3)
    assert foo2.args == (1, 2, 3)
    assert foo1.kwargs == {'x': 1, 'y': 2, 'z': 3}
    assert foo2.kwargs == {'x': 1, 'y': 2, 'z': 3}



# Generated at 2022-06-23 14:28:15.321905
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.message = "Hello World"

    a1 = A()
    assert(A() is a1)
    assert(A().message == "Hello World")
    assert(a1.message == "Hello World")


# Generated at 2022-06-23 14:28:21.221500
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test_val = 0

    t1 = TestClass()
    t2 = TestClass()

    assert id(t1) == id(t2)
    assert t1.test_val == 0
    assert t2.test_val == 0

    t1.test_val = 2
    assert t2.test_val == 2

    t2.test_val = 3
    assert t1.test_val == 3

# Generated at 2022-06-23 14:28:26.693957
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

    class B:
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    b1 = B()

    assert a1 is a2
    assert a1 is not b1

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:28:31.292813
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 10
            self.bar = 'bar value'

    a1 = A()
    assert a1.foo == 10
    assert a1.bar == 'bar value'

    a2 = A()
    assert a2.foo == 10
    assert a2.bar == 'bar value'

    assert a1 is a2


# Generated at 2022-06-23 14:28:37.028297
# Unit test for constructor of class Singleton
def test_Singleton():
    import unittest
    import types
    import random

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b=None, c=None):
            self.a = a
            self.b = b
            self.c = c

    # Test singleton works with no arguments to the constructor
    class TestSingletonNoArgs(object):
        __metaclass__ = Singleton

    class TestSingletonTestCase(unittest.TestCase):
        def setUp(self):
            self.first = TestSingleton(random.randint(0, 100))
            self.second = TestSingleton(random.randint(0, 100))
            self.result = TestSingletonNoArgs()


# Generated at 2022-06-23 14:28:39.422332
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    a = A()
    a1 = A()
    assert a is a1


# Generated at 2022-06-23 14:28:42.268460
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()

    assert t1 is t2

# Generated at 2022-06-23 14:28:45.704297
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass:
        __metaclass__ = Singleton

        def __init__(self):
            self.test_value = 0

    inst1 = TestClass()
    inst1.test_value = 1
    inst2 = TestClass()
    assert inst2.test_value == 1



# Generated at 2022-06-23 14:28:52.898090
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        pass

    # A() will create an instance of class A if it does not exist.
    a1 = A()
    # A() will return the existed instance of class A
    a2 = A()

    # a1 and a2 should be the same instance
    assert a1 is a2

    # a1 and a2 should be of class A
    assert isinstance(a1, A)
    assert isinstance(a2, A)

# Generated at 2022-06-23 14:29:03.264864
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton:
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 0

        def add(self, x):
            self.a += x

    class TestSingleton2:
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 0

        def add(self, x):
            self.a += x

    test_1 = TestSingleton()
    test_1.add(1)
    assert test_1.a == 1

    test_2 = TestSingleton()
    test_2.add(1)
    assert test_2.a == 2
    assert test_1 is test_2

    test_3 = TestSingleton2()
    test_3.add(1)
    assert test_3.a == 1

# Generated at 2022-06-23 14:29:05.112862
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        pass

    assert Test() is Test()
    assert id(Test()) == id(Test())
    assert str(Test()) == str(Test())


# Keeps a local cache of a plugin and a set of callables for a specific
# host. If a host changes, the contents of __cache are flushed.

# Generated at 2022-06-23 14:29:12.647783
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 3

        def __get__(self, instance, owner):
            print('instance:' + str(instance))
            print('owner:' + str(owner))

    s1 = SingletonTest()
    s2 = SingletonTest()
    print(id(s1), id(s2))
    assert id(s1) == id(s2)

# Generated at 2022-06-23 14:29:20.020762
# Unit test for constructor of class Singleton
def test_Singleton():
    from types import NoneType

    class ASingleton(object):
        __metaclass__ = Singleton

    _as1 = ASingleton()
    _as2 = ASingleton()
    assert id(_as1) == id(_as2)
    assert isinstance(_as1, NoneType)
    assert isinstance(_as2, NoneType)
    assert isinstance(_as1, ASingleton)
    assert isinstance(_as2, ASingleton)
    assert _as1 is _as2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:29:24.779047
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a1 = A(5)
    assert a1.value == 5
    a2 = A(2)
    assert a2.value == 5
    assert a1 is a2



# Generated at 2022-06-23 14:29:36.358530
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True
    # Test method __call__ of class Singleton with singleton with args
    class Test_Singleton_Args:
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

        def __str__(self):
            return str(self.arg)
    assert str(Test_Singleton_Args(3)) == str(Test_Singleton_Args(5))
    # Test method __call__ of class Singleton with singleton with kwargs
    class Test_Singleton_Kwargs:
        __metaclass__ = Singleton

        def __init__(self, kwarg1, kwarg2):
            self.kwarg1 = kwarg1
            self.kwarg2 = kwarg2

        def __str__(self):
            return str

# Generated at 2022-06-23 14:29:41.449974
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a=1):
            self.a = a

    from itertools import product
    for a, b, c in product([1, 2, 3], [1, 2, 3], [1, 2, 3]):
        assert A(a) is A(b) is A(c)
        assert A(a).a == A(b).a == A(c).a == a
        assert A().a == 1



# Generated at 2022-06-23 14:29:47.988908
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class_a = MyClass(1, 2, 3, a=100, b=200, c=300)
    class_b = MyClass()

    try:
        assert class_a is class_b
    except AssertionError:
        raise AssertionError("Error: the two instances of MyClass are not the same")


# Generated at 2022-06-23 14:29:53.630259
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, a1):
            self.a1 = a1

        def geta1(self):
            return self.a1

    test1 = SingletonTest(1)
    test2 = SingletonTest(2)

    assert test1.geta1() == 1
    assert test1 is test2

# Generated at 2022-06-23 14:29:57.393253
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1():
        __metaclass__ = Singleton

        def __init__(self, n):
            self.n = n

    a1 = Test1(1)
    a2 = Test1(5)
    assert a1 == a2
    assert a1.n == 5



# Generated at 2022-06-23 14:30:02.812778
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # create a class with metaclass Singleton
    class TestSingleton(object):
        __metaclass__ = Singleton

    # create two instances of TestSingleton
    a, b = TestSingleton(), TestSingleton()

    # compare object ids of a, b
    assert id(a) == id(b)

# Generated at 2022-06-23 14:30:08.316117
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 100

    ts1 = TestSingleton()
    ts2 = TestSingleton()
    assert ts1 is ts2
    assert ts1.x == ts2.x
    ts1.x = 200
    assert ts1.x == ts2.x

# Generated at 2022-06-23 14:30:16.857525
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # This class is designed for testing purpose, it will be removed once the
    # unittest for __call__ method is completed.
    class TestObj(object):
        def __init__(self, a):
            self.a = a
    class TestSingleton(TestObj):
        __metaclass__ = Singleton
    test_singleton_obj_1 = TestSingleton(1)
    test_singleton_obj_2 = TestSingleton(2)
    assert(test_singleton_obj_1 is test_singleton_obj_2)
    assert(test_singleton_obj_1.a == test_singleton_obj_2.a)



# Generated at 2022-06-23 14:30:20.204808
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    c = A()
    assert (a is b is c)



# Generated at 2022-06-23 14:30:25.208880
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_list = []

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            test_list.append('A')

    class B(A):
        def __init__(self):
            test_list.append('B')
            super(B, self).__init__()

    a = A()
    b = B()

    assert a is b
    assert test_list == ['B', 'A']



# Generated at 2022-06-23 14:30:30.251332
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    s = SingletonTest('test')
    assert s.val == 'test'
    s2 = SingletonTest('test2')
    assert s is s2
    assert s2.val == 'test'



# Generated at 2022-06-23 14:30:34.217011
# Unit test for constructor of class Singleton
def test_Singleton():
    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            pass

    a = Bar()
    b = Bar()
    assert a is b



# Generated at 2022-06-23 14:30:40.648337
# Unit test for constructor of class Singleton
def test_Singleton():
    from unittest import TestCase

    class MyClass(object):
        __metaclass__ = Singleton

    class MyClass2(MyClass):
        pass

    class MyClass3(MyClass2):
        pass

    try:
        class MyClass(object):
            __metaclass__ = Singleton

            def __init__(self):
                pass

        self.fail('__init__ should not be allowed in Singleton subclass.')
    except TypeError:
        pass

    try:
        class MyClass(object):
            __metaclass__ = Singleton

            def __new__(cls):
                return None

        self.fail('__new__ should not be allowed in Singleton subclass.')
    except TypeError:
        pass


# Generated at 2022-06-23 14:30:42.813523
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    a1 = A(10)
    a2 = A(20)
    assert a1.a == 10
    assert a1 is a2
    assert a1.a == a2.a



# Generated at 2022-06-23 14:30:49.185946
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    print('foo1: %s' % foo1)
    print('foo2: %s' % foo2)
    assert foo1 is foo2
    assert foo1 == foo2


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:30:56.959924
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Bar:
        pass
    b1 = Bar()
    b2 = Bar()
    assert b1 != b2

    class Foo(metaclass=Singleton):
        pass
    f1 = Foo()
    f2 = Foo()
    assert f1 is f2

    # make sure that different classes are different
    assert b1 is not f1

    # make sure that a subclass is not the same class
    class SubFoo(Foo):
        pass
    s1 = SubFoo()
    assert s1 is not f1
    assert s1 is not f2


# Generated at 2022-06-23 14:31:02.072522
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    tc1 = TestClass(1, 2)
    tc2 = TestClass(3, 4)
    assert tc1 == tc2
    assert tc1.a == 1
    assert tc1.b == 2



# Generated at 2022-06-23 14:31:03.848882
# Unit test for constructor of class Singleton
def test_Singleton():
    s = Singleton('Singleton', (), {})
    assert isinstance(s, Singleton)


# unit test for constructor of class MetaSingleton

# Generated at 2022-06-23 14:31:05.492683
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        pass

    assert Test() is Test()

# Generated at 2022-06-23 14:31:08.582440
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    c1 = C(1)
    c2 = C(2)
    assert(c1.arg == 1 and c1 is c2)

# Generated at 2022-06-23 14:31:13.925944
# Unit test for constructor of class Singleton
def test_Singleton():
    """
    This function tests the constructor of class Singleton
    """
    class TestSingleton(metaclass=Singleton):
        """
        This class implements Singleton
        """
        def __init__(self):
            """
            This is the constructor of class TestSingleton
            """

    # Test 1: Verify that the same object is returned
    # from multiple calls to TestSingleton()
    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:31:19.461031
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class ConcreteSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    c = ConcreteSingleton()
    assert(c.value == 1)
    assert(ConcreteSingleton().value == 1)


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:31:23.660011
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__= Singleton

        def __init__(self):
            pass

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-23 14:31:26.934568
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    instance1 = MySingleton()
    instance2 = MySingleton()

    assert(instance1 is instance2)



# Generated at 2022-06-23 14:31:32.833737
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

        def __str__(self):
            return self.name

    foo1 = Foo('foo1')
    foo2 = Foo('foo2')
    assert foo1 is foo2
    assert str(foo1) == 'foo1'
    assert str(foo2) == 'foo1'

test_Singleton()

# Generated at 2022-06-23 14:31:37.066767
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    s1 = S()
    s2 = S()
    assert(s1 == s2)
    assert(s1.x == 1)


# example usage

# Generated at 2022-06-23 14:31:48.737162
# Unit test for constructor of class Singleton
def test_Singleton():
    """Test the constructor of class Singleton."""

    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    import threading

    # Ordinary instantiation for the singleton class
    a1 = A(1)
    b1 = A(2)
    assert a1 is b1
    assert a1.x == 2

    # Singleton class can be instantiated with parallel threads
    def test(x):
        a = A(x)
        assert a.x == x

    threads = [threading.Thread(target=test, args=(i,)) for i in range(20)]
    [t.start() for t in threads]
    [t.join() for t in threads]

if __name__ == "__main__":
    test

# Generated at 2022-06-23 14:31:53.984807
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

    class B:
        __metaclass__ = Singleton

    a = A()
    b = B()

    a1 = A()
    b1 = B()

    assert a is a1
    assert a is not b
    assert b is b1
    assert b is not a



# Generated at 2022-06-23 14:32:00.074324
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a
    a = A('foo')
    b = A('bar')
    assert a is b
    assert a.a == 'bar'

# The above test is a little confusing since it's not in a test module.  The
# following test is in a test module.

from unit.compat.mock import MagicMock, patch
from ansible.modules.web_infrastructure.pagerduty import pd_integration
from ansible.module_utils.pagerduty import PagerDutyV2, PagerDutyV2Client



# Generated at 2022-06-23 14:32:12.767112
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.foo = 'foo'

    # Instantiate class A
    a = A()
    print(a)
    print(a.foo)

    # Call class A
    b = A()
    print(b)
    print(b.foo)

    print('a is b', a is b)

    # Instantiate class A
    c = A()
    print(c)
    print(c.foo)

    print('a is c', a is c)


# Generated at 2022-06-23 14:32:19.640409
# Unit test for constructor of class Singleton
def test_Singleton():

    class TestClass(object):
        __metaclass__ = Singleton


    class TestClass2(object):
        __metaclass__ = Singleton

        def __init__(self, s):
            self.s = s

    # even though the same class, the constructor argument is passed to the subclass
    # different singleton instances are created
    a = TestClass2("foo")
    b = TestClass2("bar")
    assert a.s == "foo"
    assert b.s == "bar"

    # the class is a singleton, so even though the arguments are different, the same
    # singleton instance is returned
    c = TestClass("foo")
    d = TestClass("bar")
    assert c == d
    assert c is d

# Generated at 2022-06-23 14:32:23.068303
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()

    assert f1 is f2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:32:25.767550
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass():
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert SingletonClass() is SingletonClass()

# Generated at 2022-06-23 14:32:29.206736
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self, value=None):
            self.value = value

    assert SingletonClass() is SingletonClass()



# Generated at 2022-06-23 14:32:40.297851
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from lib.ansible_galaxy import __version__
    from lib.ansible_galaxy import Galaxy
    import mock

    gal = Galaxy()
    gal.__class__.__version__ = __version__

    class Test(metaclass=Singleton):
        def __init__(self, a, b):
            self._a = a
            self._b = b

    class Test2(metaclass=Singleton):
        def __init__(self, a, b):
            self._a = a
            self._b = b

    # Make sure we can init an instance
    t = Test(1, 2)
    assert t._a == 1
    assert t._b == 2

    # Test that reuse returns the same instance (no duplicate init)
    t2 = Test(3, 4)
    assert t is t2


# Generated at 2022-06-23 14:32:43.717552
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global instance

    class TestClass(object):
        __metaclass__ = Singleton

    instance = TestClass()

    instance.foo = 'bar'

    instance2 = TestClass()
    assert instance2.foo == 'bar'

# Generated at 2022-06-23 14:32:47.223138
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

    def thread_func(ret):
        ret.append(C())

    ret = []
    ret.append(C())
    t = threading.Thread(target=thread_func, args=(ret,))
    t.start()
    t.join()
    for i in range(2):
        assert ret[i] is ret[0]

# Generated at 2022-06-23 14:32:50.106085
# Unit test for constructor of class Singleton
def test_Singleton():
    class A:
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert A() is A()
    b = A()
    assert b.__class__.__name__ == 'A'
    assert b.__class__.__bases__ == (object,)

# Generated at 2022-06-23 14:32:53.951955
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class T(object):
        __metaclass__ = Singleton

    t1 = T()
    t2 = T()
    assert t2 is t1



# Generated at 2022-06-23 14:33:00.452210
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        def __init__(self, x=0):
            # Explicitly call constructor of the base class
            super(MyClass, self).__init__()
            self.x = x

        def inc_x(self):
            self.x += 1

    m1 = MyClass()
    assert m1.x == 0

    m2 = MyClass()
    m2.inc_x()
    assert m1.x == 1
    assert m2.x == 1

    m3 = MyClass(10)
    assert m1.x == 1
    assert m2.x == 1
    assert m3.x == 1

# Generated at 2022-06-23 14:33:07.518329
# Unit test for constructor of class Singleton
def test_Singleton():
    # The class using the metaclass
    class MySingleton(metaclass=Singleton):
        pass

    # Outside the class, the MySingleton is still a class
    assert type(MySingleton) == type

    # Instantiate the class
    x = MySingleton()

    # Outside the class, x is an instance of MySingleton
    assert type(x) == MySingleton

    # Instantiate another MySingleton
    y = MySingleton()

    # Check if x and y are the same objects
    assert id(x) == id(y)



# Generated at 2022-06-23 14:33:11.008974
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a=0):
            self.a = a

    a1 = A()
    a2 = A()

    assert(a1 is a2)



# Generated at 2022-06-23 14:33:14.062546
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        """Test class for testing Singleton"""
        pass

    assert A() is A()
    b = A()
    del b
    assert A() is A()



# Generated at 2022-06-23 14:33:16.181549
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()



# Generated at 2022-06-23 14:33:18.309148
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        pass

    a1 = A()
    a2 = A()

    assert a1 == a2



# Generated at 2022-06-23 14:33:23.099606
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.init_done = True

    inst = TestSingleton()
    assert inst.init_done

    inst2 = TestSingleton()
    assert inst is inst2
    assert inst2.init_done

# Generated at 2022-06-23 14:33:28.830972
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class T(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            super(T, self).__init__()
            self.arg = arg

    assert T(1) == T(1)
    assert T(1) != T(2)
    assert T(1) != T()
    assert T() != T(1)

# Generated at 2022-06-23 14:33:31.132904
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()


# Generated at 2022-06-23 14:33:39.256024
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(metaclass=Singleton):
        def __init__(self):
            # Here we simulate a heavy and time-consuming
            # construction that should be used only once.
            time.sleep(3)
            self.ready = True
            self.x = 42

    start_time = time.time()
    with ThreadPoolExecutor(max_workers=2) as pool:
        s1 = pool.submit(MySingleton)
        s2 = pool.submit(MySingleton)
        s1 = s1.result()
        s2 = s2.result()
    end_time = time.time()

    print("s1:", s1)
    print("s2:", s2)
    print("s1 == s2:", s1 == s2)

# Generated at 2022-06-23 14:33:44.488405
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = "TestSingletonClass"

    assert TestSingletonClass() is TestSingletonClass(), "Fails to implement the singleton pattern!"
    del TestSingletonClass



# Generated at 2022-06-23 14:33:46.432888
# Unit test for constructor of class Singleton
def test_Singleton():
    class single(object):
        __metaclass__ = Singleton

    assert single() is single()

# Generated at 2022-06-23 14:33:57.862180
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Singleton does not have __call__ method, we will define a dummy
    # __call__ method for the unit test
    def __call__(self, *args, **kw):
        pass


# Generated at 2022-06-23 14:34:03.159819
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    a1 = A()
    a2 = A()
    assert a1 == a2, "expected a1 and a2 to be the same"

if __name__ == "__main__":
    test_Singleton()
    print("OK")

# Generated at 2022-06-23 14:34:05.364325
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    s1 = SingletonTest()
    assert s1 is SingletonTest()

# Generated at 2022-06-23 14:34:11.264727
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton1(object):
        __metaclass__ = Singleton

        def __init__(self, **kwargs):
            self.kwargs = kwargs

    a = TestSingleton1(x=1, y=2)
    b = TestSingleton1(x=2, y=1)
    assert a == b

# Generated at 2022-06-23 14:34:15.423871
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    t1 = Test('test_Singleton___call__')
    t2 = Test('test_Singleton___call__')

    assert t1 == t2



# Generated at 2022-06-23 14:34:17.988354
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            pass

    a1 = A()
    a2 = A()
    assert a1 == a2

# Generated at 2022-06-23 14:34:20.200356
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S1(object):
        __metaclass__ = Singleton
        value = 0
    a = S1()
    assert a.__class__ == S1
    a.value = 42
    b = S1()
    assert a is b
    assert a.value == b.value == 42

# Generated at 2022-06-23 14:34:22.463059
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        pass

    obj1 = A()
    obj2 = A()
    assert obj1 is obj2


# Generated at 2022-06-23 14:34:29.350868
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 'foo'

    assert Foo.__instance is None

    foo = Foo()

    assert foo is not None

    assert foo.value == 'foo'

    foo2 = Foo()

    assert foo is foo2

    assert foo2.value == 'foo'

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-23 14:34:32.698987
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SimpleObject(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    obj1 = SimpleObject()
    obj2 = SimpleObject()

    assert obj1 is obj2, "Instance of Singleton class is not a Singleton!"


# Generated at 2022-06-23 14:34:36.065503
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 == foo2



# Generated at 2022-06-23 14:34:38.444377
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert a is b



# Generated at 2022-06-23 14:34:40.869903
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()

    for i in range(10):
        assert a is A()

# Generated at 2022-06-23 14:34:49.250225
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass:
        def hello(self):
            print("Hello, World!")

    c1 = TestClass()
    c2 = TestClass()
    assert(c1 is not c2)

    s1 = Singleton(TestClass.__name__, (TestClass,), {"hello": TestClass.hello})
    s2 = Singleton(TestClass.__name__, (TestClass,), {"hello": TestClass.hello})
    c3 = s1()
    c4 = s2()
    c5 = s1()
    assert(c3 is c4)
    assert(c4 is c5)
    assert(c3.hello() is not None)
    assert(c4.hello() is not None)
    assert(c5.hello() is not None)

# Generated at 2022-06-23 14:34:53.582709
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = []

        def add(self, item):
            self.a.append(item)

    x = A()
    y = A()
    assert x == y
    x.add(1)
    assert x.a == [1]
    assert y.a == [1]



# Generated at 2022-06-23 14:34:56.579968
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    a1 = A('a')
    a2 = A('b')
    assert a1.name == 'b'
    assert a1.name == a2.name

# Generated at 2022-06-23 14:35:00.314346
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    # return same instance
    a = MyClass()
    b = MyClass()
    assert a is b


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-23 14:35:03.388676
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class SingletonObj(object):
        __metaclass__ = Singleton

    a = SingletonObj()
    b = SingletonObj()
    assert a is b

# Generated at 2022-06-23 14:35:06.188182
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Foo(metaclass=Singleton):
        def __init__(self):
            super(Foo, self).__init__()

    foo1 = Foo()
    foo2 = Foo()
    assert(foo1 is foo2)

# Generated at 2022-06-23 14:35:08.873421
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 == test2
    assert test1 is test2

# Generated at 2022-06-23 14:35:15.627398
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    f0 = Foo(0)
    assert f0 is not None
    f1 = Foo(1)
    assert f0 is f1
    assert f1.a == 0



# vim: set et sta sts=4 sw=4 ts=4 ft=python :

# Generated at 2022-06-23 14:35:26.250003
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import ansible.plugins.loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    Host = Singleton("Host", (Host,), {})
    Group = Singleton("Group", (Group,), {})
    loader = Singleton("PluginLoader", (ansible.plugins.loader.PluginLoader,), {})
    hosts = Host("127.0.0.1", "127.0.0.1")
    hosts2 = Host("127.0.0.1", "127.0.0.1")
    groups = Group("all", "all")
    groups2 = Group("all", "all")
    loader2 = loader("action")
    loader3 = loader("action")
    assert hosts == hosts2, "Hosts in test_Singleton___call__ is same"

# Generated at 2022-06-23 14:35:30.374457
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    instance = Foo()
    assert instance

    instance2 = Foo()
    assert id(instance) == id(instance2)



# Generated at 2022-06-23 14:35:36.325909
# Unit test for constructor of class Singleton
def test_Singleton():
    # Initialize the test class with the Singleton meta-class
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    # Instantiate the test class
    a = MyClass(1)
    b = MyClass(2)
    assert a is b, "Values not equal"

    # Check the value
    assert b.val == 1, "Value is not 1"

# Generated at 2022-06-23 14:35:40.094457
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, foo=None):
            self.foo = foo

    test_object = TestClass('bar')
    assert test_object.foo == 'bar'
    assert test_object is TestClass()

# Generated at 2022-06-23 14:35:43.430845
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    assert A() == A()



# Generated at 2022-06-23 14:35:46.191430
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # pylint: disable=too-few-public-methods
    class SingletonTest(object):
        __metaclass__ = Singleton

    a = SingletonTest()
    b = SingletonTest()

    assert a is b

# Generated at 2022-06-23 14:35:52.158121
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test:
        __metaclass__ = Singleton

    try:
        import __builtin__
        __builtin__.__dict__['assertEqual'] = assertEqual
        __builtin__.__dict__['assertNotEqual'] = assertNotEqual
        __builtin__.__dict__['assertNotIsInstance'] = assertNotIsInstance
        __builtin__.__dict__['assertIsInstance'] = assertIsInstance
        __builtin__.__dict__['assertIsNot'] = assertIsNot
        __builtin__.__dict__['assertIs'] = assertIs
    except ImportError:
        # Python 3
        import builtins
        builtins.__dict__['assertEqual'] = assertEqual
        builtins.__dict__['assertNotEqual'] = assertNotEqual
        builtins.__

# Generated at 2022-06-23 14:35:54.912168
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self, *args):
            pass

    f1 = Foo()
    f2 = Foo()

    # f1 and f2 should refer to the same instance
    assert f1 is f2

# Generated at 2022-06-23 14:35:57.495225
# Unit test for constructor of class Singleton
def test_Singleton():
    '''
    Singleton have been initialized the test will return True
    '''
    ansible_module = Singleton
    assert ansible_module

# Generated at 2022-06-23 14:36:02.867606
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create singleton class for test
    class TestSingle(object):
        __metaclass__ = Singleton
        counter = 0

        def __init__(self, arg):
            self.arg = arg
            TestSingle.counter += 1

    # Create several instances of the class and test if all of them are
    # of the same object
    single1 = TestSingle(1)
    single2 = TestSingle(2)
    single3 = TestSingle(3)

    assert isinstance(single1, TestSingle)
    assert isinstance(single2, TestSingle)
    assert isinstance(single3, TestSingle)
    assert single1 is single2 is single3
    assert TestSingle.counter == 1

# Generated at 2022-06-23 14:36:06.641516
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    instance1 = Test('foo')
    instance2 = Test('bar')
    assert instance1 is instance2

# Generated at 2022-06-23 14:36:09.168251
# Unit test for constructor of class Singleton
def test_Singleton():
    class Dummy(object):
        __metaclass__ = Singleton

    d1 = Dummy()
    d2 = Dummy()

    assert d1 is d2

# Generated at 2022-06-23 14:36:12.934956
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        pass

    ts1 = TestSingleton()
    ts2 = TestSingleton()
    ts3 = TestSingleton()

    assert ts1 is ts2 and ts2 is ts3

# Generated at 2022-06-23 14:36:16.693416
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create test class
    class Example(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 0
            self.b = 1
    # First call
    example = Example()
    assert(example.a == 0 and example.b == 1)
    # Second call
    example = Example()
    assert(example.a == 0 and example.b == 1)
    # Third call
    example = Example()
    assert(example.a == 0 and example.b == 1)


# Generated at 2022-06-23 14:36:24.899979
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton1(metaclass=Singleton):
        """Test class for Singleton"""
        def __init__(self):
            pass

    class TestSingleton2(metaclass=Singleton):
        """Test another class for Singleton"""
        def __init__(self):
            pass

    instance1a = TestSingleton1()
    instance1b = TestSingleton1()
    instance2a = TestSingleton2()
    instance2b = TestSingleton2()

    assert instance1a is instance1b
    assert instance2a is instance2b
    assert instance1a is not instance2a

    assert isinstance(instance1a, TestSingleton1)
    assert isinstance(instance1b, TestSingleton1)
    assert isinstance(instance2a, TestSingleton2)

# Generated at 2022-06-23 14:36:28.967532
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 0

    a = A()
    assert a.i == 0
    a.i = 1
    b = A()
    assert b.i == 1

# Generated at 2022-06-23 14:36:33.703059
# Unit test for constructor of class Singleton
def test_Singleton():
    class ClassTest(object):

        __metaclass__ = Singleton

        def __init__(self):
            self.value = 10

    c1 = ClassTest()
    c2 = ClassTest()

    assert id(c1) == id(c2)
    assert c2.value == 10

# Generated at 2022-06-23 14:36:41.515326
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    It is a good practice to instantiate the class only after the
    class is defined.  This is to make sure that the code in
    __init__ doesn't affect Singleton behavior.
    """
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 'a'

    a = A()
    b = A()

    assert a is b
    assert a.a == b.a

    a.a = 'aa'
    assert a.a == b.a

# Generated at 2022-06-23 14:36:44.596506
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
    s1 = TestSingleton()
    s2 = TestSingleton()
    assert s1 is s2


# Generated at 2022-06-23 14:36:49.395439
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # ...
    class A(metaclass=Singleton):
        pass

    assert A() is A()
    assert A() is not A(1, 2)
    assert A() is not A(**{'a': 1, 'b': 2})
    # ...

# Generated at 2022-06-23 14:36:53.498894
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest1(object):
        __metaclass__ = Singleton

    class SingletonTest2(object):
        __metaclass__ = Singleton

    assert SingletonTest1() is SingletonTest1()
    assert SingletonTest1() is not None
    assert SingletonTest2() is SingletonTest2()
    assert SingletonTest1() is not SingletonTest2()

# Generated at 2022-06-23 14:36:57.001905
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = A()
    b = A()
    assert(a == b)



# Generated at 2022-06-23 14:37:00.365202
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        pass

    a1 = A()
    a2 = A()
    return a1 is a2

# Generated at 2022-06-23 14:37:07.957006
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            super(A, self).__init__()
            self.a = 'a'
            
    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            super(B, self).__init__()
            self.a = 'b'

    a1 = A()
    a2 = A()
    b = B()
    assert(a1 is a2)
    assert(a1 == a2)
    assert(a1 is not b)
    assert(a1 != b)


# vim: set expandtab:ts=4:sw=4

# Generated at 2022-06-23 14:37:11.680511
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 5

    a = Test()
    b = Test()
    assert(a.x == 5)
    assert(b.x == 5)
    b.x = 7
    assert(a.x == 7)



# Generated at 2022-06-23 14:37:17.838467
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test class
    class Test_Singleton(object):
        __metaclass__ = Singleton

    # Test instance
    t_Singleton = Test_Singleton()

    # Test two different instances of same class
    assert isinstance(t_Singleton, Test_Singleton)
    assert isinstance(Test_Singleton(), Test_Singleton)

    # Test that instances are the same object
    assert id(t_Singleton) == id(Test_Singleton())

    # Test that instance is the only instance in memory
    assert id(Test_Singleton()) == id(Test_Singleton())

# Generated at 2022-06-23 14:37:22.020853
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

    assert issubclass(SingletonTest, object)
    assert issubclass(SingletonTest, Singleton)



# Generated at 2022-06-23 14:37:24.150929
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert(a is b)

# Generated at 2022-06-23 14:37:33.089985
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase
    from threading import Lock

    # Object of class TestSingleton1
    class TestSingleton1:
        __metaclass__ = Singleton

        def __init__(self, lock, value):
            self.lock = lock
            self.value = value

    # Object of class TestSingleton2
    class TestSingleton2:
        __metaclass__ = Singleton

        def __init__(self, lock, value):
            self.lock = lock
            self.value = value

    # Object of class TestSingleton3
    class TestSingleton3:
        __metaclass__ = Singleton

        def __init__(self, lock, value):
            self.lock = lock
            self.value = value

    # Object of class TestSingleton4

# Generated at 2022-06-23 14:37:36.551415
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    print(a is b)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-23 14:37:37.852293
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert a is b

# Generated at 2022-06-23 14:37:40.831929
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    instance_1 = Test("one")
    assert instance_1.name == "one"

    instance_2 = Test("two")
    assert instance_2.name == "two"
    assert instance_1 is instance_2


# Generated at 2022-06-23 14:37:46.030297
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    f1 = Foo("a", "b")
    assert f1.a == "a"
    assert f1.b == "b"

    f2 = Foo("c", "d")
    assert f2 == f1
