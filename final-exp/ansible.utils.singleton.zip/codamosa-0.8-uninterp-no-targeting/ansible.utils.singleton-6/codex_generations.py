

# Generated at 2022-06-21 08:55:59.505695
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # __call__ is called when you do MySingletonClass()
    class MySingletonClass(object):
        __metaclass__ = Singleton

    instance1 = MySingletonClass()
    instance2 = MySingletonClass()
    assert instance1 is instance2

# Generated at 2022-06-21 08:56:01.765477
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 is a2

# Generated at 2022-06-21 08:56:09.923448
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    class Bar(Foo):
        pass

    a = Foo()
    b = Foo()
    d1 = id(a)
    d2 = id(b)
    assert d1 == d2
    assert isinstance(a, Foo)
    assert isinstance(b, Foo)

    c = Bar()
    d = Bar()
    d3 = id(c)
    d4 = id(d)
    assert d3 == d4
    assert isinstance(c, Bar)
    assert isinstance(d, Bar)
    assert c == d
    assert d1 == d3

# Generated at 2022-06-21 08:56:15.634368
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 'something'

    a1 = A()
    a2 = A()

    assert a1 == a2
    assert a1.val == a2.val

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:56:18.339027
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    a = A()
    b = Singleton()
    assert a == b


# Generated at 2022-06-21 08:56:22.752941
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton
        value = 1

    assert C.value
    assert id(C()) == id(C())
    assert C() is not None
    assert C() is not False


# Generated at 2022-06-21 08:56:32.455487
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, x=2):
            self.x = x

    a = Foo()
    b = Foo()
    c = Foo()

    assert a == b and a == c, "Singleton class Foo created multiple objects"
    assert id(a) == id(b) and id(a) == id(c), "Singleton class Foo created multiple objects"
    assert a.x == 2 and b.x == 2 and c.x == 2, "Singleton class Foo created multiple objects"

    a.x = 3
    assert a.x == 3 and b.x == 3 and c.x == 3, "Singleton class Foo created multiple objects"



# Generated at 2022-06-21 08:56:35.287117
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    s1 = TestSingleton()
    assert(s1 is TestSingleton())


# Generated at 2022-06-21 08:56:39.539529
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    if A() == A():
        print("Singleton works")

# Comment this line below when you want to test the class Singleton
# test_Singleton()

# Generated at 2022-06-21 08:56:43.208053
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    instance1 = SingletonTest(1)
    assert(not instance1 is None)
    instance2 = SingletonTest(2)
    assert(instance1 is instance2)


# Generated at 2022-06-21 08:56:51.027183
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        _name = "SingletonTest"

    s1 = SingletonTest()
    s2 = SingletonTest()
    assert(s1._name == s2._name)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 08:56:58.851807
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class testClass(object):
        __metaclass__ = Singleton

    class testClass2(testClass):
        def __init__(self):
            pass

    tc = testClass()
    tc1 = testClass()
    tc2 = testClass()
    assert id(tc) == id(tc1), "Singleton does not work for simple class"
    assert id(tc) == id(tc2), "Singleton does not work for simple class"

    tc = testClass2()
    tc1 = testClass2()
    tc2 = testClass2()
    assert id(tc) == id(tc1), "Singleton does not work with inheritance"
    assert id(tc) == id(tc2), "Singleton does not work with inheritance"



# Generated at 2022-06-21 08:57:00.042419
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton


# Generated at 2022-06-21 08:57:09.456544
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global __instance
    global __rlock

    class foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = "hello"

    global __instance

    class bar(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = "world"

    # create two instances.
    instance_foo = foo()
    instance_bar = bar()
    # test if it's the same class
    assert isinstance(instance_foo, foo)
    assert isinstance(instance_bar, bar)
    # test if the instances are the same.
    assert instance_foo is instance_bar
    # test if the __instance attribute is the same.
    assert foo.__instance is bar.__instance
    # test if the __rlock attribute is

# Generated at 2022-06-21 08:57:13.542110
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert(id(test1) == id(test2))
    test2.instance_var = 'test'
    assert(test1.instance_var == test2.instance_var)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:57:18.350960
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Checking if this method really creates only one instance of
    # class when multiple calls are made.
    s = Singleton('__call__')
    s1 = s('test')
    s2 = s('test')
    assert s1 is not None and s1 == s2


# Generated at 2022-06-21 08:57:21.041411
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
    a = TestClass()
    b = TestClass()
    assert a is b


# Generated at 2022-06-21 08:57:25.071522
# Unit test for constructor of class Singleton
def test_Singleton():
    """
    Test case for the Singleton metaclass
    """
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()
    assert Test is Test()


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:57:32.971367
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):

        __metaclass__ = Singleton

        def __init__(self):
            self._var = 'test'

        def _test(self):
            return self._var

    from threading import Thread
    from Queue import Queue

    def do_test(q):
        t = TestSingleton()
        q.put(t._test())

    q = Queue()
    t = Thread(target=do_test, args=(q,))
    t.start()
    t.join()
    assert q.get() == 'test'

# Generated at 2022-06-21 08:57:40.629532
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Define a class extending Singleton
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, argument):
            self.argument = argument

    # Create a few instances of that class
    instance_1 = MyClass(1)
    instance_2 = MyClass(2)
    instance_3 = MyClass(3)

    # Make sure they are all the same object
    assert(id(instance_1) == id(instance_2) == id(instance_3))

    # Make sure the arguments are preserved
    assert(instance_1.argument == 1)

# Generated at 2022-06-21 08:57:55.286123
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = 0

    class MyOtherSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.foo = arg

    class MyNotSingleton(object):
        def __init__(self):
            self.foo = 0

    # Tests for classes where __init__ takes no arguments
    x = MySingleton()
    y = MySingleton()
    assert(x is y)

    # Tests for classes where __init__ takes arguments
    a = MyOtherSingleton('bar')
    b = MyOtherSingleton('baz')
    assert(a is b)
    assert(a.foo == 'baz')

# Generated at 2022-06-21 08:58:02.037493
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Unit test of class Singleton.

    This test is executed by test_metaclasses.py.
    """
    class TestClass(object):
        __metaclass__ = Singleton

    class TestClassWithArgs(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2, arg3=None):
            self.args = (arg1, arg2, arg3)

    class TestClassWithKwargs(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2, arg3=None):
            self.kwargs = {'arg1': arg1, 'arg2': arg2, 'arg3': arg3}

    class TestClassWithArgsAndKwargs(object):
        __metaclass__ = Singleton


# Generated at 2022-06-21 08:58:04.499907
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        # Enforce Singleton pattern
        __metaclass__ = Singleton



# Generated at 2022-06-21 08:58:08.715113
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Test_Singleton_Class(object):
        __metaclass__ = Singleton

    t = Test_Singleton_Class()
    u = Test_Singleton_Class()
    assert (t==u)



# Generated at 2022-06-21 08:58:10.555322
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton


# Test Singleton's functionality

# Generated at 2022-06-21 08:58:13.481906
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        pass
    a = TestClass()
    b = TestClass()
    assert a is b

# Generated at 2022-06-21 08:58:17.966506
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    test_singleton1 = TestSingleton('mgd')
    test_singleton2 = TestSingleton('mgd')
    assert test_singleton1 is test_singleton2

# Generated at 2022-06-21 08:58:21.519484
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class ABC(object):
        __metaclass__ = Singleton

    assert(ABC() == ABC())
    assert(ABC() is ABC())


# Generated at 2022-06-21 08:58:25.345256
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class AllTheThings(metaclass=Singleton):
        def __init__(self):
            self.init = 0

        def this(self):
            self.init += 1
            return self.init

    a1 = AllTheThings()
    a2 = AllTheThings()

    assert(type(a1) is AllTheThings)
    assert(a1 is a2)
    assert(a1.this() == 1)
    assert(a2.this() == 2)



# Generated at 2022-06-21 08:58:25.962751
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-21 08:58:42.073142
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.module_utils.common.collections import ImmutableDict

    '''Test for class Singleton, method __call__'''

    # Classes for testing
    class A(metaclass=Singleton):
        def __init__(self):
            self.x = 'abcd'

    class B(A):
        pass

    class C(metaclass=Singleton):
        def __init__(self):
            self.x = 'efgh'

    class D(C):
        pass

    # test __call__ returns existing instance
    assert A() is A()
    assert B() is B()
    assert B() is A()

    # test __call__ creates a new instance if one does not exist
    assert C() is not A()
    assert D() is not B()

    # test method __call__ is

# Generated at 2022-06-21 08:58:46.764440
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 42

    inst1 = Test()
    inst2 = Test()

    assert inst1 is inst2
    assert inst1.x == inst2.x



# Generated at 2022-06-21 08:58:49.993511
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
    assert Foo() is Foo()


if __name__ == "__main__":
    test_Singleton()
    print("Successfully passed all test")

# Generated at 2022-06-21 08:58:55.110823
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, x=0):
            self.x = x

    foo1 = Foo()
    foo2 = Foo()

    assert foo1 is foo2
    # Foo exists, so Foo(1) should return Foo
    foo3 = Foo(1)
    assert foo1 is foo3

# Generated at 2022-06-21 08:58:58.380090
# Unit test for constructor of class Singleton
def test_Singleton():
    foo = Singleton
    bar = Singleton('bar', (), {})
    assert foo == bar
    print(foo)
    print(bar)


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 08:59:03.940005
# Unit test for constructor of class Singleton
def test_Singleton():
    class testMeta(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    t = testMeta(123)
    assert t.x == 123
    s = testMeta(789)
    assert s.x == 123
    assert t == s

# Generated at 2022-06-21 08:59:06.704950
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def test_singleton(self):
            return True

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-21 08:59:09.672444
# Unit test for constructor of class Singleton
def test_Singleton():
	class A(metaclass=Singleton):
		def __init__(self):
			pass
	a1 = A()
	a2 = A()
	assert a1 == a2


# Generated at 2022-06-21 08:59:18.843770
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTestClass(metaclass=Singleton):
        def __init__(self):
            self.data = {}

        def storeItem(self, name, value):
            if name not in self.data:
                self.data[name] = value

        def printItem(self, name):
            print(self.data[name])

    singletonTest = SingletonTestClass()
    singletonTest.storeItem('test', '1')
    singletonTest.printItem('test')

    singletonTest2 = SingletonTestClass()
    singletonTest2.printItem('test')

    assert(singletonTest is singletonTest2)

# Generated at 2022-06-21 08:59:22.989282
# Unit test for constructor of class Singleton
def test_Singleton():
    class s(object):
        __metaclass__ = Singleton
        __objects = 0
        def __init__(self):
            s.__objects += 1
    s()
    s()
    assert s.__objects == 1

# test_Singleton()

# Generated at 2022-06-21 08:59:27.855481
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonClass(object):
        __metaclass__ = Singleton

    first_obj = SingletonClass()
    second_obj = SingletonClass()

    assert first_obj == second_obj



# Generated at 2022-06-21 08:59:30.532825
# Unit test for constructor of class Singleton
def test_Singleton():
    # arrange
    class Container(object):
        __metaclass__ = Singleton
        pass
    
    # act
    container1 = Container()
    container2 = Container()

    # assert
    assert container1 == container2



# Generated at 2022-06-21 08:59:33.022236
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    # Should create one instance only
    foo = Foo()
    foo2 = Foo()
    assert foo is foo2

# Generated at 2022-06-21 08:59:40.689473
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global g_instance
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self,i):
            self.i = i

    t = Test(7)
    # t2 should be the same instance as t
    t2 = Test(12)
    assert(t == t2)
    assert(t.i == 7)
    assert(t2.i == 7)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 08:59:45.668959
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, name):
            self.name = name
    a1 = A("A")
    a2 = A("B")
    assert a1.name == "A"
    assert a2.name == "A"
    assert id(a1) == id(a2)

# Generated at 2022-06-21 08:59:51.164295
# Unit test for constructor of class Singleton
def test_Singleton():
    class Singleton_child(object):
        __metaclass__ = Singleton

        def __init__(self, secret):
            self.secret = secret

    a = Singleton_child('a')
    b = Singleton_child('b')

    assert a == b
    assert b.secret == 'a'
    assert a.secret == 'a'

# Generated at 2022-06-21 08:59:55.343713
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test:
        __metaclass__ = Singleton

    assert Test() is Test()
    assert Test() is Test()
    assert Test() is Test()

    class Test2(object):
        __metaclass__ = Singleton

    assert Test2() is Test2()
    assert Test2() is Test2()
    assert Test2() is Test2()

# Generated at 2022-06-21 09:00:02.438498
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    instance_1 = MyClass()
    instance_2 = MyClass()

    assert instance_1 == instance_2
    assert instance_1 is instance_2
    print("test_Singleton___call__: PASS")


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-21 09:00:05.206293
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-21 09:00:08.758206
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

    t1 = TestClass()
    t2 = TestClass()
    assert t1 is t2

if __name__ == '__main__':
    test_Singleton()