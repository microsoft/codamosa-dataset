

# Generated at 2022-06-21 08:55:58.247552
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    for i in range(0,10):
        t = Test()
        assert(t is Test())

# Generated at 2022-06-21 08:56:03.230718
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 0
    a = X()
    assert a.x == 0
    b = X()
    assert a == b
    assert a.x == 0
    b.x = 1
    assert a.x == 1

# Generated at 2022-06-21 08:56:06.575270
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = "Test"

    t1 = Test()
    t2 = Test()
    assert t1.name == "Test"
    assert t1 == t2

# Generated at 2022-06-21 08:56:16.491486
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.n = 0

        def inc_and_return(self):
            self.n += 1
            return self.n

    # Test whether TestClass is Singleton
    a = TestClass()
    b = TestClass()
    assert a == b
    assert a.inc_and_return() == 2
    assert b.inc_and_return() == 3
    assert a == b
    assert a.inc_and_return() == 4
    assert b.inc_and_return() == 5
    assert a == b

# Generated at 2022-06-21 08:56:27.047310
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.__a = a
            self.__b = b

    # Check that two instances are equal
    assert A(1,2) == A(1,2)
    # Check that two unequal instances are not equal
    assert A(1,2) != A(1,3)
    # Check that for two different classes instances are not equal
    assert A(1,2) != B(1,2)

    class B(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.__a = a
            self.__b = b


# Generated at 2022-06-21 08:56:33.498889
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class TestSingletonClass(object):
        __metaclass__ = Singleton

    class TestSingleton(unittest.TestCase):
        def runTest(self):
            test_Singleton_instance1 = TestSingletonClass()
            test_Singleton_instance2 = TestSingletonClass()

            self.assertTrue(test_Singleton_instance1 is test_Singleton_instance2)

    unittest.main()


# Generated at 2022-06-21 08:56:41.467188
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = [1, 2]

        def list_append(self, a):
            self.a.append(a)

    assert A().__dict__['a'] == [1, 2]
    a = A()
    a.list_append(3)
    assert a.__dict__['a'] == [1, 2, 3]
    b = A()
    assert b.__dict__ == {'a': [1, 2, 3]}
    assert id(a) == id(b)

# Generated at 2022-06-21 08:56:47.888095
# Unit test for constructor of class Singleton
def test_Singleton():
    class ASingleton(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name
            self.value = name
    a1 = ASingleton('foo')
    a2 = ASingleton('bar')
    assert a1.name == 'foo'
    assert a2.name == 'foo'

# Generated at 2022-06-21 08:56:51.513443
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        pass

    class Bar(Foo):
        pass

    assert isinstance(Foo(), Foo)
    assert isinstance(Bar(), Bar)
    assert Foo() is Bar()

# Generated at 2022-06-21 08:56:55.753918
# Unit test for constructor of class Singleton
def test_Singleton():
    class AnyClass(object):
        __metaclass__ = Singleton

        def __init__(self, param):
            self.param = param

    a = AnyClass(True)
    b = AnyClass(False)

    assert a is b
    assert a.param != b.param

# Generated at 2022-06-21 08:57:00.891550
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    obj1 = TestSingleton('first')
    assert obj1.name == 'first'

    obj2 = TestSingleton('second')
    assert obj2 is obj1

# Generated at 2022-06-21 08:57:04.587055
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            super(Foo, self).__init__(*args, **kwargs)
    f1 = Foo()
    f2 = Foo()
    assert f1 == f2

# Generated at 2022-06-21 08:57:10.471071
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, value=1):
            self.val = value
    for i in range(5):
        t1 = TestClass()
        assert(t1.val == 1)
        t1.val = 0
        t2 = TestClass()
        assert(t2.val == 0)
    t3 = TestClass(100)
    assert(t3.val == 100)

# Generated at 2022-06-21 08:57:15.614777
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 0

    a = TestSingleton()
    b = TestSingleton()

    assert(id(a) == id(b))
    assert(a is TestSingleton())
    assert(b is TestSingleton())

# Generated at 2022-06-21 08:57:20.897286
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SSingleton(object):
        __metaclass__ = Singleton

    class SObj(SSingleton):
        def __init__(self, name):
            self.name = name

    a = SObj('a')
    b = SObj('b')

    assert a == b
    assert a is b
    assert a.name == b.name

# Generated at 2022-06-21 08:57:31.242319
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            if hasattr(self, 'instance_var'):
                raise RuntimeError('__init__ called on already instantiated class')
            self.instance_var = "instance_var"

        def test_method(self):
            return self.instance_var

    try:
        ts1 = TestSingleton()
        ts2 = TestSingleton()
        ts3 = TestSingleton()
        assert id(ts1) == id(ts2) == id(ts3)
        assert ts1.test_method() == ts2.test_method() == ts3.test_method() == "instance_var"
    except:
        raise AssertionError

# Generated at 2022-06-21 08:57:33.490076
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    ts1 = TestSingleton()
    ts2 = TestSingleton()

    assert ts1 is ts2

# Generated at 2022-06-21 08:57:39.692895
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleClass(object):
        """Class to test singleton implementation"""
        __metaclass__ = Singleton

        def __init__(self):
            self.my_var = "something"

    my_first_instance = MySingleClass()
    my_second_instance = MySingleClass()
    my_first_instance.my_var = "changed"
    assert my_first_instance == my_second_instance
    assert id(my_first_instance) == id(my_second_instance)
    assert my_second_instance.my_var == "changed"


# Generated at 2022-06-21 08:57:43.857978
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            pass

    a = Foo()
    b = Foo()
    del a
    c = Foo()

    assert b is c


# Generated at 2022-06-21 08:57:51.260038
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    x = MyClass(100)

# Generated at 2022-06-21 08:57:56.913562
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    assert foo1

    try:
        foo2 = Foo()
    except TypeError:
        assert False

    assert foo1 == foo2


# Generated at 2022-06-21 08:58:06.902863
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest
    from threading import Thread

    class MyClass(object):
        __metaclass__ = Singleton

    assert MyClass() is MyClass()

    # Check that instances are not shared between threads
    first_instance = []
    second_instance = []

    def first_thread():
        first_instance.append(MyClass())

    def second_thread():
        second_instance.append(MyClass())

    t1 = Thread(target=first_thread)
    t2 = Thread(target=second_thread)

    t1.start()
    t2.start()

    t1.join()
    t2.join()

    assert first_instance[0] != second_instance[0]

# Generated at 2022-06-21 08:58:10.853687
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    a = A()
    assert a is A()

    b = B()
    assert b is B()
    assert a != b



# Generated at 2022-06-21 08:58:16.245374
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton:
        __metaclass__ = Singleton

        def __init__(self):
            self.var = 1

    instance1 = TestSingleton()
    instance2 = TestSingleton()

    assert instance1 == instance2
    assert instance1.var == instance2.var

    instance1.var = 2

    assert instance1.var == instance2.var

# Generated at 2022-06-21 08:58:18.597451
# Unit test for constructor of class Singleton
def test_Singleton():
    '''
    Testing Singleton class constructor
    '''
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-21 08:58:23.753333
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert(a is b)


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 08:58:26.058556
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 == a2

# Generated at 2022-06-21 08:58:33.560376
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class A(object):
        __metaclass__ = Singleton
        
        def __init__(self):
            self.b = 0
        
        def inc(self):
            self.b += 1
    
    a = A()
    a.inc() # the value of a.b is now 1
    a1 = A()
    a1.inc() # the value of a.b is now 2, not 1
    assert a1.b == 2

test_Singleton___call__()

# Generated at 2022-06-21 08:58:39.691975
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            self.answer = 42

    inst1 = MyClass()
    inst2 = MyClass()
    assert inst1 is inst2
    assert inst1.answer == inst2.answer
    assert inst1.answer == 42
    assert inst2.answer == 42

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 08:58:46.315475
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    import random
    import time

    def foo():
        time.sleep(random.random())
        instance = TestSingleton()
        print('foo finished')

    def bar():
        time.sleep(random.random())
        instance = TestSingleton()
        print('bar finished')

    import threading
    threads = []
    for f in [foo, bar]:
        thread = threading.Thread(target=f)
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 08:58:55.028692
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    # Create a singelton instance
    t1 = Test(1)
    assert t1.arg == 1

    # Create another instance and make sure it's the same as the one created
    # before
    t2 = Test(2)
    assert t1 is t2
    assert t2.arg == 1



# Generated at 2022-06-21 08:59:02.018617
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(with_metaclass(Singleton, object)):
        def __init__(self):
            pass
    assert Singleton.__instance is None

    instance_1 = Test()
    assert Singleton.__instance is not None

    instance_2 = Test()
    assert instance_1 is instance_2

    Singleton.__instance = None
    instance_3 = Test()
    assert instance_1 is instance_3

# Generated at 2022-06-21 08:59:05.158355
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass
    test1 = Test()
    test2 = Test()
    assert(test1 == test2)

# Generated at 2022-06-21 08:59:09.832689
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    instance1 = TestSingleton()
    instance2 = TestSingleton()
    assert instance1.__class__ == TestSingleton
    assert instance2.__class__ == TestSingleton
    assert instance1 is instance2

# Generated at 2022-06-21 08:59:18.267926
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass:
        """Class to test Singleton method __call__"""
        pass

    class TestSingleton(TestClass, metaclass=Singleton):
        """Class to test method __call__ of class Singleton"""
        pass

    i1 = TestSingleton()
    i2 = TestSingleton()

    assert(i1 is i2)

    # Change attribute of instance 1
    i1.attr1 = "value1"

    # Since both instances are the same, attribute of instance 2 must
    # also be equal to value1
    assert(i2.attr1 == "value1")

# Generated at 2022-06-21 08:59:24.549218
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.initialized = True

    test_obj = TestClass()
    assert test_obj.initialized
    assert test_obj.__class__ == TestClass

    test_obj_copy = TestClass()
    assert test_obj_copy.__class__ == TestClass
    assert id(test_obj) == id(test_obj_copy)


# Generated at 2022-06-21 08:59:32.500308
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonA(metaclass=Singleton):
        def __init__(self):
            self.index = 0
            self.marked_entity = None  # dictionary of entity marked for deletion/creation
        def __str__(self):
            return f'index = {self.index}, marked_entity = {self.marked_entity}'
    i = SingletonA()
    i.index = 1
    i.marked_entity = {'A':1}
    j = SingletonA()
    print(j)
    assert(i == j)
    i.index = 2
    i.marked_entity = {'B':2}
    print(j)
    assert(i == j)
    # ensure singleton
    j.index = 3
    j.marked_entity = {'C':3}

# Generated at 2022-06-21 08:59:38.712623
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''
    test for __call__ method of class Singleton
    '''
    class TestSingleton(object):
        __metaclass__ = Singleton

    try:
        assert TestSingleton() == TestSingleton()
    except:
        import traceback
        print(traceback.format_exc())
        raise


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 08:59:50.415293
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread

    class SingletonClass(object):
        """Metaclass for classes that wish to implement Singleton
        functionality.  If an instance of the class exists, it's returned,
        otherwise a single instance is instantiated and returned.
        """
        __instance = None
        __rlock = RLock()

        def __init__(self):
            pass

        @staticmethod
        def getInstance():
            if SingletonClass.__instance is not None:
                return SingletonClass.__instance

            with SingletonClass.__rlock:
                if SingletonClass.__instance is None:
                    SingletonClass.__instance = SingletonClass()
            return SingletonClass.__instance

    # test single-thread case
    print("***** Singleton single-thread case *****")
    instance1 = SingletonClass.getInstance

# Generated at 2022-06-21 08:59:57.523098
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingleA(object, metaclass=Singleton):
        def __init__(self, a=1, b=1):
            self.a = a
            self.b = b
 
    sa1 = SingleA()
    assert(sa1.a == 1)
    assert(sa1.b == 1)

    sa2 = SingleA(2, 2)
    assert(sa1.a == 1)
    assert(sa1.b == 1)
    assert(sa2.a == 1)
    assert(sa2.b == 1)

    assert(sa1 is sa2)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:00:04.692193
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    o1 = TestSingleton(1)
    o2 = TestSingleton(2)

    assert o1 is o2
    assert o1.arg == 2
    assert o2.arg == 2

# Generated at 2022-06-21 09:00:09.687901
# Unit test for constructor of class Singleton
def test_Singleton():
    print("test begin")
    class Test(metaclass=Singleton):
        def __init__(self, msg):
            self.msg = msg

        def __str__(self):
            return self.msg

    a = Test("test1")
    print(a)
    b = Test("test2")
    print(b)
    assert(a == b)
    print("test end")

# Generated at 2022-06-21 09:00:18.084170
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, value=1):
            self.value = value

    a = Foo()
    b = Foo()
    assert a is b
    assert a.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2
    b.value = 3
    assert a.value == 3
    assert b.value == 3
    c = Foo(value=4)
    assert c is b
    assert a.value == 4
    assert b.value == 4
    assert c.value == 4
    d = Foo(value=5)
    assert d is b
    assert a.value == 5
    assert b.value == 5
    assert c.value == 5
    assert d.value == 5


# Generated at 2022-06-21 09:00:20.949348
# Unit test for constructor of class Singleton
def test_Singleton():
    class Singleton_test(object):
        __metaclass__ = Singleton

    a = Singleton_test()
    b = Singleton_test()
    assert a is b
if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 09:00:22.498150
# Unit test for constructor of class Singleton
def test_Singleton():
    with pytest.raises(TypeError):
        Singleton()



# Generated at 2022-06-21 09:00:25.897156
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert id(t1) == id(t2)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:00:27.628814
# Unit test for constructor of class Singleton
def test_Singleton():
    obj1 = Singleton.__call__
    obj2 = Singleton.__call__
    assert id(obj1) == id(obj2)

# Generated at 2022-06-21 09:00:36.080953
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

        def set_b(self, b):
            self.b = b

    s1 = TestSingleton(1, 2)
    assert s1.a == 1
    assert s1.b == 2

    s2 = TestSingleton(10, 20)
    assert s2.a == 1
    assert s2.b == 2

    assert s1 is s2

    s1.set_b(4)
    assert s2.b == 4

# Generated at 2022-06-21 09:00:38.200975
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    assert A() is A()

# Generated at 2022-06-21 09:00:40.677782
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-21 09:00:48.512955
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    class TestClass2(object):
        __metaclass__ = Singleton

    assert TestClass() == TestClass()
    assert TestClass2() == TestClass2()
    assert TestClass() is not TestClass2()



# Generated at 2022-06-21 09:00:52.829922
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    # verify that A is a singleton
    a1 = A()
    assert a1 is A()

    # verify that b is not a singleton
    b1 = A()
    assert b1 is not A()
    
if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-21 09:00:57.616610
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(metaclass=Singleton):
        def __init__(self):
            self.i = 1
        def set_i(self, i):
            self.i = i
        def get_i(self):
            return self.i

    c = C()
    assert c.get_i() == 1
    c.set_i(3)
    c2 = C()
    assert c is c2
    assert c.get_i() == 3
    assert c2.get_i() == 3

    # Test pickling
    import pickle
    c3 = pickle.loads(pickle.dumps(c2))
    assert c3 is c
    assert c3.get_i() == 3
    assert c3.get_i() == c.get_i()
    assert c3.get_i

# Generated at 2022-06-21 09:01:09.303475
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import random
    import sys
    import threading

    # Randomize test
    # This number is tested with assert to avoid false positive
    TEST_COUNT = random.randint(5, 100)

    class FakeClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    # Test init
    fc = FakeClass()
    assert fc.value == 0
    fc = None

    # Test singleton
    for i in range(TEST_COUNT):
        # Create multiple instances in multiple threads
        def foo():
            fc = FakeClass()
            fc.inc()
            fc = None


# Generated at 2022-06-21 09:01:15.513576
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonDemo(object):
        __metaclass__ = Singleton

        def __init__(self, name=None):
            self.name = name

    singleton_instance = SingletonDemo()
    assert singleton_instance.name is None

    singleton_with_name = SingletonDemo(name='bar')
    assert singleton_with_name.name == 'bar'
    assert singleton_instance is singleton_with_name
    assert id(singleton_instance) == id(singleton_with_name)

test_Singleton()

# Generated at 2022-06-21 09:01:20.740388
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingleton___call_(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_Singleton___call__(self):
            t = TestSingleton()
            self.assertEqual(t, TestSingleton())


    unittest.main()



# Generated at 2022-06-21 09:01:22.462643
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert(A() == A())

# Generated at 2022-06-21 09:01:34.475665
# Unit test for constructor of class Singleton
def test_Singleton():
    print("test_Singleton()")

    import threading
    import time

    # Define our class which will be a Singleton.
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg  # Set our init arg

    # Try to create an instance of A
    a = A("constructor arg")

    def worker(index):
        # Attempt to create another instance of A - it should fail
        # because Singleton only allows one instance.
        a = A("worker arg")

    # Spin up 7 worker threads
    threads = []
    for index in range(7):
        threads.append(threading.Thread(target=worker, args=(index,)))
        threads[-1].start()
        time.sleep(1)

    # Wait for worker

# Generated at 2022-06-21 09:01:36.771139
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 == a2


# Generated at 2022-06-21 09:01:41.051234
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1 is t2

# Test that a Singleton sublcass cannot be instantiated again
# once an instance exists.

# Generated at 2022-06-21 09:01:53.067173
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        """TestSingleton is a Singleton class"""
        __metaclass__ = Singleton

        def __init__(self, x=0):
            self.x = x
            self.y = 0

        def setX(self, x):
            self.x = x

        def getX(self):
            return self.x

    list = []
    for i in range(0, 20):
        list.append(TestSingleton(i))
        list[i].y = i

    for i in range(1, 20):
        assert(list[i] is list[0])
        assert(list[i].getX() == 0)
        assert(list[i].y == i)


# Generated at 2022-06-21 09:01:56.463067
# Unit test for constructor of class Singleton
def test_Singleton():
    from collections import namedtuple
    class test(object):
        __metaclass__ = Singleton

    testobj = test()
    testobj2 = test()
    assert(testobj == testobj2)



# Generated at 2022-06-21 09:02:04.026565
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.value = arg

    class TestSingleton2(object):
        def __init__(self, arg):
            self.value = arg

    ts1 = TestSingleton(1)
    ts2 = TestSingleton(2)
    ts3 = TestSingleton(3)
    ts4 = TestSingleton2(4)

    print(ts1.value)  # 1
    print(ts2.value)  # 1
    print(ts3.value)  # 1
    print(ts4.value)  # 4

# Generated at 2022-06-21 09:02:08.985131
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.my_dict = dict()

    i1 = MyClass()
    i2 = MyClass()
    assert i1 is i2
    i1.my_dict = 1
    assert i2.my_dict == 1

# Generated at 2022-06-21 09:02:14.385727
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import main

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    # Wrapper function to test the equality of two instances of A.
    def test_equal():
        import threading

        a = A()
        b = A()
        assert a == b

        def another_instantiation():
            A()

        t = threading.Thread(target=another_instantiation)
        t.start()
        t.join()
        assert a == b

    test_equal()
    main()



# Generated at 2022-06-21 09:02:19.394041
# Unit test for constructor of class Singleton
def test_Singleton():
    class ClassA(metaclass=Singleton):
        def __init__(self, a):
            self.a = a
    a1 = ClassA(10)
    a2 = ClassA(20)
    assert a1 is a2
    assert a1.a == 20

# Generated at 2022-06-21 09:02:26.593143
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonInstance(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    # The first time we create an instance, it should instantiate
    # the SingletonInstance, and return the new instance.
    a = SingletonInstance(1)
    assert a
    assert a.arg == 1

    # Calling SingletonInstance again should return the same instance.
    b = SingletonInstance(2)
    assert b is a
    assert b.arg == 1


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 09:02:29.958568
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    my_singleton = MySingleton()

    assert my_singleton.value == 1
    assert my_singleton is MySingleton()
    assert my_singleton is MySingleton.__instance

# Generated at 2022-06-21 09:02:32.872464
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    print(id(Test()), id(Test()))

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:02:37.805158
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    t1 = Test(1)
    t2 = Test(2)
    t3 = Test(3)

    assert t1.val == 1
    assert t2.val == 1
    assert t3.val == 1


# Generated at 2022-06-21 09:02:44.281077
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
    s = SingletonTest()
    assert s == SingletonTest()

# Generated at 2022-06-21 09:02:52.077929
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, arg=None):
            if arg is None:
                arg = {}
            self.arg_value = arg

    # create first instance
    s1 = SingletonTest(arg={'x': 1})
    # check singleton property
    assert s1 is SingletonTest()
    # check argument passed
    assert s1.arg_value == {'x': 1}

    # create second instance, should be same as first
    s2 = SingletonTest()
    assert s2 is s1
    assert s2.arg_value == {'x': 1}



# Generated at 2022-06-21 09:02:54.963529
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    one = A()
    two = B()
    three = A()
    four = B()

    assert one is three
    assert two is four


# Generated at 2022-06-21 09:02:57.525670
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1 == t2

# Generated at 2022-06-21 09:03:06.441781
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.__initialized = False

        def initialize(self, foo):
            self.__initialized = True
            self.foo = foo

        def is_initialized(self):
            return self.__initialized

        def get_foo(self):
            return self.foo

    obj1 = SingletonTest()
    obj2 = SingletonTest()

    assert obj1 is obj2
    assert obj1.is_initialized() == False
    assert obj2.is_initialized() == False
    obj1.initialize("foobar")
    assert obj2.get_foo() == "foobar"

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:03:11.182468
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.message = "Hello World!"

    test_instance1 = TestSingleton()
    test_instance2 = TestSingleton()
    assert id(test_instance1) == id(test_instance2)



# Generated at 2022-06-21 09:03:18.815730
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert type(t1) == TestSingleton
    assert type(t2) == TestSingleton
    assert t1 is not None
    assert t2 is not None
    assert t1 is t2
    assert t2 is t1
    assert t1.a == 1
    assert t2.a == 1


# Generated at 2022-06-21 09:03:22.178611
# Unit test for constructor of class Singleton
def test_Singleton():
    class single(object,metaclass=Singleton):
        def __init__(self):
            self.name = "xuefeng"

    s1 = single()
    s2 = single()
    assert s1==s2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:03:26.530376
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    result = Foo(1)
    assert result.__class__.__name__ == 'Foo'
    assert result.x == 1
    result2 = Foo(2)
    assert result2 is result
    assert result2.__class__.__name__ == 'Foo'
    assert result2.x == 1

# Generated at 2022-06-21 09:03:31.364915
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = A
    class B(metaclass=Singleton):
        def __init__(self):
            self.b = B

    a = A()
    b = B()

    assert(a is A())
    assert(b is B())
    assert(not A() is B())
    assert(a is A())
    assert(b is B())


# Generated at 2022-06-21 09:03:42.022698
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class Child(Test):
        def __init__(self):
            pass

    test1 = Test()
    test2 = Test()

    assert id(test1) == id(test2)

    child1 = Child()
    child2 = Child()

    assert id(child1) == id(child2)



# Generated at 2022-06-21 09:03:47.488219
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    instance1 = TestSingleton('instance1')
    assert instance1.name == 'instance1'
    instance2 = TestSingleton('instance2')
    assert instance2.name == 'instance1'
    assert instance1 == instance2

# Generated at 2022-06-21 09:03:50.229005
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object, metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    assert A('a1') is A('a2')


# Generated at 2022-06-21 09:03:52.597075
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class testSingleton(object):
        __metaclass__ = Singleton

    obj1 = testSingleton()
    obj2 = testSingleton()

    assert obj1 is obj2


# Generated at 2022-06-21 09:03:57.508528
# Unit test for constructor of class Singleton
def test_Singleton():
    # initialize the test
    class Test(metaclass=Singleton):
        def __init__(self):
            pass

    t = Test()
    t1 = Test()
    # check if both the objects are same
    assert t is t1
    # check if both the instances are pointing to the same object
    assert id(t) == id(t1)


if __name__=="__main__":
    test_Singleton()

# Generated at 2022-06-21 09:04:01.122200
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object):
        __metaclass__ = Singleton

    foo = C()
    bar = C()
    assert foo is bar
    assert foo == bar

# Generated at 2022-06-21 09:04:09.038207
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        __max = 100

        def __init__(self):
            self.__n = 0

        def get_next(self):
            self.__n += 1
            return self.__n

        def is_last(self):
            return self.__n == TestSingleton.__max

    t = TestSingleton()
    print(t.get_next())
    print(t.get_next())
    t2 = TestSingleton()
    print(t2.get_next())


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 09:04:10.520756
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() == Test()

# Generated at 2022-06-21 09:04:13.802290
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert id(a) == id(b)



# Generated at 2022-06-21 09:04:15.657870
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    MySingleton()
    # assert id(MySingleton()) == id(MySingleton())
    # assert id(MySingleton()) != id(MySingleton())

# Generated at 2022-06-21 09:04:29.279852
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonClass(object):
        __metaclass__ = Singleton

    a = SingletonClass()
    b = SingletonClass()

    assert a == b
    assert id(a) == id(b)



# Generated at 2022-06-21 09:04:38.386120
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class BaseClass(object):
        __metaclass__ = Singleton
        def __init__(self, a=0, b=0):
            self.x = a
            self.y = b
    class ChildClass(BaseClass): pass

    # Instantiated the first instance of BaseClass
    bc1 = BaseClass(1, 2)
    assert bc1.x == 1
    assert bc1.y == 2

    # Instantiate the second instance of BaseClass, it is the same
    # instance as bc1
    bc2 = BaseClass(3, 4)
    assert bc2.x == 1
    assert bc2.y == 2
    assert bc2 is bc1

    # Instanciate the first instance of ChildClass, different instance
    # than bc1 and bc2
    cc1 = ChildClass(5, 6)
   

# Generated at 2022-06-21 09:04:42.378540
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class s(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    n = s()
    m = s()
    n.a = 2
    assert n.a == 2
    assert m.a == 2


# Generated at 2022-06-21 09:04:49.182014
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.i = 0

    a1 = A()
    a2 = A()
    assert(a1 is a2)

    a1.i += 1
    assert(a2.i == 1)

    print("unit test for constructor of class Singleton passed")

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 09:04:52.382622
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    mySingleton1 = MySingleton()
    mySingleton2 = MySingleton()
    assert mySingleton1 is mySingleton2

# Generated at 2022-06-21 09:04:59.374613
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonClass(object):
        __metaclass__ = Singleton

    print('Test SingleonClass Instance1: {0}'.format(id(SingletonClass())))
    print('Test SingleonClass Instance2: {0}'.format(id(SingletonClass())))
    print('Test SingleonClass Instance3: {0}'.format(id(SingletonClass())))
    print('Test SingleonClass Instance4: {0}'.format(id(SingletonClass())))


# Generated at 2022-06-21 09:05:01.552543
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            self.a = 42

    x = MyClass()
    y = MyClass()

    assert x == y


# Generated at 2022-06-21 09:05:03.613547
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class CSingleton(object):
        __metaclass__ = Singleton

    csingleton = CSingleton()

    assert csingleton is CSingleton()

# Generated at 2022-06-21 09:05:08.098714
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.data = 0

    obj1 = TestClass()
    obj2 = TestClass()
    assert id(obj1) == id(obj2)

    obj1.data = 1
    assert obj1.data == obj2.data


# Generated at 2022-06-21 09:05:13.719367
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = A()
    a1 = A()
    assert a is a1

    # In most cases, singleton should not include the class name
    b = B()
    b1 = B()
    assert b is b1
    assert b is not a
    assert b is not a1



# Generated at 2022-06-21 09:05:39.694351
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2, arg3):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3

    t = TestSingleton('a','b','c')
    assert t.arg1 == 'a'
    assert t.arg2 == 'b'
    assert t.arg3 == 'c'

    assert t is TestSingleton('a','b','c')
    assert t is TestSingleton('a','b','c')

# Generated at 2022-06-21 09:05:48.805994
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kw):
            self.args = args
            self.kw = kw

    class B(A):
        pass

    args = ('foo', 'bar')
    kw = {'key1': 'val1', 'key2': 'val2'}

    assert A(*args, **kw) is A(*args, **kw)
    assert A(*args, **kw) is not A(*args, **kw)

    assert B(*args, **kw) is B(*args, **kw)
    assert B(*args, **kw) is not B(*args, **kw)

    assert A() is A()
    assert A() is not A()

    assert B() is B()
    assert B() is not B()




# Generated at 2022-06-21 09:05:54.240915
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    Test the Singleton metaclass method __call__.
    """
    from collections import Counter

    class TestSingleton(object):
        __metaclass__ = Singleton

    count = Counter()
    objects = [TestSingleton() for i in range(10)]

    # Test:
    #   That the __call__ method returns the same instance
    #   of the class each time.
    for obj in objects:
        count[obj] += 1

    assert len(count) == 1