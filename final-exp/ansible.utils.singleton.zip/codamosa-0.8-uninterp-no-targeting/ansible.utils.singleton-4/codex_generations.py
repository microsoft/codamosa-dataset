

# Generated at 2022-06-21 08:56:05.499151
# Unit test for constructor of class Singleton
def test_Singleton():
    """Check that class Singleton works correctly.
    """
    import types
    import copy

    class TestSingleton:
        __metaclass__ = Singleton

        def __init__(self):
            self.X = 1

        def doubleself(self):
            self.X = 2 * self.X


    # check singleton property
    t0 = TestSingleton()
    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t0 is t1
    assert t0.X == 1
    t0.X = 4
    t0.doubleself()
    assert t0.X == 8
    # check that the object is not static
    assert t0.__class__ == t1.__class__
    assert t0.__class__.__name__

# Generated at 2022-06-21 08:56:07.889422
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        """class A with Singleton metaclass"""
    a = A()
    b = A()
    assert a == b



# Generated at 2022-06-21 08:56:15.777599
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, a='a'):
            print(a)
            self.a = a

    a_1 = A()
    a_2 = A()

    assert a_1 is a_2
    assert a_1.a == a_2.a
    assert a_1.a == 'a'
    print(a_2.a)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:56:27.243381
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class SingletonTester(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = None

        def __call__(self, a=1):
            self.a = a

    class SingletonMetaclassTester(object):
        __metaclass__ = Singleton

    a = SingletonTester()
    b = SingletonTester()
    assert a is b
    assert a.a == 1

    c = SingletonMetaclassTester()
    d = SingletonMetaclassTester()
    assert c is d
    assert c.a is None

    class SingletonParent(object):
        def __init__(self):
            self.a = 1

    class SingletonChild(SingletonParent):
        __metaclass__ = Sing

# Generated at 2022-06-21 08:56:29.010131
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()



# Generated at 2022-06-21 08:56:37.802868
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        pass

    a_1 = A()
    a_2 = A()
    if id(a_1) == id(a_2):
        pass
    else:
        raise AssertionError

    class B(metaclass=Singleton):
        pass

    b_1 = B()
    b_2 = B()
    if id(b_1) == id(b_2):
        pass
    else:
        raise AssertionError

    if id(a_1) == id(b_1):
        raise AssertionError



# Generated at 2022-06-21 08:56:45.272182
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    my_singleton = MySingleton()
    assert my_singleton.x == 1

    my_singleton.x = 2
    assert my_singleton.x == 2

    my_singleton1 = MySingleton()
    assert my_singleton1.x == 2

    # We can assign a new object to the class variable __instance
    # to get a new singleton object
    MySingleton.__instance = None
    my_singleton2 = MySingleton()
    assert my_singleton2.x == 1
    my_singleton2.x = 3
    assert my_singleton2.x == 3

    assert my_singleton.x == 2
    assert my_

# Generated at 2022-06-21 08:56:49.724312
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton
        def __init__(self, x=0):
            self.x = x
    s = S()
    s.x += 1
    s2 = S()
    assert s2.x == 1

# Generated at 2022-06-21 08:56:56.462326
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a, b=1):
            self.a = a
            self.b = b

    a1 = A(10)

    # Calling the same class again should return the  same instance
    # of class A
    a2 = A(11)
    assert a1 == a2, "Expected same instance of A"

    # Verify the class attributes are set correctly
    assert a1.a == 10
    assert a1.b == 1
    assert a2.a == 10
    assert a2.b == 1

# Generated at 2022-06-21 08:56:57.886156
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass:
        __metaclass__ = Singleton

    MyClass()
    MyClass()
    MyClass()

# Generated at 2022-06-21 08:57:03.136091
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    assert A() is A()
    assert A is A()
    assert A() is A
    assert A().__class__ is A
    assert A == A()

# Generated at 2022-06-21 08:57:11.036381
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """ Unit Test for method __call__ of class Singleton
    """
    class TestSingleton(metaclass=Singleton):
        """ Test Class for Singleton
        """
        def __init__(self):
            self.foo = 42

    # Instantiate two objects of TestSingleton class
    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    # Check that foo attribute of two objects is the same
    assert test_singleton_1.foo == 42
    assert test_singleton_2.foo == 42

    # Check that two objects are the same
    assert test_singleton_1 is test_singleton_2

# Generated at 2022-06-21 08:57:13.877984
# Unit test for constructor of class Singleton
def test_Singleton():
    class Temp(object):
        __metaclass__ = Singleton

    t1 = Temp()
    t2 = Temp()
    assert t1 is t2



# Generated at 2022-06-21 08:57:20.465995
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            print ('init for Foo')
    class Bar(Foo):
        def __init__(self):
            print ('init for Bar')
            super(Bar, self).__init__()
    bar1 = Bar()
    bar2 = Bar()
    assert bar1 == bar2

test_Singleton___call__()

# Generated at 2022-06-21 08:57:24.875139
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = "john"
    a1 = A()
    assert a1.name == "john"
    a2 = A()
    assert a1.name == "john"
    assert a1 == a2

# Generated at 2022-06-21 08:57:27.303204
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self._a = a

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)

    assert t1 is t2
    assert t1._a == t2._a == 2


# Generated at 2022-06-21 08:57:31.739100
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo():
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    foo1 = Foo("foo1")
    foo2 = Foo("foo2")
    assert foo1 is foo2
    assert foo1.name == "foo1"


# Generated at 2022-06-21 08:57:39.152562
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Spam(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('Creating Spam')

    # Check that only one instance is created
    s1 = Spam()
    s2 = Spam()
    assert s1 == s2

    # Now check that the constructor is only called once
    # This is a little tricky - the print happens on class instantiation on the first line:
    #   __instance = super(Singleton, cls).__call__(*args, **kw)
    # since only one class can be instantiated at a time, we don't have to worry about other
    # threads being in the middle of instantiating spam
    with open('Singleton.py', 'r') as f:
        text = f.read()
    text = text.replace('Creating Spam', '')


# Generated at 2022-06-21 08:57:44.101340
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    value = []

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            value.append(1)

    s1 = SingletonTest()
    s2 = SingletonTest()

    assert s1 == s2
    assert value == [1]

# Generated at 2022-06-21 08:57:45.114368
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-21 08:57:53.694931
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.test_x = x

    s1 = SingletonTest(4)
    s2 = SingletonTest(5)

    assert id(s1) == id(s2)
    assert s1.test_x == 4


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:58:00.005395
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test's Singleton method __call__ using the class SingletonTest (see trailing code)
    # class SingletonTest inherits from the metaclass Singleton.
    # Given the first call to __call__ an instance of SingletonTest is created and returned
    # Given the second call to __call__ the instance previously created is used and returned
    # Expected: the two instances are equal
    singleton1 = SingletonTest()
    singleton2 = SingletonTest()
    assert singleton1 == singleton2 == SingletonTest()


# class SingletonTest inherits from the metaclass Singleton.

# Generated at 2022-06-21 08:58:03.552850
# Unit test for constructor of class Singleton
def test_Singleton():
    instance1, instance2 = Singleton(), Singleton()
    assert instance1 == instance2
    assert isinstance(instance1, Singleton)
    assert isinstance(instance2, Singleton)



# Generated at 2022-06-21 08:58:15.025462
# Unit test for constructor of class Singleton
def test_Singleton():
    '''
    TestCase for the Singleton class
    '''
    class Song(object):
        __metaclass__ = Singleton
        def __init__(self, name, artist, album):
            self.name = name
            self.artist = artist
            self.album = album

        def __str__(self):
            return '%s:%s:%s' % (self.name, self.artist, self.album)

    # Tests
    song1 = Song('Faded', 'Alan Walker', 'Different World')
    song2 = Song('Bad', 'Michael Jackson', 'Bad')
    song3 = Song('Faded', 'Alan Walker', 'Different World')
    song4 = Song('Skyline', 'Alan Walker', 'Different World')

    assert id(song1) == id(song3)

# Generated at 2022-06-21 08:58:16.746444
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

    assert C() is C()


# Generated at 2022-06-21 08:58:20.568801
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    assert TestSingleton(1) is TestSingleton(1)
    assert TestSingleton(0) is TestSingleton(1)


# Unit tests for class Singleton

# Generated at 2022-06-21 08:58:25.317141
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()


# Generated at 2022-06-21 08:58:28.532249
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.parsing.vault import VaultLib
    v = VaultLib()
    v2 = VaultLib()
    assert(v is v2)
    assert(v == v2)

# Generated at 2022-06-21 08:58:31.328590
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass:
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = TestClass()
    assert a is TestClass()

# Generated at 2022-06-21 08:58:37.832655
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.v = 0

    t1 = Test()
    assert t1.v == 0
    t2 = Test()
    assert t1 is t2

    t1.v = 1
    assert t2.v == 1
    t2.v = 2
    assert t1.v == 2



# Generated at 2022-06-21 08:58:46.811520
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 1

    foo = Foo()
    assert(foo.value == 1)
    foo.value += 1
    foo1 = Foo()
    assert(foo1.value == 2)



# Generated at 2022-06-21 08:58:51.837830
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Single(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    single = Single('test')
    assert single.name == 'test'
    single = Single('test2')
    assert single.name == 'test'


# Generated at 2022-06-21 08:59:00.611801
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    from multiprocessing import Process
    from multiprocessing import Queue

    expected = Queue()
    actual = Queue()

    for i in range(100):
        expected.put(i)
        Process(target=A, args=(i,)).start()

    for i in range(100):
        actual.put(A(i).a)

    while not (expected.empty() and actual.empty()):
        assert expected.get(block=False) == actual.get(block=False)

    # This will raise an exception if you have multiple instances of A
    A(a=None)
    A(a=None)

# Generated at 2022-06-21 08:59:06.129992
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.someFrob = 0

    s = Foo()
    assert isinstance(s, Foo)
    s2 = Foo()
    assert isinstance(s2, Foo)
    # both are the same instance
    assert s is s2
    return True

# Generated at 2022-06-21 08:59:12.002051
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestCase(object):
        __metaclass__ = Singleton

        def __init__(self, x=None):
            self.x = x

    test_case_1 = TestCase()
    test_case_2 = TestCase()
    assert test_case_1 == test_case_2
    assert test_case_1 is test_case_2
    test_case_3 = TestCase()
    assert test_case_1 == test_case_3
    assert test_case_1 is test_case_3


# Generated at 2022-06-21 08:59:16.657334
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, a):
            self.a = a
    a1 = A(1)
    a2 = A(2)
    assert a1 == a2
    assert a1.a == a2.a == 1

# Generated at 2022-06-21 08:59:20.429525
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

    obj1 = SingletonTest()
    obj2 = SingletonTest()

    assert id(obj1) == id(obj2)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:59:23.647811
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    Single = Singleton('Single', (object,), {})
    instance_A = Single()
    instance_B = Single()
    assert id(instance_A) == id(instance_B)



# Generated at 2022-06-21 08:59:29.704320
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    a = A(10)
    assert a.value == 10, "The value is not initialized to 10"

    b = A(20)
    assert a.value == 10, "The value is not initialized to 10"
    assert b.value == 10, "The value is not initialized to 10"
    assert b == a, "Singleton a and b didn't generate the same instance"

# Generated at 2022-06-21 08:59:31.071590
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton('Singleton', (), {}) is Singleton('Singleton', (), {})

# Generated at 2022-06-21 08:59:41.959800
# Unit test for constructor of class Singleton
def test_Singleton():
    import os
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()

    bar1 = Bar()
    bar2 = Bar()

    assert id(foo1) == id(foo2), "Foo() should be singleton"
    assert id(bar1) == id(bar2), "Bar() should be singleton"
    assert id(foo1) != id(bar1), "Foo() and Bar() should be different"


# Generated at 2022-06-21 08:59:52.361605
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    import threading

    class ThreadA(threading.Thread):
        def run(self):
            try:
                a = A('B')
            except Exception:
                pass

    class ThreadB(threading.Thread):
        def run(self):
            try:
                a = A('B')
            except Exception:
                pass

    x = ThreadA()
    y = ThreadB()
    x.start()
    y.start()
    x.join()
    y.join()

    assert A('A').name == A('B').name

# Generated at 2022-06-21 08:59:56.977031
# Unit test for constructor of class Singleton
def test_Singleton():
    from copy import copy
    class S(metaclass=Singleton):
        pass

    # check for reference equality
    assert S() is S()

    # check for deep equality
    s1 = S()
    s2 = copy(s1)
    assert s1 == s2 and s2 == s1

    # check for identity equality
    assert id(S()) == id(S())

# Unit tests for constructor of class Singleton using inheritance

# Generated at 2022-06-21 09:00:02.631153
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Arrange
    class A(object):
        __metaclass__ = Singleton

    # Act
    instance = A()
    instance2 = A()
    # Assert
    assert instance == instance2


# Generated at 2022-06-21 09:00:06.170875
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import types

    class C(object):
        __metaclass__ = Singleton

    # c1 and c2 should be singleton
    c1 = C()
    c2 = C()
    assert c1 is c2
    assert type(c1) == C


# Generated at 2022-06-21 09:00:10.824924
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    instance1_must_be_same_as_instance2 = Test()
    instance2_must_be_same_as_instance1 = Test()

    assert id(instance1_must_be_same_as_instance2) == id(instance2_must_be_same_as_instance1)

# Generated at 2022-06-21 09:00:17.154674
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unit.compat.mock import patch

    with patch('ansible.module_utils.six.with_metaclass') as with_metaclass_mock:
        with patch('threading.RLock') as rlock_mock:
            Singleton('test_Singleton__call__', (object,), {})
            with_metaclass_mock.assert_called_once_with(rlock_mock.return_value)