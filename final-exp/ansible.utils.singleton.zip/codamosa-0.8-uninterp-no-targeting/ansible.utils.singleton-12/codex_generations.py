

# Generated at 2022-06-21 08:56:04.428017
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonExample(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    orig = SingletonExample(1, 2)
    assert orig.a == 1
    assert orig.b == 2

    new = SingletonExample(3, 4)
    assert orig is new
    assert new.a == 1
    assert new.b == 2

# Generated at 2022-06-21 08:56:11.444642
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest1(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.__name = 'SingletonTest1'
        def __str__(self):
            return self.__name

    class SingletonTest2(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.__name = 'SingletonTest2'
        def __str__(self):
            return self.__name

    assert SingletonTest1() == SingletonTest1()
    assert SingletonTest2() == SingletonTest2()

    # Make sure different classes are different
    assert SingletonTest1() != SingletonTest2(), \
        'SingletonTest1 != SingletonTest2'


# Generated at 2022-06-21 08:56:21.402130
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingle(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 1

    s1 = TestSingle()
    assert isinstance(s1, TestSingle)
    assert s1.val == 1

    s2 = TestSingle()
    assert s1 is s2
    assert s1.val == 1
    assert s2.val == 1
    s2.val = 5

    s3 = TestSingle()
    assert s1 is s3
    assert s2 is s3
    assert s1.val == 5
    assert s2.val == 5
    assert s3.val == 5


# Generated at 2022-06-21 08:56:25.081133
# Unit test for constructor of class Singleton
def test_Singleton():
    class Singleton0(metaclass=Singleton):
        pass

    a = Singleton0()
    b = Singleton0()
    assert id(a) == id(b)
    return a, b


# Generated at 2022-06-21 08:56:28.959770
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, *args):
            self.args = args

    a = A(1,3,4)
    b = A(3,4,5)
    assert id(a) == id(b), "Fail"

# Generated at 2022-06-21 08:56:35.230708
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            pass

    a = A()
    print("a = A() : {}".format(id(a)))
    b = A()
    print("b = A() : {}".format(id(b)))
    print("a == b : {}".format(a == b))


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 08:56:40.862785
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(with_metaclass(Singleton, object)):
        def __init__(self):
            print("Starting singleton")
    # Start two instances
    a1 = A()
    a2 = A()
    # Check if they point to the same object
    assert(a1 is a2)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:56:42.841080
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert(a1 is a2)



# Generated at 2022-06-21 08:56:47.990546
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(A):
        pass

    x = A()
    y = A()
    assert x is y

    # Two different types derived from A should not be seen as the same
    z = B()
    assert not x is z

# Generated at 2022-06-21 08:56:51.615928
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Singleton_test(object):
        __metaclass__ = Singleton

    a = Singleton_test()
    b = Singleton_test()
    assert a is b



# Generated at 2022-06-21 08:57:00.139488
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 'test'

    t1 = Test()
    t2 = Test()
    assert t1 == t2
    assert t1.a == t2.a == 'test'

    t1.a = 'test1'
    assert t1.a == 'test1'
    assert t2.a == t1.a


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:57:02.491333
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    assert Test() is Test()


# Generated at 2022-06-21 08:57:05.092065
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(Singleton):
        pass
    a = A()
    b = A()
    assert a is b


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:57:08.529341
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    my_singleton = MySingleton()
    assert my_singleton == MySingleton()
    assert my_singleton is MySingleton()


# Generated at 2022-06-21 08:57:10.429150
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    a = Foo()
    b = Foo()
    assert a == b

# Generated at 2022-06-21 08:57:13.268121
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()
    assert test_singleton_1 is test_singleton_2



# Generated at 2022-06-21 08:57:18.702081
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    a = TestSingleton("foo")
    b = TestSingleton("bar")

    assert a is b
    assert a.foo == "bar"

# Generated at 2022-06-21 08:57:23.660053
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x=0):
            self.__x = x

        @property
        def x(self):
            return self.__x

        @x.setter
        def x(self, val):
            self.__x = val

    a = A(100)
    assert (a.x == 100)
    b = A()
    assert (b.x == 100)
    b.x = 200
    assert (b.x == 200)
    assert (a.x == 200)

# Generated at 2022-06-21 08:57:28.821158
# Unit test for constructor of class Singleton
def test_Singleton():
    
    class ClassA(metaclass=Singleton):
        pass

    class ClassB(metaclass=Singleton):
        pass

    print("# test Singleton 1")
    print(ClassA() is ClassA())
    print(ClassB() is ClassB())
    print(ClassA() is not ClassB())

    print("# test Singleton 2")
    print(id(ClassA()))
    print(id(ClassA()))
    print(id(ClassB()))
    print(id(ClassB()))
    print(id(ClassA()) is not id(ClassB()))

    print("# test Singleton 3")
    print(id(ClassA()))
    print(id(ClassB()))
    print(id(ClassA()) is id(ClassB()))



# Generated at 2022-06-21 08:57:31.030498
# Unit test for constructor of class Singleton
def test_Singleton():

    class Test(object):
        __metaclass__ = Singleton

    obj = Test()

    # Test if two classes are equal
    assert obj == Test()

# Generated at 2022-06-21 08:57:39.939780
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import os
    import time
    import unittest

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.pid = os.getpid()

    class TestSingleton(unittest.TestCase):
        def test_Singleton___call__(self):
            # os.getpid() returns the same value when called
            # simultaneously. See also
            # https://stackoverflow.com/q/1113664/3750403
            pid = os.getpid()
            t1 = TestClass()
            t2 = TestClass()
            self.assertTrue(t1 is t2)
            self.assertEqual(t1.pid, pid)
            self.assertEqual(t2.pid, pid)

    unittest.main()



# Generated at 2022-06-21 08:57:51.608297
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from collections import OrderedDict

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.data = OrderedDict()

        def __call__(self, name):
            # print('type(self.data)={}'.format(type(self.data)))
            return self.data.get(name, None)

        def get(self, name):
            return self.data.get(name, None)

        def add(self, name, value):
            self.data[name] = value

        def remove(self, name):
            self.data.pop(name, None)

        def dump(self):
            print(self.data)

    instance = A()
    print('type(instance)={}'.format(type(instance)))
    instance.dump()

# Generated at 2022-06-21 08:57:57.931157
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass():
        pass
    TestClass.__metaclass__ = Singleton
    test_class1 = TestClass()
    test_class1.name = 'test_class1'
    test_class2 = TestClass()
    test_class2.name = 'test_class2'
    assert test_class1.name == 'test_class2'
    assert test_class2.name == 'test_class2'
    assert test_class1 == test_class2



# Generated at 2022-06-21 08:58:05.362804
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    @add_metaclass(Singleton)
    class FooSingleton(object):
        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name

    foo1 = FooSingleton("Singleton1")
    foo2 = FooSingleton("Singleton2")

    assert foo1 is foo2
    assert foo1.get_name() == "Singleton1"
    assert foo2.get_name() == "Singleton1"

# Generated at 2022-06-21 08:58:10.080889
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class _SingletonTest(metaclass=Singleton):
        def __init__(self):
            self.value = 5

    a = _SingletonTest()
    b = _SingletonTest()

    assert a is b
    assert a.value == 5
    assert b.value == 5



# Generated at 2022-06-21 08:58:12.059837
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    assert Foo() == Foo()

# Generated at 2022-06-21 08:58:15.351810
# Unit test for constructor of class Singleton
def test_Singleton():
    class Single(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    s = Single('Ansible')
    assert s.name == 'Ansible'

# Generated at 2022-06-21 08:58:19.129131
# Unit test for constructor of class Singleton
def test_Singleton():
    class SampleClass(Singleton):
        __name = None

        def __init__(self, name):
            self.__name = name

        def get_name(self):
            return self.__name

    sample1 = SampleClass('name')
    sample2 = SampleClass('name')
    assert sample1 is sample2

# Generated at 2022-06-21 08:58:30.713566
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(metaclass=Singleton):
        def __init__(self):
            self.number = 0
        def inc(self):
            self.number += 1
        def get_number(self):
            return self.number

    a = TestClass()
    b = TestClass()
    c = TestClass()
    assert a.get_number() == 0
    assert b.get_number() == 0
    assert c.get_number() == 0
    a.inc()
    assert a.get_number() == 1
    assert b.get_number() == 1
    assert c.get_number() == 1
    b.inc()
    assert a.get_number() == 2
    assert b.get_number() == 2
    assert c.get_number() == 2


# Generated at 2022-06-21 08:58:36.701482
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = True
    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.value == test2.value == True


# Generated at 2022-06-21 08:58:43.016053
# Unit test for constructor of class Singleton
def test_Singleton():
    class ASingleton(object):
        __metaclass__ = Singleton
    a = ASingleton()
    b = ASingleton()
    assert a is b
    assert ASingleton.__dict__['_ASingleton__instance'] is b
    assert ASingleton.__dict__['_ASingleton__rlock'] is None



# Generated at 2022-06-21 08:58:50.906350
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        started = False

        def __init__(self, name):
            self.name = name

        def start(self):
            self.started = True

    instance1 = TestClass('class1')
    instance2 = TestClass('class2')

    assert instance1 is instance2
    assert instance1.name == instance2.name == 'class1'
    assert not instance1.started

    instance1.start()

    assert instance1.started

# Generated at 2022-06-21 08:58:52.698257
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            self.val = 10

    # two instances of class A
    a = A()
    b = A()

    # should be true
    assert a is b
    # and share same value
    assert a.val == b.val



# Generated at 2022-06-21 08:58:54.321924
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.bar = 42

    assert isinstance(Foo(), Foo)
    assert isinstance(Foo(), Foo)

# Generated at 2022-06-21 08:58:57.173439
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Dummy(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    assert Dummy(1) is Dummy(1)
    assert Dummy(1) is Dummy(2)



# Generated at 2022-06-21 08:59:04.608489
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestClass(metaclass=Singleton):
        def __init__(self):
            self.var1 = "something"
            self.var2 = 2

    # Test __call__
    class_instance1 = TestClass()
    assert class_instance1.var1 == "something"
    assert class_instance1.var2 == 2
    assert type(class_instance1) is TestClass
    assert class_instance1 is TestClass()

# Generated at 2022-06-21 08:59:11.446176
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    class Tester(object):
        def __init__(self):
            self.test_class = TestClass('asd')

    test_one = Tester()
    test_two = Tester()
    assert test_one.test_class is test_two.test_class
    assert test_one.test_class.arg == 'asd'
    assert test_two.test_class.arg == 'asd'

# Generated at 2022-06-21 08:59:14.098727
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(metaclass=Singleton):
        pass

    assert TestClass() is TestClass()

# Generated at 2022-06-21 08:59:18.180831
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    s1 = MySingleton()
    s2 = MySingleton()
    assert id(s1) == id(s2)


# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-21 08:59:24.445407
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

    class S2(object):
        __metaclass__ = Singleton

    s = S()
    s2 = S2()

    assert id(s) == id(S())
    assert id(s2) == id(S2())
    assert id(s) != id(s2)

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-21 08:59:31.557754
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()
    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-21 08:59:37.586617
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    import copy

    class SingletonTest(with_metaclass(Singleton)):
        pass

    class TestSingleton(unittest.TestCase):
        def test_singleton(self):
            a1 = SingletonTest()
            a2 = SingletonTest()
            self.assertEqual(id(a1), id(a2))

    unittest.main()



# Generated at 2022-06-21 08:59:45.305160
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("under test_Singleton")

    t1 = Test()
    t2 = Test()
    print(t1)
    print(t2)
    assert t1 is t2


if __name__ == '__main__':
    test_Singleton()


# some decorator
# origin https://github.com/saschagrunert/gig/blob/master/src/gig/decorators.py

# Generated at 2022-06-21 08:59:47.957923
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()
    assert type(TestClass()) is TestClass

# Generated at 2022-06-21 08:59:54.413098
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    class MyClass2(object):
        __metaclass__ = Singleton

    my_object1 = MyClass()
    my_object2 = MyClass()
    my_object3 = MyClass2()
    my_object4 = MyClass2()

    assert my_object1 is my_object2
    assert my_object3 is my_object4
    assert my_object1 is not my_object3

# Generated at 2022-06-21 09:00:03.319721
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Unit test for method __call__ of class Singleton
    """

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def setValue(self, value):
            self.value = value

        def getValue(self):
            return self.value

    instance1 = TestClass()
    assert(instance1.getValue() == 0)
    instance1.setValue(2)
    instance2 = TestClass()
    assert(instance2.getValue() == 2)

# Generated at 2022-06-21 09:00:10.501027
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self,bar=None):
            self.bar = bar

    foo1 = Foo()
    foo2 = Foo()
    foo2.bar = 'FOO!'
    foo3 = Foo()
    foo4 = Foo('bar')
    foo5 = Foo('bar')

    assert foo1.bar == None
    assert foo2.bar == 'FOO!'
    assert foo3.bar == 'FOO!'
    assert foo4.bar == 'bar'
    assert foo5.bar == 'bar'

# Generated at 2022-06-21 09:00:12.425599
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-21 09:00:18.750421
# Unit test for constructor of class Singleton
def test_Singleton():
    #test if constructor creates a single instance
    class SingletonTest(metaclass=Singleton):
        val = 10

    singleton_instance = SingletonTest()
    assert singleton_instance.val == 10
    singleton_instance2 = SingletonTest()
    assert singleton_instance2.val == 10
    singleton_instance.val = 20
    assert singleton_instance2.val == 20