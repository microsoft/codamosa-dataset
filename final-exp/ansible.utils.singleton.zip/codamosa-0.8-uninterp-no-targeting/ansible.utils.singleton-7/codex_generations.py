

# Generated at 2022-06-21 08:56:00.693779
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    assert Foo() is Foo()
    assert id(Foo()) == id(Foo())
    print("Test complete")


# Generated at 2022-06-21 08:56:03.672194
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    instance = TestSingleton()
    assert(instance == TestSingleton())


# Generated at 2022-06-21 08:56:05.307562
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    assert(a == A())

# Generated at 2022-06-21 08:56:10.343527
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton:
        __metaclass__ = Singleton
    Singleton.__instance = None
    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a == b



# Generated at 2022-06-21 08:56:13.326318
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert id(a) == id(b)


# Generated at 2022-06-21 08:56:16.198455
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    t1 = TestClass()
    t2 = TestClass()
    assert t1 is t2



# Generated at 2022-06-21 08:56:23.392630
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a
    test = TestClass(1)
    assert test.a == 1
    test1 = TestClass(2)
    assert test == test1
    assert test.a == 1
    assert test1.a == 1
    test1.a = 2
    assert test.a == 2
    assert test1.a == 2


# Generated at 2022-06-21 08:56:27.336846
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 23

        def get_x(self):
            return self.x

    assert Test().get_x() == Test().get_x()


# Generated at 2022-06-21 08:56:32.113360
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyObject(object):
        __metaclass__ = Singleton

    class MyObject2(object):
        __metaclass__ = Singleton

    obj1 = MyObject()
    # Constructor already called
    obj2 = MyObject()
    assert obj1 == obj2
    obj3 = MyObject2()
    assert obj1 != obj3

# Generated at 2022-06-21 08:56:36.089140
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    # Verify that the same instance of the class is returned each time
    # it is instantiated.
    assert SingletonClass() is SingletonClass()

# Generated at 2022-06-21 08:56:43.685902
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        """
        Test object for Singleton class.
        """
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    a = MyClass(1, 2, 'Hello', {"a": "b"})
    b = MyClass()
    assert a == b
    assert a.args == b.args
    assert a.kwargs == b.kwargs



# Generated at 2022-06-21 08:56:55.070827
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

        def __str__(self):
            return str(self.a)

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

        def __str__(self):
            return str(self.a)

    import threading

    # Make sure we get the same class
    # back each time

    assert Foo(1) == Foo(2)
    assert Bar(3) == Bar(4)

    # Make sure we get the same instance
    # back each time

    assert Foo(1) is Foo(2)
    assert Bar(3) is Bar(4)

    # Make sure each thread gets the

# Generated at 2022-06-21 08:57:05.285554
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from random import randrange
    from time import sleep

    class test(object):
        __metaclass__ = Singleton

    threads = []
    class testThread(threading.Thread):
        def __init__(self, Name, ID):
            threading.Thread.__init__(self)
            self.ID = ID
            self.Name = Name
        def run(self):
            for i in range(10):
                a = test()
                sleep(randrange(1,5))
                print(self.Name + " " + str(self.ID) + " " +str(a))

    for i in range(5):
        threads.append(testThread(str(i), i))
    for t in threads:
        t.start()
    for t in threads:
        t.join()


# Generated at 2022-06-21 08:57:08.395195
# Unit test for constructor of class Singleton
def test_Singleton():
    A = Singleton('A', (), {'a': 3})
    a = A()
    b = A()
    assert (a is b) and (a.a == b.a == 3)


# Generated at 2022-06-21 08:57:10.672873
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Obj(object):
        # Make Obj singleton
        __metaclass__ = Singleton

    obj1 = Obj()
    obj2 = Obj()
    assert obj1 is obj2

# Generated at 2022-06-21 08:57:18.702626
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonObject(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return 'Singleton: %s' % (self.name)

    o1 = SingletonObject('A')
    o2 = SingletonObject('B')
    o3 = SingletonObject('C')

    assert o1.name == o2.name == o3.name
    assert o1 is o2 is o3

# Generated at 2022-06-21 08:57:23.186341
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 'testing'

    test1 = Test()
    test2 = Test()

    assert test1 is test2
    assert test1.value == 'testing'
    assert test2.value == 'testing'

# Generated at 2022-06-21 08:57:26.943356
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.attr = 1

    # First instance of class is returned
    obj1 = Test()
    assert obj1.attr == 1
    # No need to instantiate again, obj2 points to obj1
    obj2 = Test()
    assert obj2.attr == 1
    assert obj1 is obj2
    # Changes to one instance reflects to the other
    obj2.attr = 2
    assert obj1.attr == 2



# Generated at 2022-06-21 08:57:31.453032
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self, val):
            self.val = val

    x = MyClass(4)
    y = MyClass(5)

    assert x.val == 4
    assert y.val == 4
    assert x is y


# Generated at 2022-06-21 08:57:33.683363
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        pass
    a = Test()
    b = Test()
    assert a is b

#

# Generated at 2022-06-21 08:57:43.481934
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    class_1 = TestClass('first')
    class_2 = TestClass('second')

    assert id(class_1) == id(class_2)
    assert class_1.name == class_2.name

    class_1.name = 'new'
    assert class_1.name == 'new'
    assert class_1.name == class_2.name


# Generated at 2022-06-21 08:57:49.674922
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self._a = a
            self._b = b

    mc1 = MyClass('a', 'b')
    mc2 = MyClass('x', 'y')

    assert mc1 == mc2
    assert MyClass.__instance == mc1


# Generated at 2022-06-21 08:57:52.536147
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo_1 = Foo()
    foo_2 = Foo()
    assert foo_1 is foo_2


# Generated at 2022-06-21 08:57:58.658424
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self._value = 1

        def get_value(self):
            return self._value

    a = TestClass()
    b = TestClass()

    assert(a == b)
    assert(a is b)
    assert(a.get_value() == 1)


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-21 08:58:04.001959
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 123

    for i in range(10):
        b1 = B()
        b2 = B()
        assert b1.a == 123
        assert b2.a == 123
        assert b1 is b2

# Generated at 2022-06-21 08:58:07.307561
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()

    assert t1 is t2



# Generated at 2022-06-21 08:58:12.812319
# Unit test for constructor of class Singleton
def test_Singleton():
    class Dog(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    dog1 = Dog("Juno")
    dog2 = Dog("Clover")
    assert dog1 == dog2
    assert dog1 is dog2
    assert dog1.name == "Juno"
    assert dog2.name == "Juno"

# Generated at 2022-06-21 08:58:14.173131
# Unit test for constructor of class Singleton
def test_Singleton():
    a = Singleton()
    b = Singleton()
    assert a == b

# Generated at 2022-06-21 08:58:22.501679
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, value=0):
            self.value = value

        def increment(self):
            self.value = self.value + 1

    assert A.__instance is None

    a = A ()
    assert a is not None
    assert A.__instance is not None
    assert a is A.__instance

    # Calling __call__ on A directly
    a2 = A.__call__()
    assert a2 is not None
    assert a2 is a
    assert a2 is A.__instance

    # Calling __call__ on a singleton subclass of A
    class B(A):
        pass

    b = B ()
    assert b is not None
    assert b is a
    assert b is A.__instance
    assert b is B

# Generated at 2022-06-21 08:58:27.010112
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.prop = "prop_val"

    t1 = TestClass()
    t2 = TestClass()
    assert t1 is t2 and t1.prop == t2.prop


# Generated at 2022-06-21 08:58:32.473523
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingleton2(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()
    assert TestSingleton2() is TestSingleton2()
    assert TestSingleton() is not TestSingleton2()

# Generated at 2022-06-21 08:58:40.084111
# Unit test for constructor of class Singleton
def test_Singleton():
    import unittest

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 0

    class TestSingletonTestCase(unittest.TestCase):
        def test_test_singleton(self):
            t1 = TestSingleton()
            t2 = TestSingleton()

            self.assertTrue(t1 is t2)

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-21 08:58:43.060169
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        pass

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 == foo2

# Generated at 2022-06-21 08:58:47.046993
# Unit test for constructor of class Singleton
def test_Singleton():
    """Test for Singleton class."""
    class Test(object):
        """Test for Singleton class."""
        __metaclass__ = Singleton

    test_0 = Test()
    test_1 = Test()

    assert test_0 == test_1

# Generated at 2022-06-21 08:58:56.889776
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    def test_Singleton___call__inner():
        import types
        import unittest

        class TestSingleton(object):
            __metaclass__ = Singleton

            def __init__(self):
                self.foo = 1

        class TestUnSingleton(object):
            def __init__(self):
                self.foo = 1

        class SingletonTestCase(unittest.TestCase):
            def setUp(self):
                self.test_singleton_1 = TestSingleton()
                self.test_singleton_2 = TestSingleton()
                self.test_unsingleton_1 = TestUnSingleton()
                self.test_unsingleton_2 = TestUnSingleton()

            def tearDown(self):
                pass


# Generated at 2022-06-21 08:58:59.645841
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert(Test() == Test())

# Generated at 2022-06-21 08:59:04.909325
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    o1 = C(5)
    o2 = C(10)
    assert o1.x == 5
    assert o2.x == 5
    assert o1 is o2


# Generated at 2022-06-21 08:59:11.382721
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self._value = None

        def set_value(self, value):
            self._value = value

        def get_value(self):
            return self._value

    # Test if the same instance is returned
    instance_one = MyClass()
    instance_one.set_value(True)
    instance_two = MyClass()
    assert instance_one is instance_two
    assert instance_two.get_value() == True



# Generated at 2022-06-21 08:59:23.936205
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SimpleClass(object):
        __metaclass__ = Singleton
        def __init__(self, value=0):
            self._value = value

    a = SimpleClass()
    b = SimpleClass()
    assert b is a, "a and b are the same instances"
    assert b._value == 0, "the value is zero by default"
    a._value = 1
    assert b._value == 1, "the value is updated when a._value is updated"
    c = SimpleClass(2)
    assert c is a, "c and a are the same instances"
    assert a._value == 2, "the value is updated when a is instantiated"
    assert b._value == 2, "the value is updated when a is instantiated"

# Generated at 2022-06-21 08:59:27.029327
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(metaclass=Singleton):
        def __init__(self):
            self.a = 1

    assert id(SingletonTest()) == id(SingletonTest())



# Generated at 2022-06-21 08:59:34.791025
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class X(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    # Create two instances of class X
    x = X(1)
    y = X(2)

    # There is only one instance of class X
    assert id(x) == id(y)
    assert x.a == y.a
    assert x.a == 2



# Generated at 2022-06-21 08:59:40.641757
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2, "a1 and a2 should be the same instance."


if __name__ == '__main__':
    from ansible.module_utils.basic import *  # noqa

    test_Singleton()

# Generated at 2022-06-21 08:59:42.763896
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 == a2

# Generated at 2022-06-21 08:59:47.146298
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    class B(A):
        pass

    assert A() is A()
    assert not A() is B()


# This class is not a real test, but a simple demo usage of Singleton

# Generated at 2022-06-21 08:59:51.264513
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a1 = A()
    a2 = A()

    assert a1 == a2


# Generated at 2022-06-21 08:59:57.075315
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_value = False

        def set_test_value(self):
            self.test_value = True

    test_class_one = TestClass()
    test_class_one.set_test_value()

    test_class_two = TestClass()
    assert test_class_one is test_class_two
    assert isinstance(test_class_two, TestClass)
    assert test_class_one.test_value is True

# Generated at 2022-06-21 09:00:03.837029
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton1 = Singleton('singleton1', (object,), {})
    singleton2 = Singleton('singleton2', (object,), {})
    assert singleton1.__class__ == singleton2.__class__
    assert singleton1.__dict__ == singleton2.__dict__

test_Singleton()

# Generated at 2022-06-21 09:00:05.146493
# Unit test for constructor of class Singleton
def test_Singleton():
    SC = Singleton('test', (), {})
    SC('test')
    return SC

# Generated at 2022-06-21 09:00:09.446787
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    s1 = TestSingleton(1)
    s2 = TestSingleton(2)
    assert s1 is s2
    assert s1.x == 1
    assert s2.x == 1

# Generated at 2022-06-21 09:00:16.394017
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''Assert that calling the same class creates only one instance.'''
    class TestClass1(with_metaclass(Singleton, object)):
        def __init__(self, *args, **kwargs): pass

    class TestClass2(with_metaclass(Singleton, object)):
        def __init__(self, *args, **kwargs): pass

    assert TestClass1.__call__() is TestClass1.__call__()
    assert TestClass2.__call__() is TestClass2.__call__()

    assert TestClass1.__call__() is not TestClass2.__call__()


# Generated at 2022-06-21 09:00:25.732201
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.num = 0

    t1 = Test()
    t1.num = 1
    t2 = Test()
    t3 = Test()
    print(t1, t1.num)
    print(t2, t2.num)
    print(t3, t3.num)
    print(t1 is t2, t1 is t3)
    print(id(t1), id(t2), id(t3))

##############################################################################
# EOF
##############################################################################

# Generated at 2022-06-21 09:00:27.485897
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        pass

    a = TestSingleton()
    b = TestSingleton()

    assert a is b

# Generated at 2022-06-21 09:00:33.178794
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread
    from time import sleep

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            sleep(0.1)

    T1 = Thread(target=TestClass)
    T2 = Thread(target=lambda: T1.start())
    T1.start()
    T2.start()

    T1.join()
    T2.join()

# Generated at 2022-06-21 09:00:38.500859
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    t1 = TestClass("bar")
    t2 = TestClass("not_bar")

    print(t1.foo)
    # "bar"
    print(t2.foo)
    # "bar"

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:00:42.356913
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("TestSingleton constructor called")

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 == test2

# Generated at 2022-06-21 09:00:45.045493
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    assert MySingleton() is MySingleton()

# Generated at 2022-06-21 09:00:51.976736
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x
            pass

    a = A(0)
    b = A(1)
    assert a is not None
    assert b is not None
    assert a is b
    assert a.x == 0
    assert b.x == 1
    print("Pass test for method __call__ of class Singleton")

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-21 09:00:54.118093
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    obj1 = SingletonTest()
    obj2 = SingletonTest()
    assert obj1 is obj2



# Generated at 2022-06-21 09:00:56.248149
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class test(object):
        __metaclass__ = Singleton

    assert test() is test()
    #test.__instance = None
    #assert test() is not test()

# Generated at 2022-06-21 09:01:01.322666
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()   # instantiate Foo, and that the only one
    foo2 = Foo()

    if foo1 is not foo2:
        raise Exception("Foo1 is not Foo2! __call__ failed.")


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-21 09:01:08.561554
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = Foo()
    b = Foo()
    assert a == b


# Generated at 2022-06-21 09:01:12.566664
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    obj1 = TestSingleton("obj1")
    obj2 = TestSingleton("obj2")

    assert obj1.name == "obj1"
    assert obj2.name == "obj1"

# Generated at 2022-06-21 09:01:15.037911
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    s = TestSingleton()
    assert(s is TestSingleton())

# Generated at 2022-06-21 09:01:17.710661
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()

    assert id(a) == id(b)



# Generated at 2022-06-21 09:01:18.889820
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Test(metaclass=Singleton):
        pass

    assert Test() is Test()

# Generated at 2022-06-21 09:01:23.331264
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class my_singleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = my_singleton(5)
    assert a.value is 5
    b = my_singleton(6)
    assert b.value is 5

# Generated at 2022-06-21 09:01:35.105604
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    test name: test_Singleton___call__

    test Singleton.__call__ method
    """
    class Test:
        """
        simple class to test Singleton.__call__ method
        """
        def __init__(self, a):
            """
            initialize class
            """
            self.a = a

    expected_prefix = "testSingleton___call__"
    class TestSingleton(Test, metaclass=Singleton):
        """
        test class that inherit from Test and use Singleton Metaclass
        """
        def __init__(self, a):
            """
            initialize class
            """
            super(TestSingleton, self).__init__(expected_prefix + a)
    object_expected = TestSingleton("1")
    object_returned = TestSingleton("2")

# Generated at 2022-06-21 09:01:39.110106
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = None

    t1 = Test()
    t2 = Test()

    assert t1 is t2
    assert t1.a is None

if __name__ == '__main__':
    test_Singleton()
    print("Success")

# Generated at 2022-06-21 09:01:43.393672
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Singleton does not implement __call__, so create a dummy class
    class DummySingleton(object):
        __metaclass__ = Singleton

    assert DummySingleton() is DummySingleton()
    assert DummySingleton() is not None


# Generated at 2022-06-21 09:01:54.282190
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, val=1):
            self.val = val

    class TestClass2(object):
        __metaclass__ = Singleton

        def __init__(self, val=2):
            self.val = val

    test_obj1 = TestClass()
    assert test_obj1.val == 1, "Singleton.__call__() method 1/2 failed"
    test_obj2 = TestClass()
    assert test_obj1 is test_obj2, "Singleton.__call__() method 2/2 failed"

    test_obj3 = TestClass2()
    assert test_obj3.val == 2, "Singleton.__call__() method 3/4 failed"
    test_obj4 = TestClass2()
   

# Generated at 2022-06-21 09:02:07.001992
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        pass

    f1 = Foo()
    f2 = Foo()
    assert f1 is f2



# Generated at 2022-06-21 09:02:11.122628
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 'foo'
        def print_x(self):
            print(self.x)

    foo = Foo()
    bar = Foo()
    foo.print_x()
    bar.print_x()
    assert(foo is bar)



# Generated at 2022-06-21 09:02:18.487480
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()

    assert a1 is a2
    assert b1 is b2
    assert a1 is not b1

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 09:02:23.286837
# Unit test for constructor of class Singleton
def test_Singleton():
    class singleton_class(object):
        __metaclass__ = Singleton

        def __init__(self):
            import uuid
            self.pid = uuid.uuid1()

    singleton = singleton_class()
    test_id = singleton.pid

    for x in range(0, 10):
        singleton = singleton_class()
        assert singleton.pid == test_id

# Generated at 2022-06-21 09:02:27.500732
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    assert A() is A()
    assert A() is not B()
    assert B() is B()

# Generated at 2022-06-21 09:02:32.355802
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    f0 = Foo('zero')
    assert f0
    assert f0.name == 'zero'
    f1 = Foo('one')
    assert f1 is f0
    assert f1.name == 'zero'
    assert f1.name == f0.name

# Generated at 2022-06-21 09:02:37.104473
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a = Foo("a")
    b = Foo("b")

    assert a is b
    assert a.a == b.a == "a"


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 09:02:40.954367
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    m = MyClass()
    m2 = MyClass()
    assert m == m2
    assert m is m2


# Generated at 2022-06-21 09:02:43.339263
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    x = TestSingleton()
    y = TestSingleton()

    assert x is y

# Generated at 2022-06-21 09:02:45.459108
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert(id(a1) == id(a2))

# Generated at 2022-06-21 09:03:09.731204
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object, metaclass=Singleton):
        def __init__(self):
            super(MySingleton,self).__init__()
            print("Init singleton class")

    ms1 = MySingleton()
    ms2 = MySingleton()

    assert(ms1 == ms2)

# Generated at 2022-06-21 09:03:14.253896
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo:
        __metaclass__ = Singleton

    class Bar(Foo):
        pass

    assert Foo() is not None
    assert Foo() is Foo()
    assert Foo() is Bar()
    assert Bar() is Bar()

# Generated at 2022-06-21 09:03:21.777711
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread, Lock
    from time import sleep

    class MyClass(object):
        def __init__(self, name):
            self.name = name

    class MyClassSingleton(MyClass):
        __metaclass__ = Singleton

    def test():
        for i in range(10):
            my_class = MyClassSingleton("toto")
            print("{0}: {1}".format(i, my_class.name))

    t1 = Thread(target=test)
    t2 = Thread(target=test)
    t1.start()
    t2.start()
    t1.join()
    t2.join()

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 09:03:23.690132
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

    c1 = C()
    c2 = C()
    assert(c1 is c2)



# Generated at 2022-06-21 09:03:31.702821
# Unit test for constructor of class Singleton
def test_Singleton():
    class ClassFoo(object):
        __metaclass__ = Singleton

    class ClassBar(object):
        __metaclass__ = Singleton

    obj_foo_a = ClassFoo()
    obj_foo_b = ClassFoo()
    obj_bar_a = ClassBar()
    obj_bar_b = ClassBar()

    # Check if helper method (Singleton) works
    assert obj_foo_a is obj_foo_b, 'Singleton method not working!'
    assert obj_bar_a is obj_bar_b, 'Singleton method not working!'
    assert obj_bar_a is not obj_foo_b, 'Singleton method not working!'
    assert obj_foo_a is not obj_bar_b, 'Singleton method not working!'

    # Check if class Foo has a singleton
    assert Class

# Generated at 2022-06-21 09:03:38.966000
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.vault import VaultLib
    class TestSingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self, param1, param2):
            self.param1 = param1
            self.param2 = param2

    vault_secrets = dict(foo='bar', baz='qux')

    # Test 1: default behavior
    obj = TestSingletonClass(param1=1, param2=2)
    assert obj
    assert obj.param1 == 1
    assert obj.param2 == 2

    obj2 = TestSingletonClass(param1=3, param2=4)
    assert obj2
    assert obj2 == obj
    assert obj2.param1 == 1

# Generated at 2022-06-21 09:03:42.538143
# Unit test for constructor of class Singleton
def test_Singleton():
    from foo import Foo
    from bar import Bar

    foo1 = Foo()
    assert foo1 == Foo()

    # Bar isn't a singleton instance
    bar1 = Bar()
    assert bar1 != Bar()

# Generated at 2022-06-21 09:03:51.427593
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    class MyClass2(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    my_object = MyClass(0)
    assert my_object.val == 0

    my_object = MyClass(5)
    assert my_object.val == 0

    my_object2 = MyClass2(6)
    assert my_object2.val == 6

    my_object2 = MyClass2(7)
    assert my_object2.val == 6

# Generated at 2022-06-21 09:03:57.210726
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    class TestSub(Test):
        def __init__(self, x):
            self.x = x+1
        pass

    assert Test(1).x == 1, "Test singleton construction"
    assert Test(2).x == 1, "Test singleton construction"
    assert TestSub(1).x == 2, "Test singleton construction"
    assert TestSub(2).x == 2, "Test singleton construction"

# Generated at 2022-06-21 09:04:00.792814
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    inst1 = A()
    inst2 = A()
    assert inst1 is inst2


# Generated at 2022-06-21 09:04:52.771791
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    print(MySingleton.__instance)
    print(MySingleton.__rlock)

    i1 = MySingleton(1)
    print(i1)
    print(MySingleton.__instance)
    print(id(MySingleton.__instance))

    i2 = MySingleton(2)
    print(i2)
    print(MySingleton.__instance)
    print(id(MySingleton.__instance))

    i3 = MySingleton(3)
    print(i3)
    print(MySingleton.__instance)
    print(id(MySingleton.__instance))

    class MySubSingleton(MySingleton):
        pass

    i4

# Generated at 2022-06-21 09:04:55.971843
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self):
            pass

    a = Test()
    b = Test()
    assert a is b



# Generated at 2022-06-21 09:04:58.814225
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class NotSingleton(object):
        __metaclass__ = Singleton

    a = NotSingleton()
    b = NotSingleton()
    assert(a == b)



# Generated at 2022-06-21 09:05:01.046728
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        pass

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 == test2
    assert test1 is test2

# Generated at 2022-06-21 09:05:04.328430
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = "bar"

    test1 = Test()
    test2 = Test()
    # Check that singleton indeed works
    assert test1 is test2
    assert test1.foo == test2.foo == "bar"



# Generated at 2022-06-21 09:05:09.391077
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase
    from contextlib import contextmanager

    @contextmanager
    def get_lock(lock):
        try:
            lock.acquire()
            yield lock
        finally:
            lock.release()

    class MockLock(object):
        def __init__(self, is_locked=False):
            self.is_locked = is_locked

        def acquire(self):
            if self.is_locked:
                raise AssertionError('Trying to acquire a locked lock')
            self.is_locked = True

        def release(self):
            if not self.is_locked:
                raise AssertionError('Trying to release an unlocked lock')
            self.is_locked = False


# Generated at 2022-06-21 09:05:10.718596
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton is Singleton, "The same instance must be returned."

# Generated at 2022-06-21 09:05:19.228146
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1():
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    class Test2():
        __metaclass__ = Singleton

        def __init__(self, arg, arg2):
            self.arg = arg
            self.arg2 = arg2

    a = Test1('arg')
    assert(a.arg == 'arg')
    b = Test1('arg')
    assert(b.arg == 'arg')
    assert(a is b)

    c = Test2('arg', 'arg2')
    assert(c.arg == 'arg')
    assert(c.arg2 == 'arg2')
    d = Test2('arg', 'arg2')
    assert(d.arg == 'arg')

# Generated at 2022-06-21 09:05:28.878532
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible_collections.misc.tests.unit.compat.six.moves import mock

    # Set up the class object with an instance of the class
    cls = Singleton('Test_Singleton', (object,), {})
    cls.__instance = cls
    new_cls = Singleton('Test_Singleton', (object,), {})

    # Test that the current instance is returned
    with mock.patch.object(Singleton, '__call__') as mock_Singleton___call__:
        with mock.patch.object(cls, '__rlock') as mock_instance___rlock:
            mock_instance___rlock.__enter__.return_value = mock.MagicMock()
            new_cls.__call__()

# Generated at 2022-06-21 09:05:35.034538
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # define singleton class Test
    class Test(object):
        __metaclass__ = Singleton
        pass
    # import the threading module for using threading.Lock()
    import threading
    # add threading.Lock() for class Test
    Test.__lock = threading.Lock()
    # define method A for class Test
    def A(self):
        print("A")
    # add __A for class Test
    Test.__A = A
    # create an instance of class Test
    test1 = Test()
    # acquire lock for class Test
    with test1.__lock:
        # call method __A of class Test
        test1.__A()
        # set method A of class Test as method __A
        test1.A = test1.__A
        # call method A of class Test
        test1