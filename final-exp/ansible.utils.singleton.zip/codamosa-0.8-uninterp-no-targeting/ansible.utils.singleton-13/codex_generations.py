

# Generated at 2022-06-21 08:56:03.376341
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        pass

    class B(object):
        __metaclass__ = Singleton
        pass

    a1 = A()
    a2 = A()
    b = B()

    assert a1 == a2
    assert a1 != b


# Generated at 2022-06-21 08:56:05.821549
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.id = 1
    a = TestClass()
    b = TestClass()
    assert a == b
    assert a.id == b.id

# Generated at 2022-06-21 08:56:11.351203
# Unit test for constructor of class Singleton
def test_Singleton():
    class testSingleton(object):
        __metaclass__ = Singleton
    testSingleton1 = testSingleton()
    testSingleton2 = testSingleton()
    assert testSingleton1 is testSingleton2
    assert id(testSingleton1) == id(testSingleton2)

# Generated at 2022-06-21 08:56:18.792370
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.s = "A"

    assert id(A()) == id(A())
    assert id(A()) != id(A()) #False

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.s = "B"

    assert id(B()) == id(B())
    assert id(B()) != id(B()) #False



# Generated at 2022-06-21 08:56:30.049651
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):

        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    class TestSingletonChild(TestSingleton):

        def __init__(self, arg, arg2):
            TestSingleton.__init__(self, arg)
            self.arg2 = arg2

    class TestSingletonGrandchild(TestSingletonChild):

        def __init__(self, arg, arg2, arg3):
            TestSingletonChild.__init__(self, arg, arg2)
            self.arg3 = arg3

    obj1 = TestSingleton('foo')
    assert obj1.arg == 'foo'
    assert str(obj1) == '<__main__.TestSingleton object at 0x%x>' % id(obj1)

   

# Generated at 2022-06-21 08:56:33.498912
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    try:
        A() == A()
    except:
        return False
    else:
        return True



# Generated at 2022-06-21 08:56:36.136701
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    a = Foo()
    b = Foo()

    assert a is b


# Generated at 2022-06-21 08:56:39.518314
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestingSingleton(metaclass=Singleton):
        pass
    instance1 = TestingSingleton()
    instance2 = TestingSingleton()
    assert instance1 is instance2

# Generated at 2022-06-21 08:56:43.657693
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A():
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    a = A()
    a2 = A()

    assert a.x == 1
    assert a2.x == 1
    assert a is a2

    a.x = 2
    assert a.x == 2
    assert a2.x == 2



# Generated at 2022-06-21 08:56:50.351686
# Unit test for constructor of class Singleton
def test_Singleton():
    '''
    if Singleton is working fine, then __call__ of Singleton
    should always return the same instance.
    '''
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a = MySingleton()
    assert id(a) == id(MySingleton())


# Generated at 2022-06-21 08:56:56.287471
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a=0):
            self.a = a
            print("A: " + str(self.a))

    A(10)
    A(20)
    A(30)

# Generated at 2022-06-21 08:56:59.467067
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    assert Foo(42).value == 42
    assert Foo('bar').value == 'bar'
    assert Foo('bar') is Foo(42)



# Generated at 2022-06-21 08:57:01.918950
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingleTest(metaclass=Singleton):
        pass

    s1 = SingleTest()
    s2 = SingleTest()

    assert id(s1) == id(s2)

# Generated at 2022-06-21 08:57:11.197395
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class X(object):
        __metaclass__ = Singleton
        def __init__(self, a=None, b=None):
            self.a = a
            self.b = b

    # Instantiate two objects.  They should point to the same instance
    if X(1,2) is not X(1,2):
        raise Exception("Singleton didn't return the same instance")

    if X(1,2).a != 1:
        raise Exception("Singleton didn't return the instance with correct value for 'a'")

    if X(1,2).b != 2:
        raise Exception("Singleton didn't return the instance with correct value for 'b'")

    if X(3,4).a != 1:
        raise Exception("Singleton didn't return the instance with correct value for 'a'")


# Generated at 2022-06-21 08:57:21.809633
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread
    class TestObj:
        __metaclass__ = Singleton

    def Singleton_check(i):
        t = TestObj()
        if i % 5 == 0:
            print("deleting instance")
            del t
        else:
            print("obtaining instance")
            # should never be None
            assert(t is not None)
        return True

    thread_num = 20
    threads = []
    for i in range(1, thread_num):
        t = Thread(target=Singleton_check, args=(i,))
        threads.append(t)
        t.start()
    for t in threads:
        t.join()
    print("%d threads run without issues" % thread_num)

# Generated at 2022-06-21 08:57:28.598997
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test_str = 'test string'

    test_obj1 = Test()
    test_obj2 = Test()

    assert test_obj1 is test_obj2
    assert test_obj1.test_str == 'test string'
    assert test_obj2.test_str == 'test string'


# Generated at 2022-06-21 08:57:30.813777
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass

    a1 = A()
    a2 = A()

    assert(a1 is a2)

# Generated at 2022-06-21 08:57:33.412654
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTestClass(object):
        __metaclass__ = Singleton

    instance1 = SingletonTestClass()
    instance2 = SingletonTestClass()
    assert instance1 == instance2

# Generated at 2022-06-21 08:57:35.157561
# Unit test for constructor of class Singleton
def test_Singleton():
    class Tester(object):
        __metaclass__ = Singleton
    p = Tester()
    q = Tester()
    assert p is q

# Generated at 2022-06-21 08:57:44.620839
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, v):
            self.v = v

    s1 = Singleton("TestSingleton", tuple(), dict())
    s2 = Singleton("TestSingleton", tuple(), dict())
    s3 = s1("value")
    s4 = s2("another value")

    assert isinstance(s1, Singleton)
    assert isinstance(s2, Singleton)
    assert isinstance(s3, TestSingleton)
    assert isinstance(s4, TestSingleton)
    assert s3 is s4
    assert s3.v == s4.v

# Generated at 2022-06-21 08:57:49.363211
# Unit test for constructor of class Singleton
def test_Singleton():
    class Widget(object):
        __metaclass__ = Singleton

    w1 = Widget()
    w2 = Widget()
    assert w1 == w2



# Generated at 2022-06-21 08:57:55.562981
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 'bar'

    #print(MySingleton())

    s1 = MySingleton()
    s2 = MySingleton()
    print(s1)
    print(s2)
    print(s1.foo)
    print(s2.foo)
    print(s1 is s2)


# Generated at 2022-06-21 08:57:57.982414
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    test_obj1 = TestClass()
    test_obj2 = TestClass()
    assert test_obj1 is test_obj2


# Generated at 2022-06-21 08:58:02.108594
# Unit test for constructor of class Singleton
def test_Singleton():
    class T(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a
    i = T(2)
    j = T(10)
    # Test that __init__ is called only once
    assert i.a == 10
    assert i is j

# Generated at 2022-06-21 08:58:09.750858
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    # Check that this always return the same instance
    t1 = Test(1)
    t2 = Test(1)
    assert t1 == t2

    # Check that this destroys and creates a new instance
    del t1
    del t2
    t1 = Test(2)
    t2 = Test(2)
    assert t1 == t2

# Generated at 2022-06-21 08:58:16.074047
# Unit test for constructor of class Singleton
def test_Singleton():
    class single(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.num = 0

        def add_num(self):
            self.num += 1

    a = single()
    a.add_num()
    assert a.num == 1

    b = single()
    b.add_num()
    assert b.num == 2

    assert a is b
    assert a.num == b.num

# Generated at 2022-06-21 08:58:23.536356
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import types

    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name
            self.x = 0

        def __len__(self):
            return 5

    foo1 = Foo('Test')
    foo2 = Foo('Test')
    assert foo1.name == foo2.name
    assert foo1 is foo2
    assert 5 == len(foo1)
    assert isinstance(Foo.__call__, types.MethodType)



# Generated at 2022-06-21 08:58:32.442006
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1
            self.lock = RLock()

        def incx(self):
            with self.lock:
                self.x += 1

            return self.x

    a = A()
    b = A()
    assert a == b
    assert isinstance(a, A)
    assert isinstance(b, A)
    assert a is b
    assert a.x == 1
    assert b.x == 1

    a.incx()
    assert a is b
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-21 08:58:43.054936
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.num = 1

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.num = 2

    a1 = A()
    a2 = A()

    b1 = B()
    b2 = B()

    print("a1:", a1)
    print("a2:", a2)
    print("b1:", b1)
    print("b2:", b2)

    print("a1.num:", a1.num)
    print("a2.num:", a2.num)
    print("b1.num:", b1.num)
    print("b2.num:", b2.num)

   

# Generated at 2022-06-21 08:58:49.149845
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Setup
    class TestSingleton(object):
        __metaclass__ = Singleton
    x = TestSingleton()
    # Test
    assert x == TestSingleton(), "expected instance to equal TestSingleton()"
    assert TestSingleton() == x, "expected TestSingleton() to equal instance"
    assert x is TestSingleton(), "expected instance to be TestSingleton()"


# Generated at 2022-06-21 08:58:52.410004
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test:
        __metaclass__ = Singleton

        def __init__(self, i):
            self.i = i

    t1 = Test("1")
    t2 = Test("2")

    assert t1 is t2
    assert t1.i == "1"
    assert t2.i == "1"

# Generated at 2022-06-21 08:58:53.284247
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-21 08:58:55.522414
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert id(t1) == id(t2)

# Generated at 2022-06-21 08:58:59.425436
# Unit test for constructor of class Singleton
def test_Singleton():
    class DerivedSingleton(object):
        __metaclass__ = Singleton

    first_instance = DerivedSingleton()
    second_instance = DerivedSingleton()
    assert(first_instance == second_instance)

# Generated at 2022-06-21 08:59:03.458349
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    assert S(1) == S(1)
    assert S(1) == S(2)

# Generated at 2022-06-21 08:59:09.586059
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # First, test __call__
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    assert A(1) == A(2)
    assert A.__instance.x == 2


# Generated at 2022-06-21 08:59:18.356693
# Unit test for constructor of class Singleton
def test_Singleton():
    a = Singleton()
    print(a)
    a.a = 1
    b = Singleton()
    print(b)
    b.b = 2
    print(a.a)
    print(b.b)
    print(a.b)
    print(b.a)
    b.a = 3
    a.b = 4
    print(a.a)
    print(b.b)
    print(a.b)
    print(b.a)
    assert (a.b == 4)
    assert (b.a == 3)
    assert (a is b)


# Generated at 2022-06-21 08:59:28.622140
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Sample(object):
        __metaclass__ = Singleton
        def __init__(self):
            self._attr = None

        def _get_attr(self):
            return self._attr

        def _set_attr(self, attr):
            self._attr = attr

        attr = property(_get_attr, _set_attr)

    obj1 = Sample()
    obj1.attr = value1 = "sample attribute"

    obj2 = Sample()
    assert obj1 is obj2, "ob1 and obj2 should be the same object"
    assert obj2.attr == value1, "obj2.attr should be the same as obj1.attr"

    obj2.attr = value2 = "another sample attribute"

# Generated at 2022-06-21 08:59:31.912006
# Unit test for constructor of class Singleton
def test_Singleton():
    class testClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.number = None

    classObj = testClass()
    classObj.number = 1
    classObj2 = testClass()
    assert classObj is classObj2
    assert classObj2.number == 1

# Generated at 2022-06-21 08:59:34.700781
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    MySingleton()
    MySingleton()


# vim:set sw=4 ts=4 et:

# Generated at 2022-06-21 08:59:40.643329
# Unit test for constructor of class Singleton
def test_Singleton():
    class test_class(object):
        __metaclass__ = Singleton

    c1 = test_class()
    c2 = test_class()

    assert c1 is c2

# Generated at 2022-06-21 08:59:45.970639
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        pass

    x = A()
    assert x is A()

    class B(A):
        pass

    y = B()
    assert y is B()
    assert y is not A(), 'B() should be a new instance'

    assert x is A()
    assert y is B()
    assert x is not y

# Generated at 2022-06-21 08:59:51.463578
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
    test1 = Test()
    test2 = Test()
    assert test1 is test2

    class Test2(object):
        __metaclass__ = Singleton
    test3 = Test2()
    assert test1 is not test3
    assert test2 is not test3

# Generated at 2022-06-21 08:59:55.838202
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

    x = Bar()
    y = Bar()
    assert x is y

    x = Foo()
    y = Foo()
    assert x is y

    x = Bar()
    y = Foo()
    assert x is not y

# Generated at 2022-06-21 09:00:02.246235
# Unit test for constructor of class Singleton
def test_Singleton():
    class Tmp(object):
        __metaclass__ = Singleton
        def __init__(self,x):
            self.x=x
    a1=Tmp(1)
    a2=Tmp(2)

    assert(a1.x == a2.x)

# Generated at 2022-06-21 09:00:07.406239
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    a = A(name='spam')
    assert a.name == 'spam'
    b = A(name='eggs')
    assert id(a) == id(b)
    assert a.name == b.name
    assert a == b


# Generated at 2022-06-21 09:00:15.166370
# Unit test for constructor of class Singleton
def test_Singleton():
    # Define some class
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x=1, y=2):
            self.x = x
            self.y = y

    # Use the class with non-default parameters
    a = A(3, 4)

    # If there is already an instance, call it again
    b = A()

    # a and b must be the same object
    assert id(a) == id(b)

    # and both have the attributes from the first __call__
    assert a.x == 3
    assert b.x == 3
    assert a.y == 4
    assert b.y == 4



# Generated at 2022-06-21 09:00:19.257600
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    instance1 = TestSingleton("foo", "bar")
    instance2 = TestSingleton("foo", "bar")

    assert instance1 is instance2  # Compare the 2 instances
    assert instance1.a == 'foo'
    assert instance1.b == 'bar'