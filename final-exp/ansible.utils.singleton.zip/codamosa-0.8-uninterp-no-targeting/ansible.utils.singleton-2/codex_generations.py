

# Generated at 2022-06-21 08:56:01.963200
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, param):
            self.param = param

    for i in range(10):
        ts = TestSingleton('blah')
        _ts = TestSingleton('blah')
        assert ts == _ts

# Generated at 2022-06-21 08:56:04.471400
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    t1 = Foo()
    t2 = Foo()

    assert t1 == t2
    assert t1 is t2

# Generated at 2022-06-21 08:56:16.198107
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            super(SingletonClass, self).__init__()
            self.key1 = kwargs.get('key1', 'value1')
            self.key2 = kwargs.get('key2', 'value2')

    cls = SingletonClass()  # First instance creation
    assert cls.key1 == 'value1'
    assert cls.key2 == 'value2'

    cls = SingletonClass(key1='value3', key2='value4')  # Second instance creation
    assert cls.key1 == 'value1'
    assert cls.key2 == 'value2'

# Generated at 2022-06-21 08:56:22.361826
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a1 = A("name_a1")  # call __call__
    a2 = A("name_a2")  # not call __call__
    assert(a1.name == a2.name)
    assert(a1 is a2)


# Generated at 2022-06-21 08:56:23.702978
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    assert MySingleton() is MySingleton()

# Generated at 2022-06-21 08:56:28.438738
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    call_count = 0
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            global call_count
            call_count += 1

    a = SingletonTest()
    b = SingletonTest()
    assert a == b
    assert call_count == 1


# Generated at 2022-06-21 08:56:35.480715
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, a, b, c=1):
            self.__a = a
            self.__b = b
            self.__c = c

        def __str__(self):
            return ('a={0}, b={1}, c={2}'.format(self.__a, self.__b, self.__c))

    assert(TestClass('test', 'test') == TestClass('test', 'test'))

# Generated at 2022-06-21 08:56:41.426742
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 10
    a1 = A()
    a2 = A()
    assert(a1 is a2)
    assert(a1.value == a2.value)
    a1.value = 3
    assert(a1.value == a2.value)


# Generated at 2022-06-21 08:56:53.535912
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    This function is created to test the Singleton class.
    """
    class TestClass(object):
        """
        This class is created to test the Singleton class.
        """
        __metaclass__ = Singleton

        def __init__(self, arg):
            TestClass.arg = arg

    class TestClass2(object):
        """
        This class is created to test the Singleton class.
        """
        __metaclass__ = Singleton

    try:
        # Creating 2 instances of TestClass and TestClass2.
        obj1 = TestClass(2)
        obj2 = TestClass(4)
        obj3 = TestClass2()
    except Exception as exception:
        print(exception)
        # If creating multiple instances raises an exception, then the test fails.
        assert False

# Generated at 2022-06-21 08:57:01.174084
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

        def display(self):
            print(self.arg1 + self.arg2)

    a1 = MyClass('a1', 'a2')
    a2 = MyClass('a1', 'a2')
    assert(a1 == a2)
    b1 = MyClass('b1', 'b2')
    b2 = MyClass('b1', 'b2')
    assert(b1 == b2)
    assert(a1 == b1)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 08:57:06.634177
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert MyClass() is MyClass()
    assert MyClass()


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:57:09.715565
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton
        pass

    A = C()
    B = C()
    assert id(A) == id(B)


# Generated at 2022-06-21 08:57:12.693240
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 42

    a = A()
    assert id(a) == id(A())
    assert a.x == 42


# Generated at 2022-06-21 08:57:21.665539
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    s1 = SingletonClass('1')
    s2 = SingletonClass('2')
    assert s1 == s2

    class SingletonClass2(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    s3 = SingletonClass2('3')
    s4 = SingletonClass2('4')
    assert s3 == s4
    assert s1 != s3

# Generated at 2022-06-21 08:57:24.152169
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert a == b

# Generated at 2022-06-21 08:57:26.447813
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import time

    class MyClass(metaclass=Singleton):
        def __init__(self):
            self.check_time()

        def check_time(self):
            self.ctime = time.ctime()

    m = MyClass()
    assert m.ctime is not None



# Generated at 2022-06-21 08:57:30.644345
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("Init called")
    a = TestClass()
    b = TestClass()
    assert(a == b)

# Generated at 2022-06-21 08:57:33.253757
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    test1 = Test()
    test2 = Test()

    assert test1 is test2, "__call__ of Singleton class should return the same object reference."

# Generated at 2022-06-21 08:57:35.891891
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global obj_b
    obj_b = Singleton_C("Test")
    assert obj_b.attribute == "Test"
    obj_c = Singleton_C("Abc")
    assert obj_c.attribute == "Abc"


# Generated at 2022-06-21 08:57:47.837425
# Unit test for constructor of class Singleton
def test_Singleton():
    class A:
        __metaclass__ = Singleton

        def __init__(self):
            self.name = "A"

    class B:
        __metaclass__ = Singleton

        def __init__(self):
            self.name = "B"

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()

    assert a1.name == a2.name, "Singleton class A did not return the same instance"
    assert b1.name == b2.name, "Singleton class B did not return the same instance"
    assert a1.name == "A", "Singleton class A did not initialize properly"
    assert b1.name == "B", "Singleton class B did not initialize properly"

# Generated at 2022-06-21 08:57:57.416814
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)

    assert id(a1) == id(a2), "Singleton metaclass is not working"

if (__name__ == '__main__'):
    test_Singleton()

# Generated at 2022-06-21 08:58:08.874445
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2=None, arg3=None):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3

    # test initial creation
    s1 = SingletonClass('first', 'second', 'third')
    assert s1.arg1 == 'first'
    assert s1.arg2 == 'second'
    assert s1.arg3 == 'third'

    # test second creation
    s2 = SingletonClass('second arg', arg3='third arg')
    assert s2 is s1
    assert s1.arg1 == 'first'
    assert s1.arg2 == 'second'
    assert s1.arg3 == 'third'


__all__

# Generated at 2022-06-21 08:58:11.476442
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Singleton_test(metaclass=Singleton):
        pass

    s = Singleton_test('ABC')
    assert s == Singleton_test('ABC')



# Generated at 2022-06-21 08:58:19.317705
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyObj(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kw):
            self.args = args
            self.kw = kw

    obj1 = MyObj(1, 2, 3, one=1, two=2, three=3)
    obj2 = MyObj('one', 'two')

    assert obj1 == obj2
    assert obj1.args == (1, 2, 3)
    assert obj1.kw['three'] == 3
    assert obj2.args == ('one', 'two')
    assert 'three' not in obj2.kw

# Generated at 2022-06-21 08:58:30.122683
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_class = getattr(Singleton, '__call__')
    assert singleton_class is not None
    class TestClass(metaclass=Singleton):
        def __init__(self, x, y):
            self.x = x
            self.y = y

    assert TestClass(1, 2).x == 1 == TestClass().x
    assert TestClass(4, 5).y == 5 == TestClass().y
    assert TestClass(1, 2).y == 5 == TestClass().y
    assert TestClass(4, 5).x == 1 == TestClass().x

    a = TestClass(1, 2)
    b = TestClass(3, 4)
    assert a == b
    assert a is b

# Generated at 2022-06-21 08:58:32.855757
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton
        def __init__(self, v=0):
            self.v = v

    a, b = C(1), C()
    assert a == b
    assert a.v == 1



# Generated at 2022-06-21 08:58:37.094242
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    # class A should have one instance only
    a1 = A()
    a2 = A()
    assert(a1 is a2)

# Generated at 2022-06-21 08:58:41.829169
# Unit test for constructor of class Singleton
def test_Singleton():
    if __name__ == "__main__":
        class A(object):
            __metaclass__ = Singleton

        class B(A):
            pass

        a = A()
        b = B()

        assert a == b and isinstance(a, A) and isinstance(b, B)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 08:58:45.206377
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a1 = A()
    a2 = A()
    assert a1 == a2

# Generated at 2022-06-21 08:58:48.116308
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.instance = 'instance'
    assert Foo().instance == 'instance'

# Generated at 2022-06-21 08:58:55.958306
# Unit test for constructor of class Singleton
def test_Singleton():
    class Singleton_Class(object):
        __metaclass__ = Singleton
        def __init__(self, param1):
            self.param1 = param1
    c1 = Singleton_Class("param1")
    c2 = Singleton_Class("param2")
    assert c1 == c2

# Generated at 2022-06-21 08:59:03.305648
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2):
            self.arg_test = arg1
            self.arg_test2 = arg2

    a1 = A(1, 2)
    a2 = A(3, 4)

    assert a1 is a2
    assert a1.arg_test == 1
    assert a1.arg_test2 == 2

# Generated at 2022-06-21 08:59:08.309176
# Unit test for constructor of class Singleton
def test_Singleton():
    class Kls(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg


    i1 = Kls('foo')
    i2 = Kls('bar')
    assert i1 is i2
    assert i1.arg != 'bar'



# Generated at 2022-06-21 08:59:11.318733
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, param1):
            self.param = param1

    a = A(1)
    b = A(2)

    assert a.param is 1
    assert a.param is b.param

# Generated at 2022-06-21 08:59:15.430457
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            self.name = "Singleton class"
    a = A()
    print(a.name)

test_Singleton()

# Generated at 2022-06-21 08:59:21.454211
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''
       >> from ansible.utils.singleton import Singleton
       >> class TestClass(object):
       ..     __metaclass__ = Singleton
       ..     def __init__(self, name):
       ..         self.name = name
       ..
       >> t1 = TestClass('test')
       >> t2 = TestClass('test')
       >> print(t1 == t2)
       True
    '''
    pass

# Generated at 2022-06-21 08:59:22.450152
# Unit test for constructor of class Singleton
def test_Singleton():

    class TestSingleton(metaclass=Singleton):
        pass

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-21 08:59:27.814619
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Singleton test class
    class STestClass:
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 1

    test1 = STestClass()
    assert test1.value == 1
    test1.value = 2

    test2 = STestClass()
    assert test2.value == 2
    assert id(test1) == id(test2)


# Generated at 2022-06-21 08:59:33.087332
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingleInstance(object):
        __metaclass__ = Singleton

        def __init__(self, **kw):
            self.kw = kw

        def __repr__(self):
            return self.kw.__repr__()

    foo1 = SingleInstance(foo="bar")
    foo2 = SingleInstance(foo="bar")
    assert foo1 is foo2

    baz1 = SingleInstance(baz="qux")
    baz2 = SingleInstance(baz="qux")
    assert baz1 is baz2

    assert foo1 is not baz1



# Generated at 2022-06-21 08:59:43.121237
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create class with Singleton as Metaclass
    class OnlyOne(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.number = 1

    # Define some args
    args = ('good', 'luck')
    kwargs = {'run': 'fast'}

    # Create first instance
    instance_a = OnlyOne(*args, **kwargs)
    assert instance_a.number == 1

    # Create second instance
    instance_b = OnlyOne(*args, **kwargs)
    assert instance_b.number == 1

    # Check that there is only one instance
    assert id(instance_a) == id(instance_b)



# Generated at 2022-06-21 08:59:53.977667
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1
    a = A()
    b = A()
    assert a == b
    assert a.x == b.x
    a.x = 2
    assert a.x == b.x

# Generated at 2022-06-21 09:00:05.526688
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.attribute = 'A'

    class B(A):
        def __init__(self):
            self.attribute = 'B'

    # Check that A and B are not the same object
    assert A() is not B()

    # Check that the result of Singleton is the same object
    assert A() is A()
    assert B() is B()

    # Check that A is an instance of A
    assert isinstance(A(), A)

    # Check that B is an instance of A
    assert isinstance(B(), A)

    # Check that A is not an instance of B
    assert not isinstance(A(), B)

    # Check that B is an instance of B
    assert isinstance(B(), B)



# Generated at 2022-06-21 09:00:14.857844
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.msg = "This is singleton instance"
            self.count = 0
            self.lock = RLock()

        def increaseCount(self):
            with self.lock:
                self.count += 1

        def getCount(self):
            return self.count

        def printMsg(self):
            print(self.msg)

    instance1 = TestSingleton()
    instance1.increaseCount()
    instance2 = TestSingleton()
    instance2.increaseCount()
    instance2.increaseCount()

    print("Count of the instances:")
    print("instance1: {}".format(instance1.getCount()))
    print("instance2: {}".format(instance2.getCount()))

# Generated at 2022-06-21 09:00:18.454242
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton:
        __metaclass__ = Singleton

    class TestSingletonAnother:
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a == b

    c = TestSingletonAnother()
    assert a != c


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:00:24.366059
# Unit test for constructor of class Singleton
def test_Singleton():
    name = 'Singleton'

    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton
        name = name

    class C(object):
        __metaclass__ = Singleton
        name = name

    b_instance = B()
    c_instance = C()

    # A should always be a new instance
    assert A() is not A()

    # B and C should be the same instance
    assert B.name is C.name

    # B and C should be the same instance
    assert B.name is C.name

    # Test that we can use the class to instantiate an instance as usual
    assert b_instance is B()
    assert c_instance is C()
    assert b_instance is B.__instance

    # Verify that the same instances

# Generated at 2022-06-21 09:00:28.275518
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass:
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 'bar'

    my_class_1 = MyClass()
    my_class_2 = MyClass()

    assert my_class_1 is my_class_2
    assert my_class_1.foo == my_class_2.foo

# Generated at 2022-06-21 09:00:34.192177
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    s1 = TestSingleton(1)
    s2 = TestSingleton(1)
    assert s1 == s2
    assert s1 is s2

    s3 = TestSingleton(2)
    assert s1 is not s3
    assert s2 is not s3

# Generated at 2022-06-21 09:00:37.371972
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = None

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-21 09:00:45.691937
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase

    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 0

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.b = 0

    class TestSingleton(TestCase):
        def test_singleton(self):
            a = A()
            self.assertIs(a, A())

            b = B()
            self.assertIs(b, B())

            self.assertIsNot(a, b)

# Generated at 2022-06-21 09:00:54.637320
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Tests that Singleton always returns the same object
    from ansible.release import __version__, __author__
    from ansible.release import __copyright__, __license__
    from ansible.release import __title__, __url__

    # Create singletons and test __call__ method
    # (__title__, __url__) is a tuple, thus we don't test it
    # (__version__) returns a string, thus we test it separately

# Generated at 2022-06-21 09:01:08.736518
# Unit test for constructor of class Singleton
def test_Singleton():
    from Singleton import Singleton
    from unittest import TestCase, main

    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, x=None):
            self.x = x

    class SingletonTest(TestCase):
        def test_Singleton(self):
            m1 = MyClass(1)
            m2 = MyClass(2)
            m3 = MyClass(3)

            self.assertEqual(m1.x, 1)
            self.assertEqual(m2.x, 1)
            self.assertEqual(m3.x, 1)

    main()

# Generated at 2022-06-21 09:01:14.019991
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1(metaclass=Singleton):
        def __init__(self):
            self.a = 10

    class Test2(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 20

    obj1 = Test1()
    obj2 = Test1()
    assert(obj1 is obj2)

    obj3 = Test2()
    obj4 = Test2()
    assert(obj3 is obj4)

# Generated at 2022-06-21 09:01:17.641382
# Unit test for constructor of class Singleton
def test_Singleton():
    # define a class
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    # Instantiate class and run test
    obj1 = MyClass()
    obj2 = MyClass()
    
    assert(obj1==obj2)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:01:23.878987
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    class OtherTest(object):
        __metaclass__ = Singleton

    foo = Test('foo')
    bar = Test('bar')
    baz = OtherTest()
    assert foo.name == 'bar'
    assert bar.name == 'bar'
    assert foo is bar
    assert foo is not baz
    assert bar is not baz

# Generated at 2022-06-21 09:01:31.304152
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    # 1. Test instantiation of singleton
    test_instance = TestSingleton()
    assert type(test_instance) is TestSingleton, "Singleton should be TestSingleton type"

    # 2. Test repeated calls to TestSingleton returns the same instance
    test_instance_2 = TestSingleton()
    assert test_instance is test_instance_2, "Instances should be the same"

# Generated at 2022-06-21 09:01:35.774190
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class MySingleton(object):
        __metaclass__ = Singleton

    class Subclass(MySingleton):
        pass

    assert MySingleton() is MySingleton()
    assert Subclass() is MySingleton()
    assert Subclass() is Subclass()
    assert MySingleton() is not Subclass()

# Generated at 2022-06-21 09:01:38.227884
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Mocks
    class BaseSingleton(object):
        __metaclass__ = Singleton
    base_singleton_1 = BaseSingleton()

    # Test
    assert base_singleton_1 == BaseSingleton()

# Generated at 2022-06-21 09:01:49.049421
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.id = id(self)
            self.attr = 'attr'

    class B(metaclass=Singleton):
        def __init__(self, n):
            self.id = n

    a1 = A()
    a2 = A()

    assert a1.id == a2.id
    assert a2.attr == 'attr'

    b1 = B(0)
    b2 = B(1)

    assert b1.id == 0
    assert b2.id == 0

    assert a1 is not a2

    # The assertion below fails because the __call__ method of the Singleton
    # metaclass creates the instance of B only with arguments that are necessary
    # to create a unique instance. In this case, because

# Generated at 2022-06-21 09:01:56.806538
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            pass

    class B(metaclass=Singleton):
        def __init__(self):
            pass

    class C(A):
        def __init__(self):
            pass

    assert(A() is A())
    assert(A() is A())

    assert(B() is B())
    assert(B() is B())

    assert(C() is C())
    assert(C() is C())

    assert(C() is A())
    assert(A() is C())

    assert(C() is not B())

# Generated at 2022-06-21 09:01:58.168513
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass():
        __metaclass__ = Singleton

    pass

# Generated at 2022-06-21 09:02:10.151455
# Unit test for constructor of class Singleton
def test_Singleton():
    class foo(object):
        __metaclass__ = Singleton

    o1 = foo()
    o2 = foo()
    o3 = foo()
    assert o1 == o2 == o3

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 09:02:12.902464
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo:
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value
    a = Foo('a')
    b = Foo('b')
    assert a is b
    assert a.value == 'a'

# Generated at 2022-06-21 09:02:20.482664
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import wrap_var

    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, bar, baz):
            self.bar = bar
            self.baz = baz

    foo = Foo(bar=True, baz=False)
    assert isinstance(foo, Foo)
    assert foo.bar
    assert not foo.baz

    foo2 = Foo()
    assert foo is foo2

# Generated at 2022-06-21 09:02:23.440688
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    one = TestSingleton()
    two = TestSingleton()
    assert(one is two)


# Generated at 2022-06-21 09:02:25.979974
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    t1 = Time()
    t2 = Time()
    assert t1 == t2
    assert id(t1) == id(t2)


# Generated at 2022-06-21 09:02:30.529987
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, x, y):
            self.x = x
            self.y = y
    f1 = Foo(1,1)
    f2 = Foo(2,2)
    assert(f1.x == f2.x)
    assert(f1.y == f2.y)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 09:02:34.600525
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, x=0):
            self.x = x

    s = SingletonTest(1)
    assert s.x == 1
    s = SingletonTest()
    assert s.x == 1

# Generated at 2022-06-21 09:02:39.387916
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingletonSubclass(TestSingleton):
        def __init__(self):
            TestSingleton.__init__(self)

    inst = TestSingleton()
    inst_sub = TestSingletonSubclass()

    assert inst is inst_sub

# Generated at 2022-06-21 09:02:46.519221
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class MySingletonClass(metaclass=Singleton):
        def __init__(self):
            self.name = 'MySingletonClass'

    # If a class is a singleton, then the __call__ method of its metaclass
    # should always return the same object.
    #
    # If not, the above unit test will fail.
    class TestSingleton___call__(unittest.TestCase):
        def test(self):
            obj1 = MySingletonClass()
            obj2 = MySingletonClass()
            self.assertEqual(id(obj1), id(obj2))

    unittest.main()

# Generated at 2022-06-21 09:02:50.160709
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)

    assert t1 is t2

# Generated at 2022-06-21 09:03:12.291803
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
    # initialize the first time
    obj1 = Test()
    assert obj1 is Test()
    # set instance to None
    Test.__instance = None
    assert obj1 is Test()


# Generated at 2022-06-21 09:03:18.967526
# Unit test for constructor of class Singleton
def test_Singleton():
    class S (metaclass=Singleton):
        def __init__(self, v=0):
            self.v = v
        def get_v(self):
            return self.v

    s1 = S(1)
    s2 = S(2)

    assert(id(s1) == id(s2))
    assert(s1.get_v() == 1)
    assert(s2.get_v() == 1)


# Unit test DataPipe

# Generated at 2022-06-21 09:03:26.910705
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 42

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 43


    foo1 = Foo()
    foo2 = Foo()

    bar1 = Bar()
    bar2 = Bar()

    assert foo1.value == 42
    assert foo2.value == 42

    assert bar1.value == 43
    assert bar2.value == 43

    assert id(foo1) == id(foo2)
    assert id(bar1) == id(bar2)

    assert id(foo1) != id(bar1)


if __name__ == "__main__":
    from pprint import pprint
    from sys import version_

# Generated at 2022-06-21 09:03:32.231287
# Unit test for constructor of class Singleton
def test_Singleton():
    class myclass(metaclass=Singleton):
        def __init__(self, a=None, b=None):
            self.a = a
            self.b = b

    m1 = myclass('a', 'b')
    m2 = myclass('c', 'd')
    assert m1 is m2
    assert m1.a == 'a'
    assert m1.b == 'b'
    assert m2.a == 'a'
    assert m2.b == 'b'

# Generated at 2022-06-21 09:03:39.218099
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, data):
            self.data = data

    # Create a new instance of TestClass
    t = TestClass('test')
    print(TestClass.__instance.data)

    # Attempt to create another instance of TestClass, but changing the
    # data that is passed in.
    t2 = TestClass('test2')

    # The instance of TestClass should have stayed the same
    print(TestClass.__instance.data)


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 09:03:44.540881
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, num):
            self.num = num

    t = Test(1)
    assert t.num == Test(2).num
    assert Test(3).num == Test(4).num
    assert Test(5).num == Test(6).num

# Generated at 2022-06-21 09:03:48.382078
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class MyClass(object):
        __metaclass__ = Singleton

    # We don't care about these arguments
    args = []
    kwargs = {}

    assert MyClass() is MyClass(*args, **kwargs)



# Generated at 2022-06-21 09:03:52.606549
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(metaclass=Singleton):
        def __init__(self):
            super(C, self).__init__()
            self.x = 5

    x = C()
    y = C()
    assert x is y
    assert x.x == y.x == 5
    y.x = 6
    assert y.x == x.x == 6
    assert y is x

# Generated at 2022-06-21 09:03:55.005402
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-21 09:03:58.879299
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    t1 = TestClass(1)
    t2 = TestClass(2)
    assert t1 == t2
    assert t1.value == 1


# Generated at 2022-06-21 09:04:37.583093
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2

# Generated at 2022-06-21 09:04:39.787906
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = A()
    b = A()
    assert a is b



# Generated at 2022-06-21 09:04:48.162137
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTestAbstract(metaclass=Singleton):
        def __init__(self,value):
            self.value = value

    class SingletonTest(SingletonTestAbstract):
        def __init__(self,value):
            self.value = value

    a = SingletonTest('first')
    assert(a.value == 'first')
    b = SingletonTest('second')
    assert(b == a)
    assert(b.value == 'first')


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 09:04:51.485030
# Unit test for constructor of class Singleton
def test_Singleton():

    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert (a is b)

    a.test = 1
    assert (a.test == b.test)



# Generated at 2022-06-21 09:04:57.984872
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self._value = value

        @property
        def value(self):
            return self._value

    obj1 = TestClass('foo')
    obj2 = TestClass('bar')

    assert obj1.value == obj2.value



# Generated at 2022-06-21 09:05:03.580466
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 'A'
    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 'B'
    a = A()
    b = B()
    assert a == A()
    assert b == B()
    assert a != B()
    assert a.x == 'A'
    assert b.x == 'B'

# Test __call__
test_Singleton___call__()



# Generated at 2022-06-21 09:05:06.311634
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    a = A()
    b = B()
    assert a is not None
    assert a is A()
    assert b is not None
    assert b is B()


# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-21 09:05:10.082773
# Unit test for constructor of class Singleton
def test_Singleton():
    class foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class bar(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    # check if both foo and bar are singleton
    f1 = foo()
    f2 = foo()
    b1 = bar()
    b2 = bar()

    assert f1 is f2
    assert b1 is b2
    assert f1 is not b1
    assert f2 is not b2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:05:12.876333
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import warnings
    warnings.simplefilter("error")

    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-21 09:05:17.399692
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a1 = A()
    # Make sure the instance of A is not None
    assert a1 is not None
    a2 = A()
    # Make sure the instance of A is same as the first instance
    assert a1 == a2
