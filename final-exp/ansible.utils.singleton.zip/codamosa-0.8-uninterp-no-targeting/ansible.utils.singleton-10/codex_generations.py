

# Generated at 2022-06-21 08:56:05.094779
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class X(metaclass=Singleton):
        def __init__(self):
            super(X, self).__init__()
            self.x = 0


    x1 = X()
    x2 = X()
    assert x1 is not None
    assert x2 is not None
    assert x1 == x2
    x1.x = 999
    assert x2.x == 999
    x2.x = 888
    assert x1.x == 888

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-21 08:56:08.792838
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()
    assert id(A()) == id(A())



# Generated at 2022-06-21 08:56:13.479322
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    class B(object):
        __metaclass__ = Singleton

    assert A() is A()
    assert A() is not B()
    assert B() is B()
    assert B() is not A()

# Generated at 2022-06-21 08:56:17.536774
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestingSingleton(object):
        __metaclass__ = Singleton

    a = TestingSingleton()
    b = TestingSingleton()
    c = TestingSingleton()
    assert id(a) == id(b) and id(a) == id(c)



# Generated at 2022-06-21 08:56:28.816460
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonA(metaclass=Singleton):
        def __init__(self):
            self.a = 0

    A1 = SingletonA()
    assert isinstance(A1, SingletonA)
    assert A1.a == 0

    # This will actually create a new instance,
    # but it's not accessible from the outside
    A1.a = 1
    A1.b = 2
    A2 = SingletonA()
    assert A2.a == 0
    assert not hasattr(A2, 'b')

    # Class variables are shared between all instances
    SingletonA.a = -1
    assert A1.a == -1
    assert A2.a == -1

    # Set the class variable only on one instance.
    # Note that this will make this class variable unavailable on the others
    A

# Generated at 2022-06-21 08:56:30.920791
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    assert Foo() is Foo()

# Generated at 2022-06-21 08:56:38.242893
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    i1 = TestSingleton(1)
    i2 = TestSingleton(2)
    i3 = TestSingleton(3)

    assert i1 == i2
    assert i2 == i3
    assert i1 == i3
    assert i1.val == 1
    assert i2.val == 1
    assert i3.val == 1

# Generated at 2022-06-21 08:56:39.811666
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(metaclass=Singleton): pass
    
    assert X() == X()
    assert X() is X()

# Generated at 2022-06-21 08:56:42.840051
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            print ("init")

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2



# Generated at 2022-06-21 08:56:47.564487
# Unit test for constructor of class Singleton
def test_Singleton():
    class Skuba(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            print("Skuba: " + name)

    s1 = Skuba('name1')
    s2 = Skuba('name2')
    assert s1 is s2

# Generated at 2022-06-21 08:56:54.223569
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class SingletonTest(object):
        __metaclass__ = Singleton

    s1 = SingletonTest('s1')
    s2 = SingletonTest('s2')

    assert s1.__dict__['kwargs'] == 's1'
    assert s2.__dict__['kwargs'] == 's1'


# Generated at 2022-06-21 08:56:57.128111
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object, metaclass=Singleton):
        def __init__(self):
            print("TestSingleton__init__")

    test_obj = TestSingleton()
    assert test_obj == TestSingleton()

# Generated at 2022-06-21 08:57:01.743762
# Unit test for constructor of class Singleton
def test_Singleton():
    class SampleClass(object):
        __metaclass__ = Singleton

    # Instantiate a single class
    sc1 = SampleClass()
    # Get another instance of sc1
    sc2 = SampleClass()

    assert sc1 == sc2


# Generated at 2022-06-21 08:57:05.464397
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    x = A(1)
    y = A(2)

    assert x is y
    assert x.a == y.a == 1

# Generated at 2022-06-21 08:57:07.807155
# Unit test for constructor of class Singleton
def test_Singleton():
    class Thing(object):
        __metaclass__ = Singleton
    first_thing = Thing()
    assert first_thing is Thing()

# Generated at 2022-06-21 08:57:15.377820
# Unit test for constructor of class Singleton
def test_Singleton():
    """
    Testing constructor of class Singleton
    """
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, x=0):
            self.x = x

    # create new object
    a = MyClass()
    # check object's state
    if ((a.x != 0)):
        raise TypeError("Wrong object initialization")
    # create another object
    b = MyClass(x=1)
    # check object's state again
    if ((b.x != 0)):
        raise TypeError("Wrong object initialization")
    # check if both are the same
    if ((a is not b)):
        raise TypeError("Different object instantiation")

# Generated at 2022-06-21 08:57:26.950439
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''
    Test the Singleton.__call__() method.
    '''

    class Foo(object):
        '''Class for testing Singleton.__call__()'''
        __metaclass__ = Singleton

        def __init__(self, bar):
            self.bar = bar

    from threading import Thread
    INSTANCE_VALUE = 42

    # Instantiate class Foo with a sample value
    instance = Foo(INSTANCE_VALUE)

    class TestThread(Thread):
        """Thread class for testing instance consistency
        across the threads.
        """
        def __init__(self):
            Thread.__init__(self)
            self.result = None

        def run(self):
            """Method run() of thread
            """
            self.result = Foo().bar

    nthreads = 1000

# Generated at 2022-06-21 08:57:30.001613
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert (a is b)

# Generated at 2022-06-21 08:57:33.951557
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 == a2

# Generated at 2022-06-21 08:57:44.620623
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Class1(object):
        __metaclass__ = Singleton

    class Class2(object):
        __metaclass__ = Singleton

    class1_inst_1 = Class1()
    class1_inst_2 = Class1()
    class2_inst_1 = Class2()
    class2_inst_2 = Class2()
    assert class1_inst_1 == class1_inst_2
    assert class2_inst_1 == class2_inst_2
    assert class1_inst_1 != class2_inst_1
    assert class1_inst_1 != class2_inst_2
    assert class1_inst_2 != class2_inst_1
    assert class1_inst_2 != class2_inst_2
    assert class1_inst_1 == class1_inst_1

# Generated at 2022-06-21 08:57:52.536345
# Unit test for constructor of class Singleton
def test_Singleton():
    class OnlyOne(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert(OnlyOne() is OnlyOne())

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 08:57:57.786199
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        # when a class uses the metaclass Singleton, the metaclass
        # initializes the class with itself
        # this class just passes that initialization on to the superclass
        # but we need a dummy class to instantiate so we can test
        # that it is actually a Singleton
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()



# Generated at 2022-06-21 08:57:59.982661
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    foo1 = Test()
    foo2 = Test()

    assert foo1 is foo2

# Generated at 2022-06-21 08:58:11.518733
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        def __init__(self, num):
            self.num = num
            print(">>>Foo.__init__(%s)" % num)

        def add_num(self, num):
            return self.num + num

    #Initialize the class Foo
    f1 = Foo(1)
    print("f1.num: %d" % f1.num)

    #Get the reference of class Foo again
    f2 = Foo(2)
    print("f2.num: %d" % f2.num)

    #Check if f1 and f2 have the same reference
    print("f1 == f2 : %s" % (f1 is f2))

    #Check if the address of f1 and f2 is the same

# Generated at 2022-06-21 08:58:13.674351
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from nose.plugins.skip import SkipTest
    raise SkipTest('TODO: Implement this test')


# Generated at 2022-06-21 08:58:22.027243
# Unit test for constructor of class Singleton
def test_Singleton():
    # Creating class that inherits from Singleton
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    # Creating the object TestSingleton1
    firstInstance = TestSingleton("TestSingleton1")
    print("first instance name: %s" % firstInstance.name)

    # Creating the object TestSingleton2
    secondInstance = TestSingleton("TestSingleton2")
    print("second instance name: %s" % secondInstance.name)
    print("first instance name: %s" % firstInstance.name)

    # Check if the same instance
    if id(firstInstance) == id(secondInstance):
        print("Same instance")
    else:
        print("Different instance")

# Generated at 2022-06-21 08:58:25.487980
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a mock class
    class MySingletonMock(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = 'test_Singleton___call__'

    # Call constructor
    s1 = MySingletonMock()
    assert s1 is not None

    # Call constructor a second time, should return the first one
    s2 = MySingletonMock()
    assert s1 is s2

# Generated at 2022-06-21 08:58:34.512080
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

        @classmethod
        def reset_state(cls):
            cls.__instance = None

    x = MyClass(1, 2)
    y = MyClass(3, 4)
    assert x is y
    assert y.a == 1
    assert y.b == 2

    MyClass.reset_state()
    y = MyClass(3, 4)
    assert y.a == 3
    assert y.b == 4

# Generated at 2022-06-21 08:58:38.339972
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TEST(object):
        __metaclass__ = Singleton
    TEST1 = TEST()
    TEST2 = TEST()
    assert TEST1 is TEST2
    return True


# Generated at 2022-06-21 08:58:40.823600
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = Foo()
    b = Foo()
    assert a is b

# Generated at 2022-06-21 08:58:51.737915
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg=None):
            super(TestClass, self).__init__()
            self.arg = arg

    assert TestClass() == TestClass()

    obj1 = TestClass("one")
    obj2 = TestClass("two")

    assert obj1 == obj2
    assert obj1.arg == "one"
    assert obj2.arg == "one"

# Generated at 2022-06-21 08:58:52.698341
# Unit test for constructor of class Singleton
def test_Singleton():
    assert isinstance(Singleton(), Singleton)

# Generated at 2022-06-21 08:58:59.596938
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase
    from modules.plugins.clicrd.common.singleton import Singleton
    from modules.plugins.clicrd.common.singleton import TestSingleton

    class TestSingleton(TestCase):
        """Tests for methods of class Singleton"""
        def test_Singleton___call___one_instance(self):
            """Unit test for method __call__: one instance"""
            instance1 = TestSingleton()
            instance2 = TestSingleton()

            self.assertEqual(id(instance1), id(instance2))

        def test_Singleton___call___two_instances(self):
            """Unit test for method __call__: two instances"""
            instance1 = TestSingleton()
            instance2 = TestSingleton()
            instance3 = TestSingleton()
            instance4 = TestSingleton

# Generated at 2022-06-21 08:59:03.621440
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class a(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("a")

    a()
    a()
    a()
    a()
    a()


# Generated at 2022-06-21 08:59:07.117171
# Unit test for constructor of class Singleton
def test_Singleton():
    '''
    Test constructor of class Singleton
    '''
    class OnlyOne(metaclass=Singleton):
        '''
        Unit test class for Singleton
        '''
        pass

    obj1 = OnlyOne()
    obj2 = OnlyOne()

    assert obj1 == obj2
    assert id(obj1) == id(obj2)

# Generated at 2022-06-21 08:59:09.712974
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert(t1 == t2)

# Generated at 2022-06-21 08:59:16.557497
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import random

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, y=None):
            self.y = y

    a = TestSingleton()
    b = TestSingleton()
    c = TestSingleton(y=random.randint(1, 1000))
    d = TestSingleton()

    assert a == b
    assert b == c
    assert c == d

# Generated at 2022-06-21 08:59:18.695140
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object):
        """Test implementation of Singleton"""
        __metaclass__ = Singleton

    assert C() == C()

# Generated at 2022-06-21 08:59:24.548379
# Unit test for constructor of class Singleton
def test_Singleton():
    class Meta(type):
        __metaclass__ = Singleton

        def __init__(cls, name, bases, dct):
            cls.test = 1

    class Foo(object):
        __metaclass__ = Meta

    assert Foo is Foo() is Foo()
    assert id(Foo) == id(Foo()) == id(Foo())
    assert Foo.test == 1

# Generated at 2022-06-21 08:59:26.370062
# Unit test for constructor of class Singleton
def test_Singleton():
    l = []
    for i in range(10):
        l.append(Singleton())
    for i in range(10):
        assert l[0].__instance == l[i].__instance

# Generated at 2022-06-21 08:59:33.319897
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(metaclass=Singleton):
        pass
    t1 = S()
    t2 = S()
    assert t1 == t2


# Generated at 2022-06-21 08:59:39.920818
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class AClass(metaclass=Singleton):
        def __init__(self):
            self.value = 'a'

    assert AClass.__instance is None
    first = AClass()
    assert first.value == 'a'
    second = AClass()
    assert second.value == 'a'
    assert first is second



# Generated at 2022-06-21 08:59:42.132982
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-21 08:59:47.296952
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase
    class TestObject(object):
        __metaclass__ = Singleton
        pass

    class TestSingleton(TestCase):
        def __call__(self):
            self.assertEqual(TestObject(), TestObject())

    test = TestSingleton()
    test()


# Generated at 2022-06-21 08:59:56.511717
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    class MySingleton2(object):
        __metaclass__ = Singleton

    def do_assertions():
        assert id(obj1) == id(obj2)
        assert obj1 == obj2
        assert not (obj1 is obj2)

    # Should be two separate instances, since they're of different types
    obj1 = MySingleton(1)
    obj2 = MySingleton2(2)

    # Assertions
    do_assertions()

    # Should be the same instance
    obj3 = MySingleton(3)
    obj4 = MySingleton(4)

    # Assertions
    do_assertions()


# Generated at 2022-06-21 09:00:02.197907
# Unit test for constructor of class Singleton
def test_Singleton():
    import ansible.utils.singleton as singleton
    class Test(object):
        __metaclass__ = singleton.Singleton
    a = Test()
    b = Test()
    assert a is b


# Generated at 2022-06-21 09:00:06.170309
# Unit test for constructor of class Singleton
def test_Singleton(): 
    class TestClass(metaclass=Singleton): 
        pass

    # create 2 instances. 
    test1 = TestClass() 
    test2 = TestClass() 

    # Now test if they are same object or not. 
    if (test1 is test2): 
        return True
    else: 
        return False

# Generated at 2022-06-21 09:00:15.048334
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import os
    import tempfile
    tmpdir = tempfile.mkdtemp(dir=os.getcwd())

    import shutil
    from ansible.module_utils.facts import Facts

    facts = Facts(module_name='/dev/null',
                  module_args='',
                  timeout=5,
                  connection=None,
                  ansible_facts=dict(),
                  verbosity=0,
                  check_mode=False,
                  console=None,
                  ansible_version=None,
                  random_console_id=None,
                  tmpdir=tmpdir)

    assert Singleton.__call__(Facts, **facts.__dict__) == Singleton.__call__(Facts, **facts.__dict__)

    shutil.rmtree(tmpdir)

