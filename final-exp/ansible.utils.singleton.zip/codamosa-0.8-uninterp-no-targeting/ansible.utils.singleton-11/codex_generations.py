

# Generated at 2022-06-21 08:56:00.592902
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 'test_Singleton'

    obj1 = Foo()
    obj2 = Foo()
    assert obj1 == obj2
    assert obj1.val == obj2.val

# Generated at 2022-06-21 08:56:09.193046
# Unit test for constructor of class Singleton
def test_Singleton():
    assert(Singleton('foo', (object,), {}).__instance == None)
    assert(Singleton('foo', (object,), {}).__rlock.locked() == False)
    assert(Singleton('foo', (object,), {})('a').__instance == None)
    assert(Singleton('foo', (object,), {})('a').__rlock.locked() == False)
    assert(Singleton('foo', (object,), {})('a').__instance == None)
    assert(Singleton('foo', (object,), {})('a').__rlock.locked() == False)
    assert(Singleton('foo', (object,), {})('b') == None)
    assert(Singleton('foo', (object,), {}).__instance == None)

# Generated at 2022-06-21 08:56:12.889493
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    instance1 = TestSingleton()
    instance2 = TestSingleton()
    assert instance1 is instance2


# Generated at 2022-06-21 08:56:20.028844
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:

        def __init__(self):
            self.x = 1

    class B(A, metaclass=Singleton):
        pass

    b1 = B()
    b2 = B()

    assert(b1 is b2)
    assert(b1 is B())
    assert(b2 is B())
    assert(b1.x == b2.x)
    assert(b1.x == B().x)
    assert(b2.x == B().x)

# Generated at 2022-06-21 08:56:24.126572
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    ts = TestSingleton()
    assert ts is TestSingleton()

# Generated at 2022-06-21 08:56:28.485828
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object, metaclass=Singleton):

        def __init__(self, name):
            self.name = name

    assert MyClass('abc') is MyClass('def')
    assert MyClass('abc').name == 'abc'
    assert MyClass('abc').name == MyClass('def').name



# Generated at 2022-06-21 08:56:32.911903
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """__call__ is a valid standalone method of Singleton"""
    class A(object, metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    a = A('a')
    b = A('b')

    assert a is b
    assert b.value == 'b'

# Generated at 2022-06-21 08:56:39.540225
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, k):
            self.k = k

    a1 = A('a1')
    a2 = A('a2')
    print(a1.k)
    print(a2.k)


test_Singleton()

# Generated at 2022-06-21 08:56:43.784543
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
    exp = Test()
    o = Test()
    assert exp is o
    assert id(exp) == id(o)



# Generated at 2022-06-21 08:56:51.267216
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    s1 = S(10)
    assert s1.a == 10
    s2 = S(20)
    assert s2.a == 10
    assert S(30).a == 10
    s3 = S(40)
    assert s3.a == 10
    


# Generated at 2022-06-21 08:57:00.947694
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a=3):
            self.a = a

    class B(A):
        def __init__(self, b):
            self.b = b
            super(B, self).__init__()

    a = A(0)
    b = A(1)
    assert a is b
    assert a.a == b.a == 1

    c = B('x')
    d = B('y')
    assert c is d
    assert c.a == d.a == 1
    assert c.b == d.b == 'y'

    e = A(2)
    assert e is a is b
    assert e.a == 2

# Generated at 2022-06-21 08:57:04.224447
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self, v):
            self.v = v

    x = C(1)
    y = C(2)
    assert x is y
    assert x.v == 1


# Generated at 2022-06-21 08:57:08.354687
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Dummy(object):
        __metaclass__ = Singleton
    d1 = Dummy()
    d2 = Dummy()
    assert d1.__class__ == Dummy
    assert d2.__class__ == Dummy
    assert id(d1) == id(d2)



# Generated at 2022-06-21 08:57:10.447468
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Dummy(object):
        __metaclass__ = Singleton

    a = Dummy()
    b = Dummy()

    assert a is b
    assert id(a) == id(b)

# Generated at 2022-06-21 08:57:13.176177
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object, metaclass=Singleton):
        pass

    a = MySingleton()
    b = MySingleton()
    assert a is b

# Generated at 2022-06-21 08:57:19.803547
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        pass

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    assert test_singleton_1 == test_singleton_2
    assert id(test_singleton_1) == id(test_singleton_2)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 08:57:21.896402
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:57:29.041109
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, name=None):
            self.name = name

        def __repr__(self):
            return '%s: %r' % (type(self).__name__, self.name)

    s1 = SingletonTest('foo')
    s2 = SingletonTest('bar')
    assert s1 is s2
    assert s1.name == 'bar'



# Generated at 2022-06-21 08:57:32.593849
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 'bar'

    s = MySingleton()
    assert s.foo == 'bar'
    assert s is MySingleton()

# Generated at 2022-06-21 08:57:34.393427
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    p1 = SingletonPrinter()
    p2 = SingletonPrinter()

    assert p1 is p2


# Generated at 2022-06-21 08:57:41.183604
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, s):
            self.s = s

    t1 = TestClass('foo')
    t2 = TestClass('bar')
    assert t1 is t2
    assert t1.s is 'foo'

# Generated at 2022-06-21 08:57:46.693710
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleClass(with_metaclass(Singleton)):
        def __init__(self, v1):
            self.val = v1

    print(hex(id(MySingleClass(1))))
    print(hex(id(MySingleClass(2))))
    print(hex(id(MySingleClass(3))))



# Generated at 2022-06-21 08:57:49.820864
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert a == b


# Generated at 2022-06-21 08:57:59.125031
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print("""test_Singleton___call__:  Testing Singleton metaclass method __call__...  """)

    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            print("running __init__ of Foo")
            self.args = args
            self.kwargs = kwargs

        def __repr__(self):
            return "Foo(%s, %s)" % (repr(self.args), repr(self.kwargs))

    f = Foo(1, 2, 3, a=4, b=5, c=6)
    print("f =", f)
    g = Foo(7, 8, f=9)
    print("g =", g)
    h = Foo()
    print("h =", h)


# Generated at 2022-06-21 08:58:01.514304
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo = Foo()
    assert id(Foo()) == id(foo)



# Generated at 2022-06-21 08:58:07.056578
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 100

    a1 = A()
    a2 = A()
    assert a1.x == a2.x
    a2.x = 101
    assert a1.x == a2.x

# Generated at 2022-06-21 08:58:15.446579
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 10

    s = SingletonTest()
    assert(s.value == 10)

    s1 = SingletonTest()
    s1.value = 20
    assert(s1.value == 20)

    s2 = SingletonTest()
    assert(s2.value == 20)
    assert(s is s1)
    assert(s is s2)


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 08:58:20.379830
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1(object):
        __metaclass__ = Singleton

    class Test2(object):
        __metaclass__ = Singleton

    # check objects are different
    assert(Test1()) is not Test2()
    assert(Test1()) is not Test1()
    assert(Test1()) is Test1()
    assert(Test2()) is not Test2()
    assert(Test2()) is Test2()



# Generated at 2022-06-21 08:58:27.010608
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    # create a new instance of class Foo
    foo1 = Foo()

    # a second new instance of class Foo should be the same as the first one
    foo2 = Foo()
    assert foo1 is foo2

    # you can still create another instance of class Foo
    foo3 = Foo()
    assert foo1 is foo3


# Generated at 2022-06-21 08:58:27.639105
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton is not None
    assert issubclass(Singleton, type)

# Generated at 2022-06-21 08:58:40.324776
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self._number = 1

        def __repr__(self):
            return str(self._number)

    f1 = Foo()
    f2 = Foo()
    assert f1 is f2, 'f1 and f2 should be the same object!'
    assert f1._number == 1, 'f1._number should be equal to 1!'
    H, M, S = (lambda x: int(x) if x > 0 else 0)(*map(float, '0.5 1.5 2.5'.split()))

    assert (H, M, S) == (0, 1, 1), 'Values were not properly converted!'

# Generated at 2022-06-21 08:58:46.107533
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # set up
    class SingletonClass(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name
    first = SingletonClass('first')
    second = SingletonClass('second')
    # test
    assert first is second, "second instance should have the same address as first instance"



# Generated at 2022-06-21 08:58:55.194305
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            self.a = 1
 
    obj1 = MyClass()
    print(obj1.a)
    print(obj1.__dict__)
 
    obj2 = MyClass()
    print(obj2.a)
    print(obj2.__dict__)
 
    obj1.a = 2
    print(obj1.a)
    print(obj1.__dict__)
 
    print(obj2.a)
    print(obj2.__dict__)
 
    print(obj1 is obj2)


# Examples of using Singleton

# Generated at 2022-06-21 08:58:56.998454
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class singleton(object):
        __metaclass__ = Singleton
    assert singleton is singleton()

# Generated at 2022-06-21 08:59:09.051971
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create class A with Singleton
    class A(object):
        __metaclass__ = Singleton
        pass

    # Create class B with Singleton
    class B(object):
        __metaclass__ = Singleton
        pass

    # Construct two instances of class A
    a1 = A()
    a2 = A()

    # Check that they are the same instance
    assert a1 is a2

    # Construct two instances of class B
    b1 = B()
    b2 = B()

    # Check that they are the same instance
    assert b1 is b2

    # Construct one instance of class A
    a3 = A()

    # Check that it is the same instance as the previous two instances
    assert a1 is a3

    # Check that A and B instances are not the same
    assert a1 is not b

# Generated at 2022-06-21 08:59:15.163892
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.data = [1, 2, 3]

    ts1 = TestSingleton()
    ts2 = TestSingleton()

    ts1.data.append(42)

    assert ts1 == ts2
    assert ts2.data == [1, 2, 3, 42]

# Generated at 2022-06-21 08:59:23.646912
# Unit test for constructor of class Singleton
def test_Singleton():
    # Define a class
    class ClassA(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            self.inited = True
            self.a = 1
            self.b = 2
            self.c = 3

    a1 = ClassA()
    assert a1.inited == True
    assert a1.a == 1
    assert a1.b == 2
    assert a1.c == 3

    a2 = ClassA()
    assert a2 is a1
    assert a2.a == 1
    assert a2.b == 2
    assert a2.c == 3

# Generated at 2022-06-21 08:59:29.401818
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.state = "INSTANTIATED"

    obj1 = A()
    obj2 = A()

    # This code should not execute
    if obj1 != obj2:
        raise Exception("Singleton failed")

    if obj1.state == "INSTANTIATED" and obj2.state == "INSTANTIATED":
        raise Exception("Singleton failed")


# Generated at 2022-06-21 08:59:34.070041
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b, 'Singleton failed'

    b = B()
    assert a is not b, 'Singleton failed'

# Utility methods for unit testing

# Generated at 2022-06-21 08:59:37.978342
# Unit test for constructor of class Singleton
def test_Singleton():
    class T(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = 'test'

    assert hasattr(T(), 'test')
    assert T().test == 'test'

# Generated at 2022-06-21 08:59:44.938153
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    a = Foo('a')
    assert a.name == 'a'
    b = Foo('b')
    assert b.name == 'a'
    assert a == b

# Generated at 2022-06-21 08:59:46.942889
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
    assert Test() == Test()

# Generated at 2022-06-21 08:59:52.690676
# Unit test for constructor of class Singleton
def test_Singleton():
    class App(object):
        __metaclass__ = Singleton
        def __init__(self):
            from random import randint
            self.val = randint(0, 100)

    a = App()
    b = App()

    assert a.val == b.val
    assert a is b

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:59:56.406464
# Unit test for constructor of class Singleton
def test_Singleton():
    class P(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 'test'

    # First instance
    p1 = P()

    assert p1.x == 'test'

    p2 = P()

    assert p2.x == 'test'
    assert p1 is p2



# Generated at 2022-06-21 09:00:01.389700
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self):
            self.value = 1

    assert Test().value == 1
    assert Test().value == 1



# Generated at 2022-06-21 09:00:04.441866
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    a1 = A()
    assert A() == a1
    assert type(a1) == A

# Generated at 2022-06-21 09:00:09.816822
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test if classes implementing Singleton return the same object
    class TestClass(object):
        __metaclass__ = Singleton

    class TestClass2(TestClass):
        pass

    class TestClass3(TestClass2):
        pass

    # Test if different classes implementing Singleton
    # return the same object
    assert TestClass() == TestClass2() == TestClass3()

    class TestClass4(object):
        __metaclass__ = Singleton

# Generated at 2022-06-21 09:00:16.619745
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonSub(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 'foo'

    s = SingletonSub()
    assert(s.value == 'foo')

    s2 = SingletonSub()
    assert(s == s2)
    assert(s.value == 'foo')
    assert(s2.value == 'foo')

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:00:21.491567
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.bar = 'baz'
        def test_str(self):
            return self.bar

    x = Foo()
    y = Foo()
    z = Foo()
    assert x.test_str() == 'baz'
    assert y == x
    assert z == x

# Generated at 2022-06-21 09:00:29.687350
# Unit test for constructor of class Singleton
def test_Singleton():
    from datetime import datetime

    # Creating class without metaclass
    class Num:
        def __init__(self):
            self.num = datetime.now()

    # Creating class with metaclass
    class NumMeta(metaclass=Singleton):
        def __init__(self):
            self.num = datetime.now()

    # Initializing classes
    obj1 = Num()
    obj2 = Num()
    obj3 = Num()
    obj4 = Num()

    obj5 = NumMeta()
    obj6 = NumMeta()
    obj7 = NumMeta()
    obj8 = NumMeta()

    # Unit test
    print(obj1.num)
    print(obj2.num)
    print(obj3.num)
    print(obj4.num)

    print(obj5.num)

# Generated at 2022-06-21 09:00:35.977846
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Cls(object):
        __metaclass__ = Singleton

    obj1 = Cls()
    obj2 = Cls()

    assert obj1 == obj2

# Generated at 2022-06-21 09:00:42.061317
# Unit test for constructor of class Singleton
def test_Singleton():
    import unittest
    import types

    class SingletonTest(object):

        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

        def foo(self, *args):
            print(self.name, ':', args)

    class SingletonTestCase(unittest.TestCase):

        def test_Singleton(self):
            mysingleton = SingletonTest('hello')
            self.assertTrue(isinstance(mysingleton, SingletonTest))
            # class method
            self.assertTrue(isinstance(mysingleton.foo, types.MethodType))

            # call __constructor__
            mysingleton2 = SingletonTest('world')
            self.assertTrue(mysingleton == mysingleton2)

# Generated at 2022-06-21 09:00:45.533527
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton): pass

    t1 = Test()
    t2 = Test()

    assert t1 is t2


# Generated at 2022-06-21 09:00:52.676318
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x
    assert A(3) is A(4)
    assert A(3).x == 4
    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.y = 5
    assert B() is B()
    assert B().y == 5
    c = A('a')
    assert A('b') is c
    assert c.x == 'b'
    assert B() is not c

# Generated at 2022-06-21 09:00:53.920121
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() == Test()

# Generated at 2022-06-21 09:00:57.522693
# Unit test for constructor of class Singleton
def test_Singleton():
    """The test case for class Singleton"""
    class TestClass(metaclass=Singleton):
        def __init__(self, val):
            self.val = val
        def value(self):
            return self.val
    class TestClass2:
        pass

    tc1 = TestClass(1)
    tc2 = TestClass(2)
    tc1.val = 10
    tc2.val = 20
    assert(tc1.val == tc2.val)
    assert(tc1.value() == tc2.value())
    tc3 = TestClass2()
    assert(tc1 is not tc3)
    return True

# Generated at 2022-06-21 09:01:09.303443
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import sys

    class K1(object):
        """This class is not a singleton"""
        pass

    k1a = K1()
    k1b = K1()

    class K2(object):
        """This class is a singleton"""
        __metaclass__ = Singleton
    k2a = K2()
    k2b = K2()

    class K3(object):
        """This class is a singleton, but has a class variable called self (not a good practice)"""
        __metaclass__ = Singleton
        self = None
        def __init__(self):
            K3.self = self
    k3 = K3()
    print("k3.self={0}".format(k3.self))


# Generated at 2022-06-21 09:01:12.283351
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton:
        __metaclass__ = Singleton

    test_singleton1 = TestSingleton()
    test_singleton2 = TestSingleton()
    assert(test_singleton1 == test_singleton2)

# Generated at 2022-06-21 09:01:19.258087
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            self.number = 1

        def plus_one(self):
            self.number = self.number + 1

        def get_number(self):
            return self.number

    myclass_1 = MyClass()
    print(myclass_1.get_number())
    myclass_2 = MyClass()
    print(myclass_2.get_number())
    myclass_1.plus_one()
    print(myclass_1.get_number())
    print(myclass_1.get_number())
    print(myclass_2.get_number())
    print(myclass_2.get_number())
    print(myclass_2.get_number())
    myclass_1.plus_one()
    print

# Generated at 2022-06-21 09:01:25.462049
# Unit test for constructor of class Singleton
def test_Singleton():

    # Test that the class can be instantiated normally
    class MyClass(metaclass=Singleton):
        def __init__(self, param):
            self.param = param

    # Test that instantiating the class twice returns the same object
    assert id(MyClass('foo')) == id(MyClass('bar'))
    assert MyClass('foo').param == 'bar'

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:01:39.436573
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # __call__ returns the singleton instance of the class
    class TestClass(metaclass=Singleton):
        def __init__(self):
            self.data = [1, 2, 3]

    instance = TestClass()
    assert instance is TestClass()
    instance.data.append(4)
    assert TestClass().data == [1, 2, 3, 4]



# Generated at 2022-06-21 09:01:41.813608
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    a = Foo()
    b = Foo()

    assert a is b
    assert a == b

