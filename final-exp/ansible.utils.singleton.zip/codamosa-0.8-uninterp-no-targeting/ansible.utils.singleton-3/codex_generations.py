

# Generated at 2022-06-21 08:56:02.056320
# Unit test for constructor of class Singleton
def test_Singleton():
    class SimpleSingleton(metaclass=Singleton):
        def __init__(self, n=1):
            self.x = n

    s1 = SimpleSingleton()
    s2 = SimpleSingleton()
    assert s1 is s2
    assert s1.x == 1

    s3 = SimpleSingleton(42)
    assert s1 is s3
    assert s1.x == 1



# Generated at 2022-06-21 08:56:06.293163
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b
    assert a == b

if __name__ == "__main__":
    # If call this python file directly, then run unit test case
    test_Singleton()

# Generated at 2022-06-21 08:56:14.601243
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass:
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 'first'

        def get(self):
            return self.value

    a = SingletonClass()
    b = SingletonClass()

    assert a == b
    assert a.get() == 'first'

    a.value = 'second'

    assert b.get() == 'second'

    b.value = 'third'

    assert a.get() == 'third'

# Generated at 2022-06-21 08:56:16.590290
# Unit test for constructor of class Singleton
def test_Singleton():
    assert type(Singleton) == type
    assert issubclass(Singleton, type)



# Generated at 2022-06-21 08:56:22.361424
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self, *args, **kwargs):
            super(Foo, self).__init__()
            self.a = args
            self.b = kwargs

    f1 = Foo(1, b=2)
    f2 = Foo(b=2, a=1)
    assert f1 is f2

# Generated at 2022-06-21 08:56:23.702857
# Unit test for constructor of class Singleton
def test_Singleton():
    assert isinstance(Singleton('name', 'bases', 'dct'), type)

# Generated at 2022-06-21 08:56:25.790236
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        """A class for testing Singleton."""
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-21 08:56:34.453736
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a=1):
            self.a = a

    a = Test()
    b = Test()
    assert a.a == b.a == 1

    a.a = 2
    assert a.a == b.a == 2

    c = Test(a=3)
    assert c.a == 3

    d = Test(a=10)
    assert d.a == 3

    assert a == b == c == d
    assert id(a) == id(b) == id(c) == id(d)



# Generated at 2022-06-21 08:56:40.257130
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = 'Test'
    instance = A()
    assert instance.test == 'Test', 'Test failed'
    instance = A()
    assert instance.test == 'Test', 'Test failed'
    assert instance is A(), 'Test failed'


# Generated at 2022-06-21 08:56:45.023239
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    a1.x = 1
    a2.y = 2
    assert a1 == a2
    assert hasattr(a1, 'x') and hasattr(a2, 'x')
    assert hasattr(a1, 'y') and hasattr(a2, 'y')
    a1.x == a2.x
    a1.y == a2.y
    assert id(a1) == id(a2)



# Generated at 2022-06-21 08:56:51.778035
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.b = 1

    a1 = A()
    assert a1.a == 1

    a2 = A()
    assert a2.a == 1

    b1 = B()
    assert b1.b == 1

    b2 = B()
    assert b2.b == 1

    assert b2 is b1
    assert a2 is a1

# Generated at 2022-06-21 08:56:56.181698
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        val = "hii"
        pass

    a = MyClass()
    b = MyClass()

    assert(id(a) == id(b))
    print(id(a))
    print(id(b))

# Generated at 2022-06-21 08:56:58.596251
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(metaclass=Singleton):
        def __init__(self):
            pass

    x = MySingleton()
    y = MySingleton()
    assert x is y

# Generated at 2022-06-21 08:57:00.371861
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    assert Foo() is Foo()

# Generated at 2022-06-21 08:57:04.125882
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(Singleton):
        pass

    class MyClass2(MyClass):
        pass

    a = MyClass()
    b = MyClass()
    c = MyClass2()
    d = MyClass2()

    assert a is b
    assert c is d
    assert a is not c

# Generated at 2022-06-21 08:57:07.215562
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        '''Test singleton'''
        __metaclass__ = Singleton

    # Create objects with initial values
    inst1 = SingletonTest()
    inst2 = SingletonTest()
    assert inst1 is inst2

# Generated at 2022-06-21 08:57:11.771691
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test_Singleton_Object(object):
        __metaclass__ = Singleton
    a = Test_Singleton_Object()
    b = Test_Singleton_Object()
    if a is b:
        print("Unit test for Singleton class passed")
    else:
        print("Unit test for Singleton class failed")

#test_Singleton___call__()

# Generated at 2022-06-21 08:57:15.166864
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = A()
    b = A()
    assert(a is b)

# Generated at 2022-06-21 08:57:25.210245
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, a, b=2, c=3):
            self.a = a
            self.b = b
            self.c = c

        def __repr__(self):
            return "%s(%s,%s,%s)" % (self.__class__.__name__, self.a, self.b, self.c)

    instance = Foo(1,c=4)
    assert instance
    assert isinstance(instance,Foo)
    assert instance.a==1
    assert instance.b==2
    assert instance.c==4

    instance2 = Foo(2)
    assert instance2 is instance

# Generated at 2022-06-21 08:57:32.758824
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            # Instance count
            self.i = 1
            self.x = x

        def __eq__(self, other):
            return self.x == other.x

    i = MyClass('x')
    assert i.x == 'x'
    assert i.i == 1

    j = MyClass('x')
    assert i is j
    assert j.x == 'x'
    assert j.i == 1

# Generated at 2022-06-21 08:57:39.691985
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        pass

    A1 = A()
    A2 = A()
    assert A1 == A2
    assert A1 is A2
    assert A1.__class__ is A2.__class__
    assert type(A1) is A2.__class__
    assert type(A2) is A1.__class__

# Generated at 2022-06-21 08:57:51.439115
# Unit test for constructor of class Singleton
def test_Singleton():
    import types
    from . import callback_loader

    def assert_valid(x):
        assert x is not None
        assert isinstance(x, Singleton)
        assert isinstance(x, types.TypeType)
        assert isinstance(x, callback_loader.CallbackModuleLoader)
        assert issubclass(x, Singleton)
        assert issubclass(x, types.TypeType)
        assert issubclass(x, callback_loader.CallbackModuleLoader)

    x = Singleton('X', (), {})
    assert_valid(x)

    x = Singleton('Y', (Singleton,), {})
    assert_valid(x)

    x = Singleton('Z', (Singleton, types.TypeType), {})
    assert_valid(x)


# Generated at 2022-06-21 08:57:57.123905
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = 'abc'

        def get_a(self):
            return self.a

    class B(metaclass=Singleton):
        def __init__(self):
            self.b = 'xyz'

        def get_b(self):
            return self.b

    a = A()
    b = B()

    assert a.get_a() == 'abc'
    assert b.get_b() == 'xyz'
    assert A().get_a() == 'abc'
    assert B().get_b() == 'xyz'

# Generated at 2022-06-21 08:58:01.417297
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = Test()
    t2 = Test()
    assert id(t1) == id(t2)
    t1.a = 2
    assert t1.a == t2.a

# Generated at 2022-06-21 08:58:08.645060
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class C(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name
            self.instance_count = 0

        def __str__(self):
            return '%s' % self.name

    i1 = C('instance 1')
    assert i1.name == 'instance 1'

    i2 = C('instance 2')
    assert i2.name == 'instance 1'

# Generated at 2022-06-21 08:58:12.252657
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTestClass(object):
        __metaclass__ = Singleton

    x = SingletonTestClass()
    y = SingletonTestClass()
    if x != y:
        raise AssertionError('x != y')

# Generated at 2022-06-21 08:58:18.736383
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, value=None):
            self.value = value
            print('Initialization of class A')

        def __str__(self):
            return str(self.value)

    a = A()
    b = A()
    assert a == b
    assert a is b

    b.value = 2
    print(a)


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 08:58:25.470231
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a=1
    s1 = MySingleton()
    s2 = MySingleton()
    assert(s1 is s2)
    assert(s1.a == s2.a)


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-21 08:58:37.332415
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    Test the method __call__ of class Singleton
    """
    class TestSingleton(object):
        """
        Class to be used in the test
        """
        __metaclass__ = Singleton

        def __init__(self):
            self.dummy = 0

        def set_dummy(self, value):
            """
            Dummy setter
            """
            self.dummy = value

    # Create a new instance of the class
    t1 = TestSingleton()

    # Test it is valid
    assert t1 is not None

    # Test instance variables are valid
    assert t1.dummy == 0

    # Change the value of dummy
    t1.set_dummy(1)

    # Test dummy has the new value
    assert t1.dummy == 1

    # Create another instance of the

# Generated at 2022-06-21 08:58:40.644062
# Unit test for constructor of class Singleton
def test_Singleton():
    # Just verify we can instantiate a singleton
    class test_Singleton:
        __metaclass__ = Singleton

    a = test_Singleton()
    print(a)
    b = test_Singleton()
    print(b)



# Generated at 2022-06-21 08:58:47.328608
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 'bar'

    assert Bar.__instance is None

    b1 = Bar()
    assert b1.foo == 'bar'

    b2 = Bar()
    assert b2.foo == 'bar'

    assert b1 is b2



# Generated at 2022-06-21 08:58:52.654830
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 10

    t1 = TestSingleton()
    t2 = TestSingleton()
    t3 = TestSingleton()
    t1.val = 20

    assert t1.val == t2.val == t3.val

# Generated at 2022-06-21 08:58:56.730123
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    ts1 = TestSingleton("test")
    ts2 = TestSingleton("test1")

    assert ts1 is ts2
    assert ts1.val == ts2.val
    assert ts1.val == "test"

# Generated at 2022-06-21 08:59:06.703460
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global class_instance_dict

    # Reset test env
    class_instance_dict.clear()

    class MyClass(object):
        __metaclass__ = Singleton

    class MyClass2(object):
        __metaclass__ = Singleton

    instance1 = MyClass()
    assert len(class_instance_dict) == 1
    instance2 = MyClass()
    assert len(class_instance_dict) == 1
    instance3 = MyClass2()
    assert len(class_instance_dict) == 2
    instance4 = MyClass2()
    assert len(class_instance_dict) == 2


class_instance_dict = {}



# Generated at 2022-06-21 08:59:09.992240
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingleInstance(object):
        __metaclass__ = Singleton

        def __ini__():
            pass

    instance1 = SingleInstance()
    instance2 = SingleInstance()

    assert id(instance1) == id(instance2)



# Generated at 2022-06-21 08:59:14.154173
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    # create two instances
    a1 = TestSingleton()
    a2 = TestSingleton()

    # compare the instances
    assert a1 is a2

# Generated at 2022-06-21 08:59:17.841798
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        pass

    a = A()
    b = A()

    assert a is b


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 08:59:25.306767
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            self.string = 'Hello World'

    instance1 = MyClass()
    instance2 = MyClass()

    assert instance1 == instance2
    assert instance1.string == instance2.string
    instance1.string = 'New Hello'
    assert instance1 == instance2
    assert instance1.string == instance2.string
    instance2.string = 'Another New Hello'
    assert instance1 == instance2
    assert instance1.string == instance2.string

# Generated at 2022-06-21 08:59:32.889346
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):

        """This class is a Singleton

        Since it does not contain any instance attribute
        class attribute are shared between all instances
        """
        __metaclass__ = Singleton
        cls_attr = list()

    a1 = A()
    a2 = A()

    assert a1 is a2
    assert a1.cls_attr is a2.cls_attr

    a1.cls_attr.append(1)
    a2.cls_attr.append(2)

    assert len(a1.cls_attr) == len(a2.cls_attr)
    assert len(a1.cls_attr) == 2

    a2.cls_attr.append(3)


# Generated at 2022-06-21 08:59:44.470568
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    class B(A):
        pass

    class C(A):
        pass

    a1 = A(1)
    a2 = A(2)
    b1 = B(100)
    b2 = B(200)
    c1 = C(1000)
    c2 = C(2000)

    assert(id(a1) == id(a2))
    assert(id(b1) == id(b2))
    assert(id(c1) == id(c2))
    assert(id(a1) != id(b1))
    assert(id(b1) != id(c1))
    assert(id(c1) != id(a1))

# Generated at 2022-06-21 08:59:53.977853
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, num):
            self.num = num

    a = SingletonTest(1)
    b = SingletonTest(2)

    assert a is b  # a and b should refer to the same instance
    assert a.num == b.num == 1  # As a and b refer to the same instance, changes done to one must be reflected in
                                # the other

# Generated at 2022-06-21 08:59:58.657173
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 0

        def add(self, val):
            self.val += val

    st1 = SingletonTest()
    st2 = SingletonTest()
    st3 = SingletonTest()
    st1.add(1)

    assert st1 is st2 is st3
    assert st1.val == 1
    assert st2.val == 1
    assert st3.val == 1


# Generated at 2022-06-21 09:00:05.100962
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton():
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert id(a) == id(b)
    assert a.value == b.value
    b.value += 1
    assert a.value == 2
    assert b.value == 2



# Generated at 2022-06-21 09:00:09.769613
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestSingleton('first')
    b = TestSingleton('second')
    assert a.name == 'first'
    assert b.name == 'first'
    assert id(a) == id(b)


# Generated at 2022-06-21 09:00:11.822621
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton() is TestSingleton()



# Generated at 2022-06-21 09:00:18.864349
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):

        __metaclass__ = Singleton

        def __init__(self, value=0):
            self.value = value
            print('A constructor called')

        def set_value(self, value):
            self.value = value

        def get_value(self):
            return self.value

    a = A()
    a.set_value(10)
    assert a.get_value() == 10
    b = A()
    assert b.get_value() == 10

    # the following code will cause exception
    # c = A(20)
    # assert c.get_value() == 20

if __name__ == '__main__':
    test_Singleton();

# Generated at 2022-06-21 09:00:21.166396
# Unit test for constructor of class Singleton
def test_Singleton():
    class t(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    c = t()
    assert c == t()

# Generated at 2022-06-21 09:00:23.892720
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo():
        __metaclass__ = Singleton

    a = Foo()
    b = Foo()

    assert a is b, 'Singleton should be singleton.'


# Generated at 2022-06-21 09:00:28.443311
# Unit test for constructor of class Singleton
def test_Singleton():
    import sys
    # in python3, __metaclass__ is used instead of metaclass
    if sys.version_info > (3, 0):
        class Singleton:
            __metaclass__ = Singleton
    else:
        class Singleton:
            __metaclass__ = Singleton

    s1 = Singleton()
    s2 = Singleton()
    assert id(s1) == id(s2)

test_Singleton()

# Generated at 2022-06-21 09:00:33.999045
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 3

    a = C()
    b = C()
    assert a is b
    a.value = 4
    assert b.value == 4
    assert b.value == a.value
    print(('%s is a singleton' % C))


test_Singleton()

# Generated at 2022-06-21 09:00:38.283718
# Unit test for constructor of class Singleton
def test_Singleton():
    # pylint: disable=C0111,E1101

    class MyClass(object):
        __metaclass__ = Singleton

    obj1 = MyClass()
    obj2 = MyClass()
    assert obj1 == obj2

# Generated at 2022-06-21 09:00:43.346645
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__=Singleton
        def __init__(self, n):
            self.n = n
    a = A(3)
    b = A(4)
    assert a.n is 3
    assert b.n is 3
    assert a is b

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:00:47.963831
# Unit test for constructor of class Singleton
def test_Singleton():
    class ABC(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    instance1 = ABC()
    instance2 = ABC()
    assert instance1 is instance2



# Generated at 2022-06-21 09:00:53.724203
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, bar):
            self._bar = bar

        def getBar(self):
            return self._bar

    foo_1 = Foo('foo bar 1')
    foo_2 = Foo('foo bar 2')

    assert foo_1 is foo_2
    assert foo_1.getBar() == foo_2.getBar() == 'foo bar 1'

# Generated at 2022-06-21 09:00:56.616294
# Unit test for constructor of class Singleton
def test_Singleton():
    from collections import namedtuple
    class TestSingleton(object):
        __metaclass__ = Singleton
    a = TestSingleton()
    b = TestSingleton()
    assert(id(a) == id(b))
    assert(a == b)

# Generated at 2022-06-21 09:01:08.476053
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Singleton_class(object):
        __metaclass__ = Singleton
    class Singleton_class_with_args(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg
    class Singleton_class_with_kwargs(object):
        __metaclass__ = Singleton
        def __init__(self, arg=None):
            self.arg = arg

    a = Singleton_class()
    b = Singleton_class()
    c = Singleton_class_with_args(1)
    d = Singleton_class_with_args(2)
    e = Singleton_class_with_kwargs('test')
    f = Singleton_class_with_kwargs(arg='test')

    assert a is b

# Generated at 2022-06-21 09:01:12.808608
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    a1 = A()
    a2 = A()
    assert(a1 is a2)
    assert(a1 == a2)
    a2.var = 123
    assert(hasattr(a1, 'var'))
    assert(a1.var == 123)


# Generated at 2022-06-21 09:01:16.161713
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
    def func():
        cls = MyClass()
    for i in range(10):
        func()
    assert MyClass() == cls

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:01:19.547043
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    s1 = Test()
    s2 = Test()
    assert (s1, id(s1)) == (s2, id(s2))

# Generated at 2022-06-21 09:01:26.512030
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = 1
            self.b = 2

        def show(self):
            print(self.a)
            print(self.b)

    obj1 = A()
    obj1.show()
    obj2 = A()
    obj2.show()

    assert(id(obj1) == id(obj2))

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:01:34.525308
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = "test"

    m1 = MyClass()
    m2 = MyClass()

    assert m1 is m2

    assert m1.test == "test"
    assert m2.test == "test"

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:01:38.664264
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        def __init__(self, num):
            self.num = num

    a = Test(2)
    b = Test(3)
    assert a == b
    assert a.num == 2
    assert b.num == 2


if __name__ == '__main__':
    test_Singleton()
    print('test passed')

# Generated at 2022-06-21 09:01:47.398482
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest
    from pytest import raises

    class MySingleton(metaclass=Singleton):
        def __init__(self, name):
            print('MySingleton.__init__')
            self._name = name

        def name(self):
            return self._name

    # First instance of MySingleton
    s1 = MySingleton('s1')
    assert s1.name() == 's1'

    # Second instance of MySingleton
    s2 = MySingleton('s2')
    assert s2.name() == 's1'
    assert s1 is s2


# Generated at 2022-06-21 09:01:52.308685
# Unit test for constructor of class Singleton
def test_Singleton():   # pragma: no cover
    class S1(object):
        __metaclass__ = Singleton

    class S2(object):
        __metaclass__ = Singleton

    s1 = S1()
    s2 = S1()
    assert s1 is s2

    s3 = S2()
    s4 = S2()
    assert s3 is s4

    assert s1 is not s4

# Generated at 2022-06-21 09:01:56.127787
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a == b


# Generated at 2022-06-21 09:01:59.888047
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("Foo created!")

    foo1 = Foo()
    foo2 = Foo()
    print(foo1 == foo2)


# Generated at 2022-06-21 09:02:02.981944
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Creation of an instance of class MyClass
    obj1 = MyClass()

    # Creation of another instance of class MyClass
    obj2 = MyClass()

    # Reference to object obj1
    assert obj1 is obj2


# Class MyClass

# Generated at 2022-06-21 09:02:12.232107
# Unit test for constructor of class Singleton
def test_Singleton():
    from collections import OrderedDict

    class TestSingleton(object):
        __metaclass__ = Singleton
        ''' Test class for Singleton metaclass.
        '''
        def __init__(self, a, b=2):
            self.a = a
            self.b = b

        def __str__(self):
            return 'a: {}, b: {}'.format(self.a, self.b)

        def __dict__(self):
            d = OrderedDict()
            d['a'] = self.a
            d['b'] = self.b
            return d

        def __repr__(self):
            return '{}(a={}, b={})'.format(type(self).__name__, self.a, self.b)


# Generated at 2022-06-21 09:02:20.642220
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        ''' Test class for Singleton '''
        __metaclass__ = Singleton

        def __init__(self, var):
            ''' __init__ function of TestSingleton '''
            self.__var = var

        def getvar(self):
            ''' function to get the __var of TestSingleton '''
            return self.__var

    obj1 = TestSingleton(8)
    obj2 = TestSingleton(9)

    assert(obj1 is obj2)
    assert(obj1.getvar() == obj2.getvar())

# Generated at 2022-06-21 09:02:26.234514
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self._a = a
            self._b = b

    x = X(1, 2)
    assert x._a == 1 and x._b == 2
    y = X(3, 4)
    assert y._a == 1 and y._b == 2


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 09:02:32.955966
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonObject1(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass
    s1 = SingletonObject1()
    s2 = SingletonObject1()
    assert s1 == s2


# Generated at 2022-06-21 09:02:35.449220
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-21 09:02:40.626252
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    obj1 = TestSingleton("obj1")
    obj2 = TestSingleton("obj2")

    assert obj1.name == "obj1"
    assert obj2.name == "obj1"

    assert obj1 == obj2

# Generated at 2022-06-21 09:02:44.610761
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object, metaclass=Singleton):
        def __init__(self, value = None):
            self.value = value

    # Make sure that two instances of A are the same object
    a1 = A(42)
    a2 = A(43)
    assert a1 is a2
    assert a1.value == 43

# Generated at 2022-06-21 09:02:53.722184
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """test method __call__ of class Singleton
    """

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs

        def get_args(self):
            return self._args

        def get_kwargs(self):
            return self._kwargs

    t = TestSingleton(1, 2, 3, a=1, b=2, c=3)
    assert t.get_args() == (1, 2, 3)
    assert t.get_kwargs() == {'a': 1, 'b': 2, 'c': 3}
    t2 = TestSingleton(2, 3, 4, a=2, b=3, c=4)
    assert t

# Generated at 2022-06-21 09:02:57.055471
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is not None
    assert Test() is Test()
    test = Test()

    class DifferentTest(object):
        __metaclass__ = Singleton

    assert test is not DifferentTest()

# Generated at 2022-06-21 09:03:01.893612
# Unit test for constructor of class Singleton
def test_Singleton():
    import types

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    obj1 = SingletonTest()
    obj2 = SingletonTest()
    assert obj1 is obj2
    assert obj1 == obj2
    assert type(obj1) == types.InstanceType
    assert type(obj2) == types.InstanceType

# Generated at 2022-06-21 09:03:10.220296
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    class B(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    a1 = A(10)
    a2 = A(20)
    assert a1 is a2 and a1.value == 10

    b1 = B(10)
    b2 = B(20)
    assert b1 is b2 and b1.value == 10

    assert a1 is not b1 and a1.value == 10 and b1.value == 10

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 09:03:13.405277
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(with_metaclass(Singleton)):
        pass
    a = TestClass()
    b = TestClass()
    assert a is b


# Generated at 2022-06-21 09:03:18.776650
# Unit test for constructor of class Singleton
def test_Singleton():
    class test1(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.s1 = 1

    a = test1()
    b = test1()
    assert a is b
    assert a.s1 == 1
    assert b.s1 == 1
    a.s1 = 4
    assert a.s1 == 4
    assert b.s1 == 4

# Generated at 2022-06-21 09:03:28.739865
# Unit test for constructor of class Singleton
def test_Singleton():
    class Dummy(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    a = Dummy(23)
    b = Dummy(42)
    assert a is b
    assert a.x == 42
    assert b.x == 42

# Generated at 2022-06-21 09:03:36.699967
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingletonClass(with_metaclass(Singleton)):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    instance1 = MySingletonClass(1, 1)
    print("instance1")
    print("  instance1.a = ", instance1.a)
    print("  instance1.b = ", instance1.b)
    instance1.b = 'b'
    print("  instance1.a = ", instance1.a)
    print("  instance1.b = ", instance1.b)

    instance2 = MySingletonClass(2, 2)
    print("instance2")
    print("  instance2.a = ", instance2.a)
    print("  instance2.b = ", instance2.b)

# Generated at 2022-06-21 09:03:45.275188
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global instance
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    assert not hasattr(TestSingleton, 'instance')

    instance = TestSingleton('Foo')
    assert isinstance(instance, TestSingleton)
    assert instance.name == 'Foo'
    assert TestSingleton.instance == 'Foo'
    assert TestSingleton.__instance == instance

    instance2 = TestSingleton('Bar')
    assert instance2 == 'Foo'
    assert instance2 == instance
    assert instance2 is instance


# Generated at 2022-06-21 09:03:48.153037
# Unit test for constructor of class Singleton
def test_Singleton():
    # Use the Class
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 == a2

# Generated at 2022-06-21 09:03:54.433306
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from operator import __eq__, __ne__

    from ansible.module_utils.six import with_metaclass
    from ansible.module_utils.six.moves import builtins

    msg = "Unexpected identity"
    class MySingleton(with_metaclass(Singleton, builtins.object)): pass

    s = MySingleton()
    t = MySingleton()

    # Ensure that s and t are the same instances.
    assert s is t, msg

    # Ensure that s and t are both equal to each other.
    assert __eq__(s, t), msg

    # Ensure that s and t are not unequal to each other.
    assert not __ne__(s, t), msg

# Generated at 2022-06-21 09:03:56.573226
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    instance_1 = TestClass()
    instance_2 = TestClass()

    assert instance_1 is instance_2

# Generated at 2022-06-21 09:03:57.989377
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        pass

    assert MyClass() is MyClass()



# Generated at 2022-06-21 09:04:01.685012
# Unit test for constructor of class Singleton
def test_Singleton():
    s = Singleton
    inst1 = s('spam', (), {})
    inst2 = s('spam', (), {})
    print(inst1 is inst2)

# Generated at 2022-06-21 09:04:11.310918
# Unit test for constructor of class Singleton
def test_Singleton():
    class ClsSingleton1(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.__dict__.update(kwargs)

    class SubClsSingleton1(ClsSingleton1):
        pass

    class OtherCls(object):
        pass

    inst = ClsSingleton1(z=42)
    c = SubClsSingleton1(x=12, y=13)
    try:
        assert c == inst
        assert c.x == 12
        assert c.y == 13
        assert c.z == 42
    except AttributeError:
        pass
    # Make sure it doesn't complain about not being initialized with a
    # dict.

# Generated at 2022-06-21 09:04:18.966517
# Unit test for constructor of class Singleton
def test_Singleton():
    class S1(object):
        __metaclass__ = Singleton
        def __init__(self, x=0):
            self.x = x

    class S2(object):
        __metaclass__ = Singleton

    assert S1().x == 0
    s1_1 = S1()
    assert s1_1.x == 0
    s1_2 = S1()
    assert s1_2.x == 0
    s1_2.x = 1
    assert s1_2.x == 1
    assert s1_1.x == 1

    s2_1 = S2()
    assert S2() is s2_1

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 09:04:34.343563
# Unit test for constructor of class Singleton
def test_Singleton():
    # create the singleton
    class MySingleton:
        __metaclass__ = Singleton

    # create 2 different instances
    instance1 = MySingleton()
    instance2 = MySingleton()

    # check if it's the same instance
    assert instance1 == instance2
    assert id(instance1) == id(instance2)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 09:04:39.172572
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        val = 1

        def __init__(self):
            self.val = MyClass.val
            MyClass.val += 1

    a1 = MyClass()
    a2 = MyClass()

    assert id(a1) == id(a2)
    assert a1.val == 2
    assert a2.val == 2

# vi: ts=4 expandtab

# Generated at 2022-06-21 09:04:49.141890
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import threading

    class Test1(object):
        __metaclass__ = Singleton

    class Test2(object):
        __metaclass__ = Singleton

    t1 = Test1()
    t2 = Test1()

    assert t1 is t2

    t3 = Test2()
    t4 = Test2()

    assert t3 is t4

    assert t1 is not t3

    def ts():
        t5 = Test1()

    th1 = threading.Thread(target=ts)
    th2 = threading.Thread(target=ts)

    th1.start()
    th2.start()

    th1.join()
    th2.join()



# Generated at 2022-06-21 09:04:54.635696
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass:
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.test_arg = arg

    assert(TestClass('test') == TestClass('test'))
    assert(TestClass('test').test_arg=='test')
    assert(TestClass('test1') == TestClass('test1'))
    assert(TestClass('test1').test_arg=='test1')
    assert(TestClass('test') == TestClass('test1'))
    assert(TestClass('test').test_arg=='test1')


test_Singleton___call__()

# Generated at 2022-06-21 09:04:59.264284
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self,test_arg):
            print("test_arg: {}".format(test_arg))
            self.test_arg=test_arg

    x=MyClass(1)
    y=MyClass(2)
    assert x.test_arg == 1
    assert x.test_arg == y.test_arg

# Generated at 2022-06-21 09:05:03.613557
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    a = A()
    b = B()
    assert a == A()  # True
    assert a != B()  # True
    assert b == B()  # True
    assert b != A()  # True
    assert a != b    # True
    assert b != a    # True

# Generated at 2022-06-21 09:05:06.727986
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(metaclass=Singleton):
        def __init__(self, x=0):
            self.x = x

    m1 = MySingleton(x=1)
    assert m1 is MySingleton()
    assert m1 is MySingleton(x=0)
    m1.x = 2
    m2 = MySingleton()
    assert m2.x == 2
    assert m1 is m2

# Generated at 2022-06-21 09:05:08.512016
# Unit test for constructor of class Singleton
def test_Singleton():
    assert issubclass(Singleton, type)
    assert Singleton('Singleton', (object,), {})


# Generated at 2022-06-21 09:05:13.948571
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    # Create a new sub type of Singleton
    class Subtype(object):
        __metaclass__ = Singleton

    # Create a few objects
    obj1 = Subtype()
    obj2 = Subtype()
    obj3 = Subtype()

    # Object 1, 2 and 3 should be the same object
    checker = unittest.TestCase()
    checker.assertTrue(obj1 == obj2)
    checker.assertTrue(obj2 == obj3)
    checker.assertTrue(obj3 == obj1)

# Generated at 2022-06-21 09:05:23.811278
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class S1(object):
        __metaclass__ = Singleton

    class S2(object):
        __metaclass__ = Singleton

    # Because these are singletons, these are exactly the same object
    assert S1() == S2()
    # Because these are singletons, these are exactly the same object
    assert id(S1()) == id(S2())

    # S1 is a singleton, so s1 and s1a are the same object
    s1 = S1()
    s1a = S1()
    assert s1 == s1a
    assert id(s1) == id(s1a)

    # S2 is a singleton, so s2 and s2a are the same object
    s2 = S2()
    s2a = S2()
    assert s2 == s2

# Generated at 2022-06-21 09:05:39.688896
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class SingletonTest(object):
        __metaclass__ = Singleton

    class TestSingleton(unittest.TestCase):
        def test_if_instances_are_the_same_the_same(self):
            first = SingletonTest()
            second = SingletonTest()

            return self.assertEqual(first, second)

    unittest.main()


# Generated at 2022-06-21 09:05:43.762403
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object, metaclass=Singleton):
        def __init__(self):
            self.x = 0

    s1 = S()
    assert s1.x == 0
    s2 = S()
    assert s2 is s1
    s2.x = 1
    assert s1.x == 1


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-21 09:05:45.623359
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Method __call__ is tested on class FactCache to check thread-safety
    pass



# Generated at 2022-06-21 09:05:50.593108
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.v = 0
    c1 = C()
    c2 = C()
    assert c1 is c2
    assert c1.v == 0
    assert c2.v == 0
    c1.v = 1
    assert c2.v == 1



# Generated at 2022-06-21 09:05:56.554769
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test_value = 1000

    # Test singleton functionality
    test_singleton1 = TestSingleton()
    test_singleton2 = TestSingleton()
    assert test_singleton1 is test_singleton2, "test_singleton1 and test_singleton2 are not the same object."
    assert test_singleton1.test_value == test_singleton2.test_value, "__init__ method of class TestSingleton not called"

    # Test singleton functionality - different from above
    # to make sure that __call__ is the method that is being called
    test_singleton3 = TestSingleton.__new__(TestSingleton)