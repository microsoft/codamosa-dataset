

# Generated at 2022-06-21 08:56:02.287784
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object, metaclass=Singleton):
        def __init__(self, param=None):
            self.value = param

    a = TestSingleton(1)
    b = TestSingleton()
    assert a == b
    assert a.value == b.value
    b.value = 2
    assert a.value == b.value

# Generated at 2022-06-21 08:56:04.436833
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton:
        __metaclass__ = Singleton

    assert(TestSingleton() is TestSingleton())



# Generated at 2022-06-21 08:56:11.657538
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  # Test with a base class
  class Test(object):
    __metaclass__ = Singleton
    def __init__(self):
      self.a = 0

  # Test with a derived class
  class TestDerived(Test):
    def __init__(self):
      super(TestDerived, self).__init__()
      self.b = 1
  # Test with a derived class which overriding __init__
  class TestDerivedOverride(Test):
    def __init__(self):
      self.b = 1

  # Test with a derived class which overriding __init__ and don't call parent one
  class TestDerivedOverrideNoParent(Test):
    def __init__(self):
      self.b = 1
      self.a = 0

  # Check __call__ of Singleton class
  assert Test() is Test()

# Generated at 2022-06-21 08:56:18.006379
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 'bar'

    instance1 = MySingleton()
    instance2 = MySingleton()

    assert instance1 == instance2
    assert instance1.foo == instance2.foo
    assert instance1 is instance2

    instance1.baz = 'qux'

    assert instance1.baz == instance2.baz

# Generated at 2022-06-21 08:56:20.082291
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        pass

    inst = Test()

    assert Test() is inst

# Generated at 2022-06-21 08:56:25.539479
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test:
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    t1 = Test('first')
    t2 = Test('second')
    t3 = Test('third')

    assert id(t1) == id(t2) == id(t3)


# Generated at 2022-06-21 08:56:31.249386
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increase(self):
            self.value += 1

    my_instance_1 = C()
    my_instance_2 = C()
    my_instance_1.increase()
    assert my_instance_1.value == my_instance_2.value



# Generated at 2022-06-21 08:56:36.372628
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(Singleton):
        def __init__(self):
            self.data = 'test'

    t = TestClass()
    assert t.data == 'test'

    # Second instantiation of the class should just return the first one
    t2 = TestClass()
    assert t2.data == 'test'
    assert id(t2) == id(t)

# Generated at 2022-06-21 08:56:41.505886
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = 'A'

    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)
    assert a1 is a2
    assert a1.name == a2.name == 'A'

# Generated at 2022-06-21 08:56:46.542273
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("__init__ of class A is called.")

    a = A()
    b = A()
    assert a is b

test_Singleton___call__()

# Generated at 2022-06-21 08:56:52.312589
# Unit test for constructor of class Singleton
def test_Singleton():
    class Testing(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass


    obj1 = Testing()
    obj2 = Testing()

    assert obj1 is obj2

# Generated at 2022-06-21 08:56:56.287355
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
           self.foo = foo

    a = Foo("a")
    b = Foo("b")
    assert a.foo == "a"
    assert b.foo == "a"

# Generated at 2022-06-21 08:56:58.063626
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        pass

    s = TestSingleton()
    assert id(s) == id(TestSingleton())

# Generated at 2022-06-21 08:57:02.052293
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import copy
    class single(object):
        __metaclass__ = Singleton

    x = single()
    y = single()

    assert x == y
    x.foo = 'bar'
    assert y.foo == 'bar'
    assert x == y

# Generated at 2022-06-21 08:57:11.311788
# Unit test for constructor of class Singleton
def test_Singleton():
    from collections import namedtuple

    class Class1(metaclass=Singleton):
        def __init__(self):
            pass

    class Class2(metaclass=Singleton):
        def __init__(self):
            self.var1 = "1"

    class Class3(metaclass=Singleton):
        def __init__(self):
            self.var1 = "1"
            self.var2 = namedtuple("var2", "a")(3)

    class Class4(metaclass=Singleton):
        def __init__(self):
            self.var1 = "1"
            self.var2 = namedtuple("var2", "a")(3)
            self.var3 = namedtuple("var3", "a b c")(5, 6, 7)


# Generated at 2022-06-21 08:57:23.660116
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Pets(object):
        __metaclass__ = Singleton
        animals = []

        def __init__(self, animals):
            if animals != None:
                self.animals = animals

        def add_pet(self, animal):
            self.animals.append(animal)

        def show_pets(self):
            for ani in self.animals:
                print('pet: ' + ani)

    cat = Pets(['Tom'])
    cat.add_pet('Garfield')
    dog = Pets(['Spot'])
    dog.add_pet('Lassy')

    cat.show_pets()
    dog.show_pets()
    assert cat == dog

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 08:57:27.418733
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, testparam):
            self.testparam = testparam

    assert TestSingleton('foo').testparam == 'foo'



# Generated at 2022-06-21 08:57:32.455922
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    obj1 = MySingleton()
    obj2 = MySingleton()

    assert obj1 is obj2



# Generated at 2022-06-21 08:57:35.422894
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
    obj1 = MyClass()
    obj2 = MyClass()
    assert id(obj1) == id(obj2)
    obj1.test = True
    assert obj2.test == True

# Generated at 2022-06-21 08:57:41.917929
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class SimpleClass(object):
        __metaclass__ = Singleton
        def test(self, a, b):
            return a, b

    c = SimpleClass()
    assert c.test(1, 2) == (1, 2)

    d = SimpleClass()
    assert c is d

    assert c.test(3, 4) == (3, 4)
    assert d.test(5, 6) == (5, 6)


# Generated at 2022-06-21 08:57:45.433414
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    # make first instance
    foo1 = Foo()

    # make second instance
    foo2 = Foo()

    # check if foo1 and foo2 is the same instance
    assert foo1 is foo2

# Generated at 2022-06-21 08:57:51.653677
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 'foo'

    s1 = TestSingleton()
    s2 = TestSingleton()
    assert s1.x == s2.x
    assert s1 == s2
    s1.x = 'bar'
    assert s2.x == 'bar'

# Generated at 2022-06-21 08:57:56.755741
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()

    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 08:58:03.954706
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 0

    obj1 = MyClass()
    obj2 = MyClass()
    assert obj1.val == 0
    assert obj2.val == 0
    obj1.val = 1
    assert obj1.val == 1
    assert obj2.val == 1
    obj2.val = 2
    assert obj1.val == 2
    assert obj2.val == 2
    assert obj1 is obj2

# Generated at 2022-06-21 08:58:07.704537
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 == foo2

# Generated at 2022-06-21 08:58:18.233388
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    # singleton class with constructor taking no arguments
    class Singleton0(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.count = 0

        def increment(self):
            self.count += 1

    instance = Singleton0()
    instance.increment()
    assert 1 == instance.count
    instance2 = Singleton0()
    instance2.increment()
    assert 2 == instance2.count
    instance3 = Singleton0()
    assert 2 == instance3.count

    # singleton class with constructor taking one argument
    class Singleton1(object):
        __metaclass__ = Singleton
        def __init__(self, param):
            self.count = param

        def increment(self):
            self.count += 1

    instance = Singleton1(1)


# Generated at 2022-06-21 08:58:21.741205
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        pass

    assert TestSingleton is TestSingleton()
    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-21 08:58:25.265736
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-21 08:58:36.950055
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    from unittest.mock import patch

    class InvalidSingleton(metaclass=Singleton):
        def __init__(self):
            pass

    class ValidSingleton(metaclass=Singleton):
        def __init__(self):
            self.test_field = "test_value"

    class ValidSingletonTest(unittest.TestCase):
        def test_instance_exists(self):
            self.assertTrue(isinstance(ValidSingleton(), ValidSingleton))

        def test_fields_match(self):
            self.assertEqual(ValidSingleton().test_field, "test_value")


# Generated at 2022-06-21 08:58:39.691013
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        #__metaclass__ = Singleton
        pass

    assert S() == S()
    assert bool(S()) is True

# Generated at 2022-06-21 08:58:48.361508
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    assert TestSingleton('test1').arg == 'test1'
    assert TestSingleton('test2').arg == 'test1'



# Generated at 2022-06-21 08:58:55.194673
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.msg = 'Singleton class'


# Generated at 2022-06-21 08:59:00.209395
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    x = A('a')
    y = A('b')
    assert x is y
    assert x.a == 'a'

# Generated at 2022-06-21 08:59:05.203203
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    o1 = C('object1')
    o2 = C('object2')
    assert o1 == o2
    assert o1.x == 'object1'
    assert o2.x == 'object1'

# Generated at 2022-06-21 08:59:07.482318
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass

    assert type(A()) is A().__class__
    assert A() is A()

# Generated at 2022-06-21 08:59:13.975755
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest
    class MockSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, value=None):
            self.value = value
    # Test first instance
    instance = MockSingleton()
    assert isinstance(instance, MockSingleton)
    assert instance.value is None
    # Test second instance
    instance2 = MockSingleton()
    assert isinstance(instance2, MockSingleton)
    assert instance2 is instance
    # Test errors raised when trying to instantiate the second instance
    with pytest.raises(TypeError) as excinfo:
        instance2 = MockSingleton("second instance")
    assert "is already instantiated" in excinfo.exconly()

# Generated at 2022-06-21 08:59:22.335733
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """To test Singleton's __call__ method with a simple class."""
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 5

    # call __call__ twice
    s = TestSingleton()
    assert s.value == 5
    assert s.value == 5

    # assign a value
    s.value = "new value"

    # call __call__ again
    s = TestSingleton()
    assert s.value == "new value"
    assert s.value == "new value"


# Generated at 2022-06-21 08:59:31.295124
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class _Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.number = 0

        def inc(self):
            self.number += 1

    test1 = _Test()
    test1.inc()
    test2 = _Test()
    assert test1.number == 1
    assert test1 is test2
    test2.inc()
    assert test2.number == 2
    assert test1 is test2

    class _Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.number = 0

        def inc(self):
            self.number += 1

    test1 = _Test()
    test2 = _Test()
    assert test1.number == 0
    assert test1 is test2
    test1.inc()

# Generated at 2022-06-21 08:59:35.826722
# Unit test for constructor of class Singleton
def test_Singleton():
    class Snippets(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    o1 = Snippets()
    o1.a = 2
    o2 = Snippets()
    assert o1 is o2
    assert o1.a == 2

# Generated at 2022-06-21 08:59:37.920169
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton

    assert SingletonClass() is SingletonClass()

# Generated at 2022-06-21 08:59:47.245981
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass


# Generated at 2022-06-21 08:59:57.010845
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import mock
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include_role import TaskIncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.clean import clean_facts

    # The tested class
    clss = (Play, Task, TaskInclude, TaskIncludeRole, Handler, Block)

    playbook_name = 'test'
    mock_loader = mock.Mock()
    mock_loader.list_templates.return_value = ['test_template']
    mock_loader.path_

# Generated at 2022-06-21 08:59:58.192828
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-21 09:00:06.481457
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    import copy
    t1 = TestSingleton()
    t2 = TestSingleton()
    t3 = copy.copy(t1)
    t4 = copy.copy(t1)
    t5 = TestSingleton()
    assert id(t1) == id(t2)
    assert id(t1) == id(t3)
    assert id(t1) == id(t4)
    assert id(t1) == id(t5)

# Generated at 2022-06-21 09:00:09.773678
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 1

    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 2

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-21 09:00:14.396969
# Unit test for constructor of class Singleton
def test_Singleton():
    class a(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    a1 = a()
    a2 = a()
    assert(a1 is a2)


if __name__ == '__main__':
    test_Singleton()