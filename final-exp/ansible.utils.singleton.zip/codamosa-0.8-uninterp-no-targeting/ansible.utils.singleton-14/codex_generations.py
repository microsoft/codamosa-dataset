

# Generated at 2022-06-21 08:55:59.224745
# Unit test for constructor of class Singleton
def test_Singleton():
    assert not Singleton('a', (), {})



# Generated at 2022-06-21 08:56:07.240982
# Unit test for constructor of class Singleton
def test_Singleton():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.value = arg

    class TestSingletonClass(unittest.TestCase):
        def test_singleton_used(self):
            t1 = TestClass(17)
            t2 = TestClass(23)
            self.assertEqual(t1, t2)
            self.assertEqual(t1.value, 17)
            self.assertEqual(t2.value, 17)

    unittest.main()

# Generated at 2022-06-21 08:56:18.922051
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread

    class SingletonTest(object, metaclass=Singleton):
        def __init__(self):
            self.value = 0
            self.rlock = RLock()

        def increase(self, by=1):
            with self.rlock:
                self.value += by

    lst = []
    def foo(name, num):
        instance = SingletonTest()
        instance.increase(num)
        lst.append(instance.value)

    threads = [Thread(target=foo, args=("Thread {}".format(i), i)) for i in range(10)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    assert len(set(lst)) == len(lst)

# Generated at 2022-06-21 08:56:25.539817
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass = Singleton):
        pass

    class B(metaclass = Singleton):
        pass

    # Ensure that different class instances are not equal
    # (and therefore different instances)
    assert(A() is not B())

    # Note that the following will not fail unless you have defined
    # another metaclass for the Singleton class
    assert(A() is A())
    assert(B() is B())

# Generated at 2022-06-21 08:56:32.815467
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

        def __init__(self):
            self.num = 2

        def test(self):
            self.num += 1

    x = A()
    y = A()
    assert x is x
    assert x is y
    assert x is A()
    assert y is x
    assert y is y

    x.test()
    assert x.num == 3
    assert y.num == 3

    y.test()
    assert x.num == 4
    assert y.num == 4

# Generated at 2022-06-21 08:56:43.073834
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    
    from Queue import Queue
    
    class Foo(object):
        __metaclass__ = Singleton
        def __init(self, x):
            self.x = x 
    
    f = Foo(x=9)
    assert isinstance(f, Foo)
    assert f.x == 9
    assert Foo(x=10) is f
    assert f.x == 9
    
    class Bar(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x 
    
    b = Bar(x=9)
    assert isinstance(b, Bar)
    assert b.x == 9
    assert Bar(x=10) is b
    assert b.x == 9
    
    class QueueWithLock:
        __metaclass__

# Generated at 2022-06-21 08:56:47.004408
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    s1 = SingletonTest()
    s2 = SingletonTest()
    assert(s1 is s2)


# Generated at 2022-06-21 08:56:56.551382
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, x=1):
            self.x = x

    # test creation of singleton
    s1 = TestSingleton()
    assert s1.x == 1
    assert TestSingleton().__dict__ == s1.__dict__

    # test that creation of another instance of singleton returns same object
    s2 = TestSingleton(x=2)
    assert s2.x == 1
    assert s2.__dict__ == s1.__dict__
    assert s2 is s1

    # test that creation of another instance with arguments returns same object with different arguments
    s3 = TestSingleton(x=3)
    assert s3.x == 1
    assert s3.__dict__ == s1.__dict__
   

# Generated at 2022-06-21 08:57:04.426540
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.count = 0

    # Verify that no instance exists, and create one
    assert TestSingleton.__instance is None
    instance = TestSingleton()  # Singleton.__call__ calls Singleton.__init__
    assert TestSingleton.__instance is not None
    assert instance.count == 0

    # Create another instance and verify it's the same as the first one
    instance2 = TestSingleton()
    assert instance == instance2
    assert instance.count == 0

    # Modify the first instance, and verify the changes are reflected in the
    # second instance
    instance.count = 1
    assert instance2.count == 1



# Generated at 2022-06-21 08:57:09.285945
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = 0

        def get_test(self):
            return self.test

        def add_test(self):
            self.test += 1

    a = MyClass()
    assert a.test == 0

    # Make sure MyClass is a Singleton class
    b = MyClass()
    assert a is b

    a.add_test()
    assert a.get_test() == 1
    assert b.get_test() == 1
    assert a.get_test() == b.get_test()

# Generated at 2022-06-21 08:57:15.971795
# Unit test for constructor of class Singleton
def test_Singleton():
    class BaseClass(object):
        def __init__(self, x):
            self.x = x

    class TestClass(BaseClass):
        __metaclass__ = Singleton

        @staticmethod
        def foo(x):
            assert x == TestClass.__instance.x

    TestClass(4)
    TestClass.foo(4)

# Generated at 2022-06-21 08:57:24.640598
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Case_1: If an instance of the class exists, it's returned
    class Test1(object):
        __metaclass__ = Singleton

    test_obj_1 = Test1()
    test_obj_2 = Test1()
    assert test_obj_1 == test_obj_2

    # Case_2: Otherwise a single instance is instantiated and returned
    class Test2(object):
        __metaclass__ = Singleton

    test_obj_1 = Test2()
    test_obj_2 = Test2()
    assert test_obj_1 == test_obj_2


# Generated at 2022-06-21 08:57:30.458356
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    new_class = MyClass(42)
    assert new_class.value == 42
    assert new_class is MyClass(43)
    assert new_class.value == 42
    assert new_class is MyClass()

# Generated at 2022-06-21 08:57:37.131086
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

        def increment_x(self):
            self.x += 1

    a1 = A()
    a2 = A()

    assert(a1 is a2)

    a1.increment_x()

    assert(a1.x == 2)
    assert(a2.x == 2)


# Generated at 2022-06-21 08:57:46.746051
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    class MySingletonSub1(MySingleton):
        pass

    class MySingletonSub2(MySingleton):
        pass

    obj1 = MySingleton()
    obj2 = MySingleton()
    obj3 = MySingletonSub1()
    obj4 = MySingletonSub2()
    obj5 = MySingletonSub1()
    obj6 = MySingletonSub2()
    assert obj1 is obj2
    assert obj3 is obj5
    assert obj4 is obj6
    assert obj1 is not obj3
    assert obj1 is not obj4

# Generated at 2022-06-21 08:57:49.911217
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert(a is b)



# Generated at 2022-06-21 08:57:58.932000
# Unit test for constructor of class Singleton
def test_Singleton():
  class TestSingleton(object):
    __metaclass__ = Singleton
    def __init__(self):
      self.a = 1
  # Class TestSingleton is still not an instance of TestSingleton
  assert(type(TestSingleton) is type)
  # TestSingleton() create an instance
  a = TestSingleton()
  assert(type(a) is TestSingleton)
  assert(type(TestSingleton) is type)
  # Second time TestSingleton() called, it will return the previous instance
  b = TestSingleton()
  assert(a is b)
  assert(TestSingleton.__instance is a is b)
  assert(type(TestSingleton) is type)

# Double check if the instance created is thread safe
import threading


# Generated at 2022-06-21 08:58:04.795124
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    bar1 = Bar()
    bar2 = Bar()
    assert foo1 is foo2
    assert bar1 is bar2
    assert foo1 is not bar1


# Generated at 2022-06-21 08:58:11.384439
# Unit test for constructor of class Singleton
def test_Singleton():

    # Define a class that inherits from Singleton class
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            print(arg)

    # Create an object
    obj1 = MySingleton("a")

    # Create another object
    obj2 = MySingleton("b")

    # Assert that object 1 and 2 are the same
    assert obj1 is obj2


# Generated at 2022-06-21 08:58:16.061601
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    instance1 = TestClass(1)
    instance2 = TestClass(2)
    assert instance1.val == 1
    assert instance1 is instance2

# Generated at 2022-06-21 08:58:24.643582
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self, x, y):
            self.x = x
            self.y = y

    a = Foo(1, 2)
    b = Foo(3, 4)
    assert a is b
    assert a.x == 1
    assert b.x == 1
    assert a.y == 2
    assert b.y == 2

# Generated at 2022-06-21 08:58:34.889357
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    t1 = TestSingleton(1, 2, 3)
    t2 = TestSingleton(a=1, b=2, c=3)
    t3 = TestSingleton(1, 2, 3, a=1)

    assert t1 is t2
    assert t2 is t3
    assert t1.args == (1, 2, 3)
    assert t1.kwargs == {"a": 1}

    # Corner case
    assert TestSingleton().__class__ == TestSingleton
    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-21 08:58:37.896080
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()
    assert f1 == f2

# Generated at 2022-06-21 08:58:45.952018
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase
    from collections import namedtuple
    class First(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 'first'

    class Second(First):
        def __init__(self):
            self.val = 'second'

    class Third(First):
        def __init__(self):
            super(Third, self).__init__()
            self.val = 'third'

    class Fourth(First):
        def __init__(self):
            super(Fourth, self).__init__()
            self.__dict__ = {'val': 'fourth'}

    class Fifth(First):
        def __init__(self):
            super(Fifth, self).__init__()

# Generated at 2022-06-21 08:58:56.323359
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, arg1=None):
            self.arg1 = arg1

    a1 = A('arg1')
    a2 = A('hello')
    assert a1 is a2
    assert a1.arg1 == 'arg1'

    class B(A):
        def __init__(self, arg1=None):
            self.arg1 = arg1
            self.arg2 = None

    b1 = B('arg1')
    b2 = B('hello')
    assert b1 is b2
    assert b1.arg1 == 'arg1'
    assert b1.arg2 is None

    class C(B):
        def __init__(self, arg1=None):
            self.arg1 = arg1
           

# Generated at 2022-06-21 08:59:01.574416
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, args):
            self.args = args

    a = SingletonTest(('a',))
    b = SingletonTest(('b',))
    assert a is b

# Generated at 2022-06-21 08:59:03.091300
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton



# Generated at 2022-06-21 08:59:07.090088
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    t = Test(10)
    assert t.value == 10
    t = Test(20)
    assert t.value == 10

# Generated at 2022-06-21 08:59:13.799247
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name
            print("init TestSingleton with " + name)

    class ConcreteSingleton(TestSingleton):
        def __init__(self, name):
            TestSingleton.__init__(self, name)
            print("init ConcreteSingleton with " + name)

    instance1 = ConcreteSingleton("instance1")
    instance2 = ConcreteSingleton("instance2")

    # instance1 and instance2 are the same instance
    assert instance1 == instance2

    # instance1.name is "instance1" but instance2.name is "instance2"
    print("instance1.name: " + instance1.name)

# Generated at 2022-06-21 08:59:17.108146
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class FakeClass(object):
        __metaclass__ = Singleton
        pass
    fake_instance1 = FakeClass()
    fake_instance2 = FakeClass()
    assert fake_instance1 is fake_instance2

# Generated at 2022-06-21 08:59:26.771075
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = "Hello World!"

    s = TestSingleton()
    print(s.x)
    t = TestSingleton()
    print(t.x)
    print(s.x == t.x)
    assert (s.x == t.x)
    print(s == t)
    assert (s == t)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:59:27.977060
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton('foo', (), {}) is Singleton('foo', (), {})

# Generated at 2022-06-21 08:59:33.184857
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.state = 1

        def get_state(self):
            return self.state

        def set_state(self, state):
            self.state = state

    assert Test() == Test()
    assert Test().get_state() == Test().get_state()
    Test().set_state(2)
    assert Test().get_state() == Test().get_state()
    Test().set_state(3)
    assert Test().get_state() == Test().get_state()



# Generated at 2022-06-21 08:59:43.213297
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    if a != b:
        raise AssertionError('a != b')

    if not a:
        raise AssertionError('a is None')

    if not b:
        raise AssertionError('b is None')

    if id(a) != id(b):
        raise AssertionError('a != b')

    if a.__class__.__name__ != 'A':
        raise AssertionError('a != A')

    if b.__class__.__name__ != 'A':
        raise AssertionError('b != A')


# Generated at 2022-06-21 08:59:49.468663
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = 'test_class'

    a1 = TestClass()
    a2 = TestClass()
    assert a1 is a2
    assert a1.name == 'test_class'
    assert a2.name == 'test_class'

# Generated at 2022-06-21 08:59:53.983239
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo():  # pylint: disable=too-few-public-methods
        """Test class"""
        __metaclass__ = Singleton

    assert Foo is Foo()
    assert Foo() is Foo()
    assert not Foo() != Foo()
    assert not Foo is not Foo()
    assert not Foo() is not Foo()

# Generated at 2022-06-21 08:59:59.831382
# Unit test for constructor of class Singleton
def test_Singleton():

    # Defining new class AnsiSingleton.
    class AnsiSingleton(metaclass=Singleton):
        pass
    
    # Testcase - Ensure that AnsiSingleton is not none.
    assert(AnsiSingleton() is not None)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 09:00:05.376653
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    # The first call of TestSingleton() must create an instance
    s0 = TestSingleton()

    # The second call of TestSingleton() must return the same instance
    s1 = TestSingleton()

    # The instance is properly returned
    assert s0 == s1

    # The instance is the same
    assert s0 is s1

# Generated at 2022-06-21 09:00:09.631134
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    with Singleton.__rlock:
        Singleton.__instance = None

    class TestSingleton(metaclass=Singleton):
        pass

    instance1 = TestSingleton()
    assert instance1 is not None
    instance2 = TestSingleton()
    assert instance2 is not None
    assert instance1 is instance2



# Generated at 2022-06-21 09:00:10.911853
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton.__instance is None
    assert Singleton.__rlock is not None