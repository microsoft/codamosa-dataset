

# Generated at 2022-06-21 08:56:02.545368
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("MySingleton instance created for the first time")

    a = MySingleton()
    b = MySingleton()
    assert a==b

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 08:56:08.399445
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(B, metaclass=Singleton):
        pass

    with pytest.raises(TypeError):
        A('a', 'b', 'c')

    a = A()
    assert a.a == 'a'
    assert a.b == 'b'
    assert a.c == 'c'

    a1 = A()
    assert id(a) == id(a1)
    a1.a = 'aa'
    assert a.a == 'aa'
    assert id(a) == id(a1)


# Generated at 2022-06-21 08:56:12.016013
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    print(id(A()))
    print(id(A()))


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:56:17.192582
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = 'baz'
    foo1 = Foo()
    assert foo1.foo == 'baz'
    foo2 = Foo()
    assert foo2.foo == 'baz'
    assert foo1 is foo2

# Generated at 2022-06-21 08:56:22.801993
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, v):
            self.v = v

    a1 = A(1)
    a2 = A(2)
    assert a1 == a2
    assert a1.v == 2
    assert a2.v == 2


# Generated at 2022-06-21 08:56:33.318423
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = True

    a = A()
    b = A()

    assert(a is b)
    assert(a.foo)
    assert(b.foo)
    assert(a.foo is b.foo)
    assert(type(a) is type(b))

# Test for errors in Singleton
# def test_Singleton_error():
#     class A(object):
#         __metaclass__ = Singleton
#
#         def __init__(self, *args):
#             pass
#
#     with py.test.raises(TypeError):
#         a = A()
#
#     with py.test.raises(TypeError):
#         a = A(1)

# Generated at 2022-06-21 08:56:36.088848
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

    a = C()
    b = C()

    assert a is b


# Generated at 2022-06-21 08:56:41.585483
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # It returns the same instance if it is called several times.
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, abc):
            self.abc = abc

    s1 = TestSingleton('s1')
    s2 = TestSingleton('s2')
    assert s1 is s2


# Generated at 2022-06-21 08:56:47.102433
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("Foo init")

    assert Foo() is Foo(), "Foo has to be a singleton"
    assert Foo() is Foo(), "Foo has to be a singleton"


# Generated at 2022-06-21 08:56:49.751631
# Unit test for constructor of class Singleton
def test_Singleton():
    global i1
    global i2

    class Foo(metaclass=Singleton):
        pass

    i1 = Foo()
    i2 = Foo()

    print([Foo(), Foo(), Foo(), Foo()])

    assert i1 == i2

# Generated at 2022-06-21 08:56:55.033122
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TempSingletonClass(object):
        __metaclass__ = Singleton

    assert TempSingletonClass() == TempSingletonClass()

# Generated at 2022-06-21 08:57:04.208087
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)

    print('a1 is A: %s' % (a1 is A))
    print('A(x=1) is {a.x=%s}' % a1.x)

    a2 = A(2)

    print('a2 is a1: %s' % (a2 is a1) )
    print('a2 is A: %s' % (a2 is A))
    print('A(x=2) is {a.x=%s}' % a2.x)



# Generated at 2022-06-21 08:57:06.518338
# Unit test for constructor of class Singleton
def test_Singleton():
    """Unit test for Singleton.
    """
    class Myclass(metaclass=Singleton):
        pass

    Myclass()
    Myclass()
    Myclass()

# Generated at 2022-06-21 08:57:11.237349
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyCls(metaclass=Singleton):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    res1 = MyCls(1, 2)
    res2 = MyCls(3, 4)
    assert res1 == res2
    assert res1.a == 1
    assert res1.b == 2

# Generated at 2022-06-21 08:57:22.986613
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class test_Singleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_id = None

        def test(self):
            return 1

    class test_Singleton_A(test_Singleton):
        def __init__(self):
            self.test_id = 'A'

    class test_Singleton_B(test_Singleton):
        def __init__(self):
            self.test_id = 'B'

    assert test_Singleton_A().test() == 1
    assert test_Singleton_A().test_id == 'A'
    assert test_Singleton_B().test() == 1
    assert test_Singleton_B().test_id == 'B'
    assert test_Singleton_A() == test_Singleton_B()

# Generated at 2022-06-21 08:57:33.502049
# Unit test for constructor of class Singleton
def test_Singleton():
    class Dummy(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    assert Dummy(1).value == 1
    assert Dummy("Foo").value == "Foo"
    assert Dummy("Bar").value == "Bar"

    dummy_Foo_instance = Dummy("Foo")
    dummy_Bar_instance = Dummy("Bar")

    assert dummy_Foo_instance is dummy_Bar_instance
    assert dummy_Foo_instance is not None
    assert dummy_Bar_instance is not None
    assert dummy_Foo_instance.value == dummy_Bar_instance.value
    assert dummy_Foo_instance is dummy_Bar_instance
    assert dummy_Foo_instance.value == dummy_Bar_instance.value

# Generated at 2022-06-21 08:57:35.525470
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert id(a) == id(b)



# Generated at 2022-06-21 08:57:39.857863
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    tc1 = TestClass()
    tc2 = TestClass()

    assert tc1 is tc2
    assert tc1.a == tc2.a

# Generated at 2022-06-21 08:57:51.526389
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    from unittest import TestCase, skip

    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton
        def __init__(self, num):
            self._num = num

    class C(object):
        __metaclass__ = Singleton
        def __init__(self, num):
            self._num = num

        def __eq__(self, obj):
            return self._num == obj._num

    class D(object):
        __metaclass__ = Singleton
        def __init__(self, num):
            self._num = num

        def __cmp__(self, obj):
            return self._num.__cmp__(obj._num)


# Generated at 2022-06-21 08:58:00.246400
# Unit test for constructor of class Singleton
def test_Singleton():
    import random

    s = Singleton('Singleton', (), {})

    def run_singleton_test(klass, args=None, kwargs=None):
        """Run a singleton test on a singleton class."""
        args = args or []
        kwargs = kwargs or {}

        # Check if the singleton is constructed.
        a = klass(*args, **kwargs)
        assert isinstance(a, klass)

        # Check if the singleton is always the same.
        b = klass(*args, **kwargs)
        assert a is b
        assert id(a) == id(b)

    class A(object):
        __metaclass__ = Singleton

    # Test singleton class with no parameters.
    run_singleton_test(A)

    # Test singleton class with one

# Generated at 2022-06-21 08:58:13.197352
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test: Initialization
    with Test_Singleton___call(1) as test:
        assert test.__instance == None
        assert test.__call__(2) == 1
        assert test.__instance == 1
    # Test: Multiple calls
    with Test_Singleton___call(3) as test:
        assert test.__call__(4) == 3
        assert test.__instance == 3
    # Test: Multiple calls in different instances
    with Test_Singleton___call(2) as test1, Test_Singleton___call(5) as test2:
        assert test1.__call__(1) == 2
        assert test2.__call__(4) == 5
        assert test1.__instance == 2
        assert test2.__instance == 5


# Generated at 2022-06-21 08:58:16.612720
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    s1 = MySingleton()
    s2 = MySingleton()

    assert s1 is s2
    assert id(s1) == id(s2)

# Generated at 2022-06-21 08:58:19.281792
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class MySingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 1

    assert MySingletonClass() is MySingletonClass()

# Generated at 2022-06-21 08:58:30.796182
# Unit test for constructor of class Singleton
def test_Singleton():

    from test import Test
    from test import test_config

    def _reset():
        test_config.reset()
        Test.__instance = None

    test_config['suppress_deprecated_messages'] = True
    _reset()

    # invoke Singleton as a metaclass
    class TestSingleton(Test):
        __metaclass__ = Singleton

    class TestSingleton2(Test):
        __metaclass__ = Singleton

    class TestSingleton3(Test):
        __metaclass__ = Singleton

    # Test that _reset works correctly
    assert Test.__instance is None, Test.__instance

    # Test that singletons don't share the same instance
    assert TestSingleton() is not TestSingleton2()
    assert TestSingleton2() is not TestSingleton3()

    # Test that instant

# Generated at 2022-06-21 08:58:37.331315
# Unit test for constructor of class Singleton
def test_Singleton():
    # pylint: disable=W0201
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 0

    a = Test()
    b = Test()

    assert a is b
    assert id(a) == id(b)
    assert a.val == b.val


# Generated at 2022-06-21 08:58:43.531123
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test that Singleton metaclass instantiates only one object."""

    # pylint: disable=abstract-class-not-used
    class TestSingleton(object):
        """
        The TestSingleton class uses the Singleton metaclass.
        """
        __metaclass__ = Singleton

    # Create two objects using class TestSingleton.  Despite the creation
    # of two objects, there is only one instance of TestSingleton.
    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1 is t2

# Generated at 2022-06-21 08:58:51.089543
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 1

    a = A()
    b = A()

    # Verify that instances a and b are references to the same object
    assert a is b

    # Verify that instances a and b both have
    # attribute foo with value 1
    assert hasattr(a, 'foo')
    assert hasattr(b, 'foo')
    assert a.foo == b.foo
    assert a.foo == 1

# Generated at 2022-06-21 08:58:56.141491
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class HelperSingleton(object):
        __metaclass__ = Singleton

    a = HelperSingleton()
    b = HelperSingleton()

    assert a is b
    assert a.__class__ is b.__class__
    assert a.__dict__ is b.__dict__
    assert a == b
    assert a.__dict__ == b.__dict__
    assert type(a) is type(b)



# Generated at 2022-06-21 08:59:03.092215
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object, metaclass=Singleton):
        def __init__(self, val):
            self.val = val

    a = A(1)
    a2 = A(2)
    print(id(a) == id(a2))
    print(a.val)
    print(a2.val)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 08:59:10.142046
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert issubclass(Singleton, type)
    # The following assertion is to ensure that Singleton is a direct subclass
    # of the 'type' class
    assert Singleton.__mro__ == (Singleton, type, object)
    assert Singleton.__bases__ == (type,)
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = True

    instance_1 = Test()
    instance_2 = Test()
    assert instance_1.test
    assert instance_2.test

# Generated at 2022-06-21 08:59:14.518166
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 == a2



# Generated at 2022-06-21 08:59:19.735572
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(metaclass=Singleton):
        def __init__(self):
            pass

    # class is initialized for the first time
    my_first_singleton = MySingleton()

    # class is already initialized, instance already exists
    my_second_singleton = MySingleton()

    assert my_first_singleton is my_second_singleton

# Generated at 2022-06-21 08:59:23.940350
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

    s1 = SingletonTest()
    s2 = SingletonTest()
    assert s1 is s2

# Generated at 2022-06-21 08:59:31.604984
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert Singleton.__call__.__doc__ == 'Metaclass for classes that wish to implement Singleton functionality. ' \
                                        'If an instance of the class exists, it\'s returned, otherwise a single ' \
                                        'instance is instantiated and returned.'

    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self._flag = 0

        def set(self):
            self._flag = 1

        def get(self):
            return self._flag


    # Test that a Singleton class indeed returns the same instance
    # when called multiple times.
    f1 = Foo()
    f1.set()
    assert f1.get() == 1

    f2 = Foo()
    assert f1 == f2

    # Test that singleton is thread-safe.

# Generated at 2022-06-21 08:59:34.792117
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    instance1 = TestSingleton()
    instance2 = TestSingleton()

    assert instance1 is instance2



# Generated at 2022-06-21 08:59:36.937529
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    assert MyClass() is MyClass()

# Generated at 2022-06-21 08:59:48.423992
# Unit test for constructor of class Singleton
def test_Singleton():
    from collections import OrderedDict
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name
            self.s = OrderedDict()
            self.s['first'] = 1

    obj1 = Test('test')
    assert(obj1.name == 'test')

    obj2 = Test('test')
    assert(obj1 is obj2)

    obj3 = Test('test2')
    assert(obj1 is obj3)
    assert(obj1.name == 'test2')

    obj1.s['second'] = 2
    assert(obj1.s.keys() == ['first', 'second'])

    assert(obj1.s == obj2.s)
    assert(obj2.s == obj3.s)

# Generated at 2022-06-21 08:59:51.971454
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonClass(object):
        __metaclass__ = Singleton
    obj1 = SingletonClass()
    obj2 = SingletonClass()
    assert obj1==obj2


# Generated at 2022-06-21 08:59:57.917240
# Unit test for constructor of class Singleton
def test_Singleton():
    from unittest import TestCase, main

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    class SingletonTests(TestCase):

        def test_create_instance(self):
            # Create the first instance
            instance1 = SingletonTest('test')
            # Create the second instance
            instance2 = SingletonTest('test')

            # Check to ensure that the two instances are the same
            self.assertEqual(instance1, instance2)
            self.assertIs(instance1, instance2)

    main()

# Generated at 2022-06-21 09:00:08.611429
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.id = id(self)

    # first instance
    foo1 = Foo()
    assert foo1.id == id(Foo())
    assert Foo().id == id(Foo())

    # second instance
    foo2 = Foo()
    assert foo1.id == foo2.id
    assert id(foo1) == id(foo2)
    assert id(foo1) == id(Foo())
    assert id(foo2) == id(Foo())

    # third instance
    foo3 = Foo()
    assert foo3.id == foo2.id
    assert id(foo3) == id(foo2)
    assert id(foo3) == id(Foo())

# Generated at 2022-06-21 09:00:15.961319
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = 'test'

    assert TestSingleton.__dict__['_Singleton__instance'] is None
    a = TestSingleton()
    assert TestSingleton.__dict__['_Singleton__instance'] == a
    TestSingleton.__dict__['_Singleton__instance'] = None
    b = TestSingleton()
    assert a == b
    assert TestSingleton.__dict__['_Singleton__instance'] == a


# Generated at 2022-06-21 09:00:22.140486
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    class Bar(Foo):
        def __init__(self, x, y):
            Foo.__init__(self, x)
            self.y = y

    instance1 = Foo(1)
    instance2 = Foo(2)

    assert instance1 is instance2
    assert instance1.x == 1

    instance3 = Bar(3, 4)
    instance4 = Bar(5, 6)

    assert instance3 is instance4
    assert instance3.x == 3
    assert instance3.y == 4



# Generated at 2022-06-21 09:00:24.507151
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(metaclass=Singleton):
        pass
    s1 = SingletonClass()
    s2 = SingletonClass()
    assert (s1 == s2)

# Generated at 2022-06-21 09:00:28.137905
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    class MySingletonSubClass(MySingleton):
        pass

    s = MySingleton()
    s2 = MySingleton()
    assert(s is s2)

    s3 = MySingletonSubClass()
    assert(s3 is s)

# Generated at 2022-06-21 09:00:31.211351
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 == test2


# Generated at 2022-06-21 09:00:36.730624
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, *args):
            self.attrs = args

    instance = MyClass('a', 'b')

    assert instance.attrs == ('a', 'b')

    instance2 = MyClass('c', 'd', 'e')

    assert instance is instance2
    assert instance2.attrs == ('a', 'b')

# Generated at 2022-06-21 09:00:39.663890
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

        def __repr__(self):
            return 'Singleton({0.value})'.format(self)

    assert SingletonTest() is SingletonTest()



# Generated at 2022-06-21 09:00:42.809473
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    c = A()
    assert a is b
    assert b is c
    assert a is c

# Generated at 2022-06-21 09:00:46.808690
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("__init__")

    assert id(A()) == id(A())

# Generated at 2022-06-21 09:00:54.185089
# Unit test for constructor of class Singleton
def test_Singleton():
    class Example(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = Example()
    b = Example()
    assert a is b

    class Example2(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self._value = value

    c = Example2(3)
    d = Example2(4)
    assert c is d

    class Example3(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self._value = value

    e = Example3(6)
    f = Example3()

    assert e is f

# Generated at 2022-06-21 09:01:00.042386
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, i):
            self.i = i
    a = TestClass(1)
    b = TestClass(2)
    assert a.i == 1
    assert b.i == 1

# Generated at 2022-06-21 09:01:03.204863
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
    foo = Foo()
    foo2 = Foo()
    assert foo2 is foo



# Generated at 2022-06-21 09:01:07.999098
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        # check for singleton
        obj1 = SingletonClass()
        obj2 = SingletonClass()
        assert obj1 == obj2
    except Exception as e:
        print('test_Singleton___call__ failed: %s' % e)


# Generated at 2022-06-21 09:01:09.953738
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A() is A()


# Generated at 2022-06-21 09:01:11.957551
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

    s1 = S()
    s2 = S()
    assert s1 is s2

# Generated at 2022-06-21 09:01:14.105567
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    a = Singleton('A', (object,), {})()
    b = Singleton('B', (object,), {})()

    assert a is b


# Generated at 2022-06-21 09:01:16.448978
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from tests.unit.v2_7.lib.shared.singleton_test_class import SingletonTestClass

    a = SingletonTestClass()
    b = SingletonTestClass()
    assert a is b

# Generated at 2022-06-21 09:01:26.642491
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        """
        Example class.
        """
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            self.lst = []
            self.lst.extend(args)
            self.lst.extend(kwargs.values())

    a = MyClass(1, 2)
    b = MyClass(3)
    c = MyClass(4)
    d = MyClass()
    e = MyClass(a=1)
    f = MyClass(a=2)
    g = MyClass()
    h = MyClass(a=1)

    print(a)
    print(b)
    print(c)
    print(d)
    print(e)
    print(f)
    print(g)
   

# Generated at 2022-06-21 09:01:30.177938
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        pass

    foo1 = Foo()
    foo2 = Foo()
    assert id(foo1) == id(foo2)

# Generated at 2022-06-21 09:01:32.940520
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test1(metaclass=Singleton):
        pass

    t1 = Test1()
    t2 = Test1()
    assert t1 == t2

# Generated at 2022-06-21 09:01:41.096917
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansibullbot.triagers.mixins.github import GithubClient
    with open('tests/unit/data/github.token', 'rb') as f:
        token = f.read()

    c = GithubClient()

    assert c is Singleton(token)

# Generated at 2022-06-21 09:01:50.494461
# Unit test for constructor of class Singleton
def test_Singleton():
    import os
    import sys
    from tempfile import mkdtemp
    from contextlib import contextmanager
    from types import ModuleType

    @contextmanager
    def tempdir():
        tmpdir = mkdtemp()
        try:
            yield tmpdir
        finally:
            os.rmdir(tmpdir)

    with tempdir() as tmpdir:
        tmppath = os.path.join(tmpdir, 'test')

# Generated at 2022-06-21 09:01:56.423064
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    foo1 = Foo(1, 2)
    foo2 = Foo(3, 4)

    assert foo1 == foo2
    assert foo1.a == 1
    assert foo2.a == 1
    assert foo1.b == 2
    assert foo2.b == 2

# Generated at 2022-06-21 09:02:00.217088
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Parent:
        pass

    class One(Parent, metaclass=Singleton):
        pass

    class Two(Parent, metaclass=Singleton):
        pass

    assert One() == One()
    assert Two() == Two()
    assert One() == Two()

# Generated at 2022-06-21 09:02:03.561623
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    a = Foo()
    b = Foo()
    try:
        assert(a is b)
    except:
        assert(0)
    print("test_Singleton OK")



# Generated at 2022-06-21 09:02:07.393231
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    a = Foo()
    b = Foo()

    assert a is b
    assert id(a) == id(b)
    assert a.__class__ is Foo


# Generated at 2022-06-21 09:02:14.717011
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Provide default, empty class
    class TestEmpty(object):
        __metaclass__ = Singleton
        pass

    # Create two instances of class TestEmpty, both returning the same instance
    instance1 = TestEmpty()
    instance2 = TestEmpty()

    # Asserting that both instances are the same object
    assert instance1 is instance2

    # Provide class with __init__, a class attribute and a method
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

        @classmethod
        def get_value(cls):
            return cls._value

        @classmethod
        def set_value(cls, value):
            cls._value = value

    # Setting the class attribute _value
    # Note that this is an attribute of the

# Generated at 2022-06-21 09:02:20.323489
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    a1 = A(0)
    a2 = A(1)
    assert a1 is a2, 'not a singleton'
    assert a1.a == 0, 'instantiation failed'



# Generated at 2022-06-21 09:02:24.518345
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)

    assert t1.a == t2.a
    assert id(t1) == id(t2)

# Generated at 2022-06-21 09:02:32.050109
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingletonClass(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    class MyClass(object):
        def __init__(self, value):
            self.value = value

    my_singleton_class1 = MySingletonClass(value='foo')
    my_singleton_class2 = MySingletonClass(value='bar')
    my_class1 = MyClass(value='foo')
    my_class2 = MyClass(value='bar')

    assert id(my_class1) != id(my_class2), '%d=%d' % (id(my_class1), id(my_class2))
    assert my_class1.value == 'foo', '%s' % my_class1.value
    assert my_

# Generated at 2022-06-21 09:02:43.538836
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, a=None):
            self.a = a
    for i in range(1,10):
        foo = Foo()
        foo.a = i
        assert i == foo.a
    for i in range(1,10):
        foo = Foo()
        assert i == foo.a
        a = Foo('test')
        assert i == a.a
    foo = Foo()
    assert 'test' == foo.a

# Generated at 2022-06-21 09:02:47.371474
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self, *args):
            self.args = args

    assert Test('a', 'b') is Test('a', 'b')
    assert Test('a', 'b').args == ('a', 'b')
    assert Test('c', 'd').args == ('a', 'b')



# Generated at 2022-06-21 09:02:51.984692
# Unit test for constructor of class Singleton
def test_Singleton():
    """Unit test for constructor of class Singleton"""
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert A() == A()
    f1 = A()
    f1.name = "f1"
    assert A().name == "f1"
    f2 = A()
    f2.name = "f2"
    assert A().name == "f2"
    assert f1 == f2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:02:54.266090
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class NotSingleton(object):
        pass

    assert NotSingleton() is not NotSingleton()

    class Singleton(object):
        __metaclass__ = Singleton

    assert Singleton() is Singleton()

# Generated at 2022-06-21 09:03:02.013971
# Unit test for constructor of class Singleton
def test_Singleton():
    """Unit test for constructor that checks if the class Singleton is Singleton
    """

    # try to create new instance of Singleton
    s1 = Singleton()
    assert isinstance(s1, Singleton)

    # try to create another instance of Singleton
    s2 = Singleton()
    assert isinstance(s2, Singleton)

    # try to create third instance of Singleton
    # should fail: can't create new object from metaclass
    try:
        s3 = Singleton()
    except TypeError as e:
        return True
    else:
        raise Exception("Can't create new object from metaclass.")



# Generated at 2022-06-21 09:03:05.332615
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 1
    a = A()
    a.value = 22
    b = A()
    assert(b.value == 22)
    assert(a is b)

# Generated at 2022-06-21 09:03:10.652506
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = A(1)
    b = A(2)
    c = A(3)

    assert id(a) == id(b) == id(c)
    assert a.value == 1


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:03:16.742700
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    # create 2 TestClass instances and check if they are the same
    instance1 = TestClass()
    instance2 = TestClass()
    assert instance1 is instance2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 09:03:22.490989
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    class TestSingleton(unittest.TestCase):
        def test_singleton(self):
            foo_1 = Foo('foo_1')
            foo_2 = Foo('foo_2')

            self.assertEqual(foo_1.value, 'foo_2')
            self.assertEqual(id(foo_1), id(foo_2))

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-21 09:03:25.960502
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 1

    s1 = TestSingleton()
    s1.value = 2
    s2 = TestSingleton()
    assert(s1 == s2)
    assert(s1.value == s2.value == 2)

# Generated at 2022-06-21 09:03:33.235129
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class SingletonTest(object):
      __metaclass__  = Singleton

    s1 = SingletonTest()

    assert s1 == SingletonTest()
    assert s1 is SingletonTest()

# Generated at 2022-06-21 09:03:36.830874
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.sample_data = 50

    obj1 = Test()
    obj2 = Test()

    assert obj1 is obj2
    assert obj1.sample_data == 50
    assert obj2.sample_data == 50



# Generated at 2022-06-21 09:03:44.503249
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Make a call to the Singleton class.
    singleton_test_instance1 = Singleton('SingletonTest', (), {})

    # The instance returned should be the same object as the class itself.
    assert singleton_test_instance1 is Singleton

    # Reset the singleton instance to another class
    Singleton('SingletonTest', (), {})

    # Again, the instance should be the same object as the class itself.
    singleton_test_instance1 = Singleton('SingletonTest', (), {})

    assert singleton_test_instance1 is Singleton



# Generated at 2022-06-21 09:03:48.709300
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class MySingletonClass(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    a = MySingletonClass(3)
    b = MySingletonClass(5)
    assert a is b
    assert a.x == b.x

# Generated at 2022-06-21 09:03:55.115898
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    a1_inst = A()
    a2_inst = A()
    assert a1_inst is a2_inst

    b1_inst = B()
    b2_inst = B()
    assert b1_inst is b2_inst

    # This will be failed in below Python versions
    # - 2.7.8
    # - 2.7.9
    # - 2.7.10
    # - 3.2.6
    # - 3.3.6
    # - 3.4.0
    # - 3.4.1
    # - 3.4.2
    # - 3.4.3
    # - 3.4.4
    # - 3

# Generated at 2022-06-21 09:03:57.797754
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    A = Singleton('A', (object,), {})

    a = A()
    assert a == A()
    assert a == A()

    b = A()
    assert b == a
    assert b != A()


# Generated at 2022-06-21 09:04:08.859192
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A():
        __metaclass__ = Singleton

        def __init__(self, v=0):
            self.__value = v
            self.__instance_counter = 0

        def __str__(self):
            return "Value=%s, Instance=%s" % (self.__value, self.__instance_counter)

        def __eq__(self, other):
            return self.__value == other.__value and self.__instance_counter == other.__instance_counter

        def __ne__(self, other):
            return self.__value != other.__value or self.__instance_counter != other.__instance_counter

        @property
        def value(self):
            return self.__value

        @value.setter
        def value(self, v):
            self.__value = v

# Generated at 2022-06-21 09:04:14.376270
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value = None):
            self.value = value

    t1 = Test()
    t1.value = "test1"
    t2 = Test()
    t1.value = "test2"
    assert t1 == t2
    t2.value= "test2"
    assert t1.value == t2.value

# Generated at 2022-06-21 09:04:17.709659
# Unit test for constructor of class Singleton
def test_Singleton():
    from ..inventory import Inventory
    from ..host import Host

    # Both should be the same instance
    assert Singleton(Inventory, (), {}) is Singleton(Inventory, (), {})

    # Both should be the same instance
    assert Singleton(Host, (), {}) is Singleton(Host, (), {})

# Generated at 2022-06-21 09:04:18.935859
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

    TestClass()
    TestClass()

# Generated at 2022-06-21 09:04:37.236049
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass = Singleton

    # Ensure that instance A exists and is unique
    assert(A() is A())
    assert(A() is not A())

    class B(object):
        __metaclass = Singleton
        def __init__(self, x, y):
            self.x = x
            self.y = y

    # Ensure that instance B exists and is unique
    b = B(1, 2)
    assert(b.x == 1)
    assert(b.y == 2)
    assert(B(3, 4) is B(1, 2))
    assert(B(3, 4) is not B(1, 2))

# Generated at 2022-06-21 09:04:38.386047
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        pass

    assert Test() is Test()

# Generated at 2022-06-21 09:04:44.918937
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            Test.count += 1

        @classmethod
        def get_count(cls):
            return Test.count

    Test.count = 0
    # initialize singleton class Test
    t = Test()
    assert Test.get_count() == 1

    # get instance of Test
    t2 = Test()
    assert Test.get_count() == 1

# Generated at 2022-06-21 09:04:52.600914
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test1(object):
        __metaclass__ = Singleton

    class Test2(object):
        __metaclass__ = Singleton
        
    class Test3(object):
        __metaclass__ = Singleton
        
    class Test4(object):
        __metaclass__ = Singleton
        
    assert Test1() is Test1() is Test1()
    assert Test2() is Test2() is Test2()
    assert Test3() is Test3() is Test3()
    assert Test4() is Test4() is Test4()

    assert Test1() is not Test2() is not Test3() is not Test4()

# Generated at 2022-06-21 09:04:58.550230
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    s1 = TestSingleton(1)
    s2 = TestSingleton(2)
    assert(s1.x == 1)
    assert(s2.x == 1)
    assert s1.x == s2.x
    assert s1 == s2

# Generated at 2022-06-21 09:05:01.648207
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    c = A()

    assert a is b
    assert b is c
    assert c is a


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 09:05:05.468354
# Unit test for constructor of class Singleton
def test_Singleton():
    class RandomClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 12

        def foo(self):
            return "foo"

    a = RandomClass()
    b = RandomClass()

    assert a.x == 12
    assert a.foo() == "foo"
    assert a == b

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-21 09:05:10.686409
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SampleClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    a = SampleClass()
    a.value += 1
    b = SampleClass()
    b.value += 2
    print(a)
    print(b)
    print(a == b)
    print(a.value == b.value == 3)


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-21 09:05:19.218302
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton  # noqa: F821

        def __init__(self):
            self.val1 = 1

    # Create first instance
    a = TestSingleton()
    assert isinstance(a, TestSingleton)

    # Create second instance
    b = TestSingleton()
    assert isinstance(b, TestSingleton)

    # Check that instances have been default initialized
    assert a.val1 == 1
    assert b.val1 == 1

    # Setting the attribute in one instance
    b.val1 = 2

    # Check that the attribute has been set in both instances
    assert a.val1 == 2
    assert b.val1 == 2

    # Check that the instances are identical
    assert a is b



# Generated at 2022-06-21 09:05:21.898715
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

    t3 = Test()
    assert t3 is t1


# Generated at 2022-06-21 09:05:45.808464
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a1 = A()
    a2 = A()
    assert a1.__class__ is a2.__class__

# Generated at 2022-06-21 09:05:50.713202
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, id):
            self.id = id

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert id(a) == id(b)
    assert a.id == 1
    assert b.id == 1

# Generated at 2022-06-21 09:05:54.310119
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    prev_i = 0
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, i):
            self.i = i

    for x in range(10):
        i = TestSingleton(x).i
        assert i >= prev_i
        prev_i = i

