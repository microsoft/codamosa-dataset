

# Generated at 2022-06-21 08:56:00.912262
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton
    o = S()
    o2 = S()
    assert o is o2, "Singleton failed"

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-21 08:56:09.923489
# Unit test for constructor of class Singleton
def test_Singleton():
    print("Test Singleton:\n")

    # Test case : Create instance with assigned constructor
    class C(object, metaclass=Singleton):
        def __init__(self, v=0):
            self.__val = v

        def get_val(self):
            return self.__val
    
    # Test case : Create instance without assigned constructor
    class D(object, metaclass=Singleton):
        def __init__(self):
            self.__val = 0

        def get_val(self):
            return self.__val

    print("Create 2 instances of class C with assigned constructor")
    c1 = C(1)
    c2 = C(2)
    print("c1.get_val() =", c1.get_val())

# Generated at 2022-06-21 08:56:11.964964
# Unit test for constructor of class Singleton
def test_Singleton():
    import imp

    # Init
    filename = 'rand.py'

# Generated at 2022-06-21 08:56:17.913332
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

    class Baz(object):
        __metaclass__ = Singleton

    assert Foo() == Foo()
    assert Bar() == Bar()
    assert Baz() == Baz()

    assert Foo() != Bar()
    assert Foo() != Baz()
    assert Bar() != Baz()

# Generated at 2022-06-21 08:56:25.116523
# Unit test for constructor of class Singleton
def test_Singleton():
    class singleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 42

    a = singleton()
    b = singleton()
    assert a == b
    assert a is b
    assert a.value == b.value
    b.value = 24
    assert a.value == b.value
    # Test if __init__ (self.value = 42) was called only once
    assert a.value == 42

# Generated at 2022-06-21 08:56:33.808950
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    @staticmethod
    def test_func(a, b):
        return a + b

    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b
            self.c = test_func(self.a, self.b)

        def get_c(self):
            return self.c

    testInstance = Test(1, 2)
    assert testInstance.get_c() == 3

    testInstance2 = Test(2, 3)
    assert testInstance2.get_c() == 3



# Generated at 2022-06-21 08:56:37.130982
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton:
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    assert TestSingleton(foo=1) == TestSingleton(foo=2)

# Generated at 2022-06-21 08:56:43.686020
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    __doc__="""
    Test Case of Callable Singleton.
    """

    class TestClass(metaclass=Singleton):
        def __init__(self, name=None):
            if name is not None:
                self.__name = name

        def __str__(self):
            return self.__name

        @property
        def name(self):
            return self.__name

        @name.setter
        def name(self, name):
            self.__name = name
            return self.__name

    assert TestClass() is TestClass()
    return True

# Generated at 2022-06-21 08:56:47.360832
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingleTest(object):
        __metaclass__ = Singleton

    assert SingleTest() == SingleTest()
    assert id(SingleTest()) == id(SingleTest())



# Generated at 2022-06-21 08:56:54.303778
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, arg1, arg2, arg3):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3

    assert A(1,2,3) is A(4,5,6)
    assert A(7,8,9).arg1 == 7
    assert A(7,8,9).arg2 == 8
    assert A(7,8,9).arg3 == 9

# Generated at 2022-06-21 08:57:00.379063
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    foo = A()
    bar = A()
    assert foo == bar


# Generated at 2022-06-21 08:57:04.460592
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingleton2(object):
        __metaclass__ = Singleton

    obj1 = TestSingleton()
    obj2 = TestSingleton()
    assert obj1 is obj2

    obj3 = TestSingleton2()
    assert obj3 is not obj2

# Generated at 2022-06-21 08:57:06.829702
# Unit test for constructor of class Singleton
def test_Singleton():
    class Y(object):
        __metaclass__ = Singleton

    y1 = Y()
    y2 = Y()
    assert y1 is y2


# Generated at 2022-06-21 08:57:10.835253
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    class Test2(object):
        __metaclass__ = Singleton

    test = Test()
    test2 = Test2()

    assert id(test) == id(Test())
    assert id(test2) == id(Test2())

# Generated at 2022-06-21 08:57:17.052423
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            super(SingletonTest, self).__init__()
            self.foo = 12
    s1 = SingletonTest()
    assert s1.foo == 12
    s1.foo = 13
    s2 = SingletonTest()
    assert s2.foo == 13

# Generated at 2022-06-21 08:57:21.147845
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, bar="baz"):
            self.bar = bar

    assert isinstance(Foo("baz"), Foo)
    assert isinstance(Foo("baz"), Foo)

# Generated at 2022-06-21 08:57:29.242239
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    # creating different instances of class A should return the same instance of A
    assert(A(0) == A(1))
    assert(A(0) == A(1))

    # changing value of one instance of A should reflect on other instances of A
    A(0).value = 5
    assert(A(0).value == 5)
    assert(A(1).value == 5)


# Generated at 2022-06-21 08:57:33.992726
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x
    a = A(1)
    assert isinstance(a, A)

    b = A(2)
    assert isinstance(b, A)

    assert id(a) == id(b)
    assert b.x == 1



# Generated at 2022-06-21 08:57:37.656916
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    expected = "Singleton.__call__ was invoked"

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_value = expected

    test_instance = TestClass()

    assert test_instance.test_value == expected
    assert test_instance is TestClass() is test_instance



# Generated at 2022-06-21 08:57:42.038437
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = A("a")
    b = A("b")
    assert a.name == "a"
    assert b.name == "a"

# Generated at 2022-06-21 08:57:55.821595
# Unit test for constructor of class Singleton
def test_Singleton():
    class Single(object):
        __metaclass__ = Singleton
    a = Single()
    b = Single()
    c = Single()
    assert a is b is c

# class Singleton(object):
#     """Class that implements Singleton functionality
#     """
#     # Make use of the Singleton metaclass.
#     __metaclass__ = Singleton
#     def __init__(self, foo=None):
#         self.foo = foo

# def test_Singleton():
#     a = Singleton()
#     b = Singleton()
#     c = Singleton()
#     assert a is b is c
#     assert a.foo == foo
#     assert b.foo == foo
#     assert c.foo == foo
#     a.foo = 'bar'
#     assert a.foo ==

# Generated at 2022-06-21 08:58:00.676928
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = '1'

    a = A()
    assert a.a == '1'

    b = A()
    assert b.a == '1'

    assert id(a) == id(b)
    b.a = '2'
    assert a.a == '2'


# Generated at 2022-06-21 08:58:05.356647
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, v):
            self.v = v

    a = A(1)
    b = A(2)
    assert a is b
    assert a.v == 2



# Generated at 2022-06-21 08:58:14.469832
# Unit test for constructor of class Singleton
def test_Singleton():
    # create class RealSingleton
    class RealSingleton(object):
        __metaclass__ = Singleton

        def foo(self):
            return 'foo'

    # RealSingleton is really Singleton
    assert RealSingleton.__name__ == 'Singleton'

    # test instance
    assert RealSingleton().foo() == 'foo'
    assert RealSingleton().foo() == 'foo'
    assert RealSingleton().foo() == 'foo'

    # test singleton
    assert RealSingleton() is RealSingleton()


if __name__ == '__main__':
    test_Singleton()
    print('Test case OK')

# Generated at 2022-06-21 08:58:22.629633
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import random
    from nose.tools import assert_true, assert_equal
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, val=None):
            self.val = val

    assert_true(not hasattr(SingletonTest, '__instance'))
    assert_true(not hasattr(SingletonTest, '__rlock'))

    a = SingletonTest(random.randint(0, 1000))
    assert_true(hasattr(SingletonTest, '__instance'))
    assert_true(hasattr(SingletonTest, '__rlock'))
    assert_equal(a, SingletonTest.__instance)
    assert_equal(id(a), id(SingletonTest.__instance))

    a_instance_id = id(a)

# Generated at 2022-06-21 08:58:25.635693
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class ConcreteClass(object):
        __metaclass__ = Singleton

        def __init__(self, value=None):
            self.value = value

    instance1 = ConcreteClass(1)
    instance2 = ConcreteClass(2)
    assert instance1 is instance2
    assert instance2.value == 1


# Generated at 2022-06-21 08:58:34.652510
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        a = 1

    assert A is A()
    assert A.a == 1
    assert A().a == 1
    A.a = 2
    assert A.a == 2
    assert A().a == 2
    assert A().a == A.a == 2

    # Check that Singleton honors __call__ and other special methods.
    class B(object):
        __metaclass__ = Singleton
        def __call__(self):
            return 'called'

    assert B() == 'called'
    assert B() == 'called'
    assert B == B()

# Generated at 2022-06-21 08:58:40.035260
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.var = 1
    m1 = MyClass()
    m2 = MyClass()
    assert(m1 is m2)
    return "Success"

if __name__ == "__main__":
    print(test_Singleton())

# Generated at 2022-06-21 08:58:43.494014
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        name = "SingletonTest"

    o1 = SingletonTest()
    o2 = SingletonTest()
    assert o1 is o2
    assert o1.name == o2.name == SingletonTest.name

# Generated at 2022-06-21 08:58:46.108151
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton

    instance1 = SingletonClass()
    instance2 = SingletonClass()
    assert instance1 is instance2

# Generated at 2022-06-21 08:58:53.449495
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        __x = "hello"

        def __init__(self):
            print("in TestClass init")

    a = TestClass()
    b = TestClass()
    assert (a is b)
    assert (a.__x == b.__x)

# Generated at 2022-06-21 08:58:59.935371
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    import os
    import tempfile

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, lock=None):
            self.lock = lock
            self.fd, self.path = tempfile.mkstemp()
            self.counter = 0

        def __del__(self):
            os.close(self.fd)

        def foo(self):
            with self.lock:
                self.counter += 1
                return self.counter

    from threading import RLock
    lock = RLock()

    s = SingletonTest(lock)
    assert type(s) == SingletonTest
    assert os.path.exists(s.path)
    assert s.counter == 0
    assert s.foo() == 1
    assert s.foo() == 2

    s2 = Sing

# Generated at 2022-06-21 08:59:07.481429
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            self.x = 100
            self.y = 200
    obj1 = MyClass()
    assert obj1.x == 100
    assert obj1.y == 200
    obj2 = MyClass()
    assert obj2.x == 100
    assert obj2.y == 200
    assert obj1 is obj2
    obj1.x = 300
    assert obj2.x == 300
    obj2.y = 400
    assert obj1.y == 400

# Generated at 2022-06-21 08:59:11.690461
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, val):
            self.val = val

    a = A(10)
    b = A(20)

    print(a.val)
    print(b.val)


# If this code is executed from python interpreter instead of imported as
# a module.
#

# Generated at 2022-06-21 08:59:17.009106
# Unit test for constructor of class Singleton
def test_Singleton():
    class class_A(metaclass=Singleton):
        def __init__(self, arg):
            self.arg = arg

    a1 = class_A(1)
    a2 = class_A(2)
    assert id(a1) == id(a2), "There can only be one!"

# Generated at 2022-06-21 08:59:21.402802
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.test == 'test'
    assert a2.test == 'test'

# Generated at 2022-06-21 08:59:25.825518
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class A(metaclass=Singleton):
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()

    assert a1 is a2 and a1.a == a2.a == 1, 'it\'s not a singleton'


# Generated at 2022-06-21 08:59:29.401605
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = 1
    s = SingletonTest()
    s2 = SingletonTest()
    assert s == s2
    assert s.foo == s2.foo


# Generated at 2022-06-21 08:59:30.997672
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert isinstance(A(), A)
    assert A() is A()



# Generated at 2022-06-21 08:59:32.733341
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object, metaclass=Singleton):
        a = 5

    assert A.a == 5



# Generated at 2022-06-21 08:59:40.824205
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Mock(metaclass=Singleton):
        def __init__(self):
            pass

    m1 = Mock()
    assert m1 is Mock()
    assert m1 is Mock()
    assert m1 is Mock()

    m2 = Mock()
    assert m2 is Mock()
    assert m2 is Mock()
    assert m2 is Mock()


# Generated at 2022-06-21 08:59:44.938327
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        def __init__(self):
            self.foo = 42

    tc1_id = id(TestClass())
    tc2_id = id(TestClass())

    assert tc1_id == tc2_id

# Generated at 2022-06-21 08:59:52.116837
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, arg1):
            self.arg1 = arg1

    a1 = A(1)
    a2 = A(2)
#    print(a1.arg1, a2.arg1)
    assert a1.arg1 == 1 and a2.arg1 == 1


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-21 08:59:56.543678
# Unit test for constructor of class Singleton
def test_Singleton():
    class P(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1
    p1 = P()
    p2 = P()
    assert id(p1) == id(p2)
    assert p1.a == 1
    assert p2.a == 1
    p2.a = 2
    assert p1.a == 2

# Generated at 2022-06-21 09:00:08.061486
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingletonClass(object):
        __metaclass__ = Singleton

    test_args = (1, 2)
    test_kwargs = {'a':1, 'b':2}
    test_instance = TestSingletonClass(*test_args, **test_kwargs)
    test_instance2 = TestSingletonClass(*test_args, **test_kwargs)
    assert test_instance is test_instance2
    assert test_instance2.__dict__ == test_instance.__dict__

    assert test_args == test_instance.args
    assert test_kwargs == test_instance.kwargs

    assert test_args == test_instance2.args
    assert test_kwargs == test_instance2.kwargs

    test_kwargs2 = {'a':2, 'b':2}
    test_instance

# Generated at 2022-06-21 09:00:11.904286
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    a = A(val="test")
    assert a.val == "test"

    b = A(val="test1")
    assert b.val == "test"

# Generated at 2022-06-21 09:00:15.828501
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = A(1)
    b = A(2)

    assert a.value == 1
    assert b.value == 1

    a.value = 2
    assert b.value == 2


# Generated at 2022-06-21 09:00:18.324177
# Unit test for constructor of class Singleton
def test_Singleton():

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 is test2