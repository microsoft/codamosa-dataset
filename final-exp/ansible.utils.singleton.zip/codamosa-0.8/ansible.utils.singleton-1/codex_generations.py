

# Generated at 2022-06-11 18:31:42.442833
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_var = 'abc'

    # create TestClass instance for the first time
    instance1 = TestClass()
    assert isinstance(instance1, TestClass)
    assert instance1.test_var == 'abc'

    # create TestClass instance for the 2nd time
    instance2 = TestClass()
    assert isinstance(instance2, TestClass)
    assert instance2.test_var == 'abc'

    # check for id equality
    assert id(instance1) == id(instance2)

    # change the value of attribute 'test_var' of instance2
    instance2.test_var = 'def'
    assert instance1.test_var == 'def'


# class that uses Singleton metaclass

# Generated at 2022-06-11 18:31:45.056914
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class FakeClass(object):
        __metaclass__ = Singleton

    assert FakeClass is FakeClass()
    assert FakeClass is not FakeClass()

# Generated at 2022-06-11 18:31:54.023428
# Unit test for constructor of class Singleton
def test_Singleton():

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name=None):
            self.name = name

    class TestSingleton2(object):
        __metaclass__ = Singleton
        pass

    test = TestSingleton()
    test2 = TestSingleton()
    assert id(test) == id(test2)
    test.name = "name 1"
    assert test.name == test2.name

    test2 = TestSingleton("name 2")
    assert test2.name == "name 2"
    assert id(test) == id(test2)

    test3 = TestSingleton2()
    test4 = TestSingleton2()
    assert id(test3) == id(test4)

# Generated at 2022-06-11 18:32:00.572022
# Unit test for constructor of class Singleton
def test_Singleton():
    # prepare the test
    class Base1(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = "Base1"
    class Base2(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = "Base2"
    
    # run test
    assert Base1() is Base1() and Base2() is Base2()



# Generated at 2022-06-11 18:32:04.841949
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 'test'

    # Test singleton instantiation
    foo = Foo()
    bar = Bar()

    # Confirm same instance of Foo
    assert foo is Foo()

    # Confirm same instance of Bar
    assert bar is Bar()

    # Confirm value of Bar instance
    assert bar.value == 'test'


# Generated at 2022-06-11 18:32:08.667699
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton:  # pylint: disable=too-few-public-methods
        """Test Singleton implementation"""
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()



# Generated at 2022-06-11 18:32:16.340353
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class FooSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    class BarSingleton(object):
        __metaclass__ = Singleton

    foo = FooSingleton(42)
    bar = BarSingleton()
    assert foo.val == 42
    assert foo is foo
    assert foo is FooSingleton(42)
    assert bar is BarSingleton()
    assert foo is not bar
    assert foo is not BarSingleton()

# Unit tesst for method __init__ of class Singleton
# Tests that a class that inherits from a class that uses the singleton
# metaclass and overrides __new__ maintains singleton semantics.

# Generated at 2022-06-11 18:32:17.753146
# Unit test for constructor of class Singleton
def test_Singleton():
    s = Singleton()
    s = Singleton()
    s = Singleton()

# Generated at 2022-06-11 18:32:29.487056
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.hello = "world"

    # Instantiate an object of class MyClass.
    myClass = MyClass()
    # Instantiate another object of class MyClass.  Note that the
    # reference is the same as the one we created above.
    myClass2 = MyClass()
    # Set the value of the attribute 'hello' in myClass2.
    myClass2.hello = "universe"
    # Print the value of the attribute 'hello' in myClass.  It's "universe",
    # because it's the same reference.
    print(myClass.hello)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:32:35.040706
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 5

        def other_method(self):
            return self.value

    tsc1 = TestSingletonClass()
    tsc2 = TestSingletonClass()

    assert tsc1 is tsc2
    assert tsc1.value == 5


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:32:44.574305
# Unit test for constructor of class Singleton
def test_Singleton():
    import ansible.module_utils.basic

    class TestSingleton(object):
        __metaclass__ = ansible.module_utils.basic.Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()

    assert a.x == 1
    assert b.x == 1

    a.x = 2

    assert a.x == 2
    assert b.x == 2

    b.x = 3

    assert a.x == 3
    assert b.x == 3

# Generated at 2022-06-11 18:32:49.010687
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestInstance(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.__value = "test"

        def getValue(self):
            return self.__value

    a = TestInstance()
    b = TestInstance()
    assert a is b
    assert a.getValue() == b.getValue()

# Generated at 2022-06-11 18:32:51.484650
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 == t2


# Generated at 2022-06-11 18:32:55.211703
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object, metaclass=Singleton):
        pass

    f1 = Foo()
    f2 = Foo()
    assert f1 == f2



# Generated at 2022-06-11 18:32:58.715122
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
    assert Test.__bases__ == (object,)
    assert Test.__call__ == Singleton.__call__
    assert isinstance(Test(), Test)
    assert Test() is Test() is Test()



# Generated at 2022-06-11 18:33:02.105288
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    # the following should return the same object
    obj1 = TestSingleton()
    obj2 = TestSingleton()
    assert obj1 is obj2



# Generated at 2022-06-11 18:33:06.963193
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("Entering MySingleton ::__init__")

        def __exit__(self, exc_type, exc_value, traceback):
            print("Entering MySingleton ::__exit__")

    a = MySingleton()
    b = MySingleton()
    assert a is b


# Generated at 2022-06-11 18:33:14.531285
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.data = []

        def add(self, value):
            self.data.append(value)

    a1 = TestSingleton()
    assert len(a1.data) == 0
    a1.add(1)
    assert len(a1.data) == 1
    a2 = TestSingleton()
    assert len(a2.data) == 1
    a2.add(2)
    assert len(a2.data) == 2
    assert len(a1.data) == 2



# Generated at 2022-06-11 18:33:17.468674
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    instance1 = Test()
    instance2 = Test()
    assert id(instance1) == id(instance2)



# Generated at 2022-06-11 18:33:22.716778
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2

# Sample code to use Singleton
# This can be used in any other code to create Singleton objects

# Generated at 2022-06-11 18:33:30.092099
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    obj = Singleton('test', (object,), {})()
    assert isinstance(obj, Singleton)
    assert obj is Singleton.__instance
    assert not isinstance(obj, object)


# Generated at 2022-06-11 18:33:39.853667
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            # Just for demo purposes
            self.a = 'a'
            self.b = 'b'

    # 1st call
    f = foo()

    # 2nd call
    f1 = foo()

    # Check that it's the same object
    assert f is f1
    # Check that the object is correctly initialized
    assert hasattr(f, 'a') and f.a == 'a'
    assert hasattr(f, 'b') and f.b == 'b'

    # You can change the state
    f1.a = 'c'
    f1.b = 'd'

    # But you still can access the old state
    assert hasattr(f, 'a') and f.a == 'c'


# Generated at 2022-06-11 18:33:51.593701
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread
    import time
    from collections import deque
    from random import randint
    class A:
        __metaclass__ = Singleton
        def __call__(self, *args, **kw):
            return (args, kw)

    def RunTest(cnt, q):
        a = A()
        for _ in range(cnt):
            # First call should succeed
            args = (randint(1, 100), randint(101, 200))
            kw = {'k': randint(201, 300)}
            rv = a(*args, **kw)
            q.append(rv)
            assert rv == (args, kw)
            # Second call should fail
            q.append(a())

    dq = deque()

# Generated at 2022-06-11 18:33:56.502779
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)
    assert a1 is a2
    assert a1.__class__ == A
    assert a2.__class__ == A

# Generated at 2022-06-11 18:34:05.018661
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    obj1 = TestSingleton(1, 2)
    obj2 = TestSingleton(3, 4)

    assert(obj1 == obj2)
    assert(obj1.a == 1)
    assert(obj1.b == 2)
    assert(obj1.a == obj2.a)
    assert(obj1.b == obj2.b)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:34:14.986091
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        pass
    
    instance1 = SingletonTest()
    instance2 = SingletonTest()
    assert instance1 is instance2
    assert isinstance(instance1, SingletonTest)

    class SingletonTest2(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    instance1 = SingletonTest2(1)
    instance2 = SingletonTest2(2)
    assert instance1 is instance2
    assert instance1.value == 1
    assert instance2.value == 1
    #assert isinstance(instance1, SingletonTest2)
    #assert isinstance(instance2, SingletonTest2)

# Generated at 2022-06-11 18:34:18.376127
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Test(object):
        __metaclass__ = Singleton

    obj_1 = Test()
    obj_2 = Test()
    assert obj_1 is obj_2

    print("PASS - test_Singleton___call__")



# Generated at 2022-06-11 18:34:22.171201
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    assert a1.__class__ is A
    a2 = A()
    assert a1 is a2
    assert a1 == a2

# Generated at 2022-06-11 18:34:28.924227
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value=None):
            self.__value = value

        def get_value(self):
            return self.__value

    ts1 = TestSingleton(value="test_Singleton")
    assert ts1 is TestSingleton()
    assert ts1.get_value() == "test_Singleton"
    assert ts1.get_value() == TestSingleton().get_value()

    ts2 = TestSingleton(value="test_Singleton2")
    assert ts1 is ts2
    assert ts2 is TestSingleton()
    assert ts2.get_value() == "test_Singleton2"
    assert ts2.get_value() == TestSingleton().get_value()



# Generated at 2022-06-11 18:34:39.324174
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase, TestLoader, TestSuite, TextTestRunner
    from collections import deque

    class SingletonTest(object):
        __metaclass__ = Singleton

    class SingletonTestCase(TestCase):
        def test_Singleton___call__(self):
            s1 = SingletonTest()
            s2 = SingletonTest()
            self.assertEqual(s1, s2)

    return TestSuite([
        TestLoader().loadTestsFromTestCase(SingletonTestCase),
    ])

if __name__ == '__main__':
    from logging import basicConfig, DEBUG

    basicConfig(
        format='%(asctime)s %(levelname)s %(message)s',
        level=DEBUG,
    )


# Generated at 2022-06-11 18:34:51.449812
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    class Test2(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    test1_obj1 = Test1(1)
    test1_obj2 = Test1(2)
    assert test1_obj1 == test1_obj2
    test2_obj1 = Test2(1)
    test2_obj2 = Test2(2)
    assert test2_obj1 == test2_obj2
    assert test1_obj1 != test2_obj1
    assert test1_obj1 != test2_obj2



# Generated at 2022-06-11 18:34:54.398123
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton
    
    instance1 = MySingleton()
    instance2 = MySingleton()
    assert instance1 is instance2


# Generated at 2022-06-11 18:34:57.325843
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        pass

    assert Test() is Test()


# Generated at 2022-06-11 18:34:59.971557
# Unit test for constructor of class Singleton
def test_Singleton():
    class Cls(object, metaclass=Singleton):
        pass

    obj1 = Cls()
    obj2 = Cls()

    assert obj1 is obj2



# Generated at 2022-06-11 18:35:03.694465
# Unit test for constructor of class Singleton
def test_Singleton():
    """
    >>> a = Singleton('a_class', (object, ), {})
    >>> a.__class__
    <class '__main__.Singleton'>
    >>> a.__instance
    """

# Generated at 2022-06-11 18:35:06.139446
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()
    assert A() is A()



# Generated at 2022-06-11 18:35:08.556866
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
    foo1 = Foo()
    foo2 = Foo()
    assert foo1 == foo2
    foo1.bar = 'baz'
    assert foo1.bar == foo2.bar


# Generated at 2022-06-11 18:35:12.923870
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    import threading, time

    def get_instance():
        TestClass()

    t1 = threading.Thread(target=get_instance)
    t2 = threading.Thread(target=get_instance)

    t1.start()
    t2.start()

    t1.join()
    t2.join()

    assert True

# Generated at 2022-06-11 18:35:17.309907
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        '''TestClass class'''
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    c = TestClass()
    assert a is b is c

# Generated at 2022-06-11 18:35:20.161939
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def get_instance(self):
            return self

    m1 = MyClass()
    m2 = MyClass()
    assert m1 == m2


# Generated at 2022-06-11 18:35:26.784924
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        pass

    assert A() == A()

# Generated at 2022-06-11 18:35:29.038213
# Unit test for constructor of class Singleton
def test_Singleton():
    s = Singleton()
    # noinspection PyCallByClass
    assert isinstance(s, Singleton)

# Generated at 2022-06-11 18:35:33.639852
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 0

    assert TestSingleton() is TestSingleton()
    assert TestSingleton().val == 0
    TestSingleton().val = 10
    assert TestSingleton().val == 10

# Generated at 2022-06-11 18:35:35.218006
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    check_singleton_implementation(Singleton, SingletonClass)


# Generated at 2022-06-11 18:35:45.815151
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('Init..')
            self._init = True

        def check_init(self):
            return self._init

    my_list = []
    for i in range(10):
        my_list.append(MyClass())
    for ins in my_list:
        assert ins.check_init()
    assert my_list[0] is my_list[1]
    assert my_list[1] is my_list[2]
    assert my_list[0] is my_list[2]
    assert my_list[0] is my_list[9]


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:35:49.220242
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class SingletonTest(object):
        __metaclass__ = Singleton

    test_obj = SingletonTest()
    test_obj_2 = SingletonTest()
    assert test_obj is test_obj_2


# Generated at 2022-06-11 18:35:56.443243
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from collections import namedtuple
    from types import MethodType

    class MyClass:
        __metaclass__ = Singleton

    MyClassWithArguments = namedtuple("MyClassWithArguments", ["arg1", "arg2", "arg3", "arg4"])

    class MyClassWithArguments2(MyClassWithArguments):
        __metaclass__ = Singleton

    # Class with no argument - should return the same object
    assert MyClass() is MyClass()

    # Class with arguments - should return the same object as
    # __call__() was called with these arguments
    my_class = MyClassWithArguments(1, 2, 3, 4)
    assert my_class is MyClassWithArguments(1, 2, 3, 4)

    # Class derived from namedtuple - should return the same object
    my_

# Generated at 2022-06-11 18:36:04.480797
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.x = arg

    assert Foo(1) is Foo(2)

    # test that singleton stays a singleton even
    # when there are multiple instances created with different
    # constructor arguments
    assert Foo(3) is Foo(4)

    # test recursively subclassing the singleton class
    class Bar(Foo):
        def __init__(self, arg1, arg2):
            Foo.__init__(self, arg1)
            self.y = arg2

    assert Bar(1, 2) is Bar(3, 4)

# Generated at 2022-06-11 18:36:07.705761
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    s = Singleton("test_Singleton___call__", (), {})
    assert s("").__class__ == s("").__class__
    assert s("") == s("")
    assert s("") is s("")

# Generated at 2022-06-11 18:36:08.919135
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        pass

    assert Test() is Test()



# Generated at 2022-06-11 18:36:17.652888
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x
            self.y = 1
        def foo(self):
            self.y += 1
            return self.y

    t = TestSingleton(1)
    assert t.x == 1
    assert t.y == 1
    assert t.x == 1
    assert t.y == 1
    result = t.foo()
    assert result == 2
    assert t.y == 2
    result = t.foo()
    assert result == 3
    assert t.y == 3

# Generated at 2022-06-11 18:36:20.780928
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton(), 'Singleton class was not instantiated'


# Generated at 2022-06-11 18:36:27.863282
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import sys
    if sys.version_info[0] == 2:
        from types import ClassType
    else:
        ClassType = type

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    s1 = SingletonTest(1)
    assert(s1.value == 1)
    assert(isinstance(s1, SingletonTest))
    assert(isinstance(s1, ClassType))

    s1_1 = SingletonTest(2)
    assert(s1_1 is s1)



# Generated at 2022-06-11 18:36:32.161943
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 0

    a = Test()
    assert(a.x == 0)
    assert(id(a) == id(Test.__instance))


# Generated at 2022-06-11 18:36:38.616240
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase
    from io import StringIO
    class SingletonTest(TestCase):
        class A(metaclass=Singleton):
            def __init__(self, fh=None):
                self.fh = fh
            def __call__(self):
                self.fh.write('A')

        class B(metaclass=Singleton):
            def __init__(self, fh=None):
                self.fh = fh
            def __call__(self):
                self.fh.write('B')

    if __name__ == '__main__':
        import unittest
        unittest.main()
    else:
        import unittest
        suite = unittest.TestLoader().loadTestsFromTestCase(SingletonTest)

# Generated at 2022-06-11 18:36:42.051563
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        pass

    class B(metaclass=Singleton):
        def __init__(self):
            self.a = A()

    assert B() is B()
    assert id(B().a) == id(B().a)



# Generated at 2022-06-11 18:36:45.958623
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    f = TestClass()
    g = TestClass()

    assert f is g



# Generated at 2022-06-11 18:36:50.139784
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.count = 0

    a = SingletonTest()
    assert a.count == 0
    a.count = 1
    b = SingletonTest()
    assert a.count == b.count

# Generated at 2022-06-11 18:36:56.798087
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class X(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            # rlock is used to control access to a shared resource
            # (in this case the "shared" instance)
            self.__rlock = RLock()
            self._a = a
            self._b = b

        def get_a(self):
            return self._a

        def get_b(self):
            return self._b

    # The following two lines should return two references to the same object
    x1 = X(1, 2)
    x2 = X(1, 2)
    assert x1 is x2

    assert x1.get_a() == 1
    assert x1.get_b() == 2



# Generated at 2022-06-11 18:36:59.129776
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo = Foo()
    bar = Foo()

    assert foo == bar


# Generated at 2022-06-11 18:37:07.717292
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    # get the first instance of class SingletonTest
    instance1 = SingletonTest()
    # get the second instance of class SingletonTest
    instance2 = SingletonTest()
    # check if they are the same object
    assert(instance1 == instance2)
    # check if they are the same type
    assert(type(instance1) == type(instance2))



# Generated at 2022-06-11 18:37:11.226005
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 0

    a1 = A()
    a2 = A()

    assert id(a1) == id(a2)
    a1.x = 1
    assert a2.x == a1.x


# Generated at 2022-06-11 18:37:14.100935
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # First call, instance not created
    inst1 = SingletonTest()
    assert(inst1.id == 1)

    # Second call, instance already created, should return the same instance
    inst2 = SingletonTest()
    assert(inst2.id == 1)
    assert(inst1 == inst2)



# Generated at 2022-06-11 18:37:21.683595
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.str = 'a'

    s = SingletonTest()
    assert(s.str == 'a')
    s.str = 'b'
    s2 = SingletonTest()
    assert(s2.str == 'b')
    assert(id(s) == id(s2))
    s2 = SingletonTest('c')
    assert(s2.str == 'b')


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:37:27.602276
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread
    from time import sleep

    class A:
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = Thread(target=lambda: setattr(A(), 'a', 2))
    t2 = Thread(target=lambda: setattr(A(), 'a', 4))
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    assert A().a == 2 or A().a == 4


globals()['test_Singleton___call__']()

# Generated at 2022-06-11 18:37:33.123476
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton1 = TestSingleton()
    test_singleton2 = TestSingleton()
    if test_singleton1 is test_singleton2:
        print("Singleton is working properly!")
    else:
        print("Singleton isn't working properly! And its error is: %s" % (test_singleton1 is test_singleton2))


# Generated at 2022-06-11 18:37:37.046567
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        def __init__(self, arg1):
            self.arg1 = arg1

    my_object_1 = MyClass('foo')
    my_object_2 = MyClass('bar')
    assert my_object_1 is my_object_2, 'Instances of two class should be the same'
    assert my_object_2.arg1 == my_object_1.arg1, 'Instance of a class should have the same argument'

test_Singleton___call__()

# Generated at 2022-06-11 18:37:41.162473
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from py._path.local import LocalPath
    # pytest -q --setup-only  Singleton_test.test_Singleton___call__
    class TestClass(LocalPath):
        __metaclass__ = Singleton
    assert TestClass('.') is TestClass('.') 
    # pytest -q  Singleton_test.test_Singleton___call__

# Generated at 2022-06-11 18:37:51.757233
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test the basics
    class Test1(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    class Test2(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    t1 = Test1(42)
    t2 = Test1(21)
    t3 = Test2(42)
    t4 = Test2(21)

    assert t1.val == t2.val == 42
    assert t3.val == t4.val == 42

    assert t1 is t2
    assert t3 is t4

    assert t1 is not t3

    # Test a singleton with a metaclass

# Generated at 2022-06-11 18:38:01.105971
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import time

    class S(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    # test two instantiations happening at the same time
    s1 = S(1)
    s2 = S(2)
    assert s1 is s2
    assert s1.x == 1
    assert s2.x == 1

    # test two instantiations happening at different times
    s1 = None
    time.sleep(0.01)
    s2 = S(2)
    assert s1 is s2
    assert s1.x == 1
    assert s2.x == 1


# Generated at 2022-06-11 18:38:04.998292
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SomeClass(object):
        __metaclass__ = Singleton

    assert (SomeClass() == SomeClass()) == True

# Generated at 2022-06-11 18:38:06.841083
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    assert(a == A())

# Generated at 2022-06-11 18:38:15.525480
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread

    class SingleCall(object):
        __metaclass__ = Singleton
        def __init__(self, num):
            self.num = num

    class checkSingleton(Thread):
        def __init__(self, num):
            super(checkSingleton, self).__init__()
            self.num = num
            self.ret = []

        def run(self):
            self.ret.append(SingleCall(self.num))

    threads = []
    result = []
    for i in range(10):
        threads.append(checkSingleton(i))
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
        result.append(thread.ret[0])

    for j, t in enumerate(result):
        assert t is result

# Generated at 2022-06-11 18:38:21.674642
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    # A__instance is None
    a1 = A(1)
    # Check that a1 is A__instance now
    assert a1 is A.__instance
    # Check that A__instance is re-used (not a new instance)
    a2 = A(2)
    assert a1 is A.__instance and a1 is a2
    # Check that A__instance is not inited again, but arguments are ignored
    a3 = A(3)
    assert a1 is A.__instance and a1 is a3
    # Check that argument is not used
    assert a1.x == 1
    assert a2.x == 1
    assert a3.x == 1

# Unit

# Generated at 2022-06-11 18:38:29.586765
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test Singleton.__call__."""
    from threading import Thread

    class TestSingleton(object):
        """Test class."""
        __metaclass__ = Singleton

        def __init__(self, value=None):
            self._value = value

        @property
        def value(self):
            return self._value

    instance_1 = TestSingleton(1)
    instance_2 = TestSingleton(2)
    assert instance_1.value == 1
    assert instance_2.value == 1
    instance_3 = TestSingleton(3)
    assert instance_3.value == 1

    def thread_func_1(value=4):
        instance_4 = TestSingleton(value)
        return instance_4

    def thread_func_2(value=5):
        instance_5 = TestSing

# Generated at 2022-06-11 18:38:34.225591
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object, metaclass=Singleton):
        """Test Class"""
        def __init__(self, name):
            self.name = name

    class_a = TestClass('a')
    class_b = TestClass('b')
    class_c = TestClass('c')

    assert class_a.name == 'c'
    assert class_b.name == 'c'
    assert class_c.name == 'c'

# Generated at 2022-06-11 18:38:37.001528
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert a is b

# Generated at 2022-06-11 18:38:44.601079
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Can not use __init__ of Singleton because of super
    # Therefore, we will create a FakeSingleton class and apply Singleton
    # on it, so that we can call __init__
    class FakeSingleton:
        def __init__(self):
            self.name = 'Hello singleton'

    SingletonFake = Singleton('SingletonFake', (FakeSingleton,), {})
    fake1 = SingletonFake()
    fake2 = SingletonFake()
    assert fake1 == fake2


# Test for method __call__ of class Singleton
test_Singleton___call__()

# Generated at 2022-06-11 18:38:47.842830
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    def get_instance():
        class MyObject(Singleton):
            pass
        return MyObject()
    a = get_instance()
    b = get_instance()
    assert a is b
    del a
    del b


# Generated at 2022-06-11 18:38:52.463372
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Dummy(object):
        __metaclass__ = Singleton
        def __init__(self, n):
            self.n = n
    a = Dummy(1)
    b = Dummy(2)
    assert(a is b)



# Generated at 2022-06-11 18:39:04.713777
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 10

    # Create the first instance
    test_instance_1 = TestSingleton()
    assert test_instance_1.value == 10

    # Create the second instance
    test_instance_2 = TestSingleton()
    assert test_instance_2.value == 10

    # The two previous instances must be the same
    assert test_instance_1 is test_instance_2

# Generated at 2022-06-11 18:39:06.452104
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()



# Generated at 2022-06-11 18:39:14.691606
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import sys
    import ansible.plugins.loader
    sys.modules['ansible.plugins.loader'] = ansible.plugins.loader

    import ansible.plugins.loader
    reload(ansible.plugins.loader)
    from ansible.plugins.loader import Singleton
    from ansible.plugins.loader import PluginLoader
    from ansible.errors import AnsibleError

    class PluginLoaderTestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name
            self.call_cnt = 0

        def test_method(self):
            self.call_cnt += 1

    loader1 = PluginLoaderTestSingleton('lodader1')
    loader2 = PluginLoaderTestSingleton('lodader2')

# Generated at 2022-06-11 18:39:20.707154
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from nose.tools import with_setup, assert_true
    from io import StringIO

    class SingletonTest(metaclass=Singleton):
        def __init__(self):
            self._singleton_test_field = 0

    # returns the same instance
    instance1 = SingletonTest()
    instance2 = SingletonTest()
    assert_true(instance1 == instance2)

if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-11 18:39:27.433514
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = None

    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = None

    a1 = A()
    a1.test = 1
    a2 = A()
    a2.test = 2
    assert a1 is a2
    assert a1.test == 2

    b1 = B()
    assert a1 is not b1
    assert b1.test is None

# Generated at 2022-06-11 18:39:32.136433
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = "test"

    test1 = SingletonTest()
    test2 = SingletonTest()

    assert(test1 == test2)



# Generated at 2022-06-11 18:39:35.346428
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    first = TestClass()
    second = TestClass()

    assert first is second # instances are the same


# Generated at 2022-06-11 18:39:45.709821
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test for class Singleton, method __call__.

    Purpose:
        To verify that Singleton is handling __call__ correctly.
    """

    # Initialize parameters for the test
    class SingleTest:pass
    cls = Singleton('test', (object, ), {'__init__': object.__init__})
    # 1. Test that Singleton works correctly for one instance
    inst1 = cls()
    assert isinstance(inst1, cls)
    assert inst1 == cls()
    # 2. Test that Singleton works correctly for a second instance of the same class
    inst2 = cls()
    assert inst2 == inst1
    # 3. Test that Singleton works correctly for a second instance of a different class
    inst3 = cls()
    assert inst3 == inst1
    # 4. Test that Singleton works

# Generated at 2022-06-11 18:39:50.443419
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 == a2
    assert a1.a == 1
    assert a2.a == 1


# Generated at 2022-06-11 18:39:53.884340
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            print('init')
            pass

    obj1 = MySingleton()
    obj2 = MySingleton()
    assert obj1 is obj2

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:40:07.660585
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value=None):
            self._value = value

        def get_value(self):
            re

# Generated at 2022-06-11 18:40:12.058387
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = Test('a')
    b = Test('b')
    assert id(a) == id(b)
    assert a.arg == 'b'


# Generated at 2022-06-11 18:40:16.048117
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    # singleton class
    class Foo(object):
        __metaclass__ = Singleton

    # define obj1, obj2 as instances of Foo
    obj1 = Foo()
    obj2 = Foo()

    # compare obj1 and obj2
    assert obj1 is obj2, "Singleton failed to return single object"


# Generated at 2022-06-11 18:40:21.016779
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = "bar"

    cls1 = TestClass()
    cls2 = TestClass()

    assert cls1 is cls2

# Generated at 2022-06-11 18:40:32.287615
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.compat.tests import unittest

    # Dummy class for testing Singleton
    class DummySingleton(object):
        __metaclass__ = Singleton

    class TestSingleton(unittest.TestCase):
        def test___call__(self):
            from threading import Thread
            import time

            # Call the method of class Singleton
            dummy1 = DummySingleton()
            dummy2 = DummySingleton()

            self.assertEqual(dummy1, dummy2)

            class CallDummySingleton(Thread):

                def __init__(self, *args, **kwargs):
                    Thread.__init__(self, *args, **kwargs)
                    self.dummy = None

                def run(self):
                    time.sleep(1)
                    self.dummy = Dummy

# Generated at 2022-06-11 18:40:36.885147
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class singleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    # case1:
    # when no instance of singleton existed
    # __init__ was called
    assert singleton('arg').arg == 'arg'

    # case2:
    # when an instance of singleton was already existed
    # __init__ won't be called
    assert singleton('test_arg').arg == 'arg'

    # case3:
    # when an instance of singleton was already existed
    # it can't be overwritten
    assert id(singleton('test_arg2')) == id(singleton('test_arg2'))

# Generated at 2022-06-11 18:40:42.361990
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, name, **kw):
            self._name = name
            self._kw = kw

    assert Foo('first') is Foo('second', arg='myarg')
    assert Foo('first')._name == 'first'
    assert Foo('first')._kw['arg'] == 'myarg'
    assert Foo('first') is not None

# Generated at 2022-06-11 18:40:46.629009
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):

        val = None

        def __init__(self):
            self.__class__.val += 1

    # test
    my_instance1 = MyClass()
    my_instance2 = MyClass()
    assert my_instance1.__class__.val == 2
    assert my_instance1 is my_instance2

# Generated at 2022-06-11 18:40:50.097124
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest

    class C(object):
        __metaclass__ = Singleton

    c1 = C()
    c2 = C()
    assert c1 is c2



# Generated at 2022-06-11 18:40:53.752157
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    # On first call a new instance of TestSingleton should be returned
    first_instance = TestSingleton()
    second_instance = TestSingleton()

    # on second call the same instance should be returned
    assert id(first_instance) == id(second_instance)

# Generated at 2022-06-11 18:41:09.285750
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, x=0):
            self.x = x

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self, s):
            if not hasattr(self, 'x'):
                self.x = 5
            self.s = s

    foo1 = Foo(5)
    foo2 = Foo(10)
    assert foo1 == foo2
    assert foo1.x == foo2.x == 5

    bar1 = Bar('a')
    bar2 = Bar('b')
    assert bar1 == bar2
    assert bar1.s == bar2.s == 'a'
    assert bar1.x == bar2.x

# Generated at 2022-06-11 18:41:14.681345
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Singleton1(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name
    s1 = Singleton1("the_one")
    s2 = Singleton1("the_other")
    assert s1 == s2


if __name__ == '__main__':
    test_Singleton___call__()
    print("all tests passed")

# Generated at 2022-06-11 18:41:17.472351
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton("foo")
    b = TestSingleton("bar")

    assert a is b
    assert a.value == 'foo'
    assert b.value == 'foo'



# Generated at 2022-06-11 18:41:25.220772
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        pass

    from threading import Thread

    results = []

    def thread_func():
        a = A()
        results.append(a)

    threads = []

    # start 100 threads
    for i in range(100):
        thread = Thread(target=thread_func)
        threads.append(thread)
        thread.start()

    # join 100 threads
    for thread in threads:
        thread.join()

    # there should be only one instance stored in results
    assert (len(results) == 1)

# Generated at 2022-06-11 18:41:27.141297
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        pass

    a1 = A()
    a2 = A()
    assert(a1 is a2)



# Generated at 2022-06-11 18:41:37.608726
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    class B(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    a = A(1)
    b = B(2)

    assert a.value == 1
    assert b.value == 2

    a.value = 3
    b.value = 4

    assert a.value == 3
    assert b.value == 4

    new_a = A(5)
    new_b = B(6)

    assert new_a.value == 3
    assert new_b.value == 4

    assert isinstance(a, A)
    assert isinstance(b, B)
    assert isinstance(new_a, A)