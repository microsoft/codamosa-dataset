

# Generated at 2022-06-11 18:31:39.168071
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def add(self, x, y):
            return x + y

    s1 = SingletonTest()
    assert(s1.add(1, 2) == 3)
    s2 = SingletonTest()
    assert(s2.add(3, 4) == 7)
    assert(s1 is s2)


if __name__ == '__main__':
    # Run directly, not as a module
    test_Singleton___call__()
    print('All unit tests of Singleton passed.')

# Generated at 2022-06-11 18:31:43.113424
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.x = 1

    a = A()
    b = A()
    assert a is b
    assert a.x == b.x
    a.x = 2
    assert a.x == b.x


# Generated at 2022-06-11 18:31:51.229313
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.sam = 5

        def __str__(self):
            return "TestSingleton instance with value '{0}'".format(self.sam)

    a = TestSingleton()
    b = TestSingleton()

    # Test for single instance
    assert a is b

    # Test for singletone value
    assert a.sam == b.sam

    # Test for modifying the unique instance
    b.sam = 10
    assert a.sam == b.sam

# Generated at 2022-06-11 18:31:53.651243
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert a == b

# Generated at 2022-06-11 18:31:57.190413
# Unit test for constructor of class Singleton
def test_Singleton():
    # assert Singleton('metaclass', (), {}) is None
    assert Singleton is None

if __name__== '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:31:59.421612
# Unit test for constructor of class Singleton
def test_Singleton():
    attrs = dir(Singleton)
    print(attrs)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:32:09.001203
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

        def set_x(self, x):
            self.x = x

        def get_x(self):
            return self.x

    a = SingletonTest()
    b = SingletonTest()
    b.set_x(2)
    assert a.get_x() == b.get_x()
    assert b.get_x() == 2
    c = SingletonTest()
    c.set_x(3)
    assert a.get_x() == c.get_x()
    assert c.get_x() == 3

# Generated at 2022-06-11 18:32:12.256507
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    a.x = 1
    assert a == b
    assert a.x == 1
    assert b.x == 1


# Generated at 2022-06-11 18:32:17.551514
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    a2.a = 2
    assert a1.a == 2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:32:26.140794
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global counter
    counter = 0

    class Class(object):
        __metaclass__ = Singleton

        def __init__(self):
            global counter
            counter = counter + 1

    assert(counter == 0)
    instance1 = Class()
    assert(counter == 1)
    instance2 = Class()
    assert(counter == 1)
    assert(instance1 is instance2)
    instance3 = Class()
    assert(counter == 1)
    assert(instance1 is instance3)
    assert(instance2 is instance3)

# Generated at 2022-06-11 18:32:28.934695
# Unit test for constructor of class Singleton
def test_Singleton():
    pass

# Generated at 2022-06-11 18:32:33.401525
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.x = value

    x1 = X("test")
    x2 = X("value")
    assert x1.x == "test"
    assert x2.x == "test"
    assert x1 is x2

# Generated at 2022-06-11 18:32:36.192991
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    obj_a = TestClass()
    obj_b = TestClass()
    assert obj_a is obj_b


# Generated at 2022-06-11 18:32:40.596573
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    # Two instances of Test class should be exactly the same
    t1 = Test()
    t2 = Test()
    assert(t1 is t2)

# Generated at 2022-06-11 18:32:50.836641
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from random import randint
    from time import sleep

    class Exposer(object):
        __metaclass__ = Singleton

        def __init__(self, id):
            self.id = id
            self.exposed = []

        def expose(self, value):
            self.exposed.append(value)
            return self.id

    def delay_random():
        sleep(randint(0, 1000) / 100000.0)

    # test
    items = []
    def worker(value):
        delay_random()
        items.append(Exposer.__call__().expose(value))
        delay_random()

    import threading
    threads = []
    for idx in range(100):
        threads.append(threading.Thread(target=worker, args=(idx,)))

# Generated at 2022-06-11 18:32:56.017234
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self, a):
            self.a = a
    assert(A(1) == A(2))
    assert(A(1).a == 1)
    assert(A(2).a == 1)


# Generated at 2022-06-11 18:33:01.001250
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    tsa = TestSingleton()
    tsb = TestSingleton()

    assert tsa == tsb

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:33:07.357505
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.num = 0

        def get_num(self):
            self.num += 1
            return self.num
    t1 = TestClass()
    assert t1.get_num() == 1
    t2 = TestClass()
    assert t2.get_num() == 2
    assert id(t1) == id(t2)
    assert t1.get_num() == t2.num
    return True

# Generated at 2022-06-11 18:33:14.428041
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestObject(object):
        def __init__(self):
            self.instance_count += 1

        instance_count = 0

    obj1 = TestSingleton()
    obj2 = TestSingleton()
    obj3 = TestSingleton()
    assert obj1 is obj2
    assert obj1 is obj3

    obj1 = TestObject()
    obj2 = TestObject()
    obj3 = TestObject()
    assert obj1 is obj2
    assert obj1 is obj3
    assert TestObject.instance_count == 1

# Generated at 2022-06-11 18:33:23.203458
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.module_utils.facts import Facter

    new_instance = Singleton('AnsibleModuleUtilsSingleton', (object,), {'__module__': __name__})
    facter_instance1 = Facter()
    facter_instance2 = Facter()

    assert facter_instance1 == facter_instance2

    facter_instance3 = new_instance()
    facter_instance4 = new_instance()

    assert facter_instance3 == facter_instance4
    assert facter_instance1 != facter_instance3

# Generated at 2022-06-11 18:33:33.459795
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    myinst1 = MyClass('instance 1')
    myinst2 = MyClass('instance 2')

    assert(myinst1 == myinst2)
    assert(myinst1.value == 'instance 1')
    assert(myinst2.value == 'instance 1')



# Generated at 2022-06-11 18:33:41.121938
# Unit test for constructor of class Singleton
def test_Singleton():

    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a
    import multiprocessing
    queues = [multiprocessing.Queue(), multiprocessing.Queue()]
    processes = [multiprocessing.Process(target=A, args=(1,)), multiprocessing.Process(target=A, args=(2,))]

    for i in range(0, 2):
        processes[i].start()
        queues[i].put(processes[i].join())
    queues[0].get()
    queues[1].get()

    assert A(1).a == A(1).a


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:33:45.133156
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        def __init__(self, val=None):
            self.val = val
    a = Test(1)
    b = Test(2)
    assert a is b
    assert a.val == 1
    assert b.val == 1

# Generated at 2022-06-11 18:33:48.258693
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass

    assert A() is A()
    assert id(A()) == id(A())
    assert type(A()) == type(A())

# Generated at 2022-06-11 18:33:49.854899
# Unit test for constructor of class Singleton
def test_Singleton():
    class TEST(object):
        __metaclass__ = Singleton

    t1 = TEST()
    t2 = TEST()
    assert t1 is t2


# Generated at 2022-06-11 18:33:58.469736
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    obj1 = TestClass("1st Call")
    obj2 = TestClass("2nd Call")

    assert obj1 == obj2
    assert obj1.value == obj2.value
    assert id(obj1) == id(obj2)

    # Objects created by __call__ are not singletons.
    # If they are wanted, you have to implement __call__
    # yourself.
    with pytest.raises(Exception):
        obj3 = TestClass("3rd Call")

# Generated at 2022-06-11 18:34:10.378649
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 'Test'

        def __str__(self):
            return self.x

    class Test2(object):
        __metaclass__ = Singleton
        # This initialization method is unused.
        def __init__(self):
            self.x = 'Test2'

        def __str__(self):
            return self.x

    # Check that two instances of the same class are identical
    t1 = Test()
    t2 = Test()
    assert t1 is t2

    # Check that two instances of different class are different
    ta = Test2()
    tb = Test()
    assert ta is not tb

if __name__ == '__main__':
    test_Singleton()


# Generated at 2022-06-11 18:34:18.939668
# Unit test for constructor of class Singleton
def test_Singleton():
    class CommonClass(object):
        __metaclass__ = Singleton
        last_name = None

        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return self.name == other.name

    class OtherClass(object):
        __metaclass__ = Singleton
        last_name = None

        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return self.name == other.name

    c1 = CommonClass('abc')
    c2 = CommonClass('abc')
    c3 = CommonClass('xyz')
    c4 = OtherClass('abc')
    c5 = OtherClass('xyz')

    assert c1 == c2
    assert c1 != c3
    assert c

# Generated at 2022-06-11 18:34:23.264450
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from collections import OrderedDict
    class A(object, metaclass=Singleton):
        def __init__(self):
            self.dict = OrderedDict()
    a = A()
    a1 = A()
    assert a == a1


# Generated at 2022-06-11 18:34:28.724396
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class DictSingleton(dict):
        __metaclass__ = Singleton

    a = DictSingleton()
    b = DictSingleton()
    assert a is b

    a['foo'] = 'bar'
    assert b['foo'] == 'bar'

    c = AnsibleUnicode('foo')
    d = AnsibleUnicode('foo')
    assert c is d

    e = AnsibleUnsafeText('foo')
    f = AnsibleUnsafeText('foo')
    assert e is f

# Generated at 2022-06-11 18:34:42.153721
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    # only one instance exists
    assert(TestSingleton('foo') is TestSingleton('bar'))
    # its value is 'foo'
    assert(TestSingleton('foo').val == 'foo')
    # setting the value to 'bar'
    TestSingleton('foo').val = 'bar'
    # verifies that the value is 'bar'
    assert(TestSingleton('foo').val == 'bar')
    # setting the value to 'foo'
    TestSingleton('foo').val = 'foo'
    # verifies that the value is indeed 'foo'
    assert(TestSingleton('foo').val == 'foo')

# Generated at 2022-06-11 18:34:45.830365
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 10

    a = Foo()
    b = Foo()
    assert a is b
    assert b.x == 10

# Generated at 2022-06-11 18:34:50.759763
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    Unit test for method __call__ of class Singleton
    """
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    s1 = MySingleton('first call')
    s2 = MySingleton('second call')

    assert s1.foo == 'first call'
    assert id(s1) == id(s2)


import pytest


# Generated at 2022-06-11 18:34:53.239065
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo = Foo()
    assert foo == Foo()



# Generated at 2022-06-11 18:34:59.029420
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    t1 = Test(1, 2, 3)
    t2 = Test(3, 4, 5)
    assert t1.a == 1
    assert t1.b == 2
    assert t1.c == 3
    assert t2.a == 1
    assert t2.b == 2
    assert t2.c == 3
    assert t1 is t2
    assert id(t1) == id(t2)

# Generated at 2022-06-11 18:35:03.852108
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        def __call__(self):
            self.x += 1
            return self.x
    class B(A):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 0

    a = A()
    b = B()
    assert a() == 1
    assert b() == 1
    assert b() == 2
    assert b() == 3
    assert a() == 2
    assert a() == 3
    assert b() == 4
    assert b() == 5
    assert a() == 4

# Generated at 2022-06-11 18:35:07.825046
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    class Test2(object):
        __metaclass__ = Singleton

    test1 = Test()
    test2 = Test()
    test3 = Test2()

    assert test1 == test2
    assert test1 != test3

# Generated at 2022-06-11 18:35:10.064301
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 == a2

# Generated at 2022-06-11 18:35:15.691045
# Unit test for constructor of class Singleton
def test_Singleton():
    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.b = 1

    assert B() is B()
    b = B()
    assert b.b == 1

# Generated at 2022-06-11 18:35:21.683197
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass():
        __metaclass__ = Singleton

        def __init__(self):
            self.test_variable = 0

    test_class_object1 = TestClass()
    test_class_object2 = TestClass()

    test_class_object1.test_variable = 10
    assert test_class_object1.test_variable == test_class_object2.test_variable
    assert test_class_object1 is test_class_object2



# Generated at 2022-06-11 18:35:43.656689
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object, metaclass=Singleton):
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    singleton1 = TestSingleton(1, 2)
    singleton2 = TestSingleton(3, 4)
    assert singleton1.arg1 == singleton2.arg1 == 1
    assert singleton1.arg2 == singleton2.arg2 == 2

# Generated at 2022-06-11 18:35:49.147679
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestClass(object):
        __metaclass__ = Singleton

        instance_num = 0

        def __init__(self):
            TestClass.instance_num += 1

    assert TestClass.instance_num == 0

    a = TestClass()
    assert TestClass.instance_num == 1

    b = TestClass()
    assert a == b
    assert TestClass.instance_num == 1



# Generated at 2022-06-11 18:35:50.874777
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    instance1 = Test()
    instance2 = Test()
    assert instance1 is instance2

# Generated at 2022-06-11 18:35:54.493511
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

        def get_value(self):
            return 1

    t1 = Test()
    t2 = Test()

    assert t1 == t2
    assert t1.get_value() == t2.get_value()

# Generated at 2022-06-11 18:36:00.699070
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

        def __str__(self):
            return self.val

    t1 = TestSingleton("foobar")
    t2 = TestSingleton("barfoo")
    assert(t1 is t2)
    assert(t1.val == t2.val)
    assert(t1.val == "foobar")

# Generated at 2022-06-11 18:36:03.340424
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 2

    assert id(Test()) == id(Test())

# Generated at 2022-06-11 18:36:08.550573
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            pass
        def bar(self):
            return "bar"

    class B(metaclass=Singleton):
        def __init__(self):
            pass
        def baz(self):
            return "baz"


if __name__ == "__main__":
    a = test_Singleton()

# Generated at 2022-06-11 18:36:16.803569
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 5
        def add(self, other):
            self.value += other
        def __eq__(self, obj):
            return self.value == obj.value
        def __ne__(self, obj):
            return self.value != obj.value

    instance1 = TestClass()
    instance2 = TestClass()

    # First call to __call__() should instantiate class
    assert instance1 is not None
    assert instance2 is not None
    assert instance1 == instance2

    # Second call should return same instance
    instance1.add(2)
    instance3 = TestClass()
    assert instance1 == instance3
    assert instance1 != instance2

# Generated at 2022-06-11 18:36:21.171775
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = "value"

    a = MyClass()
    assert a.x == "value"

    b = MyClass()
    assert a is b
    assert a.x == b.x

# Generated at 2022-06-11 18:36:26.409583
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, something):
            self.something = something

    o1 = TestSingleton("something")
    o2 = TestSingleton("something else")
    assert o1.something == "something"
    assert o2.something == "something else"
    assert o1 is o2



# Generated at 2022-06-11 18:37:05.974969
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            self.name = ""
            self.attr = ""

        def setName(self, name):
            self.name = name

        def getName(self):
            return self.name

    a0 = A()
    assert a0.name == ""
    a0.setName("a")
    assert a0.name == "a"

    a1 = A()
    assert a0 is a1
    assert a1.name == "a"

# Generated at 2022-06-11 18:37:10.125169
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import os

    class SingletonTestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.pid = os.getpid()

    s1 = SingletonTestClass()
    for i in range(0, 1000):
        s2 = SingletonTestClass()
        assert s1 == s2
        assert s1.pid == s2.pid

# Generated at 2022-06-11 18:37:13.330070
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, value=1):
            self.value = value

    t1 = TestClass()
    t2 = TestClass()
    t1.value = 11
    assert t1 is t2
    assert t2.value == 11



# Generated at 2022-06-11 18:37:18.977795
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase, main, skipUnless
    from os import getenv

    class DummySingleton(object, metaclass=Singleton):
        def __init__(self):
            self.value = 0

    DummySingleton()
    DummySingleton()

    class test_Singleton___call___TestCase(TestCase):
        def test___call___returns_same_instance(self):
            d1 = DummySingleton()
            d2 = DummySingleton()

            self.assertIs(d1, d2, 'Singleton should have returned the same instance')

        def test___call___is_thread_safe(self):
            d1 = DummySingleton()
            d2 = DummySingleton()


# Generated at 2022-06-11 18:37:27.238209
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

        def method_A(self, b):
            return self.a + b

    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.b = 2

        def method_B(self, d):
            return self.b + d

    a1 = A()
    a2 = A()
    assert(a1.method_A(3) == 4)
    assert(a1 is a2)

    b1 = B()
    b2 = B()
    assert(b1.method_B(4) == 6)
    assert(b1 is b2)


# Generated at 2022-06-11 18:37:32.196314
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    s = S(1)
    assert s.value == 1
    assert id(s) == id(S(2))
    import types
    assert isinstance(s, types.InstanceType)

# Generated at 2022-06-11 18:37:37.471492
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Spellchecker(metaclass=Singleton):
        instance_counter = 0

        def __init__(self):
            Spellchecker.instance_counter += 1

        def check(self, word):
            return word

    s = Spellchecker()
    assert Spellchecker.instance_counter == 1

    s1 = Spellchecker()
    assert Spellchecker.instance_counter == 1
    assert s1 == s

# Generated at 2022-06-11 18:37:42.340357
# Unit test for constructor of class Singleton
def test_Singleton():

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, foo, bar):
            self.foo = foo
            self.bar = bar

    # An instance was already created by the previous line.
    inst2 = TestSingleton(123, 'abc')

    assert inst2.foo == 123
    assert inst2.bar == 'abc'

    # The new instance is equal to the first.
    assert inst2 is TestSingleton

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:37:50.603303
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        pass

    # Nothing was assigned before calling __call__()
    assert TestClass.__instance is None

    obj_1 = TestClass()
    # __call__() instantiated an obj and set it to __instance
    assert TestClass.__instance is not None
    assert TestClass.__instance is obj_1

    obj_2 = TestClass()
    # __call__() returned the instantiated object instead
    # of creating a new one.
    assert obj_2 is obj_1
    assert TestClass.__instance is obj_2

# Generated at 2022-06-11 18:37:54.553815
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class foo(metaclass=Singleton):
        def __init__(self, arg):
            self.arg = arg

    a = foo(1)
    b = foo(2)
    assert a.arg == 1 and b.arg == 1

# Generated at 2022-06-11 18:39:02.704469
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value
    a = TestSingleton(1)
    b = TestSingleton(2)
    assert(a.value == 1)
    assert(b.value == 1)
    assert(a is b)


# Generated at 2022-06-11 18:39:06.736934
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = A()      # instance created
    assert a.a == 1

    a2 = A()      # instance already created
    assert a == a2  # returns the same object

# Generated at 2022-06-11 18:39:14.939896
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test1(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2=None):
            self.arg1 = arg1
            self.arg2 = arg2

    class Test2(object):
        __metaclass__ = Singleton

        def __init__(self):
            try:
                raise Exception('Test2 throw an Exception')
            except:
                pass

    n1 = Test1(1, 2)
    n2 = Test1(3, 4)
    assert id(n1) == id(n2)
    assert n1.arg1 == 1
    assert n1.arg2 == 2

    try:
        Test2()
    except:
        pass

    try:
        Test2()
    except:
        pass

# Generated at 2022-06-11 18:39:23.039547
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    __instance1=None
    __rlock1=RLock()
    class cls1(metaclass=Singleton):
        #__instance = None
        #__rlock = RLock()
        def __init__(self):
            pass
    #cls1 = Singleton('cls1',(object,),{})
    #cls1.__instance=None
    #cls1.__rlock=RLock()
    c1=cls1()
    assert __instance1==c1.__instance
    assert __rlock1 == c1.__rlock

# Generated at 2022-06-11 18:39:27.430473
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    tc_instance1 = TestClass('instance1')

    assert tc_instance1.name == 'instance1'

    # Test singleton
    tc_instance2 = TestClass('instance2')

    assert tc_instance2.name == 'instance1'



# Generated at 2022-06-11 18:39:31.442311
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self):
            pass

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2

# Generated at 2022-06-11 18:39:33.416851
# Unit test for constructor of class Singleton
def test_Singleton():
    # TODO: Validate that this test is necessary
    test_instance = Singleton()
    assert isinstance(test_instance, Singleton)



# Generated at 2022-06-11 18:39:37.919332
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    assert a1.a == 1
    a2 = A(2)
    assert a2.a == 1

# Generated at 2022-06-11 18:39:42.111122
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # class Foo(metaclass=Singleton)
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    assert Foo('bar') is Foo('bar')



# Generated at 2022-06-11 18:39:45.575020
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestObj(object):
        __metaclass__ = Singleton

        def __init__(self, value=None):
            self.value = value

    t = TestObj()
    s = TestObj('foo')

    assert t is s
    assert t.value == 'foo'