

# Generated at 2022-06-11 18:31:34.826341
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    o1 = TestClass()
    o2 = TestClass()

    assert o1 is o2
    assert id(o1) == id(o2)

# Generated at 2022-06-11 18:31:37.645405
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()
    assert f1 is f2


# Generated at 2022-06-11 18:31:45.335317
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestClass:
        """Used only for testing methods of class Singleton"""
        __metaclass__ = Singleton
        def __init__(self, arg1, arg2=None):
            print('Call Class __init__')
            self.arg1 = arg1
            self.arg2 = arg2

        def get_args(self):
            return self.arg1, self.arg2

    # Test
    # first call: __instance = None
    instance1 = TestClass('arg1', 'arg2')
    assert instance1.arg1 == 'arg1'
    assert instance1.arg2 == 'arg2'

    # second call: __instance is not None
    instance2 = TestClass('arg3', 'arg4')
    assert instance1 == instance2

    # after changing parameters of second __call__, __instance is not

# Generated at 2022-06-11 18:31:49.771624
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    a = A()
    b = B()

    assert a is A()
    assert b is B()
    assert b is not a

# Generated at 2022-06-11 18:32:01.915973
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''
    Unit test for method __call__ of class Singleton:
    Singleton(type) -> a singleton instance of the given type
    '''
    class TestSingletonExample(object):
        '''
        Example of a singleton class
        '''
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.val = arg

    # create and instance of singleton
    instance1 = TestSingletonExample(1)
    # get another instance of the same singleton
    instance2 = TestSingletonExample(2)
    # compare the instances
    assert isinstance(instance1, TestSingletonExample)
    assert id(instance1) == id(instance2)
    assert instance1.val == instance2.val
    assert instance1.val == 1


# Generated at 2022-06-11 18:32:08.667666
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    ts = TestSingleton(1, 2)
    assert ts.a == 1
    assert ts.b == 2
    ts2 = TestSingleton(1, 2)
    assert ts2.a == 1
    assert ts2.b == 2
    assert ts == ts2

# Generated at 2022-06-11 18:32:10.992218
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class X(object):
        __metaclass__ = Singleton

    x1 = X()
    x2 = X()
    assert x1 is x2

# Generated at 2022-06-11 18:32:18.034581
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    assert TestClass(10).val == 10
    assert TestClass(20).val == 10

    class TestClass1(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    class TestClass2(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    assert TestClass1(10).val == 10
    assert TestClass1(20).val == 10
    assert TestClass2(10).val == 10
    assert TestClass2(20).val == 10
    assert TestClass1(10).val == 10

# Generated at 2022-06-11 18:32:23.824335
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        def __init__(self):
            self.a = 1

    f1 = Foo()
    f2 = Foo()

    assert f1 == f2
    assert f1.a == 1
    assert f2.a == 1



# Generated at 2022-06-11 18:32:29.970899
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, foo, bar):
            self.foo = foo
            self.bar = bar

    a1 = A(foo="foo", bar="bar")
    a2 = A(foo="foo2", bar="bar2")
    assert a1 is a2
    assert a1.foo == a2.foo
    assert a1.bar == a2.bar

# Generated at 2022-06-11 18:32:33.534325
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    isinstance()

    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() == TestClass()

# Generated at 2022-06-11 18:32:34.331979
# Unit test for constructor of class Singleton
def test_Singleton():
    assert isinstance(Singleton, type)

# Generated at 2022-06-11 18:32:40.946862
# Unit test for constructor of class Singleton
def test_Singleton():
    class FakeSingleton1(object):
        __metaclass__ = Singleton

        def __init__(self, i):
            self.i = i

    # If these don't blow up, success!
    assert FakeSingleton1(1) == FakeSingleton1(2)
    assert FakeSingleton1(1).i == 1
    assert FakeSingleton1(2).i == 1

# Generated at 2022-06-11 18:32:47.719826
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    assert isinstance(TestSingleton('foo'), TestSingleton)
    assert TestSingleton('foo') == TestSingleton('bar')
    assert TestSingleton('foo').foo == 'foo'
    assert TestSingleton('bar').foo == 'foo'



# Generated at 2022-06-11 18:32:51.944497
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(42)
    a2 = A(43)
    assert a1 is a2
    assert a1.a == a2.a == 42


# Generated at 2022-06-11 18:32:59.363681
# Unit test for constructor of class Singleton
def test_Singleton():
    class test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 0

        def increment(self):
            self.val += 1
            return self.val

    obj1 = test()
    assert obj1.increment() == 1
    obj2 = test()
    assert obj1 == obj2
    assert obj2.increment() == 2

if __name__ == '__main__':
    raise SystemExit(test_Singleton())

# Generated at 2022-06-11 18:33:04.104567
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    objA1 = A()
    objA2 = A()
    assert objA1 == objA2

    objA1.x = 2
    assert objA1.x == 2
    assert objA2.x == 2



# Generated at 2022-06-11 18:33:07.468528
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self._id = 'foo'

    assert type(Foo()) is Foo

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:33:13.161136
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''Unit test for method __call__ of class Singleton'''
    class SingletonValue(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    testVal1 = SingletonValue(1)
    testVal2 = SingletonValue(2)
    testVal3 = SingletonValue(3)

    assert testVal1 is testVal2 is testVal3

# Generated at 2022-06-11 18:33:17.515800
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 1

    assert TestSingleton() is TestSingleton() is TestSingleton()
    TestSingleton().test = 3
    assert TestSingleton().test == 3

# Generated at 2022-06-11 18:33:22.807689
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test:
        __metaclass__ = Singleton

    instance1 = Test()
    instance2 = Test()
    assert instance1 == instance2

# Generated at 2022-06-11 18:33:26.666039
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object, metaclass=Singleton):
        def __init__(self, x, y):
            self._x = x
            self._y = y

        def __str__(self):
            return str((self._x, self._y))

    a = A(1, 2)
    b = A(3, 4)
    assert a is b


# Generated at 2022-06-11 18:33:37.672957
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 'Foo'

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 'Bar'

    f = Foo()
    b = Bar()
    assert f.x == 'Foo' and b.x == 'Bar'
    assert f is Foo() and b is Bar()
    assert Foo() is f and Bar() is b

    class Foo2(Foo):
        def __init__(self):
            self.x = 'Foo2'

    class Bar2(Bar):
        def __init__(self):
            self.x = 'Bar2'

    f2 = Foo2()
    b2 = Bar2()
   

# Generated at 2022-06-11 18:33:42.846215
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 4
            self.b = 10

    a = SingletonTest()
    b = SingletonTest()

    assert a is b
    assert a.a == 4 and a.b == 10
    assert a.a == b.a and a.b == b.b



# Generated at 2022-06-11 18:33:44.973648
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()



# Generated at 2022-06-11 18:33:52.931469
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            print('Initializing {}'.format(self))
            self.name = name

        def __str__(self):
            return "TestClass instance"

    a = TestClass('a')
    print(a)
    b = TestClass('b')
    print(b)
    assert a is b
    assert a.name == 'b'
    assert b.name == 'b'

# Generated at 2022-06-11 18:33:55.995964
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self, val):
            self.__val = val

        def get_val(self):
            return self.__val

    # Instantiate two objects and check only one instance is created
    test1 = Test(1)
    test2 = Test(2)
    assert test1 is test2

    # Check the value is properly saved
    assert test1.get_val() == 1
    assert test2.get_val() == 1

# Generated at 2022-06-11 18:33:58.026192
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    assert a is A()
    assert a is not A()



# Generated at 2022-06-11 18:34:05.551801
# Unit test for constructor of class Singleton
def test_Singleton():
    import threading
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.val = value
            print("I am init")
        def __repr__(self):
            return '<MySingleton: %d>' % self.val

    # test for multi threading
    for i in range(10):
        t = threading.Thread(target=lambda: MySingleton(i))
     

# Generated at 2022-06-11 18:34:07.801436
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert(A() == A())

# Generated at 2022-06-11 18:34:18.717257
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from collections import OrderedDict

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = {}

        def save_order(self, key):
            self.a[key] = len(self.a)

    a = A()
    a.save_order('a')
    a.save_order('b')
    a.save_order('c')
    assert a.a == {'a': 0, 'b': 1, 'c': 2}

    b = A()
    b.save_order('d')
    assert b.a == {'a': 0, 'b': 1, 'c': 2, 'd': 3}

    c = A()

# Generated at 2022-06-11 18:34:24.711047
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 1

    test_singleton = TestSingleton()
    assert test_singleton.val == 1
    test_singleton.val = 2
    assert test_singleton.val == 2
    test_singleton_2 = TestSingleton()
    assert test_singleton_2.val == 2


# Generated at 2022-06-11 18:34:29.020377
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonCallTest(object):
        __metaclass__ = Singleton

    # ensure only one instance is returned
    obj1 = SingletonCallTest()
    obj2 = SingletonCallTest()
    assert(obj1 is obj2)

# Generated at 2022-06-11 18:34:35.279816
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingletonClass(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            self._a = 1
    a = TestSingletonClass()
    b = TestSingletonClass()
    assert(a == b)
    assert(a._a == b._a)

# Generated at 2022-06-11 18:34:38.048407
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a1 = A()
    a2 = A()

    assert a1 == a2, 'a1 and a2 should be the same'

# Generated at 2022-06-11 18:34:41.189741
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 is a2

# Generated at 2022-06-11 18:34:44.409704
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # pylint: disable=too-few-public-methods
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.bar = 'baz'

    assert Foo() is Foo()



# Generated at 2022-06-11 18:34:52.044634
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    This test is based on the following file:

        _test-utils/test_multiprocessing_singleton_metaclass.py

    It was modified to be independent from nosetests

    """
    from multiprocessing import Process

    class MyClass(metaclass=Singleton):
        def __init__(self):
            self.a = 1

        def add(self, b):
            self.a += b

    class MyProcess(Process):
        def run(self):
            c = MyClass()
            c.add(1)

    p = [MyProcess() for i in range(10)]
    [x.start() for x in p]
    [x.join() for x in p]

    assert(10 == MyClass().a)

# Generated at 2022-06-11 18:34:54.772854
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        pass
    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)


# Generated at 2022-06-11 18:34:59.149021
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, v):
            self.v = v

    a1 = A(1)
    assert id(a1) == id(A(2))
    assert a1.v == 1

# Generated at 2022-06-11 18:35:08.403880
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    a = A()
    b = A()

    assert a is b
    assert a.val is None and b.val is None

    c = A('c')
    assert c is a and c is b
    assert c.val == 'c' and a.val == 'c' and b.val == 'c'

# Generated at 2022-06-11 18:35:11.498156
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, val=0):
            self.val = val

    A = MyClass()
    B = MyClass()
    assert A is B



# Generated at 2022-06-11 18:35:20.185343
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyTest(object):
        __metaclass__ = Singleton
        def __init__(self, x=0):
            self.x = x
    m1 = MyTest()
    assert m1.x == 0
    m2 = MyTest()
    assert m2.x == 0
    assert m1 is m2
    m3 = MyTest(x=1)
    assert m3.x == 0
    assert m1 is m3
    assert m2 is m3

# Generated at 2022-06-11 18:35:23.489083
# Unit test for constructor of class Singleton
def test_Singleton():
    __metaclass__ = Singleton

    class Sample(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    sample = Sample(10, 5)
    assert sample.a == 10
    assert sample.b == 5

# Generated at 2022-06-11 18:35:30.329607
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 'passed'
    obj1 = TestClass()
    obj2 = TestClass()
    assert obj1 == obj2
    assert obj1.a == 'passed'
    obj1.a = 'changed'
    assert obj2.a == 'changed'
    assert obj1 == obj2


# Generated at 2022-06-11 18:35:35.569711
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, a, b, c):
            self.a, self.b, self.c = a, b, c

    s1 = SingletonTest(1, 2, 3)
    assert id(s1) == id(SingletonTest(1, 2, 3))
    assert id(s1) != id(SingletonTest(3, 2, 1))

# Generated at 2022-06-11 18:35:36.237417
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
	pass

# Generated at 2022-06-11 18:35:41.997709
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = MyClass(1)
    b = MyClass(2)

    assert a == b, 'Two instances of the singleton class are not the same.'
    assert a.value == 1, 'a.value must be 1'



# Generated at 2022-06-11 18:35:44.117765
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert id(TestSingleton()) == id(TestSingleton())


# Generated at 2022-06-11 18:35:49.589484
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create basic class
    class Test:
        __metaclass__ = Singleton

        def __init__(self):
            pass

    # First call
    obj1 = Test()

    # Second call
    obj2 = Test()

    # Verify that obj1 and obj2 are the same instance
    assert obj1 is obj2
    assert id(obj1) == id(obj2)


# Generated at 2022-06-11 18:35:54.294076
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    assert(A() == A())

# Generated at 2022-06-11 18:36:02.882430
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    class MySingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    s = MySingleton("me")
    assert s.name == "me"
    s2 = MySingleton("you")
    # same object should be returned as it was instantiated before
    assert s2.name == "me"
    s3 = MySingletonTest("you")
    # different object should be returned as it was instantiated after
    assert s3.name == "you"

# Generated at 2022-06-11 18:36:05.014547
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton
    s1 = S()
    s2 = S()
    assert s1 is s2

# Generated at 2022-06-11 18:36:08.654911
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, name = "A"):
            self.name = name
    a1 = A()
    a2 = A()
    assert a1 == a2


# Generated at 2022-06-11 18:36:14.798635
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.__x = x
        def get_x(self):
            return self.__x

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.__x = 0
        def get_x(self):
            return self.__x

    b1 = B()
    b2 = B()
    assert b1 is b2
    assert b1.get_x() == b2.get_x()

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.get_x() != a2.get_x()
    assert a1.get_x() == 1
   

# Generated at 2022-06-11 18:36:16.248853
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test_Singleton(object):
        __metaclass__ = Singleton

    x = Test_Singleton()
    y = Test_Singleton()
    assert(x is y)

# Generated at 2022-06-11 18:36:23.383053
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test
    class Dummy(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    a = Dummy(1)
    b = Dummy(2)
    print('id(a)=%s, id(b)=%s' % (id(a), id(b)))
    assert id(a) == id(b)
    print('a.val=%s, b.val=%s' % (a.val, b.val))
    assert a.val == b.val


# Test
if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:36:27.762322
# Unit test for constructor of class Singleton
def test_Singleton():
    # check that Singleton is a type
    assert type(Singleton) == type

    # check that Singleton is a metaclass
    assert Singleton.__class__.__name__ == 'type'

    # check that Singleton creates a new class when called
    assert type(Singleton('name', (object,), dict())) == type



# Generated at 2022-06-11 18:36:32.047240
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

    class B:
        __metaclass__ = Singleton

    a = A()
    b = A()
    c = B()
    assert a == b
    assert a is b
    assert a is not c

# Generated at 2022-06-11 18:36:35.919055
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    t1 = TestClass("t1")
    t2 = TestClass("t2")
    assert t1 is t2
    assert t1.name == t2.name == "t1"

# Generated at 2022-06-11 18:36:53.094896
# Unit test for constructor of class Singleton
def test_Singleton():
    from collections import Counter

    class testSingletonC(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.state = 0

    testSingleton = testSingletonC()
    assert testSingleton is not None
    assert testSingleton.state == 0

    testSingleton_1 = testSingletonC()
    assert testSingleton is testSingleton_1
    assert testSingleton.state == testSingleton_1.state

    # Set state value for testSingleton
    testSingleton.state += 1

    assert testSingleton.state == testSingleton_1.state

    # Set state value for testSingleton_1
    testSingleton_1.state += 1

    assert testSingleton.state == testSingleton_1.state

    print("test_Singleton passed")



# Generated at 2022-06-11 18:36:57.411248
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object, metaclass=Singleton):
        def __init__(self):
            self.arg1 = None
            self.arg2 = None

    test_class_ins1 = TestClass(10, 20)
    assert test_class_ins1.arg1 == 10
    assert test_class_ins1.arg2 == 20

    test_class_ins2 = TestClass(30, 40)
    assert test_class_ins2 == test_class_ins1
    assert test_class_ins2.arg1 == 30
    assert test_class_ins2.arg2 == 40

# Generated at 2022-06-11 18:37:06.060696
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object, metaclass=Singleton):
        def __init__(self):
            pass

    # Create an instance of TestSingleton
    singleton_instance1 = TestSingleton()
    # Create another instance of TestSingleton
    singleton_instance2 = TestSingleton()
    # Determine whether the two instances are the same instance
    assert singleton_instance1 is singleton_instance2
    print('Success: TestSingleton class is a singleton class')


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:37:09.617027
# Unit test for constructor of class Singleton
def test_Singleton():

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    assert SingletonTest(1).value == 1
    assert SingletonTest(2).value == 1
    assert SingletonTest(3).value == 1

# Generated at 2022-06-11 18:37:13.668408
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 1

    a = Foo()
    b = Foo()

    assert a.foo == 1
    assert b.foo == 1

    a.foo = 2

    assert a.foo == 2
    assert b.foo == 2

    b.foo = 3

    assert a.foo == 3
    assert b.foo == 3

# Generated at 2022-06-11 18:37:19.336868
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        _x = 0

        def __init__(self):
            A._x += 1

        def get_x(self):
            return A._x

    a1 = A()
    a2 = A()

    if a1.get_x() == 1 and a1.get_x() == 1 and a1 is a2:
        print('Success')
    else:
        print('UnSuccess')


# Generated at 2022-06-11 18:37:24.732093
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Object(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.counter = 0

        def method(self):
            self.counter += 1

    o = Object()
    o.counter = 10
    assert o.counter == 10

    # get another instance
    oo = Object()
    assert oo.counter == 10

    # test for call of __call__
    oo.method()
    assert o.counter == 11
    assert oo.counter == 11

# Generated at 2022-06-11 18:37:27.204490
# Unit test for constructor of class Singleton
def test_Singleton():

    class X(metaclass=Singleton):
        pass

    x1 = X()
    x2 = X()
    assert id(x1) == id(x2)


# Generated at 2022-06-11 18:37:32.513682
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, bar):
            self.bar = bar

    foo1 = Foo('bar1')
    foo2 = Foo('bar2')

    assert foo1.bar == 'bar1'
    assert foo2.bar == 'bar1'
    assert foo1 is foo2

test_Singleton()

# Generated at 2022-06-11 18:37:33.279834
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton


# Generated at 2022-06-11 18:37:48.202470
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(metaclass=Singleton):
        pass

    a = MySingleton()
    b = MySingleton()
    assert a is b



# Generated at 2022-06-11 18:37:54.377165
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self._x = 1

        @property
        def x(self):
            return self._x

    # emulate the following code:
    #  o = A()
    #  o1 = A()
    #  o == o1
    o = A.__call__()
    o1 = A.__call__()
    assert o == o1
    # emulate the following code:
    #  o.x == o1.x
    #  o.x = 2
    #  o1.x == 2
    assert o.x == o1.x
    o.x = 2
    assert o.x == 2
    assert o1.x == 2
    # emulate the following code:
    #  o == o

# Generated at 2022-06-11 18:37:57.998773
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
    assert MyClass() is MyClass()
    assert type(MyClass()) == MyClass
    assert type(MyClass()) == MyClass

# Generated at 2022-06-11 18:38:03.517689
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, param):
            self.param = param
    instance1 = Test('hello')
    instance2 = Test('goodbye')

    assert instance1 == instance2, 'Instances of singleton must be equal'
    assert instance1.param == instance2.param, 'Singleton instances must have same attributes'
    assert instance1 is instance2, 'Instances of singleton must be identical'

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:38:10.246735
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from collections import OrderedDict

    class A(object):
        __metaclass__ = Singleton
        def __init__(self, name, age):
            self.name = name
            self.age = age
            self.orders = OrderedDict()


    a1 = A('AAA', 100)
    a2 = A('BBB', 200)
    a3 = A('CCC', 300)

    assert a1 is a2 is a3
    assert a1.name is 'CCC'
    assert a1.age is 300

# Generated at 2022-06-11 18:38:12.271248
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()
    assert A() is not None

# Generated at 2022-06-11 18:38:16.145289
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    class TestClassDummy(object):
        __metaclass__ = Singleton

    test_instance_1 = TestClass()
    test_instance_2 = TestClass()

    test_instance_dummy_1 = TestClassDummy()
    test_instance_dummy_2 = TestClassDummy()

    assert test_instance_1 is test_instance_2
    assert test_instance_dummy_1 is test_instance_dummy_2

# Generated at 2022-06-11 18:38:18.521452
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestA(metaclass=Singleton):
        def __init__(self):
            print("testa init")
    a1 = TestA()
    a2 = TestA()
    assert a1 == a2


# Generated at 2022-06-11 18:38:21.317472
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        pass

    c1 = TestClass()
    c2 = TestClass()
    assert c1 is c2

# Generated at 2022-06-11 18:38:27.043534
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'TestSingleton'

    t1 = TestSingleton()
    assert isinstance(t1, TestSingleton)
    t2 = TestSingleton()
    assert isinstance(t2, TestSingleton)
    assert t1 is t2
    assert t1.name == 'TestSingleton'
    assert t2.name == 'TestSingleton'

# Generated at 2022-06-11 18:38:58.059375
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    a = A(1, 2, 3)
    b = A(1, 2, 3)
    c = A(2, 3, 4)

    assert a == b
    assert a is b
    assert a != c

    print(a)  # show A
    print(b)
    print(c)


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:39:00.922511
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Single1(object):
        __metaclass__ = Singleton

    a = Single1()
    b = Single1()

    assert a is b


# Generated at 2022-06-11 18:39:05.221672
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Obtain an instance of Singleton
    class TestClass(object):
        __metaclass__ = Singleton

    obj1 = TestClass()
    obj2 = TestClass()

    # Assert that Singleton returns the same instance
    assert obj1 is obj2


# Generated at 2022-06-11 18:39:10.911592
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, arg1, arg2 = None):
            self.arg1 = arg1
            self.arg2 = arg2

    x = SingletonTest(1, 2)
    y = SingletonTest(2, 3)
    assert y == x

    try:
        z = SingletonTest(3)
    except TypeError as e:
        assert "__init__() takes 2 positional arguments" in str(e)
    else:
        assert False, 'Expected no instance z of SingletonTest'

    assert z is None



# Generated at 2022-06-11 18:39:12.738775
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class foo(object):
        __metaclass__ = Singleton

    assert foo() is foo()



# Generated at 2022-06-11 18:39:21.659983
# Unit test for constructor of class Singleton
def test_Singleton():
    from six import assertCountEqual
    class SingletonStorage(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.store = {}

    s1 = SingletonStorage()
    s2 = SingletonStorage()
    assert s1 is s2
    s1.store['x'] = 1
    assert s1.store == s2.store
    s2.store['y'] = 1
    assertCountEqual(s1.store.keys(), s2.store.keys())
    s2.store.pop('x')
    assert s1.store != s2.store
    assert len(s1.store) == len(s2.store) == 1

# Generated at 2022-06-11 18:39:25.758236
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest

    class Alpha(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    rc = Alpha(10)
    assert rc.x == 10

    rc = Alpha(20)
    assert rc.x == 10


# Generated at 2022-06-11 18:39:28.812273
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            super(TestSingleton, self).__init__()
            raise RuntimeError("I should never be called")
    try:
        ts1 = TestSingleton()
    except RuntimeError as e:
        assert 'never be called' in str(e)
    ts2 = TestSingleton()
    assert id(ts1) == id(ts2)

# Generated at 2022-06-11 18:39:36.648331
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 0

        def increment(self):
            self.x += 1

    instance1 = A()
    assert instance1
    assert instance1.x == 0

    instance1.increment()
    assert instance1.x == 1
    instance1.increment()
    assert instance1.x == 2

    instance2 = A()
    assert instance2
    assert instance2 == instance1
    assert instance2.x == 2

# Generated at 2022-06-11 18:39:44.410300
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    Test method __call__ of class Singleton
    """
    # Test 1
    class A:
        __metaclass__ = Singleton

        def __init__(self, a=None):
            self.a = a

    A1 = A(a=1)
    A2 = A()

    assert A1 == A2
    assert A1.a == A2.a == 1

    # Test 2
    class B:
        __metaclass__ = Singleton

    B1 = B()
    B2 = B()

    assert B1 == B2

# Generated at 2022-06-11 18:40:38.369587
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__=Singleton
        def __init__(self):
            self.a=1

    a1=A()
    a2=A()
    assert id(a1)==id(a2)
    assert a1.a==a2.a
    a1.a=2
    assert a1.a==a2.a

# Generated at 2022-06-11 18:40:44.120341
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Bla(object):
        __metaclass__ = Singleton
        num = 1
    b1 = Bla()
    b2 = Bla()
    b3 = Bla()
    b1.num = 2
    assert b1.num == 2
    assert b2.num == 2
    assert b3.num == 2
    assert b1 is b2 and b2 is b3 and b1 is b3

# Generated at 2022-06-11 18:40:48.252348
# Unit test for constructor of class Singleton
def test_Singleton():
    print("---------------Singleton test---------------------")
    class Test(metaclass=Singleton):
        pass
    a = Test()
    b = Test()
    assert a is b
    print("---------------Singleton test end---------------------")


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:40:56.083383
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from nose.tools import assert_equal
    from nose.tools import assert_false
    from nose.tools import assert_not_equal
    from nose.tools import assert_true

    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = 'test'

    first_instance = TestSingleton()
    second_instance = TestSingleton()

    assert_true(isinstance(first_instance, TestSingleton))
    assert_true(isinstance(second_instance, TestSingleton))
    assert_false(first_instance is None)
    assert_false(second_instance is None)
    assert_equal(first_instance, second_instance)
    assert_not_equal(first_instance, None)
    assert_not_equal(second_instance, None)


# Generated at 2022-06-11 18:41:06.127485
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import __main__

    # Create a dummy module under the hood of __main__
    __main__.__dict__['A'] = type('A', (object,), {})
    __main__.__dict__['B'] = type('B', (object,), {})

    # Create a singleton class
    class singletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.singletonTest = True

    # Create two instances of the singleton class
    instanceA = singletonTest()
    instanceB = singletonTest()

    # Since singletonTest is a singleton class, it is expected that
    # instanceA and instanceB share the same id
    assert(instanceA.singletonTest == True)
    assert(instanceB.singletonTest == True)

# Generated at 2022-06-11 18:41:11.718977
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    # Call twice and verify singleton property
    # Singleton.__call__ returns the singleton instance
    instance1 = TestClass()
    instance2 = TestClass()
    assert instance1 == instance2
    assert id(instance1) == id(instance2)


# Generated at 2022-06-11 18:41:21.773426
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    # Call the constructor first time
    s1 = MySingleton(1)
    assert s1.value == 1

    # Call the constructor second time
    s2 = MySingleton(2)
    assert s2.value == 1

    # Update the instance value
    s3 = MySingleton(3)
    assert s3.value == 1

    # Return the same instance
    s4 = MySingleton(4)
    assert s4.value == 1

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:41:24.238327
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()

    assert foo1 is foo2

# Generated at 2022-06-11 18:41:27.982054
# Unit test for constructor of class Singleton
def test_Singleton():

    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self._name = name

        @property
        def name(self):
            return self._name

    my_singleton = MySingleton('test')
    assert my_singleton.name == 'test'

    my_singleton = MySingleton('test2')
    assert my_singleton.name == 'test'