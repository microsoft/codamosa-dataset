

# Generated at 2022-06-11 18:31:36.614244
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm1 = TaskQueueManager()
    assert isinstance(tqm1, TaskQueueManager)
    tqm2 = TaskQueueManager()
    assert isinstance(tqm2, TaskQueueManager)
    assert tqm1 == tqm2

# Generated at 2022-06-11 18:31:44.798342
# Unit test for constructor of class Singleton
def test_Singleton():
    import unittest
    import sys
    # noinspection PyPep8Naming
    class SingletonSingleton(metaclass=Singleton):
        def __init__(self,singleton_name):
            print("Singleton.__init__({0})".format(singleton_name))
            self.singleton_name = singleton_name

    class SingletonTest(unittest.TestCase):
        def test_Singleton(self):
            print("Creating instance: SingletonSingleton('object1')")
            instance1 = SingletonSingleton('object1')
            print("Creating instance: SingletonSingleton('object2')")
            instance2 = SingletonSingleton('object2')

            print("Is instance1 == instance2: {0}".format(instance1 == instance2))

# Generated at 2022-06-11 18:31:52.454246
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    class B(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()
    assert(a1 == a2)
    assert(b1 == b2)
    assert(a1 is a2)
    assert(b1 is b2)
    assert(a1 is not b1)
    assert(a1 is not b2)
    assert(a2 is not b1)
    assert(a2 is not b2)



# Generated at 2022-06-11 18:32:03.012858
# Unit test for constructor of class Singleton
def test_Singleton():

    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    # see if it can be instantiated normally
    a = MySingleton()
    b = MySingleton()

    assert a is b
    assert a.x == b.x

    # see if it can be instantiated as a subclass
    class SubClass(MySingleton):
        def __init__(self):
            super(SubClass, self).__init__()
            self.y = 2

    c = SubClass()
    d = SubClass()

    assert c is d
    assert c.x == d.x
    assert c.y == d.y

    # see if it can be instantiated as a subclass with different constructor

# Generated at 2022-06-11 18:32:07.037790
# Unit test for constructor of class Singleton
def test_Singleton():
    class Class1(object):
        __metaclass__ = Singleton
    c1 = Class1()
    c2 = Class1()
    assert(id(c1) == id(c2))


# Generated at 2022-06-11 18:32:09.871348
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    t1 = TestClass()
    t2 = TestClass()

    assert(t1 is t2)



# Generated at 2022-06-11 18:32:13.814556
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, i):
            self.i = i

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.i == 1


# Generated at 2022-06-11 18:32:17.377600
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.value = 123
    a = A()
    assert id(a) == id(A())

# Generated at 2022-06-11 18:32:25.182148
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, foo):
            self.foo = foo

    s1 = MySingleton("bar")
    s2 = MySingleton("qux")

    assert s1.foo == "bar"
    assert s2.foo == "bar"     # This is what makes it a singleton
    assert s1 is s2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:32:35.077225
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Singleton can not be used directly like class
    try:
        singleton = Singleton()
    except TypeError as ex:
        # Singleton is not callable directly.  Singleton is a metaclass,
        # it's responsible for defining the behavior of class, not a
        # class itself.  Singleton always return the same instance, hence
        # it's not recommended to use Singleton like a class.
        assert True
    except:
        assert False

    # Singleton must be used as the metaclass for class that wishes to
    # implement singleton behavior
    class TestSingleton(object):
        __metaclass__ = Singleton

    # now singleton can be used as a class
    singleton1 = TestSingleton()
    singleton2 = TestSingleton()

    # the following two instances must be the same instance
   

# Generated at 2022-06-11 18:32:47.387905
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, *args):
            self.args = args

    # Calling class A
    assert not hasattr(A, '__instance')
    assert isinstance(A(), A)
    assert hasattr(A, '__instance')

    # Calling class A for the second time
    assert not hasattr(A, '__instance')
    assert A() is A()
    assert hasattr(A, '__instance')

    # Calling class A with arguments.  It should still return a single instance.
    assert A(1, 2, 3) is A()

    # Calling class A with different arguments.  It should still return a single instance.
    assert A(1, 2, 3) is A(3, 2, 1)


# Generated at 2022-06-11 18:32:57.204531
# Unit test for constructor of class Singleton
def test_Singleton():
    '''
    This is a unit test function to test the Singleton class.
    :return:
    '''
    try:

        class MyClass(object):
            __metaclass__ = Singleton

        class MyChildClass(MyClass):
            pass

        obj = MyClass()
        print('obj id:', id(obj))
        obj2 = MyClass()
        print('obj2 id:', id(obj2))
        obj3 = MyChildClass()
        print('obj3 id:', id(obj3))


    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:33:05.907891
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global test_Singleton___call___owner

    class TestSingleton___call__(object):
        __metaclass__ = Singleton

        def __init__(self, owner):
            self.owner = owner

    test_Singleton___call___owner = TestSingleton___call__.__name__
    singleton = TestSingleton___call__(test_Singleton___call___owner)
    assert singleton.owner == test_Singleton___call___owner
    assert id(singleton) == id(TestSingleton___call__())
    assert id(singleton) == id(TestSingleton___call__(None))
    return



# Generated at 2022-06-11 18:33:13.297702
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass():
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    # Instantiate the class
    test_instance = TestClass(1, 2)
    assert(isinstance(test_instance, TestClass))
    assert(test_instance.a == 1)
    assert(test_instance.b == 2)

    # The same call returns the same instance
    another_instance = TestClass(3, 4)
    assert(isinstance(another_instance, TestClass))
    assert(another_instance.a == 1)
    assert(another_instance.b == 2)
    assert(test_instance is another_instance)


# Generated at 2022-06-11 18:33:14.345468
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert False

# Generated at 2022-06-11 18:33:22.438965
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name='abc'):
            self.name = name

    singleton_instance = MySingleton()
    if singleton_instance.name != 'abc':
        raise Exception("singleton_instance.name != 'abc'")

    singleton_instance = MySingleton(name='cba')
    if singleton_instance.name != 'abc':
        raise Exception("singleton_instance.name != 'abc'")

# Generated at 2022-06-11 18:33:25.943139
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton0(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    ts0_1 = TestSingleton0()
    ts0_2 = TestSingleton0()
    assert id(ts0_1) == id(ts0_2)



# Generated at 2022-06-11 18:33:30.231875
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2

# Generated at 2022-06-11 18:33:39.911211
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    if cls.__instance is not None:
            return cls.__instance

        with cls.__rlock:
            if cls.__instance is None:
                cls.__instance = super(Singleton, cls).__call__(*args, **kw)

        return cls.__instance
        """

    class A(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    a1 = A('a', 1)
    a2 = A('aa', 2)


    assert a1 is a2
    assert a1.arg1 == a2.arg1
    assert a1.arg2 == a2.arg2

# Generated at 2022-06-11 18:33:43.733019
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'my name'

    assert TestClass('abc') is TestClass()
    assert TestClass('xyz').name == TestClass().name

# Generated at 2022-06-11 18:33:49.668485
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    tc1 = TestClass()
    tc2 = TestClass()

    assert tc1 is tc2


# Generated at 2022-06-11 18:33:59.242650
# Unit test for constructor of class Singleton
def test_Singleton():
    class DummyClass(object):
        __metaclass__ = Singleton

        def __init__(self, a=None, b=None):
            self.a = a
            self.b = b

        def set_a(self, a):
            self.a = a

    a = DummyClass("foo", "bar")
    b = DummyClass("foobar", "barfoo")
    assert a == b, "Should be singleton"
    assert a.a == "foobar", "a.a should be foobar"
    assert a.b == "barfoo", "a.b should be barfoo"
    a.set_a("barfoo")
    assert b.a == "barfoo", "b.a should be barfoo"

# Generated at 2022-06-11 18:34:01.090925
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        def __str__(self):
            return "test"
    assert str(TestClass()) == 'test'

# Generated at 2022-06-11 18:34:05.133840
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(metaclass=Singleton):
        def __init__(self):
            self.__counter = 0

        def inc(self):
            self.__counter += 1

        def get(self):
            return self.__counter

    s1 = MySingleton()
    s2 = MySingleton()

    assert s1 is s2
    s1.inc()
    assert s1.get() is 1
    s2.inc()
    assert s2.get() is 2

# Generated at 2022-06-11 18:34:08.281011
# Unit test for constructor of class Singleton
def test_Singleton():
    class _A(object):
        __metaclass__ = Singleton

    a = _A()
    b = _A()
    assert a is b
    assert not a is _A()

# Generated at 2022-06-11 18:34:12.482456
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    inst1 = TestClass()
    inst2 = TestClass()
    assert inst1 is inst2, "Singleton not working!"

# testing for Singleton
if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:34:20.534458
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import sys

    class Foo(object):
        __metaclass__ = Singleton

    print("Foo.__metaclass__: %s" % Foo.__metaclass__)
    print("Foo.__dict__: %s" % Foo.__dict__)
    print("sys.modules[__name__].__dict__: %s" %
          sys.modules[__name__].__dict__)

    # Instantiate a Foo obj a first time
    foo1 = Foo()
    print("foo1 = Foo() --> %s" % foo1)

    # Instantiate a Foo obj a second time
    foo2 = Foo()
    print("foo2 = Foo() --> %s" % foo2)

    # foo1 and foo2 have the same address
    assert(foo1 == foo2)



# Generated at 2022-06-11 18:34:24.934653
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        pass

    v1 = Foo()
    v1.x = 1

    v2 = Foo()
    assert v1 is v2, "v1 and v2 are not the same Foo obj"
    assert v2.x == 1, "Foo.x was not 1"


# Generated at 2022-06-11 18:34:33.486049
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    class Bar(object):
        __metaclass__ = Singleton

    foo1 = Foo('foo1')
    foo2 = Foo('foo2')
    bar1 = Bar()
    bar2 = Bar()

    assert foo1 is foo2
    assert foo1.value == 'foo1'
    assert foo2.value == 'foo1'

    assert bar1 is bar2

# Generated at 2022-06-11 18:34:36.716431
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test that the class object is a singleton (method __call__)"""
    class A(object):
        __metaclass__ = Singleton

    assert A() is A(), "Same instance expected"



# Generated at 2022-06-11 18:34:43.117246
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton

    obj0 = SingletonClass()
    obj1 = SingletonClass()
    assert obj0 == obj1

# Generated at 2022-06-11 18:34:44.861729
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object):
        __metaclass__ = Singleton

    assert C() is C()



# Generated at 2022-06-11 18:34:48.569101
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

    st1 = SingletonTest()
    st2 = SingletonTest()

    assert st1 == st2
    assert st1 is st2 # No new instance is created

# Generated at 2022-06-11 18:34:54.056760
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class singleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            print('test init, not called')
    a = singleton()
    b = singleton()
    print(a==b)


# Generated at 2022-06-11 18:34:57.536205
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class testclass(object):
        __metaclass__ = Singleton

    assert(testclass() is testclass())



# Generated at 2022-06-11 18:35:01.574956
# Unit test for constructor of class Singleton
def test_Singleton():
    """Test case for constructor of class Singleton
    """
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 5

    a = MyClass()
    b = MyClass()
    assert a is b
    assert a.value == b.value



# Generated at 2022-06-11 18:35:06.974427
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass:
        # This is the metaclass declaration
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 2

    class1 = MyClass()
    class2 = MyClass()

    # Check whether it's the same class
    assert class1.value == class2.value

test_Singleton()

# Generated at 2022-06-11 18:35:08.938839
# Unit test for constructor of class Singleton
def test_Singleton():
    class A():
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 2

    a = A()
    a_new = A()
    assert a is a_new
    assert a.x == 2
    assert a_new.x == 2

# Generated at 2022-06-11 18:35:16.787519
# Unit test for constructor of class Singleton
def test_Singleton():
    import copy
    import types

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("Constructor called")

    # test singleton
    a = TestSingleton()
    b = TestSingleton()
    assert(a is b)  # a and b should point to the same instance
    # a and b should be an instance of the same class
    assert(type(a) == type(b))
    # type(a) should be a subclass of TestSingleton
    assert(TestSingleton in type(a).__bases__)
    # a and b should be of type TestSingleton
    assert(type(a) == TestSingleton)

    # TestSingleton should be a subclass of object
    assert(object in TestSingleton.__bases__)

    #

# Generated at 2022-06-11 18:35:21.840232
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    class TestSubClass(TestClass):
        pass

    a = TestClass(42)
    b = TestClass(42)

    assert a is b, "a and b should be same object"
    assert a.val == 42, "a.val should be 42"

    c = TestSubClass(42)
    assert c is a, "c and a should be same object"

    d = TestClass(5)
    assert d is a, "d and a should be same object"
    assert d.val != 5, "d.val should not be 5"


# Generated at 2022-06-11 18:35:33.753349
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    instance1 = Test(1)
    instance2 = Test(2)

    assert instance1 is not None
    assert instance1 is instance2

# Generated at 2022-06-11 18:35:45.183233
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            self.val = 0

        def increment_val(self):
            self.val += 1

    class MyClass2(metaclass=Singleton):
        def __init__(self):
            self.val = 0

        def increment_val(self):
            self.val += 1

    obj1 = MyClass()
    obj2 = MyClass()
    assert obj1 is obj2

    obj1.increment_val()
    assert obj1.val == 1
    assert obj2.val == 1

    obj2.increment_val()
    assert obj1.val == 2
    assert obj2.val == 2

    obj3 = MyClass2()
    obj4 = MyClass2()
    assert obj3 is obj4

    obj

# Generated at 2022-06-11 18:35:50.469089
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import types

    class TestClass(object):
        __metaclass__ = Singleton

    f = TestClass()
    assert 1 == len(TestClass.__subclasses__())
    assert True is instance(f, types.InstanceType)
    assert 'ansible.module_utils.basic.Singleton' == f.__class__.__name__
    f2 = TestClass()
    assert f is f2


# Generated at 2022-06-11 18:35:55.377283
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
   """Test method __call__ of class Singleton"""

   class TestSingleton(metaclass=Singleton):
       def __init__(self, a, b):
           self.a = a
           self.b = b

   obj1 = TestSingleton(1, 2)
   assert obj1.a == 1
   assert obj1.b == 2

   obj2 = TestSingleton(3, 4)
   assert obj2.a == 1
   assert obj2.b == 2

   assert obj1 == obj2

# Generated at 2022-06-11 18:36:00.194785
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    # Create an instance of MyClass
    my_class_instance = MyClass()

    # The instance should be returned if we try to create another instance
    assert my_class_instance == MyClass()


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:36:04.034452
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingletonChild(TestSingleton):
        pass

    assert TestSingleton() is not None
    assert TestSingleton() is TestSingleton()
    assert TestSingletonChild() is TestSingleton()



# Generated at 2022-06-11 18:36:07.333860
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
    s1 = SingletonTest()
    s2 = SingletonTest()
    assert s1 == s2


# Generated at 2022-06-11 18:36:10.080848
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass:
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 1

    test_instance = MyClass()
    assert type(test_instance).__name__ == 'MyClass'
    assert test_instance.val == 1

# Generated at 2022-06-11 18:36:13.348348
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Check that call returns the same instance always
    instance1 = Singleton()
    instance2 = Singleton()
    assert id(instance1) == id(instance2)

    # Check that instance is of correct type
    instance1 = Singleton()
    assert isinstance(instance1, Singleton)

# Generated at 2022-06-11 18:36:22.462453
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Single instance of class SingletonTest1
    class SingletonTest1(object):
        __metaclass__ = Singleton

    assert SingletonTest1() == SingletonTest1()

    # Multiple instances of the same class but with different parameters
    # If a singleton method does not receive args or kwargs, it should
    # return the same instance for any parameters passed to the class
    # constructor.
    class SingletonTest2(object):
        __metaclass__ = Singleton

    assert SingletonTest2(1) != SingletonTest2(2)

    # However, if __init__ receives args or kwargs, the singleton
    # method should return the same instance regardless of parameters
    class SingletonTest3(object):
        __metaclass__ = Singleton


# Generated at 2022-06-11 18:36:40.560354
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    a = SingletonTest()
    b = SingletonTest()
    assert(a is b)



# Generated at 2022-06-11 18:36:43.903114
# Unit test for constructor of class Singleton
def test_Singleton():
    class Testclass(object):
        __metaclass__ = Singleton

    a = Testclass()
    b = Testclass()

    assert a is b
    assert id(a) == id(b)

# Generated at 2022-06-11 18:36:50.182054
# Unit test for constructor of class Singleton
def test_Singleton():

    class DataProvider(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.data = []

    for _ in range(4):
        data_provider = DataProvider()
        data_provider.data.append("data-from-{}".format(id(data_provider)))

    assert len(DataProvider().data) == 4
    assert len(DataProvider.__call__().data) == 4

# Generated at 2022-06-11 18:36:52.872267
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    a = Foo()
    b = Foo()
    assert a is b
    assert id(a) == id(b)



# Generated at 2022-06-11 18:36:55.106373
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    instance1 = SingletonClass1()
    assert id(instance1) == id(SingletonClass1())


# Generated at 2022-06-11 18:36:59.305882
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self, id):
            self.id = id
            self.ref = []

    a1 = A(1)
    a2 = A(2)

    assert a1.id == 1
    assert a2.id == 1
    assert a1 is a2



# Generated at 2022-06-11 18:37:03.447070
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

    a = A()
    b = A()
    c = A()

    assert a == b
    assert b == c

# Generated at 2022-06-11 18:37:06.897841
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(Singleton):
        def __init__(self, val):
            self.value = val
        pass

    object1 = TestClass(1)
    object2 = TestClass(2)
    assert(object1 == object2)
    pass

# Generated at 2022-06-11 18:37:10.656714
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, v=None):
            self.v = v

    my_instance1 = MyClass(1)
    my_instance2 = MyClass(2)

    assert my_instance1.v == 1
    assert my_instance2.v == 2

# Generated at 2022-06-11 18:37:14.147213
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    assert(SingletonTest.__instance is None)
    s1 = SingletonTest('a')
    assert(SingletonTest.__instance == s1)
    assert(singleton_test('a') == s1)


# Generated at 2022-06-11 18:37:53.257549
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        def __init__(self, value):
            self.value = value
            print("MyClass.__init__(value={0})".format(value))

    class MySubClass(MyClass, metaclass=Singleton):
        def __init__(self, value, subvalue):
            MyClass.__init__(self, value)
            self.subvalue = subvalue
            print("MySubClass.__init__(value={0}, subvalue={1})".format(value, subvalue))

    instance_01 = MyClass(value=1)
    instance_02 = MyClass(value=2)

    assert instance_01 == instance_02
    assert instance_01.value == 1
    assert instance_02.value == 1


# Generated at 2022-06-11 18:37:58.838478
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 'test'
    assert b.value == 'test'


# Generated at 2022-06-11 18:38:01.390472
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, test):
            self.test = test

    a = A(100)
    assert a.test == 100
    b = A(200)
    assert b.test == 100

# Generated at 2022-06-11 18:38:04.438660
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo():
        __metaclass__ = Singleton
        def __init__(self, *args):
            self.args = args

    assert Foo('bar') is Foo('baz')
    assert Foo('bar').args == ('bar',)

# Generated at 2022-06-11 18:38:08.210899
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    # Instantiate the TestClass
    inst0 = TestClass()

    # Now call the TestClass and verify it returns the same object
    inst1 = TestClass()

    assert inst0 is inst1


# Generated at 2022-06-11 18:38:12.704466
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kw):
            self.args = args
            self.kw = kw

    a1 = A('a', 1, 2)
    a2 = A('b', 3, 4)
    assert id(a1) == id(a2)



# Generated at 2022-06-11 18:38:15.757777
# Unit test for constructor of class Singleton
def test_Singleton():

    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            # __new__ is called before __init__, so self.__instance is already
            # populated by this point
            assert self is Foo.__instance

    Foo()
    Foo()
    return

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:38:19.959117
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object, metaclass=Singleton):
        def __init__(self):
            self.value = 0
        def __str__(self):
            return str(self.value)

    a = A()
    a.value += 1
    b = A()
    assert b.value == 1
    a.value += 1
    assert b.value == 2

    assert str(a) == '2'
    assert str(b) == '2'


# Generated at 2022-06-11 18:38:22.857300
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        pass

    a = MyClass()
    b = MyClass()

    assert a is b


# Generated at 2022-06-11 18:38:25.100167
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(metaclass=Singleton):
        def __init__(self):
            self.a = 5

    assert TestClass() is TestClass()

# Generated at 2022-06-11 18:39:32.610981
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        pass

    class Bar(metaclass=Singleton):
        pass

    foo1 = Foo()
    foo2 = Foo()
    bar = Bar()
    assert foo1 is foo2
    assert foo1 is not bar

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:39:42.190171
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    test_class1 = TestSingleton(1, 2)
    test_class2 = TestSingleton(3, 4)
    test_class3 = TestSingleton(5, 6)

    assert test_class1 == test_class2 == test_class3
    assert test_class1.a == test_class2.a == test_class3.a == 1
    assert test_class1.b == test_class2.b == test_class3.b == 2


# Generated at 2022-06-11 18:39:45.906679
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a=0, b=0):
            self.a = a
            self.b = b

    t1 = Test(a=1, b=2)
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-11 18:39:52.340600
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton

    # Class variables created
    assert hasattr(SingletonClass, '__instance')
    assert hasattr(SingletonClass, '__rlock')

    # __metaclass__ inherited correctly
    assert SingletonClass.__class__.__name__ == 'Singleton'

    # Instance created correctly
    assert isinstance(SingletonClass(), SingletonClass)



# Generated at 2022-06-11 18:39:55.811681
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()
    assert f1 == f2

# Generated at 2022-06-11 18:39:59.340352
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        pass

    test1 = Test()
    test2 = Test()
    assert test1 is test2

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:40:03.684133
# Unit test for constructor of class Singleton
def test_Singleton():
    class ThisClass(object):
        __metaclass__ = Singleton
    # make sure that Singleton actually implemented correctly
    assert issubclass(ThisClass, Singleton)
    assert isinstance(ThisClass, Singleton)
    assert isinstance(ThisClass(), ThisClass)
    assert ThisClass() is ThisClass()


test_Singleton()

# Generated at 2022-06-11 18:40:08.797960
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self, a, b, c=3):
            self.a = a
            self.b = b
            self.c = c

    f1 = Foo(1, 2)
    f2 = Foo(1, 2, c=7)
    f3 = Foo(1, 2)
    assert isinstance(f1, Foo)
    assert isinstance(f2, Foo)
    assert isinstance(f3, Foo)
    assert f1 == f3
    assert f1 is f3
    assert f1.a == 1
    assert f1.b == 2
    assert f2.c == 7

# Generated at 2022-06-11 18:40:11.758958
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    assert Foo(1) is Foo(1)


# Generated at 2022-06-11 18:40:19.511933
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, testarg):
            print("__init__ called")
            self.testarg = testarg

    def test():
        o1 = TestSingleton("foo")
        o2 = TestSingleton("bar")

        print(o1, o2)
        if o1 is o2:
            print("singleton instance")
        else:
            print("not singleton instance")

    test()

if __name__ == '__main__':
    test_Singleton()