

# Generated at 2022-06-11 18:31:41.379494
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        # Class attribute
        x = 0

        __metaclass__ = Singleton

        def __init__(self, a=0):
            # Instance attribute
            self.a = a

        def __str__(self):
            return "MyClass(x=%d, a=%s)" % (MyClass.x, self.a)

    # Call first time
    instance1 = MyClass(1)
    print(instance1)
    MyClass.x += 1

    # Call second time
    instance2 = MyClass(2)
    print(instance2)
    MyClass.x += 1

    # Call third time
    instance3 = MyClass(3)
    print(instance3)
    MyClass.x += 1

    assert instance1 == instance2 == instance3  # tests __eq

# Generated at 2022-06-11 18:31:52.134261
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    import sys
    import os

    PY3 = sys.version_info[0] == 3
    if PY3:
        from unittest.mock import patch
    else:
        from mock import patch

    class SingletonTesting(object):
        __metaclass__ = Singleton

        def __init__(self, **kwargs):
            self.testing = kwargs['testing']

        def test_method(self):
            return 1

    class TestSingleton(unittest.TestCase):

        @patch.dict('os.environ', {'ANSIBLE_PERSISTENT_CACHE_PLUGIN': 'jsonfile'}, clear=True)
        def test_single_instance(self):
            instance1 = SingletonTesting(**{'testing': 1})

# Generated at 2022-06-11 18:31:55.808319
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # This is the actual code from ansible-connection which uses the Singleton
    # metaclass
    import ansible_connection
    ansible_connection = reload(ansible_connection)

    for _, cls in ansible_connection.ConnectionFactory.__cls_registry__.items():
        c = cls()
        for _, cls in ansible_connection.ConnectionFactory.__cls_registry__.items():
            d = cls()
            assert(c is d)


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:32:00.676492
# Unit test for constructor of class Singleton
def test_Singleton():

    class Foo(object):
        __metaclass__ = Singleton

    assert issubclass(Foo, object)
    assert Foo.__instance is None
    foo1 = Foo()
    assert foo1.__class__ is Foo
    assert Foo.__instance is foo1
    foo2 = Foo()
    assert Foo.__instance is foo1
    assert foo1 is foo2

# Generated at 2022-06-11 18:32:03.604320
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass():
        __metaclass__ = Singleton
        def __init__(self):
            pass
    a = TestClass()
    b = TestClass()
    if a == b:
        print ("TestClass Singleton Success")

# Generated at 2022-06-11 18:32:08.667660
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SomeClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.number = 123

    sc1 = SomeClass()
    sc2 = SomeClass()

    assert(sc1.number == sc2.number)
    assert(sc1 is sc2)


# Generated at 2022-06-11 18:32:10.166452
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    a = A()
    assert(a == A())

# Generated at 2022-06-11 18:32:16.714407
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    >>> from ansiblelint import Singleton
    >>> class MyClass(object):
    ...     __metaclass__ = Singleton
    ...     def __init__(self, value):
    ...         self.value = value
    ...
    >>> a = MyClass(1)
    >>> a
    <__main__.MyClass object at 0x000000000149EBA8>
    >>> a.value
    1
    >>> b = MyClass(2)
    >>> b
    <__main__.MyClass object at 0x000000000149EBA8>
    >>> b.value
    1
    """

# Generated at 2022-06-11 18:32:22.034996
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 2


# Generated at 2022-06-11 18:32:29.877682
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    instance_1 = SingletonTest(1, 2)
    instance_2 = SingletonTest(3, 4)
    assert instance_1 == instance_2
    assert (instance_1.a, instance_1.b) == (1, 2)
    assert (instance_2.a, instance_2.b) == (1, 2)



# Generated at 2022-06-11 18:32:42.479261
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print("\nTest method __call__ of class Singleton")
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name
            print("Creating object with name: {0}".format(self.name))

        def __str__(self):
            print("Printing object: {0}".format(self.name))
            return str(self.name)

        def __repr__(self):
            print("Printing object: {0}".format(self.name))
            return str(self.name)
    
    foo1 = Foo("Foo1")
    print("foo1: " + repr(foo1))
    foo2 = Foo("Foo2")
    print("foo2: " + repr(foo2))

# Generated at 2022-06-11 18:32:51.605413
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a, b=2, c=3):
            self.__a = a
            self.__b = b
            self.__c = c

        def get_a(self):
            return self.__a

        def get_b(self):
            return self.__b

        def get_c(self):
            return self.__c

    assert A(1).get_a() == 1
    assert A(1).get_a() == 1
    assert A(1, 2, 3).get_a() == 1
    assert A(1, 2, 3).get_b() == 2
    assert A(1, 2, 3).get_c() == 3
    assert A(1).get_a() == 1
   

# Generated at 2022-06-11 18:32:54.575193
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(with_metaclass(Singleton)):
        pass

    assert Test() is Test()



# Generated at 2022-06-11 18:32:59.483449
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a1 = A(1)
    a2 = A(2)
    assert(a1.value == 1)
    assert(a1.value == a2.value)
    assert(id(a1) == id(a2))


# Generated at 2022-06-11 18:33:08.496865
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.utils.plugin_docs import read_docstring

    class DocSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def get_args(self):
            return self.args

        def get_kwargs(self):
            return self.kwargs

        def load_docs(self):
            self.doc_list = read_docstring(self.docs)

    class TestDocSingleton(DocSingleton):
        docs = 'testdocs'
        def get_docs(self):
            return self.docs


# Generated at 2022-06-11 18:33:12.850145
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(metaclass=Singleton):
        def __init__(self, val):
            self.val = val

    tc1 = TestClass(1)
    assert(tc1.val == 1)
    tc2 = TestClass(2)
    assert(tc2.val == 1)
    assert(tc1 == tc2)

# Generated at 2022-06-11 18:33:20.190402
# Unit test for constructor of class Singleton
def test_Singleton():
    global obj_cnt

    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            global obj_cnt

            obj_cnt = obj_cnt + 1

    obj_cnt = 0

    foo = Foo()
    assert obj_cnt == 1

    bar = Foo()
    assert obj_cnt == 1
    assert foo == bar

    assert isinstance(foo, Foo)
    assert isinstance(bar, Foo)


# Generated at 2022-06-11 18:33:27.384769
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    Unit tests for method __call__ of class Singleton.
    """
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1
            self.y = 2

        def set(self, x, y):
            self.x = x
            self.y = y

        def get(self):
            return (self.x, self.y)

    a1 = A()
    a1.set(3, 4)
    a2 = A()
    assert a1 == a2
    assert a2.get() == (3, 4)

# Generated at 2022-06-11 18:33:38.058097
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest
    from threading import Lock
    from threading import Thread
    from time import time

    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    # Test that class TestClass is a Singleton class
    assert issubclass(TestClass, Singleton)
    # Test that class TestClass is a subclass of object
    assert issubclass(TestClass, object)

    test1 = TestClass(1)
    test2 = TestClass(2)
    # Test that instances test1 and test2 are equal
    assert test1 == test2
    # Test that instance test1 has attribute a with value 1
    assert test1.a == 1
    # Test that instance test2 has attribute a with value 2
    assert test2.a == 2



# Generated at 2022-06-11 18:33:49.820796
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A():
        pass

    class B(A):
        __metaclass__ = Singleton

    class C(A):
        __metaclass__ = Singleton

    #class D(A):
    #    __metaclass__ = Singleton

    a = A()
    b = B()
    c = C()
    #d = D()

    assert a.__class__ is A
    assert b.__class__ is B
    assert c.__class__ is C
    #assert d.__class__ is D

    # Class A is not singleton
    assert id(A()) == id(A())

    # a.__class__ is class A, so A() is not singleton
    assert a.__class__ is A
    assert id(a) != id(A())

    # Class B is singleton:


# Generated at 2022-06-11 18:33:55.391480
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = 'bar'
    assert Test() is Test()



# Generated at 2022-06-11 18:33:58.150930
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonClass(object):
        __metaclass__ = Singleton

    first_instance = SingletonClass()
    second_instance = SingletonClass()
    assert first_instance == second_instance

# Generated at 2022-06-11 18:34:07.802822
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test1(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name
    assert hasattr(Test1, '__instance')
    assert not hasattr(Test1, '__rlock')

    class test2(Test1):
        pass
    assert hasattr(test2, '__instance')
    assert not hasattr(test2, '__rlock')

    t1 = test2('t1')
    t2 = test2('t2')
    assert t1 is t2
    assert t1.name == 't1'



# Generated at 2022-06-11 18:34:13.028757
# Unit test for constructor of class Singleton
def test_Singleton():
    class C:
        __metaclass__ = Singleton
        def __init__(self, a=5):
            self.a = a

    x = C()
    y = C(10)
    assert x.a == 5 and y.a == 5

    z = C(30)
    assert x.a == 30 and y.a == 30 and z.a == 30

# Generated at 2022-06-11 18:34:17.619010
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 42
    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.x == 42
    assert a2.x == 42
    a1.x = 84
    assert a1.x == 84
    assert a2.x == 84


# Generated at 2022-06-11 18:34:21.847721
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        count = 0

        def __init__(self):
            Test.count += 1

    obj1 = Test()
    obj2 = Test()

    assert obj1 is obj2
    assert obj2.count == 1

# Generated at 2022-06-11 18:34:26.531102
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 3

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 5

    assert A().val == 3
    assert B().val == 5
    assert A is A()
    assert B is B()
    assert A is not B


# Generated at 2022-06-11 18:34:33.389691
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # class A(object):
    #     __metaclass__ = Singleton
    class A(object, metaclass=Singleton):
        def __init__(self, x=0):
            self.x = x

    a1 = A(2)
    a2 = A(4)

    assert a1.x == 4
    assert id(a1) == id(a2)


# Generated at 2022-06-11 18:34:37.312525
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("Initialized")

    s1 = SingletonTest()
    s2 = SingletonTest()
    assert(s1 is s2)


# Generated at 2022-06-11 18:34:43.440809
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 'a'
            self.b = 'b'

    ts1 = TestSingleton()
    ts2 = TestSingleton()
    assert ts1 == ts2
    assert ts1.a == ts2.a
    assert ts1.b == ts2.b

# Generated at 2022-06-11 18:34:55.411898
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    # If an instance of the class exists, it's returned.
    assert id(A()) == id(A())
    # Otherwise, a single instance is instantiated and returned.
    assert id(A()) != id(A())
    # If an instance of the class exists, it's returned.
    assert id(A()) == id(A())

# Generated at 2022-06-11 18:35:03.482669
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest1(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 1

    class SingletonTest2(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 2

    s1 = SingletonTest1()
    s1.i += 1
    s2 = SingletonTest1()
    s2.i += 1
    assert s1.i == 3
    assert id(s1) == id(s2)

    s1 = SingletonTest2()
    s2 = SingletonTest2()
    assert id(s1) == id(s2)


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:35:12.578079
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    my_obj1 = MyClass()
    my_obj2 = MyClass()
    assert(my_obj1 is my_obj2)
    assert(my_obj1.a == 1)
    assert(my_obj2.a == 1)
    assert(my_obj1.a == my_obj2.a)

    my_obj2.a = 3
    assert(my_obj1 is my_obj2)
    assert(my_obj1.a == 3)
    assert(my_obj2.a == 3)
    assert(my_obj1.a == my_obj2.a)


# Generated at 2022-06-11 18:35:15.185496
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    x = A()
    y = A()
    assert(x == y)



# Generated at 2022-06-11 18:35:19.368695
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = None

    a = TestSingleton()
    a.val = 42

    a2 = TestSingleton()
    assert a.val == a2.val

# Generated at 2022-06-11 18:35:22.112638
# Unit test for constructor of class Singleton
def test_Singleton():

    class TestClass(metaclass=Singleton):
        pass

    t1 = TestClass()
    t2 = TestClass()
    print(t1 == t2)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:35:24.729164
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.number = 1
    assert A() == A()



# Generated at 2022-06-11 18:35:31.938777
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 0

        @classmethod
        def inc(cls):
            cls.__instance.i += 1

    Test.inc()
    t = Test()
    assert id(t) == id(Test())
    assert t.i == 1
    Test.inc()
    assert t.i == 2


# Generated at 2022-06-11 18:35:37.521327
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object, metaclass=Singleton):
        def __init__(self, name=None):
            self.name = name

    t1 = Test()
    t2 = Test()
    assert t1 is t2

    try:
        Test.__instance = None
        t3 = Test()
        t4 = Test()
        assert t3 is t4
    except:
        assert 1 == 0

    try: # try with different parameters
        t5 = Test("Danny")
        t6 = Test("Danny")
        assert t5 is t6
    except:
        assert 1 == 0


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:35:46.213304
# Unit test for constructor of class Singleton
def test_Singleton():
    class c1(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    class c2(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x
    # create instance and verify we get the same instance back
    a = c1(1)
    b = c1(2)
    assert a.x == 1
    assert a is b
    # create instance and verify we get the same instance back
    c = c2(3)
    d = c2(4)
    assert c.x == 3
    assert c is d

# Generated at 2022-06-11 18:35:52.857535
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert id(a) == id(b)



# Generated at 2022-06-11 18:35:57.116667
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            # This method should be called only once
            print("initialize TestSingleton class")
            
    # Create two instances of TestSingleton class
    singleton_instance1 = TestSingleton()
    singleton_instance2 = TestSingleton()
    
    # The following assert statement will fail
    # assert(singleton_instance1 == singleton_instance2)
    assert(singleton_instance1 is singleton_instance2)

# Generated at 2022-06-11 18:35:59.473017
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        pass
    a = Test()
    b = Test()
    assert(a is b)



# Generated at 2022-06-11 18:36:03.792186
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.id = val

    a = TestSingleton("A")
    b = TestSingleton("A")

    assert id(a) == id(b)
    assert a.id == "A"



# Generated at 2022-06-11 18:36:12.270314
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Tests that the Singleton metaclass can be used and that it
    behaves as expected.
    """
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            # Set an empty list as an instance attribute
            self.attrs = []

    # Create an instance of our class
    a = TestSingleton()
    # Change the list on the class instance
    a.attrs.append(1)

    # Create another instance of our class
    b = TestSingleton()
    # Change the list on the instance
    b.attrs.append(2)
    # In the original example, it was thought that the old instance
    # would show the values for A and B, but this is not the case.

    # This should show the contents of a, not the contents of b,

# Generated at 2022-06-11 18:36:17.082559
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # TODO: write unit test
    # test that if an instance already exists, it's returned
    # test that if an instance does not exist, it's created and returned
    # test that if an instance does not exist, and is being created, that
    #   only one instance is created
    # test that if an instance does not exist, and is being created, that
    #   only one instance is created even in a multithreaded environment

    pass


# Generated at 2022-06-11 18:36:19.971448
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            self.value = 10


# Generated at 2022-06-11 18:36:24.425464
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            print("A() init")
            print(args)
            print(kwargs)
            return
        def repr(self):
            return 'A() repr'

    a = A('aa', 'bb')
    b = A()
    print(a)
    print(b)
    print(a == b)
    print('111111')
    a.repr()
    print('222222')

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:36:26.791140
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert(TestSingleton() == TestSingleton())

# Generated at 2022-06-11 18:36:30.326563
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singletonTest = Singleton('SingletonTest', (object,), {})

    singletonTest()
    instance = singletonTest()

    assert singletonTest.__instance == instance



# Generated at 2022-06-11 18:36:39.622974
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a
        def __eq__(self, other):
            return isinstance(other, A) and self.a == other.a
        def __repr__(self):
            return 'A(a=%s)' % self.a

    def do_test(a1, a2):
        assert a1 == a2
        assert a1 is a2

    a1 = A(1)
    do_test(a1, A(1))

    a2 = A(2)
    do_test(a2, A(2))

    # change the value of A(1)
    a1.a = 3
    do_test(a1, A(3))


# Generated at 2022-06-11 18:36:49.135437
# Unit test for constructor of class Singleton
def test_Singleton():

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    singleton1 = SingletonTest()
    singleton2 = SingletonTest()

    # check for singletons
    assert singleton1 == singleton2

    singleton1.a = 2
    # check if change propagates
    assert singleton1.a == singleton2.a


# This is a convenience wrapper around Singleton that makes it easier
# to use with Ansible's provided base classes (ActionBase and
# PluginBase).  This is the class you should use in your plugins, see
# examples below.

# Generated at 2022-06-11 18:36:50.846635
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    a = SingletonTest()
    b = SingletonTest()
    assert a == b


# Generated at 2022-06-11 18:36:54.334917
# Unit test for constructor of class Singleton
def test_Singleton():
    # test class that inherits from Singleton
    class SingletonClass(object):
        __metaclass__ = Singleton
        pass

    # create two instances of the class and test that they are the same
    singleton1 = SingletonClass()
    singleton2 = SingletonClass()

    assert id(singleton1) == id(singleton2)

# Generated at 2022-06-11 18:37:01.956306
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(metaclass=Singleton):
        def __init__(self):
            self.x = "first"

    a1 = MySingleton()
    a2 = MySingleton()
    print(a1.x, a2.x)
    a1.x = "second"
    print(a1.x, a2.x)
    a2.x = "third"
    print(a1.x, a2.x)

    # output:
    # first first
    # second second
    # second second

# Generated at 2022-06-11 18:37:05.852380
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = 'instance of MyClass'


    assert(MyClass() is MyClass())


# Generated at 2022-06-11 18:37:08.224580
# Unit test for constructor of class Singleton
def test_Singleton():
    class Msg(object):
        __metaclass__ = Singleton

    msg1 = Msg()
    msg2 = Msg()
    assert msg1 is msg2


# Generated at 2022-06-11 18:37:13.263353
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1(Singleton):
        def __init__(self, msg='hello world'):
            self.msg = msg

        def print_msg(self):
            print(self.msg)

    o1 = Test1()
    o2 = Test1()
    o1.print_msg()
    o2.print_msg()
    o1.msg = 'foo'
    o1.print_msg()
    o2.print_msg()

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:37:18.011138
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, a=1, b=2):
            self.a = a
            self.b = b

    s1 = TestSingleton()
    assert(s1.a == 1 and s1.b == 2)
    s2 = TestSingleton(1, 3)
    assert(s1 is s2)
    assert(s2.a == 1 and s2.b == 2)  # the values are the same as s1


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:37:21.481920
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(metaclass=Singleton):
        def __init__(self, val):
            self.val = val

    a = SingletonClass(5)
    b = SingletonClass(10)

    assert a.val == 5
    assert b.val == 5

# Generated at 2022-06-11 18:37:32.953536
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        pass

    a1 = A()
    a2 = A()

    assert(a1 == a2)

# Generated at 2022-06-11 18:37:35.661552
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo:
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1


    x = Foo()
    y = Foo()
    assert x is y
    assert x.value == 1
    x.value = 2
    assert y.value == 2



# Generated at 2022-06-11 18:37:39.697491
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonClass(metaclass=Singleton):
        def __init__(self):
            self.value = 1

    assert SingletonClass().value == 1
    assert SingletonClass().value == 1
    assert SingletonClass().value == 1


# Generated at 2022-06-11 18:37:51.015059
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

        def foo(self):
            print('foo: %s' % self.val)

    a = Foo(42)
    b = Foo(43)
    c = Bar(42)
    d = Bar(43)

    print('a = Foo(42)')
    print('b = Foo(43)')
    print('c = Bar(42)')
    print('d = Bar(43)')

    print('id(a) == id(b)')
    print(id(a) == id(b))


# Generated at 2022-06-11 18:37:53.576861
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class ASingleton(object):
        __metaclass__ = Singleton

    a = ASingleton()
    assert a is ASingleton()

# Generated at 2022-06-11 18:37:59.034535
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.counter = 0

    a1 = A()
    assert a1.counter == 0
    a2 = A()
    a1.counter += 1
    assert a1.counter == 1
    assert a2.counter == 1


# Generated at 2022-06-11 18:38:02.193054
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Sample(object, metaclass=Singleton):
        pass

    test_instance = Sample()
    test_instance.__data = [1, 2, 3]
    for i in range(100):
        obj = Sample()
        assert(obj is test_instance)
        assert(obj.__data == [1, 2, 3])

# Generated at 2022-06-11 18:38:03.551520
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton



# Generated at 2022-06-11 18:38:06.354054
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object, metaclass=Singleton):
        pass

    instance1 = C()
    instance2 = C()
    assert id(instance1) == id(instance2)

# Generated at 2022-06-11 18:38:14.910513
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kw):
            self.args = args
            self.kw = kw

    a = SingletonTest(1,2,foo=3)
    b = SingletonTest(1,2,foo=3)
    c = SingletonTest(4,5,foo=6)

    assert a is b
    assert id(a) == id(b)
    assert a is not c
    assert id(a) != id(c)

    assert a.args == (1,2)
    assert a.kw == {"foo": 3}
    assert b.args == (1,2)
    assert b.kw == {"foo": 3}
    assert c.args == (4,5)
    assert c.kw

# Generated at 2022-06-11 18:38:39.159405
# Unit test for constructor of class Singleton
def test_Singleton():

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, v):
            self.v = v

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a.v == 1
    assert b.v == 1
    assert id(a) == id(b)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:38:46.082886
# Unit test for constructor of class Singleton
def test_Singleton():
    import pytest

    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            if ('test' in globals() and test is not None):
                self.test = True
            else:
                self.test = False

    test_1 = Test()
    test_2 = Test()

    assert (test_1 is test_2)
    assert (test_1.test == False)
    assert (test_2.test == False)

# Generated at 2022-06-11 18:38:49.144729
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x
    a = A(10)
    b = A(20)
    assert b.x == 10 and a is b, 'singleton error'



# Generated at 2022-06-11 18:38:57.365543
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, arg1):
            self.arg1 = arg1

    class MyClass2(object):
        __metaclass__ = Singleton
        def __init__(self, arg1):
            self.arg1 = arg1

    m1 = MyClass('arg1')
    m2 = MyClass('arg2')
    assert m1 == m2
    m3 = MyClass2('arg1')
    m4 = MyClass2('arg2')
    assert m3 == m4


# Generated at 2022-06-11 18:39:00.736427
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'Foo'

    assert id(Foo()) == id(Foo())


# Generated at 2022-06-11 18:39:05.369043
# Unit test for constructor of class Singleton
def test_Singleton():
    class A:
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    a = A(1)
    assert a.x == 1
    b = A(2)
    assert a is b
    assert b.x == 1


# Generated at 2022-06-11 18:39:11.027067
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 1
    class TestClass1(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 2
    a = TestClass()
    b = TestClass()
    a.value = 3
    assert (a.value == b.value)
    a = TestClass1()
    b = TestClass1()
    a.value = 10
    assert (a.value == b.value)
if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:39:18.878225
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        var = 'test value'
        name = 'test'

        def __init__(self):
            # should not be called
            self.var = 'wrong value'
            self.name = 'wrong'

        def __str__(self):
            return self.name

    inst1 = TestClass()
    inst2 = TestClass()
    assert inst1 is inst2
    assert inst1.var == 'test value'
    assert str(inst1) == 'test'


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:39:20.709981
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:39:21.962269
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()

# Generated at 2022-06-11 18:40:05.552731
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import ansible.plugins.loader

    # Instantiate PluginLoader, forcing it to be a singleton.
    class PluginLoader(ansible.plugins.loader.PluginLoader):
        __metaclass__ = Singleton

    loader1 = PluginLoader()
    loader2 = PluginLoader()
    assert loader1 is loader2, \
        "PluginLoader is not a singleton when it should be."

    # Check that it also works as expected when instantiated as a
    # singleton.
    loader3 = ansible.plugins.loader.PluginLoader()
    loader4 = ansible.plugins.loader.PluginLoader()
    assert loader3 is loader4, \
        "PluginLoader is not a singleton when it should be."


# Generated at 2022-06-11 18:40:13.617868
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(with_metaclass(Singleton, object)):
        def __init__(self):
            self.a = 100

    a = MySingleton()
    assert a.a == 100, 'attribute a of MySingleton was not initialized'

    b = MySingleton()
    assert b.a == 100, 'method __call__ did not return existing instance'

    b.a = 200
    assert a.a == 200, 'attribute a of MySingleton does not support assignment'
    assert b.a == 200, 'attribute a of MySingleton does not support assignment'


# Generated at 2022-06-11 18:40:22.116142
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class ClassA(metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    class ClassB(ClassA):
        def __init__(self, a, b):
            super(ClassB, self).__init__(a)
            self.b = b

    class ClassC(ClassB):
        def __init__(self, a, b, c):
            super(ClassC, self).__init__(a, b)
            self.c = c

    obj1 = ClassC(1, 2, 3)
    obj2 = ClassC(4, 5, 6)
    assert obj1 is obj2

# Generated at 2022-06-11 18:40:26.596637
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.utils.path import unfrackpath
    from ansible.config.manager import ConfigManager
    assert ConfigManager() == ConfigManager()
    assert ConfigManager() is ConfigManager()
    assert ConfigManager() is ConfigManager()
    assert ConfigManager() is ConfigManager()
    assert ConfigManager() is ConfigManager()
    assert ConfigManager() == ConfigManager()
    assert ConfigManager() is ConfigManager()
    assert ConfigManager() is ConfigManager()
    assert ConfigManager() is ConfigManager()
    assert ConfigManager() is ConfigManager()


# Generated at 2022-06-11 18:40:35.373636
# Unit test for constructor of class Singleton
def test_Singleton():
    class foo():
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    class bar():
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    f1 = foo('f1')
    assert f1.value == 'f1'
    f2 = foo('f2')
    assert f2.value == 'f1'
    assert f1 is f2

    b1 = bar('b1')
    assert b1.value == 'b1'
    b2 = bar('b2')
    assert b2.value == 'b1'
    assert b1 is b2

    assert f1 is not b1
    assert f1 is not b2

# Generated at 2022-06-11 18:40:38.120408
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        """A sample class to demonstrate the usage of Singleton metaclass.
        """
        __metaclass__ = Singleton

    assert id(TestSingleton()) == id(TestSingleton())

# Generated at 2022-06-11 18:40:40.439049
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    assert MySingleton() is MySingleton()

# Generated at 2022-06-11 18:40:42.623508
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyTestClass(object):
        __metaclass__ = Singleton

    assert MyTestClass() is MyTestClass()



# Generated at 2022-06-11 18:40:46.553114
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a = TestSingleton('aaa')
    assert a.value == 'aaa'
    b = TestSingleton('bbb')
    assert b.value == 'aaa'
    assert a == b

# Generated at 2022-06-11 18:40:54.315632
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.var = 0

        def set_var(self, var):
            self.var = var

        def get_var(self):
            return self.var

    obj1 = TestSingleton()
    assert obj1
    assert obj1.var == 0
    obj1.set_var(1)
    assert obj1.var == 1
    obj2 = TestSingleton()
    assert obj2
    assert obj2.var == 1
    obj2.set_var(2)
    assert obj2.var == 2
    assert obj1.var == 2