

# Generated at 2022-06-11 18:31:41.304410
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = Test()

    assert(a.x == 1)

    Test.__instance = None

    b = Test()

    assert(a is not b)
    assert(a.x == 1)
    assert(b.x == 1)

    a.x = 2
    assert(a.x == 2)
    assert(b.x == 2)

    b.x = 3
    assert(a.x == 3)
    assert(b.x == 3)

    c = Test()
    assert(a is c)
    assert(b is c)

    Test.__instance = None

    d = Test()
    assert(c is d)

    print('tests complete')


#

# Generated at 2022-06-11 18:31:52.022487
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(Singleton):
        pass
    class TestClass2(Singleton):
        def __init__(self):
            assert TestClass2.__instance is None
            assert TestClass.__instance is None
            self.__name = "test_instance"
        def __repr__(self):
            return self.__name
    assert TestClass.__instance is None
    assert TestClass.__rlock is not None
    tc1 = TestClass()
    tc2 = TestClass()
    assert tc1 is tc2
    assert TestClass.__instance is tc1
    tc3 = TestClass2()
    tc4 = TestClass2()
    assert tc3 is tc4
    assert TestClass2.__instance is tc3
    assert TestClass2.__instance is not TestClass.__instance
    assert repr(tc4)

# Generated at 2022-06-11 18:32:02.825431
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.utils.hashs import _get_hash_impl
    # Test for case where instance is not None
    before_instance = _get_hash_impl.__instance
    assert isinstance(_get_hash_impl(), _get_hash_impl)
    assert _get_hash_impl.__instance == before_instance
    # Test for case where instance is None, and rlock is locked
    _get_hash_impl.__instance = None
    before_instance = _get_hash_impl.__instance
    with _get_hash_impl.__rlock:
        assert isinstance(_get_hash_impl(), _get_hash_impl)
    assert _get_hash_impl.__instance == before_instance
    # Test for case where instance is None, and rlock is not locked

# Generated at 2022-06-11 18:32:06.792122
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-11 18:32:11.259619
# Unit test for constructor of class Singleton
def test_Singleton():
    # test a class that implements Singleton
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2
    # test a class that does not implement Singleton
    class B(object):
        pass

    b1 = B()
    b2 = B()
    assert b1 != b2

# Generated at 2022-06-11 18:32:12.999601
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-11 18:32:22.184817
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = "abc"
            self.__rlock = RLock()

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2

    t1.x = "def"
    assert t1.x == "def"
    assert t2.x == "def"

    t2.x = "ghi"
    assert t1.x == "ghi"
    assert t2.x == "ghi"

test_Singleton___call__()

# Generated at 2022-06-11 18:32:25.700133
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    assert Test("First creation") == Test("Second creation")



# Generated at 2022-06-11 18:32:33.909092
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from datetime import datetime

    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.arr = [datetime.now()]

        def stamp(self):
            self.arr.append(datetime.now())

    my_singleton = MySingleton()
    my_singleton.stamp()
    print(my_singleton.arr)

    my_singleton = MySingleton()
    my_singleton.stamp()
    print(my_singleton.arr)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:32:41.482161
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value
    #check that we have at most one instance of SingletonTest
    a = SingletonTest(1)
    b = SingletonTest(2)
    if ((a is not b) or (a.value != 1) or (b.value != 1)):
        raise Exception("Singleton tests failed.")


# Generated at 2022-06-11 18:32:52.060918
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SampleSingleton1(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.__class__.calls += 1

    SampleSingleton1.calls = 0

    class SampleSingleton2(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.__class__.calls += 1

    SampleSingleton2.calls = 0

    x1 = SampleSingleton1(1, 2, 3, a=1)
    assert x1.__class__.calls is 1

# Generated at 2022-06-11 18:33:01.921852
# Unit test for constructor of class Singleton
def test_Singleton():
    # Assert that the dunder instance is None
    assert CustomSingleton.__instance is None, "__instance should be None"

    # Create instance
    instance = CustomSingleton()
    # Assert that dunder instance is not None
    assert CustomSingleton.__instance is not None, "__instance should be set"

    # Create another instance
    instance_2 = CustomSingleton()

    # Assert that dunder instance is the same as one of the instances
    assert CustomSingleton.__instance is instance, "__instance should be the same as one " \
                                                  "of the instances"
    assert CustomSingleton.__instance is instance_2, "__instance should be the same as one " \
                                                    "of the instances"

# Custom class which uses Singleton as metaclass

# Generated at 2022-06-11 18:33:06.469552
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.var = 1

    a = SingletonTest()
    b = SingletonTest()
    assert a is b
    assert a.var == b.var == 1
    a.var = 2
    assert a.var == b.var == 2

# Generated at 2022-06-11 18:33:11.782968
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 1

    a = A()
    assert a.val == 1
    b = A()
    assert a is b
    assert b.val == 1
    b.val = 2
    assert a.val == 2

# Generated at 2022-06-11 18:33:15.801391
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        pass

    class Bar(metaclass=Singleton):
        pass

    foo1 = Foo()
    bar = Bar()
    foo2 = Foo()

    assert foo1 == foo2
    assert foo1 != bar
    assert foo2 != bar



# Generated at 2022-06-11 18:33:19.952133
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    assert id(Foo) == id(Foo())


if __name__ == '__main__':
    test_Singleton()
    print("Test passed.  Singleton is defined correctly.")

# Generated at 2022-06-11 18:33:23.912336
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingletonClass(object):
        __metaclass__ = Singleton

    instance1 = MySingletonClass()
    instance2 = MySingletonClass()

    assert instance1 == instance2

# Generated at 2022-06-11 18:33:27.398995
# Unit test for constructor of class Singleton
def test_Singleton():
    # create a class TestSingleton inherited from class Singleton
    class TestSingleton(Singleton):
        def __init__(self):
            self.number = 42

    # now, we should get the same instance of the class
    class_1 = TestSingleton()
    class_2 = TestSingleton()
    assert class_1 is class_2
    assert class_1.number == 42
    assert class_2.number == 42


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:33:38.096248
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object): pass
    class Bar(object): pass

    class FooSingleton(Foo, metaclass=Singleton):
        __name = 'FooSingleton'

        def __init__(self):
            self.__name = 'FooSingleton'

    class BarSingleton(Bar, metaclass=Singleton):
        __name = 'BarSingleton'

        def __init__(self):
            self.__name = 'BarSingleton'

    assert isinstance(FooSingleton(), Foo)
    assert isinstance(BarSingleton(), Bar)

    a = FooSingleton()
    b = FooSingleton()
    assert a and b
    assert a is b

    c = BarSingleton()
    d = BarSingleton()
    assert c and d
    assert c is d


# Generated at 2022-06-11 18:33:42.710633
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    # Create two instances
    test_instance_1 = TestSingleton()
    test_instance_2 = TestSingleton()

    # This statement should be executed to True
    assert id(test_instance_1) == id(test_instance_2)


# Generated at 2022-06-11 18:33:51.590933
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()
    assert f1 is f2


if __name__ == '__main__':
    test_Singleton___call__()
    print('Singleton unit tests passed')

# Generated at 2022-06-11 18:33:57.179807
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.p = 0

    s1 = S()
    assert(isinstance(s1, S))
    s2 = S()
    assert(s2 is s1)
    s2.p = 1
    assert(s1.p == 1)

# Generated at 2022-06-11 18:34:04.336877
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 'bar'

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.foo == 'bar'
    assert t2.foo == 'bar'

    t1.foo = 'baz'
    assert t1.foo == 'baz'
    assert t2.foo == 'baz'

    # Overwriting __new__ of super class object
    # ensure that object with different __dict__ are not treated as same object in singleton pattern
    class TestSingleton2(object):
        __metaclass__ = Singleton

# Generated at 2022-06-11 18:34:09.024131
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, myarg):
            self.myarg = myarg

    assert id(MyClass('arg_value')) == id(MyClass('another_arg_value'))

# Generated at 2022-06-11 18:34:14.212887
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 123

    t1 = TestSingleton()
    t2 = TestSingleton()
    print(t1.x)
    print(t2.x)


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:34:24.524076
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonOnly(metaclass=Singleton):
        pass

    foo = SingletonOnly()
    bar = SingletonOnly()
    assert foo is bar

    class SingletonOnlyWithArgs(metaclass=Singleton):
        def __init__(self, a, b, c=0):
            self.a = a
            self.b = b
            self.c = c

    foo = SingletonOnlyWithArgs(1, 2)
    bar = SingletonOnlyWithArgs(3, 4)
    assert foo is bar
    assert foo.a == 1
    assert foo.b == 2
    assert foo.c == 0

    baz = SingletonOnlyWithArgs(5, 6, 7)
    assert foo is baz
    assert foo.a == 1
    assert foo.b == 2
    assert foo.c == 0



# Generated at 2022-06-11 18:34:33.666270
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    obj1 = MySingletonClass("first")
    obj2 = MySingletonClass("second")

    if obj1.name == "first" and obj2.name == "first":
        print("test_Singleton: SUCCESS")
    else:
        print("test_Singleton: FAILED")

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:34:38.362337
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    class TestSub(Test):
        pass

    obj1 = Test(1)
    obj2 = TestSub(2)

    assert obj1.arg == 1
    assert obj2.arg == 1
    assert obj1 == obj2

# Generated at 2022-06-11 18:34:45.745350
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    with open('/tmp/test_file', 'w') as f:
        f.write('Singleton test')

    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test_file = '/tmp/test_file'

    t1 = TestSingleton()
    t2 = TestSingleton()
    t3 = TestSingleton()

    assert t1 == t2
    assert t2 == t3



# Generated at 2022-06-11 18:34:49.683963
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()

    assert id(a) == id(b)
    assert TestSingleton.__instance == a
    assert isinstance(TestSingleton.__rlock, RLock)


# Generated at 2022-06-11 18:35:01.153551
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 0

        def add(self, value):
            self.x += value
            return self.x

    assert TestClass().x == 0
    assert TestClass().add(5) == 5
    assert TestClass().x == 5
    assert TestClass().add(12) == 17
    assert TestClass().x == 17

test_Singleton___call__()

# Generated at 2022-06-11 18:35:06.613567
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x=0):
            self.x = x

    a = A()
    assert(a.x == 0)

    b = A(1)
    assert(b.x == 0)
    assert(b is a)

# Generated at 2022-06-11 18:35:14.281847
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1
            self.b = 2

    c = Test()
    d = Test()
    c.c = 3
    d.d = 4
    assert(c == d)
    assert(c.a == 1)
    assert(c.b == 2)
    assert(c.c == 3)
    assert(c.d == 4)
    assert(d.a == 1)
    assert(d.b == 2)
    assert(d.c == 3)
    assert(d.d == 4)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:35:18.979279
# Unit test for constructor of class Singleton
def test_Singleton():

    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    #The next two lines should produce same objects
    obj1 = MyClass()
    obj2 = MyClass()

    assert obj1 is obj2

# Generated at 2022-06-11 18:35:29.597623
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, x=None):
            self.x = x

    # Call the constructor
    test = SingletonTest()
    assert isinstance(test, SingletonTest)

    # Call twice, ensure the same object is returned both times
    test2 = SingletonTest()
    assert isinstance(test2, SingletonTest)
    assert id(test) == id(test2)
    assert test == test2

    # Ensure a different object is created with different arguments
    test3 = SingletonTest(x=2)
    assert isinstance(test3, SingletonTest)
    assert id(test) != id(test3)
    assert test != test3
    assert test2 != test3

    # Ensure a new object is created with the same arguments

# Generated at 2022-06-11 18:35:37.306292
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.errors import AnsibleError

    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("init")
            self.x = 10
            self.y = 20

        def get_x(self):
            return self.x

        def get_y(self):
            return self.y

    def get_inst():
        return MySingleton()

    # test init
    try:
        test_obj = MySingleton()
        print("test_obj: %s" % test_obj)
    except AnsibleError as e:
        print("Unexpected exception: %s" % e)
        return False

    # test get_x

# Generated at 2022-06-11 18:35:38.640406
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton


# Generated at 2022-06-11 18:35:49.147656
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingletone(object):
        __metaclass__ = Singleton
        x = 2
        y = 3

        def __init__(self):
            self.x = TestSingletone.x
            self.y = TestSingletone.y

        def f(self, x, y):
            return x + y

    ts1 = TestSingletone()
    assert ts1.x == TestSingletone.x
    assert ts1.y == TestSingletone.y
    assert ts1.f(ts1.x, ts1.y) == ts1.f(TestSingletone.x, TestSingletone.y)
    ts2 = TestSingletone()
    assert ts2.x == TestSingletone.x
    assert ts2.y == TestSingletone.y

# Generated at 2022-06-11 18:35:50.578139
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    assert a == A()

# Generated at 2022-06-11 18:35:53.391747
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_obj = TestSingleton()

    assert test_obj is TestSingleton()
    assert test_obj is TestSingleton()



# Generated at 2022-06-11 18:36:00.836500
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2

# Generated at 2022-06-11 18:36:04.663967
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = A(3)
    b = A(4)
    assert(id(a) == id(b))
    assert(a.arg == 4)

# Generated at 2022-06-11 18:36:11.664280
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(metaclass=Singleton):
        def __init__(self):
            self.val = None

        def set_value(self, val):
            self.val = val

        def get_value(self):
            return self.val

    obj1 = SingletonTest()
    obj2 = SingletonTest()

    assert obj1 is obj2
    obj1.set_value('foo')
    assert obj1.get_value() == 'foo'
    assert obj2.get_value() == 'foo'

    obj3 = SingletonTest()
    assert obj1 is obj3
    assert obj3.get_value() == 'foo'

# Generated at 2022-06-11 18:36:13.312499
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        pass

    a = MyClass()
    b = MyClass()

    assert a is b

# Generated at 2022-06-11 18:36:18.474063
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    def _check_instance(inst, a):
        assert isinstance(inst, A)
        assert inst.a == a

    a = A(1)
    b = A(2)
    assert a is b
    _check_instance(a, 1)

# Generated at 2022-06-11 18:36:21.277146
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # create an instance of Singleton class
    singleton1 = Singleton()
    # check the instance returned is the same
    singleton2 = Singleton()
    assert (singleton1 == singleton2)



# Generated at 2022-06-11 18:36:26.231606
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, t):
            self.t = t

    t1 = TestSingleton('t1')
    t2 = TestSingleton('t2')

    assert t1 is t2
    assert t1.t == 't1'

# Generated at 2022-06-11 18:36:36.014188
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class ClassA(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class ClassB(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    def get_a_count(cls):
        return len(cls.__subclasses__())

    def get_b_count(cls):
        return len(cls.__subclasses__())

    def get_ab_count(cls):
        return len(cls.__subclasses__())

    orig_count = get_ab_count(ClassA)

    a1 = ClassA()  # noqa
    assert get_ab_count(ClassA) == orig_count + 1
    assert get_a_count(ClassA) == 1
    assert get_b

# Generated at 2022-06-11 18:36:46.201198
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    class B(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    # a and b are two different objects
    a = A(1)
    b = B(2)

    # check instance
    assert a is A(1)
    assert b is not B(2)

    # check difference
    assert a.value is not b.value
    assert a.value == 1
    assert b.value == 2


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:36:53.121939
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        def __init__(self):
            pass

        def set_name(self, name):
            self.name = name

        def get_name(self):
            return self.name

        __metaclass__ = Singleton

    instance1 = TestClass()
    instance1.set_name('instance1')

    instance2 = TestClass()
    instance2.set_name('instance2')

    assert instance1 == instance2
    assert 'instance1' == instance1.get_name()
    assert 'instance1' == instance2.get_name()

# Generated at 2022-06-11 18:37:06.414459
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton1(metaclass=Singleton):
        pass

    t1 = TestSingleton1()
    t2 = TestSingleton1()

    assert t1 is t2
    assert id(t1) == id(t2)

    # Another class with the Singleton metaclass must be a different
    # instance

    class TestSingleton2(metaclass=Singleton):
        pass

    t3 = TestSingleton2()

    assert t1 is not t3
    assert id(t1) != id(t3)



# Generated at 2022-06-11 18:37:08.726490
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingletonClass(metaclass=Singleton):
        def __init__(self):
            pass

    assert MySingletonClass() == MySingletonClass()

# Generated at 2022-06-11 18:37:14.930404
# Unit test for constructor of class Singleton
def test_Singleton():
    """
    >>> class TestSingleton(object):
    ...     __metaclass__ = Singleton
    ...     def __init__(self, foo):
    ...         self.foo = foo
    ...         self.created = False
    ...
    ...     def create(self):
    ...         self.created = True
    >>> t1 = TestSingleton("bar")
    >>> t2 = TestSingleton("bar")
    >>> assert t1 is t2
    >>> t1.foo == t2.foo
    True
    >>> t2.foo
    'bar'
    >>> t1.create()
    >>> t1.created == t2.created
    True
    """

# Generated at 2022-06-11 18:37:19.413287
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    obj1 = SingletonTest('foo')
    assert id(obj1) == id(SingletonTest('bar'))
    assert obj1.arg == 'foo'



# Generated at 2022-06-11 18:37:23.678291
# Unit test for constructor of class Singleton
def test_Singleton():
    # Test Regular Class
    foo1 = Foo()
    foo2 = Foo()
    assert foo1 == foo2
    assert id(foo1) == id(foo2)

    # Test Singleton Class
    bar1 = Bar()
    bar2 = Bar()
    assert bar1 == bar2
    assert id(bar1) == id(bar2)



# Generated at 2022-06-11 18:37:26.915156
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 2

    a1 = A()
    a2 = A()
    print(a1, a2)
    assert(a1 == a2)
    assert(a1.x == 2)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:37:28.390090
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(metaclass=Singleton):
        def __init__(self):
            pass

    assert(C() is C())

# Generated at 2022-06-11 18:37:34.164253
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo:
        __metaclass__ = Singleton

    # Instantiate a single instance of Foo
    foo1 = Foo()
    # Verify that the single instance of Foo is returned for every call
    assert foo1 == Foo()

    # Verify that attempts to create another Foo instance fails
    try:
        foo2 = Foo()
    except AssertionError:
        pass
    else:
        assert False, "Foo should be a singleton class, but has more than one instance"

# Generated at 2022-06-11 18:37:39.704498
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import types
    obj_1 = Singleton('a', (object, ), {})  # noqa
    obj_2 = Singleton('b', (object, ), {})  # noqa
    assert isinstance(obj_1, types.InstanceType)
    assert isinstance(obj_2, types.InstanceType)
    assert obj_1 is obj_2


# Generated at 2022-06-11 18:37:46.968039
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo:
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    # Both instances of Foo should be the same object
    foo1 = Foo(1, 2)
    foo2 = Foo(3, 4)
    assert foo1 == foo2
    assert foo1.a == 1 and foo1.b == 2 and foo2.a == 1 and foo2.b == 2

# Generated at 2022-06-11 18:37:56.715688
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Example(object):
        __metaclass__ = Singleton
        def __init__(self, data):
            self.data = data

    a = Example(1)
    b = Example(2)

    assert a is b
    assert a.data == b.data
    assert a.data == 1



# Generated at 2022-06-11 18:37:57.846044
# Unit test for constructor of class Singleton
def test_Singleton():
    class Obj(object):
        __metaclass__ = Singleton

    assert Obj() is Obj()

# Generated at 2022-06-11 18:38:00.523390
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton1(object):
        __metaclass__ = Singleton

    class TestSingleton2:
        __metaclass__ = Singleton

    s1 = TestSingleton1()
    assert s1 is TestSingleton1()

    s2 = TestSingleton2()
    assert s2 is TestSingleton2()



# Generated at 2022-06-11 18:38:03.805268
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a
    a1 = A(1)
    a2 = A(2)
    assert a1.a == 1
    assert a2.a == 1

# Generated at 2022-06-11 18:38:10.207097
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1
            self.b = 2

    a = MyClass()
    b = MyClass()
    assert a is b
    assert a.a == 1
    assert b.b == 2
    assert a.a == b.a
    assert a.b == b.b
    assert a.a == a.b
    assert b.a == b.b



# Generated at 2022-06-11 18:38:13.598850
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class C(object):
        __metaclass__ = Singleton
        def __init__(self, n):
            self.n = n

    c1 = C(0)
    c2 = C(1)

    assert c1.n == 0
    assert c1 is c2
    return c1, c2

# Generated at 2022-06-11 18:38:15.193687
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

    c = C()
    assert c == C()
    assert id(c) == id(C())


# Generated at 2022-06-11 18:38:18.287791
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create class that uses Singleton
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    obj1 = Test()
    obj2 = Test()
    assert obj1 == obj2



# Generated at 2022-06-11 18:38:20.606050
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton('name', 'bases', 'dct') is None
    assert Singleton('name', 'bases', 'dct') is None

# Generated at 2022-06-11 18:38:29.030641
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create class with __metaclass__=Singleton
    class A(object):
        __metaclass__ = Singleton

    # Check class A is Singleton
    assert Singleton == type(A)
    # Check class A is a Singleton class
    assert issubclass(A, Singleton)

    # Check there is only one instance of class A
    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1 is not None
    assert a2 is not None
    assert id(a1) == id(a2)
    assert type(a1) == type(a2)
    assert isinstance(a1, A)
    assert isinstance(a2, A)
    assert issubclass(type(a1), A)

# Generated at 2022-06-11 18:38:41.707967
# Unit test for constructor of class Singleton
def test_Singleton():
    m1 = Singleton('Metaclass', (), {})
    m2 = Singleton('Metaclass', (), {})

    assert m1 is m2



# Generated at 2022-06-11 18:38:45.913193
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    assert(foo1 == foo2)


# Unit tests for class Singleton
if __name__ == "__main__":
    from test import unit

    unit.run_tests(globals())

# Generated at 2022-06-11 18:38:48.483081
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert id(test1) == id(test2)

# Generated at 2022-06-11 18:38:57.785869
# Unit test for constructor of class Singleton
def test_Singleton():
    print("\n========== Test for Singleton class ==========")
    print("\n========== Test for Singleton class ==========")

    class myclass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'test'
            self.count = 0

        def show(self):
            print("My name is " + self.name)

    a = myclass()
    b = myclass()
    print('name of a : %s, count of a : %d' % (a.name, a.count))
    print('name of b : %s, count of b : %d' % (b.name, b.count))
    print('a is b', a is b)

# Generated at 2022-06-11 18:39:01.031722
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = Test()
    b = Test()
    c = Test()

    assert a == b == c

# Generated at 2022-06-11 18:39:04.994103
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    a_1 = A()
    a_2 = A()

    # Check that a_1 is a_2
    assert a_1 is a_2


# Generated at 2022-06-11 18:39:07.234812
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    testclass_obj1 = TestClass()
    testclass_obj2 = TestClass()

    assert testclass_obj1 is testclass_obj2

# Generated at 2022-06-11 18:39:11.434095
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    s1 = TestSingleton(1)
    s2 = TestSingleton(2)
    assert s1 is s2
    assert s1.val == 1
    assert s2.val == 1

# Generated at 2022-06-11 18:39:14.550766
# Unit test for constructor of class Singleton
def test_Singleton():
    class One(metaclass=Singleton):
        pass

    a = One()
    b = One()
    assert id(a) == id(b)

    l = [One(), One(), One()]
    for i in l:
        assert id(a) == id(i)



# Generated at 2022-06-11 18:39:24.800677
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create class
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, x, y):
            self.x = x
            self.y = y

    # Create two instances
    test_singleton_obj_1 = TestSingleton(1, 2)
    test_singleton_obj_2 = TestSingleton(3, 4)

    # Check the two instances are equal
    assert test_singleton_obj_1 == test_singleton_obj_2
    assert test_singleton_obj_1.x == test_singleton_obj_2.x
    assert test_singleton_obj_1.y == test_singleton_obj_2.y
    assert test_singleton_obj_1.x == 1
    assert test_singleton_obj_2.x

# Generated at 2022-06-11 18:39:36.649075
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2
        def test_method(self):
            return self.arg1, self.arg2

    obj1 = TestClass('a', 'b')
    obj2 = TestClass('c', 'd')
    assert obj1 is obj2
    assert obj1.test_method() == obj2.test_method() == ('a', 'b')



# Generated at 2022-06-11 18:39:43.486626
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.__x = 0

        def inc(self):
            self.__x += 1
            return self.__x
    import random

    xs = [random.random() for _ in range(1000)]

    x = C()
    y = C()
    assert x is y
    z = C()
    assert z is x

    for x in xs:
        assert x == y.inc()

# Generated at 2022-06-11 18:39:47.891096
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # create a sample class
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.data = 0
    # instantiation
    o1 = Foo()
    o2 = Foo()
    # method for test
    def test():
        if o1 is not o2:
            raise Exception("the class Foo is not singleton")
    # test
    test()

# Generated at 2022-06-11 18:39:54.081572
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.module_utils.six import with_metaclass

    class TestClass(with_metaclass(Singleton, object)):
        pass

    class TestClass2(with_metaclass(Singleton, object)):
        pass

    # Test that TestClass is Singleton
    a = TestClass()
    b = TestClass()

    assert(a is b)

    # Test that TestClass and TestClass2 are not the same Singleton
    c = TestClass2()
    assert(a is not c)
    assert(b is not c)

# Generated at 2022-06-11 18:39:58.055874
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1
    a = A()
    b = A()
    assert a is b




# Generated at 2022-06-11 18:40:02.431274
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self._x = 1

        def get_x(self):
            return self._x
    instance1 = TestClass()
    instance2 = TestClass()
    assert(instance1._x == instance2._x == 1)

# Generated at 2022-06-11 18:40:05.958971
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        pass

    Test_1 = Test()
    Test_2 = Test()
    assert Test_1 is not Test_2

    class Test(object):
        __metaclass__ = Singleton

    Test_1 = Test()
    Test_2 = Test()
    assert Test_1 is Test_2

# Generated at 2022-06-11 18:40:09.610251
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    test_obj_1 = TestClass()
    test_obj_2 = TestClass()

    assert test_obj_1 == test_obj_2

# Generated at 2022-06-11 18:40:15.085588
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0
            print('init Foo instance: {}'.format(self))

    foo1 = Foo()
    foo2 = Foo()

    if foo1 is foo2:
        print('foo1 is foo2')
    else:
        print('foo1 is not foo2')

    foo1.value = 1
    print(foo1.value)
    print(foo2.value)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:40:20.001611
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    obj1 = TestSingleton()
    obj2 = TestSingleton()
    assert obj1 == obj2


# Generated at 2022-06-11 18:40:30.380566
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, val=0):
            self.val = val

    assert(A().val == 0)

    a1 = A(1)
    a2 = A()
    assert(a1.val == a2.val)
    assert(a1 is a2)



# Generated at 2022-06-11 18:40:32.811987
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object,metaclass=Singleton):
        pass
    a = A()
    assert id(a) == id(A())



# Generated at 2022-06-11 18:40:35.900243
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    t1 = TestClass()
    t2 = TestClass()
    assert id(t1) == id(t2)



# Generated at 2022-06-11 18:40:39.621527
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    test1 = Test()
    test2 = Test()
    assert test1 is test2


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:40:42.770294
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = TestClass()
    b = TestClass()

    assert a is b
    assert id(a) == id(b)

# Generated at 2022-06-11 18:40:52.759203
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import lib.ansible_module
    class TestCall(lib.ansible_module.AnsibleModule):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.call_args = args
            self.call_kwargs = kwargs
            super(TestCall, self).__init__(*args, **kwargs, check_invalid_arguments=False)

    args = ('fake args', 'for', 'testing')
    kwargs = {'foo': 'bar', 'baz': 'biz'}
    instance1 = TestCall(*args, **kwargs)
    instance2 = TestCall(*args, **kwargs)
    assert instance1 is instance2
    assert instance1.call_args == tuple(args)
    assert instance1.call_kwargs == k

# Generated at 2022-06-11 18:41:03.688077
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Singleton_Class(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    import sys
    if sys.version_info[0] < 3:
        def assertIsInstance(first, second):
            assert isinstance(first, second)

    class SingletonTest:
        def test_creation(self):
            a = Singleton_Class()
            b = Singleton_Class()
            assert a is b

        def test_instance_type(self):
            assertIsInstance(Singleton_Class(), Singleton_Class)

        def test_init_params(self):
            class Singleton_Class_With_Init(object):
                __metaclass__ = Singleton

                def __init__(self, *args, **kwargs):
                    self.args = args

# Generated at 2022-06-11 18:41:06.402021
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        print("A1")
        __metaclass__ = Singleton

        print("A2")
        def __init__(self):
            print("A3")
            self.a = 1

    a = A()
    b = A()
    assert(a is b)



# Generated at 2022-06-11 18:41:13.412475
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingleClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 5

        def add(self, val):
            self.value += val
            return self.value

    a = SingleClass()
    b = SingleClass()
    assert(a == b)
    assert(a.add(10) == b.add(10))
    assert(a.add(10) == b.add(10))


# Generated at 2022-06-11 18:41:15.397008
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(Singleton):
        pass

    s1 = S()
    s2 = S()
    assert s1 is s2

# Generated at 2022-06-11 18:41:22.699866
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test Singleton's __call__ method:
    # 1. Ensure that a class SingletonTemplate is created from
    #    metaclass Singleton
    # 2. Ensure that for class SingletonTemplate, only one instance
    #    is created.
    class SingletonTemplate(object):
        __metaclass__ = Singleton

    s1 = SingletonTemplate()
    s2 = SingletonTemplate()

    assert s1 == s2
    assert s1 is s2

# Generated at 2022-06-11 18:41:29.464866
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            super(Foo, self).__init__()
            self.bar = None
            self.baz = None

    # Instantiate with defaults
    foo = Foo()

    # Assert that the instance is unique
    assert foo is Foo()

    # Set values on the singleton
    foo.bar = 'bar'
    foo.baz = 'baz'

    # Get another reference to the singleton
    foo_2 = Foo()

    # Make sure we have a reference to the same object
    assert foo is foo_2

    # Values should have been set on the object
    assert foo.bar == 'bar'
    assert foo.baz == 'baz'