

# Generated at 2022-06-11 18:31:40.459743
# Unit test for constructor of class Singleton
def test_Singleton():
    import inspect
    # Make sure constructor is private from outside
    assert '__init__' in inspect.signature(Singleton).parameters
    # Check meta class for create Singleton class
    assert isinstance(Singleton, type)
    # Check one instance by Singleton
    class TestSingleton:
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    x = TestSingleton(1)
    y = TestSingleton(2)
    assert x is y
    assert x.val == y.val
    assert x.val == 1

# Generated at 2022-06-11 18:31:44.268286
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = MySingleton()
    b = MySingleton()
    assert a is b


# Monkey patch the decorator so the test runner doesn't crash

# Generated at 2022-06-11 18:31:47.843078
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class TestSingleton(with_metaclass(Singleton)):
        pass

    # Instantiate the TestSingleton class
    assert TestSingleton.__insta

# Generated at 2022-06-11 18:31:54.710800
# Unit test for constructor of class Singleton
def test_Singleton():
    import datetime
    class C(metaclass=Singleton):
        def __init__(self):
            self.time = datetime.datetime.now()

    c1 = C()
    c2 = C()

    if c1 is not c2:
        raise AssertionError('c1 is not c2.  c1: %s, c2: %s' % (c1, c2))

    if c1.time != c2.time:
        raise AssertionError('c1.time is not c2.time.  c1.time: %s, c2.time: %s' % (c1.time, c2.time))


test_Singleton()

# Generated at 2022-06-11 18:32:02.634992
# Unit test for constructor of class Singleton
def test_Singleton():
    # pylint: disable=no-member

    # define class as Singleton
    class SingletonTest(object):
        __metaclass__ = Singleton

        # test that constructor is evaluated exactly once when an
        # instance of the class is created
        counter = 0

        def __init__(self):
            # pylint: disable=attribute-defined-outside-init
            self.counter += 1

    # test that constructor is evaluated exactly once when an instance
    # of the class is created
    assert SingletonTest().counter == 1

    # test that Singleton instance is cached and constructor is not
    # reevaluated
    assert SingletonTest().counter == 1
    assert SingletonTest().counter == 1
    assert SingletonTest().counter == 1


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:32:07.765934
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = Foo('a')
    b = Foo('b')
    assert a == b
    assert a.arg == 'a'



# Generated at 2022-06-11 18:32:13.341111
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1(object):
        __metaclass__ = Singleton

    class Test2(Test1):
        pass

    t1_1 = Test1()
    t1_2 = Test1()
    t2_1 = Test2()
    t2_2 = Test2()

    assert t1_1 is t1_2
    assert t1_1 is not t2_1
    assert t2_1 is t2_2



# Generated at 2022-06-11 18:32:17.900681
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 'bar'
            print ("Constructor of MyClass class")

    assert MyClass() == MyClass()

    my_class = MyClass()
    assert my_class.foo == 'bar'

# Generated at 2022-06-11 18:32:25.285212
# Unit test for constructor of class Singleton
def test_Singleton():
  class Test(object,metaclass=Singleton):
    def __init__(self, name):
      self.name = name

  t = Test("x")
  t1 = Test("y")
  assert (t1.name == t.name == "x"), "Singleton instance failed"
  try:
    t2 = Test("z")
    assert False, "Singleton instance failed"
  except RuntimeError:
    pass


# Generated at 2022-06-11 18:32:32.436268
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        """
        __init__() is never called by Singleton
        """
        def __init__(self, *args, **kwargs):
            raise RuntimeError('Call to __init__() in Singleton.')

    # Instantiate a once
    a = A()
    # Instantiate it twice, it should raise RuntimeError
    try:
        b = A()
        assert(False)
    except RuntimeError as e:
        assert(True)


# Generated at 2022-06-11 18:32:41.144059
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self._val = val

        def val(self):
            return self._val

    a1 = A(3)
    a2 = A(4)

    assert a1 is a2
    assert 4 == a1.val()


# Generated at 2022-06-11 18:32:49.296764
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 'val'

    class TestSubClass(TestClass):

        def __init__(self):
            self.val = 'sub_class'

    test_class = TestClass()
    test_class2 = TestClass()

    assert test_class2.val == 'val'

    test_sub_class = TestSubClass()
    test_sub_class2 = TestSubClass()

    assert not test_sub_class.val == test_sub_class2.val

# Generated at 2022-06-11 18:32:54.529805
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Klass(object):
        __metaclass__ = Singleton

    assert Klass.__instance is None
    one = Klass()
    assert Klass.__instance == one
    assert one is one
    two = Klass()
    assert Klass.__instance == two
    assert two is two

# Generated at 2022-06-11 18:33:02.949628
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class NoArg(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 42

    class Arg(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    class Kw(object):
        __metaclass__ = Singleton
        def __init__(self, a=None):
            self.a = a

    class ArgKw(object):
        __metaclass__ = Singleton
        def __init__(self, a, b=None):
            self.a = a
            self.b = b

    # Test without arguments
    o1 = NoArg()
    o2 = NoArg()
    assert o1 is o2
    assert o1.a == o2.a

    # Test

# Generated at 2022-06-11 18:33:12.026265
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.hacking.utils import assert_equal, assert_raises
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.var = 0

        def set_var(self, var):
            self.var = var

        def get_var(self):
            return self.var

    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.var = 1

        def set_var(self, var):
            self.var = var

        def get_var(self):
            return self.var

    assert_raises(TypeError, Singleton, 'MetaclassError', (object,), {})
    a = A()
    b = B()

# Generated at 2022-06-11 18:33:12.997955
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

# Generated at 2022-06-11 18:33:24.823361
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import sys
    from .test_utils import ANSIBALLZ_PROFILE_DIR
    from ansiballz.ansiballz_main import AnsiballZMain

    sys.argv = [
        'ansiballz',
        '-p', '%s/not-in-playbook' % ANSIBALLZ_PROFILE_DIR,
        '-e', '{}',
        '-k', '/dev/null',
    ]
    old_env = dict(os.environ)
    old_env['ANSIBLE_CONFIG'], old_env['ANSIBLE_LIBRARY'], old_env['ANSIBLE_PROJECT_LIBRARY'] = (
        None, None, None)
    os.environ = {}

# Generated at 2022-06-11 18:33:31.475049
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    def simple_Singleton__init__(self):
        self.attr = 0

    class simple_Singleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.attr = 0

    s = simple_Singleton()
    s.attr = 1
    t = simple_Singleton()
    t.attr += 1
    assert s.attr == 2
    assert id(s) == id(t)

# Generated at 2022-06-11 18:33:38.353168
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    Unit test for method __call__ of class Singleton
    """
    class MyClass(object):
        __metaclass__ = Singleton

    class MyClass2(object):
        __metaclass__ = Singleton

    myclass1 = MyClass()
    myclass2 = MyClass()
    myclass21 = MyClass2()
    myclass22 = MyClass2()

    assert myclass1 == myclass2
    assert myclass21 == myclass22
    assert myclass1 != myclass21

# Generated at 2022-06-11 18:33:50.062854
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Note: In order to feed the test with clean data, we need to clear
    # the class cache of the class Singleton.
    Singleton.__instance = None

    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    class MySubclass(MyClass):
        def __init__(self, foo):
            self.foo = foo

    my_inst1 = MyClass(1)
    my_inst2 = MyClass(2)
    assert my_inst1 is my_inst2

    my_subclass_inst1 = MySubclass(1)
    my_subclass_inst2 = MySubclass(2)
    assert my_subclass_inst1 is not my_subclass_inst2
    assert my_subclass_inst

# Generated at 2022-06-11 18:34:01.091152
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.cli.shell import ShellCLI
    from ansible.cli.galaxy import GalaxyCLI
    from ansible.cli.adhoc import AdHocCLI

    # __call__() should return the same instance
    assert ShellCLI() is ShellCLI()
    assert GalaxyCLI() is GalaxyCLI()
    assert AdHocCLI() is AdHocCLI()

    # different instances of different classes
    assert ShellCLI() is not GalaxyCLI()
    assert ShellCLI() is not AdHocCLI()
    assert GalaxyCLI() is not AdHocCLI()


# Generated at 2022-06-11 18:34:04.345331
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, test):
            self._test = test

        def get_test(self):
            return self._test

    foo1 = Foo('1')
    foo2 = Foo('2')
    assert foo1 is foo2
    assert foo1.get_test() == '2'

# Generated at 2022-06-11 18:34:10.469506
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    To test class Singleton by creating two instances of class Foo,
    Foo should be defined by metaclass Singleton.
    """
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

    assert Foo() == Foo()
    assert Bar() == Bar()
    assert Foo() != Bar()




# Generated at 2022-06-11 18:34:16.138685
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            # set a value of an instance variable
            self.name = "class A"

    a1 = A()
    a2 = A()

    assert(a1 is a2)
    assert(a1.name == "class A")

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:34:19.028627
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert TestClass() is TestClass()
    assert TestClass() is TestClass()

# Generated at 2022-06-11 18:34:23.322189
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    def class_with_Singleton(metaclass=Singleton):
        class SingletonTest:
            pass

        return SingletonTest
    assert class_with_Singleton() is class_with_Singleton()


# Utility function to create a class with Singleton metaclass

# Generated at 2022-06-11 18:34:25.945199
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    t = Test(1)
    assert Test(2) is t
    assert t.val == 1

# Generated at 2022-06-11 18:34:32.482619
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, test):
            self.test = test

    test1 = Test(1)
    test2 = Test(2)
    assert test1.test == test2.test
    s = str(test1)
    assert '1' in s

# Generated at 2022-06-11 18:34:40.514624
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        pass

    instance = Test()
    print(instance)

    Test2 = Singleton('Test2', (object,), {})
    Test2()
    Test2()
    Test3 = Singleton('Test3', (object,), {})
    Test3.__instance = Test()
    Test3.__rlock = RLock()
    Test3()
    print(Test3.__rlock)


if __name__ == '__main__':
    import time
    import threading

    class Test(object):
        __metaclass__ = Singleton
        pass

    def function(arg):
        inst = arg()
        print(threading.current_thread().name, inst)

    TEST = Test

    for i in range(10):
        t

# Generated at 2022-06-11 18:34:45.350696
# Unit test for constructor of class Singleton
def test_Singleton():
    class test_me(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    print(test_me() is test_me())
    assert test_me().a == test_me().a is 1

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:34:55.371112
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = A()
    assert A() is a



# Generated at 2022-06-11 18:35:00.283904
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a_instance_1 = A(1)
    assert a_instance_1.a == 1

    a_instance_2 = A(2)
    assert a_instance_2.a == 1

# Generated at 2022-06-11 18:35:10.987368
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.log = []

        def __str__(self):
            self.log.append('str')
            return 'str'

        def __repr__(self):
            self.log.append('repr')
            return 'repr'

        def __nonzero__(self):
            self.log.append('nonzero')
            return True

    # test that instantiating an instance calls a single __init__
    obj = TestSingleton()
    assert obj.log == ['nonzero', 'repr', 'str']

    # test that a second instance returns the same object
    obj.log = []
    obj2 = TestSingleton()
    assert obj2 is obj
    assert obj.log == []

#

# Generated at 2022-06-11 18:35:16.643427
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    # Test singleton constructor
    a = A()
    b = A()
    assert(a == b)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:35:21.197549
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    class MySingletonSub(MySingleton):
        pass

    assert MySingleton() is MySingleton()
    assert MySingletonSub() is MySingletonSub()
    assert not MySingleton() is MySingletonSub()

test_Singleton()

# Generated at 2022-06-11 18:35:23.898079
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    x1 = X(1)
    assert x1.value == 1
    assert X(2).value == 1

# Generated at 2022-06-11 18:35:25.520337
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()



# Generated at 2022-06-11 18:35:34.005724
# Unit test for constructor of class Singleton
def test_Singleton():
	class MySingleton(object):
		__metaclass__ = Singleton
		myVar = 0
		def setVar(self, value):
			self.myVar = value
		def getVar(self):
			return self.myVar

	a = MySingleton()
	b = MySingleton()
	assert a is b
	a.setVar(5)
	assert 5 == b.getVar()
	assert 'MySingleton' == a.__class__.__name__

# Generated at 2022-06-11 18:35:39.685738
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self._value = value

        def value(self):
            return self._value

    a = MyClass(1)
    b = MyClass(2)
    assert(a is b)
    assert(a.value() == 1)
    assert(b.value() == 1)

# Generated at 2022-06-11 18:35:41.487997
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, n):
            self.n = n

    test1 = Test(1)
    assert test1.n == 1
    test2 = Test(2)
    assert test2.n == 1, "Singleton functionality failed"

# Generated at 2022-06-11 18:36:02.922911
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class Test2(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    obj1 = Test()
    obj2 = Test()
    obj3 = Test2()
    obj4 = Test2()

    assert(obj1 == obj2)
    assert(obj3 == obj4)
    assert(obj1 != obj3)



# Generated at 2022-06-11 18:36:11.064097
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTestClass(metaclass=Singleton):
        def __init__(self, arg1):
            self.arg1 = arg1

    class SingletonTestClass1(metaclass=Singleton):
        def __init__(self, arg1):
            self.arg1 = arg1

    test1 = SingletonTestClass(1)
    assert test1.arg1 == 1

    test2 = SingletonTestClass(2)
    assert test2.arg1 == 1

    test3 = SingletonTestClass1(3)
    assert test3.arg1 == 3

    test4 = SingletonTestClass1(4)
    assert test4.arg1 == 3


# Generated at 2022-06-11 18:36:13.098597
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

    obj1 = S()
    obj2 = S()

    assert(obj1 is obj2)


# Generated at 2022-06-11 18:36:17.002228
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, *args):
            self.args = args

    f1 = Foo(1)
    f2 = Foo()

    assert f1 == f2
    assert f1.args == (1,)
    assert f2.args == (1,)

# Generated at 2022-06-11 18:36:22.629872
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.b = 1

    a1 = A()
    a2 = A()
    a3 = A()
    assert(a1 == a2 and a2 == a3)

    a1.b = 2
    a3.b = 3
    assert(a1.b == a2.b)
    assert(a2.b == a3.b)

# Generated at 2022-06-11 18:36:29.363992
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 'test'

    a1 = A()
    a2 = A()
    if a1.val != 'test' or a2.val != 'test':
        raise RuntimeError('Incorrect value: %s' % a1.val)
    a1.val = 'test2'
    if a1.val != 'test2' or a2.val != 'test2':
        raise RuntimeError('Incorrect value: %s' % a1.val)

# Generated at 2022-06-11 18:36:37.484700
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from nose.tools.trivial import ok_, eq_

    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, a1, a2):
            try:
                self.a1, self.a2 = int(a1), int(a2)
            except ValueError:
                raise ValueError('arguments a1 and a2 should be integers')

    foo = Foo(1, 2)

    ok_(isinstance(foo, Foo))
    eq_(foo.a1, 1)
    eq_(foo.a2, 2)

    foo2 = Foo(3, 4)
    ok_(foo is foo2)
    ok_(id(foo) == id(foo2))
    eq_(foo2.a1, 1)
    eq_(foo2.a2, 2)



# Generated at 2022-06-11 18:36:42.955620
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    instance1 = Test()
    instance1.test = True

    instance2 = Test()
    assert isinstance(instance2, Test)
    assert instance2.test is True

    instance3 = Test()
    assert isinstance(instance3, Test)
    assert instance3.test is True
    assert instance3 is instance2



# Generated at 2022-06-11 18:36:49.608024
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    # Create two instances of Foo
    foo = Foo()
    foo2 = Foo()

    # Check if both instances are the same
    if foo is foo2:
        print("Ansible has engaged the Singleton metaclass properly, as both objects are the same")
    else:
        print("Ansible has not engaged the Singleton metaclass properly, as both objects are not the same")

# Generated at 2022-06-11 18:36:51.085084
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert a == b

# Alternative implementation

# Generated at 2022-06-11 18:37:28.710457
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # create new class with Singleton as metaclass
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, obj1):
            self.obj1 = obj1

        def __str__(self):
            return "MyClass[obj1={0}]".format(self.obj1)

    print("type(MyClass): {0}".format(type(MyClass)))

    instance1 = MyClass(obj1="k")
    print("type(instance1): {0}".format(type(instance1)))

    instance2 = MyClass(obj1="o")
    print("type(instance2): {0}".format(type(instance2)))

    print("instance1: {0}".format(instance1))
    print("instance2: {0}".format(instance2))

# Generated at 2022-06-11 18:37:33.446513
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            pass

    myClass1 = MyClass()
    assert myClass1 is not None

    myClass2 = MyClass()
    assert myClass2 is not None

    assert myClass1 is myClass2


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:37:36.542335
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest:
        __metaclass__ = Singleton

    s1 = SingletonTest()
    s2 = SingletonTest()

    assert s1 is s2


# Generated at 2022-06-11 18:37:38.922896
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()

# Generated at 2022-06-11 18:37:42.277578
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
    a = TestClass()
    b = TestClass()
    assert(a is b)


# Generated at 2022-06-11 18:37:45.143932
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = 'bar'

    assert Foo().foo == Foo().foo

# Generated at 2022-06-11 18:37:51.100391
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.state = 0

        def test(self):
            self.state += 1

    obj1 = TestClass()
    obj1.test()
    obj2 = TestClass()
    obj2.test()

    assert obj1 == obj2
    assert obj1.state == 2
    assert obj2.state == 2

# Generated at 2022-06-11 18:37:54.161426
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a == b



# Generated at 2022-06-11 18:37:59.448003
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    s1 = MySingleton()
    s2 = MySingleton()
    assert s1 is s2, \
        "Expected s1 is s2, but got {0} and {1}".format(
            s1, s2
        )



# Generated at 2022-06-11 18:38:03.217077
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = None

    assert MyClass() is MyClass()
    assert MyClass().value is None
    MyClass().value = 1
    assert MyClass().value == 1


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 18:39:10.630458
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 0

        def increment(self):
            self.i += 1

    a = A()
    assert a is A()
    assert a is A()
    assert a.i == 0
    a.increment()
    assert a.i == 1
    assert a is A()
    assert a is A()
    b = A()
    assert a.i == 1


# Generated at 2022-06-11 18:39:12.261709
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    assert a == TestClass()


# Generated at 2022-06-11 18:39:15.834416
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    i0 = MySingleton()
    i1 = MySingleton()

    assert i0 == i1



if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:39:18.994331
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_one = TestSingleton()
    assert test_one
    test_two = TestSingleton()
    assert test_one == test_two

# Generated at 2022-06-11 18:39:26.494760
# Unit test for constructor of class Singleton
def test_Singleton():
    class foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.bar = 10

    class foo2(object):
        __metaclass__ = Singleton
        def __init__(self, n):
            self.bar = n

    a = foo()
    b = foo()
    assert a.bar == b.bar
    assert a == b

    b.bar = 20
    assert a.bar != b.bar
    assert a != b

    c = foo2(30)
    d = foo2(40)
    assert c.bar == 30
    assert d.bar == 40
    assert c != d

    e = foo2(40)
    assert e == d
    assert e.bar == d.bar

if __name__ == "__main__":
    test

# Generated at 2022-06-11 18:39:31.588968
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    class Test2(object):
        __metaclass__ = Singleton

    assert Test is Test() and Test2 is Test2() and Test is not Test2()

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:39:33.922934
# Unit test for constructor of class Singleton
def test_Singleton():
    class NewClass(object, metaclass=Singleton):
        pass
    instance1 = NewClass()
    instance2 = NewClass()
    assert(instance1 is instance2)

# Generated at 2022-06-11 18:39:40.019202
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class DummySingleton(object):
        __metaclass__ = Singleton

    dummy_singleton_1 = DummySingleton()
    assert(dummy_singleton_1 is DummySingleton())
    dummy_singleton_2 = DummySingleton()
    assert(dummy_singleton_1 is dummy_singleton_2)

# Generated at 2022-06-11 18:39:47.588460
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # MockUp for threading.RLock object
    class MockUp(object):
        def __init__(self):
            self.acquire_was_called = False
            self.release_was_called = False

        def acquire(self):
            self.acquire_was_called = True

        def release(self):
            self.release_was_called = True

    class SingletonTest(object):
        __metaclass__ = Singleton

    assert SingletonTest.__rlock is None # pre-condition

    # first call of __call__ without lock
    SingletonTest.__rlock = MockUp()
    test = SingletonTest()
    assert SingletonTest.__instance  == test
    assert SingletonTest.__rlock.acquire_was_called == False
    assert SingletonTest.__rlock.release_

# Generated at 2022-06-11 18:39:51.350688
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = A()
    b = A()
    assert a == b, "Singleton class A failed"