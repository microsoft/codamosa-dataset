

# Generated at 2022-06-11 18:31:37.497749
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass

    class B(metaclass=Singleton):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', '-v'])

# Generated at 2022-06-11 18:31:43.442500
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    s1 = TestSingleton()
    s2 = TestSingleton()

    assert id(s1) == id(s2), \
        "Failed to create singleton instance"

    assert s1.a == 1, \
        "Failed to call __init__ of the singleton"

    assert s2.a == 1, \
        "Failed to call __init__ of the singleton"

# Generated at 2022-06-11 18:31:48.227821
# Unit test for constructor of class Singleton
def test_Singleton():
    class TheClass(metaclass=Singleton):
        def __init__(self):
            self.x = 1

    i = TheClass()
    assert id(i) == id(TheClass())


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:31:53.533432
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    class B(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 == a2

    b1 = B()
    b2 = B()
    assert b1 == b2

    a3 = A()
    assert a1 == a3

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:32:00.912816
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object, metaclass=Singleton):
        a = 1

        def __init__(self):
            self.a = 2

    assert A.a == 1
    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 2
    assert a2.a == 2
    a1.a = 3
    assert a1 is a2
    assert a1.a == 3
    assert a2.a == 3



# Generated at 2022-06-11 18:32:09.000669
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    s = TestSingleton('foo', bar='baz')
    assert s.args == ('foo',)
    assert s.kwargs == {'bar': 'baz'}

    s1 = TestSingleton('foo1', bar1='baz1')
    assert s1.args == ('foo',)
    assert s1.kwargs == {'bar': 'baz'}
    assert s1 is s

# Generated at 2022-06-11 18:32:11.337233
# Unit test for constructor of class Singleton
def test_Singleton():
    myclass = Singleton('MyClass', (object,), {})

    assert myclass('a', 'b') == myclass('a', 'b')

# Generated at 2022-06-11 18:32:15.302312
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from copy import copy

    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    t1 = Test()
    t2 = Test()

    assert t1 == t2

    t1.a = 1
    assert t2.a == 1

    # This won't raise an exception
    copy(t1)

# Generated at 2022-06-11 18:32:20.098359
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x=0):
            self.x = x
    a = A(1)
    assert a.x == 1
    b = A(2)
    assert a is b


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:32:31.911916
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    def any_callable():
        pass

    class AnyClass(object, metaclass=Singleton):
        def __init__(self, x, y, z):
            pass

        def get_class_name(self):
            return self.__class__.__name__

        def get_dict(self):
            return self.__dict__

    a = AnyClass(1, 2, 3)
    b = AnyClass(4, 5, 6)
    assert id(a) == id(b)
    assert a.get_class_name() == b.get_class_name() == "AnyClass"
    assert a.get_dict() == b.get_dict() == {'x': 1, 'y': 2, 'z': 3}
    try:
        any_callable()
    except TypeError:
        pass

# Generated at 2022-06-11 18:32:37.822479
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    foo1 = Foo(1)
    foo2 = Foo(2)
    assert foo1 is foo2

# Generated at 2022-06-11 18:32:41.705621
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            pass

    assert TestSingleton() == TestSingleton()
    assert TestSingleton() is not None

# Generated at 2022-06-11 18:32:45.035491
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    a = MyClass()
    b = MyClass()
    assert a is b

# Generated at 2022-06-11 18:32:49.405323
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("Test __init__")

    t1 = Test()
    assert(type(t1) == Test)
    t2 = Test()
    assert(type(t2) == Test)
    assert(id(t1) == id(t2))

# Generated at 2022-06-11 18:32:56.979706
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, num):
            self.num = num
      
    # Create instance #1
    instance_1 = MySingleton(1342)
    # Check the correct instance is returned
    instance_2 = MySingleton(7331)
    assert instance_2 == instance_1
    # Check that instances have the same state
    assert instance_1.num == instance_2.num
    print("Singleton class tester passed")

# Generated at 2022-06-11 18:33:02.288317
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class FooSingleton(metaclass=Singleton):
        def __init__(self):
            self.spam = 'eggs'

    foo1 = FooSingleton()
    assert foo1.spam == 'eggs'
    foo2 = FooSingleton()
    assert foo1 is foo2


# Generated at 2022-06-11 18:33:12.675794
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    _class = '_class'
    _func = '_func'
    _instance = '_instance'
    _kw = '_kw'
    _args = '_args'

    class SuperCallMock(object):
        def __init__(self):
            self.calls = 0

        def __call__(self, _class, _func, _instance, _kw, _args):
            self.calls += 1
            return "super(%s, %s).__call__(%s, %s)" % (_class, _func, _instance, _kw, _args)

    scm = SuperCallMock()
    SuperCallMock.__call__ = scm.__call__

    class SingletonTest(Singleton):
        pass

    st = SingletonTest()

    assert st.__instance is None


# Generated at 2022-06-11 18:33:17.956385
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingleA(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1
            self.y = 2

    a = SingleA()
    b = SingleA()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    assert a.y == 2
    assert b.y == 2

# Generated at 2022-06-11 18:33:22.433782
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        pass

    t1 = TestClass()
    t2 = TestClass()
    assert t1 is t2



# Generated at 2022-06-11 18:33:25.365850
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.singleton_init = 1

    test_cls = TestClass()
    assert test_cls.singleton_init == 1

# Generated at 2022-06-11 18:33:35.401011
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, *args):
            self.args = args

    a = TestClass(1, 2, 3)
    b = TestClass(4, 5, 6)
    assert a is b
    assert a.args == (1, 2, 3)
    assert b.args == (1, 2, 3)

# Generated at 2022-06-11 18:33:38.084470
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            pass

    s = A()
    assert id(s) == id(A())
    t = A()
    assert id(t) == id(s)



# Generated at 2022-06-11 18:33:49.820675
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        """docstring for TestClass"""

        __metaclass__ = Singleton

        def __init__(self):
            super(TestClass, self).__init__()

        def foo(self):
            return "bar"

    from nose.tools import assert_is_instance
    from nose.tools import assert_equal

    # test instantiation of class TestClass
    obj1 = TestClass()
    assert_is_instance(obj1, TestClass)
    assert_equal(TestClass.__instance, obj1)
    assert_is_instance(TestClass.__rlock, RLock)

    # test instantiation of class TestClass again
    obj2 = TestClass()
    assert_is_instance(obj2, TestClass)
    assert_equal(TestClass.__instance, obj2)


# Generated at 2022-06-11 18:33:55.985607
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.something = 1

    assert TestSingleton().something == 1
    assert TestSingleton().something == 1

    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.something = 2

    assert TestSingleton().something == 2
    assert TestSingleton().something == 2

# Generated at 2022-06-11 18:34:02.782926
# Unit test for constructor of class Singleton
def test_Singleton():
    # Creation of object of meta class Singleton
    # only one object will be created
    obj1 = Singleton('TestSingleton', (), {})()
    obj2 = Singleton('TestSingleton', (), {})()

    # Testing if both references point to the same object
    assert(obj1 is obj2)

    # Testing if the object has only one reference
    assert(obj1 is not None and obj1 is obj1)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:34:06.861761
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("A")

    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-11 18:34:08.758287
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()

    assert a == A()

# Generated at 2022-06-11 18:34:12.143079
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create a singleton class
    class A(object):
        __metaclass__ = Singleton

    # Get two references on A
    a = A()
    b = A()
    # check that a and b are the same instance
    assert a is b

# Generated at 2022-06-11 18:34:16.902863
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    class B(A):
        def __init__(self):
            self.a = False
            self.b = True
    class C(A):
        def __init__(self):
            self.c = True
    a = A()
    b = B()
    c = C()
    assert a == b
    assert b != c

# Generated at 2022-06-11 18:34:21.709169
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x
    
    a = MyClass(3)
    b = MyClass(5)
    assert a is b
    assert a.x == 3

# Generated at 2022-06-11 18:34:29.576990
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("A() called.")
            self.str = 'A'

    class B(A):

        def __init__(self):
            print("B() called.")
            self.str = 'B'

    class C(A):

        def __init__(self):
            print("C() called.")
            self.str = 'C'

    assert(A() is A())
    assert(isinstance(A(), A))

    assert(A() is A())
    assert(isinstance(B(), A))
    assert(B() is B())
    assert(B() is A())

    assert(C() is not B())
    assert(C() is C())
    assert(isinstance(C(), A))


# Generated at 2022-06-11 18:34:37.038070
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class ATestClass(object):
        __metaclass__ = Singleton

        def __init__(self, a_param):
            self.a_param = a_param

    first_instance = ATestClass(1)
    second_instance = ATestClass(2)

    assert first_instance.a_param == 1
    assert second_instance.a_param == 1
    assert first_instance is second_instance


# Example of usage of Singleton

# Generated at 2022-06-11 18:34:41.551050
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    obj1 = SingletonTest()
    obj2 = SingletonTest()
    assert id(obj1) == id(obj2)

# Generated at 2022-06-11 18:34:45.958656
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, id=None):
            self.id = id

    i = Test(10)
    j = Test(11)
    assert(i is j)
    assert(i.id == 10)



# Generated at 2022-06-11 18:34:48.134838
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    instance = Test()
    assert(instance == Test())
    assert(instance is Test())

# Generated at 2022-06-11 18:34:55.055708
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a class that uses Singleton as a metaclass
    class TestSingleton(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    # Test that a single instance of the class is created
    s = TestSingleton(1)
    assert s.x == 1
    assert s is TestSingleton(x=2)
    assert s.x == 1



# Generated at 2022-06-11 18:35:00.164325
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Cursor:
        __metaclass__ = Singleton
        def __init__(self):
            self.name = "Cursor"
    cursor1 = Cursor()
    cursor2 = Cursor()
    assert cursor1.name == "Cursor"
    assert cursor2.name == "Cursor"
    assert cursor1 is cursor2

# Generated at 2022-06-11 18:35:04.128055
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        pass

    foo = Foo()
    foo2 = Foo()

    assert(foo == foo2)
    assert(id(foo) == id(foo2))

# Generated at 2022-06-11 18:35:07.710002
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, id):
            self.id = id

    a = Foo(1)
    b = Foo(2)
    print(a.id, b.id)  # output: 1 1

# Generated at 2022-06-11 18:35:11.171007
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Student(metaclass=Singleton): # 或者__metaclass__=Singleton
        pass

    s1 = Student()
    s2 = Student()
    print(s1, s2)
    assert s1 is s2

test_Singleton___call__()

# Generated at 2022-06-11 18:35:20.758414
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        t = [1, 2, 3]
        def __init__(self, t):
            self.t = t

    a = SingletonTest('a')
    b = SingletonTest('b')

    assert a is b
    assert a.t == 'a'
    assert b.t == 'a'



# Generated at 2022-06-11 18:35:26.047075
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class One(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    class Two(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 2

    assert One() is One()
    assert Two() is Two()
    assert One() is not Two()
    assert Two() is not One()

# Generated at 2022-06-11 18:35:34.406350
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        def __init__(self, foo):
            self.foo = foo

    m1 = MyClass(1)
    m2 = MyClass(2)
    # Test for object identity
    assert m1 is m2
    # Test for attribute equality
    assert m1.foo == 2

if __name__ == '__main__':
    import sys
    if sys.version_info.major == 2:
        import pytest
        sys.exit(pytest.main())
    else:
        test_Singleton___call__()

# Generated at 2022-06-11 18:35:38.185966
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    x = TestSingleton()
    y = TestSingleton()
    assert(x is y)


# Generated at 2022-06-11 18:35:48.575880
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # First call of the singleton class
    test_class1 = TestClass1()
    assert test_class1.__class__.__name__ == 'TestClass1'
    assert test_class1.__class__ == Singleton('TestClass1', tuple(), {})

    # Second call of the singleton class
    test_class2 = TestClass1()
    assert test_class1 is test_class2
    assert test_class2.__class__.__name__ == 'TestClass1'
    assert test_class2.__class__ == Singleton('TestClass1', tuple(), {})

    # Call of different class
    test_class3 = TestClass2()
    assert test_class1 is not test_class3
    assert test_class3.__class__.__name__ == 'TestClass2'
    assert test_class

# Generated at 2022-06-11 18:35:53.607788
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class X(object):
        __metaclass__ = Singleton
        instance_counter = 0

        def __init__(self):
            X.instance_counter += 1

    x1 = X()
    x2 = X()
    assert x1 is x2
    assert X.instance_counter == 1
    x1.instance_counter = 5
    assert x1.instance_counter == x2.instance_counter

# Extreme test for thread safety of method __call__ of class Singleton

# Generated at 2022-06-11 18:36:00.917519
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test 1) Create singleton class with __init__ that takes no parameters
    class Test1(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    t1 = Test1()
    assert t1 is Test1()

    # Test 2) Create singleton class with __init__ that takes no parameters
    class Test2(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    t1 = Test2('Test2')
    assert t1 is Test2('other')



# Generated at 2022-06-11 18:36:07.741734
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Single(object):
        __metaclass__ = Singleton

    class Single2(object):
        __metaclass__ = Singleton

    assert Single == Single2
    # as Singleton is a new-style class, instance can only be obtained by __call__
    # we call the __call__ method of the Singleton class.
    assert Single() == Single2() == Singleton.__call__(Single) == Singleton.__call__(Single2)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:36:16.112828
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    # Create two instances of class Spam and assert they are the same.
    # Use multithreading to mimic concurrent calls to Singleton.__call__
    import threading
    import time

    class Spam(object):
        __metaclass__ = Singleton

        def __init__(self):
            time.sleep(0.01)
            self.spam = 'spam'

    class Egg(Spam):
        pass

    t1 = threading.Thread(target=lambda: Spam())
    t2 = threading.Thread(target=lambda: Spam())
    t3 = threading.Thread(target=lambda: Egg())
    t1.start()
    t2.start()
    t3.start()
    t1.join()
    t2.join()
    t3.join()
    x = Sp

# Generated at 2022-06-11 18:36:19.646835
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, _a):
            self.a = _a

    assert A('foo') is A('bar')

# Generated at 2022-06-11 18:36:30.767223
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a
    class SingletonTest(unittest.TestCase):
        def setUp(self):
            self.a = TestSingleton(a=1)
            self.b = TestSingleton(a=2)

        def tearDown(self):
            del self.a
            del self.b

        def test_instances(self):
            self.assertEqual(self.a.a, 1)
            self.assertEqual(self.b.a, 2)
            self.assertEqual(self.a.a, 2)
            self.assertEqual(self.b.a, 2)


# Generated at 2022-06-11 18:36:36.673854
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self, arg):
            self._arg = arg
        def get(self):
            return self._arg

    instance1 = Test(1)
    assert instance1.get() == 1
    instance2 = Test(2)
    assert instance1.get() == 1
    assert id(instance1) == id(instance2)
    # Delete the instance
    del instance1
    instance2 = Test(2)
    assert id(instance1) == id(instance2)
    assert instance2.get() == 2

# Generated at 2022-06-11 18:36:39.131429
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-11 18:36:41.113697
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-11 18:36:50.295032
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class AClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.__value = 0

        def inc(self):
            self.__value += 1

        def get(self):
            return self.__value

    a = AClass()
    b = AClass()
    if (a != b):
        raise RuntimeError("Two different instance")
    a.inc()
    if (a.get() != 1):
        raise RuntimeError("a.get() != 1")
    if (b.get() != 1):
        raise RuntimeError("b.get() != 1")

# Generated at 2022-06-11 18:36:53.187727
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    def A():
        pass
    def B():
        pass

    A_instance = A()
    B_instance = B()

    assert id(A()) == id(A_instance)
    assert id(B()) == id(B_instance)

# Generated at 2022-06-11 18:36:55.990076
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, dct):
            self.dct = dct

    a = TestClass(dct=(1, 2, 3))
    b = TestClass(dct=(2, 3, 4))
    assert a is b


# Generated at 2022-06-11 18:37:01.601177
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, json_output=False):
            self.json_output = json_output

    if TestClass():
        print('Yes')
    else:
        print('No')

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:37:04.623686
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() == TestSingleton()
    assert TestSingleton() is TestSingleton()



# Generated at 2022-06-11 18:37:12.429111
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    class TestSubClass(TestClass):
        """This class is a subclass of TestClass but it has a __call__ method
        which is not inherited from the super class.
        """
        def __call__(self, *args, **kwargs):
            return super(TestSubClass, self).__call__(*args, **kwargs)

    singleton_instance = TestClass()
    singleton_instance2 = TestClass()
    assert singleton_instance == singleton_instance2
    singleton_instance3 = TestSubClass()
    assert singleton_instance == singleton_instance3

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:37:30.365429
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    def print_message(self, message):
        print("Message: %s" % message)

    class TestClass(object):

        __metaclass__ = Singleton

        def __init__(self):
            self.test_var = 5

        def print_test_var(self):
            print("test_var: %d" % self.test_var)

    class SingletonTest(unittest.TestCase):

        def test_Singleton(self):
            obj_1 = TestClass()
            obj_1.print_message("Hello world from object 1")
            obj_2 = TestClass()
            obj_2.print_message("Hello world from object 2")

            obj_1.test_var = 7
            obj_1.print_test_var()
            obj_2.print_test

# Generated at 2022-06-11 18:37:40.314432
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    # Test 1:
    test_singleton = TestSingleton('hello', 'world')
    test_singleton1 = TestSingleton('goodbye', 'world')
    assert test_singleton == test_singleton1
    assert test_singleton is test_singleton1
    assert test_singleton1 == test_singleton
    assert test_singleton1 is test_singleton

# Generated at 2022-06-11 18:37:48.694167
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    # Instantiate and test using the singleton class
    a = TestClass()
    assert a is TestClass()
    # Instantiate in a background thread and see if it's the same instance
    def __thread_test():
        b = TestClass()
        assert b is a
    th = Thread(target=__thread_test)
    th.start()
    th.join()


# Generated at 2022-06-11 18:38:00.178005
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self):
            pass

    t1 = Test()
    t2 = Test()
    assert t1 == t2

    class Test(metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    t1 = Test("1")
    t2 = Test("2")
    assert t1 == t2
    assert t1.a == "1"
    assert t2.a == "1"

    class Test(metaclass=Singleton):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = Test("1", "2")
    t2 = Test("3", "4")
    assert t1 == t2
    assert t1

# Generated at 2022-06-11 18:38:07.745527
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 0

    def f(obj):
        obj.val += 1

    s1 = SingletonTest()
    s2 = SingletonTest()

    assert(s1 is s2)
    assert(s1.val == 0)
    assert(s2.val == 0)

    f(s1)
    assert(s1.val == 1)
    assert(s2.val == 1)

    f(s2)
    assert(s1.val == 2)
    assert(s2.val == 2)

# Generated at 2022-06-11 18:38:12.633202
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        """Class for testing __call__ method of class Singleton"""

        __metaclass__ = Singleton

        def __init__(self):
            """Pass"""
        def print_name(self):
            """Prints name of the class"""
            print(self.__class__.__name__)

    a = TestClass()
    b = TestClass()

    assert a is b

# Generated at 2022-06-11 18:38:17.482389
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test_attr = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.test_attr == 1
    assert t2.test_attr == 1
    t1.test_attr = 2
    assert t1.test_attr == 2
    assert t2.test_attr == 2


# Test that two classes with different namespaces do not clash.

# Generated at 2022-06-11 18:38:21.035170
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class x(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = x()
    b = x()
    assert a is b
    a.a = 2
    assert b.a == 2

# Generated at 2022-06-11 18:38:23.830079
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b


# Generated at 2022-06-11 18:38:26.967701
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    a = A()
    b = B()
    assert(a==A())
    assert(b==B())
    assert(a!=b)

# Generated at 2022-06-11 18:38:52.329738
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Person:
        __metaclass__ = Singleton

    class NamedPerson:
        __metaclass__ = Singleton

    if __name__ == "__main__":
        o_p1 = Person()
        o_p2 = Person()

        o_np1 = NamedPerson()
        o_np2 = NamedPerson()

        print("o_p1 == o_p2:", o_p1 == o_p2)
        print("o_np1 == o_np2:", o_np1 == o_np2)


# Standalone test
if __name__ == "__main__":
    # Unit test for method __call__ of class Singleton
    test_Singleton___call__()

    print("Done.")

# Generated at 2022-06-11 18:38:55.338306
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test_Singleton(object):
        __metaclass__ = Singleton
    t1 = Test_Singleton()
    t2 = Test_Singleton()
    assert(t1 is t2)



# Generated at 2022-06-11 18:38:58.352897
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.first_name = 'Ansible'
            self.last_name = 'Tower'
            pass

    s1 = S()
    s2 = S()
    assert s1 is s2


# Generated at 2022-06-11 18:39:05.369490
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    # singleton object initialization, retrieve object
    objA = A('first')
    # get instance from same class, should be identical objA
    objB = A('second')
    assert id(objA) == id(objB)
    assert objA.name == 'first'
    assert objB.name == 'first'


# Generated at 2022-06-11 18:39:09.311095
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, number=10):
            self.number = number

    obj1 = MyClass()
    assert id(obj1) == id(MyClass())
    assert obj1.number == 10

    obj2 = MyClass(20)
    assert id(obj2) == id(obj1)
    assert obj2.number == 10

# Generated at 2022-06-11 18:39:10.982936
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-11 18:39:14.414503
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object, metaclass=Singleton):
        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == b.a



# Generated at 2022-06-11 18:39:24.662136
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass1(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name1 = 'Bob'
            self.name2 = 'Dylan'

    class TestClass2(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name1 = 'Paul'
            self.name2 = 'McCartney'

    a = TestClass1()
    
    assert a.name1 == 'Bob'
    assert a.name2 == 'Dylan'

    b = TestClass1()
    
    assert b.name1 == 'Bob'
    assert b.name2 == 'Dylan'
    assert b is a

    c = TestClass1()

    assert c.name1 == 'Bob'

# Generated at 2022-06-11 18:39:28.210769
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class SingletonTest(object):
        __metaclass__ = Singleton

    class TestSingleton(unittest.TestCase):
        def test_singleton(self):
            instance1 = SingletonTest()
            instance2 = SingletonTest()
            self.assertEqual(instance1, instance2)

    TestSingleton().test_singleton()

# Generated at 2022-06-11 18:39:31.629378
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
    ob1 = TestSingleton()
    ob2 = TestSingleton()
    assert ob1 is ob2

# Generated at 2022-06-11 18:39:57.776154
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.obj_id = id(self)

    f1 = Foo()
    f2 = Foo()
    assert f1.obj_id == f2.obj_id
    assert f1 is f2



# Generated at 2022-06-11 18:40:04.226105
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            print('instance A created')

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            print('instance B created')

    a = A()
    print('a is %r' % a)
    b = B()
    print('b is %r' % b)
    c = A()
    print('c is %r' % c)
    return c is a


# Generated at 2022-06-11 18:40:14.171084
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test:
    #   1. Create a new class that uses Singleton
    #   2. Call the class twice, see if the method __call__ returns
    #   the same object
    class MyClass(object):
        __metaclass__ = Singleton
        pass
    my_class = MyClass()
    my_class1 = MyClass()
    assert id(my_class) == id(my_class1), \
        "singeleton __call__ failed test 1"

    # Test:
    #   1. Create a new class that uses Singleton
    #   2. Call the class twice, pass in keyword arguments, see if the
    #   method __call__ returns the same object
    class MyClass(object):
        __metaclass__ = Singleton

# Generated at 2022-06-11 18:40:20.405483
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingleInstance:
        __metaclass__ = Singleton

    with SingleInstance() as i1:
        assert(isinstance(i1, SingleInstance))
        with SingleInstance() as i2:
            assert(isinstance(i2, SingleInstance))
            assert(i1 == i2)
            assert(id(i1) == id(i2))



# Generated at 2022-06-11 18:40:28.852756
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class Foo(object):
        __metaclass__ = Singleton

    class Bar(Foo):
        pass

    class SingletonTestCase(unittest.TestCase):
        def test_same_instance(self):
            self.assertTrue(Foo() is Foo())

        def test_same_instance_different_class(self):
            self.assertFalse(Foo() is Bar())

    # Cleanup
    del Foo.__instance
    del Bar.__instance

    # Run unit test
    unittest.main()

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:40:36.072498
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, test_value, **kwargs):
            self.test_value = test_value
            self.kwargs = kwargs
    
    instance_1 = TestSingleton(1, foo='bar')
    instance_2 = TestSingleton(2, omg='wtf')
    assert instance_1.test_value == 2
    assert instance_1.kwargs == {'omg': 'wtf'}
    assert instance_2.test_value == 2
    assert instance_2.kwargs == {'omg': 'wtf'}

test_Singleton___call__()

# Generated at 2022-06-11 18:40:38.512816
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self):
            self.a = 1

    assert Test() == Test()
    assert Test().a == 1



# Generated at 2022-06-11 18:40:42.511964
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class ASingletonClass(object):
        __metaclass__ = Singleton

    test_class1 = ASingletonClass()
    test_class2 = ASingletonClass()
    assert test_class1 == test_class2

# Generated at 2022-06-11 18:40:47.605311
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton): pass
    x = TestSingleton()
    y = TestSingleton()
    assert x is y
    assert x == y
    assert isinstance(x, TestSingleton)
    assert isinstance(y, TestSingleton)
    assert type(x) is TestSingleton
    assert type(y) is TestSingleton
    assert id(x) == id(y)


# Generated at 2022-06-11 18:40:53.144874
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert(t1 == t2)
    assert(id(t1) == id(t2))


if __name__ == "__main__":
    test_Singleton___call__()