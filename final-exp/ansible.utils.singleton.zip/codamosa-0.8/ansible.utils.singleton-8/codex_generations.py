

# Generated at 2022-06-11 18:31:38.270075
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            print("A.__init__()")
            self.tag = 0

    aa = A()
    print("aa.tag =", aa.tag)
    aa.tag += 1
    ab = A()
    print("ab.tag =", ab.tag)
    assert (aa == ab)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:31:49.544277
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # import logging
    # logger = logging.getLogger(__name__)

    class A(object):
        """A concrete class instantiable."""

        def __init__(self, x):
            self.x = x

        def __repr__(self):
            return 'A[%s]' % self.x

        def __str__(self):
            return self.__repr__()

    class B(object):
        """A non-concrete class NOT instantiable."""

        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

        def __repr__(self):
            return 'B[%s]' % self.x

        def __str__(self):
            return self.__repr__()


# Generated at 2022-06-11 18:32:01.916029
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class ClassA(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    class ClassB(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    class ClassC(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    classA = ClassA()
    classB = ClassB()
    classC = ClassC()
    classAA = ClassA()
    classBB = ClassB()
    classCC = ClassC()

    assert(classA == classAA)
    assert(classB == classBB)
    assert(classC == classCC)
    assert(classA is not classB)
    assert(classA is not classC)

# Generated at 2022-06-11 18:32:07.188734
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(metaclass=Singleton):
        a = 1

    class MyClass2:
        a = 2

    mc = MyClass()
    mc2 = MyClass()
    assert mc is mc2
    assert mc2 is mc
    mc3 = MyClass2()
    # assert mc3 is not mc
    # assert mc3 is not mc2

# Generated at 2022-06-11 18:32:12.059367
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(metaclass=Singleton):
        def __init__(self, *args, **kw):
            self.args = args
            self.kw = kw

    if C(1,'b', foo='bar', bar='baz') != C(bar='baz', foo='bar', b='2'):
        raise Exception("Singleton constructor is broken!")


test_Singleton()

# Generated at 2022-06-11 18:32:19.401503
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    flag = False

    class MySingle(object):
        __metaclass__ = Singleton
        def __init__(self):
            global flag
            flag = True

    class MyBase(object):
        def __init__(self):
            pass

    class MyClass(MyBase):
        __metaclass__ = Singleton
        def __init__(self):
            MyBase.__init__(self)

    ms = MySingle()

    assert(flag == True)
    assert(isinstance(ms, MySingle))
    assert(isinstance(ms.__class__, Singleton))

    mc = MyClass()

    assert(isinstance(mc, MyClass))
    assert(isinstance(mc.__class__, Singleton))

    assert(mc == MyClass())
    assert(mc is MyClass())


# Generated at 2022-06-11 18:32:26.198889
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    obj1 = MyClass()
    obj2 = MyClass()
    assert obj1 is obj2
    assert obj1.x == 1 and obj2.x == 1
    obj2.x = 2
    assert obj1.x == 2 and obj2.x == 2

# Generated at 2022-06-11 18:32:31.459503
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 2

    a = MySingleton()
    b = MySingleton()
    assert a.x == 2
    assert b.x == 2
    a.x = 3
    assert a.x == 3
    assert b.x == 3

# Generated at 2022-06-11 18:32:33.688153
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(metaclass=Singleton):
        pass

    a = SingletonTest()
    b = SingletonTest()
    assert a is b


# Generated at 2022-06-11 18:32:36.235867
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    assert Singleton.__call__(Foo) is Singleton.__call__(Foo)

# Generated at 2022-06-11 18:32:41.481469
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        pass

    a = TestSingleton()
    b = TestSingleton()
    assert a is b



# Generated at 2022-06-11 18:32:46.980719
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'Foo'

    foo = Foo()
    assert foo.name == 'Foo'
    bar = Foo()
    assert not hasattr(bar, 'name')



# Generated at 2022-06-11 18:32:53.983012
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, arg=None):
            self.arg = arg

    my_class1 = MyClass('foo')
    assert my_class1.arg == 'foo'
    my_class2 = MyClass('bar')
    assert my_class2.arg == 'foo', 'Singleton returns different argument'
    assert my_class1 is my_class2, 'Singleton provides same instance'

# Generated at 2022-06-11 18:32:57.469589
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    test_obj_1 = TestClass()
    test_obj_2 = TestClass()
    assert(id(test_obj_1) == id(test_obj_2))

# Generated at 2022-06-11 18:33:01.169770
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
    test_class1 = TestClass()
    test_class2 = TestClass()
    assert test_class1 is test_class2

# Generated at 2022-06-11 18:33:04.020033
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = foo()
    b = foo()
    assert(a is b)



# Generated at 2022-06-11 18:33:06.421950
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SomeClass(object):
        __metaclass__ = Singleton


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:33:09.942804
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    inst1 = MyClass()
    inst2 = MyClass()

    assert inst1 is inst2


# Generated at 2022-06-11 18:33:12.494773
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    obj1 = MySingleton()

    obj2 = MySingleton()

    assert obj1 == obj2


# Generated at 2022-06-11 18:33:23.467102
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(object):
        __metaclass__ = Singleton
        def __init__(self, s):
            self.s = s
    class Y(object):
        __metaclass__ = Singleton
        def __init__(self, s):
            self.s = s
    assert X('foo') is X('bar')
    assert Y('foo') is Y('bar')
    assert X('foo') is not Y('foo')
    assert X('foo').s == 'bar'
    assert Y('foo').s == 'bar'
    assert X().s == 'bar'
    assert Y().s == 'bar'
    X().s = 'baz'
    assert X().s == 'baz'


# Generated at 2022-06-11 18:33:32.129832
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.__class__.instance.append(self)

        instance = []

    a = SingletonTest()
    b = SingletonTest()
    assert(a is b)
    assert(a == b)
    assert(len(SingletonTest.instance) == 1)



# Generated at 2022-06-11 18:33:38.719290
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self, number):
            self.a = number
            print(self.a)

    a = A(1)
    # Same object
    b = A(2)
    assert a.a == b.a
    assert a is b
    # Same object
    c = A(3)
    assert a.a == c.a
    assert a is c

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:33:50.539417
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.f = None

        def bar(self, x):
            self.f = x

        def __str__(self):
            return 'Foo(f={})'.format(self.f)

    foo1 = Foo()
    foo2 = Foo()

    assert foo1 == foo2
    assert foo1 is foo2

    foo1.bar(1)
    assert str(foo1) == 'Foo(f=1)'
    assert str(foo2) == 'Foo(f=1)'

    foo2.bar(2)
    assert str(foo1) == 'Foo(f=2)'
    assert str(foo2) == 'Foo(f=2)'


# Generated at 2022-06-11 18:33:55.528650
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, data):
            self.data = data

    a1 = A(1)
    a2 = A(2)

    assert a1 is a2
    assert a1.data == 1



# Generated at 2022-06-11 18:34:00.629676
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self, number):
            self.number = number

        def __repr__(self):
            return '{}:{}'.format(self.__class__.__name__, self.number)

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)

    assert t1 == t2
    assert t1.__class__.__instance == t2.__class__.__instance

# Generated at 2022-06-11 18:34:03.552364
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        pass

    a1 = A()
    a2 = A()

    assert a1 is a2

test_Singleton___call__()



# Generated at 2022-06-11 18:34:05.599025
# Unit test for constructor of class Singleton
def test_Singleton():
    assert issubclass(Singleton, type) is True



# Generated at 2022-06-11 18:34:08.237422
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonExample(object):
        __metaclass__ = Singleton

    assert SingletonExample() is not None



# Generated at 2022-06-11 18:34:12.481891
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 5

    a = TestClass()
    b = TestClass()
    assert id(a) == id(b)
    assert a.a == b.a



# Generated at 2022-06-11 18:34:15.375209
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        """A simple Singleton class"""

    s1 = TestSingleton()
    s2 = TestSingleton()
    assert s1 == s2

# Generated at 2022-06-11 18:34:18.294321
# Unit test for constructor of class Singleton
def test_Singleton():
    pass

# Generated at 2022-06-11 18:34:20.705838
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    assert isinstance(Foo(), Foo)



# Generated at 2022-06-11 18:34:24.129407
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'foo'

    a = A()
    b = A()
    assert a.name == b.name



# Generated at 2022-06-11 18:34:27.707792
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton

    a = S()
    b = S()
    assert a == b


# Generated at 2022-06-11 18:34:33.391595
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.v = 1

    a = A()
    assert(a.v == 1)
    a.v = 2
    b = A()
    assert(b.v == 2)
    assert(a is b)


# Generated at 2022-06-11 18:34:39.158544
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    # Define a class that is a singleton
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    instance1 = Foo(1)
    assert isinstance(instance1, Foo)

    instance2 = Foo(2)
    assert isinstance(instance2, Foo)

    # Check that second and third instances are the same
    # if they are, then the Singleton functionality works
    assert instance1 is instance2


# Generated at 2022-06-11 18:34:49.386324
# Unit test for constructor of class Singleton
def test_Singleton():
    from types import MethodType
    class ClassA:
        __metaclass__ = Singleton
        # NOTE: __metaclass__ should be in the first line of the class
        class_id = 1
        def __init__(self, instance_id):
            self.instance_id = instance_id
            self.inc_inst_count()

        def inc_inst_count(self):
            ClassA.class_id += 1

    # ClassA with __metaclass__ should be Singleton
    obj1 = ClassA(1)
    assert isinstance(obj1, ClassA)
    assert obj1.class_id == 2
    assert obj1.instance_id == 1
    assert len(obj1.__dict__) == 2

    obj2 = ClassA(2)
    assert isinstance(obj2, ClassA)


# Generated at 2022-06-11 18:34:52.283220
# Unit test for constructor of class Singleton
def test_Singleton():
    assert (issubclass(Singleton, type))


# Generated at 2022-06-11 18:34:53.556717
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(metaclass=Singleton):
        pass

    assert C() is C()

# Generated at 2022-06-11 18:34:59.549674
# Unit test for constructor of class Singleton
def test_Singleton():
    # define a class that inherits Singleton, but is not a singleton
    class A(object):
        __metaclass__ = Singleton
    # the singleton class
    class B(object):
        __metaclass__ = Singleton
    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()
    # a1 and a2 are two different instances of A
    assert a1 is not a2
    # When instantiating B the first time, you may get the object b1
    assert b1 is b2
    # When instantiating B the second time, you will get the object b1
    assert b1 is b2
    # b1 and b2 are the same object
    assert b1 is b2

# Generated at 2022-06-11 18:35:09.321046
# Unit test for constructor of class Singleton
def test_Singleton():

    class MockSingleton(object):
        """Dummy class for unit-testing"""
        __metaclass__ = Singleton

        def __init__(self, a, b, c):
            """Dummy constructor, taking arguments for checking
            that the objects are different.
            """
            self.a = a
            self.b = b
            self.c = c

    assert MockSingleton(1, 2, 3) == MockSingleton(4, 5, 6)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:35:15.708750
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingleton2(object):
        __metaclass__ = Singleton

    test_singleton_instance1 = TestSingleton()
    test_singleton_instance2 = TestSingleton()
    assert test_singleton_instance1 == test_singleton_instance2

    test_singleton_instance_2_1 = TestSingleton2()
    test_singleton_instance_2_2 = TestSingleton2()
    assert test_singleton_instance_2_1 == test_singleton_instance_2_2


# Generated at 2022-06-11 18:35:20.184854
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """docstring for test_Singleton___call__"""
    class Foo(object):
        __metaclass__ = Singleton
        pass

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 == foo2

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:35:30.849737
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2, kwarg1=None, kwarg2=None):
            self.arg1 = arg1
            self.arg2 = arg2
            self.kwarg1 = kwarg1
            self.kwarg2 = kwarg2

    arg1 = "arg1"
    arg2 = ["arg2", 1]
    kwarg1 = "kwarg1"
    kwarg2 = {"kwarg2": "value2"}
    o1 = TestSingleton(arg1, arg2, kwarg1, kwarg2)
    o2 = TestSingleton(arg1, arg2, kwarg1, kwarg2)
    assert o1 is o2
    assert o

# Generated at 2022-06-11 18:35:34.641024
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = "MySingleton"

    ms1 = MySingleton()
    ms2 = MySingleton()

    assert ms1 is ms2

# Generated at 2022-06-11 18:35:43.773143
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.count = 0

        def call(self):
            self.count += 1
            return self.count

    # check proper function of Singleton, i.e., that only one instance exists
    one = TestSingleton()
    two = TestSingleton()
    three = TestSingleton()
    assert one is two
    assert two is three
    assert one is three

    # check proper function of method "call"
    assert one.call() == 1
    assert two.call() == 2
    assert three.call() == 3

# Generated at 2022-06-11 18:35:50.800243
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S1(object):
        __metaclass__ = Singleton

        def __init__(self):
            super(S1,self).__init__()
            self._data = 0

        @property
        def data(self):
            return self._data
        @data.setter
        def data(self, data):
            self._data = data

    o1 = S1()
    o1.data = 2
    o2 = S1()
    assert (id(o1) == id(o2))
    assert (o2.data == 2)



# Generated at 2022-06-11 18:35:57.482300
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.num = 0

        def __str__(self):
            return "MyClass: num=" + str(self.num)

        def __eq__(self, other):
            return isinstance(other, MyClass) and self.num == other.num

        def __ne__(self, other):
            return not self.__eq__(other)

        def inc_num(self):
            self.num += 1

    # Instantiate MyClass
    var1 = MyClass()
    assert isinstance(var1, MyClass)

    # Increment var1 num attribute
    var1.inc_num()
    assert str(var1) == "MyClass: num=1"

    # Instantiate MyClass
    var

# Generated at 2022-06-11 18:36:01.044574
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    a = A()
    b = B()

    assert a is A()
    assert b is B()
    assert a is not b

# Generated at 2022-06-11 18:36:04.526777
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a single instance of class _SingletonTest
    s0 = _SingletonTest()
    # Create another instance of class _SingletonTest
    s1 = _SingletonTest()

    # Assert both instances are the same instance
    assert s0 is s1


# Generated at 2022-06-11 18:36:13.818527
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self, *args, **kwargs):
            self.one = 1
            self.two = 2
            self.args = args
            self.kwargs = kwargs

    assert MyClass(1, 2, three=3) is MyClass(1, 2, three=3)
    assert MyClass(1, 2, three=3).args == (1, 2)
    assert MyClass(1, 2, three=3).kwargs == {'three': 3}
    assert MyClass().one == 1
    assert MyClass().two == 2

# Generated at 2022-06-11 18:36:15.677530
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        pass

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-11 18:36:19.808283
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert Singleton.__instance is None

    A = Singleton('A', (), {})
    assert Singleton.__instance is None

    a = A()
    assert Singleton.__instance is not None
    assert a is Singleton.__instance
    assert isinstance(a, A) is True

# Generated at 2022-06-11 18:36:23.858146
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self, val):
            self.val = val

    a = MyClass(3)
    b = MyClass(4)
    assert id(a) == id(b)
    assert a.val == b.val
    assert b.val == 3

    c = MyClass(5)
    assert id(c) == id(b)
    assert c.val == 3


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:36:29.463535
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self._x = 1
            self._y = 2

    ins = TestSingleton()
    assert ins._x == 1
    assert ins._y == 2
    ins_2 = TestSingleton()
    assert ins_2._x == 1
    assert ins_2._y == 2
    assert ins == ins_2


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 18:36:37.533892
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase
    from unittest import TestSuite
    from unittest import main
    from mock import MagicMock
    from mock import patch

    # Mock super for class Singleton
    _Super = MagicMock(name='super')
    # Mock super class
    _SuperClass = MagicMock(name='super-class')

    class TestClass(object):
        """Test class used as base class for Singleton class."""
        pass

    with patch('ansible.utils.singleton.RLock', autospec=True) as mocked_RLock:
        mocked_RLock_instance = MagicMock(name='rlock-instance')
        mocked_RLock.return_value = mocked_RLock_instance
        with patch('ansible.utils.singleton.super', _Super):
            _Super.return_

# Generated at 2022-06-11 18:36:48.193391
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

        def get_value(self):
            return self.value

    a = MySingleton(42)
    b = MySingleton(43)

    # check for singleton like behaviour
    assert a is b
    assert a == b

    # check for values
    assert a.value == b.value == 42

    # check for attribute access
    a.myattr = "myattr"
    assert b.myattr == "myattr"

    # check for method access
    assert a.get_value() == b.get_value() == 42

# Test the functionality of class AnsibleModule.

# Generated at 2022-06-11 18:36:52.041548
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    mc1 = MyClass(12)
    mc2 = MyClass(34)

    if mc1 != mc2:
        raise Exception('Singleton failed to return existing instance')
    if mc1.a != 12:
        raise Exception('Singleton failed to modify existing instance')

# Generated at 2022-06-11 18:36:55.193338
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t = Test()
    u = Test()
    assert id(t) == id(u)

# Generated at 2022-06-11 18:36:58.106948
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        """A test class"""
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 is a2



# Generated at 2022-06-11 18:37:05.396893
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 1
    a = A()
    b = A()
    assert(a == b)



# Generated at 2022-06-11 18:37:09.347684
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.storage = []

    foo = Foo()
    foo.storage.append(1)

    foo2 = Foo()
    foo2.storage.append(2)

    assert foo is foo2
    assert foo.storage == [1, 2]

# Generated at 2022-06-11 18:37:13.921921
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.var = 'a'

    obj1 = TestSingleton()
    assert(obj1.var == 'a')

    obj2 = TestSingleton()
    assert(obj2.var == 'a')

    assert(obj1 == obj2)

    obj1.var = 'b'
    assert(obj1.var == 'b')
    assert(obj2.var == 'b')

# Generated at 2022-06-11 18:37:16.572813
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SomeClass(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = SomeClass('Foo')
    b = SomeClass('Bar')
    assert a == b
    assert a.name == b.name


# Generated at 2022-06-11 18:37:18.583377
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from . import __main__
    from . import __main__
    from . import __main__


# Generated at 2022-06-11 18:37:26.680708
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.myValue = None

    # Check that only one instance is created
    testSingleton1 = TestSingleton()
    testSingleton1.myValue = 1
    testSingleton2 = TestSingleton()
    testSingleton2.myValue = 2
    assert testSingleton1 is testSingleton2
    assert testSingleton1.myValue == testSingleton2.myValue

    # Check that only one instance is created
    testSingleton1a = TestSingleton()
    testSingleton2a = TestSingleton()
    assert testSingleton1 is testSingleton1a
    assert testSingleton2 is testSingleton2a
    assert testSingleton1 is testSingleton2a

# Generated at 2022-06-11 18:37:31.020325
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    a1 = A("1")
    a2 = A("2")
    a3 = A("3")
    assert a1 is a3
    assert a1 is a2
    assert a2 is a3
    assert a2.name == a1.name
    assert a2.name == a2.name
    assert a1.name == a3.name
    assert a1.name != a2.name



# Generated at 2022-06-11 18:37:35.062019
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():


    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            Test.init_call_count += 1

    Test.init_call_count = 0
    Test()
    Test()
    Test()
    Test()
    Test()
    assert Test.init_call_count == 1

# Generated at 2022-06-11 18:37:39.119621
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
      __metaclass__ = Singleton

    a = A()
    b = A()
    assert(a == b)

    a.the_foo = 10
    assert(b.the_foo == 10)


# Generated at 2022-06-11 18:37:43.432753
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            print('__init__')
            self.a = 0
    a = A()
    a.a = 1
    assert a.a == 1
    b = A()
    assert b.a == 1

# Generated at 2022-06-11 18:37:50.640563
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object): __metaclass__ = Singleton

    c1 = C()
    c2 = C()
    assert c1 is not None
    assert c2 is not None
    assert c1 == c2

# Generated at 2022-06-11 18:37:55.724146
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton(10)
    b = TestSingleton(20)
    assert (a == b)
    assert (a.arg == 10)
    assert (b.arg == 10)

# Generated at 2022-06-11 18:37:59.073066
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert id(TestSingleton()) == id(TestSingleton())



# Generated at 2022-06-11 18:38:01.707866
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.a = 1

    a = TestSingleton()
    b = TestSingleton()

    assert a.a == 1
    assert b.a == 1
    assert a == b



# Generated at 2022-06-11 18:38:08.571477
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import copy
    class MyClass(object):
        __metaclass__ = Singleton

    a = MyClass()
    b = MyClass()

    print(a, b)

    print("a == b", a == b)
    print("a is b", a is b)
    print("a.__dict__", a.__dict__)
    print("b.__dict__", b.__dict__)
    print("id(a) = ", id(a))
    print("id(b) = ", id(b))


# Generated at 2022-06-11 18:38:13.662044
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.__val = val
        def get_value(self):
            return self.__val

    test1 = Test("Test1")
    assert test1 is not None
    test2 = Test("Test2")
    assert test1 is test2
    assert test1.get_value() == "Test1"
    assert test2.get_value() == "Test1"

# Generated at 2022-06-11 18:38:18.157652
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(metaclass=Singleton):
        def __init__(self, test_str):
            self.test_str = test_str

        def __str__(self):
            return self.test_str

    s_1 = TestClass("testing 1")
    s_2 = TestClass("testing 2")

    assert s_1 == s_2
    assert s_1.test_str == "testing 1"
    assert s_2.test_str == "testing 1"

# Generated at 2022-06-11 18:38:27.606437
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  #import copy
  from units.mock.cache import FakeCache
  from units.mock.data import MockDict
  from units.mock.http import MockHttp
  from units.mock.loader import MockLoader
  from units.mock.path import MockPath
  from units.mock.script import MockScript
  from ansible.module_utils import basic
  from ansible.module_utils.six import string_types
  from ansible.module_utils.six.moves import configparser
  from ansible.module_utils.connection import Connection
  from ansible.module_utils._text import to_bytes, to_text
  import ansible.module_utils.connection
  from units.mock.connection import MockConnection
  from units.mock.connection import MockConnectionMixin
  from units.compat import unitt

# Generated at 2022-06-11 18:38:36.699440
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    assert isinstance(TestSingleton('I'), TestSingleton)
    assert isinstance(TestSingleton('am'), TestSingleton)
    assert isinstance(TestSingleton('the'), TestSingleton)
    assert isinstance(TestSingleton('one'), TestSingleton)
    assert isinstance(TestSingleton('and'), TestSingleton)
    assert isinstance(TestSingleton('only'), TestSingleton)
    assert TestSingleton('one').name == 'one'
    assert TestSingleton('only').name == 'one'
    assert TestSingleton('only').name == 'one'
    assert TestSingleton('one').name == 'one'

# Generated at 2022-06-11 18:38:47.035081
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test with empty class
    class TestEmpty(object):
        __metaclass__ = Singleton
    instance1 = TestEmpty()
    instance2 = TestEmpty()
    assert id(instance1) == id(instance2)

    # Test class with initializer
    class TestWithInit(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 'test'
    instance = TestWithInit()
    assert instance.value == 'test'

    # Test class with explicit initializer
    class TestWithExplicitInit(object):
        __metaclass__ = Singleton
        def __new__(cls, *args, **kwargs):
            if not hasattr(cls, 'instance'):
                cls.instance = super(TestWithExplicitInit, cls).__new__

# Generated at 2022-06-11 18:38:58.744590
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = 1

    class B(metaclass=Singleton):
        def __init__(self):
            self.a = 2

    assert A() is not None
    assert A() is not B()
    assert B() is not None



# Generated at 2022-06-11 18:39:04.493607
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    instance_1 = MyClass()
    instance_2 = MyClass()

    import sys
    if sys.version_info >= (3, 0):
        assert instance_1 is instance_2
    else:
        assert instance_1 == instance_2

# Generated at 2022-06-11 18:39:06.599306
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Note: pylint: disable=no-member, missing-docstring
    class MyClass(object):
        __metaclass__ = Singleton

    assert MyClass() is MyClass()

# Generated at 2022-06-11 18:39:10.463257
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    obj1 = MyClass(1)
    obj2 = MyClass(2)
    assert obj1 is obj2
    assert obj1.a == 1

# Generated at 2022-06-11 18:39:16.024939
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from collections import Counter

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.counter = Counter()
            self.counter['init'] += 1

        def incre(self):
            self.counter['incre'] += 1

    a = A()

    assert a.counter['init'] == 1
    a.incre()
    assert a.counter['incre'] == 1
    assert a.counter['init'] == 1

    b = A()

    # b had not called incre()
    assert b.counter['incre'] == 0

    # counter member of b is the same as counter member of a
    assert a.counter == b.counter

# Generated at 2022-06-11 18:39:20.323495
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_class = Singleton('SingletonClass', (object,), dict(a=1))
    singleton_instance_1 = singleton_class()
    singleton_instance_2 = singleton_class()
    assert singleton_instance_1 == singleton_instance_2
    assert singleton_instance_1.a == 1



# Generated at 2022-06-11 18:39:23.939428
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2


# Generated at 2022-06-11 18:39:28.577810
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        """metaclass = Singleton"""
        __metaclass__ = Singleton

        def __init__(self, a, b=None):
            if b is None:
                self.x = a * a
            else:
                self.x = a * b

    f1 = Foo(3)
    assert(f1.x == 9)
    f2 = Foo(3, 3)
    assert(f2.x == 9)
    assert(f1 is f2)



# Generated at 2022-06-11 18:39:31.366987
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    obj = TestSingleton()
    assert TestSingleton() is obj


# Generated at 2022-06-11 18:39:33.336783
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    assert a1 is A()

# Generated at 2022-06-11 18:40:01.287064
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    t1 = TestSingleton("t1")
    t2 = TestSingleton("t2")
    t3 = TestSingleton("t3")
    assert t1 is t2 is t3
    assert t1.value == "t3"

if __name__ == "__main__":
    test_Singleton___call__()
    print("[PASS] Singleton.__call__")

# Generated at 2022-06-11 18:40:02.830673
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert('Hello' == test_Singleton___call__.__name__)


# Generated at 2022-06-11 18:40:05.867174
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    obj1 = A(1)
    obj2 = A(2)
    assert obj1 == obj2


# Generated at 2022-06-11 18:40:14.987815
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from nose.tools import assert_is_instance, assert_equal, assert_same

    class TestSingletonClass(object):
        __metaclass__ = Singleton
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    # Test initialization
    assert_is_instance(TestSingletonClass(1, 2), TestSingletonClass)
    assert_is_instance(TestSingletonClass(3, 4), TestSingletonClass)
    assert_equal(TestSingletonClass(1, 2).arg1, 1)
    assert_equal(TestSingletonClass(1, 2).arg2, 2)
    assert_equal(TestSingletonClass(3, 4).arg1, 3)

# Generated at 2022-06-11 18:40:21.052986
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    instance1 = MyClass('test')
    instance2 = MyClass('test')

    assert instance1 is instance2
    assert instance1.arg == instance2.arg
    assert instance1.arg == 'test'

# Generated at 2022-06-11 18:40:27.783351
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from nose.tools import assert_equal
    from nose.tools import assert_not_equal
    from nose.tools import assert_raises

    class Test(object):
        """Test class."""
        __metaclass__ = Singleton

        def __init__(self, data):
            self.data = data

    # test
    test1 = Test('foo')
    test2 = Test('bar')
    assert_equal(test1, test2)
    assert_equal(test1.data, 'foo')

# Generated at 2022-06-11 18:40:36.528047
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object, metaclass=Singleton):
        def __init__(self, num_a, num_b):
            self.num_a = num_a
            self.num_b = num_b

        def __str__(self):
            return 'num_a=%d, num_b=%d' % (self.num_a, self.num_b)

    # Initialize the first instance of TestSingleton
    num_a = 1
    num_b = 2
    test = TestSingleton(num_a, num_b)

    # Use the same instance of TestSingleton
    num_a = 3
    num_b = 4
    assert test == TestSingleton(num_a, num_b)

    # Use the same instance of TestSingleton
    num_a = 5
   

# Generated at 2022-06-11 18:40:40.621102
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    # First call should return an object
    a1 = A()
    assert a1

    # Second call should return the same object returned by the first call
    a2 = A()
    assert a2 == a1


# Generated at 2022-06-11 18:40:46.243184
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    # No instance of class A is present
    a = A()

    # Another instance of class A created
    b = A()

    # Check if the instance of class A is a singleton
    assert a is b

    # __call__ should return an instance of class A
    assert isinstance(b, A)


# Generated at 2022-06-11 18:40:51.228457
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    # create two instance of MySingleton,
    # the second instance would point to
    # the first one
    in1 = MySingleton()
    in2 = MySingleton()

    assert in1 is in2
    assert in1 == in2