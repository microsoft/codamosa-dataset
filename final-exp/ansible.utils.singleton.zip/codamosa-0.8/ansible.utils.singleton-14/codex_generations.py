

# Generated at 2022-06-11 18:31:38.221855
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return self.value

    a = TestSingleton('foo')
    b = TestSingleton('bar')
    assert a.value == 'foo'
    assert b.value == 'foo'
    assert str(b) == 'foo'
    assert a == b



# Generated at 2022-06-11 18:31:49.499696
# Unit test for constructor of class Singleton
def test_Singleton():
    import unittest
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.counter = 0
            self.increment = 1

        def increase(self):
            self.counter += self.increment

    class TestSingleton(unittest.TestCase):
        def test_basic(self):
            obj1 = Test(1, a=2)
            obj2 = Test(2, a=1)
            assert obj1 is obj2
            assert obj1.args == (1,)
            assert obj1.kwargs == {'a': 2}
            assert obj2.args == (1,)
            assert obj2.kwargs == {'a': 2}

# Generated at 2022-06-11 18:32:00.183378
# Unit test for constructor of class Singleton
def test_Singleton():
    import unittest
    import ctypes
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 'a'
    
    class TestCase(unittest.TestCase):
        def test_singleton(self):
            a = Test()
            b = Test()
            self.assertEqual(a.a, 'a')
            self.assertEqual(b.a, 'a')
            self.assertEqual(id(a), id(b))
            self.assertEqual(a, b)

    unittest.main()


# Generated at 2022-06-11 18:32:08.752865
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonObject(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    # Test that two instances are the same
    obj1 = SingletonObject("paul")
    obj2 = SingletonObject("paul")

    assert obj1 == obj2
    assert obj1 is obj2

    # Test that changing the value of one changes it in the other
    obj2.name = "bob"

    assert obj1 == obj2
    assert obj1.name == "bob"
    assert obj2.name == "bob"

# Generated at 2022-06-11 18:32:12.330942
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

    a = S()
    b = S()

    print(a)
    print(b)

    assert(a is b)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:32:16.490006
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, id):
            self.id = id

    a = A(1)
    assert a.id == 1

    b = A(2)
    assert b.id == 1
    assert a is b

# Generated at 2022-06-11 18:32:22.580763
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    a1 = A('a1')
    a2 = A('a2')
    assert a1.a == 'a1'
    assert a2.a == 'a1'
    assert a1 == a2



# Generated at 2022-06-11 18:32:29.131186
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object, metaclass=Singleton):
        def __init__(self, log_name):
            self.log_name = log_name

    logger1 = MyClass("foo")
    logger2 = MyClass("bar")
    assert logger1 is logger2
    assert logger1.log_name == "foo"
    assert logger2.log_name == "foo"
    assert logger1.log_name == "bar"


# Generated at 2022-06-11 18:32:36.750139
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class BoringClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 0
    
    class FancyClass(object):
        __metaclass__ = Singleton
    
    c = BoringClass()
    c2 = BoringClass()
    assert c == c2
    assert c is c2
    
    c.value += 1
    c2.value += 2
    assert c.value == 3
    assert c2.value == 3
    
    fancy = FancyClass()
    fancy2 = FancyClass()
    assert fancy == fancy2
    assert fancy is fancy2

# Function to be used by unit test for method __call__ of class
# Singleton

# Generated at 2022-06-11 18:32:47.200296
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from .mock_fixture import MockFixture
    from .mock_fixture import MockFixture
    with MockFixture(Singleton) as mocks:
        obj1 = Singleton('name1', (), {})()
        obj2 = Singleton('name2', (), {})()
        assert obj1 is obj2

        #mocks.Singleton.assert_called_once_with('name1', (), {})
        mocks.Singleton.assert_has_calls([
            mocks.call('name1', (), {}),
            mocks.call('name2', (), {})
        ])
        mocks.type.assert_called_once_with('name1', (), {})
        #mocks.type().__call__.assert_called_once_with()

        assert not mocks.object.called

# Generated at 2022-06-11 18:32:49.676713
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # TODO: implement unit test
    pass

# Generated at 2022-06-11 18:32:57.951704
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    assert Test(5) is Test(6)
    assert Test(5).x == 5

    # Check if a different class is instantiated, if it also uses
    # Singleton as metaclass
    class Test2(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    assert Test2(5) is not Test(5)
    assert Test2(5).x == 5

# Generated at 2022-06-11 18:33:06.682314
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, name, age):
            self.name = name
            self.age = age

        @classmethod
        def get_instance(cls):
            return cls.__instance

    ins1 = TestClass('bob', 100)
    ins2 = TestClass('jim', 200)
    ins3 = TestClass.get_instance()
    assert ins1 == ins2 == ins3

    ins3.name = 'tom'
    assert ins1.name == ins2.name == ins3.name
    assert ins1.age == ins2.age == ins3.age



# Generated at 2022-06-11 18:33:15.565145
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from pyasn1.type import univ
    from pyasn1.codec.der.encoder import encode, DEREncoderContext
    from pyasn1.codec.der.decoder import decode, DERDecoderContext

    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, hello):
            self.hello = hello

        def encode(self):
            return univ.OctetString(self.hello + ' world').encode()

        def decode(self, data):
            self.hello = univ.OctetString.decode(data).asOctets()

    # object is only instantiated once
    a = MyClass('hello')
    b = MyClass('ciao')
    assert a.hello == 'hello'
    assert b.hello == 'hello'

# Generated at 2022-06-11 18:33:23.202588
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class test_singleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = list()
        def add_value(self, value):
            self.x.append(value)

    a = test_singleton()
    b = test_singleton()
    b.add_value(1)
    b.add_value(2)
    assert a == b
    assert a.x == b.x

# Generated at 2022-06-11 18:33:27.147264
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.__value = value

    a = A("a")
    assert a.__value == "a"
    assert a is A("b")
    assert A("a") is A("b")
    assert a is A("a")
    assert A("a") is A("a")

# Generated at 2022-06-11 18:33:37.905694
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test for Singleton __call__ method.
    """
    import random
    from threading import Thread
    from time import sleep, time

    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = random.random()

        def __str__(self):
            return 'Class Foo, value {0}.'.format(self.val)

    def worker():
        for i in range(1, 100):
            sleep(0.001)
            print(Foo())

        return

    start = time()
    threads = [Thread(target=worker) for i in range(100)] + \
              [Thread(target=worker) for i in range(100)]
    [t.start() for t in threads]
    [t.join() for t in threads]

   

# Generated at 2022-06-11 18:33:49.610121
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    a = A('a')
    assert isinstance(a, A)
    assert a.foo == 'a'

    b = A('b')
    assert isinstance(b, A)
    assert a is b
    assert b.foo == 'a'

    class B(object):
        __metaclass__ = Singleton
        def __init__(self, foo):
            self.foo = foo

    with A.__rlock:
        c = B('c')
        assert isinstance(c, B)
        assert c.foo == 'c'
        assert not isinstance(c, A)

    d = A('d')
    assert isinstance(d, A)
   

# Generated at 2022-06-11 18:33:53.064756
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self._x = x

    a = Test(1)
    b = Test(2)
    assert a == b

# Generated at 2022-06-11 18:33:54.698648
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTestClass(object):
        __metaclass__ = Singleton

    instance1 = SingletonTestClass()
    instance2 = SingletonTestClass()

    assert instance1 == instance2


# Generated at 2022-06-11 18:33:57.816211
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Moo(object):
        __metaclass__ = Singleton

    assert Moo() is Moo()



# Generated at 2022-06-11 18:34:02.567834
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    cls = Singleton('name', (), {})
    cls.__instance = "name_instance"
    assert cls() == "name_instance"
    cls.__instance = None
    cls.__call__ = "name_call"
    assert cls() == "name_call"
    cls.__instance = "name_instance"
    assert cls() == "name_instance"

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:34:12.281602
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.data = None

        def __call__(self, *args, **kw):
            return self.data

    a = MyClass()
    a.data = 5

    b = MyClass()
    assert a() == b()
    assert id(a) == id(b)
    assert a is b

    c = MyClass()
    assert a() == c()
    assert id(a) == id(c)
    assert a is c

    assert b() == c()
    assert id(b) == id(c)
    assert b is c

# Generated at 2022-06-11 18:34:16.721447
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        value = 0
        def __init__(self, x=0):
            self.value += x

    a1 = A()
    a2 = A(1)
    assert a1.value == 1
    assert a1 == a2
    assert id(a1) == id(a2)



# Generated at 2022-06-11 18:34:23.463879
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, num):
            self.num = num

    # Instantiate two instances (the second is discarded)
    obj1 = TestClass(1)
    obj2 = TestClass(2)

    # Return value of first instance is returned
    assert obj1.num == 1

    # But the second instance was created and assigned to the class attribute
    assert TestClass.__instance.num == 1

# Generated at 2022-06-11 18:34:26.338526
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    instance1 = Test(1)
    instance2 = Test(2)
    assert instance1 is instance2



# Generated at 2022-06-11 18:34:29.817637
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 == test2


# Generated at 2022-06-11 18:34:38.663261
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(metaclass=Singleton):

        def __init__(self):
            self.test = True

    class SingletonTest2(metaclass=Singleton):

        def __init__(self):
            self.test2 = True

    assert SingletonTest() is SingletonTest()
    assert SingletonTest2() is SingletonTest2()
    assert SingletonTest() is not SingletonTest2()
    assert SingletonTest2() is not SingletonTest()
    assert SingletonTest().test is True
    assert SingletonTest2().test2 is True

# pylint: disable=unused-variable

# Generated at 2022-06-11 18:34:42.308999
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1 is t2

# Generated at 2022-06-11 18:34:44.488737
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton():
        __metaclass__ = Singleton

    s1 = MySingleton()
    assert(id(s1) == id(MySingleton()))

# Generated at 2022-06-11 18:34:49.588706
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    class TestClass2(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()
    assert TestClass() is not TestClass2()


# Generated at 2022-06-11 18:34:54.144305
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Obj():
        __metaclass__ = Singleton

    obj1 = Obj()
    obj2 = Obj()

    assert obj1 is obj2
    # End of unit test for method __call__ of class Singleton

# Generated at 2022-06-11 18:35:00.440130
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.created = 1

    obj1 = TestSingleton()
    obj2 = TestSingleton()

    assert(obj1.created)
    assert(obj1 is obj2)


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:35:05.591603
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  class A(object):
    __metaclass__ = Singleton
    def __init__(self, x):
      self.x = x
  a = A(1)
  b = A(2)
  assert(a==b)
  assert(a.x==1)

# Generated at 2022-06-11 18:35:09.443237
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()

    assert a1 is a2
    assert a1.a == a2.a



# Generated at 2022-06-11 18:35:17.292513
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import six
    import tests.support.unit as unit

    global_val = None

    # Test to make sure Singleton only returns a single instance
    @six.add_metaclass(Singleton)
    class TestClass(object):

        def __init__(self, global_val_mod=None):
            if global_val_mod is not None:
                global global_val
                global_val = global_val_mod

        def value(self):
            global global_val

            return global_val

    # Create a test class, then call it several times with different values.
    # We should only get back the same instance, but all of the values should
    # be reflected in the result of the value() method.
    obj1 = TestClass(global_val_mod="one")

# Generated at 2022-06-11 18:35:22.951339
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Make sure we have working version of __call__
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, value=0):
            self.value = value
    # Now we can test
    tc1 = TestClass()
    assert tc1.value == 0
    tc1.value = 5
    tc2 = TestClass()
    assert tc2.value == 5
    tc3 = TestClass(-1)
    assert tc3.value == 5

# Generated at 2022-06-11 18:35:32.635055
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return self.name

        def __eq__(self, other):
            return True if self.name == other.name else False

    a = TestSingleton('a')
    b = TestSingleton('b')
    c = TestSingleton('c')

    assert a == b
    assert b == c
    assert c == a

    assert a is b
    assert b is c
    assert c is a


# Generated at 2022-06-11 18:35:36.768948
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    a = A()
    b = A()
    assert a is b
    a.x = 2
    assert a.x == b.x == 2



# Generated at 2022-06-11 18:35:38.717911
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(metaclass=Singleton):
        pass

    assert C() is C()



# Generated at 2022-06-11 18:35:47.146130
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        def __init__(self):
            self.a = 1

    first_instance = Foo()
    second_instance = Foo()

    assert first_instance is second_instance
    assert id(first_instance) == id(second_instance)
    assert first_instance.a == 1
    assert second_instance.a == 1
# vim: sts=4 sw=4 et

# Generated at 2022-06-11 18:35:50.725857
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestClass(object):
        __metaclass__ = Singleton

    t1 = TestClass()
    t2 = TestClass()
    assert t1 == t2, "Failed on Singleton.__call__"


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:35:53.239315
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    a = SingletonTest()
    b = SingletonTest()

    def test():
        assert a is b
    test()

# Generated at 2022-06-11 18:35:58.035270
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = "A"
        def __eq__(self, other):
            return self.name == other.name
    a = A()
    b = A()
    assert a == b


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:36:01.413682
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, *args):
            self.args = args

    t1 = TestClass('a', 'b', 'c')
    assert t1.args == ('a', 'b', 'c')

    t2 = TestClass('x', 'y', 'z')
    assert t2.args == ('a', 'b', 'c')
    assert t1 is t2


singleton = Singleton

# Generated at 2022-06-11 18:36:03.005646
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test01(object):
        __metaclass__ = Singleton
    assert Test01() == Test01()

# Generated at 2022-06-11 18:36:11.379230
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.num = 0

        def __repr__(self):
            return 'object A(%s,%s)' % (self.args, self.kwargs)

        def function(self):
            self.num += 1
            return self.num

    a = A(1, 2, a=3, b=4)
    b = A(5, 6, a=7, b=8)

    assert a == b
    assert a.function() == 1
    assert a.function() == 2



# Generated at 2022-06-11 18:36:20.637384
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    import random
    import time

    class TestClass(metaclass=Singleton):
        def __init__(self):
            self.value = random.randint(1, 100)

        def square(self):
            return self.value * self.value

    class TestSingleton(unittest.TestCase):
        def setUp(self):
            self.a = TestClass()
            self.b = TestClass()

        def testEquality(self):
            self.assertTrue(self.a is self.b)

        def testSquare(self):
            self.assertEqual(self.a.square(), self.b.square())

    class TestSingletonMultiThreading(unittest.TestCase):
        def setUp(self):
            self.instances = []


# Generated at 2022-06-11 18:36:22.871747
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 == test2
    assert test1 is test2

# Generated at 2022-06-11 18:36:29.774027
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''
    Test Case:
        Special method __call__
    Test Procedure:
        1. verify that class Singleton.__call__() works properly
    Expected Results:
        1. always return the same object for a class that has metaclass
           Singleton
    '''
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()

    assert a1 is a2
    assert b1 is b2
    assert a1 is not b1

# Generated at 2022-06-11 18:36:40.904155
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class CSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    s = CSingleton()
    assert(s is CSingleton())
    assert(s is CSingleton())
    assert(s is CSingleton())
    assert(s is CSingleton())



# Generated at 2022-06-11 18:36:51.965121
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test for instantiation of a singleton class
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()
    assert Test() is Test()

    # Test if singleton class can be instantiated multiple
    # times when optional class parameter is set
    class Test2(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            self.kwargs = kwargs

    class_arg = 'test_class_argument'
    assert Test2(test_class_arg=class_arg).kwargs['test_class_arg'] is class_arg

    assert Test2('test_class_arg_0', 'test_class_arg_1', test_class_arg=class_arg).kwargs['test_class_arg'] is class_arg

# Generated at 2022-06-11 18:36:56.384684
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2


# Generated at 2022-06-11 18:37:06.899456
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(metaclass=Singleton):
        def __init__(self, *args):
            self.args = args

    # Should call __init__
    instance = MySingleton('first argument', 'second argument')
    assert isinstance(instance, MySingleton)
    assert len(instance.args) == 2
    assert instance.args[0] == 'first argument'
    assert instance.args[1] == 'second argument'

    # Should not call __init__
    instance = MySingleton()
    assert isinstance(instance, MySingleton)
    assert len(instance.args) == 2
    assert instance.args[0] == 'first argument'
    assert instance.args[1] == 'second argument'


# Generated at 2022-06-11 18:37:10.731262
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test_var = 0
    test_instance = TestSingleton()
    assert test_instance is TestSingleton()
    test_instance.test_var = 2
    assert 2 is TestSingleton().test_var


# Generated at 2022-06-11 18:37:13.203480
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class F(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    c = F()
    assert id(c) == id(F())


# Generated at 2022-06-11 18:37:15.685244
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a = A(1)
    b = A(2)
    assert a is b


# Generated at 2022-06-11 18:37:18.546176
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    obj_1 = MyClass()
    obj_2 = MyClass()
    assert obj_1 is obj_2

# Generated at 2022-06-11 18:37:21.959883
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 0

    a = A()
    a.value = 1
    assert id(a) == id(A())
    assert A().value == 1


# Generated at 2022-06-11 18:37:24.024981
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    instance = Singleton.__call__()
    assert(instance is Singleton.__instance)
    assert(isinstance(instance, Singleton))

# Generated at 2022-06-11 18:37:52.425476
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import textwrap

    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            import inspect
            import os

            self.init_data = {
                'func': inspect.stack()[0][3],
                'pid': os.getpid()
            }
            self.invoked_with = [args, kwargs]

    args = ('Foo', 42)
    kwargs = {'bar': 'BAR', 'baz': 'BAZ'}

    class TestSingleton2(TestSingleton):
        pass

    # Verify that the first TestSingleton instance is the same as the
    # second one
    ts = TestSingleton(*args, **kwargs)
    ts2 = TestSingleton()

# Generated at 2022-06-11 18:37:55.882903
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_instance = TestSingleton()
    assert test_instance == TestSingleton()
    assert test_instance is TestSingleton()

# Generated at 2022-06-11 18:38:02.981828
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    Method __call__ of class Singleton should return only one
    instance of the class when __call__ method is called.
    """
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, id):
            self.id = id

    # First call
    first = TestSingleton('first')
    # Second call
    second = TestSingleton('second')
    # Third call
    third = TestSingleton('third')

    assert first.id == second.id == third.id
    assert first is second is third



# Generated at 2022-06-11 18:38:06.467373
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class T(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    assert T(5) is T(6)
    assert T(5).a == 5



# Generated at 2022-06-11 18:38:14.049732
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    old_instance = my_singleton_class_instance

    try:
        my_singleton_class = Singleton('MySingletonClass', (object,), {})
        my_singleton_class_instance = my_singleton_class()
        print(id(my_singleton_class_instance))
        #new_instance = my_singleton_class()
        #print(id(new_instance))
    finally:
        my_singleton_class_instance = old_instance


# Singleton class
my_singleton_class = Singleton('MySingletonClass', (object,), {})
my_singleton_class_instance = my_singleton_class()

# Generated at 2022-06-11 18:38:17.517251
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    obj1 = A()
    obj2 = A()

    assert obj1 == obj2
    assert obj1.a == 1
    assert obj2.a == 1

    obj1.a = 2
    assert obj2.a == 2



# Generated at 2022-06-11 18:38:19.970651
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonClass(object):
        __metaclass__ = Singleton

    s1 = SingletonClass()
    s2 = SingletonClass()

    assert id(s1) == id(s2)

# Generated at 2022-06-11 18:38:27.365033
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = 1

    assert A().a == 1
    assert id(A()) == id(A())


if __name__ == "__main__":
    import sys
    import inspect
    import unittest

    # Unit tests for this module
    class TestSingleton(unittest.TestCase):
        def test___call__(self):
            # run unit tests for method __call__ of class Singleton
            test_Singleton___call__()

    # run the unit tests
    unittest.main()

# Generated at 2022-06-11 18:38:30.775131
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(metaclass=Singleton):
        def __init__(self, *args):
            self.args = args or None

    singleton = SingletonTest('test')
    assert singleton.args == 'test'
    singleton_ = SingletonTest()
    assert singleton == singleton_ and singleton is singleton_

# Generated at 2022-06-11 18:38:34.668223
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 0

        def incr(self):
            self.value += 1

    t1 = TestSingleton()
    t2 = TestSingleton()

    t1.incr()
    assert t2.value == 1

# Generated at 2022-06-11 18:39:18.673780
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyTestSingleton(object):
        __metaclass__ = Singleton

    myTestSingleton = MyTestSingleton()
    myTestSingleton2 = MyTestSingleton()
    assert myTestSingleton is myTestSingleton2



# Generated at 2022-06-11 18:39:22.056237
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Bar(object):
        __metaclass__ = Singleton

    class Foo(Bar):
        pass

    assert Bar() is Bar()
    assert Foo() is Foo()
    assert Bar() is not Foo()
    assert Foo() is not Bar()
    assert Bar.__instance is Foo()
    assert Foo.__instance is Foo()
    assert Bar.__instance is not Bar()
    assert Foo.__instance is not Bar()

# Generated at 2022-06-11 18:39:27.160680
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 0

        def set(self, val):
            self.foo = val

        def get(self):
            return self.foo

    c1 = Foo()
    c1.set(1)
    c2 = Foo()
    c2.set(2)
    c3 = Foo()
    assert c3.get() == 2
    assert c3 is c1

# Generated at 2022-06-11 18:39:30.051054
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class tester(object):
        __metaclass__ = Singleton

    a = tester()
    b = tester()
    return a is b

# Generated at 2022-06-11 18:39:41.465697
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from six import PY2

    if PY2:
        from mock import MagicMock, patch
    else:
        from unittest.mock import MagicMock, patch

    with patch('ansible.utils.singleton.RLock') as mock_rlock_class:
        mock_rlock = MagicMock()
        mock_rlock_class.return_value = mock_rlock

        class mock_super_class:
            def __init__(self, *args, **kwargs):
                pass

            def __call__(self, *args, **kwargs):
                return 'the_return_value'

        mock_super = MagicMock()
        mock_super.return_value = mock_super_class()

        class mock_cls:
            __instance = None
            __rlock = None


# Generated at 2022-06-11 18:39:46.731467
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Let's create a singleton
    class MySingleton(object):
        __metaclass__ = Singleton

    sing1 = MySingleton()
    # Let's create another instance
    sing2 = MySingleton()

    # We can be sure that sing1 and sing2 are the same instance
    assert id(sing1) == id(sing2)

    # So, we can be sure that sing1 and sing2 are the same instance
    assert id(sing1) == id(sing2)



# Generated at 2022-06-11 18:39:55.004175
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs

        def __repr__(self):
            return '<Test %r %r>' % (self._args, self._kwargs)

    assert Test(1,2,3, **{'a': 'b'}) is Test(1,2,3, **{'a': 'b'})
    assert Test(**{'a': 'b'}) is Test(**{'a': 'b'})
    assert Test(1, **{'a': 'b'}) is Test(1, **{'a': 'b'})

# Generated at 2022-06-11 18:39:59.672391
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 'a'

    a1 = A()
    a2 = A()

    assert a1 is a2
    assert a1.a == 'a'
    assert a2.a == 'a'


# Generated at 2022-06-11 18:40:04.154406
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo:
        __metaclass__ = Singleton

    class Bar:
        pass

    foo = Foo()
    foo1 = Foo()
    bar = Bar()
    bar1 = Bar()

    assert foo is foo1, "Foo should be singleton"
    assert bar is not bar1, "Bar shouldn't be singleton"

# Generated at 2022-06-11 18:40:09.569665
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # pylint: disable=unused-variable
    import mock

    class Test(metaclass=Singleton):
        def __init__(self, *args, **kwargs):
            super(Test, self).__init__()

    assert Test(1, 2) == Test(3, 4)

    # Test will always return the first instance

