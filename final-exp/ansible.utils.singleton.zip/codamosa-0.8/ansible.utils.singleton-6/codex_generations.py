

# Generated at 2022-06-11 18:31:40.948178
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1
            self.b = 2
            self.x = ['foo', 'bar']
            self.y = set(['foo', 'bar'])

    c1 = Test()
    c2 = Test(a=10, b=20, x=['foo1', 'bar2'], y=set(['foo3', 'bar4']))

    assert c1 is c2
    assert all(c1.a == c2.a, c1.b == c2.b)
    assert c1.x == c2.x
    assert c1.y == c2.y

# Generated at 2022-06-11 18:31:43.159099
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        pass

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-11 18:31:47.124304
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestMe(object):
        __metaclass__ = Singleton

        def __init__(self, text):
            self.text = text
    assert (TestMe('one') is TestMe('two'))

# Generated at 2022-06-11 18:31:51.110547
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    obj = A(1)
    assert obj.value == 1
    obj_new = A(2)
    assert obj_new.value == 1


# Example of usage

# Generated at 2022-06-11 18:32:00.444334
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs

    obj1 = Test(1, 2, 3)
    obj2 = Test(4, 5, 6)

    assert obj1 is obj2
    assert obj1._args == (1, 2, 3)
    assert obj2._args == (1, 2, 3)
    assert obj1._kwargs == {}
    assert obj2._kwargs == {}


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:32:06.991586
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # 1st dummy class
    class Dummy(object):
        __metaclass__ = Singleton
        def __init__(self, name=''):
            self.name = name

    d1 = Dummy('Dummy1')
    d2 = Dummy('Dummy2')

    assert d1 is d2
    assert d1.name == 'Dummy2'

    # 2nd dummy class
    class Dummy2(object):
        __metaclass__ = Singleton
        def __init__(self, name=''):
            self.name = name
        def dummy_func(self, param):
            return 'Dummy2Func. Param: %s' % param

    d21 = Dummy2('Dummy21')
    d22 = Dummy2('Dummy22')

    assert d21 is d22
   

# Generated at 2022-06-11 18:32:15.562750
# Unit test for constructor of class Singleton
def test_Singleton():
    class ClassA(metaclass=Singleton):
        def __init__(self):
            self.var1 = "var1"
            self.var2 = "var2"
            # Just to test private variable
            self._var3 = "var3"

        def public_method(self):
            pass

        def public_method2(self, arg1, arg2):
            pass

    print("Testing Singleton")
    print("Creating class instance")
    obj = ClassA()
    obj2 = ClassA()
    print("Instance1:", obj)
    print("Instance2:", obj2)

    assert obj is obj2

    print("Instance type:", type(obj))
    print("Instance vars:", dir(obj))
    assert hasattr(obj, "public_method")

# Generated at 2022-06-11 18:32:19.630596
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    cls1 = MyClass()
    cls2 = MyClass()

    assert id(cls1) == id(cls2)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:32:23.210937
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo:
        __metaclass__ = Singleton

    inst1 = Foo()
    inst2 = Foo()

    assert inst1 == inst2


# Generated at 2022-06-11 18:32:28.397151
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

    assert Foo() == Foo(), "Singletons should be equal"
    assert Bar() == Bar(), "Singletons should be equal"
    assert Foo() != Bar(), "Singletons should not be equal"



# Generated at 2022-06-11 18:32:36.405943
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import random
    import threading

    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = random.randint(0, 100)

    def test():
        a = Test()
        b = Test()

        assert a.x == b.x

    num_threads = 10
    threads = [threading.Thread(target=test) for _ in range(num_threads)]

    for t in threads:
        t.start()

    for t in threads:
        t.join()

# Generated at 2022-06-11 18:32:41.527808
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            pass

        def some_greeting(self):
            return "Hello world!"


    assert A().some_greeting() == "Hello world!"
    assert A() is A()

# Generated at 2022-06-11 18:32:47.951979
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A():
        __metaclass__ = Singleton
        def __init__(self, v=None):
            self.v = v

    a1 = A(1)
    a2 = A()
    a3 = A()

    assert(a1 == a2 and a2 == a3)
    assert(a1.v == a2.v and a2.v == a3.v)


# Generated at 2022-06-11 18:32:53.536658
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    # Creating first instance
    a = TestSingleton()
    # Creating second instance
    b = TestSingleton()
    # assert that references point to the same instance
    assert(a is b)



# Generated at 2022-06-11 18:32:55.206053
# Unit test for constructor of class Singleton
def test_Singleton():
    class Tmp(object):
        __metaclass__ = Singleton



# Generated at 2022-06-11 18:32:57.390437
# Unit test for constructor of class Singleton
def test_Singleton():
    test = Singleton('test', (object,), {})
    assert test('test', (object,), {}) == test('test', (object,), {})

# Generated at 2022-06-11 18:33:05.118760
# Unit test for constructor of class Singleton
def test_Singleton():
    from sosco import Singleton
    from sosco.sos_colletor import SOSCollector
    class TestSingleton(SOSCollector, metaclass=Singleton):
        def __init__(self):
            super(TestSingleton, self).__init__()
            self.val = 1
    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1.val == 1
    test1.val += 1
    assert test2.val == 2

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:33:07.468627
# Unit test for constructor of class Singleton
def test_Singleton():
    class Empty(object):
        __metaclass__ = Singleton

    e1 = Empty()
    e2 = Empty()

    assert e1 is e2
    assert e1 is Empty()

# Generated at 2022-06-11 18:33:11.379798
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonA(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a1 = SingletonA()
    a2 = SingletonA()
    assert a1 is a2


# Generated at 2022-06-11 18:33:13.134566
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Singleton metadata
    class SingletonTest(object):
        __metaclass__ = Singleton
    # TODO FIXME
    # assert SingletonTest() is SingletonTest()

# Generated at 2022-06-11 18:33:26.143909
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class DummyClass(metaclass=Singleton):
        class_var = 0
        def __init__(self):
            self.instance_var = 0

        def reset(self):
            self.instance_var = 0

        def inc_instance_var(self):
            self.instance_var += 1

        def inc_class_var(self):
            self.class_var += 1

    d = DummyClass()
    c = DummyClass()

    assert d == c, "Two instances of dummy class should be equal"

    d_id = id(d)
    c_id = id(c)

    assert d_id == c_id, "Both instances of the dummy class have the same id"

    d.inc_class_var()
    d.inc_instance_var()
    d.inc_instance_var

# Generated at 2022-06-11 18:33:30.383687
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    foo1 = Foo()
    foo2 = Foo()
    assert id(foo1) == id(foo2)



# Generated at 2022-06-11 18:33:36.794975
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Base(object):
        pass

    class Example(Base):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    assert issubclass(Example, Base)
    e1 = Example()
    e2 = Example()
    assert e1 is e2
    assert e1.value == 0
    e1.value = 1
    assert e1.value == e2.value



# Generated at 2022-06-11 18:33:47.147293
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import random    
    class A(object):
        __metaclass__ = Singleton
        
        def __init__(self,x=None,y=None):
            if x:
                self.x = x
            else:
                self.x = random.random()
            if y:
                self.y = y
            else:
                self.y = random.random()
                
    obj1 = A()
    obj2 = A()
    assert(obj1 == obj2)
    
    obj1 = A(x=42,y=43)
    obj2 = A()
    assert(obj1 == obj2)
    assert(obj1.x == 42)
    assert(obj2.x == 42)
    
    obj1 = A(x=42,y=43)

# Generated at 2022-06-11 18:33:51.848082
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    obj = Test(10)
    assert obj.value == 10
    obj = Test(100)
    assert obj.value == 10

# Generated at 2022-06-11 18:34:01.336883
# Unit test for constructor of class Singleton
def test_Singleton():
    class Singleton1(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a
            self.count = 0
        def foo(self):
            self.count += 1

    assert not hasattr(Singleton1, '__instance')

    s1 = Singleton1(1)
    assert hasattr(Singleton1, '__instance')
    assert s1 is Singleton1.__instance
    assert s1.count == 0
    s1.foo()
    assert s1.count == 1

    s2 = Singleton1(2)
    assert hasattr(Singleton1, '__instance')
    assert s2 is Singleton1.__instance
    assert s2.count == 1
    s2.foo()
    assert s2.count == 2

test

# Generated at 2022-06-11 18:34:05.502037
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Class(object):
        '''Class for testing singleton class for method __call__'''
        __metaclass__ = Singleton

    first_instance = Class()
    second_instance = Class()

    #test instance of class
    assert first_instance is not None
    assert second_instance is not None

    #test returned instances are identical
    assert first_instance is second_instance

    #test that they are of the same class
    assert isinstance(first_instance, Class)
    assert isinstance(second_instance, Class)

# Generated at 2022-06-11 18:34:08.237342
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    assert MyClass() is MyClass()



# Generated at 2022-06-11 18:34:14.906094
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    class TestClass1(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 2

    test1 = TestClass()
    test2 = TestClass()
    test3 = TestClass1()
    assert test1.x == 1
    assert test2.x == 1
    assert test3.x == 2

# Generated at 2022-06-11 18:34:25.081106
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test1(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    class Test2(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    class Test3(object):
        __metaclass__ = Singleton

    t1 = Test1()
    t11 = Test1()
    assert t1 is t11
    assert t1.a == 1
    assert t11.a == 1

    t2 = Test2(a=2)
    t22 = Test2(a=2)
    assert t2 is t22
    assert t2.a == 2
    assert t22.a == 2

    t3 = Test3()
    t33 = Test3()
    assert t

# Generated at 2022-06-11 18:34:30.029115
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass():
        __metaclass__ = Singleton
    t1 = TestClass()
    t2 = TestClass()
    assert t1 == t2

# Generated at 2022-06-11 18:34:36.134136
# Unit test for constructor of class Singleton
def test_Singleton():
    class c1(object):
        __metaclass__ = Singleton

    class c2:
        __metaclass__ = Singleton

    for cls in [c1, c2]:
        x = cls()
        assert(x is cls())


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:34:37.905465
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test() is Test()
# /Unit test



# Generated at 2022-06-11 18:34:41.761040
# Unit test for constructor of class Singleton
def test_Singleton():
    class Thing(object):
        __metaclass__ = Singleton

    a = Thing()
    b = Thing()
    if a is not b:
        raise ValueError("Singleton not working")



# Generated at 2022-06-11 18:34:50.850202
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase
    from unittest import mock
    from unittest.mock import call

    class TestClass(metaclass=Singleton):
        def __init__(self):
            self.init_called = True
            self.super_init_called = False

        def foo(self):
            pass

        def __eq__(self, other):
            return True

    class TestClass2(TestClass):
        def __init__(self):
            super(TestClass2, self).__init__()
            self.super_init_called = True

    # Test 1
    # Testing with a new class.
    with mock.patch.object(TestClass, '__init__', return_value=None) as mock_init:
        obj = TestClass()

        assert isinstance(obj, TestClass)


# Generated at 2022-06-11 18:34:58.297453
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        pass
    class Bar(metaclass=Singleton):
        def __init__(self, arg):
            self.arg = arg
    f = Foo()
    f2 = Foo()
    b = Bar(5)
    b2 = Bar(6)
    assert(f == f2)
    assert(b == b2)
    assert(b.arg == 6)
    assert(b2.arg == 6)

# Project euler problem 7
# What is the 10,001st prime number?
# Bob Belderbos
# http://www.bobbelderbos.com/2013/07/project-euler-7-10001st-prime/

# Generated at 2022-06-11 18:35:00.440389
# Unit test for constructor of class Singleton
def test_Singleton():
  class A(metaclass=Singleton):
    pass
  a=A()
  b=A()
  assert a is b

# Generated at 2022-06-11 18:35:04.920399
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    @add_metaclass(Singleton)
    class A(object):
        pass

    a1 = A()
    a2 = A()

    assert a1 is a2


# Generated at 2022-06-11 18:35:10.797845
# Unit test for constructor of class Singleton
def test_Singleton():
    class E(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

        def __repr__(self):
            return "<E: x=%s>" % self.x

    assert E(1) == E(2)
    assert E(3) == E(3)
    assert E(4) == E(5)
    assert E(6) == E(2)
    assert E(6) == E(7)

# Generated at 2022-06-11 18:35:18.327146
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    test_1 = SingletonTest(1)
    assert test_1.value == 1

    test_2 = SingletonTest(2)
    assert test_2.value == 1

# Generated at 2022-06-11 18:35:28.753046
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            # Make sure that constructor is called only once
            self.i = 1

        def increment(self):
            self.i += 1

    a = A()
    b = A()

    print('a = ' + str(a.i))
    print('b = ' + str(b.i))

    a.increment()
    print('a = ' + str(a.i))
    print('b = ' + str(b.i))


# Generated at 2022-06-11 18:35:33.970512
# Unit test for constructor of class Singleton
def test_Singleton():
    class A():
        __metaclass__ = Singleton
        def __init__(self, msg):
            self.msg = msg

    a1 = A("Hello World")
    a2 = A("Hello World")
    print (a1, a2)
    assert a1 is a2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:35:38.093730
# Unit test for constructor of class Singleton
def test_Singleton():
    myclass = Singleton('MyClass', (object,), {})
    assert id(myclass) == id(Singleton('MyClass', (object,), {}))

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:35:42.383684
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    s = S()
    assert s.a == 1

    t = S()
    assert t.a == 1


# Generated at 2022-06-11 18:35:46.296276
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # First instance
    class TestSingleton(object):
        __metaclass__ = Singleton
    ts1 = TestSingleton()

    # Second instance
    ts2 = TestSingleton()

    if ts1 is not ts2:
        raise AssertionError("Singleton class is not a singleton.")



# Generated at 2022-06-11 18:35:51.061467
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    assert isinstance(MyClass(), MyClass)
    assert id(MyClass()) == id(MyClass())
    assert id(MyClass()) != id(MyClass(1))
    assert id(MyClass()) != id(MyClass(x=1))
    assert id(MyClass(1)) != id(MyClass(x=1))


# Generated at 2022-06-11 18:35:57.640998
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self, a=None):
            self.a = a
            self.call_by_a = 0
            self.call_by_b = 0

        def call_by(self, caller):
            if caller == 'a':
                self.call_by_a += 1
            elif caller == 'b':
                self.call_by_b += 1

    a = A(10)
    a.call_by('a')
    a.call_by('b')

    b = A(20)
    b.call_by('a')
    b.call_by('b')

    assert b is a
    assert b.a == 10
    assert b.call_by_a == 2
    assert b.call_by_b == 2



# Generated at 2022-06-11 18:35:59.633823
# Unit test for constructor of class Singleton
def test_Singleton():
    assert not hasattr(Singleton, '__instance')
    assert not hasattr(Singleton, '__rlock')


import json

# Generated at 2022-06-11 18:36:02.125046
# Unit test for constructor of class Singleton
def test_Singleton():
    class Example(metaclass=Singleton):
        pass

    example1 = Example()
    example2 = Example()

    assert example1 == example2
    assert example1 is example2

# Generated at 2022-06-11 18:36:04.573542
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 == a2



# Generated at 2022-06-11 18:36:10.365402
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class X(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    x1 = X()
    x2 = X()
    assert x1 is x2

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:36:16.530883
# Unit test for constructor of class Singleton
def test_Singleton():
    class a(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("Object created")
            self.val = 5
    x = a()
    y = a()
    assert id(x) == id(y)
    print("ID of x: %d" %id(x))
    print("ID of y: %d" %id(y))

# To check if metaclasses can be inherited, define the Singleton class
# as an inner class of another class, and see if it creates instances
# correctly.

# Generated at 2022-06-11 18:36:19.768335
# Unit test for constructor of class Singleton
def test_Singleton():
    class T(metaclass=Singleton):
        pass

    t1 = T()
    t2 = T()

    assert id(t1) == id(t2)

# Generated at 2022-06-11 18:36:21.681886
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self):
            pass

    first = Foo()
    second = Foo()
    assert first is second

# Generated at 2022-06-11 18:36:29.389820
# Unit test for constructor of class Singleton
def test_Singleton():

    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, val=1):
            self.val = val

    class MySubClass(MyClass):
        pass

    assert MyClass() is MyClass()
    assert MyClass().val == 1

    a = MyClass(2)
    b = MyClass(3)
    assert a is not b
    assert b is MyClass()
    assert b.val == 3

    c = MySubClass()
    d = MySubClass()
    assert a is not c
    assert c is d
    assert b is a
    assert c is MyClass()
    assert c.val == 3



# Generated at 2022-06-11 18:36:31.876900
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    instance = Singleton()
    assert instance.__rlock is not None
    assert instance.__instance is None
    instance()
    assert instance.__instance is not None


# Generated at 2022-06-11 18:36:36.575078
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    # instantiate an object
    object1 = Foo(a='a', b='b')

    # instantiate another object
    object2 = Foo(a='a', b='b')

    assert object1 is object2

# vim: filetype=python

# Generated at 2022-06-11 18:36:39.981999
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    instance1 = SingletonClass()
    instance2 = SingletonClass()
    assert instance1 is instance2

# Generated at 2022-06-11 18:36:41.915569
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    x = Test()
    assert x == Test()



# Generated at 2022-06-11 18:36:47.287188
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    counter = 0

    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            global counter
            counter += 1

    mc1 = MyClass()
    mc2 = MyClass()

    assert mc1 is mc2
    assert counter == 1

# Generated at 2022-06-11 18:36:50.101465
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-11 18:36:52.801820
# Unit test for constructor of class Singleton
def test_Singleton():
    import pytest

    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert(a == b)

# Generated at 2022-06-11 18:36:55.503329
# Unit test for constructor of class Singleton
def test_Singleton():
    class Person(object):
        __metaclass__ = Singleton

    joe = Person()
    mary = Person()
    assert joe is mary

# Generated at 2022-06-11 18:36:57.826924
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonExample(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 5

    assert SingletonExample() == SingletonExample()

# Generated at 2022-06-11 18:36:59.052734
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    f = Foo()

# Generated at 2022-06-11 18:37:10.091477
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # monkey patching __call__ of class A
    class A:
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    # creating the first instance
    a1 = A(1, 2, kwarg1=True, kwarg2=False)

    # getting an instance of A, this time using keyword arguments
    a2 = A(kwarg1=False, kwarg2=True)

    # a2 should be the same as a1
    print('a1: {0}, {1}'.format(a1.args, a1.kwargs))
    print('a2: {0}, {1}'.format(a2.args, a2.kwargs))


# Generated at 2022-06-11 18:37:16.889478
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.var = 0

        def incvar(self, num = 1):
            self.var = self.var + num
            return self.var

    import unittest
    class TestSingleton(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_it(self):
            t1 = TestClass()
            self.assertEqual(t1.var, 0)
            t1.incvar(5)
            self.assertEqual(t1.var, 5)
            t2 = TestClass()
            self.assertEqual(t2.var, 5)
            t2.incvar(7)

# Generated at 2022-06-11 18:37:25.551769
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    a = MyClass()
    b = MyClass()

    assert a is b

    a.inc()
    b.inc()

    assert a.value == 2
    assert b.value == 2

    a = MySingleton()
    b = MySingleton()

    assert a is b

    a.inc()
    b.inc()

    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-11 18:37:27.932972
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()

    assert id(foo1) == id(foo2)



# Generated at 2022-06-11 18:37:31.250247
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    # a2 should be same instance as a1
    assert a1 is a2



# Generated at 2022-06-11 18:37:38.601858
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            pass

    test_instance = TestSingleton()

    assert test_instance is TestSingleton()
    assert id(test_instance) == id(TestSingleton())

#Unit test for constructor of class Singleton

# Generated at 2022-06-11 18:37:40.962911
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1(metaclass=Singleton):
        pass

    a = Test1()
    b = Test1()
    assert(a == b)
    assert(id(a) == id(b))


# Generated at 2022-06-11 18:37:44.704421
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    s1 = MySingleton()
    assert s1 is MySingleton()
    assert MySingleton() is MySingleton()

# Generated at 2022-06-11 18:37:51.914575
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 0

        def add(self, j):
            self.i += j

    st1 = SingletonTest()
    st2 = SingletonTest()
    if (st1 == st2):
        print("Same object")
        st2.add(10)
        print("counter = ", st1.i)
    else:
        print("Different object")

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:37:55.845221
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    f1 = Foo()
    f2 = Foo()
    assert f1 is f2



# Generated at 2022-06-11 18:38:01.671742
# Unit test for constructor of class Singleton
def test_Singleton():
    class Example(object):
        __metaclass__ = Singleton

    class NonSingleton(object):
        pass

    e1 = Example()
    e2 = Example()
    e3 = Example()
    assert e1 is e2
    assert e1 is e3
    assert e2 is e3

    e1 = NonSingleton()
    e2 = NonSingleton()
    assert e1 is not e2

# Generated at 2022-06-11 18:38:11.213771
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print("====== Singleton method __call__ test start ======")
    class SingletonTest(object):
        __metaclass__ = Singleton
        def test(self):
            return 1

    singleton1 = SingletonTest()
    singleton2 = SingletonTest()
    assert singleton1 is singleton2
    assert singleton1.test() == singleton2.test()

    class SingletonTest2(object):
        __metaclass__ = Singleton
        def test(self, a):
            return a

    singleton3 = SingletonTest2(1)
    singleton4 = SingletonTest2(2)
    assert singleton3 is singleton4
    assert singleton3.test(1) == singleton4.test(2)
    assert singleton3.test(1) == 1


# Generated at 2022-06-11 18:38:12.562131
# Unit test for constructor of class Singleton
def test_Singleton():
    assert issubclass(Singleton, type)


# Generated at 2022-06-11 18:38:15.463155
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    my_first_instance = TestSingleton()
    my_second_instance = TestSingleton()

    assert my_first_instance is my_second_instance


# Unit test that the Singleton pattern works when the Singleton class is
# inherited from other classes.

# Generated at 2022-06-11 18:38:19.465932
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    instance1 = MyClass('foo')
    instance2 = MyClass('bar')

    assert instance1.val == 'foo'
    assert instance2.val == 'foo'

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:38:27.222630
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.module_utils.common.collections import Singleton, SomeOtherClass

    class Test(SomeOtherClass, metaclass=Singleton):
        def __init__(self):
            pass

    t1 = Test()
    t2 = Test()
    assert t1 == t2

# Generated at 2022-06-11 18:38:30.121006
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Foo(object):
        __metaclass__ = Singleton

    # create a new instance of the class Foo
    foo1 = Foo()
    foo2 = Foo()

    # Check if the same instance is returned
    assert(foo1 == foo2)



# Generated at 2022-06-11 18:38:33.170508
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    tmp1 = Test()
    tmp2 = Test()
    assert tmp1 is tmp2
    tmp1 = Test()
    tmp2 = Test()
    assert tmp1 is tmp2



# Generated at 2022-06-11 18:38:36.053649
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestableClass(object):
        __metaclass__ = Singleton

    tc1 = TestableClass()
    tc2 = Testabl

# Generated at 2022-06-11 18:38:39.421294
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
    assert Foo() == Foo()
    assert Foo.__instance is not None


# usage:
# class Bar(object):
#   __metaclass__ = Singleton
#
# assert Bar() == Bar()

# Generated at 2022-06-11 18:38:42.815106
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 is a2



# Generated at 2022-06-11 18:38:50.517713
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Class1(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    class Class2(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 2

    class Class3(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 3

    # Verify that Singleton functionality works
    assert Class1() is Class1()
    assert Class2() is Class2()
    assert Class3() is Class3()

    # Verify that Singleton functionality does not leak
    assert Class1() is not Class2()
    assert Class1() is not Class3()
    assert Class2() is not Class3()
    assert Class2() is not Class1()
    assert Class

# Generated at 2022-06-11 18:38:58.940432
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test class with Singleton metaclass
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    a1 = A('a1')
    a2 = A('a2')
    assert id(a1) == id(a2)
    assert a1.name == 'a1'
    assert a1.name == a2.name

    # Test class without Singleton metaclass
    class B(object):
        def __init__(self, name):
            self.name = name

    b1 = B('b1')
    b2 = B('b2')
    assert id(b1) != id(b2)
    assert b1.name == 'b1'
    assert b2.name == 'b2'

# Generated at 2022-06-11 18:39:07.649010
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = None

    test_class = TestClass()
    assert isinstance(test_class, TestClass)
    assert test_class.value is None

    test_class.value = 'test_value'
    assert test_class.value == 'test_value'

    test_class2 = TestClass()
    assert test_class is test_class2

    assert test_class2.value == 'test_value'

    # change value via test_class
    test_class.value = 'test_value_new'
    assert test_class2.value == 'test_value_new'

# Generated at 2022-06-11 18:39:10.666984
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)


# Generated at 2022-06-11 18:39:24.123325
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    singleton1 = MySingleton()
    assert singleton1 is MySingleton()
    assert True


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:39:27.465185
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonClass(object):
        __metaclass__ = Singleton

    # Instantiate the class
    obj1 = SingletonClass()
    obj2 = SingletonClass()
    assert obj1 is obj2

    # Modify its attribute
    obj1.foo = True
    assert obj1.foo == obj2.foo



# Generated at 2022-06-11 18:39:32.882167
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, a_parameter=None):
            self.a_parameter = a_parameter

    s1 = MySingleton('foo')
    s2 = MySingleton()
    assert s1 is s2




# Generated at 2022-06-11 18:39:40.721981
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    test_instance = TestSingleton(1, 2)
    assert test_instance.a == 1
    assert test_instance.b == 2
    assert TestSingleton(3, 4) is test_instance
    assert test_instance.a == 1
    assert test_instance.b == 2



# Generated at 2022-06-11 18:39:44.711792
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.my_val = val

    o = MyClass(5)
    x = MyClass(3)
    assert o == x
    assert o.my_val == 5

# Generated at 2022-06-11 18:39:52.061260
# Unit test for constructor of class Singleton
def test_Singleton():
    class test_class(object):
        __metaclass__ = Singleton

        def __init__(self, *args):
            self.args = args

    t1 = test_class(1, 2, 3)
    assert t1 is not None
    assert t1.args == (1, 2, 3)

    t2 = test_class(4, 5, 6)
    assert t2 is not None
    assert t2.args == (1, 2, 3)
    assert t1 is t2

# Generated at 2022-06-11 18:40:03.062987
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global __module__
    import sys
    import types

    # inject our own __module__
    __module__ = 'test_Singleton__call__'

    # Inject our classes into sys.modules
    sys.modules['Singleton'] = sys.modules[__name__]

    # Inject our classes into locals
    locals().update(sys.modules[__name__].__dict__)

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.__my_var = 1

        def get_my_var(self):
            return self.__my_var

        def test(self):
            pass

    # Verify if the class A is a instance of class Singleton
    assert(isinstance(A, Singleton) == True)

# Generated at 2022-06-11 18:40:10.208332
# Unit test for constructor of class Singleton
def test_Singleton():
    # The constructor of Singleton should return the same instance every
    # time it is called
    class a(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    instance1 = a()
    instance2 = a()
    assert instance1 is instance2

    # All instances of class a should be the same instance
    instance1 = a()
    instance2 = a()
    instance3 = a()
    assert instance1 is instance2
    assert instance2 is instance3
    assert instance1 is instance3

# Generated at 2022-06-11 18:40:13.740882
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    a = Foo(1)
    b = Foo(2)

    assert a.x == 1
    assert b.x == 1


# Generated at 2022-06-11 18:40:19.395288
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # The test class
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    # Instantiate it and check
    t1 = TestSingleton(1)
    t2 = TestSingleton(2)
    assert t1 is t2


# Generated at 2022-06-11 18:40:44.365483
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a, b=42):
            self.a = a
            self.b = b

    a = A(1, 2)
    b = A(1, 2)

    assert a is b  # a and b should be the same object
    assert a.a == 1 and a.b == 2   # a and b should have the same attributes

# Generated at 2022-06-11 18:40:48.748159
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    s1 = TestSingleton(1)
    assert(s1.value == 1)
    s2 = TestSingleton(2)
    assert(s2 is s1)

# Generated at 2022-06-11 18:40:51.501679
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()

    assert f1 is f2

# Generated at 2022-06-11 18:40:55.438806
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name="A"

    a1 = A()
    a2 = A()

    assert a1 is a2


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:41:05.703438
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()
    assert TestSingleton(1) is TestSingleton(1)
    assert TestSingleton(1, 2) is TestSingleton(1, 2)
    assert TestSingleton(1, 2, 3) is TestSingleton(1, 2, 3)
    assert TestSingleton(1, 2, 3, 4) is TestSingleton(1, 2, 3, 4)
    assert TestSingleton(1, 2, 3, 4, 5) is TestSingleton(1, 2, 3, 4, 5)
    assert TestSingleton(1, 2, 3, 4, 5, 6) is TestSingleton(1, 2, 3, 4, 5, 6)

# Generated at 2022-06-11 18:41:10.337338
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    # Ensure only one instance is created
    a = MySingleton()
    b = MySingleton()
    assert a is b

    # Ensure the instance is instantiated
    assert a is not None
    assert b is not None


# Generated at 2022-06-11 18:41:12.641924
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
    assert TestClass is TestClass()


# Generated at 2022-06-11 18:41:14.570581
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()

# Generated at 2022-06-11 18:41:16.382752
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert TestSingleton() == TestSingleton()

# Generated at 2022-06-11 18:41:22.509737
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1(object):
        __metaclass__ = Singleton

    class Test2(Test1):
        pass

    t1 = Test1()
    t2 = Test1()

    assert t1 is t2

    t3 = Test2()
    t4 = Test2()

    assert t3 is t4
    assert t1 is not t3
