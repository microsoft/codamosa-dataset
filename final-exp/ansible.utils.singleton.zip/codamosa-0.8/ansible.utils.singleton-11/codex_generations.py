

# Generated at 2022-06-11 18:31:32.559118
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    o1 = MySingleton(1)
    o2 = MySingleton(2)

    assert o1.x == 1
    assert o2.x == 1
    assert o1 is o2

# Singleton subclass with a different signature for __init__

# Generated at 2022-06-11 18:31:37.111092
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

    a1 = A()
    assert(isinstance(a1, A))
    assert(a1 == A())
    assert(a1 is A())



# Generated at 2022-06-11 18:31:45.058093
# Unit test for constructor of class Singleton
def test_Singleton():
    class ExampleClass(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    e = ExampleClass("arg1", arg2="arg2", arg3="arg3")

    assert (e.args[0] == "arg1")
    assert (e.kwargs["arg2"] == "arg2")
    assert (e.kwargs["arg3"] == "arg3")

    f = ExampleClass("arg1", arg2="arg2", arg3="arg3")

    assert (f is e)
    assert (f.args[0] == "arg1")
    assert (f.kwargs["arg2"] == "arg2")

# Generated at 2022-06-11 18:31:51.499585
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("Initializing MySingleton")
            self.a = 1
    
    a = MySingleton()
    b = MySingleton()
    print(a == b)
    print(a is b)
    print(a.a)
    print(b.a)

# Output:
# Initializing MySingleton
# True
# True
# 1
# 1

# Generated at 2022-06-11 18:31:54.015362
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(object):
        __metaclass__ = Singleton

    a = X()
    b = X()

    assert a is b

# Generated at 2022-06-11 18:31:59.130784
# Unit test for constructor of class Singleton
def test_Singleton():
    # create a class called TestClass
    class TestClass:
        __metaclass__ = Singleton

    # create two instances of TestClass using Singleton
    test1 = TestClass()
    test2 = TestClass()

    # verify that the two instances point to the same address
    assert test1 is test2

# Generated at 2022-06-11 18:32:02.122658
# Unit test for constructor of class Singleton
def test_Singleton():
    class Meta(metaclass=Singleton):
        def __init__(self):
            print("Meta() instance created")

    assert id(Meta()) == id(Meta())


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:32:07.531006
# Unit test for constructor of class Singleton
def test_Singleton():
    class a:
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    a = a('john')
    b = a('tom')
    assert a.name == 'john'
    assert b.name == 'john'

    assert a is b


# Generated at 2022-06-11 18:32:11.221478
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.module_utils.facts import cache

    assert isinstance(cache, Singleton)

    a = cache
    b = cache

    assert a is b
    assert isinstance(a, cache.__class__)
    assert isinstance(b, cache.__class__)

# Generated at 2022-06-11 18:32:18.196181
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self, a, b):
            self.__a = a
            self.__b = b

        def __str__(self):
            return "TestSingleton(a:{}, b:{})".format(self.__a, self.__b)

    class TestSingleton2(metacleton=Singleton):
        def __init__(self, a):
            self.__a = a

        def __str__(self):
            return "TestSingleton2(a:{})".format(self.__a)

    a = TestSingleton(1, 2)
    b = TestSingleton(3, 4)
    c = TestSingleton2(3)
    assert a is not b
    assert a is not c
    assert b is not c

   

# Generated at 2022-06-11 18:32:28.447403
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a
        def __str__(self):
            return "Foo <%s>" % self.a

    # Now, test to make sure this class only creates a single instance
    f1 = Foo('one')
    f2 = Foo('two')
    assert f1 == f2
    assert f1.a == 'one'
    assert f2.a == 'one'

# Generated at 2022-06-11 18:32:33.698042
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.args = 3

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 is test2
    assert test1.args == 3
    assert test2.args == 3

    test1.args = 4
    assert test2.args == 4

# Generated at 2022-06-11 18:32:36.235790
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
   class A(object):
      __metaclass__ = Singleton
      pass

   a1 = A()
   a2 = A()

   assert a1 is a2

# Generated at 2022-06-11 18:32:41.793603
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Single(metaclass=Singleton):
        pass

    a = Single()
    b = Single()
    assert a == b
    assert not a != b
    assert id(a) == id(b)
    assert a is not None
    assert b is not None
    assert a is b


# Generated at 2022-06-11 18:32:46.889336
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__=Singleton

    a=MyClass()
    b=MyClass()
    assert a is b
    assert a.__class__ is MyClass
    assert b.__class__ is MyClass



# Generated at 2022-06-11 18:32:50.426188
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, v):
            self.v = v

    a1 = A("one")
    a2 = A("two")
    assert a1 is a2

# Generated at 2022-06-11 18:33:00.370728
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread

    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    try:
        assert a == b
    except AssertionError:
        print("Unit test for method __call__ of class Singleton fails")
        return

    t = Thread(target=TestSingleton)
    t.start()
    t.join()

    c = TestSingleton()
    try:
        assert a == c
    except AssertionError:
        print("Unit test for method __call__ of class Singleton fails")
        return

    print("Unit test for method __call__ of class Singleton succeeds")

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:33:03.604248
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()
    print(f1==f2)


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-11 18:33:12.487753
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.errors import AnsibleModuleExit

    class ExitCode(object):
        """After setting the exit code, __exit__ will raise AnsibleModuleExit with the exit code.
        """
        __metaclass__ = Singleton

        def __init__(self):
            self.exit_code = 0

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            raise AnsibleModuleExit(self.exit_code)

        def set_exit_code(self, code):
            self.exit_code = code

    e = ExitCode()
    assert e._Singleton__instance == e

    e.set_exit_code(1)


# Generated at 2022-06-11 18:33:16.093332
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert isinstance(Singleton, type)

    class A(object):
        __metaclass__ = Singleton

    assert isinstance(A, Singleton)
    assert isinstance(A(), A)

    assert A() is A()


# Generated at 2022-06-11 18:33:23.007601
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
    class Bar(object):
        __metaclass__ = Singleton

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()

# Generated at 2022-06-11 18:33:26.046447
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t = TestSingleton()
    assert t.a == 1
    assert id(t) == id(TestSingleton())

# Generated at 2022-06-11 18:33:29.996106
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)


# Generated at 2022-06-11 18:33:39.766016
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Child(metaclass=Singleton):
        def __init__(self, a, b):
            self.a = a
            self.b = b
            self.cnt = 0

        def inc_cnt(self):
            self.cnt += 1

    # Test
    obj_1 = Child('a', 'b')
    obj_2 = Child('x', 'y')
    obj_3 = Child('a', 'b')

    obj_1.inc_cnt()
    obj_2.inc_cnt()
    obj_3.inc_cnt()

    # Asserts
    assert obj_1 == obj_2 == obj_3
    assert obj_1.a == 'a'
    assert obj_1.b == 'b'
    assert obj_1.cnt == 3
    assert obj

# Generated at 2022-06-11 18:33:44.974034
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, bar):
            self.bar = bar

        def __str__(self):
            return self.bar

    assert type(Foo('baz')).__name__ == 'Foo'
    assert type(Foo('bax')).__name__ == 'Foo'

# Generated at 2022-06-11 18:33:49.668609
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    with MySingleton() as m1:
        with MySingleton() as m2:
            print('test_Singleton___call__: ' + repr(m1) + repr(m2))
            assert m1 is m2



# Generated at 2022-06-11 18:33:52.744151
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(metaclass=Singleton):
        def __init__(self):
            pass

    o1 = MySingleton()
    o2 = MySingleton()

    assert o1 is o2


# Generated at 2022-06-11 18:33:58.484825
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    failure = False
    try:
        # Create class TestClass which has Singleton as its metaclass
        class TestClass(object):
            __metaclass__ = Singleton
            def __init__(self):
                self.x = 10
        # Create two objects of class TestClass
        a = TestClass()
        b = TestClass()
        # a and b should refer to the same object
        if id(a) != id(b):
            failure = True
            print("__call__: Failed!")
            print("Different instances of Singleton class created")
        # Make sure that a and b have same values
        if a.x != 10 or b.x != 10:
            failure = True
            print("__call__: Failed!")
            print("Values of attributes of objects are different")
    except Exception as e:
        print

# Generated at 2022-06-11 18:34:01.468511
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert isinstance(TestClass(), TestClass)



# Generated at 2022-06-11 18:34:04.605324
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    # Test that we get a new instance
    a = MyClass()

    # Test that we get the same instance again
    b = MyClass()

    # Test they are the same object
    assert(a is b)


# main function
if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:34:10.466913
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'joe'

    a = C()
    b = C()
    assert a.name == b.name


test_Singleton___call__()

# Generated at 2022-06-11 18:34:13.910210
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Sample(object):
        __metaclass__ = Singleton
    sample1 = Sample()
    sample2 = Sample()
    assert sample1 is sample2


# vim: set expandtab:ts=4:sw=4

# Generated at 2022-06-11 18:34:16.885027
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("A")

    obj1 = A()
    obj2 = A()
    assert(obj1 is obj2)



# Generated at 2022-06-11 18:34:21.709289
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class cls(object):
        __metaclass__ = Singleton
        def __init__(self, data):
            self.data = data

    s1 = cls('s1')
    s2 = cls('s2')
    assert s1 is s2
    assert s1.data == 's2'

# Generated at 2022-06-11 18:34:24.523904
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    obj1 = TestClass()
    obj2 = TestClass()
    assert id(obj1) == id(obj2)



# Generated at 2022-06-11 18:34:29.720023
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton
        def __init__(self, x, y):
            self.x = x
            self.y = y
    instance_1 = A(1, 2)
    instance_2 = A(3, 4)
    assert instance_1 == instance_2

# Generated at 2022-06-11 18:34:33.437675
# Unit test for constructor of class Singleton
def test_Singleton():
    class myclass():
        __metaclass__ = Singleton

    test_class = myclass()
    assert test_class
    assert test_class == myclass()

# Generated at 2022-06-11 18:34:37.311498
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, *args):
            self.args = args
    a = A(1, 2, 3)
    assert id(a) == id(A(4, 5, 6))


# Generated at 2022-06-11 18:34:42.473606
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''Unit test for method Singleton.__call__'''

    class Foo:
        """Test class implementing Singleton functionality"""
        __metaclass__ = Singleton

    # Check that instance of class Foo is a singleton
    foo = Foo()
    foo2 = Foo()
    assert foo == foo2


# Generated at 2022-06-11 18:34:48.450725
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SimpleObject(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.s = 'Test'

    a1 = SimpleObject()
    a2 = SimpleObject()
    assert a1 is a2

    a1.s = 'Test 2'
    assert a2.s == 'Test 2'


if __name__ == '__main__':
    test_Singleton___call__()



# Generated at 2022-06-11 18:34:57.796596
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        __init_val = None

        def __init__(self, val):
            self.__init_val = val

        def __str__(self):
            return "TestClass({})".format(self.__init_val)

    a = TestClass(1)
    b = TestClass(1)
    c = TestClass(2)

    assert id(a) == id(b)
    assert id(a) != id(c)
    assert a.__init_val == 1
    assert b.__init_val == 1
    assert c.__init_val == 2

# Generated at 2022-06-11 18:35:02.371446
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self, a=None, b=None):
            self.a = a
            self.b = b

    foo1 = Foo(2, 3)
    assert foo1.a == 2
    assert foo1.b == 3

    foo2 = Foo()
    assert foo2.a is None
    assert foo2.b is None

    assert foo1 == foo2

# Generated at 2022-06-11 18:35:05.678419
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object, metaclass=Singleton):
        pass

    obj1 = MyClass()
    obj2 = MyClass()

    assert obj1 == obj2

# Generated at 2022-06-11 18:35:08.250180
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    instance = TestClass()
    assert instance == TestClass()
    assert instance is not None
    assert TestClass() is not None



# Generated at 2022-06-11 18:35:10.760281
# Unit test for constructor of class Singleton
def test_Singleton():
    Singleton_Test_Class = Singleton("Singleton_Test_Class", (object,), {})
    assert Singleton_Test_Class("test") == Singleton_Test_Class("test")

# Generated at 2022-06-11 18:35:14.159725
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

# Generated at 2022-06-11 18:35:19.289892
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.v = 1
    a1 = A()
    a2 = A()
    a1.v += 1
    assert a1.v == 2
    assert a2.v == 2


# Generated at 2022-06-11 18:35:22.710021
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    t3 = Test()
    t4 = Test()

    assert(t1 is t2)
    assert(t2 is t3)
    assert(t3 is t4)

# Generated at 2022-06-11 18:35:34.273898
# Unit test for constructor of class Singleton
def test_Singleton():
    class A (metaclass=Singleton):
        def __init__(self):
            self.a = 10
    class B (metaclass=Singleton):
        def __init__(self):
            self.a = 20
    class C (metaclass=Singleton):
        def __init__(self):
            self.a = 30
        def __eq__(self, obj):
            return self.a == obj.a
        def __ne__(self, obj):
            return self.a != obj.a

    a = A()
    b = B()
    c = C()

    assert a is A()
    assert b is B()
    assert c is C()
    assert a is not B()
    assert b is not C()
    assert c is not A()
    assert a == A()
    assert b

# Generated at 2022-06-11 18:35:43.070182
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import sys
    import unittest

    class SingletonTest(object):
        __metaclass__ = Singleton

    class TestSingleton(unittest.TestCase):
        def test_same(self):
            s1 = SingletonTest()
            s2 = SingletonTest()
            self.assertTrue(s1 is s2)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestSingleton)
    unittest.TextTestRunner(verbosity=2).run(suite)


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:35:47.970403
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
    a = Test()
    b = Test()
    assert a == b


# Generated at 2022-06-11 18:35:53.162309
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test1(object):
        __metaclass__ = Singleton

    class Test2(object):
        __metaclass__ = Singleton

    t1 = Test1()
    t2 = Test1()
    assert id(t1) == id(t2)

    t3 = Test2()
    t4 = Test2()
    assert id(t3) == id(t4)
    assert id(t1) != id(t3)

test_Singleton()

# Generated at 2022-06-11 18:35:58.596163
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import types

    class Base(object):
        def __init__(self):
            pass

    class MySingleton(Base):
        __metaclass__ = Singleton

    a = MySingleton()
    b = MySingleton()
    assert a is b
    assert isinstance(a, MySingleton)
    assert isinstance(b, Base)
    assert not isinstance(a, types.InstanceType)
    assert not isinstance(b, types.InstanceType)



# Generated at 2022-06-11 18:36:08.240498
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class testing():
        __metaclass__ = Singleton

    class testing_child(testing):
        pass

    class testing_grand_child(testing_child):
        pass

    class testing_brother(testing):
        pass

    class testing_uncle(testing_brother):
        pass

    class testing_grand_uncle(testing_uncle):
        pass

    assert testing() == testing()
    assert testing_child() == testing_child()
    assert testing_grand_child() == testing_grand_child()
    assert testing_brother() == testing_brother()
    assert testing_uncle() == testing_uncle()
    assert testing_grand_uncle() == testing_grand_uncle()

    # Check that class can't be instanciated more than once
    assert testing_grand_uncle() == testing_grand_uncle()

    # Check that classes are

# Generated at 2022-06-11 18:36:11.190232
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    i1 = MyClass()
    i2 = MyClass()

    # If the singleton instance is correctly instantiated and returned
    assert i1 is i2



# Generated at 2022-06-11 18:36:13.205845
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    obj1 = MySingleton()
    obj2 = MySingleton()
    assert obj1 == obj2

# Generated at 2022-06-11 18:36:15.295126
# Unit test for constructor of class Singleton
def test_Singleton():
    def test_init():
        class Test(metaclass=Singleton):
            def __init__(self):
                pass
    test_init()

# Generated at 2022-06-11 18:36:18.291094
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    a = A()
    b = A()
    # a and b should be the same instance
    assert a is b
    c = a()
    d = A()
    # c and d should be the same instance
    assert c is d
    # A, a, b, c, d should all be the same instance
    assert A is a is b is c is d


# Generated at 2022-06-11 18:36:20.470090
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.id = uuid.uuid4()

    a = MyClass()
    b = MyClass()
    assert a == b
    assert id(a) == id(b)
    assert a.id == b.id

# Generated at 2022-06-11 18:36:23.934406
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

    f0 = Foo()
    f1 = Foo()
    b0 = Bar()

    assert f0 is f1
    assert f0 is not b0

# Generated at 2022-06-11 18:36:33.444074
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = True

    a = Test()
    b = Test()
    assert 'x' in dir(a)
    assert 'x' in dir(b)
    assert a is b, "%s is not %s" % (a, b)
    assert id(a) == id(b), "%d != %d" % (id(a), id(b))


# Generated at 2022-06-11 18:36:37.651703
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, attr):
            self.attr = attr

    # first instance
    test_obj1 = TestClass(1)
    assert test_obj1.attr == 1

    # second instance
    test_obj2 = TestClass(2)
    assert test_obj2.attr == 1

    # assert that the first instance is the same as the second instance
    assert test_obj1 is test_obj2

# Generated at 2022-06-11 18:36:40.040703
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    var1 = TestSingleton()
    var2 = TestSingleton()
    assert var1 == var2

# Generated at 2022-06-11 18:36:43.384102
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()
    assert TestClass.__instance is not None
    assert TestClass() is TestClass.__instance

# Generated at 2022-06-11 18:36:53.587344
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = None

        def set_arg3(self, arg3):
            self.arg3 = arg3

    test = TestSingleton(1, 2)
    assert test.arg1 == 1
    assert test.arg2 == 2
    assert test.arg3 == None
    test.set_arg3(3)
    assert test.arg3 == 3
    test2 = TestSingleton(4, 5)
    assert test == test2
    assert test.arg3 == 3
    assert test2.arg3 == 3

    # Test to make sure arguments aren't reused

# Generated at 2022-06-11 18:36:56.860372
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class c(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    a = c()
    b = c()

    assert a.x == b.x
    assert a is b

# Generated at 2022-06-11 18:36:59.803105
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = SingletonTest()
    b = SingletonTest()

    assert a is b


# Generated at 2022-06-11 18:37:04.443897
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    lock_1 = RLock()
    lock_2 = RLock()

    assert lock_1 != lock_2

    lock_1.acquire()

    assert lock_1.acquire(blocking=False) == False

# Generated at 2022-06-11 18:37:12.061443
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansibullbot.decorators.singleton import Singleton
    import unittest

    class Foo(object):
        __metaclass__ = Singleton

    class TestSingleton(unittest.TestCase):
        """Test class for testing Singleton class.
        """
        def test_same_instance(self):
            """Test that a Singleton class returns the same
            object each time it is instantiated.
            """
            foo1 = Foo()
            foo2 = Foo()

            self.assertIs(foo1, foo2)
            self.assertTrue(id(foo1) == id(foo2))

    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-11 18:37:15.356902
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a1 = A('a1')
    a2 = A('a2')
    assert a1 is a2
    assert a1.value == 'a1'


# Generated at 2022-06-11 18:37:25.859781
# Unit test for constructor of class Singleton
def test_Singleton():
    assert hasattr(Singleton, '__init__')
    assert callable(Singleton.__init__)
    assert 'super' in Singleton.__init__.__code__.co_code.hex()

    assert hasattr(Singleton, '__call__')
    assert callable(Singleton.__call__)
    assert 'super' in Singleton.__call__.__code__.co_code.hex()
    assert '__instance' in Singleton.__call__.__code__.co_code.hex()



# test_Singleton()

# Generated at 2022-06-11 18:37:31.067598
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class NonSingleton:
        def __init__(self, val):
            self.val = val

    class SingletonClass(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    s1 = SingletonClass(1)
    s2 = SingletonClass(1)
    ns1 = NonSingleton(1)
    ns2 = NonSingleton(1)

    s3 = SingletonClass(2)
    ns3 = NonSingleton(2)

    assert s1 is s2
    assert ns1 is not ns2
    assert s1 is not s3
    assert ns1 is not ns3



# Generated at 2022-06-11 18:37:40.647524
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 10

    b = A()
    assert b.a == 10

    # Will create another instance of class B, so b1 != b2
    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.b = 11

    b1 = B()
    assert b1.b == 11
    b2 = B()
    assert b2.b == 11
    assert b1 != b2

    # A singleton class's constructor should only be called once
    class C(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 100


# Generated at 2022-06-11 18:37:51.516667
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object, metaclass=Singleton):
        def __init__(self):
            self.value = 5
            self.list = []

        def set_value(self, value):
            self.value = value

        def get_value(self):
            return self.value

        def append_to_list(self, value):
            self.list.append(value)

        def get_list(self):
            return self.list

    a = A()
    a.set_value(2)
    a.append_to_list("hello")
    print("%d" % a.get_value())
    print("%s" % a.get_list())

    b = A()
    print("%d" % b.get_value())
    b.append_to_list("world")

# Generated at 2022-06-11 18:37:54.804426
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    a = MySingleton()
    b = MySingleton()
    assert a is b



# Generated at 2022-06-11 18:38:03.863669
# Unit test for constructor of class Singleton
def test_Singleton():
    import pprint
    class TestClass(object):
        """
            Class to be used as singleton.
        """
        __metaclass__ = Singleton

        def __init__(self):
            """ Constructor. """
            self.objects = list()

        def add(self, object_):
            """
                Adds the object.

                :param object_: Object to be added.
            """
            self.objects.append(object_)

    # Create the first instance of class TestClass
    instance_one = TestClass()
    # Create the second instance of class TestClass
    instance_two = TestClass()

    assert instance_one == instance_two
    instance_one.add('foo')

    assert 'foo' in instance_two.objects



if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:38:13.262493
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class ClassA(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 'a'

    class ClassB(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.b = 'b'

    objA1 = ClassA()
    objA2 = ClassA()
    assert id(objA1) == id(objA2)
    assert objA1.a == 'a' and objA2.a == 'a'

    objB1 = ClassB()
    objB2 = ClassB()
    assert id(objB1) == id(objB2)
    assert objB1.b == 'b' and objB2.b == 'b'

    assert id(objA1) != id(objB1)

# Generated at 2022-06-11 18:38:14.904185
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()

    assert a is b


# Generated at 2022-06-11 18:38:17.418124
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()

    assert a is b



# Generated at 2022-06-11 18:38:18.909358
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()

    assert f1 is f2

# Generated at 2022-06-11 18:38:29.499911
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()
    assert A() is not A(Singleton())

# Generated at 2022-06-11 18:38:34.137582
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Base(object):
        pass
    class Sub1(Base):
        pass
    class Sub2(Base):
        pass

    s1 = Sub1()
    s2 = Sub1()
    assert s1 is s2

    s3 = Sub2()
    s4 = Sub2()
    assert s3 is s4

    s5 = Sub1()
    assert s1 is s5

    assert Sub1() is Base()

# Generated at 2022-06-11 18:38:37.201904
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    instance1 = Foo()
    instance2 = Foo()

    assert instance1 == instance2


# Generated at 2022-06-11 18:38:47.222348
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a simple singleton class
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.some_variable = 'initialized'

    # Create an instance of singleton class
    singleton_subject_1 = SingletonTest()

    # Check that 'self.some_variable' was set properly
    assert singleton_subject_1.some_variable == 'initialized'

    # Call the class again (as you would normally do)
    singleton_subject_2 = SingletonTest()

    # Check that the same object was returned
    assert singleton_subject_1 == singleton_subject_2

    # Check that the method __call__ worked properly
    assert hasattr(SingletonTest, '__call__')


# Generated at 2022-06-11 18:38:50.399079
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, init_data=None):
            self.data = init_data

    # Test returns a single instance
    a1 = A(12)
    a2 = A(13)
    assert a1.data == 12
    assert a2.data == 12
    assert id(a1) == id(a2)

# Generated at 2022-06-11 18:38:54.214149
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test():
        __metaclass__ = Singleton

        def __init__(self):
            self.A = 1
    assert Test().A == 1  # first call
    assert Test().A == 1  # second call

# Generated at 2022-06-11 18:38:56.611096
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    test_object1 = TestClass()
    test_object2 = TestClass()
    assert test_object1 == test_object2

# Generated at 2022-06-11 18:39:06.944814
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a class
    class SingletonSample(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = None

    # Instantiate the first class object to test if __call__ handles over
    # instantiating the same class
    singleton_sample_obj1 = SingletonSample()
    singleton_sample_obj1.a = 'a'

    singleton_sample_obj2 = SingletonSample()
    singleton_sample_obj2.a = 'b'

    assert singleton_sample_obj2.a == singleton_sample_obj1.a

    # Test if __call__ creates an object of the same class that was created
    # earlier
    assert isinstance(singleton_sample_obj2, SingletonSample)

    # Test if __call__ creates an instance of the correct

# Generated at 2022-06-11 18:39:11.949264
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        # constructor
        def __init__(self):
            self.a = 1

    # Create a single instance
    foo = Foo()

    # get that same instance again
    assert(Foo() is foo)

    # modify an attribute of the singleton class
    foo.a = 2

    # verify the attribute was propagated to the second instance
    assert(Foo().a == 2)

# Generated at 2022-06-11 18:39:15.149518
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.x = 1

    a = A()
    b = A()
    c = A()

    assert a is b
    assert b is c

    a.x = 3
    assert b.x == 3
    assert c.x == 3

# Generated at 2022-06-11 18:39:35.902318
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert TestClass() is TestClass()

# Generated at 2022-06-11 18:39:38.136201
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test1(metaclass=Singleton):
        def func(self):
            pass

    Test1()
    Test1()

# Generated at 2022-06-11 18:39:44.409137
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        """check Singleton metaclass behavior.
        """
        __metaclass__ = Singleton

        def __init__(self):
            self.name = "Singleton"

    s1 = S()
    assert s1.name == "Singleton"
    assert isinstance(s1, S)

    s2 = S()
    assert s1 == s2
    assert s1 is s2



# Generated at 2022-06-11 18:39:48.660416
# Unit test for constructor of class Singleton
def test_Singleton():
    class Klazz(object):
        __metaclass__ = Singleton

    # the constructor for Klazz is not called
    klazz_instance_1 = Klazz()
    klazz_instance_2 = Klazz()
    assert klazz_instance_1 is klazz_instance_2

# Generated at 2022-06-11 18:39:52.714962
# Unit test for constructor of class Singleton
def test_Singleton():
    class Class(object):
        __metaclass__ = Singleton

    classobj_1 = Class()
    classobj_2 = Class()
    assert classobj_1 is classobj_2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:39:57.346328
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo():
        __metaclass__ = Singleton
        def __init__(self):
            self._x = None
    foo1 = Foo()
    foo2 = Foo()
    assert(foo1 == foo2)

# Generated at 2022-06-11 18:40:02.362004
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test_Singleton(metaclass=Singleton):
        def __init__(self, x=0, y=0):
            self.x = x
            self.y = y

    obj1 = Test_Singleton()
    obj2 = Test_Singleton()
    assert obj1.x == 0
    assert obj2.y == 0
    assert obj1 is obj2

# Test of __instance

# Generated at 2022-06-11 18:40:06.372375
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    foo1 = Foo(1, 2)
    foo2 = Foo(3, 4)
    assert foo1 is foo2
    assert foo1.a == foo2.a
    assert foo1.b == foo2.b

# Generated at 2022-06-11 18:40:07.928028
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Myclass(object):
        __metaclass__ = Singleton



# Generated at 2022-06-11 18:40:11.960045
# Unit test for constructor of class Singleton
def test_Singleton():
    import ansible.utils.unmunge
    from ansible.utils.unmunge import unmunge_dict
    unmunge_dict.__class__ = Singleton
    for x in range(100):
        assert unmunge_dict is unmunge_dict()

# Generated at 2022-06-11 18:40:52.645411
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create a class to use singleton constructor
    class Test(object):
        __metaclass__ = Singleton

    # Create two instances of the class
    test_instance = Test()
    test_instance2 = Test()

    # Assert that they are the same object
    assert test_instance is test_instance2



# Generated at 2022-06-11 18:41:03.545789
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(metaclass=Singleton):
        def __init__(self):
            self.val = 0

        def inc(self):
            self.val += 1
            return self.val

    # test
    my_s1 = MySingleton()
    my_s2 = MySingleton()
    assert my_s1.val == 0  # __init__ was called
    assert my_s2.val == 0  # __init__ was called

    # test singleton
    assert my_s1 is my_s2  # same object

    assert my_s1.inc() == 1
    assert my_s2.inc() == 2
    assert my_s1.inc() == 3
    assert my_s2.inc() == 4
    assert my_s1.inc() == 5
    assert my_s

# Generated at 2022-06-11 18:41:06.307781
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # class for testing
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    obj1 = Test(1)
    obj2 = Test(2)
    assert obj1.value == 1
    assert obj2.value == 1

# Generated at 2022-06-11 18:41:13.657759
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Moo(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    i1 = Moo(1)
    i2 = Moo(2)
    assert id(i1) == id(i2) and i1.x == i2.x

    a1 = Moo(1)
    a2 = Moo(2)
    assert id(a1) == id(a2) and a1.x != a2.x

# Generated at 2022-06-11 18:41:18.778676
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self): pass

    s1 = TestSingleton()
    assert id(s1) == id(TestSingleton())
    

# Generated at 2022-06-11 18:41:22.265959
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class EmptySingleton(object):
        __metaclass__ = Singleton
        pass

    inst1 = EmptySingleton()
    inst2 = EmptySingleton()
    assert (inst1 is inst2)
    assert (EmptySingleton.__instance is inst1)


# Generated at 2022-06-11 18:41:25.290017
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert isinstance(Foo(), Foo)
    assert Foo() == Foo()