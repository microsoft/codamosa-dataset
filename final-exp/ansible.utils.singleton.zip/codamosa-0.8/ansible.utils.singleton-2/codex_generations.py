

# Generated at 2022-06-11 18:31:39.306889
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton1(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    class TestSingleton2(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    s0 = TestSingleton1('s0')
    s1 = TestSingleton1('s1')
    s2 = TestSingleton2('s2')
    assert s0.value == 's0'
    assert s1.value == 's0'
    assert id(s0) == id(s1)
    assert s2.value == 's2'
    assert id(s1) != id(s2)

# Generated at 2022-06-11 18:31:43.620148
# Unit test for constructor of class Singleton
def test_Singleton():
    class Temp(metaclass=Singleton):
        def __init__(self):
            self.x = True

    t1 = Temp()
    t2 = Temp()
    assert t1 == t2
    assert t2.x == t1.x
    t2.x = False
    assert t1.x == t2.x

# Generated at 2022-06-11 18:31:50.710539
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Sample(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    instance1 = Sample('foo')
    instance2 = Sample('bar')
    assert instance1 == instance2, \
        'Instance1 and instance2 should be the same object'
    assert instance1.name == 'foo'
    assert instance2.name == 'foo', \
        'Instance1 and instance2 should have the same attribute "name"'



# Generated at 2022-06-11 18:31:56.892852
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    obj1 = TestClass('singleton')
    assert obj1.arg != None

    obj2 = TestClass('another singleton')
    assert obj2.arg == obj1.arg


# Generated at 2022-06-11 18:31:59.169121
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        pass

    assert TestSingleton() is TestSingleton()



# Generated at 2022-06-11 18:32:10.046488
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Unit test for Singleton.__call__()."""

    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = Test("Frank")
    assert a.name == "Frank"

    # Throw away old Test() singleton and create a new one.
    a = None
    b = Test("Alice")
    assert b.name == "Alice"
    # A new singleton is created.
    assert b is not a

    # a and b are the same singleton.
    a = Test("Frank")
    assert a.name == "Frank"
    assert a is b
    assert b.name == "Frank"


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 18:32:13.529352
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self):
            self.bar = "Hello, world!"

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 == foo2
    assert foo1.bar == 'Hello, world!'

# Generated at 2022-06-11 18:32:18.476467
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 'foo'

    a1 = A()
    assert a1.x == 'foo'
    a1.x = 'bar'

    a2 = A()
    assert a2.x == 'bar'



# Generated at 2022-06-11 18:32:25.431926
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x
    s1 = MySingleton(1)
    s2 = MySingleton(2)
    assert s1.x == 1
    assert s2.x == 1
    assert s1 == s2
    assert s1 is s2


# Generated at 2022-06-11 18:32:31.500581
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.a = 1
    assert TestSingleton.a==1
    test_singleton = TestSingleton()
    assert test_singleton.a==1
    assert type(test_singleton) == TestSingleton
    assert test_singleton == TestSingleton()
    assert test_singleton is TestSingleton()


# Generated at 2022-06-11 18:32:37.238438
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global data
    data = []
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            data.append('init')

    a = A()
    a = A()
    assert data == ['init']



# Generated at 2022-06-11 18:32:41.572560
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)



# Generated at 2022-06-11 18:32:46.225835
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo:
        __metaclass__ = Singleton

        def __init__(self):
            print('Foo __init__ called')

    f1 = Foo()
    f2 = Foo()

    assert f1 is f2


# Generated at 2022-06-11 18:32:48.138393
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A() is A()


# Generated at 2022-06-11 18:32:56.322818
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name='myname'):
            self.name = name

        def printname(self):
            print(self.name)

    assert TestSingleton() is TestSingleton()

    a = TestSingleton('a')
    b = TestSingleton('b')

    assert a is b
    a.printname()
    b.printname()
    assert a.name == 'b'
    assert b.name == 'b'

# Generated at 2022-06-11 18:33:03.894756
# Unit test for constructor of class Singleton
def test_Singleton():
    class Dog(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    d = Dog('test_dog')
    assert d.name == 'test_dog'

    d2 = Dog('xxx')
    assert d2.name == 'test_dog'
    assert id(d) == id(d2)


# vim: set sts=4 ts=8 sw=4 ft=python et noro norl cin si ai :

# Generated at 2022-06-11 18:33:06.640195
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2


# Generated at 2022-06-11 18:33:09.316849
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert(A() is A())


# Generated at 2022-06-11 18:33:12.602458
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest:
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 0

    st1 = SingletonTest()
    st2 = SingletonTest()
    assert st1 == st2
    assert st1.x == 0

# Generated at 2022-06-11 18:33:16.278405
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(metaclass=Singleton):
        def __init__(self, value):
            self.value = value
    x = X(42)
    y = X(43)
    assert x is y
    assert x.value == y.value

# Generated at 2022-06-11 18:33:22.810291
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    foo = Foo()
    assert foo == Foo()
    assert id(foo) == id(Foo())

# Generated at 2022-06-11 18:33:26.284140
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    assert TestSingleton(0) is TestSingleton(1)
    assert TestSingleton(0).x == 0
    assert TestSingleton(1).x == 0
    assert id(TestSingleton(0)) == id(TestSingleton(1))

# Generated at 2022-06-11 18:33:35.108972
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    t1 = Test(5)
    t2 = Test(2)

    # t1 and t2 should be the same instance
    assert t1 == t2
    # t1.x should be equal to 5
    assert t1.x == 5
    # t2.x should be equal to 5
    assert t2.x == 5
    # t1.x should be equal to t2.x
    assert t1.x == t2.x

# Generated at 2022-06-11 18:33:44.593018
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create singleton with data "foo"
    class foo_singleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.data = "foo"
    # Create singleton with data "bar"
    class bar_singleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.data = "bar"
    # Create singleton with data "baz"
    class baz_singleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.data = "baz"
    # Assert singleton of foo_singleton has data "foo"
    assert foo_singleton() is not None
    assert foo_singleton().data == "foo"
    # Assert singleton of bar

# Generated at 2022-06-11 18:33:50.491344
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingletonObject(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = 'SingletonTest'

    instance1 = TestSingletonObject()
    instance2 = TestSingletonObject()

    return instance1 is instance2 and instance1.name == instance2.name


# Generated at 2022-06-11 18:33:57.683924
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    test1 = TestClass('a', 'b')
    assert test1.a == 'a'
    assert test1.b == 'b'

    test2 = TestClass('c', 'd')
    assert test1 is test2
    assert test2.a == 'a'
    assert test2.b == 'b'

# Generated at 2022-06-11 18:34:04.393751
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import yaml
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    class A(VariableManager):
        __metaclass__ = Singleton

        def __init__(self,  *args, **kwargs):
            VariableManager.__init__(self, *args, **kwargs)

    assert A.__instance is None

    a = A(loader=DataLoader())
    assert isinstance(a, A)
    assert A.__instance is not None
    assert A.__instance is a

    # Get A as __call__
    b = A()

    # a and b must be the same object
    assert id(a) == id(b)
    assert a is b



# Generated at 2022-06-11 18:34:10.096288
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, named):
            self.named = named

    foo1 = Foo("foo1")
    foo2 = Foo("foo2")

    assert foo1.named == "foo1"
    assert foo1 is foo2

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:34:15.221102
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class DummyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

        def __str__(self):
            return 'dummy instance'

    a = DummyClass()
    b = DummyClass()

    assert a == b
    assert a is b
    assert str(a) == str(b)



# Generated at 2022-06-11 18:34:18.456562
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 == t2



# Generated at 2022-06-11 18:34:24.859869
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass:
        __metaclass__ = Singleton

    a = MyClass()
    b = MyClass()
    assert a == b



# Generated at 2022-06-11 18:34:32.066082
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert isinstance(Singleton, type), 'Singleton should be a type.'

    class A(metaclass=Singleton):
        pass

    class B(metaclass=Singleton):
        pass

    a1 = A()
    a2 = A()
    b1 = B()

    assert a1 is a2, 'should return only instance'
    assert b1 is not a1, 'should return different instances'

# Generated at 2022-06-11 18:34:34.141499
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, x = 0):
            self.x = x
    a1 = A(1)
    a2 = A(2)
    print(a1.x)
    print(a2.x)
    assert a1 is a2
    print("OK")

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:34:37.837962
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton1(metaclass=Singleton):
        pass

    class TestSingleton2(metaclass=Singleton):
        pass

    t1_1 = TestSingleton1()
    t1_2 = TestSingleton1()
    t2_1 = TestSingleton2()
    t2_2 = TestSingleton2()

    assert id(t1_1) == id(t1_2)
    assert id(t2_1) == id(t2_1)
    assert id(t1_1) != id(t2_1)

# Generated at 2022-06-11 18:34:43.040363
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    foo1 = Foo(1)
    foo2 = Foo(2)
    assert foo1 == foo2

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-11 18:34:51.550634
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class BaseClass:
        def __init__(self):
            self.variable_1 = 1
            self.variable_2 = 2

    class SingletonClass(BaseClass, metaclass=Singleton):
        pass

    instance_1 = SingletonClass()
    instance_2 = SingletonClass()

    assert instance_1 == instance_2
    assert instance_1.variable_1 == instance_2.variable_1
    assert instance_1.variable_2 == instance_2.variable_2

    instance_1.variable_1 += 1
    instance_1.variable_2 += 2

    assert instance_1 == instance_2
    assert instance_1.variable_1 == instance_2.variable_1
    assert instance_1.variable_2 == instance_2.variable_2


# Generated at 2022-06-11 18:34:52.933644
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert (t1 == t2)

# Generated at 2022-06-11 18:34:56.693488
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.val = None

    instance1 = TestSingleton()
    instance1.val = 'test'
    instance2 = TestSingleton()
    assert instance1 == instance2
    assert instance1.val == instance2.val


# Generated at 2022-06-11 18:34:59.472949
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = "foo"

    assert TestSingleton().value == TestSingleton().value

# Generated at 2022-06-11 18:35:04.065462
# Unit test for constructor of class Singleton
def test_Singleton():
    print("Testing Singleton Constructor")

    class A(metaclass=Singleton):
        pass

    class B(metaclass=Singleton):
        pass

    assert A() == A()
    assert B() == B()
    assert A() != B()


# Test for loggers in Singleton

# Generated at 2022-06-11 18:35:14.007499
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    assert Foo('a') is Foo('b')

    # Check that we can't instantiate a class without Singleton metaclass
    try:
        Singleton('Bar', (Foo,), {})
    except TypeError:
        print('TypeError raised as expected')
    else:
        assert False, 'singleton instantiated without metaclass'

# Generated at 2022-06-11 18:35:20.772139
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(Singleton):
        def __init__(cls):
            if cls._C__instance:
                raise RuntimeError('C is Singleton!')
            cls.x = 5

    print('Expect: 5')
    C()
    print(C().x)

    print('Expect: 5')
    C()
    print(C().x)

    print('Expect: 5')
    C()
    print(C().x)


# Generated at 2022-06-11 18:35:32.049507
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # SingletonTestCase is a class defined below and is used to test the Singleton metaclass
    # Each instance of the class SingletonTestCase is expected to have a different random number
    import random
    class SingletonTestCase(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.random_number = random.randint(1,100)
    
    # The following two variables should point to different objects
    singleton_test_case1 = SingletonTestCase()
    singleton_test_case2 = SingletonTestCase()

    # Compare the random numbers stored in the objects pointed to by the above two variables
    # They should be the same

# Generated at 2022-06-11 18:35:34.671930
# Unit test for constructor of class Singleton
def test_Singleton():
    """Tests the constructor for the class Singleton"""
    class MySingleton(metaclass=Singleton):
        pass

    s1 = MySingleton()
    assert(s1 is MySingleton()) # returns the same

# Generated at 2022-06-11 18:35:37.737553
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()



# Generated at 2022-06-11 18:35:40.789617
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert(a == b)
    assert(id(a) == id(b))

# Generated at 2022-06-11 18:35:49.658965
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert A() is A()
    assert A() is A()

    class B(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    assert B(1) is B(2)
    assert B(1).a == 1

    class C(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    assert C(1, 2) is C(2, 3)
    assert C(1, 2).b == 2

# Generated at 2022-06-11 18:35:51.394936
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    foo = Foo()
    foo1 = Foo()
    assert foo is foo1

# Generated at 2022-06-11 18:35:57.817279
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread

    class SingletonTestClass(object):
        __metaclass__ = Singleton

    assert(SingletonTestClass() == SingletonTestClass())
    assert(SingletonTestClass() is SingletonTestClass())

    # Multithreading test to make sure Singleton works as expected
    class MultithreadedSingletonTestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.lock = RLock()

        def foo(self):
            with self.lock:
                print('foo')

    def multithreaded_singleton_test():
        instance = MultithreadedSingletonTestClass()
        instance.foo()

    thread1 = Thread(target=multithreaded_singleton_test, args=())

# Generated at 2022-06-11 18:36:03.354577
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, x, y=None):
            self.x = x
            self.y = y
            self.a = 10
            self.b = 5

    instance1 = MySingleton('foo', 'bar')
    assert instance1.x == 'foo'
    assert instance1.y == 'bar'
    instance1.a = 15
    assert instance1.a == 15
    assert instance1.b == 5
    instance2 = MySingleton('baz', 'bam')
    # We should have the same instance as we already had one
    assert instance1 == instance2
    assert instance1.x == instance2.x
    assert instance1.y == instance2.y
    assert instance1.a == 15
    assert instance1

# Generated at 2022-06-11 18:36:11.522157
# Unit test for constructor of class Singleton
def test_Singleton():
    class singleton_test(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg
    assert(singleton_test('arg_1') == singleton_test('arg_2'))
    assert(singleton_test('arg_1').arg == 'arg_1')

# Generated at 2022-06-11 18:36:15.116430
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 'blah'

    s1 = S()
    assert(s1.x == 'blah')

    s2 = S()
    assert(s1 is s2)

# Generated at 2022-06-11 18:36:16.795729
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

    a = SingletonTest()
    b = SingletonTest()
    assert(id(a) == id(b))

# Generated at 2022-06-11 18:36:24.350166
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    # Create the singleton test class
    from ipalib import api

    class SingletonTest(api.Api):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.called = True
            super(SingletonTest, self).__init__(*args, **kwargs)

    integer = 1

    # Instantiate the singleton
    obj = SingletonTest(integer)

    assert(obj.called)
    assert(isinstance(obj, SingletonTest))
    assert(isinstance(obj, api.Api))
    assert(obj.__class__ == SingletonTest)
    assert(obj.__class__ == api.Api)
    assert(obj == SingletonTest(integer))

    # Restore original Api class
    api.Api = api._Api

# Generated at 2022-06-11 18:36:30.917379
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self):
            # Make sure class is being instantiated only once.
            # We will use the class level variable count for this purpose.
            if not hasattr(S, 'count'):
                type(S).count = 0
            type(S).count += 1

        @classmethod
        def get_count(cls):
            return cls.count

    # Instantiate the class and verify that count is 1.
    s = S()
    assert S.count == 1

    # Calling __call__ directly
    s = S.__call__()
    assert S.count == 1

    # Instantiate the class again and verify that the value of count remains 1.
    s = S()
    assert S.count == 1

    # Instantiate the class

# Generated at 2022-06-11 18:36:36.073425
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class AwesomeClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

        def __eq__(self, right):
            return self.value == right.value

    # Create two instances of AwesomeClass
    obj1 = AwesomeClass(42)
    obj2 = AwesomeClass(42)

    # Check if both instances are the same one (returned by Singleton)
    assert obj1 is obj2

# Generated at 2022-06-11 18:36:41.778031
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a class that derives from Singleton
    class MyClass(object):
        __metaclass__ = Singleton

    # Instantiate the class
    my_class_01 = MyClass()

    # Subsequent calls to the class should return the same instance
    my_class_02 = MyClass()
    assert my_class_01 == my_class_02
    print('Test __call__ of class Singleton is OK')



# Generated at 2022-06-11 18:36:47.704457
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    c1 = C('foo')
    c2 = C('bar')

    assert c1.foo == 'foo'
    assert c2.foo == 'foo'

# Generated at 2022-06-11 18:36:55.617651
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

        def __init__(self, a=2):
            self.a = a

    class C(object):
        __metaclass__ = Singleton

        def __init__(self, a=3):
            self.a = a

    a1 = A()
    a2 = A()
    assert a1 is a2

    b1 = B()
    b2 = B()
    assert b1 is b2
    assert b1.a == 2
    assert b2.a == 2

    c1 = C()
    c2 = C()
    assert c1 is c2
    assert c1.a == 3
    assert c2.a == 3

# Generated at 2022-06-11 18:37:06.848077
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    from collections import namedtuple

    class Foo(metaclass=Singleton):
        bar = 'bar'

    # Test that the class can be instantiated directly.
    with unittest.TestCase() as tc:
        tc.assertIsInstance(Foo(), Foo)
        tc.assertIs(Foo(), Foo())
        tc.assertFalse(Foo() is Foo())
        # And it can be instantiated indirectly.
        tc.assertIsInstance(Foo.__call__(), Foo)
        tc.assertIs(Foo.__call__(), Foo.__call__())
        tc.assertFalse(Foo.__call__() is Foo.__call__())

    # Test that the class is initialized once.

# Generated at 2022-06-11 18:37:14.849606
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    a = MyClass()

    try:
        b = MyClass()
    except:
        assert False, "several instances of MyClass are created when they should be singleton."

    assert a is b, "several instances of MyClass are created when they should be singleton."

# Generated at 2022-06-11 18:37:19.635263
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(metaclass=Singleton):
        def __init__(self):
            pass

    class MyNonSingleton(object):
        def __init__(self):
            pass

    a = MySingleton()
    b = MySingleton()

    assert a is b

    c = MyNonSingleton()
    d = MyNonSingleton()

    assert c is not d

# Generated at 2022-06-11 18:37:23.864067
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    # T1
    ins1 = TestSingleton()
    assert ins1 is TestSingleton()

    # T2
    TestSingleton.__instance = None
    ins2 = TestSingleton()
    assert ins2 is TestSingleton()

# Generated at 2022-06-11 18:37:25.575132
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestSingle(object):
        __metaclass__ = Singleton

    test1 = TestSingle()
    test2 = TestSingle()

    assert test1 is test2


# Generated at 2022-06-11 18:37:27.669162
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest:
        __metaclass__ = Singleton

    a = SingletonTest()
    b = SingletonTest()
    assert id(a) == id(b)

# Generated at 2022-06-11 18:37:29.828437
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingelton(object):
        __metaclass__ = Singleton

    a = TestSingelton()
    b = TestSingelton()
    assert(a == b)

# Generated at 2022-06-11 18:37:33.477633
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest

    @six.add_metaclass(Singleton)
    class CustomSingletonClass(object):
        def __init__(self):
            pass

    a = CustomSingletonClass()
    b = CustomSingletonClass()
    assert a is b



# Generated at 2022-06-11 18:37:41.584108
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    first = TestSingleton(1)
    second = TestSingleton(2)
    assert(first is second)

    class TestSingleton2(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    second = TestSingleton(2)
    assert(first is second)

    class TestSingleton3(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    second = TestSingleton(2)
    asser

# Generated at 2022-06-11 18:37:45.843671
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    s = TestSingleton()
    assert s.a == 1
    assert TestSingleton() is s

# Generated at 2022-06-11 18:37:48.748342
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Dog(object, metaclass=Singleton):
        pass

    a = Dog()
    b = Dog()
    assert a == b


# Generated at 2022-06-11 18:38:00.444453
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    one = TestSingleton()
    assert one
    two = TestSingleton()
    assert one is two

# Generated at 2022-06-11 18:38:03.760942
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self._name = name

    a = A('S')
    a1 = A('S')
    assert a1 == a
    assert a1 is a


# Generated at 2022-06-11 18:38:09.757271
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    instance1 = SingletonTestClass()
    instance2 = SingletonTestClass()

    # both instance1 and instance2 should link to the same memory address
    assert instance1 is instance2

    # the name of the class should be 'SingletonTestClass' instead of 'instance'
    assert instance1.__class__.__name__ == 'SingletonTestClass'

# Generated at 2022-06-11 18:38:17.927174
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        counter = 0
        def __init__(self, *args, **kwargs):
            self.__class__.counter += 1
            self.args = args
            self.kwargs = kwargs

    # Test that the constructor is called correctly when instantiating
    # the singleton
    test1 = TestClass(1)
    assert test1.counter == 1
    assert test1.args == (1,)
    assert test1.kwargs == {}

    # Test that subsequent calls return the same instance and that the
    # constructor is not called with the arguments
    test2 = TestClass(2)
    assert test2.counter == 1
    assert test1.args == (1,)
    assert test1.kwargs == {}
    assert test1 is test2

    # Test that the constructor

# Generated at 2022-06-11 18:38:22.245665
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

# Generated at 2022-06-11 18:38:29.161037
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            if not hasattr(self, 'called'):
                self.called = 0
            self.called += 1

    assert TestSingleton.called == 0, 'Singleton not initialized'

    t1 = TestSingleton()
    assert t1.called == 1, 'Singleton not initialized'
    t2 = TestSingleton()
    assert t2.called == 1, 'Singleton not reused'
    assert t1 is t2, 'Singleton not reused'

    del t1
    del t2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:38:33.593062
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

    class TestClass2(object):
        __metaclass__ = Singleton

    test_instance = TestClass()
    test_instance2 = TestClass()
    assert test_instance is test_instance2, "Instance not equal"

    test_instance = TestClass2()
    test_instance2 = TestClass2()
    assert test_instance is test_instance2, "Instance not equal"

# Generated at 2022-06-11 18:38:44.486915
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from inspect import isfunction
    from threading import Thread

    class TestSingleton(object):
        __metaclass__ = Singleton
        i = 0

        def _inc(self):
            self.i += 1

    # Create a class instance
    ts1 = TestSingleton()
    # Create another class instance
    ts2 = TestSingleton()
    # Create a third class instance
    ts3 = TestSingleton()

    # Check if the singletons are the same
    if ts1 is not ts2:
        raise Exception("Not singleton")
    elif ts1 is not ts3:
        raise Exception("Not singleton")
    elif ts2 is not ts3:
        raise Exception("Not singleton")

    # Check if the method is a bound method
    if not isfunction(ts1._inc):
        raise Exception

# Generated at 2022-06-11 18:38:47.109227
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-11 18:38:49.896492
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonClass(object):
        __metaclass__ = Singleton

    def assert_is_the_same(obj1, obj2):
        assert obj1 is obj2

    s1 = SingletonClass()
    s2 = SingletonClass()
    assert_is_the_same(s1, s2)

# Generated at 2022-06-11 18:39:02.941824
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        pass

    f = Foo()
    g = Foo()
    assert(id(f) == id(g))

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:39:05.727414
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    a = Foo()
    b = Foo()
    assert a == b

# Generated at 2022-06-11 18:39:07.448333
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert(t1 == t2)

# Generated at 2022-06-11 18:39:10.855520
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 0

    obj1 = A()
    obj2 = A()

    assert(obj1 == obj2)


# Generated at 2022-06-11 18:39:13.072893
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 == a2


# Generated at 2022-06-11 18:39:23.539479
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from yaml.scanner import ScannerError

    from ansibullbot.triagers.plugins.extractors.tickets import TicketsExtractor
    from ansibullbot.triagers.plugins.extractors.pr_context import PRContextExtractor
    from ansibullbot.triagers.plugins.extractors.modules import ModuleExtractor
    from ansibullbot.triagers.plugins.extractors.labels import LabelExtractor

    class TestClass(metaclass=Singleton):
        pass

    class TestClass2(metaclass=Singleton):
        def __init__(self, arg1):
            self.arg1 = arg1

    instances = []
    for i in range(10):
        instance = TestClass()
        instances.append(instance)

    assert len(set(instances)) == 1


# Generated at 2022-06-11 18:39:27.465485
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    a1 = A(1, 2)
    a2 = A(3, 4)
    assert a1 is a2
    assert a1.a == 1
    assert a1.b == 2



# Generated at 2022-06-11 18:39:38.220940
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

    class SingletonTest2(object):
        __metaclass__ = Singleton

    # Confirm that SingletonTest and SingletonTest2 are unique classes
    assert(SingletonTest != SingletonTest2)

    # Confirm that instantiations of SingletonTest and SingletonTest2 are unique
    assert(SingletonTest() != SingletonTest2())

    # Confirm that instantiations of SingletonTest and SingletonTest2 are the same objects
    assert(id(SingletonTest()) == id(SingletonTest()))
    assert(id(SingletonTest2()) == id(SingletonTest2()))

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:39:46.575771
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(Singleton):
        def __init__(self, arg1, arg2, arg3='c'):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3
        def __str__(self):
            return str(self.__class__) + ": " + str((self.arg1, self.arg2, self.arg3))
    t1 = Test('a', 'b')
    t2 = Test('a', 'b')
    assert t1 == t2
    assert t1.arg1 == t2.arg1
    assert t1.arg2 == t2.arg2
    assert t1.arg3 == t2.arg3

# Generated at 2022-06-11 18:39:54.057825
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.init = True

    class Test1(Test):
        def __init__(self):
            self.init = True

    class TestSingleton(unittest.TestCase):
        def setUp(self):
            self.instancia = Test()
            self.instancia1 = Test1()
        def test_tiempo(self):
            self.assertEqual(self.instancia, self.instancia1)
    unittest.main()
#test_Singleton__call__()

# Generated at 2022-06-11 18:40:13.838970
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()



# Generated at 2022-06-11 18:40:15.941100
# Unit test for constructor of class Singleton
def test_Singleton():
    s = Singleton("Basic",(),{})
    assert s.__class__.__name__ == "Basic"



# Generated at 2022-06-11 18:40:20.294889
# Unit test for constructor of class Singleton
def test_Singleton():
    class foo(object):
        __metaclass__ = Singleton

    f1 = foo()
    f2 = foo()
    assert f1 is f2, 'Singleton should make one instance of the class'



# Generated at 2022-06-11 18:40:31.696666
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test method __call__
    """
    # TestSingle is a subclass of Singleton
    # so it has only one instance
    class TestSingle(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    # TestMulti is not a subclass of Singleton
    # so it can have many different instances
    class TestMulti(object):

        def __init__(self, name):
            self.name = name

    t1 = TestMulti('t1')
    t2 = TestMulti('t2')

    ts1 = TestSingle('ts1')
    ts2 = TestSingle('ts2')

    assert ts1 is ts2
    assert t1 is not t2


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-11 18:40:37.108568
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a new class which is a subclass of Singleton
    class Example:
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.value = arg

    # Instantiate the class and check that it has the singleton property
    a = Example(1)
    b = Example(2)
    assert a == b
    # The assert above is equivalent to the two asserts below
    assert a.value == b.value
    assert a is b

    # Ensure the class singleton property is only true when the class
    # is a subclass of the Singleton class
    class NotExample:
        def __init__(self, arg):
            self.value = arg

    c = NotExample(3)
    d = NotExample(4)
    assert c.value != d.value
    assert c is not d

# Generated at 2022-06-11 18:40:40.548269
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    test1 = SingletonTest()
    assert test1 != None
    test2 = SingletonTest()
    assert test2 != None
    assert test1 == test2

# Generated at 2022-06-11 18:40:44.565045
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

    s1 = SingletonTest()
    s2 = SingletonTest()
    assert s1 is not None and s2 is not None
    assert s1 == s2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-11 18:40:54.073429
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self, num):
            self.num = num


    class TestClass(object):
        def __init__(self, num):
            self.num = num

    test_singleton_obj1 = TestSingletonClass(10)
    print('object address for test_singleton_obj1: {}'.format(hex(id(test_singleton_obj1))))
    test_singleton_obj2 = TestSingletonClass(20)
    print('object address for test_singleton_obj2: {}'.format(hex(id(test_singleton_obj2))))
    print('object data for test_singleton_obj1: {}'.format(test_singleton_obj1.num))

# Generated at 2022-06-11 18:40:59.127427
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 'bar'

        def __call__(self):
            return self.foo

    def get_instance():
        return A()

    a = get_instance()
    b = get_instance()
    assert a == b
    assert a() == b()

# Generated at 2022-06-11 18:41:02.374139
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_obj1 = TestSingleton()
    test_obj2 = TestSingleton()
    assert test_obj1 is test_obj2

# Generated at 2022-06-11 18:41:14.717529
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class T(object):
        __metaclass__ = Singleton

    # pylint: disable=assignment-from-no-return
    t1 = T()
    t2 = T()

    assert (t1 == t2)
    assert (t1 is t2)

# Generated at 2022-06-11 18:41:17.116061
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 5

    assert Test() is Test()
    Test().a = 10
    assert Test().a == 10
    Test().__instance = None



# Generated at 2022-06-11 18:41:20.577883
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class singleton(object):
        __metaclass__ = Singleton

    a = singleton()
    b = singleton()
    assert(a == b)



# Generated at 2022-06-11 18:41:23.250830
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()

    assert id(a) == id(b)


# Generated at 2022-06-11 18:41:26.294151
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = A()
    b = A()
    assert(a is b)
# end of unit test for Singleton