

# Generated at 2022-06-25 13:34:17.648606
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    int_0 = None
    set_0 = {int_0, int_0}
    dict_0 = {set_0: int_0, int_0: set_0}


# Generated at 2022-06-25 13:34:22.755549
# Unit test for constructor of class Singleton
def test_Singleton():
    try:
        from boto.cloudformation.stack import Stack
        try:
            from boto.cloudformation.stack import _Singleton
            c = _Singleton()
            c.__init__()
        except Exception as ex:
            print('Test Failed')
    except ImportError:
        print('Test Failed')


# Generated at 2022-06-25 13:34:32.135929
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import logging
    import threading
    import time

    # Test setup
    #   Create a singleton that prints "Hello world" when instantiated
    #   Create a singleton that prints "Goodbye cruel world" when
    #     instantiated.
    #   Create a singleton that prints "I'm confused" when instantiated.
    #   Create a singleton that prints "Me too" when instantiated.
    #   Create a singleton that prints "This is getting ridiculous" when
    #     instantiated.
    #   Create a singleton that prints "I can't take it anymore" when
    #     instantiated.
    #   Create a singleton that prints "I'm not sure I'm really here" when
    #     instantiated.
    #   Create a singleton that prints "I'm not sure I'm really here" when
    #     instant

# Generated at 2022-06-25 13:34:39.048966
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    long_0 = long()
    long_2 = long()
    long_1 = long()
    # test class Singleton - test case __call__ - asserts
    assert not hash(long_0) is hash(long_1)
    assert not long_1 is long_2
    assert long_2 in dict_0
    assert bool(dict_0) is True
    assert bool(int_0) is False
    assert bool(set_0) is True
    assert set_0 == set()
    assert set() == set_0
    assert dict_0 == dict()
    assert dict() == dict_0
    assert int_0 == 0
    assert 0 == int_0
    assert (long_0 - long_1) not in dict_0
    assert len(set_0) is 1
    assert float(0) is not float

# Generated at 2022-06-25 13:34:46.171753
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create new instance of Singleton
    instance_0 = Singleton()
    # Assert instance type of instance_0 is Singleton
    assert isinstance(instance_0, Singleton) == True

    # Create another instance of Singleton
    instance_1 = Singleton()
    # Assert instance_0 is instance_1
    assert instance_0 == instance_1

    # Create another instance of Singleton
    instance_2 = Singleton()
    # Assert instance_0 is instance_2
    assert instance_0 == instance_2


# Generated at 2022-06-25 13:34:47.874703
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """This is a stub to test __call__"""
    pass


# Generated at 2022-06-25 13:34:52.958118
# Unit test for constructor of class Singleton
def test_Singleton():
    int_0 = 10
    a = Singleton()
    assert(a.int_0 == 10)
    assert(a.__rlock is not None)
    assert(a.__instance is None)
    set_0 = {int_0, int_0}
    dict_0 = {set_0: int_0, int_0: set_0}


# Generated at 2022-06-25 13:34:59.971249
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print("\n# Test case 0")

    class TestSingleton0(metaclass=Singleton):
        pass

    a = TestSingleton0()
    b = TestSingleton0()
    assert id(a) == id(b)

    class TestSingleton1(metaclass=Singleton):
        def __init__(self):
            self.obj = []

    a = TestSingleton1()
    b = TestSingleton1()
    assert b.obj == []
    assert id(a) == id(b)
    assert a is b

    a.obj.append(5)
    assert b.obj == [5]
    assert id(a) == id(b)
    assert a is b


# Generated at 2022-06-25 13:35:01.768634
# Unit test for constructor of class Singleton
def test_Singleton():
    assert isinstance(Singleton('name', 'bases', 'dct'), Singleton)


# Generated at 2022-06-25 13:35:02.713803
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()


# Generated at 2022-06-25 13:35:08.468526
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        """A test class to test the Singleton Metaclass"""
        __metaclass__ = Singleton

    s1 = TestSingleton()
    s2 = TestSingleton()
    assert (s1 is s2)


# Generated at 2022-06-25 13:35:09.614211
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    assert A() is A()



# Generated at 2022-06-25 13:35:09.943709
# Unit test for constructor of class Singleton
def test_Singleton():
    pass

# Generated at 2022-06-25 13:35:13.509372
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonSingleton(object):
        __metaclass__ = Singleton

    s1 = SingletonSingleton()
    # if __call__ is not implemented properly, s2 and s1 will be different objects
    s2 = SingletonSingleton()
    assert id(s1) == id(s2)

# Generated at 2022-06-25 13:35:18.200038
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test:
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    t = Test()
    u = Test()

    assert(t.value == 1)
    assert(u.value == 1)

    t.value = 5
    assert(u.value == 5)

# Test method of class Singleton
# Test whether the Singleton object is
# shared among different class objects.

# Generated at 2022-06-25 13:35:22.864879
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from six import add_metaclass

    @add_metaclass(Singleton)
    class C(object):
        def __init__(self):
            self.a = 1

    c1 = C()
    assert c1.a == 1
    c2 = C()
    assert c2.a == 1
    assert c1 is c2
    c1.a = 2
    assert c2.a == 2
    c2.a = 3
    assert c1.a == 3



# Generated at 2022-06-25 13:35:24.609823
# Unit test for constructor of class Singleton
def test_Singleton():
    class test_class(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    assert 1 is 1

# Generated at 2022-06-25 13:35:26.650788
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Temp(object):
        __metaclass__ = Singleton

    one = Temp()
    another = Temp()

    assert one is another


# Generated at 2022-06-25 13:35:30.869734
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_var = True

    obj1 = SingletonTestClass()
    obj2 = SingletonTestClass()

    assert obj1 == obj2
    assert obj1 is obj2

    assert obj1.test_var
    assert obj2.test_var

    obj1.test_var = False
    assert not obj2.test_var

# Generated at 2022-06-25 13:35:35.174898
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        some_var = 1

    a = TestClass()
    b = TestClass()
    # Singleton should return the same instance
    assert a is b
    # Singleton instance should contain some_var
    assert hasattr(a, 'some_var')


# Generated at 2022-06-25 13:35:39.903348
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton is not None


# Generated at 2022-06-25 13:35:42.116800
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Object(object):
        __metaclass__ = Singleton
    a = Object()
    b = Object()
    assert a is b


# Generated at 2022-06-25 13:35:46.523801
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        pass
    assert Test() is Test()


from ansible.module_utils._text import to_native
from ansible.module_utils.six import iteritems
from ansible.module_utils.six.moves import xrange
from ansible.utils.display import Display

display = Display()



# Generated at 2022-06-25 13:35:47.796912
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object, metaclass=Singleton):
        pass

    test1 = A()
    test2 = A()

    assert test1 is test2


# Generated at 2022-06-25 13:35:53.019828
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a = A(2)
    b = A(3)
    assert a is b
    assert a.value == b.value

    class B:
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    c = B(1)
    assert a is not c
    assert c.value == 1



# Generated at 2022-06-25 13:35:54.923906
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    foo = Foo()
    foobar = Foo()
    assert foo is foobar

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:35:58.684273
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Instantiate a class that is implemented using the Singleton metaclass
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.call_count = 0

    # Instantiate the class three times and make sure that the objects
    # are the same.
    one = MySingleton()
    two = MySingleton()
    three = MySingleton()
    assert one == two == three

    # Make sure that the call to the constructor is only made once.
    one.call_count = 1
    two.call_count = 2
    three.call_count = 3
    assert one.call_count == two.call_count == three.call_count

    # Unit test for method __call__ of class Singleton
    # This is test for verifying bug #28250 is fixed.

# Generated at 2022-06-25 13:36:08.009812
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(metaclass=Singleton):
        def __init__(self):
            print('TestClass __init__ called.')
            self.a = 100
            self.b = 200
        def __str__(self):
            return 'a = %s, b = %s' % (str(self.a), str(self.b))
        def __repr__(self):
            return 'TestClass'

    assert TestClass() is TestClass()
    assert TestClass() is TestClass()
    assert TestClass() is TestClass()
    assert TestClass() is TestClass()
    assert TestClass() is TestClass()
    assert TestClass() is TestClass()
    assert TestClass() is TestClass()
    assert TestClass() is TestClass()
    assert TestClass() is TestClass()
    assert TestClass() is Test

# Generated at 2022-06-25 13:36:16.449159
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        def __init__(self, a, b):
            self.__a = a
            self.__b = b

        def print(self):
            print("a = " + self.__a)
            print("b = " + self.__b)

    obj1 = TestClass("apple", "ball")
    obj2 = TestClass("car", "dog")
    obj3 = TestClass("house", "igloo")
    assert obj1 is obj2 and obj1 is obj3
    obj1.print()

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:36:20.603379
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(Singleton):
        def __init__(self):
            self.c = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 == t2
    assert type(t1) == type(t2)
    assert t1.c == t2.c


# Generated at 2022-06-25 13:36:30.245055
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-25 13:36:39.409136
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.item = 0
            self.item_list = []
            self.item_list.append(self)

    a = A()
    a.item += 1
    b = A()
    b.item += 2
    print(a.item)
    print(b.item)
    c = A()
    assert a is b is c
    assert a.item == 3
    assert b.item == 3
    assert a.item_list == [a]
    print(a.item_list)
    print(b.item_list)
    assert b.item_list == [a]
    assert c.item_list == [a]

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:36:49.001380
# Unit test for constructor of class Singleton
def test_Singleton():

    if __name__ == "__main__":
        # import sys
        # if len(sys.argv) > 1 and sys.argv[1] == 'test':
        #     print('test mode')
        #     from log import Logger
        #     from cli import Argv
        # else:
        #     from .log import Logger
        #     from .cli import Argv

        from log import Logger
        from cli import Argv

        argv = Argv('', '', 'init')
        log = Logger()
        log.add_logfile('/tmp/debug.log')
        log.add_loglevel('debug')
        log.add_verbose(2)

        # test singleton
        s1 = Singleton('TestSingleton1', (), {})

# Generated at 2022-06-25 13:36:52.467457
# Unit test for constructor of class Singleton
def test_Singleton():
    class Example(object):
        __metaclass__ = Singleton

        def __init__(self, var):
            self.number = 0
            self.var = var

    instance1 = Example(1)
    instance2 = Example(2)

    assert(instance1.number == instance2.number)


# Generated at 2022-06-25 13:36:58.228153
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import threading

    class TestSingleton(metaclass=Singleton):
        def __init__(self, n):
            self.n = n

    a = TestSingleton(1)
    b = TestSingleton(2)
    # a and b are the same object
    assert a is b
    assert a.n == 1

    c = TestSingleton.__call__(TestSingleton, 3)
    # c is a new object using __call__
    assert a is not c
    assert c.n == 3

    # Test for multithreading
    result = {}

    def test(cnt):
        for i in range(cnt):
            result[i] = TestSingleton.__call__(TestSingleton, i)


# Generated at 2022-06-25 13:37:02.054878
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            super(Test, self).__init__()
    test1 = Test()
    test2 = Test()
    assert id(test1) == id(test2)

# Generated at 2022-06-25 13:37:06.044359
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTestObject(object):
        __metaclass__ = Singleton

    x = SingletonTestObject()
    y = SingletonTestObject()
    assert(x == y)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:37:07.195082
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SExtra(object):
        __metaclass__ = Singleton

    # Create two instances
    a = SExtra()
    b = SExtra()

    # Check if are the same
    assert a == b


# Generated at 2022-06-25 13:37:10.612436
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class TestClass(metaclass=Singleton):
        pass

    class TestSingleton(unittest.TestCase):
        def test_Singleton__call__(self):
            self.assertIs(TestClass(), TestClass())

    unittest.main()

# Generated at 2022-06-25 13:37:13.729596
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    import pytest

    with pytest.raises(AssertionError):
        a = A()
        a.__metaclass__ = Singleton()

    assert A() is A()

# Generated at 2022-06-25 13:37:23.741469
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert singleton_0.__call__(str_0) is singleton_0

# Generated at 2022-06-25 13:37:30.470695
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Arrange
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = (str_0)
    var_1 = {str_0: str_0}
    singleton_0 = Singleton(str_0, var_0, var_1)

    # Act
    var_2 = singleton_0.__call__(str_0)

    # Assert
    assert var_2 == (str_0)
    assert var_1 == {str_0: str_0}

if __name__ == "__main__":
    test_Singleton___call__()

# vim: set filetype=python set spell spelllang=en wrap lbr:

# Generated at 2022-06-25 13:37:31.031449
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-25 13:37:32.756297
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        assert True
    except AssertionError:
        raise AssertionError('Test failed', var_0)


# Generated at 2022-06-25 13:37:33.467376
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass


# Generated at 2022-06-25 13:37:35.921712
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)
    var_3 = singleton_0.__call__(str_0)
    assert var_3 == var_2

# Generated at 2022-06-25 13:37:36.958762
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True



# Generated at 2022-06-25 13:37:37.464508
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    
    assert True

# Generated at 2022-06-25 13:37:47.122912
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_2 = 'Trying to get value from cache, but cache is empty.  Exiting'
    str_3 = 'CACHE_MISS'
    str_4 = 'NaN'
    str_5 = 'nan'
    try:
        var_3 = (str_4 == str_5)
        if not var_3:
            raise Exception('Assertion failed')
    except Exception as var_4:
        print('Exception message: ' + str(var_4))
    str_6 = 'Received HTTP error for %s : %s'
    var_5 = ()
    var_6 = {}
    singleton_1 = Singleton(str_6, var_5, var_6)
    singleton_1.__call__(str_6)

# Generated at 2022-06-25 13:37:48.090255
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# vim: set ft=python :

# Generated at 2022-06-25 13:37:58.402204
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:38:00.270717
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = Singleton()
    var_0 = singleton_0.__call__()


# Generated at 2022-06-25 13:38:02.521020
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert (Singleton.__call__(Singleton, Singleton) == 'Received HTTP error for %s : %s')


# Generated at 2022-06-25 13:38:03.225177
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True


# Generated at 2022-06-25 13:38:04.651982
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # test case
    test_case_0()



# Generated at 2022-06-25 13:38:05.243139
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-25 13:38:13.591204
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'd'
    var_0 = (str_0)
    var_1 = {}
    # 1st call
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__(str_0)
    # 2nd call
    var_2 = ()
    singleton_1 = Singleton(str_0, var_2, var_1)
    singleton_1.__call__(str_0)
    # 3rd call
    var_3 = ()
    singleton_2 = Singleton(str_0, var_3, var_1)
    singleton_2.__call__(str_0)
    # 4th call
    var_4 = ()

# Generated at 2022-06-25 13:38:15.949512
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert var_2 == singleton_0


# Generated at 2022-06-25 13:38:19.297540
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)

# Generated at 2022-06-25 13:38:20.711302
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 13:38:37.979597
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'Received HTTP error for %s : %s'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    # Access the singleton using the method __call__ of class Singleton.
    var_4 = singleton_0.__call__(str_1)

# Generated at 2022-06-25 13:38:39.859381
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = 0
    if var_3 == 0:
        test_case_0()
    else:
        return


# Generated at 2022-06-25 13:38:44.255051
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)

# Generated at 2022-06-25 13:38:54.012461
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton('vk9', var_0, var_1)
    var_2 = singleton_0.__call__('vk9')
    var_3 = 'Received HTTP error for %s : %s'
    var_4 = ()
    var_5 = {}
    singleton_1 = Singleton(var_3, var_4, var_5)
    var_6 = singleton_1.__call__(var_3)
    var_7 = 'Received HTTP error for %s : %s'
    var_8 = ()
    var_9 = {}
    singleton_2 = Singleton(var_7, var_8, var_9)

# Generated at 2022-06-25 13:38:54.793909
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True;


# Generated at 2022-06-25 13:38:57.716313
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = 'Received HTTP error for %s : %s'
    var_1 = ()
    var_2 = {}
    singleton_0 = Singleton(var_0, var_1, var_2)
    singleton_0.__call__(var_0)


# Generated at 2022-06-25 13:39:02.289977
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)

# Generated at 2022-06-25 13:39:07.578580
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    for i in range(10):
        # Unit test for method __call__ of class Singleton
        var_2 = singleton_0.__call__(str_0)
        assert var_2

# Generated at 2022-06-25 13:39:08.425184
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True == True


# Generated at 2022-06-25 13:39:13.447957
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # This doesn't seem to be used so just make sure it works.
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)
    assert var_2.__class__.__name__ == 'type'

# Generated at 2022-06-25 13:39:38.574100
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Failed to establish a new connection: [Errno 111] Connection refused'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)


# Generated at 2022-06-25 13:39:43.205000
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    var_2 = {'__module__', '__weakref__', '__dict__', '__init__', '__doc__'}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert_equal(var_2, singleton_0.__class__.__dict__.keys())


# Unit testing of class Singleton

# Generated at 2022-06-25 13:39:43.649384
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True


# Generated at 2022-06-25 13:39:50.321303
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)
    str_1 = 'Received HTTP error for %s : %s'
    var_3 = ()
    var_4 = {}
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = singleton_1.__call__(str_1)
    assert var_2 is var_5


# Generated at 2022-06-25 13:39:51.985507
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    x = Singleton.__call__('y')
    assert x == 'y', "Assertion failed"

test_case_0()

# Generated at 2022-06-25 13:39:56.253612
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)

# Generated at 2022-06-25 13:40:01.286046
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        singleton_0 = Singleton()
        str_0 = 'Received HTTP error for %s : %s'
        var_0 = ()
        var_1 = {}
        singleton_1 = singleton_0.__call__(str_0, var_0, var_1)
    except:
        return 1
    else:
        return 0
    return 1


# Generated at 2022-06-25 13:40:04.796557
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)

# Generated at 2022-06-25 13:40:09.158126
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)
    assert var_2 == singleton_0, 'var_2'

# unit test class Singleton

# Generated at 2022-06-25 13:40:11.795123
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'e'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)


# Generated at 2022-06-25 13:41:03.045002
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)



# Generated at 2022-06-25 13:41:04.424160
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = test_case_0()
    assert var_0 == None

# Generated at 2022-06-25 13:41:13.688765
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = 'Received HTTP error for %s : %s'
    var_4 = ()
    var_5 = {}
    singleton_1 = Singleton(var_3, var_4, var_5)
    var_6 = singleton_1.__call__(var_3)
    var_6 = singleton_1.__call__(var_3)
    var_7 = var_6.__init__(var_3)
    singleton_1.__instance = var_6
    singleton_1.__rlock = var_7
    str_1 = 'Received HTTP error for %s : %s'
    var_8 = ()
    var_9 = {}
    singleton_2 = Singleton(str_1, var_8, var_9)


# Generated at 2022-06-25 13:41:15.150842
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create an instance of class Singleton
    singleton_0 = Singleton(str, (), {})


# Generated at 2022-06-25 13:41:18.602404
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)



# Generated at 2022-06-25 13:41:23.051802
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_1 = '0'
    var_0, var_1 = '1', '2'
    singleton_0 = Singleton()
    var_2 = {}
    var_2 = singleton_0(var_1, var_0, str_1)


# Generated at 2022-06-25 13:41:25.642223
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase
    class Test___call(TestCase):
        def test___call__0(self):
            test_case_0()
    test = Test___call()
    test.test___call__0()

# Generated at 2022-06-25 13:41:29.146790
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)

# Generated at 2022-06-25 13:41:37.111441
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Encountered HTTP error'
    str_1 = 'Received HTTP error for %s : %s'
    var_0 = (str_0,)
    var_1 = {}
    singleton_0 = Singleton(str_1, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)
    if (var_2 != None):
        raise RuntimeError('Wrong value for var_2: Got "%s", expected None.' % (var_2,))

    str_2 = ''
    str_3 = 'Encountered error: %s'
    var_3 = ()
    var_4 = {'__doc__': None}
    singleton_1 = Singleton(str_3, var_3, var_4)
    var_5 = single

# Generated at 2022-06-25 13:41:40.228237
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        test_case_0()
    except Exception as exception:
        print('exception')

# Generated at 2022-06-25 13:43:31.109818
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# vim: set ft=python et ts=4 sw=4 :

# Generated at 2022-06-25 13:43:32.049969
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:43:32.834171
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert 1 == 1


# Generated at 2022-06-25 13:43:35.836935
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)



# Generated at 2022-06-25 13:43:38.314681
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)



# Generated at 2022-06-25 13:43:41.292473
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # variable: singleton_0
    singleton_0 = Singleton(None, None, None)
    # variable: var_0
    var_0 = None
    # variable: var_1
    var_1 = None
    # calling method __call__ of class Singleton
    var_2 = singleton_0.__call__(var_0, var_1)


# Generated at 2022-06-25 13:43:44.723994
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)

# Generated at 2022-06-25 13:43:47.616116
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__(str_0)


# Generated at 2022-06-25 13:43:50.529915
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Received HTTP error for %s : %s'
    var_0 = ()
    var_1 = {'s': 'pwH'}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = singleton_0.__call__(str_0)
    return str_1


# Generated at 2022-06-25 13:43:56.039995
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        str_0 = 'Received HTTP error for %s : %s'
        var_0 = ()
        var_1 = {}
        singleton_0 = Singleton(str_0, var_0, var_1)
        var_2 = singleton_0.__call__(str_0)
        if (str_0 is var_2):
            print('<Test case 0 passed>')
        else:
            print('<Test case 1 failed>')
            print('<Expected: %s>' % str_0)
            print('<Received: %s>' % var_2)
    except Exception:
        print('<Exception caught>')
