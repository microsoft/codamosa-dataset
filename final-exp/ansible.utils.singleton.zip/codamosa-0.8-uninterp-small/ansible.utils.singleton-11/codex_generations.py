

# Generated at 2022-06-25 13:34:20.068564
# Unit test for constructor of class Singleton
def test_Singleton():
    bool_0 = False
    dict_0 = {}
    list_0 = [dict_0, bool_0, dict_0, dict_0]
    singleton_0 = Singleton(bool_0, bool_0, dict_0, list_0)
    # __init__ of Singleton testing successful
    assert True

# Generated at 2022-06-25 13:34:30.229968
# Unit test for constructor of class Singleton
def test_Singleton():
    # Purpose: Test constructor with different parameters
    # Input: No input
    # Expected Output: should init a class without error
    # Observed Output: None

    # method test_case_0
    test_case_0()

    # method test_case_1
    bool_0 = (1 != 0)
    dict_0 = {}
    list_0 = [dict_0, bool_0, dict_0, dict_0]
    singleton_0 = Singleton(bool_0, bool_0, dict_0, list_0)

    # method test_case_2
    bool_0 = (1 != 0)
    dict_0 = {}
    list_0 = [dict_0, bool_0, dict_0, dict_0]

# Generated at 2022-06-25 13:34:31.195336
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:34:36.934145
# Unit test for constructor of class Singleton
def test_Singleton():
    # Parameters for test_case_1
    dict_0 = {}
    list_1 = [dict_0, dict_0, dict_0, dict_0]
    dict_1 = {}
    # Parameters for test_case_2
    dict_2 = {}
    # Parameters for test_case_3
    dict_3 = {}

    test_case_0()
    test_case_1(dict_0, dict_1, list_1)
    test_case_2(dict_2)
    test_case_3(dict_3)

# Tests for Singleton

# Generated at 2022-06-25 13:34:43.781967
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    bool_1 = False
    bool_0 = bool_1
    dict_0 = {}
    list_0 = [dict_0, bool_1, dict_0, dict_0]
    
    singleton_0 = Singleton(bool_0, bool_1, dict_0, list_0)
    singleton_0()
    assert singleton_0.__instance is not None
    assert singleton_0.__rlock is None

# Generated at 2022-06-25 13:34:47.615083
# Unit test for constructor of class Singleton
def test_Singleton():
    dict_0 = {}
    list_0 = [dict_0]
    bool_0 = Singleton(dict_0, dict_0, dict_0, list_0)
    assert bool_0 is not None

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:34:50.460170
# Unit test for constructor of class Singleton
def test_Singleton():
  bool_0 = False
  dict_0 = {}
  list_0 = [dict_0, bool_0, dict_0, dict_0]
  singleton_0 = Singleton(bool_0, bool_0, dict_0, list_0)

# Generated at 2022-06-25 13:34:54.895123
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    bool_0 = False
    dict_0 = {}
    list_0 = [dict_0, bool_0, dict_0, dict_0]
    singleton_0 = Singleton(bool_0, bool_0, dict_0, list_0)
    assert singleton_0 is not None

# Generated at 2022-06-25 13:35:01.610063
# Unit test for constructor of class Singleton
def test_Singleton():
    # Check if __call__ method of class Singleton works
    trace_0 = []
    def singleton_0(*args):
        for v in args:
            trace_0.append(v)
        return trace_0
    def test_case_0():
        dict_0 = {}
        list_0 = [dict_0, dict_0, dict_0]
        singleton_1 = Singleton(dict_0, dict_0, dict_0, list_0)
        singleton_1(dict_0, dict_0, dict_0, dict_0, dict_0)
        assert(len(trace_0) == 5)
    test_case_0()
    trace_0 = []
    def test_case_1():
        dict_0 = {}

# Generated at 2022-06-25 13:35:02.536384
# Unit test for constructor of class Singleton
def test_Singleton():
    test_case_0()

# Generated at 2022-06-25 13:35:07.019621
# Unit test for constructor of class Singleton
def test_Singleton():
    obj = Singleton()
    assert isinstance(obj, Singleton)
    assert obj.__class__.__name__ == 'Singleton'


# Generated at 2022-06-25 13:35:08.229631
# Unit test for constructor of class Singleton
def test_Singleton():
    var_0 = Singleton()


# Generated at 2022-06-25 13:35:09.073960
# Unit test for constructor of class Singleton
def test_Singleton():
    var_1 = Singleton()


# Generated at 2022-06-25 13:35:10.225857
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-25 13:35:13.063165
# Unit test for constructor of class Singleton
def test_Singleton():
    # create a new instance
    Singleton(var_0)
    #assert var_0 == 0

    # create another instance
    Singleton(var_1)
    #assert var_0 == 0
    #assert var_1 == 1



# Generated at 2022-06-25 13:35:15.418962
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_1 = Singleton()
    var_2 = False
    assert var_2
    var_3 = True
    assert var_3


# Generated at 2022-06-25 13:35:16.249049
# Unit test for constructor of class Singleton
def test_Singleton():
    pass


# Generated at 2022-06-25 13:35:16.778223
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-25 13:35:17.581695
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    # Test case 0:
    test_case_0()

# Generated at 2022-06-25 13:35:24.140672
# Unit test for constructor of class Singleton

# Generated at 2022-06-25 13:35:28.492373
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton:
        __metaclass__ = Singleton

    instance_1 = TestSingleton()
    instance_2 = TestSingleton()
    assert instance_1 is instance_2


# Generated at 2022-06-25 13:35:30.823661
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    c = TestClass()
    assert a is b
    assert b is c

# Generated at 2022-06-25 13:35:32.828101
# Unit test for constructor of class Singleton
def test_Singleton():

    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    assert a1 is A()

# Generated at 2022-06-25 13:35:41.891377
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import with_metaclass

    class MySingleton(with_metaclass(Singleton, object)):
        def __init__(self):
            pass

    assert MySingleton() == MySingleton()

    # ansible.module_utils.six.with_metaclass doesn't support args and kwargs
    class MySingletonWithArgsKwargs(with_metaclass(Singleton, object)):
        def __init__(self, args, kwargs):
            pass

    # So we expect an exception when checking if MySingletonWithArgsKwargs() == MySingletonWithArgsKwargs()

# Generated at 2022-06-25 13:35:46.616921
# Unit test for constructor of class Singleton
def test_Singleton():
    class test(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("__init__")

    print("test")
    test1 = test()
    print(test1)
    # return
    test2 = test()
    print(test2)
    test3 = test()
    print(test3)



# Generated at 2022-06-25 13:35:47.539732
# Unit test for constructor of class Singleton
def test_Singleton():
    from functools import partial

# Generated at 2022-06-25 13:35:55.252376
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("A.init")

    print("---------")
    a = A()
    b = A()
    print("a: %s (%s)" % (a, id(a)))
    print("b: %s (%s)" % (b, id(b)))

    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            print("B.init")

    print("---------")
    b = B()
    a = A()
    print("a: %s (%s)" % (a, id(a)))
    print("b: %s (%s)" % (b, id(b)))

if __name__ == '__main__':
    test_Singleton___call

# Generated at 2022-06-25 13:36:01.300697
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test call method of class Singleton.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    # Create test object
    singleton_obj1 = Singleton()

    # Do singleton object call
    singleton_obj2 = singleton_obj1()

    # Verify attributes are equal
    assert singleton_obj1 is singleton_obj2



# Generated at 2022-06-25 13:36:06.556479
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.arg1 = None
            self.arg2 = None
            self.arg3 = None

    my_instance1 = SingletonTest()
    my_instance2 = SingletonTest()

    assert id(my_instance1) == id(my_instance2), \
        "Singleton class should always return the same instance id"

# Generated at 2022-06-25 13:36:08.984670
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-25 13:36:18.077213
# Unit test for constructor of class Singleton
def test_Singleton():
    class Obj(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    obj1 = Obj('obj1')
    obj2 = Obj('obj2')
    assert obj1 == obj2
    assert obj1.name == 'obj1'
    assert obj2.name == 'obj1'

# Generated at 2022-06-25 13:36:22.946119
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

    assert not hasattr(SingletonTest, '__instance')
    assert not hasattr(SingletonTest, '__rlock')

    s1 = SingletonTest()
    assert isinstance(s1, SingletonTest)
    assert isinstance(s1, object)

    s2 = SingletonTest()
    assert s1 is s2

# Generated at 2022-06-25 13:36:26.260261
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestSingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.my_list = []

    instance1 = TestSingletonClass()
    instance2 = TestSingletonClass()

    assert(instance1 is instance2)

    instance1.my_list.append("foo")
    assert(len(instance2.my_list) > 0)
    assert(instance2.my_list[0] == "foo")


# Generated at 2022-06-25 13:36:30.694757
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    a1 = A()
    a2 = A()

    assert a1 == a2
    assert id(a1) == id(a2)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:36:35.060071
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest

    # Create class which implements singleton via Singleton metaclass
    class SingletonTest(metaclass=Singleton):
        def __init__(self):
            pass

    singleton = SingletonTest()

    # Call method __call__ of class Singleton with class SingletonTest
    s1 = SingletonTest()
    s2 = SingletonTest()

    # Check the values
    assert s1 is s2


# Example of usage
if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:36:39.044342
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a == b

    class B(object):
        __metaclass__ = Singleton

    c = B()
    assert a != c

# Generated at 2022-06-25 13:36:42.247619
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    from types import MethodType

    a = A()
    assert isinstance(A.__call__, MethodType)
    assert a is A()
    assert a is not A()


# Generated at 2022-06-25 13:36:49.037084
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, name, age):
            self.name = name
            self.age = age

    a = A("test", 10)
    print("Name:", a.name)
    print("Age:", a.age)

    b = A("test", 20)
    print("Name:", b.name)
    print("Age:", b.age)
    print("Are a and b the same object?", a is b)


# Generated at 2022-06-25 13:36:52.814797
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 == a2
    # a2.x = 2
    # assert a1.x == a2.x

# Generated at 2022-06-25 13:36:59.407332
# Unit test for constructor of class Singleton
def test_Singleton():
    
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 10
            self.y = 20
   
    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 == t2
    assert t1.x == 10
    assert t2.x == 10
    assert t1.y == 20
    assert t2.y == 20


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:37:11.560621
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo:
        __metaclass__ = Singleton
        def __init__(self):
            self.count = 0

        def increment(self):
            self.count += 1

    foo1 = Foo()
    foo2 = Foo()
    assert foo1.count == 0
    foo1.increment()
    assert foo1.count == 1
    foo2.increment()
    assert foo1.count == foo2.count == 2


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:37:16.196251
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test:
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    obj_1 = Test(1)
    assert obj_1.a == 1
    obj_2 = Test(2)
    assert obj_2.a == 1
    assert obj_1 is obj_2


# Generated at 2022-06-25 13:37:21.448945
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    t = TestSingleton(1)
    assert(t.val == 1)
    t = TestSingleton(2)
    assert(t.val == 1)

test_Singleton___call__()

# Generated at 2022-06-25 13:37:25.109796
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    #check the __call__ and __init__ function of class TestSingleton
    a = A()
    b = A()
    assert(a is b)



# Generated at 2022-06-25 13:37:32.172708
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

        def inc(self):
            self.value += 1

    # Call __call__
    t = Test()
    assert isinstance(t, Test)
    assert t.value == 1
    t.inc()
    assert t.value == 2

    # Call __call__ once again
    t1 = Test()
    assert t is t1
    assert t1.value == 2
    t1.inc()
    assert t1.value == 3

    # Make sure we can't do anything to the instance
    try:
        t2 = Test(1)
        assert False
    except TypeError as e:
        assert str(e) == "object() takes no parameters"


# Generated at 2022-06-25 13:37:33.946755
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object):
        __metaclass__ = Singleton

    assert not Foo() is Bar()

# Generated at 2022-06-25 13:37:43.388749
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a class that uses Singleton metaclass
    class TestSingleton(metaclass=Singleton):
        def __init__(self, first_name, last_name, age):
            self.first_name = first_name
            self.last_name = last_name
            self.age = age

    # We expect that creating an instance of this class
    # will invoke the __init__ method
    obj1 = TestSingleton('a', 'b', 25)
    assert obj1.first_name == 'a'    # This will succeed
    
    # We expect that creating another instance of this class,
    # this time from a different thread, will NOT invoke the __init__ method again
    obj2 = TestSingleton('c', 'd', 30)
    assert obj2.first_name == 'a'    # This will succeed


# Generated at 2022-06-25 13:37:51.530744
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a, b=1):
            self.a = a
            self.b = b

        def __repr__(self):
            return 'A(a=%s, b=%s)' % (self.a, self.b)

    a1 = A(2)
    a2 = A(10, 30)
    a3 = A(10, 30)
    print('a1 %s, a2 %s, a3 %s'  % (a1, a2, a3))
    assert(a2 is a3)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:37:52.893418
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()

# Generated at 2022-06-25 13:37:55.496266
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class sub_class(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.data = 1
    instance1 = sub_class()
    instance2 = sub_class()
    assert instance1 is instance2
    assert instance1.data == 1

# Generated at 2022-06-25 13:38:15.377528
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        """Test class to test the Singleton metaclass"""
        def __init__(self, value=None):
            self.value = value

    assert TestClass() is TestClass()
    assert TestClass(1) is TestClass()

    test_inst = TestClass()
    assert test_inst.value == 1

    test_inst.value = 2
    assert test_inst.value == 2
    assert TestClass().value == 2

# Generated at 2022-06-25 13:38:18.231224
# Unit test for constructor of class Singleton
def test_Singleton():
    class SI(metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    s1 = SI(1)
    s2 = SI(2)
    # assert s1.a == 1
    # assert s2.a == 2


test_Singleton()

# Generated at 2022-06-25 13:38:24.151080
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Arrange
    class TestClass(metaclass=Singleton):
        def __init__(self):
            self.value = 1

    # Act
    value_a = TestClass()
    value_a.value = 2

    value_b = TestClass()

    # Assert
    assert isinstance(value_a, TestClass)
    assert isinstance(value_b, TestClass)
    assert value_a == value_b
    assert value_a.value == value_b.value == 2



# Generated at 2022-06-25 13:38:27.916478
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    foo = Foo('foo')
    bar = Foo('bar')
    assert foo.name == 'foo'
    assert bar.name == 'foo'
    assert id(foo) == id(bar)

# Generated at 2022-06-25 13:38:34.486404
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test1(object):
        __metaclass__ = Singleton
        def __init__(self):
            print(self)

    class Test2(object):
        __metaclass__ = Singleton
        def __init__(self):
            print(self)

    # T1 and T2 are two different instances
    T1 = Test1()
    T2 = Test2()
    assert T1 != T2

    # Assert T1 is instantiated only once
    T3 = Test1()
    assert T3 == T1

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:38:37.095332
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    test_1 = Test()
    test_2 = Test()

    assert test_1 == test_2


# Generated at 2022-06-25 13:38:39.257028
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert id(a) == id(b)

# Generated at 2022-06-25 13:38:48.267166
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    count = 0
    singleton = Singleton('singleton', (object,), {})

    class Foo(object):
        __metaclass__ = singleton

        def __init__(self):
            self.val = 0

    instances = []
    for i in range(10):
        if i == 5:
            singleton.__instance = None
        instances.append(Foo())

    for i in range(10):
        instances[i].val = i
        count += instances[i].val

    for i in range(1, 10):
        assert instances[i] is instances[i - 1]

    assert count == 9 * 10 // 2


# Generated at 2022-06-25 13:38:52.189174
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.val = value
    a = MyClass(3)
    b = MyClass(4)
    assert a is b
    assert a.val == b.val

# Generated at 2022-06-25 13:38:53.933497
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
    assert Test() is Test()
    assert Test() is not None

# Generated at 2022-06-25 13:39:31.014235
# Unit test for constructor of class Singleton
def test_Singleton():
  class ASingletonClass (metaclass=Singleton):
    i = 0
    def __init__(self):
      ASingletonClass.i = ASingletonClass.i + 1

  a = ASingletonClass()
  b = ASingletonClass()
  assert a.i == b.i
  assert a.i == 1

# Generated at 2022-06-25 13:39:34.620753
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a = A(10)
    b = A(20)
    assert a.value == b.value
    assert a is b



# Generated at 2022-06-25 13:39:42.103740
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # pylint: disable=too-many-public-methods
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 'a'

    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 'b'

    # first instance
    a = A()

    # second instance
    b = A()

    # third instance
    c = B()

    # fourth instance
    d = B()

    # verify the singleton pattern
    assert a.a == 'a'
    assert b.a == 'a'
    assert c.a == 'b'
    assert d.a == 'b'

    assert a is b
    assert c is d

# Generated at 2022-06-25 13:39:45.280802
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton
        def __init__(self, test_attr):
            self.test_attr = test_attr

    a = A(42)
    b = A(43)
    assert a is b
    assert a.test_attr == b.test_attr
    assert b.test_attr == 42

# Generated at 2022-06-25 13:39:48.828410
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("A init")

    """Test Case"""
    a = A()
    assert a
    b = A()
    assert b
    assert a is b

test_Singleton()

# Generated at 2022-06-25 13:39:53.635202
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread
    from time import sleep

    class A(object):
        """Class singleton"""
        __metaclass__ = Singleton

        def __init__(self):
            sleep(10)

    def get_a():
        """Return instance of class A"""
        return A()

    thrd = Thread(target=get_a)
    thrd.start()
    assert get_a() is get_a()
    assert get_a() is thrd.join()


# Generated at 2022-06-25 13:40:02.637247
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Unit test for method __call__ of class Singleton."""
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    class B(A):
        def __init__(self):
            super(B, self).__init__()
            self.b = 2

    class C(B):
        def __init__(self):
            super(C, self).__init__()
            self.c = 3

    a = A()
    b = B()
    c = C()

    assert id(a) == id(b)
    assert id(b) == id(c)
    assert c.a == c.b == c.c
    assert c.a == 1
    assert c.b == 2
    assert c.c == 3



# Generated at 2022-06-25 13:40:06.525981
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 5


    def f():
        return Foo()

    a = f()
    b = f()
    assert a is b

    print("test_Singleton is passed")

#test_Singleton()

# Generated at 2022-06-25 13:40:11.631232
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    class B(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = A(1)
    b = B(2)

    assert a.value == 1
    assert b.value == 2

    a = A(3)
    b = B(4)

    assert a.value == 1
    assert b.value == 2

# Generated at 2022-06-25 13:40:13.485757
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    reset_singleton_class()

    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()
    assert f1 is f2


# Generated at 2022-06-25 13:41:33.399480
# Unit test for constructor of class Singleton
def test_Singleton():
    class Klass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.instance_attribute = None

    k1 = Klass()
    k2 = Klass()
    k1.instance_attribute = "k1"
    assert(k1 is k2)
    assert(k2.instance_attribute == "k1")

# Generated at 2022-06-25 13:41:35.070305
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    a = SingletonTest()
    b = SingletonTest()
    c = SingletonTest()

    assert a is b is c

# Generated at 2022-06-25 13:41:36.940907
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        pass

    foo1 = Foo()
    foo2 = Foo()
    assert(foo1 is foo2)

# Generated at 2022-06-25 13:41:45.959521
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.value = 'TestSingleton'

        def __str__(self):
            return self.value

    @unittest.skipIf(TestSingleton().value != 'TestSingleton', "TestSingleton is not TestSingleton")
    class TestSingleton___call__(unittest.TestCase):
        def test_returns_first_instance_always(self):
            test = TestSingleton()
            self.assertTrue(test == TestSingleton())

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-25 13:41:47.432460
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        pass
    assert id(Foo()) == id(Foo())

# Generated at 2022-06-25 13:41:52.302563
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.counter = 0
            self.lock = RLock()

        def increment(self):
            with self.lock:
                self.counter += 1

    a = TestClass()
    b = TestClass()
    a.increment()
    b.increment()
    assert a.counter == b.counter == 2

# Generated at 2022-06-25 13:41:53.892634
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton

    assert(SingletonClass() is SingletonClass())

# Generated at 2022-06-25 13:41:55.926778
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-25 13:41:59.498948
# Unit test for constructor of class Singleton
def test_Singleton():
    # To unit test, use the examples given in:
    # http://code.activestate.com/recipes/66531/
    class MySingleton(object):
        __metaclass__ = Singleton

        def foo(self):
            pass

    x = MySingleton()
    y = MySingleton()
    assert x is y

# Generated at 2022-06-25 13:42:02.189273
# Unit test for constructor of class Singleton
def test_Singleton():
    class Base():
        __metaclass__ = Singleton
        def __init__(self):
            self.name = "Base"

    base1 = Base()
    base2 = Base()
    assert base1 is base2

test_Singleton()