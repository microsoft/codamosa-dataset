

# Generated at 2022-06-25 13:34:19.850046
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    set_0 = set()
    set_1 = {set_0}


# Generated at 2022-06-25 13:34:23.301110
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestMeta(metaclass=Singleton):
        pass

    a = TestMeta()
    b = TestMeta()
    if a == b:
        print("TestMeta() is singleton")

test_Singleton()

# Generated at 2022-06-25 13:34:26.903167
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.utils.unsafe_proxy import UnsafeProxy, Singleton, test_case_0
    unsafe_proxy = UnsafeProxy(test_case_0, globals(), {}, True, 'test')
    unsafe_proxy.run()
    assert(not (set() in set()))

# Generated at 2022-06-25 13:34:30.860030
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyObject(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1
        def inc(self):
            self.x += 1
        def get(self):
            return self.x

    obj_0 = MyObject()
    obj_1 = MyObject()
    obj_0.inc()
    obj_1.inc()
    assert obj_0.get() == obj_1.get()



# Generated at 2022-06-25 13:34:39.650388
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("Init function of A")
            self.data = 1

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("Init function of B")
            self.data = 2

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()

    print(a1 == a2)
    print(b1 == b2)
    print(a1 == b1)
if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:34:49.892478
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test case 1
    # Test when __instance is not None
    # Check to see whether the __instance is returned
    class test_class_1(object):
        def __init__(self):
            pass
    test_instance_1 = test_class_1()
    class test_class_2(test_class_1):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    # Set the instance of test_class_1 to the __instance of test_class_2
    test_class_2.__instance = test_instance_1
    # Call the constructor of test_class_2
    test_instance_2 = test_class_2()
    # Check to see whether the returned value is the same as test_instance_1
    assert test_instance_1 == test_instance_2


# Generated at 2022-06-25 13:34:58.934592
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from six import PY2

    import sys
    import os
    import imp

    script_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, os.path.dirname(script_dir))

    m_name = os.path.join(script_dir, 'test_singleton_module.py')
    m_name = m_name.replace('\\', '\\\\')
    m_name = m_name.replace('.', '_')
    m_name = m_name.replace('-', '_')
    if PY2:
        m_name = m_name.replace('/', '_')


# Generated at 2022-06-25 13:35:02.617989
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Widget(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value
    x = Widget(10)
    y = Widget(20)
    assert x.value == 10 and y.value == 10 and x is y


# Generated at 2022-06-25 13:35:03.643453
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton is not None


# Generated at 2022-06-25 13:35:06.975158
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # set up
    class TestClass(object):
        __metaclass__ = Singleton

    # testing
    object_0 = TestClass()
    object_1 = TestClass()

    # assert
    assert object_0 is object_1


# Generated at 2022-06-25 13:35:13.832816
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    test1 = TestSingleton('foo')
    test2 = TestSingleton('bar')
    assert test1.arg == 'foo'
    assert test2.arg == 'foo'
    assert id(test1) == id(test2)
    assert test1 is test2



# Generated at 2022-06-25 13:35:16.641354
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        pass

    class_a = TestClass()
    class_b = TestClass()

    # class_a and class_b have to be the same object,
    # otherwise, the constructor of Singleton does not work
    assert class_a is class_b


test_Singleton()

# Generated at 2022-06-25 13:35:18.155167
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    c1 = Test()
    c2 = Test()
    assert (c1 == c2)

# Generated at 2022-06-25 13:35:19.754922
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-25 13:35:27.109577
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestSingleton1(object):
        __metaclass__ = Singleton

        def __init__(self, arg1):
            self.arg1 = arg1

    class TestSingleton2(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    class TestSingleton3(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2='arg2'):
            self.arg1 = arg1
            self.arg2 = arg2

    class TestSingleton4(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, **kwargs):
            self.arg1 = arg1

# Generated at 2022-06-25 13:35:29.893884
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            print('singleton')

    obj1 = A()
    obj2 = A()
    print(obj1 is obj2)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:35:32.030038
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
    assert isinstance(Test(), Test)


# Generated at 2022-06-25 13:35:36.198382
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__=Singleton
        def __init__(self):
            print("A")
            pass
    class B(A):
        pass
    print(A())
    print(A())
    print(B())
    print(B())


# Generated at 2022-06-25 13:35:40.905022
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self,v):
            self.value = v

    instance = TestClass(v=42)
    assert instance.value == 42

    instance_prime = TestClass(v=43)
    assert instance_prime.value == 42
    assert instance is instance_prime


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:35:46.757241
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.refcount = 0

    t1 = Test()
    assert t1.refcount == 0

    t1.refcount = 1
    t2 = Test()
    assert t1.refcount == 1
    assert t1 is t2

    t2.refcount = 2
    assert t1.refcount == 2
    assert t2.refcount == 2

# Generated at 2022-06-25 13:35:53.426649
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton = TestSingleton()
    same_test_singleton = TestSingleton()
    assert test_singleton is same_test_singleton

# Generated at 2022-06-25 13:35:55.312798
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    
    assert A() is A() is  A()


if __name__ == "__main__":
    test_Singleton()
    print("Test complete")

# Generated at 2022-06-25 13:35:59.176194
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.val = arg
    a = Test(5)
    b = Test(5)
    if a != b:
        print("Failed unit test")

# Generated at 2022-06-25 13:36:04.742862
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        pass

    import unittest

    class TestSingleton___call__(unittest.TestCase):
        def test_Singleton___call__(self):
            foo1 = Foo()
            foo2 = Foo()
            self.assertEqual(foo1, foo2)

    unittest.main()


# Generated at 2022-06-25 13:36:10.078776
# Unit test for constructor of class Singleton
def test_Singleton():
    s = Singleton("singleton", (object,), {})
    assert isinstance(s, type)
    assert issubclass(s, object)
    assert s.__name__ == "singleton"
    assert s.__class__.__name__ == "type"
    assert s.__class__.__mro__ == (type, object)


# Generated at 2022-06-25 13:36:15.142812
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 == a2
    assert a1.a == 1
    assert a2.a == 1



# Generated at 2022-06-25 13:36:17.810281
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert (a1 == a2)



# Generated at 2022-06-25 13:36:19.809972
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        pass

    t = TestSingleton()
    assert t == TestSingleton()


# Generated at 2022-06-25 13:36:27.397177
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test __call__ method of class Singleton
    """

    class TestSingleton(object):
        """Test Singleton class
        """
        __metaclass__ = Singleton
        instance_count = 0
        def __init__(self):
            TestSingleton.instance_count += 1

    try:
        test_instance_1 = TestSingleton()
        test_instance_2 = TestSingleton()
        assert(test_instance_1 is test_instance_2)
        assert(TestSingleton.instance_count == 1)
    finally:
        del test_instance_1
        del test_instance_2

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:36:32.631167
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

        def get_arg(self):
            return self.arg

    sample_arg = 'sample_arg'
    sample_arg2 = 'sample_arg2'

    a1 = A(sample_arg)
    assert a1.get_arg() == sample_arg
    a2 = A(sample_arg2)
    assert a2 == a1
    assert a2.get_arg() == sample_arg

    return 0

# Generated at 2022-06-25 13:36:42.920078
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        pass

    a1 = A()
    a2 = A()

    assert a1 is a2


# Generated at 2022-06-25 13:36:46.538016
# Unit test for constructor of class Singleton
def test_Singleton():
    class R(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    r = R(1)
    assert id(r) == id(R(1))
    assert id(r) != id(R(2))

# Generated at 2022-06-25 13:36:49.725936
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    A1 = A()
    A2 = A()

    assert A1 == A2
    assert id(A1) == id(A2)


# Generated at 2022-06-25 13:36:56.887610
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    test_class1 = TestClass('arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')
    test_class2 = TestClass('arg3', 'arg4', kwarg1='kwarg2', kwarg2='kwarg2')
    assert test_class1 is test_class2
    assert test_class1.args == ('arg1', 'arg2')
    assert test_class1.kwargs == {'kwarg1': 'kwarg1', 'kwarg2': 'kwarg2'}

# Generated at 2022-06-25 13:37:01.112656
# Unit test for constructor of class Singleton
def test_Singleton():
    import sys

    class SingletonExample(object):
        __metaclass__ = Singleton

        _item = None

        def __init__(self):
            self._item = 10

    assert sys.getrefcount(SingletonExample()) == 2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:37:05.525580
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x
    foo_inst_1 = Foo(42)
    foo_inst_2 = Foo(42)
    assert foo_inst_1 is foo_inst_2

# Generated at 2022-06-25 13:37:10.018494
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test method __call__ of class Singleton"""
    class SingletonSubclass(object):
        #pylint: disable=no-init
        __metaclass__ = Singleton

    one = SingletonSubclass()
    two = SingletonSubclass()
    assert one == two
    assert id(one) == id(two)
    assert one is two

# Generated at 2022-06-25 13:37:15.213277
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            print (self)
            self.number = 40

    a = Test()
    b = Test()
    print (a is b)
    print (a.number)
    print (b.number)
    assert a is b
    assert a.number == b.number == 40

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:37:19.344953
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()
    assert id(A()) == id(A())

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:37:25.110153
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSigleton(Singleton):
        def __init__(self):
            self.test = False

        def test(self):
            self.test = True

    test1 = TestSigleton()
    test1.test()

    test2 = TestSigleton()
    assert test1 is test2
    assert test1.test is True
    assert test2.test is True

    test2.test = False

    assert test1.test is False
    assert test2.test is False

# Generated at 2022-06-25 13:37:44.580963
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestSingletonClass(object):
        __metaclass__ = Singleton

    x = TestSingletonClass()
    y = TestSingletonClass()

    assert x.__class__ is y.__class__
    assert x is y

# Generated at 2022-06-25 13:37:46.215034
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a = TestSingleton(100)
    b = TestSingleton(200)
    assert a is b
    assert a.value == b.value



# Generated at 2022-06-25 13:37:48.836229
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        pass

    class B(A):
        __metaclass__ = Singleton

    b1 = B()
    b2 = B()

    assert b1 is b2

# Generated at 2022-06-25 13:37:50.538950
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(metaclass=Singleton):
        pass

    s = SingletonTest()
    assert s is SingletonTest()
    assert s is SingletonTest()

# Generated at 2022-06-25 13:37:52.989871
# Unit test for constructor of class Singleton
def test_Singleton():
    class D(object):
        __metaclass__ = Singleton

    d1 = D()
    d2 = D()
    assert d1 is d2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:37:55.376762
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert a is b


# Generated at 2022-06-25 13:38:02.928661
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class myClass(object, metaclass=Singleton):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    a = myClass(10, 20)
    b = myClass(30, 40)

    print('a.a = %d, a.b = %d, b.a = %d, b.b = %d' % (a.a, a.b, b.a, b.b))
    assert a.a == 10 and b.a == 10
    assert a.b == 20 and b.b == 20

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:38:09.315736
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, num):
            self.num = num

    class Test2(object):
        __metaclass__ = Singleton
        def __init__(self, num, *args):
            self.num = num

    x = Test(-5)
    y = Test(-4)

    assert id(x) == id(y)

    z = Test2(-30)
    z2 = Test2(-40)

    assert id(z) == id(z2)

# Generated at 2022-06-25 13:38:13.457657
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        value = 0

        def __init__(self):
            self.value += 1

    t1 = Test()
    t2 = Test()

    assert t1 is t2, "Two instances of a class with Singleton metaclass must be the same instance"
    assert t2.value == 1, "class variable value must be 1"


# Generated at 2022-06-25 13:38:14.164643
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton.__instance is None


# Generated at 2022-06-25 13:38:51.475473
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self,a):
            self.a = a

    mc = MyClass(1)
    tw = MyClass(3)

    assert tw.a == 1
    assert mc.a == 1
    assert mc is tw


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:38:53.113523
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(object):
        __metaclass__ = Singleton
    assert X() is X()



# Generated at 2022-06-25 13:38:59.650821
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Imports
    from threading import Thread
    import time
    import unittest

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, i=0):
            self.i = i

    class TestSingletonThread(Thread):
        def __init__(self, s, i):
            Thread.__init__(self)
            self.s = s
            self.i = i

        def run(self):
            if self.s.i != self.i:
                raise Exception("Error at thread {}. Result: {}, expected {}".format(self.i, self.s.i, self.i))

            self.s.i += 1

            time.sleep(1)


# Generated at 2022-06-25 13:39:04.169880
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = 0

    a1 = A()
    a2 = A()

    assert id(a1) == id(a2)
    assert a1.a == a2.a
    a1.a = 1
    assert a1.a == a2.a

# Generated at 2022-06-25 13:39:09.513024
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class X(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 0

    x1 = X()
    assert x1.a
    x2 = X()
    assert x2.a
    assert x1.a == x2.a
    assert id(x1) == id(x2)
    x2.a += 1
    assert x1.a == x2.a



# Generated at 2022-06-25 13:39:14.805721
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object):
        __metaclass__ = Singleton


    class NormalClass(object):
        pass

    s1 = SingletonClass()
    assert isinstance(s1, SingletonClass)

    s2 = SingletonClass()
    assert isinstance(s2, SingletonClass)

    assert s1 is s2

    c1 = NormalClass()
    c2 = NormalClass()

    assert c1 is not c2

# Generated at 2022-06-25 13:39:16.826268
# Unit test for constructor of class Singleton
def test_Singleton():
    class Temp(object):
        __metaclass__ = Singleton
    t1 = Temp()
    t2 = Temp()
    assert(t1 is t2)


# Generated at 2022-06-25 13:39:19.835250
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class a(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = a()
    assert t1.a == 1
    t1.a = 2

    t2 = a()
    assert t2.a == 2


# Generated at 2022-06-25 13:39:24.602886
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, val=1):
            self.val = val

    a = A()
    b = A()
    assert a == b
    assert id(a) == id(b)
    a.val = 2
    assert b.val == 2


# Generated at 2022-06-25 13:39:31.358511
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            if not hasattr(self, "_init"):
                self._init = False

            self._init = True

    test_singleton_1 = TestSingleton()
    assert test_singleton_1._init == True

    test_singleton_2 = TestSingleton()
    assert test_singleton_1 is test_singleton_2

    assert test_singleton_2._init == True


# Generated at 2022-06-25 13:40:43.931124
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-25 13:40:49.607141
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, number):
            self.number = number
            self.identifier = id(self)

    # We should get a single instance
    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.number == 1
    assert a1.identifier == id(a2)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:40:53.339097
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 4
    a1 = A()
    a2 = A()
    assert a1.val == a2.val
    # also need to test that they are the same object
    assert a1 is a2

# Generated at 2022-06-25 13:40:58.231172
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    first_obj = TestSingleton()
    assert(first_obj is TestSingleton())
    assert(first_obj is TestSingleton())
    assert(first_obj is TestSingleton())
    assert(first_obj is TestSingleton())
    assert(first_obj is TestSingleton())

    second_obj = TestSingleton()
    assert(first_obj is TestSingleton())
    assert(first_obj is TestSingleton())
    assert(first_obj is TestSingleton())
    assert(first_obj is TestSingleton())
    assert(first_obj is TestSingleton())

    assert(first_obj is second_obj)


# Generated at 2022-06-25 13:41:01.584662
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestObject(object):
        __metaclass__ = Singleton

    obj1 = TestObject()
    obj2 = TestObject()
    assert obj1 is obj2

# Generated at 2022-06-25 13:41:04.107023
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    m = MySingleton()
    n = MySingleton()

    assert (m is n)



# Generated at 2022-06-25 13:41:06.465423
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert(isinstance(S(), S))



# Generated at 2022-06-25 13:41:11.981346
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.id = 4

    c1 = TestClass()
    c2 = TestClass()
    c3 = TestClass()

    assert c1.id == c2.id == c3.id
    assert c1 is c2 is c3
    assert id(c1) == id(c2) == id(c3)

# Generated at 2022-06-25 13:41:14.524582
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)

# Unit test to ensure instances of derived classes are not shared

# Generated at 2022-06-25 13:41:18.062143
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    t1 = Test(1)
    t2 = Test(2)
    assert id(t1) == id(t2)

# Generated at 2022-06-25 13:44:16.485703
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingleton1(object):
        __metaclass__ = Singleton

    test = TestSingleton()
    test1 = TestSingleton1()

    assert test is test1
    assert not test is not test1
    assert test.__class__ is test1.__class__
    assert not test.__class__ is not test1.__class__