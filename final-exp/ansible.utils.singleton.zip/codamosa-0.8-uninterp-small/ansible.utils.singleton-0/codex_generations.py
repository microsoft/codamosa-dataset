

# Generated at 2022-06-25 13:34:19.443203
# Unit test for constructor of class Singleton
def test_Singleton():
    test_case_0()


# Generated at 2022-06-25 13:34:20.753975
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_0 = Singleton('e_ok')


# Generated at 2022-06-25 13:34:26.893045
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    const_0 = (-6.2663)
   
    class Class_0(object):

        def __init__():
            Class_0.__instance = None
            Class_0.__rlock = RLock()

        def __call__(cls, *args, **kw):
            return cls
            
    #__call__ is not a method of class Class_0,
    #so there would be no need to test it.


# Generated at 2022-06-25 13:34:27.801813
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_0 = Singleton


# Generated at 2022-06-25 13:34:29.827258
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    set_0 = set()
    bool_0 = True
    float_0 = -1653.1068
    dict_0 = {set_0: bool_0, bool_0: bool_0, set_0: bool_0}


# Generated at 2022-06-25 13:34:33.542880
# Unit test for constructor of class Singleton
def test_Singleton():
    assert test_case_0.__doc__ == "Metaclass for classes that wish to implement Singleton\n    functionality.  If an instance of the class exists, it's returned,\n    otherwise a single instance is instantiated and returned.\n    "
    assert test_case_0.__name__ == "test_case_0"
    assert test_case_0.__module__ == "test_singleton"


# Generated at 2022-06-25 13:34:37.215430
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    obj = object()
    ret = object()
    class A(object):
        def __call__(self, obj):
            return ret
    a = A()
    assert a(obj) is ret


# Generated at 2022-06-25 13:34:42.015573
# Unit test for constructor of class Singleton
def test_Singleton():
    float_0 = -1713.534
    int_0 = -1606
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    assert True


# Generated at 2022-06-25 13:34:44.230423
# Unit test for constructor of class Singleton
def test_Singleton():
    try:
        new = Singleton()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 13:34:54.265147
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    int_0 = 1676
    dict_0 = {int_0: -422, -422: int_0, -422: int_0}
    str_0 = 'XOt'
    str_1 = 'XOt'
    dict_1 = {str_0: str_1, str_0: str_1, str_1: str_1}
    set_0 = {dict_1, str_0, str_0}
    set_0.add(dict_0)
    tuple_0 = (dict_0, set_0)
    tuple_1 = (set_0, str_0, set_0, tuple_0, set_0)
    set_0.add(tuple_0)
    tuple_2 = (tuple_0, set_0, tuple_0)
    tuple_3

# Generated at 2022-06-25 13:35:00.331300
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 42

    a = A()
    b = A()

    assert(id(a) == id(b))
    assert(a.foo == 42)
    assert(b.foo == 42)
    a.foo = 'bar'
    assert(a.foo == 'bar')
    assert(b.foo == 'bar')

# Generated at 2022-06-25 13:35:03.728918
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

    # Instantiate the class and check that the same instances are
    # returned.
    a = SingletonTest()
    b = SingletonTest()
    assert a is b

# Generated at 2022-06-25 13:35:08.436325
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MainClass(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    i1 = MainClass("bob")
    i2 = MainClass("tom")

    assert i1 is i2
    assert i1.name == "tom"
    assert i2.name == "tom"



# Generated at 2022-06-25 13:35:11.284911
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():  # noqa: E302
    from ansible.utils.singleton import Singleton
    class Test(object):
        __metaclass__ = Singleton

    cl1 = Test()
    cl2 = Test()
    assert cl1 is cl2



# Generated at 2022-06-25 13:35:14.310362
# Unit test for constructor of class Singleton
def test_Singleton():
    # Testing class with metaclass Singleton
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert MyClass() is MyClass()
    assert MyClass() is MyClass()

# Generated at 2022-06-25 13:35:17.246719
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        __metaclass__ = Singleton

    class D(C):
        pass

    assert(A() is not A())
    assert(B() is B())
    assert(C() is C())
    assert(D() is C())


# Generated at 2022-06-25 13:35:20.072152
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # class Singleton
    class SingletonTest(Singleton):
        def __init__(self):
            self.a = 1

    # test
    t1 = SingletonTest()
    t2 = SingletonTest()
    assert t1 == t2 and t1.a == t2.a


# Generated at 2022-06-25 13:35:25.756142
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from unittest import TestCase, main
    from random import randint
    from time import sleep

    class a(object):
        __metaclass__ = Singleton

    class b(object):
        __metaclass__ = Singleton

    class c(object):
        __metaclass__ = Singleton

    def make_many_instances(how_many=100):
        from threading import Thread
        from Queue import Queue

        a_instances_queue = Queue()
        b_instances_queue = Queue()
        c_instances_queue = Queue()
        threads = []
        for i in range(how_many):
            def random_delay():
                sleep(randint(1, 3))

            def random_instance():
                random_delay()

# Generated at 2022-06-25 13:35:27.170266
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        pass

    assert TestSingleton() == TestSingleton()

# Generated at 2022-06-25 13:35:35.603315
# Unit test for constructor of class Singleton
def test_Singleton():
    import time

    # create singleton class
    class mySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, sleep_time=0.0, custom_attr=False, *args, **kwargs):
            self.sleep_time = sleep_time
            self.custom_attr = custom_attr
            time.sleep(self.sleep_time)

    # create instances
    a = mySingleton()
    b = mySingleton(custom_attr=True)
    c = mySingleton(sleep_time=0.5)
    d = mySingleton(sleep_time=0.1, custom_attr=True)
    e = mySingleton(sleep_time=0.1)

    # check if all the instances of the class are the same

# Generated at 2022-06-25 13:35:41.926779
# Unit test for constructor of class Singleton
def test_Singleton():
    # import needed for test, does not get picked up by test runner
    from ansible.utils.display import Display
    assert Display() is Display()



# Generated at 2022-06-25 13:35:44.918076
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2, "Singleton instantiation failed"


# Generated at 2022-06-25 13:35:53.274055
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class test_Singleton(metaclass=Singleton):
        def __init__(self):
            self.data = 0

        def set_data(self, data):
            self.data = data

    class_obj_1 = test_Singleton()
    class_obj_2 = test_Singleton()
    class_obj_3 = test_Singleton()

    assert(class_obj_1 is class_obj_2)
    assert(class_obj_1 is class_obj_3)
    assert(class_obj_2 is class_obj_3)

    class_obj_1.set_data(1)
    assert(class_obj_1.data == 1)
    assert(class_obj_2.data == 1)
    assert(class_obj_3.data == 1)



# Generated at 2022-06-25 13:35:56.291997
# Unit test for constructor of class Singleton
def test_Singleton():
    class ARound(object):
        __metaclass__ = Singleton
        def __init__(self, name='A Round'):
            self.name = name

    class BLong(object):
        __metaclass__ = Singleton
        def __init__(self, name='B Long'):
            self.name = name

    assert ARound().name == 'A Round'
    assert BLong().name == 'B Long'

# Generated at 2022-06-25 13:36:04.559159
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class testSingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.counter = 0

        def increment(self):
            self.counter += 1

    class SingletonTest(unittest.TestCase):

        def testSingleton(self):
            self.assertEqual(testSingletonClass().counter, 0)

            testSingletonClass().increment()
            self.assertEqual(testSingletonClass().counter, 1)

            testSingletonClass().increment()
            self.assertEqual(testSingletonClass().counter, 2)

    unittest.main()

# Generated at 2022-06-25 13:36:08.369556
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
    assert A() is A()
    assert A() is A()


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:36:11.115903
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1 is t2



# Generated at 2022-06-25 13:36:15.780666
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 0

    a = A()
    a.value += 1
    b = A()
    b.value += 2
    assert a.value == 2
    assert a is b

# Generated at 2022-06-25 13:36:20.120507
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    class TestClass2(object):
        __metaclass__ = Singleton

    # We should be able to create two instances of the same class
    # with two different names
    t1 = TestClass()
    t2 = TestClass2()

    assert t1 is not t2

# Generated at 2022-06-25 13:36:28.654900
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kw):
            # we should never get here because they're all the same
            self.args = args
            self.kw = kw

        def get_args(self):
            return self.args

        def get_kw(self):
            return self.kw

    a = A()
    b = A(1, 2, 3)
    c = A(foo="bar")

    assert b.get_args() == (1, 2, 3)
    assert c.get_kw()['foo'] == "bar"

    assert a is b
    assert b is c

    # test that Singleton doesn't interfere with inheritance
    class B(A):
        pass

    b = B()

# Generated at 2022-06-25 13:36:42.159582
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        counter = 0
        def __init__(self):
            A.counter += 1

    assert A.counter == 0
    a = A()
    assert A.counter == 1
    b = A()
    assert A.counter == 1
    assert a is b


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:36:44.427908
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-25 13:36:50.570358
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass
    
    # test Singleton in multithread
    from threading import Thread
    import time
    class t1(Thread):
        def run(self):
            while(True):
                a = A()
                time.sleep(0.1)
    t2 = t1()
    t2.start()
    a = A()
    assert(a is A())



# Generated at 2022-06-25 13:36:52.390657
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    a = MyClass()
    b = MyClass()
    assert a == b

# Generated at 2022-06-25 13:36:57.759680
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # HACK: https://stackoverflow.com/questions/6760685/creating-a-singleton-in-python
    # To test method __call__ of class Singleton, it is necessary to create
    # a dummy class and use the dummy class as the metaclass of a new class
    # that needs to be tested.

    class B(metaclass=Singleton):
        pass

    # Check that two instances of class B are identical
    instance_a = B()
    instance_b = B()
    assert instance_a is instance_b

    # Check that the instances of class B are identical to the original class A
    # that is assigned with metaclass Singleton
    assert instance_a is B



# Generated at 2022-06-25 13:37:03.959618
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyFirstSingleton(object):
        __metaclass__ = Singleton

    class MySecondSingleton(object):
        __metaclass__ = Singleton

    obj1 = MyFirstSingleton()
    obj2 = MyFirstSingleton()
    obj3 = MySecondSingleton()
    obj4 = MySecondSingleton()

    assert obj1 is obj2
    assert obj3 is obj4
    assert obj1 is not obj3

# Generated at 2022-06-25 13:37:12.392071
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.is_init = True

    test = Test()
    assert test.is_init
    test2 = Test()
    assert test.is_init
    assert test == test2
    assert not id(test) == id(test2)

    class Test2(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.is_init = True

    test3 = Test2()
    assert test.is_init
    assert test3 == test2
    assert not id(test3) == id(test2)


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:37:15.647506
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    result = SingletonTest(1)
    assert isinstance(result, SingletonTest)

# Generated at 2022-06-25 13:37:20.562850
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 'b'

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 == test2
    assert test1 is test2


# Generated at 2022-06-25 13:37:25.267942
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self, val):
            self.val = val

    foo = Foo(10)
    assert foo.val == 10

    bar = Foo(20)
    assert foo is bar, "singleton failed"
    assert foo.val == 20, "singleton failed"


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:37:48.023675
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        """Class A without metaclass Singleton"""
        pass

    class B(object):
        """Class B with metaclass Singleton"""
        __metaclass__ = Singleton

    a = A()
    b = B()
    assert(a == a)
    assert(b == b)

    a1 = A()
    b1 = B()
    assert(a != a1)
    assert(b == b1)

# Generated at 2022-06-25 13:37:50.596026
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    tc1 = TestClass(1)
    tc2 = TestClass(2)

    assert tc1 is tc2
    assert tc1.val is tc2.val

# Generated at 2022-06-25 13:37:58.250979
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # checks that an existing instance is returned
    class Dummy(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    instance = Dummy()
    assert instance is Dummy()
    # checks that a new instance is returned if previous instance is destroyed
    class Dummy(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    instance = Dummy()
    del instance
    assert isinstance(Dummy(), Dummy)
    # checks that the instancied object keeps the Singleton meta class
    class Dummy(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    instance = Dummy()
    instance = Dummy()
    assert isinstance(instance, Singleton)


# Generated at 2022-06-25 13:38:01.295744
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()

    assert id(foo1) == id(foo2)


# Generated at 2022-06-25 13:38:07.929705
# Unit test for constructor of class Singleton
def test_Singleton():
    class xx(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'this is test'
            print('xx init')

        def printtest(self):
            print(self.test)

    x = xx()
    print(x.test)
    x.test = 'changed'
    x1 = xx()
    print(x1.test)
    x.printtest()
    x1.printtest()


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:38:08.840219
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    obj1 = Singleton()



# Generated at 2022-06-25 13:38:12.510272
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, val=1):
            self.val = val
    a = MySingleton()
    assert a.val == 1
    b = MySingleton(val=3)
    assert a.val == 3
    assert a is b

# Generated at 2022-06-25 13:38:14.834416
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(Singleton):
        def __init__(self):
            pass

    t1 = Test()
    t2 = Test()
    assert t1 == t2
# End of unit test for method __call__ of class Singleton

# Generated at 2022-06-25 13:38:16.242419
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t = Test()
    ti = Test()
    assert t == ti



# Generated at 2022-06-25 13:38:18.991420
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    m1 = MyClass()
    m2 = MyClass()
    assert m1 is m2, 'Singleton expected, but not implemented by MyClass'


# Generated at 2022-06-25 13:38:56.969656
# Unit test for constructor of class Singleton
def test_Singleton():
    class testClass(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value
    testInstance = testClass(10)
    testInstance2 = testClass(12)
    assert testInstance.value == 10
    assert testInstance.value == testInstance2.value
    testInstance.value = 11
    assert testInstance.value == testInstance2.value

# Generated at 2022-06-25 13:39:03.550761
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, data):
            print("init func", data)
            self.data = data

        @classmethod
        def get_data(self):
            return self.data

    # Create a first instance
    a = TestSingleton("a")

    assert a == TestSingleton("b")

    assert a is TestSingleton("c")

    assert TestSingleton.get_data() == "c"

# Generated at 2022-06-25 13:39:09.275692
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test_Singleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.__arg = arg

        def __str__(self):
            return self.__arg

    a = Test_Singleton("hello")
    b = Test_Singleton("world")
    c = Test_Singleton("ansible")

    assert (a == b)
    assert (b == c)
    assert (a == c)

# Generated at 2022-06-25 13:39:12.709442
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    assert Test(1, 2, 3) is Test(1, 2, 3)

# Generated at 2022-06-25 13:39:20.461204
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, num):
            self.num = num
    #
    # Check that two threads which instanciate TestClass at the same time
    # will get the same instance and not two distinct instances
    #

    def thread_func():
        for _ in xrange(10):
            test_instance = TestClass(2)

    threads = [ Thread(target=thread_func) for _ in xrange(10) ]

    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    # Check that the __instance class attribute has been set to an object
    assert isinstance(TestClass.__instance, TestClass)
    # Check that the value of the num attribute is the

# Generated at 2022-06-25 13:39:25.446064
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    assert A() is a

    class B(A):
        pass

    b = B()
    assert B() is b

    c = A()
    assert c is a
    assert b is not c
    assert B() is b
    assert B() is not c

# Generated at 2022-06-25 13:39:35.030317
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = ''

        def call(self):
            return 'method'

    my_singleton = MySingleton()
    my_singleton.name = 'foo'
    assert my_singleton.call() == 'method'

    my_singleton2 = MySingleton()
    assert my_singleton is my_singleton2
    assert my_singleton2.name == 'foo'
    assert my_singleton2.call() == 'method'

    my_singleton.name = 'bar'  # my_singleton2.name == 'bar'
    my_singleton2.name = 'baz'  # my_singleton.name == 'baz'

    assert my_singleton is my

# Generated at 2022-06-25 13:39:35.481918
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton("name", (), {})



# Generated at 2022-06-25 13:39:36.968001
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Example(object):
        __metaclass__ = Singleton

    assert True



# Generated at 2022-06-25 13:39:41.062960
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, id):
            self.id = id

    obj1 = MyClass.__call__(1)
    obj2 = MyClass.__call__(2)
    print(id(obj1), id(obj2))
    assert obj1.id == 1
    assert id(obj1) == id(obj2)

# Generated at 2022-06-25 13:40:10.558154
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__instance = None
    singleton_0.__rlock = RLock()
    var_2 = ()
    var_3 = {}
    singleton_0.__call__(var_2, **var_3)
    var_4 = None
    var_5 = None
    singleton_0.__call__(var_4, var_5)
    var_6 = ()
    var_7 = {}
    singleton_0.__call__(var_6, **var_7)
    singleton_0.__call__()
    var_8 = ()
    var_9 = {}
    singleton

# Generated at 2022-06-25 13:40:13.926334
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    # Test attribute __rlock of class Singleton
    assert singleton_0.__rlock.is_owned() == False, \
        'singleton_0.__rlock.is_owned() == False'


# Generated at 2022-06-25 13:40:17.116286
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()


# Generated at 2022-06-25 13:40:21.163075
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    tuple_0 = ()
    dict_0 = {}
    var_2 = singleton_0(*tuple_0, **dict_0)

# Generated at 2022-06-25 13:40:24.229624
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    # __call__ is not implemented


# Generated at 2022-06-25 13:40:27.280639
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print('Testing method Singleton.__call__')
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:40:29.967703
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

  # Setup (create a mock object)
  singleton_0 = Singleton()

  # Test
  singleton_0.__call__()

  # Verify
  assert singleton_0.__instance is not None

# Generated at 2022-06-25 13:40:33.694176
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    a = object.__new__(Singleton)
    a.__init__('a', (), {})
    x = a('name', (), {})
    assert id(a) == id(x)
    aa = a('name', (), {})
    assert id(a) == id(aa)



# Generated at 2022-06-25 13:40:39.721789
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''
    Unit test for method __call__ of class Singleton
    '''
    try:
        str_0 = 'name'
        var_0 = ()
        var_1 = {}
        singleton_0 = Singleton(str_0, var_0, var_1)
        str_0 = 'name'
        var_0 = ()
        var_1 = {}
        singleton_0 = Singleton(str_0, var_0, var_1)
    except Exception as e:
        print('Unhandled exception: %s' % str(e))

# Generated at 2022-06-25 13:40:44.673401
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_1 = Singleton(str_0, var_0, var_1)
    assert singleton_0 is singleton_1


# Generated at 2022-06-25 13:41:23.317327
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = Singleton('name', (), {})
    try:
        # AssertionError raised on failure to call __call__
        assert singleton_0.__call__(Singleton('name', (), {}))
    except AssertionError as e:
        raise AssertionError(e)
    else:
        # No exception raised, test case passed
        pass



# Generated at 2022-06-25 13:41:27.207855
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'name'
    var_2 = ()
    var_3 = {}
    singleton_0 = Singleton(str_1, var_2, var_3)

# Generated at 2022-06-25 13:41:30.351959
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert singleton_0() == singleton_0()

# Generated at 2022-06-25 13:41:35.169694
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_1 = ()
    var_2 = {}
    instance_0 = singleton_0(var_1, var_2)
    instance_1 = singleton_0(var_1, var_2)
    assert (instance_0 == instance_1)


# Generated at 2022-06-25 13:41:35.991903
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert Singleton.__call__() is None


# Generated at 2022-06-25 13:41:40.709285
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {'__module__': str_0}
    singleton_0 = Singleton(str_0, var_0, var_1)
    with var_1['__rlock']:
        str_1 = 'name'
        var_2 = ()
        var_3 = {'__module__': str_1}
        singleton_1 = Singleton(str_1, var_2, var_3)
        if (singleton_0.__instance != None):
            pass
        else:
            singleton_0.__instance = singleton_1



# Generated at 2022-06-25 13:41:44.108647
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__(str_0)


# Generated at 2022-06-25 13:41:47.189254
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    with pytest.raises(TestCaseFailureException):
        # unit_test_case_0
        #
        # Exception raised trying to instantiate Singleton
        # before calling the test function.
        #
        test_case_0()

# Generated at 2022-06-25 13:41:54.326222
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'name'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    assert not singleton_0 is singleton_1
    assert singleton_0 is Singleton.__call__(singleton_0)
    assert singleton_0 is Singleton.__call__(singleton_1)
    assert singleton_0 is Singleton.__call__(singleton_0)


# Generated at 2022-06-25 13:41:55.111501
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:42:50.041705
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Check that run instance is returned
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = singleton_0()
    if singleton_0.__instance is not singleton_1:
        raise Exception('singleton_0.__instance is not equal to singleton_1')

# Generated at 2022-06-25 13:42:55.613453
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread
    from threading import Lock
    from threading import global_address_space_size
    from threading import local_address_space_size
    from threading import local_address_size
    from threading import local_cache_size
    from threading import local_codeword_size
    from threading import local_security_bits
    from threading import local_state_size
    from threading import max_global_address_space_size
    from threading import max_local_address_space_size
    from threading import max_local_address_size
    from threading import max_local_cache_size
    from threading import max_local_codeword_size
    from threading import max_local_security_bits
    from threading import max_local_state_size

# Generated at 2022-06-25 13:42:59.250818
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = singleton_0()
    assert singleton_0 == singleton_1



# Generated at 2022-06-25 13:43:02.106710
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Initialize
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    # Test
    singleton_0(var_0, var_1)
    # Assertion
    return

# Generated at 2022-06-25 13:43:05.466601
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test case 1
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = Singleton(str_0, var_0, var_1)
    if (singleton_0 != singleton_1):
        print("Failed test case 1")


# Generated at 2022-06-25 13:43:08.180857
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    i = Singleton()
    assert i.__instance is None
    Singleton()
    assert i.__instance is not None
    j = Singleton()
    assert j.__instance is i.__instance

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:43:12.209706
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'name'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'name'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    assert singleton_0 == singleton_1


# Generated at 2022-06-25 13:43:15.683511
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = Singleton()
    singleton_0.__instance = object()
    singleton_0.__rlock = RLock()
    singleton_0.__rlock.acquire = lambda *args, **kwargs: None
    singleton_0.__rlock.release = lambda *args, **kwargs: None
    singleton_0.__call__()


# Generated at 2022-06-25 13:43:16.654589
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()



# Generated at 2022-06-25 13:43:20.527232
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    with pytest.raises(UnboundLocalError):
        # Missing attribute __instance on class singleton_0
        singleton_0 = Singleton()
    with pytest.raises(UnboundLocalError):
        # Missing attribute __rlock on class singleton_0
        singleton_0 = Singleton()