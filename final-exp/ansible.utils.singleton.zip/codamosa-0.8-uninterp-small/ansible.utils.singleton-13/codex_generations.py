

# Generated at 2022-06-25 13:34:23.995614
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    float_0 = 531.5
    complex_0 = None
    dict_0 = None
    bytes_0 = b'\xaf\xe9\x84\xf3\xb3\xaa\xb1>\xf3\x8a\x1f\x9d'
    singleton_0 = Singleton(float_0, complex_0, dict_0, bytes_0)


# Generated at 2022-06-25 13:34:26.143239
# Unit test for constructor of class Singleton
def test_Singleton():
    a = Singleton()
    assert type(a) == Singleton
    a = Singleton()
    assert type(a) == Singleton

# Generated at 2022-06-25 13:34:30.713345
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    float_0 = 2.0
    complex_0 = None
    dict_0 = None
    bytes_0 = b'\xc0\x9am\x8d\xfc\xebi\xd9\xf8\x18\xab\xff'
    singleton_0 = Singleton(float_0, complex_0, dict_0, bytes_0)

# Generated at 2022-06-25 13:34:38.293581
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    complex_0 = None
    dict_0 = None
    bytes_0 = b'\x0c\x0bn\x96\xb5\xb1\xd5\x1e\xd9\x18\x98\xac\xfe\xcd\xb3\x81\x1f\xdd\xaa\x9f\x1b\x9b@'
    singleton_0 = Singleton(False, complex_0, dict_0, bytes_0)
    float_0 = 6.673848083972688E-24
    float_1 = 2.0
    complex_0 = None
    dict_0 = None
    bytes_0 = b'\xc0\x9am\x8d\xfc\xebi\xd9\xf8\x18\xab\xff'

# Generated at 2022-06-25 13:34:40.241692
# Unit test for constructor of class Singleton
def test_Singleton():
    global singleton_0
    singleton_0 = Singleton()
    assert singleton_0 is not None

# Generated at 2022-06-25 13:34:50.380973
# Unit test for constructor of class Singleton

# Generated at 2022-06-25 13:34:58.572937
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    float_0 = 1.0
    complex_0 = None
    dict_0 = None
    bytes_0 = b'\xe1\x04\xb6\xac\xf8\x8e\x0f\xe4\x84\x8c'
    singleton_0 = Singleton(float_0, complex_0, dict_0, bytes_0)
    assert singleton_0 == None
    singleton_1 = Singleton(float_0, complex_0, dict_0, bytes_0)
    assert singleton_1 == None
    singleton_2 = Singleton(float_0, complex_0, dict_0, bytes_0)
    assert singleton_2 == None



# Generated at 2022-06-25 13:35:02.875551
# Unit test for constructor of class Singleton
def test_Singleton():
    float_0 = 2.0
    complex_0 = None
    dict_0 = None
    bytes_0 = b'\xc0\x9am\x8d\xfc\xebi\xd9\xf8\x18\xab\xff'
    singleton_0 = Singleton(float_0, complex_0, dict_0, bytes_0)

# Generated at 2022-06-25 13:35:08.277800
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    float_0 = 6.0
    complex_0 = None
    dict_0 = None
    bytes_0 = b',\xdb\x92\x8c\xf4\x83\xfe\xdb\x19\x02\xbe'
    singleton_0 = Singleton(float_0, complex_0, dict_0, bytes_0)
    assert singleton_0(1) == 0


# Generated at 2022-06-25 13:35:12.461284
# Unit test for constructor of class Singleton
def test_Singleton():
    float_0 = -2.5
    complex_0 = None
    dict_0 = None
    bytes_0 = b'\xd0\xee\xbc\xd6\x1ai\x8d\x00\x1b\xb9y\xc8'
    singleton_0 = Singleton(float_0, complex_0, dict_0, bytes_0)

# Generated at 2022-06-25 13:35:15.971175
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton = Singleton()
    assert singleton == Singleton()


# Generated at 2022-06-25 13:35:17.379120
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_obj = Singleton()
    if not singleton_obj.__call__():
        raise AssertionError("Singleton__call__: Fail")



# Generated at 2022-06-25 13:35:18.523033
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = Singleton()
    assert singleton_0.__call__() is not None



# Generated at 2022-06-25 13:35:19.335806
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = Singleton()


# Generated at 2022-06-25 13:35:20.062638
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_1 = Singleton()


# Generated at 2022-06-25 13:35:22.775896
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Case 0
    singleton_0 = Singleton()
    assert singleton_0
    singleton_1 = Singleton()
    assert singleton_1 is singleton_0

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:35:25.458685
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_0 = Singleton() # Call __init__() of class Singleton
    try:
        assert type(singleton_0) == Singleton
    except AssertionError as e:
        raise AssertionError(e)


# Generated at 2022-06-25 13:35:26.372194
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_1 = Singleton()
    assert singleton_1 is not None


# Generated at 2022-06-25 13:35:26.745468
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True

# Generated at 2022-06-25 13:35:28.349607
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_0 = Singleton()
    assert singleton_0 is not None


# Generated at 2022-06-25 13:35:33.512175
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    # Initialize the class object
    tc = TestClass()

    # Assert
    assert tc.__class__.__name__ == "TestClass"



# Generated at 2022-06-25 13:35:38.935343
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.state = 0

        def set_state(self, state):
            self.state = state

    # only care the reference
    a = A()
    b = A()
    assert a == b, "singleton failed"

    a.set_state(2)
    assert b.state == 2, "singleton failed"

# Generated at 2022-06-25 13:35:48.042941
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from types import ModuleType
    from ansible.parsing import vault

    # Test that the same instance is returned on multiple calls
    # to the same class
    assert vault.VaultLib() is vault.VaultLib()

    # Test that the same instance of the same class is returned
    # on subsequent calls to any other class in the same module
    assert vault.VaultLib() is vault.Vault()
    assert vault.VaultLib() is vault.VaultCLI()
    assert vault.VaultLib() is vault.VaultEditor()
    assert vault.VaultLib() is vault.VaultAnsibleModule()

    # Test that all of the classes in the module are of type
    # MetaclassSingleton
    for attr in dir(vault):
        if not attr.startswith('_'):
            att

# Generated at 2022-06-25 13:35:55.646003
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Unit test for the Singleton__call__ method."""
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    class B(object):
        __metaclass__ = Singleton
        def __init__(self, should_throw):
            if should_throw:
                raise Exception("You should throw me!")

    # Create two instances of class A
    a = A()
    b = A()

    assert a == b

    # Ensure that we get the same object back
    c = A()
    assert a == c

    # Creating an instance of class B will not throw
    b1 = B(False)
    assert b1 is not None

    # Creating an instance of class B will throw the second time
    thrown = False

# Generated at 2022-06-25 13:35:58.549021
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        pass

    a = Foo()

    if a is not Foo():
        raise AssertionError('test_Singleton___call__: expected the same instance')

# Generated at 2022-06-25 13:36:04.788165
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Unit test for method Singleton.__call__
    """
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, my_arg):
            self.my_arg = my_arg

    ms_inst1 = MySingleton('my_arg1')
    ms_inst2 = MySingleton('my_arg2')
    assert ms_inst1.my_arg == ms_inst2.my_arg

# Generated at 2022-06-25 13:36:11.945977
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from nose.tools import assert_equals, assert_not_equals

    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    i = MyClass("bar")
    j = MyClass("baz")

    assert_equals(i.foo, "bar")
    assert_equals(j.foo, "baz")
    assert_equals(i, j)

    assert_not_equals(MyClass("qux"), j)



# Generated at 2022-06-25 13:36:22.207926
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class test1(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.content = "content"

    class test2(object):
        def __init__(self):
            self.content = "content"

    a1 = test1()
    a2 = test1()
    assert hasattr(a1, "__metaclass__"), "class instance a1 has attribute __metaclass__"
    assert hasattr(a2, "__metaclass__"), "class instance a2 has attribute __metaclass__"
    assert a1.content == a2.content, "a1 and a2 has equal content"
    assert a1 == a2, "a1 and a2 are equal"

    b1 = test2()
    b2 = test2()

# Generated at 2022-06-25 13:36:23.799246
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            super(MyClass, self).__init__()

    MyClass1 = MyClass()
    MyClass2 = MyClass()

    assert MyClass1 is MyClass2

# Generated at 2022-06-25 13:36:25.608665
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
    x = Foo()
    y = Foo()
    assert y == x

# Generated at 2022-06-25 13:36:33.875067
# Unit test for constructor of class Singleton
def test_Singleton():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self, a=0):
            self.a = a

    c1 = C()
    c1.a = 42
    assert c1 is C()
    assert c1.a == 42

# vim: set expandtab ts=4 sw=4 ai si sta:

# Generated at 2022-06-25 13:36:37.565285
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(metaclass=Singleton):
        def __init__(self):
            self.value = 0

    s = SingletonTest()
    s.value = 1

    s2 = SingletonTest()
    assert s is s2
    assert s.value == 1

# Generated at 2022-06-25 13:36:40.255414
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = 'hello'

    assert(A() == A())
    assert(A().a == 'hello')



# Generated at 2022-06-25 13:36:43.508953
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class test_class(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    a = test_class()
    b = test_class()
    assert(a == b)



# Generated at 2022-06-25 13:36:47.644271
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object, metaclass=Singleton):
        def __init__(self, x=None):
            self.x = x

    ins1 = A(6)
    ins2 = A()

    assert ins1.x == 6
    assert ins2.x == 6
    assert ins1 is ins2



# Generated at 2022-06-25 13:36:50.611464
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert(t1 is t2)

test_Singleton()



# Generated at 2022-06-25 13:36:55.275979
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # create a test class
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    # create a couple of instances
    t1 = Test("test1")
    t2 = Test("test2")

    # check that it's the same object
    assert t1 is t2

    # check that the test1 is the name
    assert "test1" == t1.name



# Generated at 2022-06-25 13:36:56.122786
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert Singleton.__call__() is None



# Generated at 2022-06-25 13:37:01.568364
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.bar = 20

    f1 = Foo()
    f2 = Foo()

    assert f1 == f2
    assert f1 is f2
    assert f1.bar == 20
    assert f2.bar == 20
    assert f1.bar == f2.bar

# Generated at 2022-06-25 13:37:11.511775
# Unit test for constructor of class Singleton
def test_Singleton():
    from collections import defaultdict
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            # The assert that checks whether self.__instance is None
            # will not be valid after the end of the constructor
            # because the __init__ method sets it to the new instance
            assert self.__instance is None, \
                   "self.__instance should be None"
            super(Test, self).__init__()
            self.name = 'tom'
            self.age = 36
            self.hobbies = ['hacking', 'reading', 'cooking']

        def get_my_age(self):
            return self.age

    # Define method of getting the list of attributes of an object

# Generated at 2022-06-25 13:37:23.946561
# Unit test for constructor of class Singleton
def test_Singleton():
    """Calls the constructor of class Singleton and runs tests on the class.
    """
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, foo):
            self.foo = foo

    a = Test(1)
    b = Test(2)

    assert a.foo == 1
    assert a is b

# Generated at 2022-06-25 13:37:29.833544
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.count = 0

        def increment(self):
            self.count += 1

    s = TestSingleton()
    s = TestSingleton()
    assert s.count == 0, \
        "Singleton didn't return correct counts"
    s.increment()
    assert s.count == 1, \
        "Singleton didn't return correct counts"

    s = TestSingleton()
    assert s.count == 1, \
        "Singleton didn't return correct counts"


# Generated at 2022-06-25 13:37:35.332466
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.module_utils.six import with_metaclass
    class Dummy1(with_metaclass(Singleton, object)):
        def __init__(self):
            pass

    class Dummy2(with_metaclass(Singleton, object)):
        def __init__(self, b):
            self.b = b

    class Dummy3(with_metaclass(Singleton, object)):
        def __init__(self, b, c):
            self.b = b
            self.c = c

    d1 = Dummy1()
    assert type(d1) == Dummy1

    d2 = Dummy2(1)
    assert type(d2) == Dummy2
    assert d2.b == 1

    d3 = Dummy3(1, 2)

# Generated at 2022-06-25 13:37:39.210904
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    s1 = S()
    s2 = S()
    assert s1 is s2
    assert s1.x == s2.x
    assert s1.x == 1



# Generated at 2022-06-25 13:37:45.531921
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SomeClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 1

        def __str__(self):
            return str(self.val)

    x = SomeClass()
    print(x)
    y = SomeClass()
    print(y)

    assert x is y
    assert x.val == y.val

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:37:52.377230
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread
    from time import sleep

    class TestSingleton(object, metaclass=Singleton):
        pass
    ts = TestSingleton()

    class T(Thread):
        def __init__(self, ts):
            super(T, self).__init__()
            self.ts = ts

        def run(self):
            sleep(1)
            assert self.ts is ts, 'ts is different'

    ts1 = TestSingleton()
    t = T(ts1)
    t.start()
    t.join()
    assert ts1 is t.ts, 'ts1 is different'



# Generated at 2022-06-25 13:37:54.103312
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class class_to_test(object):
        __metaclass__ = Singleton


# Generated at 2022-06-25 13:37:57.538294
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    obj1 = Test("foo")
    obj2 = Test("bar")
    print(obj1.arg)
    print(obj2.arg)
    assert obj1 is obj2


# Generated at 2022-06-25 13:37:59.997996
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        pass
    
    test1 = Test()
    test2 = Test()
    assert test1 is test2


# Generated at 2022-06-25 13:38:05.733326
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a, b=1, c=None):
            self.a = a
            self.b = b
            self.c = c

    x = Test(1, c=3)
    y = Test(2, c=3)
    z = Test(3, c=3)

    assert x is y is z



# Generated at 2022-06-25 13:38:24.720310
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Foo(object):
        __metaclass__ = Singleton

    instance1 = Foo()
    instance2 = Foo()
    assert instance1 is instance2

# Generated at 2022-06-25 13:38:30.799126
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    class B(A):
        pass

    class C(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 2

    a = A()
    assert a.a == 1
    # instance of a is the same as instance of B
    b = B()
    assert a is b

    # instance of a is not the same as instance of C
    c = C()
    assert a is not c

# Generated at 2022-06-25 13:38:37.168979
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        """Test Singleton"""
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

        def __eq__(self, other):
            if not isinstance(other, TestSingleton):
                return False
            return other.foo == self.foo

    assert(TestSingleton('bar') == TestSingleton('bar'))
    assert(TestSingleton('baz') == TestSingleton('baz'))
    assert(TestSingleton('baz') != TestSingleton('bar'))

# Generated at 2022-06-25 13:38:39.859700
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__= Singleton

    a=Foo()
    b=Foo()
    assert a is b

    c=Foo()
    d=Foo()
    assert c is d

# Generated at 2022-06-25 13:38:43.532740
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            self.value = 1

    obj1 = TestSingleton()
    obj2 = TestSingleton()
    assert(obj1 is obj2)

# Generated at 2022-06-25 13:38:48.142052
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class One(object):
        __metaclass__ = Singleton

        def __init__(self, arg1):
            self.arg1 = arg1

    o0 = One(5)
    o1 = One(10)

    assert o0 is o1
    assert o0.arg1 == 10

# Generated at 2022-06-25 13:38:52.685533
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = A()
    b = A()

    assert a is b
    assert a.test == 'test'
    assert b.test == 'test'
    assert id(a) == id(b)
    assert a.test is b.test

# Generated at 2022-06-25 13:38:57.746552
# Unit test for constructor of class Singleton
def test_Singleton():
    from uuid import uuid4
    from docutils import nodes

    class DummyClass(nodes.Node):
        __metaclass__ = Singleton

        def __init__(self):
            self.__id = str(uuid4())

        @property
        def ident(self):
            return self.__id

    dummy1 = DummyClass()
    dummy2 = DummyClass()

    assert(id(dummy1) == id(dummy2))
    assert(dummy1.ident == dummy2.ident)



# Generated at 2022-06-25 13:39:02.648119
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = 'foobar'

    t1 = TestClass()
    t2 = TestClass()

    assert t1.foo == t2.foo
    assert id(t1) == id(t2)



# Generated at 2022-06-25 13:39:04.750307
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        pass

    assert MyClass() is MyClass()


# Generated at 2022-06-25 13:39:41.730447
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = 'a'

    a1 = A()
    a2 = A()

    assert a1 == a2
    assert a1.a == a2.a

    a1.a = 'A'
    assert a1.a == a2.a

# Generated at 2022-06-25 13:39:43.841928
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass:
        __metaclass__ = Singleton
        pass

    a = MyClass()
    b = MyClass()
    assert a == b



# Generated at 2022-06-25 13:39:49.023126
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import types

    class Test(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    # instantiate once
    t = Test('a')
    # instantiate again without any side effect 
    t2 = Test('a')
    assert t2.name == t.name
    assert t2 is t

    # not really a test
    print('passed')

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:39:51.780652
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = MySingleton("one")
    b = MySingleton("two")
    assert a == b
    print("Pass case for Singleton.__call__")


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:39:58.427301
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object): pass

    class B(A):
        __metaclass__ = Singleton

    class C(B): pass

    class D(C): pass

    b1 = B()
    b2 = B()
    c1 = C()
    c2 = C()
    d1 = D()
    d2 = D()
    assert b1 is b2
    assert c1 is c2
    assert d1 is d2
    assert b1 is not c1
    assert b1 is not d1
    assert c1 is not d1

# Generated at 2022-06-25 13:40:03.117768
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, a, b='value'):
            self.a = a
            self.b = b

    assert MyClass('first', b='2nd') is MyClass(1, b=2)
    assert MyClass('first', b='2nd').a == 1
    assert MyClass('first', b='2nd').b == 2

# Generated at 2022-06-25 13:40:06.929693
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        def __init__(self):
            self.value = 0

    class B(A):
        __metaclass__ = Singleton

    b1 = B()
    b2 = B()
    b1.value = 2
    assert b2.value == 2, 'singleton behavior broken'

# Generated at 2022-06-25 13:40:09.743561
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    assert TestSingleton().a == 1
    assert TestSingleton().a == 1
    assert TestSingleton().a == 1

# Generated at 2022-06-25 13:40:11.298595
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

    s1 = S()
    assert (s1 == S())



# Generated at 2022-06-25 13:40:16.034990
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class First(metaclass=Singleton):
        def __init__(self):
            self._value = 0

        def set_value(self, value):
            self._value = value

        def get_value(self):
            return self._value

    f1 = First()
    f2 = First()
    assert f1 == f2
    assert f1 is f2
    assert not f1 < f2
    assert not f1 > f2
    assert f1 <= f2
    assert f1 >= f2

    f1.set_value(10)
    assert f1.get_value() == f2.get_value()
    assert f1.get_value() == 10


# Generated at 2022-06-25 13:41:35.528459
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  class A_class(object):
    __metaclass__ = Singleton

    def __init__(self, param):
      self.attr = param

  a = A_class(1)
  assert(a.attr == 1)

  b = A_class(2)
  assert(a.attr == 1)
  assert(b.attr == 1)
  assert(a == b)



# Generated at 2022-06-25 13:41:36.996973
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.plugins.loader import shared_loader_obj, PluginLoader

    new_shared_loader_obj = PluginLoader("test_Singleton")

    assert new_shared_loader_obj == shared_loader_obj

# Generated at 2022-06-25 13:41:40.272513
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    x = Foo()
    y = Foo()
    assert x is y

# Generated at 2022-06-25 13:41:44.010755
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, bar):
            self.bar = bar
    f1 = Foo(1)
    assert f1.bar == 1
    f2 = Foo(2)
    assert f2.bar == 1


# Generated at 2022-06-25 13:41:47.071516
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        def __init__(self, arg):
            self.arg = arg

    assert Test('foo') is Test('bar')
    assert Test('foo').arg == 'bar'



# Generated at 2022-06-25 13:41:53.929458
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(Singleton):
        def __init__(self):
            if not hasattr(self, '_called_init'):
                self._called_init = True


    m1 = MySingleton()
    assert m1._called_init

    m2 = MySingleton()
    assert m2._called_init is False

    assert m1 is m2
    # test for setattr/getattr
    attr_val = "TestValue"
    setattr(m1, 'TestAttribute', attr_val)
    assert getattr(m1, 'TestAttribute') == attr_val


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:41:57.685094
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def hello(self):
            print("hello world")

    a = Test()
    b = Test()
    assert a == b
    a.hello()
    b.hello()

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:41:59.288189
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object, metaclass=Singleton):
        pass

    foo = Foo()
    assert foo is Foo()
    assert foo is not Foo()

# Generated at 2022-06-25 13:42:02.582895
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    class B(A):
        pass

    class C(A):
        pass

    class D(object):
        __metaclass__ = Singleton

    assert A() is B() is C()
    assert A() is not D()

# Generated at 2022-06-25 13:42:06.374935
# Unit test for constructor of class Singleton
def test_Singleton():
    class TClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = None

    # Check that the instances are the same
    TClass1 = TClass()
    TClass1.a = 1
    TClass2 = TClass()
    assert TClass1 is TClass2
    assert TClass1.a == TClass2.a == 1