

# Generated at 2022-06-25 13:34:21.866588
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert(False)

    try:
        print(locals())
    except Exception as e:
        print(e)
        assert(False)


# Generated at 2022-06-25 13:34:31.496343
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    Asserts that the Singleton class's __call__ method returns a class instance.
    """
    # Prepare test
    class test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.__test_val = 0
    test_inst_0 = test()
    test_inst_1 = test()

    # Test
    if test_inst_0 is not None:
        pass
    else:
        raise Exception()
    if test_inst_1 is not None:
        pass
    else:
        raise Exception()
    if test_inst_0 == test_inst_1:
        pass
    else:
        raise Exception()
    if test_inst_0 is test_inst_1:
        pass
    else:
        raise Exception()


# Generated at 2022-06-25 13:34:35.789260
# Unit test for constructor of class Singleton
def test_Singleton():
    cls_0 = type.__new__(Singleton, "c", (), {})
    cls_0_instance = cls_0()
    if cls_0_instance is not None:
        raise Exception('Assertion failed')
    if cls_0_instance is None:
        assert ((cls_0_instance is not None) or (type(cls_0) is type))


# Generated at 2022-06-25 13:34:40.193399
# Unit test for constructor of class Singleton
def test_Singleton():
    result = None
    clazz = None

    try:
        clazz = Singleton
    except:
        pass

    if clazz.__instance is None:
        result = True
    else:
        result = False

    return result


# Generated at 2022-06-25 13:34:41.672751
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton.__instance == None


# Generated at 2022-06-25 13:34:43.559397
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    obj_1 = Singleton()
    obj_2 = Singleton()
    assert obj_1 == obj_2


# Generated at 2022-06-25 13:34:46.170895
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:34:47.526200
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton is not None


# Generated at 2022-06-25 13:34:49.403201
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  Singleton___call___0 = Singleton('Singleton___call___0', (), {})
  Singleton___call___0()


# Generated at 2022-06-25 13:34:58.526762
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    obj_0 = test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    dict_obj = {"test_key":"test_value"}
    int_0 = -1797
    list_0 = [dict_obj, dict_obj, dict_obj, dict_obj]
    set_0 = {list_0, list_0}
    dict_obj = {"test_key":"test_value"}
    int_0 = -2929

# Generated at 2022-06-25 13:35:01.767040
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:35:02.660477
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:35:05.987490
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_2 = 'Singleton'
    var_4 = ()
    var_5 = {}
    singleton_1 = Singleton(str_2, var_4, var_5)
    singleton_1.__call__ = Singleton.__call__


# Generated at 2022-06-25 13:35:06.555045
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True

# Generated at 2022-06-25 13:35:07.473234
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:35:09.039177
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert test_case_0() == None


# Generated at 2022-06-25 13:35:12.255130
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()

# Generated at 2022-06-25 13:35:14.950239
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    func = test_Singleton___call__.__name__
    print()
    print(func)
    print('NOT IMPLEMENTED')
    # TODO: Implement this!


# Generated at 2022-06-25 13:35:15.970838
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()


# Generated at 2022-06-25 13:35:16.540719
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:35:19.706719
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:35:21.751003
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)

    test_case_0()


# Generated at 2022-06-25 13:35:22.483024
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()



# Generated at 2022-06-25 13:35:23.488645
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:35:24.293823
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True == True


# Generated at 2022-06-25 13:35:26.345221
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_1 = ()
    var_2 = {}
    singleton_0 = Singleton('Singleton___call___0', var_1, var_2)


# Generated at 2022-06-25 13:35:27.458196
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:35:28.141578
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:35:28.813672
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()



# Generated at 2022-06-25 13:35:31.289558
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call__'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)

    assert singleton_0.__class__.__name__ == 'Singleton'

# Generated at 2022-06-25 13:35:38.319958
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0()


# Generated at 2022-06-25 13:35:39.130119
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert callable(Singleton.__call__)

# Generated at 2022-06-25 13:35:41.177039
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = Singleton('str_0', (), {})
    obj_0 = singleton_0()
    assert obj_0 is not None


# Generated at 2022-06-25 13:35:43.940611
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___1'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)

# Generated at 2022-06-25 13:35:45.091331
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:35:45.973366
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    test_case_0()

# Generated at 2022-06-25 13:35:47.310126
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    unittest_Singleton__call_0()



# Generated at 2022-06-25 13:35:47.888233
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Run unit tests
test_Singleton___call__()

# Generated at 2022-06-25 13:35:50.591910
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0()


# Generated at 2022-06-25 13:35:52.679579
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansiblelint.ansible_test_case import assert_equals
    test_case_0()
    assert_equals(True, True)

# Generated at 2022-06-25 13:35:57.858231
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:36:01.523862
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0()


# Generated at 2022-06-25 13:36:03.609913
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = Singleton('Singleton___call__', (), {'__init__': test_case_0})
    var_0()



# Generated at 2022-06-25 13:36:04.786974
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:36:08.369148
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_2 = ()
    var_3 = {}
    str_1 = 'Singleton___call___1'
    singleton_1 = Singleton(str_1, var_2, var_3)


# Generated at 2022-06-25 13:36:11.814816
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # print('In test_Singleton___call__')
    '''
    test_Singleton___call__
    In test_case_0
    '''
    test_case_0()
    '''
    Singleton___call___0
    '''


# Generated at 2022-06-25 13:36:12.949494
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()


# Generated at 2022-06-25 13:36:17.629885
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest
    import logging
    logging.disable(logging.CRITICAL)        

# Generated at 2022-06-25 13:36:19.634431
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = Singleton('Singleton', (), {})
    var_0 = singleton_0()


# Generated at 2022-06-25 13:36:22.331353
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:36:31.865744
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:36:41.039261
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    for i in range(0, 10):
        singleton_0()
    try:
        singleton_0()
    except TypeError as exc:
        assert 'instance() takes at most 2 arguments (3 given)' in exc.message

    class singleton_0(Singleton):
        def __init__(self, *args):
            self.arg = args[0]

    s1 = singleton_0("A")
    assert s1.arg == "A"
    s2 = singleton_0("B")
    assert s2.arg == "A", s2.arg



# Generated at 2022-06-25 13:36:41.958950
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:36:43.870441
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_1 = Singleton
    singleton_2 = Singleton
    assert singleton_1 is singleton_2

# Generated at 2022-06-25 13:36:45.632310
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Unit test for method __call__ of class Singleton
    """
    raise NotImplemented()



# Generated at 2022-06-25 13:36:46.537420
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()


# Generated at 2022-06-25 13:36:47.644100
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    test_case_0()

# Generated at 2022-06-25 13:36:51.593650
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton_1'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = Singleton(str_0, var_0, var_1)
    assert singleton_0 == singleton_1


# Generated at 2022-06-25 13:36:53.631001
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    test_case_0()

# Generated at 2022-06-25 13:36:57.535376
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    test_case_0()


# Generated at 2022-06-25 13:37:18.377534
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:37:24.868992
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread


    def another_thread():
        import time
        time.sleep(1)
        assert TestSingleton.instance == None
        TestSingleton()
        TestSingleton()
        assert TestSingleton.instance != None


    TestSingleton = Singleton('TestSingleton', (), {})
    TestSingleton()
    thread = Thread(target=another_thread)
    thread.start()
    TestSingleton()
    assert TestSingleton.instance != None
    thread.join()
    assert TestSingleton.instance != None

# Generated at 2022-06-25 13:37:25.702614
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True == False


# Generated at 2022-06-25 13:37:26.489273
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:37:32.885074
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call__0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'Singleton___call__1'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    singleton_2 = singleton_1()
    assert( isinstance(singleton_2, Singleton) )
    return

    # TODO: Error?
    assert(singleton_1 == singleton_2)
    


# Generated at 2022-06-25 13:37:33.469272
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:37:35.268640
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = Singleton()
    singleton_1 = Singleton()
    assert singleton_0 is singleton_1


# Generated at 2022-06-25 13:37:39.787818
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.utils.singleton import Singleton
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.other.other_utils import A

    a1 = A()
    a2 = A()

    assert a1 is a2

    singleton_0 = Singleton()
    singleton_1 = Singleton()

    assert singleton_0 is singleton_1

# Generated at 2022-06-25 13:37:44.355525
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Call method __call__ using object of class Singleton
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()

# Generated at 2022-06-25 13:37:47.463711
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0()


# Generated at 2022-06-25 13:38:05.101618
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = test_case_0()

# Generated at 2022-06-25 13:38:07.792748
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:38:09.049830
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test cases
    test_case_0()

# Generated at 2022-06-25 13:38:09.899698
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    run_test(test_case_0)

# Generated at 2022-06-25 13:38:11.663068
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton('test', var_0, var_1)
    singleton_0()


# Generated at 2022-06-25 13:38:18.103966
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)

    def test_case_0():
        str_0 = 'test_case_0'
        str_1 = 'Singleton___call___0'
        var_0 = ()
        var_1 = {}
        singleton_0 = Singleton(str_1, var_0, var_1)
        assert_equals(id(singleton_0), id(singleton_0()))
        assert_equals(id(singleton_0), id(Singleton(str_0, var_0, var_1)))

# Generated at 2022-06-25 13:38:19.296189
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert callable(Singleton.__call__)

# Generated at 2022-06-25 13:38:20.381213
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:38:23.062340
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        assert True # TODO: implement your test here
        # The specified test target is not implemented
    except AssertionError as e:
        raise(e)
    except Exception as e:
        raise(e)

# Generated at 2022-06-25 13:38:24.029365
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:39:01.305580
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert test_Singleton___call__()



# Generated at 2022-06-25 13:39:03.774972
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        test_case_0()
    except:
        print('test_Singleton___call__ failed')

# This is the unit test for Singleton class

# Generated at 2022-06-25 13:39:08.504726
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    Check if a singleton instance is returned.
    """
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert singleton_0 is Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:39:13.215200
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert callable(singleton_0)
    # Test method __call__
    singleton_0()
    # Test exception IndexError
    # assertRaises(IndexError, singleton_0)


# Generated at 2022-06-25 13:39:14.303330
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()



# Generated at 2022-06-25 13:39:15.431762
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Perform method unit test here
    test_case_0()



# Generated at 2022-06-25 13:39:15.826450
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()


# Generated at 2022-06-25 13:39:16.705796
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from types import BuiltinFunctionType

    assert type(Singleton.__call__) is BuiltinFunctionType
    test_case_0()

# Generated at 2022-06-25 13:39:17.064890
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-25 13:39:17.835384
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:40:40.185778
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print('test_Singleton___call__')
    test_case_0()


# Generated at 2022-06-25 13:40:42.101423
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print('Testing Singleton___call__')
    test_case_0()
    print('Done testing Singleton___call__')


# Generated at 2022-06-25 13:40:50.816105
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
	assert(test_case_0())

#def test_case_1():
#    str_0 = 'Singleton___call___1'
#    var_0 = ()
#    var_1 = {}
#    singleton_0 = Singleton(str_0, var_0, var_1)
#
## Unit test for method __call__ of class Singleton
#def test_Singleton___call__():
#	assert(test_case_1())
#
#def test_case_2():
#    str_0 = 'Singleton___call___2'
#    var_0 = ()
#    var_1 = {}
#    singleton_0 = Singleton(str_0, var_0, var_1)
#
## Unit test for method __call__ of class Singleton
#def test_Singleton___call

# Generated at 2022-06-25 13:40:52.021169
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_Singleton___call__True()



# Generated at 2022-06-25 13:40:53.561976
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    unit_test_0()
    unit_test_1()
    unit_test_2()
    unit_test_3()


# Generated at 2022-06-25 13:40:55.443786
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Check Singleton.__call__ raises TypeError
    try:
        Singleton(1, 2, 3)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-25 13:41:00.242218
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton___call___0'
    try:
        test_case_0()
        print(str_0)
    except Exception as exception_0:
        print(exception_0)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:41:01.309118
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:41:11.081246
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    lock_0 = RLock()
    lock_0
    singleton_0 = Singleton
    var_0 = ()
    var_1 = {}
    singleton_1 = Singleton(var_0, var_1, lock_0)
    singleton_2 = Singleton(var_0, var_1, lock_0)
    singleton_3 = Singleton(var_0, var_1, lock_0)
    singleton_4 = Singleton(var_0, var_1, lock_0)
    singleton_5 = Singleton(var_0, var_1, lock_0)
    singleton_6 = Singleton(var_0, var_1, lock_0)
    singleton_7 = Singleton(var_0, var_1, lock_0)
    singleton_8 = Singleton

# Generated at 2022-06-25 13:41:12.383943
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print('___call__ Singleton')
    test_case_0()
