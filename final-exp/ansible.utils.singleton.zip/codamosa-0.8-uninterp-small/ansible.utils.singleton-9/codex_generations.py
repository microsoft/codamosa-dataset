

# Generated at 2022-06-25 13:34:16.948429
# Unit test for constructor of class Singleton
def test_Singleton():
    # test case 0
    test_case_0()



# Generated at 2022-06-25 13:34:18.847765
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_0 = Singleton()
    singleton_0.__init__()


# Generated at 2022-06-25 13:34:19.760314
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    Singleton.__call__()


# Generated at 2022-06-25 13:34:27.682220
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_0 = Singleton("$%a", (), {}, "uOp+*d!2@0=s,:&0+m)")
    dict_0 = {}
    dict_0[1] = True
    dict_0[1] = False
    dict_0[0] = False
    dict_0[1] = True
    dict_0[1] = True
    dict_0[0] = False
    dict_0[1] = True
    dict_0[1] = True


if __name__ == '__main__':
    test_case_0()
    test_Singleton()

# Generated at 2022-06-25 13:34:32.880478
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    int_0 = None
    bool_0 = True
    dict_0 = {int_0: bool_0, int_0: bool_0, int_0: bool_0, bool_0: int_0}
    singleton_0 = Singleton(int_0, bool_0, dict_0, dict_0)
    int_0 = singleton_0.__call__()
    assert int_0 is not None


# Generated at 2022-06-25 13:34:41.818564
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    int_0 = None
    bool_0 = True
    dict_0 = {int_0: bool_0, int_0: bool_0, int_0: bool_0, bool_0: int_0}
    singleton_0 = Singleton(int_0, bool_0, dict_0, dict_0)
    int_0 = singleton_0.__call__(int_0, bool_0, dict_0, dict_0)

# Test to see if function test_Singleton___call__ is working
test_case_0()
test_Singleton___call__()

# Generated at 2022-06-25 13:34:43.026307
# Unit test for constructor of class Singleton
def test_Singleton():
    test_case_0()

# Generated at 2022-06-25 13:34:48.272185
# Unit test for constructor of class Singleton
def test_Singleton():
    dict_0 = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}
    singleton_0 = Singleton('TestClass', (), dict_0, dict_0)
    dict_1 = singleton_0.__dict__

    assert dict_1 == dict_0, \
        "New instance dictionary not equal to expected test dictionary"


# Generated at 2022-06-25 13:34:49.769130
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # TODO: Write test case for method __call__ of class Singleton
    pass



# Generated at 2022-06-25 13:34:50.637125
# Unit test for constructor of class Singleton
def test_Singleton():
    test_case_0()

test_Singleton()

# Generated at 2022-06-25 13:34:52.361237
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass



# Generated at 2022-06-25 13:34:53.377305
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
        test_case_0()

# Generated at 2022-06-25 13:34:57.396850
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = '=)=v'
    var_0 = ()
    var_1 = {}
    str_1 = 'bz_'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = {}
    with singleton_0:
        pass
    singleton_0.__call__(var_2)

# Generated at 2022-06-25 13:35:00.469586
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = '$%a'
    var_0 = ()
    var_1 = {}
    str_1 = 'uOp+*d!2@0=s,:&0+m)'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = {}

# Generated at 2022-06-25 13:35:09.993830
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_1 = 'jKc%4z=7-u'
    var_7 = ()
    var_8 = {}
    str_2 = '6!xU6ymzU6+5\x7f'
    singleton_1 = Singleton(str_1, var_7, var_8)
    str_3 = '7\x7f9A+'
    var_9 = ()
    var_10 = {}
    singleton_2 = Singleton(str_3, var_9, var_10)
    str_0 = '$%a'
    var_0 = ()
    var_1 = {}
    str_4 = 'uOp+*d!2@0=s,:&0+m)'

# Generated at 2022-06-25 13:35:14.108284
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'uOp+*d!2@0=s,:&0+m)'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = {}
    singleton_0(var_2)
    var_3 = {}

# Generated at 2022-06-25 13:35:17.667862
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    str_0 = '9=%&kQ'
    var_0 = ()
    var_1 = {}
    str_1 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    print(singleton_0.__call__())


# Generated at 2022-06-25 13:35:23.456847
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = (1, 2, 3)
    var_4 = {'a': 1, 'b': 2, 'c': 3}
    var_5 = 1
    var_6 = 'abc'
    var_7 = 6
    var_8 = 'def'
    str_2 = 'w}1xyh*bY.@bl3'
    singleton__call___0 = Singleton('*g:Yu1$wZ15', var_3, var_4)
    singleton__call___0.__call__(var_5, var_6, var_7, var_8, str_2=str_2)


# Generated at 2022-06-25 13:35:24.256553
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass


# Generated at 2022-06-25 13:35:25.111638
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print("\nTest _Singleton.__call__()")
    test_case_0()

# Generated at 2022-06-25 13:35:33.734858
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import random

    test_cases = [
        #(
        #{
        #    "inputs": (("Lu_x|", (), {}), ("wE*U}", (), {}), ("<U$+q", (), {}), ("MLS2S", (), {}), ("g+", (), {}), ("$1yB", (), {}), ("C}t", (), {})),
        #    "result": "Lu_x|"
        #}
        #),
        (
        {
            "inputs": (("z$e+|w[p", (), {}), ("`}W`", (), {}), ("(*L", (), {})),
            "result": "z$e+|w[p"
        }
        ),
    ]

    for test_case in test_cases:
        # Arrange
        test_inputs

# Generated at 2022-06-25 13:35:36.830577
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    if True:
        singleton_0 = Singleton()
        singleton_0.__call__()
    else:
        singleton_0 = Singleton()
        singleton_0.__call__()


# Generated at 2022-06-25 13:35:42.627775
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_10 = ()
    var_11 = {}
    str_10 = 'XnH4A'
    singleton_10 = Singleton(str_10, var_10, var_11)
    var_12 = ()
    var_13 = {}
    str_11 = 'LfnST'
    singleton_11 = Singleton(str_11, var_12, var_13)
    var_14 = singleton_11.__call__()
    var_15 = singleton_10.__call__()


# Generated at 2022-06-25 13:35:43.820181
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 13:35:44.445748
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True == True

# Generated at 2022-06-25 13:35:53.036182
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = '7'
    str_1 = '/b'
    str_2 = 'w.hT_'
    str_3 = '9-A'
    str_4 = '6Uq#'
    str_5 = 'JvE8'
    str_6 = '-5'
    str_7 = '{Z^1'
    str_8 = '%8.`'
    str_9 = '5b'
    str_10 = ')'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = Singleton(str_1, var_0, var_1)
    singleton_2 = Singleton(str_2, var_0, var_1)
   

# Generated at 2022-06-25 13:35:56.455818
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = Singleton('s', (), {})
    var_0 = ()
    var_1 = {}
    str_0 = 'T@!s,s'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__instance = singleton_0
    singleton_0.__rlock = RLock()
    singleton_0.__call__()



if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:36:00.454834
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:36:04.650437
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    # AssertionError


# Generated at 2022-06-25 13:36:13.246990
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_1 = 'Singleton'
    var_3 = ()
    var_4 = {}
    # Class instantiation
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = 'Singleton'
    var_6 = ()
    var_7 = {}
    var_8 = {}
    singleton_2 = Singleton(var_5, var_6, var_7)
    instance_0 = singleton_2.__call__(var_8)


if __name__ == '__main__':
    test_case_0()
    test_Singleton___call__()

# Generated at 2022-06-25 13:36:15.972616
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert callable(Singleton.__call__)


# Generated at 2022-06-25 13:36:19.592079
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()

# Generated at 2022-06-25 13:36:23.728803
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Testing the following condition: 'cls'
    str_0 = 'fXx44'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()



# Generated at 2022-06-25 13:36:25.201975
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert singleton_0.__call__()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:36:27.143880
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'r1z9j1'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()


# Generated at 2022-06-25 13:36:27.681108
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert False


# Generated at 2022-06-25 13:36:30.282744
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
	var_0 = ()
	var_1 = {}
	str_0 = 'BtLX9+'
	singleton_0 = Singleton(str_0, var_0, var_1)
	var_2 = singleton_0.__call__()

# Generated at 2022-06-25 13:36:39.450888
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = '~.A'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = ()
    var_6 = {}
    str_2 = 'xvj8`'
    singleton_2 = Singleton(str_2, var_5, var_6)
    var_7 = singleton_1.__call__()
    var_8 = singleton_2.__call__()
    bool_0 = (var_7 is var_8)
    var_9 = ()
    var_10 = {}
    str_3 = 'yU$*@'
    singleton_3 = Singleton(str_3, var_9, var_10)
    var_11 = singleton_3

# Generated at 2022-06-25 13:36:43.018070
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'Q8-X`'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()


# Generated at 2022-06-25 13:36:46.616713
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = '!#9Nf'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()



# Generated at 2022-06-25 13:36:49.485237
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:36:53.230837
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert type(singleton_0.__call__()) is singleton_0, "Line 10: Unexpected result"


# Generated at 2022-06-25 13:36:54.562550
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        test_case_0()
    except Exception as err:
        print(err)



# Generated at 2022-06-25 13:37:00.210315
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    var_3 = singleton_0.__call__()
    assert var_2 is var_3


# Generated at 2022-06-25 13:37:05.051198
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = '2VuL*#'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    var_3 = singleton_0.__call__()


# Generated at 2022-06-25 13:37:13.583718
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_2 = ()
    var_3 = {}
    str_1 = 'BtLX9+'
    singleton_1 = Singleton(str_1, var_2, var_3)

    # Testing '__call__' method of class 'Singleton'
    var_4 = ()
    var_5 = {}
    str_2 = 'BtLX9+'
    singleton_2 = Singleton(str_2, var_4, var_5)
    var_6 = singleton_2.__call__()
    var_6 = singleton_1.__call__()
    var_7 = (1, 2, 3)
    singleton_2.__call__(var_7)
    var_8 = {}
    singleton_2.__call__(var_8)

# Unit

# Generated at 2022-06-25 13:37:18.558568
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'LmjVm;{'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    var_3 = singleton_0.__call__()
    assert var_2 is var_3



# Generated at 2022-06-25 13:37:22.204155
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()


# Generated at 2022-06-25 13:37:25.544584
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'bkA'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:37:26.044095
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True


# Generated at 2022-06-25 13:37:30.436220
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'qXIp+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()
    singleton_0.__call__()

# Generated at 2022-06-25 13:37:36.102083
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = 'BtLX9+'
    singleton_0.__call__()
    singleton_0.__call__()
    var_3 = singleton_0.__dict__['_Singleton__instance']
    var_4 = var_3.__class__.__name__
    assert var_2 is var_4


# Generated at 2022-06-25 13:37:39.323589
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = 'BtLX9+'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = singleton_1.__call__()


# Generated at 2022-06-25 13:37:43.818688
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'T  O)'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()
    singleton_0.__call__()



# Generated at 2022-06-25 13:37:47.295519
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = '/XGI<'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = singleton_1.__call__()



# Generated at 2022-06-25 13:37:48.194135
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:37:50.566295
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()

# Generated at 2022-06-25 13:37:58.249237
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = '\x01\x1b\x05\t\x82\x11\t\x1f\x1e\x19%\x8f\x0eV\x18$\r\x1b\x95\x1f\x1a\x82\x08'

# Generated at 2022-06-25 13:38:02.105535
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  str_0 = 'BtLX9+'
  var_0 = ()
  var_1 = {}
  singleton_0 = Singleton(str_0, var_0, var_1)
  assert singleton_0.__call__() is not None



# Generated at 2022-06-25 13:38:09.358036
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Setup
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    # Procedure call
    var_2 = singleton_0.__call__()
    # Verification
    assert (var_2 == singleton_0.__instance), "Assertion failed."
    assert (var_2 == singleton_0.__instance), "Assertion failed."
    assert (var_2 != singleton_0.__instance), "Assertion failed."

# Generated at 2022-06-25 13:38:11.808451
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True
# EOF

# Generated at 2022-06-25 13:38:14.507424
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()


# Generated at 2022-06-25 13:38:16.140308
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, (), {})
    singleton_0.__call__()

# Generated at 2022-06-25 13:38:24.609968
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 's'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    str_1 = '_'
    str_2 = '_'
    str_3 = '_'
    str_4 = '_'
    str_5 = '_'
    str_6 = '_'
    str_7 = '_'
    var_0 = ()
    var_1 = {str_2:str_3, str_4:str_5, str_6:str_7}
    str_8 = '_'
    str_9 = '_'

# Generated at 2022-06-25 13:38:33.221924
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.module_utils.common._collections_compat import Mapping
    from threading import RLock
    import threading

    class Singleton(type):
        """Metaclass for classes that wish to implement Singleton
        functionality.  If an instance of the class exists, it's returned,
        otherwise a single instance is instantiated and returned.
        """
        def __init__(cls, name, bases, dct):
            super(Singleton, cls).__init__(name, bases, dct)
            cls.__instance = None
            cls.__rlock = RLock()

        def __call__(cls, *args, **kw):
            if cls.__instance is not None:
                return cls.__instance


# Generated at 2022-06-25 13:38:36.510317
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()



# Generated at 2022-06-25 13:38:37.603720
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 13:38:38.052935
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True


# Generated at 2022-06-25 13:38:39.063724
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    _test_case_0()



# Generated at 2022-06-25 13:38:39.860558
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass


# Generated at 2022-06-25 13:38:43.249666
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:38:49.261130
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'b#'
    str_1 = 'fq)8N'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_2 = '#r!-*'
    var_2 = singleton_0.__call__(str_2)
    assert var_2.__str__() == str_1

# Generated at 2022-06-25 13:38:57.369073
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = {}
    str_1 = '>'
    str_2 = 'Vc'
    str_3 = 'k_F'

    var_4 = ()
    str_4 = '>'
    str_5 = 'S'
    str_6 = 'h-m'
    var_4 = (str_4,)
    var_4 = str_6.join(var_4)
    var_4 = (str_5,) + (var_4,)
    var_4 = str_6.join(var_4)
    var_4 = (str_3,) + (var_4,)
    var_4 = str_6.join(var_4)
    var_4 = (str_2,) + (var_4,)
    var_4 = str_6.join(var_4)


# Generated at 2022-06-25 13:39:01.576682
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:39:08.221184
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test for call
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    assert var_2 is singleton_0.__instance
    assert singleton_0.__instance is not None
    var_2 = singleton_0.__call__()
    assert var_2 is singleton_0.__instance


# Generated at 2022-06-25 13:39:09.074262
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  test_case_0()

# Generated at 2022-06-25 13:39:10.721253
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Assert failure for execution of method __call__ of class Singleton
    assert False, "__call__"


# Generated at 2022-06-25 13:39:14.223751
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = '+I'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = singleton_1.__call__()


# Generated at 2022-06-25 13:39:17.153570
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = '0@[I}6'
    singleton_0 = Singleton(str_0, var_0, var_1)
    # Begin test ...
    # End test


# Generated at 2022-06-25 13:39:20.042446
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = '/|no7'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()



# Generated at 2022-06-25 13:39:23.227297
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True


# Generated at 2022-06-25 13:39:30.687745
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'Yj2dC'
    singleton_0 = Singleton(str_0, var_0, var_1)
    # Calling __call__ directly would create a new instance and return
    # a different value from the one we stored in instance
    singleton_1 = Singleton(str_0, var_0, var_1)
    assert singleton_1 is singleton_1
    str_0 = 'Yj2dC'
    assert singleton_1.__name__ == str_0


# Generated at 2022-06-25 13:39:34.055769
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:39:37.729725
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_a = ()
    var_b = {}
    str_0 = 'uV7'
    singleton_0 = Singleton(str_0, var_a, var_b)
    var_c = singleton_0.__call__()
    assert not (var_c is None)


# Generated at 2022-06-25 13:39:39.608643
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = None

    with Singleton.__rlock:
        if singleton_0 is None:
            singleton_0 = None

    var_0 = singleton_0
    var_0.__call__()

# Generated at 2022-06-25 13:39:43.843840
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    var_1[str_0] = var_2
    var_3 = singleton_0.__call__()
    assert var_3 == var_2



# Generated at 2022-06-25 13:39:47.128954
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'v'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:39:54.452005
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # 'assert' statements are used to check if a condition is met
    # 'assert' will raise an exception if a condition is not met
    # 'try' and 'except' are used to handle exceptions
    try:
        test_case_0()
        print('passed test case 0')
    except:
        print('failed test case 0')
    try:
        # test case
        # expected result:
        # 'passed test case 1'
        # actual result:
        # 'failed test case 1'
        test_case_1()
        print('passed test case 1')
    except:
        print('failed test case 1')

# Generated at 2022-06-25 13:39:55.319438
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:40:00.629614
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'bYQBQ'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__init__(str_0, var_0, var_1)
    singleton_0.__call__()

if (__name__ == '__main__'):
    test_Singleton___call__()

# Generated at 2022-06-25 13:40:04.718976
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert test_case_0() is None


# Generated at 2022-06-25 13:40:10.454598
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    assert isinstance(var_2, singleton_0), "Expected: {} but got {}".format(singleton_0, type(var_2))
    assert var_2 == singleton_0.__instance, "Expected: {} but got {}".format(singleton_0.__instance, var_2)



# Generated at 2022-06-25 13:40:10.926946
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-25 13:40:11.665076
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  assert 25 == 25


# Generated at 2022-06-25 13:40:14.348475
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = 'BtLX9+'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = singleton_1.__call__()
    assert singleton_1.__instance is var_5


# Generated at 2022-06-25 13:40:15.434411
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Singleton is an abstract class
    assert 0 == 1


# Generated at 2022-06-25 13:40:19.279174
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'rNDdcq'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()

# Unit test of method __init__ of class Singleton

# Generated at 2022-06-25 13:40:28.557890
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Asserts that the two instances of the class A are identical.
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert A() is A()

    # Asserts that the two instances of the class B are identical.
    class B(A):
        pass

    assert B() is B()

    # Asserts that the two instances of the class B are different than the
    # instances of the class A.
    assert A() is not B()

    # Asserts that the singleton works from the module.
    class C(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert C() is C()

    # Asserts that the singleton works from the module.

# Generated at 2022-06-25 13:40:32.183600
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:40:35.231769
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = 'HfwRK7'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = singleton_1.__call__()

# Generated at 2022-06-25 13:40:42.987793
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'gf|'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    assert var_2 is not None
    assert var_2 is singleton_0.__call__()


# Generated at 2022-06-25 13:40:48.135518
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# main function
if __name__ == "__main__":
    operationChoice = input('Choose one of the following user operations: 1)Test __init__ method 2)Test __call__ method 3)Exit')
    if operationChoice == '1':
        test_Singleton___init__()
    elif operationChoice == '2':
        test_Singleton___call__()
    else:
        sys.exit()

# Generated at 2022-06-25 13:40:55.530515
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    int_0 = 0
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)

# Generated at 2022-06-25 13:40:59.691723
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:41:03.395975
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()


# Generated at 2022-06-25 13:41:06.993217
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()



# Generated at 2022-06-25 13:41:08.741591
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # The method __call__ of class Singleton is defined here
    pass


# Generated at 2022-06-25 13:41:09.963627
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass


# Generated at 2022-06-25 13:41:10.759605
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True


# Generated at 2022-06-25 13:41:16.645573
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'BtLX9+'
    var_0 = {}
    var_1 = ()
    singleton_0 = Singleton(str_0, var_1, var_0)
    var_2 = singleton_0.__call__()
    assert singleton_0.__instance == var_2
    str_1 = 's4sndy'
    var_3 = {}
    var_4 = ()
    singleton_1 = Singleton(str_1, var_4, var_3)
    var_5 = singleton_1.__call__()
    assert singleton_1.__instance == var_2
    assert var_2 == var_5


# Generated at 2022-06-25 13:41:24.781329
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = 'bmwWlh'
    singleton_1 = Singleton(str_1, var_3, var_4)
    assert singleton_1.__call__() is not None


# Generated at 2022-06-25 13:41:28.032602
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()


# Generated at 2022-06-25 13:41:31.256732
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_2 = ()
    var_3 = {}
    str_0 = 'oGKfO'
    singleton_0 = Singleton(str_0, var_2, var_3)
    var_4 = singleton_0.__call__()


# Generated at 2022-06-25 13:41:33.005424
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        test_case_0()
    except:
        raise Exception('Test Failed')

# Function for testing class Singleton

# Generated at 2022-06-25 13:41:36.975767
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = singleton_0.__call__()
    var_2 = singleton_0.__instance
    var_3 = singleton_1 is var_2
    assert var_3


# Generated at 2022-06-25 13:41:43.817103
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create an instance of class Singleton
    var_3 = ()
    var_4 = {}
    str_1 = 'BtLX9+'
    singleton_1 = Singleton(str_1, var_3, var_4)
    singleton_2 = singleton_1.__call__()
    # Assert that the returned value from __call__ is equal to the
    # instance of class Singleton
    assert singleton_1 is singleton_2


# Generated at 2022-06-25 13:41:44.982465
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print("test_Singleton___call__ is running")


# Generated at 2022-06-25 13:41:46.079834
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert test_case_0() == None

# Generated at 2022-06-25 13:41:48.641477
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import ansible.module_utils.six as six
    if six.PY2:
        test_case_0()

    if six.PY3:
        test_case_0()



# Generated at 2022-06-25 13:41:51.788665
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = 'DJV7U2'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = singleton_1.__call__()


# Generated at 2022-06-25 13:41:58.271391
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:42:01.006082
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = 'BtLX9+'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = singleton_1.__call__()


# Generated at 2022-06-25 13:42:07.931191
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print('Test: __call__')
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    assert var_2 == singleton_0
    assert var_2 == singleton_0.__call__()
    var_1 = ()
    var_2 = {}
    str_1 = '*6H`+'
    singleton_1 = Singleton(str_1, var_1, var_2)
    var_3 = singleton_1.__call__()
    assert var_3 == singleton_1


# Generated at 2022-06-25 13:42:09.230189
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Calling __call__ method of Singleton
    test_case_0()


# Generated at 2022-06-25 13:42:10.464817
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

    # Test case where __instance is not None
    # TODO




# Generated at 2022-06-25 13:42:13.720361
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    var_1 = {'__call__': test_case_0}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:42:17.055138
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'b@'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    var_3 = singleton_0.__call__()
    assert var_2 == var_3 


# Generated at 2022-06-25 13:42:19.314742
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'FjVZJH'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:42:20.778295
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = 'BtLX9+'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = singleton_1.__call__()



# Generated at 2022-06-25 13:42:26.723534
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)

    # line 516
    singleton_0.__instance = singleton_0
    # line 517
    var_2 = singleton_0.__instance
    # line 518
    var_3 = singleton_0.__instance is not None
    # line 519
    if var_3:
        # line 520
        var_2 = singleton_0.__instance
    # line 521
    var_4 = singleton_0.__instance is None
    # line 522
    if var_4:
        # line 523
        singleton_0.__instance = singleton_0
    # line

# Generated at 2022-06-25 13:42:32.482376
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True
    # assert False # TODO: implement your test here


# Generated at 2022-06-25 13:42:35.052426
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()


# Generated at 2022-06-25 13:42:39.468949
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()

# Generated at 2022-06-25 13:42:42.078544
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:42:48.765041
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = 'e<b)t"Y$t'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = ()
    var_6 = {}
    str_2 = 'Pf%c*_E9'
    singleton_2 = Singleton(str_2, var_5, var_6)
    var_7 = ()
    var_8 = {}
    str_3 = ':?R'
    singleton_3 = Singleton(str_3, var_7, var_8)
    var_9 = singleton_3.__call__()
    var_10 = {}
    str_4 = 'c\x1dG'

# Generated at 2022-06-25 13:42:52.322349
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()
    var_2 = {}
    str_1 = 'M`Gz'
    singleton_1 = Singleton(str_1, var_0, var_2)
    singleton_1.__call__()

# Generated at 2022-06-25 13:42:56.866318
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = 'BtLX9+'
    singleton_1 = Singleton(str_1, var_3, var_4)
    str_2 = 'Ve5w1bm'
    singleton_1.__instance = str_2
    var_5 = singleton_1.__call__()
    var_6 = (var_5 == str_2)
    var_6 = (not var_6)

    if (var_6):
        raise Exception('AssertionError')

if (__name__ == '__main__'):
    test_case_0()
    test_Singleton___call__()

# Generated at 2022-06-25 13:42:59.661033
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:43:05.408476
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Dummy0():

        def __init__(self):
            self.x = 0

        def __str__(self):
            return "Dummy object, value of x: %d" % self.x

    var_0 = ()
    var_1 = {}
    str_0 = 'I6m1'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    var_3 = singleton_0.__call__()
    var_4 = singleton_0.__call__()
    var_2.x = 10
    assert var_3.x == var_2.x



# Generated at 2022-06-25 13:43:06.050062
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert callable(Singleton.__call__)

# Generated at 2022-06-25 13:43:13.531363
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:43:17.494485
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = '7XD,0/'
    singleton_1 = Singleton(str_1, var_3, var_4)
    singleton_2 = singleton_1.__call__()
    singleton_3 = singleton_1.__call__()
    assert singleton_2 is singleton_3


# Generated at 2022-06-25 13:43:20.823018
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'kLsN'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()

# Generated at 2022-06-25 13:43:24.913855
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # simple test
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()

    assert 1 is 1


# Generated at 2022-06-25 13:43:29.103918
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = 'EzN'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = singleton_1.__call__()
    var_6 = singleton_1.__call__()
    var_7 = var_5 == var_6

# Generated at 2022-06-25 13:43:32.501643
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()



# Generated at 2022-06-25 13:43:35.263382
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = 'v_8V*'
    singleton_1 = Singleton(str_1, var_3, var_4)
    assert not (singleton_1.__call__() is None)

# Generated at 2022-06-25 13:43:36.635211
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        test_case_0()
    except Exception:
        assert False



# Generated at 2022-06-25 13:43:42.728368
# Unit test for method __call__ of class Singleton

# Generated at 2022-06-25 13:43:46.339210
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    assert singleton_0.__instance == var_2


# Generated at 2022-06-25 13:43:53.081926
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = '0vkV7Fm8'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:43:55.710530
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # var_0 = ()
    # var_1 = {}
    # str_0 = 'BtLX9+'
    # singleton_0 = Singleton(str_0, var_0, var_1)
    # var_2 = singleton_0.__call__()
    pass



# Generated at 2022-06-25 13:43:56.275150
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True


# Generated at 2022-06-25 13:44:00.408954
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'hJ47L'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
    var_3 = ()
    var_4 = {'B' : var_2}
    str_1 = 'lP'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = singleton_1.__call__()
    var_6 = {'B' : var_2}



# Generated at 2022-06-25 13:44:05.233520
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Assign variables
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    # Try to call method __call__
    try:
        var_2 = singleton_0.__call__()
    except Exception as e:
        print('Failure in __call__: ', type(e), ': ', e)
        return
    else:
        print('No exception in __call__')
        return

if __name__ == '__main__':
    test_case_0()
    test_Singleton___call__()

# Generated at 2022-06-25 13:44:07.587340
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global var_2
    var_0 = ()
    var_1 = {}
    str_0 = 'BtLX9+'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()


# Generated at 2022-06-25 13:44:08.716430
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert func_0() == 'J'
    assert func_1() == 'J'
    assert func_0() == func_1()


# Generated at 2022-06-25 13:44:10.747160
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_3 = ()
    var_4 = {}
    str_1 = 'BtLX9+'
    singleton_1 = Singleton(str_1, var_3, var_4)
    var_5 = singleton_1.__call__()


# Generated at 2022-06-25 13:44:13.481316
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    str_0 = 'ZRf+*'
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0.__call__()
