

# Generated at 2022-06-25 13:34:19.980463
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton
    test_case_0()

# Generated at 2022-06-25 13:34:26.143270
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    int_0 = 73
    float_0 = -516.58
    list_0 = [int_0, int_0]
    list_1 = [float_0, float_0]
    singleton_0 = Singleton(float_0, list_0, list_1, list_0)
    assert singleton_0.__instance is None
    singleton_0(1.0, 3, 2.0)


# Generated at 2022-06-25 13:34:28.432153
# Unit test for constructor of class Singleton
def test_Singleton():
    float_0 = -166.195
    list_0 = []
    singleton_0 = Singleton(float_0, list_0, list_0, list_0)


# Generated at 2022-06-25 13:34:30.170512
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    float_0 = -166.195
    list_0 = []
    singleton_0 = Singleton(float_0, list_0, list_0, list_0)



# Generated at 2022-06-25 13:34:32.146633
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    list_0 = []
    singleton_0 = Singleton(list_0, list_0, list_0, list_0)



# Generated at 2022-06-25 13:34:32.855692
# Unit test for constructor of class Singleton
def test_Singleton():
    test_case_0()

# Generated at 2022-06-25 13:34:33.787202
# Unit test for constructor of class Singleton
def test_Singleton():
    test_case_0()

# Generated at 2022-06-25 13:34:34.769713
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True
    # assert False


# Generated at 2022-06-25 13:34:38.896638
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    float_0 = -166.195
    list_0 = []
    singleton_0 = Singleton(float_0, list_0, list_0, list_0)


# Generated at 2022-06-25 13:34:42.918117
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    string_0 = symbol()
    list_0 = []
    singleton_0 = Singleton(string_0, list_0, list_0, list_0)
    singleton_0.__call__()


# Generated at 2022-06-25 13:34:47.836901
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    assert Foo() is Foo()

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:34:52.478862
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        def __init__(self):
            self.name = 'A'

    a1 = A()
    a2 = A()
    assert a1 is a2
    a1.name = 'B'
    assert a2.name == 'B'
    assert a1 is a2


# Generated at 2022-06-25 13:34:57.618885
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class DummyClass(object):
        __metaclass__ = Singleton
        def __init__(self, name=None):
            self.name = name

    assert DummyClass() is DummyClass()
    assert DummyClass('a') == DummyClass('a')
    assert DummyClass('a') is DummyClass('a')
    assert DummyClass('a') == DummyClass('b')
    assert DummyClass('a') is not DummyClass('b')

# Generated at 2022-06-25 13:35:00.097710
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:35:03.477333
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()

    # The instance of class Foo will be the same
    assert foo1 is foo2



# Generated at 2022-06-25 13:35:12.501452
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global __instance
    __instance = None

    def my_mock(self, *args, **kw):
        global __instance
        self.x = 1
        __instance = self

    def test_obj_creation():
        return Singleton('test', (), {'__init__': my_mock})

    # Test that the class is created and that __init__ is called
    obj1 = test_obj_creation()
    assert issubclass(obj1, Singleton)
    assert obj1 == test_obj_creation()
    assert obj1.x == 1

    # Test that first instance is created and __init__ is called only once.
    obj2 = obj1()
    assert obj2.x == 1
    obj3 = obj1()
    assert obj3.x == 1
    obj1.__instance = None
    obj4

# Generated at 2022-06-25 13:35:15.182465
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a1 = Test()
    a2 = Test()

    print(id(a1), id(a2))


# Generated at 2022-06-25 13:35:16.582837
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-25 13:35:19.338968
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = A(1)
    b = A(2)

    assert a is b
    assert a.x == 1

# Generated at 2022-06-25 13:35:21.356803
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    assert SingletonTest() is SingletonTest() is SingletonTest()


# Generated at 2022-06-25 13:35:27.431082
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import pytest

    class Test(object):
        __metaclass__ = Singleton
        pass

    assert id(Test()) == id(Test())



# Generated at 2022-06-25 13:35:29.234107
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object, metaclass=Singleton):
        pass

    s1 = SingletonTest()
    s2 = SingletonTest()
    assert(s1 is s2)

# Generated at 2022-06-25 13:35:31.657262
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 0

    print(isinstance(TestSingleton(), TestSingleton))


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:35:40.716976
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from time import time
    from random import random

    class Foo(object):
        __metaclass__ = Singleton

    assert Foo() is Foo()
    foo = Foo()

    # Make sure instance is the same over multiple threads.
    from threading import Thread
    length = 100
    threads = []
    for i in range(length):
        t = Thread(target=lambda: Foo() is foo)
        threads.append(t)
        t.start()

    for i in range(length):
        threads[i].join()

    # Make sure two classes of the same name are not equal (they are
    # return separate instances).
    class Foo(object):
        __metaclass__ = Singleton
    foo2 = Foo()
    assert foo.__class__ is foo2.__class__

# Generated at 2022-06-25 13:35:45.808150
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.username = 'admin'
            self.password = 'password'

    a1 = A()
    a2 = A()
    print(a1)
    print(a2)

    a1.username = 'admin1'
    print(a2.username)


test_Singleton()

# Generated at 2022-06-25 13:35:50.347452
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest
    class TestSingleton(object):
        __metaclass__ = Singleton
        pass
    class TestCase(unittest.TestCase):
        def test_instance_is_singleton(self):
            instance_1 = TestSingleton()
            instance_2 = TestSingleton()
            self.assertTrue(instance_1 is instance_2)
    unittest.main()

# Generated at 2022-06-25 13:35:53.056804
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a1 = A()
    a2 = A()

    assert a1 == a2


# Generated at 2022-06-25 13:35:55.158714
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a = A(1)
    b = A(2)
    assert a is b
    assert a.value == b.value

# Generated at 2022-06-25 13:35:58.416798
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2



# Generated at 2022-06-25 13:36:07.801402
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        """Test class that implements Singleton functionality
        """
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 0

    # Create two instances of TestClass
    test_class_1 = TestClass()
    test_class_2 = TestClass()

    # test_class_1 and test_class_2 should refer to the same instance
    # of TestClass
    assert test_class_1 == test_class_2

    # test_class_1 and test_class_2 are the same instance of TestClass
    # as test_class_1 and test_class_2 are the same objects
    assert test_class_1 is test_class_2

    # test_class_2 refers to the same instance of TestClass as
    # test_class_1.  Thus

# Generated at 2022-06-25 13:36:23.645184
# Unit test for constructor of class Singleton
def test_Singleton():
    '''test whether singleton works or not'''

    class test_singleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            print("initiated")

    print("test for singleton")

    test_singleton1 = test_singleton()
    test_singleton2 = test_singleton()

    print(test_singleton1)
    print(test_singleton2)

    if(test_singleton1 is test_singleton2):
        print("singleton works")
    else:
        print("singleton fails")

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:36:26.362204
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        pass

    obj1 = TestSingleton()
    obj2 = TestSingleton()
    assert obj1 is obj2

    obj1.value = 1
    assert obj1.value == obj2.value

# Generated at 2022-06-25 13:36:30.496360
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        def __init__(self):
            self.data = 42

    f1 = Foo()
    f2 = Foo()

    assert f1 is f2
    assert f1.data == 42
    assert f2.data == 42
    f2.data = 24
    assert f1.data == 24
    assert f2.data == 24


# Generated at 2022-06-25 13:36:33.776701
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Stub of class SingletonDemo
    class SingletonDemo():
        __metaclass__ = Singleton
    # Call method __call__ of class Singleton
    result = SingletonDemo()
    assert(isinstance(result, SingletonDemo))


# Generated at 2022-06-25 13:36:35.600960
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    assert Foo() is Foo()
    assert Foo() is Foo()

# Generated at 2022-06-25 13:36:39.248819
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    assert isinstance(SingletonTest(), SingletonTest)

    assert SingletonTest() is not None

# Generated at 2022-06-25 13:36:43.465085
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTester(metaclass=Singleton):
        def __init__(self):
            self.a = 1
            self.b = 2

    s = SingletonTester()

    assert hasattr(s, 'a')
    assert s.a == 1
    assert hasattr(s, 'b')
    assert s.b == 2

# Generated at 2022-06-25 13:36:52.621579
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    '''
    Unit test for method __call__ of class Singleton
    '''
    from unittest import TestCase
    from collections import namedtuple

    # NamedTuple Class
    class City(namedtuple('City', 'name population')):
        def __str__(self):
            return "%s, pop: %d" % (self.name.title(), self.population)

    # Singleton class
    class CityInfo(object):
        __metaclass__ = Singleton
        City = City
        # Constructor
        def __init__(self):
            self.__cities = [self.City("Paris", 2.2),
                             self.City("Rome", 2.6),
                             self.City("Milan", 1.3)]
        # __getitem__: access element of array

# Generated at 2022-06-25 13:37:00.462581
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.counter = 0

    a = MyClass()
    b = MyClass()

    assert a is b
    a.counter += 1
    assert a.counter == 1
    assert b.counter == 1
    a.counter = 10
    assert a.counter == 10
    assert b.counter == 10
    b.counter = 100
    assert a.counter == 100
    assert b.counter == 100

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:37:06.659656
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(4)
    a2 = A(5)
    assert a1 is a2, "a1 is not a2"
    assert a1.x == 5, "a1.x is not 5"
    assert a2.x == 5, "a2.x is not 5"


# Generated at 2022-06-25 13:37:30.605059
# Unit test for constructor of class Singleton
def test_Singleton():
    class IAmASingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self._value = False

        def set_value(self, value):
            self._value = value

        def get_value(self):
            return self._value

    singleton1 = IAmASingleton()
    singleton2 = IAmASingleton()

    assert(singleton1 is singleton2)
    assert(singleton1._value is False)
    assert(singleton2._value is False)

    singleton1.set_value(True)
    assert(singleton1._value is True)
    assert(singleton2._value is True)

    singleton2.set_value(False)
    assert(singleton1._value is False)

# Generated at 2022-06-25 13:37:33.657136
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        def __init__(self, param=42):
            self.param = param

    x = Test()
    assert x.param == 42

    try:
        y = Test(43)
    except TypeError:
        assert x.param == 42



# Generated at 2022-06-25 13:37:36.921133
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass
    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)
    a1.foo = 1
    assert a2.foo == 1

# Dummy class for testing purpose

# Generated at 2022-06-25 13:37:45.078204
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A:
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 0

    a1 = A()
    a2 = A()

    assert a1 is a2

    a1.a = 1
    assert a1.a == a2.a

    class B(A):
        def __init__(self):
            super(B, self).__init__()
            self.b = 0

    b1 = B()
    b2 = B()

    assert b1 is b2

    b1.b = 1
    assert b1.b == b2.b

    assert not b1 is a1


# Generated at 2022-06-25 13:37:47.077869
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo = Foo()

    assert Foo() is foo
    assert Foo() is not Foo()

# Generated at 2022-06-25 13:37:51.920282
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class SingletonCallTest(unittest.TestCase):
        def test___call__(self):
            a = SingletonTest()
            b = SingletonTest()
            self.assertEqual(id(a), id(b))

    unittest.main(verbosity=2)

# Generated at 2022-06-25 13:37:54.186213
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()
    assert TestClass() is TestClass()


# Generated at 2022-06-25 13:37:58.854642
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self):
            self.bar = 'not set'

    foo1 = Foo()
    foo2 = Foo()
    assert(foo1.bar == 'not set')
    assert(foo2.bar == 'not set')
    foo1.bar = 'set'
    assert(foo1.bar == 'set')
    assert(foo2.bar == 'set')

    assert(foo1 is foo2)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:38:08.712983
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kw):
            self.__init_args = args
            self.__init_kw = kw

        @property
        def init_args(self):
            return self.__init_args

        @property
        def init_kw(self):
            return self.__init_kw

    assert(isinstance(SingletonTest, Singleton))

    # Singleton should never be instantiated with class.
    try:
        result = SingletonTest()
        assert(False)
    except TypeError:
        pass

    # Create first instance
    instance1 = SingletonTest('foo', bar='baz')
    assert(isinstance(instance1, SingletonTest))

# Generated at 2022-06-25 13:38:10.916844
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    assert(TestClass(10).x == 10)
    assert(TestClass(10).x == TestClass(20).x)
    assert(TestClass(10).x == TestClass(10).x)

# Generated at 2022-06-25 13:38:53.386451
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 0
            self.b = 0
    a1 = A()
    a2 = A()
    assert(a1 is a2)
    # Check if object has been properly initialized
    assert(a1.a == 0)
    assert(a1.b == 0)
    # Check if (re)initialization fails
    a2.a = 1
    a2.b = 1
    assert(a2.a == 1)
    assert(a2.b == 1)
    assert(a1.a == 1)
    assert(a1.b == 1)

# Generated at 2022-06-25 13:38:56.203629
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

    test1 = Test('test1')
    assert test1.x == 'test1'
    test2 = Test('test2')
    assert test2.x == 'test1'
    assert test1 is test2

# Generated at 2022-06-25 13:38:58.677230
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    instance1 = TestSingleton()
    instance2 = TestSingleton()

    print ("instance1 = ", instance1)
    print ("instance2 = ", instance2)

    assert id(instance1) == id(instance2) 
    assert instance1 == instance2


# Generated at 2022-06-25 13:39:03.505042
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Class Foo
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'foo'

    foo1 = Foo()
    assert foo1.name == 'foo'

    foo2 = Foo()
    assert foo2.name == 'foo'

    assert foo1 == foo2



# Generated at 2022-06-25 13:39:06.209005
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass:
        __metaclass__ = Singleton
    m1 = MyClass()
    m2 = MyClass()
    assert m1 == m2


# Generated at 2022-06-25 13:39:09.126785
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 42

    a = A()
    b = A()
    assert(a is b)

# Generated at 2022-06-25 13:39:17.727330
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton():
        __metaclass__ = Singleton
        def __init__(self, a, b=2):
            self.a = a
            self.b = b

    test_instance = TestSingleton(1)
    assert test_instance.a == 1
    assert test_instance.b == 2

    test_instance = TestSingleton(2)
    assert test_instance.a == 1
    assert test_instance.b == 2

    test_instance = TestSingleton(2, 3)
    assert test_instance.a == 1
    assert test_instance.b == 2



from re import compile
from threading import RLock

from ansible.module_utils._text import to_bytes
from ansible.module_utils.six.moves.urllib.parse import urlparse

# Generated at 2022-06-25 13:39:19.634085
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()

    assert f1 is f2


# Generated at 2022-06-25 13:39:25.892474
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self,v):
            self.v = v

    class B(object):
        __metaclass__ = Singleton
        def __init__(self,v):
            self.v = v
            self.v = v

    a=A(5)
    b=B(5)
    assert id(a) == id(A(5))
    assert id(a) != id(B(5))

# Generated at 2022-06-25 13:39:28.356144
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    obj1 = SingletonTest()
    obj2 = SingletonTest()
    assert id(obj1) == id(obj2)


# Generated at 2022-06-25 13:40:49.115977
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class cls_1(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 0

    class cls_2(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    c1 = cls_1()
    c2 = cls_2()
    c3 = cls_1()
    assert c1 is c3
    assert c1.x == c3.x
    assert c1 is not c2
    assert c1.x != c2.x
    c1.x = 2
    assert c1.x == c3.x
    assert c1.x != c2.x



# Generated at 2022-06-25 13:40:52.923333
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 1

    a1 = A()
    a2 = A()

    assert(id(a1) == id(a2))

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:40:53.957366
# Unit test for constructor of class Singleton
def test_Singleton():
    class Myclass(metaclass=Singleton):
        pass

    a = Myclass()
    b = Myclass()

    assert a is b

# Generated at 2022-06-25 13:40:56.599591
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonExample:
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    a = SingletonExample(1)
    b = SingletonExample(2)

    assert a.val == 1
    assert b.val == 1
    assert a is b


# Generated at 2022-06-25 13:41:04.224360
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class A(object):
        __metaclass__ = Singleton

    class B(A):
        pass

    a = A()  # A is a Singleton, the second time it is invoked, the same instance is returned
    b = B()  # B is a class that inherits from A, the first time it is invoked, a new instance is created

    assert(id(a) == id(A()))
    assert(id(b) == id(B()))
    assert(id(a) != id(b))

# Generated at 2022-06-25 13:41:06.913955
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class DummyClass(object):
        __metaclass__ = Singleton

    dummy_obj1 = DummyClass()
    dummy_obj2 = DummyClass()
    assert dummy_obj1 == dummy_obj2

# Generated at 2022-06-25 13:41:09.722383
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    assert Test() is Test()

# Generated at 2022-06-25 13:41:16.574678
# Unit test for constructor of class Singleton
def test_Singleton():
    class ClassA(metaclass=Singleton):
        def __init__(self, val=None):
            self.val = val
    obj1 = ClassA()
    obj2 = ClassA()
    assert obj1 is obj2
    obj1.val = 1
    assert obj1.val == obj2.val
    obj3 = ClassA(1)
    assert obj1 is obj3
    assert obj2 is obj3
    obj4 = ClassA(2)
    assert obj1 is obj4
    assert obj3 is obj4
    assert obj1.val == obj3.val
    assert obj3.val == obj4.val
    obj5 = ClassA()
    assert obj1 is obj5
    assert obj4 is obj5
    assert obj5.val is None
    obj6 = ClassA(1)
    assert obj

# Generated at 2022-06-25 13:41:24.066521
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # init
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    # start testing
    foo1 = Foo()
    assert foo1.value == 0
    foo2 = Foo()
    assert foo2.value == 0
    foo1.increment()
    assert foo1.value == 1
    assert foo2.value == 1
    foo2.increment()
    assert foo1.value == 2
    assert foo2.value == 2
    assert foo1 is foo2

# Generated at 2022-06-25 13:41:28.181954
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class A(object):
        __metaclass__ = Singleton

    class B(A):
        pass

    a1 = A()
    a2 = A()
    assert a1 is a2

    b1 = B()
    b2 = B()
    assert b1 is b2

    assert a1 is not b1
    assert a2 is not b2
