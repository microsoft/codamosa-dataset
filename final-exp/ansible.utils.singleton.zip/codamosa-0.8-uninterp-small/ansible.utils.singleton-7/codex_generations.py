

# Generated at 2022-06-25 13:34:15.796190
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_0 = Singleton()
    assert singleton_0.__instance == None

# Generated at 2022-06-25 13:34:17.377435
# Unit test for constructor of class Singleton
def test_Singleton():
    # Constructor test
    instance = Singleton()
    assert instance is not None


# Generated at 2022-06-25 13:34:20.391510
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    int_0 = None
    str_0 = None
    bool_0 = False
    singleton_0 = Singleton(int_0, str_0, bool_0, int_0)


# Generated at 2022-06-25 13:34:25.458855
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create a new instance of class Singleton
    s = Singleton()

    # Ensure the class is a Singleton, and keeps a reference to
    # all instances.
    assert s is Singleton()
    assert Singleton().getInstances() == 1
    assert Singleton().getInstances() == 2
    assert Singleton().getInstances() == 3

# Generated at 2022-06-25 13:34:28.064578
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    int_0 = None
    str_0 = None
    bool_0 = True
    object_0 = Singleton(int_0, str_0, bool_0, int_0)
    # Make sure the object returns the same object on subsequent calls.
    assert id(object_0) == id(object_0())


# Generated at 2022-06-25 13:34:29.157688
# Unit test for constructor of class Singleton
def test_Singleton():
    test_instance_0 = Singleton()
    test_instance_0.test_Singleton()


# Generated at 2022-06-25 13:34:34.868545
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # unit test for method __call__ of class Singleton
    # Test 1
    int_0 = None
    str_0 = None
    bool_0 = False
    singleton_0 = Singleton(int_0, str_0, bool_0, int_0)
    # Test 2
    str_1 = None
    bool_1 = None
    int_1 = None
    singleton_1 = Singleton(str_1, bool_1, int_1, int_1)


# Generated at 2022-06-25 13:34:40.095235
# Unit test for constructor of class Singleton
def test_Singleton():
    int_0 = None
    str_0 = None
    bool_0 = False
    singleton_0 = Singleton(int_0, str_0, bool_0, int_0)
    raise TypeError


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 13:34:43.690377
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_0 = Singleton()
    assert isinstance(singleton_0, Singleton)
    assert isinstance(singleton_0, type)
    assert singleton_0 == Singleton


# Generated at 2022-06-25 13:34:44.274657
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-25 13:34:50.029465
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        def __init__(self):
            pass
    t1 = Test()
    t2 = Test()
    assert t1 is t2, "t1 and t2 should be the same object"


# Generated at 2022-06-25 13:34:52.771128
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object, metaclass=Singleton):
        pass

    foo = Foo()
    assert foo is Foo()



# Generated at 2022-06-25 13:34:58.060083
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 0

    t = TestSingleton()
    assert t.val == 0

    t.val = 1

    t2 = TestSingleton()
    assert t2.val == 1

    t2.val = 2
    assert t.val == 2

    t3 = TestSingleton()
    assert t3.val == 2
    assert t3 is t2

    assert t is t2

# Generated at 2022-06-25 13:35:02.236597
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.__x = x

        def get_x(self):
            return self.__x

    a = A(1)
    b = A(2)
    assert id(a) == id(b)
    assert a.get_x() == 1



# Generated at 2022-06-25 13:35:05.893192
# Unit test for constructor of class Singleton
def test_Singleton():
    import pytest

    class SingletonTestClass(object):
        __metaclass__ = Singleton

    assert len(dir(SingletonTestClass)) == 0
    a = SingletonTestClass()
    b = SingletonTestClass()
    assert a == b
    assert a is not None

# Generated at 2022-06-25 13:35:08.922153
# Unit test for constructor of class Singleton
def test_Singleton():
    # define a test class using the Singleton metaclass
    class Test(object):
        __metaclass__ = Singleton

    # make sure the instance exists
    assert Test()



# Generated at 2022-06-25 13:35:13.431089
# Unit test for constructor of class Singleton
def test_Singleton():
    @add_metaclass(Singleton)
    class A(object):
        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    a3 = A(3)
    assert a1.x == 1
    assert a2.x == 1
    assert a3.x == 1



# Generated at 2022-06-25 13:35:20.074030
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kw):
            pass

    class OtherClass(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kw):
            pass

    m = MyClass()
    assert isinstance(m, MyClass)
    assert m == MyClass()

    m2 = OtherClass('foo', bar='baz')
    assert isinstance(m2, OtherClass)
    assert m2 == OtherClass('foo', bar='baz')
    assert m != m2


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:35:22.777514
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonUser(object):
        __metaclass__ = Singleton

    assert isinstance(SingletonUser(), SingletonUser)
    assert SingletonUser() is SingletonUser()
    assert not SingletonUser() is not SingletonUser()



# Generated at 2022-06-25 13:35:30.248450
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.__dict__.update(*args, **kwargs)

    a1 = A(x=1)
    a2 = A(x=2)
    assert a1 is a2
    assert a1 == a2
    assert a1.x == 1
    assert a2.x == 1

    # This class cannot be a singleton because it is not derived from object
    # so its __metaclass__ will not be Singleton.
    class B:
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.__dict__.update(*args, **kwargs)

    b1 = B(x=1)
    b2

# Generated at 2022-06-25 13:35:41.177500
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # test class definition
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'A'

    a1 = A()
    a2 = A()
    assert a1 == a2, 'Singleton class failed to create single instance'

    # test class definition execution
    A = Singleton('A', (object,), {
        '__init__': lambda self: setattr(self, 'name', 'A')
    })
    a1 = A()
    a2 = A()
    assert a1 == a2, 'Singleton class failed to create single instance'


# Generated at 2022-06-25 13:35:46.301659
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    # A and B are two instances of class TestSingleton
    a = TestSingleton()
    b = TestSingleton()

    # Check if A and B are the same object
    assert id(a) == id(b)
    print("TestSingleton unit test passed")


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:35:47.952337
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTestClass(object):
        __metaclass__ = Singleton

    obj1 = SingletonTestClass()
    obj2 = SingletonTestClass()

    assert obj1 is obj2, "Same object is not returned"


# Generated at 2022-06-25 13:35:52.563387
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton


# Generated at 2022-06-25 13:35:56.514161
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            pass

    class B(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            pass

    a1 = A()
    a2 = A()
    assert a1 is a2

    b1 = B()
    b2 = B()
    assert b1 is b2

    assert a1 is not b1
    assert a2 is not b2



# Generated at 2022-06-25 13:36:00.045655
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass

    a1 = A()
    a2 = A()

    assert a1 is a2

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:36:05.565010
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, a, b, c=3):
            self.a = a
            self.b = b
            self.c = c

    a1 = A(1, 2, 3)
    a2 = A(4, 5, 6)

    assert a1 is a2, "A(1, 2, 3) should return A(4, 5, 6)"


# Generated at 2022-06-25 13:36:12.476914
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 100

    t1 = TestSingleton()
    t2 = TestSingleton()
    print(t1.a, t2.a)
    t1.a = 300
    print(t1.a, t2.a)
    t2.a = 500
    print(t1.a, t2.a)
    print(t1)
    print(t2)


# Generated at 2022-06-25 13:36:17.629768
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            print('TestSingleton: ', self)

    instance1 = TestSingleton()
    instance2 = TestSingleton()
    assert(instance1 == instance2)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:36:26.404203
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    import sys

    class MySingleton(metaclass=Singleton):
        pass

    assert MySingleton() is MySingleton()

    # But a different class does not effect the singleton
    class MySingleton1(metaclass=Singleton):
        pass

    assert MySingleton1() is not MySingleton()

    # Singleton is valid across class and subclasses
    class MySingleton2(MySingleton, metaclass=Singleton):
        pass

    assert MySingleton2() is MySingleton()

    # Singleton is valid across different subclasses
    class MySingleton3(MySingleton, metaclass=Singleton):
        pass

    assert MySingleton3() is MySingleton()

    # Singleton is valid across different subclasses of another class

# Generated at 2022-06-25 13:36:38.882376
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    s1 = TestSingleton('first')
    s2 = TestSingleton('second')

    assert s1.name == 'first'
    assert s1 is s2


# Generated at 2022-06-25 13:36:43.418825
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    print('SingletonTest:')
    print('Constructing...')
    x = SingletonTest()
    y = SingletonTest()
    print('Constructed.')
    assert x is y
    print('x is y')


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:36:49.320312
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.mem = 0

        def __str__(self):
            return "MyClass:mem = " + str(self.mem)

    instance = MyClass()
    print("instance1 = " + str(instance))
    instance.mem += 1
    print("instance2 = " + str(instance))


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:36:52.152231
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  global s
  s = Singleton("Singleton")
  instances_count = len(s.__instance)
  s.__call__()

  assert instances_count + 1 == len(s.__instance)
  assert s.__call__() == s

# Generated at 2022-06-25 13:36:55.736504
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object, metaclass=Singleton):
        def __init__(self, value):
            self.value = value

    first_instance = SingletonTest("Hello world!")

    second_instance = SingletonTest("Goodbye cruel world!")

    assert first_instance == second_instance
    assert first_instance.value == second_instance.value



# Generated at 2022-06-25 13:37:00.426073
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # args = [int]
    a = SingletonTest(1)
    b = SingletonTest(2)
    assert a == b

    # args = [str, bool]
    a = SingletonTest("Test", False)
    b = SingletonTest("Test", True)
    assert a == b



# Generated at 2022-06-25 13:37:04.079711
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)


# Generated at 2022-06-25 13:37:07.947212
# Unit test for constructor of class Singleton
def test_Singleton():
    # pylint: disable=unused-variable
    class Object(object):
        __metaclass__ = Singleton

    obj1 = Object()
    obj2 = Object()
    assert obj1 == obj2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:37:10.300311
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert a is b



# Generated at 2022-06-25 13:37:14.789337
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a=0):
            self.a = a

    assert(id(A()) == id(A()))
    assert(id(A(4)) == id(A(4)))
    assert(A(4).a == 4)
    assert(id(A(4)) == id(A(5)))

# Generated at 2022-06-25 13:37:35.216813
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import time

    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.time = time.time()

    a = MyClass()
    b = MyClass()
    print(a.time)
    print(b.time)
    print(a is b)
    print(a.time == b.time)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:37:40.336187
# Unit test for constructor of class Singleton
def test_Singleton():
    '''
    Test our Singleton implementation
    :return:
    '''

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, foo=False):
            self.foo = foo

    t1 = TestSingleton("bar")
    t2 = TestSingleton("bar")
    assert(t1 is t2)

    t3 = TestSingleton(True)
    assert(t1 is t3)

# Generated at 2022-06-25 13:37:45.385153
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name

    assert TestSingleton('A').name == 'A'
    assert TestSingleton('B').name == 'A'


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:37:49.045470
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('init')
    A = Test()
    B = Test()
    assert id(A) == id(B)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:37:52.795746
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 10

    t = Test()
    assert t.x == 10

    t1 = Test()
    t1.x = 20

    # only one instance of Test is available
    assert t1.x == 20
    assert t.x == 20
    assert t is t1


# Generated at 2022-06-25 13:37:57.286906
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTester(metaclass=Singleton):
        def __init__(self):
            self.value = 1

        def increment(self):
            self.value += 1

    s1 = SingletonTester()
    s2 = SingletonTester()
    assert s1 is s2
    assert s1.value == 1
    s1.increment()
    assert s1.value == 2

# Generated at 2022-06-25 13:37:59.690932
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(metaclass=Singleton):
        def __init__(self, value):
            self.value = value
    f = Foo(42)
    assert f.value == 42

# Generated at 2022-06-25 13:38:05.064500
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 0

        def incc(self):
            self.i += 1

    a = A()
    a.incc()

    b = A()
    b.incc()

    assert id(a) == id(b) and a.i == 2 and b.i == 2



# Generated at 2022-06-25 13:38:07.075289
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(with_metaclass(Singleton)):
        pass

    aa = A()
    assert aa is A()



# Generated at 2022-06-25 13:38:09.049924
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    obj = TestSingleton()
    assert obj is TestSingleton()



# Generated at 2022-06-25 13:38:46.373938
# Unit test for constructor of class Singleton
def test_Singleton():
    cnt = 0

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            global cnt
            cnt += 1

    assert cnt == 0
    s = SingletonTest()
    assert cnt == 1
    s1 = SingletonTest()
    assert cnt == 1

# Generated at 2022-06-25 13:38:49.302109
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton.__instance is None
    assert Singleton.__rlock is not None

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:38:54.610094
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value
    # Creating object with value 1
    a = TestSingleton(1)
    # Creating object with value 2
    b = TestSingleton(2)
    # Comparing the values of both objects
    assert a.value == b.value
    # Comparing the objects if they are one and the same
    assert id(a) == id(b)

# Generated at 2022-06-25 13:39:01.261682
# Unit test for constructor of class Singleton
def test_Singleton():
    class Thing(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    class OtherThing(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    thing1 = Thing(1)
    thing2 = Thing(2)
    otherthing = OtherThing(1)

    assert(thing1 is thing2)
    assert(thing1.val == 1)
    assert(otherthing.val == 1)
    assert(otherthing is not thing1)

# Generated at 2022-06-25 13:39:07.305239
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import random

    class TestingSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.field = 0

    # Create singleton
    a = TestingSingleton()

    # Check that we have singleton
    assert(TestingSingleton() is a)
    assert(TestingSingleton() is a)

    a.field = random.randint(0, 99)
    assert(a.field == TestingSingleton().field)


# Generated at 2022-06-25 13:39:16.039299
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            print("%s __init__ called" % name)
            self._name = name
            self._age = 0
            self._friends = []

        def greet(self):
            print("Hi, I am %s" % self._name)

        def add_friend(self, friend):
            self._friends.append(friend)

        def show_friends(self):
            print("My count of friends: %d" % len(self._friends))

    print("Return singleton")
    s1 = TestSingleton("John")
    assert s1._name == "John"
    s1.greet()
    s1.add_friend("Jack")

    s2 = TestSingleton("Jack")

# Generated at 2022-06-25 13:39:18.190875
# Unit test for constructor of class Singleton
def test_Singleton():
    def my_singleton_factory():
        return type('MySingleton', (object,), {'__metaclass__': Singleton})

    assert my_singleton_factory() is my_singleton_factory()


# Generated at 2022-06-25 13:39:21.244942
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg=None):
            pass

    t1 = TestSingleton(arg=1)
    t2 = TestSingleton()
    t3 = TestSingleton()
    assert t1 is t2 and t2 is t3

# Generated at 2022-06-25 13:39:25.783535
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self, x:int):
            self.x = x
    a = Test(0)
    b = Test(1)
    assert a == b
    assert a.x == b.x

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:39:29.205882
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton() == Singleton()
    assert Singleton(1) != Singleton(2)
    assert Singleton().call_me() == 'method'
    assert Singleton(1).call_me() == 'method'


# Generated at 2022-06-25 13:40:41.891453
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class test():
        __metaclass__ = Singleton

    # run several times and expect the same instance
    test1 = test()
    test2 = test()
    assert id(test1) == id(test2)


# Generated at 2022-06-25 13:40:45.391896
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    singleton_obj_1 = SingletonTest()
    singleton_obj_2 = SingletonTest()

    assert(singleton_obj_1 is singleton_obj_2)

# Generated at 2022-06-25 13:40:48.175991
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-25 13:40:53.624576
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg
    class B(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    a1 = A(1)
    assert id(a1) == id(A(1))

    b1 = B(1)
    assert id(b1) == id(B(1))
    assert id(a1) != id(b1)

# Generated at 2022-06-25 13:40:56.333006
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Single(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    s1 = Single(5)
    s2 = Single(10)

    assert s1.val == s2.val

    s1.val = -1
    assert s1.val == s2.val

# Generated at 2022-06-25 13:41:04.622328
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        print(TestSingleton)

        def __init__(self, test_value):
            self.test_value = test_value

    test_singleton = TestSingleton(10)
    print(id(test_singleton))
    second_test_singleton = TestSingleton(20)
    print(id(second_test_singleton))
    print(test_singleton.test_value)
    print(second_test_singleton.test_value)


# Generated at 2022-06-25 13:41:09.574907
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TheTestClass(object):
        __metaclass__ = Singleton
        counter = 0
        def __init__(self):
            type(self).counter += 1

    TheTestClass.__instance = None
    TheTestClass()
    TheTestClass()
    TheTestClass()
    assert TheTestClass.counter == 1

# Generated at 2022-06-25 13:41:12.346644
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    foo_instance_1 = Foo()
    foo_instance_2 = Foo()
    assert foo_instance_1 == foo_instance_2

# Generated at 2022-06-25 13:41:16.314739
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            print("Test.__init__({})".format(value))
            self.value = value

    value = 1
    assert Test.__instance is None
    test = Test(value)
    assert Test.__instance is not None
    assert test == Test.__instance
    assert test.value == value


# Generated at 2022-06-25 13:41:20.424114
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.b = 2

    a = A()
    print(a.b)
    a.b = 5
    a2 = A()
    print(a2.b)  # will print 5

if __name__ == '__main__':
    test_Singleton___call__()