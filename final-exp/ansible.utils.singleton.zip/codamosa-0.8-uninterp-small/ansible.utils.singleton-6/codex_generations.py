

# Generated at 2022-06-25 13:34:19.265310
# Unit test for constructor of class Singleton
def test_Singleton():
    bool_0 = True
    int_0 = -698
    list_0 = [int_0]
    singleton_0 = Singleton(bool_0, int_0, list_0, list_0)


# Generated at 2022-06-25 13:34:21.632516
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create instance of with default argument values
    # Call method
    # Check for value
    assert Singleton.__call__()



# Generated at 2022-06-25 13:34:24.095772
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    obj_0 = Singleton()
    assert Singleton.__instance is None

test_case_0()
test_Singleton___call__()

# Generated at 2022-06-25 13:34:27.239338
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create instance of Singleton class
    singleton_0 = Singleton()

    # Call method __call__ of singleton_0
    # (No parameters passed)
    singleton_0.__call__()


# Generated at 2022-06-25 13:34:29.930796
# Unit test for constructor of class Singleton
def test_Singleton():
    # Set up variables for the test
    bool_0 = True
    int_0 = -698
    list_0 = [int_0]
    singleton_0 = Singleton(bool_0, int_0, list_0, list_0)

    # Run the test
    assert singleton_0 != None

# Generated at 2022-06-25 13:34:37.813726
# Unit test for method __call__ of class Singleton

# Generated at 2022-06-25 13:34:43.201652
# Unit test for constructor of class Singleton
def test_Singleton():
    list_0 = list()
    singleton_0 = Singleton(list_0)
    assert len(singleton_0) == 0
    list_0.append(bool(0))
    singleton_1 = Singleton(list_0)
    assert len(singleton_0) == 1
    assert singleton_1 is singleton_0

# Generated at 2022-06-25 13:34:45.855270
# Unit test for constructor of class Singleton
def test_Singleton():
    bool_0 = True
    int_0 = -698
    list_0 = [int_0]
    singleton_0 = Singleton(bool_0, int_0, list_0, list_0)

# Generated at 2022-06-25 13:34:50.261505
# Unit test for constructor of class Singleton
def test_Singleton():
    list_0 = list()
    int_0 = -957
    cls_0 = Singleton(list_0, int_0, int_0, int_0)
    cls_1 = Singleton(list_0, int_0, int_0, int_0)
    assert cls_0 == cls_1

# Generated at 2022-06-25 13:34:51.355612
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:34:54.974558
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_0 = Singleton()
    assert isinstance(singleton_0, object)


# Generated at 2022-06-25 13:34:56.494049
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton = Singleton()
    assert singleton.__call__()
    return True



# Generated at 2022-06-25 13:34:59.558542
# Unit test for constructor of class Singleton
def test_Singleton():
    from ansible.module_utils.six import with_metaclass
    singleton_i = None
    for i in range(3):
        class A(with_metaclass(Singleton)):
            def __init__(self):
                self.i = i
        singleton_i = A()
        assert i == singleton_i.i

# Generated at 2022-06-25 13:35:01.274243
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    my_singleton_0 = Singleton()
    assert my_singleton_0 is not None


# Generated at 2022-06-25 13:35:04.351302
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    cls1 = None
    cls2 = None
    if cls1 is None:
        cls1 = Singleton()
    if cls2 is None:
        cls2 = Singleton()
    assert cls1 is cls2

# Generated at 2022-06-25 13:35:06.563980
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_1 = Singleton()
    singleton_2 = Singleton()
    assert id(singleton_1) == id(singleton_2)


# Generated at 2022-06-25 13:35:07.474182
# Unit test for constructor of class Singleton
def test_Singleton():
    assert _test_Singleton()



# Generated at 2022-06-25 13:35:08.436540
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_1 = Singleton()
    singleton_2 = Singleton()
    assert singleton_1 is singleton_2


# Generated at 2022-06-25 13:35:10.225773
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_obj_0 = Singleton()
    assert singleton_obj_0, "singleton object instanciation failed"


# Generated at 2022-06-25 13:35:12.138590
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_1 = Singleton()
    singleton_2 = Singleton()
    assert(singleton_1 == singleton_2)

# Generated at 2022-06-25 13:35:18.155586
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print('Unit test for method Singleton.__call__()')

    # Create a new instance
    singleton_0 = Singleton()

    # Check that the instance state is maintained
    singleton_0.state = 0
    singleton_1 = Singleton()
    singleton_1.state = 1

    assert singleton_0.state == singleton_1.state

    # Check that we get the same instance
    assert singleton_0 is singleton_1



# Generated at 2022-06-25 13:35:19.441310
# Unit test for constructor of class Singleton
def test_Singleton():
    test_case_0()

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:35:21.475241
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    assert Foo() is Foo()
    assert Foo() is not Foo.__call__()



# Generated at 2022-06-25 13:35:22.444762
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    inst = Singleton()
    assert inst('arg') == inst

# Generated at 2022-06-25 13:35:25.770359
# Unit test for constructor of class Singleton
def test_Singleton():
    my_instance = Singleton()
    print(my_instance)

    TestSingle = type('TestSingle', (object,),{'__metaclass__': Singleton})
    print(type(TestSingle))
    print(type(TestSingle()))
    print(type(TestSingle()))

# Generated at 2022-06-25 13:35:27.630550
# Unit test for constructor of class Singleton
def test_Singleton():

    # Create instance of class Singleton
    singleton_0 = Singleton()

    # Check if the singleton_0 is not None.
    assert singleton_0 is not None


# Generated at 2022-06-25 13:35:29.725509
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    o = Singleton()
    o.__instance = 'test_value'
    o.__rlock = RLock()
    result = o.__call__()
    assert result == 'test_value'


# Generated at 2022-06-25 13:35:31.169275
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_1 = Singleton()
    singleton_2 = Singleton()
    assert singleton_1 is singleton_2 is True

# Generated at 2022-06-25 13:35:33.971039
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = Singleton(int, {}, {})
    assert isinstance(singleton_0.__call__(), int)
    assert isinstance(singleton_0(), int)

# Generated at 2022-06-25 13:35:34.642965
# Unit test for constructor of class Singleton
def test_Singleton():
    assert True

# Generated at 2022-06-25 13:35:38.361151
# Unit test for constructor of class Singleton
def test_Singleton():
    class Callable(object):
        __metaclass__ = Singleton
    assert Callable() == Callable()

# Generated at 2022-06-25 13:35:42.924003
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton
    class SingletonTest2(object):
        __metaclass__ = Singleton
    # This has to be true
    assert SingletonTest() == SingletonTest()
    # This has to be false
    assert SingletonTest() != SingletonTest2()

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:35:51.753234
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from collections import namedtuple
    from unittest import TestCase

    class Singleton0(object):
        __metaclass__ = Singleton

    class Singleton1(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 'value'

    class Singleton2(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    class SingletonTest(TestCase):
        def test_singleton0(self):
            s0 = Singleton0()
            self.assertIsInstance(s0, Singleton0)
            s1 = Singleton0()
            self.assertIs(s0, s1)

        def test_singleton1(self):
            s0 = Singleton1()
            self

# Generated at 2022-06-25 13:35:53.622416
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Single(object):
        __metaclass__ = Singleton

    s = Single()
    t = Single()

    assert s is t
    assert id(s) == id(t)

# Generated at 2022-06-25 13:35:56.977892
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo:
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    class Bar:
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    foo1 = Foo("foo1")
    foo2 = Foo("foo2")
    bar1 = Bar("bar1")
    bar2 = Bar("bar2")

    assert foo1 == foo2
    assert foo2 != bar1
    assert bar1 == bar2

# Generated at 2022-06-25 13:36:06.419610
# Unit test for constructor of class Singleton
def test_Singleton():
    from nose.tools import raises

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a1 = A()
    a2 = A()
    assert id(a1) == id(a2), "Singleton should work"

    class B(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    b1 = B(1)
    b2 = B(2)
    assert id(b1) == id(b2), "Singleton should work"
    assert b1.val == 1 and b2.val == 1, "Singleton should work"
    assert b1.val != 2 and b2.val != 2, "Singleton should work"

# Generated at 2022-06-25 13:36:11.026239
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = 1
    obj1 = TestSingleton()
    obj2 = TestSingleton()
    assert obj1 == obj2
    assert id(obj1) == id(obj2)



# Generated at 2022-06-25 13:36:15.680519
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    def get_instance():
        return TestClass()

    instance1 = get_instance()
    instance2 = get_instance()
    assert instance1 is instance2



# Generated at 2022-06-25 13:36:22.162866
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        t_val = 0
        def __init__(self, t_val=0):
            self.t_val = t_val
        def __del__(self):
            self.t_val = 0

    s = TestSingleton()
    assert s.t_val == 0
    s = TestSingleton(3)
    assert s.t_val == 3
    s.t_val = 2
    assert s.t_val == 2



# Generated at 2022-06-25 13:36:24.069605
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Myclass(object):
        __metaclass__ = Singleton

        def method(self):
            return 'singleton'

    obj1 = Myclass()
    obj2 = Myclass()
    assert(obj1 == obj2) and (obj1 is obj2)
    assert(obj1.method() == 'singleton')

# Generated at 2022-06-25 13:36:31.412430
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self, i):
            self.i = i

    s1 = S(1)
    s2 = S(2)
    assert s1.i == 1
    assert s2.i == 1


# Generated at 2022-06-25 13:36:35.314131
# Unit test for constructor of class Singleton
def test_Singleton():
    Singleton.__instance = None
    inst = Singleton('Singleton', (object,), {})
    inst2 = Singleton('Singleton', (object,), {})
    assert inst == inst2
    assert inst is inst2
    assert inst.__instance == inst2.__instance
    assert inst.__instance is inst2.__instance

# Generated at 2022-06-25 13:36:41.334398
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 1
            self.bar = 2

    cls = TestSingleton()

    assert isinstance(cls, TestSingleton)
    assert cls.foo == 1
    assert cls.bar == 2

    cls.bar = 5
    cls2 = TestSingleton()

    assert cls == cls2
    assert cls2.bar == 5

# Generated at 2022-06-25 13:36:50.856467
# Unit test for constructor of class Singleton
def test_Singleton():
    class X(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    class Y(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            pass
    # Test for initailizer with no argument
    x = X()
    assert(x)
    y = Y()
    assert(y)
    # Test for initailizer with argument
    try:
        x = X(1)
    except TypeError:
        assert(True)
    except:
        assert(False)
    try:
        y = Y(1)
    except TypeError:
        assert(True)
    except:
        assert(False)
    # Test for no duplicate instances
    x = X()
    y = Y()
    x2 = X()

# Generated at 2022-06-25 13:36:55.736641
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    class B(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a1 = A('a1')
    a2 = A('a2')
    assert a1 is a2
    assert a1.a == 'a1'

    b1 = B()
    b2 = B()
    assert b1 is b2

# Generated at 2022-06-25 13:36:59.765572
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    # Verify that the singleton constructor is calling
    # the A class constructor with the correct arguments
    a = A(42)
    assert a.a == 42

# Generated at 2022-06-25 13:37:03.683557
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    Singleton.__instance = None

    class MySingleton(metaclass=Singleton):
        def __init__(self):
            pass

    s = MySingleton()
    assert s == MySingleton()



# Generated at 2022-06-25 13:37:04.731106
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # TODO: implement this
    pass

# Generated at 2022-06-25 13:37:07.722429
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class test_class(object):
        __metaclass__ = Singleton

    assert test_class() is test_class()  # Both calls for an instance of class test_class() should return the same object

# Generated at 2022-06-25 13:37:10.100629
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    obj1 = SingletonTest()
    obj2 = SingletonTest()
    assert id(obj1) == id(obj2)
    return True


# Generated at 2022-06-25 13:37:21.286930
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-25 13:37:25.583894
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test_var = 1

    test_obj1 = TestClass()
    test_obj2 = TestClass()
    assert test_obj1 == test_obj2
    assert test_obj1.test_var == test_obj2.test_var

# Generated at 2022-06-25 13:37:31.380397
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test_var = 0

    a = A()
    b = A()

    # Singleton pattern should be achieved
    assert(a == b)

    # Objects must be the same
    assert(id(a) == id(b))

    # Test if we can modify a singleton object
    a.test_var = 1
    assert(a.test_var == 1)
    assert(b.test_var == 1)

# Execute unit test
if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:37:34.798123
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    class SingletonTest2(object):
        __metaclass__ = Singleton

    s1 = SingletonTest()
    s2 = SingletonTest()
    assert s1.a == s2.a
    s3 = SingletonTest2()
    s4 = SingletonTest2()
    assert s2.a == s3.a == s4.a

# Generated at 2022-06-25 13:37:39.285279
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self, value):
            self.__value = value

        def __str__(self):
            return self.__value

    obj1 = Test('foo')
    obj2 = Test('bar')

    assert obj1 is obj2
    assert str(obj1) == 'foo'
    assert str(obj2) == 'foo'



# Generated at 2022-06-25 13:37:43.773562
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    obj1 = Singleton()

    # simulate 2 different calls to the same class, if it wouldn't be a
    # singleton, 2 different objects would be created, instead the first
    # object is returned by __call__()
    obj2 = Singleton()

    assert obj1 is obj2



# Generated at 2022-06-25 13:37:48.962533
# Unit test for constructor of class Singleton
def test_Singleton():
    # a class inherits Singleton meta class
    class TestSingleton(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    obj_1 = TestSingleton('Some name')
    obj_2 = TestSingleton('Some name')

    assert obj_1 is obj_2
    assert obj_1.name == 'Some name'
    assert obj_2.name == 'Some name'

# Generated at 2022-06-25 13:37:54.627366
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.a, self.b = args
            self.kw = kwargs

    s1 = TestSingleton(1, 2, a=3, b=4)
    s2 = TestSingleton(5, 6, c=7, d=8)
    assert s1 == s2
    assert s1.a == s2.a
    assert s1.kw == {'a': 3, 'b': 4}

# Generated at 2022-06-25 13:37:58.370856
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(metaclass=Singleton):
        def __init__(self):
            self.foo = 42

    test_object = TestClass()
    test_object.foo = 43
    test_object2 = TestClass()

    assert test_object == test_object2
    assert test_object.foo == test_object2.foo == 43


# unit test for method __call__ of decorator func.

# Generated at 2022-06-25 13:37:59.282298
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton


# Generated at 2022-06-25 13:38:24.455296
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test setup
    class Test_Singleton(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            pass

    # Unit test begins
    ts1 = Test_Singleton()
    assert ts1 == Test_Singleton()
    ts2 = Test_Singleton()
    assert ts2 == Test_Singleton()
    assert ts1 == ts2
    del ts2
    assert ts1 == Test_Singleton()
    del ts1
    # Reinstantiate ts1
    ts1 = Test_Singleton()
    assert ts1 == Test_Singleton()
    ts2 = Test_Singleton()
    assert ts2 == Test_Singleton()
    assert ts1 == ts2
    del ts2
    assert ts1 == Test_Singleton()
    del ts

# Generated at 2022-06-25 13:38:30.526817
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a, b=None):
            print(a, b)

    a = A(1)
    print('A' + str(a))
    b = A(2)
    print('B' + str(b))
    assert a is b
    c = a
    print('C' + str(c))
    assert c is a
    assert a is b
    assert b is c


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:38:35.949947
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, foo):
            self.foo = foo

    class B(object):
        __metaclass__ = Singleton
        def __init__(self, foo):
            self.foo = foo

    assert A('bar') is A('baz')
    assert B('bar') is B('baz')
    assert A('bar') is not B('bar')


# Generated at 2022-06-25 13:38:37.707851
# Unit test for constructor of class Singleton
def test_Singleton():
    class T(metaclass=Singleton):
        pass

    t1 = T()
    t2 = T()
    assert t1 is t2

# Generated at 2022-06-25 13:38:40.483460
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    a = A()
    b = A()
    assert a == b

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:38:46.296194
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import sys
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    assert sys.getrefcount(Test(1, 2)) == 2
    assert sys.getrefcount(Test(3, 4)) == 2
    assert sys.getrefcount(Test(1, 2)) == 3

# Generated at 2022-06-25 13:38:51.665030
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestSingleton(object):
        __metaclass__ = Singleton

        value = None

        def __init__(self, value):
            self.value = value

    test1 = TestSingleton(1)
    test2 = TestSingleton(2)
    print(test1.value, test2.value)
    assert id(test1) == id(test2)


# Generated at 2022-06-25 13:38:54.124344
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class ASingleton(object):
        __metaclass__ = Singleton

    a = ASingleton()
    b = ASingleton()
    assert(a is b)



# Generated at 2022-06-25 13:38:56.043450
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    return a is b

# Generated at 2022-06-25 13:38:59.337735
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass
    a = A()
    b = A()
    assert a == b
    assert id(a) == id(b)



# Generated at 2022-06-25 13:39:36.731887
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

    a = SingletonTest()
    b = SingletonTest()
    assert(a is b)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:39:43.185587
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class SingletonClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 'foo'

    class Test(unittest.TestCase):
        def test(self):
            s = SingletonClass()
            self.assertIsInstance(s, SingletonClass)
            self.assertEqual(s.foo, 'foo')

            s1 = SingletonClass()
            self.assertIsInstance(s1, SingletonClass)
            self.assertEqual(s1.foo, 'foo')
            self.assertIs(s1, s)
    return unittest.TestLoader().loadTestsFromTestCase(Test)

# Generated at 2022-06-25 13:39:47.874803
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_value = 1
    a = TestSingleton()
    b = TestSingleton()
    assert(a == b)
    assert(id(a) == id(b))
    a.test_value = 2
    assert(b.test_value == 2)
    b.test_value = 3
    assert(a.test_value == 3)



# Generated at 2022-06-25 13:39:50.874152
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonUnitTest(object):
        __metaclass__ = Singleton

    assert SingletonUnitTest() is SingletonUnitTest()
    assert SingletonUnitTest() is not SingletonUnitTest()
    
if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:39:53.814132
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    a = TestSingleton('foo')
    assert isinstance(a, TestSingleton)
    b = TestSingleton('bar')
    assert a is b


# Generated at 2022-06-25 13:39:56.722120
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    a = MySingleton()
    b = MySingleton()
    assert a is b

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:39:59.422817
# Unit test for constructor of class Singleton
def test_Singleton():

    # metaclass definition
    class A(object):
        __metaclass__ = Singleton

    # test instance
    a = A()
    b = A()
    assert a == b

# Generated at 2022-06-25 13:40:02.320875
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'a'

    a = MyClass()
    b = MyClass()

    assert(a is b)


# Generated at 2022-06-25 13:40:04.638015
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 is a2



# Generated at 2022-06-25 13:40:08.454453
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = True

    s1 = S()
    s2 = S()
    assert s1.value == s2.value

# test Singleton
if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:41:27.026699
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    instance1 = MyClass()
    instance2 = MyClass()

    assert instance1 == instance2


# Generated at 2022-06-25 13:41:31.722373
# Unit test for constructor of class Singleton
def test_Singleton():
    import pytest

    class Foo(metaclass=Singleton):
        pass

    class Bar(metaclass=Singleton):
        pass

    assert Foo() == Foo()
    assert Bar() == Bar()
    assert Foo() != Bar()
    assert Bar() != Foo()

    with pytest.raises(TypeError):
        Foo("foo")

    with pytest.raises(TypeError):
        Bar("foo")

# Generated at 2022-06-25 13:41:34.982951
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass:
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    a = MyClass(3)
    assert a.a == 3
    b = MyClass(4)
    assert b is a and a.a == 3


# Generated at 2022-06-25 13:41:38.139939
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert A() == A()
    class B(object):
        __metaclass__ = Singleton

    assert B() == B()
    class C(object):
        __metaclass__ = Singleton

    assert C() != B()
    assert C() == C()

# Generated at 2022-06-25 13:41:40.389052
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton('SingletonTest', (object, ), {}) is Singleton('SingletonTest', (object, ), {})

# Generated at 2022-06-25 13:41:49.363217
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import unittest

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.args = None
            self.kw = None

    class SingletonTestCase(unittest.TestCase):
        def setUp(self):
            self.test_args = {}
            self.test_kw = {}
            self.singleton_inst1 = TestClass()
            self.singleton_inst2 = TestClass()

        def test_class_call(self):
            TestClass(1, 2, 3)

            self.assertEqual(self.singleton_inst1.args, (1, 2, 3))
            self.assertEqual(self.singleton_inst2.args, (1, 2, 3))


# Generated at 2022-06-25 13:41:56.790919
# Unit test for constructor of class Singleton
def test_Singleton():
    # pylint: disable=too-few-public-methods
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            super(MyClass, self).__init__()
            self.val = None

    obj1 = MyClass()
    obj2 = MyClass()
    obj1.val = 'Test'
    obj2.val = 'ABC'

    # obj1 and obj2 are instances of the same object, val should be the same.
    print(obj1.val)
    print(obj2.val)
    assert obj1 == obj2
    assert obj1.val == obj2.val

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:41:58.517725
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(metaclass=Singleton):
        pass

    a = A()
    b = A()
    assert a is b



# Generated at 2022-06-25 13:42:02.647428
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1
            pass

    a = A()
    assert isinstance(a, A)
    a.a = 2
    b = A()
    assert isinstance(b, A)
    assert a == b
    assert a.a == 2
    assert b.a == 2


# Generated at 2022-06-25 13:42:09.839634
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    foo = [0]
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            foo[0] += 1
            self.foo = foo[0]
    class B(A):
        pass

    assert foo[0] == 0
    a = A()
    b = B()
    c = A()
    d = B()
    assert foo[0] == 1
    assert isinstance(a, A)
    assert isinstance(a, B)
    assert isinstance(b, A)
    assert isinstance(b, B)
    assert isinstance(c, A)
    assert isinstance(c, B)
    assert isinstance(d, A)
    assert isinstance(d, B)
    assert b is a
    assert d is b