

# Generated at 2022-06-25 13:34:24.637686
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    dict_0 = None
    bool_0 = False
    int_0 = -1560
    singleton_0 = Singleton(dict_0, bool_0, bool_0, int_0)
    int_0 = -1560
    dict_0 = None
    bool_0 = False
    singleton_0.__call__(dict_0, bool_0, bool_0, int_0)


# Generated at 2022-06-25 13:34:25.961793
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton(None, False, False, -1560).__eq__("") == False

# Generated at 2022-06-25 13:34:26.564923
# Unit test for constructor of class Singleton
def test_Singleton():
    assert test_case_0() == None

# Generated at 2022-06-25 13:34:28.739054
# Unit test for constructor of class Singleton
def test_Singleton():
    dict_0 = None
    bool_0 = False
    int_0 = -1560
    singleton_0 = Singleton(dict_0, bool_0, bool_0, int_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:34:32.260086
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    dict_0 = None
    bool_0 = False
    int_0 = -1456
    singleton_0 = Singleton(dict_0, bool_0, bool_0, int_0)


if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:34:33.762606
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:34:38.576830
# Unit test for constructor of class Singleton
def test_Singleton():
    # no need to test anything here unless you have some sort
    # of test_config available
    dict_0 = None
    bool_0 = False
    int_0 = 1665
    singleton_0 = Singleton(dict_0, bool_0, bool_0, int_0)

# Generated at 2022-06-25 13:34:48.470012
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Try to get an instance
    singleton_0 = Singleton()

    # Assert that this instance is the same as the next instance
    singleton_1 = Singleton()
    assert singleton_0 == singleton_1, "AssertionError: Variables singleton_0, singleton_1 are not the same"

    # Assert that this instance is the same as the instance from the
    # singleton method
    singleton_2 = singleton_0.singleton()
    assert singleton_0 == singleton_2, "AssertionError: Variables singleton_0, singleton_2 are not the same"


if __name__ == "__main__":
    test_case_0()
    test_Singleton___call__()

# Generated at 2022-06-25 13:34:53.294800
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert Singleton.__call__(Singleton,
                              {'__module__': '__main__', 'Singleton': Singleton, 'test_Singleton___call__': test_Singleton___call__,
                               'test_case_0': test_case_0}, False, False, -1560) == Singleton.__instance



# Generated at 2022-06-25 13:34:54.139598
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton is not None


# Generated at 2022-06-25 13:35:02.318985
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('constructor of class A')

    class B(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            print('constructor of class B with a = %s' % a)

    class C(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('constructor of class C')
            self.a = A()

    class D(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('constructor of class D')
            self.b = B(A())

    a = A()

# Generated at 2022-06-25 13:35:08.844787
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class foo(object):
        __metaclass__ = Singleton

    class bar(object):
        __metaclass__ = Singleton

    class baz(object):
        __metaclass__ = Singleton

    f = foo()
    g = foo()
    h = bar()
    i = bar()
    j = baz()
    k = baz()

    assert f is g
    assert h is i
    assert j is k

    assert f is not h
    assert f is not j
    assert h is not j



# Generated at 2022-06-25 13:35:13.023748
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    s1 = S(1)
    s2 = S(2)

    assert s1 is not None
    assert s2 is not None
    assert s1 is s2
    assert s1.x == 1



# Generated at 2022-06-25 13:35:18.899328
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    inst1 = A()
    inst2 = A()

    try:
        assert inst1 is inst2
        print("Test Case 1: Success")
    except AssertionError:
        print("Test Case 1: Fail")

    class B(object):
        __metaclass__ = Singleton

    inst3 = B()

    try:
        assert inst1 is not inst3
        print("Test Case 2: Success")
    except AssertionError:
        print("Test Case 2: Fail")



# Generated at 2022-06-25 13:35:20.342703
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()

# Generated at 2022-06-25 13:35:22.746137
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()
    assert f1 is f2  # We can only create instance of a Singleton class once.


# Generated at 2022-06-25 13:35:24.811084
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass
        
    assert isinstance(A(), A)
    assert A() is A()

 

# Generated at 2022-06-25 13:35:28.275328
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    a = Test(1)
    b = Test(2)
    assert a is b
    assert a.val == b.val
    assert a.val == 1



# Generated at 2022-06-25 13:35:32.903227
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    # class A has no parameter
    a1 = A()
    a2 = A()
    assert a1 is a2

    # class A has 2 parameters
    class B(object):
        __metaclass__ = Singleton
        def __init__(self, x, y):
            self.x = x
            self.y = y

    b1 = B(1, 2)
    b2 = B(2, 3)
    assert b1.x == b2.x
    assert b1.y == b2.y

# Generated at 2022-06-25 13:35:36.695412
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 2

    a = SingletonTest()
    b = SingletonTest()
    assert a.val == 2
    assert a is b

# Generated at 2022-06-25 13:35:44.202145
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = 1

    a = A()
    assert a.a == 1
    a.a = 2
    b = A()
    assert a.a == 2
    assert b.a == 2

# Generated at 2022-06-25 13:35:45.693391
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton('test', (object,),{}).__instance == None

# Generated at 2022-06-25 13:35:50.921493
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest:
        def __init__(self):
            self.value = 1

    assert issubclass(SingletonTest, Singleton)
    s1 = SingletonTest()
    assert isinstance(s1, SingletonTest)
    s2 = SingletonTest()
    assert s2 is s1
    assert s1.value == 1
    s1.value += 1
    assert s2.value == 2
    assert s1.value == 2



# Generated at 2022-06-25 13:35:55.151381
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest:
        __metaclass__ = Singleton

        def __init__(self, x=2):
            self.x = x

    a = SingletonTest()
    assert a.x == 2
    b = SingletonTest(3)
    assert a.x == 2
    assert a == b
    assert a is b
    a.x = 4
    assert a.x == b.x


# Generated at 2022-06-25 13:35:56.858090
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-25 13:36:01.129984
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test1(object):
        __metaclass__ = Singleton

    ob1 = Test1()
    ob2 = Test1()
    assert ob1 is ob2
    assert ob1.__class__ is ob2.__class__
    assert ob1.__class__ is Test1


# Generated at 2022-06-25 13:36:06.945468
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test __call__ method of class Singleton"""
    class B(metaclass=Singleton):
        def __init__(self, arg):
            self.arg = arg

    a = B(1)
    assert a.arg == 1

    # Only one instance of B can exist
    c = B(2)
    assert a.arg == 1
    assert c.arg == 1

    c.arg = 2
    assert a.arg == 2
    assert c.arg == 2


# Generated at 2022-06-25 13:36:11.204457
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 1
            
    x = TestClass()
    assert x.value == 1
    x2 = TestClass()
    assert x2.value == 1
    assert x is x2

# Generated at 2022-06-25 13:36:17.902760
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    i1 = MyClass(1, 2, 3)
    i2 = MyClass(4, 5, 6)

    assert i1 is i2
    assert i1.a == 1
    assert i1.b == 2
    assert i1.c == 3

# Generated at 2022-06-25 13:36:20.602867
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class mycls(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    assert mycls() is mycls()


# Generated at 2022-06-25 13:36:30.471558
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a == b

# Generated at 2022-06-25 13:36:34.957700
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 'b'

    obj1 = Foo()
    obj2 = Foo()
    assert id(obj1) == id(obj2)
    assert obj1.a == obj2.a
    obj1.a = 'c'
    assert obj1.a != obj2.a


# Generated at 2022-06-25 13:36:37.707869
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()

    assert t1 is t2


# Generated at 2022-06-25 13:36:43.419012
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    assert MySingleton.__instance is None

    s1 = MySingleton('s1')
    assert s1.name == 's1'
    assert MySingleton.__instance == s1
    s2 = MySingleton('s2')
    assert s2.name == 's1'
    assert s2 == s1



# Generated at 2022-06-25 13:36:48.668234
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a1 = A("s")
    print(a1.name)

    a2 = A("s")
    print(a2.name)
    #print(a1 == a2)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:36:51.510286
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    t0 = Test()
    t1 = Test()

    assert id(t0) == id(t1)



# Generated at 2022-06-25 13:36:56.661320
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

        def __str__(self):
            return "Foo(%s)" % self.value

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

        def __str__(self):
            return "Bar(%s)" % self.value

    foo1 = Foo(1)
    foo2 = Foo(2)
    bar1 = Bar(1)

    assert foo1.value == 1
    assert str(foo1) == "Foo(1)"
    assert foo2 is foo1
    assert foo1 is bar1
    assert bar1 is not foo2


# Generated at 2022-06-25 13:37:04.851146
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Singleton1(object):
        __metaclass__ = Singleton

        def __init__(self, val="0"):
            self.val = val

    class Singleton2(object):
        __metaclass__ = Singleton

        def __init__(self, val="0"):
            self.val = val

    obj1 = Singleton1("1")
    obj2 = Singleton1()

    assert obj1 == obj2

    obj3 = Singleton2("2")
    obj4 = Singleton2()

    assert obj3 == obj4
    assert obj1 != obj3

# Generated at 2022-06-25 13:37:13.447765
# Unit test for constructor of class Singleton
def test_Singleton():
    import unittest

    class A(object):
        __metaclass__ = Singleton

    class A1(A):
        pass

    class B(object):
        pass

    class B1(B):
        pass

    class C(A, B):
        pass

    class C1(C):
        pass

    class D(C, B):
        pass

    class D1(D):
        pass

    def uniq(seq):
        """return a list of unique items in list seq"""
        d = {}
        for i in seq:
            d[i] = 1
        return d.keys()

    class Test(unittest.TestCase):
        def test(self):
            a = A()
            a1 = A1()
            self.assertEqual(a, a1)

# Generated at 2022-06-25 13:37:14.826950
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert Singleton() == Singleton()
    assert Singleton() != object()


# Generated at 2022-06-25 13:37:32.117124
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    obj_1 = MyClass()
    obj_2 = MyClass()
    assert(obj_1 is obj_2)


# Generated at 2022-06-25 13:37:35.410109
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.state = 0

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = Foo()
            self.state = 1

    foo = Foo()
    assert foo is Foo()
    assert foo.state == 0

    bar = Bar()
    assert bar is Bar()
    assert bar.state == 1
    assert foo is bar.foo

# Generated at 2022-06-25 13:37:37.126615
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() == TestSingleton()

# Generated at 2022-06-25 13:37:44.538818
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Test case of testing singleton object initialization.  If two
    objects development from the same super class and one of the
    objects is instantiated, the other object instance should
    return the same object.

    """
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    tc1 = TestClass('tc1')
    tc2 = TestClass('tc2')
    assert(tc1.val == 'tc1')
    assert(tc2.val == 'tc1')
    assert(tc1 == tc2)


# Generated at 2022-06-25 13:37:46.469295
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    a = SingletonTest('a')
    b = SingletonTest('b')
    assert id(a) == id(b)
    assert a.foo == b.foo
    assert a.foo == 'a'



# Generated at 2022-06-25 13:37:49.757084
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from test.lib.ansible_test.mock import MockSingleton, MockSingleton2
    m1 = MockSingleton()
    m2 = MockSingleton()
    # m1 and m2 are the same instance
    assert(id(m1) == id(m2))
    m3 = MockSingleton2()
    # m3 is a different instance than m1
    assert(id(m3) != id(m1))

# Generated at 2022-06-25 13:37:54.352025
# Unit test for constructor of class Singleton
def test_Singleton():
    from py.test import raises
    from ansible.module_utils.connection import ConnectionBase
    import ansible.module_utils.network.common.config as config
    config.STRATEGY = 'netconf'
    connection = ConnectionBase()
    try:
        connection2 = ConnectionBase()
        assert False, "Should not have been able to instantiate 2 ConnectionBase classes."
    except TypeError as e:
        assert "can't instantiate" in str(e)

# Generated at 2022-06-25 13:37:58.943142
# Unit test for constructor of class Singleton
def test_Singleton():
    # Create a class SingletonClass and make it a Singleton
    class SingletonClass(metaclass=Singleton):
        def __init__(self, name):
            self.name = name

    # Create the first instance of SingletonClass
    s1 = SingletonClass("S1")

    # Check the instance of SingletonClass is a singleton
    s2  = SingletonClass("S2")

    assert s1 == s2
    assert s1.name == s2.name
    assert s1.name == "S1"


# Generated at 2022-06-25 13:38:05.245131
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 'a'
            print('A()')

        def print(self):
            print(self.a)

    a = A()
    b = A()

    assert(a == b)
    assert(a is b)
    assert(a.a == b.a)


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:38:10.023931
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

        def get(self):
            return self.x

    assert id(Test()) == id(Test())
    assert Test().get() == 1
    t = Test()
    t.x = 2
    assert Test().x == 2
    assert Test().get() == 2

# Generated at 2022-06-25 13:38:46.097014
# Unit test for constructor of class Singleton
def test_Singleton():
    class Example(object):
        __metaclass__ = Singleton
    ex1 = Example()
    ex2 = Example()
    assert ex1 is ex2
    assert id(ex1) == id(ex2)

# Generated at 2022-06-25 13:38:51.996803
# Unit test for constructor of class Singleton
def test_Singleton():
    class Sing(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    s = Sing(1, 2)
    assert s.a == 1
    assert s.b == 2

    s2 = Sing(2, 3)
    assert s2.a == 1
    assert s2.b == 2

    assert s == s2

# Generated at 2022-06-25 13:38:55.227515
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = None

    a1 = A()
    a1.a = 9
    a2 = A()
    a2.a = 8
    assert(a1.a == a2.a)

# Generated at 2022-06-25 13:39:00.713270
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class TestClassSubclass(TestClass):
        pass

    from threading import Thread

    # No existing instance.
    # Testing that after exec __call__ we have only one instance of TestClass
    test_obj = TestClass()
    same_test_obj = TestClass()
    assert(id(test_obj) == id(same_test_obj))

    # Testing that instance of subclass of TestClass is also instance of TestClass
    test_obj2 = TestClassSubclass()
    same_test_obj2 = TestClass()
    assert(id(test_obj2) == id(same_test_obj2))

    # Testing that instance of subclass of TestClass is not instance of TestClass
    # because subclass have

# Generated at 2022-06-25 13:39:03.142824
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton


    instance1 = MyClass()
    instance2 = MyClass()

    assert instance1 is instance2

# Generated at 2022-06-25 13:39:06.950275
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert (a1 is a2)
    assert (a1.__class__ is a2.__class__)

test_Singleton()

# Generated at 2022-06-25 13:39:10.876260
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyTestClass(object):
        __metaclass__ = Singleton

    test_class1 = MyTestClass()
    test_class2 = MyTestClass()
    result = test_class1 is test_class2
    if not result:
        raise AssertionError("__call__ method of class Singleton does not work!")

# Generated at 2022-06-25 13:39:13.624197
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(with_metaclass(Singleton)):
        pass
    instance1 = TestClass()
    instance2 = TestClass()
    assert id(instance1) == id(instance2)


# Generated at 2022-06-25 13:39:16.713272
# Unit test for constructor of class Singleton
def test_Singleton():
    '''Unit test of Constructor of Class Singleton
    '''
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            pass

    a = A()
    b = A()

    assert a is b

# Generated at 2022-06-25 13:39:18.991857
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    foo1 = Foo()
    foo2 = Foo()

    assert foo1 == foo2

# Generated at 2022-06-25 13:40:33.856125
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    f1 = Foo(1, 2)
    f2 = Foo(3, 4)
    assert f1 == f2
    assert f1.a == 1
    assert f1.b == 2

# Generated at 2022-06-25 13:40:37.059616
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonSubclass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.i = 0

    s1 = SingletonSubclass()
    s2 = SingletonSubclass()

    assert s1 is s2


# Generated at 2022-06-25 13:40:42.371280
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 1

    ts1 = TestSingleton()
    ts2 = TestSingleton()

    assert ts1 is ts2
    assert ts1.foo == 1
    assert ts2.foo == 1

    ts1.foo = 2
    assert ts1.foo == 2
    assert ts2.foo == 2


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:40:45.829854
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    >>> class TestSingleton():
    ...     __metaclass__ = Singleton
    >>> a = TestSingleton()
    >>> b = TestSingleton()
    >>> c = TestSingleton()
    >>> id(a) == id(b) == id(c)
    True
    """
    

# Generated at 2022-06-25 13:40:50.376069
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Tests __call__() of class Singleton"""

    class Dummy(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = Dummy()
    b = Dummy()
    assert(a is b)
    assert(isinstance(a, Dummy))
    assert(isinstance(b, Dummy))

# Generated at 2022-06-25 13:40:54.024453
# Unit test for constructor of class Singleton
def test_Singleton():
    class A():
        __metaclass__ = Singleton

        def __init__(self, i):
            self.i = i

    a1 = A(1)
    a2 = A(2)
    assert(a1.i == 1)
    assert(a2.i == 1)
    assert(a1 is a2)

# Generated at 2022-06-25 13:40:57.759134
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object, metaclass=Singleton):
        def __init__(self):
            self.value1 = 0

        def increment(self):
            self.value1 += 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    t3 = TestSingleton()

    t1.increment()

    assert t1 is t2 and t2 is t3
    assert t1.value1 == 1
    assert t1.value1 == t2.value1
    assert t2.value1 == t3.value1



# Generated at 2022-06-25 13:41:03.860972
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible.module_utils.six import with_metaclass
    class TestClass(with_metaclass(Singleton, object)):
        def __init__(self):
            self.foo = 'bar'

    tc1 = TestClass()
    assert tc1.foo == 'bar'

    tc2 = TestClass()
    assert tc2.foo == 'bar'

    assert tc1 == tc2

# Generated at 2022-06-25 13:41:13.213756
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonClass(object, metaclass=Singleton):
        def __init__(self):
            print("init")
            self.var = "a"

    class BadSingletonClass(object, metaclass=Singleton):
        def __init__(self, val):
            print("init")
            self.var = val

    s1 = SingletonClass()
    assert isinstance(s1, SingletonClass)
    s2 = SingletonClass()
    assert s1 is s2

    # Test custom __init__ method (with arguments)
    bs1 = BadSingletonClass("b")
    assert isinstance(bs1, BadSingletonClass)
    assert bs1.var == "b"
    try:
        bs2 = BadSingletonClass()
    except TypeError:
        pass



# Generated at 2022-06-25 13:41:15.379314
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

    # Initialization
    foo = SingletonTest()
    bar = SingletonTest()
    assert(foo is bar)

# Generated at 2022-06-25 13:44:13.316921
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            pass

        def foo(self):
            return 1

    o1 = TestSingleton()
    o2 = TestSingleton()
    assert o1.foo() == 1
    assert o1 is o2

# Generated at 2022-06-25 13:44:16.257445
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2


# Generated at 2022-06-25 13:44:23.612481
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread

    from ansiblelint.rules.CommandsIncludeRulesdMetaEnv import CommandsIncludeRulesdMetaEnv

    def func1(singleton):
        return singleton()

    def func2(singleton):
        return singleton()

    obj = CommandsIncludeRulesdMetaEnv()

    assert obj is CommandsIncludeRulesdMetaEnv()

    thread1 = Thread(target=func1, args=(CommandsIncludeRulesdMetaEnv,))
    thread1.start()
    thread1.join()

    thread2 = Thread(target=func2, args=(CommandsIncludeRulesdMetaEnv,))
    thread2.start()
    thread2.join()

    assert obj is CommandsIncludeRulesdMetaEnv()