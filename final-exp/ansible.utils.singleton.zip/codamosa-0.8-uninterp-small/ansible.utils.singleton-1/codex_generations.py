

# Generated at 2022-06-25 13:34:18.401243
# Unit test for constructor of class Singleton
def test_Singleton():
    # Test for call to Singleton.__init__
    # TODO: test __init__ here
    assert False # TODO: implement your test here



# Generated at 2022-06-25 13:34:19.397309
# Unit test for constructor of class Singleton
def test_Singleton():
    test_case_0()

# Generated at 2022-06-25 13:34:24.397166
# Unit test for constructor of class Singleton
def test_Singleton():
    """Unit test for constructor of class Singleton"""
    int_0 = None
    list_0 = None
    str_0 = 'k8Mup\x0bt'
    singleton_0 = Singleton(str_0, list_0, str_0, int_0)
    assert isinstance(singleton_0, type)



# Generated at 2022-06-25 13:34:25.422118
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass


# Generated at 2022-06-25 13:34:27.759842
# Unit test for constructor of class Singleton
def test_Singleton():
    list_0 = [str]
    singleton_0 = Singleton(str, str, str, list_0)
    assert(isinstance(singleton_0, Singleton))

# Generated at 2022-06-25 13:34:29.643170
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = Singleton('test_string', list(), dict())
    singleton_0.__call__()


# Generated at 2022-06-25 13:34:37.722172
# Unit test for constructor of class Singleton
def test_Singleton():
    # assignment
    test_case_1()
    int_0 = None
    str_0 = 'l\n!_'
    list_0 = [str_0, int_0]
    singleton_0 = Singleton(str_0, int_0, str_0, list_0)
    # assignment
    test_case_0()
    int_0 = None
    str_0 = '5:c%'
    list_0 = [str_0, int_0]
    singleton_0 = Singleton(str_0, int_0, str_0, list_0)
    # assignment
    test_case_1()
    int_0 = None
    str_0 = 'w'
    list_0 = [str_0, int_0]

# Generated at 2022-06-25 13:34:39.698364
# Unit test for constructor of class Singleton
def test_Singleton():
    assert Singleton(str_0, int_0, str_0, list_0)


# Generated at 2022-06-25 13:34:49.935425
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    list_0 = [0.99, 1.24, 16.63]
    dict_0 = dict(dict_0=list_0, **list_0)
    int_0 = 11
    str_0 = 'e6U'
    bytes_0 = b'\xa2\x1b\x03\x9a\xea\x80\xcf\x98\xc6\x02\x04\xa3\x03\x1a\xf1\x80'
    float_0 = 0.96
    singleton_0 = Singleton(int_0, dict_0, str_0, bytes_0, list_0, float_0)
    str_1 = '*\x0b\x9f\xaf\x05'
    singleton_0.str_1 = str_1
   

# Generated at 2022-06-25 13:34:58.988277
# Unit test for constructor of class Singleton
def test_Singleton():
    int_0 = None
    str_0 = '0_z&W\x7fa$'
    list_0 = [str_0, int_0]
    singleton_0 = Singleton(str_0, int_0, str_0, list_0)
    singleton_0 = singleton_0()
    int_1 = singleton_0()
    int_0 = singleton_0()
    int_0 = singleton_0()
    int_0 = singleton_0()
    int_1 = singleton_0()
    int_1 = singleton_0()
    str_0 = singleton_0()
    int_0 = singleton_0()
    singleton_0 = singleton_0()
    int_1 = singleton_0()
    int_0 = singleton_0()

# Generated at 2022-06-25 13:35:05.330690
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    a.test = "a"
    assert b.test == "a"
    try:
        b.test = "b"
    except AttributeError:
        pass
    assert a.test == "b"

# Generated at 2022-06-25 13:35:07.347254
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
    a = Foo()
    b = Foo()
    assert a is b

# Generated at 2022-06-25 13:35:10.925592
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    assert t1
    assert t1.__class__ == Test
    t2 = Test()
    assert t2
    assert t2.__class__ == Test
    assert t2 == t1

# Generated at 2022-06-25 13:35:13.430085
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.v = 0

    a = A()
    b = A()
    assert a == b

# Generated at 2022-06-25 13:35:16.062713
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        pass

    assert TestSingleton
    assert TestSingleton.__instance is None

    TestSingleton()

    assert TestSingleton.__instance is not None

# Generated at 2022-06-25 13:35:19.256657
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(cls, name):
            cls.name = name

    # Test that only one instance of TestClass is created at a time
    instance_1 = TestClass('instance_1')
    instance_2 = TestClass('instance_2')

    # Test that the instances are in fact the same object
    assert instance_1 is instance_2

# Generated at 2022-06-25 13:35:24.719498
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class singleton(object):
        __metaclass__ = Singleton
    class singleton2(object):
        __metaclass__ = Singleton
    import threading
    threads = []

    def thread_instance():
        x = singleton()
        y = singleton2()
        x is y
        threads.append((x,y))
    for i in range(100):
        t = threading.Thread(target=thread_instance)
        t.start()
    for i in range(100):
        t.join()
    assert len(threads) == 100
    for instance in threads:
        assert instance[0] is not None
        assert instance[0] is instance[1]

# Generated at 2022-06-25 13:35:28.481124
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Single(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.num = 0

        def inc(self):
            self.num += 1

    s = Single()
    s.inc()
    assert s.num == 1
    s1 = Single()
    s1.inc()
    assert s.num == 2

# Generated at 2022-06-25 13:35:30.246452
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    a = MySingleton()
    b = MySingleton()
    assert a == b

# Generated at 2022-06-25 13:35:32.237705
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.foo = 'bar'

    a1 = A()
    a2 = A()
    assert id(a1) == id(a2)

# Generated at 2022-06-25 13:35:38.207550
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

    a = C()
    b = C()
    assert a is b


# Generated at 2022-06-25 13:35:41.966300
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    # Test __init__ of Singleton works.
    assert issubclass(Singleton, type)

    # Test if the same instance is returned.
    a = TestClass()
    b = TestClass()
    assert a==b

# Generated at 2022-06-25 13:35:45.681763
# Unit test for constructor of class Singleton
def test_Singleton():
    class S(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 42

    assert S() is S()
    assert S().x == 42

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:35:52.754238
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Singleton_class_test(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self.name = name
    
    # Create and test the first instance of class Singleton_class_test
    instance_1 = Singleton_class_test('instance_1')
    assert instance_1.name == 'instance_1'
    
    # Create and test the second instance of class Singleton_class_test
    instance_2 = Singleton_class_test('instance_2')
    assert instance_2.name == 'instance_1'

    assert id(instance_1) == id(instance_2)


# Generated at 2022-06-25 13:35:57.517126
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    t1 = TestSingleton(1)
    assert t1.val == 1, 'TestSingleton.__init__ not called correctly'
    t2 = TestSingleton(2)
    assert t1.val == 1, 't1 was created again'
    assert t2.val == 1, 't1 and t2 are not the same object'


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:36:00.413264
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-25 13:36:07.497859
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    class TestNotSingleton(object):
        def __init__(self, val):
            self.val = val

    test_singleton = TestSingleton('a')
    assert test_singleton.val == 'a'
    test_not_singleton = TestNotSingleton('b')
    assert test_not_singleton.val == 'b'

    assert test_singleton is TestSingleton('c')
    assert test_not_singleton is not TestNotSingleton('d')


# Generated at 2022-06-25 13:36:13.952707
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def test(self, arg):
            return arg

    try:
        at = TestClass()
        assert at.test('chang') == 'chang'
        assert at.test('chang') == 'chang'
        assert at.test('li') == 'li'
        assert at.test('li') == 'li'
    except Exception as e:
        assert 0, 'Uncaught exception: %s' % e



# Generated at 2022-06-25 13:36:23.770689
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # create a singleton class using Singleton
    class TestSingleton(object):
        __metaclass__ = Singleton
        
        # init is called when the singleton constructor is called
        # we use it to set the redis connection
        def __init__(self):
            self.redis_connection = 'default'

        def get_redis(self):
            return self.redis_connection

        def set_redis(self, redis_connection):
            self.redis_connection = redis_connection

    # instantiate the singleton
    singleton_instance = TestSingleton()
    singleton_instance.set_redis('new ip')

    # instantiate the class the second time
    singleton_instance_2 = TestSingleton()
    
    assert singleton_instance is singleton_instance_2
   

# Generated at 2022-06-25 13:36:26.284675
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self, arg):
            self.arg = arg

    test1 = Test('test')
    test2 = Test('another test')
    assert test1 is test2
    assert test1.arg == 'another test'



# Generated at 2022-06-25 13:36:34.923920
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert id(Singleton) == id(Singleton)



# Generated at 2022-06-25 13:36:39.527579
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass (with_metaclass(Singleton, object)):
        def __init__(self):
            self.x = "You got a singleton!"

    instance1 = TestClass()
    instance2 = TestClass()

    assert instance1 == instance2
    assert instance1.x == instance2.x


# Generated at 2022-06-25 13:36:44.993936
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        def __int__(self):
            pass
    class TestNonSingleton:
        def __init__(self):
            pass
    instance_1 = TestSingleton()
    instance_2 = TestSingleton()
    assert instance_1 is instance_2

    instance_3 = TestSingleton()
    instance_4 = TestNonSingleton()
    assert instance_3 is instance_4

# Generated at 2022-06-25 13:36:53.793044
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import random

    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x=None):
            self.x = x
            # for simplifying print
            self.__class__.__name__ = "A"

    # ensure every A() returns the same instance
    a0 = A(0)
    a1 = A(1)
    assert a1 == a0, "a1 == a0?"
    a2 = A(2)
    assert a2 == a1, "a2 == a1?"
    a3 = A(3)
    assert a3 == a2, "a3 == a2?"

    # ensure parallel instance creation is locked
    A.__instance = None
    threads = []


# Generated at 2022-06-25 13:36:56.702943
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(metaclass=Singleton):
        def __init__(self):
            pass

    assert isinstance(TestSingleton(), TestSingleton)

# Generated at 2022-06-25 13:36:59.545336
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    instance_1 = Foo()
    instance_2 = Foo()

    assert(instance_1 is instance_2)



# Generated at 2022-06-25 13:37:08.222725
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, string):
            self.string = string

        def __eq__(self, other):
            return self.string == other.string

    assert A("a") == A("a")

    a1 = A("a")
    a2 = A("a")
    b1 = A("b")
    b2 = A("b")

    assert a1 == a2
    assert a1 is a2
    assert b1 == b2
    assert b1 is b2

    assert a1 == b1
    assert a1 is b1

# Generated at 2022-06-25 13:37:13.360460
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 0

    test_singleton = TestSingleton()
    test_singleton_2 = TestSingleton()

    assert id(test_singleton) == id(test_singleton_2)
    assert test_singleton is test_singleton_2

    test_singleton.x = 5
    assert test_singleton.x == test_singleton_2.x

# Generated at 2022-06-25 13:37:23.025578
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingletonError(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            """
            Class constructor.
            """
            self.a = a


# Generated at 2022-06-25 13:37:25.114631
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):

        def __init__(self):
            pass

    instance = A()
    assert instance == A()

# Generated at 2022-06-25 13:37:49.665625
# Unit test for constructor of class Singleton
def test_Singleton():
    # Test case 1
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    class Test2(object):
        __metaclass__ = Singleton

        def __init__(self, b):
            self.b = b

    test = Test(1)
    test2 = Test2(2)
    assert id(test) == id(Test(1))
    assert id(test2) == id(Test2(2))


# Generated at 2022-06-25 13:37:51.497119
# Unit test for constructor of class Singleton
def test_Singleton():
    class t(object):
        __metaclass__ = Singleton

    assert id(t()) == id(t())
    assert id(t()) != id(t("a"))

# Generated at 2022-06-25 13:37:55.111238
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 'test'

    obj1 = TestSingleton()
    obj2 = TestSingleton()

    assert obj1.val == obj2.val
    assert obj1 == obj2

# Generated at 2022-06-25 13:37:56.053846
# Unit test for constructor of class Singleton
def test_Singleton():
    s = Singleton()
    assert isinstance(s, Singleton)


# Generated at 2022-06-25 13:37:58.002566
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class T(object):
        __metaclass__ = Singleton

    t1 = T()
    t2 = T()
    assert t1 is t2


# Generated at 2022-06-25 13:38:00.549647
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    obj1 = MyClass()
    obj2 = MyClass()
    assert obj1 is obj2

# Generated at 2022-06-25 13:38:03.270481
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(metaclass=Singleton):
        pass

    a = TestClass()
    b = TestClass()

    assert a is b
    return a, b

# Generated at 2022-06-25 13:38:11.189626
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from abc import ABCMeta, abstractmethod

    class Base(object):
        __metaclass__ = ABCMeta

        @abstractmethod
        def test(self):
            pass

    class Derived(Base):
        __metaclass__ = Singleton

        def __init__(self):
            print(id(self))

        def test(self):
            print("Test done!")
            return True

    # Testing if test method is really implemented
    derived = Derived()
    derived.test()

    # Testing if instance is singleton
    derived2 = Derived()
    assert(derived.test() == True)
    assert(derived2.test() == True)
    assert(id(derived) == id(derived2))

# Generated at 2022-06-25 13:38:12.587101
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()



# Generated at 2022-06-25 13:38:14.298755
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

    a = MySingleton()
    b = MySingleton()
    assert a is b

# Generated at 2022-06-25 13:38:48.467852
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    assert(A() == A())
    assert(id(A()) == id(A()))


# Generated at 2022-06-25 13:38:49.763327
# Unit test for constructor of class Singleton
def test_Singleton():
    obj = Singleton('Test', bases=(), dct={})


# Generated at 2022-06-25 13:38:57.503221
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    class Bar(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    foo1 = Foo(1)
    foo2 = Foo(2)
    assert foo1 is foo2
    assert foo1.a == 1
    assert foo2.a == 1

    bar1 = Bar(1, 2)
    bar2 = Bar(2, 3)
    assert bar1 is bar2
    assert bar1.a == 1 and bar1.b == 2
    assert bar2.a == 1 and bar2.b == 2


# Generated at 2022-06-25 13:39:07.863049
# Unit test for constructor of class Singleton
def test_Singleton():
    from io import StringIO
    class MySingle(metaclass=Singleton):
        def __init__(self):
            self.value = 1

    class MyNonSingle:
        def __init__(self):
            self.value = 1

    single = MySingle()
    another_single = MySingle()
    assert single is not None
    assert single is another_single
    single.value = 2
    assert single.value == another_single.value

    non_single = MyNonSingle()
    another_non_single = MyNonSingle()
    assert non_single is not None
    assert non_single is not another_non_single
    non_single.value = 3
    assert non_single.value != another_non_single.value

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:39:16.565483
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    #
    # Single Instance created
    #

    class A(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.foo == 1
    assert a2.foo == 1

    #
    # Subclass single instance created
    #

    class B(A):
        pass

    b1 = B(1)
    b2 = B(2)
    assert b1 is b2
    assert b1.foo == 1
    assert b2.foo == 1

    class C(A):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo


# Generated at 2022-06-25 13:39:21.732473
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton
        def __init__(self, a=None, b=None):
            self.a = a
            self.b = b
            self.c = 'c'

    # Create 2 Foo instances
    foo1 = Foo(1, 2)
    foo2 = Foo(3)

    # Verify both instances are the same
    assert foo1 == foo2

    # Make sure foo1 and foo2 have the same attributes
    assert foo1.a == foo2.a
    assert foo1.b == foo2.b
    assert foo1.c == foo2.c

# Generated at 2022-06-25 13:39:24.227936
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    s1 = TestSingleton()
    s2 = TestSingleton()
    assert s1 is s2

# Generated at 2022-06-25 13:39:27.337527
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-25 13:39:31.480809
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    assert A() is A()
    assert A() is A()


if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == 'test':
        test_Singleton()

# Generated at 2022-06-25 13:39:34.002589
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    a = Foo()
    b = Foo()

    assert a is b



# Generated at 2022-06-25 13:40:02.133458
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    # Constructor call on class Singleton with arguments: ('Test', (), {})
    str_1 = 'Test'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)

    # AssertionError: {} != ()
    assert var_3 != var_2
    # AssertionError: {} != {}
    assert var_3 != var_1
    # AssertionError: () != ()
    assert var_2 != var_0
    # AssertionError: 'Test' != 'Test'
    assert str_1 != str_0

# Generated at 2022-06-25 13:40:03.946234
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    args = ()
    kwargs = {}
    assert Singleton()(args, kwargs) is None


# Generated at 2022-06-25 13:40:07.657755
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    # Test Call
    # args#0
    var_0 = ''
    var_1 = ()
    var_2 = {}
    singleton_0 = Singleton(var_0, var_1, var_2)
    singleton_1 = Singleton(var_0, var_1, var_2)

# Generated at 2022-06-25 13:40:10.903093
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    list_0 = list()
    list_0.append({'a': 'a'})
    str_0 = 'test'
    var_0 = (list_0, str_0)
    var_1 = {}
    singleton_0 = Singleton(var_0, var_0, var_1)


# Generated at 2022-06-25 13:40:13.543809
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_0 = None
    singleton_0 = singleton_0(str_0)


# Generated at 2022-06-25 13:40:18.200036
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'Foo'
    singleton_1 = Singleton(str_1, var_0, var_1)
    assert(singleton_0 is not None)
    assert(singleton_0 is singleton_1)

# Generated at 2022-06-25 13:40:20.998379
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:40:24.772223
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    obj_0 = singleton_0()
    obj_1 = singleton_0()
    assert obj_0 == obj_1

# Generated at 2022-06-25 13:40:29.077352
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_1 = Singleton(str_0, var_0, var_1)
    singleton_1_call = singleton_1()
    assert isinstance(singleton_1_call, type)
    assert singleton_1_call.__name__ == str_0

# Generated at 2022-06-25 13:40:32.389468
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_2 = object()
    singleton_0 = Singleton()
    singleton_1 = Singleton()
    assert singleton_0.__instance == var_2
    assert singleton_1.__instance == var_2


# Generated at 2022-06-25 13:41:24.928354
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from Singleton import Singleton
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__instance = 'foo'
    var_2 = singleton_0()
    assert var_2 == 'foo'



# Generated at 2022-06-25 13:41:28.739986
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = Singleton(str_0, var_0, var_1)
    print(singleton_0 is singleton_1)

# Generated at 2022-06-25 13:41:31.993881
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0(False, )
    singleton_0(True, )


# Generated at 2022-06-25 13:41:36.357014
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        str_0 = 'Test'
        var_0 = ()
        var_2 = {}
        singleton_0 = Singleton(str_0, var_0, var_2)
        var_1 = singleton_0.__call__('A', 'B', 'C')
        assert id(var_1) == id(singleton_0.__instance)
    except Exception as e:
        print(e)

# Generated at 2022-06-25 13:41:41.114789
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0_instance_0 = singleton_0()
    str_1 = 'Test'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    singleton_1_instance_0 = singleton_1()
    assert singleton_1_instance_0 == singleton_0_instance_0


# Generated at 2022-06-25 13:41:44.502975
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__(var_0, **var_1)


# Generated at 2022-06-25 13:41:49.283416
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print('Testing __call__')
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    obj_0 = singleton_0(str_0, var_0, var_1)
    assert obj_0 == singleton_0(str_0, var_0, var_1)

# Generated at 2022-06-25 13:41:51.788927
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton('Test', var_0, var_1)
    singleton_0.__call__()


# Generated at 2022-06-25 13:41:52.573469
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True

# Generated at 2022-06-25 13:41:56.041699
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_1 = 'Test'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    try:
        singleton_1.__call__()
    except TypeError:
        assert True
        return
    assert False



# Generated at 2022-06-25 13:42:56.265167
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0()


# Generated at 2022-06-25 13:42:59.049497
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Use the Singleton class to create a singleton object,
    # then verify that two separate references are actually
    # the same instance.
    singleton_0 = Singleton()
    singleton_1 = Singleton()
    assert singleton_0 is singleton_1


# Generated at 2022-06-25 13:43:00.682242
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  try:
    test_case_0()
  except Exception as e:
    print(e)
    assert False
  else:
    assert True

# Generated at 2022-06-25 13:43:05.089797
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0()
    var_3 = singleton_1()

    assert var_2 is var_3, 'Locks not working as expected'
    assert var_2 == var_3, 'Instance created multiple times'


# Generated at 2022-06-25 13:43:07.099448
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_1 = Singleton(str_0, var_0, var_1)
    singleton_1()


# Generated at 2022-06-25 13:43:10.318926
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    try:
        var_2 = __call__(singleton_0, ())
    except:
        var_2 = None

# Generated at 2022-06-25 13:43:15.865039
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()
    singleton_0.__call__()
    singleton_0.__call__()
    singleton_0.__call__()
    singleton_0.__call__()
    singleton_0.__call__()
    singleton_0.__call__()
    singleton_0.__call__()
    singleton_0.__call__()


# Generated at 2022-06-25 13:43:20.750724
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Test'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = Singleton(str_0, var_0, var_1)
    if not singleton_1 is singleton_0:
        raise RuntimeError("Singleton.Test failed")


# Generated at 2022-06-25 13:43:26.330560
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_1 = 'Test'
    var_2 = ()
    var_3 = {}
    # __call__ is a method of class Singleton
    singleton_1 = Singleton(str_1, var_2, var_3)
    assert singleton_1('b', 'a') == singleton_1('b', 'a')
    assert not singleton_1('b', 'a') is singleton_1('b', 'a')

# Generated at 2022-06-25 13:43:27.485238
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert Singleton.__call__ is Singleton.__call__