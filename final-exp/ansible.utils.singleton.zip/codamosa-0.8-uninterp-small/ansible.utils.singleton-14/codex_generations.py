

# Generated at 2022-06-25 13:34:27.716100
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_1 = "Z"
    dict_0 = {str_1: str_1, str_1: str_1}
    dict_1 = {dict_0: dict_0}
    dict_1 = {dict_0: dict_0, dict_0: dict_0, dict_0: dict_1}
    str_0 = ")h\x1c\xe2o\x04"
    dict_0 = {dict_1: dict_1, dict_1: dict_1, str_0: str_0, dict_0: dict_1}
    dict_0 = {dict_0: dict_1, dict_0: dict_0}
    dict_0 = {dict_0: dict_0, dict_0: dict_0, dict_1: dict_0, dict_1: dict_0}

# Generated at 2022-06-25 13:34:32.596065
# Unit test for constructor of class Singleton
def test_Singleton():
    #Testing for call type 1
    assert Singleton.__instance is None
    assert Singleton.__rlock is not None
    #Testing for call type 2
    try:
        assert isinstance(Singleton.__instance, Singleton)
    except AssertionError as ae:
        print("AssertionError: ", ae)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:34:43.515596
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = ''
    dict_0 = {str_0: str_0, str_0: str_0}
    class_0 = Singleton('', (), dict_0)
    str_1 = '^#cQ\x0b\x0b3\x0b'
    dict_1 = {class_0: str_0, class_0: class_0, str_1: str_0, class_0: str_1}
    class_1 = Singleton('', (), dict_1)
    class_2 = Singleton('', (), dict_1)
    assert class_1.__instance == class_2.__instance
    assert type(class_1.__instance) == type(class_2.__instance)


# Generated at 2022-06-25 13:34:45.143685
# Unit test for constructor of class Singleton
def test_Singleton():
    var = Singleton()
    print(type(var))
    print(type(var))


# Generated at 2022-06-25 13:34:47.614531
# Unit test for constructor of class Singleton
def test_Singleton():
  Singleton()

if __name__ == "__main__":
  test_case_0()
  test_Singleton()

# Generated at 2022-06-25 13:34:51.008010
# Unit test for constructor of class Singleton
def test_Singleton():
    # initialize and check if the class singleton is implemented correctly
    # test_case_0() and test_case_1 have been commented temporarly as they are not supported
    # by the current version of the compiler
    # Singleton()
    return


# Generated at 2022-06-25 13:34:55.570723
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        ansible.module_utils.basic.AnsibleModule.exit_json()
        ansible.module_utils.basic.AnsibleModule.exit_json()
        ansible.module_utils.basic.AnsibleModule.exit_json()
    except Exception:
        pass
    finally:
        pass


# Generated at 2022-06-25 13:35:01.957151
# Unit test for constructor of class Singleton
def test_Singleton():

    # Find and delete Singleton.__init__.pyc, to avoid false positive on next import
    try:
        os.remove('Singleton.__init__.pyc')
    except OSError as e:
        if os.path.exists('Singleton.__init__.pyc'):
            raise Exception("Failed to remove Singleton.__init__.pyc, error was: " + str(e))

    # __init__()
    assert Singleton.__init__ is Singleton.__init__

    # Set up test variables
    try:
        __temp = Singleton
    except:
        Singleton = Singleton

    __temp = Singleton

    cls_0 = None
    name_0 = None
    bases_0 = None
    dct_0 = None

    # Call the __init__


# Generated at 2022-06-25 13:35:03.688599
# Unit test for constructor of class Singleton
def test_Singleton():
    singleton_class = Singleton('SingletonClass', (), {})
    assert singleton_class


# Generated at 2022-06-25 13:35:04.556189
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:35:06.936243
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True


# Generated at 2022-06-25 13:35:10.844494
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__instance = 'SingletonClass'
    singleton_1 = singleton_0()


# Generated at 2022-06-25 13:35:12.385058
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # TODO: Add test cases for method __call__ of class Singleton
    raise NotImplementedError


# Generated at 2022-06-25 13:35:20.218326
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    # AssertionError raised when __call__ called with no args and
    # __instance not None.
    try:
        test_case_0()
    except Exception as e:
        print("AssertionError: %s" % e)

    # AssertionError raised when __call__ called with args and
    # __instance not None.
    try:
        test_case_1()
    except Exception as e:
        print("AssertionError: %s" % e)

    # AssertionError raised when __call__ called with args and
    # __instance not None.
    try:
        test_case_2()
    except Exception as e:
        print("AssertionError: %s" % e)

    # AssertionError raised when __call__ called with args and
    # __instance not None.


# Generated at 2022-06-25 13:35:22.403318
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:35:27.060411
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {'__module__': 'SingletonClass', '__qualname__': 'SingletonClass', '__doc__': None}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = Singleton.__call__(singleton_0, ())
    assert singleton_0 == singleton_1


# Generated at 2022-06-25 13:35:28.912767
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)

# Generated at 2022-06-25 13:35:33.557186
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # if cls.__instance is not None:
    #     return cls.__instance
    #
    # with cls.__rlock:
    #     if cls.__instance is None:
    #         cls.__instance = super(Singleton, cls).__call__(*args, **kw)
    #
    # return cls.__instance
    pass


# Generated at 2022-06-25 13:35:36.695335
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
   str_0 = 'SingletonClass'
   var_0 = ()
   var_1 = {}
   singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:35:40.982624
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test to verify that Singleton __call__() works
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    var_2 = Singleton(str_0, var_0, var_1)
    var_3 = var_2()
    return isinstance(var_3, Singleton)


print('Test case 0: ', test_Singleton___call__())

# Generated at 2022-06-25 13:35:48.002413
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        str_0 = 'SingletonClass'
        var_0 = ()
        var_1 = {}
        singleton_0 = Singleton(str_0, var_0, var_1)
        singleton_0 = None
    except Exception as inst:
        print('Exception %s caught' % inst)
    else:
        raise


# Generated at 2022-06-25 13:35:51.671871
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = ()
    var_3 = {}
    singleton_0.__call__(var_2, *var_3)

# Generated at 2022-06-25 13:35:58.212118
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    str_1 = 'test_Singleton___call__'
    var_2 = ()
    var_3 = {}
    var_4 = None

    def func_0():
        nonlocal var_4
        var_4 = test_case_0()

    func_0()
    var_5 = var_4
    assert var_5.__instance != None
    var_5.__instance = None
    var_6 = var_5.__instance
    assert var_6 is None
    singleton_1 = Singleton(str_0, var_0, var_1)
    var_7 = var_5.__instance
    assert var_7 != None
    var_8 = var_7

# Generated at 2022-06-25 13:36:03.847720
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = singleton_0()
    var_2 = singleton_0()
    var_3 = singleton_1
    assert_true(var_3, 'arg_0')


# Generated at 2022-06-25 13:36:11.510420
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_1 = Singleton(str_1, var_0, var_1)
    singleton_1.__call__()
    assert id(singleton_0) == id(singleton_1)


# Generated at 2022-06-25 13:36:15.049125
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create an instance of the Singleton class
    singleton_0 = Singleton(0)
    # Call the __call__ method of the Singleton class
    singleton_0.__call__(0)


# Generated at 2022-06-25 13:36:19.453854
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = ()
    var_3 = {}
    singleton_1 = singleton_0(var_2, var_3)
    assert False

# Generated at 2022-06-25 13:36:28.035740
# Unit test for method __call__ of class Singleton

# Generated at 2022-06-25 13:36:31.420642
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = ()
    var_3 = {}
    singleton_0.__call__(*var_2, **var_3)

# Generated at 2022-06-25 13:36:34.374877
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0()


# Generated at 2022-06-25 13:36:37.989216
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert False


# Generated at 2022-06-25 13:36:42.604143
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__instance = None
    singleton_0.__rlock = RLock()
    singleton_0.__call__()



# Generated at 2022-06-25 13:36:45.127381
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)

# Generated at 2022-06-25 13:36:48.339272
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  from thespian.actors import ActorSystem
  actor = ActorSystem()
  var_0 = False
  if (actor == actor):
    var_0 = True
  assert var_0
  # assert actor.__instance == actor


# Generated at 2022-06-25 13:36:53.792606
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    print('%s %s' % (singleton_0, singleton_1))


# Generated at 2022-06-25 13:36:59.810907
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """A test for Singleton metaclass __call__() method.
    """
    str_0 = 'AnotherSingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)

    singleton_1 = singleton_0()
    singleton_2 = singleton_0()

    assert singleton_1 is singleton_2

# Generated at 2022-06-25 13:37:05.843563
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    singleton_0(singleton_1)


# Generated at 2022-06-25 13:37:10.655251
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)

# Generated at 2022-06-25 13:37:11.105526
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-25 13:37:11.785841
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass



# Generated at 2022-06-25 13:37:17.907177
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    v_0 = type('SingletonClass', (), {})
    m_0 = Singleton('SingletonClass', (), {})
    v_1 = m_0(v_0)
    assert v_1 == v_1


# Generated at 2022-06-25 13:37:25.543944
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a dummy test class
    class TestSingletonClass(object):
        __metaclass__ = Singleton

    # Create two instances
    instance_1 = TestSingletonClass()
    instance_2 = TestSingletonClass()

    # Test that the instances are equal
    assert instance_1 is instance_2

    # Test that changing the value of instance_1 does not change the value of instance_2
    # due to the Singleton metaclass
    instance_1.value = "test"
    assert instance_2.value == "test"

    instance_1.value = "different test"
    assert instance_2.value != "different test"

# Generated at 2022-06-25 13:37:26.196046
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()


# Generated at 2022-06-25 13:37:28.427273
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:37:30.824476
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)

# test for __init__

# Generated at 2022-06-25 13:37:32.568347
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'test_Singleton___call__'

    obj_0 = Singleton(str_0)

    assert(obj_0(1) == obj_0(2))



# Generated at 2022-06-25 13:37:40.604930
# Unit test for method __call__ of class Singleton

# Generated at 2022-06-25 13:37:45.336905
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'test_Singleton___call__'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    class_0 = singleton_0.__call__()
    assert class_0 != None

# Generated at 2022-06-25 13:37:48.667608
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_2 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_2 = Singleton(str_2, var_2, var_3)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 13:37:51.491219
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()


# Generated at 2022-06-25 13:37:57.696301
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = singleton_0('first call')
    singleton_2 = singleton_0('second call')
    assert singleton_1 is singleton_2

# Generated at 2022-06-25 13:38:02.241594
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = ()
    singleton_1 = singleton_0(*var_2,)
    assert singleton_1 is not None


# Generated at 2022-06-25 13:38:09.817304
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert singleton_0.__call__() == None
    assert singleton_0.__call__() == None
    assert singleton_0.__call__() == None
    str_1 = 'SingletonClass0'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    assert singleton_1.__call__() == None


# Generated at 2022-06-25 13:38:10.647503
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass


# Generated at 2022-06-25 13:38:14.800716
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = ''
    var_2 = ()
    var_3 = {}
    singleton_1 = singleton_0(str_1, var_2, var_3)
    assert singleton_1.__instance == None

# Generated at 2022-06-25 13:38:16.446577
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)

# Generated at 2022-06-25 13:38:20.156540
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    var_4 = singleton_0()

    assert var_4 == singleton_1()


# Generated at 2022-06-25 13:38:28.443338
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = ()
    var_3 = {}
    singleton_0.__call__(var_2, var_3)
    str_1 = 'SingletonClass'
    var_4 = ()
    var_5 = {}
    singleton_1 = Singleton(str_1, var_4, var_5)
    var_6 = ()
    var_7 = {}
    singleton_1.__call__(var_6, var_7)
    str_2 = 'SingletonClass'
    var_8 = ()
    var_9 = {}

# Generated at 2022-06-25 13:38:33.186156
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass.__call__'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = singleton_0()
    singleton_2 = singleton_0()
    assert(singleton_1.__instance == singleton_2.__instance)


# Generated at 2022-06-25 13:38:34.014952
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()


# Generated at 2022-06-25 13:38:41.487674
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'

    # Instantiate Singleton
    singleton_0 = Singleton(str_0, (), {})

    # TODO: assert if singleton_0 is a Singleton instance.
    assert isinstance(singleton_0, Singleton)
    str_1 = 'SingletonClass'
    var_0 = (str_1, (), {})
    singleton_0 = singleton_0(*var_0)
    assert isinstance(singleton_0, Singleton)

# Generated at 2022-06-25 13:38:49.508086
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    result = singleton_0.__call__() == singleton_1.__call__()
    assert result == True


# Generated at 2022-06-25 13:38:57.598840
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = str_2 + str_0
    str_3 = str_3 + str_2
    str_3 = str_3 + str_0
    str_3 = str_3 + str_1
    str_3 = str_3 + str_2
    str_3 = str_3 + str_2
    str_3 = str_3 + str_1
    str_3 = str_3 + str_1
    str_3 = str_3 + str_2
    str_3 = str_3 + str_0
    str_3 = str_3 + str_0
    str_3 = str_3 + str_2
    str_3 = str_3 + str_2
    str_

# Generated at 2022-06-25 13:39:01.532583
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__class__

# Generated at 2022-06-25 13:39:04.347208
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        test_case_0()
    except NameError as error:
        print(error)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:39:08.061601
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = singleton_0('SingletonClass')


# Generated at 2022-06-25 13:39:12.162368
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = ()
    var_3 = {}
    singleton_0.__call__(*var_2, **var_3)

# Generated at 2022-06-25 13:39:15.431379
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert singleton_0('test') != None


# Generated at 2022-06-25 13:39:17.980617
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()


# Generated at 2022-06-25 13:39:19.830234
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)

# Generated at 2022-06-25 13:39:22.978702
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    pass

# Generated at 2022-06-25 13:39:25.689422
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:39:28.802672
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:39:31.316909
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
  ansible_module_0 = Singleton()
  ansible_module_1 = Singleton()
  assert ansible_module_0 is ansible_module_1


# Generated at 2022-06-25 13:39:37.610061
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    var_4 = ()
    var_5 = {}
    singleton_2 = singleton_1.__call__(var_4, var_5)
    var_6 = singleton_1
    var_7 = singleton_2
    var_8 = var_6 is var_7
    _test_singleton___call__(var_8)


# Generated at 2022-06-25 13:39:40.882164
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__instance = None
    var_2 = ()
    var_3 = {}
    var_4 = singleton_0(*var_2, **var_3)
    assert singleton_0.__instance == var_4


# Generated at 2022-06-25 13:39:43.866994
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = ()
    var_3 = {}
    singleton_0.__call__(var_2, var_3)


# Generated at 2022-06-25 13:39:48.112158
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_0 = Singleton(str_0, var_2, var_3)
    str_1 = 'SingletonClass'
    var_4 = ()
    var_5 = {}
    singleton_1 = Singleton(str_1, var_4, var_5)
    assert True

# Generated at 2022-06-25 13:39:54.476844
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = '<class \'tests.unit.meta.test_meta.TestClass\'>'
    str_1 = 'TEST_CLASS_INSTANCE'
    str_2 = 'TEST_CLASS_INSTANCE'
    str_3 = 'TEST_CLASS_INSTANCE'
    var_0 = ()
    var_1 = {}
    obj_0 = Singleton(str_0, var_0, var_1)
    obj_1 = obj_0(str_1)
    obj_2 = obj_0(str_2)
    obj_3 = obj_0(str_3)
    assert obj_1 is obj_2
    assert obj_1 is obj_3


# Generated at 2022-06-25 13:39:59.880000
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    tuple_0 = ()
    dict_0 = {}
    bool_0 = singleton_0.__call__(*tuple_0, **dict_0)
    assert bool_0
    assert singleton_0


# Generated at 2022-06-25 13:40:08.957494
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = Singleton(str_0, var_0, var_1)
    assert singleton_0 == singleton_1

# Generated at 2022-06-25 13:40:11.858504
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = singleton_0()
    assert(singleton_0 is singleton_1)


# Generated at 2022-06-25 13:40:13.684874
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:40:22.617000
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from collections import OrderedDict
    from ansible.module_utils.hashivault import hashivault_argspec

    dict_0 = OrderedDict()
    dict_0['required'] = False
    dict_0['type'] = 'dict'
    dict_0['options'] = {}

    dict_1 = OrderedDict()
    dict_1['required'] = False
    dict_1['type'] = 'dict'

# Generated at 2022-06-25 13:40:25.706913
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert singleton_0 is not None

# Generated at 2022-06-25 13:40:34.718927
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create mock object of Singleton class
    mock_Singleton_class = SingletonType()

    # Mock object with value 'abc'
    mock_Singleton_object = SingletonType()
    mock_Singleton_object.__instance = 'abc'

    # Mock object with value '123'
    mock_args = SingletonType()
    mock_args.__instance = '123'

    # Mock global variable
    global mock_rlock
    mock_rlock = SingletonType()
    mock_rlock.__rlock = None

    # Set return value of the mock_rlock object
    mock_rlock.acquire = Mock(return_value=None)
    mock_rlock.acquire.__name__ = 'acquire'

    # Assign global variable mock_rlock to rlock
    rlock = mock_r

# Generated at 2022-06-25 13:40:37.545144
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    the_class = Singleton
    the_instance = the_class(name='some name', bases=(), dct={})
    Singleton.__instance = None
    the_instance()
    value = the_instance().__class__
    assert value.__name__ == 'Singleton'


# Generated at 2022-06-25 13:40:41.313651
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = Singleton(str_0, var_0, var_1)
    assert singleton_0 == singleton_1


# Generated at 2022-06-25 13:40:44.339035
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()


# Generated at 2022-06-25 13:40:50.927079
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0._Singleton__rlock.acquire(True)
    if singleton_0._Singleton__instance is None:
        singleton_0._Singleton__instance = super(Singleton, singleton_0).__call__()
    assert(singleton_1._Singleton__instance is singleton_0._Singleton__instance)
    singleton_0._Singleton__rlock.release()



# Generated at 2022-06-25 13:41:02.083462
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = Singleton(str_0, var_0, var_1)
    assert id(singleton_0) == id(singleton_1)

# Generated at 2022-06-25 13:41:04.972359
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_2 = ()
    var_3 = {}
    var_4 = Singleton()
    var_5 = var_4.__call__(*var_2, **var_3)


# Generated at 2022-06-25 13:41:07.982720
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)


# Generated at 2022-06-25 13:41:14.435168
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'ClassInstance'
    var_2 = ()
    var_3 = {}
    instance_0 = singleton_0(str_1, var_2, var_3)
    assert instance_0 == singleton_0.__instance
    instance_1 = singleton_0(str_1, var_2, var_3)
    assert instance_1 == singleton_0.__instance


# Generated at 2022-06-25 13:41:18.244779
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """
    Assert that only one instance of class exists.
    """
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    print(singleton_0)


# Generated at 2022-06-25 13:41:23.316215
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = ()
    var_3 = {}
    var_4 = singleton_0(*var_2, **var_3)


# Generated at 2022-06-25 13:41:26.663432
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0 = singleton_0()
    assert isinstance(singleton_0, Singleton)


# Generated at 2022-06-25 13:41:30.348681
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = Singleton.__call__(str_0, var_0, var_1)

# Generated at 2022-06-25 13:41:33.360546
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    var_0 = {}
    singleton_0 = Singleton(__name__, (), var_0)
    assert singleton_0.__call__(0) == singleton_0.__instance
    assert singleton_0.__call__(0) is not None


# Generated at 2022-06-25 13:41:34.166234
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()

# Generated at 2022-06-25 13:41:43.072718
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0()
    pass

# Generated at 2022-06-25 13:41:44.898096
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    try:
        singleton_0 = Singleton()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 13:41:53.406995
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from ansible_collections.ansible.community.plugins.module_utils.network.common.utils.singleton import Singleton
    from mock import MagicMock

    class SingletonClass:
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    obj = SingletonClass(1, 2)
    assert obj.a == 1
    assert obj.b == 2

    obj_1 = SingletonClass(1, 2)
    assert obj == obj_1
    assert obj_1.a == 1
    assert obj_1.b == 2

    obj_2 = SingletonClass(10, 20)
    assert obj == obj_2
    assert obj_2.a == 10
    assert obj_2.b == 20


# Unit test

# Generated at 2022-06-25 13:41:56.825953
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = singleton_0()
    assert singleton_1 == singleton_0


# Generated at 2022-06-25 13:41:59.359596
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__call__()

# Generated at 2022-06-25 13:42:00.724349
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    a = Singleton.__call__(1, 2, 3)
    print(a)


# Generated at 2022-06-25 13:42:04.216862
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    int_0 = 0
    var_2 = 1
    var_3 = -var_2
    assert int_0 == var_3


# Generated at 2022-06-25 13:42:05.267059
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()
    return
# Testing of Singleto


# Generated at 2022-06-25 13:42:06.008804
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert callable(Singleton.__call__)

# Generated at 2022-06-25 13:42:08.834400
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = singleton_0()


# Generated at 2022-06-25 13:42:18.716656
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = singleton_0()
    var_3 = singleton_0()
    assert var_2 == var_3, \
        '''Expected {} to be equal to {}'''.format(var_2, var_3)


# Generated at 2022-06-25 13:42:19.608009
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create Singleton object
    singleton_0 = Singleton()

    # Call method __call__ of object singleton_0
    singleton_0.__call__()

# Generated at 2022-06-25 13:42:20.934448
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0()


# Generated at 2022-06-25 13:42:26.957764
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from random import randint, random
    from copy import copy
    from sys import version_info

    var_0 = randint(1, 100)
    var_1 = random()
    #
    # Python 2 only
    #
    if version_info[0] < 3:
        var_2 = unicode('')
    else:
        var_2 = str('')
    str_0 = str('')
    var_3 = randint(1, 100)
    var_4 = random()
    var_5 = {}
    var_6 = randint(1, 100)
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = {}
    var_11 = {}
    var_12 = {}
    var_13 = {}
    var_14 = {}

# Generated at 2022-06-25 13:42:35.709937
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    if singleton_0.__instance is not None:
        var_2 = singleton_0.__instance
    else:
        singleton_0.__rlock.acquire()
        if singleton_0.__instance is None:
            var_3 = super(Singleton, singleton_0)
            var_2 = var_3.__call__()
            var_2
        else:
            var_2 = singleton_0.__instance
        singleton_0.__rlock.release()
    var_4 = var_2


# Generated at 2022-06-25 13:42:39.366621
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'Singleton'
    var_0 = ()
    var_1 = {}
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton = Singleton(str_0, var_0, var_1)
    singleton_0 = Singleton(str_1, var_2, var_3)

# Generated at 2022-06-25 13:42:45.556454
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)

    # Return singleton_0 if an instance has already been instantiated
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    singleton_1.__instance = singleton_0
    singleton_1.__call__()
    # Return singleton_1 if it has not been instantiated
    singleton_1.__instance = None
    obj_0 = singleton_1.__call__()

    pass

# Generated at 2022-06-25 13:42:45.948560
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert True



# Generated at 2022-06-25 13:42:49.046194
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    var_2 = ()
    var_3 = {}
    assert singleton_0.__call__(*var_2, **var_3)


# Generated at 2022-06-25 13:42:51.324831
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert singleton_0.__call__(singleton_0) == singleton_0.__instance


# Generated at 2022-06-25 13:43:03.937323
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert False

# Generated at 2022-06-25 13:43:06.693635
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    assert (singleton_0 is singleton_1)

# Generated at 2022-06-25 13:43:11.631162
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test case 1
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = singleton_0()
    # Test case 2
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_2 = Singleton(str_1, var_2, var_3)
    singleton_3 = singleton_2()
    # Test case 3
    str_2 = 'SingletonClass'
    var_4 = ()
    var_5 = {}
    singleton_4 = Singleton(str_2, var_4, var_5)
    singleton_5 = singleton_4()
    # Test case

# Generated at 2022-06-25 13:43:13.594726
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # This test cannot be run and is for coverage only
    test_case_0()

# Generated at 2022-06-25 13:43:17.313801
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert 'SingletonClass' == singleton_0.__name__

if __name__ == "__main__":
    test_case_0()
    test_Singleton___call__()

# Generated at 2022-06-25 13:43:20.949279
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert singleton_0() != None, None


# Generated at 2022-06-25 13:43:21.732175
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test failure
    pass



# Generated at 2022-06-25 13:43:29.465922
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    class A(object):
        __metaclass__ = singleton_0

    A()
    B = A()
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    class B(object):
        __metaclass__ = singleton_1

    C = B()
    C


# Generated at 2022-06-25 13:43:32.427680
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_1 = 'SingletonClass'
    var_2 = ()
    var_3 = {}
    singleton_1 = Singleton(str_1, var_2, var_3)
    singleton_1()


# Generated at 2022-06-25 13:43:36.269253
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    method___call__ = singleton_0.__call__

    print('\n---- Unit test for method __call__ of class Singleton ----')
    print('This method is not unit testable!')



# Generated at 2022-06-25 13:43:49.760230
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    singleton_0 = Singleton.__call__()
    assert isinstance(singleton_0, Singleton)


# Generated at 2022-06-25 13:43:50.394987
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert False


# Generated at 2022-06-25 13:43:51.391021
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    test_case_0()


if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:43:54.735074
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'string'
    singleton_0 = Singleton(str_0)
    singleton_1 = singleton_0()
    assert singleton_1 == singleton_0
    singleton_2 = singleton_0()
    assert singleton_2 == singleton_0
    assert singleton_1 == singleton_2


# Generated at 2022-06-25 13:43:55.711021
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert 'SingletonClass'.__call__(var_0, var_1) != None


# Generated at 2022-06-25 13:43:57.460162
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_1 = singleton_0()
    assert singleton_0 is singleton_1

# Generated at 2022-06-25 13:43:59.752317
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0(var_0, **var_1)
    assert(True)


# Generated at 2022-06-25 13:44:02.266684
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    singleton_0.__instance = None
    singleton_0.__rlock = RLock()
    singleton_0.__call__()


# Generated at 2022-06-25 13:44:03.284630
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    import copy
    test_case_0()



# Generated at 2022-06-25 13:44:07.372072
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'SingletonClass'
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert_equal(singleton_0.__call__(), singleton_0)

    '''
    var_0 = ()
    var_1 = {}
    singleton_0 = Singleton(str_0, var_0, var_1)
    assert_equal(singleton_0.__call__(), singleton_0)
    '''