

# Generated at 2022-06-25 13:34:24.978514
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global int_0
    global float_0
    global set_0
    global dict_0
    # Initialize test environment
    test_case_0()
    # Print statements to show output on console
    print('int_0 = ', int_0)
    print('float_0 = ', float_0)
    print('set_0 = ', set_0)
    print('dict_0 = ', dict_0)
# test_Singleton___call__()


# Generated at 2022-06-25 13:34:33.995006
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    float_0 = int()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()

# Generated at 2022-06-25 13:34:35.286817
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # FIXME: implement
    pass



# Generated at 2022-06-25 13:34:38.266248
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class_0 = Singleton()
    assert class_0 is not None and class_0 is not True and class_0 is not False


# Generated at 2022-06-25 13:34:48.878105
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    int_0 = 350
    dict_0 = {int_0: int_0}
    float_0 = 1545.94905
    set_0 = {float_0, int_0, float_0, dict_0}
    str_0 = "Ju1[Nn6q,|6hWcPn"
    int_1 = 3696
    list_0 = [str_0, str_0, str_0, int_0, int_1, str_0, str_0, int_1, int_1, int_1, int_1, int_1, int_0, float_0, float_0, float_0, int_0, float_0, float_0]
    tuple_0 = (list_0,)

# Generated at 2022-06-25 13:34:58.096509
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # template for
    # test_Singleton___call__()
    #
    # __call__(cls, *args, **kw)
    #
    # Tests the method __call__(Singleton, *args, **kw) of class Singleton
    #
    # Parameters
    # ----------
    # cls : 
    # args : 
    # kw : 
    #

    # template for
    # test_Singleton___call__
    #
    # __call__(_cls, *args, **kw)
    #
    # Tests the method __call__(Singleton, *args, **kw) of class Singleton
    #
    # Parameters
    # ----------
    # _cls : 
    # args : 
    # kw : 
    #

    test_case_0()

# Generated at 2022-06-25 13:34:58.871690
# Unit test for constructor of class Singleton
def test_Singleton():
    obj_Singleton = Singleton()


# Generated at 2022-06-25 13:35:04.677045
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from collections import Mapping as Mapping
    from collections import Sequence as Sequence
    from collections import Set as Set

    try:
        int_0 = 350
        dict_0 = {int_0: int_0}
        float_0 = 7.979844646
        set_0 = {float_0, int_0, float_0, dict_0}
        test_case_0()
        test_case_0()
        test_case_0()
    except Exception as exception:
        raise exception

# Generated at 2022-06-25 13:35:05.537558
# Unit test for constructor of class Singleton
def test_Singleton():
    test_case_0()


# Generated at 2022-06-25 13:35:14.763390
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    #from Singleton import Singleton
    int_0 = 909
    str_0 = 'fJgKjw'
    float_0 = 17.83736

    # call Singleton.__call__()
    assert Singleton.__call__(int_0, str_0, float_0) is None
    assert Singleton.__call__(int_0, str_0, float_0) is None
    assert Singleton.__call__(int_0, str_0, float_0) is None
    assert Singleton.__call__(int_0, str_0, float_0) is None
    assert Singleton.__call__(int_0, str_0, float_0) is None
    assert Singleton.__call__(int_0, str_0, float_0) is None

# Generated at 2022-06-25 13:35:22.187122
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestNotSingleton(object):
        pass

    test = TestSingleton()
    test1 = TestSingleton()
    test3 = TestNotSingleton()
    test4 = TestNotSingleton()

    print("test: %r" % test)
    print("test1: %r" % test1)
    print("test3: %r" % test3)
    print("test4: %r" % test4)

    assert test1 is test
    assert test3 is not test4

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:35:28.277029
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # pylint: disable=C0111,C0103
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self, val):
            self.val = val

    a = MySingleton(1)
    assert isinstance(a, MySingleton), "a isn't an instance of MySingleton"
    b = MySingleton(2)
    assert b is a, "b isn't equal to a"
    assert a.val == 1, "a.val isn't 1"
    assert b.val == 1, "b.val isn't 1"



# Generated at 2022-06-25 13:35:31.979798
# Unit test for constructor of class Singleton
def test_Singleton():
    # singleton object dummy object
    class SingletonTest(object):
        __metaclass__ = Singleton

    singleton_instance = SingletonTest()

    # check that instance is the singleton_instance
    assert singleton_instance == SingletonTest()
    assert singleton_instance is SingletonTest()
    assert not singleton_instance is None

# Generated at 2022-06-25 13:35:34.015053
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass
    a = A()
    assert a is A()


# Generated at 2022-06-25 13:35:38.020472
# Unit test for constructor of class Singleton
def test_Singleton():
    class c1(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass

    c11 = c1()
    c12 = c1()
    assert c11 == c12

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:35:40.057782
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class MyClass(object):
        __metaclass__ = Singleton

    x = MyClass()
    y = MyClass()
    assert (x is y)



# Generated at 2022-06-25 13:35:44.161874
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class M(metaclass=Singleton):
        def __init__(self):
            self.v = 1

    m1 = M()
    m2 = M()
    assert m1 == m2
    assert m1.v == 1
    m1.v = 2
    assert m1.v == m2.v



# Generated at 2022-06-25 13:35:47.797581
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.val = 1

    a = A()
    b = A()
    assert id(a) == id(b), "Singleton constructor test failed"

# Generated at 2022-06-25 13:35:53.856403
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread

    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0
            pass

        def inc(self):
            self.value += 1

    def thread_func():
        st = SingletonTest()
        st.inc()

    thread_lists = [Thread(target=thread_func) for _ in range(100)]
    [t.start() for t in thread_lists]
    [t.join() for t in thread_lists]

    st = SingletonTest()
    assert(st.value == 1)

# Generated at 2022-06-25 13:35:54.884769
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton:
        __metaclass__ = Singleton

    assert TestSingleton() == TestSingleton()



# Generated at 2022-06-25 13:36:01.482045
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton): pass
    x = Foo()
    y = Foo()
    assert(x is y)



# Generated at 2022-06-25 13:36:03.235578
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    assert id(A()) == id(A())

# Generated at 2022-06-25 13:36:08.567155
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test the method Singleton.__call__
    # Failure scenario 1
    # Create an instance of class Singleton
    S = Singleton('test1', (object,), {})
    # Instantiate the instance created
    s_instance = S()
    # Check if __instance attribute exists
    assert hasattr(s_instance, '__instance')
    # Check if __instance attribute is null
    assert s_instance.__instance is None
    # Check if __call__ method returns the same instance
    assert s_instance is S()



# Generated at 2022-06-25 13:36:09.875893
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    test1 = Test()
    assert test1 is Test()



# Generated at 2022-06-25 13:36:16.593399
# Unit test for constructor of class Singleton
def test_Singleton():
    class myclass(metaclass=Singleton):
        def __init__(self, x):
            self.x = x

        def getx(self):
            return self.x

    inst1 = myclass(7)
    inst2 = myclass(8)

    assert inst1 is inst2
    assert inst1.getx() == 7
    assert inst2.getx() == 7
    assert inst1.x == inst2.x
    assert inst1.x == 7

# Generated at 2022-06-25 13:36:18.648876
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()



# Generated at 2022-06-25 13:36:21.374208
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1 is t2


# Generated at 2022-06-25 13:36:23.731333
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-25 13:36:25.242554
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class c:
        __metaclass__ = Singleton

    a = c()
    b = c()

    assert a == b
    assert a is b

# Generated at 2022-06-25 13:36:27.010533
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    instance1 = C()
    instance2 = C()

    assert instance1 is not None
    assert instance1 is instance2

# Generated at 2022-06-25 13:36:44.240953
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Test empty class
    class EmptySingleton(object):
        __metaclass__ = Singleton
    instance = EmptySingleton()
    assert(instance is EmptySingleton())

    # Test class with a constructor
    class ConstructorSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.args = arg
    instance = ConstructorSingleton('arg')
    assert(instance.args == ConstructorSingleton().args)

    # Test class with a constructor, that takes no arguments
    class ConstructorSingletonWithoutArguments(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    instance = ConstructorSingletonWithoutArguments()
    assert(instance is ConstructorSingletonWithoutArguments())

    # Test cashing with multiple arguments
   

# Generated at 2022-06-25 13:36:52.312503
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        """Test class for Singleton"""
        __metaclass__ = Singleton

        def __init__(self, a, b):
            """Unit test constructor with 2 arguments"""
            self.__a = a
            self.__b = b

        def __str__(self):
            return "A(a=%s, b=%s)" % (self.__a, self.__b)

    a = A('x', 'y')
    assert str(a) == "A(a=x, b=y)"
    b = A('u', 'v')
    assert str(b) == "A(a=x, b=y)"
    assert a is b

# Generated at 2022-06-25 13:36:55.079555
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, bar):
            self.bar = bar

    assert Foo('baz') is Foo('baz')
    assert Foo('baz').bar == 'baz'



# Generated at 2022-06-25 13:36:57.535259
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class C(object):
        __metaclass__ = Singleton

    c1 = C()
    c2 = C()
    assert c1 == c2

# Generated at 2022-06-25 13:36:59.633109
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    d1 = Test()
    d2 = Test()

    assert d1 is d2

# Generated at 2022-06-25 13:37:03.959271
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a1 = A(1)
    assert a1.value == 1

    a2 = A(2)
    assert a2.value == 1

# Generated at 2022-06-25 13:37:11.548977
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.data = 'foo'

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.data = 'bar'

    bar1 = Bar()
    bar2 = Bar()
    assert bar1 is bar2

    assert foo1 is not bar1

    # Unit test for method __call__ of class Singleton

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:37:14.205789
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        pass
    a1 = A()
    a2 = A()
    assert a1 == a2


# Generated at 2022-06-25 13:37:18.606291
# Unit test for constructor of class Singleton
def test_Singleton():
    class DummySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.name = 'DummySingleton'

    dummy = DummySingleton()
    assert isinstance(dummy, DummySingleton)
    assert dummy is DummySingleton()

# Generated at 2022-06-25 13:37:26.005086
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = True

        def get(self):
            return self.test


    # assert(TestSingleton().get() == True)
    # assert(TestSingleton.__instance.get() == True)
    x = TestSingleton()
    assert(TestSingleton.__instance == x)
    assert(TestSingleton() == x)
    assert(TestSingleton().get() == True)
    assert(TestSingleton() == x)

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:37:46.063772
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    assert test_singleton_1 is test_singleton_2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:37:51.004258
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(metaclass=Singleton):
        def __init__(self):
            self._x = 10

        def __eq__(self, other):
            return self._x == other._x

    # Create new instance of the class
    class1 = MyClass()
    # Get the same instance of the class
    class2 = MyClass()

    # Check the instance is the same
    assert class1 is class2
    assert class1 == class2

# Generated at 2022-06-25 13:37:54.696756
# Unit test for constructor of class Singleton
def test_Singleton():
    class Single(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.obj_id = 79

    obj = Single()
    obj2 = Single()
    assert id(obj) == id(obj2)
    assert obj.obj_id == obj2.obj_id


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:38:00.093539
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(metaclass=Singleton):
        def __init__(self, a, b):
            self.__a = a
            self.__b = b

        def __eq__(self, other):
            return self.__a == other.__a and self.__b == other.__b

    assert TestClass(1, 2) == TestClass(1, 2)
    assert TestClass(1, 2) is TestClass(1, 2)
    assert TestClass(2, 3) == TestClass(2, 3)
    assert TestClass(1, 2) is TestClass(1, 2)
    assert TestClass(1, 2) != TestClass(2, 3)
    assert TestClass(1, 2) is not TestClass(2, 3)



# Generated at 2022-06-25 13:38:09.696912
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    # call the constructor of class Singleton via Test
    t = Test()

    # only one instance of class Test
    assert(len(t.__dict__) == 0)

    # class Test has attribute '__instance'
    # but class Test is not an instance of class Singleton
    # so instance of class Test cannot access attribute '__instance'
    # of class Singleton
    try:
        assert(t.__instance is None)
    except AttributeError:
        pass

    # since class Singleton is not a subclass of class Test
    # instance of class Test cannot access attribute '__instance'
    # of class Singleton
    try:
        assert(Test.__instance is None)
    except AttributeError:
        pass

    # constructor of class Singleton is

# Generated at 2022-06-25 13:38:11.629160
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

    x1 = MySingleton()
    x2 = MySingleton()
    assert x1 is x2, 'Singleton test failed.'

# Generated at 2022-06-25 13:38:15.916922
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    t1 = Test('foo', 'bar', foo='bar')
    assert t1.args == ('foo', 'bar')
    assert t1.kwargs == dict(foo='bar')

    t2 = Test()
    assert t1 is t2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:38:24.344606
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    class A(object, metaclass=Singleton):
        count = 0
        def __init__(self):
            self.__class__.count += 1
    assert A.count == 0
    a = A()
    assert A.count == 1
    b = A()
    assert A.count == 1
    assert a == b

    from threading import Thread
    class B(object, metaclass=Singleton):
        count = 0
        def __init__(self):
            self.__class__.count += 1
    assert B.count == 0
    b1 = B()
    assert B.count == 1
    b2 = B()
    assert B.count == 1
    assert b1 == b2

    def b3():
        B()
    def b4():
        B()


# Generated at 2022-06-25 13:38:26.896580
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    a = SingletonTest()
    b = SingletonTest()
    assert(a == b)


# Generated at 2022-06-25 13:38:28.876108
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    foo = Foo()
    assert foo == Foo()
    print("test_Singleton passed")

test_Singleton()

# Generated at 2022-06-25 13:39:02.289940
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    ts1 = TestSingleton()
    ts2 = TestSingleton()

    assert ts1 is ts2


# Generated at 2022-06-25 13:39:05.797445
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = Test(1)
    b = Test(1)
    assert a == b

# Generated at 2022-06-25 13:39:12.630322
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            pass

    class MySubClass(MyClass):
        def __init__(self, *args, **kwargs):
            pass

    assert not hasattr(MyClass, '__instance')
    assert not hasattr(MySubClass, '__instance')

    assert MyClass() is MyClass()
    assert MyClass() is MySubClass()
    assert MySubClass() is MyClass()
    assert MySubClass() is MySubClass()

# Testing code

# Generated at 2022-06-25 13:39:20.394472
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    class MyNonSingleton(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    a = MySingleton(1, 2)
    b = MySingleton(3, 4)

    assert(a.a == 1)
    assert(a.b == 2)
    assert(b.a == 1)
    assert(b.b == 2)

    c = MyNonSingleton(1, 2)
    d = MyNonSingleton(3, 4)

    assert(c.a == 1)
    assert(c.b == 2)

# Generated at 2022-06-25 13:39:29.528580
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # prepare
    from tempfile import NamedTemporaryFile
    import os

    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    # test
    test_instance = TestClass("foo", bar="baz")
    second_instance = TestClass("foo", bar="baz")

    assert test_instance is second_instance
    assert ["foo"] == test_instance.args
    assert {"bar": "baz"} == test_instance.kwargs

if __name__ == '__main__':
    # run tests
    # test_Singleton___call__()
    pass

# Generated at 2022-06-25 13:39:38.423150
# Unit test for constructor of class Singleton
def test_Singleton():
    print("Singleton testing")
    class A(object):
        __metaclass__ = Singleton
    a,b= A(), A()
    print("A and B are instance of {} : {}".format(A, a is b))
    class B(object):
        __metaclass__ = Singleton
        def __init__(self, C):
            self.C = C
    c1, c2, c3 = B(1), B(2), B(3)
    print("c1 and c2 are instance of {} : {}".format(B, c1 is c2))
    print("c1 and c3 are instance of {} : {}".format(B, c1 is c3))
    print("isinstance(c1, B) : {}".format(isinstance(c1, B)))

# Generated at 2022-06-25 13:39:41.670942
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    """Verify that class implements Singleton behaviour"""

    class Bar(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 'bar'

    # Ensure that we do not get two instances of Bar class
    assert Bar() is Bar()

    # Ensure that we get the same instance when __init__ is called
    assert Bar() == Bar()

# Generated at 2022-06-25 13:39:44.025150
# Unit test for constructor of class Singleton
def test_Singleton():
    class testSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    t = testSingleton()
    assert t == testSingleton()

# Generated at 2022-06-25 13:39:46.135180
# Unit test for constructor of class Singleton
def test_Singleton():
    s = Singleton('Test', (object,), {'return_true': lambda self: True})
    assert(s('test') is s('foo'))



# Generated at 2022-06-25 13:39:50.395290
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    # Verify that init is called twice
    obj1 = MyClass(100)
    assert obj1.value == 100

    obj2 = MyClass(200)
    assert obj2.value == 100

    # Verify that only one instance is created
    assert obj1 is obj2

# Generated at 2022-06-25 13:41:02.158652
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test:
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    a1 = Test(1)
    assert a1.val == 1
    a2 = Test(2)
    assert a1.val == 1
    assert a2.val == 1

# Generated at 2022-06-25 13:41:03.511807
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    obj_st = Singleton()
    assert obj_st is not None


# Generated at 2022-06-25 13:41:05.576404
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    assert a1 is A()


# Generated at 2022-06-25 13:41:08.416519
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    obj_1 = Foo()
    assert id(obj_1) == id(Foo())


# Generated at 2022-06-25 13:41:14.669658
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    class B(object):
        __metaclass__ = Singleton

    instance_a1 = A()
    instance_a2 = A()
    instance_b1 = B()
    instance_b2 = B()

    assert instance_a1 == instance_a2
    assert instance_b1 == instance_b2
    assert id(instance_a1) == id(instance_a2)
    assert id(instance_b1) == id(instance_b2)
    assert id(instance_a1) != id(instance_b1)

# Generated at 2022-06-25 13:41:24.591159
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Class1(object):
        __metaclass__ = Singleton
#        __metaclass__ = type
        def __init__(self):
            self.a = 'a'

    class Class2(object):
        __metaclass__ = Singleton
#        __metaclass__ = type
        def __init__(self):
            self.a = 'a'

    a = Class1()
    b = Class1()
    assert a is b

    c = Class2()
    d = Class2()
    assert c is d


# Generated at 2022-06-25 13:41:28.998821
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    obj1 = TestSingleton(1, 2)
    obj2 = TestSingleton(3, 4)
    assert obj1 is obj2
    assert obj1.a == 3
    assert obj1.b == 4

# Generated at 2022-06-25 13:41:34.427687
# Unit test for constructor of class Singleton
def test_Singleton():
    class Base:
        def __init__(self):
            self.value = 1

    @Singleton
    class Derived(Base):
        def __init__(self):
            self.value = 2

    instance1 = Derived()
    instance2 = Derived()

    assert instance1 is instance2
    assert instance1.value == 2

# There are many ways to code this (and some are better than others).  This
# is a simple way to do it that doesn't involve using the deprecated
# function type().

# Generated at 2022-06-25 13:41:36.882839
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Arrange
    # Act
    class A(metaclass=Singleton):
        pass

    class B(metaclass=Singleton):
        pass

    inst_of_A = A()
    inst_of_B = B()

    # Assert
    assert inst_of_A is A()
    assert inst_of_B is B()
    assert inst_of_A is not inst_of_B

# Generated at 2022-06-25 13:41:42.692738
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            pass

    assert A() is A()
    assert A() is not A(1, 2, name='a')
    assert A() is not A(name='a', a=1, b=2)
    assert A(1, 2, name='a') is A(1, 2, name='a')
    assert A(name='a', a=1, b=2) is A(name='a', a=1, b=2)

    class B(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            print(args, kwargs)

    assert B() is B()