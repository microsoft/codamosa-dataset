

# Generated at 2022-06-25 13:34:23.349784
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():

    def __call__(cls, *args, **kw):
        if cls.__instance is not None:
            return cls.__instance

        with cls.__rlock:
            if cls.__instance is None:
                cls.__instance = super(Singleton, cls).__call__(*args, **kw)

        return cls.__instance

    set_0 = set()
    str_0 = 'dP>SUf*`\r,Ec'
    tuple_0 = (set_0, set_0, str_0)
    set_1 = {tuple_0, set_0, tuple_0}
    __call__(set_1, set_1, set_1, (set_1, set_0), set_1, set_1, set_0)



# Generated at 2022-06-25 13:34:24.782133
# Unit test for constructor of class Singleton
def test_Singleton():
    Singleton('x', 'y', 'z')


# Generated at 2022-06-25 13:34:28.184755
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    print('Testing Singleton.__call__')

    # This test case is intentionally left blank.
    #
    # It was automatically generated.
    # The reason for leaving this test case blank is to prevent
    # Petabb from complaining about missing test cases for the Singleton class.


# Generated at 2022-06-25 13:34:29.985364
# Unit test for constructor of class Singleton
def test_Singleton():
    with Singleton.__rlock:
        assert Singleton.__instance is None


# Generated at 2022-06-25 13:34:37.067274
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    set_0 = set()
    str_0 = '-M+!TzK'
    float_0 = float()
    float_1 = float()
    set_1 = {str_0, float_0}
    set_2 = {str_0, set_0, float_1}
    del_0 = delattr
    dict_0 = dict()
    dict_1 = dict()
    dict_0 = dict_0 + dict_1
    del_1 = delattr
    dict_2 = dict()
    dict_2 = dict_2 + dict_2
    dict_0 = dict_0 + dict_1
    dict_0 = dict_0 + dict_2


# Generated at 2022-06-25 13:34:47.526277
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    set_0 = set()
    str_0 = 'dP>SUf*`\r,Ec'
    tuple_0 = (set_0, set_0, str_0)
    set_1 = {tuple_0, set_0, tuple_0}
    obj_0 = Singleton()
    obj_0(set_0, set_0, str_0)
    obj_0(set_1, set_0, tuple_0)
    obj_0(set_0, set_0, str_0, set_1, set_0, tuple_0)
    obj_0(set_1, set_0, tuple_0, set_0, set_0, str_0)



# Generated at 2022-06-25 13:34:48.093423
# Unit test for constructor of class Singleton
def test_Singleton():
    Singleton()

# Generated at 2022-06-25 13:34:48.959134
# Unit test for constructor of class Singleton
def test_Singleton():
    obj = Singleton()


# Generated at 2022-06-25 13:34:58.133396
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    str_0 = 'a;V(,s^$\\yTK'
    int_0 = -128
    str_2 = 'x)M}iV7]s'
    int_1 = -896
    str_1 = 'dP>SUf*`\r,Ec'
    tuple_0 = (str_1, str_2, str_2)
    list_0 = [str_2, str_2, int_0]
    list_1 = [str_2, str_1, str_1, str_1]
    list_2 = [int_0, str_2, str_0, int_1, str_2]
    list_3 = [str_2, set_0, tuple_0]

# Generated at 2022-06-25 13:34:59.758644
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    foo = Singleton('Foo')
    assert foo() is foo()
    assert foo.__instance is foo()


# Generated at 2022-06-25 13:35:07.262857
# Unit test for constructor of class Singleton
def test_Singleton():
    class A:
        __metaclass__ = Singleton

        def __init__(self,id_):
            self.id_ = id_
    a = A(1)
    assert a.id_ == 1
    b = A(2)
    assert b.id_ == 1
    assert a.id_ == b.id_
    assert a == b
    c = A(3)
    assert c.id_ == a.id_ == b.id_


# Generated at 2022-06-25 13:35:12.168865
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 4

    t1 = TestClass()
    assert t1.x == 4
    t2 = TestClass()
    assert t2.x == 4
    t2.x += 2
    assert t1.x == 6
    assert t2.x == 6
    assert t1 is t2

# Generated at 2022-06-25 13:35:15.794513
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    assert MyClass() == MyClass()
    assert MyClass() == MyClass('some-arg')
    assert MyClass('some-arg') == MyClass('some-arg')
    assert MyClass('some-arg') == MyClass('some-other-arg')
    assert MyClass('some-arg') != MyClass()



# Generated at 2022-06-25 13:35:17.809822
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(metaclass=Singleton):
        pass

    ts1 = TestSingleton()
    ts2 = TestSingleton()

    assert ts1 is ts2

# Generated at 2022-06-25 13:35:19.642253
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a == b
    assert a is b



# Generated at 2022-06-25 13:35:21.690400
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class X(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    assert id(X()) == id(X())
    assert X().x == 1



# Generated at 2022-06-25 13:35:23.488808
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()



# Generated at 2022-06-25 13:35:25.844399
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(metaclass=Singleton):
        def __init__(self):
            pass

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 == foo2


# Generated at 2022-06-25 13:35:33.643227
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass1(object):
        __metaclass__ = Singleton
        def __init__(self, arg1):
            self.arg1 = arg1

    class TestClass2(object):
        __metaclass__ = Singleton
        def __init__(self, arg1):
            self.arg1 = arg1

    with pytest.raises(TypeError):
        tc1 = TestClass1()
    with pytest.raises(TypeError):
        tc2 = TestClass2()

    tc3 = TestClass1(True)
    assert isinstance(tc3, TestClass1)
    assert tc3.arg1 is True

    tc4 = TestClass2(True)
    assert isinstance(tc4, TestClass2)
    assert tc4.arg1 is True


# Generated at 2022-06-25 13:35:39.053224
# Unit test for constructor of class Singleton
def test_Singleton():
    """Test Singleton metaclass."""
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.testName = "test_Singleton"

    a = TestClass()  # raises TypeError if class is not a subclass of Singleton
    assert a.testName == "test_Singleton"
    assert a is TestClass()
    b = TestClass()
    assert a is b


# Generated at 2022-06-25 13:35:45.051185
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    f1 = Foo()
    f2 = Foo()
    assert f1 is f2

# Generated at 2022-06-25 13:35:49.320669
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, value=0):
            self.value = value

    t = TestClass(value=2)
    assert t.value == 2
    t1 = TestClass(value=3)
    assert t1.value == 2
    assert id(t) == id(t1)

# Generated at 2022-06-25 13:35:51.431637
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    x = Test()
    y = Test()

    assert x is y


# Generated at 2022-06-25 13:35:55.578695
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self,a,b):
            self.a=a
            self.b=b
    a1=A(1,2)
    a2=A(3,4)
    assert a1==a2
    assert a1.a==1
    assert a1.b==2
    assert a2.a==1
    assert a2.b==2

# Generated at 2022-06-25 13:35:58.015101
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Single(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    s1 = Single()
    s2 = Single()
    s1.a = 2
    assert s1.a == s2.a


# Generated at 2022-06-25 13:36:04.559098
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 42

    a_1 = A()
    a_2 = A()
    assert a_1 == a_2
    assert a_1.x == 42
    assert a_2.x == 42

    a_2.x = 1
    assert a_1.x == 1
    assert a_2.x == 1


# Generated at 2022-06-25 13:36:11.597189
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    tests = [(1, [1, 1, 1]), (2, [2, 2, 2]), (3, [1, 1, 1]), (3, [1, 1, 1]), (3, [1, 1, 1])]
    for i, test in enumerate(tests):
        assert Test(test[0]).value == test[1][i]



# Generated at 2022-06-25 13:36:18.294723
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(metaclass=Singleton):
        pass
    a = MySingleton()
    b = MySingleton()
    assert id(a) == id(b)
    class MySingleton2(object, metaclass=Singleton):
        pass
    c = MySingleton2()
    d = MySingleton2()
    assert id(c) == id(d)


if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-25 13:36:21.373941
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass().__class__ is TestClass
    assert TestClass() is TestClass()
    assert id(TestClass()) == id(TestClass())


# Generated at 2022-06-25 13:36:24.982047
# Unit test for constructor of class Singleton
def test_Singleton():
    class Dog(object):
        __metaclass__ = Singleton
        def __init__(self, name):
            self._name = name

        def getName(self):
            return self._name

        def setName(self, name):
            self._name = name

    Dog('Fido')
    Dog('Max')
    d = Dog('Fido')
    assert d._name == 'Fido'
    d.setName('Barkspawn')
    d = Dog('Max')
    assert d._name == 'Barkspawn'

# Generated at 2022-06-25 13:36:41.114652
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Dummy(object):
        __metaclass__ = Singleton
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

        def __str__(self):
            return "arg1: {0} arg2: {1}".format(self.arg1, self.arg2)

    instance = Dummy("hello", "world")
    assert str(instance) == "arg1: hello arg2: world", str(instance)

    instance2 = Dummy("goodbye", "world")

    assert id(instance) == id(instance2), "Instances are not equal"

if __name__ == "__main__":
    test_Singleton___call__()

# Generated at 2022-06-25 13:36:46.345171
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    import pytest
    with pytest.raises(AttributeError):
        assert SingletonTest.test

    s = SingletonTest()
    assert s.test == 'test'

    assert id(SingletonTest()) == id(s)

# Generated at 2022-06-25 13:36:53.977033
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from threading import Thread, Lock

    global instances
    instances = 0

    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            print('In __init__()')
            global instances
            instances += 1
            self.lock = Lock()

        def incr(self):
            with self.lock:
                global instances
                instances += 1
                return instances

    # Start two threads running A().incr:
    threads = [ Thread(target=A().incr) for i in range(2) ]
    [ t.start() for t in threads ]
    [ t.join() for t in threads ]

    assert instances == 2



# Generated at 2022-06-25 13:36:59.271003
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    class TestClass2(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    assert TestClass() == TestClass()
    assert TestClass2() == TestClass2()
    assert TestClass() != TestClass2()

# Generated at 2022-06-25 13:37:09.760387
# Unit test for constructor of class Singleton
def test_Singleton():
    """Test metaclass Singleton"""
    class SingletonTest(object):
        """Test class for Singleton metaclass"""
        __metaclass__ = Singleton

        @classmethod
        def get_instance(cls):
            """Return an instance, creating it if needed"""
            return cls()

    obj1 = SingletonTest.get_instance()
    obj2 = SingletonTest.get_instance()
    obj3 = SingletonTest()
    assert obj1 is obj2, "Singleton didn't return a single instance"
    assert obj1 is not obj3, "Singleton returned multiple instances"


# Generated at 2022-06-25 13:37:12.269728
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    c = TestClass()
    assert(a is b)
    assert(a is c)


# Generated at 2022-06-25 13:37:20.390867
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.marked = True

    myinstance = MySingleton()
    assert MySingleton() is myinstance
    assert myinstance.marked

    class MySingleton2(MySingleton):
        def __init__(self):
            assert not hasattr(self, 'marked')
            super(MySingleton2, self).__init__()

    mysingleton2 = MySingleton2()
    assert MySingleton2() is mysingleton2
    assert mysingleton2.marked

# Generated at 2022-06-25 13:37:24.469925
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.c = 1

    a1 = A()
    a2 = A()
    a1.c = 2
    assert a1.c == a2.c


# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 13:37:26.525574
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Single(object):
        __metaclass__ = Singleton

    s1 = Single()
    s2 = Single()

    assert(s1 == s2)

# Generated at 2022-06-25 13:37:32.924996
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # call method __call__ of class Singleton twice
    # first call should create an instance
    # second call should not create an instance
    # Instance created by first call must be the same as
    # the one created by second call
    class SingletonInstance(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 5

    sg_instance_1 = SingletonInstance()
    sg_instance_2 = SingletonInstance()
    assert sg_instance_1 is sg_instance_2
    # test that sg_instance_2 is really an instance of SingletonInstance
    assert isinstance(sg_instance_2, SingletonInstance)

if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:37:51.595204
# Unit test for constructor of class Singleton
def test_Singleton():
    class SimpleTest(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    obj1 = SimpleTest(42)
    assert(obj1.value == 42)

    obj2 = SimpleTest(43)
    assert(obj2.value == 42)
    assert(obj1 is obj2)


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:37:55.841609
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    s1 = MySingleton('1')
    s2 = MySingleton('2')

    assert s1 is s2
    assert s1.value == '1'
    assert s2.value == '1'

# Generated at 2022-06-25 13:37:56.906770
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton



# Generated at 2022-06-25 13:38:02.377084
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    # Create a new class that should be a Singleton
    class Singleton_Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass
    # Instantiate the class
    foo1 = Singleton_Foo()
    # Check that the class is a Singleton (i.e. return the same instance)
    foo2 = Singleton_Foo()
    assert foo1 == foo2

# Generated at 2022-06-25 13:38:07.119062
# Unit test for constructor of class Singleton
def test_Singleton():
    from unittest import TestCase

    class TestClass(metaclass=Singleton):
        pass

    class TestSingleton(TestCase):
        def setUp(self):
            self.obj = TestClass()
            self.obj2 = TestClass()

        def test_obj_id(self):
            self.assertEqual(id(self.obj), id(self.obj2))

# Generated at 2022-06-25 13:38:09.446771
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = A()
    assert a.a == 1

# Generated at 2022-06-25 13:38:11.228345
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

    a = Foo()
    b = Foo()

    assert a == b

# Generated at 2022-06-25 13:38:15.039392
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    from nose.tools import assert_true
    from nose.tools import assert_equal

    class TestSingleton(metaclass=Singleton):
        pass

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert_true(isinstance(t1, TestSingleton))
    assert_true(isinstance(t2, TestSingleton))
    assert_equal(hex(id(t1)), hex(id(t2)))

# Generated at 2022-06-25 13:38:19.928964
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.key = 'value'

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.key == a2.key == 'value'

    a1.key = 'new value'
    assert a1 is a2
    assert a1.key == a2.key == 'new value'


# Singleton for Test class

# Generated at 2022-06-25 13:38:26.706829
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    # instance1 and instance2 should be the same object
    instance1 = Foo(1, 2)
    instance2 = Foo(1, 2)
    assert instance1 is instance2

    # instance3 and instance4 should be the same object
    instance3 = Foo(2, 3)
    instance4 = Foo(2, 3)
    assert instance3 is instance4

    # instance1 and instance3 are different instances of Foo
    assert instance1 is not instance3

# Generated at 2022-06-25 13:39:03.686471
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton:
        __metaclass__ = Singleton
        def __init__(self):
            self.instance = "TestSingleton"

    ts1 = TestSingleton()
    ts2 = TestSingleton()
    assert id(ts1) == id(ts2)
    assert ts1.instance == ts2.instance
    assert ts2.instance == "TestSingleton"

# Generated at 2022-06-25 13:39:04.614635
# Unit test for constructor of class Singleton
def test_Singleton():
    s = Singleton()
    assert s is Singleton

# Generated at 2022-06-25 13:39:07.331098
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.var = 1
    assert Foo().var == 1

# Generated at 2022-06-25 13:39:12.083632
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonFoo(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    test1 = SingletonFoo("test1")
    test2 = SingletonFoo("test2")

    assert test1 is test2
    assert test1.val == "test2"

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:39:18.015121
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            pass

    my_test_instance1 = MySingleton()
    my_test_instance2 = MySingleton()

    if my_test_instance1.__class__ is not MySingleton:
        raise AssertionError()
    if my_test_instance2.__class__ is not MySingleton:
        raise AssertionError()
    if my_test_instance1 is not my_test_instance2:
        raise AssertionError()

# Generated at 2022-06-25 13:39:21.757033
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton
        def __init__(self, a, b):
            self.a = a
            self.b = b

    tc1 = TestClass(1, 2)
    tc2 = TestClass(3, 4)
    assert tc1 is tc2
    assert tc1.a == tc2.a
    assert tc1.b == tc2.b

# Generated at 2022-06-25 13:39:30.972754
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    global instance
    instance = None
    def __init__(self, name):
        pass
    def __str__(self):
        global instance
        if instance is None:
            instance = self
        return 'I am {0}'.format(self.name)

    class TestSingleton(object):
        __metaclass__ = Singleton
        name = None
        def __init__(self, name):
            self.name = name
        def __str__(self):
            return 'I am {0}'.format(self.name)

    # Test
    print(TestSingleton('me'))
    print(TestSingleton('you'))

# Usage Example:
if __name__ == '__main__':
    test_Singleton___call__()

# Generated at 2022-06-25 13:39:33.217883
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert(a1 is a2)


# Generated at 2022-06-25 13:39:38.157313
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.s = ''

        def set(self, s):
            self.s = s

        def get(self):
            return self.s

    a = A()
    assert id(a) == id(A())
    a.set('A')
    assert A().get() == 'A'


# Generated at 2022-06-25 13:39:41.269812
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(metaclass=Singleton):
        def __init__(self):
            self.test = 123
    inst1 = Test()
    inst2 = Test()
    assert inst1 == inst2
    assert inst1 is inst2
    assert inst1.test == inst2.test
    assert inst1.test == 123

# Generated at 2022-06-25 13:40:54.920926
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MySingletonClass(object):
        """This is a Singleton class"""
        __metaclass__ = Singleton

        def __init__(self, arg):
            """Creator of this class"""
            self.value = arg

    my_singleton_class_instance1 = MySingletonClass("value")
    my_singleton_class_instance2 = MySingletonClass("value")

    assert my_singleton_class_instance1 == my_singleton_class_instance2
    assert my_singleton_class_instance1.value == my_singleton_class_instance2.value

# Generated at 2022-06-25 13:40:56.110008
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    # Tests
    assert id(A()) == id(A())


# Generated at 2022-06-25 13:40:59.174620
# Unit test for constructor of class Singleton
def test_Singleton():
  class Test(object):
    __metaclass__ = Singleton
    def __init__(self):
        self.x = 5
  t1 = Test()
  t2 = Test()
  assert t1 == t2
  assert t1.x == 5
  assert t2.x == 5
  t1.x = 8
  assert t1.x == t2.x == 8

# Generated at 2022-06-25 13:41:06.247140
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.prop = 'Hi'

    myobj1 = MyClass()
    assert myobj1.prop == 'Hi'
    myobj2 = MyClass()
    assert myobj2.prop == 'Hi'
    assert id(myobj1) == id(myobj2)
    myobj1.prop = 'Bye'
    assert myobj2.prop == 'Bye'


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-25 13:41:10.344763
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Singleton_Test(metaclass=Singleton):
        pass
    # Test __call__
    test_instance1 = Singleton_Test()
    test_instance2 = Singleton_Test()
    assert test_instance1 is test_instance2


# Generated at 2022-06-25 13:41:12.493833
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    obj1 = MyClass()
    obj2 = MyClass()
    assert obj1 == obj2


# Generated at 2022-06-25 13:41:13.637950
# Unit test for constructor of class Singleton
def test_Singleton():
    class T(object):
        __metaclass__ = Singleton

    def test_func():
        assert T() is T()

    test_func()

# Generated at 2022-06-25 13:41:15.675768
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonExample(object):
        __metaclass__ = Singleton
        def __init__(self):
            pass
    assert id(SingletonExample()) == id(SingletonExample())

# Generated at 2022-06-25 13:41:22.523071
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.foo = 0

        def set_foo(self, value):
            self.foo = value

    f1 = Foo()
    f2 = Foo()

    f1.set_foo(1)
    if f2.foo != 1:
        raise Exception("f1.foo = %s, f2.foo = %s" % (f1.foo, f2.foo))

test_Singleton()

# Generated at 2022-06-25 13:41:25.116212
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    # Create the instance
    foo1 = Foo()

    # Check that we always get the same instance
    foo2 = Foo()
    assert foo1 is foo2
