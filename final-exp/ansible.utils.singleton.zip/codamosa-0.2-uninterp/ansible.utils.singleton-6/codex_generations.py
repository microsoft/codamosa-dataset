

# Generated at 2022-06-17 15:35:22.942772
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.arg == 1
    assert b.arg == 1

# Generated at 2022-06-17 15:35:28.597806
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a == b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:35:32.040508
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b



# Generated at 2022-06-17 15:35:37.186727
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:35:43.382882
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    a.increment()
    assert a.value == 1
    assert b.value == 1
    b.increment()
    assert a.value == 2
    assert b.value == 2



# Generated at 2022-06-17 15:35:49.146270
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    test_singleton_1 = TestSingleton(1)
    test_singleton_2 = TestSingleton(2)
    assert test_singleton_1 is test_singleton_2
    assert test_singleton_1.value == 1
    assert test_singleton_2.value == 1

# Generated at 2022-06-17 15:35:54.542259
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_a = TestSingleton()
    test_singleton_b = TestSingleton()
    assert test_singleton_a is test_singleton_b

# Generated at 2022-06-17 15:35:58.907926
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test1 = Test()
    test2 = Test()
    assert test1 is test2
    assert test1.test == 'test'
    assert test2.test == 'test'

# Generated at 2022-06-17 15:36:02.408130
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    instance1 = TestSingleton()
    instance2 = TestSingleton()
    assert instance1 is instance2


# Generated at 2022-06-17 15:36:04.739764
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:36:12.912418
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    s1 = TestSingleton(1)
    s2 = TestSingleton(2)
    assert s1.value == 1
    assert s2.value == 1
    assert s1 is s2

# Generated at 2022-06-17 15:36:18.821470
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestSingleton('a')
    b = TestSingleton('b')

    assert a is b
    assert a.name == 'a'
    assert b.name == 'a'

# Generated at 2022-06-17 15:36:20.093008
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    assert MyClass() is MyClass()

# Generated at 2022-06-17 15:36:23.385211
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:36:29.146892
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2


# Generated at 2022-06-17 15:36:34.910119
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:36:42.095674
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestClass()
    b = TestClass()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2
    b.x = 3
    assert a.x == 3
    assert b.x == 3

# Generated at 2022-06-17 15:36:49.613938
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    s1 = TestSingleton(1)
    s2 = TestSingleton(2)
    assert s1.value == 1
    assert s2.value == 1
    assert s1 is s2
    assert s1.value is s2.value

# Generated at 2022-06-17 15:36:51.607791
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:54.350361
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:37:00.722433
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1
    a1.x = 2
    assert a1.x == 2
    assert a2.x == 2



# Generated at 2022-06-17 15:37:06.063986
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a == b
    assert a.test == b.test
    assert a is b

# Generated at 2022-06-17 15:37:08.986337
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    t1 = TestClass()
    t2 = TestClass()
    assert t1 is t2

# Generated at 2022-06-17 15:37:13.387971
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.x == b.x == 1

# Generated at 2022-06-17 15:37:18.702737
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.value == 1
    assert test2.value == 1
    test1.value = 2
    assert test1.value == 2
    assert test2.value == 2

# Generated at 2022-06-17 15:37:22.363917
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.name == test2.name

# Generated at 2022-06-17 15:37:26.392924
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1 is t2
    assert t1.x == 1
    assert t2.x == 1

    t1.x = 2
    assert t1.x == 2
    assert t2.x == 2

# Generated at 2022-06-17 15:37:30.778243
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a == b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2
    b.x = 3
    assert a.x == 3
    assert b.x == 3

# Generated at 2022-06-17 15:37:35.268056
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestClass(1)
    b = TestClass(2)
    assert a is b
    assert a.arg == 1
    assert b.arg == 1

# Generated at 2022-06-17 15:37:37.995269
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:37:43.895496
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:37:47.558727
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    t1 = Test(1)
    t2 = Test(2)

    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1

# Generated at 2022-06-17 15:37:49.644837
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-17 15:37:59.873130
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    test_singleton = TestSingleton('foo', bar='baz')
    assert test_singleton.args == ('foo',)
    assert test_singleton.kwargs == {'bar': 'baz'}

    test_singleton2 = TestSingleton('foo', bar='baz')
    assert test_singleton2.args == ('foo',)
    assert test_singleton2.kwargs == {'bar': 'baz'}

    assert test_singleton is test_singleton2

# Generated at 2022-06-17 15:38:02.014584
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-17 15:38:04.707134
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    t1 = TestClass()
    t2 = TestClass()
    assert t1 is t2


# Generated at 2022-06-17 15:38:12.617138
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2

# Generated at 2022-06-17 15:38:15.836517
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-17 15:38:21.505371
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 1
    a.value = 2
    assert b.value == 2



# Generated at 2022-06-17 15:38:24.907019
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    # create two instances of TestClass
    instance1 = TestClass()
    instance2 = TestClass()

    # check that both instances are the same
    assert instance1 is instance2



# Generated at 2022-06-17 15:38:30.861260
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:34.464535
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.test == b.test

# Generated at 2022-06-17 15:38:45.226868
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    tc1 = TestClass()
    tc2 = TestClass()
    assert tc1 is tc2
    tc1.increment()
    assert tc1.value == 1
    assert tc2.value == 1
    tc2.increment()
    assert tc1.value == 2
    assert tc2.value == 2


# Generated at 2022-06-17 15:38:48.854521
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = 'test'

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1 == t2
    assert t1.test == t2.test

# Generated at 2022-06-17 15:38:53.828983
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)

    assert a1 is a2
    assert a1.x == 2
    assert a2.x == 2

# Generated at 2022-06-17 15:38:56.446890
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:38:59.953347
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a is b
    assert a.arg == 1
    assert b.arg == 1

# Generated at 2022-06-17 15:39:02.556205
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:39:05.321914
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:39:10.258650
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.name == 'test'
    assert b.name == 'test'
    assert a.name == b.name

# Generated at 2022-06-17 15:39:24.259299
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2

# Generated at 2022-06-17 15:39:28.747626
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestSingleton('a')
    b = TestSingleton('b')
    assert a is b
    assert a.name == 'a'
    assert b.name == 'a'

# Generated at 2022-06-17 15:39:29.953276
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:39:34.142519
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    assert TestSingleton().value == 1
    assert TestSingleton().value == 1

    TestSingleton().value = 2
    assert TestSingleton().value == 2


# Generated at 2022-06-17 15:39:41.858086
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = MyClass()
    b = MyClass()
    assert a == b
    assert a.value == 1
    a.value = 2
    assert b.value == 2

# Generated at 2022-06-17 15:39:47.466942
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a is b
    assert a.x == 1
    assert b.x == 1

# Generated at 2022-06-17 15:39:51.993017
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.val == 1
    assert b.val == 1
    a.val = 2
    assert a.val == 2
    assert b.val == 2
    b.val = 3
    assert a.val == 3
    assert b.val == 3

# Generated at 2022-06-17 15:39:56.232221
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = A(1)
    b = A(2)
    assert a is b
    assert a.x == 1
    assert b.x == 1

# Generated at 2022-06-17 15:39:59.203197
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-17 15:40:03.952057
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    t1 = Test(1)
    t2 = Test(2)
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1

# Generated at 2022-06-17 15:40:22.041774
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()



# Generated at 2022-06-17 15:40:24.833224
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:40:28.950472
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    t1 = Test(1)
    t2 = Test(2)
    assert t1 is t2
    assert t1.value == 2


# Generated at 2022-06-17 15:40:33.377255
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    t1 = Test('test1')
    t2 = Test('test2')
    assert t1 is t2
    assert t1.name == 'test1'
    assert t2.name == 'test1'

# Generated at 2022-06-17 15:40:39.849705
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    # Create two instances of TestSingleton
    instance1 = TestSingleton()
    instance2 = TestSingleton()

    # Check if both instances are the same
    assert instance1 is instance2

# Generated at 2022-06-17 15:40:44.489370
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 == test2

# Generated at 2022-06-17 15:40:46.765760
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:40:49.762283
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1

# Generated at 2022-06-17 15:40:55.789051
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.arg == 1
    assert b.arg == 1

# Generated at 2022-06-17 15:40:57.528941
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() == TestClass()

# Generated at 2022-06-17 15:41:18.770783
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    assert TestSingleton(1) is TestSingleton(2)
    assert TestSingleton(1).arg == 2

# Generated at 2022-06-17 15:41:21.979210
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = True

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:41:24.698011
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:41:26.200279
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:41:30.514029
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.arg == 1
    assert b.arg == 1

# Generated at 2022-06-17 15:41:35.841330
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a == b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2
    b.value = 3
    assert a.value == 3
    assert b.value == 3

# Generated at 2022-06-17 15:41:39.791875
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert a is b


# Generated at 2022-06-17 15:41:45.417046
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 1
    assert b.value == 1

    a.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:41:47.060116
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()


# Generated at 2022-06-17 15:41:52.731797
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b



# Generated at 2022-06-17 15:42:27.862811
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:42:34.070325
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1
    t1.value = 2
    assert t1.value == 2
    assert t2.value == 2

# Generated at 2022-06-17 15:42:43.508535
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2
    t2.a = 3
    assert t1.a == 3
    assert t2.a == 3


# Generated at 2022-06-17 15:42:52.384280
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = Test(1, 2)
    t2 = Test(3, 4)

    assert t1 is t2
    assert t1.a == 1
    assert t1.b == 2

# Generated at 2022-06-17 15:42:55.289623
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:42:59.963337
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 0

        def inc(self):
            self.val += 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    t1.inc()
    assert t1.val == 1
    assert t2.val == 1



# Generated at 2022-06-17 15:43:03.089137
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:08.950438
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2

# Generated at 2022-06-17 15:43:12.891426
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    t1 = Test(1)
    t2 = Test(2)
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1


# Generated at 2022-06-17 15:43:14.420251
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-17 15:43:49.989238
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:51.032336
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:52.096130
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:55.372919
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1
    a1.x = 2
    assert a1.x == 2
    assert a2.x == 2
    a2.x = 3
    assert a1.x == 3
    assert a2.x == 3

# Generated at 2022-06-17 15:43:58.905150
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.test == test2.test

# Generated at 2022-06-17 15:44:02.723554
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1


# Generated at 2022-06-17 15:44:04.501449
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:44:07.082073
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:44:10.196277
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.x == b.x == 1

# Generated at 2022-06-17 15:44:15.196948
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestClass(1)
    b = TestClass(2)
    assert a is b
    assert a.value == 1
    assert b.value == 1
