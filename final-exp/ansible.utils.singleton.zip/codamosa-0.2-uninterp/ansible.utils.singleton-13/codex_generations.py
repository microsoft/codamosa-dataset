

# Generated at 2022-06-17 15:35:23.531275
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a.value == 1
    assert b.value == 1
    assert a is b



# Generated at 2022-06-17 15:35:26.054795
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b

# Generated at 2022-06-17 15:35:34.101203
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.b = 2

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()

    assert a1 is a2
    assert b1 is b2
    assert a1 is not b1
    assert a2 is not b2

# Generated at 2022-06-17 15:35:37.450362
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert a is b

# Generated at 2022-06-17 15:35:41.458341
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:35:45.137156
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2

# Generated at 2022-06-17 15:35:49.957103
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'test'

    test_class_1 = TestClass()
    test_class_2 = TestClass()

    assert test_class_1 is test_class_2
    assert test_class_1.name == 'test'
    assert test_class_2.name == 'test'



# Generated at 2022-06-17 15:35:52.924419
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestClass(1)
    b = TestClass(2)
    assert a is b
    assert a.arg == 1
    assert b.arg == 1

# Generated at 2022-06-17 15:35:56.720945
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    assert TestSingleton() is TestSingleton()
    assert TestSingleton().a == 1

# Generated at 2022-06-17 15:35:58.495801
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:06.190510
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestClass()
    b = TestClass()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2
    b.x = 3
    assert a.x == 3
    assert b.x == 3

# Generated at 2022-06-17 15:36:12.989540
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a == b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:36:18.440199
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1

# Generated at 2022-06-17 15:36:21.567133
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1



# Generated at 2022-06-17 15:36:27.308450
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:36:32.907702
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_var = 1

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    assert test_singleton_1 == test_singleton_2
    assert test_singleton_1.test_var == test_singleton_2.test_var

# Generated at 2022-06-17 15:36:36.909847
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    obj1 = TestSingleton()
    obj2 = TestSingleton()
    assert obj1 is obj2

# Generated at 2022-06-17 15:36:40.997935
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:36:46.464424
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()
    assert test_singleton_1 is test_singleton_2


# Generated at 2022-06-17 15:36:53.763554
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = MyClass()
    b = MyClass()
    assert a is b
    assert a.a == 1
    assert b.a == 1

    a.a = 2
    assert a.a == 2
    assert b.a == 2

    b.a = 3
    assert a.a == 3
    assert b.a == 3

# Generated at 2022-06-17 15:36:59.653982
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:37:03.565599
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    t1.inc()
    assert t1.value == 1
    assert t2.value == 1
    t2.inc()
    assert t1.value == 2
    assert t2.value == 2



# Generated at 2022-06-17 15:37:09.032416
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1.a == 1
    assert a2.a == 1
    assert a1 is a2


# Generated at 2022-06-17 15:37:12.411190
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    assert test_singleton_1 is test_singleton_2

# Generated at 2022-06-17 15:37:13.800487
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:37:16.950344
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a.value == 1
    assert b.value == 1
    assert a is b

# Generated at 2022-06-17 15:37:23.002312
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    test_singleton_1 = TestSingleton('test_singleton_1')
    test_singleton_2 = TestSingleton('test_singleton_2')
    assert test_singleton_1 == test_singleton_2
    assert test_singleton_1.name == 'test_singleton_2'
    assert test_singleton_2.name == 'test_singleton_2'

# Generated at 2022-06-17 15:37:27.261269
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a == b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:37:35.965286
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    t1.increment()
    assert t1.value == 1
    assert t2.value == 1
    t2.increment()
    assert t1.value == 2
    assert t2.value == 2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-17 15:37:39.583261
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2

# Generated at 2022-06-17 15:37:48.398188
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1.a == 1
    assert a2.a == 1
    assert a1 is a2


# Generated at 2022-06-17 15:37:50.095732
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:37:53.913674
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2


# Generated at 2022-06-17 15:37:58.805702
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)

    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1



# Generated at 2022-06-17 15:38:03.347585
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2

# Generated at 2022-06-17 15:38:05.424657
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()



# Generated at 2022-06-17 15:38:09.011624
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-17 15:38:13.804988
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.a == t2.a
    t1.a = 2
    assert t1.a == t2.a

# Generated at 2022-06-17 15:38:15.623501
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:18.883581
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:38:33.830930
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:38:42.582368
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    a = TestSingleton()
    a.value = 1
    b = TestSingleton()
    assert a is b
    assert a.value == 1
    assert b.value == 1
    b.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:38:45.480720
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton = TestSingleton()
    assert test_singleton is TestSingleton()

# Generated at 2022-06-17 15:38:49.281155
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 is test2
    assert test1.test == 'test'
    assert test2.test == 'test'

# Generated at 2022-06-17 15:38:56.360930
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 0

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 0
    assert b.value == 0
    a.value = 1
    assert a.value == 1
    assert b.value == 1
    b.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:38:58.447411
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:39:02.996824
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, foo):
            self.foo = foo

    t1 = Test(1)
    t2 = Test(2)
    assert t1 is t2
    assert t1.foo == 1
    assert t2.foo == 1

# Generated at 2022-06-17 15:39:07.498056
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:39:11.645262
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)
    assert t1 is t2
    assert t1.arg == 1
    assert t2.arg == 1

# Generated at 2022-06-17 15:39:19.198956
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    s1 = TestSingleton()
    s2 = TestSingleton()
    assert s1 is s2
    assert s1.x == 1
    assert s2.x == 1
    s1.x = 2
    assert s1.x == 2
    assert s2.x == 2

# Generated at 2022-06-17 15:39:45.803162
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2
    a2.a = 3
    assert a1.a == 3
    assert a2.a == 3

# Generated at 2022-06-17 15:39:47.787528
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:39:51.992168
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.test_value == 1
    assert b.test_value == 1
    a.test_value = 2
    assert a.test_value == 2
    assert b.test_value == 2



# Generated at 2022-06-17 15:39:55.040119
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:40:03.525057
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.test == 'test'
    assert t2.test == 'test'
    t1.test = 'test2'
    assert t1.test == 'test2'
    assert t2.test == 'test2'

# Generated at 2022-06-17 15:40:06.466403
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:40:08.329086
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:40:12.845745
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1


# Generated at 2022-06-17 15:40:14.753167
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:40:16.517395
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:40:50.584356
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    s1 = TestSingleton(1, 2)
    s2 = TestSingleton(3, 4)
    assert s1 is s2
    assert s1.a == 1
    assert s1.b == 2

# Generated at 2022-06-17 15:40:54.251141
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:41:03.030050
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def set_value(self, value):
            self.value = value

        def get_value(self):
            return self.value

    test_singleton = TestSingleton()
    test_singleton.set_value(1)
    assert test_singleton.get_value() == 1

    test_singleton2 = TestSingleton()
    assert test_singleton2.get_value() == 1
    test_singleton2.set_value(2)
    assert test_singleton.get_value() == 2
    assert test_singleton2.get_value() == 2

# Generated at 2022-06-17 15:41:05.718097
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:41:08.886869
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1

# Generated at 2022-06-17 15:41:12.052521
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:41:13.534927
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:41:18.850037
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    test_singleton = TestSingleton()
    assert test_singleton.a == 1

    test_singleton.a = 2
    assert test_singleton.a == 2

    test_singleton_2 = TestSingleton()
    assert test_singleton_2.a == 2

    test_singleton_2.a = 3
    assert test_singleton_2.a == 3

    assert test_singleton.a == 3

# Generated at 2022-06-17 15:41:23.504406
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.a == 1
    t1.a = 2
    assert t2.a == 2

# Generated at 2022-06-17 15:41:29.946997
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2
    b.value = 3
    assert a.value == 3
    assert b.value == 3
    assert a is b

# Generated at 2022-06-17 15:42:35.005431
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2


# Generated at 2022-06-17 15:42:38.605659
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:42:42.097301
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:42:44.352547
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert a is b


# Generated at 2022-06-17 15:42:54.091826
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    instance1 = TestSingleton()
    instance1.increment()
    instance2 = TestSingleton()
    instance2.increment()
    assert instance1.value == 2
    assert instance2.value == 2
    assert instance1 is instance2


# Generated at 2022-06-17 15:42:59.401683
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1

    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2

# Generated at 2022-06-17 15:43:02.696753
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:07.445778
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    t1 = Test(1)
    t2 = Test(2)
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1


# Generated at 2022-06-17 15:43:09.883753
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:14.012377
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestSingleton('a')
    b = TestSingleton('b')
    assert a is b
    assert a.name == 'b'

# Generated at 2022-06-17 15:44:21.036557
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 is a2


# Generated at 2022-06-17 15:44:22.252286
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:44:27.841010
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1


# Generated at 2022-06-17 15:44:29.828164
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b

# Generated at 2022-06-17 15:44:36.643197
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1
            self.b = 2

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.a == 1
    assert t1.b == 2
    assert t2.a == 1
    assert t2.b == 2
    t1.a = 3
    assert t1.a == 3
    assert t2.a == 3
    t2.b = 4
    assert t1.b == 4
    assert t2.b == 4

# Generated at 2022-06-17 15:44:45.330472
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    class TestSingleton2(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 2

    assert TestSingleton() is TestSingleton()
    assert TestSingleton2() is TestSingleton2()
    assert TestSingleton() is not TestSingleton2()

# Generated at 2022-06-17 15:44:47.114500
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:44:49.137921
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:44:55.869511
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1
    t1.value = 2
    assert t1.value == 2
    assert t2.value == 2
    t2.value = 3
    assert t1.value == 3
    assert t2.value == 3

# Generated at 2022-06-17 15:45:05.103609
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    instance1 = TestSingleton(1, 2, 3, a=1, b=2, c=3)
    instance2 = TestSingleton(4, 5, 6, d=4, e=5, f=6)

    assert instance1 is instance2
    assert instance1.args == (1, 2, 3)
    assert instance1.kwargs == {'a': 1, 'b': 2, 'c': 3}
    assert instance2.args == (1, 2, 3)
    assert instance2.kwargs == {'a': 1, 'b': 2, 'c': 3}