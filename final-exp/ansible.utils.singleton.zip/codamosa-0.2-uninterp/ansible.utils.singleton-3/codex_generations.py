

# Generated at 2022-06-17 15:35:16.094237
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 == a2
    assert a1.a == a2.a
    a1.a = 2
    assert a1.a == a2.a
    assert a1 == a2

# Generated at 2022-06-17 15:35:20.007362
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-17 15:35:25.644163
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)
    assert t1 is t2
    assert t1.arg == 1
    assert t2.arg == 1

# Generated at 2022-06-17 15:35:29.508286
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:35:34.351402
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = Test()
    b = Test()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:35:41.966860
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 1

    a = TestSingleton()
    b = TestSingleton()

    assert a == b
    assert a.test == b.test
    assert a is b

    a.test = 2
    assert a.test == b.test

# Generated at 2022-06-17 15:35:47.697297
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:35:51.322907
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1


# Generated at 2022-06-17 15:35:56.180617
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a = A(1)
    b = A(2)

    assert a is b
    assert a.a == 1
    assert b.a == 1



# Generated at 2022-06-17 15:35:58.000329
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:05.639864
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    # Create two instances of TestSingleton
    instance1 = TestSingleton(1)
    instance2 = TestSingleton(2)

    # Check that both instances are the same
    assert instance1 is instance2
    assert instance1.value == 1
    assert instance2.value == 1

# Generated at 2022-06-17 15:36:09.599087
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:36:12.031869
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:20.130919
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2

# Generated at 2022-06-17 15:36:28.025747
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 0

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.x == 0
    assert t2.x == 0
    t1.x = 1
    assert t1.x == 1
    assert t2.x == 1

# Generated at 2022-06-17 15:36:30.766587
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:36:35.777204
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.test == 'test'
    assert b.test == 'test'

# Generated at 2022-06-17 15:36:39.436589
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1 is t2
    assert t1.test == t2.test

# Generated at 2022-06-17 15:36:49.531908
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    # Create two instances of TestSingleton
    test_singleton_1 = TestSingleton('test_singleton_1')
    test_singleton_2 = TestSingleton('test_singleton_2')

    # Check that both instances are the same
    assert test_singleton_1 is test_singleton_2

    # Check that the argument is the same for both instances
    assert test_singleton_1.arg == test_singleton_2.arg

    # Check that the argument is the same as the one passed to the
    # constructor
    assert test_singleton_1.arg == 'test_singleton_1'


# Generated at 2022-06-17 15:36:54.093950
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = Test(1)
    b = Test(2)

    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:36:58.400122
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b



# Generated at 2022-06-17 15:37:00.172672
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-17 15:37:04.061252
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:37:08.986022
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.arg == 1
    assert b.arg == 1

# Generated at 2022-06-17 15:37:16.343573
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    a = TestSingleton(1, 2, 3, foo='bar')
    b = TestSingleton(4, 5, 6, foo='baz')

    assert a is b
    assert a.args == (1, 2, 3)
    assert a.kwargs == {'foo': 'bar'}
    assert b.args == (1, 2, 3)
    assert b.kwargs == {'foo': 'bar'}

# Generated at 2022-06-17 15:37:21.373605
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:37:24.596893
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1.x == 1
    assert a2.x == 1
    assert a1 is a2


# Generated at 2022-06-17 15:37:32.192639
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2
    t2.a = 3
    assert t1.a == 3
    assert t2.a == 3

# Generated at 2022-06-17 15:37:36.129189
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 10

    a = MyClass()
    b = MyClass()
    assert a is b
    assert a.x == 10
    assert b.x == 10

    a.x = 20
    assert a.x == 20
    assert b.x == 20

# Generated at 2022-06-17 15:37:40.011967
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.x == 1
    assert t2.x == 1
    t1.x = 2
    assert t1.x == 2
    assert t2.x == 2

# Generated at 2022-06-17 15:37:48.442175
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    instance1 = TestSingleton(1)
    instance2 = TestSingleton(2)
    assert instance1.value == 1
    assert instance2.value == 1
    assert instance1 is instance2

# Generated at 2022-06-17 15:37:52.485063
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1



# Generated at 2022-06-17 15:37:55.663443
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()


# Generated at 2022-06-17 15:37:59.631726
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_attr = 'test'

    assert TestSingleton() is TestSingleton()
    assert TestSingleton().test_attr == 'test'

# Generated at 2022-06-17 15:38:04.344424
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:06.521524
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:38:11.845147
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:38:16.092861
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.test == test2.test

# Generated at 2022-06-17 15:38:24.722189
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.name == 'test'
    assert test2.name == 'test'
    test1.name = 'test1'
    assert test1.name == 'test1'
    assert test2.name == 'test1'
    test2.name = 'test2'
    assert test1.name == 'test2'
    assert test2.name == 'test2'

# Generated at 2022-06-17 15:38:34.180461
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.x == 1
    assert t2.x == 1
    t1.x = 2
    assert t1.x == 2
    assert t2.x == 2
    t2.x = 3
    assert t1.x == 3
    assert t2.x == 3

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-17 15:38:47.188678
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.test == 'test'
    assert t2.test == 'test'

# Generated at 2022-06-17 15:38:54.172910
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.test == 'test'
    assert test2.test == 'test'
    test1.test = 'test1'
    assert test1.test == 'test1'
    assert test2.test == 'test1'

# Generated at 2022-06-17 15:38:56.446471
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-17 15:39:01.062524
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    a = TestClass()
    b = TestClass()

    assert a is b
    assert a.value == 0
    assert b.value == 0

    a.inc()

    assert a.value == 1
    assert b.value == 1


# Generated at 2022-06-17 15:39:05.690970
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    t1 = Test(1)
    t2 = Test(2)

    assert t1.x == 1
    assert t2.x == 1
    assert t1 is t2

# Generated at 2022-06-17 15:39:10.080073
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 is test2
    assert test1.test == 'test'
    assert test2.test == 'test'

# Generated at 2022-06-17 15:39:13.970126
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.value == 1
    t1.value = 2
    assert t2.value == 2

# Generated at 2022-06-17 15:39:17.836278
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    instance1 = TestSingleton()
    instance2 = TestSingleton()
    assert instance1 is instance2


# Generated at 2022-06-17 15:39:20.108260
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:39:22.907075
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2



# Generated at 2022-06-17 15:39:43.370241
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:39:46.435364
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b

# Generated at 2022-06-17 15:39:52.500347
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def set_value(self, value):
            self.value = value

    test_singleton = TestSingleton()
    test_singleton.set_value(1)
    assert test_singleton.value == 1
    test_singleton_2 = TestSingleton()
    assert test_singleton_2.value == 1
    test_singleton_2.set_value(2)
    assert test_singleton.value == 2
    assert test_singleton_2.value == 2
    assert test_singleton is test_singleton_2

# Generated at 2022-06-17 15:39:59.723359
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    t1 = Test(1, 2, 3, a=4, b=5, c=6)
    t2 = Test(7, 8, 9, a=10, b=11, c=12)
    assert t1 is t2
    assert t1.args == (1, 2, 3)
    assert t1.kwargs == {'a': 4, 'b': 5, 'c': 6}

# Generated at 2022-06-17 15:40:02.663254
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:40:05.716031
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:40:07.121483
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2


# Generated at 2022-06-17 15:40:13.870013
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.value == 0
    assert t2.value == 0
    t1.value = 1
    assert t1.value == 1
    assert t2.value == 1
    t2.value = 2
    assert t1.value == 2
    assert t2.value == 2

# Generated at 2022-06-17 15:40:15.786183
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:40:18.663110
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:40:58.451418
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2

# Generated at 2022-06-17 15:41:02.579194
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == a2.a
    a1.a = 2
    assert a1.a == a2.a

# Generated at 2022-06-17 15:41:06.741888
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a == b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:41:09.809645
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1

# Generated at 2022-06-17 15:41:11.535833
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:41:14.849749
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()

    assert a == b
    assert a.x == b.x
    assert a is b

# Generated at 2022-06-17 15:41:16.123768
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:41:18.245755
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:41:23.116216
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1


# Generated at 2022-06-17 15:41:28.827430
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    b.a = 2
    assert a.a == 2
    assert b.a == 2

# Generated at 2022-06-17 15:42:37.830690
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:42:43.440039
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 is test2
    assert test1.test == test2.test

# Generated at 2022-06-17 15:42:47.066716
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-17 15:42:51.682778
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2


# Generated at 2022-06-17 15:42:55.857683
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.a == 1
    assert b.a == 1

    a.a = 2
    assert a.a == 2
    assert b.a == 2

# Generated at 2022-06-17 15:42:58.228189
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b



# Generated at 2022-06-17 15:42:59.700024
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:02.886135
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:04.583572
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestSingleton('a')
    b = TestSingleton('b')
    assert a is b
    assert a.name == 'b'

# Generated at 2022-06-17 15:43:07.124915
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1
    t1.value = 2
    assert t1.value == 2
    assert t2.value == 2

# Generated at 2022-06-17 15:44:22.737889
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:44:26.502413
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:44:30.969562
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.test == 'test'
    assert b.test == 'test'

# Generated at 2022-06-17 15:44:34.812093
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 == test2
    assert test1.test == 'test'
    assert test2.test == 'test'

# Generated at 2022-06-17 15:44:37.837067
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:44:42.074207
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:44:46.699276
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    t1 = Test(1)
    t2 = Test(2)
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1

# Generated at 2022-06-17 15:44:51.520864
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test1 = Test()
    test2 = Test()
    assert test1 is test2
    assert test1.test == 'test'
    assert test2.test == 'test'

# Generated at 2022-06-17 15:44:56.275667
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    test_singleton = TestSingleton()
    assert test_singleton.a == 1

    test_singleton.a = 2
    assert test_singleton.a == 2

    test_singleton2 = TestSingleton()
    assert test_singleton2.a == 2

# Generated at 2022-06-17 15:45:02.077522
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestClass(1)
    b = TestClass(2)
    assert a is b
    assert a.arg == 1
    assert b.arg == 1