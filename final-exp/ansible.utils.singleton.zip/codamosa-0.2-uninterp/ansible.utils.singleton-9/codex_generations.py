

# Generated at 2022-06-17 15:35:17.859458
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:35:25.223924
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    a = TestSingleton()
    a.inc()
    b = TestSingleton()
    b.inc()
    assert a is b
    assert a.value == 2
    assert b.value == 2



# Generated at 2022-06-17 15:35:32.442439
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:35:38.814289
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2


# Generated at 2022-06-17 15:35:41.684457
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    test1 = Test()
    test2 = Test()
    assert test1 is test2



# Generated at 2022-06-17 15:35:43.887944
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:35:47.532476
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    # Create two instances of TestSingleton
    instance1 = TestSingleton()
    instance2 = TestSingleton()

    # Check that both instances are the same
    assert instance1 is instance2


# Generated at 2022-06-17 15:35:49.065677
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:00.665777
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    class B(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.b = 2

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == a2.a
    assert a1.a == 1

    b1 = B()
    b2 = B()
    assert b1 is b2
    assert b1.b == b2.b
    assert b1.b == 2

if __name__ == "__main__":
    test_Singleton()

# Generated at 2022-06-17 15:36:06.258335
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    class TestClass2(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    assert TestClass(1) is TestClass(2)
    assert TestClass2(1) is TestClass2(2)
    assert TestClass(1) is not TestClass2(1)

# Generated at 2022-06-17 15:36:16.006442
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.bar = 'baz'

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2
    assert foo1.bar == 'baz'
    assert foo2.bar == 'baz'
    foo1.bar = 'qux'
    assert foo1.bar == 'qux'
    assert foo2.bar == 'qux'
    foo2.bar = 'quux'
    assert foo1.bar == 'quux'
    assert foo2.bar == 'quux'

# Generated at 2022-06-17 15:36:17.793800
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:20.662451
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    test_class_1 = TestClass()
    test_class_2 = TestClass()
    assert test_class_1 is test_class_2

# Generated at 2022-06-17 15:36:26.206668
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.test == b.test

# Generated at 2022-06-17 15:36:31.082130
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestClass(1)
    b = TestClass(2)
    assert a.arg == 1
    assert b.arg == 1
    assert a is b


# Generated at 2022-06-17 15:36:34.989320
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    assert test_singleton_1 is test_singleton_2

# Generated at 2022-06-17 15:36:40.022724
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 'test'

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:43.782283
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:36:48.461944
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:36:53.985485
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2

# Generated at 2022-06-17 15:36:59.226972
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-17 15:37:01.275114
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:37:08.741614
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1
    t1.value = 2
    assert t1.value == 2
    assert t2.value == 2
    t2.value = 3
    assert t1.value == 3
    assert t2.value == 3

# Generated at 2022-06-17 15:37:12.850483
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    t1.value = 1
    assert t2.value == 1

# Generated at 2022-06-17 15:37:21.292922
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def set_value(self, value):
            self.value = value

        def get_value(self):
            return self.value

    test_singleton = TestSingleton()
    test_singleton.set_value(1)
    assert test_singleton.get_value() == 1

    test_singleton2 = TestSingleton()
    assert test_singleton2.get_value() == 1
    test_singleton2.set_value(2)
    assert test_singleton2.get_value() == 2
    assert test_singleton.get_value() == 2


# Generated at 2022-06-17 15:37:22.595183
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-17 15:37:24.710150
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:37:26.931837
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    assert test_singleton_1 is test_singleton_2

# Generated at 2022-06-17 15:37:32.425164
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test_singleton = TestSingleton()
    assert test_singleton.test == 'test'

    test_singleton_2 = TestSingleton()
    assert test_singleton_2.test == 'test'

    assert test_singleton is test_singleton_2

# Generated at 2022-06-17 15:37:35.065439
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:37:45.859450
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert a is b


# Generated at 2022-06-17 15:37:49.734883
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:37:51.770429
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:37:56.709959
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a.a == 1
    assert b.a == 1
    assert a is b

# Generated at 2022-06-17 15:38:01.559015
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2


# Generated at 2022-06-17 15:38:09.920706
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    test_singleton = TestSingleton(1, 2)
    assert test_singleton.a == 1
    assert test_singleton.b == 2

    test_singleton_1 = TestSingleton(3, 4)
    assert test_singleton_1.a == 1
    assert test_singleton_1.b == 2

    assert test_singleton is test_singleton_1

# Generated at 2022-06-17 15:38:14.794396
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = Test(1, 2)
    t2 = Test(3, 4)
    assert t1 is t2
    assert t1.a == 1
    assert t1.b == 2
    assert t2.a == 1
    assert t2.b == 2

# Generated at 2022-06-17 15:38:20.078372
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:38:21.794350
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:25.773967
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    test1 = Test(1)
    test2 = Test(2)

    assert test1 is test2
    assert test1.arg == 1
    assert test2.arg == 1



# Generated at 2022-06-17 15:38:47.653458
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(metaclass=Singleton):
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == a2.a
    a1.a = 2
    assert a1.a == a2.a

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-17 15:38:50.656451
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a == b


# Generated at 2022-06-17 15:38:56.362280
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2

# Generated at 2022-06-17 15:38:59.886401
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a is b
    assert a.arg == 1
    assert b.arg == 1

# Generated at 2022-06-17 15:39:04.208903
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.test == test2.test

# Generated at 2022-06-17 15:39:08.421098
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = A()
    b = A()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:39:10.080354
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:39:11.425535
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b


# Generated at 2022-06-17 15:39:12.714497
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:39:17.798887
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()
    assert test_singleton_1 == test_singleton_2


# Generated at 2022-06-17 15:39:54.722234
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    a = TestClass(1, 2)
    b = TestClass(3, 4)
    assert a is b
    assert a.arg1 == 1
    assert a.arg2 == 2
    assert b.arg1 == 1
    assert b.arg2 == 2

# Generated at 2022-06-17 15:39:59.516181
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b



# Generated at 2022-06-17 15:40:06.467878
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    s1 = TestSingleton(1, 2)
    s2 = TestSingleton(3, 4)
    assert s1 is s2
    assert s1.a == 1
    assert s1.b == 2
    assert s2.a == 1
    assert s2.b == 2

# Generated at 2022-06-17 15:40:08.698714
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-17 15:40:11.739230
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b


# Generated at 2022-06-17 15:40:13.695623
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    assert MyClass() is MyClass()

# Generated at 2022-06-17 15:40:15.882717
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    assert SingletonTest() is SingletonTest()

# Generated at 2022-06-17 15:40:18.330774
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()

    assert a is b

# Generated at 2022-06-17 15:40:25.719547
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:40:28.328077
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:41:33.672604
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:41:39.448171
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    assert test_singleton_1 is test_singleton_2

# Generated at 2022-06-17 15:41:43.881129
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    assert TestSingleton(1) is TestSingleton(2)

# Generated at 2022-06-17 15:41:45.636158
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert a is b

# Generated at 2022-06-17 15:41:49.953200
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 == t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2

# Generated at 2022-06-17 15:41:54.954057
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestSingleton('a')
    b = TestSingleton('b')
    assert a is b
    assert a.name == 'b'

# Generated at 2022-06-17 15:41:58.744668
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = Test(1)
    b = Test(2)

    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:42:03.653959
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    t1 = TestSingleton('t1')
    t2 = TestSingleton('t2')
    assert t1 is t2
    assert t1.name == 't2'
    assert t2.name == 't2'

# Generated at 2022-06-17 15:42:09.271100
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2
    a2.a = 3
    assert a1.a == 3
    assert a2.a == 3

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-17 15:42:14.453667
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2

# Generated at 2022-06-17 15:43:21.545603
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.arg == 1
    assert b.arg == 1

# Generated at 2022-06-17 15:43:27.580992
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 1

    ts1 = TestSingleton()
    ts2 = TestSingleton()
    assert ts1 == ts2
    assert ts1.test == 1
    assert ts2.test == 1
    ts1.test = 2
    assert ts1.test == 2
    assert ts2.test == 2

# Generated at 2022-06-17 15:43:29.776713
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()



# Generated at 2022-06-17 15:43:32.236263
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:36.674099
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    a.increment()
    assert a.value == 1
    assert b.value == 1
    b.increment()
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:43:39.040336
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:42.042515
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-17 15:43:43.910300
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:48.347727
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 == t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2

# Generated at 2022-06-17 15:43:53.396817
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()
    assert test_singleton_1 == test_singleton_2
    assert test_singleton_1.a == 1
    assert test_singleton_2.a == 1

    test_singleton_1.a = 2
    assert test_singleton_1.a == 2
    assert test_singleton_2.a == 2

    test_singleton_2.a = 3
    assert test_singleton_1.a == 3
    assert test_singleton_2.a == 3

