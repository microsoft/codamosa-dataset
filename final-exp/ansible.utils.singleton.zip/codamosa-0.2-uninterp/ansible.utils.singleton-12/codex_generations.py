

# Generated at 2022-06-17 15:35:24.702825
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:35:31.145237
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()

    assert a is b
    assert a.value == 1
    assert b.value == 1

    a.value = 2

    assert a is b
    assert a.value == 2
    assert b.value == 2

    b.value = 3

    assert a is b
    assert a.value == 3
    assert b.value == 3

# Generated at 2022-06-17 15:35:35.535288
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.test == t2.test
    t1.test = 'test2'
    assert t1.test == t2.test

# Generated at 2022-06-17 15:35:41.897046
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    t1 = Test(1)
    t2 = Test(2)
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1

# Generated at 2022-06-17 15:35:49.882143
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    test_singleton_1 = TestSingleton(1, 2)
    test_singleton_2 = TestSingleton(3, 4)

    assert test_singleton_1 == test_singleton_2
    assert test_singleton_1.arg1 == 1
    assert test_singleton_1.arg2 == 2
    assert test_singleton_2.arg1 == 1
    assert test_singleton_2.arg2 == 2

# Generated at 2022-06-17 15:35:55.443259
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, value):
            self.value = value

    # Create two instances of TestSingleton
    instance1 = TestSingleton(1)
    instance2 = TestSingleton(2)

    # Check that instance1 and instance2 are the same object
    assert instance1 is instance2

    # Check that instance1.value and instance2.value are the same
    assert instance1.value == instance2.value

    # Check that instance1.value is 1
    assert instance1.value == 1

    # Check that instance2.value is 1
    assert instance2.value == 1

# Generated at 2022-06-17 15:36:04.110939
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    a = TestSingleton(1, 2, 3, foo='bar')
    b = TestSingleton(4, 5, 6, foo='baz')
    assert a is b
    assert a.args == (1, 2, 3)
    assert a.kwargs == {'foo': 'bar'}
    assert b.args == (1, 2, 3)
    assert b.kwargs == {'foo': 'bar'}

# Generated at 2022-06-17 15:36:07.316998
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.a == t2.a
    t1.a = 2
    assert t1.a == t2.a

# Generated at 2022-06-17 15:36:10.271215
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:14.908849
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestClass()
    b = TestClass()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:36:21.364413
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.arg == 1
    assert b.arg == 1

# Generated at 2022-06-17 15:36:29.579780
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestClass()
    b = TestClass()
    assert a is b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2
    b.value = 3
    assert a.value == 3
    assert b.value == 3


# Generated at 2022-06-17 15:36:33.832320
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:36:42.412277
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a == b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:36:55.222387
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_var = 1

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()
    assert test_singleton_1 is test_singleton_2
    assert test_singleton_1.test_var == 1
    assert test_singleton_2.test_var == 1
    test_singleton_1.test_var = 2
    assert test_singleton_1.test_var == 2
    assert test_singleton_2.test_var == 2
    test_singleton_2.test_var = 3
    assert test_singleton_1.test_var == 3
    assert test_singleton_2.test_var == 3

# Generated at 2022-06-17 15:36:57.866615
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:37:01.579803
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2

# Generated at 2022-06-17 15:37:06.380328
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    t1 = TestSingleton('foo')
    t2 = TestSingleton('bar')

    assert t1 is t2
    assert t1.arg == 'bar'

# Generated at 2022-06-17 15:37:08.452657
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:37:12.222216
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    a = Test()
    b = Test()
    assert a is b
    a.value = 1
    assert b.value == 1

# Generated at 2022-06-17 15:37:16.505147
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-17 15:37:21.449822
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a = A()
    assert a.a == 1
    b = A()
    assert b.a == 1
    assert id(a) == id(b)
    b.a = 2
    assert a.a == 2
    assert b.a == 2

# Generated at 2022-06-17 15:37:25.900246
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = TestSingleton(1, 2)
    t2 = TestSingleton(3, 4)
    assert t1 is t2
    assert t1.a == 1
    assert t1.b == 2
    assert t2.a == 1
    assert t2.b == 2

# Generated at 2022-06-17 15:37:31.307750
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1

# Generated at 2022-06-17 15:37:35.394353
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    t1 = Test()
    t2 = Test()

    assert t1 is t2
    assert t1.test == 'test'
    assert t2.test == 'test'

# Generated at 2022-06-17 15:37:39.340219
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:37:46.155453
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    a = TestClass()
    b = TestClass()
    a.increment()
    assert a.value == 1
    assert b.value == 1
    assert a is b


# Generated at 2022-06-17 15:37:48.574403
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b


# Generated at 2022-06-17 15:37:50.225517
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:37:52.114147
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:37:57.434252
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:02.166634
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()

    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1

    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2

# Generated at 2022-06-17 15:38:04.843600
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:38:09.144412
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:38:15.663893
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2
    t2.a = 3
    assert t1.a == 3
    assert t2.a == 3

# Generated at 2022-06-17 15:38:18.933735
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2


# Generated at 2022-06-17 15:38:21.262346
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:23.707578
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2


# Generated at 2022-06-17 15:38:25.483874
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:32.077764
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self, arg):
            self.arg = arg

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)
    assert t1 is t2
    assert t1.arg == 1
    assert t2.arg == 1

# Generated at 2022-06-17 15:38:46.781294
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    t1 = Test()
    t2 = Test()

    assert t1 is t2
    assert t1.x == 1
    assert t2.x == 1

    t1.x = 2
    assert t1.x == 2
    assert t2.x == 2


# Generated at 2022-06-17 15:38:51.275665
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_var = 1

    test_class_1 = TestClass()
    test_class_2 = TestClass()

    assert test_class_1 is test_class_2
    assert test_class_1.test_var == 1
    assert test_class_2.test_var == 1

    test_class_1.test_var = 2

    assert test_class_1 is test_class_2
    assert test_class_1.test_var == 2
    assert test_class_2.test_var == 2

# Generated at 2022-06-17 15:38:56.319369
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.a == t2.a
    t1.a = 2
    assert t1.a == t2.a

# Generated at 2022-06-17 15:38:59.048163
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2


# Generated at 2022-06-17 15:39:04.159983
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = MyClass()
    b = MyClass()
    assert a is b
    assert a.x == b.x
    a.x = 2
    assert a.x == b.x

# Generated at 2022-06-17 15:39:06.165547
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:39:10.571805
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1.a == 1
    assert a2.a == 1
    assert a1 is a2


# Generated at 2022-06-17 15:39:16.696496
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.test == 'test'
    assert test2.test == 'test'

# Generated at 2022-06-17 15:39:22.307574
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestSingleton('a')
    b = TestSingleton('b')
    assert a is b
    assert a.name == 'b'

# Generated at 2022-06-17 15:39:26.498239
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 0
    assert b.value == 0
    a.value = 1
    assert a.value == 1
    assert b.value == 1
    b.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:39:43.229673
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()

    assert t1 == t2
    assert t1.a == t2.a
    assert t1 is t2
    assert id(t1) == id(t2)

# Generated at 2022-06-17 15:39:45.874942
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:39:50.504861
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = TestSingleton(1, 2)
    t2 = TestSingleton(3, 4)
    assert t1 is t2
    assert t1.a == 1
    assert t1.b == 2
    assert t2.a == 1
    assert t2.b == 2

# Generated at 2022-06-17 15:39:57.562522
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 == test2
    assert test1.a == test2.a
    test1.a = 2
    assert test1.a == test2.a
    test2.a = 3
    assert test1.a == test2.a

# Generated at 2022-06-17 15:40:00.287946
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:40:05.276384
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = A(1)
    b = A(2)
    assert a is b
    assert a.x == 1
    assert b.x == 1

# Generated at 2022-06-17 15:40:10.695507
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    test_singleton = TestSingleton()
    assert test_singleton.a == 1

    test_singleton2 = TestSingleton()
    assert test_singleton2.a == 1

    test_singleton2.a = 2
    assert test_singleton.a == 2
    assert test_singleton2.a == 2

# Generated at 2022-06-17 15:40:12.544580
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()


# Generated at 2022-06-17 15:40:15.099587
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    assert TestSingleton() is TestSingleton()
    assert TestSingleton().a == 1

# Generated at 2022-06-17 15:40:19.622757
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()

    assert a is b
    assert a.test == 'test'
    assert b.test == 'test'

# Generated at 2022-06-17 15:40:40.478202
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_var = 1

    assert TestSingleton().test_var == 1
    assert TestSingleton().test_var == 1

# Generated at 2022-06-17 15:40:48.457317
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2
    b.x = 3
    assert a.x == 3
    assert b.x == 3


# Generated at 2022-06-17 15:40:50.883214
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:40:58.296178
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 1
    assert b.value == 1

    a.value = 2
    assert a.value == 2
    assert b.value == 2



# Generated at 2022-06-17 15:41:00.938462
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()

    assert a is b


# Generated at 2022-06-17 15:41:04.242373
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    a = TestClass(1)
    b = TestClass(2)
    assert a is b
    assert a.val == 1
    assert b.val == 1


# Generated at 2022-06-17 15:41:07.878825
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)

    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1

# Generated at 2022-06-17 15:41:11.610287
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    test_class_1 = TestClass(1)
    test_class_2 = TestClass(2)

    assert test_class_1 is test_class_2
    assert test_class_1.value == 1
    assert test_class_2.value == 1

# Generated at 2022-06-17 15:41:13.681311
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:41:18.282765
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2
    b.a = 3
    assert a.a == 3
    assert b.a == 3

# Generated at 2022-06-17 15:41:55.270645
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1



# Generated at 2022-06-17 15:41:58.742346
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()

    assert a is b
    assert a.test == b.test

# Generated at 2022-06-17 15:42:00.780756
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:42:06.071039
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = TestSingleton(1, 2)
    t2 = TestSingleton(3, 4)
    assert t1 is t2
    assert t1.a == 1
    assert t1.b == 2
    assert t2.a == 1
    assert t2.b == 2

# Generated at 2022-06-17 15:42:10.830803
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1

# Generated at 2022-06-17 15:42:16.316166
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2
    b.a = 3
    assert a.a == 3
    assert b.a == 3

# Generated at 2022-06-17 15:42:18.102796
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class MyClass(object):
        __metaclass__ = Singleton

    a = MyClass()
    b = MyClass()
    assert a is b


# Generated at 2022-06-17 15:42:20.422379
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class SingletonTest(object):
        __metaclass__ = Singleton

    a = SingletonTest()
    b = SingletonTest()
    assert a is b

# Generated at 2022-06-17 15:42:22.527139
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    assert MyClass() is MyClass()

# Generated at 2022-06-17 15:42:28.122292
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1
    t1.value = 2
    assert t1.value == 2
    assert t2.value == 2
    t2.value = 3
    assert t1.value == 3
    assert t2.value == 3

# Generated at 2022-06-17 15:43:35.297050
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2


# Generated at 2022-06-17 15:43:41.700666
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == b.value
    a.value = 2
    assert a.value == b.value

# Generated at 2022-06-17 15:43:44.428105
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:43:47.592957
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    test_class_1 = TestClass()
    test_class_2 = TestClass()
    assert test_class_1 is test_class_2


# Generated at 2022-06-17 15:43:51.776850
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 0
    assert b.value == 0
    a.value = 1
    assert a.value == 1
    assert b.value == 1


# Generated at 2022-06-17 15:43:53.153189
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:43:58.542833
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)
    assert t1 is t2
    assert t1.value == 2
    assert t2.value == 2

# Generated at 2022-06-17 15:44:01.271605
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    test_class_1 = TestClass()
    test_class_2 = TestClass()

    assert test_class_1 is test_class_2

# Generated at 2022-06-17 15:44:03.361573
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2

# Generated at 2022-06-17 15:44:07.986333
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    t1 = TestSingleton(1, 2)
    t2 = TestSingleton(3, 4)
    assert t1 is t2
    assert t1.a == 1
    assert t1.b == 2

# Generated at 2022-06-17 15:45:15.396779
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b