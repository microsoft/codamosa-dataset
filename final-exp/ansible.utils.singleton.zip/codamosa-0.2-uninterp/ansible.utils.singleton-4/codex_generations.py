

# Generated at 2022-06-17 15:35:21.088351
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:35:27.490236
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.a == 1
    assert test2.a == 1
    test1.a = 2
    assert test1.a == 2
    assert test2.a == 2

# Generated at 2022-06-17 15:35:30.394533
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:35:35.601586
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = Test()
    b = Test()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2
    b.x = 3
    assert a.x == 3
    assert b.x == 3

# Generated at 2022-06-17 15:35:41.966958
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:35:45.335262
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:35:49.229488
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == a2.a
    a1.a = 2
    assert a1.a == a2.a

# Generated at 2022-06-17 15:35:55.845115
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = TestSingleton('a')
    b = TestSingleton('b')
    assert a is b
    assert a.name == 'b'
    assert b.name == 'b'

# Generated at 2022-06-17 15:35:57.748972
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:00.665730
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b


# Generated at 2022-06-17 15:36:07.656609
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1

    a.x = 2
    assert a.x == 2
    assert b.x == 2

    b.x = 3
    assert a.x == 3
    assert b.x == 3



# Generated at 2022-06-17 15:36:13.103620
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    t1 = Test(1)
    t2 = Test(2)
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1

# Generated at 2022-06-17 15:36:16.511577
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-17 15:36:19.057052
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:36:22.282372
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    test_class_1 = TestClass()
    test_class_2 = TestClass()

    assert test_class_1 is test_class_2
    assert test_class_1.a == test_class_2.a


# Generated at 2022-06-17 15:36:25.998268
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-17 15:36:28.697690
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:36:33.534577
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-17 15:36:42.187947
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test_singleton = TestSingleton()
    assert test_singleton.test == 'test'

    test_singleton2 = TestSingleton()
    assert test_singleton2.test == 'test'

    assert test_singleton is test_singleton2

# Generated at 2022-06-17 15:36:44.654037
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:36:54.248957
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2

# Generated at 2022-06-17 15:36:59.413135
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a == b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:37:07.247852
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1
    t1.value = 2
    assert t1.value == 2
    assert t2.value == 2
    t2.value = 3
    assert t1.value == 3
    assert t2.value == 3

# Generated at 2022-06-17 15:37:10.049729
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2

# Generated at 2022-06-17 15:37:15.971620
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1
    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2
    a2.a = 3
    assert a1.a == 3
    assert a2.a == 3

# Generated at 2022-06-17 15:37:22.586589
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    # Create first instance of TestSingleton
    test_singleton_1 = TestSingleton(1)

    # Create second instance of TestSingleton
    test_singleton_2 = TestSingleton(2)

    # Check that both instances are the same
    assert test_singleton_1 is test_singleton_2

    # Check that the value of the second instance is not 2
    assert test_singleton_2.value != 2

# Generated at 2022-06-17 15:37:26.347390
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1


# Generated at 2022-06-17 15:37:29.655389
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    # Test that two instances of TestSingleton are the same
    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 2

# Generated at 2022-06-17 15:37:31.842173
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:37:36.331682
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-17 15:37:48.276640
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:37:53.274456
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.a == 1
    assert test2.a == 1
    test1.a = 2
    assert test1.a == 2
    assert test2.a == 2

# Generated at 2022-06-17 15:37:57.697498
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()
    assert test_singleton_1 is test_singleton_2


# Generated at 2022-06-17 15:38:00.111025
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    a = TestClass()
    b = TestClass()
    assert a is b


# Generated at 2022-06-17 15:38:03.224706
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()



# Generated at 2022-06-17 15:38:05.663052
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:38:09.037160
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = MyClass()
    b = MyClass()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:38:13.236799
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton('a')
    b = TestSingleton('b')
    assert a is b
    assert a.arg == 'b'

# Generated at 2022-06-17 15:38:15.782663
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:38:23.446910
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2
    a2.a = 3
    assert a1.a == 3
    assert a2.a == 3

# Generated at 2022-06-17 15:38:48.951075
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1

# Generated at 2022-06-17 15:38:52.295512
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:38:54.090206
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:56.007561
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-17 15:38:58.959725
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    assert TestSingleton() is TestSingleton()
    assert TestSingleton().a == 1

# Generated at 2022-06-17 15:39:02.004831
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:39:05.140758
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1

    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2

# Generated at 2022-06-17 15:39:09.427621
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test = True

    t1 = Test()
    t2 = Test()

    assert t1 is t2
    assert t1.test is True
    assert t2.test is True

# Generated at 2022-06-17 15:39:12.841172
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1
    t1.value = 2
    assert t1.value == 2
    assert t2.value == 2

# Generated at 2022-06-17 15:39:20.798645
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    test_singleton = TestSingleton()
    assert test_singleton.value == 0
    test_singleton.value = 1
    assert test_singleton.value == 1
    test_singleton2 = TestSingleton()
    assert test_singleton2.value == 1
    test_singleton2.value = 2
    assert test_singleton2.value == 2
    assert test_singleton.value == 2
    assert test_singleton is test_singleton2

# Generated at 2022-06-17 15:40:06.952058
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:40:10.212740
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:40:13.612521
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestClass(1)
    b = TestClass(2)

    assert a is b
    assert a.arg == 1
    assert b.arg == 1

# Generated at 2022-06-17 15:40:14.938647
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:40:18.733702
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    s1 = TestSingleton()
    s2 = TestSingleton()
    assert s1 is s2
    assert s1.x == 1
    assert s2.x == 1
    s1.x = 2
    assert s1.x == 2
    assert s2.x == 2
    s2.x = 3
    assert s1.x == 3
    assert s2.x == 3

# Generated at 2022-06-17 15:40:26.102621
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    s1 = TestSingleton()
    s2 = TestSingleton()
    assert s1 is s2
    assert s1.x == 1
    assert s2.x == 1
    s1.x = 2
    assert s1.x == 2
    assert s2.x == 2

# Generated at 2022-06-17 15:40:32.097092
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 1

    a = Test()
    b = Test()
    assert a is b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2
    b.value = 3
    assert a.value == 3
    assert b.value == 3

# Generated at 2022-06-17 15:40:36.074454
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2

    t1.increment()
    assert t1.value == 1
    assert t2.value == 1

    t2.increment()
    assert t1.value == 2
    assert t2.value == 2

# Generated at 2022-06-17 15:40:46.471946
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.test_var = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.test_var == 'test'
    assert b.test_var == 'test'
    a.test_var = 'test2'
    assert a.test_var == 'test2'
    assert b.test_var == 'test2'

# Generated at 2022-06-17 15:40:48.263625
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:42:22.849902
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    a.increment()
    assert a.value == 1
    b.increment()
    assert b.value == 2
    assert a.value == 2


# Generated at 2022-06-17 15:42:25.640724
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    assert Test() is Test()

# Generated at 2022-06-17 15:42:28.154984
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()



# Generated at 2022-06-17 15:42:36.936916
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def set_value(self, value):
            self.value = value

        def get_value(self):
            return self.value

    # Create two instances of TestSingleton
    instance1 = TestSingleton()
    instance2 = TestSingleton()

    # Check that both instances are the same
    assert instance1 is instance2

    # Set value for instance1
    instance1.set_value(1)

    # Check that value of instance2 is the same as value of instance1
    assert instance2.get_value() == 1

# Generated at 2022-06-17 15:42:45.523811
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def set_value(self, value):
            self.value = value

        def get_value(self):
            return self.value

    # Create two instances of TestSingleton
    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    # Check that both instances are the same
    assert test_singleton_1 is test_singleton_2

    # Set a value on the first instance
    test_singleton_1.set_value(1)

    # Check that the value is the same on the second instance
    assert test_singleton_2.get_value() == 1

# Generated at 2022-06-17 15:42:53.468445
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    obj1 = TestSingleton(1, 2)
    obj2 = TestSingleton(3, 4)

    assert obj1 is obj2
    assert obj1.a == 1
    assert obj1.b == 2

# Generated at 2022-06-17 15:42:58.063359
# Unit test for constructor of class Singleton
def test_Singleton():
    class Foo(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    foo1 = Foo(1)
    foo2 = Foo(2)
    assert foo1 is foo2
    assert foo1.value == 1
    assert foo2.value == 1



# Generated at 2022-06-17 15:43:01.976833
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == a2.a
    a1.a = 2
    assert a1.a == a2.a



# Generated at 2022-06-17 15:43:08.992498
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    class MyClass2(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 2

    a = MyClass()
    b = MyClass()
    c = MyClass2()
    d = MyClass2()

    assert a is b
    assert c is d
    assert a is not c

# Generated at 2022-06-17 15:43:14.481432
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestClass()
    t2 = TestClass()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2
    t2.a = 3
    assert t1.a == 3
    assert t2.a == 3

# Generated at 2022-06-17 15:44:56.818077
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.x == 1
    assert t2.x == 1
    t1.x = 2
    assert t1.x == 2
    assert t2.x == 2



# Generated at 2022-06-17 15:45:02.221540
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.test == b.test
    assert a.test == 'test'

# Generated at 2022-06-17 15:45:10.152886
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()

    assert a is b
    assert a.x == 1
    assert b.x == 1

    a.x = 2
    assert a.x == 2
    assert b.x == 2

    b.x = 3
    assert a.x == 3
    assert b.x == 3

# Generated at 2022-06-17 15:45:14.142915
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    s1 = TestSingleton(1)
    s2 = TestSingleton(2)
    assert s1 is s2
    assert s1.x == s2.x == 1

# Generated at 2022-06-17 15:45:16.570000
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

