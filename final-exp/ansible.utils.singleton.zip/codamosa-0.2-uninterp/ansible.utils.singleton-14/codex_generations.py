

# Generated at 2022-06-17 15:35:20.829085
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Foo(object):
        __metaclass__ = Singleton

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2


# Generated at 2022-06-17 15:35:23.626258
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-17 15:35:26.620522
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:35:34.551424
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    a = TestClass()
    b = TestClass()

    assert a is b
    assert a.value == 0
    assert b.value == 0

    a.increment()
    assert a.value == 1
    assert b.value == 1

    b.increment()
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:35:40.949997
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == b.a
    a.a = 2
    assert a.a == b.a

# Generated at 2022-06-17 15:35:44.983323
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a1 = A()
    a2 = A()

    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1

    a1.x = 2

    assert a1.x == 2
    assert a2.x == 2



# Generated at 2022-06-17 15:35:49.186524
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2


# Generated at 2022-06-17 15:35:56.768618
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:36:00.053624
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    s1 = TestSingleton()
    s2 = TestSingleton()
    assert s1 is s2


# Generated at 2022-06-17 15:36:02.823549
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

