

# Generated at 2022-06-17 15:35:15.541917
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == b.a


# Generated at 2022-06-17 15:35:19.181574
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 is test2
    assert test1.a == 1
    assert test2.a == 1

    test1.a = 2

    assert test1.a == 2
    assert test2.a == 2

# Generated at 2022-06-17 15:35:25.270976
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton('a')
    b = TestSingleton('b')
    assert a is b
    assert a.arg == 'a'
    assert b.arg == 'a'


# Generated at 2022-06-17 15:35:32.087007
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.value == 0
    t1.value = 1
    assert t1.value == t2.value



# Generated at 2022-06-17 15:35:37.187277
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a.arg == 1
    assert b.arg == 1
    assert a is b

# Generated at 2022-06-17 15:35:40.337911
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:35:44.633098
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    assert TestSingleton(1) is TestSingleton(2)

# Generated at 2022-06-17 15:35:49.186751
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    s1 = TestSingleton(1, 2)
    s2 = TestSingleton(3, 4)

    assert s1 is s2
    assert s1.a == 1
    assert s1.b == 2

# Generated at 2022-06-17 15:35:55.869580
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    t1 = Test(1)
    t2 = Test(2)
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1


# Generated at 2022-06-17 15:36:03.043084
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2
    a2.a = 3
    assert a1.a == 3
    assert a2.a == 3

# Generated at 2022-06-17 15:36:11.985274
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 == a2
    assert a1.a == a2.a
    a1.a = 2
    assert a1.a == a2.a

# Generated at 2022-06-17 15:36:20.554157
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    a.inc()
    assert a.value == 1
    assert b.value == 1
    b.inc()
    assert a.value == 2
    assert b.value == 2



# Generated at 2022-06-17 15:36:26.951605
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.x == 1
    assert a2.x == 1


# Generated at 2022-06-17 15:36:29.792337
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    t1 = Test()
    t2 = Test()
    assert t1 == t2
    assert t1.x == t2.x
    t1.x = 2
    assert t1.x == t2.x

# Generated at 2022-06-17 15:36:33.244170
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    assert test_singleton_1 is test_singleton_2

# Generated at 2022-06-17 15:36:38.570127
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self, a):
            self.a = a

    a1 = A(1)
    a2 = A(2)
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1


# Generated at 2022-06-17 15:36:41.441621
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:44.924182
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 0

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 0
    a.value = 1
    assert b.value == 1



# Generated at 2022-06-17 15:36:51.501663
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = Test(1)
    b = Test(2)

    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:36:54.663004
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    assert TestSingleton().value == 1
    assert TestSingleton().value == 1

# Generated at 2022-06-17 15:37:02.329377
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestClass(1)
    b = TestClass(2)

    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:37:06.690383
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()

    assert a1 is a2



# Generated at 2022-06-17 15:37:09.558842
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-17 15:37:14.826009
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2

# Generated at 2022-06-17 15:37:19.072321
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()

    assert a is b
    assert a.test == 'test'
    assert b.test == 'test'

# Generated at 2022-06-17 15:37:21.488280
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b



# Generated at 2022-06-17 15:37:24.581325
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    t1 = TestSingleton('foo')
    t2 = TestSingleton('bar')
    assert t1 is t2
    assert t1.name == 'bar'

# Generated at 2022-06-17 15:37:26.678759
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    a = Test()
    b = Test()
    assert a is b


# Generated at 2022-06-17 15:37:29.897915
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-17 15:37:33.296599
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a.value == 1
    assert b.value == 1
    assert a is b

# Generated at 2022-06-17 15:37:44.199289
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.a == 1
    t1.a = 2
    assert t2.a == 2

# Generated at 2022-06-17 15:37:45.919522
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:37:47.918357
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:37:51.706423
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == b.value == 1

# Generated at 2022-06-17 15:37:58.805738
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1

    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2


# Generated at 2022-06-17 15:38:00.313435
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:38:04.707349
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:38:13.160591
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    a.increment()
    assert a.value == 1
    assert b.value == 1
    b.increment()
    assert a.value == 2
    assert b.value == 2


# Generated at 2022-06-17 15:38:20.911231
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2
    a2.a = 3
    assert a1.a == 3
    assert a2.a == 3

# Generated at 2022-06-17 15:38:24.579372
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, a):
            self.a = a

    t1 = Test(1)
    t2 = Test(2)
    assert t1.a == 1
    assert t2.a == 1
    assert t1 is t2

# Generated at 2022-06-17 15:38:34.945992
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-17 15:38:45.122492
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    # Create an instance of MyClass
    my_class = MyClass("MyClass")

    # Create another instance of MyClass
    my_class2 = MyClass("MyClass2")

    # Check if both instances are the same
    assert my_class == my_class2

    # Check if both instances have the same name
    assert my_class.name == my_class2.name

# Generated at 2022-06-17 15:38:48.530885
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.test == b.test

# Generated at 2022-06-17 15:38:54.867558
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 1
    assert b.value == 1

    a.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:38:57.262942
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-17 15:38:59.945364
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:39:06.504191
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    a.increment()
    assert a.value == 1
    assert b.value == 1
    b.increment()
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:39:11.477710
# Unit test for constructor of class Singleton
def test_Singleton():
    class MySingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = MySingleton()
    b = MySingleton()
    assert a is b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:39:15.299585
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(metaclass=Singleton):
        def __init__(self, a):
            self.a = a

    t1 = Test(1)
    t2 = Test(2)
    assert t1.a == 1
    assert t2.a == 1
    assert t1 is t2


if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-17 15:39:20.108299
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()

    assert a is b

# Generated at 2022-06-17 15:39:31.167412
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2

# Generated at 2022-06-17 15:39:36.346532
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.test == 'test'
    assert t2.test == 'test'


# Generated at 2022-06-17 15:39:40.236772
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:39:44.132609
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:39:48.246229
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == b.a
    assert a.a == 1

    a.a = 2
    assert a.a == b.a
    assert a.a == 2

# Generated at 2022-06-17 15:39:58.002250
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    t1 = Test(1, 2, 3, a=4, b=5, c=6)
    t2 = Test(7, 8, 9, d=10, e=11, f=12)

    assert t1 is t2
    assert t1.args == (1, 2, 3)
    assert t1.kwargs == {'a': 4, 'b': 5, 'c': 6}
    assert t2.args == (1, 2, 3)
    assert t2.kwargs == {'a': 4, 'b': 5, 'c': 6}

# Generated at 2022-06-17 15:40:05.131470
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a == b
    assert a.x == b.x
    assert a is b
    a.x = 2
    assert a.x == b.x
    assert a is b

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-17 15:40:07.372875
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == b.value == 1

# Generated at 2022-06-17 15:40:13.802976
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2
    a2.a = 3
    assert a1.a == 3
    assert a2.a == 3

# Generated at 2022-06-17 15:40:15.176850
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:40:39.106521
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert(a is b)

if __name__ == '__main__':
    test_Singleton()

# Generated at 2022-06-17 15:40:46.197909
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = A(1)
    b = A(2)
    assert a.x == 1
    assert b.x == 1
    assert a is b


# Generated at 2022-06-17 15:40:47.451069
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-17 15:40:50.492842
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.name = 'test'

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.name == 'test'
    assert t2.name == 'test'

# Generated at 2022-06-17 15:40:58.603104
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, a, b):
            self.a = a
            self.b = b

    s1 = TestSingleton(1, 2)
    s2 = TestSingleton(3, 4)

    assert s1 is s2
    assert s1.a == 1
    assert s1.b == 2
    assert s2.a == 1
    assert s2.b == 2

# Generated at 2022-06-17 15:41:00.590153
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()



# Generated at 2022-06-17 15:41:02.042789
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:41:07.659198
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2

# Generated at 2022-06-17 15:41:12.891760
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a is b
    assert a.value == b.value == 1

# Generated at 2022-06-17 15:41:14.885049
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b



# Generated at 2022-06-17 15:41:54.190466
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

    a = MyClass()
    b = MyClass()
    assert a is b

# Generated at 2022-06-17 15:41:56.858417
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    obj1 = TestSingleton()
    obj2 = TestSingleton()
    assert obj1 is obj2


# Generated at 2022-06-17 15:42:02.748735
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    a = TestSingleton(1, 2, 3, foo='bar')
    b = TestSingleton(4, 5, 6, foo='baz')

    assert a is b
    assert a.args == (1, 2, 3)
    assert a.kwargs == {'foo': 'bar'}
    assert b.args == (1, 2, 3)
    assert b.kwargs == {'foo': 'bar'}

# Generated at 2022-06-17 15:42:08.749135
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.test == 'test'
    assert t2.test == 'test'

    t1.test = 'test1'
    assert t1.test == 'test1'
    assert t2.test == 'test1'

    t2.test = 'test2'
    assert t1.test == 'test2'
    assert t2.test == 'test2'

# Generated at 2022-06-17 15:42:11.504753
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:42:13.333085
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:42:15.549193
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:42:21.297558
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    a.increment()
    assert a.value == 1
    assert b.value == 1
    b.increment()
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:42:25.821509
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestClass(1)
    b = TestClass(2)

    assert a is b
    assert a.value == 1
    assert b.value == 1



# Generated at 2022-06-17 15:42:29.632205
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:43:16.631517
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 0
    assert b.value == 0
    a.value = 1
    assert a.value == 1
    assert b.value == 1
    b.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:43:22.427183
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:43:24.731471
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2


# Generated at 2022-06-17 15:43:28.381471
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.test == b.test

# Generated at 2022-06-17 15:43:33.374900
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    test_singleton_1 = TestSingleton(1)
    test_singleton_2 = TestSingleton(2)

    assert test_singleton_1 is test_singleton_2
    assert test_singleton_1.value == 1
    assert test_singleton_2.value == 1

# Generated at 2022-06-17 15:43:39.500996
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()
    assert test1 is test2
    assert test1.test == test2.test

# Generated at 2022-06-17 15:43:41.414484
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:44.158963
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:43:47.990146
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 0

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    a.x = 1
    assert b.x == 1
    b.x = 2
    assert a.x == 2


# Generated at 2022-06-17 15:43:49.319545
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

