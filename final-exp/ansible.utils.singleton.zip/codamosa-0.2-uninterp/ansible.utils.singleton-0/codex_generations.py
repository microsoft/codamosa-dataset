

# Generated at 2022-06-17 15:35:19.029876
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    s1 = TestSingleton('s1')
    s2 = TestSingleton('s2')

    assert s1.name == 's1'
    assert s2.name == 's1'
    assert s1 is s2

# Generated at 2022-06-17 15:35:21.641777
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()


# Generated at 2022-06-17 15:35:23.609505
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-17 15:35:26.620282
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 is a2


# Generated at 2022-06-17 15:35:33.222374
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2

# Generated at 2022-06-17 15:35:37.744290
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:35:44.053827
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = A(1)
    b = A(2)

    assert a is b
    assert a.x == 1
    assert b.x == 1

# Generated at 2022-06-17 15:35:45.832254
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:35:48.468477
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    t1 = Test(1)
    t2 = Test(2)
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1



# Generated at 2022-06-17 15:35:51.146192
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    assert test_singleton_1 is test_singleton_2

# Generated at 2022-06-17 15:35:56.132146
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2


# Generated at 2022-06-17 15:36:02.453886
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    s = TestSingleton()
    assert s.value == 1
    s.value = 2
    assert s.value == 2
    s2 = TestSingleton()
    assert s2.value == 2
    s2.value = 3
    assert s2.value == 3
    assert s.value == 3

# Generated at 2022-06-17 15:36:05.903154
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    test_singleton = TestSingleton()
    assert test_singleton.value == 0
    test_singleton.inc()
    assert test_singleton.value == 1

    test_singleton2 = TestSingleton()
    assert test_singleton2.value == 1
    test_singleton2.inc()
    assert test_singleton2.value == 2

    assert test_singleton is test_singleton2


# Generated at 2022-06-17 15:36:09.657321
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b
    assert a == b

# Generated at 2022-06-17 15:36:15.319127
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 1
    assert b.value == 1
    a.value = 2
    assert a.value == 2
    assert b.value == 2
    b.value = 3
    assert a.value == 3
    assert b.value == 3

# Generated at 2022-06-17 15:36:17.099335
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:22.506973
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.value == 1
    assert t2.value == 1
    t1.value = 2
    assert t1.value == 2
    assert t2.value == 2
    t2.value = 3
    assert t1.value == 3
    assert t2.value == 3


# Generated at 2022-06-17 15:36:30.321641
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()

    assert a is b
    assert a.value == 1
    assert b.value == 1

    a.value = 2
    assert a.value == 2
    assert b.value == 2

    b.value = 3
    assert a.value == 3
    assert b.value == 3

# Generated at 2022-06-17 15:36:35.268218
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2


# Generated at 2022-06-17 15:36:41.430086
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2