

# Generated at 2022-06-17 15:35:24.750093
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2


# Generated at 2022-06-17 15:35:28.957339
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.a == 1
    t1.a = 2
    assert t2.a == 2
    assert t1 is t2

# Generated at 2022-06-17 15:35:31.780649
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    assert TestSingleton('foo') is TestSingleton('bar')

# Generated at 2022-06-17 15:35:40.423553
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    t1 = Test()
    t2 = Test()

    assert t1 is t2
    assert t1.value == 0
    assert t2.value == 0

    t1.value = 1

    assert t1.value == 1
    assert t2.value == 1

    t2.value = 2

    assert t1.value == 2
    assert t2.value == 2



# Generated at 2022-06-17 15:35:42.492014
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2


# Generated at 2022-06-17 15:35:45.339724
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:35:47.573437
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:35:49.107632
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()


# Generated at 2022-06-17 15:35:52.771541
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()



# Generated at 2022-06-17 15:35:55.126070
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()


# Generated at 2022-06-17 15:36:01.829579
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a.arg == 1
    assert b.arg == 1
    assert a is b

# Generated at 2022-06-17 15:36:04.430278
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:36:09.657182
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 is test2
    assert test1.a == 1
    assert test2.a == 1

# Generated at 2022-06-17 15:36:12.078354
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-17 15:36:19.475890
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    test_class_1 = TestClass(1)
    test_class_2 = TestClass(2)

    assert test_class_1.value == 1
    assert test_class_2.value == 1
    assert test_class_1 is test_class_2

# Generated at 2022-06-17 15:36:20.993949
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-17 15:36:27.362057
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 == a2
    assert a1.a == a2.a
    a1.a = 2
    assert a1.a == a2.a

# Generated at 2022-06-17 15:36:30.390691
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    a = A()
    b = A()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2

# Generated at 2022-06-17 15:36:32.810290
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.value = 1

    ts1 = TestSingleton()
    ts2 = TestSingleton()
    assert ts1 == ts2
    assert ts1.value == ts2.value
    ts1.value = 2
    assert ts1.value == ts2.value

# Generated at 2022-06-17 15:36:37.269774
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 'test'

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:36:49.507560
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    t1 = Test(1, 2, 3, a=1, b=2, c=3)
    t2 = Test(4, 5, 6, d=4, e=5, f=6)

    assert t1 is t2
    assert t1.args == (1, 2, 3)
    assert t1.kwargs == {'a': 1, 'b': 2, 'c': 3}
    assert t2.args == (1, 2, 3)
    assert t2.kwargs == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 15:36:54.041090
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:36:56.810764
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b



# Generated at 2022-06-17 15:37:00.300377
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    s1 = TestSingleton(1)
    s2 = TestSingleton(2)
    assert s1 is s2
    assert s1.arg == 1
    assert s2.arg == 1

# Generated at 2022-06-17 15:37:07.439549
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    assert test_singleton_1 is test_singleton_2
    assert test_singleton_1.test == test_singleton_2.test

# Generated at 2022-06-17 15:37:11.657628
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)

    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:37:14.105665
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:37:18.902706
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

        def increment(self):
            self.value += 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    a.increment()
    assert b.value == 1



# Generated at 2022-06-17 15:37:22.546817
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 == test2
    assert test1.test == test2.test

# Generated at 2022-06-17 15:37:25.778783
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingleton2(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()
    assert TestSingleton2() is TestSingleton2()
    assert TestSingleton() is not TestSingleton2()



# Generated at 2022-06-17 15:37:35.757380
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    t1 = Test(1, 2, 3, a=1, b=2, c=3)
    t2 = Test(4, 5, 6, d=4, e=5, f=6)

    assert t1 is t2
    assert t1.args == (1, 2, 3)
    assert t1.kwargs == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 15:37:37.296438
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2



# Generated at 2022-06-17 15:37:45.156156
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.value == 0
    assert b.value == 0
    a.value = 1
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:37:47.036023
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    assert TestSingleton().a == 1
    assert TestSingleton().a == 1

# Generated at 2022-06-17 15:37:49.825574
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:37:56.581719
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = "test"

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()
    assert test_singleton_1 is test_singleton_2
    assert test_singleton_1.test == test_singleton_2.test

# Generated at 2022-06-17 15:38:03.592216
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    # Create two instances of TestSingleton
    s1 = TestSingleton()
    s2 = TestSingleton()

    # Check that they are the same instance
    assert s1 is s2

    # Check that the value of x is the same for both instances
    assert s1.x == s2.x

    # Change the value of x for s1
    s1.x = 2

    # Check that the value of x is the same for both instances
    assert s1.x == s2.x

# Generated at 2022-06-17 15:38:05.582145
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()


# Generated at 2022-06-17 15:38:13.649954
# Unit test for constructor of class Singleton
def test_Singleton():
    class SingletonTest(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    class SingletonTest2(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 2

    assert SingletonTest().value == 1
    assert SingletonTest2().value == 2
    assert SingletonTest() is SingletonTest()
    assert SingletonTest2() is SingletonTest2()
    assert SingletonTest() is not SingletonTest2()

# Generated at 2022-06-17 15:38:16.460807
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:38:30.412439
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton('a')
    b = TestSingleton('b')
    assert a is b
    assert a.arg == 'b'

# Generated at 2022-06-17 15:38:35.181231
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.val = 1

    a = Test()
    b = Test()
    assert a is b
    assert a.val == 1
    assert b.val == 1
    a.val = 2
    assert a.val == 2
    assert b.val == 2

# Generated at 2022-06-17 15:38:40.340751
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:43.883088
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:38:47.803396
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test_singleton = TestSingleton()
    assert test_singleton.test == 'test'
    assert test_singleton is TestSingleton()

# Generated at 2022-06-17 15:38:53.036009
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self, x):
            self.x = x

    a = A(1)
    b = A(2)
    assert a is b
    assert a.x == 1
    assert b.x == 1

# Generated at 2022-06-17 15:38:55.273886
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-17 15:38:56.996171
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:38:59.144434
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:39:01.214477
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:39:11.409053
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    t1 = Test(1)
    t2 = Test(2)
    assert t1 is t2
    assert t1.arg == 1
    assert t2.arg == 1

# Generated at 2022-06-17 15:39:15.456585
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.x == 1
    assert b.x == 1
    a.x = 2
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-17 15:39:25.281170
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    s1 = TestSingleton()
    s2 = TestSingleton()
    assert s1 is s2
    assert s1.x == 1
    assert s2.x == 1
    s1.x = 2
    assert s1.x == 2
    assert s2.x == 2
    s2.x = 3
    assert s1.x == 3
    assert s2.x == 3


# Generated at 2022-06-17 15:39:28.604512
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    assert TestSingleton() is TestSingleton()
    assert TestSingleton().a == 1

# Generated at 2022-06-17 15:39:34.723402
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 1

    a = TestSingleton()
    b = TestSingleton()

    assert a == b
    assert a.value == b.value
    assert a is b
    assert a.value == 1
    assert b.value == 1

    a.value = 2
    assert a.value == 2
    assert b.value == 2

    b.value = 3
    assert a.value == 3
    assert b.value == 3

    c = TestSingleton()
    assert c.value == 3

# Generated at 2022-06-17 15:39:40.387329
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    test_class_1 = TestClass()
    test_class_2 = TestClass()

    assert test_class_1 is test_class_2

# Generated at 2022-06-17 15:39:49.130130
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton
        def __init__(self):
            self.a = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.a == 1
    assert t2.a == 1
    t1.a = 2
    assert t1.a == 2
    assert t2.a == 2
    t2.a = 3
    assert t1.a == 3
    assert t2.a == 3

# Generated at 2022-06-17 15:39:53.601356
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.test == b.test

# Generated at 2022-06-17 15:39:55.761644
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

    a1 = A()
    a2 = A()
    assert a1 == a2


# Generated at 2022-06-17 15:40:00.023960
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:40:18.826578
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()



# Generated at 2022-06-17 15:40:25.720548
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 'test'

    test_singleton = TestSingleton()
    assert test_singleton.test == 'test'

    test_singleton_2 = TestSingleton()
    assert test_singleton_2.test == 'test'

    assert test_singleton is test_singleton_2

# Generated at 2022-06-17 15:40:30.144769
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, val):
            self.val = val

    a = MyClass(1)
    b = MyClass(2)
    assert a.val == 1
    assert b.val == 1
    assert a is b


# Generated at 2022-06-17 15:40:34.421098
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.a == 1
    assert b.a == 1
    a.a = 2
    assert a.a == 2
    assert b.a == 2

# Generated at 2022-06-17 15:40:38.089044
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.arg == 1
    assert b.arg == 1

# Generated at 2022-06-17 15:40:40.682241
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:40:45.484598
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

    a = A()
    b = A()
    assert a is b


# Generated at 2022-06-17 15:40:46.430300
# Unit test for constructor of class Singleton
def test_Singleton():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()

# Generated at 2022-06-17 15:40:48.470737
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:40:50.883115
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:41:29.096894
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b


# Generated at 2022-06-17 15:41:34.628923
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    t1 = Test()
    t2 = Test()
    assert t1 is t2
    assert t1.x == 1
    assert t2.x == 1
    t1.x = 2
    assert t1.x == 2
    assert t2.x == 2


# Generated at 2022-06-17 15:41:43.182899
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1
    a1.a = 2
    assert a1.a == 2
    assert a2.a == 2

# Generated at 2022-06-17 15:41:46.877740
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:41:55.585356
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.x = 1

    t1 = TestSingleton()
    t2 = TestSingleton()
    assert t1 is t2
    assert t1.x == 1
    assert t2.x == 1
    t1.x = 2
    assert t1.x == 2
    assert t2.x == 2

# Generated at 2022-06-17 15:41:59.261657
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, value):
            self.value = value

    a = TestSingleton(1)
    b = TestSingleton(2)
    assert a is b
    assert a.value == 1
    assert b.value == 1

# Generated at 2022-06-17 15:42:03.725845
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test = 1

    a = TestSingleton()
    b = TestSingleton()
    assert a is b
    assert a.test == b.test
    a.test = 2
    assert a.test == b.test

# Generated at 2022-06-17 15:42:07.042646
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == 1
    assert a2.a == 1

# Generated at 2022-06-17 15:42:11.965833
# Unit test for constructor of class Singleton
def test_Singleton():
    class MyClass(object):
        __metaclass__ = Singleton

        def __init__(self, name):
            self.name = name

    a = MyClass('a')
    b = MyClass('b')
    assert a.name == 'a'
    assert b.name == 'a'
    assert a is b

# Generated at 2022-06-17 15:42:16.709904
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.test_var = 'test'

    test_obj1 = TestClass()
    test_obj2 = TestClass()

    assert test_obj1 is test_obj2
    assert test_obj1.test_var == 'test'
    assert test_obj2.test_var == 'test'

# Generated at 2022-06-17 15:43:30.568128
# Unit test for constructor of class Singleton
def test_Singleton():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()

    assert a1 is a2
    assert a1.a == a2.a

# Generated at 2022-06-17 15:43:33.970265
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class A(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1.a == a2.a


# Generated at 2022-06-17 15:43:38.391187
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

    test_class_1 = TestClass()
    test_class_2 = TestClass()

    assert test_class_1 == test_class_2

# Generated at 2022-06-17 15:43:44.701324
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.a = 1

    a = TestClass()
    b = TestClass()
    assert a is b
    assert a.a == b.a
    assert a.a == 1


# Generated at 2022-06-17 15:43:49.593337
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestClass(object):
        __metaclass__ = Singleton

        def __init__(self):
            self.value = 0

    a = TestClass()
    b = TestClass()
    assert a is b
    assert a.value == 0
    assert b.value == 0
    a.value = 1
    assert a.value == 1
    assert b.value == 1
    b.value = 2
    assert a.value == 2
    assert b.value == 2


# Generated at 2022-06-17 15:43:50.593998
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:43:52.881856
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

        def __init__(self, arg):
            self.arg = arg

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)
    assert t1 is t2
    assert t1.arg == 2

# Generated at 2022-06-17 15:43:56.963939
# Unit test for constructor of class Singleton
def test_Singleton():
    class TestSingleton(object):
        __metaclass__ = Singleton

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-17 15:43:58.411854
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class Test(object):
        __metaclass__ = Singleton

    assert Test() is Test()



# Generated at 2022-06-17 15:43:59.950903
# Unit test for method __call__ of class Singleton
def test_Singleton___call__():
    class TestSingleton(object):
        __metaclass__ = Singleton

    test_singleton_1 = TestSingleton()
    test_singleton_2 = TestSingleton()

    assert test_singleton_1 is test_singleton_2